::: easydiffraction.summary
