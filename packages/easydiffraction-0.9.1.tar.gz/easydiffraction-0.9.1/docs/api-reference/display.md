::: easydiffraction.display
