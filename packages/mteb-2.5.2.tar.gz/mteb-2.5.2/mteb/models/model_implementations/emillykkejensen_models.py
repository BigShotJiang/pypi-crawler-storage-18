from mteb.models.model_meta import ModelMeta
from mteb.models.sentence_transformer_wrapper import sentence_transformers_loader

embedding_gemma_300m_scandi = ModelMeta(
    loader=sentence_transformers_loader,  # type: ignore
    name="emillykkejensen/EmbeddingGemma-Scandi-300m",
    model_type=["dense"],
    languages=["dan-Latn", "swe-Latn", "nor-Latn", "nob-Latn", "nno-Latn"],
    open_weights=True,
    revision="9f3307b9f601db564a9190cb475324d128dcfe86",
    release_date="2025-10-17",
    n_parameters=307_581_696,
    embed_dim=768,
    max_tokens=2048,
    license="apache-2.0",
    reference="https://huggingface.co/emillykkejensen/EmbeddingGemma-Scandi-300m",
    framework=["Sentence Transformers", "PyTorch"],
    use_instructions=True,
    public_training_code=None,
    public_training_data="https://huggingface.co/datasets/DDSC/nordic-embedding-training-data",
    training_datasets=set(),
    similarity_fn_name="cosine",  # type: ignore[arg-type]
    adapted_from="google/embeddinggemma-300m",
    memory_usage_mb=578,
    citation="""@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}""",
)


qwen_scandi = ModelMeta(
    loader=sentence_transformers_loader,  # type: ignore
    name="emillykkejensen/Qwen3-Embedding-Scandi-0.6B",
    model_type=["dense"],
    languages=["dan-Latn", "swe-Latn", "nor-Latn", "nob-Latn", "nno-Latn"],
    open_weights=True,
    revision="cf1e7ba36ebd3d605549d8f02930a18e17b54513",
    release_date="2025-10-17",
    n_parameters=595776512,
    memory_usage_mb=2272,
    embed_dim=1024,
    max_tokens=32768,
    license="apache-2.0",
    reference="https://huggingface.co/emillykkejensen/Qwen3-Embedding-Scandi-0.6B",
    framework=["Sentence Transformers", "PyTorch"],
    use_instructions=True,
    public_training_code=None,
    public_training_data="https://huggingface.co/datasets/DDSC/nordic-embedding-training-data",
    training_datasets=set(),
    similarity_fn_name="cosine",  # type: ignore[arg-type]
    adapted_from="Qwen/Qwen3-Embedding-0.6B",
)


mmbert_scandi = ModelMeta(
    loader=sentence_transformers_loader,  # type: ignore
    name="emillykkejensen/mmBERTscandi-base-embedding",
    model_type=["dense"],
    languages=["dan-Latn", "swe-Latn", "nor-Latn", "nob-Latn", "nno-Latn"],
    open_weights=True,
    revision="82d74c7a5d8e1ddf31b132865df2d16b2b0294ee",
    release_date="2025-10-17",
    n_parameters=306939648,
    memory_usage_mb=1171,
    embed_dim=768,
    max_tokens=8192,
    license="apache-2.0",
    reference="https://huggingface.co/emillykkejensen/Qwen3-Embedding-Scandi-0.6B",
    framework=["Sentence Transformers", "PyTorch"],
    use_instructions=True,
    public_training_code=None,
    public_training_data="https://huggingface.co/datasets/DDSC/nordic-embedding-training-data",
    training_datasets=set(),
    similarity_fn_name="cosine",  # type: ignore[arg-type]
    adapted_from="jonasaise/scandmmBERT-base-scandinavian",
    citation="""@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}""",
)
