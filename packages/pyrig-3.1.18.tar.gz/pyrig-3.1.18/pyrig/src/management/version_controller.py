"""Git version control wrapper.

Provides type-safe wrapper for Git commands: init, add, commit, push, tag, config.

Example:
    >>> from pyrig.src.management.version_controller import VersionController
    >>> VersionController.get_add_all_args().run()
    >>> VersionController.get_commit_no_verify_args("Update docs").run()
    >>> VersionController.get_push_args().run()
"""

from pyrig.src.management.base.base import Args, Tool


class VersionController(Tool):
    """Git version control wrapper.

    Constructs git command arguments for version control operations.

    Operations:
        - Repository setup: init
        - Staging: add files, add all
        - Committing: commit with options
        - Remote operations: push, push tags
        - Tagging: create and push tags
        - Configuration: user name/email

    Example:
        >>> VersionController.get_init_args().run()
        >>> VersionController.get_add_all_args().run()
        >>> VersionController.get_commit_no_verify_args("Initial commit").run()
    """

    @classmethod
    def name(cls) -> str:
        """Get tool name.

        Returns:
            'git'
        """
        return "git"

    @classmethod
    def get_init_args(cls, *args: str) -> Args:
        """Construct git init arguments.

        Args:
            *args: Init command arguments.

        Returns:
            Args for 'git init'.
        """
        return cls.get_args("init", *args)

    @classmethod
    def get_add_args(cls, *args: str) -> Args:
        """Construct git add arguments.

        Args:
            *args: Files or paths to add.

        Returns:
            Args for 'git add'.
        """
        return cls.get_args("add", *args)

    @classmethod
    def get_add_all_args(cls, *args: str) -> Args:
        """Construct git add arguments for all files.

        Args:
            *args: Add command arguments.

        Returns:
            Args for 'git add .'.
        """
        return cls.get_add_args(".", *args)

    @classmethod
    def get_add_pyproject_toml_args(cls, *args: str) -> Args:
        """Construct git add arguments for pyproject.toml.

        Args:
            *args: Add command arguments.

        Returns:
            Args for 'git add pyproject.toml'.
        """
        return cls.get_add_args("pyproject.toml", *args)

    @classmethod
    def get_add_pyproject_toml_and_uv_lock_args(cls, *args: str) -> Args:
        """Construct git add arguments for pyproject.toml and uv.lock.

        Args:
            *args: Add command arguments.

        Returns:
            Args for 'git add pyproject.toml uv.lock'.
        """
        return cls.get_add_pyproject_toml_args("uv.lock", *args)

    @classmethod
    def get_commit_args(cls, *args: str) -> Args:
        """Construct git commit arguments.

        Args:
            *args: Commit command arguments.

        Returns:
            Args for 'git commit'.
        """
        return cls.get_args("commit", *args)

    @classmethod
    def get_commit_no_verify_args(cls, msg: str, *args: str) -> Args:
        """Construct git commit arguments with no verification.

        Args:
            msg: Commit message.
            *args: Commit command arguments.

        Returns:
            Args for 'git commit --no-verify -m <msg>'.
        """
        return cls.get_commit_args("--no-verify", "-m", msg, *args)

    @classmethod
    def get_push_args(cls, *args: str) -> Args:
        """Construct git push arguments.

        Args:
            *args: Push command arguments.

        Returns:
            Args for 'git push'.
        """
        return cls.get_args("push", *args)

    @classmethod
    def get_config_args(cls, *args: str) -> Args:
        """Construct git config arguments.

        Args:
            *args: Config command arguments.

        Returns:
            Args for 'git config'.
        """
        return cls.get_args("config", *args)

    @classmethod
    def get_config_global_args(cls, *args: str) -> Args:
        """Construct git config arguments with --global flag.

        Args:
            *args: Config command arguments.

        Returns:
            Args for 'git config --global'.
        """
        return cls.get_config_args("--global", *args)

    @classmethod
    def get_config_local_args(cls, *args: str) -> Args:
        """Construct git config arguments with --local flag.

        Args:
            *args: Config command arguments.

        Returns:
            Args for 'git config --local'.
        """
        return cls.get_config_args("--local", *args)

    @classmethod
    def get_config_local_user_email_args(cls, email: str, *args: str) -> Args:
        """Construct git config arguments for local user email.

        Args:
            email: Email address.
            *args: Config command arguments.

        Returns:
            Args for 'git config --local user.email <email>'.
        """
        return cls.get_config_local_args("user.email", email, *args)

    @classmethod
    def get_config_local_user_name_args(cls, name: str, *args: str) -> Args:
        """Construct git config arguments for local user name.

        Args:
            name: Name.
            *args: Config command arguments.

        Returns:
            Args for 'git config --local user.name <name>'.
        """
        return cls.get_config_local_args("user.name", name, *args)

    @classmethod
    def get_config_global_user_email_args(cls, email: str, *args: str) -> Args:
        """Construct git config arguments for global user email.

        Args:
            email: Email address.
            *args: Config command arguments.

        Returns:
            Args for 'git config --global user.email <email>'.
        """
        return cls.get_config_global_args("user.email", email, *args)

    @classmethod
    def get_config_global_user_name_args(cls, name: str, *args: str) -> Args:
        """Construct git config arguments for global user name.

        Args:
            name: Name.
            *args: Config command arguments.

        Returns:
            Args for 'git config --global user.name <name>'.
        """
        return cls.get_config_global_args("user.name", name, *args)
