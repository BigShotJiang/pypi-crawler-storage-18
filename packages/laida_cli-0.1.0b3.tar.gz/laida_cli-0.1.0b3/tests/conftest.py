"""Pytest configuration and shared fixtures."""

from collections.abc import Generator
from pathlib import Path

import pytest


@pytest.fixture
def tmp_project_dir(tmp_path: Path) -> Generator[Path, None, None]:
    """Create a temporary project directory with LAIDA structure."""
    project_dir = tmp_path / "test_project"
    project_dir.mkdir()

    # Create minimal LAIDA structure
    (project_dir / ".laida").mkdir()
    (project_dir / ".laida" / "prompts").mkdir(parents=True)
    (project_dir / "inputs").mkdir()
    (project_dir / "outputs").mkdir()

    # Create minimal project_context.yaml
    context_file = project_dir / "inputs" / "project_context.yaml"
    context_file.write_text(
        """project_context:
  project_name: "test-project"
  description: "Test project for unit tests"
"""
    )

    yield project_dir


@pytest.fixture
def sample_phase_number() -> int:
    """Return a valid phase number for testing."""
    return 0


@pytest.fixture
def sample_step_number() -> int:
    """Return a valid step number for testing."""
    return 0
