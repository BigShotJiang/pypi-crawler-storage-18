"""TUI Unit Tests."""
