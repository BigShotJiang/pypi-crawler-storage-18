"""Tests for CLI commands."""

from pathlib import Path

from click.testing import CliRunner

from laida_cli.main import cli


class TestCli:
    """Test main CLI group."""

    def test_version_option(self) -> None:
        """Test --version option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_help_option(self) -> None:
        """Test --help option."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "LAIDA" in result.output
        assert "init" in result.output
        assert "status" in result.output
        assert "run" in result.output
        assert "validate" in result.output


class TestStatusCommand:
    """Test status command."""

    def test_status_not_laida_project(self, tmp_path: Path) -> None:
        """Test status on non-LAIDA project."""
        runner = CliRunner()
        result = runner.invoke(cli, ["status", "--path", str(tmp_path)])
        assert result.exit_code == 1
        assert "Not a LAIDA project" in result.output

    def test_status_empty_project(self, tmp_path: Path) -> None:
        """Test status on empty LAIDA project."""
        # Create minimal LAIDA structure
        (tmp_path / ".laida").mkdir()
        (tmp_path / "outputs").mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["status", "--path", str(tmp_path)])
        assert result.exit_code == 0
        assert "Not Started" in result.output or "Phase 0" in result.output

    def test_status_json_output(self, tmp_path: Path) -> None:
        """Test status with JSON output."""
        (tmp_path / ".laida").mkdir()
        (tmp_path / "outputs").mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["status", "--path", str(tmp_path), "--json"])
        assert result.exit_code == 0
        assert "next_phase" in result.output


class TestValidateCommand:
    """Test validate command."""

    def test_validate_not_laida_project(self, tmp_path: Path) -> None:
        """Test validate on non-LAIDA project."""
        runner = CliRunner()
        result = runner.invoke(cli, ["validate", "--path", str(tmp_path)])
        assert result.exit_code == 1
        assert "Not a LAIDA project" in result.output

    def test_validate_missing_context(self, tmp_path: Path) -> None:
        """Test validate with missing project_context.yaml."""
        (tmp_path / ".laida").mkdir()
        (tmp_path / "inputs").mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["validate", "--path", str(tmp_path)])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_validate_valid_context(self, tmp_path: Path) -> None:
        """Test validate with valid project_context.yaml."""
        (tmp_path / ".laida").mkdir()
        (tmp_path / "inputs").mkdir()
        (tmp_path / "outputs").mkdir()

        context_file = tmp_path / "inputs" / "project_context.yaml"
        context_file.write_text("""
project_context:
  project_name: "test-project"
  description: "A test project"
""")

        runner = CliRunner()
        result = runner.invoke(cli, ["validate", "--path", str(tmp_path)])
        assert result.exit_code == 0
        assert "PASS" in result.output or "passed" in result.output.lower()


class TestRunCommand:
    """Test run command."""

    def test_run_not_laida_project(self, tmp_path: Path) -> None:
        """Test run on non-LAIDA project."""
        runner = CliRunner()
        result = runner.invoke(cli, ["run", "0", "0", "--path", str(tmp_path)])
        assert result.exit_code == 1
        assert "Not a LAIDA project" in result.output

    def test_run_dry_run(self, tmp_path: Path) -> None:
        """Test run with --dry-run."""
        (tmp_path / ".laida").mkdir()
        (tmp_path / ".laida" / "prompts").mkdir()
        (tmp_path / "inputs").mkdir()
        (tmp_path / "outputs").mkdir()

        context_file = tmp_path / "inputs" / "project_context.yaml"
        context_file.write_text("""
project_context:
  project_name: "test"
  description: "test"
""")

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["run", "0", "0", "--path", str(tmp_path), "--dry-run"]
        )
        # Dry run should show plan without executing
        assert "Dry run" in result.output or "Plan" in result.output

    def test_run_invalid_phase(self) -> None:
        """Test run with invalid phase number."""
        runner = CliRunner()
        result = runner.invoke(cli, ["run", "5", "0"])
        assert result.exit_code != 0
        # Click should reject invalid range

    def test_run_invalid_step(self) -> None:
        """Test run with invalid step number."""
        runner = CliRunner()
        result = runner.invoke(cli, ["run", "0", "4"])
        assert result.exit_code != 0
        # Click should reject invalid range
