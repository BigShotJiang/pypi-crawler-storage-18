"""Tests for DetectStateService."""

from pathlib import Path

from laida_cli.services.detect_state import DetectStateService, ProjectState


class TestProjectState:
    """Test ProjectState dataclass."""

    def test_has_started_false_when_no_completion(self) -> None:
        """Test has_started is False when nothing completed."""
        state = ProjectState(
            last_completed_phase=None,
            last_completed_step=None,
            next_phase=0,
            next_step=0,
            is_complete=False,
        )
        assert not state.has_started

    def test_has_started_true_when_phase_completed(self) -> None:
        """Test has_started is True when a phase is completed."""
        state = ProjectState(
            last_completed_phase=0,
            last_completed_step=0,
            next_phase=0,
            next_step=1,
            is_complete=False,
        )
        assert state.has_started

    def test_str_not_started(self) -> None:
        """Test string representation when not started."""
        state = ProjectState(
            last_completed_phase=None,
            last_completed_step=None,
            next_phase=0,
            next_step=0,
            is_complete=False,
        )
        assert "not started" in str(state).lower()

    def test_str_complete(self) -> None:
        """Test string representation when complete."""
        state = ProjectState(
            last_completed_phase=4,
            last_completed_step=3,
            next_phase=4,
            next_step=3,
            is_complete=True,
        )
        assert "complete" in str(state).lower()


class TestDetectStateService:
    """Test DetectStateService."""

    def test_detect_empty_project(self, tmp_path: Path) -> None:
        """Test detecting state of empty project."""
        service = DetectStateService()
        state = service.detect(tmp_path)

        assert state.last_completed_phase is None
        assert state.last_completed_step is None
        assert state.next_phase == 0
        assert state.next_step == 0
        assert not state.is_complete

    def test_detect_with_phase0_step0_complete(self, tmp_path: Path) -> None:
        """Test detecting state after phase 0 step 0 is complete."""
        # Create outputs structure
        step_dir = tmp_path / "outputs" / "phase0" / "step0_profiling"
        step_dir.mkdir(parents=True)
        (step_dir / "_index.yaml").write_text("step0: complete")

        service = DetectStateService()
        state = service.detect(tmp_path)

        assert state.last_completed_phase == 0
        assert state.last_completed_step == 0
        assert state.next_phase == 0
        assert state.next_step == 1
        assert not state.is_complete

    def test_detect_complete_project(self, tmp_path: Path) -> None:
        """Test detecting fully complete project."""
        # Create all phases and steps
        for phase in range(5):
            for step in range(4):
                step_dir = tmp_path / "outputs" / f"phase{phase}" / f"step{step}_test"
                step_dir.mkdir(parents=True)
                (step_dir / "_index.yaml").write_text(f"phase{phase} step{step}: complete")

        service = DetectStateService()
        state = service.detect(tmp_path)

        assert state.last_completed_phase == 4
        assert state.last_completed_step == 3
        assert state.is_complete

    def test_get_step_name(self) -> None:
        """Test getting step directory names."""
        service = DetectStateService()

        assert service.get_step_name(0, 0) == "step0_profiling"
        assert service.get_step_name(0, 1) == "step1_foundation"
        assert service.get_step_name(4, 0) == "step0_environment_scaffolding"
        assert service.get_step_name(4, 3) == "step3_verification_release"

    def test_get_step_name_unknown(self) -> None:
        """Test getting step name for unknown phase."""
        service = DetectStateService()
        # Unknown phase should return a fallback
        assert "step" in service.get_step_name(99, 0)
