"""Tests for ExecutionStatus enum."""

from laida_cli.domain.execution_status import ExecutionStatus


class TestExecutionStatus:
    """Test ExecutionStatus enum."""

    def test_pending_is_not_terminal(self) -> None:
        """Test that PENDING is not a terminal state."""
        assert not ExecutionStatus.PENDING.is_terminal()

    def test_running_is_not_terminal(self) -> None:
        """Test that RUNNING is not a terminal state."""
        assert not ExecutionStatus.RUNNING.is_terminal()

    def test_completed_is_terminal(self) -> None:
        """Test that COMPLETED is a terminal state."""
        assert ExecutionStatus.COMPLETED.is_terminal()

    def test_failed_is_terminal(self) -> None:
        """Test that FAILED is a terminal state."""
        assert ExecutionStatus.FAILED.is_terminal()

    def test_pending_can_transition_to_running(self) -> None:
        """Test PENDING -> RUNNING transition is valid."""
        assert ExecutionStatus.PENDING.can_transition_to(ExecutionStatus.RUNNING)

    def test_pending_cannot_transition_to_completed(self) -> None:
        """Test PENDING -> COMPLETED transition is invalid."""
        assert not ExecutionStatus.PENDING.can_transition_to(ExecutionStatus.COMPLETED)

    def test_running_can_transition_to_completed(self) -> None:
        """Test RUNNING -> COMPLETED transition is valid."""
        assert ExecutionStatus.RUNNING.can_transition_to(ExecutionStatus.COMPLETED)

    def test_running_can_transition_to_failed(self) -> None:
        """Test RUNNING -> FAILED transition is valid."""
        assert ExecutionStatus.RUNNING.can_transition_to(ExecutionStatus.FAILED)

    def test_completed_cannot_transition(self) -> None:
        """Test COMPLETED cannot transition to any state."""
        assert not ExecutionStatus.COMPLETED.can_transition_to(ExecutionStatus.PENDING)
        assert not ExecutionStatus.COMPLETED.can_transition_to(ExecutionStatus.RUNNING)
        assert not ExecutionStatus.COMPLETED.can_transition_to(ExecutionStatus.FAILED)

    def test_failed_cannot_transition(self) -> None:
        """Test FAILED cannot transition to any state."""
        assert not ExecutionStatus.FAILED.can_transition_to(ExecutionStatus.PENDING)
        assert not ExecutionStatus.FAILED.can_transition_to(ExecutionStatus.RUNNING)
        assert not ExecutionStatus.FAILED.can_transition_to(ExecutionStatus.COMPLETED)

    def test_enum_values(self) -> None:
        """Test enum string values."""
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"
