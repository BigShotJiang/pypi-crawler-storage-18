"""Tests for ValidationResult value object."""

from laida_cli.domain.validation_result import ValidationResult


class TestValidationResult:
    """Test ValidationResult value object."""

    def test_success_creation(self) -> None:
        """Test creating a successful result."""
        result = ValidationResult.success()
        assert result.is_valid is True
        assert result.errors == []
        assert result.warnings == []

    def test_failure_creation(self) -> None:
        """Test creating a failed result."""
        result = ValidationResult.failure(["Error 1", "Error 2"])
        assert result.is_valid is False
        assert result.errors == ["Error 1", "Error 2"]
        assert result.warnings == []

    def test_with_warnings_creation(self) -> None:
        """Test creating result with warnings."""
        result = ValidationResult.with_warnings(["Warning 1"])
        assert result.is_valid is True
        assert result.errors == []
        assert result.warnings == ["Warning 1"]

    def test_str_valid(self) -> None:
        """Test string representation of valid result."""
        result = ValidationResult.success()
        assert str(result) == "Valid"

    def test_str_valid_with_warnings(self) -> None:
        """Test string representation of valid result with warnings."""
        result = ValidationResult.with_warnings(["W1", "W2"])
        assert "2 warning" in str(result)

    def test_str_invalid(self) -> None:
        """Test string representation of invalid result."""
        result = ValidationResult.failure(["E1", "E2", "E3"])
        assert "3 error" in str(result)
        assert "Invalid" in str(result)
