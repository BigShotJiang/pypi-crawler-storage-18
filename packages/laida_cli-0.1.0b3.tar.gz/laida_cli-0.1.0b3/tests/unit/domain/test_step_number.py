"""Tests for StepNumber value object."""

import pytest

from laida_cli.domain.step_number import StepNumber


class TestStepNumber:
    """Test StepNumber value object."""

    def test_create_valid_step_0(self) -> None:
        """Test creating step 0."""
        step = StepNumber.from_int(0)
        assert step.value == 0

    def test_create_valid_step_3(self) -> None:
        """Test creating step 3."""
        step = StepNumber.from_int(3)
        assert step.value == 3

    def test_create_invalid_step_negative(self) -> None:
        """Test that negative step raises ValueError."""
        with pytest.raises(ValueError, match="Step must be 0-3"):
            StepNumber.from_int(-1)

    def test_create_invalid_step_too_high(self) -> None:
        """Test that step > 3 raises ValueError."""
        with pytest.raises(ValueError, match="Step must be 0-3"):
            StepNumber.from_int(4)

    def test_immutability(self) -> None:
        """Test that StepNumber is immutable."""
        step = StepNumber.from_int(1)
        with pytest.raises(AttributeError):
            step.value = 2  # type: ignore

    def test_str_representation(self) -> None:
        """Test string representation."""
        step = StepNumber.from_int(2)
        assert str(step) == "Step 2"

    def test_equality(self) -> None:
        """Test equality of StepNumber instances."""
        step1 = StepNumber.from_int(1)
        step2 = StepNumber.from_int(1)
        assert step1 == step2
