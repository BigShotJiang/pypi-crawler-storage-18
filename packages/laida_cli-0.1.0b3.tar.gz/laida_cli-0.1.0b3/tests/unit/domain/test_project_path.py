"""Tests for ProjectPath value object."""

from pathlib import Path

import pytest

from laida_cli.domain.project_path import ProjectPath


class TestProjectPath:
    """Test ProjectPath value object."""

    def test_create_from_string_with_absolute_path(self, tmp_path: Path) -> None:
        """Test creating from absolute path string."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert project_path.path == tmp_path
        assert project_path.path.is_absolute()

    def test_create_from_relative_path_resolves(self, tmp_path: Path) -> None:
        """Test that relative paths are resolved to absolute."""
        # Create a subdirectory
        subdir = tmp_path / "project"
        subdir.mkdir()

        # Change to parent and use relative path
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            project_path = ProjectPath.from_string("project")
            assert project_path.path.is_absolute()
            assert project_path.path == subdir
        finally:
            os.chdir(original_cwd)

    def test_create_fails_for_nonexistent_path(self) -> None:
        """Test that nonexistent path raises ValueError."""
        with pytest.raises(ValueError, match="does not exist"):
            ProjectPath.from_string("/nonexistent/path/12345")

    def test_current_directory(self) -> None:
        """Test creating from current directory."""
        project_path = ProjectPath.current()
        assert project_path.path == Path.cwd()
        assert project_path.path.is_absolute()

    def test_outputs_dir(self, tmp_path: Path) -> None:
        """Test outputs_dir method."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert project_path.outputs_dir() == tmp_path / "outputs"

    def test_inputs_dir(self, tmp_path: Path) -> None:
        """Test inputs_dir method."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert project_path.inputs_dir() == tmp_path / "inputs"

    def test_laida_dir(self, tmp_path: Path) -> None:
        """Test laida_dir method."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert project_path.laida_dir() == tmp_path / ".laida"

    def test_prompts_dir(self, tmp_path: Path) -> None:
        """Test prompts_dir method."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert project_path.prompts_dir() == tmp_path / ".laida" / "prompts"

    def test_str_representation(self, tmp_path: Path) -> None:
        """Test string representation."""
        project_path = ProjectPath.from_string(str(tmp_path))
        assert str(project_path) == str(tmp_path)

    def test_immutability(self, tmp_path: Path) -> None:
        """Test that ProjectPath is immutable."""
        project_path = ProjectPath.from_string(str(tmp_path))
        with pytest.raises(AttributeError):
            project_path.path = Path("/other")  # type: ignore
