"""Tests for ExecutionResult value object."""

import pytest

from laida_cli.domain.execution_result import ExecutionResult


class TestExecutionResult:
    """Test ExecutionResult value object."""

    def test_success_result_creation(self) -> None:
        """Test creating a successful result."""
        result = ExecutionResult.success_result(
            output_files=["file1.yaml", "file2.yaml"],
            tokens_used=100,
        )
        assert result.success is True
        assert result.output_files == ["file1.yaml", "file2.yaml"]
        assert result.error_message is None
        assert result.tokens_used == 100

    def test_failure_result_creation(self) -> None:
        """Test creating a failed result."""
        result = ExecutionResult.failure_result(
            error_message="Something went wrong",
            tokens_used=50,
        )
        assert result.success is False
        assert result.output_files == []
        assert result.error_message == "Something went wrong"
        assert result.tokens_used == 50

    def test_failure_requires_error_message(self) -> None:
        """Test that failure without error message raises ValueError."""
        with pytest.raises(ValueError, match="error message"):
            ExecutionResult(
                success=False,
                output_files=[],
                error_message=None,
            )

    def test_success_allows_no_error_message(self) -> None:
        """Test that success with no error message is valid."""
        result = ExecutionResult(
            success=True,
            output_files=["file.yaml"],
            error_message=None,
        )
        assert result.success is True
        assert result.error_message is None

    def test_immutability(self) -> None:
        """Test that ExecutionResult is immutable."""
        result = ExecutionResult.success_result(["file.yaml"], 100)
        with pytest.raises(AttributeError):
            result.success = False  # type: ignore

    def test_str_representation_success(self) -> None:
        """Test string representation of successful result."""
        result = ExecutionResult.success_result(["a.yaml", "b.yaml"], 100)
        assert "Success" in str(result)
        assert "2 files" in str(result)

    def test_str_representation_failure(self) -> None:
        """Test string representation of failed result."""
        result = ExecutionResult.failure_result("Timeout error")
        assert "Failed" in str(result)
        assert "Timeout error" in str(result)

    def test_default_tokens_used(self) -> None:
        """Test default tokens_used value."""
        result = ExecutionResult.failure_result("Error")
        assert result.tokens_used == 0
