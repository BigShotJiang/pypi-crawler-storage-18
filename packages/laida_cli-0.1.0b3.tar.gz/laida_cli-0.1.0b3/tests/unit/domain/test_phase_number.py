"""Tests for PhaseNumber value object."""

import pytest

from laida_cli.domain.phase_number import PhaseNumber


class TestPhaseNumber:
    """Test PhaseNumber value object."""

    def test_create_valid_phase_0(self) -> None:
        """Test creating phase 0."""
        phase = PhaseNumber.from_int(0)
        assert phase.value == 0

    def test_create_valid_phase_4(self) -> None:
        """Test creating phase 4."""
        phase = PhaseNumber.from_int(4)
        assert phase.value == 4

    def test_create_invalid_phase_negative(self) -> None:
        """Test that negative phase raises ValueError."""
        with pytest.raises(ValueError, match="Phase must be 0-4"):
            PhaseNumber.from_int(-1)

    def test_create_invalid_phase_too_high(self) -> None:
        """Test that phase > 4 raises ValueError."""
        with pytest.raises(ValueError, match="Phase must be 0-4"):
            PhaseNumber.from_int(5)

    def test_next_from_phase_0(self) -> None:
        """Test next() from phase 0."""
        phase = PhaseNumber.from_int(0)
        next_phase = phase.next()
        assert next_phase is not None
        assert next_phase.value == 1

    def test_next_from_phase_3(self) -> None:
        """Test next() from phase 3."""
        phase = PhaseNumber.from_int(3)
        next_phase = phase.next()
        assert next_phase is not None
        assert next_phase.value == 4

    def test_next_from_phase_4_returns_none(self) -> None:
        """Test that next() from phase 4 returns None."""
        phase = PhaseNumber.from_int(4)
        assert phase.next() is None

    def test_immutability(self) -> None:
        """Test that PhaseNumber is immutable."""
        phase = PhaseNumber.from_int(2)
        with pytest.raises(AttributeError):
            phase.value = 3  # type: ignore

    def test_str_representation(self) -> None:
        """Test string representation."""
        phase = PhaseNumber.from_int(2)
        assert str(phase) == "Phase 2"

    def test_equality(self) -> None:
        """Test equality of PhaseNumber instances."""
        phase1 = PhaseNumber.from_int(2)
        phase2 = PhaseNumber.from_int(2)
        assert phase1 == phase2

    def test_inequality(self) -> None:
        """Test inequality of PhaseNumber instances."""
        phase1 = PhaseNumber.from_int(1)
        phase2 = PhaseNumber.from_int(2)
        assert phase1 != phase2
