# Adapters unit tests
