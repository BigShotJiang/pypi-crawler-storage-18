"""MainScreen - Primary Mission Control dashboard.

Contract: CNT-TUI-SCR-001
Traceability: UX-001, UI-002
"""

from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Footer, Header, Static

from laida_cli.tui.services.telemetry_service import TelemetryService
from laida_cli.tui.widgets.file_tree import FileTreeWidget
from laida_cli.tui.widgets.git_status import GitStatusWidget
from laida_cli.tui.widgets.live_feed import LiveFeedWidget
from laida_cli.tui.widgets.progress_panel import ProgressPanel
from laida_cli.tui.widgets.quick_actions import QuickActionsWidget
from laida_cli.tui.widgets.telemetry_bar import TelemetryBar


class PlaceholderWidget(Static):
    """Temporary placeholder for widgets not yet implemented."""

    DEFAULT_CSS = """
    PlaceholderWidget {
        border: round #4c1d95;
        padding: 1 2;
        margin: 0 1 1 1;
        height: auto;
        min-height: 5;
    }
    """

    def __init__(self, title: str, icon: str = "📦", **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._title = title
        self._icon = icon

    def render(self) -> str:
        return f"[bold #a78bfa]{self._icon} {self._title}[/]\n[#64748b]Coming soon...[/]"


class MainScreen(Screen[None]):
    """Main Mission Control dashboard screen.

    Layout:
    - Header with LAIDA branding
    - 30/70 split: Sidebar (context) | Main viewer (live feed)
    - Telemetry bar at bottom
    - Footer with keybindings
    """

    DEFAULT_CSS = """
    MainScreen {
        background: #0f0a1a;
    }

    #main-layout {
        height: 1fr;
    }

    #sidebar {
        width: 30%;
        border-right: solid #8b5cf6;
        padding: 1 0;
    }

    #main-panel {
        width: 70%;
        padding: 1 0;
    }
    """

    def __init__(
        self,
        project_path: Path,
        telemetry_service: TelemetryService | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the main screen.

        Args:
            project_path: Path to LAIDA project
            telemetry_service: Shared telemetry service
            **kwargs: Additional screen arguments
        """
        super().__init__(**kwargs)
        self._project_path = project_path
        self._telemetry_service = telemetry_service or TelemetryService()

    def compose(self) -> ComposeResult:
        """Compose the screen layout."""
        yield Header()

        with Horizontal(id="main-layout"):
            # Sidebar (30%)
            with Vertical(id="sidebar"):
                yield FileTreeWidget(project_path=self._project_path)
                yield GitStatusWidget(project_path=self._project_path)
                yield ProgressPanel(project_path=self._project_path)

            # Main panel (70%)
            with Vertical(id="main-panel"):
                yield LiveFeedWidget()
                yield QuickActionsWidget()

        yield TelemetryBar(telemetry_service=self._telemetry_service)
        yield Footer()

    @property
    def project_path(self) -> Path:
        """Get the project path."""
        return self._project_path
