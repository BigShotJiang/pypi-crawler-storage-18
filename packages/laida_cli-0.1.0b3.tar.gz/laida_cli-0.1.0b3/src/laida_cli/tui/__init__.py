"""LAIDA TUI - Mission Control Interface.

Contract: CNT-TUI-001
Traceability: UX-001, UI-002

This package provides a Textual-based TUI for monitoring and controlling
LAIDA methodology execution with real-time telemetry and feedback.
"""

from laida_cli.tui.app import TUIApp

__all__ = ["TUIApp"]
