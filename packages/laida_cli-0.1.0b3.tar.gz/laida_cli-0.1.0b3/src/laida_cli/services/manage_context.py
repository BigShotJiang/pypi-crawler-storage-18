"""ManageContextService - Clear Claude context window.

Contract: CNT-T2-SVC-003
Traceability: UC-003, BR-001
"""

from laida_cli.ports.claude_code_port import ClaudeCodePort


class ManageContextService:
    """Service for managing Claude Code context.

    BR-001: Clear Claude Code context before each step execution
    to ensure consistent behavior.
    """

    def __init__(self, claude_port: ClaudeCodePort) -> None:
        """Initialize with Claude Code port.

        Args:
            claude_port: Port for Claude Code interaction
        """
        self._claude_port = claude_port

    def clear_context(self) -> bool:
        """Clear Claude Code context window.

        Returns:
            True if context was cleared successfully
        """
        return self._claude_port.send_command("/clear")
