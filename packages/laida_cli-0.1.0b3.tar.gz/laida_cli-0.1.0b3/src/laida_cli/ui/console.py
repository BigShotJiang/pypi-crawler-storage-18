"""LaidaConsole - Pre-themed Rich Console for LAIDA CLI.

Contract: CNT-T5-UI-003
Traceability: UI-002

Responsibility: Provide a themed console with helper methods for
consistent UI output across all LAIDA CLI commands.
"""

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from laida_cli.ui.theme import LAIDA_THEME, Styles


class LaidaConsole(Console):
    """Rich Console pre-configured with LAIDA theme.

    Extends Console with helper methods for common LAIDA output patterns.

    Usage:
        console = LaidaConsole()
        console.header("LAIDA Execution")
        console.success("Operation completed!")
        console.error("Something went wrong")
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize with LAIDA theme.

        Args:
            **kwargs: Additional Console arguments
        """
        super().__init__(theme=LAIDA_THEME, **kwargs)

    # --- Status output methods ---

    def success(self, message: str) -> None:
        """Print a success message.

        Args:
            message: The success message
        """
        self.print(f"[{Styles.SUCCESS}]{message}[/{Styles.SUCCESS}]")

    def error(self, message: str, prefix: str = "Error:") -> None:
        """Print an error message.

        Args:
            message: The error message
            prefix: Prefix label (default: "Error:")
        """
        self.print(f"[{Styles.ERROR}]{prefix}[/{Styles.ERROR}] {message}")

    def warning(self, message: str, prefix: str = "Warning:") -> None:
        """Print a warning message.

        Args:
            message: The warning message
            prefix: Prefix label (default: "Warning:")
        """
        self.print(f"[{Styles.WARNING}]{prefix}[/{Styles.WARNING}] {message}")

    def info(self, message: str) -> None:
        """Print an info message.

        Args:
            message: The info message
        """
        self.print(f"[{Styles.INFO}]{message}[/{Styles.INFO}]")

    def muted(self, message: str) -> None:
        """Print muted/secondary text.

        Args:
            message: The muted message
        """
        self.print(f"[{Styles.MUTED}]{message}[/{Styles.MUTED}]")

    def hint(self, message: str) -> None:
        """Print a hint message.

        Args:
            message: The hint message
        """
        self.print(f"[{Styles.HINT}]{message}[/{Styles.HINT}]")

    # --- Header methods ---

    def header(self, title: str) -> None:
        """Print a section header.

        Args:
            title: The header title
        """
        self.print(f"[{Styles.HEADER}]{title}[/{Styles.HEADER}]")

    def subheader(self, title: str) -> None:
        """Print a sub-section header.

        Args:
            title: The subheader title
        """
        self.print(f"[{Styles.SUBHEADER}]{title}[/{Styles.SUBHEADER}]")

    # --- Phase/Step methods ---

    def phase_header(self, phase: int, step: int, name: str) -> None:
        """Print phase/step execution header.

        Args:
            phase: Phase number (0-4)
            step: Step number (0-3)
            name: Step name
        """
        self.print()
        self.print(f"[{Styles.HEADER}]LAIDA Execution[/{Styles.HEADER}]")
        self.print(f"Phase {phase} Step {step}: {name}")

    def phase_info(self, label: str, value: str) -> None:
        """Print phase-related info line.

        Args:
            label: The label
            value: The value
        """
        self.print(f"{label}: [{Styles.MUTED}]{value}[/{Styles.MUTED}]")

    # --- Validation methods ---

    def validation_pass(self, message: str) -> None:
        """Print a validation pass result.

        Args:
            message: The pass message
        """
        self.print(f"[{Styles.PASS}]PASS[/{Styles.PASS}] {message}")

    def validation_fail(self, message: str) -> None:
        """Print a validation fail result.

        Args:
            message: The fail message
        """
        self.print(f"[{Styles.FAIL}]FAIL[/{Styles.FAIL}] {message}")

    def validation_warn(self, message: str) -> None:
        """Print a validation warning.

        Args:
            message: The warning message
        """
        self.print(f"[{Styles.WARN}]WARN[/{Styles.WARN}] {message}")

    def validation_skip(self, message: str) -> None:
        """Print a validation skip result.

        Args:
            message: The skip message
        """
        self.print(f"[{Styles.SKIP}]SKIP[/{Styles.SKIP}] {message}")

    # --- Panel helpers ---

    def branded_panel(
        self,
        content: str | Text,
        title: str | None = None,
        subtitle: str | None = None,
    ) -> None:
        """Print a LAIDA-branded panel.

        Args:
            content: Panel content
            title: Optional title
            subtitle: Optional subtitle
        """
        panel = Panel(
            content,
            title=f"[{Styles.PANEL_TITLE}]{title}[/{Styles.PANEL_TITLE}]" if title else None,
            subtitle=f"[{Styles.PANEL_SUBTITLE}]{subtitle}[/{Styles.PANEL_SUBTITLE}]" if subtitle else None,
            border_style=Styles.PANEL_BORDER,
            padding=(0, 1),
        )
        self.print(panel)

    # --- Table helpers ---

    def create_table(
        self,
        *columns: str,
        show_header: bool = True,
    ) -> Table:
        """Create a LAIDA-styled table.

        Args:
            *columns: Column names
            show_header: Whether to show header row

        Returns:
            Configured Rich Table
        """
        table = Table(
            show_header=show_header,
            header_style=Styles.HEADER,
        )
        for col in columns:
            table.add_column(col)
        return table

    def status_table(self) -> Table:
        """Create a table for status display (Property/Value).

        Returns:
            Configured Rich Table for status display
        """
        return self.create_table("Property", "Value")


# Singleton instance for module-level import
console = LaidaConsole()
