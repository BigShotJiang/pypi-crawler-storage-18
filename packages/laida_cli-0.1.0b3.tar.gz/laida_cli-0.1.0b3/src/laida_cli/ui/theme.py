"""LAIDA Theme - Centralized color palette and semantic styles.

Contract: CNT-T5-UI-002
Traceability: UI-002

Responsibility: Define a consistent, semantic color palette for LAIDA CLI.
All UI components should use these styles for visual consistency.
"""

from rich.theme import Theme

# Semantic color definitions
# Professional palette: muted tones, no pure primaries
# Inspired by modern terminal themes (Dracula, Nord, Tokyo Night)
LAIDA_STYLES = {
    # Brand colors - Violet/Purple accent (distinctive, not typical CLI blue)
    "laida.brand": "bold #a78bfa",           # Soft violet
    "laida.brand.dim": "#7c3aed",            # Deeper violet

    # Status indicators - Softer, less aggressive colors
    "laida.success": "#10b981",              # Emerald green (not pure green)
    "laida.error": "bold #f87171",           # Soft red (not aggressive)
    "laida.warning": "#fbbf24",              # Amber (warmer than yellow)
    "laida.info": "#60a5fa",                 # Sky blue

    # Semantic elements
    "laida.header": "bold #e2e8f0",          # Slate white
    "laida.subheader": "#94a3b8",            # Slate gray
    "laida.muted": "#64748b",                # Darker slate
    "laida.hint": "italic #64748b",          # Muted italic

    # Agent/AI output - Cyan/Teal tones for AI feel
    "laida.agent": "#5eead4",                # Teal (AI output)
    "laida.agent.thinking": "italic #c084fc", # Purple italic (thinking)
    "laida.agent.action": "#22d3ee",         # Cyan (actions)

    # Phase/Step execution
    "laida.phase": "bold #818cf8",           # Indigo
    "laida.step": "#a5b4fc",                 # Light indigo
    "laida.progress": "#5eead4",             # Teal

    # Validation states
    "laida.pass": "bold #10b981",            # Emerald
    "laida.fail": "bold #f87171",            # Soft red
    "laida.skip": "#fbbf24",                 # Amber
    "laida.warn": "#fb923c",                 # Orange (distinct from skip)

    # Table styling
    "laida.table.header": "bold #e2e8f0",    # Slate white
    "laida.table.row.even": "",
    "laida.table.row.odd": "#475569",        # Slate

    # Panel borders - Violet accent
    "laida.panel.border": "#8b5cf6",         # Violet
    "laida.panel.title": "bold #a78bfa",     # Soft violet
    "laida.panel.subtitle": "#94a3b8",       # Slate gray
}

# Create the theme instance
LAIDA_THEME = Theme(LAIDA_STYLES)


# Style constants for direct use (avoid magic strings)
class Styles:
    """Style constants for type-safe style references."""

    # Brand
    BRAND = "laida.brand"
    BRAND_DIM = "laida.brand.dim"

    # Status
    SUCCESS = "laida.success"
    ERROR = "laida.error"
    WARNING = "laida.warning"
    INFO = "laida.info"

    # Text
    HEADER = "laida.header"
    SUBHEADER = "laida.subheader"
    MUTED = "laida.muted"
    HINT = "laida.hint"

    # Agent
    AGENT = "laida.agent"
    AGENT_THINKING = "laida.agent.thinking"
    AGENT_ACTION = "laida.agent.action"

    # Execution
    PHASE = "laida.phase"
    STEP = "laida.step"
    PROGRESS = "laida.progress"

    # Validation
    PASS = "laida.pass"
    FAIL = "laida.fail"
    SKIP = "laida.skip"
    WARN = "laida.warn"

    # Panel
    PANEL_BORDER = "laida.panel.border"
    PANEL_TITLE = "laida.panel.title"
    PANEL_SUBTITLE = "laida.panel.subtitle"
