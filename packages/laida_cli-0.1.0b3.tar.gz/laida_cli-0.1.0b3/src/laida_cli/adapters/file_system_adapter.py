"""FileSystemAdapter - File system operations abstraction.

Contract: CNT-T3-ADP-001
Implements: FileSystemPort
"""

from pathlib import Path

from laida_cli.ports.file_system_port import FileSystemPort


class FileSystemAdapter:
    """Adapter for file system operations."""

    def read_file(self, path: Path) -> str:
        """Read file contents.

        Args:
            path: Path to the file

        Returns:
            File contents as string

        Raises:
            FileNotFoundError: If file does not exist
        """
        return path.read_text(encoding="utf-8")

    def write_file(self, path: Path, content: str) -> None:
        """Write content to file.

        Args:
            path: Path to the file
            content: Content to write
        """
        path.write_text(content, encoding="utf-8")

    def file_exists(self, path: Path) -> bool:
        """Check if file exists.

        Args:
            path: Path to check

        Returns:
            True if file exists
        """
        return path.is_file()

    def directory_exists(self, path: Path) -> bool:
        """Check if directory exists.

        Args:
            path: Path to check

        Returns:
            True if directory exists
        """
        return path.is_dir()

    def list_directory(self, path: Path, pattern: str = "*") -> list[Path]:
        """List directory contents matching pattern.

        Args:
            path: Directory path
            pattern: Glob pattern (default: "*")

        Returns:
            List of matching paths
        """
        if not path.is_dir():
            return []
        return list(path.glob(pattern))

    def ensure_directory(self, path: Path) -> None:
        """Ensure directory exists, creating if necessary.

        Args:
            path: Directory path to ensure exists
        """
        path.mkdir(parents=True, exist_ok=True)


# Compile-time check that adapter implements the protocol
_: FileSystemPort = FileSystemAdapter()
