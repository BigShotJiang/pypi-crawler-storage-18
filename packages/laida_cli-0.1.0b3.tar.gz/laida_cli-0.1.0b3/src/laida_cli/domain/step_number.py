"""StepNumber - Value object for LAIDA step number (0-3).

Contract: CNT-T0-DOM-002
Traceability: UC-001, INV-002
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class StepNumber:
    """Immutable value object representing LAIDA step number (0-3).

    Invariant INV-002: 0 <= value <= 3
    """

    value: int

    def __post_init__(self) -> None:
        """Validate invariant INV-002."""
        if not (0 <= self.value <= 3):
            raise ValueError(f"Step must be 0-3, got {self.value}")

    @classmethod
    def from_int(cls, value: int) -> StepNumber:
        """Create StepNumber from integer.

        Args:
            value: Step number (0-3)

        Returns:
            StepNumber instance

        Raises:
            ValueError: If value is not in range 0-3
        """
        return cls(value=value)

    def __str__(self) -> str:
        """Return string representation."""
        return f"Step {self.value}"
