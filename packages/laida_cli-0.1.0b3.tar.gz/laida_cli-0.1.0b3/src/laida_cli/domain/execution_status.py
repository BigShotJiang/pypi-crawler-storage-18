"""ExecutionStatus - Enum for phase execution state machine.

Contract: CNT-T0-DOM-005
Traceability: UC-001, INV-010
"""

from enum import Enum


class ExecutionStatus(str, Enum):
    """Execution state machine states.

    State transitions:
    - PENDING -> RUNNING (execute() called)
    - RUNNING -> COMPLETED (execution succeeds)
    - RUNNING -> FAILED (execution fails)
    """

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

    def is_terminal(self) -> bool:
        """Check if this is a terminal state."""
        return self in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED)

    def can_transition_to(self, target: "ExecutionStatus") -> bool:
        """Check if transition to target state is valid."""
        valid_transitions = {
            ExecutionStatus.PENDING: {ExecutionStatus.RUNNING},
            ExecutionStatus.RUNNING: {ExecutionStatus.COMPLETED, ExecutionStatus.FAILED},
            ExecutionStatus.COMPLETED: set(),
            ExecutionStatus.FAILED: set(),
        }
        return target in valid_transitions.get(self, set())
