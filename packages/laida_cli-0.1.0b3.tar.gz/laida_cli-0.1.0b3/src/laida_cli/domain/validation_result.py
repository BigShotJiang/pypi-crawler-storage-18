"""ValidationResult - Value object for validation outcomes.

Contract: CNT-T0-DOM-007
Traceability: UC-004, UC-005
"""

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ValidationResult:
    """Immutable value object representing validation outcome."""

    is_valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @classmethod
    def success(cls) -> "ValidationResult":
        """Create a successful validation result."""
        return cls(is_valid=True)

    @classmethod
    def failure(cls, errors: list[str]) -> "ValidationResult":
        """Create a failed validation result.

        Args:
            errors: List of error messages
        """
        return cls(is_valid=False, errors=errors)

    @classmethod
    def with_warnings(cls, warnings: list[str]) -> "ValidationResult":
        """Create a successful validation result with warnings.

        Args:
            warnings: List of warning messages
        """
        return cls(is_valid=True, warnings=warnings)

    def __str__(self) -> str:
        """Return human-readable validation status."""
        if self.is_valid:
            if self.warnings:
                return f"Valid with {len(self.warnings)} warning(s)"
            return "Valid"
        return f"Invalid: {len(self.errors)} error(s)"
