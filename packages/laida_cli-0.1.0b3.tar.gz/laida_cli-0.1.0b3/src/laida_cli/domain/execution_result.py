"""ExecutionResult - Value object for phase execution outcome.

Contract: CNT-T0-DOM-003
Traceability: UC-001, INV-003, BR-002
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    """Immutable value object representing phase execution outcome.

    Invariant INV-003: not success implies error_message is not None
    """

    success: bool
    output_files: list[str] = field(default_factory=list)
    error_message: str | None = None
    tokens_used: int = 0

    def __post_init__(self) -> None:
        """Validate invariant INV-003."""
        if not self.success and self.error_message is None:
            raise ValueError("Failed execution must have an error message")

    @classmethod
    def success_result(
        cls,
        output_files: list[str],
        tokens_used: int = 0,
    ) -> ExecutionResult:
        """Create a successful execution result.

        Args:
            output_files: List of files created during execution
            tokens_used: Number of tokens consumed

        Returns:
            ExecutionResult with success=True
        """
        return cls(
            success=True,
            output_files=output_files,
            error_message=None,
            tokens_used=tokens_used,
        )

    @classmethod
    def failure_result(
        cls,
        error_message: str,
        tokens_used: int = 0,
    ) -> ExecutionResult:
        """Create a failed execution result.

        Args:
            error_message: Description of the failure
            tokens_used: Number of tokens consumed before failure

        Returns:
            ExecutionResult with success=False
        """
        return cls(
            success=False,
            output_files=[],
            error_message=error_message,
            tokens_used=tokens_used,
        )

    def __str__(self) -> str:
        """Return string representation."""
        if self.success:
            return f"Success: {len(self.output_files)} files created"
        return f"Failed: {self.error_message}"
