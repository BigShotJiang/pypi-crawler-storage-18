"""ProjectPath - Value object for validated LAIDA project directory.

Contract: CNT-T0-DOM-004
Traceability: UC-001, INV-004
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ProjectPath:
    """Value object representing a validated LAIDA project directory.

    Invariant INV-004: path.is_absolute() and path.exists()
    """

    path: Path

    def __post_init__(self) -> None:
        """Validate invariant INV-004."""
        if not self.path.is_absolute():
            raise ValueError(f"Path must be absolute: {self.path}")
        if not self.path.exists():
            raise ValueError(f"Path does not exist: {self.path}")

    @classmethod
    def from_string(cls, path_str: str) -> ProjectPath:
        """Create ProjectPath from string.

        Args:
            path_str: Path string (relative paths will be resolved)

        Returns:
            ProjectPath instance

        Raises:
            ValueError: If path does not exist or cannot be resolved
        """
        path = Path(path_str).resolve()
        return cls(path=path)

    @classmethod
    def current(cls) -> ProjectPath:
        """Create ProjectPath from current working directory."""
        return cls(path=Path.cwd())

    def outputs_dir(self) -> Path:
        """Get the outputs directory."""
        return self.path / "outputs"

    def inputs_dir(self) -> Path:
        """Get the inputs directory."""
        return self.path / "inputs"

    def laida_dir(self) -> Path:
        """Get the .laida directory."""
        return self.path / ".laida"

    def prompts_dir(self) -> Path:
        """Get the prompts directory."""
        return self.laida_dir() / "prompts"

    def __str__(self) -> str:
        """Return string representation."""
        return str(self.path)
