"""PhaseNumber - Value object for LAIDA phase number (0-4).

Contract: CNT-T0-DOM-001
Traceability: UC-001, INV-001
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PhaseNumber:
    """Immutable value object representing LAIDA phase number (0-4).

    Invariant INV-001: 0 <= value <= 4
    """

    value: int

    def __post_init__(self) -> None:
        """Validate invariant INV-001."""
        if not (0 <= self.value <= 4):
            raise ValueError(f"Phase must be 0-4, got {self.value}")

    @classmethod
    def from_int(cls, value: int) -> PhaseNumber:
        """Create PhaseNumber from integer.

        Args:
            value: Phase number (0-4)

        Returns:
            PhaseNumber instance

        Raises:
            ValueError: If value is not in range 0-4
        """
        return cls(value=value)

    def next(self) -> PhaseNumber | None:
        """Get the next phase number.

        Returns:
            Next PhaseNumber if current < 4, None otherwise
        """
        if self.value >= 4:
            return None
        return PhaseNumber(value=self.value + 1)

    def __str__(self) -> str:
        """Return string representation."""
        return f"Phase {self.value}"
