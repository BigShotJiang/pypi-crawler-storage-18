"""LAIDA CLI - Main entry point.

Contract: CNT-T5-MAIN-001
Traceability: UI-002
"""

import click

from laida_cli import __version__
from laida_cli.banner import print_banner
from laida_cli.commands.init import init_command
from laida_cli.commands.login import login_command
from laida_cli.commands.run import run_command
from laida_cli.commands.status import status_command
from laida_cli.commands.validate import validate_command
from laida_cli.tui_main import tui_command
from laida_cli.ui import console


class LaidaGroup(click.Group):
    """Custom Click Group that shows banner on help."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Format help with banner first."""
        # Print banner before help text
        print_banner(console, show_version=True)
        super().format_help(ctx, formatter)


@click.group(cls=LaidaGroup)
@click.version_option(version=__version__, prog_name="laida")
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Enable verbose output",
)
@click.pass_context
def cli(ctx: click.Context, verbose: bool) -> None:
    """Agent-executable software architecture methodology.

    Transforms project requirements into structured YAML artifacts
    through 5 phases (0-4), each with 4 steps.

    \b
    Quick start:
        laida init          Initialize a new project
        laida status        Check project status
        laida run 0 0       Execute Phase 0 Step 0
        laida validate      Validate project artifacts
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose


# Register commands
cli.add_command(init_command)
cli.add_command(login_command)
cli.add_command(status_command)
cli.add_command(run_command)
cli.add_command(validate_command)
cli.add_command(tui_command)


def main() -> None:
    """Main entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
