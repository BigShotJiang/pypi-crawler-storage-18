"""LAIDA CLI Banner - ASCII art and branding.

Contract: CNT-T5-BANNER-001
Traceability: UI-002
"""

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from laida_cli.ui.theme import LAIDA_THEME, Styles

# Compact ASCII Art for LAIDA v3 (fits 80 columns)
BANNER_COMPACT = r"""
  _        _    ___ ____    _                _____
 | |      / \  |_ _|  _ \  / \    __   ___ _|___ /
 | |     / _ \  | || | | |/ _ \   \ \ / / '_ \|_ \
 | |___ / ___ \ | || |_| / ___ \   \ V /| (_) |__) |
 |_____/_/   \_\___|____/_/   \_\   \_/  \___/____/
"""

# Full ASCII Art (for wide terminals)
BANNER_FULL = r"""
 __/\\_________________/\\\\\\\\\\_____/\\\\\\\\\\\_/\\\\\\\\\\\\________/\\\\\\\\\_
  _\/\\\_____________/\\\\\\\\\\\\\__\/////\\\//__\/\\\//////\\\____/\\\\\\\\\\\\\__
   _\/\\\____________/\\\/////////\\\_____\/\\\____\/\\\____\//\\\__/\\\/////////\\\_
    _\/\\\_________\/\\\_______\/\\\_____\/\\\____\/\\\_____\/\\\_\/\\\_______\/\\\_
     _\/\\\_________\/\\\\\\\\\\\\\\\____\/\\\____\/\\\_____\/\\\_\/\\\\\\\\\\\\\\\__
      _\/\\\_________\/\\\/////////\\\_____\/\\\____\/\\\_____\/\\\_\/\\\/////////\\\_
       _\/\\\_________\/\\\_______\/\\\_____\/\\\____\/\\\_____/\\\__\/\\\_______\/\\\_
        _\/\\\\\\\\\\\\_\/\\\_______\/\\\_/\\\\\\\\\\\\_\/\\\\\\\\\\\\/___\/\\\_______\/\\\_
         _\////////////__\///________\///__\///////////__\////////////_____\///________\///_
"""

TAGLINE = "LLM Agent-Executable Implementation Design Architecture"


def print_banner(console: Console | None = None, show_version: bool = True) -> None:
    """Print the LAIDA banner with optional version.

    Args:
        console: Rich console instance (creates themed console if None)
        show_version: Whether to show version below banner
    """
    if console is None:
        console = Console(theme=LAIDA_THEME)

    # Use compact banner (works in most terminals)
    banner_text = Text(BANNER_COMPACT)
    banner_text.stylize(Styles.BRAND)

    # Build subtitle
    from laida_cli import __version__
    subtitle = f"[{Styles.MUTED}]{TAGLINE}[/{Styles.MUTED}]"
    if show_version:
        subtitle += f"  [{Styles.MUTED}]v{__version__}[/{Styles.MUTED}]"

    # Print as panel for nice framing
    console.print(Panel(
        banner_text,
        subtitle=subtitle,
        border_style=Styles.PANEL_BORDER,
        padding=(0, 1),
    ))
    console.print()


def print_banner_simple(console: Console | None = None) -> None:
    """Print a simple one-line banner.

    Args:
        console: Rich console instance (creates themed console if None)
    """
    if console is None:
        console = Console(theme=LAIDA_THEME)

    from laida_cli import __version__
    console.print(f"[{Styles.BRAND}]LAIDA[/{Styles.BRAND}] v{__version__} - {TAGLINE}")
    console.print()


def get_banner_str() -> str:
    """Get banner as plain string.

    Returns:
        Banner string without formatting
    """
    return BANNER_COMPACT
