"""Init command - Initialize new LAIDA project.

Contract: CNT-T4-CMD-001
Traceability: UC-020
"""

import importlib.resources
import shutil
import sys
from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command("init")
@click.option(
    "--force", "-f",
    is_flag=True,
    help="Overwrite existing LAIDA project structure",
)
@click.option(
    "--path", "-p",
    type=click.Path(exists=False),
    default=".",
    help="Path to initialize project (default: current directory)",
)
def init_command(force: bool, path: str) -> None:
    """Initialize a new LAIDA project.

    Creates the following structure:
    - .laida/ (prompts, templates, config)
    - inputs/ (project_context.yaml)
    - outputs/ (generated artifacts)
    """
    project_path = Path(path).resolve()

    # Check if already initialized
    laida_dir = project_path / ".laida"
    if laida_dir.exists() and not force:
        console.print(
            "[red]Error:[/red] LAIDA project already exists. "
            "Use --force to overwrite."
        )
        raise SystemExit(1)

    # Find the source .laida directory
    # Updated to use importlib for package compatibility
    try:
        source_laida = _get_template_source()
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        console.print("Please ensure laida-cli is installed correctly with template data.")
        raise SystemExit(1)

    console.print(f"[blue]Initializing LAIDA project at:[/blue] {project_path}")

    # Create directory structure
    _create_directories(project_path)

    # Copy .laida directory
    if laida_dir.exists():
        shutil.rmtree(laida_dir)
    
    # Copy from the source (package or local) to the target
    shutil.copytree(source_laida, laida_dir, dirs_exist_ok=True)

    # Create project_context.yaml from template
    _create_project_context(project_path)

    console.print("[green]Success![/green] LAIDA project initialized.")
    console.print("")
    console.print("Next steps:")
    console.print("  1. Edit inputs/project_context.yaml with your project details")
    console.print("  2. Run: laida status")
    console.print("  3. Run: laida run 0 0  (to start Phase 0 Step 0)")


def _get_template_source() -> Path:
    """Find the .laida template directory inside the installed package or local dev.

    Returns:
        Path to source .laida directory
    
    Raises:
        FileNotFoundError if not found
    """
    # 1. Try finding it inside the installed package (Production Mode)
    # This matches the pyproject.toml force-include=".laida=laida_cli/.laida"
    try:
        # We look inside the 'laida_cli' package
        pkg_files = importlib.resources.files("laida_cli")
        template_dir = pkg_files.joinpath(".laida")
        
        # Check if it exists and is a directory (typical in standard installs)
        if template_dir.is_dir():
            return Path(str(template_dir))
            
        # Fallback for zipped packages or different install methods
        with importlib.resources.as_file(template_dir) as p:
            if p.exists():
                return p
    except Exception:
        # Ignore errors here and try local fallback
        pass

    # 2. Fallback: Local Development Environment
    # Assuming code is in src/laida_cli/commands/init.py
    # We look for .laida in the project root (3 levels up from here)
    local_dev_path = Path(__file__).resolve().parent.parent.parent.parent / ".laida"
    if local_dev_path.exists() and (local_dev_path / "config.yaml").exists():
        return local_dev_path
    
    # Try one level deeper just in case (depending on where run from)
    local_dev_path_alt = Path(__file__).resolve().parent.parent.parent / ".laida"
    if local_dev_path_alt.exists():
        return local_dev_path_alt

    raise FileNotFoundError("Cannot find .laida templates in package resources or local path.")


def _create_directories(project_path: Path) -> None:
    """Create project directory structure.

    Args:
        project_path: Path to project root
    """
    dirs = [
        project_path / "inputs",
        project_path / "outputs",
    ]

    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)


def _create_project_context(project_path: Path) -> None:
    """Create project_context.yaml from template.

    Args:
        project_path: Path to project root
    """
    context_file = project_path / "inputs" / "project_context.yaml"

    # Check if template exists
    template_file = project_path / "inputs" / "project_context_template.yaml"
    laida_template = project_path / ".laida" / "templates" / "project_context.yaml"

    if template_file.exists():
        # Copy from existing template
        shutil.copy(template_file, context_file)
    elif laida_template.exists():
        shutil.copy(laida_template, context_file)
    elif not context_file.exists():
        # Create minimal template
        context_file.write_text(
            """# LAIDA Project Context
# =====================
# Fill in your project details below

project_context:
  # Required fields
  project_name: "my-project"
  description: "Brief description of your project"

  # Optional fields
  # criticality: "experimental"  # experimental, internal, business-critical, mission-critical
  # budget: 0
  # timeline: "flexible"
  # team_size: 1

  # Constraints and integrations
  # constraints: []
  # integrations: []
"""
        )