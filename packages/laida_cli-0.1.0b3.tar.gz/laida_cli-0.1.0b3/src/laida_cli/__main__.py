"""Allow running as python -m laida_cli."""

from laida_cli.main import main

if __name__ == "__main__":
    main()
