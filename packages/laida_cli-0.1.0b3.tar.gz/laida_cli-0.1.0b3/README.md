# LAIDA CLI

**L**LM **A**gent-Executable **I**mplementation **D**esign **A**rchitecture

A CLI tool for executing the LAIDA software architecture methodology.

## Installation

```bash
pip install laida-cli
```

Or install from source:

```bash
pip install -e ".[dev]"
```

## Quick Start

```bash
# Initialize a new project
laida init

# Check project status
laida status

# Execute Phase 0 Step 0
laida run 0 0

# Validate project artifacts
laida validate
```

## Methodology Overview

LAIDA transforms project requirements into structured YAML artifacts through 5 phases (0-4), each with 4 steps:

| Phase | Name | Output Focus |
|-------|------|--------------|
| 0 | Strategic Foundation | Scale, tech stack, risks, QAS, bounded contexts, ADRs |
| 1 | Module Design | Module specs, DDD aggregates, validation |
| 2 | Physical Design | File structure, CoT architecture |
| 3 | Contract Definition | API contracts, dependency analysis |
| 4 | Implementation | Python code, tests, docs, CI/CD |

## Commands

- `laida init` - Initialize a new LAIDA project
- `laida status` - Show current project progress
- `laida run <phase> <step>` - Execute a specific phase/step
- `laida validate` - Validate project artifacts

## Development

```bash
# Install with development dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run linting
ruff check src/ tests/

# Run type checking
mypy src/laida_cli/
```

## License

MIT
