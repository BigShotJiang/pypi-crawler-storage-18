"""CLI for exploring simulation APIs.

Usage:
    plato sims list
    plato sims info <sim_name>
    plato sims endpoints <sim_name> [--spec SPEC_NAME] [--tag TAG] [--path PATH] [--code]
    plato sims spec <sim_name> [--spec SPEC_NAME]

Examples:
    # Show HTTP endpoints
    plato sims endpoints spree --spec platform

    # Show with code examples
    plato sims endpoints spree --spec platform --code

    # Filter to specific path
    plato sims endpoints espocrm --path "/User/{id}/tasks" --code
"""

import json
import sys

from .registry import registry


def format_table(rows: list[list[str]], headers: list[str]) -> str:
    """Format data as a simple text table."""
    if not rows:
        return ""

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # Build table
    lines = []

    # Header
    header_line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    lines.append(header_line)
    lines.append("-" * len(header_line))

    # Rows
    for row in rows:
        line = "  ".join(str(cell).ljust(w) for cell, w in zip(row, widths))
        lines.append(line)

    return "\n".join(lines)


def cmd_list() -> None:
    """List all available sims."""
    sims = registry.list_sims()

    if not sims:
        print("No sims found.")
        return

    print("Available simulation APIs:\n")
    for sim in sims:
        info = registry.get_sim_info(sim)
        print(f"  {sim}")
        print(f"    {info.title} (v{info.version})")
        print(f"    Auth: {info.auth.type}")
        if len(info.specs) > 1:
            print(f"    APIs: {', '.join(info.specs)}")
        print()


def _get_param_type(schema: dict) -> str:
    """Get Python type hint from OpenAPI schema."""
    schema_type = schema.get("type", "Any")
    schema_format = schema.get("format", "")

    # Map OpenAPI types to Python types
    type_map = {
        "string": "str",
        "integer": "int",
        "number": "float",
        "boolean": "bool",
        "array": "list",
        "object": "dict",
    }

    base_type = type_map.get(schema_type, "Any")

    # Handle array types
    if schema_type == "array":
        items = schema.get("items", {})
        item_type = _get_param_type(items)
        return f"list[{item_type}]"

    return base_type


def _format_schema_type(schema: dict, components: dict) -> str:
    """Format schema type for display, including refs and complex types."""
    # Handle $ref
    if "$ref" in schema:
        ref = schema["$ref"]
        # Extract model name from #/components/schemas/ModelName
        if ref.startswith("#/components/schemas/"):
            model_name = ref.split("/")[-1]
            return model_name
        return "dict"

    schema_type = schema.get("type", "")

    if schema_type == "array":
        items = schema.get("items", {})
        item_type = _format_schema_type(items, components)
        return f"list[{item_type}]"
    elif schema_type == "object":
        # Check if it has properties
        properties = schema.get("properties", {})
        if properties:
            return "dict"  # Could expand to show property types
        return "dict"
    elif schema_type:
        return _get_param_type(schema)

    return "dict"


def cmd_info(sim_name: str) -> None:
    """Show detailed information about a sim."""
    try:
        info = registry.get_sim_info(sim_name)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"{info.title} (v{info.version})")
    print("=" * 60)

    if info.description:
        print(f"\n{info.description}\n")

    print(f"Name: {info.name}")
    print(f"Auth Type: {info.auth.type}")

    if len(info.specs) > 1:
        print(f"APIs: {', '.join(info.specs)}")

    if info.tags:
        print(f"Tags: {', '.join(info.tags)}")

    print("\nRequired Environment Variables:")
    for var, desc in info.auth.env_vars.items():
        has_default = any(v for v in info.auth.default_values.values() if v)
        default_marker = " (has default for artifacts)" if has_default else ""
        print(f"  {var}: {desc}{default_marker}")

    print("\nUsage:")
    if len(info.specs) == 1 and info.specs[0] == "default":
        print(f"  from plato.sims import {info.name}")
        print(f"  client = await {info.name}.AsyncClient.create(base_url='...')")
    else:
        print(f"  from plato.sims.{info.name} import {', '.join(info.specs)}")
        print(f"  client = await {info.specs[0]}.AsyncClient.create(base_url='...')")

    print("\nExplore API:")
    print(f"  plato sims endpoints {info.name}")


def cmd_endpoints(
    sim_name: str,
    spec_name: str | None = None,
    tag_filter: str | None = None,
    path_filter: str | None = None,
    show_code: bool = False,
) -> None:
    """List all endpoints in a sim's API."""
    try:
        endpoints = registry.get_endpoints_summary(sim_name, spec_name)
        spec = registry.get_spec(sim_name, spec_name) if show_code else None
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    # Filter by tag if specified (case-insensitive)
    if tag_filter:
        tag_filter_lower = tag_filter.lower()
        endpoints = [e for e in endpoints if any(tag_filter_lower in tag.lower() for tag in e["tags"])]

    # Filter by path if specified (case-insensitive contains)
    if path_filter:
        path_filter_lower = path_filter.lower()
        endpoints = [e for e in endpoints if path_filter_lower in e["path"].lower()]

    if not endpoints:
        print("No endpoints found.")
        return

    # Group by tag
    by_tag: dict[str, list[dict]] = {}
    for endpoint in endpoints:
        tags = endpoint["tags"] or ["untagged"]
        for tag in tags:
            by_tag.setdefault(tag, []).append(endpoint)

    info = registry.get_sim_info(sim_name)
    spec_str = f" - {spec_name}" if spec_name else ""
    print(f"{info.title}{spec_str}")
    print("=" * 60)
    print(f"Total endpoints: {len(endpoints)}\n")

    if show_code:
        # Show SDK usage example
        api_name = spec_name or info.specs[0] if len(info.specs) > 1 else sim_name
        print("SDK Usage Example:")
        print(f"  from plato.sims.{sim_name}.{api_name} import Client")
        print(f"  from plato.sims.{sim_name}.{api_name}.api.<endpoint_group> import <operation_name>")
        print()
        print("  client = Client.create()  # Reads env vars")
        print("  result = <operation_name>.sync(client.httpx, ...)  # First arg is client.httpx")
        print()

    for tag in sorted(by_tag.keys()):
        tag_endpoints = by_tag[tag]
        print(f"\n{tag.upper()} ({len(tag_endpoints)} endpoints)")
        print("-" * 60)

        for endpoint in tag_endpoints:
            method = endpoint["method"].ljust(6)
            path = endpoint["path"]
            operation_id = endpoint.get("operationId", "")
            summary = endpoint["summary"] or endpoint["description"] or ""
            if len(summary) > 60:
                summary = summary[:57] + "..."

            print(f"  {method} {path}")
            if summary:
                print(f"         {summary}")

            if show_code and spec:
                # Get full endpoint details from spec
                path_spec = spec.get("paths", {}).get(path, {})
                method_spec = path_spec.get(method.lower().strip(), {})

                # Get path parameters from both path-level and method-level
                path_level_params = path_spec.get("parameters", [])
                method_level_params = method_spec.get("parameters", [])
                all_params = path_level_params + method_level_params

                # Build function signature components
                params = []
                params.append("client.httpx")  # First param is always httpx client

                # Extract path and query parameters
                query_params = []
                for param in all_params:
                    param_name = param.get("name", "")
                    param_in = param.get("in", "")
                    required = param.get("required", False)
                    param_type = _get_param_type(param.get("schema", {}))

                    if param_in == "path":
                        params.append(f"{param_name}: {param_type}")
                    elif param_in == "query":
                        if required:
                            query_params.append(f"{param_name}: {param_type}")
                        else:
                            query_params.append(f"{param_name}: {param_type} | None = None")

                # Add query params
                params.extend(query_params)

                # Check for request body
                request_body = method_spec.get("requestBody", {})
                body_schema_info = None
                if request_body:
                    content = request_body.get("content", {})
                    required = request_body.get("required", False)

                    # Look for JSON content
                    json_content = content.get("application/json", {})
                    if json_content:
                        schema = json_content.get("schema", {})
                        body_type = _format_schema_type(schema, spec.get("components", {}))

                        if required:
                            params.append(f"body: {body_type}")
                        else:
                            params.append(f"body: {body_type} | None = None")

                        # Store schema info for detailed display
                        body_schema_info = schema

                # If we have an operation ID, show full import + function call
                if operation_id:
                    # Convert operationId to module path
                    python_operation_id = operation_id.replace("-", "_")

                    # Try to guess the resource name from path
                    path_parts = [p for p in path.split("/") if p and not p.startswith("{")]
                    resource = None

                    # Strategy 1: Look for segment after "platform" or "storefront"
                    for i, part in enumerate(path_parts):
                        if part in ["platform", "storefront"] and i + 1 < len(path_parts):
                            resource = path_parts[i + 1].lower()
                            break

                    # Strategy 2: Use first non-api, non-version segment
                    if not resource:
                        for part in path_parts:
                            if part not in ["api", "v1", "v2", "v3", "v4"] and not part.startswith("v"):
                                resource = part.lower()
                                break

                    if resource:
                        print(
                            f"         from plato.sims.{sim_name}.{spec_name or info.specs[0]}.api.{resource} import {python_operation_id}"
                        )

                        # Format the function call
                        if len(params) <= 3:
                            params_str = ", ".join(params)
                            print(f"         result = {python_operation_id}.sync({params_str})")
                        else:
                            print(f"         result = {python_operation_id}.sync(")
                            for i, param in enumerate(params):
                                if i == len(params) - 1:
                                    print(f"             {param}")
                                else:
                                    print(f"             {param},")
                            print("         )")

                # If no operationId, just show parameter structure
                else:
                    if len(params) > 1:  # More than just client.httpx
                        print("         Parameters:")
                        for param in params[1:]:  # Skip client.httpx
                            print(f"           - {param}")

                # Show body schema details if available
                if body_schema_info and body_schema_info.get("properties"):
                    print("         Request body fields:")
                    for prop_name, prop_schema in body_schema_info["properties"].items():
                        prop_type = _get_param_type(prop_schema)
                        prop_desc = prop_schema.get("description", "")
                        required_mark = " (required)" if prop_name in body_schema_info.get("required", []) else ""
                        if prop_desc:
                            print(f"           - {prop_name}: {prop_type}{required_mark} - {prop_desc}")
                        else:
                            print(f"           - {prop_name}: {prop_type}{required_mark}")

                print()


def cmd_spec(sim_name: str, spec_name: str | None = None) -> None:
    """Output the full OpenAPI spec as JSON."""
    try:
        spec = registry.get_spec(sim_name, spec_name)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(spec, indent=2))


def main(args: list[str] | None = None) -> None:
    """Main CLI entry point."""
    if args is None:
        args = sys.argv[1:]

    if not args or args[0] in ["-h", "--help", "help"]:
        print(__doc__)
        return

    command = args[0]

    if command == "list":
        cmd_list()

    elif command == "info":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print("Usage: plato sims info <sim_name>", file=sys.stderr)
            sys.exit(1)
        cmd_info(args[1])

    elif command == "endpoints":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print(
                "Usage: plato sims endpoints <sim_name> [--spec SPEC] [--tag TAG] [--path PATH] [--code]",
                file=sys.stderr,
            )
            sys.exit(1)

        sim_name = args[1]
        spec_name = None
        tag_filter = None
        path_filter = None
        show_code = False

        # Parse optional flags
        i = 2
        while i < len(args):
            if args[i] == "--spec" and i + 1 < len(args):
                spec_name = args[i + 1]
                i += 2
            elif args[i] == "--tag" and i + 1 < len(args):
                tag_filter = args[i + 1]
                i += 2
            elif args[i] == "--path" and i + 1 < len(args):
                path_filter = args[i + 1]
                i += 2
            elif args[i] == "--code":
                show_code = True
                i += 1
            else:
                i += 1

        cmd_endpoints(sim_name, spec_name, tag_filter, path_filter, show_code)

    elif command == "spec":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print("Usage: plato sims spec <sim_name> [--spec SPEC]", file=sys.stderr)
            sys.exit(1)

        sim_name = args[1]
        spec_name = None

        if len(args) > 2 and args[2] == "--spec" and len(args) > 3:
            spec_name = args[3]

        cmd_spec(sim_name, spec_name)

    else:
        print(f"Error: Unknown command '{command}'", file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
