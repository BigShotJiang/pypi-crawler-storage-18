#!/usr/bin/env python3
# sr.py
"""
License & Disclaimer
Copyright © 2025 Viren
This software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, or non-infringement.
By using this software, you agree that Viren Sahti is not responsible for any direct, indirect, incidental, special, exemplary, or consequential damages, including but not limited to damages for loss of data, profits, or any other intangible losses, resulting from:
any misuse of the software
criminal activity, hacking, or any illegal use
any modifications or derivative works
any failure, bug, or security breach
You may use this software only for legitimate purposes. Redistribution, modification, or claiming the code as your own is strictly prohibited. All rights, title, and interest in the software remain with Viren Sahti.
In summary: Any damage, illegal activity, or misuse done with this software is not the responsibility of Viren Sahti. Use at your own risk.
"""

"""
READ LICENSE AND README.MD
"""

import os
import sys
import json
import time
import base64
import getpass
import hashlib
import argparse
import traceback
import hmac
import shutil
import gc
import importlib.util
from datetime import datetime
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from colorama import init, Fore, Style

init(autoreset=True)

VERSION = "1.7.1"

def _user_data_dir():
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "sr")
    else:
        return os.path.join(os.path.expanduser("~/.local/share"), "sr")

BASE_DIR = _user_data_dir()
PLUGIN_DIR = os.path.join(BASE_DIR, "plugins")
LOCKED_DIR = os.path.join(BASE_DIR, "locked")

GREEN = Fore.GREEN
YELLOW = Fore.YELLOW
RED = Fore.RED
RESET = Style.RESET_ALL
BOLD = Style.BRIGHT

_runtime_cache = {}
_PLUGIN_COMMANDS = {}
_PBKDF2_ITER = 5_000_000
_DK_LEN = 32

def _ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _info(msg):
    print(f"{BOLD}{GREEN}[{_ts()}] {msg}{RESET}")

def _warn(msg):
    print(f"{BOLD}{YELLOW}[{_ts()}] {msg}{RESET}")

def _err(msg):
    print(f"{BOLD}{RED}[{_ts()}] {msg}{RESET}")
    
def _ensure_dirs():
    os.makedirs(LOCKED_DIR, exist_ok=True)

def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()

def _sr_path(label: str) -> str:
    safe = label.replace("/", "_").replace("..", "_").replace(" ", "_")
    return os.path.join(LOCKED_DIR, f"{safe}.sr")

def _derive_key(password: bytes, salt: bytes, iterations: int = _PBKDF2_ITER) -> bytes:
    if iterations <= 0:
        raise ValueError("Invalid PBKDF2 iteration count")

    key = hashlib.pbkdf2_hmac(
        "sha256",
        password,
        salt,
        iterations,
        dklen=32
    )
    return key

def _chacha_encrypt(plain: bytes, key: bytes):
    nonce = os.urandom(12)  # verplicht 12 bytes
    cipher = ChaCha20Poly1305(key)
    ct = cipher.encrypt(nonce, plain, None)
    return nonce, ct

def _chacha_decrypt(ciphertext: bytes, nonce: bytes, key: bytes) -> bytes:
    cipher = ChaCha20Poly1305(key)
    return cipher.decrypt(nonce, ciphertext, None)    

def _zero_bytes(b):
    try:
        if isinstance(b, bytearray):
            for i in range(len(b)):
                b[i] = 0
    except Exception:
        pass

def setup():
    _ensure_dirs()
    _info(f"SR setup done. Version {VERSION}")

def register_command(name, help, handler):
    if not name.isidentifier():
        raise ValueError("Invalid command name")
    if name in _PLUGIN_COMMANDS:
        raise ValueError("Command already exists")
    _PLUGIN_COMMANDS[name] = {
        "help": help,
        "handler": handler
    }

def load_plugins():
    os.makedirs(PLUGIN_DIR, exist_ok=True)

    for fname in os.listdir(PLUGIN_DIR):
        if not fname.endswith(".py"):
            continue

        path = os.path.join(PLUGIN_DIR, fname)
        name = fname[:-3]

        spec = importlib.util.spec_from_file_location(
            f"sr_plugin_{name}", path
        )
        mod = importlib.util.module_from_spec(spec)

        try:
            spec.loader.exec_module(mod)
            if hasattr(mod, "register"):
                mod.register(sys.modules[__name__])
                _info(f"Loaded plugin: {name}")
        except Exception as e:
            _err(f"Plugin {name} failed: {e}")    
            
def logo():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
{RESET}""")

def logo_with_text():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
  Secure Run
{RESET}""")

def logo_with_version():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
  Secure Run {VERSION}
{RESET}""")

def cls():
    os.system("cls" if os.name == "nt" else "clear")
    logo()
    
def lock(label: str, filepath: str, password: str = None, pbkdf2_iter: int = _PBKDF2_ITER):
    if not filepath.endswith(".py"):
        _err("Only .py files are allowed to be locked.")
        raise ValueError("Only .py files are allowed")

    if password is None:
        password = getpass.getpass("Enter password to lock: ")

    if not os.path.isfile(filepath):
        _err("Input file not found.")
        raise FileNotFoundError(filepath)

    with open(filepath, "rb") as f:
        raw = f.read()

    file_hash = _sha256_bytes(raw)
    salt = os.urandom(16)
    key = _derive_key(password.encode("utf-8"), salt, int(pbkdf2_iter))

    nonce, ct = _chacha_encrypt(raw, key)
    _zero_bytes(bytearray(key))

    payload = {
        "meta": {
            "filename": os.path.basename(filepath),
            "locked_at": _ts(),
            "method": "chacha20-poly1305",
            "pbkdf2_iter": int(pbkdf2_iter),
        },
        "data": {
            "file_hash": file_hash,
            "salt": base64.b64encode(salt).decode(),
            "nonce": base64.b64encode(nonce).decode(),
            "ciphertext": base64.b64encode(ct).decode()
        }
    }

    path = _sr_path(label)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    os.replace(tmp, path)
    _zero_bytes(bytearray(ct))
    del raw
    gc.collect()
    _info(f"Locked {filepath} as '{label}' -> {path}")
    return path

def _decrypt_payload(payload: dict, password: str) -> bytes:
    try:
        data = payload["data"]
        salt = base64.b64decode(data["salt"])
        nonce = base64.b64decode(data["nonce"])
        ct = base64.b64decode(data["ciphertext"])
    except Exception:
        raise ValueError("Malformed sr file")

    iterations = int(payload["meta"].get("pbkdf2_iter", _PBKDF2_ITER))
    key = _derive_key(password.encode("utf-8"), salt, iterations)

    try:
        plain = _chacha_decrypt(ct, nonce, key)
    except Exception:
        _zero_bytes(bytearray(key))
        raise RuntimeError("Decryption failed (wrong password or corrupted data)")

    _zero_bytes(bytearray(key))

    expected_hash = data.get("file_hash")
    if expected_hash and not hmac.compare_digest(_sha256_bytes(plain), expected_hash):
        _zero_bytes(bytearray(plain))
        raise ValueError("Integrity check failed")

    return plain

def get_runtime(label: str, password: str = None) -> bytes:
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if password is None:
        password = getpass.getpass(f"Enter password for '{label}': ")

    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    plain = _decrypt_payload(payload, password)
    _runtime_cache[label] = plain[:]
    _info(f"Decrypted '{label}' into runtime cache only (no disk write).")
    return _runtime_cache[label]
    
def run(label: str, password: str = None, show_output: bool = True):
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    plain = _runtime_cache.get(label)
    if plain is None:
        if password is None:
            password = getpass.getpass(f"Enter password to run '{label}': ")
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        plain = _decrypt_payload(payload, password)

    try:
        src = plain.decode("utf-8", errors="replace")
    except Exception:
        _zero_bytes(bytearray(plain))
        raise RuntimeError("Failed to decode script")

    filename = os.path.basename(label) + ".py"
    header = f"{BOLD}{GREEN}Running ({label}) - {filename}...{RESET}"
    if show_output:
        print(header)
    start = time.time()

    try:
        code_obj = compile(src, filename, "exec")
        g = {"__name__": "__main__", "__file__": filename}
        try:
            exec(code_obj, g, g)
        except SystemExit:
            _warn("Script called exit().")
        except Exception as e:
            _err(f"Runtime error in decrypted script: {e}")
            _err(traceback.format_exc())
            raise
    finally:
        elapsed = time.time() - start
        _info(f"Finished running {label} in {elapsed:.2f}s.")
        try:
            _zero_bytes(bytearray(plain))
        except Exception:
            pass
        del src, code_obj, plain
        _runtime_cache.pop(label, None)
        gc.collect()

    return True
    
def get(label: str, password: str = None) -> bytes:
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if password is None:
        password = getpass.getpass("Enter password to get file: ")

    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    plain = _decrypt_payload(payload, password)

    filename = payload.get("meta", {}).get("filename") or f"{label}.py"
    if not filename.endswith(".py"):
        _zero_bytes(bytearray(plain))
        raise ValueError("Stored filename is not a .py file; refusing to write to disk.")

    _runtime_cache[label] = plain[:]
    _info(f"Decrypted '{label}' into runtime cache only (no disk write). Filename: {filename}")
    return _runtime_cache[label]
    
def delete(label: str):
    path = _sr_path(label)
    if os.path.isfile(path):
        try:
            os.remove(path)
            _info(f"Deleted locked file: {path}")
        except Exception as e:
            _err("Failed to delete file: " + str(e))
            raise
    else:
        _warn("Item not found; nothing to delete.")
    _runtime_cache.pop(label, None)

def flush():
    for k, v in list(_runtime_cache.items()):
        try:
            _zero_bytes(bytearray(v))
        except Exception:
            pass
        _runtime_cache.pop(k, None)
    _info("Runtime cache flushed. All decrypted bytes removed from memory cache (best-effort).")
    gc.collect()

def reset(confirm: bool = False):
    if not confirm:
        _warn("Call reset(confirm=True) to actually wipe all locked data.")
        return

    if os.path.isdir(LOCKED_DIR):
        for fname in os.listdir(LOCKED_DIR):
            if fname.endswith(".sr"):
                try:
                    os.remove(os.path.join(LOCKED_DIR, fname))
                except Exception:
                    pass

    if os.path.isdir(BASE_DIR):
        for fname in os.listdir(BASE_DIR):
            if fname.endswith(".py"):
                try:
                    os.remove(os.path.join(BASE_DIR, fname))
                except Exception:
                    pass

    if os.path.isdir(PLUGIN_DIR):
        for fname in os.listdir(PLUGIN_DIR):
            if fname.endswith(".py"):
                try:
                    os.remove(os.path.join(PLUGIN_DIR, fname))
                except Exception:
                    pass

    bundle_dir = os.path.join(BASE_DIR, "bundles")
    if os.path.isdir(bundle_dir):
        for fname in os.listdir(bundle_dir):
            if fname.endswith(".json"):
                try:
                    os.remove(os.path.join(bundle_dir, fname))
                except Exception:
                    pass

    _runtime_cache.clear()
    _info("FULL reset: removed .sr files, written .py files, plugins, bundles, and cleared memory cache.")
    gc.collect()
    
def export_sr(label: str, out_path: str = None):
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if out_path is None:
        out_path = os.path.join(os.getcwd(), os.path.basename(path))

    tmp = out_path + ".tmp"
    try:
        with open(path, "rb") as f_in:
            data = f_in.read()
        with open(tmp, "wb") as f_out:
            f_out.write(data)
            f_out.flush()
            os.fsync(f_out.fileno())
        os.replace(tmp, out_path)
        _info(f"Exported .sr file to: {out_path}")
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _err("Failed to export .sr file: " + str(e))
        raise
        
def import_sr(file_path: str, label: str = None):
    if not os.path.isfile(file_path):
        _err("Source .sr file not found.")
        raise FileNotFoundError(file_path)

    if label is None:
        label = os.path.splitext(os.path.basename(file_path))[0]

    dest_path = _sr_path(label)
    tmp = dest_path + ".tmp"
    try:
        with open(file_path, "rb") as f_in:
            data = f_in.read()
        with open(tmp, "wb") as f_out:
            f_out.write(data)
            f_out.flush()
            os.fsync(f_out.fileno())
        os.replace(tmp, dest_path)
        _info(f"Imported .sr file as '{label}' -> {dest_path}")
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _err("Failed to import .sr file: " + str(e))
        raise       

def info(label: str, *, as_json=False, show_hash=False, show_path=False, quiet=False):
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        return

    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    meta = payload.get("meta", {})
    data = payload.get("data", {})

    if as_json:
        print(json.dumps(payload, indent=2))
        return

    if show_path:
        print(f"path: {path}")

    if quiet:
        print(f"label: {label}")
        print(f"method: {meta.get('method')}")
        print(f"locked_at: {meta.get('locked_at')}")
        return

    print(f"{BOLD}label:{RESET} {label}")
    for k in ("filename", "locked_at", "method", "pbkdf2_iter"):
        if k in meta:
            print(f"{k}: {meta[k]}")

    if show_hash and "file_hash" in data:
        print(f"file_hash: {data['file_hash']}")
        
def install_plugin(file_path):
    if not os.path.isfile(file_path):
        raise FileNotFoundError(file_path)

    os.makedirs(PLUGIN_DIR, exist_ok=True)
    name = os.path.basename(file_path)

    if not name.endswith(".py"):
        raise ValueError("Plugin must be .py")

    dest = os.path.join(PLUGIN_DIR, name)
    shutil.copy2(file_path, dest)
    _info(f"Installed plugin: {name}")

def uninstall_plugin(name):
    path = os.path.join(PLUGIN_DIR, name + ".py")
    if os.path.isfile(path):
        os.remove(path)
        _info(f"Removed plugin: {name}")
        
def relock(label: str, old_password: str = None, new_password: str = None, pbkdf2_iter: int = _PBKDF2_ITER):
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if old_password is None:
        old_password = getpass.getpass("Enter CURRENT password: ")

    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    plain = _decrypt_payload(payload, old_password)

    if new_password is None:
        new_password = getpass.getpass("Enter NEW password: ")
        confirm = getpass.getpass("Confirm NEW password: ")
        if new_password != confirm:
            _zero_bytes(bytearray(plain))
            raise ValueError("Passwords do not match")

    # Bereken hash VOOR zeroing
    new_hash = _sha256_bytes(plain)

    salt = os.urandom(16)
    key = _derive_key(new_password.encode(), salt, int(pbkdf2_iter))
    nonce, ct = _chacha_encrypt(plain, key)

    _zero_bytes(bytearray(key))
    _zero_bytes(bytearray(plain))

    payload["meta"]["locked_at"] = _ts()
    payload["meta"]["pbkdf2_iter"] = int(pbkdf2_iter)
    payload["data"] = {
        "file_hash": new_hash,
        "salt": base64.b64encode(salt).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "ciphertext": base64.b64encode(ct).decode(),
    }

    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    os.replace(tmp, path)

    _zero_bytes(bytearray(ct))
    gc.collect()
    _info(f"Password changed for '{label}'")
    
def list_labels(as_json: bool = False):
    os.makedirs(LOCKED_DIR, exist_ok=True)
    labels = [f[:-3] for f in sorted(os.listdir(LOCKED_DIR)) if f.endswith(".sr")]
    if as_json:
        print(json.dumps(labels, indent=2))
    else:
        for lbl in labels:
            print(lbl)
    return labels
    
def create_bundle(name: str, labels: list[str]):
    bundle_dir = os.path.join(BASE_DIR, "bundles")
    os.makedirs(bundle_dir, exist_ok=True)
    bundle_path = os.path.join(bundle_dir, name + ".json")
    with open(bundle_path, "w") as f:
        json.dump(labels, f)
    _info(f"Bundle '{name}' created with labels: {labels}")

def run_bundle(name: str):
    bundle_dir = os.path.join(BASE_DIR, "bundles")
    bundle_path = os.path.join(bundle_dir, name + ".json")
    if not os.path.isfile(bundle_path):
        raise FileNotFoundError(f"Bundle '{name}' not found")
    with open(bundle_path, "r") as f:
        labels = json.load(f)
    for lbl in labels:
        run(lbl)

def delete_bundle(name: str):
    bundle_dir = os.path.join(BASE_DIR, "bundles")
    bundle_path = os.path.join(bundle_dir, name + ".json")
    if os.path.isfile(bundle_path):
        os.remove(bundle_path)
        _info(f"Bundle '{name}' deleted")

def backup(label: str, out_path: str = None) -> str:
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err(f"Locked item '{label}' not found.")
        raise FileNotFoundError(path)
    if out_path is None:
        out_path = os.path.join(os.getcwd(), f"{label}_{int(time.time())}.sr.bak")
    try:
        shutil.copy2(path, out_path)
        _info(f"Backup of '{label}' created at: {out_path}")
        return out_path
    except Exception as e:
        _err(f"Backup failed for '{label}': {e}")
        raise

def restore(label: str, backup_file: str) -> str:
    if not os.path.isfile(backup_file):
        _err(f"Backup file '{backup_file}' not found.")
        raise FileNotFoundError(backup_file)
    dest_path = _sr_path(label)
    try:
        shutil.copy2(backup_file, dest_path)
        _info(f"Backup '{backup_file}' restored as '{label}' -> {dest_path}")
        return dest_path
    except Exception as e:
        _err(f"Restore failed for '{label}': {e}")
        raise

def rename(label: str, new_label: str) -> str:
    old_path = _sr_path(label)
    new_path = _sr_path(new_label)
    if not os.path.isfile(old_path):
        _err(f"Locked item '{label}' not found.")
        raise FileNotFoundError(old_path)
    if os.path.isfile(new_path):
        _err(f"Target label '{new_label}' already exists.")
        raise FileExistsError(new_path)
    try:
        os.rename(old_path, new_path)
        _info(f"'{label}' renamed to '{new_label}'")
        if label in _runtime_cache:
            _runtime_cache[new_label] = _runtime_cache.pop(label)
        return new_path
    except Exception as e:
        _err(f"Rename failed for '{label}': {e}")
        raise

def clone(label: str, new_label: str) -> str:
    path = _sr_path(label)
    new_path = _sr_path(new_label)
    if not os.path.isfile(path):
        _err(f"Locked item '{label}' not found.")
        raise FileNotFoundError(path)
    if os.path.isfile(new_path):
        _err(f"Target label '{new_label}' already exists.")
        raise FileExistsError(new_path)
    try:
        shutil.copy2(path, new_path)
        _info(f"'{label}' cloned to '{new_label}' -> {new_path}")
        if label in _runtime_cache:
            _runtime_cache[new_label] = _runtime_cache[label][:]
        return new_path
    except Exception as e:
        _err(f"Clone failed for '{label}': {e}")
        raise        
        
def exit_sr(force: bool = False):
    _info(f"Exiting (force={force})")
    flush()
    if force:
        os._exit(1)
    else:
        sys.exit(0)

# -----------------------
# CLI wrapper
# -----------------------
def _cli():
    setup()
    load_plugins()
    parser = argparse.ArgumentParser(prog="sr", description="Secure-run (sr)")
    sub = parser.add_subparsers(dest="cmd")

    p_lock = sub.add_parser("lock")
    p_lock.add_argument("label")
    p_lock.add_argument("file")
    p_lock.add_argument("--iter", type=int, default=_PBKDF2_ITER)

    p_run = sub.add_parser("run")
    p_run.add_argument("label")

    p_get = sub.add_parser("get")
    p_get.add_argument("label")

    p_relock = sub.add_parser("relock")
    p_relock.add_argument("label")
    p_relock.add_argument("--iter", type=int, default=_PBKDF2_ITER)

    p_delete = sub.add_parser("delete")
    p_delete.add_argument("label")

    sub.add_parser("flush")

    p_reset = sub.add_parser("reset")
    p_reset.add_argument("--confirm", action="store_true")

    p_export = sub.add_parser("export")
    p_export.add_argument("label")
    p_export.add_argument("--out")

    p_import = sub.add_parser("import")
    p_import.add_argument("file")
    p_import.add_argument("--label")

    p_info = sub.add_parser("info")
    p_info.add_argument("label")
    p_info.add_argument("--json", action="store_true")
    p_info.add_argument("--hash", action="store_true")
    p_info.add_argument("--path", action="store_true")
    p_info.add_argument("--quiet", action="store_true")

    sub.add_parser("labels")

    p_backup = sub.add_parser("backup")
    p_backup.add_argument("label")
    p_backup.add_argument("--out")

    p_restore = sub.add_parser("restore")
    p_restore.add_argument("label")
    p_restore.add_argument("file")

    p_rename = sub.add_parser("rename")
    p_rename.add_argument("label")
    p_rename.add_argument("new_label")

    p_clone = sub.add_parser("clone")
    p_clone.add_argument("label")
    p_clone.add_argument("new_label")

    p_bundle = sub.add_parser("bundle")
    bundle_sub = p_bundle.add_subparsers(dest="bundle_cmd")
    p_b_create = bundle_sub.add_parser("create")
    p_b_create.add_argument("name")
    p_b_create.add_argument("labels", nargs="+")
    p_b_run = bundle_sub.add_parser("run")
    p_b_run.add_argument("name")
    p_b_delete = bundle_sub.add_parser("delete")
    p_b_delete.add_argument("name")

    p_plugin = sub.add_parser("plugin")
    plugin_sub = p_plugin.add_subparsers(dest="plugin_cmd")
    plugin_sub.add_parser("list")
    p_p_install = plugin_sub.add_parser("install")
    p_p_install.add_argument("file")
    p_p_uninstall = plugin_sub.add_parser("uninstall")
    p_p_uninstall.add_argument("name")

    p_exit = sub.add_parser("exit")
    p_exit.add_argument("--force", action="store_true")

    args = parser.parse_args()
    try:
        if args.cmd == "lock":
            lock(args.label, args.file, pbkdf2_iter=args.iter)
        elif args.cmd == "run":
            run(args.label)
        elif args.cmd == "get":
            data = get(args.label)
            if data:
                try:
                    sys.stdout.buffer.write(data)
                except Exception:
                    print(data.decode("utf-8", errors="replace"))
        elif args.cmd == "relock":
            relock(args.label, pbkdf2_iter=args.iter)
        elif args.cmd == "delete":
            delete(args.label)
        elif args.cmd == "flush":
            flush()
        elif args.cmd == "reset":
            reset(confirm=args.confirm)
        elif args.cmd == "export":
            export_sr(args.label, out_path=args.out)
        elif args.cmd == "import":
            import_sr(args.file, label=args.label)
        elif args.cmd == "info":
            info(args.label, as_json=args.json, show_hash=args.hash, show_path=args.path, quiet=args.quiet)
        elif args.cmd == "labels":
            list_labels()
        elif args.cmd == "backup":
            p = backup(args.label, out_path=args.out)
            print(f"Backup created: {p}")
        elif args.cmd == "restore":
            p = restore(args.label, backup_file=args.file)
            print(f"Restored: {p}")
        elif args.cmd == "rename":
            p = rename(args.label, args.new_label)
            print(f"Renamed to: {p}")
        elif args.cmd == "clone":
            p = clone(args.label, args.new_label)
            print(f"Cloned to: {p}")
        elif args.cmd == "bundle":
            if args.bundle_cmd == "create":
                create_bundle(args.name, args.labels)
            elif args.bundle_cmd == "run":
                run_bundle(args.name)
            elif args.bundle_cmd == "delete":
                delete_bundle(args.name)
            else:
                p_bundle.print_help()
        elif args.cmd == "plugin":
            if args.plugin_cmd == "install":
                install_plugin(args.file)
            elif args.plugin_cmd == "uninstall":
                uninstall_plugin(args.name)
            elif args.plugin_cmd == "list":
                os.makedirs(PLUGIN_DIR, exist_ok=True)
                for f in sorted(os.listdir(PLUGIN_DIR)):
                    if f.endswith(".py"):
                        print(f[:-3])
            else:
                p_plugin.print_help()
        elif args.cmd == "exit":
            exit_sr(force=args.force)
        else:
            parser.print_help()
    except Exception as e:
        _err("Operation failed: " + str(e))
        if os.environ.get("SR_DEBUG"):
            import traceback
            traceback.print_exc()
        sys.exit(2)
        
def main():
    _ensure_dirs()
    _cli()