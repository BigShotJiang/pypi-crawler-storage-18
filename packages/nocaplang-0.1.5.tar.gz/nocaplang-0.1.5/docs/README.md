# NoCapLang Documentation

Welcome to the NoCapLang documentation! This directory contains comprehensive guides for learning and using NoCapLang.

## Documentation Overview

### For Beginners

Start here if you're new to NoCapLang:

1. **[Getting Started](GETTING_STARTED.md)** - Installation, setup, and your first program
2. **[REPL Tutorial](REPL_TUTORIAL.md)** - Learn interactively with the REPL
3. **[Language Reference](LANGUAGE_REFERENCE.md)** - Complete syntax and features guide

### For Developers

Essential references for development:

- **[Language Reference](LANGUAGE_REFERENCE.md)** - Complete language specification
- **[Standard Library API](STDLIB_API.md)** - All built-in functions
- **[Compiler Usage](COMPILER_USAGE.md)** - Command-line options and workflows

### Quick Links

- **[Examples](../examples/)** - Sample programs
- **[Project Status](../PROJECT_STATUS.md)** - Current implementation status
- **[Specification](../.kiro/specs/nocap-lang/)** - Formal requirements and design

## Documentation Files

### [Getting Started](GETTING_STARTED.md)

**What it covers:**
- Prerequisites and installation
- Building the compiler (C++, Python, Java)
- Your first NoCapLang program
- Language basics (variables, control flow, functions, classes)
- REPL mode
- Next steps

**Best for:** First-time users, installation help

### [Language Reference](LANGUAGE_REFERENCE.md)

**What it covers:**
- Complete lexical structure (keywords, identifiers, literals)
- All data types (text, digits, tf, lineup, bag)
- Variables and operators
- Control flow (vibecheck, loops, break/continue)
- Functions (lowkey, comeback, lambdas)
- Classes (vibe, vibes_with, inheritance)
- Error handling (tryna, oops, nomatter, crash)
- Async/await (chill, holdup)
- Pattern matching (match, case)
- Modules (grab)
- Comments (tea:, rant:)
- Assertions (nocap)
- Standard library overview
- Best practices and common patterns

**Best for:** Learning syntax, reference lookup, understanding features

### [Compiler Usage](COMPILER_USAGE.md)

**What it covers:**
- Installation instructions
- Basic compilation commands
- Command-line options
- Compilation targets (C++ and Java)
- Error messages and debugging
- Optimization flags
- Multi-file projects
- Build system integration (Make, CMake, Gradle)
- Troubleshooting
- Performance tips
- Advanced usage

**Best for:** Compiling programs, build automation, troubleshooting

### [REPL Tutorial](REPL_TUTORIAL.md)

**What it covers:**
- Starting the REPL
- Basic usage (expressions, statements)
- Variables and state persistence
- Functions and classes in REPL
- Multi-line input
- Special commands (:help, :exit, :clear, :type, :vars)
- Error handling
- Tips and tricks
- Common workflows
- Keyboard shortcuts

**Best for:** Interactive learning, testing code, prototyping

### [Standard Library API](STDLIB_API.md)

**What it covers:**
- String functions (length, substring, split, join, uppercase, lowercase, trim, contains, replace)
- Math functions (abs, sqrt, pow, round, floor, ceil, min, max, random)
- Collection functions (map, filter, reduce, sort, reverse, keys, values, has)
- File I/O functions (read_file, write_file, append_file, file_exists, delete_file, list_directory)
- Usage examples
- Performance considerations
- Error handling
- Platform differences

**Best for:** Function reference, API lookup, learning standard library

## Learning Paths

### Path 1: Quick Start (30 minutes)

1. Read [Getting Started](GETTING_STARTED.md) - Installation and basics
2. Try examples in [examples/hello.nocap](../examples/hello.nocap)
3. Experiment in the [REPL](REPL_TUTORIAL.md)

### Path 2: Comprehensive Learning (2-3 hours)

1. [Getting Started](GETTING_STARTED.md) - Setup
2. [Language Reference](LANGUAGE_REFERENCE.md) - Full syntax
3. [Standard Library API](STDLIB_API.md) - Built-in functions
4. [Examples](../examples/) - Practice with examples
5. [REPL Tutorial](REPL_TUTORIAL.md) - Interactive practice

### Path 3: Production Development (1 day)

1. [Getting Started](GETTING_STARTED.md) - Setup
2. [Language Reference](LANGUAGE_REFERENCE.md) - Language features
3. [Compiler Usage](COMPILER_USAGE.md) - Build workflows
4. [Standard Library API](STDLIB_API.md) - API reference
5. [Examples](../examples/comprehensive_demo.nocap) - Complete example
6. Build your project!

## Feature Documentation

### Variables and Types
- [Language Reference - Variables](LANGUAGE_REFERENCE.md#variables)
- [Language Reference - Data Types](LANGUAGE_REFERENCE.md#data-types)

### Control Flow
- [Language Reference - Control Flow](LANGUAGE_REFERENCE.md#control-flow)
- [Examples - demo.nocap](../examples/demo.nocap)

### Functions
- [Language Reference - Functions](LANGUAGE_REFERENCE.md#functions)
- [Examples - functions_test.nocap](../examples/functions_test.nocap)

### Classes
- [Language Reference - Classes](LANGUAGE_REFERENCE.md#classes)
- [Examples - classes_test.nocap](../examples/classes_test.nocap)

### Error Handling
- [Language Reference - Error Handling](LANGUAGE_REFERENCE.md#error-handling)
- [Examples - error_handling_test.nocap](../examples/error_handling_test.nocap)

### Async/Await
- [Language Reference - Async/Await](LANGUAGE_REFERENCE.md#asyncawait)
- [Examples - async_example.nocap](../examples/async_example.nocap)

### Pattern Matching
- [Language Reference - Pattern Matching](LANGUAGE_REFERENCE.md#pattern-matching)
- [Examples - pattern_matching.nocap](../examples/pattern_matching.nocap)

### Standard Library
- [Standard Library API](STDLIB_API.md)
- [Examples - stdlib_example.nocap](../examples/stdlib_example.nocap)

## Common Tasks

### How do I...

**...compile a program?**
```bash
nocap program.nocap
```
See [Compiler Usage - Basic Usage](COMPILER_USAGE.md#basic-usage)

**...compile to Java instead of C++?**
```bash
nocap --target java program.nocap
```
See [Compiler Usage - Compilation Targets](COMPILER_USAGE.md#compilation-targets)

**...start the REPL?**
```bash
nocap --repl
```
See [REPL Tutorial](REPL_TUTORIAL.md)

**...import another file?**
```nocap
grab "mymodule.nocap"
```
See [Language Reference - Modules](LANGUAGE_REFERENCE.md#modules)

**...handle errors?**
```nocap
tryna {
    tea: risky code
} oops {
    tea: handle error
}
```
See [Language Reference - Error Handling](LANGUAGE_REFERENCE.md#error-handling)

**...use the standard library?**
All functions are automatically available:
```nocap
fr len = length("hello")
fr upper = uppercase("hello")
```
See [Standard Library API](STDLIB_API.md)

**...debug my program?**
- Use `yap()` for print debugging
- Check error messages in [Compiler Usage - Error Messages](COMPILER_USAGE.md#error-messages)
- Try code in [REPL](REPL_TUTORIAL.md)
- Use `--verbose` flag for detailed output

## Syntax Quick Reference

```nocap
tea: Variables
fr name: text = "Alice"
fr age: digits = 25
fr isActive: tf = real

tea: Control Flow
vibecheck condition {
    tea: code
} nah {
    tea: else code
}

run i: digits = 0; i < 10; i = i + 1 {
    tea: loop body
}

tea: Functions
lowkey greet(name: text) -> text {
    comeback "Hello, " + name
}

tea: Classes
vibe Person {
    fr name: text
    
    lowkey init(n: text) {
        self.name = n
    }
}

tea: Error Handling
tryna {
    tea: code
} oops {
    tea: handle error
}

tea: Collections
fr numbers: lineup<digits> = [1, 2, 3]
fr person: bag<text, text> = {"name": "Alice"}
```

## Additional Resources

### Implementation Details
- [Parser Implementation](../python/nocaplang/parser/PARSER_IMPLEMENTATION.md)
- [Semantic Analysis](../python/nocaplang/semantic/IMPLEMENTATION_SUMMARY.md)
- [Type System](../python/nocaplang/semantic/TYPE_SYSTEM.md)
- [C++ Standard Library](../include/README.md)
- [Java Standard Library](../java/src/main/java/com/nocaplang/stdlib/README.md)

### Project Information
- [Project Status](../PROJECT_STATUS.md)
- [Requirements](../.kiro/specs/nocap-lang/requirements.md)
- [Design Document](../.kiro/specs/nocap-lang/design.md)
- [Implementation Tasks](../.kiro/specs/nocap-lang/tasks.md)

## Contributing to Documentation

When adding or updating documentation:

1. **Be clear and concise** - Use simple language
2. **Include examples** - Show, don't just tell
3. **Link related content** - Help users navigate
4. **Test code examples** - Ensure they work
5. **Update this index** - Keep it current
6. **Follow the style** - Match existing docs

## Getting Help

- **Read the docs** - Most questions are answered here
- **Try examples** - See working code in [examples/](../examples/)
- **Use the REPL** - Test ideas interactively
- **Check error messages** - They're designed to be helpful
- **Report issues** - Help improve NoCapLang

## Documentation Roadmap

Future documentation planned:

- [ ] Video tutorials
- [ ] Interactive examples
- [ ] API reference generator
- [ ] Migration guides
- [ ] Performance tuning guide
- [ ] Testing guide
- [ ] Deployment guide

---

**Happy coding! No cap fr fr!** 🚀

For questions or feedback, please open an issue on GitHub.
