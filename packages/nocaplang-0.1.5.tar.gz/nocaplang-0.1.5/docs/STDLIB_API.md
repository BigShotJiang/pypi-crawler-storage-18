# NoCapLang Standard Library API Reference

## Table of Contents

1. [Overview](#overview)
2. [String Functions](#string-functions)
3. [Math Functions](#math-functions)
4. [Collection Functions](#collection-functions)
5. [File I/O Functions](#file-io-functions)
6. [Usage Examples](#usage-examples)

## Overview

The NoCapLang standard library provides a comprehensive set of functions for common programming tasks. All functions are automatically available without requiring imports.

### Availability

The standard library is available in both compilation targets:
- **C++ target**: Implemented using C++ STL
- **Java target**: Implemented using Java standard library

### Type Notation

- `text` - String type
- `digits` - Numeric type (integer or float)
- `tf` - Boolean type
- `lineup<T>` - Array/List of type T
- `bag<K, V>` - Map/Dictionary with key type K and value type V
- `void` - No return value

## String Functions

### length

Get the length of a string.

**Signature:**
```nocap
length(s: text) -> digits
```

**Parameters:**
- `s` - The string to measure

**Returns:**
- The number of characters in the string

**Example:**
```nocap
fr text = "Hello"
fr len = length(text)  tea: 5
```

---

### substring

Extract a portion of a string.

**Signature:**
```nocap
substring(s: text, start: digits, end: digits) -> text
```

**Parameters:**
- `s` - The source string
- `start` - Starting index (inclusive, 0-based)
- `end` - Ending index (exclusive)

**Returns:**
- The extracted substring

**Example:**
```nocap
fr text = "Hello, World!"
fr sub = substring(text, 0, 5)  tea: "Hello"
fr sub2 = substring(text, 7, 12)  tea: "World"
```

---

### split

Split a string into an array using a delimiter.

**Signature:**
```nocap
split(s: text, delimiter: text) -> lineup<text>
```

**Parameters:**
- `s` - The string to split
- `delimiter` - The delimiter to split on

**Returns:**
- Array of substrings

**Example:**
```nocap
fr text = "apple,banana,cherry"
fr fruits = split(text, ",")  tea: ["apple", "banana", "cherry"]

fr sentence = "Hello World"
fr words = split(sentence, " ")  tea: ["Hello", "World"]
```

---

### join

Join an array of strings into a single string.

**Signature:**
```nocap
join(parts: lineup<text>, separator: text) -> text
```

**Parameters:**
- `parts` - Array of strings to join
- `separator` - String to insert between elements

**Returns:**
- The joined string

**Example:**
```nocap
fr words = ["Hello", "World"]
fr sentence = join(words, " ")  tea: "Hello World"

fr items = ["apple", "banana", "cherry"]
fr csv = join(items, ",")  tea: "apple,banana,cherry"
```

---

### uppercase

Convert a string to uppercase.

**Signature:**
```nocap
uppercase(s: text) -> text
```

**Parameters:**
- `s` - The string to convert

**Returns:**
- The uppercase string

**Example:**
```nocap
fr text = "hello"
fr upper = uppercase(text)  tea: "HELLO"
```

---

### lowercase

Convert a string to lowercase.

**Signature:**
```nocap
lowercase(s: text) -> text
```

**Parameters:**
- `s` - The string to convert

**Returns:**
- The lowercase string

**Example:**
```nocap
fr text = "HELLO"
fr lower = lowercase(text)  tea: "hello"
```

---

### trim

Remove whitespace from both ends of a string.

**Signature:**
```nocap
trim(s: text) -> text
```

**Parameters:**
- `s` - The string to trim

**Returns:**
- The trimmed string

**Example:**
```nocap
fr text = "  hello  "
fr trimmed = trim(text)  tea: "hello"
```

---

### contains

Check if a string contains a substring.

**Signature:**
```nocap
contains(s: text, substring: text) -> tf
```

**Parameters:**
- `s` - The string to search in
- `substring` - The substring to search for

**Returns:**
- `real` if substring is found, `fake` otherwise

**Example:**
```nocap
fr text = "Hello, World!"
fr hasHello = contains(text, "Hello")  tea: real
fr hasGoodbye = contains(text, "Goodbye")  tea: fake
```

---

### replace

Replace all occurrences of a substring with another string.

**Signature:**
```nocap
replace(s: text, old: text, new: text) -> text
```

**Parameters:**
- `s` - The source string
- `old` - The substring to replace
- `new` - The replacement string

**Returns:**
- The string with replacements made

**Example:**
```nocap
fr text = "Hello, World!"
fr replaced = replace(text, "World", "NoCapLang")  tea: "Hello, NoCapLang!"
```

## Math Functions

### abs

Get the absolute value of a number.

**Signature:**
```nocap
abs(n: digits) -> digits
```

**Parameters:**
- `n` - The number

**Returns:**
- The absolute value

**Example:**
```nocap
fr x = abs(-42)  tea: 42
fr y = abs(17)   tea: 17
```

---

### sqrt

Calculate the square root of a number.

**Signature:**
```nocap
sqrt(n: digits) -> digits
```

**Parameters:**
- `n` - The number (must be non-negative)

**Returns:**
- The square root

**Example:**
```nocap
fr x = sqrt(16)  tea: 4.0
fr y = sqrt(2)   tea: 1.414...
```

---

### pow

Raise a number to a power.

**Signature:**
```nocap
pow(base: digits, exp: digits) -> digits
```

**Parameters:**
- `base` - The base number
- `exp` - The exponent

**Returns:**
- base raised to the power of exp

**Example:**
```nocap
fr x = pow(2, 8)   tea: 256.0
fr y = pow(10, 3)  tea: 1000.0
fr z = pow(5, 0)   tea: 1.0
```

---

### round

Round a number to the nearest integer.

**Signature:**
```nocap
round(n: digits) -> digits
```

**Parameters:**
- `n` - The number to round

**Returns:**
- The rounded number

**Example:**
```nocap
fr x = round(3.7)   tea: 4.0
fr y = round(3.2)   tea: 3.0
fr z = round(-2.5)  tea: -2.0
```

---

### floor

Round a number down to the nearest integer.

**Signature:**
```nocap
floor(n: digits) -> digits
```

**Parameters:**
- `n` - The number to round down

**Returns:**
- The floor value

**Example:**
```nocap
fr x = floor(3.7)   tea: 3.0
fr y = floor(3.2)   tea: 3.0
fr z = floor(-2.5)  tea: -3.0
```

---

### ceil

Round a number up to the nearest integer.

**Signature:**
```nocap
ceil(n: digits) -> digits
```

**Parameters:**
- `n` - The number to round up

**Returns:**
- The ceiling value

**Example:**
```nocap
fr x = ceil(3.7)   tea: 4.0
fr y = ceil(3.2)   tea: 4.0
fr z = ceil(-2.5)  tea: -2.0
```

---

### min

Get the minimum of two numbers.

**Signature:**
```nocap
min(a: digits, b: digits) -> digits
```

**Parameters:**
- `a` - First number
- `b` - Second number

**Returns:**
- The smaller of the two numbers

**Example:**
```nocap
fr x = min(5, 10)   tea: 5
fr y = min(-3, -1)  tea: -3
```

---

### max

Get the maximum of two numbers.

**Signature:**
```nocap
max(a: digits, b: digits) -> digits
```

**Parameters:**
- `a` - First number
- `b` - Second number

**Returns:**
- The larger of the two numbers

**Example:**
```nocap
fr x = max(5, 10)   tea: 10
fr y = max(-3, -1)  tea: -1
```

---

### random

Generate a random number between 0 and 1.

**Signature:**
```nocap
random() -> digits
```

**Returns:**
- A random number in the range [0, 1)

**Example:**
```nocap
fr x = random()  tea: e.g., 0.7234...
fr y = random() * 100  tea: random number 0-100
fr z = floor(random() * 6) + 1  tea: random dice roll 1-6
```

## Collection Functions

### map

Transform each element of an array using a function.

**Signature:**
```nocap
map<T, U>(arr: lineup<T>, fn: (T) -> U) -> lineup<U>
```

**Parameters:**
- `arr` - The source array
- `fn` - Function to apply to each element

**Returns:**
- New array with transformed elements

**Example:**
```nocap
fr numbers = [1, 2, 3, 4, 5]
fr doubled = map(numbers, lowkey(x) { comeback x * 2 })
tea: [2, 4, 6, 8, 10]

fr words = ["hello", "world"]
fr upper = map(words, lowkey(s) { comeback uppercase(s) })
tea: ["HELLO", "WORLD"]
```

---

### filter

Filter an array based on a predicate function.

**Signature:**
```nocap
filter<T>(arr: lineup<T>, fn: (T) -> tf) -> lineup<T>
```

**Parameters:**
- `arr` - The source array
- `fn` - Predicate function (returns `real` to keep element)

**Returns:**
- New array with filtered elements

**Example:**
```nocap
fr numbers = [1, 2, 3, 4, 5, 6]
fr evens = filter(numbers, lowkey(x) { comeback x % 2 == 0 })
tea: [2, 4, 6]

fr words = ["apple", "banana", "cherry"]
fr longWords = filter(words, lowkey(s) { comeback length(s) > 5 })
tea: ["banana", "cherry"]
```

---

### reduce

Reduce an array to a single value using an accumulator function.

**Signature:**
```nocap
reduce<T, U>(arr: lineup<T>, fn: (U, T) -> U, initial: U) -> U
```

**Parameters:**
- `arr` - The source array
- `fn` - Accumulator function (takes accumulator and current element)
- `initial` - Initial accumulator value

**Returns:**
- The final accumulated value

**Example:**
```nocap
fr numbers = [1, 2, 3, 4, 5]
fr sum = reduce(numbers, lowkey(acc, x) { comeback acc + x }, 0)
tea: 15

fr product = reduce(numbers, lowkey(acc, x) { comeback acc * x }, 1)
tea: 120

fr words = ["Hello", "World"]
fr sentence = reduce(words, lowkey(acc, w) { comeback acc + " " + w }, "")
tea: " Hello World"
```

---

### sort

Sort an array in ascending order.

**Signature:**
```nocap
sort<T>(arr: lineup<T>) -> lineup<T>
```

**Parameters:**
- `arr` - The array to sort

**Returns:**
- New sorted array (original unchanged)

**Example:**
```nocap
fr numbers = [5, 2, 8, 1, 9]
fr sorted = sort(numbers)  tea: [1, 2, 5, 8, 9]

fr words = ["cherry", "apple", "banana"]
fr sortedWords = sort(words)  tea: ["apple", "banana", "cherry"]
```

---

### reverse

Reverse the order of elements in an array.

**Signature:**
```nocap
reverse<T>(arr: lineup<T>) -> lineup<T>
```

**Parameters:**
- `arr` - The array to reverse

**Returns:**
- New reversed array (original unchanged)

**Example:**
```nocap
fr numbers = [1, 2, 3, 4, 5]
fr reversed = reverse(numbers)  tea: [5, 4, 3, 2, 1]
```

---

### keys

Get all keys from an object/map.

**Signature:**
```nocap
keys<K, V>(obj: bag<K, V>) -> lineup<K>
```

**Parameters:**
- `obj` - The object/map

**Returns:**
- Array of all keys

**Example:**
```nocap
fr person = {"name": "Alice", "age": 25, "city": "NYC"}
fr personKeys = keys(person)  tea: ["name", "age", "city"]
```

---

### values

Get all values from an object/map.

**Signature:**
```nocap
values<K, V>(obj: bag<K, V>) -> lineup<V>
```

**Parameters:**
- `obj` - The object/map

**Returns:**
- Array of all values

**Example:**
```nocap
fr person = {"name": "Alice", "age": 25, "city": "NYC"}
fr personValues = values(person)  tea: ["Alice", 25, "NYC"]
```

---

### has

Check if an object/map has a specific key.

**Signature:**
```nocap
has<K, V>(obj: bag<K, V>, key: K) -> tf
```

**Parameters:**
- `obj` - The object/map
- `key` - The key to check

**Returns:**
- `real` if key exists, `fake` otherwise

**Example:**
```nocap
fr person = {"name": "Alice", "age": 25}
fr hasName = has(person, "name")  tea: real
fr hasEmail = has(person, "email")  tea: fake
```

## File I/O Functions

### read_file

Read the entire contents of a file.

**Signature:**
```nocap
read_file(path: text) -> text
```

**Parameters:**
- `path` - Path to the file

**Returns:**
- The file contents as a string

**Throws:**
- Error if file doesn't exist or can't be read

**Example:**
```nocap
fr content = read_file("data.txt")
yap(content)
```

---

### write_file

Write content to a file (overwrites existing content).

**Signature:**
```nocap
write_file(path: text, content: text) -> void
```

**Parameters:**
- `path` - Path to the file
- `content` - Content to write

**Throws:**
- Error if file can't be written

**Example:**
```nocap
write_file("output.txt", "Hello, World!")
```

---

### append_file

Append content to a file.

**Signature:**
```nocap
append_file(path: text, content: text) -> void
```

**Parameters:**
- `path` - Path to the file
- `content` - Content to append

**Throws:**
- Error if file can't be written

**Example:**
```nocap
append_file("log.txt", "New log entry\n")
```

---

### file_exists

Check if a file exists.

**Signature:**
```nocap
file_exists(path: text) -> tf
```

**Parameters:**
- `path` - Path to the file

**Returns:**
- `real` if file exists, `fake` otherwise

**Example:**
```nocap
vibecheck file_exists("config.txt") {
    fr config = read_file("config.txt")
} nah {
    yap("Config file not found")
}
```

---

### delete_file

Delete a file.

**Signature:**
```nocap
delete_file(path: text) -> void
```

**Parameters:**
- `path` - Path to the file

**Throws:**
- Error if file doesn't exist or can't be deleted

**Example:**
```nocap
delete_file("temp.txt")
```

---

### list_directory

List all files and directories in a directory.

**Signature:**
```nocap
list_directory(path: text) -> lineup<text>
```

**Parameters:**
- `path` - Path to the directory

**Returns:**
- Array of file and directory names

**Throws:**
- Error if directory doesn't exist or can't be read

**Example:**
```nocap
fr files = list_directory(".")
each file in files {
    yap(file)
}
```

## Usage Examples

### String Processing

```nocap
tea: Parse CSV data
fr csv = "name,age,city\nAlice,25,NYC\nBob,30,LA"
fr lines = split(csv, "\n")
fr headers = split(lines[0], ",")

each line in lines {
    vibecheck line != lines[0] {
        fr values = split(line, ",")
        yap("Name:", values[0], "Age:", values[1], "City:", values[2])
    }
}
```

### Mathematical Calculations

```nocap
tea: Calculate statistics
fr numbers = [5, 2, 8, 1, 9, 3, 7]

fr sum = reduce(numbers, lowkey(acc, n) { comeback acc + n }, 0)
fr count = length(numbers)
fr average = sum / count

fr sorted = sort(numbers)
fr median = sorted[floor(count / 2)]

yap("Average:", average)
yap("Median:", median)
yap("Min:", sorted[0])
yap("Max:", sorted[count - 1])
```

### Data Transformation

```nocap
tea: Process user data
fr users = [
    {"name": "Alice", "age": 25},
    {"name": "Bob", "age": 30},
    {"name": "Charlie", "age": 35}
]

tea: Get all names
fr names = map(users, lowkey(u) { comeback u["name"] })

tea: Filter adults
fr adults = filter(users, lowkey(u) { comeback u["age"] >= 18 })

tea: Calculate total age
fr totalAge = reduce(users, lowkey(acc, u) { comeback acc + u["age"] }, 0)
```

### File Processing

```nocap
tea: Read and process a file
vibecheck file_exists("data.txt") {
    fr content = read_file("data.txt")
    fr lines = split(content, "\n")
    
    tea: Process each line
    fr processed = map(lines, lowkey(line) {
        comeback uppercase(trim(line))
    })
    
    tea: Write results
    fr output = join(processed, "\n")
    write_file("output.txt", output)
    
    yap("Processing complete!")
} nah {
    yap("Input file not found")
}
```

### Text Analysis

```nocap
tea: Count word frequency
fr text = read_file("document.txt")
fr words = split(lowercase(text), " ")

fr wordCount: bag<text, digits> = {}
each word in words {
    vibecheck has(wordCount, word) {
        wordCount[word] = wordCount[word] + 1
    } nah {
        wordCount[word] = 1
    }
}

tea: Display results
fr wordList = keys(wordCount)
each word in wordList {
    yap(word, ":", wordCount[word])
}
```

## Performance Considerations

1. **String operations** - Immutable strings; operations create new strings
2. **Collection operations** - Most return new collections (non-mutating)
3. **File I/O** - Blocking operations; use for small to medium files
4. **map/filter/reduce** - Efficient for most use cases; consider loops for very large datasets

## Error Handling

All standard library functions may throw errors. Use try-catch to handle them:

```nocap
tryna {
    fr content = read_file("missing.txt")
} oops {
    yap("Error reading file")
}
```

## Platform Differences

### C++ Target
- Uses C++ STL implementations
- File paths use platform-specific separators
- Performance optimized for native execution

### Java Target
- Uses Java standard library
- File paths use platform-specific separators
- Runs on JVM with garbage collection

Both targets provide identical functionality and behavior.

## Next Steps

- Read the [Language Reference](LANGUAGE_REFERENCE.md)
- Try the [REPL Tutorial](REPL_TUTORIAL.md)
- Check out [Examples](../examples/)
- Read [Compiler Usage](COMPILER_USAGE.md)
