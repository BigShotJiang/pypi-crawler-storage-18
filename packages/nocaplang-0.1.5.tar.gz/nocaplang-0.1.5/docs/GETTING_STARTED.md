# Getting Started with NoCapLang

## Installation

### Prerequisites

- **C++ Implementation**: CMake 3.15+, C++17 compiler (GCC 7+, Clang 5+, MSVC 2017+)
- **Python Implementation**: Python 3.8+
- **Java Implementation**: Java 11+, Gradle 7+

### Installing Dependencies

#### C++ (Optional: RapidCheck for property-based testing)

```bash
# Clone and build RapidCheck
git clone https://github.com/emil-e/rapidcheck.git
cd rapidcheck
mkdir build && cd build
cmake ..
make
sudo make install
```

#### Python

```bash
pip install -r requirements.txt
```

#### Java

Dependencies are managed by Gradle and will be downloaded automatically.

## Building the Compiler

### C++ Build

```bash
mkdir build && cd build
cmake ..
make
```

This creates the `nocap` executable in the `build/` directory.

### Python Build

```bash
pip install -e .
```

This installs the `nocap` command globally.

### Java Build

```bash
./gradlew build
```

## Your First NoCapLang Program

Create a file called `hello.nocap`:

```nocap
tea: This is a comment
fr message: text = "Hello, World!"
yap(message)
```

### Compile and Run

#### Using Python

```bash
nocap hello.nocap
# This generates hello.cpp (default target)
```

#### Using C++

```bash
./build/nocap hello.nocap
```

#### Using Java

```bash
./gradlew run --args="hello.nocap"
```

## Language Basics

### Variables

```nocap
fr name: text = "Alice"
fr age: digits = 25
fr isStudent: tf = real
fr items: lineup<text> = ["apple", "banana"]
fr person: bag<text, text> = {"name": "Bob", "city": "NYC"}
```

### Control Flow

```nocap
tea: If-else
vibecheck age >= 18 {
    yap("Adult")
} nah {
    yap("Minor")
}

tea: Loops
run i: digits = 0; i < 5; i = i + 1 {
    yap(i)
}

until age < 100 {
    age = age + 1
}

each item in items {
    yap(item)
}
```

### Functions

```nocap
lowkey greet(name: text) -> text {
    comeback "Hello, " + name + "!"
}

fr greeting: text = greet("World")
yap(greeting)
```

### Classes

```nocap
vibe Person {
    fr name: text
    fr age: digits
    
    lowkey constructor(n: text, a: digits) {
        self.name = n
        self.age = a
    }
    
    lowkey introduce() -> void {
        yap("Hi, I'm", self.name)
    }
}

fr person: Person = Person("Alice", 25)
person.introduce()
```

## REPL Mode

Start an interactive session:

```bash
nocap --repl
```

## Next Steps

- Read the [Language Reference](LANGUAGE_REFERENCE.md)
- Explore [Examples](../examples/)
- Check out the [Standard Library](STDLIB.md)
