# NoCapLang REPL Tutorial

## Table of Contents

1. [Introduction](#introduction)
2. [Starting the REPL](#starting-the-repl)
3. [Basic Usage](#basic-usage)
4. [Variables and State](#variables-and-state)
5. [Functions](#functions)
6. [Classes](#classes)
7. [Multi-Line Input](#multi-line-input)
8. [Special Commands](#special-commands)
9. [Error Handling](#error-handling)
10. [Tips and Tricks](#tips-and-tricks)

## Introduction

The NoCapLang REPL (Read-Eval-Print Loop) provides an interactive environment for experimenting with NoCapLang code. It's perfect for:

- Learning the language
- Testing code snippets
- Debugging
- Quick calculations
- Prototyping ideas

## Starting the REPL

### Python Implementation

```bash
nocap --repl
```

### C++ Implementation

```bash
./build/nocap --repl
```

### Java Implementation

```bash
./gradlew runRepl
```

You should see:

```
NoCapLang REPL v1.0
Type ':help' for help, ':exit' to quit
>>>
```

## Basic Usage

### Simple Expressions

The REPL evaluates expressions and displays results:

```nocap
>>> 2 + 2
4

>>> "Hello, " + "World!"
Hello, World!

>>> 10 * 5
50

>>> real and fake
fake
```

### Print Statements

```nocap
>>> yap("Hello, REPL!")
Hello, REPL!

>>> yap(42)
42
```

### Arithmetic

```nocap
>>> 10 + 5
15

>>> 10 - 5
5

>>> 10 * 5
50

>>> 10 / 5
2.0

>>> 10 % 3
1
```

### Comparisons

```nocap
>>> 10 > 5
real

>>> 10 == 10
real

>>> 5 != 10
real

>>> "hello" == "hello"
real
```

## Variables and State

The REPL maintains state across inputs, so variables persist:

```nocap
>>> fr name = "Alice"
>>> yap(name)
Alice

>>> fr age = 25
>>> yap("Name:", name, "Age:", age)
Name: Alice Age: 25

>>> age = age + 1
>>> yap(age)
26
```

### Type Annotations

```nocap
>>> fr x: digits = 42
>>> fr message: text = "Hello"
>>> fr isActive: tf = real
```

### Collections

```nocap
>>> fr numbers = [1, 2, 3, 4, 5]
>>> yap(numbers)
[1, 2, 3, 4, 5]

>>> yap(numbers[0])
1

>>> fr person = {"name": "Bob", "age": 30}
>>> yap(person["name"])
Bob
```

## Functions

### Defining Functions

```nocap
>>> lowkey greet(name: text) -> text {
...     comeback "Hello, " + name + "!"
... }

>>> yap(greet("Alice"))
Hello, Alice!
```

### Using Functions

```nocap
>>> lowkey add(a: digits, b: digits) -> digits {
...     comeback a + b
... }

>>> fr result = add(10, 20)
>>> yap(result)
30

>>> yap(add(5, 7))
12
```

### Recursive Functions

```nocap
>>> lowkey factorial(n: digits) -> digits {
...     vibecheck n <= 1 {
...         comeback 1
...     }
...     comeback n * factorial(n - 1)
... }

>>> yap(factorial(5))
120
```

## Classes

### Defining Classes

```nocap
>>> vibe Person {
...     fr name: text
...     fr age: digits
...     
...     lowkey init(n: text, a: digits) {
...         self.name = n
...         self.age = a
...     }
...     
...     lowkey greet() -> void {
...         yap("Hello, I'm", self.name)
...     }
... }

>>> fr person = Person("Alice", 25)
>>> person.greet()
Hello, I'm Alice
```

### Using Classes

```nocap
>>> vibe Counter {
...     fr count: digits
...     
...     lowkey init() {
...         self.count = 0
...     }
...     
...     lowkey increment() -> void {
...         self.count = self.count + 1
...     }
...     
...     lowkey getCount() -> digits {
...         comeback self.count
...     }
... }

>>> fr counter = Counter()
>>> counter.increment()
>>> counter.increment()
>>> yap(counter.getCount())
2
```

## Multi-Line Input

The REPL automatically detects incomplete statements and allows multi-line input:

### Multi-Line Functions

```nocap
>>> lowkey calculate(x: digits) -> digits {
...     fr result = x * 2
...     result = result + 10
...     comeback result
... }
```

The `...` prompt indicates continuation. Press Enter on an empty line to complete.

### Multi-Line Conditionals

```nocap
>>> fr x = 10
>>> vibecheck x > 5 {
...     yap("Greater than 5")
... } nah {
...     yap("5 or less")
... }
Greater than 5
```

### Multi-Line Loops

```nocap
>>> run i: digits = 0; i < 3; i = i + 1 {
...     yap("Count:", i)
... }
Count: 0
Count: 1
Count: 2
```

## Special Commands

The REPL supports special commands that start with `:`:

### :help

Show help information:

```nocap
>>> :help
NoCapLang REPL Commands:
  :help     - Show this help message
  :exit     - Exit the REPL
  :quit     - Exit the REPL
  :clear    - Clear all variables and state
  :type     - Show type of expression
  :target   - Show or change compilation target
  :vars     - List all defined variables
```

### :exit or :quit

Exit the REPL:

```nocap
>>> :exit
Goodbye!
```

### :clear

Clear all variables and reset state:

```nocap
>>> fr x = 10
>>> yap(x)
10

>>> :clear
State cleared

>>> yap(x)
Error: Undefined variable 'x'
```

### :type

Show the type of an expression:

```nocap
>>> :type 42
digits

>>> :type "hello"
text

>>> :type real
tf

>>> fr numbers = [1, 2, 3]
>>> :type numbers
lineup<digits>
```

### :target

Show or change the compilation target:

```nocap
>>> :target
Current target: cpp

>>> :target java
Target changed to: java

>>> :target cpp
Target changed to: cpp
```

### :vars

List all defined variables:

```nocap
>>> fr x = 10
>>> fr name = "Alice"
>>> fr isActive = real

>>> :vars
Variables:
  x: digits = 10
  name: text = "Alice"
  isActive: tf = real
```

## Error Handling

The REPL handles errors gracefully and continues running:

### Syntax Errors

```nocap
>>> fr x = 
Error: Syntax error at line 1, column 8
  fr x = 
        ^
Expected expression after '='

>>> fr y = 10
>>> yap(y)
10
```

### Type Errors

```nocap
>>> fr x: digits = "hello"
Error: Type mismatch at line 1, column 16
  fr x: digits = "hello"
                 ^^^^^^^
Expected type 'digits', got 'text'

>>> fr x: digits = 42
>>> yap(x)
42
```

### Runtime Errors

```nocap
>>> fr numbers = [1, 2, 3]
>>> yap(numbers[10])
Error: Index out of bounds
  Index: 10, Size: 3

>>> yap(numbers[0])
1
```

### Undefined Variables

```nocap
>>> yap(unknownVar)
Error: Undefined variable 'unknownVar'
Did you mean: 'knownVar'?

>>> fr knownVar = 42
>>> yap(knownVar)
42
```

## Tips and Tricks

### Quick Calculations

Use the REPL as a calculator:

```nocap
>>> 2 ** 10
1024

>>> sqrt(16)
4.0

>>> pow(2, 8)
256.0
```

### Testing Standard Library

Try out standard library functions:

```nocap
>>> fr text = "  hello world  "
>>> yap(trim(text))
hello world

>>> yap(uppercase(text))
  HELLO WORLD  

>>> fr words = split(trim(text), " ")
>>> yap(words)
[hello, world]
```

### Prototyping Algorithms

Test algorithms before adding to your program:

```nocap
>>> lowkey isPrime(n: digits) -> tf {
...     vibecheck n < 2 {
...         comeback fake
...     }
...     run i: digits = 2; i * i <= n; i = i + 1 {
...         vibecheck n % i == 0 {
...             comeback fake
...         }
...     }
...     comeback real
... }

>>> yap(isPrime(17))
real

>>> yap(isPrime(18))
fake
```

### Exploring Collections

```nocap
>>> fr data = [5, 2, 8, 1, 9]
>>> yap(sort(data))
[1, 2, 5, 8, 9]

>>> yap(reverse(data))
[9, 1, 8, 2, 5]

>>> fr doubled = map(data, lowkey(x) { comeback x * 2 })
>>> yap(doubled)
[10, 4, 16, 2, 18]
```

### Debugging

Use the REPL to test parts of your program:

```nocap
>>> tea: Test a function from your program
>>> lowkey myFunction(x: digits) -> digits {
...     comeback x * 2 + 10
... }

>>> yap(myFunction(5))
20

>>> yap(myFunction(0))
10

>>> yap(myFunction(-5))
0
```

### Learning by Experimentation

Try different language features:

```nocap
>>> tea: Test conditionals
>>> fr score = 85
>>> vibecheck score >= 90 {
...     yap("A")
... } nah vibecheck score >= 80 {
...     yap("B")
... } nah {
...     yap("C")
... }
B

>>> tea: Test loops
>>> fr sum = 0
>>> run i: digits = 1; i <= 5; i = i + 1 {
...     sum = sum + i
... }
>>> yap(sum)
15
```

### Copy-Paste Code

You can paste multi-line code directly:

```nocap
>>> lowkey fibonacci(n: digits) -> digits {
...     vibecheck n <= 1 {
...         comeback n
...     }
...     comeback fibonacci(n - 1) + fibonacci(n - 2)
... }
>>> run i: digits = 0; i < 10; i = i + 1 {
...     yap(fibonacci(i))
... }
0
1
1
2
3
5
8
13
21
34
```

## Common Workflows

### 1. Quick Script Testing

```nocap
>>> tea: Test a quick script
>>> fr names = ["Alice", "Bob", "Charlie"]
>>> each name in names {
...     yap("Hello,", name)
... }
Hello, Alice
Hello, Bob
Hello, Charlie
```

### 2. Function Development

```nocap
>>> tea: Develop a function iteratively
>>> lowkey gradeToLetter(score: digits) -> text {
...     vibecheck score >= 90 {
...         comeback "A"
...     }
...     comeback "F"
... }

>>> yap(gradeToLetter(95))
A

>>> tea: Add more cases
>>> lowkey gradeToLetter(score: digits) -> text {
...     vibecheck score >= 90 {
...         comeback "A"
...     } nah vibecheck score >= 80 {
...         comeback "B"
...     }
...     comeback "F"
... }

>>> yap(gradeToLetter(85))
B
```

### 3. Data Exploration

```nocap
>>> fr data = [
...     {"name": "Alice", "age": 25},
...     {"name": "Bob", "age": 30},
...     {"name": "Charlie", "age": 35}
... ]

>>> each person in data {
...     yap(person["name"], "is", person["age"], "years old")
... }
Alice is 25 years old
Bob is 30 years old
Charlie is 35 years old
```

## Keyboard Shortcuts

- **Ctrl+C** - Cancel current input
- **Ctrl+D** - Exit REPL (Unix/Linux/Mac)
- **Ctrl+Z** - Exit REPL (Windows)
- **Up/Down arrows** - Navigate command history
- **Tab** - Auto-complete (if supported)

## Best Practices

1. **Start simple** - Test basic expressions before complex code
2. **Use :clear** - Reset state when starting fresh
3. **Check types** - Use :type to verify expression types
4. **Save useful code** - Copy working code to files
5. **Experiment freely** - The REPL is safe for experimentation
6. **Use comments** - Document your REPL experiments
7. **Test edge cases** - Try boundary values and special cases

## Limitations

- **No file I/O in REPL** - File operations may not work as expected
- **Limited async support** - Async operations may behave differently
- **State persistence** - State is lost when REPL exits
- **Performance** - REPL is for development, not production

## Next Steps

- Read the [Language Reference](LANGUAGE_REFERENCE.md)
- Check out [Compiler Usage](COMPILER_USAGE.md)
- Explore [Standard Library](STDLIB_API.md)
- Try [Examples](../examples/)

## Troubleshooting

### REPL Won't Start

```bash
# Check installation
nocap --version

# Reinstall if needed
pip install -e .
```

### Can't Exit REPL

- Try `:exit` or `:quit`
- Press Ctrl+D (Unix/Linux/Mac) or Ctrl+Z (Windows)
- Close the terminal window

### State Issues

```nocap
>>> :clear
State cleared
```

### Syntax Highlighting Not Working

Some terminals don't support colors. The REPL will still work without highlighting.

## Advanced Features

### Importing Modules in REPL

```nocap
>>> grab "mymodule.nocap"
>>> tea: Use functions from mymodule
```

### Changing Targets

```nocap
>>> :target java
Target changed to: java

>>> tea: Now generates Java code
```

### Inspecting Generated Code

```nocap
>>> :show-generated
tea: Shows the generated C++ or Java code
```

Happy REPLing! 🚀
