# NoCapLang Compiler Usage Guide

## Table of Contents

1. [Installation](#installation)
2. [Basic Usage](#basic-usage)
3. [Command-Line Options](#command-line-options)
4. [Compilation Targets](#compilation-targets)
5. [Error Messages](#error-messages)
6. [Optimization](#optimization)
7. [Multi-File Projects](#multi-file-projects)
8. [Integration with Build Systems](#integration-with-build-systems)
9. [Troubleshooting](#troubleshooting)

## Installation

### Python Implementation (Recommended)

```bash
# Clone the repository
git clone https://github.com/yourusername/nocaplang.git
cd nocaplang

# Install dependencies
pip install -r requirements.txt

# Install the compiler
pip install -e .

# Verify installation
nocap --version
```

### C++ Implementation

```bash
# Prerequisites: CMake 3.15+, C++17 compiler

# Build
mkdir build && cd build
cmake ..
make

# The compiler will be at build/nocap
./nocap --version
```

### Java Implementation

```bash
# Prerequisites: Java 11+, Gradle 7+

# Build
./gradlew build

# Run
./gradlew run --args="--version"
```

## Basic Usage

### Compile a Program

The simplest way to compile a NoCapLang program:

```bash
nocap program.nocap
```

This generates `program.cpp` in the same directory.

### Compile and Specify Output

```bash
nocap program.nocap --output myprogram.cpp
```

### Compile to Java

```bash
nocap program.nocap --target java
```

This generates `program.java`.

### Compile and Run

**For C++ target:**
```bash
# Compile NoCapLang to C++
nocap program.nocap

# Compile C++ to executable
g++ -std=c++17 program.cpp -o program

# Run
./program
```

**For Java target:**
```bash
# Compile NoCapLang to Java
nocap program.nocap --target java

# Compile Java to bytecode
javac program.java

# Run
java program
```

## Command-Line Options

### General Options

```bash
nocap [options] <file.nocap>
```

**Options:**

- `--help`, `-h` - Show help message
- `--version`, `-v` - Show compiler version
- `--target <cpp|java>` - Specify compilation target (default: cpp)
- `--output <file>`, `-o <file>` - Specify output file
- `--repl` - Start interactive REPL
- `--verbose` - Enable verbose output
- `--quiet` - Suppress non-error messages

### Examples

**Show help:**
```bash
nocap --help
```

**Show version:**
```bash
nocap --version
```

**Compile with verbose output:**
```bash
nocap --verbose program.nocap
```

**Compile to specific output file:**
```bash
nocap program.nocap -o output.cpp
```

**Compile to Java:**
```bash
nocap --target java program.nocap
```

## Compilation Targets

### C++ Target (Default)

The C++ target generates C++17 code that can be compiled with any modern C++ compiler.

**Type Mappings:**
- `text` → `std::string`
- `digits` → `double`
- `tf` → `bool`
- `lineup<T>` → `std::vector<T>`
- `bag<K, V>` → `std::unordered_map<K, V>`
- `ghost` → `std::optional<T>` or `nullptr`

**Required Headers:**
The generated code includes necessary headers:
```cpp
#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <optional>
#include <functional>
#include <future>
```

**Compiling Generated C++:**
```bash
g++ -std=c++17 program.cpp -o program
# or
clang++ -std=c++17 program.cpp -o program
```

**With Standard Library:**
```bash
g++ -std=c++17 program.cpp -I/path/to/nocaplang/include -o program
```

### Java Target

The Java target generates Java 11+ code.

**Type Mappings:**
- `text` → `String`
- `digits` → `double`
- `tf` → `boolean`
- `lineup<T>` → `ArrayList<T>`
- `bag<K, V>` → `HashMap<K, V>`
- `ghost` → `null`

**Required Imports:**
The generated code includes necessary imports:
```java
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.io.*;
```

**Compiling Generated Java:**
```bash
javac program.java
java program
```

**With Standard Library:**
```bash
javac -cp /path/to/nocaplang/stdlib.jar program.java
java -cp /path/to/nocaplang/stdlib.jar:. program
```

## Error Messages

The NoCapLang compiler provides detailed error messages to help you fix issues quickly.

### Syntax Errors

**Example:**
```nocap
fr x = 10
vibecheck x > 5
    yap("Greater")
}
```

**Error:**
```
Error: Syntax error at line 2, column 16
  vibecheck x > 5
                 ^
Expected '{' after condition
```

### Type Errors

**Example:**
```nocap
fr x: digits = "hello"
```

**Error:**
```
Error: Type mismatch at line 1, column 16
  fr x: digits = "hello"
                 ^^^^^^^
Expected type 'digits', got 'text'
```

### Undefined Variable

**Example:**
```nocap
yap(unknownVariable)
```

**Error:**
```
Error: Undefined variable at line 1, column 5
  yap(unknownVariable)
      ^^^^^^^^^^^^^^^
Variable 'unknownVariable' is not defined
Did you mean: 'knownVariable'?
```

### Semantic Errors

**Example:**
```nocap
lowkey myFunction() {
    dip  tea: break outside loop
}
```

**Error:**
```
Error: Invalid statement at line 2, column 5
    dip
    ^^^
'dip' can only be used inside a loop
```

## Optimization

### Optimization Levels

The compiler supports optimization flags:

```bash
nocap --optimize program.nocap
```

**Optimizations include:**
- Constant folding
- Dead code elimination
- Inline function hints (C++)
- Final keyword optimization (Java)

**Example:**

**Before optimization:**
```nocap
fr x = 2 + 3
fr y = x * 2
```

**After optimization:**
```cpp
double x = 5;  // constant folded
double y = 10; // constant folded
```

### Disabling Optimizations

```bash
nocap --no-optimize program.nocap
```

## Multi-File Projects

### Project Structure

```
myproject/
├── main.nocap
├── utils.nocap
└── models.nocap
```

### Using Imports

**utils.nocap:**
```nocap
lowkey add(a: digits, b: digits) -> digits {
    comeback a + b
}

lowkey multiply(a: digits, b: digits) -> digits {
    comeback a * b
}
```

**main.nocap:**
```nocap
grab "utils.nocap"

fr result = add(10, 20)
yap("Result:", result)
```

### Compiling Multi-File Projects

**Option 1: Compile main file (imports are resolved automatically)**
```bash
nocap main.nocap
```

**Option 2: Compile all files together**
```bash
nocap main.nocap utils.nocap models.nocap
```

### Relative Imports

```nocap
grab "./utils.nocap"           tea: same directory
grab "../shared/helpers.nocap" tea: parent directory
grab "lib/math.nocap"          tea: subdirectory
```

## Integration with Build Systems

### Makefile

```makefile
# Makefile for NoCapLang project

NOCAP = nocap
TARGET = cpp
SOURCES = main.nocap utils.nocap models.nocap
OUTPUT = main.cpp

all: compile

compile:
	$(NOCAP) --target $(TARGET) $(SOURCES) -o $(OUTPUT)
	g++ -std=c++17 $(OUTPUT) -o program

run: compile
	./program

clean:
	rm -f $(OUTPUT) program

.PHONY: all compile run clean
```

### CMake

```cmake
# CMakeLists.txt for NoCapLang project

cmake_minimum_required(VERSION 3.15)
project(MyNoCapProject)

set(CMAKE_CXX_STANDARD 17)

# Custom command to compile NoCapLang to C++
add_custom_command(
    OUTPUT ${CMAKE_CURRENT_BINARY_DIR}/main.cpp
    COMMAND nocap ${CMAKE_CURRENT_SOURCE_DIR}/main.nocap 
            -o ${CMAKE_CURRENT_BINARY_DIR}/main.cpp
    DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/main.nocap
    COMMENT "Compiling NoCapLang to C++"
)

# Add executable from generated C++
add_executable(program ${CMAKE_CURRENT_BINARY_DIR}/main.cpp)
```

### Gradle (for Java target)

```groovy
// build.gradle for NoCapLang project

plugins {
    id 'java'
}

task compileNoCapLang(type: Exec) {
    commandLine 'nocap', '--target', 'java', 
                'src/main.nocap', '-o', 'src/Main.java'
}

compileJava.dependsOn compileNoCapLang

sourceSets {
    main {
        java {
            srcDirs = ['src']
        }
    }
}
```

## Troubleshooting

### Common Issues

#### Issue: "nocap: command not found"

**Solution:**
```bash
# Make sure the compiler is installed
pip install -e .

# Or add to PATH
export PATH=$PATH:/path/to/nocaplang/build
```

#### Issue: "Cannot find module 'utils.nocap'"

**Solution:**
- Check that the file exists
- Use correct relative path
- Ensure file has .nocap extension

#### Issue: Generated C++ won't compile

**Solution:**
```bash
# Make sure you have C++17 support
g++ --version  # should be 7.0 or higher

# Use correct flags
g++ -std=c++17 program.cpp -o program

# Include standard library if needed
g++ -std=c++17 -I/path/to/nocaplang/include program.cpp -o program
```

#### Issue: Generated Java won't compile

**Solution:**
```bash
# Make sure you have Java 11+
java --version

# Include standard library
javac -cp /path/to/nocaplang/stdlib.jar program.java
```

### Debugging

#### Enable Verbose Output

```bash
nocap --verbose program.nocap
```

This shows:
- Lexer tokens
- Parser AST
- Semantic analysis results
- Code generation steps

#### Check Generated Code

Inspect the generated C++ or Java code to understand what the compiler produced:

```bash
nocap program.nocap -o output.cpp
cat output.cpp
```

#### Validate Syntax

Use the compiler to check syntax without generating code:

```bash
nocap --check-syntax program.nocap
```

### Getting Help

- **Documentation:** See `docs/` directory
- **Examples:** See `examples/` directory
- **Issues:** Report bugs on GitHub
- **Community:** Join our Discord/Slack

## Performance Tips

1. **Use type annotations** - Helps compiler generate more efficient code
2. **Avoid unnecessary allocations** - Reuse collections when possible
3. **Use appropriate data structures** - Choose `lineup` vs `bag` wisely
4. **Enable optimizations** - Use `--optimize` flag
5. **Profile generated code** - Use standard C++/Java profiling tools

## Advanced Usage

### Custom Standard Library Path

```bash
nocap --stdlib-path /custom/path program.nocap
```

### Generate Assembly

```bash
# For C++ target
nocap program.nocap -o program.cpp
g++ -S -std=c++17 program.cpp -o program.s
```

### Cross-Compilation

```bash
# Compile on Linux for Windows (C++ target)
nocap program.nocap -o program.cpp
x86_64-w64-mingw32-g++ -std=c++17 program.cpp -o program.exe
```

### Continuous Integration

**GitHub Actions example:**
```yaml
name: Build NoCapLang

on: [push, pull_request]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Install NoCapLang
        run: pip install -e .
      - name: Compile
        run: nocap main.nocap
      - name: Build C++
        run: g++ -std=c++17 main.cpp -o program
      - name: Run
        run: ./program
```

## Best Practices

1. **Version control** - Commit `.nocap` files, not generated code
2. **Consistent style** - Use consistent naming and formatting
3. **Modular design** - Split large programs into multiple files
4. **Test thoroughly** - Test both NoCapLang and generated code
5. **Document** - Use comments to explain complex logic
6. **Handle errors** - Use try-catch for robust programs
7. **Use standard library** - Leverage built-in functions

## Next Steps

- Read the [Language Reference](LANGUAGE_REFERENCE.md)
- Try the [REPL Tutorial](REPL_TUTORIAL.md)
- Explore [Standard Library](STDLIB_API.md)
- Check out [Examples](../examples/)
