# NoCapLang Language Reference

## Table of Contents

1. [Introduction](#introduction)
2. [Lexical Structure](#lexical-structure)
3. [Data Types](#data-types)
4. [Variables](#variables)
5. [Operators](#operators)
6. [Control Flow](#control-flow)
7. [Functions](#functions)
8. [Classes](#classes)
9. [Error Handling](#error-handling)
10. [Async/Await](#asyncawait)
11. [Pattern Matching](#pattern-matching)
12. [Modules](#modules)
13. [Comments](#comments)
14. [Assertions](#assertions)
15. [Standard Library](#standard-library)

## Introduction

NoCapLang is a compiled programming language that transpiles to C++ or Java. It features Gen Z slang-based syntax while providing full programming capabilities including object-oriented programming, async/await, pattern matching, and a comprehensive standard library.

### File Extension

NoCapLang source files use the `.nocap` extension.

### Hello World

```nocap
fr message: text = "Hello, World!"
yap(message)
```

## Lexical Structure

### Keywords

NoCapLang uses the following keywords:

**Variable Declaration:**
- `fr` - declare a variable (short for "for real")

**Output:**
- `yap` - print to console

**Control Flow:**
- `vibecheck` - if statement
- `nah` - else
- `run` - for loop
- `until` - while loop
- `each` - for-each loop
- `dip` - break
- `skip` - continue

**Functions:**
- `lowkey` - function declaration
- `comeback` - return statement

**Classes:**
- `vibe` - class declaration
- `vibes_with` - inheritance
- `self` - reference to current instance

**Error Handling:**
- `tryna` - try block
- `oops` - catch block
- `nomatter` - finally block
- `crash` - throw error

**Async:**
- `chill` - async function
- `holdup` - await

**Pattern Matching:**
- `match` - match statement
- `case` - case clause
- `default` - default case

**Modules:**
- `grab` - import statement

**Assertions:**
- `nocap` - assertion (literally "no cap" = "no lie")

**Type Keywords:**
- `text` - string type
- `digits` - number type
- `tf` - boolean type (true/false)
- `lineup` - array type
- `bag` - object/map type
- `void` - void type
- `choices` - enum type

**Literals:**
- `real` - boolean true
- `fake` - boolean false
- `ghost` - null value

### Identifiers

Identifiers must start with a letter or underscore, followed by any combination of letters, numbers, or underscores. Unicode characters are supported.

```nocap
fr myVariable = 10
fr _private = 20
fr user123 = "Alice"
fr 变量 = "Unicode support"
```

### Literals

**String Literals:**
```nocap
fr name = "Alice"
fr message = "Hello, \"World\"!"
fr multiline = "Line 1\nLine 2\nLine 3"
```

Escape sequences: `\n` (newline), `\t` (tab), `\"` (quote), `\\` (backslash)

**Number Literals:**
```nocap
fr integer = 42
fr float = 3.14
fr scientific = 1.5e10
fr negative = -17
```

**Boolean Literals:**
```nocap
fr isTrue = real
fr isFalse = fake
```

**Null Literal:**
```nocap
fr nothing = ghost
```

**Array Literals:**
```nocap
fr numbers = [1, 2, 3, 4, 5]
fr mixed = [1, "two", real, ghost]
```

**Object Literals:**
```nocap
fr person = {
    "name": "Alice",
    "age": 25,
    "city": "NYC"
}
```

## Data Types

### Primitive Types

**text** - String type
```nocap
fr name: text = "Alice"
```

**digits** - Numeric type (supports integers and floats)
```nocap
fr age: digits = 25
fr pi: digits = 3.14159
```

**tf** - Boolean type
```nocap
fr isActive: tf = real
fr isDeleted: tf = fake
```

**void** - No return value (for functions)
```nocap
lowkey printMessage() -> void {
    yap("Hello")
}
```

### Collection Types

**lineup<T>** - Array/List type
```nocap
fr numbers: lineup<digits> = [1, 2, 3, 4, 5]
fr names: lineup<text> = ["Alice", "Bob", "Charlie"]
```

**bag<K, V>** - Object/Map type
```nocap
fr scores: bag<text, digits> = {
    "Alice": 95,
    "Bob": 87
}
```

### Special Types

**ghost** - Null/undefined value
```nocap
fr maybeValue = ghost
```

## Variables

### Declaration

Variables are declared with the `fr` keyword:

```nocap
fr x = 10
fr name = "Alice"
fr isActive = real
```

### Type Annotations

Type annotations are optional but recommended:

```nocap
fr x: digits = 10
fr name: text = "Alice"
fr isActive: tf = real
```

### Uninitialized Variables

Variables without initialization default to `ghost`:

```nocap
fr x: digits
tea: x is ghost until assigned
```

### Assignment

```nocap
fr x = 10
x = 20
x = x + 5
```

## Operators

### Arithmetic Operators

```nocap
fr sum = 10 + 5        tea: Addition
fr diff = 10 - 5       tea: Subtraction
fr product = 10 * 5    tea: Multiplication
fr quotient = 10 / 5   tea: Division
fr remainder = 10 % 3  tea: Modulo
```

### Comparison Operators

```nocap
fr isEqual = 10 == 10        tea: Equal
fr isNotEqual = 10 != 5      tea: Not equal
fr isLess = 5 < 10           tea: Less than
fr isGreater = 10 > 5        tea: Greater than
fr isLessOrEqual = 5 <= 10   tea: Less than or equal
fr isGreaterOrEqual = 10 >= 5 tea: Greater than or equal
```

### Logical Operators

```nocap
fr andResult = real and fake    tea: Logical AND
fr orResult = real or fake      tea: Logical OR
fr notResult = not real         tea: Logical NOT
```

### Operator Precedence

From highest to lowest:
1. Parentheses `()`
2. Unary operators: `not`, `-` (negation)
3. Multiplicative: `*`, `/`, `%`
4. Additive: `+`, `-`
5. Comparison: `<`, `>`, `<=`, `>=`
6. Equality: `==`, `!=`
7. Logical AND: `and`
8. Logical OR: `or`

## Control Flow

### If-Else (vibecheck/nah)

```nocap
vibecheck condition {
    tea: code when condition is true
}

vibecheck condition {
    tea: code when condition is true
} nah {
    tea: code when condition is false
}

vibecheck condition1 {
    tea: code for condition1
} nah vibecheck condition2 {
    tea: code for condition2
} nah {
    tea: code when all conditions are false
}
```

### For Loop (run)

```nocap
run i: digits = 0; i < 10; i = i + 1 {
    yap(i)
}
```

### While Loop (until)

```nocap
fr i = 0
until i < 10 {
    yap(i)
    i = i + 1
}
```

### For-Each Loop (each)

**Iterate over array:**
```nocap
fr numbers = [1, 2, 3, 4, 5]
each num in numbers {
    yap(num)
}
```

**Iterate over object:**
```nocap
fr person = {"name": "Alice", "age": 25}
each key in person {
    yap(key, ":", person[key])
}
```

### Break (dip)

```nocap
run i: digits = 0; i < 10; i = i + 1 {
    vibecheck i == 5 {
        dip  tea: exit loop
    }
    yap(i)
}
```

### Continue (skip)

```nocap
run i: digits = 0; i < 10; i = i + 1 {
    vibecheck i % 2 == 0 {
        skip  tea: skip even numbers
    }
    yap(i)
}
```

## Functions

### Function Declaration

```nocap
lowkey functionName(param1: type1, param2: type2) -> returnType {
    tea: function body
    comeback result
}
```

### Examples

**Simple function:**
```nocap
lowkey greet(name: text) -> text {
    comeback "Hello, " + name + "!"
}

fr greeting = greet("Alice")
yap(greeting)
```

**Function without return:**
```nocap
lowkey printMessage(msg: text) -> void {
    yap(msg)
}
```

**Function with default return:**
```nocap
lowkey doSomething() {
    yap("Doing something")
    tea: returns ghost by default
}
```

**Recursive function:**
```nocap
lowkey factorial(n: digits) -> digits {
    vibecheck n <= 1 {
        comeback 1
    }
    comeback n * factorial(n - 1)
}
```

**Lambda/Anonymous function:**
```nocap
fr double = lowkey(x: digits) { comeback x * 2 }
fr result = double(5)
```

## Classes

### Class Declaration

```nocap
vibe ClassName {
    tea: properties
    fr property1: type1
    fr property2: type2
    
    tea: constructor
    lowkey init(param1: type1, param2: type2) {
        self.property1 = param1
        self.property2 = param2
    }
    
    tea: methods
    lowkey methodName() -> returnType {
        tea: method body
    }
}
```

### Example

```nocap
vibe Person {
    fr name: text
    fr age: digits
    
    lowkey init(n: text, a: digits) {
        self.name = n
        self.age = a
    }
    
    lowkey greet() -> void {
        yap("Hello, I'm", self.name)
    }
    
    lowkey getAge() -> digits {
        comeback self.age
    }
}

fr person = Person("Alice", 25)
person.greet()
yap("Age:", person.getAge())
```

### Inheritance

```nocap
vibe Student vibes_with Person {
    fr grade: text
    
    lowkey init(n: text, a: digits, g: text) {
        self.name = n
        self.age = a
        self.grade = g
    }
    
    lowkey study() -> void {
        yap(self.name, "is studying")
    }
}

fr student = Student("Bob", 20, "A")
student.greet()  tea: inherited method
student.study()  tea: own method
```

### Method Overriding

```nocap
vibe Dog vibes_with Animal {
    lowkey speak() -> void {
        yap("Woof woof!")
    }
}
```

## Error Handling

### Try-Catch-Finally

```nocap
tryna {
    tea: code that might throw error
} oops {
    tea: handle error
} nomatter {
    tea: always executes (optional)
}
```

### Throwing Errors

```nocap
lowkey divide(a: digits, b: digits) -> digits {
    vibecheck b == 0 {
        crash "Cannot divide by zero"
    }
    comeback a / b
}
```

### Example

```nocap
tryna {
    fr result = divide(10, 0)
    yap(result)
} oops {
    yap("Error occurred!")
} nomatter {
    yap("Cleanup code")
}
```

## Async/Await

### Async Functions

Declare async functions with `chill`:

```nocap
chill lowkey fetchData(url: text) -> text {
    tea: async operation
    comeback "data"
}
```

### Await

Use `holdup` to wait for async operations:

```nocap
chill lowkey main() -> void {
    fr data = holdup fetchData("https://api.example.com")
    yap(data)
}
```

### Example

```nocap
chill lowkey processUser(userId: digits) -> text {
    fr user = holdup fetchUser(userId)
    fr posts = holdup fetchPosts(userId)
    comeback user + " has " + posts + " posts"
}
```

**Note:** `holdup` can only be used inside `chill` functions.

## Pattern Matching

### Match Statement

```nocap
match expression {
    case pattern1 {
        tea: code for pattern1
    }
    case pattern2 {
        tea: code for pattern2
    }
    default {
        tea: default case
    }
}
```

### Value Matching

```nocap
match number {
    case 0 {
        yap("zero")
    }
    case 1 {
        yap("one")
    }
    default {
        yap("other")
    }
}
```

### Type Matching

```nocap
match value {
    case text {
        yap("It's a string")
    }
    case digits {
        yap("It's a number")
    }
    default {
        yap("Unknown type")
    }
}
```

### Range Matching

```nocap
match score {
    case 90..100 {
        yap("A")
    }
    case 80..89 {
        yap("B")
    }
    case 70..79 {
        yap("C")
    }
    default {
        yap("F")
    }
}
```

## Modules

### Import Entire Module

```nocap
grab "module.nocap"
```

### Import Specific Symbols

```nocap
grab { function1, function2 } from "module.nocap"
```

### Import with Alias

```nocap
grab "module.nocap" as alias
```

### Relative Imports

```nocap
grab "./utils.nocap"
grab "../shared/helpers.nocap"
```

## Comments

### Single-Line Comments

```nocap
tea: This is a single-line comment
fr x = 10  tea: comment after code
```

### Multi-Line Comments

```nocap
rant:
This is a multi-line comment.
It can span multiple lines.
Useful for documentation.
:end
```

## Assertions

### Basic Assertion

```nocap
nocap condition, "error message"
```

### Examples

```nocap
fr age = 25
nocap age >= 0, "Age must be non-negative"
nocap age < 150, "Age must be realistic"

lowkey divide(a: digits, b: digits) -> digits {
    nocap b != 0, "Divisor cannot be zero"
    comeback a / b
}
```

## Standard Library

NoCapLang provides a comprehensive standard library that's automatically available without imports.

### String Functions

```nocap
length(s: text) -> digits
substring(s: text, start: digits, end: digits) -> text
split(s: text, delimiter: text) -> lineup<text>
join(parts: lineup<text>, separator: text) -> text
uppercase(s: text) -> text
lowercase(s: text) -> text
trim(s: text) -> text
contains(s: text, substring: text) -> tf
replace(s: text, old: text, new: text) -> text
```

### Math Functions

```nocap
abs(n: digits) -> digits
sqrt(n: digits) -> digits
pow(base: digits, exp: digits) -> digits
round(n: digits) -> digits
floor(n: digits) -> digits
ceil(n: digits) -> digits
min(a: digits, b: digits) -> digits
max(a: digits, b: digits) -> digits
random() -> digits  tea: returns [0, 1)
```

### Collection Functions

```nocap
map<T, U>(arr: lineup<T>, fn: (T) -> U) -> lineup<U>
filter<T>(arr: lineup<T>, fn: (T) -> tf) -> lineup<T>
reduce<T, U>(arr: lineup<T>, fn: (U, T) -> U, initial: U) -> U
sort<T>(arr: lineup<T>) -> lineup<T>
reverse<T>(arr: lineup<T>) -> lineup<T>
keys<K, V>(obj: bag<K, V>) -> lineup<K>
values<K, V>(obj: bag<K, V>) -> lineup<V>
has<K, V>(obj: bag<K, V>, key: K) -> tf
```

### File I/O Functions

```nocap
read_file(path: text) -> text
write_file(path: text, content: text) -> void
append_file(path: text, content: text) -> void
file_exists(path: text) -> tf
delete_file(path: text) -> void
list_directory(path: text) -> lineup<text>
```

## Best Practices

1. **Use type annotations** for better error detection
2. **Use meaningful variable names** even with slang syntax
3. **Handle errors** with try-catch blocks
4. **Use assertions** to validate assumptions
5. **Comment your code** to explain complex logic
6. **Break code into functions** for reusability
7. **Use classes** for related data and behavior
8. **Leverage the standard library** instead of reimplementing

## Common Patterns

### Input Validation

```nocap
lowkey validateAge(age: digits) -> tf {
    nocap age >= 0, "Age cannot be negative"
    nocap age <= 150, "Age must be realistic"
    comeback real
}
```

### Error Handling Pattern

```nocap
tryna {
    tea: risky operation
} oops {
    tea: handle error
    comeback ghost
} nomatter {
    tea: cleanup
}
```

### Builder Pattern

```nocap
vibe UserBuilder {
    fr name: text
    fr age: digits
    fr email: text
    
    lowkey setName(n: text) -> UserBuilder {
        self.name = n
        comeback self
    }
    
    lowkey setAge(a: digits) -> UserBuilder {
        self.age = a
        comeback self
    }
    
    lowkey build() -> User {
        comeback User(self.name, self.age, self.email)
    }
}
```

## Compilation Targets

NoCapLang compiles to C++ or Java:

```bash
tea: Compile to C++ (default)
nocap program.nocap

tea: Compile to Java
nocap --target java program.nocap
```

Generated code maintains the same semantics as the NoCapLang source.
