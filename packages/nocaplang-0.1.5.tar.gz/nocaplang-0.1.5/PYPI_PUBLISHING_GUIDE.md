# PyPI Publishing Guide for NoCapLang

This guide will walk you through publishing NoCapLang to the Python Package Index (PyPI), allowing users to install it with `pip install nocaplang`.

## Prerequisites

Before you begin, make sure you have:
- Python 3.8 or higher installed
- A PyPI account (create one at https://pypi.org/account/register/)
- A TestPyPI account for testing (create one at https://test.pypi.org/account/register/)

## Step 1: Install Required Tools

Install the tools needed to build and upload your package:

```bash
pip install --upgrade build twine
```

- `build`: Creates distribution packages
- `twine`: Securely uploads packages to PyPI

## Step 2: Prepare Your Package

### 2.1 Verify setup.py

Your `setup.py` is already configured with:
- Package metadata (name, version, description)
- Long description from README.md
- Author information
- Dependencies
- Entry points for the `nocap` command
- Classifiers for PyPI categorization

### 2.2 Create/Update LICENSE File

If you don't have a LICENSE file yet, create one. Since setup.py specifies MIT license, create a `LICENSE` file:

```bash
# Create LICENSE file with MIT license
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2025 NoCapLang Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF
```

### 2.3 Create MANIFEST.in (Optional)

If you want to include additional files in your distribution (like examples, docs), create a `MANIFEST.in` file:

```bash
cat > MANIFEST.in << 'EOF'
include README.md
include LICENSE
recursive-include examples *.nocap
recursive-include docs *.md
EOF
```

## Step 3: Build Your Package

From the root directory of your project:

```bash
# Clean previous builds (if any)
rm -rf dist/ build/ *.egg-info

# Build the package
python -m build
```

This creates two files in the `dist/` directory:
- `nocaplang-0.1.0.tar.gz` (source distribution)
- `nocaplang-0.1.0-py3-none-any.whl` (wheel distribution)

## Step 4: Test on TestPyPI (Recommended)

Before publishing to the real PyPI, test on TestPyPI first.

### 4.1 Create TestPyPI Account

1. Go to https://test.pypi.org/account/register/
2. Create an account and verify your email

### 4.2 Create API Token for TestPyPI

1. Go to https://test.pypi.org/manage/account/token/
2. Click "Add API token"
3. Give it a name (e.g., "nocaplang-upload")
4. Set scope to "Entire account" (or specific project after first upload)
5. Copy the token (starts with `pypi-`)
6. Save it securely - you won't see it again!

### 4.3 Upload to TestPyPI

```bash
python -m twine upload --repository testpypi dist/*
```

When prompted:
- Username: `__token__`
- Password: (paste your TestPyPI API token)

### 4.4 Test Installation from TestPyPI

```bash
# Create a test virtual environment
python -m venv test_env
source test_env/bin/activate  # On Windows: test_env\Scripts\activate

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ nocaplang

# Test the installation
nocap --version
nocap --help

# Test the REPL
nocap --repl

# Deactivate and remove test environment
deactivate
rm -rf test_env
```

Note: We use `--extra-index-url https://pypi.org/simple/` to allow pip to install dependencies (like `hypothesis`) from the real PyPI.

## Step 5: Publish to Real PyPI

Once you've tested on TestPyPI and everything works:

### 5.1 Create PyPI Account

1. Go to https://pypi.org/account/register/
2. Create an account and verify your email

### 5.2 Create API Token for PyPI

1. Go to https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Give it a name (e.g., "nocaplang-upload")
4. Set scope to "Entire account" (or specific project after first upload)
5. Copy the token (starts with `pypi-`)
6. Save it securely!

### 5.3 Upload to PyPI

```bash
python -m twine upload dist/*
```

When prompted:
- Username: `__token__`
- Password: (paste your PyPI API token)

### 5.4 Verify Publication

1. Visit https://pypi.org/project/nocaplang/
2. Check that all information displays correctly
3. Verify the README renders properly

## Step 6: Test Real Installation

```bash
# Install from PyPI
pip install nocaplang

# Test it works
nocap --version
nocap --help
```

## Step 7: Users Can Now Install NoCapLang!

Anyone can now install NoCapLang with:

```bash
pip install nocaplang
```

## Updating Your Package

When you release a new version:

### 1. Update Version Number

Edit `setup.py` and increment the version:
```python
version="0.1.1",  # or 0.2.0, 1.0.0, etc.
```

### 2. Update CHANGELOG (Optional but Recommended)

Document what changed in this version.

### 3. Rebuild and Upload

```bash
# Clean old builds
rm -rf dist/ build/ *.egg-info

# Build new version
python -m build

# Upload to PyPI
python -m twine upload dist/*
```

## Best Practices

### Version Numbering (Semantic Versioning)

- `MAJOR.MINOR.PATCH` (e.g., 1.2.3)
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

### Security

- **Never commit API tokens** to version control
- Use `.pypirc` file for credentials (optional):

```bash
cat > ~/.pypirc << 'EOF'
[pypi]
username = __token__
password = pypi-YOUR_TOKEN_HERE

[testpypi]
username = __token__
password = pypi-YOUR_TESTPYPI_TOKEN_HERE
EOF

chmod 600 ~/.pypirc
```

Then you can upload without entering credentials:
```bash
python -m twine upload dist/*
```

### Testing Before Release

Always:
1. Run all tests: `pytest python/tests/`
2. Test on TestPyPI first
3. Test installation in a clean virtual environment
4. Verify the `nocap` command works

## Troubleshooting

### "File already exists" Error

PyPI doesn't allow re-uploading the same version. You must:
1. Increment the version number in `setup.py`
2. Rebuild: `python -m build`
3. Upload again

### "Invalid distribution" Error

Make sure:
- `README.md` exists and is readable
- `setup.py` has no syntax errors
- All required files are present

### Import Errors After Installation

Check that:
- Package structure is correct (`python/nocaplang/`)
- `__init__.py` files exist in all package directories
- Dependencies are listed in `install_requires`

### Command Not Found: `nocap`

After installation, if `nocap` command isn't found:
- Make sure Python's scripts directory is in your PATH
- Try: `python -m nocaplang.cli.main` instead
- Reinstall: `pip install --force-reinstall nocaplang`

## Additional Resources

- PyPI Help: https://pypi.org/help/
- Python Packaging Guide: https://packaging.python.org/
- Twine Documentation: https://twine.readthedocs.io/
- TestPyPI: https://test.pypi.org/

## Quick Reference Commands

```bash
# Install tools
pip install --upgrade build twine

# Build package
python -m build

# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Upload to PyPI
python -m twine upload dist/*

# Test installation
pip install nocaplang

# Verify
nocap --version
```

---

**Congratulations!** Once published, users worldwide can install NoCapLang with a simple `pip install nocaplang`! 🎉
