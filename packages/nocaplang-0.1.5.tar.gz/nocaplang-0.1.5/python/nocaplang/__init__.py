"""NoCapLang - A Gen Z slang-based programming language."""

__version__ = "0.1.0"
