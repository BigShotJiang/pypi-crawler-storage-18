import logging
from rich.logging import RichHandler

def setup_default_logger(level=logging.INFO):
    root = logging.getLogger()
    if not root.hasHandlers():
        handler = RichHandler(show_path=False, rich_tracebacks=True)
        logging.basicConfig(level=level, handlers=[handler], format="%(message)s")

    return root
