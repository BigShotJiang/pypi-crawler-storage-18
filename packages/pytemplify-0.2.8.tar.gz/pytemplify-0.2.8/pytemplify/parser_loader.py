"""Module to load the specified parser."""

import logging
import sys
from importlib import metadata
from typing import Any, Dict, List, Optional

from pytemplify.base_classes import BaseParserClass

logger = logging.getLogger(__name__)


def load_parser(parser_name: str) -> BaseParserClass:
    """Load the specified parser."""
    try:
        entry_points = metadata.entry_points()
        parser_entries: List[metadata.EntryPoint] = []
        if hasattr(entry_points, "select"):
            parser_entries = list(entry_points.select(group="pytemplify.parsers"))
        elif isinstance(entry_points, dict):
            if "pytemplify.parsers" in entry_points:
                parser_entries = list(entry_points["pytemplify.parsers"])
            else:
                raw_entry: Optional[Any] = entry_points.get(parser_name)
                if raw_entry is None:
                    parser_entries = []
                elif isinstance(raw_entry, list):
                    parser_entries = raw_entry
                elif isinstance(raw_entry, metadata.EntryPoint) or hasattr(raw_entry, "load"):
                    parser = raw_entry.load()
                    if issubclass(parser, BaseParserClass):
                        return parser()
                    logger.error("Parser '%s' is not a subclass of BaseParserClass.", parser_name)
                    sys.exit(1)
                else:
                    parser_entries = []
        else:
            parser_entries = list(entry_points.get("pytemplify.parsers", []))

        parser_map: Dict[str, metadata.EntryPoint] = {entry.name: entry for entry in parser_entries}
        parser = parser_map[parser_name].load()
        if issubclass(parser, BaseParserClass):
            return parser()
        logger.error("Parser '%s' is not a subclass of BaseParserClass.", parser_name)
        sys.exit(1)
    except KeyError:
        logger.error("Parser '%s' not found.", parser_name)
        sys.exit(1)
    except (ImportError, AttributeError) as e:
        logger.error("Failed to load parser '%s': %s", parser_name, e)
        sys.exit(1)
