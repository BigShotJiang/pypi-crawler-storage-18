"""
Skill Installer

Installs pytemplify skills for various AI coding assistants.

Skills themselves are agent-agnostic and follow the agentskills.io standard.
This installer handles agent-specific deployment (config files, directory locations, etc.).

Supported agents:
- Claude Code (claude)
- GitHub Copilot (copilot)
- Cursor (cursor)
- Windsurf (windsurf)
- Generic shell aliases (generic)
"""

import json
import shutil
from pathlib import Path
from typing import List, Optional

from .registry import SkillRegistry

# Agent-specific configuration
AGENT_CONFIG = {
    "claude": {
        "name": "Claude Code",
        "config_file": "settings.json",
        "local_dir": ".claude",
        "global_dir": ".claude",
        "method": "json_config",
    },
    "copilot": {
        "name": "GitHub Copilot",
        "skills_dir": ".github/skills",
        "method": "copy_skills",
    },
    "cursor": {
        "name": "Cursor",
        "skills_dir": ".github/skills",
        "method": "copy_skills",
    },
    "windsurf": {
        "name": "Windsurf",
        "skills_dir": ".github/skills",
        "method": "copy_skills",
    },
    "codeium": {
        "name": "Codeium",
        "skills_dir": ".github/skills",
        "method": "copy_skills",
    },
    "generic": {
        "name": "Generic Shell",
        "method": "shell_aliases",
    },
}


class SkillInstaller:
    """Installer for agent skills.

    Skills are agent-agnostic. This installer adapts them for specific agents.
    """

    def __init__(self, registry: Optional[SkillRegistry] = None):
        """Initialize skill installer.

        Args:
            registry: SkillRegistry instance (creates new one if not provided)
        """
        self.registry = registry or SkillRegistry()

    def install_for_claude(self, skills: Optional[List[str]] = None, global_install: bool = False) -> bool:
        """Install skills for Claude Code.

        Args:
            skills: List of skill names to install (None = all)
            global_install: Install globally (~/.claude/) vs locally (.claude/)

        Returns:
            True if successful
        """
        if skills is None:
            skills = list(self.registry)

        # Determine config path
        if global_install:
            config_dir = Path.home() / ".claude"
        else:
            config_dir = Path.cwd() / ".claude"

        config_dir.mkdir(parents=True, exist_ok=True)
        config_file = config_dir / "settings.json"

        # Load existing config or create new
        if config_file.exists():
            with open(config_file) as f:
                config = json.load(f)
        else:
            config = {}

        # Ensure skills section exists
        if "skills" not in config:
            config["skills"] = {}

        # Add skills
        for skill_name in skills:
            skill = self.registry.get_skill(skill_name)
            if not skill:
                print(f"Warning: Skill '{skill_name}' not found, skipping")
                continue

            # Add skill entry
            config["skills"][skill_name] = {
                "description": skill.description,
                "command": f"pytemplify-{skill_name}",
            }

        # Write config
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)

        print(f"✓ Installed {len(skills)} skills for Claude Code")
        print(f"  Config: {config_file}")

        return True

    def install_for_copilot(self, skills: Optional[List[str]] = None, target_dir: Optional[Path] = None) -> bool:
        """Install skills for GitHub Copilot / VSCode.

        Args:
            skills: List of skill names to install (None = all)
            target_dir: Target directory (default: .github/skills/)

        Returns:
            True if successful
        """
        if skills is None:
            skills = list(self.registry)

        # Determine target directory
        if target_dir is None:
            target_dir = Path.cwd() / ".github" / "skills"

        # Check if we're in the pytemplify repo itself
        source_dir = self.registry.skills_dir

        # If target and source are different, copy skills
        if target_dir.resolve() != source_dir.resolve():
            target_dir.mkdir(parents=True, exist_ok=True)

            for skill_name in skills:
                skill_path = self.registry.get_skill_path(skill_name)
                if not skill_path:
                    print(f"Warning: Skill '{skill_name}' not found, skipping")
                    continue

                target_skill_dir = target_dir / skill_name

                # Copy skill directory
                if target_skill_dir.exists():
                    shutil.rmtree(target_skill_dir)

                shutil.copytree(skill_path, target_skill_dir)

            print(f"✓ Copied {len(skills)} skills for GitHub Copilot")
            print(f"  Location: {target_dir}")
        else:
            print("✓ Skills already available for GitHub Copilot")
            print(f"  Location: {target_dir}")

        return True

    def install_for_generic(self, skills: Optional[List[str]] = None) -> bool:
        """Install skills as shell aliases/functions.

        Args:
            skills: List of skill names to install (None = all)

        Returns:
            True if successful
        """
        if skills is None:
            skills = list(self.registry)

        # Generate shell aliases
        aliases = []
        for skill_name in skills:
            skill = self.registry.get_skill(skill_name)
            if not skill:
                continue

            command = skill_name.replace("-", "_")
            aliases.append(f"alias pt-{skill_name}='pytemplify-{skill_name}'")
            aliases.append(f"alias {command}='pytemplify-{skill_name}'")

        # Print instructions
        print("✓ Generated shell aliases")
        print("\nAdd these to your ~/.bashrc or ~/.zshrc:\n")
        print("\n".join(aliases))
        print("\nOr run this command:")
        print(f"  echo '{chr(10).join(aliases)}' >> ~/.bashrc")

        return True

    def auto_detect_agent(self) -> Optional[str]:
        """Auto-detect which AI agent is being used.

        Returns:
            Agent name ('claude', 'copilot', 'cursor', 'windsurf', 'codeium') or None
        """
        # Check for Claude Code
        claude_dir = Path.home() / ".claude"
        if claude_dir.exists():
            return "claude"

        # Check for Cursor
        cursor_dir = Path.home() / ".cursor"
        if cursor_dir.exists():
            return "cursor"

        # Check for Windsurf
        windsurf_dir = Path.home() / ".windsurf"
        if windsurf_dir.exists():
            return "windsurf"

        # Check for Codeium
        codeium_dir = Path.home() / ".codeium"
        if codeium_dir.exists():
            return "codeium"

        # Check for VSCode/Copilot (check last as it's most common)
        vscode_dir = Path.home() / ".vscode"
        if vscode_dir.exists():
            return "copilot"

        return None

    def install(self, agent: str, skills: Optional[List[str]] = None, **kwargs) -> bool:
        """Install skills for specified agent.

        Skills are agent-agnostic. This method adapts them for specific agents.

        Args:
            agent: Agent type ('claude', 'copilot', 'cursor', 'windsurf', 'codeium', 'generic')
            skills: List of skill names to install (None = all)
            **kwargs: Additional options passed to specific installer

        Returns:
            True if successful
        """
        if agent not in AGENT_CONFIG:
            raise ValueError(f"Unknown agent type: {agent}. Supported: {', '.join(AGENT_CONFIG.keys())}")

        if agent == "claude":
            return self.install_for_claude(skills, **kwargs)
        elif agent in ("copilot", "cursor", "vscode", "windsurf", "codeium"):
            # All these agents use the .github/skills/ directory
            return self.install_for_copilot(skills, **kwargs)
        elif agent == "generic":
            return self.install_for_generic(skills)
        else:
            raise ValueError(f"Unknown agent type: {agent}")

    def get_installed_skills(self, agent: str) -> List[str]:
        """Get list of installed skills for an agent.

        Args:
            agent: Agent type

        Returns:
            List of installed skill names
        """
        if agent == "claude":
            config_file = Path.home() / ".claude" / "settings.json"
            if not config_file.exists():
                return []

            with open(config_file) as f:
                config = json.load(f)

            return list(config.get("skills", {}).keys())

        elif agent in ("copilot", "cursor", "vscode"):
            skills_dir = Path.cwd() / ".github" / "skills"
            if not skills_dir.exists():
                return []

            return [d.name for d in skills_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists()]

        return []

    def uninstall(self, agent: str, skills: List[str]) -> bool:
        """Uninstall skills for specified agent.

        Args:
            agent: Agent type
            skills: List of skill names to uninstall

        Returns:
            True if successful
        """
        if agent == "claude":
            config_file = Path.home() / ".claude" / "settings.json"
            if not config_file.exists():
                return False

            with open(config_file) as f:
                config = json.load(f)

            removed = 0
            for skill_name in skills:
                if skill_name in config.get("skills", {}):
                    del config["skills"][skill_name]
                    removed += 1

            with open(config_file, "w") as f:
                json.dump(config, f, indent=2)

            print(f"✓ Uninstalled {removed} skills from Claude Code")
            return True

        elif agent in ("copilot", "cursor", "vscode"):
            skills_dir = Path.cwd() / ".github" / "skills"
            if not skills_dir.exists():
                return False

            removed = 0
            for skill_name in skills:
                skill_dir = skills_dir / skill_name
                if skill_dir.exists():
                    shutil.rmtree(skill_dir)
                    removed += 1

            print(f"✓ Uninstalled {removed} skills from {agent}")
            return True

        return False


def main():
    """CLI entry point for skill installer."""
    import click

    @click.command()
    @click.option(
        "--agent",
        type=click.Choice(["claude", "copilot", "cursor", "windsurf", "codeium", "generic", "auto"]),
        default="auto",
        help="AI agent type to install for",
    )
    @click.option("--global", "global_install", is_flag=True, help="Install globally (Claude only)")
    @click.option("--list", "list_skills", is_flag=True, help="List available skills")
    @click.option("--list-agents", "list_agents", is_flag=True, help="List supported agents")
    @click.option("--validate", "validate", is_flag=True, help="Validate all skills")
    @click.argument("skills", nargs=-1)
    def install_skills(
        agent: str,
        global_install: bool,
        list_skills: bool,
        list_agents: bool,
        validate: bool,
        skills: tuple,
    ):
        """Install pytemplify agent skills.

        Skills are agent-agnostic and follow the agentskills.io standard.
        This installer adapts them for your specific AI coding assistant.
        """
        registry = SkillRegistry()
        installer = SkillInstaller(registry)

        # List supported agents
        if list_agents:
            click.echo("\n🤖 Supported AI Agents:\n")
            for agent_id, config in AGENT_CONFIG.items():
                click.echo(f"  • {config['name']} ({agent_id})")
            click.echo("\n💡 Skills are agent-agnostic and work with all agents")
            click.echo("   The installer handles agent-specific deployment\n")
            return

        # List skills
        if list_skills:
            click.echo("\n📚 Available Skills:\n")
            for skill in registry.list_skills():
                click.echo(f"  • {skill.name}: {skill.description[:60]}...")
            click.echo(f"\nTotal: {len(registry)} skills")
            click.echo("\n💡 All skills are agent-agnostic and work across AI assistants\n")
            return

        # Validate skills
        if validate:
            click.echo("\nValidating skills...\n")
            all_valid = True
            for skill_name in registry:
                errors = registry.validate_skill(skill_name)
                if errors:
                    click.echo(f"✗ {skill_name}:")
                    for error in errors:
                        click.echo(f"    {error}")
                    all_valid = False
                else:
                    click.echo(f"✓ {skill_name}")

            if all_valid:
                click.echo(f"\n✓ All {len(registry)} skills are valid\n")
            else:
                click.echo("\n✗ Some skills have validation errors\n")
            return

        # Auto-detect agent
        if agent == "auto":
            detected_agent = installer.auto_detect_agent()
            if detected_agent:
                agent = detected_agent
                agent_name = AGENT_CONFIG[agent]["name"]
                click.echo(f"🔍 Auto-detected: {agent_name} ({agent})")
            else:
                click.echo("❌ Could not auto-detect agent. Please specify with --agent")
                click.echo("\nSupported agents:")
                for agent_id, config in AGENT_CONFIG.items():
                    if agent_id != "generic":
                        click.echo(f"  • {config['name']}: --agent {agent_id}")
                return

        # Install skills
        skill_list = list(skills) if skills else None

        click.echo(f"\n📦 Installing skills for {AGENT_CONFIG[agent]['name']}...")

        if agent == "claude":
            installer.install_for_claude(skill_list, global_install=global_install)
        elif agent in ("copilot", "cursor", "windsurf", "codeium"):
            installer.install_for_copilot(skill_list)
        elif agent == "generic":
            installer.install_for_generic(skill_list)

    install_skills()


if __name__ == "__main__":
    main()
