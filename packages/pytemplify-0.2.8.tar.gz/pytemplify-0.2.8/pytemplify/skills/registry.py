"""
Skill Registry

Discovers and manages pytemplify agent skills.
"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class SkillMetadata:
    """Metadata for a skill."""

    name: str
    description: str
    compatibility: Optional[str] = None
    license: Optional[str] = None
    path: Optional[Path] = None

    @classmethod
    def from_skill_md(cls, skill_path: Path) -> "SkillMetadata":
        """Parse SKILL.md file and extract metadata.

        Args:
            skill_path: Path to SKILL.md file

        Returns:
            SkillMetadata instance
        """
        content = skill_path.read_text(encoding="utf-8")

        # Extract YAML frontmatter
        frontmatter_match = re.match(r"---\n(.*?)\n---", content, re.DOTALL)

        if not frontmatter_match:
            raise ValueError(f"Invalid SKILL.md format in {skill_path}")

        frontmatter = frontmatter_match.group(1)
        metadata = {}

        # Parse YAML-like frontmatter (simple key: value pairs)
        for line in frontmatter.split("\n"):
            if ":" in line:
                key, value = line.split(":", 1)
                metadata[key.strip()] = value.strip().strip('"').strip("'")

        return cls(
            name=metadata.get("name", skill_path.parent.name),
            description=metadata.get("description", ""),
            compatibility=metadata.get("compatibility"),
            license=metadata.get("license"),
            path=skill_path.parent,
        )


class SkillRegistry:
    """Registry for discovering and managing skills."""

    def __init__(self, skills_dir: Optional[Path] = None):
        """Initialize skill registry.

        Args:
            skills_dir: Path to skills directory (default: .github/skills/)
        """
        if skills_dir is None:
            from . import get_skill_path

            skills_dir = get_skill_path()

        self.skills_dir = skills_dir
        self._skills: Dict[str, SkillMetadata] = {}
        self._discover_skills()

    def _discover_skills(self):
        """Discover all skills in the skills directory."""
        if not self.skills_dir.exists():
            return

        for skill_dir in self.skills_dir.iterdir():
            if not skill_dir.is_dir():
                continue

            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue

            try:
                metadata = SkillMetadata.from_skill_md(skill_md)
                self._skills[metadata.name] = metadata
            except Exception as e:
                print(f"Warning: Failed to load skill {skill_dir.name}: {e}")

    def get_skill(self, name: str) -> Optional[SkillMetadata]:
        """Get skill metadata by name.

        Args:
            name: Skill name

        Returns:
            SkillMetadata or None if not found
        """
        return self._skills.get(name)

    def list_skills(self, category: Optional[str] = None) -> List[SkillMetadata]:
        """List all skills.

        Args:
            category: Optional category filter (not implemented yet)

        Returns:
            List of SkillMetadata instances
        """
        return list(self._skills.values())

    def has_skill(self, name: str) -> bool:
        """Check if a skill exists.

        Args:
            name: Skill name

        Returns:
            True if skill exists
        """
        return name in self._skills

    def get_skill_path(self, name: str) -> Optional[Path]:
        """Get the file system path for a skill.

        Args:
            name: Skill name

        Returns:
            Path to skill directory or None if not found
        """
        skill = self.get_skill(name)
        return skill.path if skill else None

    def validate_skill(self, name: str) -> List[str]:
        """Validate a skill's structure and metadata.

        Args:
            name: Skill name

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if not self.has_skill(name):
            errors.append(f"Skill '{name}' not found")
            return errors

        skill = self.get_skill(name)
        assert skill is not None  # has_skill check guarantees this

        # Check required fields
        if not skill.name:
            errors.append("Missing required field: name")

        if not skill.description:
            errors.append("Missing required field: description")

        # Check name format
        if skill.name:
            if not re.match(r"^[a-z0-9-]+$", skill.name):
                errors.append(
                    f"Invalid name format '{skill.name}': must contain only lowercase letters, numbers, and hyphens"
                )

            if skill.name.startswith("-") or skill.name.endswith("-"):
                errors.append(f"Invalid name '{skill.name}': cannot start or end with hyphen")

            if "--" in skill.name:
                errors.append(f"Invalid name '{skill.name}': cannot contain consecutive hyphens")

            if len(skill.name) > 64:
                errors.append(f"Invalid name '{skill.name}': exceeds 64 characters")

        # Check description length
        if skill.description and len(skill.description) > 1024:
            errors.append(f"Description exceeds 1024 characters ({len(skill.description)})")

        # Check SKILL.md exists
        if skill.path:
            skill_md = skill.path / "SKILL.md"
            if not skill_md.exists():
                errors.append("SKILL.md file not found")

        return errors

    def __len__(self) -> int:
        """Return number of registered skills."""
        return len(self._skills)

    def __contains__(self, name: str) -> bool:
        """Check if skill is registered."""
        return name in self._skills

    def __iter__(self):
        """Iterate over skill names."""
        return iter(self._skills.keys())
