"""
PyTemplify Agent Skills

This module provides utilities for managing and installing pytemplify agent skills
for various AI coding assistants (Claude Code, GitHub Copilot, etc.).
"""

from pathlib import Path
from typing import Dict, List, Optional

__all__ = ["SkillRegistry", "SkillInstaller", "list_skills", "get_skill_path"]


def get_skill_path() -> Path:
    """Get the path to the .github/skills directory."""
    # Navigate up from pytemplify/skills/ to project root
    module_dir = Path(__file__).parent
    project_root = module_dir.parent.parent
    skills_dir = project_root / ".github" / "skills"

    if not skills_dir.exists():
        raise FileNotFoundError(
            f"Skills directory not found at {skills_dir}. Ensure pytemplify is properly installed with skills."
        )

    return skills_dir


def list_skills() -> List[str]:
    """List all available skills.

    Returns:
        List of skill names
    """
    skills_dir = get_skill_path()
    skills = []

    for skill_dir in skills_dir.iterdir():
        if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
            skills.append(skill_dir.name)

    return sorted(skills)


def get_skill_info(skill_name: str) -> Optional[Dict[str, str]]:
    """Get information about a skill.

    Args:
        skill_name: Name of the skill

    Returns:
        Dictionary with skill metadata (name, description, etc.) or None if not found
    """
    skills_dir = get_skill_path()
    skill_path = skills_dir / skill_name / "SKILL.md"

    if not skill_path.exists():
        return None

    import re

    # Parse SKILL.md frontmatter
    content = skill_path.read_text()
    frontmatter_match = re.match(r"---\n(.*?)\n---", content, re.DOTALL)

    if not frontmatter_match:
        return None

    frontmatter = frontmatter_match.group(1)
    info = {}

    for line in frontmatter.split("\n"):
        if ":" in line:
            key, value = line.split(":", 1)
            info[key.strip()] = value.strip().strip('"')

    return info
