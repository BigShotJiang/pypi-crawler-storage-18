"""Helper utilities for validation workflows."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional

from pytemplify.validation.base import ValidatorConfig, ValidatorType
from pytemplify.validation.registry import create_validators_from_config, get_registry


def list_gtest_targets(
    output_dir: Path,
    patterns: Optional[List[str]] = None,
    options: Optional[Dict[str, Any]] = None,
) -> List[Path]:
    """Discover Google Test targets in an output directory.

    Args:
        output_dir: Directory to scan for test files
        patterns: Optional list of glob patterns for test discovery
        options: Optional validator options for gtest discovery

    Returns:
        List of discovered test file paths
    """
    config = ValidatorConfig(
        name="GTest Discovery",
        type=ValidatorType.GTEST,
        enabled=True,
        patterns=patterns or [],
        options=options or {},
    )
    validator = get_registry().create_validator(config)
    return validator.discover(output_dir)


def create_validators_with_overrides(
    validation_config: Dict[str, Any],
    overrides: Dict[str, Dict[str, Any]],
) -> List:
    """Create validators from config, applying overrides by name or type.

    Overrides may target validator name or validator type (e.g., "gtest").
    Name overrides take precedence over type overrides.
    """
    config_copy = deepcopy(validation_config)
    validators = config_copy.get("validators", [])

    for validator in validators:
        if not isinstance(validator, dict):
            continue

        name = validator.get("name")
        vtype = validator.get("type")

        override = {}
        if vtype in overrides:
            override.update(overrides.get(vtype, {}))
        if name in overrides:
            override.update(overrides.get(name, {}))

        if "patterns" in override:
            validator["patterns"] = override["patterns"]
        if "options" in override:
            validator_options = validator.get("options", {})
            validator_options.update(override["options"])
            validator["options"] = validator_options
        if "enabled" in override:
            validator["enabled"] = override["enabled"]

    return create_validators_from_config(config_copy)
