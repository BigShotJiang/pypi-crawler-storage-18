"""
NeuralDLP Python SDK

Official Python client for the NeuralDLP API.
Neural Data Loss Prevention for AI.

Usage:
    from neuraldlp import NeuralDLP
    
    client = NeuralDLP(api_key="your_api_key")
    result = client.inspect_input("sensitive data here")
"""

from .client import NeuralDLP
from .models import (
    InspectionResult,
    TokenizationResult,
    RehydrationResult,
    Entity,
    Threat,
    PolicyMatch
)
from .exceptions import (
    NeuralDLPError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NotFoundError
)

__version__ = "1.0.0"
__all__ = [
    "NeuralDLP",
    "InspectionResult",
    "TokenizationResult",
    "RehydrationResult",
    "Entity",
    "Threat",
    "PolicyMatch",
    "NeuralDLPError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
]
