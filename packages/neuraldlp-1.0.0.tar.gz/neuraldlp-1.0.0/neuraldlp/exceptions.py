"""
Custom Exceptions

NeuralDLP SDK exceptions.
"""


class NeuralDLPError(Exception):
    """Base exception for NeuralDLP SDK"""
    pass


class AuthenticationError(NeuralDLPError):
    """Authentication failed (invalid API key)"""
    pass


class RateLimitError(NeuralDLPError):
    """Rate limit exceeded"""
    pass


class ValidationError(NeuralDLPError):
    """Request validation failed"""
    pass


class NotFoundError(NeuralDLPError):
    """Resource not found (e.g., mapping expired)"""
    pass
