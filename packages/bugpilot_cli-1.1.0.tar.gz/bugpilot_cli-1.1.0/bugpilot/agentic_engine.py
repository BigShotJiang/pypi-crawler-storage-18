"""
Intelligent Agentic System for BugPilot
Handles autonomous decision-making and command execution
"""

from typing import List, Dict, Tuple, Optional
import json
import re


class AgenticEngine:
    """
    Intelligent agent that analyzes command results and makes decisions
    """
    
    def __init__(self, model, ui, config):
        self.model = model
        self.ui = ui
        self.config = config
        self.task_state = {
            "objective": "",
            "steps_completed": [],
            "findings": [],
            "current_target": "",
            "iteration": 0
        }
    
    def analyze_and_decide(self, command_output: str, previous_command: str, 
                          original_objective: str) -> Tuple[Optional[str], str, bool]:
        """
        Analyzes command output and decides next action
        
        Returns:
            Tuple of (next_command, analysis, is_complete)
        """
        # Build intelligent analysis prompt
        analysis_prompt = self._build_analysis_prompt(
            command_output, previous_command, original_objective
        )
        
        # Get AI analysis
        response = self.model.generate(analysis_prompt)
        
        # Parse response
        next_command, analysis, is_complete = self._parse_ai_response(response)
        
        # Update task state
        self._update_task_state(previous_command, command_output, analysis)
        
        return next_command, analysis, is_complete
    
    def _build_analysis_prompt(self, output: str, cmd: str, objective: str) -> str:
        """Builds intelligent analysis prompt"""
        
        # Truncate output for analysis
        output_truncated = output[:3000] + ('...' if len(output) > 3000 else '')
        
        prompt = f"""You are an elite penetration testing AI agent analyzing command results.

**ORIGINAL OBJECTIVE:** {objective}

**PREVIOUS COMMAND:** {cmd}

**COMMAND OUTPUT:**
{output_truncated}

**YOUR TASK STATE:**
- Objective: {self.task_state['objective']}
- Steps completed: {len(self.task_state['steps_completed'])}
- Target: {self.task_state['current_target']}

**INSTRUCTIONS:**
1. **ANALYZE** the command output thoroughly
2. **EXTRACT** key findings (IPs, ports, vulnerabilities, etc.)
3. **DECIDE** the next logical step based on pentesting methodology
4. **RESPOND** in this EXACT format:

```json
{{
  "analysis": "Brief analysis of what the output shows",
  "findings": ["finding 1", "finding 2", "finding 3"],
  "next_step": "What to do next and why",
  "command": "exact command to run next (or null if complete)",
  "is_complete": false
}}
```

**DECISION RULES:**
- If you found the info needed → set is_complete: true, command: null
- If error occurred → suggest alternative approach
- If scan incomplete → continue with next logical step
- Follow pentesting methodology: Recon → Scanning → Enumeration → Exploitation

**BE SPECIFIC:** Don't suggest the same command twice. Progress forward.
"""
        
        return prompt
    
    def _parse_ai_response(self, response: str) -> Tuple[Optional[str], str, bool]:
        """Parses AI response to extract decision"""
        
        try:
            # Extract JSON from response
            json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group(1))
            else:
                # Try direct JSON parsing
                data = json.loads(response)
            
            analysis = data.get('analysis', 'Analysis unavailable')
            findings = data.get('findings', [])
            next_step = data.get('next_step', '')
            command = data.get('command')
            is_complete = data.get('is_complete', False)
            
            # Build analysis text
            analysis_text = f"**Analysis:** {analysis}\n\n"
            if findings:
                analysis_text += "**Findings:**\n" + "\n".join([f"• {f}" for f in findings]) + "\n\n"
            analysis_text += f"**Next Step:** {next_step}"
            
            return command, analysis_text, is_complete
            
        except Exception as e:
            # Fallback: try to extract command from markdown
            commands = re.findall(r'```(?:bash|shell)?\s*(.*?)\s*```', response, re.DOTALL)
            if commands:
                return commands[0].strip(), response, False
            
            # No command found - might be complete
            if any(phrase in response.lower() for phrase in [
                'complete', 'finished', 'done', 'no further', 'assessment complete'
            ]):
                return None, response, True
            
            return None, response, False
    
    def _update_task_state(self, command: str, output: str, analysis: str):
        """Updates internal task state"""
        self.task_state['steps_completed'].append({
            "command": command,
            "output_length": len(output),
            "iteration": self.task_state['iteration']
        })
        self.task_state['iteration'] += 1
        
        # Extract findings from output (simple approach)
        if 'PORT' in output.upper() or 'OPEN' in output.upper():
            self.task_state['findings'].append(f"Port scan results from iteration {self.task_state['iteration']}")
        if 'VULN' in output.upper() or 'EXPLOIT' in output.upper():
            self.task_state['findings'].append(f"Vulnerability found at iteration {self.task_state['iteration']}")
    
    def get_task_summary(self) -> str:
        """Returns summary of task state"""
        return f"""
**Task Summary:**
- Objective: {self.task_state['objective']}
- Steps Completed: {len(self.task_state['steps_completed'])}
- Findings: {len(self.task_state['findings'])}
- Iterations: {self.task_state['iteration']}
"""
    
    def reset_task_state(self, objective: str, target: str):
        """Resets task state for new objective"""
        self.task_state = {
            "objective": objective,
            "steps_completed": [],
            "findings": [],
            "current_target": target,
            "iteration": 0
        }
