# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.0] - 2025-12-20

### Added
- Initial release
- Multi-LLM Orchestrator integration (GigaChat, YandexGPT)
- LangChain RAG chains with FAISS/OpenSearch vector stores
- Flexible embeddings (Local HuggingFace, GigaChat API, Yandex AI Studio)
- Telegram bot with /start, /mode, /reload_faq commands
- Session management (Redis + memory fallback)
- Config-driven FAQ modes (YAML)
- Health check endpoint for Docker/Kubernetes
- Structured logging (JSON/text formats)
- Prometheus metrics collection (query latency, active users, errors)
- CLI tool for project management

### Week 1 MVP Features
- Production-ready monitoring (health check + metrics)
- Graceful degradation patterns
- Comprehensive error handling
- Async/await architecture

### Fixed
- Environment variable validation for embeddings/vectorstore
- Graceful shutdown for OpenSearch connections
- Router providers type checking

## [0.8.0] - 2025-12-20

### Changed
- Migrated to LangChain 1.x compatibility
- Updated import paths for `create_retrieval_chain` and `create_stuff_documents_chain`
- Updated dependency: `langchain>=1.0`

### Technical Details
- No breaking changes for end users
- Backward compatible with existing configurations
- FAISS/OpenSearch indices remain unchanged

## [0.8.1] - 2025-12-20

### Fixed
- Fixed LangChain 1.x imports: using `langchain-classic` package for `create_retrieval_chain` and `create_stuff_documents_chain`
- Added `langchain-classic>=1.0,<2.0` dependency

### Technical Details
- In LangChain 1.0.x, retrieval chain functions are in separate `langchain-classic` package
- No breaking changes for end users
- Backward compatible with existing configurations

## [Unreleased]

### Planned for 0.9.0
- Docker deployment (Dockerfile, docker-compose.yml)
- CI/CD pipeline (GitHub Actions)
- Unit tests (pytest framework)
- Comprehensive error handling (retry logic, circuit breaker)
- Connection pooling (Redis, OpenSearch)
- Token usage metric (state management)

---

## Version Update Checklist

When releasing a new version:

1. Update `telegram_rag_bot/__init__.py` (`__version__`)
2. Update `pyproject.toml` (`version` field)
3. Update `CHANGELOG.md` (add new version section)
4. Create git tag: `git tag -a v0.X.Y -m "Release v0.X.Y"`
5. Push tag: `git push origin v0.X.Y`
6. Create GitHub Release (GitHub Actions will auto-publish to PyPI)

