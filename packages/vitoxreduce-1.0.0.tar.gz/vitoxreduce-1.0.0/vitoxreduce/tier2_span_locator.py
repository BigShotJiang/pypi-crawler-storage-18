#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tầng 2: Span Tagger (Bộ định vị vùng độc hại)
Sử dụng PhoBERT Token Classification (BIO Tagging) để xác định vị trí các cụm từ độc hại
"""

import os
import json
import logging
import torch
from typing import List, Tuple, Optional, Dict

from .span_locator_inference import SpanLocatorInference

logger = logging.getLogger(__name__)


class SpanTagger:
    """Tầng 2: Span Tagger - PhoBERT Token Classification (BIO Tagging)"""
    
    def __init__(
        self,
        span_locator_model_path: Optional[str] = None,
        device: Optional[str] = None,
        max_length: int = 256,
        span_dictionary_paths: Optional[List[str]] = None
    ):
        """
        Args:
            span_locator_model_path: Đường dẫn đến PhoBERT Token Classification model (bắt buộc)
            device: Device để chạy model (cuda/cpu)
            max_length: Độ dài tối đa của sequence
            span_dictionary_paths: Danh sách đường dẫn đến các file JSONL để tạo từ điển span (tùy chọn)
        """
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.max_length = max_length
        self.span_locator_model = None
        self.span_dictionary: Dict[str, List[Tuple[int, int]]] = {}  # text -> spans_indices (legacy format)
        self.span_texts_set: set = set()  # Set các span text độc hại (format mới)
        
        if span_locator_model_path is None or not os.path.exists(span_locator_model_path):
            raise FileNotFoundError(
                f"Không tìm thấy PhoBERT Span Locator model tại {span_locator_model_path}. "
                f"Vui lòng chỉ định span_locator_model_path hợp lệ."
            )
        
        # Load từ điển span nếu có
        if span_dictionary_paths:
            self._load_span_dictionary(span_dictionary_paths)
        else:
            logger.info("Không có từ điển span, sẽ chỉ sử dụng model")
        
        # Load Span Locator model
        self.span_locator_model_path = span_locator_model_path
        self._load_span_locator_model(span_locator_model_path)
    
    def _load_span_dictionary(self, file_paths: List[str]):
        """
        Load từ điển span từ các file JSONL (đã trích xuất hoặc train/val)
        
        Args:
            file_paths: Danh sách đường dẫn đến các file JSONL
        """
        logger.info(f"Đang load từ điển span từ {len(file_paths)} file(s)...")
        total_loaded = 0
        total_spans_loaded = 0
        
        for file_path in file_paths:
            if not os.path.exists(file_path):
                logger.warning(f"File không tồn tại: {file_path}")
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line_num, line in enumerate(f, 1):
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            item = json.loads(line)
                            
                            # Format mới: {"span": "...", "length": ...}
                            if 'span' in item:
                                span_text = item.get('span', '').strip()
                                # Loại bỏ dấu ngoặc kép ở đầu và cuối nếu có
                                if span_text.startswith('"') and span_text.endswith('"'):
                                    span_text = span_text[1:-1].strip()
                                if span_text:
                                    self.span_texts_set.add(span_text)
                                    total_spans_loaded += 1
                            
                            # Format cũ: {"comment": "...", "unsafe_spans_indices": [...]}
                            elif 'comment' in item:
                                comment = item.get('comment', '').strip()
                                unsafe_spans_indices = item.get('unsafe_spans_indices', [])
                                
                                if not comment:
                                    continue
                                
                                if unsafe_spans_indices:
                                    # Chuyển đổi từ list of lists sang list of tuples
                                    spans_indices = []
                                    for span in unsafe_spans_indices:
                                        if isinstance(span, (list, tuple)) and len(span) == 2:
                                            start, end = int(span[0]), int(span[1])
                                            # Validate span indices
                                            if 0 <= start < end <= len(comment):
                                                spans_indices.append((start, end))
                                    
                                    if spans_indices:
                                        # Lưu vào từ điển (key là comment text)
                                        # Nếu đã có, giữ nguyên (không ghi đè)
                                        if comment not in self.span_dictionary:
                                            self.span_dictionary[comment] = spans_indices
                                            total_loaded += 1
                        except json.JSONDecodeError as e:
                            logger.debug(f"Bỏ qua dòng {line_num} lỗi JSON trong {file_path}: {e}")
                            continue
            except Exception as e:
                logger.warning(f"Lỗi khi load từ điển từ {file_path}: {e}")
                continue
        
        if total_spans_loaded > 0:
            logger.info(f"Đã load {total_spans_loaded} spans vào từ điển span (format mới)")
            # Log một số spans mẫu để debug
            sample_spans = sorted(list(self.span_texts_set))[:10]
            logger.debug(f"Mẫu spans trong từ điển: {sample_spans}")
        if total_loaded > 0:
            logger.info(f"Đã load {total_loaded} entries vào từ điển span (format cũ, tổng {len(self.span_dictionary)} unique texts)")
    
    def _load_span_locator_model(self, model_path: str):
        """Load PhoBERT Span Locator model"""
        try:
            self.span_locator_model = SpanLocatorInference(
                model_path=model_path,
                device=self.device,
                max_length=self.max_length
            )
            logger.info("Span Tagger model đã được load thành công!")
        except Exception as e:
            logger.error(f"Không thể load Span Locator model: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            raise
    
    def locate_spans(self, text: str) -> List[Tuple[int, int]]:
        """
        Xác định spans độc hại trong text
        Ưu tiên sử dụng từ điển span (từ train/val) trước, nếu không có thì mới gọi model
        
        Args:
            text: Câu cần tìm spans
            
        Returns:
            List of (start, end) character indices
        """
        logger.debug(f"[Tier2] Đang tìm spans cho text: '{text[:100]}...'")
        
        # Bước 1: Kiểm tra từ điển span format cũ (text -> spans_indices)
        if text in self.span_dictionary:
            spans = self.span_dictionary[text]
            logger.debug(f"[Tier2] Tìm thấy spans trong từ điển (format cũ) cho text '{text[:50]}...': {len(spans)} spans")
            return spans
        
        # Bước 2: Kiểm tra từ điển span format mới (tìm kiếm substring)
        if self.span_texts_set:
            found_spans = []
            text_lower = text.lower()  # Tìm kiếm không phân biệt hoa thường
            
            # Sắp xếp các span theo độ dài giảm dần để ưu tiên span dài hơn
            sorted_spans = sorted(self.span_texts_set, key=len, reverse=True)
            
            logger.debug(f"[Tier2] Đang tìm kiếm {len(sorted_spans)} spans trong text (từ điển format mới)")
            
            for span_text in sorted_spans:
                span_text_clean = span_text.strip()
                if not span_text_clean:  # Bỏ qua span rỗng
                    continue
                
                span_lower = span_text_clean.lower()
                
                # Tìm tất cả các vị trí xuất hiện của span trong text
                start = 0
                while True:
                    pos = text_lower.find(span_lower, start)
                    if pos == -1:
                        break
                    # Tính end dựa trên độ dài của span_text_clean (đã strip)
                    end = pos + len(span_text_clean)
                    # Validate span indices
                    if 0 <= pos < end <= len(text):
                        # Kiểm tra xem span này có bị overlap với span đã tìm thấy không
                        overlap = False
                        for existing_start, existing_end in found_spans:
                            # Overlap nếu: không phải là (end <= existing_start) và không phải là (pos >= existing_end)
                            if not (end <= existing_start or pos >= existing_end):
                                overlap = True
                                logger.debug(f"Span '{span_text_clean}' tại ({pos}, {end}) bị overlap với span tại ({existing_start}, {existing_end})")
                                break
                        if not overlap:
                            found_spans.append((pos, end))
                            logger.debug(f"Tìm thấy span '{span_text_clean}' tại vị trí ({pos}, {end}) trong text")
                    start = pos + 1
            
            if found_spans:
                # Sắp xếp theo vị trí bắt đầu
                found_spans = sorted(found_spans)
                logger.debug(f"[Tier2] ✓ Tìm thấy {len(found_spans)} spans trong từ điển (format mới) cho text '{text[:50]}...': {found_spans}")
                return found_spans
            else:
                logger.debug(f"[Tier2] Không tìm thấy spans nào trong từ điển (format mới) cho text '{text[:50]}...'")
        
        # Bước 3: Nếu không có trong từ điển, gọi model
        logger.debug(f"[Tier2] Không tìm thấy trong từ điển, đang gọi model để predict spans cho text '{text[:50]}...'")
        if self.span_locator_model is None:
            logger.warning("[Tier2] Span Locator model chưa được load và không tìm thấy trong từ điển")
            return []
        
        try:
            spans = self.span_locator_model.predict_spans(text)
            logger.debug(f"[Tier2] Model predict được {len(spans)} spans cho text '{text[:50]}...': {spans}")
            return spans
        except Exception as e:
            logger.warning(f"[Tier2] Lỗi khi phát hiện spans cho text '{text[:50]}...': {e}")
            return []
    
    def get_span_texts(self, text: str, spans_indices: List[Tuple[int, int]]) -> List[str]:
        """
        Lấy text của các spans từ indices
        
        Args:
            text: Câu gốc
            spans_indices: List of (start, end) character indices
            
        Returns:
            List of span texts
        """
        span_texts = []
        for start, end in spans_indices:
            if 0 <= start < end <= len(text):
                span_texts.append(text[start:end])
        return span_texts

