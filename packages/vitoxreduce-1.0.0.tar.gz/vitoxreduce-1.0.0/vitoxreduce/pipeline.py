#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline chính ViToxReduce - Kiến trúc 3 tầng Streamlined
Tầng 1: Safety Checker (PhoBERT Sequence Classification)
Tầng 2: Span Tagger (PhoBERT Token Classification / BIO Tagging)
Tầng 3: Contextual Rewriter (BARTpho Seq2Seq - Span-guided)
"""

import logging
from typing import Dict, Optional, List, Any
from datetime import datetime
import torch
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False
    tqdm = lambda x, **kwargs: x

from .tier1_toxicity_detector import ToxicityDetector
from .tier2_span_locator import SpanTagger
from .tier3_rewrite_generator import ContextualRewriter

logger = logging.getLogger(__name__)


class ViToxReducePipeline:
    """Pipeline ViToxReduce với kiến trúc 3 tầng Streamlined"""
    
    def __init__(
        self,
        # Tầng 1 config
        toxicity_detector_model_path: Optional[str] = None,
        toxicity_threshold: float = 0.5,
        
        # Tầng 2 config
        span_locator_model_path: Optional[str] = None,
        
        # Tầng 3 config
        rewriter_model_path: Optional[str] = None,
        num_beams: int = 5,
        
        # General config
        device: Optional[str] = None,
    ):
        """
        Khởi tạo pipeline với các config cho từng tầng
        
        Args:
            toxicity_detector_model_path: Path đến PhoBERT classifier cho Tầng 1
            toxicity_threshold: Ngưỡng phân loại unsafe
            span_locator_model_path: Path đến PhoBERT Token Classification model cho Tầng 2
            rewriter_model_path: Path đến BARTpho rewriter model cho Tầng 3 (bắt buộc)
            num_beams: Số beams cho beam search trong Tầng 3
            device: Device để chạy models
        """
        if rewriter_model_path is None:
            raise ValueError("rewriter_model_path là tham số bắt buộc và không được để None")
        
        # Xác định device
        if device:
            self.device = device.lower()
            if self.device not in ["cuda", "cpu"]:
                logger.warning(f"Device '{device}' không hợp lệ, sử dụng 'cpu'")
                self.device = "cpu"
        else:
            # Tự động chọn device
            if torch.cuda.is_available():
                self.device = "cuda"
            else:
                self.device = "cpu"
        
        # Log thông tin device
        logger.info("=" * 60)
        logger.info("KHỞI TẠO PIPELINE VITOXREDUCE (3 TẦNG)")
        logger.info("=" * 60)
        logger.info(f"Device đang sử dụng: {self.device.upper()}")
        if self.device == "cuda":
            if torch.cuda.is_available():
                logger.info(f"GPU: {torch.cuda.get_device_name(0)}")
                logger.info(f"CUDA Version: {torch.version.cuda}")
                logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
            else:
                logger.warning("CUDA không khả dụng nhưng device được set là 'cuda', chuyển sang CPU")
                self.device = "cpu"
        else:
            logger.info("Sử dụng CPU (có thể chậm hơn GPU)")
        
        # Tầng 1: Safety Checker
        logger.info("Đang khởi tạo Tầng 1: Safety Checker (PhoBERT Sequence Classification)...")
        self.tier1 = ToxicityDetector(
            model_path=toxicity_detector_model_path,
            device=self.device,
            threshold=toxicity_threshold
        )
        
        # Tầng 2: Span Tagger
        logger.info("Đang khởi tạo Tầng 2: Span Tagger (PhoBERT Token Classification)...")
        self.tier2 = SpanTagger(
            span_locator_model_path=span_locator_model_path,
            device=self.device
        )
        
        # Tầng 3: Contextual Rewriter
        logger.info("Đang khởi tạo Tầng 3: Contextual Rewriter (BARTpho Seq2Seq)...")
        self.tier3 = ContextualRewriter(
            model_path=rewriter_model_path,
            device=self.device,
            num_beams=num_beams
        )
        
        logger.info("=" * 60)
        logger.info("PIPELINE ĐÃ SẴN SÀNG!")
        logger.info("=" * 60)
    
    def process(self, text: str, verbose: bool = False) -> Dict[str, Any]:
        """
        Xử lý một câu qua pipeline 3 tầng: Check → Tag → Rewrite
        
        Args:
            text: Câu cần xử lý
            verbose: In chi tiết quá trình xử lý
            
        Returns:
            Dict chứa kết quả với các keys:
                - original: Câu gốc
                - is_safe: True nếu safe, False nếu unsafe
                - toxicity_score: Điểm độc hại của câu gốc (0.0-1.0)
                - spans: Danh sách spans tìm được (character indices)
                - span_texts: Danh sách text của spans
                - rewritten: Câu đã được viết lại (hoặc câu gốc nếu safe)
                - rewritten_is_safe: True nếu câu đã rewrite là safe, False nếu vẫn unsafe, None nếu chưa check
                - rewritten_toxicity_score: Điểm độc hại của câu đã rewrite (0.0-1.0), None nếu chưa check
                - processing_time: Thời gian xử lý (giây)
        """
        result = {
            'original': text,
            'is_safe': False,
            'toxicity_score': 0.0,
            'spans': [],
            'span_texts': [],
            'rewritten': text,
            'rewritten_is_safe': None,  # None nếu chưa check, True/False sau khi check
            'rewritten_toxicity_score': None,  # None nếu chưa check, score sau khi check
            'processing_time': 0.0,
        }
        
        start_time = datetime.now()
        
        # Tầng 1: Safety Checker
        if verbose:
            logger.info(f"\n[Tầng 1] Kiểm tra an toàn: '{text[:50]}...'")
        label, toxicity_score = self.tier1.detect(text)
        result['is_safe'] = (label == "safe")
        result['toxicity_score'] = toxicity_score
        
        if result['is_safe']:
            # Câu an toàn, giữ nguyên và kết thúc
            # LƯU Ý: Safe thì BỎ QUA tier 2 và tier 3, không chạy span locator và rewriter
            # spans và span_texts sẽ giữ nguyên là [] (rỗng)
            if verbose:
                logger.info(f"[Tầng 1] Câu an toàn (toxicity={toxicity_score:.3f}), giữ nguyên")
            result['rewritten'] = text
            result['rewritten_is_safe'] = True  # Câu gốc đã safe thì rewritten cũng safe
            result['rewritten_toxicity_score'] = toxicity_score
            result['processing_time'] = (datetime.now() - start_time).total_seconds()
            return result
        
        # Câu không an toàn, tiếp tục xử lý qua tier 2 và tier 3
        if verbose:
            logger.info(f"[Tầng 1] Câu không an toàn (toxicity={toxicity_score:.3f}), tiếp tục xử lý...")
        
        # Tầng 2: Span Tagger (CHỈ chạy khi unsafe)
        if verbose:
            logger.info(f"[Tầng 2] Đang định vị spans độc hại...")
        spans_indices = self.tier2.locate_spans(text)
        result['spans'] = spans_indices  # Lưu character indices của spans
        
        # Lấy text của các spans
        span_texts = self.tier2.get_span_texts(text, spans_indices)
        result['span_texts'] = span_texts  # Lưu text của spans
        
        if verbose:
            logger.info(f"[Tầng 2] Tìm thấy {len(spans_indices)} spans: {span_texts}")
        
        # Tầng 3: Contextual Rewriter
        if verbose:
            logger.info(f"[Tầng 3] Đang viết lại câu (One-time Rewriting với Beam Search)...")
        # Truyền cả spans_indices để tier3 sử dụng BartphoSpanRewriter từ baseline
        rewritten_text = self.tier3.rewrite(text, span_texts=span_texts, spans_indices=spans_indices)
        result['rewritten'] = rewritten_text
        
        if verbose:
            logger.info(f"[Tầng 3] Kết quả: '{text[:50]}...' -> '{rewritten_text[:50]}...'")
        
        # Kiểm tra lại câu đã rewrite bằng Tier 1 để đánh giá hiệu quả
        if verbose:
            logger.info(f"[Tầng 1 - Post-check] Đang kiểm tra lại câu đã rewrite...")
        rewritten_label, rewritten_toxicity_score = self.tier1.detect(rewritten_text)
        result['rewritten_is_safe'] = (rewritten_label == "safe")
        result['rewritten_toxicity_score'] = rewritten_toxicity_score
        
        if verbose:
            status = "AN TOÀN" if result['rewritten_is_safe'] else "VẪN ĐỘC HẠI"
            logger.info(f"[Tầng 1 - Post-check] Câu đã rewrite: {status} (toxicity={rewritten_toxicity_score:.3f})")
            logger.info(f"[Tầng 1 - Post-check] Giảm độc hại: {result['toxicity_score']:.3f} -> {rewritten_toxicity_score:.3f} (Δ={result['toxicity_score'] - rewritten_toxicity_score:.3f})")
        
        result['processing_time'] = (datetime.now() - start_time).total_seconds()
        
        return result
    
    def process_batch(self, texts: List[str], verbose: bool = False) -> List[Dict[str, Any]]:
        """
        Xử lý một batch các câu
        
        Args:
            texts: Danh sách câu cần xử lý
            verbose: In chi tiết quá trình xử lý
            
        Returns:
            List of results
        """
        results = []
        
        # Sử dụng tqdm để hiển thị thanh tiến trình
        if TQDM_AVAILABLE:
            text_iterator = tqdm(
                enumerate(texts),
                total=len(texts),
                desc="Đang xử lý",
                unit="câu",
                ncols=100,
                bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]'
            )
        else:
            text_iterator = enumerate(texts)
            logger.warning("tqdm không khả dụng, không hiển thị thanh tiến trình")
        
        for i, text in text_iterator:
            if verbose:
                logger.info(f"\n{'='*60}")
                logger.info(f"Xử lý câu {i+1}/{len(texts)}")
                logger.info(f"{'='*60}")
            result = self.process(text, verbose=verbose)
            results.append(result)
            
            # Cập nhật mô tả thanh tiến trình với thông tin chi tiết
            if TQDM_AVAILABLE and not verbose:
                text_iterator.set_postfix({
                    'safe': sum(1 for r in results if r.get('is_safe', False)),
                    'unsafe': sum(1 for r in results if not r.get('is_safe', True))
                })
        
        return results


if __name__ == "__main__":
    # Thiết lập logging trước khi sử dụng logger
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler()]
    )
    
    # Lấy lại logger sau khi đã cấu hình logging
    logger = logging.getLogger(__name__)
    
    print("=" * 60)
    print("VITOXREDUCE PIPELINE - MODULE (3 TẦNG)")
    print("=" * 60)
    print("File này chứa class ViToxReducePipeline.")
    print("Để chạy pipeline, vui lòng sử dụng:")
    print("  python run_pipeline.py --input <input> --rewriter_model <model_path>")
    print("")
    print("Hoặc import và sử dụng trong code:")
    print("  from vitoxreduce_pipeline import ViToxReducePipeline")
    print("  pipeline = ViToxReducePipeline(rewriter_model_path='...')")
    print("  result = pipeline.process('text cần xử lý', verbose=True)")
    print("=" * 60)

