#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tầng 1: Toxicity Detector (Bộ phát hiện độc hại)
Phân loại câu đầu vào thành safe (an toàn) hoặc unsafe (không an toàn)
Sử dụng PhoBERT hoặc viBERT4News
"""

import os
import logging
from typing import Tuple, Optional
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

logger = logging.getLogger(__name__)


class ToxicityDetector:
    """Tầng 1: Phát hiện độc hại - Gác cổng để xác định câu có cần xử lý hay không"""
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        device: Optional[str] = None,
        threshold: float = 0.5
    ):
        """
        Args:
            model_path: Đường dẫn đến model PhoBERT classifier. Nếu None, sẽ raise error
            device: Device để chạy model (cuda/cpu)
            threshold: Ngưỡng để phân loại unsafe (default: 0.5)
        """
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.threshold = threshold
        
        if model_path is None or not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Không tìm thấy PhoBERT classifier model tại {model_path}. "
                f"Vui lòng chỉ định model_path hợp lệ."
            )
        
        self.model_path = model_path
        self._load_model()
    
    def _load_model(self):
        """Load tokenizer và model"""
        logger.info(f"Đang load Toxicity Detector từ {self.model_path}...")
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            self.model = AutoModelForSequenceClassification.from_pretrained(self.model_path)
            self.model.to(self.device)
            self.model.eval()
            logger.info("Toxicity Detector đã được load thành công!")
        except Exception as e:
            logger.error(f"Lỗi khi load model: {e}")
            raise
    
    def detect(self, text: str) -> Tuple[str, float]:
        """
        Phát hiện độc hại của câu
        
        Args:
            text: Câu cần kiểm tra
            
        Returns:
            (label, probability): 
                - label: "safe" hoặc "unsafe"
                - probability: Xác suất unsafe (0.0-1.0)
        """
        if not text or not text.strip():
            return "safe", 0.0
        
        try:
            # Tokenize
            encoding = self.tokenizer(
                text,
                max_length=256,
                padding=True,
                truncation=True,
                return_tensors="pt",
            ).to(self.device)
            
            # Forward pass
            with torch.no_grad():
                outputs = self.model(**encoding)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=-1)
                # Class 1 = unsafe
                unsafe_prob = probs[0][1].item()
            
            label = "unsafe" if unsafe_prob >= self.threshold else "safe"
            return label, float(unsafe_prob)
            
        except Exception as e:
            logger.warning(f"Lỗi khi phát hiện độc hại cho text '{text[:50]}...': {e}")
            # Mặc định là safe nếu có lỗi
            return "safe", 0.0
    
    def is_safe(self, text: str) -> bool:
        """
        Kiểm tra nhanh xem câu có an toàn không
        
        Returns:
            True nếu safe, False nếu unsafe
        """
        label, _ = self.detect(text)
        return label == "safe"
    
    def is_unsafe(self, text: str) -> bool:
        """
        Kiểm tra nhanh xem câu có độc hại không
        
        Returns:
            True nếu unsafe, False nếu safe
        """
        label, _ = self.detect(text)
        return label == "unsafe"

