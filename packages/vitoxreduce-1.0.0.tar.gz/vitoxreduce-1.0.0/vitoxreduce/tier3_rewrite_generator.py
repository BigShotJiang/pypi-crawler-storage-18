#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tầng 3: Contextual Rewriter (Bộ viết lại ngữ cảnh)
Sử dụng BARTpho (Seq2Seq - Span-guided) để viết lại câu
One-time Rewriting với Beam Search để chọn Top-1 kết quả tốt nhất

Tái cấu trúc để sử dụng BartphoSpanRewriter từ baseline để đảm bảo prompt và logic giống hệt
"""

import logging
import re
from typing import List, Optional
import torch

from .bartpho_span_baseline import BartphoSpanRewriter, PredictionCleaner

logger = logging.getLogger(__name__)


class ContextualRewriter:
    """Tầng 3: Contextual Rewriter - BARTpho Seq2Seq với Span-guided prompt
    
    Sử dụng BartphoSpanRewriter từ baseline để đảm bảo prompt và logic giống hệt baseline
    """
    
    def __init__(
        self,
        model_path: str,
        device: Optional[str] = None,
        max_length: int = 256,  # Giống baseline default
        num_beams: int = 5
    ):
        """
        Args:
            model_path: Đường dẫn đến BARTpho model đã fine-tune
            device: Device để chạy model
            max_length: Độ dài tối đa của sequence (default: 256 giống baseline)
            num_beams: Số beams cho beam search (để chọn top-1 tốt nhất)
        """
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.max_length = max_length
        self.num_beams = num_beams
        self.model_path = model_path
        
        # Sử dụng BartphoSpanRewriter từ baseline
        logger.info(f"Đang khởi tạo Contextual Rewriter với BartphoSpanRewriter...")
        self.rewriter = BartphoSpanRewriter(
            model_path=model_path,
            device=self.device,
            max_length=max_length,
            num_beams=num_beams,
            num_return_sequences=1,  # Chỉ lấy top-1
            do_sample=False,
        )
        
        # Sử dụng PredictionCleaner từ baseline để clean output
        self.cleaner = PredictionCleaner(enable=True)
        
        logger.info("Contextual Rewriter đã được khởi tạo thành công!")
    
    def rewrite(
        self,
        text: str,
        span_texts: Optional[List[str]] = None,
        spans_indices: Optional[List[List[int]]] = None
    ) -> str:
        """
        Viết lại câu một lần duy nhất (One-time Rewriting) với Beam Search để chọn Top-1
        
        Args:
            text: Câu gốc cần viết lại
            span_texts: Danh sách các từ/cụm từ độc hại cần sửa (từ Tầng 2) - không dùng trực tiếp, chỉ để log
            spans_indices: Danh sách các span dạng [[start, end], ...] (character indices) từ Tầng 2
            
        Returns:
            Câu đã được viết lại (Top-1 từ beam search)
        """
        try:
            # Sử dụng BartphoSpanRewriter từ baseline
            # Method rewrite() nhận (text, spans_indices)
            if spans_indices:
                # Chuyển đổi từ List[Tuple[int, int]] sang List[List[int]]
                spans_indices_list = [[start, end] for start, end in spans_indices]
                rewritten_text = self.rewriter.rewrite(text, spans_indices_list)
            else:
                # Fallback nếu không có spans_indices - dùng empty list
                rewritten_text = self.rewriter.rewrite(text, [])
            
            # Clean output để loại bỏ prompt text còn sót lại
            rewritten_text = self._clean_prediction(rewritten_text, text)
            
            # Đảm bảo có kết quả
            if not rewritten_text or not rewritten_text.strip():
                logger.warning("Kết quả viết lại rỗng, trả về câu gốc")
                rewritten_text = text
            
            logger.debug(f"Đã viết lại câu: '{text[:50]}...' -> '{rewritten_text[:50]}...'")
            return rewritten_text.strip()
            
        except Exception as e:
            logger.warning(f"Lỗi khi viết lại câu: {e}")
            import traceback
            traceback.print_exc()
            # Fallback về câu gốc nếu có lỗi
            return text
    
    def _clean_prediction(self, prediction: str, original_text: str) -> str:
        """
        Làm sạch prediction để loại bỏ prompt text còn sót lại
        
        Args:
            prediction: Text prediction từ model
            original_text: Câu gốc để so sánh
            
        Returns:
            Text đã được clean
        """
        if not prediction:
            return prediction
        
        # Sử dụng PredictionCleaner từ baseline nếu có
        if self.cleaner:
            prediction = self.cleaner.clean(prediction)
        
        # Loại bỏ các pattern prompt còn sót lại
        # Pattern 1: "Từ từ" ở đầu câu
        prediction = re.sub(r'^Từ từ\s+', '', prediction, flags=re.IGNORECASE)
        
        # Pattern 2: "Câu gốc: ..." hoặc "Câu gốc:... " ở cuối
        prediction = re.sub(r'\s*Câu gốc\s*:\s*.*$', '', prediction, flags=re.IGNORECASE)
        
        # Pattern 3: "Từ cần sửa: ..." hoặc "Từ cần sửa:... " ở cuối
        prediction = re.sub(r'\s*Từ cần sửa\s*:\s*.*$', '', prediction, flags=re.IGNORECASE)
        
        # Pattern 4: "giữ nguyên lập trường và thông tin quan trọng" (có thể còn sót)
        prediction = re.sub(r'\s*,\s*giữ nguyên lập trường và thông tin quan trọng\.?\s*$', '', prediction, flags=re.IGNORECASE)
        prediction = re.sub(r'\s*giữ nguyên lập trường và thông tin quan trọng\.?\s*$', '', prediction, flags=re.IGNORECASE)
        
        # Loại bỏ khoảng trắng thừa
        prediction = re.sub(r'\s+', ' ', prediction).strip()
        
        return prediction

