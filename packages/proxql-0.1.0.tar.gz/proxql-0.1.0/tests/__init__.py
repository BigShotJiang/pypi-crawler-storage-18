"""ProxQL test suite."""

