import sysconfig

def fmt(name):
    print(f'{name:<15} {sysconfig.get_config_var(name)}')

fmt('CFLAGS')
fmt('CXXFLAGS')
fmt('LDFLAGS')
fmt('LDFLAGS_EXE')
fmt('CC')
fmt('CXX')
fmt('CONFIG_ARGS')
print('-'*57)
