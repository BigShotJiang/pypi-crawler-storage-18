import time

def fmt(name, value):
    print(f'{name:<40} {value:.6f} seconds')

def cpu_loop():
    N = 100_000_000
    start = time.perf_counter()
    x = 0
    for i in range(N):
        x += (i % 5) * 3
    end = time.perf_counter()
    fmt('CPU (Python VM modulo loop):', (end - start))

def list_allocation():
    N = 10_000_000
    start = time.perf_counter()
    lst = [i for i in range(N)] #noqa F841
    end = time.perf_counter()
    fmt('List allocation:', (end - start))

def modules_import():
    modules = ['math', 'json', 'collections', 're', 'itertools', 'os', 'sys', 'datetime']

    start = time.perf_counter()
    for m in modules:
        __import__(m)
    end = time.perf_counter()
    fmt('Module imports:', (end - start))

if __name__ == '__main__':
    cpu_loop()
    list_allocation()
    modules_import()
    print('-'*57)
