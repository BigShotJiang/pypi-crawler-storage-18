# Wox setup for wox developers

## Installation

Create a new directory (or workspace on IDE) and type the following command from it:

```bash
git clone <repo> .
```

Switch on the develop branch to see the codebase.

Create a new virtual environment, activate it and type the next command:

```bash
pip install -e ".[uv, doc, dev]"
```

Since wox is using pre-commit, it must be initialized to apply on every commit:

```bash
pre-commit install
```

## Where to begin with?

### Reading documentation

I strongly suggest reading the documentation at least once. Build it with the instructions on the README file located in ``./docs/``.

The documentation is accessible from ``./docs/build/dirhtml/index.html``.

To access it on vscode, I suggest the [Live Server][live-server-repo] extension or any means which opens a local development server for .html files.

As a fallback solution, use the built-in http.server Python library:

```bash
python -B -m http.server -d <path to index.html directory>

python -B -m http.server -d ./docs/build/dirhtml
```

### Running tests

The officiel test validation is done with the following coverage command:

```bash
coverage run -m pytest -rA --no-header \
--html=./reports/pytest/report.html \
--self-contained-html && \
coverage html
```

[live-server-repo]: https://github.com/ritwickdey/vscode-live-server
