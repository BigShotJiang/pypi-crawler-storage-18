Wox scripts
===========

Wox is very good at running Python code inside managed virtual environments, why not take advantage of it?

A wox script is a small Python program designed to accomplish a focused task. On its own, a Python script works, but it cannot fully shine: it lacks orchestration, isolation, and reproducibility.

Once executed through wox, however, these same scripts become powerful tools!


Wox provides them with:

- an isolated environment,
- a controlled interpreter,
- predictable dependencies,
- and the ability to run across multiple environments automatically.

For example, the wox scripts used for :ref:`benchmarking <benchmarking>` can only measure the performance of a single Python interpreter when run manually. But when executed by wox - across different builds, with consistent setup - they effectively become a mini benchmarking framework.

All built-in wox scripts are available under the ``wox.scripts`` package:

- ``python_benchmark.core_operations``: Run Python operations to measure the performances of the interpreter.
- ``python_benchmark.extended_operations``: Run alternative Python operations to measure the performances of the interpreter.
- ``python_benchmark.check_config``: Display configuration options used during the compilation of the Python interpreter.
