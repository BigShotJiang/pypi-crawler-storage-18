"""
Syriatel Cash API Python Library

A professional Python library for interacting with the Syriatel Cash API.
Supports both async and sync operations.
"""

from .client import SyriatelCashClient, SyriatelCashClientSync
from .exceptions import (
    SyriatelCashError,
    InvalidTokenError,
    SubscriptionExpiredError,
    FetchFailedError,
    NotAuthorizedError,
    ServerMaintenanceError,
    NetworkError,
    GSMNotFoundError,
    VerificationRequiredError,
    VerificationFailedError,
    PINInvalidError,
    LoginFailedError,
)

__version__ = "1.0.0"
__all__ = [
    "SyriatelCashClient",
    "SyriatelCashClientSync",
    "SyriatelCashError",
    "InvalidTokenError",
    "SubscriptionExpiredError",
    "FetchFailedError",
    "NotAuthorizedError",
    "ServerMaintenanceError",
    "NetworkError",
    "GSMNotFoundError",
    "VerificationRequiredError",
    "VerificationFailedError",
    "PINInvalidError",
    "LoginFailedError",
]

