# =============================================================================
# Docstring
# =============================================================================

"""
Path Is Directory Helper
========================

Provide a thin wrapper around ``Path.is_dir``.

"""


# =============================================================================
# Imports
# =============================================================================

# Import | Future
from __future__ import annotations

# Import | Standard Library
from pathlib import Path

# Import | Libraries

# Import | Local Modules


# =============================================================================
# Functions
# =============================================================================


def path_is_dir(path: str | Path) -> bool:
    """Return ``True`` if a filesystem path is a directory."""
    return Path(path).is_dir()


# =============================================================================
# Module Exports
# =============================================================================

__all__: list[str] = [
    "path_is_dir",
]
