# =============================================================================
# Docstring
# =============================================================================

"""
Path Exists Helper
==================

Provide a thin wrapper around ``Path.exists``.

"""


# =============================================================================
# Imports
# =============================================================================

# Import | Future
from __future__ import annotations

# Import | Standard Library
from pathlib import Path

# Import | Libraries

# Import | Local Modules


# =============================================================================
# Functions
# =============================================================================


def path_exists(path: str | Path) -> bool:
    """Return ``True`` if a filesystem path exists."""
    return Path(path).exists()


# =============================================================================
# Module Exports
# =============================================================================

__all__: list[str] = [
    "path_exists",
]
