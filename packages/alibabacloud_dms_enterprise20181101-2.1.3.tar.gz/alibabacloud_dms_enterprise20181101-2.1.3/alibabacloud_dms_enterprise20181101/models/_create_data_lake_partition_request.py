# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_dms_enterprise20181101 import models as main_models
from darabonba.model import DaraModel

class CreateDataLakePartitionRequest(DaraModel):
    def __init__(
        self,
        catalog_name: str = None,
        data_region: str = None,
        db_name: str = None,
        if_not_exists: bool = None,
        need_result: bool = None,
        partition_input: main_models.DLPartitionInput = None,
        table_name: str = None,
        tid: int = None,
        workspace_id: int = None,
    ):
        # The name of the data catalog.
        # 
        # This parameter is required.
        self.catalog_name = catalog_name
        # The region where the data lake resides.
        # 
        # This parameter is required.
        self.data_region = data_region
        # The database name.
        # 
        # This parameter is required.
        self.db_name = db_name
        # Specifies whether to ignore the exception if the name of the created partition is the same as the name of an existing partition.
        self.if_not_exists = if_not_exists
        # Specifies whether to return information about the created partition. If the value is true, the Partition parameter is returned. Valid values:
        # 
        # *   true: returns information about the created partition.
        # *   false: does not return information about the created partition.
        self.need_result = need_result
        # The information about the created partition.
        # 
        # This parameter is required.
        self.partition_input = partition_input
        # The name of the table
        # 
        # This parameter is required.
        self.table_name = table_name
        # The ID of the tenant.
        # 
        # > To view the tenant ID, go to the Data Management (DMS) console and move the pointer over the profile picture in the upper-right corner. For more information, see the [View information about the current tenant](https://help.aliyun.com/document_detail/181330.html) section of the "Manage DMS tenants" topic.
        self.tid = tid
        # The workspace ID.
        self.workspace_id = workspace_id

    def validate(self):
        if self.partition_input:
            self.partition_input.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.catalog_name is not None:
            result['CatalogName'] = self.catalog_name

        if self.data_region is not None:
            result['DataRegion'] = self.data_region

        if self.db_name is not None:
            result['DbName'] = self.db_name

        if self.if_not_exists is not None:
            result['IfNotExists'] = self.if_not_exists

        if self.need_result is not None:
            result['NeedResult'] = self.need_result

        if self.partition_input is not None:
            result['PartitionInput'] = self.partition_input.to_map()

        if self.table_name is not None:
            result['TableName'] = self.table_name

        if self.tid is not None:
            result['Tid'] = self.tid

        if self.workspace_id is not None:
            result['WorkspaceId'] = self.workspace_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CatalogName') is not None:
            self.catalog_name = m.get('CatalogName')

        if m.get('DataRegion') is not None:
            self.data_region = m.get('DataRegion')

        if m.get('DbName') is not None:
            self.db_name = m.get('DbName')

        if m.get('IfNotExists') is not None:
            self.if_not_exists = m.get('IfNotExists')

        if m.get('NeedResult') is not None:
            self.need_result = m.get('NeedResult')

        if m.get('PartitionInput') is not None:
            temp_model = main_models.DLPartitionInput()
            self.partition_input = temp_model.from_map(m.get('PartitionInput'))

        if m.get('TableName') is not None:
            self.table_name = m.get('TableName')

        if m.get('Tid') is not None:
            self.tid = m.get('Tid')

        if m.get('WorkspaceId') is not None:
            self.workspace_id = m.get('WorkspaceId')

        return self

