# llmskit

## 介绍
统一的LLM客户端与工具

## 已实现
```python3
# 调用embedding
from llmskit import OpenAIEmbeddings, AsyncOpenAIEmbeddings
# 调用LLM
from llmskit import ChatLLM, AsyncChatLLM, OpenAIClient, AsyncOpenAIClient, AzureOpenAIClient, AsyncAzureOpenAIClient
```

