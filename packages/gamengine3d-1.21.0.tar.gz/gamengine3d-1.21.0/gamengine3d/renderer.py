import math
import moderngl
import pygame
from pygame.locals import DOUBLEBUF, OPENGL
import importlib.resources as pkg_resources
import numpy as np
from pyrr import Matrix44
from .helper import vector3d, ShadowVolume

class Renderer:
    def __init__(self, width=800, height=600, flags=DOUBLEBUF | OPENGL):
        pygame.init()
        self.screen = pygame.display.set_mode((width, height), flags)
        self.ctx = moderngl.create_context()
        self.ctx.viewport = (0, 0, width, height)
        self.samples = 4
        self.color_tex = self.ctx.texture((width, height), 3, samples=self.samples)
        self.depth_rbo = self.ctx.depth_renderbuffer((width, height), samples=self.samples)
        self.fbo = self.ctx.framebuffer(color_attachments=[self.color_tex], depth_attachment=self.depth_rbo)
        self.lights = []
        self.frame_emissives = []
        self.width = width
        self.height = height
        self.ambient = 0.2
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.MAX_VERTICES = 500_000

        self.prog = self._load_shader("default.vert", "default.frag")
        self.prog["model"].write(np.eye(4, dtype="f4").tobytes())
        self.proj = Matrix44.perspective_projection(60.0, width / height, 0.1, 100.0)
        self.view = Matrix44.look_at(
            eye=(3.0, 2.0, 3.0),
            target=(0.0, 0.0, 0.0),
            up=(0.0, 1.0, 0.0)
        )
        self.mvp = self.proj * self.view
        self.prog["mvp"].write(self.mvp.astype("f4").tobytes())
        self.prog["ambient"].value = self.ambient


        # --- Shadow configuration: support multiple per-light shadow maps ---
        # Runtime toggle: set renderer.shadows = False to disable shadow rendering/binding
        self.shadows = True
        # Shadow map resolution (reduce if VRAM is tight)
        self.shadow_size = 2048
        # Maximum shadow maps to allocate (must match shader MAX_LIGHTS)
        self.max_shadow_maps = 20
        # Pre-create depth textures and FBOs, one per potential casting light
        self.shadow_depth_textures = [
            self.ctx.depth_texture((self.shadow_size, self.shadow_size))
            for _ in range(self.max_shadow_maps)
        ]
        for tex in self.shadow_depth_textures:
            try:
                tex.repeat_x = False
                tex.repeat_y = False
            except Exception:
                pass
        self.shadow_fbos = [self.ctx.framebuffer(depth_attachment=tex) for tex in self.shadow_depth_textures]
        # Per-light light-space matrices (uploaded to shader each frame)
        self.light_space_matrices = [np.eye(4, dtype="f4") for _ in range(self.max_shadow_maps)]

        # depth shader (unchanged)
        self.depth_prog = self._load_shader("depth.vert", "depth.frag")

        self.light_space_matrix = np.eye(4, dtype="f4")

        self.frame_vertices = []
        self.vbo = self.ctx.buffer(reserve=self.MAX_VERTICES * 4 * 12)

        self.vao = self.ctx.vertex_array(
            self.prog,
            [(self.vbo, "3f 3f 3f 3f", "in_vert", "in_color", "in_normal", "in_emission")]
        )

        self.shadow_volume = ShadowVolume(minx=-50, maxx=50, miny=-50, maxy=50, minz=1, maxz=100)

    def resize(self, width, height):
        self.width = width
        self.height = height
        pygame.display.set_mode((width, height), pygame.OPENGL | pygame.DOUBLEBUF | pygame.RESIZABLE)

        # just update viewport, don’t create a new context
        self.ctx.viewport = (0, 0, width, height)

        # update projection matrix
        aspect = width / height
        self.proj = Matrix44.perspective_projection(60.0, aspect, 0.1, 100.0)
        self.mvp = self.proj * self.view
        self.prog["mvp"].write(self.mvp.astype("f4").tobytes())

        # resize textures and framebuffers
        self.color_tex.release()
        self.color_tex = self.ctx.texture((width, height), 3, samples=self.samples)

        self.depth_rbo.release()
        self.depth_rbo = self.ctx.depth_renderbuffer((width, height), samples=self.samples)

        self.fbo.release()
        self.fbo = self.ctx.framebuffer(color_attachments=[self.color_tex], depth_attachment=self.depth_rbo)

        self._send_lights()

    def add_light(self, light):
        self.lights.append(light)

    def _compute_normal(self, p1, p2, p3):
        u = p2 - p1
        v = p3 - p1
        return u.cross(v).normalized

    def compute_light_matrix(self, light):
        light_proj = Matrix44.orthogonal_projection(self.shadow_volume.minx, self.shadow_volume.maxx, self.shadow_volume.miny, self.shadow_volume.maxy, self.shadow_volume.minz, self.shadow_volume.maxz)
        light_view = Matrix44.look_at(
            eye=light.position.totuple(),
            target=(0, 0, 0),
            up=(0, 1, 0)
        )
        return light_proj * light_view


    def render_shadow_pass(self, objects):
        """Render a depth map for each positional light (up to max_shadow_maps).
        If shadows are disabled or there are no positional lights, do nothing.
        """
        # Respect runtime toggle
        if not getattr(self, 'shadows', True):
            return

        # Collect positional lights (lights that have a .position attribute)
        casters = [l for l in self.lights if hasattr(l, 'position')]
        if not casters:
            return

        casters = casters[:self.max_shadow_maps]

        # Batch all geometry that should cast shadows (we reuse the same VBO for each light)
        shadow_vertices = []
        for obj in objects:
            if not hasattr(obj, "get_corners"):
                continue
            corners = obj.get_corners()
            for face in obj.faces:
                p1, p2, p3, p4 = [corners[i] for i in face]
                # Two triangles per quad
                shadow_vertices.extend([
                    *p1.totuple(), *p2.totuple(), *p3.totuple(),
                    *p1.totuple(), *p3.totuple(), *p4.totuple()
                ])

        if not shadow_vertices:
            return

        vertices = np.array(shadow_vertices, dtype="f4")
        vbo = self.ctx.buffer(vertices.tobytes())
        vao = self.ctx.vertex_array(self.depth_prog, [(vbo, "3f", "in_vert")])

        # Render a depth map for each caster light
        for idx, light in enumerate(casters):
            # Compute and store light-space matrix
            mat = self.compute_light_matrix(light)
            self.light_space_matrices[idx] = mat.astype('f4')

            # Bind and clear the shadow FBO for this light, then render depth
            fbo = self.shadow_fbos[idx]
            fbo.clear(depth=1.0)
            fbo.use()
            self.ctx.enable(moderngl.DEPTH_TEST)

            # Upload uniforms for the depth shader
            try:
                self.depth_prog["model"].write(np.eye(4, dtype="f4").tobytes())
            except Exception:
                pass
            try:
                self.depth_prog["light_space_matrix"].write(mat.astype("f4").tobytes())
            except Exception:
                pass

            vao.render()

        vao.release()
        vbo.release()

        # restore default framebuffer
        self.ctx.screen.use()

    def _append_vertices(self, vertices):
        self.frame_vertices.extend(vertices)

    def flush(self):
        if not self.frame_vertices:
            return
        vertices = np.array(self.frame_vertices, dtype="f4")
        self.vbo.write(vertices.tobytes())
        # Ensure FBO is bound before rendering
        self.fbo.use()
        # Send lights and bind shadow maps + matrices
        self._send_lights()
        # Draw
        num_verts = len(vertices) // 12
        self.vao.render(vertices=num_verts)
        self.frame_vertices.clear()

    def render_plane(self, p1, p2, p3, color, emit: bool = False):

        normal = self._compute_normal(p1, p2, p3)

        # per-vertex emission marker (non-zero -> emissive)
        em_triplet = (1.0, 1.0, 1.0) if emit else (0.0, 0.0, 0.0)

        def v_entry(p):
            return [*p.totuple(), *color.to_rgb(), *normal.totuple(), *em_triplet]

        vertices = []
        vertices.extend(v_entry(p1))
        vertices.extend(v_entry(p2))
        vertices.extend(v_entry(p3))

        self._append_vertices(vertices)

    def render_sphere(self, center, radius, color, segments=32, rings=16,
                      emit: bool = False):
        """
        Render a sphere with optional emission.
        - center: vector3d
        - radius: float
        - color: Color
        - segments, rings: tessellation
        - emit / emission_*: same meaning as for render_plane
        """
        vertices = []
        em_triplet = (1.0, 1.0, 1.0) if emit else (0.0, 0.0, 0.0)

        for i in range(rings):
            theta1 = math.pi * i / rings
            theta2 = math.pi * (i + 1) / rings
            for j in range(segments):
                phi1 = 2 * math.pi * j / segments
                phi2 = 2 * math.pi * (j + 1) / segments

                p1 = vector3d(radius * math.sin(theta1) * math.cos(phi1),
                              radius * math.cos(theta1),
                              radius * math.sin(theta1) * math.sin(phi1)) + center
                p2 = vector3d(radius * math.sin(theta2) * math.cos(phi1),
                              radius * math.cos(theta2),
                              radius * math.sin(theta2) * math.sin(phi1)) + center
                p3 = vector3d(radius * math.sin(theta2) * math.cos(phi2),
                              radius * math.cos(theta2),
                              radius * math.sin(theta2) * math.sin(phi2)) + center
                p4 = vector3d(radius * math.sin(theta1) * math.cos(phi2),
                              radius * math.cos(theta1),
                              radius * math.sin(theta1) * math.sin(phi2)) + center

                for tri in [(p1, p2, p3), (p1, p3, p4)]:
                    n1 = (tri[0] - center).normalized
                    n2 = (tri[1] - center).normalized
                    n3 = (tri[2] - center).normalized
                    vertices.extend([
                        *tri[0].totuple(), *color.to_rgb(), *n1.totuple(), *em_triplet,
                        *tri[1].totuple(), *color.to_rgb(), *n2.totuple(), *em_triplet,
                        *tri[2].totuple(), *color.to_rgb(), *n3.totuple(), *em_triplet,
                    ])

        self._append_vertices(vertices)

    def render_cylinder(self, center, height, radius, color, segments=32, rotation=vector3d(0, 0, 0),
                        emit: bool = False):
        vertices = []

        def apply_matrix(v: vector3d, m: Matrix44) -> vector3d:
            vec4 = np.array([v.x, v.y, v.z, 1.0], dtype="f4")
            transformed = m @ vec4
            return vector3d(*transformed[:3])

        def apply_matrix_normal(n: vector3d, m: Matrix44) -> vector3d:
            vec4 = np.array([n.x, n.y, n.z, 0.0], dtype="f4")  # w=0 for direction
            transformed = m @ vec4
            return vector3d(*transformed[:3]).normalized

        rot_x = Matrix44.from_x_rotation(math.radians(rotation.x))
        rot_y = Matrix44.from_y_rotation(math.radians(rotation.y))
        rot_z = Matrix44.from_z_rotation(math.radians(rotation.z))
        rot_matrix = rot_z * rot_y * rot_x

        em_triplet = (1.0, 1.0, 1.0) if emit else (0.0, 0.0, 0.0)

        for i in range(segments):
            theta1 = 2 * math.pi * i / segments
            theta2 = 2 * math.pi * (i + 1) / segments

            # Top/bottom circle vertices
            top1 = vector3d(radius * math.cos(theta1), height / 2, radius * math.sin(theta1))
            top2 = vector3d(radius * math.cos(theta2), height / 2, radius * math.sin(theta2))
            bottom1 = vector3d(radius * math.cos(theta1), -height / 2, radius * math.sin(theta1))
            bottom2 = vector3d(radius * math.cos(theta2), -height / 2, radius * math.sin(theta2))

            top1 = apply_matrix(top1, rot_matrix) + center
            top2 = apply_matrix(top2, rot_matrix) + center
            bottom1 = apply_matrix(bottom1, rot_matrix) + center
            bottom2 = apply_matrix(bottom2, rot_matrix) + center

            normal1 = apply_matrix_normal(vector3d(math.cos(theta1), 0, math.sin(theta1)), rot_matrix)
            normal2 = apply_matrix_normal(vector3d(math.cos(theta2), 0, math.sin(theta2)), rot_matrix)

            # Side quad (two triangles)
            for tri in [(top1, bottom1, bottom2), (top1, bottom2, top2)]:
                n1 = (tri[0] - center).normalized
                n2 = (tri[1] - center).normalized
                n3 = (tri[2] - center).normalized
                vertices.extend([
                    *tri[0].totuple(), *color.to_rgb(), *n1.totuple(), *em_triplet,
                    *tri[1].totuple(), *color.to_rgb(), *n2.totuple(), *em_triplet,
                    *tri[2].totuple(), *color.to_rgb(), *n3.totuple(), *em_triplet,
                ])

            # Top cap (triangle fan triangles)
            top_center = apply_matrix(vector3d(0, height / 2, 0), rot_matrix) + center
            normal_top = apply_matrix_normal(vector3d(0, 1, 0), rot_matrix)
            vertices.extend([
                *top_center.totuple(), *color.to_rgb(), *normal_top.totuple(), *em_triplet,
                *top2.totuple(), *color.to_rgb(), *normal_top.totuple(), *em_triplet,
                *top1.totuple(), *color.to_rgb(), *normal_top.totuple(), *em_triplet,
            ])

            bottom_center = apply_matrix(vector3d(0, -height / 2, 0), rot_matrix) + center
            normal_bottom = apply_matrix_normal(vector3d(0, -1, 0), rot_matrix)
            vertices.extend([
                *bottom_center.totuple(), *color.to_rgb(), *normal_bottom.totuple(), *em_triplet,
                *bottom1.totuple(), *color.to_rgb(), *normal_bottom.totuple(), *em_triplet,
                *bottom2.totuple(), *color.to_rgb(), *normal_bottom.totuple(), *em_triplet,
            ])

        self._append_vertices(vertices)

    def render_quad(self, p1, p2, p3, p4, color, emit: bool = False):
        normal = self._compute_normal(p1, p2, p3)

        if emit:
            em_triplet = (1.0, 1.0, 1.0)
        else:
            em_triplet = (0.0, 0.0, 0.0)

        def v_entry(p):
            return [*p.totuple(), *color.to_rgb(), *normal.totuple(), *em_triplet]

        vertices = []
        vertices.extend(v_entry(p1))
        vertices.extend(v_entry(p2))
        vertices.extend(v_entry(p3))
        vertices.extend(v_entry(p1))
        vertices.extend(v_entry(p3))
        vertices.extend(v_entry(p4))

        self._append_vertices(vertices)

    def _send_lights(self):
        max_lights = self.max_shadow_maps

        def sample_quad(corners, n_samples):
            p1, p2, p3, p4 = corners
            n = int(math.sqrt(n_samples))
            if n * n < n_samples:
                n += 1
            pts = []
            count = 0
            for i in range(n):
                for j in range(n):
                    if count >= n_samples:
                        break
                    u = (i + 0.5) / n
                    v = (j + 0.5) / n
                    # bilinear interpolation on quad (p1->p2 and p4->p3 interpolation)
                    a = p1 * (1.0 - u) + p2 * u
                    b = p4 * (1.0 - u) + p3 * u
                    pos = a * (1.0 - v) + b * v
                    pts.append(pos)
                    count += 1
                if count >= n_samples:
                    break
            return pts

        def sample_tri(corners, n_samples):
            p1, p2, p3 = corners
            # We'll use a simple stratified scheme: find grid m x m such that m*m >= n_samples
            m = int(math.sqrt(n_samples))
            if m * m < n_samples:
                m += 1
            pts = []
            count = 0
            for i in range(m):
                for j in range(m):
                    if count >= n_samples:
                        break
                    u = (i + 0.5) / m
                    v = (j + 0.5) / m
                    # enforce u+v <= 1 by folding when >1 to stay inside triangle
                    if u + v > 1.0:
                        u = 1.0 - u
                        v = 1.0 - v
                    # barycentric interpolation
                    pos = p1 * (1 - u - v) + p2 * u + p3 * v
                    pts.append(pos)
                    count += 1
                if count >= n_samples:
                    break
            return pts

        flattened = []

        # --- persistent lights (existing self.lights) ---
        for light in self.lights:
            if hasattr(light, 'is_area') and getattr(light, 'is_area'):
                if hasattr(light, 'sample_points'):
                    try:
                        pts = light.sample_points()
                    except Exception:
                        pts = []
                else:
                    pts = []
                if not pts:
                    continue
                per_sample_int = float(light.intensity) / max(1, len(pts))
                color_tuple = tuple(c / 255 for c in light.color.to_rgb())
                for p in pts:
                    flattened.append({
                        'position': p.totuple(),
                        'color': color_tuple,
                        'intensity': per_sample_int
                    })
            else:
                flattened.append({
                    'position': light.position.totuple(),
                    'color': tuple(c / 255 for c in light.color.to_rgb()),
                    'intensity': float(light.intensity)
                })

        num_lights = min(len(flattened), max_lights)

        self.prog["num_lights"].value = num_lights
        self.prog["ambient"].value = self.ambient
        for i in range(num_lights):
            l = flattened[i]
            self.prog[f"lights[{i}].position"].value = l['position']
            self.prog[f"lights[{i}].color"].value = l['color']
            self.prog[f"lights[{i}].intensity"].value = l['intensity']

        # Bind per-light shadow maps and upload light-space matrices (if shadows enabled)
        if getattr(self, 'shadows', True):
            for i in range(num_lights):
                # bind depth texture to texture unit i (moderngl texture unit)
                if i < len(self.shadow_depth_textures):
                    try:
                        self.shadow_depth_textures[i].use(location=i)
                        try:
                            self.prog[f"shadow_maps[{i}]"].value = i
                        except Exception:
                            # shader might not have the sampler array name expected; ignore
                            pass
                    except Exception:
                        pass
                # upload light-space matrix for this light (if computed); else identity
                try:
                    mat = self.light_space_matrices[i]
                except Exception:
                    mat = np.eye(4, dtype='f4')
                try:
                    self.prog[f"light_space_matrices[{i}]"].write(mat.astype('f4').tobytes())
                except Exception:
                    # shader may not have the uniform; ignore
                    pass
        else:
            # Shadows disabled: write identity matrices (safe fallback)
            for i in range(min(num_lights, self.max_shadow_maps)):
                try:
                    self.prog[f"light_space_matrices[{i}]"].write(np.eye(4, dtype='f4').tobytes())
                except Exception:
                    pass

    def clear(self, color):
        color_f = np.array(color.to_rgb(), dtype="f4") / 255.0
        self.fbo.clear(*color_f, depth=1.0)
        self.fbo.use()
        self.frame_vertices.clear()
        self.frame_emissives.clear()

    def swap(self):
        self.flush()  # Render everything in one draw call
        self.ctx.copy_framebuffer(dst=self.ctx.screen, src=self.fbo)
        pygame.display.flip()

    def quit(self):
        pygame.quit()

    def _load_shader(self, vert_name, frag_name):
        vert_src = pkg_resources.read_text(f"{__package__}.shaders", vert_name)
        frag_src = pkg_resources.read_text(f"{__package__}.shaders", frag_name)
        return self.ctx.program(vertex_shader=vert_src, fragment_shader=frag_src)

class Camera:
    def __init__(self, position=None, target=None, up=None, fov=60.0, aspect_ratio=4/3, near=0.1, far=100.0, orbiting=True):
        self.orbiting = orbiting  # New: toggle automatic look-at behavior
        self.target = target or vector3d(0, 0, 0)
        self.up = up or vector3d.up
        self.fov = fov
        self.aspect_ratio = aspect_ratio
        self.near = near
        self.far = far

        # Compute spherical coordinates from initial position
        pos = position or vector3d(3, 2, 3)
        if self.orbiting:
            self._update_spherical(pos)
        self.position = pos

        self._update_position()

    def move_to(self, new_position: vector3d):
        """
        Move the camera to a new position.
        If orbiting is enabled, updates spherical coordinates.
        If orbiting is disabled, just sets position directly.
        """
        self.position = new_position
        if self.orbiting:
            self._update_spherical(new_position)
        self._update_position()

    def set_orbiting(self, orbiting: bool):
        """Enable or disable automatic look-at behavior."""
        self.orbiting = orbiting

    def _update_spherical(self, pos):
        """Convert position to spherical coordinates relative to target."""
        dir_vec = pos - self.target
        self.radius = dir_vec.magnitude
        self.azimuth = math.atan2(dir_vec.z, dir_vec.x)  # yaw
        self.elevation = math.asin(dir_vec.y / self.radius)  # pitch

    def _update_position(self):
        if self.orbiting:
            x = self.radius * math.cos(self.elevation) * math.cos(self.azimuth)
            y = self.radius * math.sin(self.elevation)
            z = self.radius * math.cos(self.elevation) * math.sin(self.azimuth)
            self.position = self.target + vector3d(x, y, z)

        look_at = self.target if self.orbiting else self.position + getattr(self, "look_dir", vector3d(0, 0, -1))

        self.view_matrix = Matrix44.look_at(
            self.position.totuple(),
            look_at.totuple(),
            self.up.totuple()
        )

        self.near = max(self.radius * 0.001, 1e-4)
        self.far = self.radius * 10_000
        self.projection_matrix = Matrix44.perspective_projection(
            self.fov, self.aspect_ratio, self.near, self.far
        )


    def rotate_around_target(self, delta_azimuth_degrees, delta_elevation_degrees):
        if not self.orbiting:
            return  # rotation disabled in free mode

        self.azimuth += math.radians(delta_azimuth_degrees)
        self.elevation += math.radians(delta_elevation_degrees)

        # Handle elevation wrapping to allow full rotation without flipping
        while self.elevation > math.pi / 2:
            self.elevation = math.pi - self.elevation
            self.azimuth += math.pi
            self.up = -self.up  # flip up vector

        while self.elevation < -math.pi / 2:
            self.elevation = -math.pi - self.elevation
            self.azimuth += math.pi
            self.up = -self.up  # flip up vector

        self._update_position()


    def zoom(self, amount):
        """
        Dolly zoom:
        Positive amount moves forward
        Negative amount moves backward
        """

        # Forward direction
        if self.orbiting:
            forward = (self.target - self.position).normalized
        else:
            forward = getattr(self, "look_dir", vector3d(0, 0, -1)).normalized

        # Move camera
        delta = forward * amount
        self.position += delta

        if self.orbiting:
            self._update_spherical(self.position)

        self._update_position()

    def update_renderer(self, renderer: Renderer):
        renderer.view = self.view_matrix
        renderer.proj = self.projection_matrix
        renderer.mvp = renderer.proj * renderer.view
        renderer.prog["mvp"].write(renderer.mvp.astype("f4").tobytes())

    def look_at(self, point: vector3d):
        """
        Make the camera look at a specific point in space.
        - In orbiting mode, sets the target and updates spherical coordinates.
        - In free mode, sets the look direction vector.
        """
        if self.orbiting:
            self.target = point
            self._update_spherical(self.position)
        else:
            self.look_dir = (point - self.position).normalized  # direction vector in free mode

        self._update_position()
