# -*- coding: utf-8 -*-
"""
OlivOS-CLI 主入口
"""

import sys

from .cli.main import main

if __name__ == "__main__":
    sys.exit(main())
