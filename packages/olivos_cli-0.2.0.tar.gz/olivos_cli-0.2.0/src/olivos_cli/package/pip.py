# -*- coding: utf-8 -*-
"""
Pip 包管理器实现
"""

import sys
from pathlib import Path

from ..core.exceptions import PackageError
from ..core.logger import get_logger
from ..utils import run_command
from .base import PackageManager

logger = get_logger()


class PipPackageManager(PackageManager):
    """Pip 包管���器"""

    name = "pip"

    def __init__(self, index_url: str = None):
        self.index_url = index_url

    def is_available(self) -> bool:
        """检查 pip 是否可用"""
        try:
            import pip

            return True
        except ImportError:
            # 确保 pip 可用
            return True

    def ensure_available(self) -> None:
        """确保 pip 可用"""
        if not self.is_available():
            raise PackageError("pip 不可用")

    def _get_pip_command(self) -> list[str]:
        """获取 pip 命令"""
        return [sys.executable, "-m", "pip"]

    def install(self, target_dir: Path, requirements: Path) -> bool:
        """安装依赖"""
        self.ensure_available()

        if not requirements.exists():
            raise PackageError(f"依赖文件不存在: {requirements}")

        cmd = self._get_pip_command() + ["install", "-r", str(requirements)]
        if self.index_url:
            cmd.extend(["--index-url", self.index_url])

        logger.step(f"正在安装依赖: {requirements.name}")
        result = run_command(cmd, cwd=str(target_dir), check=False)

        if result.returncode != 0:
            raise PackageError(f"依赖安装失败: {result.stderr}")

        logger.success("依赖安装成功")
        return True

    def add(self, package: str, target_dir: Path) -> bool:
        """添加包"""
        self.ensure_available()

        cmd = self._get_pip_command() + ["install", package]
        if self.index_url:
            cmd.extend(["--index-url", self.index_url])

        logger.step(f"正在添加包: {package}")
        result = run_command(cmd, cwd=str(target_dir), check=False)

        if result.returncode != 0:
            raise PackageError(f"包添加失败: {result.stderr}")

        logger.success(f"已添加: {package}")
        return True

    def remove(self, package: str, target_dir: Path) -> bool:
        """移除包"""
        self.ensure_available()

        cmd = self._get_pip_command() + ["uninstall", "-y", package]

        logger.step(f"正在移除包: {package}")
        result = run_command(cmd, cwd=str(target_dir), check=False)

        if result.returncode != 0:
            raise PackageError(f"包移除失败: {result.stderr}")

        logger.success(f"已移除: {package}")
        return True

    def update(self, target_dir: Path) -> bool:
        """更新依赖"""
        self.ensure_available()

        cmd = self._get_pip_command() + ["install", "--upgrade", "-r", "requirements.txt"]
        if self.index_url:
            cmd.extend(["--index-url", self.index_url])

        logger.step("正在更新依赖...")
        result = run_command(cmd, cwd=str(target_dir), check=False)

        if result.returncode != 0:
            raise PackageError(f"依赖更新失败: {result.stderr}")

        logger.success("依赖更新成功")
        return True

    def list_installed(self, target_dir: Path) -> list[str]:
        """列出已安装的包"""
        self.ensure_available()

        cmd = self._get_pip_command() + ["list", "--format=json"]
        result = run_command(cmd, cwd=str(target_dir), capture_output=True)

        if result.returncode != 0:
            return []

        try:
            import json

            packages = json.loads(result.stdout)
            return [p["name"] for p in packages]
        except Exception:
            return []
