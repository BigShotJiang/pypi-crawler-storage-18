# -*- coding: utf-8 -*-
"""
包管理模块
"""

from .base import PackageManager
from .pip import PipPackageManager
from .uv import UVPackageManager

# 包管理器工厂
PACKAGE_MANAGERS_MAP = {
    "uv": UVPackageManager,
    "pip": PipPackageManager,
}


def get_package_manager(
    name: str,
    auto_install: bool = True,
    index_url: str = None,
) -> PackageManager:
    """获取包管理器实例

    Args:
        name: 包管理器名称
        auto_install: 是否自动安装包管理器
        index_url: 镜像源地址

    Returns:
        包管理器实例
    """
    if name not in PACKAGE_MANAGERS_MAP:
        from ..core.exceptions import PackageError

        raise PackageError(f"不支持的包管理器: {name}")

    manager_class = PACKAGE_MANAGERS_MAP[name]

    if name == "uv":
        return manager_class(auto_install=auto_install, index_url=index_url)
    else:
        return manager_class(index_url=index_url)


__all__ = [
    "PackageManager",
    "UVPackageManager",
    "PipPackageManager",
    "get_package_manager",
]
