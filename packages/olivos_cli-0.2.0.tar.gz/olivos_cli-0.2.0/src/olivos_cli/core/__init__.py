# -*- coding: utf-8 -*-
"""
核心模块
"""

from .config import Config, ConfigManager, expand_path, path_to_str
from .const import (
    ADAPTER_TYPE_CHOICES,
    CONFIG_DIR,
    CONFIG_FILE,
    DATA_DIR,
    DEFAULT_BRANCH,
    DEFAULT_MIRROR_URL,
    DEFAULT_REPO_URL,
    DEFAULT_SERVICE_NAME,
    LOG_DIR,
    LOG_LEVELS,
    PACKAGE_MANAGERS,
    SUPPORTED_ADAPTERS,
    SYSTEMD_USER_DIR,
    VERSION,
)
from .exceptions import (
    AccountError,
    AdapterError,
    ConfigError,
    FileNotFoundError as OlivOSFileNotFoundError,
    GitError,
    OlivOSCLIError,
    OlivOSConfigError,
    PackageError,
    ProcessError,
    SystemdError,
    ValidationError,
)
from .logger import OlivOSLogger, get_logger

__all__ = [
    # config
    "Config",
    "ConfigManager",
    "expand_path",
    "path_to_str",
    # const
    "ADAPTER_TYPE_CHOICES",
    "CONFIG_DIR",
    "CONFIG_FILE",
    "DATA_DIR",
    "DEFAULT_BRANCH",
    "DEFAULT_MIRROR_URL",
    "DEFAULT_REPO_URL",
    "DEFAULT_SERVICE_NAME",
    "LOG_DIR",
    "LOG_LEVELS",
    "PACKAGE_MANAGERS",
    "SUPPORTED_ADAPTERS",
    "SYSTEMD_USER_DIR",
    "VERSION",
    # exceptions
    "AccountError",
    "AdapterError",
    "ConfigError",
    "OlivOSFileNotFoundError",
    "GitError",
    "OlivOSCLIError",
    "OlivOSConfigError",
    "PackageError",
    "ProcessError",
    "SystemdError",
    "ValidationError",
    # logger
    "OlivOSLogger",
    "get_logger",
]
