# -*- coding: utf-8 -*-
"""
OlivOS-CLI - OlivOS 命令行工具
用于构建、部署和管理 OlivOS 应用
"""

__version__ = "0.2.0"

from .cli.main import main

__all__ = ["__version__", "main"]
