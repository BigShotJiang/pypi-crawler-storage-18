# -*- coding: utf-8 -*-
"""
service 命令实现
"""

import subprocess
import sys
from pathlib import Path

from ...core import ConfigManager, get_logger
from ...core.exceptions import SystemdError
from ...systemd import SystemdManager

logger = get_logger()


def cmd_service(config_manager: ConfigManager, args) -> int:
    """服务管理"""
    action = args.svc_action

    if not action:
        from ..main import OlivOSCLI

        cli = OlivOSCLI()
        subparsers = cli.parser._subparsers._actions[1]
        for action in subparsers.choices:
            if "service" in action:
                action.choices["service"].print_help()
                return 0
        return 1

    config = config_manager.config
    install_path = config.git.expanded_install_path
    service_name = config.systemd.service_name

    systemd = SystemdManager(
        user_mode=config.systemd.user_mode,
        service_dir=config.systemd.expanded_service_dir,
    )

    if action == "install":
        return _cmd_service_install(systemd, config, install_path)
    elif action == "uninstall":
        return _cmd_service_uninstall(systemd, service_name)
    elif action == "enable":
        return _cmd_service_enable(systemd, service_name)
    elif action == "disable":
        return _cmd_service_disable(systemd, service_name)
    elif action == "start":
        return _cmd_service_start(systemd, service_name)
    elif action == "stop":
        return _cmd_service_stop(systemd, service_name)
    elif action == "restart":
        return _cmd_service_restart(systemd, service_name)
    elif action == "status":
        return _cmd_service_status(systemd, service_name)
    elif action == "logs":
        return _cmd_service_logs(systemd, service_name, args)

    return 0


def _cmd_service_install(systemd: SystemdManager, config, install_path: Path) -> int:
    """安装服务"""
    if not install_path.exists():
        logger.error_print(f"OlivOS 目录不存在: {install_path}")
        logger.info_print("请先运行: olivos-cli init")
        return 1

    try:
        systemd.install_service(
            name="olivos",
            working_directory=install_path,
            config=config,
        )
        logger.success("服务已安装")
        logger.info_print("使用以下命令管理服务:")
        logger.info_print(f"  启用: olivos-cli service enable")
        logger.info_print(f"  启动: olivos-cli service start")
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_uninstall(systemd: SystemdManager, service_name: str) -> int:
    """卸载服务"""
    try:
        systemd.uninstall_service(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_enable(systemd: SystemdManager, service_name: str) -> int:
    """启用开机自启"""
    try:
        systemd.enable(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_disable(systemd: SystemdManager, service_name: str) -> int:
    """禁用开机自启"""
    try:
        systemd.disable(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_start(systemd: SystemdManager, service_name: str) -> int:
    """启动服务"""
    try:
        systemd.start(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_stop(systemd: SystemdManager, service_name: str) -> int:
    """停止服务"""
    try:
        systemd.stop(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_restart(systemd: SystemdManager, service_name: str) -> int:
    """重启服务"""
    try:
        systemd.restart(service_name)
        return 0
    except SystemdError as e:
        logger.error_print(str(e))
        return 1


def _cmd_service_status(systemd: SystemdManager, service_name: str) -> int:
    """查看服务状态"""
    status = systemd.status(service_name)

    from rich.console import Console
    from rich.table import Table

    console = logger.console

    table = Table(title=f"服务状态: {service_name}")
    table.add_column("项", style="cyan")
    table.add_column("值", style="green")

    table.add_row("已加载", "[green]是[/green]" if status["loaded"] else "[red]否[/red]")
    table.add_row("已启用", "[green]是[/green]" if status["enabled"] else "[red]否[/red]")
    table.add_row("运行中", "[green]是[/green]" if status["running"] else "[red]否[/red]")
    table.add_row("PID", str(status["pid"]) if status["pid"] else "-")

    console.print(table)
    return 0


def _cmd_service_logs(systemd: SystemdManager, service_name: str, args) -> int:
    """查看服务日志"""
    # 使用 journalctl 查看日志
    cmd = ["journalctl", "--user", "-u", f"{service_name}.service", "-n", str(args.lines)]

    if args.follow:
        cmd.append("-f")
        # 跟踪模式使用 subprocess 直接运行
        subprocess.call(cmd)
    else:
        # 非跟踪模式，捕获并显示
        result = subprocess.run(cmd, capture_output=False)
        return result.returncode

    return 0
