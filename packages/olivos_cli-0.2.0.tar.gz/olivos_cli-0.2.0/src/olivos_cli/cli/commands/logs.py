# -*- coding: utf-8 -*-
"""
logs 命令实现
"""

import subprocess
from pathlib import Path

from ...core import ConfigManager, get_logger

logger = get_logger()


def cmd_logs(config_manager: ConfigManager, args) -> int:
    """日志查看"""
    config = config_manager.config
    log_file = config.logging.expanded_log_file

    if not log_file.exists():
        logger.error_print(f"日志文件不存在: {log_file}")
        return 1

    if args.follow:
        # 实时跟踪
        cmd = ["tail", "-f", str(log_file)]
        subprocess.call(cmd)
    else:
        # 显示指定行数
        cmd = ["tail", "-n", str(args.lines), str(log_file)]
        result = subprocess.call(cmd)

    return 0
