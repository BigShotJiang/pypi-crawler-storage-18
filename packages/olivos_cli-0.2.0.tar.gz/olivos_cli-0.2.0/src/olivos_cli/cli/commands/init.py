# -*- coding: utf-8 -*-
"""
init 命令实现
"""

from pathlib import Path

from ...core import CONFIG_DIR, ConfigManager, get_logger
from ...core.exceptions import GitError, PackageError
from ...git import GitOperator
from ...package import get_package_manager

logger = get_logger()


def cmd_init(config_manager: ConfigManager, args) -> int:
    """初始化并安装 OlivOS"""
    # 确保配置目录存在
    config_manager.ensure_dirs()

    # 如果配置不存在，创建默认配置
    if not config_manager.config_path.exists():
        config_manager.init_default_config()
    else:
        config_manager.load()

    # 获取安装路径
    install_path = Path(args.path) if args.path else config_manager.config.git.expanded_install_path
    branch = args.branch or config_manager.config.git.branch
    use_mirror = args.mirror or config_manager.config.git.use_mirror

    logger.step(f"初始化 OlivOS 到: {install_path}")
    logger.step(f"分支: {branch}")
    if use_mirror:
        logger.info_print("使用镜像源")

    # Clone 仓库
    git = GitOperator()
    try:
        git.clone(
            repo_url=config_manager.config.git.repo_url,
            target_dir=install_path,
            branch=branch,
            mirror_url=config_manager.config.git.mirror_url,
            use_mirror=use_mirror,
            force=True,
        )
    except GitError as e:
        logger.error_print(str(e))
        return 1

    # 安装依赖
    if args.no_deps:
        logger.info_print("跳过依赖安装")
    else:
        logger.step("安装依赖...")

        # 选择依赖文件
        import platform

        if platform.system() == "Windows":
            requirements_file = install_path / "requirements310_win.txt"
        else:
            requirements_file = install_path / "requirements310.txt"

        if not requirements_file.exists():
            # 回退到通用依赖文件
            requirements_file = install_path / "requirements.txt"

        if requirements_file.exists():
            try:
                pkg_mgr = get_package_manager(
                    name=config_manager.config.package.manager,
                    auto_install=config_manager.config.package.auto_install,
                    index_url=config_manager.config.package.uv.index_url,
                )
                pkg_mgr.install(install_path, requirements_file)
            except PackageError as e:
                logger.error_print(str(e))
                return 1
        else:
            logger.warning_print(f"未找到依赖文件: {requirements_file.name}")

    # 创建配置目录
    (install_path / "conf").mkdir(parents=True, exist_ok=True)
    (install_path / "plugin").mkdir(parents=True, exist_ok=True)
    (install_path / "data").mkdir(parents=True, exist_ok=True)

    logger.success("OlivOS 初始化完成!")
    logger.info_print(f"安装路径: {install_path}")
    logger.info_print(f"配置文件: {install_path / 'conf'}")

    if not args.no_deps:
        logger.info_print("")
        logger.info_print("下一步:")
        logger.info_print("  1. 配置账号: olivos-cli account add")
        logger.info_print("  2. 安装服务: olivos-cli service install")
        logger.info_print("  3. 启动服务: olivos-cli service start")

    return 0
