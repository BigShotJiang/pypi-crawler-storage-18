# -*- coding: utf-8 -*-
"""
adapter 命令实现
"""

from ...core import SUPPORTED_ADAPTERS, ConfigManager, get_logger

logger = get_logger()


def cmd_adapter(config_manager: ConfigManager, args) -> int:
    """适配器管理"""
    action = args.adapt_action

    if not action:
        from ..main import OlivOSCLI

        cli = OlivOSCLI()
        subparsers = cli.parser._subparsers._actions[1]
        for action in subparsers.choices:
            if "adapter" in action:
                action.choices["adapter"].print_help()
                return 0
        return 1

    if action == "list":
        return _cmd_adapter_list()
    elif action == "enable":
        return _cmd_adapter_enable(args)
    elif action == "disable":
        return _cmd_adapter_disable(args)
    elif action == "config":
        return _cmd_adapter_config(args)

    return 0


def _cmd_adapter_list() -> int:
    """列出支持的适配器"""
    from rich.console import Console
    from rich.table import Table

    console = logger.console

    table = Table(title="支持的适配器")
    table.add_column("类型", style="cyan")
    table.add_column("名称", style="green")
    table.add_column("描述", style="yellow")

    for key, info in SUPPORTED_ADAPTERS.items():
        table.add_row(key, info["name"], info["description"])

    console.print(table)
    return 0


def _cmd_adapter_enable(args) -> int:
    """启用适配器"""
    logger.info_print(f"适配器 {args.name} 启用功能待实现")
    return 0


def _cmd_adapter_disable(args) -> int:
    """禁用适配器"""
    logger.info_print(f"适配器 {args.name} 禁用功能待实现")
    return 0


def _cmd_adapter_config(args) -> int:
    """配置适配器"""
    logger.info_print(f"适配器 {args.name} 配置功能待实现")
    return 0
