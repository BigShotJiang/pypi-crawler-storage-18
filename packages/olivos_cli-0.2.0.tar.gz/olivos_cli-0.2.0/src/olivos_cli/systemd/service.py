# -*- coding: utf-8 -*-
"""
systemd 服务管理
"""

import os
from pathlib import Path
from typing import Optional

from ..core.config import ConfigManager, expand_path
from ..core.exceptions import SystemdError
from ..core.logger import get_logger
from ..utils import run_command
from .template import ServiceTemplateData, generate_service_file

logger = get_logger()


class SystemdManager:
    """systemd 服务管理器"""

    def __init__(self, user_mode: bool = True, service_dir: Optional[Path] = None):
        self.user_mode = user_mode
        self.service_dir = service_dir or expand_path("~/.config/systemd/user")

    def _get_systemctl_cmd(self) -> list[str]:
        """获取 systemctl 命令"""
        cmd = ["systemctl"]
        if self.user_mode:
            cmd.append("--user")
        return cmd

    def _run_systemctl(self, args: list[str], check: bool = False) -> bool:
        """运行 systemctl 命令"""
        cmd = self._get_systemctl_cmd() + args
        result = run_command(cmd, check=check)
        return result.returncode == 0

    def install_service(
        self,
        name: str,
        working_directory: Path,
        config: Optional[ConfigManager] = None,
    ) -> Path:
        """安装服务

        Args:
            name: 服务名称
            working_directory: 工作目录
            config: 配置管理器

        Returns:
            service 文件路径
        """
        if config:
            cfg = config.config
            service_name = cfg.systemd.service_name
            template_data = ServiceTemplateData(
                instance_name=name,
                working_directory=str(working_directory),
                environment=cfg.systemd.runtime.environment,
                restart_policy=cfg.systemd.runtime.restart_policy,
                restart_sec=cfg.systemd.runtime.restart_sec,
            )
        else:
            service_name = "olivos-cli"
            template_data = ServiceTemplateData(
                instance_name=name,
                working_directory=str(working_directory),
            )

        # 生成 service 文件
        service_filename = f"{service_name}.service"
        service_path = self.service_dir / service_filename

        content = render_service_template(template_data)
        service_path.parent.mkdir(parents=True, exist_ok=True)
        service_path.write_text(content, encoding="utf-8")

        # 重载 systemd
        self._run_systemctl(["daemon-reload"])

        logger.success(f"服务已安装: {service_path}")
        return service_path

    def uninstall_service(self, name: str) -> bool:
        """卸载服务"""
        service_filename = f"{name}.service"
        service_path = self.service_dir / service_filename

        # 先停止并禁用
        self.stop(name)
        self.disable(name)

        # 删除文件
        if service_path.exists():
            service_path.unlink()
            self._run_systemctl(["daemon-reload"])
            logger.success(f"服务已卸载: {name}")
            return True

        return False

    def enable(self, name: str) -> bool:
        """启用开机自启"""
        service_filename = f"{name}.service"
        result = self._run_systemctl(["enable", service_filename])
        if result:
            logger.success(f"服务已启用: {name}")
        return result

    def disable(self, name: str) -> bool:
        """禁用开机自启"""
        service_filename = f"{name}.service"
        result = self._run_systemctl(["disable", service_filename])
        if result:
            logger.success(f"服务已禁用: {name}")
        return result

    def start(self, name: str) -> bool:
        """启动服务"""
        service_filename = f"{name}.service"
        result = self._run_systemctl(["start", service_filename])
        if result:
            logger.success(f"服务已启动: {name}")
        return result

    def stop(self, name: str) -> bool:
        """停止服务"""
        service_filename = f"{name}.service"
        result = self._run_systemctl(["stop", service_filename])
        if result:
            logger.success(f"服务已停止: {name}")
        return result

    def restart(self, name: str) -> bool:
        """重启服务"""
        service_filename = f"{name}.service"
        result = self._run_systemctl(["restart", service_filename])
        if result:
            logger.success(f"服务已重启: {name}")
        return result

    def status(self, name: str) -> dict:
        """获取服务状态"""
        service_filename = f"{name}.service"
        cmd = self._get_systemctl_cmd() + [
            "show",
            service_filename,
            "--property=LoadState,ActiveState,SubState,MainPID",
        ]
        result = run_command(cmd, capture_output=True)

        if result.returncode != 0:
            return {"loaded": False, "active": False, "running": False}

        status = {}
        for line in result.stdout.strip().split("\n"):
            if "=" in line:
                key, value = line.split("=", 1)
                status[key] = value

        loaded = status.get("LoadState", "not-found") == "loaded"
        active = status.get("ActiveState", "inactive") == "active"
        running = status.get("SubState", "dead") == "running"
        pid = int(status.get("MainPID", 0)) if status.get("MainPID", "0") != "0" else None

        return {
            "loaded": loaded,
            "active": active,
            "running": running,
            "enabled": self._is_enabled(name),
            "pid": pid,
        }

    def _is_enabled(self, name: str) -> bool:
        """检查服务是否已启用"""
        service_filename = f"{name}.service"
        cmd = self._get_systemctl_cmd() + [
            "is-enabled",
            service_filename,
        ]
        result = run_command(cmd, capture_output=True)
        return result.returncode == 0

    def logs(
        self,
        name: str,
        lines: int = 100,
        follow: bool = False,
    ) -> str:
        """获取服务日志"""
        service_filename = f"{name}.service"
        cmd = self._get_systemctl_cmd() + ["journalctl", "-u", service_filename]

        if follow:
            cmd.append("-f")
        else:
            cmd.extend(["-n", str(lines)])

        result = run_command(cmd, capture_output=False)
        return ""

    def get_service_path(self, name: str) -> Path:
        """获取 service 文件路径"""
        return self.service_dir / f"{name}.service"


# 导入 render_service_template 函数
from .template import render_service_template

__all__ = [
    "SystemdManager",
    "generate_service_file",
    "ServiceTemplateData",
    "render_service_template",
]
