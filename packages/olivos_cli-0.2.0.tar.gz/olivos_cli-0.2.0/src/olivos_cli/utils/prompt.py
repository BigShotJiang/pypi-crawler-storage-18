# -*- coding: utf-8 -*-
"""
交互式输入工具
"""

from typing import Any, Optional

from rich.prompt import Confirm, Prompt


def ask(
    question: str,
    default: Optional[str] = None,
    password: bool = False,
    choices: Optional[list[str]] = None,
) -> str:
    """询问用户输入

    Args:
        question: 问题文本
        default: 默认值
        password: 是否为密码
        choices: 可选值列表

    Returns:
        用户输入的值
    """
    return Prompt.ask(
        question,
        default=default,
        password=password,
        choices=choices,
    )


def confirm(question: str, default: bool = False) -> bool:
    """确认操作

    Args:
        question: 问题文本
        default: 默认值

    Returns:
        用户选择
    """
    return Confirm.ask(question, default=default)


def select(question: str, choices: list[str], default: Optional[int] = None) -> str:
    """从列表中选择

    Args:
        question: 问题文本
        choices: 选项列表
        default: 默认选项索引

    Returns:
        选择的值
    """
    from rich.console import Console

    console = Console()
    console.print(f"\n[bold cyan]{question}[/bold cyan]")

    for i, choice in enumerate(choices):
        marker = "[bold cyan]→[/bold cyan]" if i == default else " "
        console.print(f"  {marker} [{i}] {choice}")

    while True:
        try:
            answer = Prompt.ask(
                "请选择",
                default=str(default) if default is not None else None,
                console=console,
            )
            index = int(answer)
            if 0 <= index < len(choices):
                return choices[index]
            console.print("[red]无效的选择，请重试[/red]")
        except (ValueError, KeyboardInterrupt):
            console.print("[red]无效的输入，请输入数字[/red]")


__all__ = ["ask", "confirm", "select"]
