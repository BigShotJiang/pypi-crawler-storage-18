# -*- coding: utf-8 -*-
"""
工具函数模块
"""

import shutil
import subprocess
from typing import Optional


def run_command(
    cmd: list[str],
    cwd: Optional[str] = None,
    capture: bool = True,
    check: bool = False,
    env: Optional[dict[str, str]] = None,
) -> subprocess.CompletedProcess:
    """运行 shell 命令

    Args:
        cmd: 命令列表
        cwd: 工作目录
        capture: 是否捕获输出
        check: 是否检查返回码
        env: 环境变量

    Returns:
        subprocess.CompletedProcess
    """
    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=capture,
        text=True,
        check=check,
        env=env,
    )


def find_command(name: str) -> Optional[str]:
    """查找系统中的命令

    Args:
        name: 命令名称

    Returns:
        命令完整路径或 None
    """
    return shutil.which(name)


def check_command(name: str) -> bool:
    """检查命令是否存在

    Args:
        name: 命令名称

    Returns:
        是否存在
    """
    return find_command(name) is not None


def get_editor() -> str:
    """获取系统默认编辑器"""
    import os

    editor = os.environ.get("EDITOR")
    if editor:
        return editor

    for candidate in ["vim", "vi", "nano", "micro"]:
        if check_command(candidate):
            return candidate

    return "vi"


__all__ = [
    "run_command",
    "find_command",
    "check_command",
    "get_editor",
]
