# OlivOS-CLI

> OlivOS 框架的 CLI 命令行工具 - 用于构建、部署和管理 OlivOS 应用

[![Python Version](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-AGPLv3-green.svg)](./LICENSE)

## 特性

- **一键部署** - 自动克隆 OlivOS 仓库并安装依赖
- **包管理** - 支持 uv、pip、poetry 等多种包管理器
- **systemd 集成** - 自动生成和管理 systemd 服务
- **适配器管理** - 支持 14+ 种聊天平台适配器
- **账号管理** - 交互式添加、配置和管理多个账号
- **镜像源支持** - 内置 ghproxy 镜像加速
- **分支管理** - 灵活切换不同分支和版本
- **健康检查** - 实时监控服务状态

## 支持的适配器

| 平台 | 适配器 | 说明 |
|------|--------|------|
| QQ | onebot, onebot12 | OneBot V11/V12 协议 |
| Telegram | telegram | Telegram Bot |
| Discord | discord | Discord Bot |
| QQ 频道 | qqguild, qqguildv2 | QQ 频道 |
| 钉钉 | dingtalk | 钉钉机器人 |
| 微信 | cwcb | ComWeChatBot |
| 哔哩哔哩 | bililive | 直播弹幕 |
| KOOK | kaiheila | 开黑啦 |
| DoDo | dodo | DoDo 社区 |
| Fanbook | fanbook | Fanbook |
| 米游社 | mhyvila | 米游社大别野 |

## 安装

### 使用 uv (推荐)

```bash
uv pip install olivos-cli
```

### 使用 pip

```bash
pip install olivos-cli
```

### 从源码安装

```bash
git clone https://github.com/HsiangNianian/olivos-cli.git
cd olivos-cli
pip install -e .
```

## 快速开始

### 1. 初始化 OlivOS

```bash
olivos-cli init
```

这将自动：
- 克隆 OlivOS 仓库到 `~/.local/share/olivos`
- 安装 Python 依赖
- 创建配置目录

### 2. 添加账号

```bash
olivos-cli account add --adapter onebot
```

按提示输入账号信息。

### 3. 安装并启动服务

```bash
olivos-cli service install
olivos-cli service enable
olivos-cli service start
```

## 命令参考

### 命令缩写

所有命令都支持缩写形式：

| 完整命令 | 缩写 |
|---------|------|
| `olivos-cli init` | `olivos-cli i` |
| `olivos-cli git` | `olivos-cli g` |
| `olivos-cli git pull` | `olivos-cli g up` |
| `olivos-cli package` | `olivos-cli p` / `pkg` |
| `olivos-cli service` | `olivos-cli s` / `svc` |
| `olivos-cli adapter` | `olivos-cli a` / `adapt` |
| `olivos-cli account` | `olivos-cli acc` |
| `olivos-cli config` | `olivos-cli c` / `cfg` |
| `olivos-cli status` | `olivos-cli st` |

### init - 初始化

```bash
olivos-cli init [OPTIONS]
```

| 选项 | 说明 |
|------|------|
| `--path <PATH>` | 安装路径 |
| `--branch <NAME>` | Git 分支 (默认: main) |
| `--mirror` | 使用镜像源 |
| `--minimal` | 最小化安装 |
| `--no-deps` | 跳过依赖安装 |

### git - Git 管理

```bash
olivos-cli git <ACTION>
```

| 动作 | 说明 |
|------|------|
| `clone` | 克隆仓库 |
| `pull` / `up` | 拉取更新 |
| `checkout` / `co` | 切换分支/提交 |
| `status` / `st` | 查看状态 |

```bash
# 克隆指定分支
olivos-cli g clone --branch develop

# 拉取更新
olivos-cli g pull

# 切换到指定提交
olivos-cli g co abc1234
```

### package - 包管理

```bash
olivos-cli package <ACTION>
```

| 动作 | 说明 |
|------|------|
| `install` / `i` | 安装依赖 |
| `update` / `up` | 更新依赖 |
| `list` / `ls` | 列出已安装的包 |

```bash
# 安装全部依赖
olivos-cli pkg install

# 安装指定包
olivos-cli pkg install requests

# 更新依赖
olivos-cli pkg update
```

### service - 服务管理

```bash
olivos-cli service <ACTION>
```

| 动作 | 说明 |
|------|------|
| `install` | 安装 systemd 服务 |
| `uninstall` | 卸载服务 |
| `enable` | 启用开机自启 |
| `disable` | 禁用开机自启 |
| `start` | 启动服务 |
| `stop` | 停止服务 |
| `restart` / `r` | 重启服务 |
| `status` / `st` | 查看服务状态 |
| `logs` / `log` | 查看服务日志 |

```bash
# 安装服务
olivos-cli s install

# 启动服务
olivos-cli s start

# 查看日志
olivos-cli s logs -f

# 查看状态
olivos-cli s st
```

### adapter - 适配器管理

```bash
olivos-cli adapter <ACTION>
```

| 动作 | 说明 |
|------|------|
| `list` / `ls` | 列出支持的适配器 |
| `enable <NAME>` | 启用适配器 |
| `disable <NAME>` | 禁用适配器 |
| `config <NAME>` | 配置适配器 |

```bash
# 列出所有适配器
olivos-cli a ls

# 配置 OneBot 适配器
olivos-cli a cfg onebot --get host
olivos-cli a cfg onebot --set "host=127.0.0.1"
```

### account - 账号管理

```bash
olivos-cli account <ACTION>
```

| 动作 | 说明 |
|------|------|
| `list` / `ls` | 列出所有账号 |
| `add` | 添加账号 |
| `remove` / `rm` | 删除账号 |
| `show` | 显示账号详情 |

```bash
# 交互式添加账号
olivos-cli acc add

# 非交互模式添加
olivos-cli acc add --adapter onebot --id 123456 --host 127.0.0.1 --port 5700

# 列出账号
olivos-cli acc ls

# 删除账号
olivos-cli acc rm 123456
```

### config - 配置管理

```bash
olivos-cli config <ACTION>
```

| 动作 | 说明 |
|------|------|
| `show` | 显示配置 |
| `get <KEY>` | 获取配置项 |
| `set <KEY> <VALUE>` | 设置配置项 |
| `unset <KEY>` | 删除配置项 |
| `edit` | 编辑配置文件 |
| `reset` | 重置为默认配置 |

```bash
# 显示配置
olivos-cli c show

# 获取配置项
olivos-cli c get git.branch

# 设置配置项
olivos-cli c set git.use_mirror true

# 编辑配置文件
olivos-cli c edit
```

### logs - 日志查看

```bash
olivos-cli logs [OPTIONS]
```

| 选项 | 说明 |
|------|------|
| `-n, --lines <N>` | 显示行数 (默认: 100) |
| `-f, --follow` | 实时跟踪 |
| `--pattern <PATTERN>` | 过滤模式 |

```bash
# 查看最近 100 行日志
olivos-cli log

# 实时跟踪
olivos-cli log -f

# 查看 500 行
olivos-cli log -n 500
```

### status - 状态监控

```bash
olivos-cli status [OPTIONS]
```

| 选项 | 说明 |
|------|------|
| `--health` | 健康检查 |
| `--watch, -w` | 实时监控 |

```bash
# 查看状态
olivos-cli st

# 健康检查
olivos-cli st --health

# 实时监控
olivos-cli st -w
```

### run - 直接运行

```bash
olivos-cli run [OPTIONS]
```

| 选项 | 说明 |
|------|------|
| `--dev` | 开发模式 |
| `--debug` | 调试模式 |

```bash
# 前台运行
olivos-cli run

# 开发模式
olivos-cli run --dev
```

## 配置文件

配置文件位于 `~/.config/olivos-cli/config.toml`：

```toml
[cli]
verbose = false
log_level = "INFO"

[git]
repo_url = "https://github.com/OlivOS-Team/OlivOS.git"
mirror_url = "https://mirror.ghproxy.com/https://github.com/OlivOS-Team/OlivOS.git"
use_mirror = false
install_path = "~/.local/share/olivos"
branch = "main"

[package]
manager = "uv"
auto_install = true

[systemd]
user_mode = true
service_dir = "~/.config/systemd/user"
service_name = "olivos-cli"
```

## 目录结构

```
~/.local/share/olivos/
├── OlivOS/           # OlivOS 核心代码
├── conf/             # 配置文件
│   ├── basic.json
│   ├── config.json
│   └── account.json
├── plugin/           # 插件目录
└── data/             # 数据目录
```

## 开发

### 环境要求

- Python 3.11+
- uv (推荐) 或 pip

### 开发安装

```bash
git clone https://github.com/HsiangNianian/olivos-cli.git
cd olivos-cli
uv pip install -e ".[dev]"
```

### 运行测试

```bash
# 使用 PYTHONPATH 直接运行
PYTHONPATH=src python -m olivos_cli --help
```

### 项目结构

```
olivos-cli/
├── src/olivos_cli/
│   ├── cli/           # CLI 命令层
│   ├── core/          # 核心逻辑
│   ├── git/           # Git 操作
│   ├── package/       # 包管理
│   ├── systemd/       # systemd 集成
│   ├── olivos/        # OlivOS 交互
│   ├── models/        # 数据模型
│   └── utils/         # 工具函数
├── templates/         # Jinja2 模板
└── pyproject.toml
```

## 相关链接

- [OlivOS 官方仓库](https://github.com/OlivOS-Team/OlivOS)
- [OlivOS 文档](https://doc.olivos.wiki/)
- [OlivOS 论坛](https://forum.olivos.run/)

## 许可证

本项目采用 AGPLv3 协议开源。详见 [LICENSE](./LICENSE) 文件。

---

Made with ❤️ by [HsiangNianian](https://github.com/HsiangNianian)
