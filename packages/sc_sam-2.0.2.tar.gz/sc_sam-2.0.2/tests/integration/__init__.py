"""Integration tests for samalg."""
