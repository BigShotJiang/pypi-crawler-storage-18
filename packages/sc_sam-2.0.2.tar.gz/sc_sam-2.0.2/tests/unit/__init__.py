"""Unit tests for samalg."""
