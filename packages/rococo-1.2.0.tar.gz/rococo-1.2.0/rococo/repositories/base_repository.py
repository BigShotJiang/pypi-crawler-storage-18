"""
base repository for rococo
"""
import json
from uuid import UUID
from typing import Any, Dict, List, Type, Union
from rococo.data.base import DbAdapter
from rococo.messaging.base import MessageAdapter
from rococo.models.versioned_model import BaseModel, VersionedModel


class BaseRepository:
    """
    BaseRepository class
    """

    def __init__(
        self,
        adapter: DbAdapter,
        model: Type[BaseModel],
        message_adapter: MessageAdapter,
        queue_name: str = 'placeholder',
        user_id: UUID = None
    ):
        self.adapter = adapter
        self.message_adapter = message_adapter
        self.queue_name = queue_name
        self.model = model
        self.table_name = model.__name__.lower()
        self.user_id = user_id
        # Don't save calculated fields (properties) to database by default
        self.save_calculated_fields = False
        # Enable auditing by default (only applies to VersionedModel)
        self.use_audit_table = True
        # Ttl field for delete() method
        self.ttl_field = None
        # Ttl (in minutes) for deleted records
        self.ttl_minutes = 0

    def _is_versioned_model(self) -> bool:
        """Check if the repository's model is a VersionedModel (has versioning support)."""
        return issubclass(self.model, VersionedModel)

    def _execute_within_context(
        self,
        func,
        *args,
        **kwargs
    ):
        """Utility method to execute adapter methods within the context manager."""
        with self.adapter:
            return func(*args, **kwargs)

    def _process_data_before_save(
        self,
        instance: BaseModel
    ) -> Dict[str, Any]:
        """Convert a BaseModel instance to a data dictionary for the adapter."""
        instance.prepare_for_save(changed_by_id=self.user_id)
        return instance.as_dict(
            convert_datetime_to_iso_string=True,
            export_properties=self.save_calculated_fields
        )

    def _process_data_from_db(
        self,
        data: Any
    ):
        """Hook to process raw DB data (can be overridden by subclass)."""
        pass

    def get_one(
        self,
        conditions: Dict[str, Any],
        fetch_related: List[str] = None
    ) -> Union[BaseModel, None]:
        """
        Fetches a single record from the specified table based on given conditions.

        :param conditions: filter conditions
        :param fetch_related: list of related fields to fetch
        :return: a BaseModel instance if found, None otherwise
        """
        data = self._execute_within_context(
            self.adapter.get_one,
            self.table_name,
            conditions,
            fetch_related=fetch_related
        )

        self._process_data_from_db(data)

        if not data:
            return None
        return self.model.from_dict(data)

    def _validate_int(
        self,
        value: Any,
        context: str = "value",
        min_val: int = None,
        max_val: int = None
    ) -> int:
        """
        Validate and convert to integer with optional range check.
        This prevents injection attacks in LIMIT, OFFSET, and other numeric contexts
        by ensuring the value is actually an integer, not a string containing SQL code.
        Args:
            value: The value to validate and convert
            context: Description of what this value represents (for error messages)
            min_val: Minimum allowed value (inclusive), or None for no minimum
            max_val: Maximum allowed value (inclusive), or None for no maximum
        Returns:
            The validated integer value, or None if value is None and allow_none=True
        Raises:
            ValueError: If validation fails
        Examples:
            >>> SqlValidator.validate_integer(10, "limit")
            10
            >>> SqlValidator.validate_integer("20", "offset", min_val=0)
            20
            >>> SqlValidator.validate_integer("10; DROP TABLE", "limit")
            ValueError: Invalid limit: must be an integer
            >>> SqlValidator.validate_integer(1000000, "limit", max_val=10000)
            ValueError: Invalid limit: 1000000 exceeds maximum 10000
        """
        # Allow None if specified
        if value is None:
            return None

        # Convert to integer (will raise ValueError if not convertible)
        try:
            int_value = int(value)
        except (ValueError, TypeError) as e:
            raise ValueError(
                f"Invalid {context}: must be an integer, got {type(value).__name__} '{value}'"
            )

        # Check minimum value
        if min_val is not None and int_value < min_val:
            raise ValueError(
                f"Invalid {context}: {int_value} is less than minimum {min_val}"
            )

        # Check maximum value
        if max_val is not None and int_value > max_val:
            raise ValueError(
                f"Invalid {context}: {int_value} exceeds maximum {max_val}"
            )

        return int_value

    def get_many(
        self,
        conditions: Dict[str, Any] = None,
        sort: List[tuple] = None,
        limit: int = 100,
        offset: int = 0,
        fetch_related: List[str] = None
    ) -> List[BaseModel]:
        """
        Fetches multiple records from the specified table based on given conditions.

        :param conditions: filter conditions
        :param sort: sort order
        :param limit: maximum number of records to return
        :param offset: number of records to skip before returning results
        :param fetch_related: list of related fields to fetch
        :return: list of BaseModel instances
        """

        limit = self._validate_int(limit, "limit", 0, 100000)
        offset = self._validate_int(offset, "offset", 0)

        records = self._execute_within_context(
            self.adapter.get_many,
            self.table_name,
            conditions,
            sort,
            limit,
            offset,
            fetch_related=fetch_related
        )

        if isinstance(records, dict):
            records = [records]

        self._process_data_from_db(records)

        return [self.model.from_dict(record) for record in records]

    def get_count(
        self,
        collection_name: str,
        index: str,
        query: Dict[str, Any]
    ) -> int:
        """
        Retrieves the count of records in a specified collection that match the given query parameters
        and index.

        Args:
            collection_name (str): The name of the collection to query.
            index (str): The name of the index to use for the query. hint actually work for MongoDB and ignore by other DBs
            query (Dict[str, Any], optional): Additional query parameters to filter the results.

        Returns:
            int: The count of matching records.
        """
        # The 'query' parameter directly represents the conditions for the count.
        # If an 'active' filter is needed, it should be included in the 'query' argument by the caller.
        db_conditions = query

        adapter_options: Dict[str, Any] = {}
        if index:
            adapter_options['hint'] = index

        return self._execute_within_context(
            self.adapter.get_count,
            collection_name,
            db_conditions,
            options=adapter_options if adapter_options else None
        )

    def save(
        self,
        instance: BaseModel,
        send_message: bool = False
    ) -> BaseModel:
        """
        Saves a BaseModel instance to the database.

        :param instance: The BaseModel instance to save.
        :param send_message: Whether to send a message to the message queue after saving. Defaults to False.
        :return: The saved BaseModel instance.
        """
        data = self._process_data_before_save(instance)
        
        with self.adapter:
            # Only use audit table for VersionedModel instances
            if self._is_versioned_model() and self.use_audit_table:
                move_entity_query = self.adapter.get_move_entity_to_audit_table_query(
                    self.table_name, instance.entity_id)
                save_entity_query = self.adapter.get_save_query(
                    self.table_name, data)
                self.adapter.run_transaction(
                    [move_entity_query, save_entity_query])
            else:
                # For non-versioned models (BaseModel), just save without audit
                save_entity_query = self.adapter.get_save_query(
                    self.table_name, data)
                self.adapter.run_transaction([save_entity_query])
        
        if send_message:
            # This assumes that the instance is now in post-saved state with all the new DB updates
            message = json.dumps(instance.as_dict(
                convert_datetime_to_iso_string=True))
            self.message_adapter.send_message(self.queue_name, message)

        return instance

    def delete(
        self,
        instance: BaseModel
    ) -> BaseModel:
        """
        Deletes a model instance from the database.

        For VersionedModel: Performs a soft delete by setting the active flag to False.
        For BaseModel (non-versioned): Performs a hard delete, permanently removing the record.

        :param instance: The model instance to delete.
        :return: The deleted model instance.
        """
        if self._is_versioned_model():
            # Soft delete for versioned models
            instance.active = False
            return self.save(instance)
        else:
            # Hard delete for non-versioned models
            with self.adapter:
                self.adapter.hard_delete(self.table_name, instance.entity_id)
            return instance