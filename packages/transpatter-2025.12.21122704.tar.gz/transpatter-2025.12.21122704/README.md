# transpatter
[![PyPI version](https://badge.fury.io/py/transpatter.svg)](https://badge.fury.io/py/transpatter)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/transpatter)](https://pepy.tech/project/transpatter)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


transpatter is a Python package that leverages pattern matching with language models to generate structured summaries or insights from user-submitted texts related to transportation topics, infrastructure issues, or system problems. It processes your input text and provides clear, formatted output highlighting key points, suggested improvements, or concise summaries. This tool is designed to assist users in quickly understanding complex textual descriptions without handling media files.

## Installation

Install the package via pip:

```bash
pip install transpatter
```

## Usage

Here's a basic example of how to use transpatter:

```python
from transpatter import transpatter

user_input = "Describe the current issues with the train map system and suggestions for improvement."

response = transpatter(user_input)
print(response)
```

You can also pass your own language model instance. The default uses `ChatLLM7` from `langchain_llm7`, but you are free to specify other models for more customization.

### Examples of different LLM integrations:

Using OpenAI's GPT:

```python
from langchain_openai import ChatOpenAI
from transpatter import transpatter

llm = ChatOpenAI()
response = transpatter(user_input, llm=llm)
```

Using Anthropic's Claude:

```python
from langchain_anthropic import ChatAnthropic
from transpatter import transpatter

llm = ChatAnthropic()
response = transpatter(user_input, llm=llm)
```

Using Google's Generative AI:

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from transpatter import transpatter

llm = ChatGoogleGenerativeAI()
response = transpatter(user_input, llm=llm)
```

## Configuration

- The default API key for `ChatLLM7` can be set via the environment variable `LLM7_API_KEY`.
- For higher rate limits or custom API keys, pass your key directly:

```python
response = transpatter(user_input, api_key="your_api_key")
```

- Alternatively, provide your own language model instance for maximum flexibility:

```python
response = transpatter(user_input, llm=your_custom_llm)
```

## Notes

- `transpatter` is built for flexibility; it uses `langchain_llm7` by default but can integrate with other LLM providers.
- The package is ideal for generating structured summaries of complex transportation/system descriptions, aiding analysis and decision-making.

## Support and Issues

- For issues or feature requests, please visit the GitHub issues page: [https://github.com/yourusername/transpatter/issues](https://github.com/yourusername/transpatter/issues)

## Author

- **Eugene Evstafev**  
  Email: hi@euegne.plus  
  GitHub: [chigwell](https://github.com/chigwell)