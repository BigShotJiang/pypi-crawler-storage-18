# News Summarizer
[![PyPI version](https://badge.fury.io/py/news-summarizer.svg)](https://badge.fury.io/py/news-summarizer)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/news-summarizer)](https://pepy.tech/project/news-summarizer)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package designed to facilitate the generation of structured summaries and insights from user-provided news headlines or short articles. It uses pattern matching to ensure responses are consistently formatted, enabling quick extraction of key information such as main issues, affected regions, or sentiment.

## Features

- Structured summaries from news headlines or short articles
- Pattern matching for consistent response formatting
- Extraction of key information (main issues, affected regions, sentiment)
- Support for multiple LLM providers
- Easy integration with LangChain

## Installation

```bash
pip install news_summarizer
```

## Usage

### Basic Usage

```python
from news_summarizer import news_summarizer

user_input = "Your news headline or short article here"
response = news_summarizer(user_input)
print(response)
```

### Using a Custom LLM

You can use any LLM compatible with LangChain. Here are examples with different providers:

#### OpenAI

```python
from langchain_openai import ChatOpenAI
from news_summarizer import news_summarizer

llm = ChatOpenAI()
response = news_summarizer(user_input, llm=llm)
print(response)
```

#### Anthropic

```python
from langchain_anthropic import ChatAnthropic
from news_summarizer import news_summarizer

llm = ChatAnthropic()
response = news_summarizer(user_input, llm=llm)
print(response)
```

#### Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from news_summarizer import news_summarizer

llm = ChatGoogleGenerativeAI()
response = news_summarizer(user_input, llm=llm)
print(response)
```

### Using LLM7 with API Key

```python
from news_summarizer import news_summarizer

user_input = "Your news headline or short article here"
api_key = "your_api_key_here"
response = news_summarizer(user_input, api_key=api_key)
print(response)
```

## Parameters

- `user_input` (str): The user input text to process
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Default LLM

The package uses `ChatLLM7` from [langchain_llm7](https://pypi.org/project/langchain-llm7/) by default. You can safely pass your own LLM instance if you want to use another LLM.

## Rate Limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits for LLM7, you can pass your own API key via the environment variable `LLM7_API_KEY` or directly via the `api_key` parameter. You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/news-summarizer/issues).

## Author

- **Eugene Evstafev**
- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)