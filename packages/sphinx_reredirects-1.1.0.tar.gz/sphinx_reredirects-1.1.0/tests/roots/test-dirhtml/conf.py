extensions = ["sphinx_reredirects"]
