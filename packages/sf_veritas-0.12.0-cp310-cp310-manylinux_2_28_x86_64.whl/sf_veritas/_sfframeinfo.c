// sf_veritas/_sfframeinfo.c
// Ultra-fast frame introspection for network hop capture
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <string.h>

// Check if a path is user code (not stdlib/site-packages)
static int is_user_code(const char *path) {
    if (!path || path[0] == '<') return 0;

    // Check for common non-user-code patterns
    if (strstr(path, "site-packages")) return 0;
    if (strstr(path, "dist-packages")) return 0;
    if (strstr(path, "/lib/python")) return 0;
    if (strstr(path, "\\lib\\python")) return 0;
    if (strstr(path, "sf-veritas")) return 0;

    return 1;
}

// Extract code info from a function object
// Returns: (filename: str, lineno: int, name: str, is_user: bool) or None
static PyObject *py_get_code_info(PyObject *self, PyObject *args) {
    PyObject *func_obj;

    if (!PyArg_ParseTuple(args, "O", &func_obj)) {
        Py_RETURN_NONE;
    }

    // Get __code__ attribute
    PyObject *code_obj = PyObject_GetAttrString(func_obj, "__code__");
    if (!code_obj) {
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Get filename
    PyObject *filename_obj = PyObject_GetAttrString(code_obj, "co_filename");
    if (!filename_obj) {
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    const char *filename = PyUnicode_AsUTF8(filename_obj);
    if (!filename) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Check if user code early - fast path
    int user = is_user_code(filename);
    if (!user) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        Py_RETURN_NONE;  // Not user code, return None immediately
    }

    // Get line number
    PyObject *lineno_obj = PyObject_GetAttrString(code_obj, "co_firstlineno");
    if (!lineno_obj) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    long lineno = PyLong_AsLong(lineno_obj);
    Py_DECREF(lineno_obj);

    // Get function name
    PyObject *name_obj = PyObject_GetAttrString(func_obj, "__name__");
    if (!name_obj) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Build result tuple: (filename, lineno, name, is_user)
    PyObject *result = PyTuple_Pack(4,
        filename_obj,
        PyLong_FromLong(lineno),
        name_obj,
        Py_True
    );

    Py_DECREF(filename_obj);
    Py_DECREF(code_obj);
    Py_DECREF(name_obj);

    return result;
}

// Extract info from a frame object (for profilers)
// Returns: (filename: str, lineno: int, name: str, is_user: bool) or None
static PyObject *py_get_frame_info(PyObject *self, PyObject *args) {
    PyObject *frame_obj;

    if (!PyArg_ParseTuple(args, "O", &frame_obj)) {
        Py_RETURN_NONE;
    }

    // Get f_code
    PyObject *code_obj = PyObject_GetAttrString(frame_obj, "f_code");
    if (!code_obj) {
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Get filename
    PyObject *filename_obj = PyObject_GetAttrString(code_obj, "co_filename");
    if (!filename_obj) {
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    const char *filename = PyUnicode_AsUTF8(filename_obj);
    if (!filename) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Check if user code early
    int user = is_user_code(filename);
    if (!user) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        Py_RETURN_NONE;
    }

    // Get line number from frame
    PyObject *lineno_obj = PyObject_GetAttrString(frame_obj, "f_lineno");
    if (!lineno_obj) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    long lineno = PyLong_AsLong(lineno_obj);
    Py_DECREF(lineno_obj);

    // Get name from code object
    PyObject *name_obj = PyObject_GetAttrString(code_obj, "co_name");
    if (!name_obj) {
        Py_DECREF(filename_obj);
        Py_DECREF(code_obj);
        PyErr_Clear();
        Py_RETURN_NONE;
    }

    // Build result tuple
    PyObject *result = PyTuple_Pack(4,
        filename_obj,
        PyLong_FromLong(lineno),
        name_obj,
        Py_True
    );

    Py_DECREF(filename_obj);
    Py_DECREF(code_obj);
    Py_DECREF(name_obj);

    return result;
}

// Quick check if function is user code
static PyObject *py_is_user_code_func(PyObject *self, PyObject *args) {
    PyObject *func_obj;

    if (!PyArg_ParseTuple(args, "O", &func_obj)) {
        Py_RETURN_FALSE;
    }

    PyObject *code_obj = PyObject_GetAttrString(func_obj, "__code__");
    if (!code_obj) {
        PyErr_Clear();
        Py_RETURN_FALSE;
    }

    PyObject *filename_obj = PyObject_GetAttrString(code_obj, "co_filename");
    Py_DECREF(code_obj);

    if (!filename_obj) {
        PyErr_Clear();
        Py_RETURN_FALSE;
    }

    const char *filename = PyUnicode_AsUTF8(filename_obj);
    Py_DECREF(filename_obj);

    if (!filename) {
        PyErr_Clear();
        Py_RETURN_FALSE;
    }

    return is_user_code(filename) ? Py_True : Py_False;
}

// Module methods
static PyMethodDef SFFrameInfoMethods[] = {
    {"get_code_info", py_get_code_info, METH_VARARGS,
     "Extract (filename, lineno, name, is_user) from function. Returns None if not user code."},
    {"get_frame_info", py_get_frame_info, METH_VARARGS,
     "Extract (filename, lineno, name, is_user) from frame. Returns None if not user code."},
    {"is_user_code_func", py_is_user_code_func, METH_VARARGS,
     "Quick check if function is user code."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef sfframeinfomodule = {
    PyModuleDef_HEAD_INIT,
    "_sfframeinfo",
    "Ultra-fast frame introspection for network hop capture",
    -1,
    SFFrameInfoMethods
};

PyMODINIT_FUNC PyInit__sfframeinfo(void) {
    return PyModule_Create(&sfframeinfomodule);
}
