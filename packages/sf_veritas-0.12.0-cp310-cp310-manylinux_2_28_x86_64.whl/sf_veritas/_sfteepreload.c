// sf_tee_preload.c
// Ultra-low overhead network tee for HTTP/HTTPS using LD_PRELOAD.
// Hooks: send/recv/sendmsg/recvmsg and SSL_write/SSL_read (and *_ex).
// Captures request/response headers + bounded body samples, enqueues to a ring,
// and posts to a GraphQL sink on a background thread (raw HTTP).
//
// Build (optimized for minimal PLT/GOT overhead and maximum inlining):
//   gcc -O3 -fPIC -shared -fvisibility=hidden -fno-plt -fno-semantic-interposition \
//       -fomit-frame-pointer -fno-asynchronous-unwind-tables -march=native \
//       -ffunction-sections -fdata-sections -Wl,--gc-sections \
//       -o libsfnettee.so sf_tee_preload.c -ldl -lpthread -luuid
//
// Use:
//   export SAILFISH_GRAPHQL_ENDPOINT="https://.../graphql/"
//   export SAILFISH_API_KEY="..."
//   export SFT_SERVICE_UUID="..."
//   export SFT_LIBRARY="sf-veritas"
//   export SFT_VERSION="1.0.0"
//   LD_PRELOAD=./libsfnettee.so python app.py

#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <sys/uio.h>  // sendmsg()/iovec on all platforms
#include <signal.h>
#include <execinfo.h>
#if defined(__linux__)
#include <ucontext.h>
#endif
#if defined(__linux__)
#include <elf.h>
#include <link.h>
#endif
#include <sys/mman.h>
#include <unistd.h>
#include "sf_tls.h"

#ifndef SF_ENABLE_STATS_WATCHDOG
#define SF_ENABLE_STATS_WATCHDOG 0
#endif
// --- minimal "curl-like" typedefs kept from your version (we're not linking libcurl here)
typedef void CURL;
typedef void curl_slist;
typedef int CURLoption;
typedef int CURLcode;

#include <openssl/ssl.h>
#include <openssl/bio.h>

static void segv_handler(int sig, siginfo_t *info, void *ucontext);
static void install_debug_signal_handlers(void);
static inline void ensure_ssl_bound_and_direction(SSL *ssl);

static inline int ssl_get_fd_safe(SSL *ssl);
typedef struct conn_state conn_state_t;

#define SF_DEBUG 1

#define DEBUG_LOG(...) do { \
    if (SF_DEBUG) { \
        fprintf(stderr, __VA_ARGS__); \
        fflush(stderr); \
    } \
} while(0)

// ========= Signal-safe buffer helpers (no allocation, no stdio) =========
static inline size_t buf_append(char *buf, size_t cap, size_t off, const char *text) {
    if (!text) return off;
    while (*text && off + 1 < cap) {
        buf[off++] = *text++;
    }
    return off;
}

static inline size_t buf_append_uint(char *buf, size_t cap, size_t off, uint64_t value) {
    char tmp[21];
    size_t idx = 0;
    do {
        tmp[idx++] = (char)('0' + (value % 10));
        value /= 10;
    } while (value && idx < sizeof(tmp));
    while (idx && off + 1 < cap) {
        buf[off++] = tmp[--idx];
    }
    return off;
}

static inline size_t buf_append_hex(char *buf, size_t cap, size_t off, uint64_t value) {
    static const char hex[] = "0123456789abcdef";
    char tmp[17];
    size_t idx = 0;
    do {
        tmp[idx++] = hex[value & 0xF];
        value >>= 4;
    } while (value && idx < sizeof(tmp));
    if (idx == 0 && off + 2 < cap) {
        buf[off++] = '0';
    }
    while (idx && off + 1 < cap) {
        buf[off++] = tmp[--idx];
    }
    return off;
}

// UUID generation for child trace_ids
// Try to include uuid.h, but if not available, we'll generate a simple UUID
#ifdef __APPLE__
#include <uuid/uuid.h>
#define HAVE_UUID 1
#elif defined(__linux__)
#include <uuid/uuid.h>
#define HAVE_UUID 1
#else
#define HAVE_UUID 0
#endif

// Python.h - but we'll load symbols dynamically, not link
// Define minimal types/constants we need without full Python.h
// This allows the library to compile and load even if Python isn't available
typedef struct _object PyObject;
typedef struct _ts PyThreadState;
typedef enum {PyGILState_LOCKED, PyGILState_UNLOCKED} PyGILState_STATE;

// ============================================================================
// ULTRA-FAST TLS for parent trace ID + child ID generation (NO PYTHON!)
// ============================================================================
// This provides < 5ns overhead on hot path by avoiding Python/GIL entirely
// Python wrappers set the TLS pointer before making requests via ctypes

__attribute__((visibility("default"))) __thread const char *sf_tls_parent_trace_id = NULL;

// Setter/getter exported for Python shim (ctypes/CFFI)
__attribute__((visibility("default")))
void sf_set_parent_trace_id_tls(const char *s) {
    if (SF_DEBUG && s) {
        size_t len = strlen(s);
        if (len > 512) {
            fprintf(stderr, "[SF_DEBUG _sfteepreload] sf_set_parent_trace_id_tls: len=%zu (possible anomaly)\n", len);
            fflush(stderr);
        }
    }
    // We only store the pointer; Python shim ensures the lifetime covers the request
    sf_tls_parent_trace_id = s;
}

__attribute__((visibility("default")))
const char* sf_get_parent_trace_id_tls(void) {
    return sf_tls_parent_trace_id;
}

// Fast UUID4 generation (uses libuuid on Linux/macOS, fallback to /dev/urandom)
// ULTRA-FAST: Thread-local cached /dev/urandom fd (saves 5-15μs per UUID)
// Open once per thread, reuse forever - avoids open/close syscall overhead
__thread int g_urandom_fd = -1;

// Forward declaration for TLS cleanup helper (defined later, used in hot paths)
static inline void ensure_tls_cleanup_registered(void);

// Slow UUID generation (original function, called by background thread)
static inline void uuid4_string_slow(char out36[37]) {
    // CRITICAL FIX #2: Ensure TLS destructor is registered BEFORE opening /dev/urandom
    // This guarantees the FD will be closed when the thread exits (prevents FD leak!)
    ensure_tls_cleanup_registered();

#if HAVE_UUID
    uuid_t u;
    uuid_generate_random(u);
    uuid_unparse_lower(u, out36);
#else
    // ULTRA-FAST: Use cached /dev/urandom fd (10-20μs vs 20-30μs with open/close)
    unsigned char r[16];

    // Open once per thread and cache (huge savings!)
    if (__builtin_expect(g_urandom_fd == -1, 0)) {
        g_urandom_fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
        if (g_urandom_fd == -1) {
            // open failed - fallback to time-based randomness
            uint64_t t = (uint64_t)time(NULL) ^ (uint64_t)clock();
            memcpy(r, &t, sizeof(t));
            memcpy(r + sizeof(t), &t, sizeof(t));
            goto format_uuid;
        }
    }

    // Fast path: read from cached fd (no open/close overhead!)
    ssize_t n = read(g_urandom_fd, r, 16);
    if (__builtin_expect(n != 16, 0)) {
        // read failed - fallback to time-based randomness
        uint64_t t = (uint64_t)time(NULL) ^ (uint64_t)clock();
        memcpy(r, &t, sizeof(t));
        memcpy(r + sizeof(t), &t, sizeof(t));
    }

format_uuid:
    r[6] = (r[6] & 0x0F) | 0x40;  // version 4
    r[8] = (r[8] & 0x3F) | 0x80;  // variant
    static const char *hex = "0123456789abcdef";
    int i = 0, j = 0;
    for (; i < 16; ++i) {
        if (i == 4 || i == 6 || i == 8 || i == 10) out36[j++] = '-';
        out36[j++] = hex[(r[i] >> 4) & 0xF];
        out36[j++] = hex[r[i] & 0xF];
    }
    out36[j] = 0;
#endif
}

// ========== UUID Ring Buffer for Ultra-Fast UUID Generation ==========
// OPTIMIZATION: Pre-generate UUIDs in background thread for ~100ns retrieval (vs 10-20μs)
// Ring buffer with 16384 UUIDs (~600KB) - refills every ~16K requests
#define UUID_RING_SIZE 16384
#define UUID_RING_MASK (UUID_RING_SIZE - 1)  // Fast modulo with power-of-2

// Ring buffer storage (pre-allocated, no malloc overhead)
static char g_uuid_ring[UUID_RING_SIZE][37];  // 16384 UUIDs × 37 bytes = ~600KB
static _Atomic size_t g_uuid_head = 0;        // Consumer pointer (lock-free)
static _Atomic size_t g_uuid_tail = 0;        // Producer pointer (lock-free)

// Telemetry counters for UUID ring performance
static _Atomic uint64_t g_uuid_ring_hits = 0;       // Fast path (from ring)
static _Atomic uint64_t g_uuid_ring_misses = 0;     // Slow path (buffer empty)
static _Atomic uint64_t g_uuid_ring_fallbacks = 0;  // Fallback to slow generation
static _Atomic uint64_t g_uuid_buffer_empty = 0;    // Times buffer was completely empty

// Background thread handle
static pthread_t g_uuid_generator_thread;
static _Atomic int g_uuid_generator_running = 0;

// Background thread: continuously generates UUIDs to fill ring buffer
static void* uuid_generator_thread_func(void* arg) {
    (void)arg;  // Unused

    // CRITICAL: Set thread-local flag to prevent capture of our own syscalls
    sf_guard_enter();

    while (atomic_load(&g_uuid_generator_running)) {
        size_t tail = atomic_load(&g_uuid_tail);
        size_t next_tail = (tail + 1) & UUID_RING_MASK;  // Fast modulo with mask
        size_t head = atomic_load(&g_uuid_head);

        // Check if buffer is full (next_tail == head means full)
        if (next_tail != head) {
            // Buffer has space - generate UUID directly into ring
            uuid4_string_slow(g_uuid_ring[tail]);

            // Advance tail pointer (lock-free publish)
            atomic_store(&g_uuid_tail, next_tail);
        } else {
            // Buffer full - sleep briefly and retry
            // This should rarely happen with 16K buffer size
            usleep(50);  // 50μs = enough time for ~5 requests to drain buffer
        }
    }

    return NULL;
}

// ULTRA-FAST: Retrieve pre-generated UUID from ring buffer (~100ns vs 10-20μs!)
static inline void uuid4_string(char out36[37]) {
    size_t head = atomic_load(&g_uuid_head);
    size_t tail = atomic_load(&g_uuid_tail);

    // Fast path: ring buffer has UUIDs ready
    if (__builtin_expect(head != tail, 1)) {
        // Copy UUID from ring (37 bytes = 36 + null terminator)
        memcpy(out36, g_uuid_ring[head], 37);

        // Advance head pointer (lock-free consume)
        size_t next_head = (head + 1) & UUID_RING_MASK;
        atomic_store(&g_uuid_head, next_head);

        // Telemetry: track hit
        atomic_fetch_add(&g_uuid_ring_hits, 1);
    } else {
        // Slow path: buffer empty (shouldn't happen often with 16K buffer)
        uuid4_string_slow(out36);

        // Telemetry: track miss
        atomic_fetch_add(&g_uuid_ring_misses, 1);
        atomic_fetch_add(&g_uuid_buffer_empty, 1);
    }
}

// Start UUID generator background thread
static void start_uuid_generator_thread(void) {
    if (atomic_load(&g_uuid_generator_running)) {
        return;  // Already running
    }

    // Pre-fill buffer with initial UUIDs (avoids cold start misses)
    for (size_t i = 0; i < UUID_RING_SIZE / 2; i++) {
        uuid4_string_slow(g_uuid_ring[i]);
    }
    atomic_store(&g_uuid_tail, UUID_RING_SIZE / 2);  // Mark half-full

    // Start background thread
    atomic_store(&g_uuid_generator_running, 1);
    if (pthread_create(&g_uuid_generator_thread, NULL, uuid_generator_thread_func, NULL) != 0) {
        // Thread creation failed - fallback to slow generation (set running=0)
        atomic_store(&g_uuid_generator_running, 0);
        atomic_fetch_add(&g_uuid_ring_fallbacks, 1);
    }
}

// Stop UUID generator background thread (called at shutdown)
static void stop_uuid_generator_thread(void) {
    if (!atomic_load(&g_uuid_generator_running)) {
        return;  // Not running
    }

    atomic_store(&g_uuid_generator_running, 0);
    pthread_join(g_uuid_generator_thread, NULL);
}

// Allocate child trace id: "<parent_prefix/>xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
// EXPORTED for Python wrappers to call via ctypes for header propagation
__attribute__((visibility("default")))
char* sf_make_child_trace_id(const char *parent) {
    if (!parent || !*parent) return NULL;
    const char *last = strrchr(parent, '/');
    size_t prefix = last ? (size_t)(last - parent + 1) : strlen(parent) + 1;  // add '/'
    char uuid[37];
    uuid4_string(uuid);
    size_t total = prefix + 36;
    char *out = (char*)malloc(total + 1);
    if (!out) return NULL;
    memcpy(out, parent, prefix);
    if (!last) out[prefix - 1] = '/';  // add slash if not present
    memcpy(out + prefix, uuid, 36);
    out[total] = 0;
    return out;
}

// ========== Thread-Local String Pooling for Reduced malloc/free Overhead ==========
// OPTIMIZATION: Reuse fixed-size buffers instead of malloc/free for trace IDs
// Each thread gets 16 buffers × 512 bytes = 8KB per thread
#define STRING_POOL_SIZE 16
#define STRING_POOL_BUF_SIZE 512

typedef struct {
    char buf[STRING_POOL_BUF_SIZE];
    int in_use;  // 1 = allocated, 0 = free
} string_pool_entry_t;

__thread string_pool_entry_t g_string_pool[STRING_POOL_SIZE] = {{0}};

// ULTRA-FAST: Allocate string from thread-local pool (~20ns vs ~500ns for malloc)
static inline char* pool_alloc_string(size_t size) {
    // Fast path: check if size fits in pool buffer
    if (__builtin_expect(size < STRING_POOL_BUF_SIZE, 1)) {
        // Linear scan for free slot (16 slots = ~80-160ns worst case)
        for (int i = 0; i < STRING_POOL_SIZE; i++) {
            if (!g_string_pool[i].in_use) {
                g_string_pool[i].in_use = 1;
                return g_string_pool[i].buf;
            }
        }
    }

    // Pool exhausted or size too large - fallback to malloc
    return (char*)malloc(size);
}

// ULTRA-FAST: Return string to thread-local pool (~5ns vs ~300ns for free)
static inline void pool_free_string(char* ptr) {
    if (!ptr) return;

    // Check if pointer is in our pool (fast pointer arithmetic)
    for (int i = 0; i < STRING_POOL_SIZE; i++) {
        if (ptr == g_string_pool[i].buf) {
            g_string_pool[i].in_use = 0;  // Mark as free
            return;
        }
    }

    // Not in pool - must be malloc'd, free it
    free(ptr);
}

// ============================= Tunables via env =============================
static size_t  SF_RING_CAP          = 262144;   // power-of-two ideal, but we handle any
static size_t  SF_MAX_REQ_BODY      = 8192;
static size_t  SF_MAX_RESP_BODY     = 8192;
static int     SF_CAPTURE_REQ_HEADERS  = 1;     // 1=send req headers, 0=skip (still capture internally for host/method)
static int     SF_CAPTURE_RESP_HEADERS = 1;     // 1=send resp headers, 0=skip (still capture internally for status)
static int     SF_EXTRACT_GRAPHQL_NAME = 0;     // 1=parse GraphQL operation names (expensive!), 0=skip (default)
static int     SF_ENABLE_PYTHON_FILTERS = 0;    // 1=call Python for trace_id/suppression (10-100µs GIL!), 0=skip (default)
static int     SF_SENDER_THREADS    = 4;        // Number of background sender threads (default 4 = 52k events/sec, configurable via SFT_SENDER_THREADS)
static double  SF_THREAD_KEEPALIVE  = 1.0;      // Thread keepalive seconds (prevents wake/sleep thrashing, configurable via SFT_THREAD_KEEPALIVE)
static int     SF_HTTP2             = 1;
static int     SF_ENABLE_SSL_HOOKS  = 0;    // 1 to enable TLS hooking
static int     SF_PYTHON_SSL_MODE   = 0;    // 1 when Python SSL patching active (disables C SSL hooks)
static int     SF_INITIALIZED       = 0;    // 1 after setup_interceptors() configures C library

static char   *SF_SINK_URL          = NULL;
static char   *SF_API_KEY           = NULL;
static char   *SF_SERVICE_UUID      = NULL;
static char   *SF_LIBRARY           = NULL;
static char   *SF_VERSION           = NULL;

// ============================= Real function pointers (forward declarations) =============================
// These must be declared early because they're used in ensure_telem_connection()
// They will be initialized in sftee_init() constructor
static ssize_t (*real_send)(int,const void*,size_t,int) = NULL;
static ssize_t (*real_recv)(int,void*,size_t,int) = NULL;
static ssize_t (*real_sendto)(int,const void*,size_t,int,const struct sockaddr*,socklen_t) = NULL;
static ssize_t (*real_recvfrom)(int,void*,size_t,int,struct sockaddr*,socklen_t*) = NULL;
static ssize_t (*real_sendmsg)(int,const struct msghdr*,int) = NULL;
static ssize_t (*real_recvmsg)(int,struct msghdr*,int) = NULL;

static int (*real_SSL_write)(SSL*,const void*,int) = NULL;
static int (*real_SSL_read)(SSL*,void*,int) = NULL;
static int (*real_SSL_write_ex)(SSL*,const void*,size_t,size_t*) = NULL;
static int (*real_SSL_read_ex)(SSL*,void*,size_t,size_t*) = NULL;

static int (*real_close)(int) = NULL;
static void (*real_SSL_free)(SSL*) = NULL;
static int (*real_socket)(int, int, int) = NULL;
static int (*real_shutdown)(int, int) = NULL;
static int (*real_setsockopt)(int, int, int, const void*, socklen_t) = NULL;
static int (*real_SSL_shutdown)(SSL*) = NULL;
typedef int (*connect_fn_t)(int, const struct sockaddr*, socklen_t);
typedef int (*accept_fn_t)(int, struct sockaddr*, socklen_t*);
typedef int (*accept4_fn_t)(int, struct sockaddr*, socklen_t*, int);

static _Atomic(connect_fn_t) g_real_connect = ATOMIC_VAR_INIT(NULL);
static _Atomic(accept_fn_t) g_real_accept = ATOMIC_VAR_INIT(NULL);
static _Atomic(accept4_fn_t) g_real_accept4 = ATOMIC_VAR_INIT(NULL);
// OpenSSL API is 'int SSL_get_fd(const SSL *ssl)'
static int (*real_SSL_connect_ptr)(SSL*) = NULL;
static int (*real_SSL_set_fd_ptr)(SSL*, int) = NULL;
static SSL* (*real_SSL_new_ptr)(SSL_CTX*) = NULL;

static int g_ssl_ex_index = -1;

typedef struct {
    int fd;
    conn_state_t *state;     // Points at SSL-mapped conn_state_t
} ssl_aux_t;

static void init_ssl_ex_index(void) {
    if (g_ssl_ex_index == -1) {
        g_ssl_ex_index = SSL_get_ex_new_index(0, "sf_tls_state", NULL, NULL, NULL);
    }
}

static ssl_aux_t* ssl_get_aux(SSL *ssl, int create) {
    if (!ssl) return NULL;
    init_ssl_ex_index();
    ssl_aux_t *aux = (ssl_aux_t*)SSL_get_ex_data(ssl, g_ssl_ex_index);
    if (!aux && create) {
        aux = (ssl_aux_t*)calloc(1, sizeof(ssl_aux_t));
        if (aux) {
            SSL_set_ex_data(ssl, g_ssl_ex_index, aux);
            DEBUG_LOG("[SF_DEBUG _sfteepreload] ssl_get_aux: allocated aux=%p for ssl=%p\n",
                      (void*)aux, (void*)ssl);
        }
    }
    return aux;
}

static inline connect_fn_t get_real_connect(void) {
    connect_fn_t fn = atomic_load_explicit(&g_real_connect, memory_order_acquire);
    if (__builtin_expect(fn != NULL, 1)) return fn;
    void *sym = dlsym(RTLD_NEXT, "connect");
    if (!sym) return NULL;
    connect_fn_t desired = (connect_fn_t)sym;
    connect_fn_t expected = NULL;
    if (atomic_compare_exchange_strong_explicit(&g_real_connect,
                                                &expected,
                                                desired,
                                                memory_order_release,
                                                memory_order_relaxed)) {
        return desired;
    }
    return atomic_load_explicit(&g_real_connect, memory_order_acquire);
}

static inline accept_fn_t get_real_accept(void) {
    accept_fn_t fn = atomic_load_explicit(&g_real_accept, memory_order_acquire);
    if (__builtin_expect(fn != NULL, 1)) return fn;
    void *sym = dlsym(RTLD_NEXT, "accept");
    if (!sym) return NULL;
    accept_fn_t desired = (accept_fn_t)sym;
    accept_fn_t expected = NULL;
    if (atomic_compare_exchange_strong_explicit(&g_real_accept,
                                                &expected,
                                                desired,
                                                memory_order_release,
                                                memory_order_relaxed)) {
        return desired;
    }
    return atomic_load_explicit(&g_real_accept, memory_order_acquire);
}

static inline accept4_fn_t get_real_accept4(void) {
    accept4_fn_t fn = atomic_load_explicit(&g_real_accept4, memory_order_acquire);
    if (__builtin_expect(fn != NULL, 1)) return fn;
    void *sym = dlsym(RTLD_NEXT, "accept4");
    if (!sym) return NULL;
    accept4_fn_t desired = (accept4_fn_t)sym;
    accept4_fn_t expected = NULL;
    if (atomic_compare_exchange_strong_explicit(&g_real_accept4,
                                                &expected,
                                                desired,
                                                memory_order_release,
                                                memory_order_relaxed)) {
        return desired;
    }
    return atomic_load_explicit(&g_real_accept4, memory_order_acquire);
}

// ============================= State array size constants (forward declarations) =============================
// These must be declared before the helper functions that use them
#define STATE_ARRAY_FD_SIZE 65536   // Direct FD→state mapping (512KB memory)
#define STATE_ARRAY_SSL_SIZE 8192   // SSL pointer→state mapping via hash (64KB memory)

// ============================= Skip bitmap and helper functions (forward declarations) =============================
// ULTRA-FAST SKIP BITMAP: Lock-free tracking of FDs/SSL that are DONE (emitted or not HTTP)
#define SKIP_BITMAP_SIZE 8192  // Tracks 65536 FDs with 8KB memory
static _Atomic uint64_t g_skip_bitmap[SKIP_BITMAP_SIZE];

// SSL SOCKET BITMAP: Tracks which FDs are SSL sockets vs plain HTTP sockets
// Used in Python SSL mode to distinguish: SSL sockets pass through, plain HTTP captured by C
static _Atomic uint64_t g_ssl_socket_bitmap[SKIP_BITMAP_SIZE];

// Forward declare hash_ptr for idx_ptr
static inline __attribute__((always_inline)) uint64_t hash_ptr(void *p){ uintptr_t v=(uintptr_t)p; v ^= v>>33; v*=0xff51afd7ed558ccdULL; v^=v>>33; v*=0xc4ceb9fe1a85ec53ULL; v^=v>>33; return v; }

// Helper functions for skip bitmap (must be declared before ensure_telem_connection uses them)
static inline __attribute__((always_inline)) size_t idx_fd(int fd){ return (size_t)(fd); }
static inline __attribute__((always_inline)) size_t idx_ptr(void *p){ return (size_t)(hash_ptr(p) % STATE_ARRAY_SSL_SIZE); }

static inline void mark_skip(size_t idx) {
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word < SKIP_BITMAP_SIZE) {
        atomic_fetch_or_explicit(&g_skip_bitmap[word], 1ULL << bit, memory_order_relaxed);
    }
}

static inline void unmark_skip(size_t idx) {
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word < SKIP_BITMAP_SIZE) {
        atomic_fetch_and_explicit(&g_skip_bitmap[word], ~(1ULL << bit), memory_order_relaxed);
    }
}

static inline __attribute__((always_inline)) int should_skip(size_t idx) {
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word >= SKIP_BITMAP_SIZE) return 0;
    uint64_t bits = atomic_load_explicit(&g_skip_bitmap[word], memory_order_relaxed);
    return (bits & (1ULL << bit)) != 0;
}

// Helper functions for SSL socket bitmap (distinguishes SSL vs plain HTTP sockets)
static inline void mark_ssl_socket(int fd) {
    size_t idx = idx_fd(fd);
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word < SKIP_BITMAP_SIZE) {
        atomic_fetch_or_explicit(&g_ssl_socket_bitmap[word], 1ULL << bit, memory_order_relaxed);
    }
}

static inline void unmark_ssl_socket(int fd) {
    size_t idx = idx_fd(fd);
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word < SKIP_BITMAP_SIZE) {
        atomic_fetch_and_explicit(&g_ssl_socket_bitmap[word], ~(1ULL << bit), memory_order_relaxed);
    }
}

static inline __attribute__((always_inline)) int is_ssl_socket(int fd) {
    size_t idx = idx_fd(fd);
    size_t word = idx / 64;
    size_t bit = idx % 64;
    if (word >= SKIP_BITMAP_SIZE) return 0;
    uint64_t bits = atomic_load_explicit(&g_ssl_socket_bitmap[word], memory_order_relaxed);
    return (bits & (1ULL << bit)) != 0;
}

// Forward declaration for remove_state_fd (needed by ensure_telem_connection)
static void remove_state_fd(int fd);

// OpenTelemetry filtering configuration
static int     SF_SUPPRESS_OTEL     = 0;   // If 1, suppress all OTEL requests

// OTEL endpoint storage (parsed from env vars at init)
#define MAX_OTEL_ENDPOINTS 32
typedef struct {
    char *host;      // e.g., "localhost", "otel-collector.example.com"
    int port;        // e.g., 4317, 4318, or -1 for any
    char *path;      // e.g., "/v1/traces", or NULL for any path
} otel_endpoint_t;

static otel_endpoint_t g_otel_endpoints[MAX_OTEL_ENDPOINTS];
static int g_otel_endpoint_count = 0;

// Network suppression patterns (configured via env vars)
#define MAX_SUPPRESS_PATTERNS 64
typedef struct {
    char *pattern;      // URL or path pattern (can include wildcards like "/admin/*" or "*/healthz")
    int is_path_only;   // 1 if just path, 0 if full URL pattern
} suppress_pattern_t;

static suppress_pattern_t g_suppress_patterns[MAX_SUPPRESS_PATTERNS];
static int g_suppress_pattern_count = 0;

// Python ContextVars for trace_id and suppress_network_recording
static PyObject *g_trace_id_contextvar = NULL;
static PyObject *g_suppress_network_recording_contextvar = NULL;
static PyObject *g_funcspan_override_contextvar = NULL;  // [ADD] For funcspan_override_ctx
static PyObject *g_get_or_set_sf_trace_id_func = NULL;  // Cached function reference
static int g_contextvar_init_attempted = 0;  // Track if we've tried to initialize

// Dynamically loaded Python API function pointers
static int (*py_IsInitialized)(void) = NULL;
static PyGILState_STATE (*py_GILState_Ensure)(void) = NULL;
static void (*py_GILState_Release)(PyGILState_STATE) = NULL;
static int (*py_ContextVar_Get)(PyObject*, PyObject*, PyObject**) = NULL;
static PyObject* (*py_Import_ImportModule)(const char*) = NULL;
static PyObject* (*py_Object_GetAttrString)(PyObject*, const char*) = NULL;
static PyObject* (*py_Object_CallObject)(PyObject*, PyObject*) = NULL;
static void (*py_Decref)(PyObject*) = NULL;
// Note: PyUnicode_Check is a macro in Python.h, not a function - don't declare it here
static const char* (*py_Unicode_AsUTF8)(PyObject*) = NULL;
static PyObject* (*py_Err_Occurred)(void) = NULL;
static void (*py_Err_Clear)(void) = NULL;
static int (*py_Object_IsTrue)(PyObject*) = NULL;
static PyObject* (*py_Tuple_GetItem)(PyObject*, int) = NULL;

static void *g_python_handle = NULL;  // dlopen handle for libpython

// ============================= Small utils =============================
// ULTRA-FAST: Always-inline and use MONOTONIC_COARSE for 3-5x faster timestamps
static inline __attribute__((always_inline)) uint64_t now_ns(void) {
    struct timespec ts;
#if defined(__linux__)
    // Linux: MONOTONIC_COARSE is 3-5x faster than REALTIME_COARSE (~15ns vs ~50-80ns)
    // Resolution is ~1ms which is fine for network telemetry
    clock_gettime(CLOCK_MONOTONIC_COARSE, &ts);
#elif defined(__APPLE__)
    // macOS: Use MONOTONIC (no COARSE variant available)
    clock_gettime(CLOCK_MONOTONIC, &ts);
#else
    clock_gettime(CLOCK_MONOTONIC, &ts);
#endif
    return ((uint64_t)ts.tv_sec) * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

// PRECISE timing for debug measurements (nanosecond resolution)
// Use this for SF_DEBUG timing measurements, NOT for hot path!
static inline __attribute__((always_inline)) uint64_t now_ns_precise(void) {
    struct timespec ts;
    // ALWAYS use CLOCK_MONOTONIC (not COARSE) for precise measurements
    // ~50-80ns overhead but nanosecond resolution (vs COARSE: ~15ns overhead but 1ms resolution)
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ((uint64_t)ts.tv_sec) * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static inline size_t minz(size_t a, size_t b) { return a < b ? a : b; }

// ========== GOT/TLS guard (diagnostic) ==========
// NOTE: This feature is Linux-only as it uses ELF structures and dl_iterate_phdr
#if defined(__linux__)
typedef struct {
    uintptr_t base_addr;
    uintptr_t got_addr;
    uintptr_t malloc_slot;
    size_t    got_len;
    void     *malloc_value;
    void     *malloc_rtld;
    int       enabled;
} got_guard_t;

static got_guard_t g_got_guard = {0};

static inline uintptr_t resolve_module_ptr(uintptr_t base, uintptr_t value) {
    if (value == 0) {
        return 0;
    }
    if (value >= base) {
        return value;
    }
    return base + value;
}

static int locate_self_image(struct dl_phdr_info *info, size_t size, void *data) {
    (void)size;
    uintptr_t self = (uintptr_t)&locate_self_image;
    for (ElfW(Half) i = 0; i < info->dlpi_phnum; ++i) {
        const ElfW(Phdr) *ph = &info->dlpi_phdr[i];
        if (ph->p_type != PT_LOAD) continue;
        uintptr_t seg_start = info->dlpi_addr + ph->p_vaddr;
        uintptr_t seg_end   = seg_start + ph->p_memsz;
        if (self >= seg_start && self < seg_end) {
            got_guard_t *guard = (got_guard_t*)data;
            guard->base_addr = info->dlpi_addr;
            const ElfW(Dyn) *dyn = NULL;
            for (ElfW(Half) j = 0; j < info->dlpi_phnum; ++j) {
                const ElfW(Phdr) *dp = &info->dlpi_phdr[j];
                if (dp->p_type == PT_DYNAMIC) {
                    dyn = (const ElfW(Dyn)*)(info->dlpi_addr + dp->p_vaddr);
                    break;
                }
            }
            if (!dyn) return 1;

            const ElfW(Sym)  *symtab = NULL;
            const char       *strtab = NULL;
            const ElfW(Rela) *rela   = NULL;
            size_t rela_cnt = 0;
            size_t rela_ent = sizeof(ElfW(Rela));

            for (const ElfW(Dyn) *entry = dyn; entry->d_tag != DT_NULL; ++entry) {
                switch (entry->d_tag) {
                    case DT_PLTGOT:
                        guard->got_addr = resolve_module_ptr(info->dlpi_addr, entry->d_un.d_ptr);
                        break;
                    case DT_RELA:
                        rela = (const ElfW(Rela)*)(resolve_module_ptr(info->dlpi_addr, entry->d_un.d_ptr));
                        break;
                    case DT_RELASZ:
                        rela_cnt = entry->d_un.d_val;
                        break;
                    case DT_RELAENT:
                        rela_ent = entry->d_un.d_val;
                        break;
                    case DT_SYMTAB:
                        symtab = (const ElfW(Sym)*)(resolve_module_ptr(info->dlpi_addr, entry->d_un.d_ptr));
                        break;
                    case DT_STRTAB:
                        strtab = (const char*)(resolve_module_ptr(info->dlpi_addr, entry->d_un.d_ptr));
                        break;
                    default:
                        break;
                }
            }
            if (rela && rela_ent) rela_cnt /= rela_ent;
            if (rela && symtab && strtab) {
                for (size_t idx = 0; idx < rela_cnt; ++idx) {
                    unsigned long type = ELF64_R_TYPE(rela[idx].r_info);
                    if (type != R_AARCH64_GLOB_DAT && type != R_AARCH64_JUMP_SLOT) {
                        continue;
                    }
                    unsigned long sym_idx = ELF64_R_SYM(rela[idx].r_info);
                    const char *name = strtab + symtab[sym_idx].st_name;
                    if (name && strcmp(name, "malloc") == 0) {
                        guard->malloc_slot = resolve_module_ptr(info->dlpi_addr, rela[idx].r_offset);
                        break;
                    }
                }
            }
            return 1;
        }
    }
    return 0;
}

static void enable_got_guard(void) {
    if (g_got_guard.enabled) return;
    const char *flag = getenv("SF_GOT_GUARD");
    if (!flag || (*flag != '1' && strcasecmp(flag, "true") != 0 && strcasecmp(flag, "yes") != 0)) {
        return;
    }

    got_guard_t guard = {0};
    dl_iterate_phdr(locate_self_image, &guard);
    if (!guard.got_addr) {
        fprintf(stderr, "[SF_DEBUG _sfteepreload] GOT guard: failed to locate GOT\n");
        fflush(stderr);
        return;
    }

    guard.malloc_value = guard.malloc_slot ? *(void**)guard.malloc_slot : NULL;
    guard.malloc_rtld = dlsym(RTLD_NEXT, "malloc");

    long pagesize = sysconf(_SC_PAGESIZE);
    if (pagesize <= 0) pagesize = 4096;
    uintptr_t page = guard.got_addr & ~((uintptr_t)pagesize - 1);
    guard.got_len = (size_t)pagesize * 2;  // cover .got and .got.plt

    if (mprotect((void*)page, guard.got_len, PROT_READ) != 0) {
        fprintf(stderr, "[SF_DEBUG _sfteepreload] GOT guard: mprotect failed (%d)\n", errno);
        fflush(stderr);
    } else {
        fprintf(stderr, "[SF_DEBUG _sfteepreload] GOT guard active (addr=%p len=%zu)\n",
                (void*)guard.got_addr, guard.got_len);
        fprintf(stderr, "[SF_DEBUG _sfteepreload]   malloc slot=%p initial=%p dlsym=%p\n",
                (void*)guard.malloc_slot, guard.malloc_value, guard.malloc_rtld);
        fflush(stderr);
        guard.enabled = 1;
    }
    g_got_guard = guard;
}
#else  /* !__linux__ (macOS, etc.) */
// GOT guard is not supported on non-Linux platforms
static void enable_got_guard(void) {
    // No-op on macOS - ELF structures not available
}
#endif /* __linux__ */

static char *str_dup(const char *s) {
    if (!s) return NULL;
    size_t n = strlen(s);
    char *p = (char*)malloc(n+1);
    if (p) { memcpy(p, s, n); p[n]=0; }
    return p;
}

// Generate a child trace_id from a parent trace_id
// Format: parent_prefix/new_uuid4
// Returns malloc'd string (caller must free)
static char* generate_child_trace_id(const char *parent_trace_id) {
    if (!parent_trace_id || !*parent_trace_id) return NULL;

    // Find the last '/' in the parent trace_id
    const char *last_slash = strrchr(parent_trace_id, '/');
    if (!last_slash) {
        // No slash found - just append a slash and UUID
        last_slash = parent_trace_id + strlen(parent_trace_id);
    }

    // Calculate parent prefix length (everything up to and including the last slash)
    size_t prefix_len = (size_t)(last_slash - parent_trace_id);
    if (*last_slash == '/') prefix_len++; // Include the slash

#if HAVE_UUID
    // Generate UUID4 using libuuid
    uuid_t binuuid;
    char uuid_str[37]; // 36 chars + null terminator

    uuid_generate_random(binuuid);
    uuid_unparse_lower(binuuid, uuid_str);

    // Allocate: parent_prefix + uuid_str + null
    char *child_trace_id = (char*)malloc(prefix_len + 36 + 1);
    if (!child_trace_id) return NULL;

    memcpy(child_trace_id, parent_trace_id, prefix_len);
    memcpy(child_trace_id + prefix_len, uuid_str, 36);
    child_trace_id[prefix_len + 36] = '\0';

    return child_trace_id;
#else
    // Fallback: if no UUID library, just return a copy of the parent
    // This shouldn't happen on macOS/Linux, but just in case
    return str_dup(parent_trace_id);
#endif
}

// ============================= ContextVar Cache (for capture, not injection) =============================
// Thread-local cache for UTF-8 strings from Python ContextVars
// Used by get_trace_id() and get_funcspan_override() for capturing parentRequestID and sessionId
__thread char *g_cached_trace_id_utf8 = NULL;
__thread char *g_cached_funcspan_utf8 = NULL;

// Forward declarations for telemetry thread-local resources (defined later)
extern __thread int g_telem_sock;
extern __thread SSL *g_telem_ssl;
extern __thread char *g_extracted_parent_trace_id;
extern __thread char *g_send_shadow;           // CRITICAL SEGFAULT FIX: Shadow buffer for send()
extern __thread size_t g_send_shadow_cap;      // CRITICAL SEGFAULT FIX: Shadow buffer capacity

// Thread-local cleanup infrastructure using pthread key destructor
// This ensures cached strings and telemetry resources are freed when threads exit
static int g_tls_cleanup_sentinel = 0;
static pthread_key_t g_tls_cleanup_key;
static pthread_once_t g_tls_cleanup_key_once = PTHREAD_ONCE_INIT;

// Destructor called when thread exits
static void tls_cleanup_destructor(void *data) {
    (void)data;

    // Free cached strings
    if (g_cached_trace_id_utf8) {
        free(g_cached_trace_id_utf8);
        g_cached_trace_id_utf8 = NULL;
    }
    if (g_cached_funcspan_utf8) {
        free(g_cached_funcspan_utf8);
        g_cached_funcspan_utf8 = NULL;
    }
    // CRITICAL MEMORY LEAK FIX: Free extracted parent trace ID!
    if (g_extracted_parent_trace_id) {
        free(g_extracted_parent_trace_id);
        g_extracted_parent_trace_id = NULL;
    }

    // CRITICAL SEGFAULT FIX: Free send shadow buffer!
    if (g_send_shadow) {
        free(g_send_shadow);
        g_send_shadow = NULL;
        g_send_shadow_cap = 0;
    }

    // Close telemetry socket
    if (g_telem_sock >= 0) {
        if (real_close) {
            real_close(g_telem_sock);
        } else {
            close(g_telem_sock);
        }
        g_telem_sock = -1;
    }

    // Free SSL context
    if (g_telem_ssl) {
        SSL_free(g_telem_ssl);
        g_telem_ssl = NULL;
    }

    // CRITICAL FIX #1: Close /dev/urandom FD (prevents FD leak!)
    if (g_urandom_fd >= 0) {
        close(g_urandom_fd);
        g_urandom_fd = -1;
    }
}

// Initialize pthread key once
static void tls_cleanup_key_init(void) {
    pthread_key_create(&g_tls_cleanup_key, tls_cleanup_destructor);
}

// Register thread-local resources for cleanup on thread exit
static void register_tls_cleanup(void) {
    pthread_once(&g_tls_cleanup_key_once, tls_cleanup_key_init);

    // Check if already registered
    if (pthread_getspecific(g_tls_cleanup_key)) {
        return;  // Already registered for this thread
    }

    // Use a sentinel pointer so the destructor always runs on thread exit
    pthread_setspecific(g_tls_cleanup_key, (void*)&g_tls_cleanup_sentinel);
}

// CRITICAL FIX #2: Lightweight helper to ensure TLS cleanup is registered
// Called from ALL thread entry points (UUID generation, header processing, telemetry sending)
// Branch-predicted to be fast (~2ns overhead when already registered)
static inline void ensure_tls_cleanup_registered(void) {
    if (__builtin_expect(pthread_getspecific(g_tls_cleanup_key) == NULL, 0)) {
        register_tls_cleanup();
    }
}

// ============================= OTEL Endpoint Detection =============================

// Add an OTEL endpoint to the list
static void add_otel_endpoint(const char *host, int port, const char *path) {
    if (g_otel_endpoint_count >= MAX_OTEL_ENDPOINTS) {
        return;
    }

    otel_endpoint_t *ep = &g_otel_endpoints[g_otel_endpoint_count++];
    ep->host = str_dup(host);
    ep->port = port;
    ep->path = path ? str_dup(path) : NULL;
}

// Parse a URL/endpoint string and add to OTEL list
// Supports formats: "host:port", "host:port/path", "http://host:port/path", etc.
static void parse_and_add_otel_endpoint(const char *endpoint_str) {
    if (!endpoint_str || !*endpoint_str) return;

    char *str = str_dup(endpoint_str);
    if (!str) return;

    // Strip protocol if present
    char *p = str;
    if (strncmp(p, "http://", 7) == 0) p += 7;
    else if (strncmp(p, "https://", 8) == 0) p += 8;

    // Find host, port, path
    char *host_start = p;
    char *port_str = NULL;
    char *path = NULL;

    // Look for port separator
    char *colon = strchr(host_start, ':');
    char *slash = strchr(host_start, '/');

    if (colon && (!slash || colon < slash)) {
        // Has port
        *colon = '\0';
        port_str = colon + 1;

        if (slash) {
            *slash = '\0';
            path = slash + 1;  // Point to path without leading slash
        }
    } else if (slash) {
        // No port, has path
        *slash = '\0';
        path = slash + 1;
    }

    char *host = host_start;
    int port = -1;  // -1 means any port

    if (port_str) {
        port = atoi(port_str);
    }

    // Build full path with leading slash
    char *full_path = NULL;
    if (path && *path) {
        full_path = (char*)malloc(strlen(path) + 2);
        if (full_path) {
            full_path[0] = '/';
            strcpy(full_path + 1, path);
        }
    }

    add_otel_endpoint(host, port, full_path);

    free(full_path);
    free(str);
}

// Initialize OTEL endpoints from environment variables
static void init_otel_endpoints(void) {
    // Check if OTEL suppression is enabled
    const char *suppress = getenv("SAILFISH_SUPPRESS_OTEL");
    if (suppress && (strcmp(suppress, "1") == 0 || strcmp(suppress, "true") == 0 || strcmp(suppress, "True") == 0)) {
        SF_SUPPRESS_OTEL = 1;
    }

    if (!SF_SUPPRESS_OTEL) {
        return;
    }

    // Parse standard OTEL environment variables
    const char *otel_vars[] = {
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT",
        "OTEL_EXPORTER_OTLP_METRICS_ENDPOINT",
        "OTEL_EXPORTER_OTLP_LOGS_ENDPOINT",
        NULL
    };

    for (int i = 0; otel_vars[i]; i++) {
        const char *val = getenv(otel_vars[i]);
        if (val && *val) {
            parse_and_add_otel_endpoint(val);
        }
    }

    // Parse custom SAILFISH_OTEL_ENDPOINTS (comma-separated list)
    const char *custom = getenv("SAILFISH_OTEL_ENDPOINTS");
    if (custom && *custom) {
        char *list = str_dup(custom);
        if (list) {
            char *token = strtok(list, ",");
            while (token) {
                // Trim leading spaces
                while (*token == ' ') token++;
                if (*token) {
                    parse_and_add_otel_endpoint(token);
                }
                token = strtok(NULL, ",");
            }
            free(list);
        }
    }

    // Add well-known defaults if no endpoints were specified
    if (g_otel_endpoint_count == 0) {
        // gRPC OTLP (any path)
        add_otel_endpoint("localhost", 4317, NULL);
        add_otel_endpoint("127.0.0.1", 4317, NULL);

        // HTTP/JSON OTLP (specific paths)
        add_otel_endpoint("localhost", 4318, "/v1/traces");
        add_otel_endpoint("localhost", 4318, "/v1/metrics");
        add_otel_endpoint("localhost", 4318, "/v1/logs");
        add_otel_endpoint("127.0.0.1", 4318, "/v1/traces");
        add_otel_endpoint("127.0.0.1", 4318, "/v1/metrics");
        add_otel_endpoint("127.0.0.1", 4318, "/v1/logs");
    }
}

// Check if a host:port/path matches any OTEL endpoint
// Returns 1 if it's an OTEL request, 0 otherwise
static int is_otel_request(const char *host, int port, const char *path) {
    if (!SF_SUPPRESS_OTEL) return 0;  // OTEL filtering disabled
    if (!host) return 0;

    // Normalize path (ensure it starts with / or is empty)
    const char *norm_path = path;
    if (path && path[0] == '/') {
        norm_path = path;
    } else if (!path) {
        norm_path = "";
    }

    for (int i = 0; i < g_otel_endpoint_count; i++) {
        otel_endpoint_t *ep = &g_otel_endpoints[i];

        // Check host (case-insensitive)
        if (strcasecmp(host, ep->host) != 0) continue;

        // Check port (-1 means any port)
        if (ep->port != -1 && port != ep->port) continue;

        // Check path (NULL means any path)
        if (ep->path) {
            if (!norm_path || strcmp(norm_path, ep->path) != 0) continue;
        }

        // Match!
        return 1;
    }

    return 0;
}

// ============================= Network Suppression Patterns =============================

// Simple wildcard pattern matching (supports * as wildcard)
// Returns 1 if string matches pattern, 0 otherwise
static int simple_wildcard_match(const char *pattern, const char *str) {
    if (!pattern || !str) return 0;

    const char *p = pattern;
    const char *s = str;
    const char *star = NULL;
    const char *ss = str;

    while (*s) {
        if (*p == '*') {
            // Remember position of * and current string position
            star = p++;
            ss = s;
        } else if (*p == *s) {
            // Characters match, advance both
            p++;
            s++;
        } else if (star) {
            // Mismatch, but we have a star - backtrack
            p = star + 1;
            s = ++ss;
        } else {
            // No match and no star to backtrack to
            return 0;
        }
    }

    // Handle trailing stars in pattern
    while (*p == '*') p++;

    return (*p == '\0') ? 1 : 0;
}

// Add a suppression pattern to the list
static void add_suppress_pattern(const char *pattern) {
    if (g_suppress_pattern_count >= MAX_SUPPRESS_PATTERNS) {
        return;
    }

    if (!pattern || !*pattern) return;

    // Determine if this is a path-only pattern (starts with /) or full URL pattern
    int is_path = (pattern[0] == '/');

    suppress_pattern_t *sp = &g_suppress_patterns[g_suppress_pattern_count++];
    sp->pattern = str_dup(pattern);
    sp->is_path_only = is_path;
}

// Initialize suppression patterns from environment variables
static void init_suppress_patterns(void) {
    const char *patterns_env = getenv("SAILFISH_SUPPRESS_PATHS");

    if (!patterns_env || !*patterns_env) {
        return;
    }

    // Parse comma-separated patterns
    char *patterns = str_dup(patterns_env);
    if (!patterns) return;

    char *token = strtok(patterns, ",");
    while (token) {
        // Trim leading spaces
        while (*token == ' ') token++;

        // Trim trailing spaces
        char *end = token + strlen(token) - 1;
        while (end > token && *end == ' ') {
            *end = '\0';
            end--;
        }

        if (*token) {
            add_suppress_pattern(token);
        }

        token = strtok(NULL, ",");
    }

    free(patterns);
}

// Check if a URL or path should be suppressed
// Returns 1 if should suppress, 0 otherwise
static int should_suppress_by_pattern(const char *url, const char *path) {
    if (g_suppress_pattern_count == 0) return 0;
    if (!url && !path) return 0;

    for (int i = 0; i < g_suppress_pattern_count; i++) {
        suppress_pattern_t *sp = &g_suppress_patterns[i];

        if (sp->is_path_only) {
            // Path-only pattern - match against path
            if (path && simple_wildcard_match(sp->pattern, path)) {
                return 1;
            }
        } else {
            // Full URL pattern - match against full URL
            if (url && simple_wildcard_match(sp->pattern, url)) {
                return 1;
            }
        }
    }

    return 0;
}

// ============================= Message & Ring =============================
// ULTRA-FAST: Raw captured data (NO JSON building on hot path!)
// Background thread builds JSON from this raw data
typedef struct {
    // Connection metadata (cheap to copy)
    int is_ssl;
    int resp_status;
    uint64_t t_req_start_ns;
    uint64_t t_resp_last_hdr_ns;

    // Raw captured data (pointers to malloc'd buffers - zero-copy!)
    // NOTE: req_method/req_target are inline strings (copied from offsets), not separate malloc
    char req_method[16];   // Inline method string (GET, POST, etc - always < 16 bytes)
    char req_target[256];  // Inline target string (most URLs < 256 bytes for path part)
    char *req_host;        // malloc'd
    char *req_hdr_raw;     // malloc'd - raw request headers (for extracting X-Sf3-Rid)
    size_t req_hdr_raw_len;
    char *req_hdr_json;    // malloc'd (only if SF_CAPTURE_REQ_HEADERS)
    char *resp_hdr_json;   // malloc'd (only if SF_CAPTURE_RESP_HEADERS)
    char *req_body_sample; // malloc'd (only if has body)
    size_t req_body_len;
    char *resp_body_sample;// malloc'd (only if has body)
    size_t resp_body_len;

    // Python context (copied once, cached)
    char *parent_trace_id; // malloc'd (only if SF_ENABLE_PYTHON_FILTERS)
    int is_suppressed_by_python;

    // [DIAGNOSTICS] For end-to-end accounting and message tracking
    uint64_t seq;
} tee_msg_t;

// ULTRA-FAST: Lock-free MPMC ring buffer (power-of-2 capacity with mask, no modulo!)
static tee_msg_t *g_ring = NULL;
static size_t     g_rcap = 0;        // Actual capacity (power of 2)
static size_t     g_rcap_mask = 0;   // Capacity - 1 (for fast & instead of %)
static _Atomic size_t g_head = 0;    // pop index
static _Atomic size_t g_tail = 0;    // push index (no lock needed with fetch_add!)

static pthread_mutex_t g_cv_mtx = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_cv     = PTHREAD_COND_INITIALIZER;
static _Atomic int     g_running = 0;
// CRITICAL FIX: Counter for producers blocked on full ring (ensures unmissable wakeups)
static _Atomic int     g_producers_waiting = 0;
// CRITICAL FIX: Counter for consumers (sender threads) blocked on empty ring
static _Atomic int     g_consumers_waiting = 0;
// [STATS-ONLY] static _Atomic uint64_t g_ring_overflow_blocks = 0;  // Counter: how many times ring was full and we had to block

// OBSERVABILITY: Track active connection states (should oscillate, not grow monotonically!)
// If these only ever grow → state leak causing ~2M req stall
static _Atomic int     g_active_fd_states = 0;   // Active per-fd connection states
static _Atomic int     g_active_ssl_states = 0;  // Active per-SSL* connection states

// DETERMINISTIC SHUTDOWN: Track exact enqueue/sent counts for proper drain
static _Atomic uint64_t g_total_enqueued = 0;  // Total messages enqueued to ring
static _Atomic uint64_t g_total_sent = 0;      // Total messages successfully sent
static _Atomic uint64_t g_total_popped = 0;    // Total messages popped from ring (for consumption rate tracking)

// [DIAGNOSTICS] Send outcome classification
typedef enum {
    SEND_OK = 0,
    SEND_FAIL_CONNECT,
    SEND_FAIL_WRITE,
    SEND_FAIL_TIMEOUT,
    SEND_FAIL_RECV_CLOSE,
    SEND_FAIL_SSL,
    SEND_FAIL_OTHER
} send_result_t;

// [DIAGNOSTICS] Per-message sequence id (monotonic) - for end-to-end tracking
static _Atomic uint64_t g_msg_seq = 0;

// [DIAGNOSTICS] Tunables for retry behavior
static int SF_SEND_RETRIES = 2;           // SFT_SEND_RETRIES, default 2 (best-effort)
static int SF_STRICT_DELIVERY = 0;        // SFT_STRICT_DELIVERY=1 -> retry harder + requeue on failure

#define MAX_SENDER_THREADS 16
static pthread_t       g_sender_threads[MAX_SENDER_THREADS];
static int             g_num_sender_threads = 0;

// ULTRA-FAST: Global kill switch - if 0, skip ALL processing (not configured)
// This gives ZERO overhead when the library is loaded but not configured
static _Atomic int     g_enabled = 0;
static int             g_enabled_cached = 0;  // ULTRA-FAST: Non-atomic hot read (set once at init)

// Thread-local flag to prevent recursive capture when sending telemetry
// CRITICAL: This provides a 1-branch ultra-fast skip for telemetry syscalls (~5ns overhead)
// Each thread has its own independent copy:
// - Application threads: always 0 (captures everything normally)
// - Background sender threads: 1 only during http_post_simple() (skips all syscalls)
// This is the ONLY protection mechanism we need - no header markers required!
__attribute__((visibility("default")))

// ULTRA-FAST: Thread-local storage for extracted X-Sf4-Prid value (passed from send() to on_tx_fd())
// Used to transfer extracted parent_trace_id from header processing to connection state without malloc overhead
__thread char *g_extracted_parent_trace_id = NULL;

// CRITICAL SEGFAULT FIX: Thread-local send shadow buffer to avoid in-place mutation of caller buffers
// Never mutate the caller's buffer (especially Python bytes/OpenSSL buffers which are immutable/shared)
// Instead, copy to this shadow buffer, modify there, and pass to real_send/real_SSL_write
__thread char  *g_send_shadow      = NULL;
__thread size_t g_send_shadow_cap  = 0;

static inline char* ensure_send_shadow(size_t want) {
    if (g_send_shadow_cap < want) {
        size_t ncap = g_send_shadow_cap ? g_send_shadow_cap : 2048;
        while (ncap < want) ncap <<= 1;
        char *nb = (char*)realloc(g_send_shadow, ncap);
        if (!nb) {
            DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_send_shadow: realloc failed want=%zu current_cap=%zu\n",
                      want, g_send_shadow_cap);
            return NULL;
        }
        g_send_shadow = nb;
        g_send_shadow_cap = ncap;
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_send_shadow: resized shadow buffer to %zu bytes\n", ncap);
    }
    DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_send_shadow: returning shadow buffer cap=%zu want=%zu\n",
              g_send_shadow_cap, want);
    return g_send_shadow;
}

// CRITICAL LEAK FIX: Atomic ownership transfer helper (move semantics for C)
// Takes the TLS pointer and NULLs it to prevent double-free or leak
static inline char *take_extracted_parent_trace_id(void) {
    char *p = g_extracted_parent_trace_id;
    g_extracted_parent_trace_id = NULL;   // transfer ownership to caller
    return p;
}

// Forward declaration of process_outbound_headers (defined later)
static size_t process_outbound_headers(char *buf, size_t len, size_t buf_capacity, char **out_parent_trace_id, int fd, int allow_growth);

// ---------- Lazy symbol resolution ----------
static void resolve_ssl_symbols_once(void) {
    static int done = 0;
    if (__builtin_expect(done, 1)) return;
    done = 1;
    real_SSL_read      = (int (*)(SSL*,void*,int))           dlsym(RTLD_NEXT, "SSL_read");
    real_SSL_write     = (int (*)(SSL*,const void*,int))     dlsym(RTLD_NEXT, "SSL_write");
    real_SSL_read_ex   = (int (*)(SSL*,void*,size_t,size_t*))dlsym(RTLD_NEXT, "SSL_read_ex");
    real_SSL_write_ex  = (int (*)(SSL*,const void*,size_t,size_t*))dlsym(RTLD_NEXT, "SSL_write_ex");
    real_SSL_new_ptr   = (SSL*(*)(SSL_CTX*))                 dlsym(RTLD_NEXT, "SSL_new");
    real_SSL_set_fd_ptr= (int (*)(SSL*,int))                 dlsym(RTLD_NEXT, "SSL_set_fd");
    // Sockets for telemetry sender paths
    if (!real_send)      real_send      = (ssize_t(*)(int,const void*,size_t,int))dlsym(RTLD_NEXT,"send");
    if (!real_recv)      real_recv      = (ssize_t(*)(int,void*,size_t,int))      dlsym(RTLD_NEXT,"recv");
    if (!real_sendmsg)   real_sendmsg   = (ssize_t(*)(int,const struct msghdr*,int))dlsym(RTLD_NEXT,"sendmsg");
    if (!real_close)     real_close     = (int(*)(int))                           dlsym(RTLD_NEXT,"close");
    if (!real_socket)    real_socket    = (int(*)(int,int,int))                   dlsym(RTLD_NEXT,"socket");
    if (!real_setsockopt)real_setsockopt= (int(*)(int,int,int,const void*,socklen_t))dlsym(RTLD_NEXT,"setsockopt");
}

// ---------- Minimal HTTP/1.x request sniff (avoid touching HTTP/2/other) ----------
static inline int looks_like_http11_request(const char *p, size_t n) {
    if (n < 8) return 0;
    // Very fast method token check (GET/POST/PUT/HEAD/DELETE/PATCH)
    if ((n >= 4 && !memcmp(p, "GET ", 4))  ||
        (n >= 5 && !memcmp(p, "PUT ", 4))  ||
        (n >= 6 && !memcmp(p, "HEAD ", 5)) ||
        (n >= 5 && !memcmp(p, "POST ", 5)) ||
        (n >= 7 && !memcmp(p, "DELETE ", 7)) ||
        (n >= 6 && !memcmp(p, "PATCH ", 6)))
        return 1;
    return 0;
}

/* Forward declarations for functions used in sniff_tls_headers_no_mutation */
static inline __attribute__((always_inline)) char* find_crlfcrlf(const char *buf, size_t len);
static char *extract_x_sf4_prid(const char *hdr_buf, size_t hdr_len);

/* ========================= TLS WRITE: SNIFF-ONLY, NO MUTATION ========================= */
/* REMOVED: SSL capture disabled - Python handles HTTPS, C handles plain HTTP
static inline __attribute__((always_inline))
void sniff_tls_headers_no_mutation(const void *in, size_t in_len, SSL *ssl) {
    if (__builtin_expect(!in || in_len < 32, 1)) return;
    if (sf_guard_active()) return;

    const char *p = (const char*)in;
    if (!looks_like_http11_request(p, in_len)) return;

    const char *eoh = find_crlfcrlf(p, in_len);
    if (!eoh) return;
    size_t hdr_len = (size_t)(eoh - p) + 4;

    char *maybe_parent = extract_x_sf4_prid(p, hdr_len);
    if (maybe_parent) {
        if (g_extracted_parent_trace_id) free(g_extracted_parent_trace_id);
        g_extracted_parent_trace_id = maybe_parent;
    }
}

static inline void prepare_tls_write_buffer(SSL *ssl,
                                            const void *in, size_t in_len,
                                            const void **out_ptr, size_t *out_len)
{
    sniff_tls_headers_no_mutation(in, in_len, ssl);
    *out_ptr = in;
    *out_len = in_len;
}
*/ // END REMOVED SSL capture code

/* ========================= RAW SEND/SENDMSG HARDENING ========================= */
/* Guard function to detect complete HTTP headers before processing */
static inline int buffer_looks_like_full_http_headers(const char *b, size_t n) {
    if (!looks_like_http11_request(b, n)) return 0;
    const char *eoh = find_crlfcrlf(b, n);
    return eoh != NULL; /* only process if we see end-of-headers */
}

// [ADD] --- SMART CACHE: Always fetch from Python, but cache preformatted header if same ---
// THREAD-POOL SAFETY: Value-based caching (not time-based) is safe!
//
// SOLUTION: Always fetch from Python ContextVars, but cache preformatted header string
// - Fetch trace_id on EVERY injection check (~60-130ns per call) - 100% CORRECT
// - Compare with cached trace_id - if SAME, reuse preformatted header (skip rebuild)
// - If DIFFERENT, rebuild header and update cache
//
// PERFORMANCE WIN: Header building (memcpy + strlen) takes ~100-200ns
//                  Comparing pointers takes ~2ns
//                  For same trace_id: ~62ns (fetch + compare)
//                  For different trace_id: ~280ns (fetch + rebuild + cache)
//
// (Thread-local cache variables declared earlier in file, near line 292)
//
// For now: CORRECTNESS > PERFORMANCE

// Per-FD telemetry tracking: bitmap to mark FDs used for telemetry sends
// This allows us to suppress capture on specific FDs without affecting other FDs in the same thread
#define TELEMETRY_FD_BITMAP_SIZE 1024  // Tracks up to 65536 FDs
static _Atomic uint64_t g_telemetry_fd_bitmap[TELEMETRY_FD_BITMAP_SIZE];

static inline void mark_telemetry_fd(int fd) {
    if (fd < 0) return;
    size_t word = (size_t)fd / 64;
    size_t bit = (size_t)fd % 64;
    if (word < TELEMETRY_FD_BITMAP_SIZE) {
        atomic_fetch_or_explicit(&g_telemetry_fd_bitmap[word], 1ULL << bit, memory_order_relaxed);
    }
}

static inline void unmark_telemetry_fd(int fd) {
    if (fd < 0) return;
    size_t word = (size_t)fd / 64;
    size_t bit = (size_t)fd % 64;
    if (word < TELEMETRY_FD_BITMAP_SIZE) {
        atomic_fetch_and_explicit(&g_telemetry_fd_bitmap[word], ~(1ULL << bit), memory_order_relaxed);
    }
}

static inline int is_telemetry_fd(int fd) {
    if (fd < 0) return 0;
    size_t word = (size_t)fd / 64;
    size_t bit = (size_t)fd % 64;
    if (word >= TELEMETRY_FD_BITMAP_SIZE) return 0;
    uint64_t bits = atomic_load_explicit(&g_telemetry_fd_bitmap[word], memory_order_relaxed);
    return (bits & (1ULL << bit)) != 0;
}

// ============================= compact JSON builder =============================
typedef struct { char *buf; size_t len; size_t cap; } sb_t;

static int sb_grow(sb_t *sb, size_t need) {
    if (sb->len + need <= sb->cap) return 1;
    size_t ncap = sb->cap ? sb->cap : 1024;
    while (ncap < sb->len + need) ncap <<= 1;
    char *nb = (char*)realloc(sb->buf, ncap);
    if (!nb) return 0;
    sb->buf = nb; sb->cap = ncap; return 1;
}
static int sb_putc(sb_t *sb, char c) { if (!sb_grow(sb,1)) return 0; sb->buf[sb->len++]=c; return 1; }
static int sb_puts(sb_t *sb, const char *s, size_t n) { if (!sb_grow(sb,n)) return 0; memcpy(sb->buf+sb->len,s,n); sb->len+=n; return 1; }
static int sb_putstr(sb_t *sb, const char *s) { return sb_puts(sb, s, strlen(s)); }
static int sb_put_uint(sb_t *sb, uint64_t v) {
    char tmp[32]; int n=0; if (v==0) return sb_putc(sb,'0');
    while (v) { tmp[n++] = (char)('0'+(v%10)); v/=10; }
    if (!sb_grow(sb,n)) return 0;
    for (int i=n-1;i>=0;--i) sb->buf[sb->len++]=tmp[i];
    return 1;
}
static int sb_put_int(sb_t *sb, int v) {
    if (v<0){ if(!sb_putc(sb,'-')) return 0; return sb_put_uint(sb, (uint64_t)(-(int64_t)v)); }
    return sb_put_uint(sb,(uint64_t)v);
}
static int sb_put_json_esc(sb_t *sb, const char *s, size_t n) {
    if (!sb_putc(sb, '"')) return 0;
    for (size_t i=0;i<n;i++){
        unsigned char c=(unsigned char)s[i];
        // Escape quotes and backslashes
        if (c=='"'||c=='\\'){
            if(!sb_grow(sb,2))return 0;
            sb->buf[sb->len++]='\\';
            sb->buf[sb->len++]=c;
        }
        // Special handling for common whitespace - use JSON short escapes
        else if (c=='\n'){
            if(!sb_grow(sb,2))return 0;
            sb->buf[sb->len++]='\\';
            sb->buf[sb->len++]='n';
        }
        else if (c=='\r'){
            if(!sb_grow(sb,2))return 0;
            sb->buf[sb->len++]='\\';
            sb->buf[sb->len++]='r';
        }
        else if (c=='\t'){
            if(!sb_grow(sb,2))return 0;
            sb->buf[sb->len++]='\\';
            sb->buf[sb->len++]='t';
        }
        // Other control characters - use \uXXXX format
        else if (c<0x20){
            if(!sb_grow(sb,6))return 0;
            static const char hex[]="0123456789abcdef";
            sb->buf[sb->len++]='\\';
            sb->buf[sb->len++]='u';
            sb->buf[sb->len++]='0';
            sb->buf[sb->len++]='0';
            sb->buf[sb->len++]=hex[c>>4];
            sb->buf[sb->len++]=hex[c&0xF];
        }
        // Normal printable characters
        else {
            if(!sb_grow(sb,1))return 0;
            sb->buf[sb->len++]=(char)c;
        }
    }
    return sb_putc(sb,'"');
}
static int sb_put_json_esc_cstr(sb_t *sb, const char *s){ return sb_put_json_esc(sb, s?s:"", s?strlen(s):0); }

// Extract "query|mutation operationName (fieldName)" from GraphQL request body
// Returns malloc'd string or NULL if not GraphQL or parse error
// Handles both direct GraphQL and JSON-wrapped: {"query": "mutation ..."}
static char *extract_graphql_name(const char *body, size_t len) {
    if (len < 6) return NULL;  // minimum: "query{a}"

    const char *p = body;
    const char *end = body + len;
    const char *operation_type = NULL;
    size_t operation_type_len = 0;

    // Skip leading whitespace
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    if (p >= end) return NULL;
    size_t remaining = end - p;

    // Check if it's JSON-wrapped GraphQL: {"query": "mutation ..."}
    if (remaining > 10 && *p == '{') {
        const char *query_key = p + 1;
        while (query_key < end && (*query_key == ' ' || *query_key == '\t' || *query_key == '\n' || *query_key == '\r')) query_key++;
        if ((end - query_key) > 10 && memcmp(query_key, "\"query\"", 7) == 0) {
            query_key += 7;
            while (query_key < end && (*query_key == ' ' || *query_key == '\t' || *query_key == '\n' || *query_key == '\r')) query_key++;
            if (query_key < end && *query_key == ':') {
                query_key++;
                while (query_key < end && (*query_key == ' ' || *query_key == '\t' || *query_key == '\n' || *query_key == '\r')) query_key++;
                if (query_key < end && *query_key == '"') {
                    query_key++;
                    p = query_key;
                    const char *query_end = p;
                    while (query_end < end) {
                        if (*query_end == '"' && (query_end == p || *(query_end - 1) != '\\')) break;
                        query_end++;
                    }
                    if (query_end >= end) return NULL;
                    end = query_end;
                    remaining = end - p;
                }
            }
        }
    }

    // Skip any leading whitespace or escaped whitespace
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\\' || *p == 'n' || *p == 't' || *p == 'r')) {
        if (*p == '\\' && p + 1 < end && (*(p + 1) == 'n' || *(p + 1) == 't' || *(p + 1) == 'r')) {
            p += 2;
        } else if (*p == ' ' || *p == '\t') {
            p++;
        } else {
            break;
        }
    }
    if (p >= end) return NULL;
    remaining = end - p;

    // Fast-path check for "mutation " or "query "
    if (remaining >= 9 && memcmp(p, "mutation ", 9) == 0) {
        operation_type = "mutation"; operation_type_len = 8; p += 9;
    } else if (remaining >= 6 && memcmp(p, "query ", 6) == 0) {
        operation_type = "query"; operation_type_len = 5; p += 6;
    } else if (remaining >= 9 && memcmp(p, "mutation{", 9) == 0) {
        operation_type = "mutation"; operation_type_len = 8; p += 8;
    } else if (remaining >= 6 && memcmp(p, "query{", 6) == 0) {
        operation_type = "query"; operation_type_len = 5; p += 5;
    } else {
        return NULL;
    }

    // Skip whitespace
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;

    // Extract operation name (optional)
    const char *op_name_start = p;
    const char *op_name_end = p;
    if (p < end && *p != '{' && *p != '(') {
        while (p < end && *p != '(' && *p != '{' && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') p++;
        op_name_end = p;
    }
    size_t op_name_len = op_name_end - op_name_start;

    // Skip whitespace
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;

    // Skip parameter list if present: ($param1: Type, ...)
    if (p < end && *p == '(') {
        int depth = 1; p++;
        while (p < end && depth > 0) {
            if (*p == '(') depth++;
            else if (*p == ')') depth--;
            p++;
        }
        if (depth != 0) return NULL;
    }

    // Skip whitespace
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;

    // Expect '{'
    if (p >= end || *p != '{') return NULL;
    p++;

    // Skip whitespace inside selection set
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;

    // Extract first field name
    const char *field_start = p;
    while (p < end && *p != '(' && *p != '{' && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') p++;
    const char *field_end = p;
    size_t field_len = field_end - field_start;
    if (field_len == 0) return NULL;

    // Build result: "operation_type operationName (fieldName)"
    size_t result_len = operation_type_len + 1;
    if (op_name_len > 0) result_len += op_name_len + 1;
    result_len += 1 + field_len + 1;

    char *result = (char*)malloc(result_len + 1);
    if (!result) return NULL;

    char *o = result;
    memcpy(o, operation_type, operation_type_len); o += operation_type_len;
    *o++ = ' ';
    if (op_name_len > 0) {
        memcpy(o, op_name_start, op_name_len); o += op_name_len;
        *o++ = ' ';
    }
    *o++ = '(';
    memcpy(o, field_start, field_len); o += field_len;
    *o++ = ')';
    *o = '\0';
    return result;
}

// Extract X-Sf3-Rid header value from raw request headers
// Returns malloc'd string (caller must free) or NULL if not found
// Extract header value from raw HTTP headers (case-insensitive search)
// Returns malloc'd string (caller must free) or NULL if not found
static char *extract_header(const char *hdr_buf, size_t hdr_len, const char *header_name) {
    if (!hdr_buf || hdr_len == 0 || !header_name) return NULL;

    size_t needle_len = strlen(header_name);
    const char *p = hdr_buf;
    const char *end = hdr_buf + hdr_len;

    while (p < end) {
        // Find the header name (case-insensitive search)
        if ((size_t)(end - p) >= needle_len &&
            strncasecmp(p, header_name, needle_len) == 0) {

            p += needle_len;
            // Skip whitespace after colon
            while (p < end && (*p == ' ' || *p == '\t')) p++;

            // Find end of value (CR or LF)
            const char *value_start = p;
            while (p < end && *p != '\r' && *p != '\n') p++;

            size_t value_len = p - value_start;
            if (value_len > 0) {
                char *result = (char*)malloc(value_len + 1);
                if (result) {
                    memcpy(result, value_start, value_len);
                    result[value_len] = '\0';
                    return result;
                }
            }
            return NULL;
        }

        // Move to next line
        while (p < end && *p != '\n') p++;
        if (p < end) p++; // skip the \n
    }

    return NULL;
}

// Non-allocating variant: copy into caller buffer, return length (or -1 if not found)
static int extract_header_into(const char *hdr_buf, size_t hdr_len,
                               const char *header_name, char *out, size_t out_cap) {
    if (!hdr_buf || !header_name || !out || out_cap==0) return -1;
    size_t needle_len = strlen(header_name);
    const char *p = hdr_buf, *end = hdr_buf + hdr_len;
    while (p < end) {
        if ((size_t)(end - p) >= needle_len && strncasecmp(p, header_name, needle_len) == 0) {
            p += needle_len;
            while (p < end && (*p==' '||*p=='\t')) p++;
            const char *vs = p;
            while (p < end && *p!='\r' && *p!='\n') p++;
            size_t vlen = (size_t)(p - vs);
            if (vlen >= out_cap) vlen = out_cap - 1;
            memcpy(out, vs, vlen); out[vlen] = '\0';
            return (int)vlen;
        }
        while (p < end && *p != '\n') p++;
        if (p < end) p++;
    }
    return -1;
}

static char *extract_x_sf3_rid(const char *hdr_buf, size_t hdr_len) {
    return extract_header(hdr_buf, hdr_len, "X-Sf3-Rid:");
}

static char *extract_x_sf4_prid(const char *hdr_buf, size_t hdr_len) {
    return extract_header(hdr_buf, hdr_len, "X-Sf4-Prid:");
}

// Forward declaration (defined later)
static inline __attribute__((always_inline)) char* find_crlfcrlf(const char *buf, size_t len);

// ULTRA-FAST: Inline header matchers (replace strncasecmp for 3-5μs savings)
// These are optimized for exact header names we're looking for
// ========== SIMD-Optimized Header Matching (SSE4.2) ==========
// ULTRA-FAST: Use SIMD instructions for parallel string comparison (~3x faster)
#ifdef __SSE4_2__
#include <nmmintrin.h>  // SSE4.2 intrinsics (_mm_cmpestri)

// SIMD version: Match "x-sf3-rid:" using SSE4.2 string instructions
static inline __attribute__((always_inline)) int fast_match_x_sf3_rid(const char *p, size_t avail) {
    if (avail < 10) return 0;

    // Use SSE4.2 PCMPESTRI for 16-byte parallel comparison
    // This compares 16 bytes at once vs 10 individual byte comparisons
    __m128i needle = _mm_set_epi8(0, 0, 0, 0, 0, 0, ':', 'd', 'i', 'r', '-', '3', 'f', 's', '-', 'x');
    __m128i haystack = _mm_loadu_si128((__m128i*)p);

    // Case-insensitive comparison: convert both to lowercase using OR with 0x20
    __m128i lower_mask = _mm_set1_epi8(0x20);  // Mask to convert uppercase to lowercase
    __m128i haystack_lower = _mm_or_si128(haystack, lower_mask);
    __m128i needle_lower = _mm_set_epi8(0, 0, 0, 0, 0, 0, ':', 'd', 'i', 'r', '-', '3', 'f', 's', '-', 'x');

    // Compare 10 bytes (x-sf3-rid:)
    int result = _mm_cmpestri(needle_lower, 10, haystack_lower, 10,
                               _SIDD_CMP_EQUAL_ORDERED | _SIDD_UBYTE_OPS);

    return result == 0;  // Match found at position 0
}

// SIMD version: Match "x-sf4-prid:" using SSE4.2 string instructions
static inline __attribute__((always_inline)) int fast_match_x_sf4_prid(const char *p, size_t avail) {
    if (avail < 11) return 0;

    __m128i needle = _mm_set_epi8(0, 0, 0, 0, 0, ':', 'd', 'i', 'r', 'p', '-', '4', 'f', 's', '-', 'x');
    __m128i haystack = _mm_loadu_si128((__m128i*)p);

    // Case-insensitive comparison
    __m128i lower_mask = _mm_set1_epi8(0x20);
    __m128i haystack_lower = _mm_or_si128(haystack, lower_mask);
    __m128i needle_lower = _mm_set_epi8(0, 0, 0, 0, 0, ':', 'd', 'i', 'r', 'p', '-', '4', 'f', 's', '-', 'x');

    // Compare 11 bytes (x-sf4-prid:)
    int result = _mm_cmpestri(needle_lower, 11, haystack_lower, 11,
                               _SIDD_CMP_EQUAL_ORDERED | _SIDD_UBYTE_OPS);

    return result == 0;
}

#else
// ========== Non-SIMD Fallback (Bitwise Operations) ==========
// Uses bitwise OR with 32 to convert to lowercase (faster than tolower)
static inline __attribute__((always_inline)) int fast_match_x_sf3_rid(const char *p, size_t avail) {
    // Match "x-sf3-rid:" (10 bytes, case-insensitive)
    return avail >= 10 &&
           ((p[0] | 32) == 'x') && (p[1] == '-') &&
           ((p[2] | 32) == 's') && ((p[3] | 32) == 'f') &&
           (p[4] == '3') && (p[5] == '-') &&
           ((p[6] | 32) == 'r') && ((p[7] | 32) == 'i') &&
           ((p[8] | 32) == 'd') && (p[9] == ':');
}

static inline __attribute__((always_inline)) int fast_match_x_sf4_prid(const char *p, size_t avail) {
    // Match "x-sf4-prid:" (11 bytes, case-insensitive)
    return avail >= 11 &&
           ((p[0] | 32) == 'x') && (p[1] == '-') &&
           ((p[2] | 32) == 's') && ((p[3] | 32) == 'f') &&
           (p[4] == '4') && (p[5] == '-') &&
           ((p[6] | 32) == 'p') && ((p[7] | 32) == 'r') &&
           ((p[8] | 32) == 'i') && ((p[9] | 32) == 'd') &&
           (p[10] == ':');
}
#endif

// Strip X-Sf4-Prid header from outbound HTTP request buffer (HTTP and HTTPS)
// Robust line start handling: every byte after '\n' (or buffer start) is a new line.
// Ignores leading spaces/tabs before header name. Case-insensitive match.
/**
 * Process outbound HTTP headers in-place:
 * 1. Append UUID4 to X-Sf3-Rid header value (e.g., "session/page" -> "session/page/uuid")
 * 2. Extract AND strip X-Sf4-Prid header (saves value before stripping!)
 *
 * Returns new buffer length after modifications.
 * Buffer must have at least 64 extra bytes of capacity for UUID appending.
 *
 * @param out_parent_trace_id: Optional output parameter. If non-NULL, stores malloc'd copy of X-Sf4-Prid value
 *                              (caller must free). Set to NULL if no X-Sf4-Prid header found.
 */
static size_t process_outbound_headers(char *buf, size_t len, size_t buf_capacity, char **out_parent_trace_id, int fd, int allow_growth /* 0 = never enlarge write */) {
    if (!buf || len < 20) return len;

    // CRITICAL FIX #2: Ensure TLS cleanup registered (cheap, branch-predicted)
    ensure_tls_cleanup_registered();

    DEBUG_LOG("[SF_DEBUG _sfteepreload] process_outbound_headers: fd=%d len=%zu cap=%zu allow_growth=%d\n",
              fd, len, buf_capacity, allow_growth);

    // Initialize output parameter
    if (out_parent_trace_id) *out_parent_trace_id = NULL;

    // OPTIMIZATION: Quick check if headers already processed (UUID already present)
    // Look for UUID pattern in X-Sf3-Rid (8-4-4-4-12 format with dashes)
    // This prevents re-processing on chunked sends or keep-alive reuse
    const char *uuid_check = buf;
    const char *buf_end = buf + (len < 200 ? len : 200);  // Only check first 200 bytes
    while (uuid_check < buf_end - 40) {
        // Look for UUID pattern: xxxxxxxx-xxxx-4xxx-xxxx-xxxxxxxxxxxx (version 4)
        if (uuid_check[8] == '-' && uuid_check[13] == '-' &&
            uuid_check[14] == '4' && uuid_check[18] == '-' && uuid_check[23] == '-') {
            // Found UUID pattern - headers likely already processed
            return len;
        }
        uuid_check++;
    }

    // CRITICAL FIX: Always find exact end-of-headers to prevent body scanning
    // Some stacks send headers+body in one buffer - we MUST NOT scan into body!
    const char *eoh = find_crlfcrlf(buf, len);
    if (!eoh) return len;  // Headers incomplete; don't touch

    // eoh currently points to the '\r' of the CRLFCRLF; advance past it for safe scanning bounds
    eoh += 4;  // Safe upper bound for header scan (stops at body start)

    // Generate UUID once for X-Sf3-Rid (10-20μs with cached /dev/urandom fd)
    // IMPORTANT: Only generate if allow_growth==1 (plaintext HTTP)
    // For TLS (allow_growth==0), we NEVER mutate, so don't waste cycles on UUID generation
    char uuid[37];
    if (allow_growth) {
        uuid4_string(uuid);
    }

    // ULTRA-FAST: SINGLE-PASS header scan (saves 15-30μs by scanning once instead of twice!)
    // Find BOTH X-Sf3-Rid and X-Sf4-Prid in one loop with early exit
    int found_rid = 0, found_prid = 0;
    const char *rid_val_end = NULL;  // Where to insert UUID
    const char *prid_line_start = NULL, *prid_line_end = NULL;  // Line to remove
    const char *prid_val_start = NULL;
    size_t prid_val_len = 0;

    const char *line = buf;
    const char *scan_end = eoh;

    // Skip the request line (first line)
    const char *nl = memchr(line, '\n', (size_t)(scan_end - line));
    if (!nl) nl = scan_end; else line = nl + 1;

    // SINGLE PASS: Scan headers once, find both targets
    while (line < scan_end) {
        const char *line_end = memchr(line, '\n', (size_t)(scan_end - line));
        if (!line_end) line_end = scan_end;

        const char *hard_end = line_end;
        if (hard_end > line && *(hard_end - 1) == '\r') hard_end--;

        const char *p = line;
        while (p < hard_end && (*p == ' ' || *p == '\t')) p++;

        size_t avail = (size_t)(hard_end - p);

        // ULTRA-FAST: Inline header matching (3-5μs faster than strncasecmp!)
        if (!found_rid && fast_match_x_sf3_rid(p, avail)) {
            // Found X-Sf3-Rid - save position for UUID append
            const char *val_start = p + 10;  // Skip "x-sf3-rid:"
            while (val_start < hard_end && (*val_start == ' ' || *val_start == '\t')) val_start++;
            const char *val_end = hard_end;
            while (val_end > val_start && (val_end[-1] == ' ' || val_end[-1] == '\t')) val_end--;
            rid_val_end = val_end;
            found_rid = 1;
        }
        else if (!found_prid && fast_match_x_sf4_prid(p, avail)) {
            // Found X-Sf4-Prid - save entire line for removal AND extract value
            prid_line_start = line;
            prid_line_end = line_end;

            // Extract value for telemetry
            const char *val_start = p + 11;  // Skip "x-sf4-prid:"
            while (val_start < hard_end && (*val_start == ' ' || *val_start == '\t')) val_start++;
            const char *val_end = hard_end;
            while (val_end > val_start && (val_end[-1] == ' ' || val_end[-1] == '\t')) val_end--;
            prid_val_start = val_start;
            prid_val_len = (size_t)(val_end - val_start);
            found_prid = 1;
        }

        // CRITICAL: Early exit when both found (HUGE savings! ~10-20μs)
        if (__builtin_expect(found_rid && found_prid, 0)) break;

        // Advance to next line
        line = (line_end < scan_end) ? (line_end + 1) : scan_end;
    }

    // Now do modifications in optimal order
    size_t current_len = len;

    // STEP 1: Extract X-Sf4-Prid value for telemetry (malloc ONCE, not in loop)
    // NOTE: We extract but DO NOT strip - X-Sf4-Prid propagates to external services
    if (found_prid && out_parent_trace_id && prid_val_len > 0) {
        if (*out_parent_trace_id) {
            free(*out_parent_trace_id);
            *out_parent_trace_id = NULL;
        }
        char *tmp = (char*)malloc(prid_val_len + 1);
        if (tmp) {
            memcpy(tmp, prid_val_start, prid_val_len);
            tmp[prid_val_len] = '\0';
            *out_parent_trace_id = tmp;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] process_outbound_headers: extracted parent_trace_id len=%zu\n",
                      prid_val_len);
        }
    }

    // STEP 2 (REMOVED): We no longer strip X-Sf4-Prid header
    // It now propagates to external services as part of the tracing API

    // STEP 3: Append UUID to X-Sf3-Rid value (ONLY if allow_growth is enabled)
    if (found_rid && rid_val_end && allow_growth) {
        size_t insert_pos = (size_t)(rid_val_end - buf);
        size_t tail_len = current_len - insert_pos;

        // Check buffer capacity
        if (insert_pos + 37 + tail_len <= buf_capacity) {
            // OPTIMIZATION: Only memmove if tail is non-empty (saves ~1-2μs for small tails)
            // Most HTTP requests have headers at the end, so tail is often small
            if (__builtin_expect(tail_len > 0, 1)) {
                // Shift tail to make room for "/uuid" (37 bytes)
                memmove((char*)(rid_val_end + 37), rid_val_end, tail_len);
            }

            // Insert "/uuid" - write directly without intermediate pointer
            char *insert_ptr = (char*)rid_val_end;
            *insert_ptr++ = '/';
            memcpy(insert_ptr, uuid, 36);

            current_len += 37;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] process_outbound_headers: appended UUID, new_len=%zu\n",
                      current_len);
        }
    }

    DEBUG_LOG("[SF_DEBUG _sfteepreload] process_outbound_headers: returning len=%zu\n", current_len);
    return current_len;
}

// Legacy function - kept for backwards compatibility but now just calls process_outbound_headers
static size_t strip_parent_session_id_header(char *buf, size_t len) {
    // For legacy calls, assume buffer has at least 64 extra bytes capacity
    // Don't extract parent_trace_id (pass NULL)
    // Pass -1 for fd since we don't have context here
    // Allow growth for legacy callers (assume they provide sufficient buffer)
    return process_outbound_headers(buf, len, len + 64, NULL, -1, 1 /* allow_growth=1 */);
}

// prebuilt JSON prefix; suffix
static char *g_json_prefix = NULL;
static const char *JSON_SUFFIX = "}}}";

static char *build_event_json(
    const char *trace_id, const char *parent_trace_id, const char *url, const char *method, int status, int ok,
    uint64_t ts_start, uint64_t ts_end,
    const char *req_hdr_json, const char *resp_hdr_json,
    const char *req_body, size_t req_len,
    const char *resp_body, size_t resp_len,
    size_t *out_len
) {
    sb_t sb={0};
    if (!g_json_prefix) return NULL;
    if (!sb_putstr(&sb, g_json_prefix)) goto fail;
    // Continue building the data object (prefix already has apiKey and serviceUuid)

    // Extract requestId and pageVisitId from trace_id (format: session_id/page_visit_id/request_id)
    const char *page_visit_id = NULL;
    const char *request_id = NULL;
    size_t page_visit_len = 0;
    size_t request_id_len = 0;
    char generated_request_id[37] = {0};  // Buffer for fallback UUID generation

    if (trace_id) {
        const char *first_slash = strchr(trace_id, '/');
        if (first_slash) {
            page_visit_id = first_slash + 1;
            const char *second_slash = strchr(page_visit_id, '/');
            if (second_slash) {
                page_visit_len = second_slash - page_visit_id;
                request_id = second_slash + 1;
                request_id_len = strlen(request_id);
            }
        }
    }

    // If we couldn't extract requestId, generate a new UUID (requestId is required by schema)
    if (!request_id || request_id_len == 0) {
        uuid4_string_slow(generated_request_id);
        request_id = generated_request_id;
        request_id_len = 36;
    }

    // CRITICAL FIX: No leading comma before first field in data object!
    // Prefix ends with "data":{ so recordingSessionId is the FIRST field
    if (!sb_putstr(&sb, "\"recordingSessionId\":")) goto fail;         if (!sb_put_json_esc_cstr(&sb, trace_id)) goto fail;
    if (!sb_putstr(&sb, ",\"parentRecordingSessionId\":")) goto fail;  if (!sb_put_json_esc_cstr(&sb, parent_trace_id)) goto fail;

    // Add requestId (required field - never null)
    if (!sb_putstr(&sb, ",\"requestId\":\"")) goto fail;
    if (!sb_puts(&sb, request_id, request_id_len)) goto fail;
    if (!sb_putc(&sb, '"')) goto fail;

    // Add pageVisitId (optional field)
    if (!sb_putstr(&sb, ",\"pageVisitId\":")) goto fail;
    if (page_visit_id && page_visit_len > 0) {
        if (!sb_putc(&sb, '"')) goto fail;
        if (!sb_puts(&sb, page_visit_id, page_visit_len)) goto fail;
        if (!sb_putc(&sb, '"')) goto fail;
    } else {
        if (!sb_putstr(&sb, "null")) goto fail;
    }

    if (!sb_putstr(&sb, ",\"url\":")) goto fail;            if (!sb_put_json_esc_cstr(&sb, url)) goto fail;
    if (!sb_putstr(&sb, ",\"method\":")) goto fail;         if (!sb_put_json_esc_cstr(&sb, method)) goto fail;
    if (!sb_putstr(&sb, ",\"responseCode\":")) goto fail;   if (!sb_put_int(&sb, status)) goto fail;
    if (!sb_putstr(&sb, ",\"success\":")) goto fail;        if (!sb_putstr(&sb, ok?"true":"false")) goto fail;
    if (!sb_putstr(&sb, ",\"timestampStart\":")) goto fail; if (!sb_put_uint(&sb, ts_start)) goto fail;
    if (!sb_putstr(&sb, ",\"timestampEnd\":")) goto fail;   if (!sb_put_uint(&sb, ts_end)) goto fail;

    // Send headers as JSON objects (not escaped strings)
    if (!sb_putstr(&sb, ",\"requestHeaders\":")) goto fail;
    if (SF_CAPTURE_REQ_HEADERS && req_hdr_json) {
        if (!sb_putstr(&sb, req_hdr_json)) goto fail;
    } else {
        if (!sb_putstr(&sb, "null")) goto fail;
    }

    if (!sb_putstr(&sb, ",\"responseHeaders\":")) goto fail;
    if (SF_CAPTURE_RESP_HEADERS && resp_hdr_json) {
        if (!sb_putstr(&sb, resp_hdr_json)) goto fail;
    } else {
        if (!sb_putstr(&sb, "null")) goto fail;
    }

    if (!sb_putstr(&sb, ",\"requestBody\":")) goto fail;
    if (req_len > 0 && req_body) { if (!sb_put_json_esc(&sb, req_body, req_len)) goto fail; } else { if (!sb_putstr(&sb, "null")) goto fail; }
    if (!sb_putstr(&sb, ",\"responseBody\":")) goto fail;
    if (resp_len > 0 && resp_body) { if (!sb_put_json_esc(&sb, resp_body, resp_len)) goto fail; } else { if (!sb_putstr(&sb, "null")) goto fail; }

    // ULTRA-FAST: Only extract GraphQL name if enabled (expensive parsing!)
    // Most users don't use GraphQL, so make this opt-in via SFT_EXTRACT_GRAPHQL_NAME=1
    char *graphql_name = NULL;
    if (__builtin_expect(SF_EXTRACT_GRAPHQL_NAME && req_len > 0 && req_body, 0)) {
        graphql_name = extract_graphql_name(req_body, req_len);
    }
    if (!sb_putstr(&sb, ",\"name\":")) goto fail;
    if (graphql_name) {
        if (!sb_put_json_esc_cstr(&sb, graphql_name)) { free(graphql_name); goto fail; }
        free(graphql_name);
    } else {
        if (!sb_putstr(&sb, "null")) goto fail;
    }

    if (!sb_putstr(&sb, JSON_SUFFIX)) goto fail;

    if (!sb_grow(&sb,1)) goto fail; sb.buf[sb.len]=0;
    *out_len = sb.len;
    return sb.buf;
fail:
    free(sb.buf); return NULL;
}

// ADAPTIVE THREAD SCALING: Calculate how many sender threads should be active
// based on current ring occupancy (tiered: 10%/25%/50% occupancy → 10%/25%/100% threads)
static inline int calculate_threads_needed(size_t occupancy) {
    if (g_num_sender_threads <= 0 || g_rcap == 0) return 1;  // Safety

    // Calculate occupancy percentage (0-100)
    int occupancy_pct = (int)((occupancy * 100) / g_rcap);

    // Tiered scaling thresholds
    if (occupancy_pct >= 50) {
        // High load: all threads (100%)
        return g_num_sender_threads;
    } else if (occupancy_pct >= 25) {
        // Medium load: 25% of threads (minimum 1)
        int threads = (g_num_sender_threads * 25) / 100;
        return threads < 1 ? 1 : threads;
    } else if (occupancy_pct >= 10) {
        // Light load: 10% of threads (minimum 1)
        int threads = (g_num_sender_threads * 10) / 100;
        return threads < 1 ? 1 : threads;
    } else {
        // Minimal load: 1 thread
        return 1;
    }
}

// Ring push/pop
// ULTRA-FAST: Lock-free MPMC ring with fetch_add (NO spin-lock, NO modulo!)
// This is 10-100x faster under contention - uses power-of-2 mask instead of %
static int ring_push_raw(tee_msg_t *msg){
    DEBUG_LOG("[SF_DEBUG _sfteepreload] ring_push_raw: seq=%llu req_len=%zu resp_len=%zu parent=%p\n",
              (unsigned long long)msg->seq, msg->req_body_len, msg->resp_body_len,
              (void*)msg->parent_trace_id);
    while (1) {
        size_t t = atomic_load_explicit(&g_tail, memory_order_relaxed);
        size_t h = atomic_load_explicit(&g_head, memory_order_acquire);

        // CRITICAL: BLOCKING RING BUFFER - guarantees ZERO data loss!
        // If ring is full, WAIT with pthread_cond_wait instead of usleep (efficient + low latency)
        if (t - h >= g_rcap) {
            // Ring is full - BLOCK until consumer signals space available
            int warned = 0;

            // [STATS-ONLY] Increment overflow counter (tracks backpressure events)
            // uint64_t overflow_count = atomic_fetch_add_explicit(&g_ring_overflow_blocks, 1, memory_order_relaxed) + 1;

            // CRITICAL FIX: Wake ALL consumer threads BEFORE blocking!
            // Without this, producers block but consumers might still be sleeping → deadlock!
            int sleeping_consumers = atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed);
            if (sleeping_consumers > 0) {
                pthread_mutex_lock(&g_cv_mtx);
                // Wake ALL consumers - ring is 100% full, need maximum drain rate!
                for (int i = 0; i < sleeping_consumers; i++) {
                    pthread_cond_signal(&g_cv);
                }
                pthread_mutex_unlock(&g_cv_mtx);
            }

            pthread_mutex_lock(&g_cv_mtx);

            // CRITICAL FIX: Reload t and h INSIDE mutex to avoid missed wakeup race!
            // Without this, we might use stale values and wait even though ring was drained
            t = atomic_load_explicit(&g_tail, memory_order_relaxed);
            h = atomic_load_explicit(&g_head, memory_order_acquire);

            while (t - h >= g_rcap) {
                if (!warned && SF_DEBUG) {
                    fprintf(stderr, "[SF_DEBUG _sfteepreload] ⚠ Ring FULL (%zu events), WAITING on condvar (producers_waiting=%d consumers_waiting=%d)\n",
                            g_rcap,
                            atomic_load_explicit(&g_producers_waiting, memory_order_relaxed) + 1,  // +1 for this thread about to wait
                            atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed));
                    warned = 1;
                }

                // CRITICAL FIX: Increment counter RIGHT BEFORE waiting (unmissable wakeup!)
                // This eliminates the TOCTOU race where:
                // 1. Producer increments counter early
                // 2. Consumers see counter=1, signal condvar
                // 3. Producer hasn't called pthread_cond_wait() yet → MISSED WAKEUP!
                // Now counter is ONLY non-zero while thread is ACTUALLY waiting!
                atomic_fetch_add_explicit(&g_producers_waiting, 1, memory_order_relaxed);

                // Wait for consumer to signal (more efficient than usleep backoff!)
                pthread_cond_wait(&g_cv, &g_cv_mtx);

                // CRITICAL FIX: Decrement counter RIGHT AFTER waking (no leak!)
                atomic_fetch_sub_explicit(&g_producers_waiting, 1, memory_order_relaxed);

                // Re-check ring status AFTER waking
                t = atomic_load_explicit(&g_tail, memory_order_relaxed);
                h = atomic_load_explicit(&g_head, memory_order_acquire);

                if (SF_DEBUG) {
                    fprintf(stderr, "[SF_DEBUG _sfteepreload] Producer woke from condvar (occupancy now=%zu/%zu, producers_waiting=%d)\n",
                            t - h, g_rcap,
                            atomic_load_explicit(&g_producers_waiting, memory_order_relaxed));
                }
            }

            pthread_mutex_unlock(&g_cv_mtx);

            if (warned && SF_DEBUG) {
                fprintf(stderr, "[SF_DEBUG _sfteepreload] ✓ Ring space available (occupancy=%zu/%zu), resuming\n", t - h, g_rcap);
            }
        }

        // Try to claim a slot atomically (multi-producer safe!)
        size_t my_t = atomic_fetch_add_explicit(&g_tail, 1, memory_order_acquire);

        // Re-check if we overflowed (another thread might have filled it between check and claim)
        // This is VERY rare with blocking above, but handle it just in case
        h = atomic_load_explicit(&g_head, memory_order_acquire);
        if (my_t - h >= g_rcap) {
            // Extremely rare: Another thread filled ring between our check and claim
            // Retry from top (will hit blocking loop with condvar wait)
            // Wait on condition variable instead of usleep
            pthread_mutex_lock(&g_cv_mtx);
            pthread_cond_wait(&g_cv, &g_cv_mtx);
            pthread_mutex_unlock(&g_cv_mtx);
            continue;  // Retry from top of while(1) loop
        }

        // ULTRA-FAST: Use mask instead of modulo (3-10x faster!)
        size_t idx = my_t & g_rcap_mask;

        // [DIAGNOSTICS] Assign sequence id before storing (for end-to-end tracking)
        msg->seq = atomic_fetch_add_explicit(&g_msg_seq, 1, memory_order_relaxed) + 1;

        // Zero-copy: Just copy the struct (pointers + metadata)
        g_ring[idx] = *msg;
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ring_push_raw: stored idx=%zu seq=%llu req_sample=%p resp_sample=%p\n",
                  idx, (unsigned long long)g_ring[idx].seq,
                  (void*)g_ring[idx].req_body_sample, (void*)g_ring[idx].resp_body_sample);

        // DETERMINISTIC: Increment total enqueued (for shutdown drain tracking)
        if (SF_DEBUG) atomic_fetch_add_explicit(&g_total_enqueued, 1, memory_order_relaxed);

        // ADAPTIVE THREAD SCALING: Wake sender threads based on occupancy (10%/25%/50% → 10%/25%/100%)
        size_t occupancy_after_push = (my_t + 1) - h;
        int threads_needed = calculate_threads_needed(occupancy_after_push);
        int threads_sleeping = atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed);
        int threads_active = g_num_sender_threads - threads_sleeping;

        // Calculate how many additional threads we need to wake
        int threads_to_wake = threads_needed - threads_active;

        if (threads_to_wake > 0 && threads_sleeping > 0) {
            // Wake exactly the number of threads we need (capped by sleeping threads)
            if (threads_to_wake > threads_sleeping) threads_to_wake = threads_sleeping;

            pthread_mutex_lock(&g_cv_mtx);
            for (int i = 0; i < threads_to_wake; i++) {
                pthread_cond_signal(&g_cv);  // Wake one thread per signal
            }
            pthread_mutex_unlock(&g_cv_mtx);
        }
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ring_push_raw: success seq=%llu\n",
                  (unsigned long long)g_ring[idx].seq);
        return 1;
    }
}
// ULTRA-FAST: Pop raw captured data for background processing
// MULTI-CONSUMER SAFE: Uses atomic fetch_add to allow N sender threads without lock contention
static int ring_pop_raw(tee_msg_t *msg){
    while (1) {
        size_t h = atomic_load_explicit(&g_head, memory_order_relaxed);
        size_t t = atomic_load_explicit(&g_tail, memory_order_acquire);
        if (h >= t) return 0;  // Empty

        // Try to claim this slot atomically (multi-consumer safe!)
        size_t my_h = atomic_fetch_add_explicit(&g_head, 1, memory_order_acquire);
        if (my_h >= t) {
            // Another thread already claimed the last item - roll back our increment!
            atomic_fetch_sub_explicit(&g_head, 1, memory_order_release);
            return 0;
        }

        // ULTRA-FAST: Use mask instead of modulo (3-10x faster!)
        size_t idx = my_h & g_rcap_mask;
        // Zero-copy: Just copy the struct (pointers + metadata)
        *msg = g_ring[idx];
        // Clear the ring slot (prevent double-free)
        memset(&g_ring[idx], 0, sizeof(tee_msg_t));

        // OPTIMIZATION: Signal if ring was getting full to prevent producer starvation
        // Use 50% threshold (more liberal) to ensure producers get woken before blocking
        // This still reduces signals significantly while preventing deadlock
        // BURST WORKLOAD FIX: Wake MULTIPLE producers (min(10, waiting)) to handle async burst concurrency
        size_t occupancy_before_pop = t - my_h;
        if (occupancy_before_pop >= (g_rcap / 2)) {
            // Ring was >50% full - wake multiple waiting producers
            int producers_waiting_count = atomic_load_explicit(&g_producers_waiting, memory_order_relaxed);
            int to_wake = producers_waiting_count < 10 ? producers_waiting_count : 10;
            if (to_wake > 0) {
                pthread_mutex_lock(&g_cv_mtx);
                for (int i = 0; i < to_wake; i++) {
                    pthread_cond_signal(&g_cv);
                }
                pthread_mutex_unlock(&g_cv_mtx);
            }
        }

        // CRITICAL FIX: If any producer is actively waiting, always signal (unmissable wakeup!)
        // This guarantees no missed wakeups even if our heuristic thresholds are off
        // BURST WORKLOAD FIX: Wake MULTIPLE producers (min(10, waiting)) to handle async burst concurrency
        int producers_waiting_count = atomic_load_explicit(&g_producers_waiting, memory_order_relaxed);
        if (producers_waiting_count > 0) {
            int to_wake = producers_waiting_count < 10 ? producers_waiting_count : 10;
            pthread_mutex_lock(&g_cv_mtx);
            for (int i = 0; i < to_wake; i++) {
                pthread_cond_signal(&g_cv);  // Wake multiple waiting producers
            }
            pthread_mutex_unlock(&g_cv_mtx);
        }

        // DIAGNOSTICS: Track total messages popped (for consumption rate calculation)
        if (SF_DEBUG) atomic_fetch_add_explicit(&g_total_popped, 1, memory_order_relaxed);

        return 1;
    }
}

// Per-thread persistent connection for telemetry POSTs (avoids port exhaustion + no mutex bottleneck)
__thread int g_telem_sock = -1;
__thread const char *g_telem_host_ptr = NULL;  // Pointer comparison instead of strcmp
__thread int g_telem_port = 0;
__thread struct sockaddr_in g_telem_cached_addr = {0};  // ULTRA-FAST: Cache DNS result (~200µs savings per reconnect!)

// TLS for telemetry (optional, only if sink URL uses https://)
static SSL_CTX *g_telem_ssl_ctx = NULL;
__thread SSL *g_telem_ssl = NULL;
__thread int g_telem_use_tls = 0;  // 0=http, 1=https

// ADAPTIVE THREAD SCALING: Per-thread keepalive tracking (prevents thrashing)
__thread double g_thread_wake_time = 0.0;  // Time when this thread last woke up (0 = never woken)

// Create or reconnect telemetry socket (thread-local, no locking needed)
static int ensure_telem_connection(const char *host, int port) {
    // Register cleanup for telemetry resources
    register_tls_cleanup();

    // ULTRA-FAST PATH: Pointer + int comparison (no strcmp!)
    if (g_telem_sock >= 0 && g_telem_host_ptr == host && g_telem_port == port) {
        return g_telem_sock;  // Instant return - same host pointer
    }

    // Slow path: host changed or first connection
    if (g_telem_sock >= 0) {
        if (g_telem_ssl) { SSL_free(g_telem_ssl); g_telem_ssl = NULL; }
        real_close(g_telem_sock);  // Use real_close to bypass our hook (telemetry sockets should not be tracked)
        g_telem_sock = -1;
    }

    // Create new socket - use real_socket to bypass our hook (telemetry sockets should not be tracked)
    int sock = real_socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        return -1;
    }

    // CRITICAL: Remove any existing conn_state_t for this fd BEFORE marking as skip!
    // The OS may reuse an fd that was just closed, and if it has lingering state,
    // we'll emit phantom events with corrupted data (e.g., "http://200" from response parsing)
    remove_state_fd(sock);

    // CRITICAL: Mark as skip IMMEDIATELY to prevent ANY capture (close race window!)
    mark_skip(idx_fd(sock));

    struct sockaddr_in addr = {0};

    // ULTRA-FAST: Use cached DNS result if reconnecting to same host (saves ~200µs!)
    // Cache is valid as long as host pointer + port match
    if (g_telem_cached_addr.sin_family != 0 && g_telem_host_ptr == host && g_telem_port == port) {
        // Fast path: Reuse cached address
        addr = g_telem_cached_addr;
        addr.sin_port = htons(port);  // Update port just in case
    } else {
        // Slow path: Need to resolve DNS
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);

        if (inet_pton(AF_INET, host, &addr.sin_addr) != 1) {
            // Not an IP address - must do DNS lookup
            struct addrinfo hints = {0}, *res = NULL;
            hints.ai_family = AF_INET;
            hints.ai_socktype = SOCK_STREAM;
            if (getaddrinfo(host, NULL, &hints, &res) != 0 || !res) {
                real_close(sock);  // Use real_close for telemetry socket
                return -1;
            }
            addr = *(struct sockaddr_in*)res->ai_addr;
            addr.sin_port = htons(port);
            freeaddrinfo(res);
        }

        // Cache the resolved address for next time
        g_telem_cached_addr = addr;
    }

    // Enable SO_REUSEADDR to allow rapid reuse of local ports (prevents EADDRINUSE after millions of connections)
    // This is critical for high-throughput scenarios where we cycle through ephemeral ports quickly
    // Without this, TIME_WAIT sockets accumulate and exhaust the port range (1024-65535)
    int reuse = 1;
    if (real_setsockopt) {
        real_setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    } else {
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    }

    // PERFORMANCE: We reuse connections forever, so SO_LINGER is not needed
    // Original implementation used SO_LINGER with l_linger=0 to avoid TIME_WAIT,
    // but this caused data truncation when close() was called before send buffer drained!
    // Connection reuse eliminates TIME_WAIT concerns (we never close until shutdown)
    // REMOVED: struct linger linger_opt = {1, 0};

    // Send timeout (5 seconds max)
    struct timeval tv_send = {5, 0};
    if (real_setsockopt) {
        real_setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv_send, sizeof(tv_send));
    } else {
        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv_send, sizeof(tv_send));
    }

    // Receive timeout (1 second) - Wait for server to process and respond
    // CRITICAL: Under load (200 requests), server may take >1ms to respond!
    // A 1ms timeout was causing false "timeouts" where we claimed success but server hadn't responded
    // Since we're in a background thread, waiting 1 second is acceptable for guaranteed delivery
    struct timeval tv_recv = {1, 0};  // 1 second
    if (real_setsockopt) {
        real_setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv_recv, sizeof(tv_recv));
    } else {
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv_recv, sizeof(tv_recv));
    }

    // Enable TCP_NODELAY for immediate send (no Nagle delay)
    int nodelay = 1;
    if (real_setsockopt) {
        real_setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));
    } else {
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));
    }

    // Enable TCP keepalive for long-lived connections
    int keepalive = 1;
    if (real_setsockopt) {
        real_setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(keepalive));
    } else {
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(keepalive));
    }

    // Connect with BLOCKING socket (waits for connection to complete)
    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        // Connection failed - don't mark this FD as telemetry
        real_close(sock);  // Use real_close for telemetry socket
        return -1;
    }

    // Keep socket in BLOCKING mode (we're in a background thread, blocking is fine)
    // This allows proper response draining with SO_RCVTIMEO
    // Non-blocking mode would cause recv() to return EAGAIN immediately, leaving responses in buffer

    // If HTTPS requested, create/attach SSL and handshake
    if (g_telem_use_tls) {
        if (!g_telem_ssl_ctx) {
            real_close(sock);  // Use real_close for telemetry socket
            return -1;
        }

        // Tear down any previous SSL object bound to an older fd
        if (g_telem_ssl) {
            SSL_free(g_telem_ssl);
            g_telem_ssl = NULL;
        }

        g_telem_ssl = SSL_new(g_telem_ssl_ctx);
        if (!g_telem_ssl) {
            real_close(sock);  // Use real_close for telemetry socket
            return -1;
        }

        // SNI for virtual hosts
        SSL_set_tlsext_host_name(g_telem_ssl, host);
        SSL_set_fd(g_telem_ssl, sock);

        // Blocking handshake is fine (we're on a background thread)
        if (SSL_connect(g_telem_ssl) <= 0) {
            SSL_free(g_telem_ssl);
            g_telem_ssl = NULL;
            real_close(sock);  // Use real_close for telemetry socket
            return -1;
        }
    }

    // Connection successful, save state (thread-local)
    g_telem_sock = sock;
    g_telem_host_ptr = host;  // Store pointer, not copy
    g_telem_port = port;

    // CRITICAL: Mark telemetry socket as skip to prevent our own hooks from tracking it!
    // This prevents:
    // 1. Recursive capture (telemetry traffic creating more telemetry)
    // 2. State array leaks (creating conn_state_t for telemetry sockets)
    // 3. FD exhaustion (state never cleaned up because we use real_close)
    mark_skip(idx_fd(sock));
    if (g_telem_ssl) {
        mark_skip(idx_ptr((void*)g_telem_ssl));  // Also mark SSL pointer
    }

    return sock;
}

// Helper: Read until double CRLF (\r\n\r\n) for TLS
// Returns total bytes read, or -1 on error
// Stops immediately after finding \r\n\r\n (HTTP headers complete)
// This avoids draining large response bodies unnecessarily
static int read_until_double_crlf_tls(SSL *ssl, char *buf, size_t buf_size) {
    if (!ssl || !buf || buf_size < 4) return -1;

    size_t total = 0;
    while (total < buf_size - 1) {
        int n = real_SSL_read(ssl, buf + total, 1);  // Read one byte at a time to detect \r\n\r\n
        if (n <= 0) return (total > 0) ? (int)total : -1;
        total += n;

        // Check for \r\n\r\n (need at least 4 bytes)
        if (total >= 4) {
            if (buf[total-4] == '\r' && buf[total-3] == '\n' &&
                buf[total-2] == '\r' && buf[total-1] == '\n') {
                return (int)total;  // Found end of headers
            }
        }
    }
    return (int)total;  // Buffer full without finding \r\n\r\n
}

// Helper: Read until double CRLF (\r\n\r\n) for TCP
// Returns total bytes read, or -1 on error
// Stops immediately after finding \r\n\r\n (HTTP headers complete)
// This avoids draining large response bodies unnecessarily
static int read_until_double_crlf_tcp(int sock, char *buf, size_t buf_size) {
    if (sock < 0 || !buf || buf_size < 4) return -1;

    size_t total = 0;
    while (total < buf_size - 1) {
        ssize_t n = real_recv(sock, buf + total, 1, 0);  // Read one byte at a time to detect \r\n\r\n
        if (n <= 0) return (total > 0) ? (int)total : -1;
        total += n;

        // Check for \r\n\r\n (need at least 4 bytes)
        if (total >= 4) {
            if (buf[total-4] == '\r' && buf[total-3] == '\n' &&
                buf[total-2] == '\r' && buf[total-1] == '\n') {
                return (int)total;  // Found end of headers
            }
        }
    }
    return (int)total;  // Buffer full without finding \r\n\r\n
}

// Simple HTTP POST using raw sockets with per-thread connection reuse (no libcurl, no mutex)
static int http_post_simple_once(const char *host, int port, const char *path, const char *json_body, size_t body_len, send_result_t *out_reason) {
    if (out_reason) *out_reason = SEND_FAIL_OTHER;

    // CRITICAL FIX #2: Ensure TLS cleanup registered (telemetry sender threads need cleanup too!)
    ensure_tls_cleanup_registered();

    // CRITICAL: Set telemetry guard BEFORE any network calls (prevents recursive capture)
    // We use BOTH approaches: thread-local guard (immediate 1-branch skip) + header marker (connection-level detection)
    sf_guard_enter();

    int sock = ensure_telem_connection(host, port);
    if (sock < 0) {
        if (out_reason) *out_reason = SEND_FAIL_CONNECT;
        sf_guard_leave();  // CRITICAL: Clear flag even on error!
        return 0;
    }

    // ULTRA-FAST: Build header directly on stack WITHOUT snprintf (zero format overhead!)
    // Manual memcpy is 3-5x faster than snprintf for fixed headers
    // CRITICAL: Inject X-Sf3-IsTelemetryMessage header to mark this as telemetry traffic
    char header[1024];
    char *w = header;

    // POST path HTTP/1.1\r\n
    memcpy(w, "POST ", 5); w += 5;
    size_t plen = strlen(path);
    memcpy(w, path, plen); w += plen;
    memcpy(w, " HTTP/1.1\r\nHost: ", 17); w += 17;

    // Host: host:port\r\n
    size_t hlen_host = strlen(host);
    memcpy(w, host, hlen_host); w += hlen_host;
    *w++ = ':';
    // Manual integer formatting (faster than sprintf)
    char portbuf[8];
    int port_digits = 0;
    int p = port;
    do { portbuf[port_digits++] = '0' + (p % 10); p /= 10; } while(p);
    // Reverse digits
    for(int i = port_digits - 1; i >= 0; i--) *w++ = portbuf[i];
    memcpy(w, "\r\nAccept: */*\r\nContent-Type: application/json\r\nContent-Length: ", 63); w += 63;

    // Manual size_t formatting (faster than sprintf)
    char lenbuf[24];
    int len_digits = 0;
    size_t bl = body_len;
    do { lenbuf[len_digits++] = '0' + (bl % 10); bl /= 10; } while(bl);
    // Reverse digits
    for(int i = len_digits - 1; i >= 0; i--) *w++ = lenbuf[i];

    // // Mark as telemetry (allows header-based detection if needed)
    // memcpy(w, "\r\nX-Sf3-IsTelemetryMessage: 1", 30); w += 30;

    // // Connection: keep-alive for socket reuse (eliminates connection churn!)
    // memcpy(w, "\r\nConnection: keep-alive\r\n\r\n", 30); w += 30;


    // With this:
    const char *telemetry = "\r\nX-Sf3-IsTelemetryMessage: 1";
    memcpy(w, telemetry, sizeof("\r\nX-Sf3-IsTelemetryMessage: 1") - 1);
    w += sizeof("\r\nX-Sf3-IsTelemetryMessage: 1") - 1;

    const char *keepalive = "\r\nConnection: keep-alive\r\n\r\n";
    memcpy(w, keepalive, sizeof("\r\nConnection: keep-alive\r\n\r\n") - 1);
    w += sizeof("\r\nConnection: keep-alive\r\n\r\n") - 1;


    int hlen = (int)(w - header);

    // ULTRA-FAST: Use scatter-gather I/O to send header+body in ONE syscall
    struct iovec iov[2];
    iov[0].iov_base = header;
    iov[0].iov_len = hlen;
    iov[1].iov_base = (void*)json_body;
    iov[1].iov_len = body_len;

    struct msghdr msg = {0};
    msg.msg_iov = iov;
    msg.msg_iovlen = 2;

    ssize_t total = hlen + body_len;
    int result = 0;

    // CRITICAL: Check if connection is still alive BEFORE sending (detect server-side close)
    // Use MSG_PEEK to check without consuming data, MSG_DONTWAIT to avoid blocking
    // If server closed, recv() returns 0 (EOF) or -1 with errno != EAGAIN/EWOULDBLOCK
    if (!g_telem_use_tls && real_recv) {
        char probe;
        ssize_t peek_result = real_recv(sock, &probe, 1, MSG_PEEK | MSG_DONTWAIT);
        if (peek_result == 0) {
            // EOF: Server closed the connection - close and let ensure_telem_connection() reconnect
            // Close the dead socket so ensure_telem_connection() will create a fresh one
            if (g_telem_use_tls && g_telem_ssl) { SSL_free(g_telem_ssl); g_telem_ssl = NULL; }
            if (g_telem_sock >= 0) { real_close(g_telem_sock); g_telem_sock = -1; }
            // CRITICAL: Call ensure_telem_connection() again to reconnect!
            sock = ensure_telem_connection(host, port);
            if (sock < 0) {
                sf_guard_leave();
                return 0;
            }
        } else if (peek_result < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
            // Socket error (not just "no data available")
            //     fprintf(stderr, "[SF_DEBUG _sfteepreload] http_post_simple: ✗ SOCKET ERROR on liveness check (errno=%d), closing and reconnecting\n", errno);
            //     fflush(stderr);
            // }
            // Close the bad socket and reconnect
            if (g_telem_use_tls && g_telem_ssl) { SSL_free(g_telem_ssl); g_telem_ssl = NULL; }
            if (g_telem_sock >= 0) { real_close(g_telem_sock); g_telem_sock = -1; }
            // CRITICAL: Call ensure_telem_connection() again to reconnect!
            sock = ensure_telem_connection(host, port);
            if (sock < 0) {
                sf_guard_leave();
                return 0;
            }
        }
        // else: peek_result < 0 with EAGAIN/EWOULDBLOCK = no data (connection is alive!)
    }

    // Write-all helper: loops until all data is sent (handles partial writes for both TCP and TLS)
    int write_success = 0;
    size_t sent = 0;

    // CRITICAL: Enable TCP_CORK before sending to batch writes, then disable to force IMMEDIATE flush
    // This prevents data from getting stuck in TCP buffers with keep-alive connections!
    // Without this, the last 1-3 messages can remain buffered until the next request "unsticks" them
    // NOTE: TCP_CORK is Linux-only; macOS uses TCP_NOPUSH with different semantics
#ifdef __linux__
    int cork = 1;
    if (!g_telem_use_tls && real_setsockopt) {
        // Ignore failures (some platforms/configs may not support TCP_CORK)
        real_setsockopt(sock, IPPROTO_TCP, TCP_CORK, &cork, sizeof(cork));
    }
#endif

    if (g_telem_use_tls) {
        // TLS write loop - CRITICAL: Use real_SSL_write to bypass hooks!
        const char *h = header;
        const char *b = json_body;
        size_t hl = hlen;
        size_t bl = body_len;

        // Write header
        while (hl > 0) {
            int n = real_SSL_write(g_telem_ssl, h, (int)hl);
            if (n <= 0) goto write_failed;
            h += n; hl -= n; sent += n;
        }
        // Write body
        while (bl > 0) {
            int n = real_SSL_write(g_telem_ssl, b, (int)bl);
            if (n <= 0) goto write_failed;
            b += n; bl -= n; sent += n;
        }
        write_success = (sent == (size_t)total);
    } else {
        // TCP write: try sendmsg first (zero-copy), fall back to loop on partial write
        // CRITICAL: Use real_sendmsg to bypass hooks!
        ssize_t nsg = real_sendmsg(sock, &msg, MSG_NOSIGNAL);
        if (nsg < 0) goto write_failed;
        if (nsg == total) {
            write_success = 1;
            sent = total;
        } else {
            // Partial write - finish with send() loop
            sent = nsg;
            const char *h = header;
            const char *b = json_body;
            size_t hl = hlen;
            size_t bl = body_len;

            // Advance pointers based on what was sent
            if ((size_t)nsg < hl) {
                h += nsg; hl -= nsg;
            } else {
                size_t used = (size_t)nsg - hl;
                h += hl; hl = 0;
                b += used; bl -= used;
            }

            // Finish header - CRITICAL: Use real_send to bypass hooks!
            while (hl > 0) {
                ssize_t n = real_send(sock, h, hl, MSG_NOSIGNAL);
                if (n <= 0) goto write_failed;
                h += n; hl -= n; sent += n;
            }
            // Finish body - CRITICAL: Use real_send to bypass hooks!
            while (bl > 0) {
                ssize_t n = real_send(sock, b, bl, MSG_NOSIGNAL);
                if (n <= 0) goto write_failed;
                b += n; bl -= n; sent += n;
            }
            write_success = (sent == (size_t)total);
        }
    }

    // CRITICAL: Disable TCP_CORK to force IMMEDIATE flush of buffered data
    // This ensures data is transmitted NOW (not stuck waiting for more data with keep-alive)
    // Without this, last 1-3 messages can remain buffered until next request "unsticks" them
#ifdef __linux__
    if (!g_telem_use_tls && real_setsockopt) {
        int cork = 0;
        // Ignore failures (some platforms/configs may not support TCP_CORK)
        real_setsockopt(sock, IPPROTO_TCP, TCP_CORK, &cork, sizeof(cork));
    }
#endif

    if (write_success) {
        // CRITICAL: Wait for server response to ensure data was RECEIVED (not just buffered in TCP!)
        // Without this, we claim success when data is stuck in kernel buffers (causes 198/200 bug)
        // Connection reuse = no reconnect overhead = 13k+ req/s sustained!
        // Only close on timeout/error (rare), otherwise reuse forever
        int got_response = 0;
        if (g_telem_use_tls) {
            // TLS: Wait for response (BLOCKING - required for flush guarantee!)
            // CRITICAL: Use real_SSL_read to bypass hooks (prevents phantom http://200 request!)
            // OPTIMIZED: Only read until \r\n\r\n (end of HTTP headers), don't drain entire response body!
            char buf[8192];  // Buffer for headers only
            int n = read_until_double_crlf_tls(g_telem_ssl, buf, sizeof(buf));
            if (n > 0) {
                if (out_reason) *out_reason = SEND_OK;
                got_response = 1;
            } else {
                // Timeout or error
                int e = SSL_get_error(g_telem_ssl, n);
                // CRITICAL: SSL_ERROR_WANT_READ means timeout - this is a FAILURE!
                // Data is stuck in TCP buffers, server hasn't processed it yet
                if (e == SSL_ERROR_WANT_READ || e == SSL_ERROR_WANT_WRITE) {
                    if (out_reason) *out_reason = SEND_FAIL_TIMEOUT;
                    // Close and reconnect - data may be lost
                    SSL_free(g_telem_ssl); g_telem_ssl = NULL;
                    real_close(g_telem_sock); g_telem_sock = -1;
                } else {
                    if (out_reason) *out_reason = SEND_FAIL_SSL;
                    // Real SSL error (connection closed, protocol error, etc.) → close and reconnect
                    SSL_free(g_telem_ssl); g_telem_ssl = NULL;
                    real_close(g_telem_sock); g_telem_sock = -1;
                }
            }
        } else {
            // TCP: Wait for response (BLOCKING - required for flush guarantee!)
            // CRITICAL: Use real_recv to bypass hooks (prevents phantom http://200 request!)
            // OPTIMIZED: Only read until \r\n\r\n (end of HTTP headers), don't drain entire response body!
            char buf[8192];  // Buffer for headers only
            int n = read_until_double_crlf_tcp(sock, buf, sizeof(buf));
            if (n > 0) {
                if (out_reason) *out_reason = SEND_OK;
                got_response = 1;
            } else if (n == 0) {
                // Server closed connection - treat as failure
                if (out_reason) *out_reason = SEND_FAIL_RECV_CLOSE;
                real_close(g_telem_sock); g_telem_sock = -1;
            } else {
                // Timeout or error
                // CRITICAL: EAGAIN/EWOULDBLOCK means TIMEOUT - this is a FAILURE!
                // Data is stuck in TCP buffers, server hasn't processed it yet
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    if (out_reason) *out_reason = SEND_FAIL_TIMEOUT;
                    real_close(g_telem_sock); g_telem_sock = -1;
                } else {
                    if (out_reason) *out_reason = SEND_FAIL_OTHER;
                    // Real error (connection reset, pipe broken, etc.) → close and reconnect
                    real_close(g_telem_sock); g_telem_sock = -1;
                }
            }
        }

        // CRITICAL: Only return success if we got a response (data was RECEIVED, not just buffered!)
        result = got_response ? 1 : 0;
    } else {
write_failed:
        if (out_reason && *out_reason == SEND_FAIL_OTHER) *out_reason = SEND_FAIL_WRITE;
        if (g_telem_use_tls && g_telem_ssl) { SSL_free(g_telem_ssl); g_telem_ssl = NULL; }
        if (g_telem_sock >= 0) { real_close(g_telem_sock); g_telem_sock = -1; }  // Use real_close for telemetry socket
    }

    // CRITICAL: Clear telemetry guard AFTER all network operations complete
    sf_guard_leave();
    return result;
}

// [DIAGNOSTICS] Retry wrapper for http_post_simple_once - retries transient failures
static int http_post_simple(const char *host, int port, const char *path,
                            const char *json_body, size_t body_len,
                            send_result_t *out_reason) {
    int retries = SF_SEND_RETRIES;
    if (SF_STRICT_DELIVERY && retries < 3) retries = 3; // be more stubborn in strict mode

    send_result_t reason = SEND_FAIL_OTHER;
    for (int attempt = 0; attempt <= retries; ++attempt) {
        int ok = http_post_simple_once(host, port, path, json_body, body_len, &reason);
        if (ok) {
            if (out_reason) *out_reason = SEND_OK;
            return 1;
        }

        // Transient classes worth retrying:
        if (reason == SEND_FAIL_TIMEOUT || reason == SEND_FAIL_RECV_CLOSE ||
            reason == SEND_FAIL_WRITE   || reason == SEND_FAIL_CONNECT) {
            // small backoff to let server breathe
            if (attempt < retries) usleep(1000 * (attempt+1)); // 1ms, 2ms, 3ms...
            continue;
        }
        // Non-transient failure (SSL error, etc.) - don't retry
        break;
    }
    if (out_reason) *out_reason = reason;
    return 0;
}

// [DIAGNOSTICS] Watchdog thread - prints ring buffer statistics every 5 seconds
// Tracks occupancy, consumption rate, and producer/consumer waiting counts
#if SF_ENABLE_STATS_WATCHDOG
static void* stats_watchdog_main(void* arg) {
    (void)arg;

    // Track previous values for rate calculation
    uint64_t last_popped = 0;

    while (atomic_load(&g_running)) {
        sleep(5);  // Print every 5 seconds

        // Read current counters
        uint64_t enqueued = atomic_load_explicit(&g_total_enqueued, memory_order_relaxed);
        uint64_t popped = atomic_load_explicit(&g_total_popped, memory_order_relaxed);
        uint64_t sent = atomic_load_explicit(&g_total_sent, memory_order_relaxed);

        // Ring buffer occupancy
        size_t head = atomic_load_explicit(&g_head, memory_order_relaxed);
        size_t tail = atomic_load_explicit(&g_tail, memory_order_relaxed);
        // CRITICAL FIX: Always use (tail - head) for monotonically increasing counters!
        // Old code: (tail > head) ? (tail - head) : 0
        // Problem: Returns 0 when tail <= head, hiding true occupancy in edge cases
        // With monotonic counters, tail >= head ALWAYS (tail only increases, head only increases)
        // Using unsigned arithmetic, (tail - head) is always correct even if they're equal
        size_t occupancy = tail - head;
        int occupancy_pct = g_rcap > 0 ? (int)((occupancy * 100) / g_rcap) : 0;

        // Producer/consumer waiting counts
        int producers_waiting = atomic_load_explicit(&g_producers_waiting, memory_order_relaxed);
        int consumers_waiting = atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed);

        // Calculate consumption rate (events/sec over last 5 seconds)
        uint64_t popped_delta = popped - last_popped;
        double consumption_rate = popped_delta / 5.0;
        last_popped = popped;

        // Calculate deficit (enqueued but not yet sent)
        long long deficit = (long long)enqueued - (long long)sent;

        fprintf(stderr,
          "[SF_STATS_5s] ring(occupancy=%zu/%zu (%d%%), consuming=%.1f events/sec) | "
          "waiting(producers=%d consumers=%d) | "
          "counters(enq=%llu pop=%llu sent=%llu deficit=%lld)\n",
          occupancy, g_rcap, occupancy_pct, consumption_rate,
          producers_waiting, consumers_waiting,
          (unsigned long long)enqueued, (unsigned long long)popped,
          (unsigned long long)sent, deficit);
        fflush(stderr);
    }
    return NULL;
}
#endif

// pthread cleanup handler for sender thread - closes telemetry connection
// Sender thread (raw HTTP or HTTPS)
static void* sender_main(void*arg){
    (void)arg;

    // Ensure TLS cleanup is registered so sockets/SSL handles are closed on thread exit.
    ensure_tls_cleanup_registered();

    // Track allocated host string to free at end
    char *host_heap = NULL;
    const char *host = "sink"; int port = 8001; const char *path = "/graphql/";
    int use_tls = 0;
    if (SF_SINK_URL) {
        const char *p = SF_SINK_URL;
        if (strncmp(p, "http://", 7) == 0) { p += 7; use_tls = 0; port = 80; }
        else if (strncmp(p, "https://", 8) == 0) { p += 8; use_tls = 1; port = 443; }

        const char *colon = strchr(p, ':');
        const char *slash = strchr(p, '/');

        if (colon && (!slash || colon < slash)) {
            size_t hlen = (size_t)(colon - p);
            char *h = (char*)malloc(hlen + 1);
            memcpy(h, p, hlen); h[hlen] = 0;
            host = h;
            host_heap = h;  // Track for cleanup
            port = atoi(colon + 1);
            if (slash) path = slash;
        } else if (slash) {
            size_t hlen = (size_t)(slash - p);
            char *h = (char*)malloc(hlen + 1);
            memcpy(h, p, hlen); h[hlen] = 0;
            host = h;
            host_heap = h;  // Track for cleanup
            path = slash;
        } else {
            host_heap = str_dup(p);
            host = host_heap;
        }
    }

    // Set thread-local TLS mode for this sender thread
    g_telem_use_tls = use_tls;

    // BACKGROUND THREAD: Process raw captured data into JSON and send
    // This is where ALL expensive work happens (URL building, suppression checks, trace IDs, JSON)
    // Hot path just captures raw data with ZERO overhead!
    while (1){
        int running = atomic_load(&g_running);

        // Wait for work (but only if still running - don't wait during shutdown)
        if (running) {
            pthread_mutex_lock(&g_cv_mtx);
            size_t h = atomic_load_explicit(&g_head, memory_order_relaxed);
            size_t t = atomic_load_explicit(&g_tail, memory_order_acquire);
            if (h == t && atomic_load(&g_running)) {
                // CRITICAL FIX: Increment consumer waiting counter before blocking
                int consumers_before = atomic_fetch_add_explicit(&g_consumers_waiting, 1, memory_order_relaxed);

                if (SF_DEBUG && consumers_before == 0) {
                    // First thread going to sleep - log active count
                    fprintf(stderr, "[SF_DEBUG _sfteepreload] Consumer threads: %d active → %d active (1 sleeping)\n",
                            g_num_sender_threads, g_num_sender_threads - 1);
                }

                pthread_cond_wait(&g_cv, &g_cv_mtx);

                // CRITICAL FIX: Decrement after waking up
                int consumers_after = atomic_fetch_sub_explicit(&g_consumers_waiting, 1, memory_order_relaxed);

                // Record wake time for keepalive tracking
                struct timespec ts;
                clock_gettime(CLOCK_MONOTONIC, &ts);
                g_thread_wake_time = ts.tv_sec + ts.tv_nsec / 1e9;

                if (SF_DEBUG && consumers_after == 1) {
                    // Last sleeping thread woke up - log active count
                    fprintf(stderr, "[SF_DEBUG _sfteepreload] Consumer threads: %d active → %d active (all awake)\n",
                            g_num_sender_threads - consumers_after, g_num_sender_threads);
                }

                // CRITICAL DEADLOCK FIX: After waking, check if ring is STILL empty
                // If so, signal any waiting producers - they might be blocked thinking ring is full!
                // This breaks the deadlock where producers wait for consumers, but consumers have no work
                h = atomic_load_explicit(&g_head, memory_order_relaxed);
                t = atomic_load_explicit(&g_tail, memory_order_acquire);
                if (h == t) {
                    // Ring is still empty, but producers might be waiting with stale data
                    int producers_waiting = atomic_load_explicit(&g_producers_waiting, memory_order_relaxed);
                    if (producers_waiting > 0) {
                        if (SF_DEBUG) {
                            fprintf(stderr, "[SF_DEBUG _sfteepreload] Consumer woke but ring empty - signaling %d waiting producers to recheck\n",
                                    producers_waiting);
                        }
                        // Signal all waiting producers to recheck ring status
                        for (int i = 0; i < producers_waiting; i++) {
                            pthread_cond_signal(&g_cv);
                        }
                    }
                }
            }
            pthread_mutex_unlock(&g_cv_mtx);
        }

        // Pop raw captured data
        tee_msg_t msg;
        int had_work = 0;
        while (ring_pop_raw(&msg)){
            had_work = 1;
            // ULTRA-FAST: Build URL on stack (zero malloc!), then strdup only once
            const char *scheme = msg.is_ssl ? "https" : "http";
            const char *mhost = msg.req_host ? msg.req_host : "";
            // Use inline strings directly (no malloc, already copied from offsets)
            const char *target = msg.req_target[0] ? msg.req_target : "/";
            const char *method = msg.req_method[0] ? msg.req_method : "?";

            // Stack buffer - no heap allocation for URL construction!
            char url_buf[2048];  // Stack buffer for URL (plenty for most URLs)
            char *w = url_buf;

            // Manual URL building (faster than sprintf)
            size_t scheme_len = strlen(scheme);
            memcpy(w, scheme, scheme_len); w += scheme_len;
            *w++ = ':'; *w++ = '/'; *w++ = '/';
            size_t host_len = strlen(mhost);
            memcpy(w, mhost, host_len); w += host_len;
            size_t target_len = strlen(target);
            memcpy(w, target, target_len); w += target_len;
            *w = '\0';

            // Use stack buffer directly - NO MALLOC! (eliminates 1 malloc/free per message)
            const char *url = url_buf;

            // Check OTEL endpoints (background thread, not hot path!)
            // Parse host:port from the request to check against configured OTEL endpoints
            if (msg.req_host) {
                char host_buf[256];
                int port = msg.is_ssl ? 443 : 80;  // Default ports
                const char *colon = strchr(msg.req_host, ':');

                if (colon) {
                    // Has port
                    size_t host_len = (size_t)(colon - msg.req_host);
                    if (host_len < sizeof(host_buf)) {
                        memcpy(host_buf, msg.req_host, host_len);
                        host_buf[host_len] = '\0';
                        port = atoi(colon + 1);
                    } else {
                        // Host too long, copy what we can
                        memcpy(host_buf, msg.req_host, sizeof(host_buf) - 1);
                        host_buf[sizeof(host_buf) - 1] = '\0';
                    }
                } else {
                    // No port specified
                    strncpy(host_buf, msg.req_host, sizeof(host_buf) - 1);
                    host_buf[sizeof(host_buf) - 1] = '\0';
                }

                // Check if this matches any OTEL endpoint
                if (is_otel_request(host_buf, port, target)) {
                    // NO FREE needed - url is stack buffer now!
                    goto cleanup_msg;
                }
            }

            // Check Python suppression (background thread, not hot path!)
            if (msg.is_suppressed_by_python) {
                // NO FREE needed - url is stack buffer now!
                goto cleanup_msg;
            }

            // Check URL/path suppression patterns (background thread, not hot path!)
            if (should_suppress_by_pattern(url, target)) {
                // NO FREE needed - url is stack buffer now!
                goto cleanup_msg;
            }

            // Extract X-Sf3-Rid from raw request headers (background thread, not hot path!)
            // X-Sf3-Rid → recordingSessionId (propagates to external services)
            // X-Sf4-Prid → parentRecordingSessionId (already extracted and saved in msg.parent_trace_id BEFORE stripping!)

            // NON-ALLOCATING: Use stack buffers to avoid malloc/free churn (2 mallocs eliminated per message!)
            char recording_session_id_buf[256];
            char parent_recording_session_id_buf[256];
            const char *recording_session_id = "";
            const char *parent_recording_session_id = "";

            // Extract X-Sf3-Rid from headers (still present in req_hdr_raw) - NO MALLOC!
            if (msg.req_hdr_raw && msg.req_hdr_raw_len > 0) {
                if (extract_header_into(msg.req_hdr_raw, msg.req_hdr_raw_len, "X-Sf3-Rid:",
                                       recording_session_id_buf, sizeof(recording_session_id_buf)) >= 0) {
                    recording_session_id = recording_session_id_buf;
                }
            }

            // CRITICAL FIX: Use msg.parent_trace_id instead of extracting from req_hdr_raw
            // The X-Sf4-Prid header was STRIPPED from req_hdr_raw, so extraction would return NULL!
            // We saved the value BEFORE stripping in msg.parent_trace_id
            if (msg.parent_trace_id) {
                parent_recording_session_id = msg.parent_trace_id;  // Use pre-extracted value (no malloc, no free!)
            } else {
                // Fallback: Try to extract from headers (shouldn't happen with new code, but keep for safety) - NO MALLOC!
                if (msg.req_hdr_raw && msg.req_hdr_raw_len > 0) {
                    if (extract_header_into(msg.req_hdr_raw, msg.req_hdr_raw_len, "X-Sf4-Prid:",
                                           parent_recording_session_id_buf, sizeof(parent_recording_session_id_buf)) >= 0) {
                        parent_recording_session_id = parent_recording_session_id_buf;
                    }
                }
            }

            // Build JSON (background thread, not hot path!)
            int status = msg.resp_status;
            int ok = (status>0 && status<400) ? 1 : 0;
            uint64_t start_ms = msg.t_req_start_ns ? (msg.t_req_start_ns / 1000000ULL) : 0;
            uint64_t end_ms = msg.t_resp_last_hdr_ns ? (msg.t_resp_last_hdr_ns / 1000000ULL) : 0;

            size_t json_len = 0;
            char *json = build_event_json(
                /*recordingSessionId (trace_id)*/ recording_session_id,
                /*parentRecordingSessionId (parent_trace_id)*/ parent_recording_session_id,
                url, method,
                status, ok,
                start_ms, end_ms,
                msg.req_hdr_json, msg.resp_hdr_json,
                msg.req_body_sample, msg.req_body_len,
                msg.resp_body_sample, msg.resp_body_len,
                &json_len
            );

            // Send JSON (background thread, not hot path!)
            if (json) {
                send_result_t reason = SEND_FAIL_OTHER;

                int send_ok = http_post_simple(host, port, path, json, json_len, &reason);

                if (send_ok) {
                    // DETERMINISTIC: Increment total sent (for shutdown drain tracking)
                    if (SF_DEBUG) atomic_fetch_add_explicit(&g_total_sent, 1, memory_order_relaxed);
                } else {
                    // Optional strict delivery: requeue once if we must not lose it
                    if (SF_STRICT_DELIVERY) {
                        // NOTE: we do NOT requeue infinitely; rely on http_post_simple retries first.
                        tee_msg_t retry_msg = msg; // shallow copy is OK; we kept ownership until cleanup below
                        (void)ring_push_raw(&retry_msg);
                    }
                }
                free(json);
            }

            // NO FREE needed for url/recording_session_id/parent_recording_session_id - they're all stack buffers now!

cleanup_msg:
            // Free all allocated strings from raw message
            // NOTE: req_method/req_target are inline, no free needed
            free(msg.req_host);
            free(msg.req_hdr_raw);
            free(msg.req_hdr_json);
            free(msg.resp_hdr_json);
            free(msg.req_body_sample);
            free(msg.resp_body_sample);
            free(msg.parent_trace_id);
        }

        // ADAPTIVE SCALE-DOWN: After processing batch, check if we should go back to sleep
        // This implements the scale-down side of tiered thread management
        if (had_work && atomic_load(&g_running)) {
            size_t h = atomic_load_explicit(&g_head, memory_order_relaxed);
            size_t t = atomic_load_explicit(&g_tail, memory_order_acquire);
            size_t current_occupancy = t - h;
            int threads_needed = calculate_threads_needed(current_occupancy);
            int threads_sleeping = atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed);
            int threads_active = g_num_sender_threads - threads_sleeping;

            // If we have more active threads than needed, voluntarily go back to sleep
            if (threads_active > threads_needed && threads_needed > 0) {
                // KEEPALIVE: Only sleep if we've been awake longer than keepalive threshold
                // This prevents rapid wake/sleep thrashing during brief load blips
                struct timespec ts;
                clock_gettime(CLOCK_MONOTONIC, &ts);
                double current_time = ts.tv_sec + ts.tv_nsec / 1e9;
                double time_awake = current_time - g_thread_wake_time;

                if (time_awake >= SF_THREAD_KEEPALIVE) {
                    pthread_mutex_lock(&g_cv_mtx);
                    // Double-check condition while holding lock (avoid race with wakeup)
                    threads_sleeping = atomic_load_explicit(&g_consumers_waiting, memory_order_relaxed);
                    threads_active = g_num_sender_threads - threads_sleeping;
                    if (threads_active > threads_needed) {
                        // Voluntarily sleep (will be woken if occupancy increases)
                        int sleeping_before = atomic_fetch_add_explicit(&g_consumers_waiting, 1, memory_order_relaxed);

                        if (SF_DEBUG) {
                            fprintf(stderr, "[SF_DEBUG _sfteepreload] Consumer threads: %d active → %d active (keepalive expired, scaling down)\n",
                                    threads_active, threads_active - 1);
                        }

                        pthread_cond_wait(&g_cv, &g_cv_mtx);
                        atomic_fetch_sub_explicit(&g_consumers_waiting, 1, memory_order_relaxed);

                        // Record new wake time
                        clock_gettime(CLOCK_MONOTONIC, &ts);
                        g_thread_wake_time = ts.tv_sec + ts.tv_nsec / 1e9;
                    }
                    pthread_mutex_unlock(&g_cv_mtx);
                }
            }
        }

        // DETERMINISTIC SHUTDOWN: Wait until sent == enqueued (not just head >= tail!)
        // This guarantees ALL enqueued messages are sent before exiting
        if (!atomic_load(&g_running)) {
            size_t h = atomic_load_explicit(&g_head, memory_order_acquire);
            size_t t = atomic_load_explicit(&g_tail, memory_order_acquire);

            // When SF_DEBUG is active, check both counters AND ring state for deterministic shutdown
            // When SF_DEBUG is off, only check ring state (counters not maintained for performance)
            int shutdown_complete = 0;
            if (SF_DEBUG) {
                uint64_t enqueued = atomic_load_explicit(&g_total_enqueued, memory_order_acquire);
                uint64_t sent = atomic_load_explicit(&g_total_sent, memory_order_acquire);
                shutdown_complete = (sent >= enqueued && h >= t);
            } else {
                shutdown_complete = (h >= t);
            }

            if (shutdown_complete) {
                // DETERMINISTIC: All enqueued messages have been sent AND ring is empty
                break;
            }
        }
    }

    if (g_telem_ssl) {
        SSL_free(g_telem_ssl);
        g_telem_ssl = NULL;
    }
    if (g_telem_sock >= 0) {
        if (real_close) {
            real_close(g_telem_sock);
        } else {
            close(g_telem_sock);
        }
        g_telem_sock = -1;
    }
    sf_guard_leave();

    // Free allocated host string
    free(host_heap);

    return NULL;
}

// ============================= HTTP mini-parser =============================
typedef enum { DIR_TX=0, DIR_RX=1 } dir_t;

struct conn_state {
    int       active;
    int       is_ssl;         // 0=plain, 1=ssl
    void     *ssl_ptr;        // SSL* when is_ssl=1
    int       fd;             // socket fd
    int       is_outbound;    // 1 = client socket (connect), 0 = server socket (accept) - only capture outbound!
    // request
    int       have_req_line;
    int       have_req_hdrs;
    uint64_t  t_req_start_ns;
    // ULTRA-FAST: Store method/target as small inline strings (no malloc!)
    // Most methods are 3-7 bytes (GET, POST, PUT, DELETE), most paths < 256
    char      req_method[16];     // Inline method string (GET, POST, etc)
    char      req_target[256];    // Inline target string (path part of URL)
    char     *req_host;
    char     *req_hdr_raw;        // malloc'd - raw request headers (for extracting X-Sf3-Rid)
    size_t    req_hdr_raw_len;
    char     *parent_trace_id;    // malloc'd - extracted X-Sf4-Prid value (saved before stripping)
    char     *req_hdr_json;
    size_t    req_content_length;    // Content-Length from request headers (SIZE_MAX = unknown)
    size_t    req_body_len;
    char     *req_body_sample;
    int       req_capture_complete;  // Set to 1 when req headers+body sampling complete (ULTRA-FAST early return)
    int       outbound_headers_processed;  // OPTIMIZATION: Set to 1 after first process_outbound_headers() call (prevents re-scanning)
    int       is_http2;            // OPTIMIZATION: Set to 1 if HTTP/2 detected (skip all header parsing)
    char      parent_trace_id_inline[512];  // OPTIMIZATION: Fixed buffer for parent_trace_id (avoids malloc in 99% of cases)
    // response
    int       have_resp_line;
    int       have_resp_hdrs;
    uint64_t  t_resp_last_hdr_ns;
    int       resp_status;
    char     *resp_hdr_json;
    size_t    resp_content_length;   // Content-Length from response headers (SIZE_MAX = unknown)
    size_t    resp_body_len;
    char     *resp_body_sample;
    int       resp_capture_complete;  // Set to 1 when resp headers+body sampling complete (ULTRA-FAST early return)
    // scratch for header accumulation
    char     *hdr_buf;
    size_t    hdr_len;
    size_t    hdr_cap;
    size_t    hdr_search_pos;  // Last position searched for CRLFCRLF (incremental search optimization)
    int       req_done_once;
    int       resp_done_once;
    // Python suppression cache (only used if SF_ENABLE_PYTHON_FILTERS=1)
    int       python_suppression_checked;  // 1 if we've checked Python suppression (cache valid)
    int       is_suppressed_by_python;     // Cached result: 1 if suppressed, 0 if not
    // Inline buffers to avoid malloc in 99% of cases (most headers/bodies < 8KB)
    char      hdr_buf_inline[8192];
    char      req_body_inline[8192];     // Inline request body buffer (avoids malloc!)
    char      resp_body_inline[8192];    // Inline response body buffer (avoids malloc!)
};

// ULTRA-FAST LOCK-FREE STATE ARRAYS: Direct-indexed atomic pointers for zero-overhead lookups
// This replaces the previous hash bucket + mutex approach for 100-250x speedup on hot path
// (STATE_ARRAY_FD_SIZE and STATE_ARRAY_SSL_SIZE already declared at top of file - see lines 174-175)
static _Atomic(conn_state_t*) g_state_array_fd[STATE_ARRAY_FD_SIZE];
static _Atomic(conn_state_t*) g_state_array_ssl[STATE_ARRAY_SSL_SIZE];
static pthread_mutex_t g_state_create_mtx = PTHREAD_MUTEX_INITIALIZER;  // Only for state creation

// (Skip bitmap and helper functions already declared at top of file - see lines 172-198)

static conn_state_t* get_state_fd(int fd, int create){
    // Validate FD range
    if (fd < 0 || fd >= STATE_ARRAY_FD_SIZE) return NULL;

    // ULTRA-FAST PATH: Lock-free atomic load (2-3ns vs 250-500ns with mutex!)
    // This is the common case - state already exists
    conn_state_t *s = atomic_load_explicit(&g_state_array_fd[fd], memory_order_acquire);

    if (s) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] get_state_fd: reuse state=%p fd=%d\n",
                  (void*)s, fd);
        return s;
    }
    if (!create) return NULL;

    // SLOW PATH (first packet only): Create new state with mutex
    // This happens once per connection, so mutex overhead is acceptable
    pthread_mutex_lock(&g_state_create_mtx);

    // Double-check after acquiring lock (another thread may have created it)
    s = atomic_load_explicit(&g_state_array_fd[fd], memory_order_acquire);
    if (!s) {
        s = (conn_state_t*)calloc(1, sizeof(conn_state_t));
        if (s) {
            s->fd = fd;
            s->req_content_length = SIZE_MAX;  // Unknown until parsed
            s->resp_content_length = SIZE_MAX; // Unknown until parsed
            atomic_store_explicit(&g_state_array_fd[fd], s, memory_order_release);

            // OBSERVABILITY: Track active fd states (increment on create)
            atomic_fetch_add_explicit(&g_active_fd_states, 1, memory_order_relaxed);
            DEBUG_LOG("[SF_DEBUG _sfteepreload] get_state_fd: created state=%p fd=%d\n",
                      (void*)s, fd);
        }
    }

    pthread_mutex_unlock(&g_state_create_mtx);
    return s;
}
static conn_state_t* get_state_ssl(void *ssl, int create){
    if (!ssl) return NULL;

    // Hash SSL pointer to array index
    size_t idx = idx_ptr(ssl);

    // ULTRA-FAST PATH: Lock-free atomic load (2-3ns vs 250-500ns with mutex!)
    // For SSL we store the pointer in the state and check for match
    conn_state_t *s = atomic_load_explicit(&g_state_array_ssl[idx], memory_order_acquire);

    // Linear probing for collision resolution (rare with 8192 slots)
    for (int probe = 0; probe < 16 && s; probe++) {
        if (s->ssl_ptr == ssl) {
            DEBUG_LOG("[SF_DEBUG _sfteepreload] get_state_ssl: reuse state=%p ssl=%p idx=%zu probe=%d\n",
                      (void*)s, ssl, idx, probe);
            return s;
        }
        // Try next slot
        idx = (idx + 1) % STATE_ARRAY_SSL_SIZE;
        s = atomic_load_explicit(&g_state_array_ssl[idx], memory_order_acquire);
    }

    if (!create) return NULL;

    // SLOW PATH (first packet only): Create new state with mutex
    pthread_mutex_lock(&g_state_create_mtx);

    // CRITICAL FIX #3: Proper open-addressing insertion with infinite loop
    // The old code had a bug: it would cap at 16 probes and return the wrong state
    // if no empty slot was found, causing states to be "lost" (unfindable → never freed)
    idx = idx_ptr(ssl);
    for (;;) {
        s = atomic_load_explicit(&g_state_array_ssl[idx], memory_order_acquire);
        if (!s) {
            // Found empty slot - create new state
            s = (conn_state_t*)calloc(1, sizeof(conn_state_t));
            if (s) {
                s->ssl_ptr = ssl;
                s->is_ssl = 1;
                s->req_content_length = SIZE_MAX;  // Unknown until parsed
                s->resp_content_length = SIZE_MAX; // Unknown until parsed
                atomic_store_explicit(&g_state_array_ssl[idx], s, memory_order_release);

                // OBSERVABILITY: Track active SSL states (increment on create)
                atomic_fetch_add_explicit(&g_active_ssl_states, 1, memory_order_relaxed);
                DEBUG_LOG("[SF_DEBUG _sfteepreload] get_state_ssl: created state=%p ssl=%p idx=%zu\n",
                          (void*)s, ssl, idx);
            }
            pthread_mutex_unlock(&g_state_create_mtx);
            return s;
        }
        if (s->ssl_ptr == ssl) {
            // Another thread created it while we waited for lock
            pthread_mutex_unlock(&g_state_create_mtx);
            return s;
        }
        // Collision - try next slot
        idx = (idx + 1) % STATE_ARRAY_SSL_SIZE;
    }
}

static void free_state(conn_state_t *s){
    if (!s) return;
    // NOTE: req_method/req_target are now offsets, not pointers - no free needed!
    free(s->req_host);
    free(s->req_hdr_raw);  // CRITICAL: Free raw headers (used for X-Sf3-Rid extraction)
    free(s->parent_trace_id);  // CRITICAL: Free extracted X-Sf4-Prid (MEMORY LEAK FIX!)
    free(s->req_hdr_json);
    free(s->resp_hdr_json);

    // Only free body samples if they're NOT pointing to inline buffers
    if (s->req_body_sample && s->req_body_sample != s->req_body_inline) {
        free(s->req_body_sample);
    }
    if (s->resp_body_sample && s->resp_body_sample != s->resp_body_inline) {
        free(s->resp_body_sample);
    }

    // Only free hdr_buf if it's not pointing to inline buffer
    if (s->hdr_buf && s->hdr_buf != s->hdr_buf_inline) {
        free(s->hdr_buf);
    }
    memset(s,0,sizeof(*s));
}

// Reset state for the next HTTP request on a keep-alive connection
// This preserves the fd/ssl_ptr but clears everything else
static void reset_state_for_next_request(conn_state_t *s){
    if (!s) return;

    // Save the connection identifiers AND is_outbound flag!
    int saved_fd = s->fd;
    int saved_is_ssl = s->is_ssl;
    void *saved_ssl_ptr = s->ssl_ptr;
    int saved_is_outbound = s->is_outbound;  // CRITICAL: Must preserve for keep-alive!

    // Free all allocated memory (NOTE: req_method/req_target are offsets, not pointers!)
    free(s->req_host);
    free(s->req_hdr_raw);
    free(s->parent_trace_id);  // Free extracted parent_trace_id (if not transferred to message)
    free(s->req_hdr_json);
    free(s->resp_hdr_json);

    // Only free body samples if they're NOT pointing to inline buffers
    if (s->req_body_sample && s->req_body_sample != s->req_body_inline) {
        free(s->req_body_sample);
    }
    if (s->resp_body_sample && s->resp_body_sample != s->resp_body_inline) {
        free(s->resp_body_sample);
    }

    // Only free hdr_buf if it's not pointing to inline buffer
    if (s->hdr_buf && s->hdr_buf != s->hdr_buf_inline) {
        free(s->hdr_buf);
    }

    // Zero out the entire structure (this also clears python_suppression_checked and is_suppressed_by_python)
    memset(s, 0, sizeof(*s));

    // Restore the connection identifiers AND is_outbound flag!
    s->fd = saved_fd;
    s->is_ssl = saved_is_ssl;
    s->ssl_ptr = saved_ssl_ptr;
    s->is_outbound = saved_is_outbound;  // CRITICAL: Restore for keep-alive connections!
}

// Forward declarations for real_* function pointers
static ssize_t (*real_send)(int,const void*,size_t,int);
static int (*real_setsockopt)(int, int, int, const void*, socklen_t);

// Remove and free state from atomic array
static void remove_state_fd(int fd){
    if (fd < 0 || fd >= STATE_ARRAY_FD_SIZE) return;

    // Unmark skip bit to allow reuse (connection died, SSL object freed, etc.)
    unmark_skip((size_t)fd);

    // Atomically swap out the pointer and free the state
    conn_state_t *s = atomic_exchange_explicit(&g_state_array_fd[fd], NULL, memory_order_acq_rel);
    if (s) {
        free_state(s);
        free(s);

        // OBSERVABILITY: Track active fd states (decrement on remove)
        atomic_fetch_sub_explicit(&g_active_fd_states, 1, memory_order_relaxed);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] remove_state_fd: fd=%d removed state=%p\n",
                  fd, (void*)s);
    } else {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] remove_state_fd: fd=%d no existing state\n", fd);
    }
}

static int remove_state_fd_if_matches(int fd, conn_state_t *expected, const char *origin){
    if (fd < 0 || fd >= STATE_ARRAY_FD_SIZE || !expected) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] remove_state_fd_if_matches: skip fd=%d expected=%p origin=%s\n",
                  fd, (void*)expected, origin ? origin : "(null)");
        return 0;
    }

    conn_state_t *current = expected;
    if (!atomic_compare_exchange_strong_explicit(&g_state_array_fd[fd],
                                                 &current,
                                                 NULL,
                                                 memory_order_acq_rel,
                                                 memory_order_acquire)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] remove_state_fd_if_matches: mismatch fd=%d origin=%s current=%p expected=%p\n",
                  fd, origin ? origin : "(null)", (void*)current, (void*)expected);
        return 0;
    }

    unmark_skip(idx_fd(fd));
    free_state(expected);
    free(expected);
    atomic_fetch_sub_explicit(&g_active_fd_states, 1, memory_order_relaxed);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] remove_state_fd_if_matches: removed fd=%d origin=%s state=%p\n",
              fd, origin ? origin : "(null)", (void*)expected);
    return 1;
}

static void remove_state_ssl(void *ssl){
    if (!ssl) return;

    // Unmark skip bit to allow reuse (SSL object freed, connection died, etc.)
    unmark_skip(idx_ptr(ssl));

    // Find the SSL state using linear probing
    size_t idx = idx_ptr(ssl);
    for (int probe = 0; probe < 16; probe++) {
        conn_state_t *s = atomic_load_explicit(&g_state_array_ssl[idx], memory_order_acquire);
        if (s && s->ssl_ptr == ssl) {
            // Found it - atomically swap out and free
            s = atomic_exchange_explicit(&g_state_array_ssl[idx], NULL, memory_order_acq_rel);
            if (s) {
                free_state(s);
                free(s);

                // OBSERVABILITY: Track active SSL states (decrement on remove)
                atomic_fetch_sub_explicit(&g_active_ssl_states, 1, memory_order_relaxed);
            }
            return;
        }
        if (!s) return;  // Empty slot, not found
        idx = (idx + 1) % STATE_ARRAY_SSL_SIZE;
    }
}

static int hdr_append(conn_state_t *s, const char *p, size_t n){
    // ULTRA-FAST PATH: Use inline buffer if not yet allocated (99% of requests)
    if (__builtin_expect(!s->hdr_buf, 0)) {
        s->hdr_buf = s->hdr_buf_inline;
        s->hdr_cap = sizeof(s->hdr_buf_inline);
    }

    // Check if we need more space
    if (__builtin_expect(s->hdr_len + n + 1 > s->hdr_cap, 0)){
        // Only realloc if we're already using heap memory
        if (s->hdr_buf == s->hdr_buf_inline) {
            // First overflow - allocate heap memory
            size_t nc = s->hdr_cap * 2;
            while (nc < s->hdr_len+n+1) nc <<= 1;
            char *nb = (char*)malloc(nc);
            if (!nb) return 0;
            memcpy(nb, s->hdr_buf, s->hdr_len);
            s->hdr_buf = nb;
            s->hdr_cap = nc;
        } else {
            // Already on heap - realloc
            size_t nc = s->hdr_cap * 2;
            while (nc < s->hdr_len+n+1) nc <<= 1;
            char *nb = (char*)realloc(s->hdr_buf, nc);
            if (!nb) return 0;
            s->hdr_buf = nb;
            s->hdr_cap = nc;
        }
    }
    memcpy(s->hdr_buf + s->hdr_len, p, n);
    s->hdr_len += n; s->hdr_buf[s->hdr_len] = 0;
    return 1;
}

// simple header → JSON (very small; last-wins)
static int sb_put_json_esc_range(sb_t *sb, const char *p, size_t n){
    return sb_put_json_esc(sb, p, n);
}

// ULTRA-FAST: Extract ONLY the Host header without building JSON (single-pass scan!)
// Used when SF_CAPTURE_REQ_HEADERS=0 to avoid expensive JSON serialization
// This is 3-5x faster than strstr-based approach - only scans for 'H'/'h' at line starts
static char* extract_host_header(const char *hdrs){
    const char *p = hdrs;

    // Skip first line (request line: "GET / HTTP/1.1\r\n")
    while (*p && !(*p == '\r' && p[1] == '\n')) p++;
    if (!*p) return NULL;
    p += 2;  // Skip \r\n

    // Single-pass scan: Look for 'H' or 'h' at line start, then verify "ost:"
    // This is WAY faster than strstr on every line!
    while (*p) {
        // Check for end of headers (empty line: \r\n\r\n)
        if (*p == '\r' && p[1] == '\n') break;

        // ULTRA-FAST: Only check lines starting with 'H' or 'h'
        // This skips 90%+ of headers instantly (Content-Length, User-Agent, etc.)
        if (__builtin_expect(*p == 'H' || *p == 'h', 0)) {
            // Verify "Host:" (case-insensitive)
            if ((p[1]=='o'||p[1]=='O') && (p[2]=='s'||p[2]=='S') &&
                (p[3]=='t'||p[3]=='T') && p[4]==':') {

                // Found Host header! Extract value
                const char *v = p + 5;
                while (*v == ' ' || *v == '\t') v++;  // Skip whitespace

                // Find end of line
                const char *eol = v;
                while (*eol && !(*eol == '\r' && eol[1] == '\n')) eol++;

                size_t vn = (size_t)(eol - v);
                char *host = (char*)malloc(vn + 1);
                if (host) {
                    memcpy(host, v, vn);
                    host[vn] = 0;
                }
                return host;
            }
        }

        // Skip to next line (find \r\n)
        while (*p && !(*p == '\r' && p[1] == '\n')) p++;
        if (*p) p += 2;  // Skip \r\n
    }
    return NULL;
}

static char* headers_to_json(const char *hdrs, int is_request, char **host_out){
    const char *p = strstr(hdrs, "\r\n");
    if (!p) return str_dup("{}");
    p += 2;
    sb_t sb={0};
    if (!sb_putc(&sb,'{')) goto fail;
    int first=1;
    while (*p){
        const char *eol = strstr(p,"\r\n");
        if (!eol) break;
        if (eol==p){ break; }
        const char *colon = memchr(p, ':', (size_t)(eol-p));
        if (colon){
            const char *k=p; size_t kn = (size_t)(colon-p);
            const char *v=colon+1; while (v<eol && (*v==' '||*v=='\t')) v++;
            size_t vn = (size_t)(eol-v);
            if (!first) { if(!sb_putc(&sb,',')) goto fail; } first=0;
            if (!sb_put_json_esc_range(&sb, k, kn)) goto fail;
            if (!sb_putc(&sb,':')) goto fail;
            if (!sb_put_json_esc_range(&sb, v, vn)) goto fail;

            if (host_out && *host_out==NULL){
                if (kn==4 && (k[0]=='H'||k[0]=='h')&&(k[1]=='o'||k[1]=='O')&&(k[2]=='s'||k[2]=='S')&&(k[3]=='t'||k[3]=='T')) {
                    *host_out = (char*)malloc(vn+1); if (*host_out){ memcpy(*host_out,v,vn); (*host_out)[vn]=0; }
                }
            }
        }
        p = eol+2;
    }
    if (!sb_putc(&sb,'}')) goto fail;
    if (!sb_grow(&sb,1)) goto fail; sb.buf[sb.len]=0;
    return sb.buf;
fail:
    free(sb.buf); return str_dup("{}");
}

// parse request/status lines quickly - copies into inline buffers (no malloc!)
static void parse_req_line(conn_state_t *s){
    const char *nl = strstr(s->hdr_buf, "\r\n");
    if (!nl) {
        return;
    }
    const char *sp1 = memchr(s->hdr_buf, ' ', (size_t)(nl - s->hdr_buf));
    if (!sp1) return;
    const char *sp2 = memchr(sp1+1, ' ', (size_t)(nl - (sp1+1)));
    if (!sp2) return;

    // CRITICAL FIX: Reject obvious response lines ("HTTP/1.") to prevent phantom events
    // This prevents "HTTP/1.1 200 OK" from being parsed as method="HTTP/1.1", target="200"
    if ((size_t)(sp1 - s->hdr_buf) >= 5 && strncmp(s->hdr_buf, "HTTP/", 5) == 0) {
        return;  // Don't populate req_method/req_target from a status line
    }

    // ULTRA-FAST: Copy method and target into inline buffers (small strings, no malloc!)
    // This must happen NOW before hdr_buf gets reused for response headers
    size_t method_len = (size_t)(sp1 - s->hdr_buf);
    size_t target_len = (size_t)(sp2 - (sp1+1));

    // Copy method (bounded by buffer size)
    size_t method_copy = minz(method_len, sizeof(s->req_method) - 1);
    if (method_copy > 0) {
        memcpy(s->req_method, s->hdr_buf, method_copy);
        s->req_method[method_copy] = '\0';
    }

    // Copy target (bounded by buffer size)
    size_t target_copy = minz(target_len, sizeof(s->req_target) - 1);
    if (target_copy > 0) {
        memcpy(s->req_target, sp1+1, target_copy);
        s->req_target[target_copy] = '\0';
    }

    s->have_req_line = 1;

    // [FIX] CRITICAL: Unmark skip for HTTP keep-alive connection reuse!
    // When the SAME fd/SSL handles a NEW request (keep-alive), we need to unmark the skip bit
    // that was set after the PREVIOUS request completed. Without this, the 2nd+ request on a
    // keep-alive connection would be blocked by should_skip() returning true.
    // This fixes the "1 message lost on second batch" bug where keep-alive connections
    // were permanently marked skip after their first request.
    if (s->req_done_once || s->resp_done_once) {
        // This is a REUSED connection (was previously marked done)
        // [STATS-ONLY] atomic_fetch_add_explicit(&g_stat_keepalive_reuse, 1, memory_order_relaxed);
        if (s->is_ssl && s->ssl_ptr) {
            unmark_skip(idx_ptr(s->ssl_ptr));
        } else if (s->fd >= 0) {
            unmark_skip(idx_fd(s->fd));
        }
    }
}
static void parse_status_line(conn_state_t *s){
    const char *nl = strstr(s->hdr_buf, "\r\n");
    if (!nl) return;
    const char *sp1 = memchr(s->hdr_buf, ' ', (size_t)(nl - s->hdr_buf));
    if (!sp1) return;
    int code = 0;
    if (sp1+4 <= nl){
        if (sp1[1]>='0' && sp1[1]<='9' && sp1[2]>='0'&&sp1[2]<='9' && sp1[3]>='0'&&sp1[3]<='9'){
            code = (sp1[1]-'0')*100 + (sp1[2]-'0')*10 + (sp1[3]-'0');
        }
    }
    s->resp_status = code;
    s->have_resp_line = 1;
}

// Forward declarations for Python ContextVar access
static char* get_trace_id(void);
static char* get_funcspan_override(void);

// on seeing CRLFCRLF, seal headers and produce req/resp header JSON + host
// Extract Content-Length from HTTP headers
// Returns SIZE_MAX if not found or invalid
static size_t extract_content_length(const char *headers) {
    if (!headers) return SIZE_MAX;

    // Case-insensitive search for "Content-Length:" or "content-length:"
    const char *p = headers;
    while (*p) {
        // Look for 'C' or 'c' at start of line
        if ((*p == 'C' || *p == 'c') &&
            (p == headers || p[-1] == '\n')) {
            // Check for "ontent-length:" (case insensitive)
            const char *check = "ontent-length:";
            const char *q = p + 1;
            int match = 1;
            for (int i = 0; check[i]; i++) {
                if (*q != check[i] && *q != (check[i] - 32)) {  // Handle case difference
                    match = 0;
                    break;
                }
                q++;
            }
            if (match && *q) {
                // Skip whitespace after colon
                while (*q == ' ' || *q == '\t') q++;
                // Parse number
                size_t len = 0;
                while (*q >= '0' && *q <= '9') {
                    len = len * 10 + (*q - '0');
                    q++;
                }
                return len;
            }
        }
        p++;
    }
    return SIZE_MAX;
}

static void seal_headers(dir_t dir, conn_state_t *s, size_t hdr_total){
    if (dir==DIR_TX && !s->have_req_hdrs){
        if (!s->have_req_line) parse_req_line(s);

        // ULTRA-FAST: Only build JSON if we're actually going to send it!
        // When SF_CAPTURE_REQ_HEADERS=0, we skip expensive JSON serialization
        // but still extract Host header for OTEL endpoint detection
        if (__builtin_expect(SF_CAPTURE_REQ_HEADERS, 1)) {
            // Full path: Build JSON and extract Host as side effect
            char *host = NULL;
            s->req_hdr_json = headers_to_json(s->hdr_buf, 1, &host);
            if (host) s->req_host = host;
        } else {
            // Fast path: Extract ONLY Host header (10-100x faster!)
            s->req_host = extract_host_header(s->hdr_buf);
            s->req_hdr_json = NULL;  // Will be set to "{}" in build_event_json if needed
        }

        // CRITICAL FIX: Capture raw request headers for X-Sf3-Rid extraction
        // Copy ONLY the header bytes (hdr_total), NOT the entire buffer which may include body!
        if (s->hdr_buf && hdr_total > 0) {
            s->req_hdr_raw = (char*)malloc(hdr_total);
            if (s->req_hdr_raw) {
                memcpy(s->req_hdr_raw, s->hdr_buf, hdr_total);
                s->req_hdr_raw_len = hdr_total;  // ✅ headers only, no body bleed
            }
        }

        // Extract Content-Length from request headers (for pipelined request handling)
        s->req_content_length = extract_content_length(s->hdr_buf);

        s->have_req_hdrs = 1;
        s->t_req_start_ns = s->t_req_start_ns ? s->t_req_start_ns : now_ns();

        // Trace ID comes from TLS pointer (sf_tls_parent_trace_id) or X-Sf3-Rid header
        // NO Python calls on hot path - zero GIL overhead!

        // OTEL endpoint checks moved to background thread (sender_main)
        // Thread-local g_in_telemetry_send flag provides complete protection for sender threads
        // No need for header-based detection anymore!
    } else if (dir==DIR_RX && !s->have_resp_hdrs){
        if (!s->have_resp_line) parse_status_line(s);

        // ULTRA-FAST: Only build JSON if we're actually going to send it!
        // When SF_CAPTURE_RESP_HEADERS=0, we skip expensive JSON serialization entirely
        if (__builtin_expect(SF_CAPTURE_RESP_HEADERS, 1)) {
            s->resp_hdr_json = headers_to_json(s->hdr_buf, 0, NULL);
        } else {
            s->resp_hdr_json = NULL;  // Will be set to "{}" in build_event_json if needed
        }

        // Extract Content-Length from response headers (CRITICAL for handling pipelined responses!)
        s->resp_content_length = extract_content_length(s->hdr_buf);

        s->have_resp_hdrs = 1;
        s->t_resp_last_hdr_ns = now_ns();
    }
}

// ULTRA-FAST: Find "\r\n\r\n" using simple state machine (~3x faster than memmem!)
// memmem() uses Boyer-Moore-Horspool which is overkill for a 4-byte needle.
// This simple byte-by-byte scan with branch prediction is much faster for short patterns.
// Robust implementation: no overrun, no partial matches
static inline __attribute__((always_inline)) char* find_crlfcrlf(const char *buf, size_t len) {
    if (__builtin_expect(len < 4, 0)) return NULL;

    const char *p = buf;
    const char *end = buf + len - 3;  // Safe upper bound for 4-byte pattern

    while (p < end) {
        /* Fast skip: most bytes are NOT '\r' */
        if (__builtin_expect(*p != '\r', 1)) {
            p++;
            continue;
        }

        /* Found '\r', verify we have room for full pattern and check sequence */
        if (__builtin_expect((p + 3 < buf + len) &&
                            p[1] == '\n' && p[2] == '\r' && p[3] == '\n', 0)) {
            return (char*)p;  // Found CRLFCRLF!
        }

        p++;
    }

    return NULL;
}

// ULTRA-FAST HTTP detection with branch prediction hints and byte precheck
// Returns: 1=HTTP, 0=not HTTP, -1=unknown (too small)
static inline __attribute__((always_inline)) int is_likely_http(const char *buf, size_t n) {
    if (__builtin_expect(n < 4, 0)) return -1; // Too small

    const unsigned char *p = (const unsigned char *)buf;
    unsigned char first = p[0];

    // ULTRA-FAST: HTTP/2 preface check (PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n)
    // If we see "PRI ", immediately mark as non-HTTP/1.1 (we don't support H2 yet)
    if (__builtin_expect(first == 'P' && n >= 4 && p[1] == 'R' && p[2] == 'I' && p[3] == ' ', 0)) {
        return 0;  // HTTP/2 preface - not supported, skip immediately!
    }

    // ULTRA-FAST: Single-byte precheck eliminates 90%+ of binary protocols instantly!
    // HTTP methods: G(ET), P(OST/UT/ATCH), H(EAD/TTP), D(ELETE), O(PTIONS), T(RACE), C(ONNECT)
    // If first byte isn't one of these, it's definitely not HTTP (instant return!)
    if (__builtin_expect(first != 'G' && first != 'P' && first != 'H' &&
                         first != 'D' && first != 'O' && first != 'T' && first != 'C', 0)) {
        return 0;  // Not HTTP - binary protocol (PostgreSQL, Redis, etc.) - INSTANT RETURN!
    }

    // Now check full method (only for potential HTTP traffic)
    if (first == 'G' && p[1] == 'E' && p[2] == 'T' && p[3] == ' ') return 1;
    if (first == 'P') {
        if (p[1] == 'O' && p[2] == 'S' && p[3] == 'T') return 1;  // POST
        if (p[1] == 'U' && p[2] == 'T' && p[3] == ' ') return 1;  // PUT
        if (p[1] == 'A' && p[2] == 'T' && p[3] == 'C') return 1;  // PATCH
    }
    if (first == 'H') {
        if (p[1] == 'E' && p[2] == 'A' && p[3] == 'D') return 1;  // HEAD
        // REMOVED: "HTTP" check - that matches responses (HTTP/1.1 200 OK), not requests!
        // We ONLY inject into outbound requests, never responses
    }
    if (first == 'D' && p[1] == 'E' && p[2] == 'L' && p[3] == 'E') return 1;  // DELETE
    if (first == 'O' && p[1] == 'P' && p[2] == 'T' && p[3] == 'I') return 1;  // OPTIONS
    if (first == 'T' && p[1] == 'R' && p[2] == 'A' && p[3] == 'C') return 1;  // TRACE
    if (first == 'C' && p[1] == 'O' && p[2] == 'N' && p[3] == 'N') return 1;  // CONNECT

    return 0; // Not HTTP
}

// Forward declaration for maybe_emit (defined later in file)
static inline void maybe_emit(conn_state_t *s);

// consume stream bytes, looking for CRLFCRLF then sample body
// NOTE: Removed __attribute__((always_inline)) because this function is now recursive (handles pipelined HTTP)
__attribute__((hot))
static inline void feed_stream(dir_t dir, conn_state_t *s, const char *buf, size_t n){
    DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: entry dir=%d state=%p len=%zu\n",
              dir, (void*)s, n);

    if (__builtin_expect(!s, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: NULL state dir=%d len=%zu\n",
                  dir, n);
        return;
    }

    // CRITICAL: Only capture OUTBOUND (client) sockets - skip server-side accept() sockets immediately!
    // This prevents phantom events from server→client responses being parsed as requests
    if (__builtin_expect(!s->is_outbound, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p outbound=0 len=%zu skip\n",
                  dir, (void*)s, n);
        return;
    }

    // ULTRA-FAST EARLY RETURN: If capture complete, instant return (5ns vs 1-2µs processing)
    // This is THE KEY optimization for bulk data transfer after headers are captured!
    if (__builtin_expect(dir == DIR_TX && s->req_capture_complete, 0)) return;
    if (__builtin_expect(dir == DIR_RX && s->resp_capture_complete, 0)) return;

    if (__builtin_expect(!s->active, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p HTTP detect len=%zu\n",
                  dir, (void*)s, n);
        int http_check = is_likely_http(buf, n);
        if (__builtin_expect(http_check == 0, 0)) {
            // NOT HTTP - mark as skip for zero overhead on future calls!

            if (s->is_ssl && s->ssl_ptr) {
                mark_skip(idx_ptr(s->ssl_ptr));
            } else if (s->fd >= 0) {
                mark_skip(idx_fd(s->fd));
            }
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p non-http, mark skip\n",
                      dir, (void*)s);
            return;
        }
        if (__builtin_expect(http_check == -1, 0)) {
            // CRITICAL FIX: Buffer the tiny prefix so next call can complete the line
            // Without this, we drop the first bytes (e.g., "GE") and corrupt the request line!
            (void)hdr_append(s, buf, n);
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p buffered partial len=%zu\n",
                      dir, (void*)s, n);
            return;
        }
        // Confirmed HTTP! Mark active and capture start time
        s->active = 1;
        DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p confirmed HTTP\n",
                  dir, (void*)s);
        if (dir == DIR_TX && !s->t_req_start_ns) {
            s->t_req_start_ns = now_ns();  // ONLY call timing AFTER HTTP confirmed!
        }
        // Fall through to header accumulation which will also append this chunk
    }

    // 1) accumulate headers until CRLFCRLF
    if (__builtin_expect((dir==DIR_TX && !s->have_req_hdrs) || (dir==DIR_RX && !s->have_resp_hdrs), 1) ){
        size_t old_len = s->hdr_len;
        if (__builtin_expect(!hdr_append(s, buf, n), 0)) return;

        // SAFETY: Hard cap at 32KB - if headers exceed this without CRLFCRLF, mark as skip
        // This prevents unbounded accumulation for non-HTTP/malformed traffic
        if (__builtin_expect(s->hdr_len > (32 * 1024), 0)) {
            // Mark this connection as skip for all future packets (zero overhead)
            if (s->is_ssl && s->ssl_ptr) {
                mark_skip(idx_ptr(s->ssl_ptr));
            } else if (s->fd >= 0) {
                mark_skip(idx_fd(s->fd));
            }
            s->hdr_len = 0;  // Clear buffer
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p header overflow -> skip\n",
                      dir, (void*)s);
            return;
        }

        // ULTRA-FAST incremental search: Only search NEW data (plus 3 bytes overlap for boundary cases)
        // Use custom state machine instead of memmem (~3x faster for 4-byte needle!)
        size_t search_start = old_len > 3 ? old_len - 3 : 0;
        char *search_ptr = s->hdr_buf + search_start;
        size_t search_len = s->hdr_len - search_start;

        char *at = find_crlfcrlf(search_ptr, search_len);
        if (__builtin_expect(!at, 1)) {
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p awaiting CRLFCRLF hdr_len=%zu\n",
                      dir, (void*)s, s->hdr_len);
            return;  // Most calls won't see end of headers yet
        }

        size_t hdr_total = (size_t)((at + 4) - s->hdr_buf);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p headers complete len=%zu\n",
                  dir, (void*)s, hdr_total);

        // FIX(1): temp-terminate for parsing, then restore before copying body
        char saved = s->hdr_buf[hdr_total];
        s->hdr_buf[hdr_total] = '\0';
        seal_headers(dir, s, hdr_total);  // Pass hdr_total to prevent body bleed
        s->hdr_buf[hdr_total] = saved;

        // CRITICAL FIX: Handle HTTP keep-alive pipelining (multiple transactions in one buffer)
        // Check if Content-Length is known - if so, we can detect where this transaction ends
        size_t content_length = (dir == DIR_TX ? s->req_content_length : s->resp_content_length);
        size_t body_left = s->hdr_len - hdr_total;

        // Calculate how much body data belongs to THIS transaction
        size_t body_for_this_txn = body_left;  // Default: consume all remaining bytes
        size_t leftover = 0;  // Bytes that belong to NEXT transaction (if any)

        if (content_length != SIZE_MAX) {
            // Content-Length is known! We can determine exact transaction boundary
            if (body_left > content_length) {
                // Buffer contains MORE than this transaction's body!
                // This is pipelined HTTP - split the buffer
                body_for_this_txn = content_length;
                leftover = body_left - content_length;
            } else {
                // Buffer contains this transaction's body (or less)
                body_for_this_txn = body_left;
            }
        }

        // Process body for THIS transaction only
        if (body_for_this_txn > 0){
            const char *b = s->hdr_buf + hdr_total;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p capturing body bytes=%zu cap=%zu\n",
                      dir, (void*)s, body_for_this_txn,
                      (size_t)(dir==DIR_TX ? SF_MAX_REQ_BODY : SF_MAX_RESP_BODY));
            size_t cap = (dir==DIR_TX ? SF_MAX_REQ_BODY : SF_MAX_RESP_BODY);
            char **sample = (dir==DIR_TX ? &s->req_body_sample : &s->resp_body_sample);
            size_t *blen   = (dir==DIR_TX ? &s->req_body_len : &s->resp_body_len);

            // ULTRA-FAST: Use inline buffer first (avoids malloc for 99% of requests!)
            if (__builtin_expect(!*sample && cap > 0, 0)) {
                if (__builtin_expect(cap <= 8192, 1)) {
                    // Fast path: Use inline buffer (no malloc!)
                    *sample = (dir == DIR_TX ? s->req_body_inline : s->resp_body_inline);
                } else {
                    // Slow path: Need more than 8KB, must malloc
                    *sample = (char*)malloc(cap);
                }
            }

            size_t space = (*sample && cap>*blen) ? (cap - *blen) : 0;
            size_t take = minz(space, body_for_this_txn);
            if (take){ memcpy(*sample + *blen, b, take); *blen += take; }

            // Mark capture complete if we've consumed all body bytes for this transaction
            if (content_length != SIZE_MAX && *blen >= content_length) {
                if (dir == DIR_TX) s->req_capture_complete = 1;
                else s->resp_capture_complete = 1;
            } else if (*blen >= cap) {
                // Also mark complete if we hit sampling limit
                if (dir == DIR_TX) s->req_capture_complete = 1;
                else s->resp_capture_complete = 1;
            }
        } else {
            // No body data - mark capture complete immediately after headers
            if (dir == DIR_TX) s->req_capture_complete = 1;
            else s->resp_capture_complete = 1;
        }

        // clear hdr buf for next cycle
        s->hdr_len = 0;

        // CRITICAL: If we have leftover bytes (pipelined HTTP), trigger emission NOW
        // then continue processing the remainder as a new transaction!
        if (leftover > 0) {
            // Save leftover data (next transaction's data)
            char leftover_buf[8192];  // Stack buffer for next transaction
            const char *leftover_ptr = s->hdr_buf + hdr_total + body_for_this_txn;
            size_t leftover_to_save = minz(leftover, sizeof(leftover_buf));
            memcpy(leftover_buf, leftover_ptr, leftover_to_save);
            DEBUG_LOG("[SF_DEBUG _sfteepreload] feed_stream: dir=%d state=%p leftover bytes=%zu\n",
                      dir, (void*)s, leftover_to_save);

            // Emit THIS transaction (only for RX - responses)
            if (dir == DIR_RX) {
                // Check if we should emit (both headers present)
                if (s->have_req_hdrs && s->have_resp_hdrs && !(s->req_done_once && s->resp_done_once)) {
                    maybe_emit(s);  // This will reset state for next transaction
                }
            }

            // Continue processing leftover bytes as next transaction
            // State has been reset by maybe_emit, so this is a fresh transaction
            feed_stream(dir, s, leftover_buf, leftover_to_save);
        }

        return;
    }

    // 2) already in body: take up to cap
    if ( (dir==DIR_TX && s->have_req_hdrs) || (dir==DIR_RX && s->have_resp_hdrs) ){
        size_t cap = (dir==DIR_TX ? SF_MAX_REQ_BODY : SF_MAX_RESP_BODY);
        char **sample = (dir==DIR_TX ? &s->req_body_sample : &s->resp_body_sample);
        size_t *blen   = (dir==DIR_TX ? &s->req_body_len : &s->resp_body_len);
        if (cap == 0) {
            // No body capture configured - mark complete immediately
            if (dir == DIR_TX) s->req_capture_complete = 1;
            else s->resp_capture_complete = 1;
            return;
        }

        // ULTRA-FAST: Use inline buffer first (avoids malloc for 99% of requests!)
        if (__builtin_expect(!*sample, 0)) {
            if (__builtin_expect(cap <= 8192, 1)) {
                // Fast path: Use inline buffer (no malloc!)
                *sample = (dir == DIR_TX ? s->req_body_inline : s->resp_body_inline);
            } else {
                // Slow path: Need more than 8KB, must malloc
                *sample = (char*)malloc(cap);
            }
        }

        size_t space = (cap > *blen) ? (cap - *blen) : 0;
        size_t take = minz(space, n);
        if (take){ memcpy(*sample + *blen, buf, take); *blen += take; }

        // ULTRA-FAST: Mark capture complete when body sampling reaches limit
        // This enables instant early return on all future packets (5ns vs 1-2µs)!
        if (*blen >= cap) {
            if (dir == DIR_TX) s->req_capture_complete = 1;
            else s->resp_capture_complete = 1;
        }
        return;
    }
}

// Load Python symbols dynamically at runtime
// Returns 1 on success, 0 on failure (library continues without Python support)
static int load_python_symbols(void) {
    // Try common Python library names (version-specific first, then generic)
    const char *lib_names[] = {
        "libpython3.11.so",
        "libpython3.11.dylib",
        "libpython3.10.so",
        "libpython3.10.dylib",
        "libpython3.12.so",
        "libpython3.12.dylib",
        "libpython3.so",
        "libpython3.dylib",
        NULL
    };

    for (int i = 0; lib_names[i]; i++) {
        g_python_handle = dlopen(lib_names[i], RTLD_LAZY | RTLD_GLOBAL);
        if (g_python_handle) {
            break;
        }
    }

    if (!g_python_handle) {
        return 0;
    }

    // Load all required symbols
    #define LOAD_SYM(name, sym) \
        py_##name = dlsym(g_python_handle, sym); \
        if (!py_##name) { \
            dlclose(g_python_handle); g_python_handle = NULL; return 0; \
        }

    LOAD_SYM(IsInitialized, "Py_IsInitialized")
    LOAD_SYM(GILState_Ensure, "PyGILState_Ensure")
    LOAD_SYM(GILState_Release, "PyGILState_Release")
    LOAD_SYM(ContextVar_Get, "PyContextVar_Get")
    LOAD_SYM(Import_ImportModule, "PyImport_ImportModule")
    LOAD_SYM(Object_GetAttrString, "PyObject_GetAttrString")
    LOAD_SYM(Object_CallObject, "PyObject_CallObject")
    LOAD_SYM(Decref, "Py_DecRef")
    // Note: PyUnicode_Check is a macro, not a function - don't load it!
    LOAD_SYM(Unicode_AsUTF8, "PyUnicode_AsUTF8")
    LOAD_SYM(Err_Occurred, "PyErr_Occurred")
    LOAD_SYM(Err_Clear, "PyErr_Clear")
    LOAD_SYM(Object_IsTrue, "PyObject_IsTrue")
    LOAD_SYM(Tuple_GetItem, "PyTuple_GetItem")

    #undef LOAD_SYM

    return 1;
}

// Try to initialize the ContextVars (lazy initialization)
// Can be called multiple times safely - only attempts once
static void try_init_trace_id_contextvar(void) {
    // Only try once
    if (g_contextvar_init_attempted) return;
    g_contextvar_init_attempted = 1;

    // Must have Python symbols loaded
    if (!py_IsInitialized || !py_Import_ImportModule || !py_Object_GetAttrString) {
        return;
    }

    // Python must be initialized
    if (!py_IsInitialized()) {
        return;
    }


    PyGILState_STATE gstate = py_GILState_Ensure();

    PyObject *module = py_Import_ImportModule("sf_veritas.thread_local");
    if (module) {
        PyObject *ctx = py_Object_GetAttrString(module, "trace_id_ctx");
        if (ctx) {
            g_trace_id_contextvar = ctx;
            // Don't DECREF - we keep this reference for the lifetime of the library
        } else {
            if (py_Err_Clear) py_Err_Clear();
        }

        // Also get the suppress_network_recording_ctx ContextVar
        PyObject *suppress_ctx = py_Object_GetAttrString(module, "suppress_network_recording_ctx");
        if (suppress_ctx) {
            g_suppress_network_recording_contextvar = suppress_ctx;
            // Don't DECREF - we keep this reference for the lifetime of the library
        } else {
            if (py_Err_Clear) py_Err_Clear();
        }

        // [ADD] Also get the funcspan_override_ctx ContextVar
        PyObject *funcspan_ctx = py_Object_GetAttrString(module, "funcspan_override_ctx");
        if (funcspan_ctx) {
            g_funcspan_override_contextvar = funcspan_ctx;
            // Don't DECREF - we keep this reference for the lifetime of the library
        } else {
            if (py_Err_Clear) py_Err_Clear();
        }

        // Cache the get_or_set_sf_trace_id function for later use
        PyObject *func = py_Object_GetAttrString(module, "get_or_set_sf_trace_id");
        if (func) {
            g_get_or_set_sf_trace_id_func = func;
            // Don't DECREF - we keep this reference for the lifetime of the library
        } else {
            if (py_Err_Clear) py_Err_Clear();
        }

        py_Decref(module);
    } else {
        if (py_Err_Clear) py_Err_Clear();
    }

    py_GILState_Release(gstate);
}

// Check if network recording should be suppressed (from Python ContextVar)
// Returns 1 if suppressed, 0 if not suppressed or on any error
static int should_suppress_network_recording(void) {
    // Lazy initialization: try to load ContextVars on first use
    if (!g_suppress_network_recording_contextvar && !g_contextvar_init_attempted) {
        try_init_trace_id_contextvar();
    }

    // Fast path: if Python not loaded or ContextVar not initialized, return 0 (don't suppress)
    if (!py_IsInitialized || !g_suppress_network_recording_contextvar || !py_Object_IsTrue || !py_IsInitialized()) {
        return 0;
    }

    PyGILState_STATE gstate = py_GILState_Ensure();
    int result = 0;  // Default: don't suppress

    PyObject *value = NULL;
    int status = py_ContextVar_Get(g_suppress_network_recording_contextvar, NULL, &value);


    if (status == 0 && value) {
        // Got a value - use PyObject_IsTrue to check if it's truthy
        // Returns 1 if true, 0 if false, -1 on error
        int is_true = py_Object_IsTrue(value);
        if (is_true == 1) {
            result = 1;  // Suppress network recording
        }
        // If is_true is 0 or -1 (error), result stays 0 (don't suppress)

        py_Decref(value);
    }
    // If status != 0 (ContextVar not set), result stays 0 (don't suppress)

    py_GILState_Release(gstate);
    return result;
}

// Call Python's get_or_set_sf_trace_id() to generate/retrieve a trace_id
// Returns malloc'd string or NULL on error
// This is called when the ContextVar is None (backend-only processes)
static char* call_get_or_set_sf_trace_id(void) {

    // Lazy initialization: try to load function on first use
    if (!g_get_or_set_sf_trace_id_func && !g_contextvar_init_attempted) {
        try_init_trace_id_contextvar();
    }

    if (!py_IsInitialized || !py_Object_CallObject || !py_Tuple_GetItem) {
        return NULL;
    }

    if (!py_IsInitialized()) {
        return NULL;
    }

    if (!g_get_or_set_sf_trace_id_func) {
        return NULL;
    }

    PyGILState_STATE gstate = py_GILState_Ensure();
    char *result = NULL;

    // Call the cached function with no arguments (NULL)
    PyObject *ret = py_Object_CallObject(g_get_or_set_sf_trace_id_func, NULL);
    if (!ret) {
        if (py_Err_Clear) py_Err_Clear();
        goto cleanup;
    }

    // get_or_set_sf_trace_id returns a tuple: (was_set: bool, trace_id: str)
    // We need the second element (index 1)
    PyObject *trace_id_obj = py_Tuple_GetItem(ret, 1);  // Borrowed reference
    if (trace_id_obj && py_Unicode_AsUTF8) {
        const char *trace_id_str = py_Unicode_AsUTF8(trace_id_obj);
        if (trace_id_str) {
            result = str_dup(trace_id_str);
        } else {
            // CRITICAL: Clear error if UTF-8 conversion failed
            if (py_Err_Clear) py_Err_Clear();
        }
    }

    py_Decref(ret);

cleanup:
    // CRITICAL: Clear any remaining errors before releasing GIL
    if (py_Err_Occurred && py_Err_Occurred() && py_Err_Clear) {
        py_Err_Clear();
    }
    py_GILState_Release(gstate);
    return result;
}

// Get trace_id from Python ContextVar (returns malloc'd string or NULL)
// If ContextVar is None, calls get_or_set_sf_trace_id() to generate one
// CRITICAL: This function must NEVER crash or hang - if anything fails, return NULL
static char* get_trace_id(void) {
    uint64_t t_start = 0, t_after_lazy_check = 0, t_after_ptr_checks = 0, t_after_py_init_call = 0, t_after_checks = 0, t_gil_start = 0, t_gil_acquired = 0, t_contextvar_get = 0, t_utf8_convert = 0, t_str_dup = 0, t_gil_release = 0, t_end = 0;

    // Lazy initialization: try to load ContextVar on first use
    if (!g_trace_id_contextvar && !g_contextvar_init_attempted) {
        try_init_trace_id_contextvar();
    }

    // Fast path: if Python not loaded or ContextVar not initialized, return NULL
    if (!py_IsInitialized) {
        return NULL;
    }
    if (!g_trace_id_contextvar) {
        return NULL;
    }

    if (!py_IsInitialized()) {
        return NULL;
    }


    char *result = NULL;
    PyGILState_STATE gstate;
    int gil_acquired = 0;

    // Wrap everything in error handling - MUST NOT break emission if this fails!

    // CRITICAL: Acquire GIL before calling any Python C API functions
    gstate = py_GILState_Ensure();
    gil_acquired = 1;

    // Call PyContextVar_Get - signature: PyContextVar_Get(var, default_value, &value)
    // Returns 0 on success with value set, -1 on error, 1 if not found
    PyObject *value = NULL;
    int status = py_ContextVar_Get(g_trace_id_contextvar, NULL, &value);

    if (status == 0 && value) {
        // ULTRA-FAST: Always convert to UTF-8 first (Python caches this internally - cheap!)
        const char *trace_id_str = NULL;

        if (py_Unicode_AsUTF8) {
            trace_id_str = py_Unicode_AsUTF8(value);

            if (trace_id_str) {
                // SAFE: Compare string CONTENT, not PyObject pointers!
                // strcmp is ~200ns for typical trace_id vs str_dup malloc = ~3µs
                if (g_cached_trace_id_utf8 != NULL && strcmp(trace_id_str, g_cached_trace_id_utf8) == 0) {
                    // CACHE HIT: Same string value! Return cached pointer directly
                    result = g_cached_trace_id_utf8;  // Direct pointer return - NO str_dup!

                    // Early cleanup and GIL release for cache hit fast path
                    py_Decref(value);
                    py_GILState_Release(gstate);
                    gil_acquired = 0;  // Mark as released

                    // CRITICAL: Early return on cache hit!
                    return result;
                }

                // CACHE MISS: Different string value - update cache

                // Free old cache and allocate new
                register_tls_cleanup();  // Ensure cleanup registered before allocating
                if (g_cached_trace_id_utf8) {
                    free(g_cached_trace_id_utf8);
                }
                g_cached_trace_id_utf8 = str_dup(trace_id_str);
                result = g_cached_trace_id_utf8;  // Return newly cached pointer
            } else {
                // Value is not a string (probably None)
                if (py_Err_Occurred && py_Err_Occurred()) {
                    if (py_Err_Clear) py_Err_Clear();
                }
            }
        }

        py_Decref(value);
    } else {
        // No value set or error occurred, clear any error and continue
        if (py_Err_Occurred && py_Err_Occurred()) {
            if (py_Err_Clear) py_Err_Clear();
        }
    }

    // CRITICAL: Clear any remaining errors before releasing GIL
    if (py_Err_Occurred && py_Err_Occurred() && py_Err_Clear) {
        py_Err_Clear();
    }

    // CRITICAL: Always release GIL before returning (skip if already released in cache hit path)
    if (gil_acquired) {
        py_GILState_Release(gstate);
    }

    // If we didn't get a trace_id from the ContextVar, call get_or_set_sf_trace_id()
    if (!result) {
        result = call_get_or_set_sf_trace_id();
    }

    return result;
}

// [ADD] Get funcspan_override from Python ContextVar (returns malloc'd string or NULL)
// Similar to get_trace_id() but simpler - doesn't call a generator function
static char* get_funcspan_override(void) {
    uint64_t t_start = 0, t_after_lazy_check = 0, t_after_ptr_checks = 0, t_after_py_init_call = 0, t_after_checks = 0, t_gil_start = 0, t_gil_acquired = 0, t_contextvar_get = 0, t_utf8_convert = 0, t_str_dup = 0, t_gil_release = 0, t_end = 0;

    // Lazy initialization: try to load ContextVar on first use
    if (!g_funcspan_override_contextvar && !g_contextvar_init_attempted) {
        try_init_trace_id_contextvar();
    }

    // Fast path: if Python not loaded or ContextVar not initialized, return NULL
    if (!py_IsInitialized || !g_funcspan_override_contextvar) {
        return NULL;
    }

    if (!py_IsInitialized()) {
        return NULL;
    }


    char *result = NULL;
    PyGILState_STATE gstate;
    int gil_acquired = 0;

    // CRITICAL: Acquire GIL before calling any Python C API functions
    gstate = py_GILState_Ensure();
    gil_acquired = 1;

    PyObject *value = NULL;
    int status = py_ContextVar_Get(g_funcspan_override_contextvar, NULL, &value);

    if (status == 0 && value) {
        // ULTRA-FAST: Always convert to UTF-8 first (Python caches this internally - cheap!)
        const char *override_str = NULL;

        if (py_Unicode_AsUTF8) {
            override_str = py_Unicode_AsUTF8(value);

            if (override_str) {
                // SAFE: Compare string CONTENT, not PyObject pointers!
                if (g_cached_funcspan_utf8 != NULL && strcmp(override_str, g_cached_funcspan_utf8) == 0) {
                    // CACHE HIT: Same string value! Return cached pointer directly
                    result = g_cached_funcspan_utf8;  // Direct pointer return - NO str_dup!

                    // Early cleanup and GIL release for cache hit fast path
                    py_Decref(value);
                    py_GILState_Release(gstate);
                    gil_acquired = 0;  // Mark as released

                    // CRITICAL: Early return on cache hit!
                    return result;
                }

                // CACHE MISS: Different string value - update cache

                // Free old cache and allocate new
                register_tls_cleanup();  // Ensure cleanup registered before allocating
                if (g_cached_funcspan_utf8) {
                    free(g_cached_funcspan_utf8);
                }
                g_cached_funcspan_utf8 = str_dup(override_str);
                result = g_cached_funcspan_utf8;  // Return newly cached pointer
            } else {
                // Value is not a string (probably None)
                if (py_Err_Occurred && py_Err_Occurred()) {
                    if (py_Err_Clear) py_Err_Clear();
                }
            }
        }

        py_Decref(value);
    } else {
        // Clear any error
        if (py_Err_Occurred && py_Err_Occurred()) {
            if (py_Err_Clear) py_Err_Clear();
        }
    }

    // CRITICAL: Clear any remaining errors before releasing GIL
    if (py_Err_Occurred && py_Err_Occurred() && py_Err_Clear) {
        py_Err_Clear();
    }

    // CRITICAL: Always release GIL before returning (skip if already released in cache hit path)
    if (gil_acquired) {
        py_GILState_Release(gstate);
    }

    return result;
}

// ULTRA-FAST HOT PATH: Just capture raw data, NO expensive processing!
// All expensive work (URL building, Python calls, trace IDs, JSON) moved to background thread
// This is THE KEY to achieving ZERO overhead!
// ULTRA-FAST: Always inline to avoid call/ret overhead and allow compiler to hoist field reads
__attribute__((hot))
static inline __attribute__((always_inline)) void maybe_emit(conn_state_t *s){

    // FAST PATH: Most calls won't have both headers yet
    if (__builtin_expect(!s->have_req_hdrs || !s->have_resp_hdrs, 1)) {
        return;
    }
    if (__builtin_expect(s->req_done_once && s->resp_done_once, 0)) {
        return;
    }

    // No need for telemetry check here - thread-local g_in_telemetry_send flag
    // already provides complete protection in sender threads!

    // ULTRA-FAST: Build raw message (copying metadata + small inline strings, NO malloc!)
    // This is 100-1000x faster than the old approach!
    tee_msg_t msg = {0};
    msg.is_ssl = s->is_ssl;
    msg.resp_status = s->resp_status;
    msg.t_req_start_ns = s->t_req_start_ns;
    msg.t_resp_last_hdr_ns = s->t_resp_last_hdr_ns;

    // ULTRA-FAST: Copy method/target from state inline buffers (already parsed, just memcpy!)
    // Method is typically 3-7 bytes (GET, POST, PUT, DELETE), target is typically < 256 bytes
    if (s->have_req_line) {
        memcpy(msg.req_method, s->req_method, sizeof(msg.req_method));
        memcpy(msg.req_target, s->req_target, sizeof(msg.req_target));
    }

    // Transfer ownership of malloc'd strings from state to message (zero-copy!)
    // The background thread will free these after building JSON
    msg.req_host = s->req_host;           s->req_host = NULL;
    msg.req_hdr_raw = s->req_hdr_raw;     s->req_hdr_raw = NULL;
    msg.req_hdr_raw_len = s->req_hdr_raw_len;
    msg.req_hdr_json = s->req_hdr_json;   s->req_hdr_json = NULL;
    msg.resp_hdr_json = s->resp_hdr_json; s->resp_hdr_json = NULL;
    msg.req_body_len = s->req_body_len;
    msg.req_body_sample = NULL;
    if (msg.req_body_len > 0 && s->req_body_sample) {
        int req_inline = (s->req_body_sample == s->req_body_inline);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: duplicating req body len=%zu sample=%p inline=%d\n",
                  msg.req_body_len, (void*)s->req_body_sample, req_inline);
        char *dup = (char*)malloc(msg.req_body_len);
        if (dup) {
            memcpy(dup, s->req_body_sample, msg.req_body_len);
            msg.req_body_sample = dup;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: req body duplicated -> %p\n", (void*)dup);
            if (!req_inline) {
                free(s->req_body_sample);
            }
        } else if (!req_inline) {
            // Can't duplicate but original was heap - hand ownership to message as-is
            msg.req_body_sample = s->req_body_sample;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: req body malloc failed, reusing heap sample %p\n",
                      (void*)msg.req_body_sample);
        } else {
            // Inline + OOM → drop capture to avoid freeing inline storage
            msg.req_body_len = 0;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: req body malloc failed for inline buffer, dropping sample\n");
        }
    }
    s->req_body_sample = NULL;

    msg.resp_body_len = s->resp_body_len;
    msg.resp_body_sample = NULL;
    if (msg.resp_body_len > 0 && s->resp_body_sample) {
        int resp_inline = (s->resp_body_sample == s->resp_body_inline);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: duplicating resp body len=%zu sample=%p inline=%d\n",
                  msg.resp_body_len, (void*)s->resp_body_sample, resp_inline);
        char *dup = (char*)malloc(msg.resp_body_len);
        if (dup) {
            memcpy(dup, s->resp_body_sample, msg.resp_body_len);
            msg.resp_body_sample = dup;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: resp body duplicated -> %p\n", (void*)dup);
            if (!resp_inline) {
                free(s->resp_body_sample);
            }
        } else if (!resp_inline) {
            msg.resp_body_sample = s->resp_body_sample;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: resp body malloc failed, reusing heap sample %p\n",
                      (void*)msg.resp_body_sample);
        } else {
            msg.resp_body_len = 0;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: resp body malloc failed for inline buffer, dropping sample\n");
        }
    }
    s->resp_body_sample = NULL;

    // Trace ID: Prioritize extracted value from connection state (X-Sf4-Prid), then TLS
    // CRITICAL FIX: Use extracted parent_trace_id from header (saved BEFORE stripping)
    // This fixes the bug where parent_trace_id was empty because we tried to extract AFTER stripping
    if (s->parent_trace_id) {
        msg.parent_trace_id = s->parent_trace_id;  // Transfer ownership (no copy!)
        s->parent_trace_id = NULL;  // Clear state (ownership transferred)
    } else if (sf_tls_parent_trace_id && *sf_tls_parent_trace_id) {
        msg.parent_trace_id = str_dup(sf_tls_parent_trace_id);
    } else {
        msg.parent_trace_id = NULL;  // Sender will extract from X-Sf3-Rid header (fallback)
    }

    // Python suppression check (only if enabled)
    if (__builtin_expect(SF_ENABLE_PYTHON_FILTERS, 0)) {
        // Get suppression flag (cached in state)
        if (!s->python_suppression_checked) {
            s->is_suppressed_by_python = should_suppress_network_recording();
            s->python_suppression_checked = 1;
        }
        msg.is_suppressed_by_python = s->is_suppressed_by_python;
    } else {
        msg.is_suppressed_by_python = 0;
    }

    // ULTRA-FAST: Push raw data to ring (just struct copy, ~10-50ns!)
    // Background thread will do ALL expensive processing: URL building, suppression checks, trace IDs, JSON
    DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: pushing msg seq placeholder req_len=%zu resp_len=%zu parent=%p\n",
              msg.req_body_len, msg.resp_body_len, (void*)msg.parent_trace_id);
    int push_ok = ring_push_raw(&msg);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: ring_push_raw returned %d (req_sample=%p resp_sample=%p)\n",
              push_ok, (void*)msg.req_body_sample, (void*)msg.resp_body_sample);

    if (!push_ok) {
        // Ring full - free the allocated strings to avoid leak
        // NOTE: req_method/req_target are inline, no free needed
        DEBUG_LOG("[SF_DEBUG _sfteepreload] maybe_emit: ring push failed, freeing local copies\n");
        free(msg.req_host);
        free(msg.req_hdr_raw);
        free(msg.req_hdr_json);
        free(msg.resp_hdr_json);
        free(msg.req_body_sample);
        free(msg.resp_body_sample);
        free(msg.parent_trace_id);
    }

    // CRITICAL: Mark as done to prevent double-emission (in case of multiple recv calls)
    // These will be cleared by reset_state_for_next_request for keep-alive connections
    s->req_done_once = 1;
    s->resp_done_once = 1;

    // CRITICAL: Reset state for next request (HTTP/1.1 keep-alive reuses sockets)
    reset_state_for_next_request(s);
}

// ============================= Hooks =============================

// Internal wrappers (no skip check - caller already checked)
static inline __attribute__((always_inline)) void on_tx_fd_internal(int fd, const void *buf, size_t n){
    // [STATS-ONLY] Count non-telemetry outbound connections
    // uint64_t conn_id = atomic_fetch_add_explicit(&g_stat_connections_seen, 1, memory_order_relaxed) + 1;

    conn_state_t *s = get_state_fd(fd, 1);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_fd_internal: fd=%d len=%zu state=%p\n", fd, n, (void*)s);
    if (__builtin_expect(!s, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_fd_internal: NULL state for fd=%d\n", fd);
        return;
    }
    s->is_ssl = 0; s->fd = fd;

    // CRITICAL: Transfer extracted parent_trace_id from thread-local to connection state
    // This must happen BEFORE feed_stream to ensure it's available when emitting the message
    if (!s->parent_trace_id) {
        s->parent_trace_id = take_extracted_parent_trace_id();  // Atomic ownership transfer (move semantics)
        DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_fd_internal: parent_trace_id=%p\n", (void*)s->parent_trace_id);
    }

    // NOTE: Timing now called in feed_stream AFTER HTTP confirmation!
    feed_stream(DIR_TX, s, (const char*)buf, n);
}
static inline __attribute__((always_inline)) void on_rx_fd_internal(int fd, const void *buf, size_t n){
    conn_state_t *s = get_state_fd(fd, 1);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] on_rx_fd_internal: fd=%d len=%zu state=%p\n", fd, n, (void*)s);
    if (__builtin_expect(!s, 0)) return;
    s->is_ssl = 0; s->fd = fd;
    feed_stream(DIR_RX, s, (const char*)buf, n);

    // ULTRA-FAST inline check: Only call maybe_emit when both headers are ready
    // This saves 100ns per packet by avoiding function call when not needed
    // IMPORTANT: Match the check inside maybe_emit - don't call if BOTH are done
    if (__builtin_expect(s->have_req_hdrs && s->have_resp_hdrs && !(s->req_done_once && s->resp_done_once), 0)) {
        maybe_emit(s);
    }
}

// External wrappers with ULTRA-FAST skip check
__attribute__((hot))
static inline __attribute__((always_inline)) void on_tx_fd(int fd, const void *buf, size_t n){
    // ULTRA-FAST: Non-atomic check (plain load, set once at init) - compile-time cheap!
    if (__builtin_expect(!g_enabled_cached, 0)) {
        return;
    }
    // CRITICAL FAST PATH: Check skip bitmap (lock-free, single atomic load)
    if (__builtin_expect(should_skip(idx_fd(fd)), 0)) {
        return;
    }
    on_tx_fd_internal(fd, buf, n);
}
__attribute__((hot))
static inline __attribute__((always_inline)) void on_rx_fd(int fd, const void *buf, size_t n){
    // ULTRA-FAST: Non-atomic check (plain load, set once at init) - compile-time cheap!
    if (__builtin_expect(!g_enabled_cached, 0)) {
        return;
    }
    // CRITICAL FAST PATH: Check skip bitmap (lock-free, single atomic load)
    if (__builtin_expect(should_skip(idx_fd(fd)), 0)) {
        return;
    }
    on_rx_fd_internal(fd, buf, n);
}
/* REMOVED: SSL capture disabled - Python handles HTTPS, C handles plain HTTP
static void on_tx_ssl(SSL *ssl, const void *buf, size_t n){
    if (__builtin_expect(!g_enabled_cached, 0)) {
        return;
    }
    size_t idx = idx_ptr((void*)ssl);
    if (__builtin_expect(should_skip(idx), 0)) {
        return;
    }

    ensure_ssl_bound_and_direction(ssl);
    ssl_aux_t *aux = ssl_get_aux(ssl, 0);
    conn_state_t *s = aux ? aux->state : NULL;
    if (!s) {
        s = get_state_ssl((void*)ssl, 1);
        if (aux) aux->state = s;
    }
    if (__builtin_expect(!s, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_ssl: ssl=%p missing state\n", (void*)ssl);
        return;
    }
    s->is_ssl = 1;
    if (__builtin_expect(!s->is_outbound, 0)) {
        if (s->fd >= 0) {
            conn_state_t *fs = get_state_fd(s->fd, 0);
            if (fs && fs->is_outbound) {
                s->is_outbound = 1;
            }
        }
    }
    DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_ssl: ssl=%p state=%p fd=%d outbound=%d len=%zu\n",
              (void*)ssl, (void*)s, s->fd, s->is_outbound, n);

    if (!s->parent_trace_id) {
        s->parent_trace_id = take_extracted_parent_trace_id();
    }

    feed_stream(DIR_TX, s, (const char*)buf, n);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] on_tx_ssl: feed_stream done ssl=%p state=%p\n",
              (void*)ssl, (void*)s);
}
static void on_rx_ssl(SSL *ssl, const void *buf, size_t n){
    if (__builtin_expect(!g_enabled_cached, 0)) {
        return;
    }
    size_t idx = idx_ptr((void*)ssl);
    if (__builtin_expect(should_skip(idx), 0)) {
        return;
    }

    ensure_ssl_bound_and_direction(ssl);
    ssl_aux_t *aux = ssl_get_aux(ssl, 0);
    conn_state_t *s = aux ? aux->state : NULL;
    if (!s) {
        s = get_state_ssl((void*)ssl, 1);
        if (aux) aux->state = s;
    }
    if (__builtin_expect(!s, 0)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] on_rx_ssl: ssl=%p missing state\n", (void*)ssl);
        return;
    }
    s->is_ssl = 1;
    if (__builtin_expect(!s->is_outbound, 0)) {
        if (s->fd >= 0) {
            conn_state_t *fs = get_state_fd(s->fd, 0);
            if (fs && fs->is_outbound) {
                s->is_outbound = 1;
            }
        }
    }
    DEBUG_LOG("[SF_DEBUG _sfteepreload] on_rx_ssl: ssl=%p state=%p fd=%d outbound=%d len=%zu\n",
              (void*)ssl, (void*)s, s->fd, s->is_outbound, n);
    feed_stream(DIR_RX, s, (const char*)buf, n);

    if (__builtin_expect(s->have_req_hdrs && s->have_resp_hdrs && !(s->req_done_once && s->resp_done_once), 0)) {
        maybe_emit(s);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] on_rx_ssl: maybe_emit triggered ssl=%p state=%p\n",
                  (void*)ssl, (void*)s);
    }
}
*/ // END REMOVED SSL capture functions

// --- TX heuristic helper (DISABLED - getpeername succeeds on BOTH client and server sockets!) ---
// CRITICAL BUG: getpeername() returns success for accept()ed server sockets too!
// This was causing server-side response data to be marked as outbound and rejected.
// We MUST rely only on connect()/accept() hooks for direction tagging.
static inline void maybe_mark_outbound_on_first_tx(int fd) {
    // DISABLED: This heuristic is fundamentally broken
    // getpeername() succeeds on server sockets (from accept()), so it incorrectly marks them as outbound
    // Example bug: Server sends "HTTP/1.1 200 OK" → marked outbound → rejected as "not HTTP request"
    //
    // The ONLY reliable way to distinguish client vs server is at socket creation:
    // - Client: connect() succeeds → mark is_outbound=1
    // - Server: accept() returns → mark is_outbound=0
    (void)fd;  // Suppress unused parameter warning
}

// --- send/recv family ---
__attribute__((visibility("default")))
ssize_t send(int fd, const void *buf, size_t len, int flags){
    fprintf(stderr, "[DEBUG _sfteepreload.c] send() ENTRY: fd=%d, len=%zu\n", fd, len);
    fflush(stderr);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) {
        return real_send(fd, buf, len, flags);
    }

    // ULTRA-FAST: 3-branch fast path (all predictable, ~10-15ns total)
    // 1. Check telemetry guard (thread-local, no atomic) - instant skip for telemetry sends
    if (__builtin_expect(sf_guard_active(), 0)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] send() in_telemetry_send, calling real_send\n");
        fflush(stderr);
        return real_send(fd, buf, len, flags);
    }

    // CRITICAL: In Python SSL mode, pass through SSL sockets (Python captures them)
    // Only capture plain HTTP sockets in C
    if (SF_PYTHON_SSL_MODE && is_ssl_socket(fd)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] send: fd=%d is SSL socket, passing through (Python SSL mode)\n", fd);
        return real_send(fd, buf, len, flags);
    }

    // HARDENING: Bail fast unless clearly HTTP/1.x with complete headers (CRLFCRLF)
    // This prevents processing of:
    // - Encrypted TLS records (random bytes that happen to look like HTTP)
    // - Partial HTTP writes (split across multiple send calls)
    // - Non-HTTP protocols
    const void *send_buf = buf;
    size_t send_len = len;

    if (__builtin_expect(buf && buffer_looks_like_full_http_headers((const char*)buf, len), 0)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] send() detected PLAINTEXT HTTP request, processing headers\n");
        fflush(stderr);

        // Use thread-local shadow buffer (avoids malloc on every call)
        size_t want = len + 128;  // headroom for UUID appending
        char *shadow = ensure_send_shadow(want);
        if (shadow) {
            memcpy(shadow, buf, len);
            fprintf(stderr, "[DEBUG _sfteepreload.c] send() calling process_outbound_headers\n");
            fflush(stderr);

            char *extracted_parent_trace_id = NULL;
            size_t new_len = process_outbound_headers(shadow, len, g_send_shadow_cap, &extracted_parent_trace_id, fd, 1 /* allow_growth=1 for plaintext HTTP */);
            fprintf(stderr, "[DEBUG _sfteepreload.c] send() process_outbound_headers returned, new_len=%zu\n", new_len);
            fflush(stderr);

            // Store extracted parent trace ID
            if (extracted_parent_trace_id) {
                if (g_extracted_parent_trace_id) free(g_extracted_parent_trace_id);
                g_extracted_parent_trace_id = extracted_parent_trace_id;
            }

            // Use modified buffer if headers changed
            if (new_len != len) {
                send_buf = shadow;
                send_len = new_len;
            }
        }
    }

    // 2. Check if capture enabled (set once at init, no atomic) - instant skip if not configured
    // 3. Check if this fd is marked skip (lock-free bitmap) - instant skip for completed/non-HTTP
    // These checks are inside on_tx_fd()
    if (__builtin_expect(send_buf && send_len, 1)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] send() calling on_tx_fd, fd=%d\n", fd);
        fflush(stderr);
        // OPTIONAL: Safety net for async patterns (mark outbound on first TX if not already set)
        maybe_mark_outbound_on_first_tx(fd);
        on_tx_fd(fd, send_buf, send_len);
        fprintf(stderr, "[DEBUG _sfteepreload.c] send() on_tx_fd returned\n");
        fflush(stderr);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] send() about to call real_send\n");
    fflush(stderr);
    ssize_t result = real_send(fd, send_buf, send_len, flags);
    fprintf(stderr, "[DEBUG _sfteepreload.c] send() real_send returned, result=%zd\n", result);
    fflush(stderr);

    // No need to free shadow buffer - it's thread-local and reused across calls
    return result;
}
__attribute__((visibility("default")))
ssize_t recv(int fd, void *buf, size_t len, int flags){
    fprintf(stderr, "[DEBUG _sfteepreload.c] recv() ENTRY: fd=%d, len=%zu\n", fd, len);
    fflush(stderr);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) {
        return real_recv(fd, buf, len, flags);
    }

    // ULTRA-FAST: Check telemetry guard first (thread-local, instant skip)
    if (__builtin_expect(sf_guard_active(), 0)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] recv() in_telemetry_send, calling real_recv\n");
        fflush(stderr);
        return real_recv(fd, buf, len, flags);
    }

    // CRITICAL: In Python SSL mode, pass through SSL sockets (Python captures them)
    // Only capture plain HTTP sockets in C
    if (SF_PYTHON_SSL_MODE && is_ssl_socket(fd)) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] recv: fd=%d is SSL socket, passing through (Python SSL mode)\n", fd);
        return real_recv(fd, buf, len, flags);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recv() about to call real_recv\n");
    fflush(stderr);
    ssize_t r = real_recv(fd, buf, len, flags);
    fprintf(stderr, "[DEBUG _sfteepreload.c] recv() real_recv returned, result=%zd\n", r);
    fflush(stderr);

    if (__builtin_expect(r>0, 1)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] recv() calling on_rx_fd, fd=%d, bytes=%zd\n", fd, r);
        fflush(stderr);
        on_rx_fd(fd, buf, (size_t)r);
        fprintf(stderr, "[DEBUG _sfteepreload.c] recv() on_rx_fd returned\n");
        fflush(stderr);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recv() returning %zd\n", r);
    fflush(stderr);
    return r;
}
__attribute__((visibility("default")))
ssize_t sendto(int fd, const void *buf, size_t len, int flags, const struct sockaddr *to, socklen_t tolen){
    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_sendto(fd, buf, len, flags, to, tolen);

    // ULTRA-FAST: Check telemetry guard first (thread-local, instant skip)
    if (__builtin_expect(sf_guard_active(), 0)) return real_sendto(fd, buf, len, flags, to, tolen);

    // CRITICAL: Strip X-Sf4-Prid header from outbound requests (works on any buffer)
    const void *send_buf = buf;
    size_t send_len = len;
    char *modified_buf = NULL;

    // ULTRA-FAST: Skip expensive header processing if buffer doesn't look like HTTP request headers
    int looks_like_http_request = 0;
    if (__builtin_expect(buf && len >= 4, 1)) {
        const char *cbuf = (const char*)buf;
        if ((cbuf[0] == 'G' && cbuf[1] == 'E' && cbuf[2] == 'T' && cbuf[3] == ' ') ||      // GET
            (cbuf[0] == 'P' && cbuf[1] == 'O' && cbuf[2] == 'S' && cbuf[3] == 'T') ||     // POST
            (cbuf[0] == 'P' && cbuf[1] == 'U' && cbuf[2] == 'T' && cbuf[3] == ' ') ||      // PUT
            (cbuf[0] == 'P' && cbuf[1] == 'A' && cbuf[2] == 'T' && cbuf[3] == 'C') ||     // PATCH
            (cbuf[0] == 'D' && cbuf[1] == 'E' && cbuf[2] == 'L' && cbuf[3] == 'E') ||     // DELETE
            (cbuf[0] == 'H' && cbuf[1] == 'E' && cbuf[2] == 'A' && cbuf[3] == 'D') ||     // HEAD
            (cbuf[0] == 'O' && cbuf[1] == 'P' && cbuf[2] == 'T' && cbuf[3] == 'I') ||     // OPTIONS
            (cbuf[0] == 'C' && cbuf[1] == 'O' && cbuf[2] == 'N' && cbuf[3] == 'N')) {     // CONNECT
            looks_like_http_request = 1;
        }
    }

    if (__builtin_expect(looks_like_http_request && buf && len >= 20, 0)) {
        // SLOW PATH: Process HTTP request headers
        // Allocate buffer with extra space for UUID appending
        size_t buf_capacity = len + 64;
        modified_buf = (char*)malloc(buf_capacity);
        if (modified_buf) {
            memcpy(modified_buf, buf, len);
            // Extract parent_trace_id BEFORE stripping (same fix as send())
            // Note: TLS cleanup registration happens automatically in on_tx_fd()
            char *extracted_parent_trace_id = NULL;
            size_t new_len = process_outbound_headers(modified_buf, len, buf_capacity, &extracted_parent_trace_id, fd, 1 /* allow_growth=1 for plaintext HTTP */);

            // Store extracted value in thread-local for on_tx_fd() to retrieve
            if (extracted_parent_trace_id) {
                if (g_extracted_parent_trace_id) {
                    free(g_extracted_parent_trace_id);
                }
                g_extracted_parent_trace_id = extracted_parent_trace_id;
            }

            if (new_len != len) {
                send_buf = modified_buf;
                send_len = new_len;
            }
        }
    }

    if (__builtin_expect(send_buf && send_len, 1)) {
        on_tx_fd(fd, send_buf, send_len);
    }

    ssize_t result = real_sendto(fd, send_buf, send_len, flags, to, tolen);

    if (modified_buf) free(modified_buf);

    return result;
}
__attribute__((visibility("default")))
ssize_t recvfrom(int fd, void *buf, size_t len, int flags, struct sockaddr *from, socklen_t *fromlen){
    fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() ENTRY: fd=%d, len=%zu\n", fd, len);
    fflush(stderr);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) {
        return real_recvfrom(fd, buf, len, flags, from, fromlen);
    }

    // ULTRA-FAST: Check telemetry guard first (thread-local, instant skip)
    if (__builtin_expect(sf_guard_active(), 0)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() in_telemetry_send, calling real_recvfrom\n");
        fflush(stderr);
        return real_recvfrom(fd, buf, len, flags, from, fromlen);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() about to call real_recvfrom\n");
    fflush(stderr);
    ssize_t r = real_recvfrom(fd, buf, len, flags, from, fromlen);
    fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() real_recvfrom returned, result=%zd\n", r);
    fflush(stderr);

    if (__builtin_expect(r>0, 1)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() calling on_rx_fd, fd=%d, bytes=%zd\n", fd, r);
        fflush(stderr);
        on_rx_fd(fd, buf, (size_t)r);
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() on_rx_fd returned\n");
        fflush(stderr);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recvfrom() returning %zd\n", r);
    fflush(stderr);
    return r;
}
__attribute__((visibility("default")))
ssize_t sendmsg(int fd, const struct msghdr *msg, int flags){
    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_sendmsg(fd, msg, flags);

    // ULTRA-FAST: Check telemetry guard FIRST (thread-local, instant skip for telemetry sends)
    if (__builtin_expect(sf_guard_active(), 0)) return real_sendmsg(fd, msg, flags);

    // Flatten iov into a stack/heap scratch once to both capture and process headers
    size_t total = 0;
    if (msg && msg->msg_iovlen > 0) {
        for (size_t i = 0; i < (size_t)msg->msg_iovlen; i++) total += msg->msg_iov[i].iov_len;
    }

    // Allocate extra space for UUID appending (64 bytes)
    char stackbuf[8192 + 64];
    size_t buf_capacity = total + 64;
    char *merged = (buf_capacity <= sizeof(stackbuf)) ? stackbuf : (char*)malloc(buf_capacity);
    if (!merged) {
        // OOM: best effort capture then forward
        return real_sendmsg(fd, msg, flags);
    }

    size_t off = 0;
    for (size_t i = 0; i < (size_t)msg->msg_iovlen; i++) {
        memcpy(merged + off, msg->msg_iov[i].iov_base, msg->msg_iov[i].iov_len);
        off += msg->msg_iov[i].iov_len;
    }

    // HARDENING: Use same guard as send() - bail fast unless complete HTTP/1.x headers
    size_t send_len = total;
    char *extracted_parent_trace_id = NULL;

    if (buffer_looks_like_full_http_headers(merged, total)) {
        // SLOW PATH: Process HTTP request headers
        // Note: TLS cleanup registration happens automatically in on_tx_fd()
        // CRITICAL: Process headers - append UUID to X-Sf3-Rid and extract+strip X-Sf4-Prid
        send_len = process_outbound_headers(merged, total, buf_capacity, &extracted_parent_trace_id, fd, 1 /* allow_growth=1 for plaintext HTTP */);
    }

    // Store extracted value in thread-local for on_tx_fd() to retrieve
    if (extracted_parent_trace_id) {
        if (g_extracted_parent_trace_id) {
            free(g_extracted_parent_trace_id);
        }
        g_extracted_parent_trace_id = extracted_parent_trace_id;
    }

    // Capture (with safety net for async patterns)
    maybe_mark_outbound_on_first_tx(fd);
    on_tx_fd(fd, merged, send_len);

    // If headers were modified, need to send modified buffer instead of original iov
    ssize_t result;
    if (send_len != total) {
        // Headers were modified - send the modified merged buffer
        result = real_send(fd, merged, send_len, flags);
    } else {
        // No modifications - use original sendmsg for efficiency
        result = real_sendmsg(fd, msg, flags);
    }

    if (merged != stackbuf) free(merged);
    return result;
}
__attribute__((visibility("default")))
// FIX(2): only feed the ACTUAL bytes returned by recvmsg across iovecs
ssize_t recvmsg(int fd, struct msghdr *msg, int flags){
    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() ENTRY: fd=%d\n", fd);
    fflush(stderr);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) {
        return real_recvmsg(fd, msg, flags);
    }

    // ULTRA-FAST: Check telemetry guard FIRST (thread-local, instant skip for telemetry receives)
    if (__builtin_expect(sf_guard_active(), 0)) {
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() in_telemetry_send, calling real_recvmsg\n");
        fflush(stderr);
        return real_recvmsg(fd, msg, flags);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() about to call real_recvmsg\n");
    fflush(stderr);
    ssize_t r = real_recvmsg(fd, msg, flags);
    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() real_recvmsg returned, result=%zd\n", r);
    fflush(stderr);

    // ULTRA-FAST: Non-atomic check first (plain load, set once at init) - compile-time cheap!
    // CRITICAL OPTIMIZATION: Check skip bitmap ONCE before processing all iovecs
    if (__builtin_expect(r>0 && msg && msg->msg_iovlen>0 && g_enabled_cached, 1)){
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() processing iovecs, fd=%d, bytes=%zd, iovlen=%d\n", fd, r, msg->msg_iovlen);
        fflush(stderr);
        if (__builtin_expect(!should_skip(idx_fd(fd)), 1)) {  // Likely not skipped on first requests
            size_t remaining = (size_t)r;
            const struct iovec *iov = msg->msg_iov;
            for (int i=0;i<msg->msg_iovlen && remaining>0;i++){
                size_t take = minz(remaining, iov[i].iov_len);
                if (__builtin_expect(iov[i].iov_base && take, 1)){
                    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() calling on_rx_fd_internal, iov[%d], bytes=%zu\n", i, take);
                    fflush(stderr);
                    on_rx_fd_internal(fd, iov[i].iov_base, take);  // Use internal version (no double-check)
                    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() on_rx_fd_internal returned for iov[%d]\n", i);
                    fflush(stderr);
                    remaining -= take;
                }
            }
        }
        fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() finished processing iovecs\n");
        fflush(stderr);
    }

    fprintf(stderr, "[DEBUG _sfteepreload.c] recvmsg() returning %zd\n", r);
    fflush(stderr);
    return r;
}

// --- SSL helper functions ---
static pthread_once_t g_sym_once = PTHREAD_ONCE_INIT;

static void resolve_syms(void) {
    real_send      = dlsym(RTLD_NEXT, "send");
    real_recv      = dlsym(RTLD_NEXT, "recv");
    real_sendmsg   = dlsym(RTLD_NEXT, "sendmsg");
    real_recvmsg   = dlsym(RTLD_NEXT, "recvmsg");
    real_sendto    = dlsym(RTLD_NEXT, "sendto");
    real_recvfrom  = dlsym(RTLD_NEXT, "recvfrom");
    real_close     = dlsym(RTLD_NEXT, "close");
    real_socket    = dlsym(RTLD_NEXT, "socket");
    real_setsockopt= dlsym(RTLD_NEXT, "setsockopt");
    real_shutdown  = dlsym(RTLD_NEXT, "shutdown");

    real_SSL_write    = (int (*)(SSL*,const void*,int))dlsym(RTLD_NEXT, "SSL_write");
    real_SSL_read     = (int (*)(SSL*,void*,int))dlsym(RTLD_NEXT, "SSL_read");
    real_SSL_write_ex = (int (*)(SSL*,const void*,size_t,size_t*))dlsym(RTLD_NEXT, "SSL_write_ex");
    real_SSL_read_ex  = (int (*)(SSL*,void*,size_t,size_t*))dlsym(RTLD_NEXT, "SSL_read_ex");
    real_SSL_shutdown = (int (*)(SSL*))dlsym(RTLD_NEXT, "SSL_shutdown");
    real_SSL_free     = (void (*)(SSL*))dlsym(RTLD_NEXT, "SSL_free");
}

static inline void ensure_syms(void) { pthread_once(&g_sym_once, resolve_syms); }

// Heuristic: only attempt header surgery if the first byte looks like an HTTP method
static inline int looks_like_http_request_start(const char *p, size_t n) {
    if (n < 4) return 0;
    char c = p[0];
    return (c=='G' || c=='P' || c=='D' || c=='H' || c=='O' || c=='C'); // GET/POST/PUT/DELETE/HEAD/OPTIONS/CONNECT
}

// --- SSL direction binding helper ---
static inline int ssl_get_fd_safe(SSL *ssl) {
    if (!ssl) return -1;
    ssl_aux_t *aux = ssl_get_aux(ssl, 0);
    if (aux && aux->fd > 0) return aux->fd;

    int fd = -1;
    BIO *rbio = SSL_get_rbio(ssl);
    if (rbio) {
        fd = BIO_get_fd(rbio, NULL);
    }
    if (fd < 0) {
        BIO *wbio = SSL_get_wbio(ssl);
        if (wbio) {
            fd = BIO_get_fd(wbio, NULL);
        }
    }
    if (fd < 0) {
        conn_state_t *ss = get_state_ssl((void*)ssl, 0);
        if (ss && ss->fd >= 0) fd = ss->fd;
    }
    DEBUG_LOG("[SF_DEBUG _sfteepreload] ssl_get_fd_safe: ssl=%p resolved fd=%d (aux=%p)\n",
              (void*)ssl, fd, (void*)aux);
    if (aux && fd >= 0) aux->fd = fd;
    return fd;
}

static inline void ensure_ssl_bound_and_direction(SSL *ssl) {
    // CRITICAL: Bind SSL* to fd and propagate is_outbound from fd-state to ssl-state
    // This makes HTTPS outbound requests work (connect() sets fd's is_outbound=1, we copy it here)
    if (!ssl) return;

    ssl_aux_t *aux = ssl_get_aux(ssl, 1);
    if (!aux) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p aux allocation failed\n", (void*)ssl);
    }
    conn_state_t *ss = aux ? aux->state : NULL;
    if (!ss) ss = get_state_ssl((void*)ssl, 1);
    if (!ss) {
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p missing state\n", (void*)ssl);
        return;
    }

    if (ss->ssl_ptr != (void*)ssl) ss->ssl_ptr = (void*)ssl;
    ss->is_ssl = 1;
    DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p state=%p fd=%d\n",
              (void*)ssl, (void*)ss, ss->fd);

    // If we don't yet know the fd, fetch it from SSL*
    if (ss->fd <= 0) {
        int fd = ssl_get_fd_safe(ssl);
        if (fd >= 0) {
            ss->fd = fd;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p discovered fd=%d\n",
                      (void*)ssl, fd);
        }
    }

    if (aux) {
        aux->state = ss;
        if (ss->fd > 0) aux->fd = ss->fd;
    }

    // Copy outbound/inbound from the fd-mapped state if available
    if (ss->fd >= 0) {
        conn_state_t *fs = get_state_fd(ss->fd, 0);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p fd=%d fetched fd_state=%p aux=%p\n",
                  (void*)ssl, ss->fd, (void*)fs, (void*)aux);
        if (fs) {
            ss->is_outbound = fs->is_outbound;
            DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: ssl=%p fd=%d inherited outbound=%d\n",
                      (void*)ssl, ss->fd, ss->is_outbound);
        }
    }

    DEBUG_LOG("[SF_DEBUG _sfteepreload] ensure_ssl_bound: final ssl=%p state=%p fd=%d outbound=%d\n",
              (void*)ssl, (void*)ss, ss->fd, ss->is_outbound);
}

// --- OpenSSL path (cleartext) ---
// ============================= TLS HOOKS (SAFE, COPY-ONLY) =============================
// NOTE: These override libssl's symbols at link time (LD_PRELOAD interposition).
// They MUST be visible (default) elsewhere in the file or via linker flags.

__attribute__((visibility("default")))
SSL* SSL_new(SSL_CTX *ctx) {
    resolve_ssl_symbols_once();
    if (!real_SSL_new_ptr) {
        real_SSL_new_ptr = (SSL*(*)(SSL_CTX*))dlsym(RTLD_NEXT, "SSL_new");
    }
    SSL *ssl = real_SSL_new_ptr ? real_SSL_new_ptr(ctx) : NULL;

    // SIMPLIFIED: Just pass through, no state management needed
    return ssl;
}

__attribute__((visibility("default")))
int SSL_write(SSL *ssl, const void *buf, int num) {
    resolve_ssl_symbols_once();
    if (!real_SSL_write) {
        // fail open
        int (*orig)(SSL*,const void*,int) = (int(*)(SSL*,const void*,int))dlsym(RTLD_NEXT,"SSL_write");
        return orig ? orig(ssl, buf, num) : -1;
    }

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_SSL_write(ssl, buf, num);

    // Python SSL mode: C SSL hooks disabled (pass through to Python capture)
    // SSL capture removed - Python handles HTTPS, C handles plain HTTP
    if (SF_PYTHON_SSL_MODE || !SF_ENABLE_SSL_HOOKS) {
        return real_SSL_write(ssl, buf, num);
    }

    // If disabled or telemetry, pass-through
    if (!atomic_load_explicit(&g_enabled, memory_order_relaxed) || sf_guard_active() || num <= 0) {
        return real_SSL_write(ssl, buf, num);
    }

    // SSL capture code removed - just pass through
    DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_write: ssl=%p num=%d (capture disabled)\n",
              (void*)ssl, num);
    return real_SSL_write(ssl, buf, num);
}

__attribute__((visibility("default")))
int SSL_read(SSL *ssl, void *buf, int num) {
    resolve_ssl_symbols_once();
    if (!real_SSL_read) {
        int (*orig)(SSL*,void*,int) = (int(*)(SSL*,void*,int))dlsym(RTLD_NEXT,"SSL_read");
        return orig ? orig(ssl, buf, num) : -1;
    }

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_SSL_read(ssl, buf, num);

    // Python SSL mode: C SSL hooks disabled (pass through to Python capture)
    // SSL capture removed - Python handles HTTPS, C handles plain HTTP
    if (SF_PYTHON_SSL_MODE || !SF_ENABLE_SSL_HOOKS) {
        return real_SSL_read(ssl, buf, num);
    }

    // SSL capture code removed - just pass through
    DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_read: ssl=%p num=%d (capture disabled)\n",
              (void*)ssl, num);
    return real_SSL_read(ssl, buf, num);
}
__attribute__((visibility("default")))
int SSL_write_ex(SSL *ssl, const void *buf, size_t num, size_t *written) {
    resolve_ssl_symbols_once();
    if (!real_SSL_write_ex) {
        int ret = SSL_write(ssl, buf, (int)num);
        if (written) *written = (ret > 0) ? (size_t)ret : 0;
        return (ret > 0);
    }

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_SSL_write_ex(ssl, buf, num, written);

    // Python SSL mode: C SSL hooks disabled (pass through to Python capture)
    // SSL capture removed - Python handles HTTPS, C handles plain HTTP
    if (SF_PYTHON_SSL_MODE || !SF_ENABLE_SSL_HOOKS) {
        return real_SSL_write_ex(ssl, buf, num, written);
    }

    // SSL capture code removed - just pass through
    DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_write_ex: ssl=%p num=%zu (capture disabled)\n",
              (void*)ssl, num);
    return real_SSL_write_ex(ssl, buf, num, written);
}
__attribute__((visibility("default")))
int SSL_read_ex(SSL *ssl, void *buf, size_t num, size_t *readbytes) {
    resolve_ssl_symbols_once();
    if (!real_SSL_read_ex) {
        int r = SSL_read(ssl, buf, (int)num);
        if (readbytes) *readbytes = (r > 0) ? (size_t)r : 0;
        return (r > 0);
    }

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_SSL_read_ex(ssl, buf, num, readbytes);

    // Python SSL mode: C SSL hooks disabled (pass through to Python capture)
    // SSL capture removed - Python handles HTTPS, C handles plain HTTP
    if (SF_PYTHON_SSL_MODE || !SF_ENABLE_SSL_HOOKS) {
        return real_SSL_read_ex(ssl, buf, num, readbytes);
    }

    // SSL capture code removed - just pass through
    DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_read_ex: ssl=%p num=%zu (capture disabled)\n",
              (void*)ssl, num);
    return real_SSL_read_ex(ssl, buf, num, readbytes);
}

__attribute__((visibility("default")))
int SSL_set_fd(SSL *ssl, int fd) {
    resolve_ssl_symbols_once();
    if (!real_SSL_set_fd_ptr) {
        real_SSL_set_fd_ptr = (int(*)(SSL*,int))dlsym(RTLD_NEXT, "SSL_set_fd");
    }
    DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_set_fd: ssl=%p fd=%d\n", (void*)ssl, fd);
    int rc = real_SSL_set_fd_ptr ? real_SSL_set_fd_ptr(ssl, fd) : -1;

    // SIMPLIFIED: Just mark the fd as SSL socket for send/recv filtering
    // No state management, no aux structures
    if (SF_INITIALIZED && fd >= 0) {
        mark_ssl_socket(fd);
        DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_set_fd: marked fd=%d as SSL socket\n", fd);
        // HTTPS sockets are handled by Python; drop any C-layer state to avoid double capture
        remove_state_fd(fd);
        mark_skip(idx_fd(fd));
        mark_skip(idx_ptr((void*)ssl));
        DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_set_fd: fd=%d marked skip for HTTP capture\n", fd);
    }

    return rc;
}

__attribute__((visibility("default")))
int SSL_connect(SSL *ssl) {
    resolve_ssl_symbols_once();
    if (!real_SSL_connect_ptr) {
        int (*orig)(SSL*) = (int(*)(SSL*))dlsym(RTLD_NEXT, "SSL_connect");
        real_SSL_connect_ptr = orig;
    }

    // SIMPLIFIED: Just mark the fd as SSL socket for send/recv filtering
    // No state management, no aux structures
    if (SF_INITIALIZED && ssl) {
        int fd = ssl_get_fd_safe(ssl);
        if (fd >= 0) {
            mark_ssl_socket(fd);
            DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_connect: marked fd=%d as SSL socket\n", fd);
            remove_state_fd(fd);
            mark_skip(idx_fd(fd));
            mark_skip(idx_ptr((void*)ssl));
            DEBUG_LOG("[SF_DEBUG _sfteepreload] SSL_connect: fd=%d marked skip for HTTP capture\n", fd);
        }
    }

    return real_SSL_connect_ptr ? real_SSL_connect_ptr(ssl) : -1;
}

// --- Socket creation hook ---
__attribute__((visibility("default")))
int socket(int domain, int type, int protocol){
    // ULTRA-FAST: No dlsym branch (resolved at init)
    int fd = real_socket(domain, type, protocol);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return fd;

    // CRITICAL FIX: Defensively clean up stale state if OS reused this fd number
    // Without this, high-churn workloads (httpcore) leak state and cause ~2M req stalls
    if (fd >= 0) {
        remove_state_fd(fd);
        unmark_skip(idx_fd(fd));
        unmark_telemetry_fd(fd);
    }
    return fd;
}

// --- Connection cleanup hooks ---
__attribute__((visibility("default")))
int close(int fd){
    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_close(fd);

    // Clean up connection state if exists
    conn_state_t *s = get_state_fd(fd, 0);
    if (s) {
        // CRITICAL: Emit final event if response was captured but not yet emitted
        // This handles fast connections that close() without shutdown(SHUT_RDWR)
        if (s->have_resp_hdrs && !s->resp_done_once) {
            maybe_emit(s);
        }
        remove_state_fd(fd);
    }
    // Unmark telemetry fd to avoid bitmap leak
    unmark_telemetry_fd(fd);
    // Also unmark from skip bitmap (conn may have been marked skip)
    // CRITICAL: Clear skip bit so fd can be reused for new connections!
    // Note: idx_fd is identity for fd, so this is safe
    if (fd >= 0 && (size_t)fd < STATE_ARRAY_FD_SIZE) {
        unmark_skip(idx_fd(fd));  // Clear skip bit for fd reuse
        unmark_ssl_socket(fd);     // Clear SSL socket bit for fd reuse
    }
    return real_close(fd);
}

__attribute__((visibility("default")))
int shutdown(int fd, int how){
    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_shutdown ? real_shutdown(fd, how) : -1;

    // SHUT_RDWR means connection is fully closed - clean up state early
    if (how == SHUT_RDWR) {
        conn_state_t *s = get_state_fd(fd, 0);
        if (s) {
            // Emit final event if response was captured
            if (s->have_resp_hdrs && !s->resp_done_once) {
                maybe_emit(s);
            }
            remove_state_fd(fd);
        }
    }
    return real_shutdown ? real_shutdown(fd, how) : -1;
}

__attribute__((visibility("default")))
void SSL_free(SSL *ssl){
    // SIMPLIFIED: Just pass through, no state management
    if (real_SSL_free) {
        real_SSL_free(ssl);
    }
}

__attribute__((visibility("default")))
int SSL_shutdown(SSL *ssl){
    // SIMPLIFIED: Just pass through, no state management
    return real_SSL_shutdown ? real_SSL_shutdown(ssl) : 0;
}

// ============================= Direction Tagging Hooks =============================

__attribute__((visibility("default")))
int connect(int fd, const struct sockaddr *addr, socklen_t len) {
    // CRITICAL: Tag outbound client sockets (connect) with is_outbound=1
    // Only these sockets should be captured - server-side accept() sockets are skipped!
    connect_fn_t real_connect_fn = get_real_connect();
    if (!real_connect_fn) {
        errno = ENOSYS;
        return -1;
    }

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return real_connect_fn(fd, addr, len);

    DEBUG_LOG("[SF_DEBUG _sfteepreload] connect hook: fd=%d len=%u family=%d\n",
              fd, (unsigned)len, addr ? addr->sa_family : -1);

    // CRITICAL FIX: Clean up any stale state from previous use of this fd (OS reuse)
    if (fd >= 0) {
        remove_state_fd(fd);
        unmark_skip(idx_fd(fd));
        unmark_telemetry_fd(fd);
    }

    int rc = real_connect_fn(fd, addr, len);
    DEBUG_LOG("[SF_DEBUG _sfteepreload] connect hook: fd=%d rc=%d errno=%d\n",
              fd, rc, (rc < 0) ? errno : 0);

    if (fd >= 0) {
        // Outbound if connect succeeds OR is in progress (nonblocking)
        if (rc == 0 || (rc < 0 && (errno == EINPROGRESS || errno == EALREADY))) {
            conn_state_t *s = get_state_fd(fd, 1);  // Create state if needed
            if (s) {
                s->fd = fd;
                s->is_outbound = 1;   // Mark as client socket (outbound)
                DEBUG_LOG("[SF_DEBUG _sfteepreload] connect hook: fd=%d state=%p marked outbound\n",
                          fd, (void*)s);
                // don't set s->active here; that waits until HTTP detected
            }
        }
    }
    return rc;
}

__attribute__((visibility("default")))
int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen) {
    // CRITICAL: Server-side accepted sockets should be marked inbound (is_outbound=0)
    // The feed_stream() check will skip them, but we need state for proper cleanup
    accept_fn_t real_accept_fn = get_real_accept();
    if (!real_accept_fn) {
        errno = ENOSYS;
        return -1;
    }
    int cfd = real_accept_fn(sockfd, addr, addrlen);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return cfd;

    DEBUG_LOG("[SF_DEBUG _sfteepreload] accept hook: parent=%d child=%d\n", sockfd, cfd);

    // CRITICAL FIX: Clean up any stale state if OS reused this fd number
    if (cfd >= 0) {
        remove_state_fd(cfd);
        unmark_skip(idx_fd(cfd));
        unmark_telemetry_fd(cfd);

        conn_state_t *s = get_state_fd(cfd, 1);
        if (s) {
            s->fd = cfd;
            s->is_outbound = 0;  // inbound/server side
            DEBUG_LOG("[SF_DEBUG _sfteepreload] accept hook: child=%d state=%p marked inbound\n",
                      cfd, (void*)s);
        }
    }
    return cfd;
}

__attribute__((visibility("default")))
int accept4(int sockfd, struct sockaddr *addr, socklen_t *addrlen, int flags) {
    // CRITICAL: Same as accept() - mark server-side sockets as inbound
    accept4_fn_t real_accept4_fn = get_real_accept4();
    if (!real_accept4_fn) {
        errno = ENOSYS;
        return -1;
    }
    int cfd = real_accept4_fn(sockfd, addr, addrlen, flags);

    // CRITICAL: Wait for setup_interceptors() to configure C library
    if (!SF_INITIALIZED) return cfd;
    DEBUG_LOG("[SF_DEBUG _sfteepreload] accept4 hook: parent=%d child=%d flags=%d\n",
              sockfd, cfd, flags);

    // CRITICAL FIX: Clean up any stale state if OS reused this fd number
    if (cfd >= 0) {
        remove_state_fd(cfd);
        unmark_skip(idx_fd(cfd));
        unmark_telemetry_fd(cfd);

        conn_state_t *s = get_state_fd(cfd, 1);
        if (s) {
            s->fd = cfd;
            s->is_outbound = 0;  // inbound/server side
            DEBUG_LOG("[SF_DEBUG _sfteepreload] accept4 hook: child=%d state=%p marked inbound\n",
                      cfd, (void*)s);
        }
    }
    return cfd;
}

// ============================= Configuration Setters (Called by Python) =============================

// Python calls these functions AFTER setup_interceptors() to push configuration to C library
// This replaces the old approach where C constructor read env vars (which were NULL before Python started)

// Helper function to build JSON prefix for mutations
// MUST be called AFTER SF_API_KEY and SF_SERVICE_UUID are set
static int build_json_prefix(void) {
    if (!SF_API_KEY || !SF_SERVICE_UUID) {
        fprintf(stderr, "[_sfteepreload] ERROR: build_json_prefix called without API key or service UUID!\n");
        fflush(stderr);
        return 0;
    }

    // Free old prefix if it exists
    if (g_json_prefix) {
        free(g_json_prefix);
        g_json_prefix = NULL;
    }

    // Build JSON prefix for collectNetworkRequest mutation
    sb_t sb={0};
    const char *q = "{\"query\":\"mutation CollectNetworkRequest($data:NetworkRequestInput!){"
                    "collectNetworkRequest(data:$data)}\","
                    "\"variables\":{\"data\":{\"apiKey\":";

    if (!sb_putstr(&sb, q)) goto prefix_fail;
    if (!sb_put_json_esc_cstr(&sb, SF_API_KEY)) goto prefix_fail;
    if (!sb_putstr(&sb, ",\"serviceUuid\":")) goto prefix_fail;
    if (!sb_put_json_esc_cstr(&sb, SF_SERVICE_UUID)) goto prefix_fail;
    if (!sb_putc(&sb, ',')) goto prefix_fail;
    if (!sb_putc(&sb, 0)) goto prefix_fail;

    g_json_prefix = sb.buf;
    fprintf(stderr, "[_sfteepreload] ✓ Built JSON prefix for mutations\n");
    fflush(stderr);
    return 1;

prefix_fail:
    fprintf(stderr, "[ERROR _sfteepreload] Failed to build JSON prefix - OUT OF MEMORY or buffer error!\n");
    fflush(stderr);
    free(sb.buf);
    return 0;
}

__attribute__((visibility("default")))
void sf_set_sink_url(const char *url) {
    if (SF_SINK_URL) {
        free(SF_SINK_URL);
    }
    SF_SINK_URL = url ? strdup(url) : NULL;
    fprintf(stderr, "[_sfteepreload] sf_set_sink_url: %s\n", SF_SINK_URL ? SF_SINK_URL : "(null)");
    fflush(stderr);
}

__attribute__((visibility("default")))
void sf_set_api_key(const char *key) {
    if (SF_API_KEY) {
        free(SF_API_KEY);
    }
    SF_API_KEY = key ? strdup(key) : NULL;
    fprintf(stderr, "[_sfteepreload] sf_set_api_key: %s\n", SF_API_KEY ? "***" : "(null)");
    fflush(stderr);
}

__attribute__((visibility("default")))
void sf_set_service_uuid(const char *uuid) {
    if (SF_SERVICE_UUID) {
        free(SF_SERVICE_UUID);
    }
    SF_SERVICE_UUID = uuid ? strdup(uuid) : NULL;
    fprintf(stderr, "[_sfteepreload] sf_set_service_uuid: %s\n", SF_SERVICE_UUID ? SF_SERVICE_UUID : "(null)");
    fflush(stderr);
}

__attribute__((visibility("default")))
void sf_initialize(void) {
    fprintf(stderr, "[_sfteepreload] sf_initialize: Activating C library...\n");
    fflush(stderr);

    // Validate configuration before activating
    if (!SF_SINK_URL || !SF_API_KEY || !SF_SERVICE_UUID) {
        fprintf(stderr, "[_sfteepreload] ERROR: sf_initialize called without complete configuration!\n");
        fprintf(stderr, "[_sfteepreload]   SF_SINK_URL=%s, SF_API_KEY=%s, SF_SERVICE_UUID=%s\n",
                SF_SINK_URL ? SF_SINK_URL : "(null)",
                SF_API_KEY ? "***" : "(null)",
                SF_SERVICE_UUID ? SF_SERVICE_UUID : "(null)");
        fflush(stderr);
        return;
    }

    // CRITICAL: Build JSON prefix NOW that we have the correct API key and service UUID
    // Constructor couldn't build this because these values were NULL
    if (!build_json_prefix()) {
        fprintf(stderr, "[_sfteepreload] ERROR: Failed to build JSON prefix, cannot activate!\n");
        fflush(stderr);
        return;
    }

    // Activate the C library - hooks will now capture traffic
    SF_INITIALIZED = 1;

    fprintf(stderr, "[_sfteepreload] ✓ C library initialized and activated\n");
    fprintf(stderr, "[_sfteepreload]   Sink URL: %s\n", SF_SINK_URL);
    fprintf(stderr, "[_sfteepreload]   Service UUID: %s\n", SF_SERVICE_UUID);
    fprintf(stderr, "[_sfteepreload]   Python SSL mode: %s\n", SF_PYTHON_SSL_MODE ? "ENABLED" : "DISABLED");
    fflush(stderr);
}

// ============================= Init / Fini =============================

// Note: sftee_fini is defined later (after sender thread code) to have access to cleanup functions

__attribute__((constructor))
static void sftee_init(void){
    const char *v = NULL;

    install_debug_signal_handlers();

    // ULTRA-FAST: Resolve ALL symbols up front to remove per-call dlsym branches!
    // This eliminates 5-20ns overhead per syscall
    real_send = dlsym(RTLD_NEXT, "send");
    real_recv = dlsym(RTLD_NEXT, "recv");
    real_sendto = dlsym(RTLD_NEXT, "sendto");
    real_recvfrom = dlsym(RTLD_NEXT, "recvfrom");
    real_sendmsg = dlsym(RTLD_NEXT, "sendmsg");
    real_recvmsg = dlsym(RTLD_NEXT, "recvmsg");
    real_close = dlsym(RTLD_NEXT, "close");
    real_socket = dlsym(RTLD_NEXT, "socket");
    real_SSL_write = dlsym(RTLD_NEXT, "SSL_write");
    real_SSL_read = dlsym(RTLD_NEXT, "SSL_read");
    real_SSL_write_ex = dlsym(RTLD_NEXT, "SSL_write_ex");
    real_SSL_read_ex = dlsym(RTLD_NEXT, "SSL_read_ex");
    real_SSL_free = dlsym(RTLD_NEXT, "SSL_free");
    real_shutdown = dlsym(RTLD_NEXT, "shutdown");
    real_setsockopt = dlsym(RTLD_NEXT, "setsockopt");
    real_SSL_shutdown = dlsym(RTLD_NEXT, "SSL_shutdown");
    real_SSL_connect_ptr = dlsym(RTLD_NEXT, "SSL_connect");
    real_SSL_set_fd_ptr = dlsym(RTLD_NEXT, "SSL_set_fd");
    real_SSL_new_ptr = dlsym(RTLD_NEXT, "SSL_new");

    // NOTE: GOT guard moved to END of constructor (after threads start)
    // Enabling it here causes crashes when sender threads trigger lazy symbol resolution

    // ALWAYS log initialization to confirm library is loading
    fprintf(stderr, "[_sfteepreload] Initializing libsfnettee.so (SF_DEBUG=%s)\n", getenv("SF_DEBUG") ? getenv("SF_DEBUG") : "(not set)");
    fflush(stderr);

    if ((v=getenv("SFT_RING_CAP")))              SF_RING_CAP = strtoull(v,NULL,10);
    if ((v=getenv("SFT_MAX_REQ_BODY")))          SF_MAX_REQ_BODY = strtoull(v,NULL,10);
    if ((v=getenv("SFT_MAX_RESP_BODY")))         SF_MAX_RESP_BODY = strtoull(v,NULL,10);
    if ((v=getenv("SFT_CAPTURE_REQ_HEADERS")))   SF_CAPTURE_REQ_HEADERS = atoi(v);
    if ((v=getenv("SFT_CAPTURE_RESP_HEADERS")))  SF_CAPTURE_RESP_HEADERS = atoi(v);
    if ((v=getenv("SFT_EXTRACT_GRAPHQL_NAME")))  SF_EXTRACT_GRAPHQL_NAME = atoi(v);
    if ((v=getenv("SFT_ENABLE_PYTHON_FILTERS"))) SF_ENABLE_PYTHON_FILTERS = atoi(v);
    if ((v=getenv("SFT_SENDER_THREADS")))        SF_SENDER_THREADS = atoi(v);
    if ((v=getenv("SFT_THREAD_KEEPALIVE")))      SF_THREAD_KEEPALIVE = atof(v);
    if ((v=getenv("SFT_HTTP2")))                 SF_HTTP2 = atoi(v);
    if ((v=getenv("SFT_ENABLE_SSL_HOOKS")))      SF_ENABLE_SSL_HOOKS = atoi(v);
    if ((v=getenv("SF_SSL_PYTHON_MODE")))        SF_PYTHON_SSL_MODE = atoi(v);

    // [DIAGNOSTICS] Retry and delivery mode configuration
    if ((v=getenv("SFT_SEND_RETRIES")))          SF_SEND_RETRIES = atoi(v);
    if ((v=getenv("SFT_STRICT_DELIVERY")))       SF_STRICT_DELIVERY = atoi(v);

    // CRITICAL: SF_SINK_URL, SF_API_KEY, and SF_SERVICE_UUID are now set by Python via setter functions
    // Constructor runs BEFORE Python starts, so these env vars would be NULL/empty here
    // Python calls sf_set_sink_url(), sf_set_api_key(), sf_set_service_uuid(), sf_initialize() after setup_interceptors()
    // SF_SINK_URL     = str_dup(getenv("SAILFISH_GRAPHQL_ENDPOINT"));  // OLD: Now set by sf_set_sink_url()
    // SF_API_KEY      = str_dup(getenv("SAILFISH_API_KEY"));           // OLD: Now set by sf_set_api_key()
    // SF_SERVICE_UUID = str_dup(getenv("SFT_SERVICE_UUID"));           // OLD: Now set by sf_set_service_uuid()
    SF_LIBRARY      = str_dup(getenv("SFT_LIBRARY"));
    SF_VERSION      = str_dup(getenv("SFT_VERSION"));

    // Log Python SSL mode status
    if (SF_PYTHON_SSL_MODE) {
        fprintf(stderr, "[_sfteepreload] ✓ Python SSL mode ENABLED - C SSL hooks will be DISABLED\n");
        fprintf(stderr, "[_sfteepreload]   Python patches handle HTTPS capture (~15-20ns overhead)\n");
        fflush(stderr);
    } else {
        if (SF_DEBUG) {
            fprintf(stderr, "[SF_DEBUG _sfteepreload] Python SSL mode OFF - using C SSL hooks\n");
            fflush(stderr);
        }
    }

    // Initialize OpenSSL for optional HTTPS telemetry
    SSL_library_init();
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();
    g_telem_ssl_ctx = SSL_CTX_new(TLS_client_method());
    if (g_telem_ssl_ctx) {
        // Fire-and-forget telemetry: skip certificate verification to avoid handshake failures
        // (Change to SSL_VERIFY_PEER if you need to validate certificates)
        SSL_CTX_set_verify(g_telem_ssl_ctx, SSL_VERIFY_NONE, NULL);
    }

    // Initialize lock-free state arrays to NULL (static/global, so already zero, but explicit is good)
    for (size_t i = 0; i < STATE_ARRAY_FD_SIZE; i++) {
        atomic_store_explicit(&g_state_array_fd[i], NULL, memory_order_relaxed);
    }
    for (size_t i = 0; i < STATE_ARRAY_SSL_SIZE; i++) {
        atomic_store_explicit(&g_state_array_ssl[i], NULL, memory_order_relaxed);
    }

    // Initialize skip bitmap to zeros (static/global, so already zero, but explicit is good)
    for (size_t i = 0; i < SKIP_BITMAP_SIZE; i++) {
        atomic_store_explicit(&g_skip_bitmap[i], 0, memory_order_relaxed);
    }

    // Initialize SSL socket bitmap to zeros (tracks SSL vs plain HTTP sockets)
    for (size_t i = 0; i < SKIP_BITMAP_SIZE; i++) {
        atomic_store_explicit(&g_ssl_socket_bitmap[i], 0, memory_order_relaxed);
    }

    // Network capture works immediately, trace_id will come from TLS or headers

    // Initialize OTEL endpoint filtering
    init_otel_endpoints();

    // Initialize network suppression patterns
    init_suppress_patterns();

    // ULTRA-FAST: Round up to power-of-2 for mask-based indexing (no modulo!)
    size_t requested_cap = SF_RING_CAP ? SF_RING_CAP : 262144;
    g_rcap = 1;
    while (g_rcap < requested_cap) g_rcap <<= 1;
    g_rcap_mask = g_rcap - 1;  // For fast & instead of %
    g_ring = (tee_msg_t*)calloc(g_rcap, sizeof(tee_msg_t));

    // REMOVED: JSON prefix building moved to sf_initialize()
    // Constructor runs BEFORE Python starts, so SF_API_KEY and SF_SERVICE_UUID are NULL here
    // Python will call sf_initialize() after pushing configuration via sf_set_* functions
    // g_json_prefix will be built then with the correct values

    // MULTI-THREADED SENDER: Start N background threads for parallel processing
    // This scales out under high load without dropping messages
    atomic_store(&g_running, 1);
    g_num_sender_threads = SF_SENDER_THREADS;
    if (g_num_sender_threads < 1) g_num_sender_threads = 1;
    if (g_num_sender_threads > MAX_SENDER_THREADS) g_num_sender_threads = MAX_SENDER_THREADS;
    for (int i = 0; i < g_num_sender_threads; i++) {
        pthread_create(&g_sender_threads[i], NULL, sender_main, NULL);
    }

    // ULTRA-FAST UUID GENERATION: Start background UUID generator thread
    // Pre-generates UUIDs in ring buffer for ~100ns retrieval (vs 10-20μs!)
    start_uuid_generator_thread();
    if (SF_DEBUG) fprintf(stderr, "[SF_DEBUG _sfteepreload] Started UUID generator thread (16K buffer, ~600KB)\n");

    if (SF_DEBUG) {
#if SF_ENABLE_STATS_WATCHDOG
        pthread_t stats_thread;
        pthread_create(&stats_thread, NULL, stats_watchdog_main, NULL);
        pthread_detach(stats_thread);
        fprintf(stderr, "[SF_DEBUG _sfteepreload] Started stats watchdog thread (prints every 5 seconds)\n");
#else
        fprintf(stderr, "[SF_DEBUG _sfteepreload] Stats watchdog disabled (prevents TLS races)\n");
#endif
    }

    // ULTRA-FAST: Enable library ONLY if sink URL is configured
    // This gives ZERO overhead when library is loaded but not configured
    g_enabled_cached = (SF_SINK_URL && *SF_SINK_URL) ? 1 : 0;
    atomic_store(&g_enabled, g_enabled_cached);

    if (g_enabled_cached) {
    } else {
    }

    // CRITICAL: Enable GOT guard LAST, after all threads are started and symbols resolved
    // Doing this earlier causes crashes when sender threads trigger lazy binding
    enable_got_guard();
}

__attribute__((destructor))
static void sftee_fini(void){

    // Stop UUID generator thread first
    stop_uuid_generator_thread();
    if (SF_DEBUG) {
        fprintf(stderr, "[SF_DEBUG _sfteepreload] UUID generator stats: hits=%lu, misses=%lu, empty=%lu, fallbacks=%lu\n",
            (unsigned long)atomic_load(&g_uuid_ring_hits),
            (unsigned long)atomic_load(&g_uuid_ring_misses),
            (unsigned long)atomic_load(&g_uuid_buffer_empty),
            (unsigned long)atomic_load(&g_uuid_ring_fallbacks));
    }

    atomic_store(&g_running, 0);
    // Wake up all sender threads
    pthread_mutex_lock(&g_cv_mtx);
    pthread_cond_broadcast(&g_cv);  // Use broadcast to wake ALL threads
    pthread_mutex_unlock(&g_cv_mtx);

    // Join all sender threads (their pthread cleanup handlers will close their telemetry connections)
    for (int i = 0; i < g_num_sender_threads; i++) {
        if (g_sender_threads[i]) pthread_join(g_sender_threads[i], NULL);
    }

    // CRITICAL: Drain any remaining ring buffer items to prevent memory leaks
    // This is a safety net in case items were pushed during shutdown
    tee_msg_t msg;
    while (ring_pop_raw(&msg)) {
        // Free all allocated strings to prevent leaks
        free(msg.req_host);
        free(msg.req_hdr_raw);
        free(msg.req_hdr_json);
        free(msg.resp_hdr_json);
        free(msg.req_body_sample);
        free(msg.resp_body_sample);
        free(msg.parent_trace_id);
    }

    // Close main thread's telemetry connection (if any)
    if (g_telem_ssl) {
        SSL_free(g_telem_ssl);
        g_telem_ssl = NULL;
    }
    if (g_telem_sock >= 0) {
        if (real_close) {
            real_close(g_telem_sock);  // Use real_close for telemetry socket
        } else {
            close(g_telem_sock);
        }
        g_telem_sock = -1;
    }

    // Clean up Python ContextVar references and close Python handle
    if (py_IsInitialized && py_IsInitialized()) {
        if (g_trace_id_contextvar && py_Decref) {
            py_Decref(g_trace_id_contextvar);
            g_trace_id_contextvar = NULL;
        }
        if (g_suppress_network_recording_contextvar && py_Decref) {
            py_Decref(g_suppress_network_recording_contextvar);
            g_suppress_network_recording_contextvar = NULL;
        }
        // [ADD] Clean up funcspan_override ContextVar
        if (g_funcspan_override_contextvar && py_Decref) {
            py_Decref(g_funcspan_override_contextvar);
            g_funcspan_override_contextvar = NULL;
        }
    }
    if (g_python_handle) {
        dlclose(g_python_handle);
        g_python_handle = NULL;
    }

    // Clean up lock-free state arrays
    for (size_t i = 0; i < STATE_ARRAY_FD_SIZE; i++) {
        conn_state_t *s = atomic_load_explicit(&g_state_array_fd[i], memory_order_relaxed);
        if (s) {
            free_state(s);
            free(s);
        }
    }
    for (size_t i = 0; i < STATE_ARRAY_SSL_SIZE; i++) {
        conn_state_t *s = atomic_load_explicit(&g_state_array_ssl[i], memory_order_relaxed);
        if (s) {
            free_state(s);
            free(s);
        }
    }

    // Clean up OTEL endpoints
    for (int i = 0; i < g_otel_endpoint_count; i++) {
        free(g_otel_endpoints[i].host);
        free(g_otel_endpoints[i].path);
    }

    // Clean up suppression patterns
    for (int i = 0; i < g_suppress_pattern_count; i++) {
        free(g_suppress_patterns[i].pattern);
    }

    // Free ring buffer and JSON prefix
    free(g_ring);
    free(g_json_prefix);
    g_ring = NULL;
    g_json_prefix = NULL;

    // Free configuration strings
    free(SF_SINK_URL);
    free(SF_API_KEY);
    free(SF_SERVICE_UUID);
    free(SF_LIBRARY);
    free(SF_VERSION);
    SF_SINK_URL = NULL;
    SF_API_KEY = NULL;
    SF_SERVICE_UUID = NULL;
    SF_LIBRARY = NULL;
    SF_VERSION = NULL;

    // Free SSL context for telemetry (HTTPS support)
    if (g_telem_ssl_ctx) {
        SSL_CTX_free(g_telem_ssl_ctx);
        g_telem_ssl_ctx = NULL;
    }
}
static volatile sig_atomic_t g_in_segv_handler = 0;

static void segv_handler(int sig, siginfo_t *info, void *ucontext) {
    (void)ucontext;
    if (g_in_segv_handler) {
        _exit(128 + sig);
    }
    g_in_segv_handler = 1;
    char buf[512];
    size_t off = 0;
    off = buf_append(buf, sizeof(buf), off, "[SF_DEBUG _sfteepreload] **** Caught signal ");
    off = buf_append_uint(buf, sizeof(buf), off, (uint64_t)sig);
    off = buf_append(buf, sizeof(buf), off, " si_errno=");
    off = buf_append_uint(buf, sizeof(buf), off, info ? (uint64_t)info->si_errno : 0);
    off = buf_append(buf, sizeof(buf), off, " si_code=");
    off = buf_append_uint(buf, sizeof(buf), off, info ? (uint64_t)info->si_code : 0);
    off = buf_append(buf, sizeof(buf), off, " addr=0x");
    off = buf_append_hex(buf, sizeof(buf), off, info ? (uint64_t)info->si_addr : 0);

#if defined(__linux__) && defined(__aarch64__)
    if (ucontext) {
        ucontext_t *uc = (ucontext_t*)ucontext;
        uint64_t pc = uc->uc_mcontext.pc;
        uint64_t sp = uc->uc_mcontext.sp;
        uint64_t lr = uc->uc_mcontext.regs[30];
        off = buf_append(buf, sizeof(buf), off, " pc=0x");
        off = buf_append_hex(buf, sizeof(buf), off, pc);
        off = buf_append(buf, sizeof(buf), off, " lr=0x");
        off = buf_append_hex(buf, sizeof(buf), off, lr);
        off = buf_append(buf, sizeof(buf), off, " sp=0x");
        off = buf_append_hex(buf, sizeof(buf), off, sp);
        off = buf_append(buf, sizeof(buf), off, "\n[SF_DEBUG _sfteepreload] regs:");
        for (int i = 0; i < 31 && off + 32 < sizeof(buf); i++) {
            off = buf_append(buf, sizeof(buf), off, " x");
            off = buf_append_uint(buf, sizeof(buf), off, (uint64_t)i);
            off = buf_append(buf, sizeof(buf), off, "=0x");
            off = buf_append_hex(buf, sizeof(buf), off, uc->uc_mcontext.regs[i]);
        }
        off = buf_append(buf, sizeof(buf), off, " pstate=0x");
        off = buf_append_hex(buf, sizeof(buf), off, uc->uc_mcontext.pstate);
    }
#endif

    if (off < sizeof(buf))
        buf[off++] = '\n';

    write(STDERR_FILENO, buf, off);
    fsync(STDERR_FILENO);
    _exit(128 + sig);
}

static void install_debug_signal_handlers(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = segv_handler;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
}
