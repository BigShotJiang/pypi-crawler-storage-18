"""Flows module for WikiGen."""
