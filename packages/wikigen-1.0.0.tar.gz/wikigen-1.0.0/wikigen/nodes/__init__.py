"""Nodes module for WikiGen."""
