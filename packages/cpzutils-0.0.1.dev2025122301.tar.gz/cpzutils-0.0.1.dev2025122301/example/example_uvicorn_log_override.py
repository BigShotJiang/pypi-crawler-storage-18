# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "cpzutils>=0.0.1.dev2025122301",
#     "fastapi>=0.127.0",
#     "uvicorn>=0.40.0",
# ]
# ///
from contextlib import asynccontextmanager

from fastapi import FastAPI
import uvicorn

import cpzutils.uvicorn_log_override


@asynccontextmanager
async def lifespan(app: FastAPI):
    cpzutils.uvicorn_log_override.override_access_log()
    yield


app = FastAPI(
    lifespan=lifespan,
)


if __name__ == "__main__":
    uvicorn.run(app)
