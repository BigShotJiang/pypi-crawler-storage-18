# Auto-generated Python types from Avro schemas
# DO NOT EDIT MANUALLY

from typing import Optional, Any


class EventMetadata:
    """Common metadata for all events"""
    def __init__(self, correlationId: str, causationId: str, traceId: str):
        # Unique identifier for tracking related events
        self.correlationId = correlationId
        # Identifier of the event that caused this event
        self.causationId = causationId
        # Distributed tracing identifier
        self.traceId = traceId


class BaseEvent:
    """Base event structure for all events in the system"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event (e.g., user.created, user.updated)
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata


class BalanceTopUpPayload:
    """Payload for balance top-up in beginner program"""
    def __init__(self, userId: str, clubId: int, amount: float):
        # User ID who topped up balance
        self.userId = userId
        # Club ID where top-up occurred
        self.clubId = clubId
        # Amount topped up
        self.amount = amount


class BalanceTopUpEvent:
    """Event emitted when user tops up balance (beginner program step 1/4)"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: BalanceTopUpPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Balance top-up data
        self.data = data


class OptionSelectedPayload:
    """Payload for option selection in beginner program step 2"""
    def __init__(self, userId: str, clubId: int, optionId: int):
        # User ID who selected option
        self.userId = userId
        # Club ID where selection occurred
        self.clubId = clubId
        # Selected option ID (1/2/3)
        self.optionId = optionId


class OptionSelectedEvent:
    """Event emitted when staff selects option for user (beginner program step 2)"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: OptionSelectedPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Option selection data
        self.data = data


class StepCompletedPayload:
    """Payload for step 3 completion in beginner program"""
    def __init__(self, userId: str, clubId: int):
        # User ID who completed step 3
        self.userId = userId
        # Club ID where completion occurred
        self.clubId = clubId


class StepCompletedEvent:
    """Event emitted when staff marks step 3 as completed (beginner program)"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: StepCompletedPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Step completion data
        self.data = data


class GrantBonusPayload:
    """Payload for granting bonus from gamer-id service"""
    def __init__(self, userId: str, clubId: int, amount: float, stepId: int):
        # User ID to grant bonus to
        self.userId = userId
        # Club ID where bonus should be granted
        self.clubId = clubId
        # Bonus amount to grant
        self.amount = amount
        # Completed step id that we should grant bonus for
        self.stepId = stepId


class GrantBonusEvent:
    """Event from gamer-id to grant bonus to user"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: GrantBonusPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Bonus grant data
        self.data = data


class MarkCompletedPayload:
    """Payload for marking program as completed"""
    def __init__(self, userId: str):
        # User ID who completed the program
        self.userId = userId


class MarkCompletedEvent:
    """Event from gamer-id to mark user as completed beginner program"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: MarkCompletedPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Completion mark data
        self.data = data


class PromoCodeUsePayload:
    """Payload for using promo code"""
    def __init__(self, promoCode: str, success: bool):
        # Promo code for use
        self.promoCode = promoCode
        # Is successfull promo code usage
        self.success = success


class PromoCodeUsedEvent:
    """Event emitted when a promo code used"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: PromoCodeUsePayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Promo code data
        self.data = data


class UserPayload:
    """User data payload"""
    def __init__(self, id: str, login: str, phone: str, email: Optional[str] = None, name: Optional[str] = None, surname: Optional[str] = None, patronymic: Optional[str] = None, birthday: Optional[str] = None, gender: Optional[str] = None, avatarUrl: Optional[str] = None, photoUrl: Optional[str] = None, clubId: Optional[int] = None, rankId: Optional[int] = None, subscriptionName: Optional[str] = None, beginnersProgramStatus: Optional[str] = None):
        # Unique identifier for the user
        self.id = id
        # User login
        self.login = login
        # User phone number
        self.phone = phone
        # User email address
        self.email = email
        # User first name
        self.name = name
        # User surname
        self.surname = surname
        # User patronymic
        self.patronymic = patronymic
        # User birthday
        self.birthday = birthday
        # User gender
        self.gender = gender
        # User avatar URL
        self.avatarUrl = avatarUrl
        # User photo URL
        self.photoUrl = photoUrl
        # User club ID
        self.clubId = clubId
        # User rank ID
        self.rankId = rankId
        # User subscription name
        self.subscriptionName = subscriptionName
        # Beginners Program Status
        self.beginnersProgramStatus = beginnersProgramStatus


class UserCreatedEvent:
    """Event emitted when a new user is created"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: UserPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # User data
        self.data = data


class UpdateUserPayload:
    """User update payload"""
    def __init__(self, userId: str, login: Optional[str] = None, phone: Optional[str] = None, email: Optional[str] = None, name: Optional[str] = None, surname: Optional[str] = None, patronymic: Optional[str] = None, birthday: Optional[str] = None, gender: Optional[str] = None, avatarUrl: Optional[str] = None, photoUrl: Optional[str] = None, rankId: Optional[int] = None, subscriptionName: Optional[str] = None, telegramId: Optional[int] = None, telegramLink: Optional[str] = None):
        # Unique identifier for the user being updated
        self.userId = userId
        # User login
        self.login = login
        # User phone number
        self.phone = phone
        # User email address
        self.email = email
        # User first name
        self.name = name
        # User surname
        self.surname = surname
        # User patronymic
        self.patronymic = patronymic
        # User birthday
        self.birthday = birthday
        # User gender
        self.gender = gender
        # User avatar URL
        self.avatarUrl = avatarUrl
        # User photo URL
        self.photoUrl = photoUrl
        # User rank ID
        self.rankId = rankId
        # User subscription name
        self.subscriptionName = subscriptionName
        # User telegram ID
        self.telegramId = telegramId
        # User telegram link
        self.telegramLink = telegramLink


class UserUpdatedEvent:
    """Event emitted when a user is updated"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: UpdateUserPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Updated user data
        self.data = data


class DeletedUserPayload:
    """Deleted user data payload"""
    def __init__(self, userId: str):
        # Unique identifier for the deleted user
        self.userId = userId


class UserDeletedEvent:
    """Event emitted when a user is deleted"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: DeletedUserPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Deleted user data
        self.data = data


class UserBalanceUpdatedPayload:
    """User data payload"""
    def __init__(self, id: str, balance: int):
        # Unique identifier for the user
        self.id = id
        # User balance
        self.balance = balance


class UserBalanceUpdatedEvent:
    """Event emitted when a user is deleted"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: UserBalanceUpdatedPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # Updated user balance data
        self.data = data


class UserClubBalanceTopUpPayload:
    """Payload for user club balance top-up event"""
    def __init__(self, userId: str, amount: float):
        # Unique identifier for the user
        self.userId = userId
        # Amount added to the user's club balance
        self.amount = amount


class UserClubBalanceTopUpEvent:
    """Event emitted when a user tops up club balance"""
    def __init__(self, eventId: str, eventType: str, version: str, timestamp: str, source: str, metadata: EventMetadata, data: UserClubBalanceTopUpPayload):
        # Unique identifier for this event
        self.eventId = eventId
        # Type of event
        self.eventType = eventType
        # Schema version for this event
        self.version = version
        # ISO 8601 timestamp when the event occurred
        self.timestamp = timestamp
        # Service that generated this event
        self.source = source
        # Event metadata for tracing and correlation
        self.metadata = metadata
        # User club balance top-up details
        self.data = data


# Export all classes
__all__ = [
        "EventMetadata",
    "BaseEvent",
    "BalanceTopUpPayload",
    "BalanceTopUpEvent",
    "OptionSelectedPayload",
    "OptionSelectedEvent",
    "StepCompletedPayload",
    "StepCompletedEvent",
    "GrantBonusPayload",
    "GrantBonusEvent",
    "MarkCompletedPayload",
    "MarkCompletedEvent",
    "PromoCodeUsePayload",
    "PromoCodeUsedEvent",
    "UserPayload",
    "UserCreatedEvent",
    "UpdateUserPayload",
    "UserUpdatedEvent",
    "DeletedUserPayload",
    "UserDeletedEvent",
    "UserBalanceUpdatedPayload",
    "UserBalanceUpdatedEvent",
    "UserClubBalanceTopUpPayload",
    "UserClubBalanceTopUpEvent",
]
