## Database

### 初始化

```python
from xll_kit.database.session_manager import init_session_manager

init_session_manager(database_uri)
```