from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from xll_kit.models import BaseModel


class AuditObjectLog(BaseModel):
    """审计日志"""
    __tablename__ = "audit_object_log"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )
    action: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_type: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_id: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_version: Mapped[int] = mapped_column(
        Integer,
        nullable=True
    )
    data: Mapped[Optional[dict]] = mapped_column(
        JSON,
        default=dict,
        nullable=True,
        comment="变更内容"
    )
    operator: Mapped[str] = mapped_column(
        String(64),
        nullable=True
    )


class AuditFieldLog(BaseModel):
    """审计日志"""
    __tablename__ = "audit_field_log"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True
    )
    action: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_type: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_id: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    obj_version: Mapped[int] = mapped_column(
        Integer,
        nullable=True
    )
    field: Mapped[str] = mapped_column(
        String(64),
        nullable=False
    )
    old_value: Mapped[str] = mapped_column(
        String(1024),
        nullable=True
    )
    new_value: Mapped[str] = mapped_column(
        String(1024),
        nullable=True
    )
    operator: Mapped[str] = mapped_column(
        String(64),
        nullable=True
    )
