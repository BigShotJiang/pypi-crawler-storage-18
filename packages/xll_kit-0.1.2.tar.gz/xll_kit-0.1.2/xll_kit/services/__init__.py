from sqlalchemy.orm import Session

from .base import BaseService
from .pagination import PaginationResult

__all__ = [
    'BaseService',
    'PaginationResult'
]


def application_service(fn):
    def wrapper(self, session, *args, **kwargs):
        if session.in_transaction():
            return fn(self, session, *args, **kwargs)
        with session.begin():
            return fn(self, session, *args, **kwargs)

    return wrapper

# -------------------------
# 事务装饰器
# -------------------------
def transactional(func):
    """自动 commit/rollback 的事务装饰器"""
    def wrapper(self, session: Session, *args, **kwargs):
        try:
            result = func(self, session, *args, **kwargs)
            session.commit()
            return result
        except Exception:
            session.rollback()
            raise
    return wrapper