# Learnify
[![PyPI version](https://badge.fury.io/py/learnify.svg)](https://badge.fury.io/py/learnify)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/learnify)](https://pepy.tech/project/learnify)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


Learnify is a Python package that helps software developers improve their learning strategies by analyzing self‑reported learning habits, goals, and challenges. Provide a description of your current learning routine (time management, resources, difficulties, etc.) and receive structured, actionable feedback with personalized recommendations.

## Features

- Parses free‑form text about learning habits.
- Returns a clear, consistent, markdown‑formatted response with:
  - Effective learning techniques
  - Common pitfalls to avoid
  - Tips for optimizing study routines
- Works out‑of‑the‑box with the default **ChatLLM7** model.
- Fully compatible with any LangChain‑compatible LLM (OpenAI, Anthropic, Google, …).

## Installation

```bash
pip install learnify
```

## Quick Start

```python
from learnify import learnify

user_input = """
I usually study Python for about 1 hour each evening, but I often get distracted by
notifications. I read documentation and watch YouTube tutorials, but I never write
code projects. I feel stuck when trying to learn advanced topics like concurrency.
"""

# Use the default ChatLLM7 model (API key taken from env var LLM7_API_KEY)
response = learnify(user_input)

print(response)   # -> List of strings with the structured feedback
```

## Advanced Usage – Plug in Your Own LLM

You can supply any LangChain LLM instance instead of the default ChatLLM7.

### OpenAI

```python
from langchain_openai import ChatOpenAI
from learnify import learnify

llm = ChatOpenAI(model="gpt-4o")   # configure as you like
response = learnify(user_input, llm=llm)
```

### Anthropic

```python
from langchain_anthropic import ChatAnthropic
from learnify import learnify

llm = ChatAnthropic(model_name="claude-3-5-sonnet")
response = learnify(user_input, llm=llm)
```

### Google Gemini

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from learnify import learnify

llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro")
response = learnify(user_input, llm=llm)
```

## Parameters

| Parameter   | Type                               | Description |
|-------------|------------------------------------|-------------|
| `user_input`| `str`                              | The free‑form text describing the developer's learning habits, goals, and challenges. |
| `llm`       | `Optional[BaseChatModel]`          | A LangChain LLM instance to use. If omitted, `ChatLLM7` is created automatically. |
| `api_key`   | `Optional[str]`                    | API key for LLM7. If not provided, the function tries to read `LLM7_API_KEY` from the environment. |

## LLM7 Default Model

- **Package:** `langchain_llm7` – [`https://pypi.org/project/langchain-llm7/`](https://pypi.org/project/langchain-llm7/)
- Free‑tier rate limits are sufficient for typical usage.
- To obtain a free API key, register at: <https://token.llm7.io/>

You can also pass a custom key:

```python
response = learnify(user_input, api_key="YOUR_LLM7_API_KEY")
```

## License

This project is licensed under the MIT License.

## Author

- **Eugene Evstafev** – <hi@eugene.plus>

## Repository & Support

- **GitHub:** <https://github.com/chigwell/learnify>
- **Issues:** <https://github.com/chigwell/learnify/issues>

Feel free to open an issue for bugs, feature requests, or questions. Happy learning!