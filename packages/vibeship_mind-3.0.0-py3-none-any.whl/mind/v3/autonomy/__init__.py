"""Mind v3 progressive autonomy system.

Autonomy levels (1-5):
1. RECORD ONLY: Observe and capture
2. SUGGEST: Propose based on precedent
3. ASK PERMISSION: Propose with confidence
4. ACT + NOTIFY: Act automatically, inform user
5. SILENT: Handle automatically, log only

Mind earns trust through demonstrated good judgment.
"""
from .confidence import (
    ConfidenceTracker,
    ConfidenceConfig,
    ConfidenceScore,
    ActionOutcome,
    OutcomeType,
)
from .levels import (
    AutonomyLevel,
    AutonomyManager,
    AutonomyConfig,
    ActionPolicy,
)
from .feedback import (
    FeedbackLoop,
    FeedbackConfig,
    UserFeedback,
    FeedbackType,
    FeedbackEffect,
)
from .dashboard import (
    ObservabilityDashboard,
    DashboardConfig,
    SystemHealth,
    MetricSnapshot,
    TrendDirection,
)
from .tracker import AutonomyTracker

__all__ = [
    "ConfidenceTracker",
    "ConfidenceConfig",
    "ConfidenceScore",
    "ActionOutcome",
    "OutcomeType",
    "AutonomyLevel",
    "AutonomyManager",
    "AutonomyConfig",
    "ActionPolicy",
    "FeedbackLoop",
    "FeedbackConfig",
    "UserFeedback",
    "FeedbackType",
    "FeedbackEffect",
    "ObservabilityDashboard",
    "DashboardConfig",
    "SystemHealth",
    "MetricSnapshot",
    "TrendDirection",
    "AutonomyTracker",
]
