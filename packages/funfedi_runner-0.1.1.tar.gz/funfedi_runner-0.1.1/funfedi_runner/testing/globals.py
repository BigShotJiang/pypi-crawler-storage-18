from funfedi_runner.tools import get_app_name

app_name: str = get_app_name()
