import pytest

from funfedi_connect import application_for_name
from funfedi_runner.runner import Runner

from .globals import app_name


@pytest.fixture
def runner() -> Runner:
    application = application_for_name(app_name)

    return Runner(application)


@pytest.fixture
async def parsing_and_run(runner):
    async with runner.runner() as (parsing, run):
        yield parsing, run
