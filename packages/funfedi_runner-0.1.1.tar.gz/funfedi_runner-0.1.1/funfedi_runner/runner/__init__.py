from contextlib import asynccontextmanager
from dataclasses import dataclass
import aiohttp

from funfedi_connect.types import ApplicationConfiguration
from funfedi_parsing_test_cases.cases.activity import ActivityTestCase
from funfedi_parsing_test_cases.types import Environment
from funfedi_parsing_test_cases.activity import ActivityTestCaseMaker

from fediverse_pasture.one_actor import bovine_actor_and_actor_object


@dataclass
class Runner:
    application: ApplicationConfiguration
    domain: str = "http://pasture-one-actor"

    environment: Environment | None = None

    @asynccontextmanager
    async def _actor_id_and_session(self):
        bovine_actor, actor_object = bovine_actor_and_actor_object(
            "http://pasture-one-actor"
        )

        if actor_object.id is None:
            raise Exception("Failed to create actor with id")

        async with aiohttp.ClientSession() as session:
            await bovine_actor.init(session)

            yield bovine_actor, actor_object.id, session

    @asynccontextmanager
    async def runner(self):
        async with self._actor_id_and_session() as (bovine_actor, actor_id, session):
            parsing = await self.application.build_object_parsing(session)

            actor = await bovine_actor.get(actor_id)

            if not isinstance(actor, dict):
                raise Exception("Failed to load actor")

            environment = Environment(actor, parsing.actor_id)
            remote_actor = await bovine_actor.get(environment.receiving_actor)
            if not isinstance(remote_actor, dict):
                raise ValueError("Failed to fetch remote actor")
            inbox = remote_actor.get("inbox")
            if not isinstance(inbox, str):
                raise ValueError("Failed to resolve inbox")

            async def run(maker: ActivityTestCaseMaker) -> ActivityTestCase:
                test_case = maker.to_send(environment)
                await bovine_actor.post(inbox, test_case.activity)
                return test_case

            yield parsing, run
