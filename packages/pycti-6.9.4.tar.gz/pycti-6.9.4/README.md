# OpenCTI client for Python

[![Website](https://img.shields.io/badge/website-opencti.io-blue.svg)](https://opencti.io)
[![readthedocs](https://readthedocs.org/projects/opencti-client-for-python/badge/?style=flat)](https://opencti-client-for-python.readthedocs.io/en/latest/)
[![Number of PyPI downloads](https://img.shields.io/pypi/dm/pycti.svg)](https://pypi.python.org/pypi/pycti/)
[![Slack Status](https://img.shields.io/badge/slack-3K%2B%20members-4A154B)](https://community.filigran.io)

The official OpenCTI Python client helps developers to use the OpenCTI API by providing easy to use methods and utils.
This client is also used by some OpenCTI components.

## Install

To install the latest Python client library, please use `pip`:

```bash
$ pip3 install pycti
```

## Local development

```bash
# Fork the current repository, then clone your fork
$ git clone https://github.com/YOUR-USERNAME/opencti.git
$ cd client-python
$ git remote add upstream https://github.com/OpenCTI-Platform/opencti.git
# Create a branch for your feature/fix
$ git checkout -b [branch-name]
# Create a virtualenv
$ cd client-python
$ python3 -m venv .venv
$ source .venv/bin/activate
# Install the client-python and dependencies for the development and the documentation
$ python3 -m pip install -e .[dev,doc]
# Set up the git hook scripts
$ pre-commit install
# Create your feature/fix
# Create tests for your changes
$ pytest
# Push you feature/fix on Github
$ git add [file(s)]
$ git commit -m "[descriptive message]"
$ git push origin [branch-name]
# Open a pull request
```

### Install the package locally

```bash
$ pip install -e .
```

## Documentation

### Client usage

To learn about how to use the OpenCTI Python client and read some examples and cases, refer to [the client documentation](https://opencti-client-for-python.readthedocs.io/en/latest/client_usage/getting_started.html).

### API reference

To learn about the methods available for executing queries and retrieving their answers, refer to [the client API Reference](https://opencti-client-for-python.readthedocs.io/en/latest/pycti/pycti.html).

## Tests

### Install dependencies

```bash
$ pip install -r ./test-requirements.txt
```

[pytest](https://docs.pytest.org/en/7.2.x/) is used to launch the tests.

### Launch tests

#### Prerequisite

Your OpenCTI API should be running.
Your conftest.py should be configured with your API url, your token, and if applicable, your mTLS cert/key.

#### Launching

Unit tests
```bash
$ pytest ./tests/01-unit/
```

Integration testing
```bash
$ pytest ./tests/02-integration/
```

Example testing:

> OpenCTI must be running

```bash
cd examples
# Configure with you local instance of OpenCTI
export OPENCTI_API_URL="http://localhost:4000"
export OPENCTI_API_TOKEN="xxxxxxxxxxxxxxxxxxxxxx"

#Run one example file
python get_indicators_of_malware.py
```

## About

OpenCTI is a product designed and developed by the company [Filigran](https://filigran.io).

<a href="https://filigran.io" alt="Filigran"><img src="https://github.com/OpenCTI-Platform/opencti/raw/master/.github/img/logo_filigran.png" width="300" /></a>