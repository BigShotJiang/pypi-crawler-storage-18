

.. _sphx_glr_auto_examples_api:

.. _api_usage:

Examples showing API imbalanced-learn usage
-------------------------------------------

Examples that show some details regarding the API of imbalanced-learn.



.. raw:: html

    <div class="sphx-glr-thumbnails">

.. thumbnail-parent-div-open

.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows the different usage of the parameter sampling_strategy for the different family of samplers (i.e. over-sampling, under-sampling. or cleaning methods).">

.. only:: html

  .. image:: /auto_examples/api/images/thumb/sphx_glr_plot_sampling_strategy_usage_thumb.png
    :alt:

  :doc:`/auto_examples/api/plot_sampling_strategy_usage`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">How to use sampling_strategy in imbalanced-learn</div>
    </div>


.. thumbnail-parent-div-close

.. raw:: html

    </div>


.. toctree::
   :hidden:

   /auto_examples/api/plot_sampling_strategy_usage

