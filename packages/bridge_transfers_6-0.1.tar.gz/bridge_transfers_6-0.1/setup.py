
from setuptools import setup
setup(
    name="bridge_transfers_6",
    version="0.1",
    py_modules=["carrier"],
)
