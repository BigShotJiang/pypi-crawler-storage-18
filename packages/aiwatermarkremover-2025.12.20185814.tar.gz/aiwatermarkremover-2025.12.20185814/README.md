# aiwatermarkremover

## Overview

**Detect and remove AI-generated watermarks** from text with this specialized tool. Perfect for developers, researchers, or anyone who needs to reprocess AI outputs for human consumption, further analysis, or compliance without losing context.

## Installation

```bash
pip install aiwatermarkremover
```

## Usage

```python
from aiwatermarkremover import aiwatermarkremover

response = aiwatermarkremover(user_input)
```

### Parameters

* `user_input`: str - The user input text to process
* `llm`: Optional[BaseChatModel] - The langchain LLM instance to use (default: `ChatLLM7` from `langchain_llm7`)
* `api_key`: Optional[str] - The API key for LLM7 (default: uses a free tier API key or the `LLM7_API_KEY` environment variable, or `None` for a local LLM instance)

### Using a custom LLM

You can safely pass your own LLM instance (based on [langchain](https://docs.langchain.com/)) via the `llm` parameter:

```python
from langchain_openai import ChatOpenAI
from aiwatermarkremover import aiwatermarkremover

llm = ChatOpenAI()
response = aiwatermarkremover(user_input, llm=llm)
```

or for example to use the Anthropic:

```python
from langchain_anthropic import ChatAnthropic
from aiwatermarkremover import aiwatermarkremover

llm = ChatAnthropic()
response = aiwatermarkremover(user_input, llm=llm)
```

or Google Generative AI:

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from aiwatermarkremover import aiwatermarkremover

llm = ChatGoogleGenerativeAI()
response = aiwatermarkremover(user_input, llm=llm)
```

## LLM7 API Key

The default rate limits for LLM7 free tier are sufficient for most use cases. If you need higher rate limits, you can pass your own API key via the `api_key` parameter or environment variable `LLM7_API_KEY`.

## Credits

Author: Eugene Evstafev (github: @chigwell)
Email: hi@euegne.plus
GitHub: https://github.com/chigwell

## LICENSE

Licensed under the MIT License (https://opensource.org/licenses/MIT)

## Links

Project: [https://github.com/chigwell/aiwatermarkremover](https://github.com/chigwell/aiwatermarkremover)
LLM7 API Key: https://token.llm7.io/

[![PyPI version](https://badge.fury.io/py/aiwatermarkremover.svg)](https://badge.fury.io/py/aiwatermarkremover)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/api/charts/aiwatermarkremover/month/short)](https://pepy.tech/project/aiwatermarkremover)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Open%20Source-%2300ff00.svg)](https://www.linkedin.com/in/eugene-evstafev-1595a3ba)