from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    status: int  # 本参数表示告警规则状态。取值范围：<br>0：启用。<br>1：停用。<br>根据以上范围取值。
    alarmRuleIDList: List[str]  # 告警规则ID列表

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorChangeAlarmRulesStatusReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusReturnObj:
    success: Optional[bool] = None  # 是否成功
