from ctyun_python_sdk_core import CtyunClient, Credential, ClientConfig, CtyunRequestException

from .models import *


class MonitorClient:
    def __init__(self, client_config: ClientConfig):
        self.endpoint = client_config.endpoint
        self.credential = Credential(client_config.access_key_id, client_config.access_key_secret)
        self.ctyun_client = CtyunClient(client_config.verify_tls)

    def v4_monitor_intelligent_inspection_modify_inspection_item(self, request: V4MonitorIntelligentInspectionModifyInspectionItemRequest) -> V4MonitorIntelligentInspectionModifyInspectionItemResponse:
        """调用此接口可修改巡检项。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/modify-inspection-item"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionModifyInspectionItemResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_history_detail(self, request: V4MonitorIntelligentInspectionQueryHistoryDetailRequest) -> V4MonitorIntelligentInspectionQueryHistoryDetailResponse:
        """调用此接口可查询巡检历史详情。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-history-detail"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryHistoryDetailResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_history_list(self, request: V4MonitorIntelligentInspectionQueryHistoryListRequest) -> V4MonitorIntelligentInspectionQueryHistoryListResponse:
        """调用此接口可查询巡检历史列表。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-history-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryHistoryListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_task_detail(self, request: V4MonitorIntelligentInspectionQueryTaskDetailRequest) -> V4MonitorIntelligentInspectionQueryTaskDetailResponse:
        """调用此接口可查询巡检结果详情。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-task-detail"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryTaskDetailResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_task_overview(self, request: V4MonitorIntelligentInspectionQueryTaskOverviewRequest) -> V4MonitorIntelligentInspectionQueryTaskOverviewResponse:
        """调用此接口可查询巡检结果总览。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-task-overview"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryTaskOverviewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_task_anomaly(self, request: V4MonitorIntelligentInspectionQueryTaskAnomalyRequest) -> V4MonitorIntelligentInspectionQueryTaskAnomalyResponse:
        """调用此接口可查询巡检结果异常。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-task-anomaly"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryTaskAnomalyResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_create_task(self, request: V4MonitorIntelligentInspectionCreateTaskRequest) -> V4MonitorIntelligentInspectionCreateTaskResponse:
        """调用此接口可创建巡检任务。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/create-task"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionCreateTaskResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_onekey_solve(self, request: V4MonitorIntelligentInspectionOnekeySolveRequest) -> V4MonitorIntelligentInspectionOnekeySolveResponse:
        """调用此接口可一键处理巡检任务异常事件。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/onekey-solve"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionOnekeySolveResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_change_alarm_rules_status(self, request: V41MonitorChangeAlarmRulesStatusRequest) -> V41MonitorChangeAlarmRulesStatusResponse:
        """批量更新告警规则状态为禁用或启用。"""
        url = f"{self.endpoint}/v4.1/monitor/change-alarm-rules-status"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorChangeAlarmRulesStatusResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_delete_alarm_rules(self, request: V41MonitorDeleteAlarmRulesRequest) -> V41MonitorDeleteAlarmRulesResponse:
        """调用此接口可批量删除多个告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/delete-alarm-rules"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorDeleteAlarmRulesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_create_alarm_rule(self, request: V41MonitorCreateAlarmRuleRequest) -> V41MonitorCreateAlarmRuleResponse:
        """创建一个或多个告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/create-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorCreateAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_update_alarm_rule(self, request: V41MonitorUpdateAlarmRuleRequest) -> V41MonitorUpdateAlarmRuleResponse:
        """更新指定告警规则， 支持全量字段修改。"""
        url = f"{self.endpoint}/v4.1/monitor/update-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorUpdateAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_describe_alarm_rule(self, request: V41MonitorDescribeAlarmRuleRequest) -> V41MonitorDescribeAlarmRuleResponse:
        """查看告警规则的详情信息。"""
        url = f"{self.endpoint}/v4.1/monitor/describe-alarm-rule"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorDescribeAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_alarm_rules(self, request: V41MonitorQueryAlarmRulesRequest) -> V41MonitorQueryAlarmRulesResponse:
        """根据筛选项查询告警规则列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-alarm-rules"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryAlarmRulesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_canvas_query_resource_child(self, request: V4MonitorCanvasQueryResourceChildRequest) -> V4MonitorCanvasQueryResourceChildResponse:
        """查询资源子设备信息。"""
        url = f"{self.endpoint}/v4/monitor/canvas/query-resource-child"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCanvasQueryResourceChildResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_canvas_query_history_data(self, request: V4MonitorCanvasQueryHistoryDataRequest) -> V4MonitorCanvasQueryHistoryDataResponse:
        """查询指定时间段内的画布数据"""
        url = f"{self.endpoint}/v4/monitor/canvas/query-history-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCanvasQueryHistoryDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_canvas_query_view_data(self, request: V4MonitorCanvasQueryViewDataRequest) -> V4MonitorCanvasQueryViewDataResponse:
        """查询指定时间段内的画布数据"""
        url = f"{self.endpoint}/v4/monitor/canvas/query-view-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCanvasQueryViewDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_canvas_query_resource_list(self, request: V4MonitorCanvasQueryResourceListRequest) -> V4MonitorCanvasQueryResourceListResponse:
        """根据筛选条件查询资源池下指定产品的列表。"""
        url = f"{self.endpoint}/v4/monitor/canvas/query-resource-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCanvasQueryResourceListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_canvas_query_region_deploy(self, request: V4MonitorCanvasQueryRegionDeployRequest) -> V4MonitorCanvasQueryRegionDeployResponse:
        """查询资源池画布"""
        url = f"{self.endpoint}/v4/monitor/canvas/query-region-deploy"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCanvasQueryRegionDeployResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def lcm_test003(self, request: LcmTest003Request) -> LcmTest003Response:
        """
        该接口提供用户多台云主机信息查询功能，用户可以根据此接口的返回值得到多台云主机信息。该接口相较于/v4/ecs/list-instances提供更精简的云主机信息，拥有更高的查找效率
        准备工作：
          构造请求：在调用前需要了解如何构造请求，详情查看：[构造请求](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81)
          认证鉴权：openapi请求需要进行加密调用，详细查看：[认证鉴权](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=25&api=%u6784%u9020%u8BF7%u6C42&data=87&vid=81)
        注意事项：
          分页查询：当前查询结果以分页形式进行展示，单次查询最多显示50条数据
          匹配查找：可以通过部分字段进行匹配筛选数据，无符合条件的为空，在指定多台云主机ID的情况下，只返回匹配到的云主机信息。推荐每次使用单个条件查找
        """
        url = f"{self.endpoint}/v5/lcmTest003"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, LcmTest003Response)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_custom_events(self, request: V4MonitorQueryCustomEventsRequest) -> V4MonitorQueryCustomEventsResponse:
        """调用此接口可查询自定义事件。（已废弃）"""
        url = f"{self.endpoint}/v4/monitor/query-custom-events"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryCustomEventsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_overview_active_alarm(self, request: V4MonitorOverviewActiveAlarmRequest) -> V4MonitorOverviewActiveAlarmResponse:
        """调用此接口可查询当前用户活跃告警数量。"""
        url = f"{self.endpoint}/v4/monitor/overview/active-alarm"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorOverviewActiveAlarmResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alert_history(self, request: V4MonitorQueryAlertHistoryRequest) -> V4MonitorQueryAlertHistoryResponse:
        """查询告警历史, 返回结果按告警历史的触发时间(createTime)降序排列。"""
        url = f"{self.endpoint}/v4/monitor/query-alert-history"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlertHistoryResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_message_records(self, request: V4MonitorQueryMessageRecordsRequest) -> V4MonitorQueryMessageRecordsResponse:
        """查询通知记录列表。"""
        url = f"{self.endpoint}/v4/monitor/query-message-records"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryMessageRecordsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_quota(self, request: V4MonitorQuotaRequest) -> V4MonitorQuotaResponse:
        """调用此接口可查询用户资源池指定配额量。"""
        url = f"{self.endpoint}/v4/monitor/quota"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQuotaResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_unit_query_units(self, request: V4MonitorUnitQueryUnitsRequest) -> V4MonitorUnitQueryUnitsResponse:
        """调用此接口可获取单位组和单位信息。"""
        url = f"{self.endpoint}/v4/monitor/unit/query-units"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUnitQueryUnitsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_public_network_probing_query_table_data(self, request: V4MonitorPublicNetworkProbingQueryTableDataRequest) -> V4MonitorPublicNetworkProbingQueryTableDataResponse:
        """查询指定时间段内的表格数据。"""
        url = f"{self.endpoint}/v4/monitor/public-network-probing/query-table-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorPublicNetworkProbingQueryTableDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_public_network_probing_query_map_data(self, request: V4MonitorPublicNetworkProbingQueryMapDataRequest) -> V4MonitorPublicNetworkProbingQueryMapDataResponse:
        """查询指定时间段内的地图数据。"""
        url = f"{self.endpoint}/v4/monitor/public-network-probing/query-map-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorPublicNetworkProbingQueryMapDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_export_view_data(self, request: V4MonitorMonitorBoardExportViewDataRequest) -> V4MonitorMonitorBoardExportViewDataResponse:
        """导出看板下某个视图的数据。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/export-view-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardExportViewDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_delete_sys_resources(self, request: V4MonitorMonitorBoardDeleteSysResourcesRequest) -> V4MonitorMonitorBoardDeleteSysResourcesResponse:
        """为系统看板删除监控资源实例。仅支持系统看板。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/delete-sys-resources"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDeleteSysResourcesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_contact_groups(self, request: V41MonitorQueryContactGroupsRequest) -> V41MonitorQueryContactGroupsResponse:
        """调用此接口可查询告警联系人组的列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-contact-groups"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryContactGroupsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_contact_group(self, request: V4MonitorDescribeContactGroupRequest) -> V4MonitorDescribeContactGroupResponse:
        """调用此接口可查询告警联系人组的配置详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-contact-group"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_contact_group(self, request: V4MonitorUpdateContactGroupRequest) -> V4MonitorUpdateContactGroupResponse:
        """调用此接口可修改告警联系组基本信息， 支持全量字段修改。"""
        url = f"{self.endpoint}/v4/monitor/update-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contact_groups(self, request: V4MonitorDeleteContactGroupsRequest) -> V4MonitorDeleteContactGroupsResponse:
        """调用此接口可批量删除多个删除告警联系人组。"""
        url = f"{self.endpoint}/v4/monitor/delete-contact-groups"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactGroupsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_group_contacts(self, request: V4MonitorUpdateGroupContactsRequest) -> V4MonitorUpdateGroupContactsResponse:
        """调用此接口可变更告警联系组内的告警联系人列表。"""
        url = f"{self.endpoint}/v4/monitor/update-group-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateGroupContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contact_group(self, request: V4MonitorDeleteContactGroupRequest) -> V4MonitorDeleteContactGroupResponse:
        """调用此接口可删除告警联系人组。"""
        url = f"{self.endpoint}/v4/monitor/delete-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_contact_group(self, request: V4MonitorCreateContactGroupRequest) -> V4MonitorCreateContactGroupResponse:
        """调用此接口可创建告警联系组。"""
        url = f"{self.endpoint}/v4/monitor/create-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_activate_contact(self, request: V4MonitorActivateContactRequest) -> V4MonitorActivateContactResponse:
        """调用此接口可激活告警联系人的手机短息或邮箱，激活后的媒介可接收平台告警信息。"""
        url = f"{self.endpoint}/v4/monitor/activate-contact"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorActivateContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_contacts(self, request: V41MonitorQueryContactsRequest) -> V41MonitorQueryContactsResponse:
        """调用此接口可查询告警联系人的列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_contact(self, request: V4MonitorDescribeContactRequest) -> V4MonitorDescribeContactResponse:
        """调用此接口可查看告警联系人的配置详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-contact"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contacts(self, request: V4MonitorDeleteContactsRequest) -> V4MonitorDeleteContactsResponse:
        """调用此接口可批量删除多个创建告警联系人。"""
        url = f"{self.endpoint}/v4/monitor/delete-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_contact_activation_code(self, request: V4MonitorContactActivationCodeRequest) -> V4MonitorContactActivationCodeResponse:
        """调用此接口可对告警联系人发送手机短息激活验证码或邮箱激活验证码。"""
        url = f"{self.endpoint}/v4/monitor/contact-activation-code"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorContactActivationCodeResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contact(self, request: V4MonitorDeleteContactRequest) -> V4MonitorDeleteContactResponse:
        """调用此接口可删除告警联系人。"""
        url = f"{self.endpoint}/v4/monitor/delete-contact"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_contact(self, request: V4MonitorCreateContactRequest) -> V4MonitorCreateContactResponse:
        """调用此接口可创建告警联系人，用于告警通知。"""
        url = f"{self.endpoint}/v4/monitor/create-contact"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_contacts(self, request: V4MonitorUpdateContactsRequest) -> V4MonitorUpdateContactsResponse:
        """调用此接口可修改告警联系人配置，支持全量字段修改。"""
        url = f"{self.endpoint}/v4/monitor/update-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_describe_view(self, request: V4MonitorMonitorBoardDescribeViewRequest) -> V4MonitorMonitorBoardDescribeViewResponse:
        """查看监控看板详细信息，包括视图信息，不包含监控数据信息。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/describe-view"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDescribeViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_describe(self, request: V4MonitorMonitorBoardDescribeRequest) -> V4MonitorMonitorBoardDescribeResponse:
        """查看监控看板详细信息，包括视图信息，不包含监控数据信息。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/describe"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDescribeResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_update_view(self, request: V4MonitorMonitorBoardUpdateViewRequest) -> V4MonitorMonitorBoardUpdateViewResponse:
        """更新已有监控视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/update-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardUpdateViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_create_view(self, request: V4MonitorMonitorBoardCreateViewRequest) -> V4MonitorMonitorBoardCreateViewResponse:
        """为已存在的监控看板创建视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/create-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardCreateViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_create(self, request: V4MonitorMonitorBoardCreateRequest) -> V4MonitorMonitorBoardCreateResponse:
        """创建监控看板，可以创建空看板，也可以附带视图创建。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/create"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardCreateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def newapi(self, request: NewapiRequest) -> NewapiResponse:
        """烦烦烦"""
        url = f"{self.endpoint}/v4/testapi/create"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, NewapiResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_message_records_apiname(self, request: V4MonitorQueryMessageRecordsAPInameRequest) -> V4MonitorQueryMessageRecordsAPInameResponse:
        """查询通知记录列表。"""
        url = f"{self.endpoint}/v4/monitor/query-message-records"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryMessageRecordsAPInameResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))



