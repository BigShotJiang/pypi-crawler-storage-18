📄 pdfsmartocr

pdfsmartocr é uma biblioteca Python para OCR híbrido e performático de PDFs grandes, especialmente pensada para processos judiciais, inquéritos, laudos e documentos extensos.

Ela combina:

🔍 Tesseract OCR (para páginas escaneadas)

📄 PdfReader (PyPDF2) para texto nativo

⚡ Paralelismo automático (multiprocessing)

🎯 Seleção precisa de páginas para OCR

✨ Principais recursos

OCR paralelo com Tesseract

Leitura nativa com PdfReader

Processamento eficiente de PDFs grandes

Seleção de páginas por:

número (5)

lista ([1, 3, 10])

intervalos ("1-5, 9, 12-14")

Numeração de páginas 1-based (padrão) ou 0-based

Ideal para documentos jurídicos

📦 Instalação
pip install pdfsmartocr

Dependências de sistema (obrigatórias)

O pdfsmartocr depende de ferramentas externas:

🔹 Tesseract OCR

Windows: https://github.com/UB-Mannheim/tesseract/wiki

Linux: sudo apt install tesseract-ocr

macOS: brew install tesseract

Após instalar, configure o caminho no seu código:

import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

🔹 Poppler (necessário para pdf2image)

Windows: https://github.com/oschwartz10612/poppler-windows

Linux: sudo apt install poppler-utils

macOS: brew install poppler

🚀 Uso básico (modo híbrido automático)

Executa OCR nas primeiras páginas e leitura nativa nas demais:

from pdfsmartocr import ocr_pdf

texto, tempo = ocr_pdf(
    "arquivo.pdf",
    max_ocr_pages=70
)

print(f"Tempo: {tempo:.2f}s")

🎯 OCR apenas em páginas específicas

Ideal quando você já sabe quais páginas são escaneadas.

from pdfsmartocr import ocr_pdf_paginas

texto, tempo = ocr_pdf_paginas(
    "arquivo.pdf",
    paginas_ocr="1-5, 9, 12-14"
)

Exemplos válidos de paginas_ocr
paginas_ocr=5                # uma página
paginas_ocr=[1, 3, 10]       # lista
paginas_ocr="1-5, 9, 12-14"  # intervalos


Por padrão, as páginas são 1-based (a primeira página é 1).

📄 OCR + leitura do restante via PdfReader
texto, tempo = ocr_pdf_paginas(
    "processo.pdf",
    paginas_ocr="1-3",
    ler_restante_pdfreader=True
)

⚙️ Parâmetros principais
Parâmetro	Descrição
paginas_ocr	Página(s) a serem processadas com OCR
dpi	Resolução das imagens (padrão: 200)
lang	Idioma do OCR (ex: "por")
n_processos	Nº de processos paralelos
one_based	Numeração 1-based ou 0-based
ler_restante_pdfreader	Ler páginas restantes com PdfReader
🏛️ Casos de uso típicos

Processos judiciais digitalizados

Inquéritos policiais

Laudos periciais

PDFs híbridos (parte texto, parte imagem)

Extração de texto para NLP, RAG e IA jurídica

⚠️ Observações importantes

O caminho do Tesseract deve ser configurado pelo usuário

PDFs 100% digitais não precisam de OCR

OCR é computacionalmente caro → selecione páginas sempre que possível

📜 Licença

MIT License