# Tests for py-observatory
