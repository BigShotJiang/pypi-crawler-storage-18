# RibbitXDB Release Notes

## Version 1.0.4 (December 2025) - Major Performance & Feature Update

### 🚀 Major Features

#### Enhanced SQL Query Capabilities
- **JOIN Operations**: Full support for INNER, LEFT, and RIGHT joins
- **Aggregate Functions**: COUNT, SUM, AVG, MIN, MAX with GROUP BY and HAVING
- **Advanced Filtering**: LIKE pattern matching, IN lists, BETWEEN ranges
- **Compound Conditions**: AND/OR logical operators in WHERE clauses
- **Result Control**: ORDER BY (multi-column), LIMIT, OFFSET, DISTINCT
- **Query Optimization**: Cost-based optimizer with automatic JOIN ordering

#### Performance Improvements
- **2x+ Faster Indexing**: Optimized B-tree with order 256 (up from 128)
- **Binary Search**: O(log n) key lookups instead of linear search
- **LRU Caching**: Page cache and query result caching with TTL
- **Bulk Operations**: Optimized bulk insert for large datasets
- **Cache Hit Rate**: 70%+ cache hits on repeated queries

#### New SQL Syntax Examples
```sql
-- JOINs
SELECT users.name, orders.total 
FROM users 
INNER JOIN orders ON users.id = orders.user_id;

-- Aggregates with GROUP BY
SELECT category, COUNT(*), AVG(price) 
FROM products 
GROUP BY category 
HAVING COUNT(*) > 5;

-- Advanced Filtering
SELECT * FROM users 
WHERE name LIKE 'John%' 
AND age IN (25, 30, 35) 
AND salary BETWEEN 50000 AND 100000;

-- Pagination
SELECT * FROM products 
ORDER BY price DESC, name ASC 
LIMIT 20 OFFSET 40;
```

### 📊 Benchmark Results

Performance comparison vs SQLite (10,000 rows):
- **Inserts**: 25,000+ inserts/sec (competitive with SQLite)
- **Selects**: 100,000+ selects/sec (2x faster with caching)
- **Aggregates**: 50% faster than SQLite on complex queries
- **JOINs**: Comparable performance with optimization
- **Memory**: <50MB for 100K records

### 🔧 Technical Improvements

- **Query Parser**: Extended tokenizer with 50+ SQL keywords
- **Query Executor**: Rewritten with modular architecture
- **Index Manager**: LRU cache with performance statistics
- **Query Cache**: MD5-based caching with automatic invalidation
- **Optimizer**: Table statistics and cost estimation

### 📦 New Modules

- `ribbitxdb.query.optimizer` - Query optimization and caching
- `benchmarks/performance_benchmark.py` - Comprehensive test suite

### 🐛 Bug Fixes

- Fixed WHERE clause evaluation with NULL values
- Improved error handling in parser for malformed SQL
- Fixed memory leak in page allocation
- Corrected ORDER BY with mixed data types

### ⚠️ Breaking Changes

**None** - Fully backward compatible with v1.0.0

### 🔄 Migration Guide

No migration needed! Simply upgrade:
```bash
pip install --upgrade ribbitxdb
```

All existing databases and code will work without changes.

### 📝 Notes

- Query cache is enabled by default (100 queries, 5min TTL)
- B-tree order increased to 256 for better performance
- Recommended for production use with <1M records
- For larger datasets, consider partitioning strategies

---

## Version 1.0.0 (Initial Release)

### Core Features
- DB-API 2.0 compliant interface
- BLAKE2 cryptographic hashing for data integrity
- LZMA compression for storage efficiency
- B-tree indexing with O(log n) lookups
- Page-based storage engine (4KB pages)
- Transaction support with ACID guarantees
- Zero external dependencies

### Supported SQL
- CREATE TABLE, DROP TABLE
- INSERT, SELECT, UPDATE, DELETE
- WHERE clauses with basic operators (=, !=, <, >, <=, >=)
- PRIMARY KEY, NOT NULL, UNIQUE constraints
- INTEGER, TEXT, REAL, BLOB data types

### Performance
- 10,000+ inserts/sec
- 50,000+ selects/sec
- <10MB memory footprint
- 70%+ compression ratio

### Security
- BLAKE2b hashing for row integrity
- Tamper detection on data reads
- Secure by default

---

**Full Changelog**: https://github.com/ribbitx/ribbitxdb/compare/v1.0.0...v1.0.4
