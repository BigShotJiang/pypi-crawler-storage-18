<p align="center">
  <a href="https://trueconf.com" target="_blank" rel="noopener noreferrer">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/TrueConf/.github/refs/heads/main/logos/logo-cyrillic-dark.svg">
      <img width="150" alt="trueconf" src="https://raw.githubusercontent.com/TrueConf/.github/refs/heads/main/logos/logo-cyrillic.svg">
    </picture>
  </a>
</p>

<h1 align="center">python-trueconf-room</h1>

<p align="center">Это библиотека на Python для TrueConf Room API</p>

<p align="center">
    <a href="https://pypi.org/project/python-trueconf-room/">
        <img src="https://img.shields.io/pypi/v/python-trueconf-room">
    </a>
    <a href="https://pypi.org/project/python-trueconf-room/">
        <img src="https://img.shields.io/pypi/pyversions/python-trueconf-room">
    </a>
    <a href="https://t.me/trueconf_chat" target="_blank">
        <img src="https://img.shields.io/badge/Telegram-2CA5E0?logo=telegram&logoColor=white" />
    </a>
    <a href="https://discord.gg/2gJ4VUqATZ">
        <img src="https://img.shields.io/badge/Discord-%235865F2.svg?&logo=discord&logoColor=white" />
    </a>
    <a href="#">
        <img src="https://img.shields.io/github/stars/trueconf/python-trueconf-room?style=social" />
    </a>
</p>

<p align="center">
  <a href="./README.md">English</a> /
  <a href="./README-ru.md">Русский</a> /
  <a href="./README-de.md">Deutsch</a> /
  <a href="./README-es.md">Español</a>
</p>

**TrueConf Room** — программный терминал для переговорных комнат и конференц-залов любого размера.
Устанавливается на ПК на базе ОС Windows или Linux, и предоставляет удобный интерфейс управления с помощью веб-интерфейса или приложения для смартфонов и планшетов на базе Android.
Подробнее смотрите в [документации к TrueConf Room](https://trueconf.ru/docs/room/ru/introduction/).

> [!NOTE]
> Данная библиотека поддерживает **только API v1**. В будущем будет обновлена для поддержки **API v2**.

## 🚀 Как использовать `python-trueconf-room`

1. Загрузите и установите TrueConf Room по [прямой ссылке](https://raw.githubusercontent.com/TrueConf/python-trueconf-room/refs/heads/main/download_links.md).
2. Запустите TrueConf Room с параметром [`--pin`](https://trueconf.ru/docs/videosdk/ru/introduction/commandline#pin):

    **Windows:**

    ```sh
    "C:\Program Files\TrueConf\Room\TrueConfRoom.exe" --pin some_pin
    ```

    **Linux:**

    ```sh
    trueconf-room --pin some_pin
    ```

3. Теперь вы можете подключиться к TrueConf Room используя следующий пример:

    ```py
    import trueconf_room
    from trueconf_room.methods import Methods
    from trueconf_room.consts import EVENT, METHOD_RESPONSE
    import trueconf_room.consts as C

    room = trueconf_room.open_session(ip = "127.0.0.1", port = 80, pin = "some_pin")
    methods = Methods(room)

    @room.handler(EVENT[C.EV_appStateChanged])
    def on_state_change(response):
        print(f'    Application state is {response["appState"]}')
        # Need to login
        if (response["appState"] == 2):
            methods.login("john_doe@video.example.com", "my_very_strong_password")

    if __name__ == '__main__':
    # Try to connect to TrueConf Server
    methods.connectToServer("video.example.com")
    room.run()
    ```

## 🧩 Описание библиотеки

**python-trueconf-room** — это Python-библиотека для управления TrueConf Room через TrueConf Room API. Взаимодействие построено по схеме “команда → ответ”, а также через события, которые приходят автоматически при изменении состояния приложения. Обмен данными происходит по WebSocket в формате JSON, но пользователю не нужно вручную собирать и разбирать JSON-пакеты — библиотека делает это за вас.

### 📦 Импорт модулей

Для корректной работы обычно достаточно четырех импортов:

```python
import trueconf_room
from trueconf_room.methods import Methods
from trueconf_room.consts import EVENT, METHOD_RESPONSE
import trueconf_room.consts as C
```

`trueconf_room` — основной модуль. Через него создаётся сессия (`open_session`), регистрируются обработчики (`handler`) и запускается цикл обработки входящих сообщений (`run`).

`Methods` — класс, в котором команды TrueConf Room API представлены как методы Python. Это удобный слой, который позволяет вызывать команды “по имени”, без ручной подготовки запросов.

`EVENT` и `METHOD_RESPONSE` — типы входящих уведомлений, которые используются при регистрации обработчиков:
- `EVENT` — события (например, входящий вызов, смена состояния приложения и т.д.),
- `METHOD_RESPONSE` — ответы на команды, которые вы вызвали через methods.

`import trueconf_room.consts as C` — импорт всех констант под коротким именем `C`. Это упрощает код: вместо длинных ссылок на константы вы пишете `C.EV_...` и `C.M_...`, и сразу видно, что это именно имя события или команды из API.

### 🔌 Создание сессии и объектов

Работа начинается с создания объекта `room`. Это активная сессия, которая держит соединение с TrueConf Room и принимает все входящие сообщения:

```py
room = trueconf_room.open_session(ip="127.0.0.1", port=80, pin="some_pin")
```

Далее создаётся объект methods. Он использует уже созданную сессию room и через неё отправляет команды в TrueConf Room API:

```py
methods = Methods(room)
```

### 🪝 Обработчики (handlers)

TrueConf Room постоянно отправляет уведомления: это могут быть ответы на ваши команды или события, которые происходят сами по себе. Чтобы не “ловить” весь поток сообщений вручную, библиотека использует хендлеры (обработчики).

**Хендлер** — это обычная функция, которую библиотека вызывает автоматически, когда приходит нужное событие или ответ. Регистрируется хендлер через декоратор `@room.handler(...)`.

Ключевой принцип такой:

- для событий используется `EVENT[...]` и константы `C.EV_...`;
- для ответов на команды используется `METHOD_RESPONSE[...]` и константы `C.M_....`.

Пример: обработка смены состояния приложения и обработка  входящего вызова:

```py
@room.handler(EVENT[C.EV_appStateChanged])
@room.handler(METHOD_RESPONSE[C.M_getAppState])
def on_state_change(response):
    print(response["appState"])

@room.handler(EVENT[C.EV_inviteReceived])
def on_invite(response):
    print("Incoming call from:", response["peerId"])
    methods.accept()
```

> [!NOTE]
> Обратите внимание: функция-хендлер всегда принимает один параметр response — это уже распарсенный JSON в виде Python-словаря.

## ⚡️ Вызов команд

Команды вызываются через объект `methods`. Названия методов повторяют названия команд из оригинального TrueConf Room API, поэтому ориентироваться по документации просто: нашли команду в API — вызвали одноимённый метод в `Methods`.

Пример вызова команды:

```py
methods.getHardware()
```

Ответ на эту команду придёт отдельным уведомлением, и чтобы его обработать, нужно зарегистрировать хендлер на `METHOD_RESPONSE[C.M_getHardware]`.

### 🏃‍♂️ Запуск обработки сообщений

После того как вы зарегистрировали нужные хендлеры и (при необходимости) вызвали первые команды, нужно запустить цикл обработки:

```py
room.run()
```

`run()` держит сессию активной и позволяет библиотеке принимать ответы и события, пока соединение не будет закрыто.

## 📚 Документация

1. [Документация TrueConf Room API](https://trueconf.ru/docs/videosdk/ru/introduction/common)
2. [Примеры кода](examples/):
   1. [Общие примеры](examples/)
   2. [Кнопка вызова с использованием PyQT5](examples/CallButton/)
   3. [Голосовое управление TrueConf Room с помощью Vosk](https://github.com/TrueConf/pyVideoSDK-VoiceControl) 
