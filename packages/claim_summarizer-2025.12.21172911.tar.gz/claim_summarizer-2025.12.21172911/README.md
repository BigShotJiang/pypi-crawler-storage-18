# Claim Summarizer
[![PyPI version](https://badge.fury.io/py/claim-summarizer.svg)](https://badge.fury.io/py/claim-summarizer)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/claim-summarizer)](https://pepy.tech/project/claim-summarizer)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package that takes user-provided text (such as a blog post title or a short article snippet) and generates a structured summary highlighting key advantages or claims. It uses an LLM to analyze the text and extract a concise, formatted list of points, ensuring the output is consistent and well-structured through pattern matching.

## Installation

```bash
pip install claim_summarizer
```

## Usage

```python
from claim_summarizer import claim_summarizer

response = claim_summarizer(user_input="How GNU Guile is 10x better (2021)")
print(response)
```

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Using Different LLMs

By default, the package uses `ChatLLM7` from [langchain_llm7](https://pypi.org/project/langchain-llm7). However, you can safely pass your own LLM instance if you want to use another LLM.

### Example with OpenAI

```python
from langchain_openai import ChatOpenAI
from claim_summarizer import claim_summarizer

llm = ChatOpenAI()
response = claim_summarizer(user_input="How GNU Guile is 10x better (2021)", llm=llm)
print(response)
```

### Example with Anthropic

```python
from langchain_anthropic import ChatAnthropic
from claim_summarizer import claim_summarizer

llm = ChatAnthropic()
response = claim_summarizer(user_input="How GNU Guile is 10x better (2021)", llm=llm)
print(response)
```

### Example with Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from claim_summarizer import claim_summarizer

llm = ChatGoogleGenerativeAI()
response = claim_summarizer(user_input="How GNU Guile is 10x better (2021)", llm=llm)
print(response)
```

## API Key

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits for LLM7, you can pass your own API key via the environment variable `LLM7_API_KEY` or directly via the `api_key` parameter.

```python
from claim_summarizer import claim_summarizer

response = claim_summarizer(user_input="How GNU Guile is 10x better (2021)", api_key="your_api_key")
print(response)
```

You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/claim-summarizer/issues).

## Author

- **Eugene Evstafev**
- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)