from setuptools import setup, find_packages

setup(
    name='NetHyTech-STT-tools',
    version='0.1',
    author='Anurag Singh',
    author_email='anusin2255@gmail.com',
    description='this is speech to text package created by Anurag Singh',
)
packages = find_packages(),
install_requires= [
    'selenium',
    'webdriver-manager',
]
