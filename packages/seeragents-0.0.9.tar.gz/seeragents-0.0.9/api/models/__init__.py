"""Model information API endpoints."""

