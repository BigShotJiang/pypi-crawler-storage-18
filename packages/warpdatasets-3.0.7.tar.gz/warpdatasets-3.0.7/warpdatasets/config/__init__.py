"""Configuration module."""

from warpdatasets.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
