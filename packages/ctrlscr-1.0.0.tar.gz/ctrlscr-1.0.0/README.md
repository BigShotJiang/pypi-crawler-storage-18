# CTRL-SCR

<div align="center">
  <img src="docs/icon.png" alt="Logo" width="120" height="120">
  <h3 align="center">Control Everything with One Keyboard</h3>
  
  <p align="center">
    Seamlessly control multiple computers across your network with the mouse and keyboard you already own.
    <br />
    <a href="https://therandomuser03.github.io/ctrl-scr/"><strong>Visit Website »</strong></a>
    <br />
    <br />
    <a href="https://github.com/therandomuser03/ctrl-scr/issues">Report Bug</a>
    ·
    <a href="https://github.com/therandomuser03/ctrl-scr/releases">Download Latest</a>
  </p>
</div>

---

**CTRL-SCR** is a secure, cross-platform tool designed to declutter your desk. Move your mouse off the edge of your main screen, and it instantly jumps to your other computer. No hardware switches, no cloud, no lag.

## 🚀 Features

*   **Zero Latency Feel**: UDP mouse streaming ensures buttery smooth cursor movement.
*   **System-Wide Control**: Control the entire remote system (Admin, Taskbar, etc.).
*   **Screen Edge Switching**: Move your mouse off the edge to instantly switch control to the Client (like Barrier).
*   **Secure**: AES-256 encryption for all inputs. Your keystrokes never leave your LAN.
*   **Simple UI**: Modern Dark Theme with easy "Start" and "Connect" buttons.
*   **Cross-Platform**: Run on Windows, macOS, and Linux (Source).
*   **Portable**: Windows builds are standalone `.exe` files—no installation required.

## 📥 Download

### Windows
Download the **Single-File EXE** from the [Releases Page](https://github.com/therandomuser03/ctrl-scr/releases/latest). 
Just double-click `ctrl-scr.exe` to run.

### macOS & Linux
See [BUILD.md](BUILD.md) for instructions on how to run from source.
*(Native installers coming soon)*

## 🛠️ Usage

1.  **Host (Primary PC)**:
    *   Open App -> Click **Start Server**.
    *   Note the IP address displayed (e.g., `192.168.1.5`).

2.  **Client (Secondary PC)**:
    *   Open App -> Click **Connect Client**.
    *   Enter the IP address of the Host.

3.  **Control**:
    *   **Host Position**: Use the dropdown on the Host to select the Client's position (e.g., "Right").
    *   **Switching**: Move your mouse off that edge of your screen. Your cursor will lock comfortably, and you will control the Client.
    *   **Return**: Move the Client mouse back towards the Host to switch back.

## 🛑 Reset / Troubleshooting

If you get stuck or connections fail:
*   Click the red **Reset App** button in the top right.
*   This immediately kills all connections and resets the app to a fresh state.

## 📦 Building from Source

Requirements: Python 3.10+

```bash
# Clone
git clone https://github.com/therandomuser03/ctrl-scr.git
cd ctrl-scr

# Install via Pip (Build first)
pip install .

# Or run from source
python -m ctrlscr.gui.app
```

### Create Single EXE
```bash
pyinstaller --onefile --noconsole --name "ctrl-scr" --icon=icon.ico --add-data "config.yaml;." --add-data "icon.png;." ctrlscr/gui/app.py
```
```

See [BUILD.md](BUILD.md) for platform-specific details (Linux dependencies, macOS permissions).

## 📄 License

Distributed under the [MIT License](LICENSE). See `LICENSE` for more information.

## 👤 Author

**Anubhab**
*   Website: [anubhab.site](https://anubhab.site)
*   GitHub: [@therandomuser03](https://github.com/therandomuser03)