
import asyncio
from ctrlscr.network.transport import SecureTCPServer
from ctrlscr.core.input_inject import get_platform_injector
import msgpack

async def handle_client(reader, writer):
    injector = get_platform_injector()
    print("Client Connected. Input capabilities active.")
    
    unpacker = msgpack.Unpacker(raw=False)

    while True:
        try:
            data = await reader.read(4096)
            if not data:
                break
            
            unpacker.feed(data)
            
            for unpacked in unpacker:
                msg_type = unpacked.get("type")
                payload = unpacked.get("payload")
                
                if msg_type == "mouse_move_relative":
                    dx = payload.get("dx", 0)
                    dy = payload.get("dy", 0)
                    injector.mouse.move(dx, dy)
                    
                elif msg_type == "mouse_move":
                    # Fallback or absolute positioning if needed
                    x = payload.get("x", 0)
                    y = payload.get("y", 0)
                    injector.move_mouse(x, y)
                    
                elif msg_type == "mouse_click":
                    btn_str = payload.get("button")
                    state = payload.get("state")
                    # pynput expects Button.left etc.
                    # Injector class wrapper should handle string conversion or we do it here
                    # Let's assume injector.mouse_click handles string
                    # Checking InputInjector implementation...
                    # It likely needs raw pynput buttons if not wrapped
                    # Ideally we update InputInjector wrapper too.
                    # For now assuming injector exposes raw controllers
                    from pynput.mouse import Button
                    btn = getattr(Button, btn_str, Button.left)
                    if state == "pressed":
                        injector.mouse.press(btn)
                    else:
                        injector.mouse.release(btn)

                elif msg_type == "mouse_scroll":
                    dx = payload.get("dx", 0)
                    dy = payload.get("dy", 0)
                    injector.mouse.scroll(dx, dy)

                elif msg_type == "key_event":
                    key = payload.get("key")
                    state = payload.get("state") # down/up
                    injector.key_event(key, state)

        except Exception as e:
            print(f"Error handling client: {e}")
            break

async def run_server(host, port, cert_path, key_path, on_start=None, on_connect=None):
    ssl_ctx = None
    server = SecureTCPServer(host, port, ssl_ctx)
    print(f"Server starting on {host}:{port}")

    async def wrapped_handler(reader, writer):
        addr = writer.get_extra_info('peername')
        print(f"Connection from {addr}")
        if on_connect:
            if asyncio.iscoroutinefunction(on_connect):
                await on_connect(addr)
            else:
                on_connect(addr)
        
        await handle_client(reader, writer)

    await server.start(wrapped_handler, on_start=on_start)
