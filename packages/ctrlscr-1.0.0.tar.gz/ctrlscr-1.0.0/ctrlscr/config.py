"""Configuration management for Control Screen."""
