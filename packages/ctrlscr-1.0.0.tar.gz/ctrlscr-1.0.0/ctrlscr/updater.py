import urllib.request
import json
from packaging import version

CURRENT_VERSION = "1.0.0"
UPDATE_URL = "https://api.github.com/repos/therandomuser03/ctrl-scr/releases/latest"

class UpdateChecker:
    @staticmethod
    def check_for_updates():
        """
        Checks for updates against a remote API.
        Returns (bool, str): (is_update_available, latest_version_url)
        """
        try:
            # In a real scenario, we'd parse the JSON from GitHub
            # req = urllib.request.Request(UPDATE_URL) 
            # with urllib.request.urlopen(req) as response:
            #    data = json.loads(response.read())
            #    latest_tag = data["tag_name"]
            
            # For this v1.0 demo, we will simulate no updates available yet
            # or simulate a newer version if we want to test the UI.
            
            # Simulated check
            latest_version = "1.0.0"
            
            if version.parse(latest_version) > version.parse(CURRENT_VERSION):
                return True, "https://github.com/therandomuser03/ctrl-scr/releases"
            
            return False, None
            
        except Exception as e:
            print(f"Update check failed: {e}")
            return False, None
