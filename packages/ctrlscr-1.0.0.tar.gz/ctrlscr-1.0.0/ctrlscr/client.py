
import asyncio
from ctrlscr.network.protocol import encode_message
from ctrlscr.core.input_capture import InputCapture
import pyautogui
import time
import sys

# Disable fail-safe to allow moving mouse to corners if needed (though we center lock)
pyautogui.FAILSAFE = False

class VirtualScreen:
    def __init__(self, position):
        self.position = position
        self.w, self.h = pyautogui.size()
        self.vx = 0
        self.vy = 0
        
        # Center of local screen for locking
        self.center_x = self.w // 2
        self.center_y = self.h // 2

    def check_entry(self, x, y):
        # 0 or Width-1 is safer than exact edge due to acceleration
        if self.position == "Right" and x >= self.w - 2: return True
        if self.position == "Left" and x <= 1: return True
        if self.position == "Above" and y <= 1: return True
        if self.position == "Below" and y >= self.h - 2: return True
        return False

    def update_and_check_exit(self, dx, dy):
        self.vx += dx
        self.vy += dy
        
        # Return thresholds (sensitivity) - how "far" into the other screen are we? 
        # Actually we just track relative from entry point (0,0 of virtual space).
        
        # Right: We are at Left Edge of Remote. Pulling Left (Negative VX) returns.
        if self.position == "Right" and self.vx < -50: return True
        
        # Left: We are at Right Edge of Remote. Pulling Right (Positive VX) returns.
        if self.position == "Left" and self.vx > 50: return True
        
        # Above: We are at Bottom Edge of Remote. Pulling Down (Positive VY) returns.
        if self.position == "Above" and self.vy > 50: return True
        
        # Below: We are at Top Edge of Remote. Pulling Up (Negative VY) returns.
        if self.position == "Below" and self.vy < -50: return True
        
        return False
        
    def get_return_pos(self):
        # Where to place cursor when returning
        if self.position == "Right": return (self.w - 10, self.h // 2)
        if self.position == "Left": return (10, self.h // 2)
        if self.position == "Above": return (self.w // 2, 10)
        if self.position == "Below": return (self.w // 2, self.h - 10)
        return (self.center_x, self.center_y)

async def run_client(host, port, position):
    ssl_ctx = None
    
    try:
        reader, writer = await asyncio.open_connection(
            host, port, ssl=ssl_ctx
        )
        print(f"Connected to {host}:{port} ({position})")
        
        loop = asyncio.get_running_loop()
        vscreen = VirtualScreen(position)
        
        # State
        state = "LOCAL" # LOCAL | REMOTE
        
        capture = None
        
        def raw_send(msg_type, payload):
            try:
                msg = encode_message(msg_type, payload)
                loop.call_soon_threadsafe(writer.write, msg)
            except:
                pass

        def on_event(etype, payload):
            nonlocal state
            
            if etype == "mouse_move":
                x, y = payload['x'], payload['y']
                
                if state == "LOCAL":
                    if vscreen.check_entry(x, y):
                        print("Switching to REMOTE Control")
                        state = "REMOTE"
                        vscreen.vx, vscreen.vy = 0, 0
                        
                        # Enable Key suppression, keep Mouse active (unsuppressed) to read moves
                        capture.set_suppress(keys=True, mouse=False) 
                        
                        # Lock cursor to center
                        pyautogui.moveTo(vscreen.center_x, vscreen.center_y)
                        
                elif state == "REMOTE":
                    # Calculate Delta
                    dx = x - vscreen.center_x
                    dy = y - vscreen.center_y
                    
                    if dx == 0 and dy == 0:
                        return
                        
                    # Send Delta
                    raw_send("mouse_move_relative", {"dx": dx, "dy": dy})
                    
                    # Update Virtual State
                    if vscreen.update_and_check_exit(dx, dy):
                        print("Returning to LOCAL Control")
                        state = "LOCAL"
                        capture.set_suppress(keys=False, mouse=False)
                        
                        # Restore cursor to edge
                        rx, ry = vscreen.get_return_pos()
                        pyautogui.moveTo(rx, ry)
                    else:
                        # Re-Center Lock
                        pyautogui.moveTo(vscreen.center_x, vscreen.center_y)

            elif state == "REMOTE":
                # Forward other events
                if etype in ["mouse_click", "mouse_scroll", "key_event"]:
                   raw_send(etype, payload)

        capture = InputCapture(on_event)
        capture.start()
        print("Input Capture Started.")

        while True:
            data = await reader.read(4096)
            if not data:
                break
                
    except Exception as e:
        print(f"Client Error: {e}")
    finally:
        if 'capture' in locals() and capture:
            capture.stop()
        print("Client Disconnected")
