import argparse
import asyncio
import sys
from ctrlscr.server import run_server
from ctrlscr.client import run_client
from ctrlscr.gui.app import run as run_gui

def main():
    parser = argparse.ArgumentParser(description="CTRL-SCR: Control Screen")
    parser.add_argument("--server", action="store_true", help="Run as server")
    parser.add_argument("--client", type=str, help="Connect as client to HOST")
    parser.add_argument("--gui", action="store_true", help="Launch GUI")
    
    args = parser.parse_args()

    if args.server:
        # Default port 5050
        try:
            asyncio.run(run_server("0.0.0.0", 5050, "cert.pem", "key.pem"))
        except KeyboardInterrupt:
            pass
    elif args.client:
        try:
            asyncio.run(run_client(args.client, 5050))
        except KeyboardInterrupt:
            pass
    else:
        # Default to GUI if no args or --gui
        run_gui()

if __name__ == "__main__":
    main()
