"""Control Screen - Cross-platform remote control and screen sharing."""
__version__ = "0.1.0"
