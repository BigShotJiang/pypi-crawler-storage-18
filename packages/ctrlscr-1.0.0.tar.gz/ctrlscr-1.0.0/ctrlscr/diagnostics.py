import platform
import sys
import os
import zipfile
import datetime
import shutil

class Diagnostics:
    @staticmethod
    def collect_diagnostics(config_path="config.yaml"):
        """
        Collects system info and config (redacted) into a zip file.
        Returns the path to the zip file.
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        if not os.path.exists(desktop):
            desktop = os.path.expanduser("~") # Fallback to home if no desktop found
            
        output_filename = os.path.join(desktop, f"ctrl-scr-diagnostics-{timestamp}.zip")
        
        info = []
        info.append(f"Report Generated: {datetime.datetime.now()}")
        info.append(f"OS: {platform.system()} {platform.release()} ({platform.version()})")
        info.append(f"Python: {sys.version}")
        info.append(f"Platform: {platform.platform()}")
        
        # Redact config
        config_content = ""
        if os.path.exists(config_path):
            with open(config_path, "r") as f:
                for line in f:
                    if "secret_key" in line or "key" in line:
                        config_content += "secret_key: [REDACTED]\n"
                    else:
                        config_content += line
        else:
            config_content = "Config file not found."

        try:
            with zipfile.ZipFile(output_filename, 'w') as zf:
                zf.writestr("system_info.txt", "\n".join(info))
                zf.writestr("config_redacted.yaml", config_content)
                # Add logs if we had them (future)
        except Exception as e:
            print(f"Failed to create diagnostics: {e}")
            return None
            
        return os.path.abspath(output_filename)
