import random
import time

class mustafatik:
    def __init__(self):
        self.devices = [
            "Samsung Galaxy A10","Samsung Galaxy A10s","Samsung Galaxy A11","Samsung Galaxy A12","Samsung Galaxy A12s","Samsung Galaxy A13","Samsung Galaxy A13 5G","Samsung Galaxy A14","Samsung Galaxy A14 5G","Samsung Galaxy A15","Samsung Galaxy A15 5G","Samsung Galaxy A20","Samsung Galaxy A20s","Samsung Galaxy A21","Samsung Galaxy A21s","Samsung Galaxy A22","Samsung Galaxy A22 5G","Samsung Galaxy A23","Samsung Galaxy A23 5G","Samsung Galaxy A24","Samsung Galaxy A25","Samsung Galaxy A30","Samsung Galaxy A30s","Samsung Galaxy A31","Samsung Galaxy A32","Samsung Galaxy A32 5G","Samsung Galaxy A33","Samsung Galaxy A33 5G","Samsung Galaxy A34","Samsung Galaxy A34 5G","Samsung Galaxy A35","Samsung Galaxy A40","Samsung Galaxy A41","Samsung Galaxy A42","Samsung Galaxy A42 5G","Samsung Galaxy A50","Samsung Galaxy A50s","Samsung Galaxy A51","Samsung Galaxy A51 5G","Samsung Galaxy A52","Samsung Galaxy A52 5G","Samsung Galaxy A52s","Samsung Galaxy A53","Samsung Galaxy A53 5G","Samsung Galaxy A54","Samsung Galaxy A54 5G","Samsung Galaxy A55","Samsung Galaxy A70","Samsung Galaxy A71","Samsung Galaxy A71 5G","Samsung Galaxy A72","Samsung Galaxy A73","Samsung Galaxy A73 5G","Samsung Galaxy A80","Samsung Galaxy A90","Samsung Galaxy A90 5G",
            "Samsung Galaxy S20","Samsung Galaxy S20+","Samsung Galaxy S20 Ultra","Samsung Galaxy S20 FE","Samsung Galaxy S21","Samsung Galaxy S21+","Samsung Galaxy S21 Ultra","Samsung Galaxy S21 FE","Samsung Galaxy S22","Samsung Galaxy S22+","Samsung Galaxy S22 Ultra","Samsung Galaxy S23","Samsung Galaxy S23+","Samsung Galaxy S23 Ultra","Samsung Galaxy S23 FE","Samsung Galaxy S24","Samsung Galaxy S24+","Samsung Galaxy S24 Ultra","Samsung Galaxy S10","Samsung Galaxy S10+","Samsung Galaxy S10e","Samsung Galaxy S9","Samsung Galaxy S9+","Samsung Galaxy S8","Samsung Galaxy S8+",
            "Samsung Galaxy Note 10","Samsung Galaxy Note 10+","Samsung Galaxy Note 20","Samsung Galaxy Note 20 Ultra","Samsung Galaxy Note 8","Samsung Galaxy Note 9",
            "Samsung Galaxy M11","Samsung Galaxy M12","Samsung Galaxy M13","Samsung Galaxy M14","Samsung Galaxy M21","Samsung Galaxy M21s","Samsung Galaxy M22","Samsung Galaxy M23","Samsung Galaxy M31","Samsung Galaxy M31s","Samsung Galaxy M32","Samsung Galaxy M33","Samsung Galaxy M34","Samsung Galaxy M51","Samsung Galaxy M52","Samsung Galaxy M53","Samsung Galaxy M54","Samsung Galaxy M62",
            "Samsung Galaxy Z Fold2","Samsung Galaxy Z Fold3","Samsung Galaxy Z Fold4","Samsung Galaxy Z Fold5","Samsung Galaxy Z Flip","Samsung Galaxy Z Flip3","Samsung Galaxy Z Flip4","Samsung Galaxy Z Flip5",
            "Xiaomi Redmi 9","Xiaomi Redmi 9A","Xiaomi Redmi 9C","Xiaomi Redmi 9T","Xiaomi Redmi 10","Xiaomi Redmi 10A","Xiaomi Redmi 10C","Xiaomi Redmi 11","Xiaomi Redmi 11A","Xiaomi Redmi 12","Xiaomi Redmi 12C","Xiaomi Redmi 13","Xiaomi Redmi 13C",
            "Xiaomi Redmi Note 8","Xiaomi Redmi Note 8 Pro","Xiaomi Redmi Note 9","Xiaomi Redmi Note 9 Pro","Xiaomi Redmi Note 9S","Xiaomi Redmi Note 10","Xiaomi Redmi Note 10 Pro","Xiaomi Redmi Note 10S","Xiaomi Redmi Note 11","Xiaomi Redmi Note 11 Pro","Xiaomi Redmi Note 11S","Xiaomi Redmi Note 12","Xiaomi Redmi Note 12 Pro","Xiaomi Redmi Note 12S","Xiaomi Redmi Note 13","Xiaomi Redmi Note 13 Pro",
            "Xiaomi Poco X3","Xiaomi Poco X3 Pro","Xiaomi Poco X4","Xiaomi Poco X4 Pro","Xiaomi Poco X5","Xiaomi Poco X5 Pro","Xiaomi Poco X6","Xiaomi Poco X6 Pro",
            "Xiaomi Poco F3","Xiaomi Poco F4","Xiaomi Poco F5","Xiaomi Poco F6","Xiaomi Poco M3","Xiaomi Poco M4","Xiaomi Poco M5","Xiaomi Poco M6",
            "Xiaomi Mi 10","Xiaomi Mi 10T","Xiaomi Mi 11","Xiaomi Mi 11T","Xiaomi Mi 12","Xiaomi Mi 12T","Xiaomi Mi 13","Xiaomi Mi 13T",
            "OPPO A15","OPPO A15s","OPPO A16","OPPO A16s","OPPO A17","OPPO A17k","OPPO A18","OPPO A31","OPPO A53","OPPO A54","OPPO A55","OPPO A57","OPPO A74","OPPO A76","OPPO A78","OPPO A79","OPPO A83","OPPO A91","OPPO A94","OPPO A95","OPPO A96","OPPO A98",
            "OPPO Reno 5","OPPO Reno 5 Pro","OPPO Reno 6","OPPO Reno 6 Pro","OPPO Reno 7","OPPO Reno 7 Pro","OPPO Reno 8","OPPO Reno 8 Pro","OPPO Reno 9","OPPO Reno 9 Pro","OPPO Reno 10","OPPO Reno 10 Pro",
            "OPPO Find X3","OPPO Find X5","OPPO Find X6","OPPO Find X7",
            "Vivo Y12","Vivo Y12s","Vivo Y15","Vivo Y15s","Vivo Y16","Vivo Y17","Vivo Y20","Vivo Y20s","Vivo Y21","Vivo Y21s","Vivo Y22","Vivo Y22s","Vivo Y27","Vivo Y33","Vivo Y33s","Vivo Y35","Vivo Y36","Vivo Y50","Vivo Y52","Vivo Y53","Vivo Y55","Vivo Y56","Vivo Y70","Vivo Y72","Vivo Y76","Vivo Y78","Vivo Y90","Vivo Y100",
            "Vivo V20","Vivo V20 SE","Vivo V21","Vivo V21e","Vivo V23","Vivo V23e","Vivo V25","Vivo V25 Pro","Vivo V27","Vivo V27 Pro","Vivo V29","Vivo V29 Pro",
            "Vivo X60","Vivo X70","Vivo X80","Vivo X90","Vivo X100",
            "Huawei Y7 Prime","Huawei Y7p","Huawei Y8p","Huawei Y9 2019","Huawei Y9a","Huawei Y9s","Huawei Y6p","Huawei Y6s","Huawei Y5p","Huawei Y3","Y5","Y6","Y7","Y8","Y9",
            "Huawei Nova 3i","Huawei Nova 5T","Huawei Nova 7i","Huawei Nova 8i","Huawei Nova 9","Huawei Nova 10","Huawei Nova 11",
            "Huawei Mate 20 Lite","Huawei Mate 30 Lite","Huawei Mate 40 Lite","Huawei Mate 50 Lite",
            "Huawei P30 Lite","Huawei P40 Lite","Huawei P50 Lite","Huawei P60 Lite",
            "Infinix Hot 9","Infinix Hot 10","Infinix Hot 11","Infinix Hot 12","Infinix Hot 13","Infinix Hot 14","Infinix Hot 15","Infinix Hot 16","Infinix Hot 17","Infinix Hot 18","Infinix Hot 19","Infinix Hot 20","Infinix Hot 21","Infinix Hot 22","Infinix Hot 23","Infinix Hot 24",
            "Infinix Note 7","Infinix Note 8","Infinix Note 10","Infinix Note 11","Infinix Note 12","Infinix Note 13","Infinix Note 14","Infinix Note 15","Infinix Note 16","Infinix Note 17","Infinix Note 18","Infinix Note 19","Infinix Note 20","Infinix Note 21","Infinix Note 22","Infinix Note 23","Infinix Note 24",
            "Infinix Zero 8","Infinix Zero 9","Infinix Zero 10","Infinix Zero 11","Infinix Zero 12","Infinix Zero 13","Infinix Zero 14","Infinix Zero 15","Infinix Zero 16","Infinix Zero 17","Infinix Zero 18",
            "Tecno Spark 6","Tecno Spark 7","Tecno Spark 8","Tecno Spark 9","Tecno Spark 10","Tecno Spark 11","Tecno Spark 12","Tecno Spark 13","Tecno Spark 14","Tecno Spark 15","Tecno Spark 16","Tecno Spark 17","Tecno Spark 18","Tecno Spark 19","Tecno Spark 20",
            "Tecno Camon 15","Tecno Camon 16","Tecno Camon 17","Tecno Camon 18","Tecno Camon 19","Tecno Camon 20","Tecno Camon 21","Tecno Camon 22","Tecno Camon 23","Tecno Camon 24","Tecno Camon 25",
            "Tecno Pova 2","Tecno Pova 3","Tecno Pova 4","Tecno Pova 5","Tecno Pova 6",
            "Motorola Moto G7","Motorola Moto G7 Power","Motorola Moto G7 Play","Motorola Moto G8","Motorola Moto G8 Power","Motorola Moto G9","Motorola Moto G9 Play","Motorola Moto G9 Power","Motorola Moto G10","Motorola Moto G10 Power","Motorola Moto G20","Motorola Moto G30","Motorola Moto G31","Motorola Moto G32","Motorola Moto G33","Motorola Moto G34","Motorola Moto G40","Motorola Moto G41","Motorola Moto G42","Motorola Moto G50","Motorola Moto G51","Motorola Moto G52","Motorola Moto G53","Motorola Moto G54","Motorola Moto G60","Motorola Moto G62","Motorola Moto G70","Motorola Moto G71","Motorola Moto G72","Motorola Moto G73","Motorola Moto G84","Motorola Moto G100",
            "Motorola Moto E7","Motorola Moto E7 Power","Motorola Moto E7i Power","Motorola Moto E13","Motorola Moto E14","Motorola Moto E20","Motorola Moto E22","Motorola Moto E23","Motorola Moto E30","Motorola Moto E32","Motorola Moto E40","Motorola Moto E50",
            "Motorola Edge 20","Motorola Edge 30","Motorola Edge 40","Motorola Edge 50",
            "Nokia 3.4","Nokia 5.3","Nokia 5.4","Nokia 6.2","Nokia 7.2","Nokia 8.3","Nokia X10","Nokia X20","Nokia X30","Nokia X100","Nokia G10","Nokia G20","Nokia G30","Nokia G50","Nokia G60","Nokia C10","Nokia C20","Nokia C30","Nokia C100","Nokia C200","Nokia C300",
            "Realme C11","Realme C12","Realme C15","Realme C17","Realme C21","Realme C25","Realme C30","Realme C31","Realme C33","Realme C35","Realme C51","Realme C53","Realme C55","Realme C65",
            "Realme Narzo 10","Realme Narzo 20","Realme Narzo 30","Realme Narzo 40","Realme Narzo 50","Realme Narzo 60","Realme Narzo 70",
            "Realme 6","Realme 7","Realme 8","Realme 9","Realme 10","Realme 11","Realme GT","Realme GT 2","Realme GT 3","Realme GT 5",
            "OnePlus Nord","OnePlus Nord 2","OnePlus Nord 3","OnePlus Nord CE","OnePlus Nord CE 2","OnePlus Nord CE 3",
            "OnePlus 8","OnePlus 8T","OnePlus 9","OnePlus 9 Pro","OnePlus 9RT","OnePlus 10","OnePlus 10 Pro","OnePlus 10T","OnePlus 11","OnePlus 11R","OnePlus 12","OnePlus 12R",
            "Google Pixel 4a","Google Pixel 4a 5G","Google Pixel 5","Google Pixel 5a","Google Pixel 6","Google Pixel 6a","Google Pixel 6 Pro","Google Pixel 7","Google Pixel 7a","Google Pixel 7 Pro","Google Pixel 8","Google Pixel 8a","Google Pixel 8 Pro","Google Pixel 9","Google Pixel 9 Pro",
            "Asus Zenfone 8","Asus Zenfone 9","Asus Zenfone 10","Asus ROG Phone 5","Asus ROG Phone 6","Asus ROG Phone 7","Asus ROG Phone 8",
            "LG G7","LG G8","LG V50","LG V60","LG Velvet","LG Wing",
            "Sony Xperia 1 II","Sony Xperia 1 III","Sony Xperia 1 IV","Sony Xperia 1 V","Sony Xperia 5 II","Sony Xperia 5 III","Sony Xperia 5 IV","Sony Xperia 10 II","Sony Xperia 10 III","Sony Xperia 10 IV","Sony Xperia 10 V",
            "HTC U12+","HTC U20 5G","HTC Desire 20+","HTC Desire 21 Pro","HTC Desire 22 Pro",
            "BlackBerry Key2","BlackBerry Key2 LE","BlackBerry Motion","BlackBerry Evolve","BlackBerry Evolve X",
            "HONOR 50","HONOR 50 Lite","HONOR 70","HONOR 70 Lite","HONOR 90","HONOR 90 Lite","HONOR X7","HONOR X8","HONOR X9","HONOR Magic 4","HONOR Magic 5",
            "ZTE Blade A7","ZTE Blade A71","ZTE Blade V40","ZTE Blade V50","ZTE Axon 30","ZTE Axon 40","ZTE Axon 50",
            "Alcatel 1","Alcatel 1S","Alcatel 3","Alcatel 3X","Alcatel 5","Alcatel 7",
            "Lenovo K12","Lenovo K13","Lenovo Tab M10","Lenovo Tab P11","Lenovo Legion Duel","Lenovo Legion Duel 2",
            "Panasonic Eluga I8","Panasonic Eluga Ray","Panasonic P95","Panasonic P99",
            "Micromax In Note 1","Micromax In Note 2","Micromax In 1","Micromax In 2",
            "Lava Z1","Lava Z2","Lava Z4","Lava Z6","Lava Agni","Lava Agni 2",
            "Gionee Max","Gionee Max Pro","Gionee F9","Gionee F10",
            "Coolpad Cool 3","Coolpad Cool 5","Coolpad Mega 5",
            "Ulefone Note","Ulefone Note 12","Ulefone Armor","Ulefone Power",
            "Doogee S96","Doogee S98","Doogee V30","Doogee X97",
            "Blackview BV4900","Blackview BV5800","Blackview BV6600","Blackview BV8800",
            "Cubot King Kong","Cubot Pocket","Cubot X90",
            "Oukitel WP10","Oukitel WP12","Oukitel WP15",
            "Umidigi A13","Umidigi Bison","Umidigi F3",
            "Vernee Thor","Vernee Mars","Vernee Apollo",
            "Leagoo T5","Leagoo T10","Leagoo P1",
            "Cherry Mobile Flare","Cherry Mobile Aqua","Cherry Mobile Fusion",
            "Starmobile Play","Starmobile Knight","Starmobile Epic",
            "MyPhone MyX1","MyPhone MyX2","MyPhone MyX3",
            "Cloudfone Next","Cloudfone Thrill","Cloudfone Excite",
            "Advan G5","Advan S5","Advan Vandroid",
            "Evercoss Winner","Evercoss A74","Evercoss M54",
            "Smartfren Andromax","Smartfren New Andromax","Smartfren G2",
            "Mito A10","Mito A20","Mito A30",
            "Symphony Z40","Symphony Z50","Symphony Z60",
            "Walton Primo","Walton Ultra","Walton Max",
            "iTel Vision","iTel P33","iTel S23",
            "Mobicel R9","Mobicel R1","Mobicel R5",
            "Huawei Enjoy 20","Huawei Enjoy 50","Huawei Enjoy 60",
            "Xiaomi Black Shark 2","Xiaomi Black Shark 3","Xiaomi Black Shark 4",
            "Nubia Red Magic 5","Nubia Red Magic 6","Nubia Red Magic 7",
            "Asus ROG Phone 5s","Asus ROG Phone 5s Pro","Asus ROG Phone 6D",
            "Lenovo Legion Phone","Lenovo Legion Phone 2","Lenovo Legion Phone Duel",
            "Sharp Aquos R6","Sharp Aquos R7","Sharp Aquos Wish",
            "Kyocera DuraForce","Kyocera DuraSport","Kyocera DuraXE",
            "Cat S62","Cat S62 Pro","Cat S75",
            "Sonim XP8","Sonim XP10","Sonim XP12",
            "Crosscall Action","Crosscall Core","Crosscall Trekker",
            "BQ Aquaris X2","BQ Aquaris X2 Pro","BQ Aquaris X5",
            "Wiko View","Wiko View2","Wiko View3",
            "Archos Oxygen","Archos Helium","Archos Xenon",
            "Allview X4","Allview X5","Allview X6",
            "Gigaset GS4","Gigaset GS5","Gigaset GS6",
            "Condor Plume","Condor Allure","Condor Glory",
            "Doro 8030","Doro 8040","Doro 8050",
            "Emporia Smart","Emporia Solid","Emporia Touch",
            "Maxcom MM777","Maxcom MM888","Maxcom MM999",
            "Mode1 M1","Mode1 M2","Mode1 M3",
            "Logicom L-EMENT","Logicom L-EMENT2","Logicom L-EMENT3",
            "Krono K1","Krono K2","Krono K3",
            "Star N1","Star N2","Star N3",
            "Prestigio MultiPhone","Prestigio Grace","Prestigio Smart",
            "QMobile Noir","QMobile Elite","QMobile Dream",
            "Voice V40","Voice V50","Voice V60",
            "Nomi i501","Nomi i502","Nomi i503",
            "DEXP Ixion","DEXP Larus","DEXP Ursus",
            "Texet X-treme","Texet TM","Texet TX",
            "Jinga iGo","Jinga iStyle","Jinga iPro",
            "HOMTOM HT","HOMTOM S9","HOMTOM S12",
            "LeEco Le 2","LeEco Le Pro3","LeEco Le Max2",
            "Meizu M10","Meizu M8","Meizu M6",
            "ZUK Z2","ZUK Edge","ZUK Z2 Pro",
            "Smartisan Nut","Smartisan Pro","Smartisan R2",
            "Essential PH-1","Essential PH-2","Essential PH-3",
            "Nextbit Robin","Nextbit Storm","Nextbit Cloud",
            "Fairphone 3","Fairphone 4","Fairphone 5",
            "Planet Computers Astro","Planet Computers Cosmo","Planet Computers Gemini",
            "F(x)tec Pro1","F(x)tec Pro1-X","F(x)tec Pro2",
            "Pine64 PinePhone","Pine64 PinePhone Pro","Pine64 PineTab",
            "Librem 5","Librem 5 USA","Librem 14",
            "Volla Phone","Volla Phone 22","Volla Phone X",
            "Sirin Labs Solarin","Sirin Labs Finney","Sirin Labs V3",
            "Vertu Aster","Vertu Signature","Vertu Metavertu",
            "Turing Phone","Turing Robotic","Turing Appassionato",
            "Carbon Mobile 1","Carbon Mobile 2","Carbon Mobile 3",
            "Shift6mq","Shift7","Shift8",
            "Solo Anchors 3","Solo Anchors 4","Solo Anchors 5",
            "TCL 10 Pro","TCL 20 Pro","TCL 30 Pro",
            "Hisense A5","Hisense A7","Hisense A9",
            "Oppo K9","Oppo K10","Oppo K11",
            "Vivo T1","Vivo T2","Vivo T3",
            "Xiaomi Civi","Xiaomi Civi 2","Xiaomi Civi 3",
            "Realme V5","Realme V11","Realme V13",
            "HONOR Play","HONOR Play 2","HONOR Play 3",
            "Huawei Mate Xs","Huawei Mate X2","Huawei Mate X3",
            "Samsung Galaxy F04","Samsung Galaxy F14","Samsung Galaxy F34",
            "Samsung Galaxy M04","Samsung Galaxy M14","Samsung Galaxy M44",
            "Samsung Galaxy A04","Samsung Galaxy A04s","Samsung Galaxy A04e"
        ]

    def _device(self):
        device = random.choice(self.devices)
        android = random.choice(["10", "11", "12", "13", "14"])
        
        build_prefixes = ["QP1A", "RP1A", "SP1A", "TP1A", "UP1A", "VP1A", "WP1A"]
        build_prefix = random.choice(build_prefixes)
        
        build_middle = random.randint(190000, 299999)
        build_end = random.randint(1, 999)
        build = f"{build_prefix}.{build_middle:06d}.{build_end:03d}"
        
        ua = (
            f"Mozilla/5.0 (Linux; Android {android}; {device}) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) "
            f"Chrome/{random.randint(110, 125)}.0.0.0 "
            f"Mobile Safari/537.36 "
            f"Build/{build}"
        )
        
        ts = str(int(time.time()))
        return {
            "device_type": device,
            "device_brand": device.split()[0],
            "android_version": android,
            "build_number": build,
            "user_agent": ua,
            "ts": ts,
            "_rticket": str(int(time.time() * 1000)),
            "device_id": str(random.randint(1, 10**19))
        }

    def updateParams(self, params: dict):
        self._last_device = self._device()
        d = self._last_device
        params.update({
            "device_id": d["device_id"],
            "aid": "1233",
            "device_type": d["device_type"],
            "device_brand": d["device_brand"],
            "os_version": d["android_version"],
            "_rticket": d["_rticket"],
            "ts": d["ts"],
        })
        return params

    def updateHeaders(self, headers: dict):
        d = getattr(self, "_last_device", None)
        if d is None:
            d = self._device()
            self._last_device = d
        headers.update({
            "User-Agent": d["user_agent"]
        })
        return headers
