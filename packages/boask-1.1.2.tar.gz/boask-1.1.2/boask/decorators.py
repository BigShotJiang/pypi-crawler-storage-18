from urllib.parse import urlparse

class decorators:
    @staticmethod
    def strict_slashes(loose: bool = False):
        def decorator(func):
            def wrapper(handler):
                if loose:
                    path = handler.path
                    if path != "/" and not path.endswith("/"):
                        location = path + "/"
                        if handler.query_string:
                            location += "?" + handler.query_string.decode("utf-8", errors="ignore")
                        handler.send_response(301)
                        handler.send_header("Location", location)
                        handler.end_headers()
                        return  # Stop here — redirected
                return func(handler)
            return wrapper
        return decorator

strict_slashes = decorators.strict_slashes