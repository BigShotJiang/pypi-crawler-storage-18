# fapis — FastAPI infrastructure starter

fapis is a small CLI and template library to bootstrap a production-ready FastAPI project. It ships with a `base` template containing a minimal app layout (routers, lifecycle hooks, logging, and tests) so you can scaffold a new service quickly.

This README focuses on how developers use the project and the templates for local development and iteration.

## What is included

- A CLI to generate project skeletons from the built-in templates.
- A `base` template (under `fapis/templates/infrastructure/base`) with a sample FastAPI app, tests, and Dockerfile.

## Quickstart (developer)

1. Create a virtual environment and activate it (recommended):

```bash
python3 -m venv .venv
source .venv/bin/activate
```

2. Install this package in editable mode so you can iterate on the CLI:

```bash
pip install -e .
```

3. Generate a new project from the `base` template:

```bash
fapis base ./my-new-service
```

This copies the template files into `./my-new-service` and initializes a git repository there.

4. Enter the generated project, install its runtime requirements and run the app:

```bash
cd my-new-service
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/api/health to see the sample health endpoint.

## Project layout (template)

The `base` template demonstrates a minimal but practical structure:

- `app/main.py` — application factory and ASGI entrypoint
- `app/api/health.py` — example router
- `app/core/` — configuration and logging setup
- `app/infrastructure/` — lifecycle and DI helpers
- `tests/` — sample pytest tests
- `Dockerfile`, `Makefile` — dev and deployment helpers

Inspect `fapis/templates/infrastructure/base` to see the full template source.

## Development workflow

- Run tests:

```bash
pytest -q
```

- When modifying the CLI, install in editable mode (`pip install -e .`) so `fapis` command reflects changes immediately.

## How the CLI works

The CLI entry point is `fapis.cli:main`. After installing the package it exposes a `fapis` console script that accepts a template name and destination:

```bash
fapis <template> <destination>
# example
fapis base ./services/my-service
```

If the destination already exists the command will fail; it will also attempt to initialize a git repository in the created folder (if `git` is available).

## Contributing and license

See `CONTRIBUTING.md` for contribution guidelines and `LICENSE` for license terms (MIT).

