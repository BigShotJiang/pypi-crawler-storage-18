(This README provides a tiny, reusable FastAPI "base" template. Use this folder as a starting point for new services.)

# fastapi-starter (template)

This folder is a minimal, practical FastAPI service template intended to be copied or used as a project scaffold. It includes:

- A small `app/` package with an example health endpoint
- Configuration via `pydantic` (`.env` support)
- Basic logging and lifecycle (startup/shutdown)
- A test (`pytest` + `httpx` async client)
- `requirements.txt`, `Dockerfile`, and a GitHub Actions CI workflow

Quick start

1. Create a new repository and copy the contents of this template into it.
2. Create a virtualenv and install dependencies:

   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt

3. Copy `.env.example` to `.env` and edit values as needed.
4. Run locally:

   uvicorn app.main:app --reload

5. Run tests:

   pytest -q

Docker

Build and run (example):

docker build -t fastapi-starter .
docker run -p 8000:8000 fastapi-starter

How to use this template

- Replace or extend `app/api`, `app/core`, and `app/infrastructure` with your domain code.
- Add production-ready configuration, secrets management, and health checks (DB, caches, etc.).
- Consider adding pre-commit hooks, security scanning, and more CI steps as needed.
