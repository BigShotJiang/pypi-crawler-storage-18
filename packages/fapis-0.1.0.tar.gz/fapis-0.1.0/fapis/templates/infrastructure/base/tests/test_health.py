import pytest
from httpx import AsyncClient
from app.main import app


@pytest.mark.asyncio
async def test_health_ok() -> None:
	"""Health endpoint should return status ok and a timestamp."""
	async with AsyncClient(app=app, base_url="http://test") as ac:
		r = await ac.get("/api/health")
		assert r.status_code == 200
		data = r.json()
		assert data["status"] == "ok"
		assert "timestamp" in data

