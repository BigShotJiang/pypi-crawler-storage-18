from fastapi import APIRouter
from datetime import datetime

router = APIRouter()


@router.get("/health", tags=["health"])
async def health():
	"""Simple health endpoint returning basic service metadata."""
	return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

