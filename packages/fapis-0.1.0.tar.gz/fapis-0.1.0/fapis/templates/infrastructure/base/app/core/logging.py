import logging


def setup_logging(level: int | str = logging.INFO) -> None:
	"""Configure simple, readable console logging for the template."""
	logging.basicConfig(
		level=level,
		format="%(asctime)s %(levelname)s %(name)s: %(message)s",
	)

