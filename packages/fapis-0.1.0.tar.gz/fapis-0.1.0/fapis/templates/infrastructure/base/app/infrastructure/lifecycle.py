from fastapi import FastAPI
import logging
import time

logger = logging.getLogger(__name__)


def register_lifecycle(app: FastAPI) -> None:
	"""Register basic startup and shutdown handlers that set state and log events."""

	@app.on_event("startup")
	async def startup_event() -> None:
		app.state.start_time = time.time()
		logger.info("Application startup complete")

	@app.on_event("shutdown")
	async def shutdown_event() -> None:
		uptime = time.time() - getattr(app.state, "start_time", time.time())
		logger.info(f"Application shutdown (uptime={uptime:.2f}s)")

