async def get_health_status() -> dict:
	"""Placeholder async dependency for health checks.

	Replace or extend this with DB checks, external services, etc.
	"""
	return {"status": "ok"}

