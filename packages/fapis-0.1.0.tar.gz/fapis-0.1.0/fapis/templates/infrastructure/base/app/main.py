from fastapi import FastAPI
from app.api import health as health_api
from app.infrastructure.lifecycle import register_lifecycle
from app.core.logging import setup_logging


def create_app() -> FastAPI:
	"""Create and configure the FastAPI application instance.

	- Sets up logging
	- Registers routers and lifecycle events
	"""
	setup_logging()
	app = FastAPI(title="FastAPI Starter", version="0.1.0")
	app.include_router(health_api.router, prefix="/api")
	register_lifecycle(app)
	return app


app = create_app()


if __name__ == "__main__":
	import uvicorn

	uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
