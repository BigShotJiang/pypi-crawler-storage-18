"""
TDE File Parser - Reads legacy Tableau Data Extract files into pandas DataFrames.

Based on reverse-engineered TDE file format specification.
"""

import struct
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import BinaryIO, Optional, Any
import pandas as pd
import numpy as np


# Magic bytes identifying a TDE file
TDE_MAGIC = bytes([0x20, 0x02, 0x01, 0x62, 0xa0, 0x1e, 0xab, 0x07])

# Block markers
DATA_BLOCK_MARKER = bytes([0xf0, 0xca, 0x12, 0x78])
INDEX_BLOCK_MARKER = bytes([0xf1, 0xca, 0x12, 0x78])


@dataclass
class TDEHeader:
    """TDE file header structure."""
    magic: bytes
    format_version: int
    root_index_offset: int
    file_size: int


@dataclass
class BlockInfo:
    """Information about a data block."""
    file_pos: int
    data_offset: int
    size: int
    virt_start: int
    virt_end: int


@dataclass
class ColumnEntry:
    """Column entry from index block."""
    name: str
    file_start: int
    file_end: int
    block_info: Optional[BlockInfo] = None


@dataclass
class ExtractColumn:
    """Parsed column data."""
    name: str
    datatype: str  # 'string', 'double', 'integer', 'date', etc.
    dictionary: list = field(default_factory=list)
    values: list = field(default_factory=list)
    indices: list = field(default_factory=list)


class TDEParser:
    """Parser for TDE (Tableau Data Extract) files."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.content: bytes = b''
        self.header: Optional[TDEHeader] = None
        self.xml_metadata: str = ''
        self.column_entries: dict[str, ColumnEntry] = {}
        self.extract_columns: dict[str, ExtractColumn] = {}

    def _read_header(self) -> TDEHeader:
        """Read the TDE file header."""
        magic = self.content[0:8]
        if magic != TDE_MAGIC:
            raise ValueError(f"Invalid TDE file: wrong magic bytes {magic.hex()}")

        format_version = struct.unpack('<I', self.content[8:12])[0]
        root_index_offset = struct.unpack('<Q', self.content[12:20])[0]
        file_size = struct.unpack('<Q', self.content[20:28])[0]

        return TDEHeader(
            magic=magic,
            format_version=format_version,
            root_index_offset=root_index_offset,
            file_size=file_size
        )

    def _read_xml_metadata(self) -> str:
        """Read embedded XML metadata."""
        xml_start = self.content.find(b'<?xml')
        if xml_start == -1:
            return ''

        xml_end = self.content.find(b'</datasource>', xml_start)
        if xml_end == -1:
            return ''

        xml_end += len(b'</datasource>')
        return self.content[xml_start:xml_end].decode('utf-8', errors='replace')

    def _get_block_info(self, file_pos: int) -> Optional[BlockInfo]:
        """Get block information at file position."""
        if file_pos + 20 > len(self.content):
            return None

        marker = self.content[file_pos:file_pos+4]
        if marker != DATA_BLOCK_MARKER:
            return None

        virt_start = struct.unpack('<Q', self.content[file_pos+4:file_pos+12])[0]
        virt_end = struct.unpack('<Q', self.content[file_pos+12:file_pos+20])[0]

        return BlockInfo(
            file_pos=file_pos,
            data_offset=file_pos + 32,
            size=virt_end - virt_start,
            virt_start=virt_start,
            virt_end=virt_end
        )

    def _read_block_data(self, file_pos: int) -> Optional[bytes]:
        """Read data from block at file position."""
        block = self._get_block_info(file_pos)
        if not block:
            return None
        return self.content[block.data_offset:block.data_offset + block.size]

    def _find_extract_index_block(self) -> int:
        """Find the index block that lists Extract table columns."""
        # Search for f1ca1278 blocks that contain user data column names
        # Names are UTF-16LE encoded, so look for patterns like ".data" or ".dict" in UTF-16LE
        data_pattern_utf16 = '.data'.encode('utf-16-le')
        dict_pattern_utf16 = '.dict'.encode('utf-16-le')

        pos = 0
        best_block = -1
        best_score = 0

        while True:
            idx = self.content.find(INDEX_BLOCK_MARKER, pos)
            if idx == -1:
                break

            entry_count = struct.unpack('<I', self.content[idx+4:idx+8])[0]

            # Estimate chunk size based on entry count (each entry ~40-100 bytes)
            chunk_size = min(entry_count * 100 + 100, 2000)
            chunk = self.content[idx:idx+chunk_size]

            # Score based on user data patterns
            score = 0
            if data_pattern_utf16 in chunk:
                score += chunk.count(data_pattern_utf16)
            if dict_pattern_utf16 in chunk:
                score += chunk.count(dict_pattern_utf16)

            # Check first entry name for system indicators
            first_name = ''
            if entry_count > 0:
                name_len = struct.unpack('<I', self.content[idx+8:idx+12])[0]
                if 0 < name_len < 100:
                    first_name = self.content[idx+12:idx+12+name_len*2].decode('utf-16-le', errors='replace').rstrip('\x00')

            # Skip system table blocks
            first_name_upper = first_name.upper()
            is_system = (first_name_upper.startswith('COLUMNPROPS') or
                        first_name_upper.startswith('TABLEPROPS') or
                        first_name_upper.startswith('SCHEMAPROPS') or
                        first_name_upper.startswith('COLUMNS_') or
                        first_name_upper.startswith('TABLES_') or
                        first_name_upper.startswith('SCHEMAS_') or
                        first_name_upper.startswith('DUAL_') or
                        first_name_upper.startswith('.DATABASE') or
                        first_name_upper.startswith('$TABLEAU') or
                        first_name_upper.startswith('KEY.') or  # key.1.dict, key.data
                        first_name_upper.startswith('VALUE.'))  # value.1.dict, value.data

            if entry_count >= 2 and score > 0 and not is_system:
                # Score higher for more data/dict patterns
                if score > best_score:
                    best_score = score
                    best_block = idx

            pos = idx + 1

        return best_block

    def _parse_index_entries(self, index_pos: int) -> dict[str, ColumnEntry]:
        """Parse entries from an index block."""
        entries = {}

        if self.content[index_pos:index_pos+4] != INDEX_BLOCK_MARKER:
            return entries

        entry_count = struct.unpack('<I', self.content[index_pos+4:index_pos+8])[0]
        pos = index_pos + 8

        for _ in range(entry_count):
            if pos + 4 > len(self.content):
                break

            name_len = struct.unpack('<I', self.content[pos:pos+4])[0]
            if name_len > 500:
                break

            name = self.content[pos+4:pos+4+name_len*2].decode('utf-16-le', errors='replace').rstrip('\x00')

            offset_pos = pos + 4 + name_len * 2
            if offset_pos + 16 > len(self.content):
                break

            file_start = struct.unpack('<Q', self.content[offset_pos:offset_pos+8])[0]
            file_end = struct.unpack('<Q', self.content[offset_pos+8:offset_pos+16])[0]

            block_info = self._get_block_info(file_start)

            entries[name] = ColumnEntry(
                name=name,
                file_start=file_start,
                file_end=file_end,
                block_info=block_info
            )

            pos = offset_pos + 16

        return entries

    def _detect_string_prefix_size(self, data: bytes) -> int:
        """Detect whether string dictionary uses 1-byte, 2-byte, or 4-byte length prefixes."""
        if len(data) < 2:
            return 0

        # Try 4-byte prefix first (original format)
        if len(data) >= 4:
            len_4 = struct.unpack('<I', data[:4])[0]
            if 1 <= len_4 <= 1000 and len(data) >= 4 + len_4:
                try:
                    s = data[4:4+len_4].decode('utf-8')
                    if s.isprintable() or any(c in s for c in ' \n\t'):
                        return 4
                except:
                    pass

        # Try 2-byte prefix (newer format used by many federated TDE files)
        len_2 = struct.unpack('<H', data[:2])[0]
        if 1 <= len_2 <= 1000 and len(data) >= 2 + len_2:
            try:
                s = data[2:2+len_2].decode('utf-8')
                if s.isprintable() or any(c in s for c in ' \n\t'):
                    return 2
            except:
                pass

        # Try 1-byte prefix (compact format used by some federated TDE files)
        len_1 = data[0]
        if 1 <= len_1 <= 200 and len(data) >= 1 + len_1:
            try:
                s = data[1:1+len_1].decode('utf-8')
                if s.isprintable() or any(c in s for c in ' \n\t'):
                    return 1
            except:
                pass

        return 0

    def _read_string_dictionary(self, data: bytes) -> list[str]:
        """Read length-prefixed UTF-8 strings from data.

        Supports 1-byte, 2-byte, and 4-byte length prefixes (auto-detected).
        """
        if not data or len(data) < 2:
            return []

        # Auto-detect length prefix size by testing all formats
        prefix_size = self._detect_string_prefix_size(data)
        if prefix_size == 0:
            return []

        strings = []
        pos = 0

        # Select format based on prefix size
        if prefix_size == 1:
            fmt = 'B'  # unsigned char (1 byte)
        elif prefix_size == 2:
            fmt = '<H'  # unsigned short (2 bytes)
        else:
            fmt = '<I'  # unsigned int (4 bytes)

        while pos < len(data) - prefix_size:
            if prefix_size == 1:
                length = data[pos]
            else:
                length = struct.unpack(fmt, data[pos:pos+prefix_size])[0]

            # End markers
            if length == 0 or length == 0xFF or length == 0xFFFF or length == 0xFFFFFFFF:
                break
            if length > 10000 or pos + prefix_size + length > len(data):
                break

            try:
                s = data[pos+prefix_size:pos+prefix_size+length].decode('utf-8', errors='replace')
                strings.append(s)
            except:
                break
            pos += prefix_size + length

        return strings

    def _read_doubles(self, data: bytes) -> list[float]:
        """Read array of doubles from data."""
        if not data or len(data) < 8:
            return []

        count = len(data) // 8
        return [struct.unpack('<d', data[i*8:(i+1)*8])[0] for i in range(count)]

    def _read_integers(self, data: bytes, size: int = 8) -> list[int]:
        """Read array of integers from data."""
        if not data:
            return []

        count = len(data) // size
        fmt = '<q' if size == 8 else ('<i' if size == 4 else '<h')
        return [struct.unpack(fmt, data[i*size:(i+1)*size])[0] for i in range(count)]

    def _determine_column_type(self, col_name: str, data: bytes) -> str:
        """Determine column data type from content."""
        if not data:
            return 'unknown'

        # Check if it's string dictionary (length-prefixed strings)
        # Try 4-byte prefix first
        if len(data) >= 4:
            length = struct.unpack('<I', data[:4])[0]
            if 1 <= length <= 1000 and len(data) >= 4 + length:
                try:
                    s = data[4:4+length].decode('utf-8')
                    if s.isprintable() or '\n' in s or ' ' in s:
                        return 'string_dict'
                except:
                    pass

        # Try 2-byte prefix
        if len(data) >= 2:
            length = struct.unpack('<H', data[:2])[0]
            if 1 <= length <= 1000 and len(data) >= 2 + length:
                try:
                    s = data[2:2+length].decode('utf-8')
                    if s.isprintable() or '\n' in s or ' ' in s:
                        return 'string_dict'
                except:
                    pass

        # Check if it's doubles (look at multiple values for better detection)
        if len(data) >= 16:
            try:
                valid_count = 0
                geo_like = 0  # Count values that look like lat/lon
                for i in range(min(5, len(data) // 8)):
                    d = struct.unpack('<d', data[i*8:(i+1)*8])[0]
                    if np.isfinite(d):
                        valid_count += 1
                        if -180 <= d <= 360:  # Lat/lon range
                            geo_like += 1

                # If most values are valid doubles and look reasonable
                if valid_count >= 3:
                    if geo_like >= 3:  # Geographic data
                        return 'double'
                    # Check if values are in reasonable numeric range
                    d0 = struct.unpack('<d', data[:8])[0]
                    if np.isfinite(d0) and 0.001 < abs(d0) < 1e12:
                        return 'double'
            except:
                pass

        # Check if it's small indices (byte values used to index into dictionary)
        if len(data) > 0:
            values = list(data[:min(50, len(data))])
            if max(values) < 200 and len(set(values)) < len(values) // 2 + 5:
                return 'indices'

        return 'unknown'

    def _extract_column_data(self) -> dict[str, ExtractColumn]:
        """Extract all column data from the file."""
        columns = {}

        # First, determine row count from Number of Records if available
        row_count = 0
        for name, entry in self.column_entries.items():
            if 'Number of Records' in name:
                data = self._read_block_data(entry.file_start)
                if data:
                    # Row count might be encoded as bytes (old format) or as uint64 (new format)
                    if len(data) >= 8:
                        # Try reading as uint64 - row count is typically the first value
                        potential_count = struct.unpack('<Q', data[:8])[0]
                        if 1 <= potential_count <= 10000000:  # Reasonable row count
                            row_count = potential_count
                            break
                    if row_count == 0 and len(data) > 0:
                        # Fallback to byte count (old format)
                        row_count = len(data)
                        break

        # If no Number of Records found, try to get row count from .dict entries
        # Many TDE files store row count as first 8 bytes of .dict data
        if row_count == 0:
            dict_counts = []
            for name, entry in self.column_entries.items():
                if '.dict' in name and '.1.dict' not in name:
                    data = self._read_block_data(entry.file_start)
                    if data and len(data) >= 8:
                        potential_count = struct.unpack('<Q', data[:8])[0]
                        # Row count should be reasonable (1 to 10 million)
                        if 1 <= potential_count <= 10000000:
                            dict_counts.append(potential_count)
            # Use the most common count (mode) as row count
            if dict_counts:
                from collections import Counter
                count_freq = Counter(dict_counts)
                row_count = count_freq.most_common(1)[0][0]

        # Group entries by base column name
        base_columns = {}
        for name, entry in self.column_entries.items():
            # Skip system columns
            if any(x in name for x in ['COLUMN', 'TABLE', 'SCHEMA', 'DUAL', 'ACTIVE',
                                        'PARENT', 'ID', 'KEY', 'VALUE', 'Metadata', 'Records']):
                continue

            # Parse column name - remove various suffixes
            base_name = name
            for suffix in ['.1.data', '.1.dict', '.dict', '.data']:
                base_name = base_name.replace(suffix, '')

            if base_name not in base_columns:
                base_columns[base_name] = {}

            if '.1.data' in name:
                # String dictionary (the actual strings)
                base_columns[base_name]['string_dict_entry'] = entry
            elif '.1.dict' in name:
                # String indices (maps rows to dictionary entries)
                base_columns[base_name]['string_index_entry'] = entry
            elif '.dict' in name:
                # May contain indices or double values
                base_columns[base_name]['dict_entry'] = entry
            elif '.data' in name:
                # Raw data
                base_columns[base_name]['data_entry'] = entry

        # Process each column
        for col_name, entries in base_columns.items():
            column = ExtractColumn(name=col_name, datatype='unknown')

            # Read .1.data entry - could be string dictionary, doubles, or indices
            if 'string_dict_entry' in entries:
                entry = entries['string_dict_entry']
                data = self._read_block_data(entry.file_start)
                if data:
                    # First, detect what type of data this actually is
                    data_type = self._determine_column_type(col_name, data)

                    if data_type == 'string_dict':
                        # It's a string dictionary
                        strings = self._read_string_dictionary(data)
                        if strings:
                            column.dictionary = strings
                            column.datatype = 'string'
                    elif data_type == 'double':
                        # It's double data directly in .1.data
                        doubles = self._read_doubles(data)
                        if row_count > 0 and len(doubles) > row_count:
                            doubles = doubles[:row_count]
                        if doubles:
                            column.values = doubles
                            column.datatype = 'double'
                    elif data_type == 'indices':
                        # It's index data - store for later use with dictionary
                        column.indices = list(data[:row_count] if row_count > 0 else data)

            # Read .dict entry (may contain indices for strings OR double values OR string dictionary)
            if 'dict_entry' in entries:
                entry = entries['dict_entry']
                data = self._read_block_data(entry.file_start)
                if data:
                    col_type = self._determine_column_type(col_name, data)

                    # If .1.data had indices, .dict might have the string dictionary
                    if column.indices and not column.dictionary and col_type == 'string_dict':
                        strings = self._read_string_dictionary(data)
                        if strings:
                            column.dictionary = strings
                            column.datatype = 'string'
                    elif col_type == 'indices' and column.dictionary:
                        # This contains indices for the string dictionary
                        column.indices = list(data[:row_count] if row_count > 0 else data)
                    elif col_type == 'double' and not column.values:
                        doubles = self._read_doubles(data)
                        if row_count > 0 and len(doubles) > row_count:
                            doubles = doubles[:row_count]
                        column.values = doubles
                        column.datatype = 'double'
                    elif not column.dictionary and not column.values:
                        # Try to detect if it's double data
                        if col_type == 'double':
                            doubles = self._read_doubles(data)
                            if row_count > 0 and len(doubles) > row_count:
                                column.values = doubles[:row_count]
                            else:
                                column.values = doubles
                            column.datatype = 'double'

            # Read .data entry (may contain raw numeric data)
            if 'data_entry' in entries:
                entry = entries['data_entry']
                data = self._read_block_data(entry.file_start)
                if data and not column.values:
                    # Check if this looks like double data
                    if len(data) >= 8:
                        # Verify it's not another index block
                        if data[:4] != INDEX_BLOCK_MARKER:
                            col_type = self._determine_column_type(col_name, data)
                            if col_type == 'double':
                                doubles = self._read_doubles(data)
                                if row_count > 0 and len(doubles) > row_count:
                                    column.values = doubles[:row_count]
                                else:
                                    column.values = doubles
                                column.datatype = 'double'

            if column.dictionary or column.values or column.indices:
                columns[col_name] = column

        # Store row count for later use
        self._row_count = row_count

        return columns

    def _build_dataframe(self) -> pd.DataFrame:
        """Build pandas DataFrame from extracted columns."""
        # Use stored row count, or calculate from values/indices
        row_count = getattr(self, '_row_count', 0)

        # Also check values/indices if row_count not set
        if row_count == 0:
            for col in self.extract_columns.values():
                if col.values:
                    row_count = max(row_count, len(col.values))
                elif col.indices:
                    row_count = max(row_count, len(col.indices))

        if row_count == 0:
            return pd.DataFrame()

        df_data = {}

        for col_name, col in self.extract_columns.items():
            if col.datatype == 'double' and col.values:
                # Use values directly, truncate to row_count
                df_data[col_name] = col.values[:row_count]

            elif col.datatype == 'string' and col.dictionary:
                if col.indices:
                    # Map indices to dictionary values
                    mapped = []
                    for idx in col.indices[:row_count]:
                        if 0 <= idx < len(col.dictionary):
                            mapped.append(col.dictionary[idx])
                        else:
                            mapped.append(None)
                    df_data[col_name] = mapped
                else:
                    # If no indices, distribute dictionary values across rows
                    # This is a fallback when index data isn't found
                    values = []
                    items_per_value = max(1, row_count // len(col.dictionary))
                    for i, val in enumerate(col.dictionary):
                        count = items_per_value if i < len(col.dictionary) - 1 else row_count - len(values)
                        values.extend([val] * count)
                    df_data[col_name] = values[:row_count]

            elif col.indices and not col.dictionary and not col.values:
                # Indices without dictionary - use indices as integer values
                df_data[col_name] = list(col.indices[:row_count])

        # Ensure all columns have same length
        for col_name in df_data:
            if len(df_data[col_name]) < row_count:
                df_data[col_name].extend([None] * (row_count - len(df_data[col_name])))

        return pd.DataFrame(df_data)

    def parse(self) -> pd.DataFrame:
        """
        Parse the TDE file and return a DataFrame.

        Returns:
            pandas DataFrame containing the extract data.
        """
        # Read entire file
        with open(self.file_path, 'rb') as f:
            self.content = f.read()

        # Parse header
        self.header = self._read_header()

        # Read XML metadata
        self.xml_metadata = self._read_xml_metadata()

        # Find and parse Extract table index
        index_pos = self._find_extract_index_block()
        if index_pos > 0:
            self.column_entries = self._parse_index_entries(index_pos)

        # Extract column data
        self.extract_columns = self._extract_column_data()

        # Build DataFrame
        return self._build_dataframe()

    def get_metadata(self) -> dict[str, Any]:
        """Get file metadata."""
        return {
            'file_path': self.file_path,
            'format_version': self.header.format_version if self.header else None,
            'file_size': self.header.file_size if self.header else None,
            'xml_metadata': self.xml_metadata,
            'columns': list(self.extract_columns.keys()),
            'column_types': {name: col.datatype for name, col in self.extract_columns.items()}
        }


def read_tde(file_path: str) -> pd.DataFrame:
    """
    Read a TDE file and return its contents as a pandas DataFrame.

    Args:
        file_path: Path to the TDE file.

    Returns:
        pandas DataFrame containing the extract data.
    """
    parser = TDEParser(file_path)
    return parser.parse()


def read_tde_metadata(file_path: str) -> dict[str, Any]:
    """
    Read TDE file metadata without fully parsing.

    Args:
        file_path: Path to the TDE file.

    Returns:
        Dictionary containing file metadata.
    """
    parser = TDEParser(file_path)
    parser.parse()
    return parser.get_metadata()


def main():
    """Command-line interface for pytde."""
    import sys

    if len(sys.argv) < 2:
        print("Usage: pytde <file.tde>")
        print("\nRead a Tableau Data Extract (TDE) file and display its contents.")
        sys.exit(1)

    file_path = sys.argv[1]

    print(f"Parsing TDE file: {file_path}")
    print("-" * 60)

    # Parse file
    df = read_tde(file_path)
    metadata = read_tde_metadata(file_path)

    print(f"Format version: {metadata['format_version']}")
    print(f"File size: {metadata['file_size']} bytes")
    print(f"Columns found: {metadata['columns']}")
    print(f"Column types: {metadata['column_types']}")

    print(f"\n{'='*60}")
    print(f"Shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    print(f"\nData types:")
    print(df.dtypes)
    print(f"\nFirst 10 rows:")
    print(df.head(10))

    # Show statistics for numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        print(f"\nNumeric column statistics:")
        print(df[numeric_cols].describe())


if __name__ == '__main__':
    main()
