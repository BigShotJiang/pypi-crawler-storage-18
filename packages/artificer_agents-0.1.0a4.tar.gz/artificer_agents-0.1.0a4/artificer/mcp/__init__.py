"""MCP client module for Artificer."""

from artificer.mcp.client import MCPClient

__all__ = [
    "MCPClient",
]
