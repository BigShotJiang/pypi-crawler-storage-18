"""Agent runtime loop."""

from __future__ import annotations

import json
import logging
import re
import sys
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel

from artificer.agents.actions import Action
from artificer.agents.context import WorkingMemory
from artificer.models.base import Tool

if TYPE_CHECKING:
    from artificer.agents.agent import Agent

logger = logging.getLogger("artificer.agents")
logger.setLevel(logging.WARNING)  # Default to WARNING; verbose mode lowers to DEBUG


def _configure_verbose_logging() -> None:
    """Configure the logger for verbose output if not already configured."""
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
        logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


def _parse_action(text: str) -> Action:
    """Parse Action from model response text.

    Extracts JSON from the response, handling markdown code blocks.
    """
    # Try to find JSON in code blocks first
    json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1)
    else:
        # Try to find raw JSON object
        json_match = re.search(r"\{.*\}", text, re.DOTALL)
        if json_match:
            json_str = json_match.group(0)
        else:
            raise ValueError(f"No JSON found in response: {text[:200]}")

    data = json.loads(json_str)
    return Action.model_validate(data)


class ToolCallRecord(BaseModel):
    """Record of a tool call."""

    tool_name: str
    arguments: dict[str, Any]
    result: Any
    iteration: int


class SubagentCallRecord(BaseModel):
    """Record of a subagent call."""

    subagent_name: str
    input: dict[str, Any]
    output: Any
    iteration: int


class RunResult(BaseModel, arbitrary_types_allowed=True):
    """Result of an agent execution."""

    output: BaseModel | None
    iterations: int
    termination_reason: Literal["done", "max_iterations", "error"]
    tool_calls: list[ToolCallRecord] = []
    subagent_calls: list[SubagentCallRecord] = []
    error: str | None = None


def _truncate(text: str, max_len: int = 200) -> str:
    """Truncate text for logging."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + "..."


async def run_agent(
    agent: Agent,
    input_data: BaseModel,
    *,
    verbose: bool = False,
) -> RunResult:
    """Execute an agent with the given input.

    The runtime loop:
    1. Build prompt (system + input + context + tools)
    2. Call model -> parse into Action
    3. Execute: CALL_TOOL | SPAWN_SUBAGENT | DONE
    4. Update context
    5. Repeat until DONE or max_iterations

    Args:
        agent: The agent configuration to run.
        input_data: Input data matching the agent's input schema.
        verbose: If True, log detailed execution info to stderr.
    """
    if verbose:
        _configure_verbose_logging()

    context = WorkingMemory()
    tools = await agent.mcp_client.get_tools(agent.tools) if agent.mcp_client else []
    tool_calls: list[ToolCallRecord] = []
    subagent_calls: list[SubagentCallRecord] = []

    for iteration in range(agent.max_iterations):
        logger.debug("[%s] Iteration %d", agent.name, iteration + 1)

        # 1. Build prompt
        messages = _build_messages(agent, input_data, context, tools)
        logger.debug("[%s] Calling model with %d messages", agent.name, len(messages))

        # 2. Call model and parse response
        try:
            response_text = await agent.model.call(messages)
            logger.debug(
                "[%s] Model response: %s", agent.name, _truncate(response_text)
            )
            action = _parse_action(response_text)
            logger.debug("[%s] Action: %s", agent.name, action.action)
        except Exception as e:
            logger.warning("[%s] Parse error: %s", agent.name, e)
            # Give the model feedback about the parse error and let it retry
            context.add_tool_result(
                "error",
                f"Failed to parse action: {e}. "
                "Remember to use the exact format: "
                '{"action": "CALL_TOOL", "tool_name": "...", "arguments": {...}}',
                iteration,
            )
            continue

        # 3. Execute action
        if action.action == "CALL_TOOL":
            if not action.tool_name:
                context.add_tool_result(
                    "error", "CALL_TOOL requires tool_name", iteration
                )
                continue
            if not agent.mcp_client:
                context.add_tool_result("error", "No MCP client configured", iteration)
                continue
            logger.debug(
                "[%s] Calling tool: %s with args: %s",
                agent.name,
                action.tool_name,
                action.arguments,
            )
            result: Any = await agent.mcp_client.call_tool(
                action.tool_name, action.arguments
            )
            logger.debug("[%s] Tool result: %s", agent.name, _truncate(str(result)))
            context.add_tool_result(action.tool_name, result, iteration)
            tool_calls.append(
                ToolCallRecord(
                    tool_name=action.tool_name,
                    arguments=action.arguments,
                    result=result,
                    iteration=iteration,
                )
            )

        elif action.action == "SPAWN_SUBAGENT":
            if not action.subagent_name:
                context.add_tool_result(
                    "error", "SPAWN_SUBAGENT requires subagent_name", iteration
                )
                continue
            subagent = _find_subagent(agent, action.subagent_name)
            if subagent is None:
                context.add_tool_result(
                    f"error:{action.subagent_name}",
                    f"Subagent '{action.subagent_name}' not found",
                    iteration,
                )
                continue

            logger.debug("[%s] Spawning subagent: %s", agent.name, action.subagent_name)
            # Parse input for subagent
            parsed_input = subagent.input_schema.model_validate(action.subagent_input)
            sub_result: RunResult = await run_agent(
                subagent, parsed_input, verbose=verbose
            )
            output_dict = sub_result.output.model_dump() if sub_result.output else None
            logger.debug("[%s] Subagent %s complete", agent.name, action.subagent_name)
            context.add_subagent_output(action.subagent_name, output_dict, iteration)
            subagent_calls.append(
                SubagentCallRecord(
                    subagent_name=action.subagent_name,
                    input=action.subagent_input,
                    output=output_dict,
                    iteration=iteration,
                )
            )

        elif action.action == "DONE":
            # Validate output against schema
            try:
                validated_output = agent.output_schema.model_validate(action.output)
                logger.info(
                    "[%s] Completed in %d iterations", agent.name, iteration + 1
                )
                return RunResult(
                    output=validated_output,
                    iterations=iteration + 1,
                    termination_reason="done",
                    tool_calls=tool_calls,
                    subagent_calls=subagent_calls,
                )
            except Exception as e:
                return RunResult(
                    output=None,
                    iterations=iteration + 1,
                    termination_reason="error",
                    tool_calls=tool_calls,
                    subagent_calls=subagent_calls,
                    error=f"Output validation failed: {e}",
                )

    logger.warning("[%s] Max iterations (%d) reached", agent.name, agent.max_iterations)
    return RunResult(
        output=None,
        iterations=agent.max_iterations,
        termination_reason="max_iterations",
        tool_calls=tool_calls,
        subagent_calls=subagent_calls,
    )


ACTION_FORMAT_INSTRUCTIONS = """
You must respond with a JSON object (in a ```json code block) representing your action.

Action types:
1. CALL_TOOL - Call an MCP tool
   {"action": "CALL_TOOL", "tool_name": "<name>", "arguments": {<args>}}

2. SPAWN_SUBAGENT - Delegate to a subagent
   {"action": "SPAWN_SUBAGENT", "subagent_name": "<name>", "subagent_input": {<input>}}

3. DONE - Complete with final output
   {"action": "DONE", "output": {<output matching output schema>}}

Only respond with ONE action per message. Do not include text outside the JSON block.
""".strip()


def _build_messages(
    agent: Agent,
    input_data: BaseModel,
    context: WorkingMemory,
    tools: list[Tool],
) -> list[dict[str, Any]]:
    """Build messages for model prompt."""
    # Build output schema info
    output_schema_info = json.dumps(agent.output_schema.model_json_schema(), indent=2)

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": agent.system_prompt},
        {"role": "system", "content": ACTION_FORMAT_INSTRUCTIONS},
        {
            "role": "system",
            "content": f"Output schema (for DONE action):\n{output_schema_info}",
        },
        {
            "role": "user",
            "content": f"Input:\n{input_data.model_dump_json(indent=2)}",
        },
    ]

    # Add available tools info
    if tools:
        tool_info = "\n".join(
            f"- {t.name}: {t.description}\n  Parameters: {json.dumps(t.parameters)}"
            for t in tools
        )
        messages.append(
            {
                "role": "system",
                "content": f"Available tools:\n{tool_info}",
            }
        )

    # Add available subagents info with full schemas
    if agent.subagents:
        subagent_parts = []
        for s in agent.subagents:
            input_schema = json.dumps(s.input_schema.model_json_schema(), indent=2)
            output_schema = json.dumps(s.output_schema.model_json_schema(), indent=2)
            subagent_parts.append(
                f"- {s.name}:\n"
                f"  Input schema:\n{input_schema}\n"
                f"  Output schema:\n{output_schema}"
            )
        messages.append(
            {
                "role": "system",
                "content": "Available subagents:\n" + "\n".join(subagent_parts),
            }
        )

    # Add context from previous iterations
    messages.extend(context.to_messages())

    return messages


def _find_subagent(agent: Agent, name: str) -> Agent | None:
    """Find a subagent by name."""
    for subagent in agent.subagents:
        if subagent.name == name:
            return subagent
    return None
