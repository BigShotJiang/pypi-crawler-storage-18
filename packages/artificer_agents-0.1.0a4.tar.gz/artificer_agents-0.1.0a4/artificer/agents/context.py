"""Context management for agent execution."""

from typing import Any, Literal

from pydantic import BaseModel


class ContextEntry(BaseModel):
    """A single entry in working memory."""

    type: Literal["tool_result", "subagent_output"]
    name: str
    content: Any
    iteration: int


class WorkingMemory:
    """Bounded working memory for agent execution.

    Stores tool results and subagent outputs, converting them
    to messages for the model prompt.
    """

    def __init__(self, max_entries: int = 100) -> None:
        """Initialize working memory.

        Args:
            max_entries: Maximum number of entries to retain.
        """
        self._entries: list[ContextEntry] = []
        self._max_entries = max_entries

    def add_tool_result(self, tool_name: str, result: Any, iteration: int) -> None:
        """Add a tool result to memory."""
        self._entries.append(
            ContextEntry(
                type="tool_result",
                name=tool_name,
                content=result,
                iteration=iteration,
            )
        )
        self._enforce_bounds()

    def add_subagent_output(
        self, subagent_name: str, output: Any, iteration: int
    ) -> None:
        """Add a subagent output to memory."""
        self._entries.append(
            ContextEntry(
                type="subagent_output",
                name=subagent_name,
                content=output,
                iteration=iteration,
            )
        )
        self._enforce_bounds()

    def to_messages(self) -> list[dict[str, Any]]:
        """Convert working memory to message format for model prompt."""
        messages: list[dict[str, Any]] = []

        for entry in self._entries:
            if entry.type == "tool_result":
                messages.append(
                    {
                        "role": "user",
                        "content": f"[Tool Result: {entry.name}]\n{entry.content}",
                    }
                )
            elif entry.type == "subagent_output":
                messages.append(
                    {
                        "role": "user",
                        "content": f"[Subagent Output: {entry.name}]\n{entry.content}",
                    }
                )

        return messages

    def _enforce_bounds(self) -> None:
        """Remove oldest entries if exceeding max."""
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries :]

    def __len__(self) -> int:
        return len(self._entries)
