"""Action types for agent runtime."""

from typing import Any, Literal

from pydantic import BaseModel, Field


class Action(BaseModel):
    """Agent action response.

    The model must return exactly one action per iteration.
    """

    action: Literal["CALL_TOOL", "SPAWN_SUBAGENT", "DONE"] = Field(
        description="The type of action to take"
    )
    tool_name: str | None = Field(
        default=None, description="Name of the MCP tool to call (for CALL_TOOL)"
    )
    arguments: dict[str, Any] = Field(
        default_factory=dict,
        description="Arguments for tool call (for CALL_TOOL)",
    )
    subagent_name: str | None = Field(
        default=None, description="Name of subagent to spawn (for SPAWN_SUBAGENT)"
    )
    subagent_input: dict[str, Any] = Field(
        default_factory=dict,
        description="Input for subagent (for SPAWN_SUBAGENT)",
    )
    output: dict[str, Any] = Field(
        default_factory=dict,
        description="Final output matching schema (for DONE)",
    )
