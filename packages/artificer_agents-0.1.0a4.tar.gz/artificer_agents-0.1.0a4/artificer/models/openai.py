"""OpenAI model implementation."""

from typing import Any

from openai import AsyncOpenAI

from artificer.models.base import Model


class OpenAIModel(Model):
    """OpenAI model implementation."""

    def __init__(
        self,
        model: str = "gpt-4o",
        client: AsyncOpenAI | None = None,
    ) -> None:
        """Initialize OpenAI model.

        Args:
            model: Model identifier (e.g., "gpt-4o", "gpt-4o-mini").
            client: Optional AsyncOpenAI client. Created if not provided.
        """
        self._model = model
        self._client = client or AsyncOpenAI()

    async def call(self, messages: list[dict[str, Any]]) -> str:
        """Call OpenAI model and return text response."""
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=messages,  # type: ignore[arg-type]
        )

        content = response.choices[0].message.content
        if content is None:
            raise ValueError("Model returned no content")

        return content
