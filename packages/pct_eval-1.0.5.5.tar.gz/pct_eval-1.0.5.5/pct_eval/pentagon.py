import math
from shapely.geometry import Polygon

# Base functions
def distance(p1, p2):
    """Calculate Euclidean distance between two points."""
    # return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])     # --> better numerical stability and overflow handling

def angle(a, b, c):
    """
    Angle at point b formed by points (a, b, c).
    Uses the law of cosines.
    """
    ab = distance(a, b)
    bc = distance(b, c)
    ac = distance(a, c)
    if ab * bc == 0:
        return 0
    
    cos_theta = (ab**2 + bc**2 - ac**2) / (2 * ab * bc)
    cos_theta = max(-1, min(1, cos_theta))  # Clamp to avoid numerical issues
    return math.degrees(math.acos(cos_theta))

def is_pentagon(
        points,
        LENGTH_TOL = 15,
        ANGLE_RANGE=(45, 175)
):
    """
    Check if a set of 5 points forms a pentagon.
    
    LENGTH_TOL: allowed relative difference between shortest and longest edges
    ANGLE_RANGE: acceptable range for internal angles

    TODO: improve logic + check if this is working well
    """
    if len(points) != 5:
        return False

    # Compute edges
    edges = [distance(points[i], points[(i+1)%5]) for i in range(5)]
    min_len, max_len = min(edges), max(edges)

    if max_len / min_len > LENGTH_TOL:  # edge lengths too different
        cond1 = False
    else: 
        cond1 = True

    # Compute angles
    angles = [angle(points[i-1], points[i], points[(i+1)%5]) for i in range(5)]
    if any(not (ANGLE_RANGE[0] <= ang <= ANGLE_RANGE[1]) for ang in angles):
        cond2 = False
    else: 
        cond2 = True

    return cond2 or (cond1 and cond2)



# ----------------------------------------
# Helper functions
# TODO: test these functions
# ----------------------------------------

def fix_polygon(coords):
    # --- Helper: fix invalid polygons (self-intersections) ---
    poly = Polygon(coords)
    if not poly.is_valid:
        poly = poly.buffer(0)
    return poly

def is_convex(coords):
    if len(coords) < 4:
        return False

    direction = 0
    n = len(coords)

    for i in range(n):
        p0 = coords[i]
        p1 = coords[(i+1) % n]
        p2 = coords[(i+2) % n]

        dx1, dy1 = p1[0]-p0[0], p1[1]-p0[1]
        dx2, dy2 = p2[0]-p1[0], p2[1]-p1[1]

        cross = dx1 * dy2 - dy1 * dx2  # 2D cross product

        if cross != 0:  # ignore collinear
            if direction == 0:
                direction = 1 if cross > 0 else -1
            elif direction * cross < 0:
                return False

    return True

def compute_angles(coords):
    angles = []
    n = len(coords)
    for i in range(n):
        p_prev = coords[(i-1) % n]
        p = coords[i]
        p_next = coords[(i+1) % n]

        # vectors
        v1 = (p_prev[0]-p[0], p_prev[1]-p[1])
        v2 = (p_next[0]-p[0], p_next[1]-p[1])

        # dot product & magnitudes
        dot = v1[0]*v2[0] + v1[1]*v2[1]
        mag1 = math.sqrt(v1[0]**2 + v1[1]**2)
        mag2 = math.sqrt(v2[0]**2 + v2[1]**2)

        if mag1 * mag2 == 0:
            angles.append(None)
        else:
            cos_angle = max(-1, min(1, dot / (mag1*mag2)))
            angle_deg = math.degrees(math.acos(cos_angle))
            angles.append(angle_deg)

    return angles