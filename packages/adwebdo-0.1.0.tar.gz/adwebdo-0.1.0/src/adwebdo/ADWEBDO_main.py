from pylab import *
import pandas as pd
import numpy as np
from numpy import *
import operator
import math
from math import pi
import matplotlib.pyplot as plt
import random
np.set_printoptions(suppress=True)
import numpy.linalg


def initializeMembershipMatrix():
    membership_mat = list()
    for i in range(n_posi):
        random_num_list = [random.random() for i in range(k1)]
        summation = sum(random_num_list)
        temp_list = [x / summation for x in random_num_list]
        membership_mat.append(temp_list)
    return membership_mat

def calculateClusterCenter(membership_mat):
    cluster_mem_val = zip(*membership_mat)
    cluster_centers = list()
    cluster_mem_val_list = list(cluster_mem_val)
    for j in range(k1):
        x = cluster_mem_val_list[j]
        xraised = [e ** m for e in x]
        denominator = sum(xraised)
        temp_num = list()
        for i in range(n_posi):
            data_point = list(df.iloc[i])
            prod = [xraised[i] * val for val in data_point]
            temp_num.append(prod)
        numerator = map(sum, zip(*temp_num))
        center = [z / denominator for z in numerator]
        cluster_centers.append(center)
    return cluster_centers

def updateMembershipValue(membership_mat, cluster_centers):
    data = []
    for i in range(n_posi):
        x = list(df.iloc[i])
        data.append(x)
        distances = [np.linalg.norm(list(map(operator.sub, x, cluster_centers[j]))) for j in range(k1)]
        for j in range(k1):
            den = sum([math.pow(float(distances[j] / distances[c]), 2) for c in range(k1)])
            membership_mat[i][j] = float(1 / den)
    return membership_mat, data

def getClusters(membership_mat):
    cluster_labels = list()
    for i in range(n_posi):
        max_val, idx = max((val, idx) for (idx, val) in enumerate(membership_mat[i]))
        cluster_labels.append(idx)
    return cluster_labels
def fuzzyCMeansClustering1():
    membership_mat = initializeMembershipMatrix()
    curr = 0
    while curr <= MAX_ITER:
        cluster_centers = calculateClusterCenter(membership_mat)
        membership_mat, data = updateMembershipValue(membership_mat, cluster_centers)
        cluster_labels = getClusters(membership_mat)
        curr += 1
    print(membership_mat)
    return cluster_labels, cluster_centers, data, membership_mat

def xie_beni(membership_mat, center, data):
    sum_cluster_distance = 0
    min_cluster_center_distance = np.inf
    for i in range(k1):
        for j in range(n_posi):
            sum_cluster_distance = sum_cluster_distance + membership_mat[j][i] ** 2 * sum(
                power(data[j, :] - center[i, :], 2))
    for i in range(k1 - 1):
        for j in range(i + 1, k1):
            cluster_center_distance = sum(power(center[i, :] - center[j, :], 2))  # 计算类间距离
            if cluster_center_distance < min_cluster_center_distance:
                min_cluster_center_distance = cluster_center_distance
    return sum_cluster_distance / (n_posi* min_cluster_center_distance)




def initializeMembershipMatrix2():
    membership_mat = list()
    for i in range(n_nega):
        random_num_list = [random.random() for i in range(k2)]
        summation = sum(random_num_list)
        temp_list = [x / summation for x in random_num_list]
        membership_mat.append(temp_list)
    return membership_mat

def calculateClusterCenter2(membership_mat):
    cluster_mem_val = zip(*membership_mat)
    cluster_centers = list()
    cluster_mem_val_list = list(cluster_mem_val)
    for j in range(k2):
        x = cluster_mem_val_list[j]
        xraised = [e ** m for e in x]
        denominator = sum(xraised)
        temp_num = list()
        for i in range(n_nega):
            data_point = list(df.iloc[i])
            prod = [xraised[i] * val for val in data_point]
            temp_num.append(prod)
        numerator = map(sum, zip(*temp_num))
        center = [z / denominator for z in numerator]
        cluster_centers.append(center)
    return cluster_centers

def updateMembershipValue2(membership_mat, cluster_centers):
    data = []
    for i in range(n_nega):
        x = list(df.iloc[i])
        data.append(x)
        distances = [np.linalg.norm(list(map(operator.sub, x, cluster_centers[j]))) for j in range(k2)]
        for j in range(k2):
            den = sum([math.pow(float(distances[j] / distances[c]), 2) for c in range(k2)])
            membership_mat[i][j] = float(1 / den)
    return membership_mat, data

def getClusters2(membership_mat):
    cluster_labels = list()
    for i in range(n_nega):
        max_val, idx = max((val, idx) for (idx, val) in enumerate(membership_mat[i]))
        cluster_labels.append(idx)
    return cluster_labels

def fuzzyCMeansClustering2():

    membership_mat = initializeMembershipMatrix2()
    curr = 0
    while curr <= MAX_ITER:
        cluster_centers = calculateClusterCenter2(membership_mat)
        membership_mat, data = updateMembershipValue2(membership_mat, cluster_centers)
        cluster_labels = getClusters2(membership_mat)
        curr += 1
    print(membership_mat)
    return cluster_labels, cluster_centers, data, membership_mat

def xie_beni2(membership_mat, center, data):
    sum_cluster_distance = 0
    min_cluster_center_distance = np.inf
    for i in range(k2):
        for j in range(n_nega):
            sum_cluster_distance = sum_cluster_distance + membership_mat[j][i] ** 2 * sum(
                power(data[j, :] - center[i, :], 2))
    for i in range(k2 - 1):
        for j in range(i + 1, k2):
            cluster_center_distance = sum(power(center[i, :] - center[j, :], 2))  # 计算类间距离
            if cluster_center_distance < min_cluster_center_distance:
                min_cluster_center_distance = cluster_center_distance
    return sum_cluster_distance / (n_nega* min_cluster_center_distance)

if __name__ == '__main__':
    df_full = pd.read_csv(".csv")
    columns = list(df_full.columns)
    features = columns[:len(columns) - 1]
    df = df_full[features]
    num_attr = len(df.columns)
    MAX_ITER = 500
    n = len(df)
    m = 2.00
    df_array = np.array(df_full)
    df_X = df_array[:, 0: num_attr]
    df_y = df_array[:, num_attr].T
    posi_X = []
    posi_y = []
    nega_X = []
    nega_y = []
    for i in range(n):
        if df_y[i] == 1:
            posi_X.append(df_X[i])
            posi_y.append(df_y[i])
            i += 1
        else:
            nega_X.append(df_X[i])
            nega_y.append(df_y[i])
            i += 1
    n_posi = len(posi_X)
    n_nega = len(nega_X)
    k1 = 2
    k2 = 3
    labels, centers, data, membership = fuzzyCMeansClustering1()
    labels2, centers2, data2, membership2 = fuzzyCMeansClustering2()
    center_array = np.array(centers)
    label = np.array(labels)
    datas = np.array(data)
    center_array2 = np.array(centers2)
    label2 = np.array(labels2)
    datas2 = np.array(data2)
    data_0_X = datas[label == 0]
    data_1_X = datas[label == 1]
    data2_0_X = datas2[label2 == 0]
    data2_1_X = datas2[label2 == 1]
    data2_2_X = datas2[label2 == 2]
    data_0_y = []
    for i in range(len(data_0_X)):
        data_0_y.append(1)
        i+=1
    data_1_y = []
    for i in range(len(data_1_X)):
        data_1_y.append(1)
        i += 1
    data2_0_y = []
    for i in range(len(data2_0_X)):
        data2_0_y.append(0)
        i += 1
    data2_1_y = []
    for i in range(len(data2_1_X)):
        data2_1_y.append(0)
        i += 1
    data2_2_y = []
    for i in range(len(data2_2_X)):
        data2_2_y.append(0)
        i += 1
    df_0_X = pd.DataFrame(data_0_X)
    df_0_y_series = pd.Series(data_0_y)
    df_0_y = pd.DataFrame(data_0_y)
    df_0_all = pd.concat([df_0_X, df_0_y], axis=1)
    df_1_X = pd.DataFrame(data_1_X)
    df_1_y_series = pd.Series(data_1_y)
    df_1_y = pd.DataFrame(data_1_y)
    df_1_all = pd.concat([df_1_X, df_1_y], axis=1)
    df2_0_X = pd.DataFrame(data2_0_X)
    df2_0_y_series = pd.Series(data2_0_y)
    df2_0_y = pd.DataFrame(data2_0_y)
    df2_0_all = pd.concat([df2_0_X, df2_0_y], axis=1)
    df2_1_X = pd.DataFrame(data2_1_X)
    df2_1_y_series = pd.Series(data2_1_y)
    df2_1_y = pd.DataFrame(data2_1_y)
    df2_1_all = pd.concat([df2_1_X, df2_1_y], axis=1)
    df2_2_X = pd.DataFrame(data2_2_X)
    df2_2_y_series = pd.Series(data2_2_y)
    df2_2_y = pd.DataFrame(data2_2_y)
    df2_2_all = pd.concat([df2_2_X, df2_2_y], axis=1)
    G = (n - n_posi) - n_posi
    n_0 = len(data_0_y)
    n_1 = len(data_1_y)
    n2_0 = len(data2_0_y)
    n2_1 = len(data2_1_y)
    n2_2 = len(data2_2_y)
    L_0 = []
    for j in range(k2):
        L_0.append(sqrt(sum((center_array[0]- center_array2[j]) ** 2)))
    j += 1
    L_0 = np.mean(L_0)
    R_0 = 1/exp(L_0)
    L_1 = []
    for j in range(k2):
        L_1.append(sqrt(sum((center_array[1] - center_array2[j]) ** 2)))
    j += 1
    L_1 = np.mean(L_1)
    R_1 = 1 / exp(L_1)
    minR = min(R_0, R_1)
    maxR = max(R_0, R_1)
    R_0_stand = (R_0 - minR) / (maxR - minR)
    R_1_stand = (R_1 - minR) / (maxR - minR)
    n_0 = len(data_0_y)
    n_1 = len(data_1_y)
    minn = min(n_0, n_1 )
    maxn = max(n_0, n_1 )
    n_0_stand = (n_0 - minn) / (maxn - minn)
    n_1_stand = (n_1 - minn) / (maxn - minn)
    alpha = 0.1
    beta = 0.9
    Z_0 = alpha * (R_0_stand) + beta * (n_0_stand)
    Z_1 = alpha * (R_1_stand) + beta * (n_1_stand)
    Z_0_nor = Z_0 / (Z_0 + Z_1)
    Z_1_nor = Z_1 / (Z_0 + Z_1)
    g_0 = int(Z_0_nor * G)
    g_1 = int(Z_1_nor * G)
    X_syn_0 = []
    y_syn_0 = []
    alpha = np.random.uniform(0, 1)
    if g_0 != 0:
        for a in range(g_0):
            fea_mean_all = []
            fea_var_all = []
            for j in range(num_attr):
                fea_eve = []
                for i in range(n_0):
                    fea_eve.append(data_0_X[i][j])
                fea_mean_all.append(np.mean(fea_eve))
                fea_var_all.append(np.var(fea_eve))
            new_eve = []
            for b in range(num_attr):
                new_eve.append(
                    np.random.uniform(fea_mean_all[b] - alpha * fea_var_all[b], fea_mean_all[b] + alpha * fea_var_all[b]))
            X_syn_0.append(np.array(new_eve))
        X_syn_0_df=pd.DataFrame(np.array(X_syn_0))
        y_syn_0_df=pd.Series(np.ones(len(X_syn_0)).astype(np.int32))
    else:
        X_syn_0_df = pd.DataFrame(np.array([]))
        y_syn_0_df = pd.Series(np.array([]))
    X_syn_1 = []
    y_syn_1 = []
    alpha = np.random.uniform(0, 1)
    if g_1 != 0:
        for a in range(g_1):
            fea_mean_all = []
            fea_var_all = []
            for j in range(num_attr):
                fea_eve = []
                for i in range(n_1):
                    fea_eve.append(data_1_X[i][j])
                fea_mean_all.append(np.mean(fea_eve))
                fea_var_all.append(np.var(fea_eve))
            new_eve = []
            for b in range(num_attr):
                new_eve.append(
                    np.random.uniform(fea_mean_all[b] - alpha * fea_var_all[b], fea_mean_all[b] + alpha * fea_var_all[b]))
            X_syn_1.append(np.array(new_eve))
        X_syn_1_df = pd.DataFrame(np.array(X_syn_1))
        y_syn_1_df = pd.Series(np.ones(len(X_syn_1)).astype(np.int32))
    else:
        X_syn_1_df = pd.DataFrame(np.array([]))
        y_syn_1_df = pd.Series(np.array([]))
    nega_X = pd.DataFrame(np.array(nega_X))
    nega_y = pd.Series(np.array(nega_y))
    X_resampled_all = []
    y_resampled_all = []
    if X_syn_0_df.empty == False:
        X_resampled_all = np.vstack([nega_X, X_syn_0_df])
        y_resampled_all = np.hstack((nega_y, y_syn_0_df))
    X_resampled_all_X = X_resampled_all
    y_resampled_all_y = y_resampled_all
    if X_syn_1_df.empty == False:
        X_resampled_all = np.vstack([X_resampled_all_X, X_syn_1_df])
        y_resampled_all = np.hstack((y_resampled_all_y, y_syn_1_df))
    X_resampled_all_X = X_resampled_all
    y_resampled_all_y = y_resampled_all
    X_resampled_all = np.vstack([X_resampled_all_X,pd.DataFrame(np.array(posi_X))])
    y_resampled_all = np.hstack((y_resampled_all_y,pd.Series(np.array(posi_y))))
    X_resampled_all_PD = pd.DataFrame(X_resampled_all)
    y_resampled_all_PD = pd.DataFrame(y_resampled_all)
    all_resampled_PD = pd.concat([X_resampled_all_PD, y_resampled_all_PD],axis=1)
    all_resampled_PD.to_csv('.csv',index=False)