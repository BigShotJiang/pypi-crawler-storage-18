"""Polars engine and data types."""

import builtins
import dataclasses
import datetime
import decimal
import inspect
import warnings
from collections.abc import Iterable, Mapping, Sequence
from typing import (
    Any,
    Literal,
    Optional,
    TypedDict,
    Union,
    overload,
)

import polars as pl
from packaging import version
from polars._typing import ColumnNameOrSelector, PythonDataType
from polars.datatypes import DataTypeClass
from typing_extensions import NotRequired

from pandera import dtypes, errors
from pandera.api.polars.types import PolarsData
from pandera.constants import CHECK_OUTPUT_KEY
from pandera.dtypes import immutable
from pandera.engines import engine

PolarsDataContainer = Union[pl.LazyFrame, PolarsData]
PolarsDataType = Union[DataTypeClass, pl.DataType]

COERCION_ERRORS = (
    TypeError,
    pl.exceptions.InvalidOperationError,
    pl.exceptions.ComputeError,
)


SchemaDict = Mapping[str, PolarsDataType]


def polars_version() -> version.Version:
    """Return the polars version."""

    return version.parse(pl.__version__)


def convert_py_dtype_to_polars_dtype(dtype):
    if isinstance(dtype, DataTypeClass):
        return dtype

    if polars_version().release < (1, 0, 0):
        from polars.datatypes import py_type_to_dtype

        conversion_fn = py_type_to_dtype
    else:
        from polars.datatypes._parse import parse_py_type_into_dtype

        conversion_fn = parse_py_type_into_dtype

    return conversion_fn(dtype)


def polars_object_coercible(
    data_container: PolarsData, type_: PolarsDataType
) -> pl.LazyFrame:
    """Checks whether a polars object is coercible with respect to a type."""
    key = data_container.key or "*"

    # do a strict cast for list types since is_not_null() cannot correctly
    # evaluate null values in lists.
    strict = isinstance(type_, pl.List)
    coercible = data_container.lazyframe.cast(
        {key: type_}, strict=strict
    ).select(pl.col(key).is_not_null())
    # reduce to a single boolean column
    return coercible.select(pl.all_horizontal(key).alias(CHECK_OUTPUT_KEY))


def polars_failure_cases_from_coercible(
    data_container: PolarsData,
    is_coercible: pl.LazyFrame,
) -> pl.DataFrame:
    """Get the failure cases resulting from trying to coerce a polars object."""
    return (
        pl.concat(
            items=[data_container.lazyframe, is_coercible], how="horizontal"
        )
        .filter(pl.col(CHECK_OUTPUT_KEY).not_())
        .collect()
    )


def polars_coerce_failure_cases(
    data_container: PolarsData,
    type_: Any,
) -> tuple[pl.DataFrame, pl.DataFrame]:
    """
    Get the failure cases resulting from trying to coerce a polars object
    into particular data type.
    """
    try:
        is_coercible = polars_object_coercible(data_container, type_)
    except (TypeError, pl.exceptions.InvalidOperationError):
        is_coercible = data_container.lazyframe.with_columns(
            **{CHECK_OUTPUT_KEY: pl.lit(False)}
        ).select(CHECK_OUTPUT_KEY)

    try:
        failure_cases = polars_failure_cases_from_coercible(
            data_container, is_coercible
        )
        is_coercible_df = is_coercible.collect()
    except COERCION_ERRORS:
        # If coercion fails, all of the relevant rows are failure cases
        failure_cases = data_container.lazyframe.select(
            data_container.key or "*"
        ).collect()

        is_coercible_df = (
            data_container.lazyframe.with_columns(
                **{CHECK_OUTPUT_KEY: pl.lit(False)}
            ).select(CHECK_OUTPUT_KEY)
        ).collect()

    return is_coercible_df, failure_cases


@immutable(init=True)
class DataType(dtypes.DataType):
    """Base `DataType` for boxing Polars data types."""

    type: Union[builtins.type[pl.DataType], DataTypeClass] = dataclasses.field(
        repr=False, init=False
    )

    def __init__(self, dtype: Any | None = None):
        super().__init__()

        try:
            object.__setattr__(
                self, "type", convert_py_dtype_to_polars_dtype(dtype)
            )
        except ValueError:
            object.__setattr__(self, "type", pl.Object)

        dtype_cls = dtype if inspect.isclass(dtype) else dtype.__class__
        warnings.warn(
            f"'{dtype_cls}' support is not guaranteed.\n"
            + "Usage Tip: Consider writing a custom "
            + "pandera.dtypes.DataType or opening an issue at "
            + "https://github.com/pandera-dev/pandera"
        )

    def __post_init__(self):
        # this method isn't called if __init__ is defined
        if not isinstance(self.type, DataTypeClass):
            try:
                object.__setattr__(
                    self, "type", convert_py_dtype_to_polars_dtype(self.type)
                )
            except ValueError:
                object.__setattr__(self, "type", pl.Object)

    def coerce(self, data_container: PolarsDataContainer) -> pl.LazyFrame:
        """Coerce data container to the data type."""
        if isinstance(data_container, pl.LazyFrame):
            data_container = PolarsData(data_container)

        dtypes: Union[
            Mapping[
                Union[ColumnNameOrSelector, PolarsDataType],
                Union[PolarsDataType, PythonDataType],
            ],
            PolarsDataType,
        ]

        if data_container.key == "*":
            dtypes = self.type
        else:
            dtypes = {data_container.key: self.type}

        return data_container.lazyframe.cast(dtypes, strict=True)

    def try_coerce(self, data_container: PolarsDataContainer) -> pl.LazyFrame:
        """Coerce data container to the data type,
        raises a :class:`~pandera.errors.ParserError` if the coercion fails
        :raises: :class:`~pandera.errors.ParserError`: if coercion fails
        """
        from pandera.api.polars.utils import get_lazyframe_schema

        if isinstance(data_container, pl.LazyFrame):
            data_container = PolarsData(data_container)

        try:
            lf = self.coerce(data_container)
            lf.collect()
            return lf
        except COERCION_ERRORS as exc:
            _key = (
                ""
                if data_container.key == "*"
                else f"'{data_container.key}' in"
            )
            is_coercible, failure_cases = polars_coerce_failure_cases(
                data_container=data_container, type_=self.type
            )
            if data_container.key != "*":
                failure_cases = failure_cases.select(data_container.key)
            raise errors.ParserError(
                f"Could not coerce {_key} LazyFrame with schema "
                f"{get_lazyframe_schema(data_container.lazyframe)} "
                f"into type {self.type}",
                failure_cases=failure_cases,
                parser_output=is_coercible,
            ) from exc

    def check(
        self,
        pandera_dtype: dtypes.DataType,
        data_container: PolarsDataContainer | None = None,
    ) -> Union[bool, Iterable[bool]]:
        try:
            pandera_dtype = Engine.dtype(pandera_dtype)
        except TypeError:
            return False

        return self.type == pandera_dtype.type and super().check(pandera_dtype)

    def __str__(self) -> str:
        return str(self.type)

    def __repr__(self) -> str:
        return f"DataType({self})"


class Engine(metaclass=engine.Engine, base_pandera_dtypes=DataType):
    """Polars data type engine."""

    @classmethod
    def dtype(cls, data_type: Any) -> dtypes.DataType:
        """Convert input into a polars-compatible
        Pandera :class:`~pandera.dtypes.DataType` object."""
        try:
            return engine.Engine.dtype(cls, data_type)
        except TypeError:
            try:
                pl_dtype = convert_py_dtype_to_polars_dtype(data_type)
            except ValueError:
                raise TypeError(
                    f"data type '{data_type}' not understood by "
                    f"{cls.__name__}."
                ) from None

            try:
                return engine.Engine.dtype(cls, pl_dtype)
            except TypeError:
                return DataType(data_type)


###############################################################################
# Numeric types
###############################################################################
@Engine.register_dtype(
    equivalents=["int8", pl.Int8, dtypes.Int8, dtypes.Int8()]
)
@immutable
class Int8(DataType, dtypes.Int8):
    """Polars signed 8-bit integer data type."""

    type = pl.Int8


@Engine.register_dtype(
    equivalents=["int16", pl.Int16, dtypes.Int16, dtypes.Int16()]
)
@immutable
class Int16(DataType, dtypes.Int16):
    """Polars signed 16-bit integer data type."""

    type = pl.Int16


@Engine.register_dtype(
    equivalents=["int32", pl.Int32, dtypes.Int32, dtypes.Int32()]
)
@immutable
class Int32(DataType, dtypes.Int32):
    """Polars signed 32-bit integer data type."""

    type = pl.Int32


@Engine.register_dtype(
    equivalents=["int64", int, pl.Int64, dtypes.Int64, dtypes.Int64()]
)
@immutable
class Int64(DataType, dtypes.Int64):
    """Polars signed 64-bit integer data type."""

    type = pl.Int64


@Engine.register_dtype(
    equivalents=["uint8", pl.UInt8, dtypes.UInt8, dtypes.UInt8()]
)
@immutable
class UInt8(DataType, dtypes.UInt8):
    """Polars unsigned 8-bit integer data type."""

    type = pl.UInt8


@Engine.register_dtype(
    equivalents=["uint16", pl.UInt16, dtypes.UInt16, dtypes.UInt16()]
)
@immutable
class UInt16(DataType, dtypes.UInt16):
    """Polars unsigned 16-bit integer data type."""

    type = pl.UInt16


@Engine.register_dtype(
    equivalents=["uint32", pl.UInt32, dtypes.UInt32, dtypes.UInt32()]
)
@immutable
class UInt32(DataType, dtypes.UInt32):
    """Polars unsigned 32-bit integer data type."""

    type = pl.UInt32


@Engine.register_dtype(
    equivalents=["uint64", pl.UInt64, dtypes.UInt64, dtypes.UInt64()]
)
@immutable
class UInt64(DataType, dtypes.UInt64):
    """Polars unsigned 64-bit integer data type."""

    type = pl.UInt64


@Engine.register_dtype(
    equivalents=["float32", pl.Float32, dtypes.Float32, dtypes.Float32()]
)
@immutable
class Float32(DataType, dtypes.Float32):
    """Polars 32-bit floating point data type."""

    type = pl.Float32


@Engine.register_dtype(
    equivalents=[
        "float64",
        float,
        pl.Float64,
        dtypes.Float64,
        dtypes.Float64(),
    ]
)
@immutable
class Float64(DataType, dtypes.Float64):
    """Polars 64-bit floating point data type."""

    type = pl.Float64


@Engine.register_dtype(
    equivalents=[
        "decimal",
        decimal.Decimal,
        pl.Decimal,
        dtypes.Decimal,
        dtypes.Decimal(),
    ]
)
@immutable(init=True)
class Decimal(DataType, dtypes.Decimal):
    """Polars decimal data type."""

    type = pl.Decimal

    # polars Decimal doesn't have a rounding attribute
    rounding = None

    _default_precision: int = dtypes.DEFAULT_PYTHON_PREC

    def __init__(
        self,
        precision: int = _default_precision,
        scale: int = 0,
    ) -> None:
        object.__setattr__(self, "precision", precision)
        object.__setattr__(self, "scale", scale)
        object.__setattr__(
            self, "type", pl.Decimal(precision=precision, scale=scale)
        )

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Decimal):
        """Convert a :class:`polars.Decimal` to
        a Pandera :class:`pandera.engines.polars_engine.Decimal`."""
        # polars precision may be nullable, pandera imposes a default.
        precision = (
            polars_dtype.precision
            if polars_dtype.precision is not None
            else cls._default_precision
        )
        return cls(precision=precision, scale=polars_dtype.scale)

    def coerce(self, data_container: PolarsDataContainer) -> pl.LazyFrame:
        """Coerce data container to the data type."""
        if isinstance(data_container, pl.LazyFrame):
            data_container = PolarsData(data_container)

        key = data_container.key or "*"
        return data_container.lazyframe.cast({key: pl.Float64}).cast(
            {key: pl.Decimal(scale=self.scale, precision=self.precision)},
            strict=True,
        )

    def check(
        self,
        pandera_dtype: dtypes.DataType,
        data_container: PolarsDataContainer | None = None,
    ) -> Union[bool, Iterable[bool]]:
        try:
            pandera_dtype = Engine.dtype(pandera_dtype)
            assert isinstance(pandera_dtype, Decimal), (
                "The return is expected to be of Decimal class"
            )
        except TypeError:  # pragma: no cover
            return False

        try:
            return (
                (self.type == pandera_dtype.type)
                & (self.scale == pandera_dtype.scale)
                & (self.precision == pandera_dtype.precision)
            )

        except TypeError:  # pragma: no cover
            return super().check(pandera_dtype)

    def __str__(self) -> str:
        return f"Decimal(precision={self.precision}, scale={self.scale})"


###############################################################################
# Temporal types
###############################################################################


@Engine.register_dtype(
    equivalents=[
        "date",
        datetime.date,
        pl.Date,
        dtypes.Date,
        dtypes.Date(),
    ]
)
@immutable
class Date(DataType, dtypes.Date):
    """Polars date data type."""

    type = pl.Date


@Engine.register_dtype(
    equivalents=[
        "datetime",
        datetime.datetime,
        pl.Datetime,
        dtypes.DateTime,
        dtypes.DateTime(),
    ]
)
@immutable(init=True)
class DateTime(DataType, dtypes.DateTime):
    """Polars datetime data type."""

    type: builtins.type[pl.Datetime] = pl.Datetime
    time_zone_agnostic: bool = False

    def __init__(
        self,
        time_zone_agnostic: bool = False,
        time_zone: str | None = None,
        time_unit: Literal["ns", "us", "ms"] | None = None,
    ) -> None:
        # avoid deprecated warning when initializing pl.Datetime:
        # passing time_unit=None is deprecated.
        if time_unit is not None:
            datetime = pl.Datetime(time_zone=time_zone, time_unit=time_unit)
        else:
            datetime = pl.Datetime(time_zone=time_zone)

        object.__setattr__(self, "type", datetime)
        object.__setattr__(self, "time_zone_agnostic", time_zone_agnostic)

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Datetime):
        """Convert a :class:`polars.Datetime` to
        a Pandera :class:`pandera.engines.polars_engine.DateTime`."""
        return cls(
            time_zone=polars_dtype.time_zone, time_unit=polars_dtype.time_unit
        )

    def check(
        self,
        pandera_dtype: dtypes.DataType,
        data_container: PolarsDataContainer | None = None,
    ) -> Union[bool, Iterable[bool]]:
        try:
            pandera_dtype = Engine.dtype(pandera_dtype)
        except TypeError:
            return False

        if self.time_zone_agnostic:
            return (
                isinstance(pandera_dtype.type, pl.Datetime)
                and pandera_dtype.type.time_unit == self.type.time_unit
            )

        return self.type == pandera_dtype.type and super().check(pandera_dtype)


@Engine.register_dtype(
    equivalents=[
        "time",
        datetime.time,
        pl.Time,
    ]
)
@immutable
class Time(DataType):
    """Polars time data type."""

    type = pl.Time


@Engine.register_dtype(
    equivalents=[
        "timedelta",
        datetime.timedelta,
        pl.Duration,
        dtypes.Timedelta,
        dtypes.Timedelta(),
    ]
)
@immutable(init=True)
class Timedelta(DataType, dtypes.Timedelta):
    """Polars timedelta data type."""

    type = pl.Duration

    def __init__(
        self,
        time_unit: Literal["ns", "us", "ms"] = "us",
    ) -> None:
        object.__setattr__(self, "type", pl.Duration(time_unit))

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Duration):
        """Convert a :class:`polars.Duration` to
        a Pandera :class:`pandera.engines.polars_engine.Duration`."""
        if polars_dtype.time_unit is None:
            return cls()
        return cls(time_unit=polars_dtype.time_unit)


###############################################################################
# Nested types
###############################################################################


class _ArrayKwargs(TypedDict):
    """typeddict for mypy."""

    shape: NotRequired[Union[int, tuple[int, ...]]]
    width: NotRequired[Union[int, None]]


@Engine.register_dtype(equivalents=[pl.Array])
@immutable(init=True)
class Array(DataType):
    """Polars Array nested type."""

    type = pl.Array

    @overload
    def __init__(
        self,
        inner: Literal[None] = ...,
        shape: Literal[None] = ...,
        *,
        width: Literal[None] = ...,
    ) -> None: ...

    @overload
    def __init__(
        self,
        inner: PolarsDataType = ...,
        shape: Union[int, tuple[int, ...], None] = ...,
        *,
        width: int | None = ...,
    ) -> None: ...

    def __init__(
        self,
        inner: PolarsDataType | None = None,
        shape: Union[int, tuple[int, ...], None] = None,
        *,
        width: int | None = None,
    ) -> None:
        kwargs: _ArrayKwargs = {}
        if width is not None:
            # width deprecated in polars 0.20.31, replaced by shape
            kwargs["shape"] = width
        elif shape is not None:
            kwargs["shape"] = shape

        if inner:
            object.__setattr__(self, "type", pl.Array(inner=inner, **kwargs))

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Array):
        shape = polars_dtype.shape

        if (
            isinstance(shape, tuple)
            and isinstance(shape[0], int)
            and len(shape) > 1
        ):
            offset = len(shape) - 1
            shape = shape[offset:]

        return cls(
            inner=polars_dtype.inner,
            shape=shape,
        )


@Engine.register_dtype(equivalents=[pl.List])
@immutable(init=True)
class List(DataType):
    """Polars List nested type."""

    type = pl.List

    def __init__(
        self,
        inner: PolarsDataType | None = None,
    ) -> None:
        if inner:
            object.__setattr__(self, "type", pl.List(inner=inner))

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.List):
        return cls(inner=polars_dtype.inner)


@Engine.register_dtype(equivalents=[pl.Struct])
@immutable(init=True)
class Struct(DataType):
    """Polars Struct nested type."""

    type = pl.Struct

    def __init__(
        self,
        fields: Union[Sequence[pl.Field], SchemaDict] | None = None,
    ) -> None:
        if fields:
            object.__setattr__(self, "type", pl.Struct(fields=fields))

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Struct):
        return cls(fields=polars_dtype.fields)


###############################################################################
# Other types
###############################################################################


@Engine.register_dtype(
    equivalents=["bool", bool, pl.Boolean, dtypes.Bool, dtypes.Bool()]
)
@immutable
class Bool(DataType, dtypes.Bool):
    """Polars boolean data type."""

    type = pl.Boolean


@Engine.register_dtype(
    equivalents=["binary", bytes, pl.Binary, dtypes.Binary, dtypes.Binary()]
)
@immutable
class Binary(DataType, dtypes.Binary):
    """Polars binary data type."""

    type = pl.Binary


@Engine.register_dtype(
    equivalents=["string", str, pl.Utf8, dtypes.String, dtypes.String()]
)
@immutable
class String(DataType, dtypes.String):
    """Polars string data type."""

    type = pl.Utf8


@Engine.register_dtype(equivalents=[pl.Categorical])
@immutable(init=True)
class Categorical(DataType):
    """Polars categorical data type."""

    type = pl.Categorical

    ordering = None

    def __init__(
        self,
        ordering: Literal["physical", "lexical"] | None = "lexical",
    ) -> None:
        object.__setattr__(self, "ordering", ordering)
        object.__setattr__(self, "type", pl.Categorical())

    def __deepcopy__(self, memo):
        """Custom deepcopy to avoid pickling issues with pl.Categorical()."""
        return self.__class__(ordering=self.ordering)

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Categorical):
        """Convert a :class:`polars.Categorical` to
        a Pandera :class:`pandera.engines.polars_engine.Categorical`."""
        return cls(ordering=polars_dtype.ordering)


@Engine.register_dtype(equivalents=[pl.Enum])
@immutable(init=True)
class Enum(DataType):
    """Polars enum data type."""

    type = pl.Enum

    categories: pl.Series

    def __init__(
        self,
        categories: Union[pl.Series, Iterable[str], None] = None,
    ) -> None:
        if categories is not None:
            # skip setting categories when no arg pl.Enum() called as part of registration
            object.__setattr__(self, "categories", categories)
            object.__setattr__(self, "type", pl.Enum(categories=categories))

    @classmethod
    def from_parametrized_dtype(cls, polars_dtype: pl.Enum):
        """Convert a :class:`polars.Enum` to
        a Pandera :class:`pandera.engines.polars_engine.Enum`."""
        return cls(categories=polars_dtype.categories)

    def check(
        self,
        pandera_dtype: dtypes.DataType,
        data_container: PolarsDataContainer | None = None,
    ) -> Union[bool, Iterable[bool]]:
        try:
            pandera_dtype = Engine.dtype(pandera_dtype)
        except TypeError:
            return False

        return (
            self.type == pandera_dtype.type
            and (self.type.categories == pandera_dtype.categories).all()  # type: ignore
        )


@Engine.register_dtype(
    equivalents=["category", dtypes.Category, dtypes.Category()]
)
@immutable(init=True)
class Category(DataType, dtypes.Category):
    """Pandera categorical data type for polars."""

    type = pl.Utf8

    def __init__(self, categories: Iterable[Any] | None = None):
        dtypes.Category.__init__(self, categories, ordered=False)

    def coerce(self, data_container: PolarsDataContainer) -> pl.LazyFrame:
        """Coerce data container to the data type."""
        if isinstance(data_container, pl.LazyFrame):
            data_container = PolarsData(data_container)

        lf = data_container.lazyframe.cast(self.type, strict=True)

        key = data_container.key or "*"
        belongs_to_categories = self.__belongs_to_categories(lf, key=key)

        all_true = (
            belongs_to_categories.select(pl.all_horizontal(key))
            .select(pl.all().all())
            .collect()
            .item()
        )
        if not all_true:
            raise ValueError(
                f"Could not coerce {type(lf)} data_container "
                f"into type {self.type}. Invalid categories found in data_container."
            )
        return lf

    def try_coerce(self, data_container: PolarsDataContainer) -> pl.LazyFrame:
        """Coerce data container to the data type,

        raises a :class:`~pandera.errors.ParserError` if the coercion fails
        :raises: :class:`~pandera.errors.ParserError`: if coercion fails
        """
        if isinstance(data_container, pl.LazyFrame):
            data_container = PolarsData(data_container)

        try:
            return self.coerce(data_container)
        except Exception as exc:
            coercible = polars_object_coercible(data_container, self.type)
            match_categories = self.__belongs_to_categories(
                data_container.lazyframe, key=data_container.key
            )
            is_coercible: pl.LazyFrame = pl.concat(
                (coercible, match_categories), how="horizontal"
            ).select(pl.all_horizontal(CHECK_OUTPUT_KEY, "belongs"))

            failure_cases = polars_failure_cases_from_coercible(
                data_container, is_coercible
            )
            raise errors.ParserError(
                f"Could not coerce {type(data_container)} data_container "
                f"into type {self.type}. Invalid categories found in data_container.",
                failure_cases=failure_cases,
            ) from exc

    def __belongs_to_categories(
        self,
        lf: pl.LazyFrame,
        key: str = "*",
    ) -> pl.LazyFrame:
        # self.categories can be None, and polars won't crash on this, though the types indicate this should not
        # be None
        return lf.select(
            pl.col(key)
            .is_in(self.categories)  # type:ignore [arg-type]
            .alias("belongs")
        )

    def __str__(self):
        return "Category"


@Engine.register_dtype(equivalents=["null", pl.Null])
@immutable
class Null(DataType):
    """Polars null data type."""

    type = pl.Null


@Engine.register_dtype(equivalents=["object", object, pl.Object])
@immutable
class Object(DataType):
    """Semantic representation of a :class:`numpy.object_`."""

    type = pl.Object
