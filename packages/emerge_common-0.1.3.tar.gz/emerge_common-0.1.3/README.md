# What is this

This library is just a collection of common features in the EMerge software suite including:
 * Emerge FEM
 * Heavi
 * Optycal