"""
Transformer Cloner - Clone and prune transformer models with new tokenizers.

A library for cloning transformer models with new tokenizers, including
support for vocabulary mapping, embedding strategies, and model pruning.
"""

from transformer_cloner.embedding_strategy import EmbeddingStrategy
from transformer_cloner.pruning_config import PruningConfig
from transformer_cloner.cloner import TransformerCloner

__version__ = "0.1.1"
__all__ = [
    "TransformerCloner",
    "EmbeddingStrategy",
    "PruningConfig",
    "__version__",
]
