"""Tests for transformer_cloner package."""

import pytest
from transformer_cloner import EmbeddingStrategy, PruningConfig


def test_embedding_strategy_values():
    """Test that all embedding strategies have expected values."""
    assert EmbeddingStrategy.MEAN.value == "mean"
    assert EmbeddingStrategy.SUM.value == "sum"
    assert EmbeddingStrategy.FIRST.value == "first"
    assert EmbeddingStrategy.LAST.value == "last"
    assert EmbeddingStrategy.WEIGHTED.value == "weighted"
    assert EmbeddingStrategy.MAX.value == "max"
    assert EmbeddingStrategy.MIN.value == "min"


def test_pruning_config_defaults():
    """Test that PruningConfig defaults to None for all fields."""
    config = PruningConfig()
    assert config.hidden_size is None
    assert config.num_hidden_layers is None
    assert config.intermediate_size is None
    assert config.num_attention_heads is None
    assert config.num_key_value_heads is None
    assert config.head_dim is None


def test_pruning_config_with_values():
    """Test PruningConfig with specified values."""
    config = PruningConfig(
        hidden_size=512,
        num_hidden_layers=6,
        intermediate_size=1536,
    )
    assert config.hidden_size == 512
    assert config.num_hidden_layers == 6
    assert config.intermediate_size == 1536


class MockConfig:
    """Mock model config for testing validation."""
    hidden_size = 768
    num_hidden_layers = 12
    intermediate_size = 3072
    num_attention_heads = 12
    num_key_value_heads = 12
    head_dim = 64


def test_pruning_config_validation_valid():
    """Test validation passes for valid config."""
    config = PruningConfig(
        hidden_size=512,
        num_hidden_layers=6,
        intermediate_size=1536,
        num_attention_heads=8,
    )
    errors = config.validate(MockConfig())
    assert len(errors) == 0


def test_pruning_config_validation_exceeds_original():
    """Test validation fails when exceeding original dimensions."""
    config = PruningConfig(hidden_size=1024)  # Exceeds 768
    errors = config.validate(MockConfig())
    assert len(errors) > 0
    assert "cannot exceed original" in errors[0]


def test_pruning_config_validation_divisibility():
    """Test validation fails for non-divisible attention heads."""
    config = PruningConfig(
        hidden_size=512,
        num_attention_heads=7,  # 512 not divisible by 7
    )
    errors = config.validate(MockConfig())
    assert len(errors) > 0
