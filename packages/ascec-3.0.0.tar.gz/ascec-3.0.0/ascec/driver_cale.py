"""
Andy Zapata
21/12/2025
"""

import subprocess


wavedirac = """#
**DIRAC
.TITLE
 WV
.WAVE FUNCTION
**INTEGRALS
.NUCMOD
 1
**WAVE FUNCTIONS
.SCF
*SCF
.INTFLG
1 1 0
.MAXITR
 50
"""


def write_atoms(f, cluster) -> None:
    """
    Write atoms in input file
    """
    for frag in cluster:
        natoms = len(frag) // 4
        for ia in range(natoms):
            ia0 = ia * 4
            f.write(f" {frag[ia0]} {frag[ia0+1]} {frag[ia0+2]} {frag[ia0+3]}\n")


def en_gaussian(
    cluster, alias, meth, bas, charge, mult, nproc, mem
) -> tuple[int, float]:
    """
    Gaussian inputs and electronic energy calculation
    """
    if "DFT" in meth.upper():
        meth.replace("DFT", "")
    with open("en_gauss.com", "w") as f:
        if mem > 0.0:
            f.write(f"%mem={mem*nproc}GB\n")
        f.write(f"%nproc={nproc}\n")
        f.write(f"# {meth}/{bas}\n\n")
        f.write("Single Point Calculation with Gaussian\n\n")
        f.write(f"{charge} {mult}\n")
        write_atoms(f, cluster)
        f.write("\n")
    # * Execution of gaussian ######
    subprocess.run(
        f"{alias} en_gauss.com", shell=True, executable="/bin/tcsh", check=False
    )
    # * End calculation ############
    # * Read energy from .log ######
    value = subprocess.run(
        "grep termination en_gauss.log | sed s/termination.*//",
        shell=True,
        capture_output=True,
        check=False,
    ).stdout.decode("utf-8")
    value = value.replace(" ", "").replace("\n", "")
    # * End read ##################
    if value != "Normal":
        done = 0
        energy = 0.0
    else:
        done = 1
        # * Read energy
        energy = float(
            subprocess.run(
                "grep Done: en_gauss.log | sed s/.*=// | sed s/A.U.*//",
                shell=True,
                capture_output=True,
                check=False,
            ).stdout
        )
        # * End
    return done, energy


def en_dirac(
    cluster, alias, meth, bas, charge, scratch, nproc, mem
) -> tuple[int, float]:
    """
    Dirac input and electronic energy calculation
    """
    with open("en_dirac.inp", "w") as f:
        f.write(wavedirac)
        f.write(f"**MOLECULE\n*CHARGE\n.CHARGE\n {charge}\n")
        f.write("*SYMMETRY\n.NOSYM\n")
        f.write(f"*BASIS\n.DEFAULT\n {bas}\n")
        f.write("*COORDINATES\n.UNITS\n AU\n")
        if "DFT" in meth.upper():
            meth.replace("DFT", "")
            f.write("**HAMILTONIAN\n")
            f.write(f".DFT\n{meth}\n")
        f.write("*END OF\n")

    natoms = 0
    for frag in cluster:
        natoms += len(frag) // 4
    with open("mol_dirac.xyz", "w") as fmol:
        fmol.write(f" {natoms}\n\n")
        write_atoms(fmol, cluster)

    # * Execution of dirac ######
    command = f"{alias} --noarch --scratch={scratch}"
    if mem != 0.0:
        command += f" --mem={mem}"
    if nproc > 1:
        command += f" --mpi={nproc}"
    command += " --inp=en_dirac.inp --mol=mol_dirac.xyz"
    subprocess.run(command, shell=True, check=False)
    # * End calculation ############
    # * does calculation donde? ######
    value = subprocess.run(
        "grep 'Convergence after' en_dirac_mol_dirac.out | awk '{print $2}'",
        shell=True,
        capture_output=True,
        check=False,
    ).stdout.decode("utf-8")
    value = value.replace(" ", "").replace("\n", "")
    # * End read ##################
    if value.upper() != "CONVERGENCE":
        done = 0
        energy = 0.0
    else:
        done = 1
        # * Read energy
        energy = float(
            subprocess.run(
                "grep 'Total energy' en_dirac_mol_dirac.out | awk '{print $4}'",
                shell=True,
                capture_output=True,
                check=False,
            ).stdout
        )
        # * End
    return done, energy


def cale(
    cluster,
    idprogram=1,
    alias="g09",
    scratch="",
    meth="HF",
    bas="sto-3g",
    charge=0,
    mult=1,
    nproc=1,
    mem=0.0,
) -> tuple[int, float]:
    """
    Driver the electronic energy calculation

    Parameters
    ----------
    cluster: (list[list[str,float,float,float,str,...],...])
            #! Please, respect the format.
            System under study. Each sublist represents a fragment that
            can interact with others through intermolecular interactions
            without undergoing a reaction.
    ic: (int)
        Selection the program which calculates the electronic energy (1:Gaussian,
        2:Dalton, and 3:Dirac).
        The default value is 1.
    alias: (str)
        Code alias of the program.
        The default value is g09.
    scratch: (str)
            scratch path
    meth: (str)
           Methodology to calculate the energy.
           The default value is HF (Hartree-Fock).
    bas: (str)
            Basis set.
            The default value is sto-3g.
    charge: (int)
            Molecular charge.
            The default value is 0.
    mult: (int)
            Spin multiplicity.
            The default value is 1.
    nproc: (int)
            Number of processors
            The default value is 1.
    mem: (float)
            Quantity of ram memory in GB by processor.
            The default value of the program.
    """
    done = 0
    energy = 0.0

    if idprogram == 1:
        # * Gaussain
        done, energy = en_gaussian(cluster, alias, meth, bas, charge, mult, nproc, mem)
    if idprogram == 3:
        # * Dirac
        done, energy = en_dirac(cluster, alias, meth, bas, charge, scratch, nproc, mem)

    return done, energy
