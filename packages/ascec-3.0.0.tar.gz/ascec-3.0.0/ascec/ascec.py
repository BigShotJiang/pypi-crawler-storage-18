"""
Author: Andy Zapata
Date:   21/10/25

This version:
    *) Used the same bases set for all fragments
    *) Gaussian runs on tcsh shell
    *) Dirac and Dalton runs on bash shell
    *) Respect formate of basis set for DIRAC and DALTON, for example,
        sto-3g is STO-3G
        dyall.cv2z is dyall.cv2z
"""

from datetime import datetime
from math import exp

from fungeom import *
from driver_cale import *


def maxv(lista: list[list[str, float, float, float, ...], ...]) -> float:
    """
    Get maximum value from a list which has float and string values
    """
    maxt = 0
    for mol in lista:
        for x in mol:
            if isinstance(x, str):
                continue
            if abs(x) > abs(maxt):
                maxt = x
    return maxt


class ascec:
    """
    Driver of the ASCEC calculation

    Paramters
    ---------
    cluster: (list[list[str,float,float,float,str,...],...])
            #! Please, respect the format.
            System under study. Each sublist represents a fragment that
            can interact with others through intermolecular interactions
            without undergoing a reaction.
    ic: (int)
        Selection the program which calculates the electronic energy (1:Gaussian,
        2:Dalton, and 3:Dirac).
        The default value is 1.
    alias: (str)
        Code alias of the program.
        The default value is g09.
    scratch: (str)
            Scratch path
    nproc: (int)
        Number of processors
            The default value is 1.
    mem: (float)
            Quantity of ram memory by processor.
            The default value of the program.
    length: (float)
        Cubic edge that encloses the cluster under study.
        By default, the program adds 4 Å to the highest coordinate.
    route: (int)
        Quenching rout 1: linear, 2: geometrical.
        The default value is 2.
    Ti: (float)
        Initial temperature.
        The default value is 500 K.
    nT: (int)
        Number of the temperatures.
        The default value is 200.
    dT: (float)
        Step between temperatures.
        The default value is 2%.
    MaxCycles: (int)
                Maximum number of cycles of the interactions of the ASCEC
                algorithm by temperature.
                The default value is 2500.
    meth: (str)
           Methodology to calculate the energy.
           The default value is HF (Hartree-Fock).
           For DFT methodology please used the following nomenclature:
                            DFTFunctional
    bas: (str)
            Basis set.
            The default value is sto-3g.
    charge: (int)
            Molecular charge.
            The default value is 0.
    mult: (int)
            Spin multiplicity.
            The default value is 1.
    maxr: (float)
            Maximum displacement in Å.
            The default value is 1.0 Å.
    maxa: (float)
            Maximum rotation angle. The default value is 1. radians.
    seed: (int)
    """

    def __init__(
        self,
        # System configuration
        cluster: list[list[str, float, float, float]] = [],
        charge: int = 0,
        mult: int = 1,
        # End Configuration ########################
        # Electronic structure program configuration
        ic: int = 1,
        alias: str = "g09",
        scratch="",
        nproc: int = 1,
        mem: float = 0.0,
        meth: str = "HF",
        bas: str = "sto-3g",
        # End Configuration ########################
        # ASCEC Configuration
        length: float = -1.0,
        route: int = 2,
        Ti: float = 500.0,
        nT: int = 200,
        dT: float = 2,
        MaxCycles: int = 2500,
        maxr: float = 1.0,
        maxa: float = 1.0,
        seed: int = int(datetime.now().strftime("%M%S%d")),
        # End Configuration ##########################
    ) -> None:
        if len(cluster) == 0:
            raise ValueError("*** Please input the cluster under study.")
        if not isinstance(cluster, list):
            raise TypeError(
                "*** The cluster variable might be a list[list['str',float,float, float, 'str', ...], ....]"
            )
        self.cluster = cluster
        self.charge = charge
        self.mult = mult
        self.natoms = 0
        for ifrag in cluster:
            self.natoms += len(ifrag) // 4
        ##############* Electronic Energy Calc. Configurations *################
        self.ic = ic
        self.alias = alias
        self.scratch = scratch
        self.nproc = nproc
        self.mem = mem
        self.meth = meth
        if "DFT" in meth.upper():
            print("Nomenclature for DFT methodologies:\nDFTFunctional (DFTB3LYP)")
        self.bas = bas
        #####################*    End Configuration    *#######################
        #####################*  ASCEC Configuration  *#########################
        self.length = length
        if self.length == -1.0:
            self.length = 4.0
        self.route = route
        self.Ti = Ti
        self.nT = nT
        self.dT = dT
        self.MaxCycles = MaxCycles
        self.maxr = maxr
        self.maxa = maxa
        self.seed = seed
        #####################*   End Configuration *###########################
        label = []
        xyz = []
        for frag in cluster:
            natoms = len(frag) // 4
            for ia in range(natoms):
                ia0 = ia * 4
                label.append(frag[ia0])
                xyz += frag[ia0 + 1 : ia0 + 4]
        self.center_cube = cm(label, xyz)

    def move_cluster(self, cluster) -> list[list[str, float, float, float]]:
        """
        Move the geometry of each fragment within the cube
        """
        self.seed, newclstr = move_geom_cluster(
            self.seed, self.maxr, self.maxa, self.length, self.center_cube, cluster
        )
        return newclstr

    def single_point(self, cluster) -> tuple[int, float]:
        """
        Get electronic energy
        """
        done, energy = cale(
            cluster,
            self.ic,
            self.alias,
            self.scratch,
            self.meth,
            self.bas,
            self.charge,
            self.mult,
            self.nproc,
            self.mem,
        )
        return done, energy

    def move_energy(
        self, cluster, cycle, ncycles
    ) -> tuple[int, float, list[list[str, float, float, float]]]:
        """
        Move the cluster until get any electronic energy value
        """
        # * Energy evaluation until a normal termination
        done = 0
        while done == 0 and cycle < ncycles:
            done, energy = self.single_point(cluster)
            if done == 0:
                cluster = self.move_cluster(cluster)
            cycle += 1
        # * End energy evaluation
        return cycle, energy, cluster

    def pes_exp(self) -> tuple[[float], [[[str, float, float, float]]]]:
        """
        Start potential energy surface exploration using ascec algorithm
        """
        cluster_accept = []
        energy_accept = []
        iT = 0
        icluster = self.cluster

        # * Initial energy and cluster
        cycle, energy, icluster = self.move_energy(icluster, 0, 500)
        print(f"Energy of structure inital {energy} a.u.")
        cluster_accept.append(icluster)
        energy_accept.append(energy)
        # * end
        energy = 0.0
        Ti = self.Ti
        kB = 3.1668e-6
        ######################### ! Core ASCEC ! #############################
        while iT < self.nT:
            cycle = 0
            while cycle < self.MaxCycles:
                # * Energy evaluation until a normal termination
                cycle, energy, icluster = self.move_energy(
                    self.move_cluster(cluster_accept[-1]), cycle, self.MaxCycles
                )
                # * End energy evaluation
                deltaE = energy - energy_accept[-1]
                # * Accept and exit of MaxCycles
                if deltaE < 0.0:
                    energy_accept.append(energy)
                    cluster_accept.append(icluster)
                    print(f"*** Structure Accepted\nE={energy}a.u. (DE<0)")
                    cycle = self.MaxCycles
                # * End
                # * Accept structure according modified metropolis and pass
                # * to another cycle
                if deltaE > 0.0 and exp(-deltaE / (kB * Ti)) > deltaE / energy:
                    energy_accept.append(energy)
                    cluster_accept.append(icluster)
                    print(f"*** Structure Accepted\nE={energy}a.u. (DE>0)")
                # * End
            # * Next Temperature
            iT += 1
            if self.route == 1:
                # * lineal route
                Ti -= self.dT * iT
            else:
                # * Geometrical route
                Ti -= self.dT * Ti / 100
            # * End
        ####################### ! End Core ASCEC ! ############################
        return energy_accept, cluster_accept


if __name__ == "__main__":
    cluster = [
        [
            "O",
            0.000000,
            0.000000,
            0.118997,
            "H",
            0.000000,
            0.753010,
            -0.475986,
            "H",
            0.000000,
            -0.753010,
            -0.475986,
        ],
        [
            "O",
            0.000000,
            0.000000,
            0.118997,
            "H",
            0.000000,
            0.753010,
            -0.475986,
            "H",
            0.000000,
            -0.753010,
            -0.475986,
        ],
    ]

    obj_ascec = ascec(cluster=cluster, Ti=200, nT=5, dT=10, MaxCycles=200, length=4.0)

    print("Start Geom ", obj_ascec.cluster)

    with open("move_dimer_water.xyz", "w") as f:
        for ig in range(10):
            f.write(f" {obj_ascec.natoms} \n")
            f.write(f" Structure {ig}\n")
            for ifrag in obj_ascec.move_cluster(obj_ascec.cluster):
                nats = len(ifrag) // 4
                for ia in range(nats):
                    ia0 = ia * 4
                    f.write(
                        f"{ifrag[ia0]}   {ifrag[ia0+1]}  {ifrag[ia0+2]}  {ifrag[ia0+3]}\n"
                    )

    print(" *** ASCEC Results (Gaussian) ***")
    energies, geoms = obj_ascec.pes_exp()

    ngeoms = len(energies)
    print(f"Total the geometries accepted: {ngeoms}")
    cc = obj_ascec.center_cube
    with open("dimer_water.xyz", "w") as f:
        for ic, en in enumerate(energies):
            f.write(f" {obj_ascec.natoms} \n")
            f.write(f" Structure {ic} Energy {en} a.u.\n")
            for ifrag in geoms[ic]:
                nats = len(ifrag) // 4
                for ia in range(nats):
                    ia0 = ia * 4
                    f.write(
                        f"{ifrag[ia0]}   {ifrag[ia0+1]}  {ifrag[ia0+2]}  {ifrag[ia0+3]}\n"
                    )
            f.write(f"X     {cc[0] + 2.0}  {cc[0] + 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] + 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] - 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] - 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] + 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] + 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] - 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] - 2.0}  {cc[0] - 2.0}\n")

    obj_ascec = ascec(
        cluster=cluster,
        ic=3,
        alias="/home/danian/programs/DIRAC-24.0-Source/build/pam",
        scratch="/home/danian/scratch",
        Ti=200,
        nT=5,
        dT=10,
        MaxCycles=200,
        length=4.0,
        bas="STO-3G",
        seed=231220251415,
    )

    print(" *** ASCEC Results (DIRAC) ***")
    energies, geoms = obj_ascec.pes_exp()

    ngeoms = len(energies)
    print(f"Total the geometries accepted: {ngeoms}")
    cc = obj_ascec.center_cube
    with open("dirac_dimer_water.xyz", "w") as f:
        for ic, en in enumerate(energies):
            f.write(f" {obj_ascec.natoms} \n")
            f.write(f" Structure {ic} Energy {en} a.u.\n")
            for ifrag in geoms[ic]:
                nats = len(ifrag) // 4
                for ia in range(nats):
                    ia0 = ia * 4
                    f.write(
                        f"{ifrag[ia0]}   {ifrag[ia0+1]}  {ifrag[ia0+2]}  {ifrag[ia0+3]}\n"
                    )
            f.write(f"X     {cc[0] + 2.0}  {cc[0] + 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] + 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] - 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] + 2.0}  {cc[0] - 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] + 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] + 2.0}  {cc[0] - 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] - 2.0}  {cc[0] + 2.0}\n")
            f.write(f"X     {cc[0] - 2.0}  {cc[0] - 2.0}  {cc[0] - 2.0}\n")
