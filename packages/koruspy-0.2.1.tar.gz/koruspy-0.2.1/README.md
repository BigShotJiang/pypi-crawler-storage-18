# 🦀 Koruspy

**Koruspy** é uma biblioteca ultra-leve que traz a segurança do **Rust** e a elegância do **Kotlin** para o ecossistema Python. 

Desenvolvida inteiramente via **Termux**, esta biblioteca elimina a necessidade de verificações manuais de `None` e blocos `try/except` repetitivos, utilizando o poder do **Pattern Matching** (Python 3.10+) e programação funcional.

---

## 🚀 Diferenciais

* **Zero NoneErrors:** Use `Option` (`Some` ou `nothing`) para lidar com valores ausentes.
* **Result Pattern:** Trate sucessos e falhas como dados, não como exceções que quebram o código.
* **Estilo Kotlin:** Métodos encadeáveis como `.map()`, `.filter()` e o operador de navegação segura `.getattr()`.
* **Terminal Colorido:** Substitua o `print` padrão pelo `println` com suporte a tipos e cores ANSI.

---

## 📦 Instalação

Como você está desenvolvendo no **Termux** ou em ambiente mobile, instale via modo editável:

```bash
pip install -e .
```
