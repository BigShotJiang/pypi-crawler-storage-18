"""Minimal test code for readable"""

import sys
import tempfile
from skilleter_readable.readable import readable

def test_cleanfile():
    """Very basic test"""

    with tempfile.NamedTemporaryFile(mode='wt+', delete=True) as outfile:
        sys.argv = [sys.argv[0], 'pyproject.toml', outfile.name, '--verbose', '--debug']
        readable()
