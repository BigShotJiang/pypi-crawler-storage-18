# nonebot-plugin-Astro-blog

_✨ 通过 NoneBot 进行 Astro 博客的简单操作 ✨_

## 📖 介绍

`nonebot-plugin-Astro-blog` 是一个基于 NoneBot2 的插件，旨在帮助用户通过机器人指令便捷地管理和操作 Astro 博客（如查看文章列表、发布简易内容等）。

## 💿 安装

### 使用 nb-cli 安装
在 nonebot2 项目的根目录下打开命令行, 输入以下指令即可安装：
```bash
nb plugin install nonebot-plugin-Astro-blog
```

### 使用包管理器安装
根据你使用的包管理器，输入相应的安装命令：

<details>
<summary>pip</summary>

```bash
pip install nonebot-plugin-Astro-blog
```
</details>

<details>
<summary>pdm</summary>

```bash
pdm add nonebot-plugin-Astro-blog
```
</details>

<details>
<summary>poetry</summary>

```bash
poetry add nonebot-plugin-Astro-blog
```
</details>

## ⚙️ 配置

在 nonebot2 项目的 `.env` 文件中添加下表中的配置项：

| 配置项 | 必填 | 默认值 | 说明 |
|:-----|:----:|:----:|:----|
| `GITHUB_TOKEN` | **是** | - | GitHub Personal Access Token (需要 repo 权限) |
| `GITHUB_REPO` | **是** | - | 仓库名，格式为 `用户名/仓库名` |
| `GITHUB_BRANCH` | 否 | `main` | 仓库分支 |
| `BLOG_PATH` | 否 | `src/content/blog` | 博客文章存放路径 |
| `THOUGHT_PATH` | 否 | `src/content/thoughts` | 小事记录存放路径(需要自己添加过) |
| `IMAGE_PATH` | 否 | `public/images/blog` | 图片上传存放路径 |


## 🚀 使用

### 指令列表

| 指令 | 权限 | 范围 | 说明 |
|:-----|:----:|:----:|:----|
| `/blog list` | 所有人 | 私聊/群聊 | 列出所有博客文章 |
| `/blog view <slug>` | 所有人 | 私聊/群聊 | 查看文章的图片预览 |
| `/blog new <标题>` | 所有人 | 私聊/群聊 | 交互式创建新文章 |
| `/blog update <slug>` | 所有人 | 私聊/群聊 | 交互式更新文章内容 |
| `/blog del <slug>` | 管理员 | 私聊/群聊 | 删除指定的文章 |
| `/blog thought <内容>` | 所有人 | 私聊/群聊 | 记录一件小事（支持图片，自动上传） |
| `/blog thoughts` | 所有人 | 私聊/群聊 | 查看最近 10 条小事列表 |
| `/blog view_thought <文件名>` | 所有人 | 私聊/群聊 | 查看小事详情图 |
| `/blog help` | 所有人 | 私聊/群聊 | 显示插件帮助信息 |

### 功能特色

- **文章管理**：支持通过指令进行文章的增删改查。
- **小事记录 (Thoughts)**：快速记录生活点滴，支持图片并自动上传至 GitHub 仓库。
- **图片自动处理**：自动将消息中的图片上传至配置的路径，并在 Markdown 中生成正确的引用。
- **图片渲染预览**：集成 `nonebot-plugin-htmlrender`，将文章和小事以图片形式美观呈现。


## 📄 开源许可
本项目使用 [MIT](./LICENSE) 许可证开源。
