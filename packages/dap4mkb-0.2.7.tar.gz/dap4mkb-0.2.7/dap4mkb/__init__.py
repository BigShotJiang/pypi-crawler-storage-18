"""
DAP4MKB - DataAudit Platform для МКБ
Аудит и аналитика данных для банков

Использование в Jupyter/Spyder:
    import dap4mkb
    dap4mkb.init()   # Первый раз
    dap4mkb.start()  # Запуск
"""

__version__ = "0.1.0"
__author__ = "DAP Team"


def init(force: bool = False):
    """
    Инициализация DAP Platform.
    Создаёт ~/.dap, базу данных, admin пользователя.
    
    Args:
        force: Перезаписать существующую конфигурацию
    
    Пример:
        >>> import dap4mkb
        >>> dap4mkb.init()
    """
    from dap4mkb.cli import init as cli_init
    from click.testing import CliRunner
    runner = CliRunner()
    args = ["--force"] if force else []
    result = runner.invoke(cli_init, args)
    print(result.output)


def start(host: str = "127.0.0.1", port: int = 8000, bi_port: int = 8088, no_bi: bool = False):
    """
    Запуск DAP Platform (UI + BI).
    
    Args:
        host: Хост (по умолчанию 127.0.0.1)
        port: Порт DAP UI (по умолчанию 8000)
        bi_port: Порт DAP BI (по умолчанию 8088)
        no_bi: Запустить только UI без BI
    
    Пример:
        >>> import dap4mkb
        >>> dap4mkb.start()  # UI на :8000, BI на :8088
        >>> dap4mkb.start(no_bi=True)  # Только UI
    """
    import os
    import sys
    import subprocess
    import time
    from pathlib import Path
    
    DAP_HOME = Path.home() / ".dap"
    
    # Check if initialized
    if not (DAP_HOME / "config.env").exists():
        print("DAP не инициализирован. Выполняю init()...")
        init()
        print()
    
    # Load config
    config_file = DAP_HOME / "config.env"
    if config_file.exists():
        from dotenv import load_dotenv
        load_dotenv(config_file)
    
    os.environ.setdefault("DAP_DEV_MODE", "true")
    os.environ.setdefault("DAP_HOME", str(DAP_HOME))
    
    print("=" * 50)
    print("  DAP Platform")
    print("=" * 50)
    print(f"  UI:  http://{host}:{port}")
    if not no_bi:
        print(f"  BI:  http://{host}:{bi_port}")
    print("=" * 50)
    print()
    print("  Логин: admin / admin123")
    print("  Для остановки: Interrupt Kernel (Jupyter) или Ctrl+C")
    print()
    
    processes = []
    
    try:
        # Start DAP BI
        if not no_bi:
            bi_env = os.environ.copy()
            bi_env["FLASK_APP"] = "superset"
            superset_config = DAP_HOME / "superset" / "superset_config.py"
            if superset_config.exists():
                bi_env["SUPERSET_CONFIG_PATH"] = str(superset_config)
            
            bi_cmd = f"superset run -h {host} -p {bi_port}"
            bi_process = subprocess.Popen(bi_cmd, env=bi_env, shell=True)
            processes.append(bi_process)
            print(f"[BI] Запущен на порту {bi_port}")
            time.sleep(2)
        
        # Start DAP UI
        import uvicorn
        print(f"[UI] Запуск на порту {port}...")
        uvicorn.run(
            "dap4mkb.server:app",
            host=host,
            port=port,
        )
        
    except KeyboardInterrupt:
        print("\n\nОстановка сервисов...")
    finally:
        for proc in processes:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        print("Все сервисы остановлены.")


def stop():
    """Остановка сервисов (для будущего использования)"""
    print("Используйте Interrupt Kernel в Jupyter или Ctrl+C")