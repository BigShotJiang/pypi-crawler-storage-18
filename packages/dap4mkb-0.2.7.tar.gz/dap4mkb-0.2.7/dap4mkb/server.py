"""
DAP4MKB Server - FastAPI application
Точка входа для uvicorn
"""

import os
import sys
from pathlib import Path

# Добавляем ui в путь для импортов
PACKAGE_DIR = Path(__file__).parent
UI_DIR = PACKAGE_DIR / "ui"
sys.path.insert(0, str(UI_DIR))

# Устанавливаем рабочую директорию для шаблонов и статики
os.chdir(UI_DIR)

# Импортируем приложение из ui/main.py
from main import app

# Реэкспортируем для uvicorn
__all__ = ["app"]