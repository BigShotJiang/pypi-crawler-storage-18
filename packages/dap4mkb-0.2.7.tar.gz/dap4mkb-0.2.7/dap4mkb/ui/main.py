from fastapi import FastAPI, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from routers.bi import router as bi_router
from auth import (
    get_ldap_client,
    get_session_manager,
    auth_middleware,
    add_user_to_context,
    get_current_user,
)
from routers.workflows import router as workflows_router

app = FastAPI(title="DataAudit Platform")
app.include_router(bi_router)
app.include_router(workflows_router)


# Auth middleware - protects all routes except /login, /health, /static
app.middleware("http")(auth_middleware)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup Jinja2 templates
templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "pages/home.html",
        {"request": request, "current_page": "home", **add_user_to_context(request)}
    )


@app.get("/reports", response_class=HTMLResponse)
async def reports(request: Request):
    return templates.TemplateResponse(
        "pages/reports.html",
        {"request": request, "current_page": "reports", **add_user_to_context(request)}
    )


@app.get("/analytics", response_class=HTMLResponse)
async def analytics(request: Request):
    return templates.TemplateResponse(
        "pages/bi_analytics.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


@app.get("/ai", response_class=HTMLResponse)
async def ai_assistant(request: Request):
    return templates.TemplateResponse(
        "pages/ai_assistant.html",
        {"request": request, "current_page": "ai", **add_user_to_context(request)}
    )


@app.get("/governance", response_class=HTMLResponse)
async def data_governance(request: Request):
    return templates.TemplateResponse(
        "pages/data_governance.html",
        {"request": request, "current_page": "governance", **add_user_to_context(request)}
    )


@app.get("/workflows", response_class=HTMLResponse)
async def workflows(request: Request):
    return templates.TemplateResponse(
        "pages/workflows.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/settings", response_class=HTMLResponse)
async def settings(request: Request):
    return templates.TemplateResponse(
        "pages/settings.html",
        {"request": request, "current_page": "settings", **add_user_to_context(request)}
    )


@app.get("/login", response_class=HTMLResponse)
async def login(request: Request, next: str = "/", error: str = None):
    # If already logged in, redirect
    user = await get_current_user(request)
    if user:
        return RedirectResponse(url=next, status_code=302)
    
    error_messages = {
        "invalid": "Неверный логин или пароль",
        "expired": "Сессия истекла. Войдите снова.",
        "unavailable": "Сервис авторизации недоступен. Обратитесь в службу поддержки.",
    }
    
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "next": next, "error_message": error_messages.get(error)}
    )


@app.post("/login")
async def login_post(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    next: str = Form("/"),
):
    ldap = get_ldap_client()
    session_mgr = get_session_manager()
    
    result = await ldap.authenticate(username.strip(), password)
    
    if not result.success:
        error = "unavailable" if result.error_code == "LDAP_UNREACHABLE" else "invalid"
        return RedirectResponse(url=f"/login?error={error}&next={next}", status_code=302)
    
    session = session_mgr.create_session(result.user)
    response = RedirectResponse(url=next, status_code=302)
    session_mgr.set_session_cookie(response, session)
    return response


@app.get("/logout")
async def logout(request: Request):
    session_mgr = get_session_manager()
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Выход...</title></head>
    <body>
    <script>
        window.location.replace('/login');
    </script>
    </body>
    </html>
    """
    response = HTMLResponse(html)
    session_mgr.logout(request, response)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

@app.get("/api/me")
async def me(request: Request):
    user = await get_current_user(request)
    if not user:
        return {"error": "Не авторизован"}
    return user.to_dict()

@app.get("/health")
async def health():
    return {"status": "ok"}