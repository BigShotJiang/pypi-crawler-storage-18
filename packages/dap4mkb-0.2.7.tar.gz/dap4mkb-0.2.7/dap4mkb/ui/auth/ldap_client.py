"""
DAP LDAP/Active Directory Client
"""

import os
import logging
from typing import Optional

from .models import User, Role, AuthResult

logger = logging.getLogger("dap.auth.ldap")


class LDAPClient:
    """LDAP client with dev mode support."""

    def __init__(self):
        self.dev_mode = os.getenv("DAP_DEV_MODE", "false").lower() == "true"
        self.server = os.getenv("LDAP_SERVER", "ldap://openldap:389")
        self.base_dn = os.getenv("LDAP_BASE_DN", "dc=dap,dc=local")
        self.bind_user = os.getenv("LDAP_BIND_USER", "")
        self.bind_password = os.getenv("LDAP_BIND_PASSWORD", "")

        if self.dev_mode:
            logger.warning("=" * 50)
            logger.warning("DEV MODE - authentication bypassed!")
            logger.warning("=" * 50)

    async def authenticate(self, username: str, password: str) -> AuthResult:
        if self.dev_mode:
            return self._dev_mode_auth(username)
        return await self._ldap_auth(username, password)

    def _dev_mode_auth(self, username: str) -> AuthResult:
        """Dev mode - role based on username."""
        username = username.lower().strip()

        if username == "admin":
            role, groups = Role.ADMIN, ["DAP_Admins"]
        elif username == "auditor":
            role, groups = Role.AUDITOR, ["DAP_Auditors"]
        else:
            role, groups = Role.USER, ["Domain Users"]

        user = User(
            user_id=username,
            full_name=f"Dev User {username.title()}",
            email=f"{username}@dap.local",
            role=role,
            groups=groups
        )

        logger.info(f"DEV MODE: '{username}' as {role.value}")
        return AuthResult(success=True, user=user)

    async def _ldap_auth(self, username: str, password: str) -> AuthResult:
        """Real LDAP authentication."""
        try:
            from ldap3 import Server, Connection, ALL, SUBTREE
            from ldap3.core.exceptions import LDAPException, LDAPBindError
        except ImportError:
            return AuthResult(success=False, error_message="ldap3 not installed", error_code="LDAP_NOT_INSTALLED")

        try:
            server = Server(self.server, get_info=ALL)
            service_conn = Connection(server, user=self.bind_user, password=self.bind_password, auto_bind=True)
        except LDAPException as e:
            logger.error(f"LDAP unreachable: {e}")
            return AuthResult(success=False, error_message="Сервис авторизации недоступен", error_code="LDAP_UNREACHABLE")

        try:
            # Search for user (OpenLDAP uses uid, AD uses sAMAccountName)
            user_filter = f"(uid={username})"
            user_base = f"ou=Users,{self.base_dn}"
            service_conn.search(
                user_base, 
                user_filter, 
                SUBTREE, 
                attributes=['cn', 'mail', 'displayName', 'givenName', 'sn', 'uid']
            )

            if not service_conn.entries:
                return AuthResult(success=False, error_message="Неверный логин или пароль", error_code="USER_NOT_FOUND")

            entry = service_conn.entries[0]
            user_dn = entry.entry_dn

            # Verify password by binding as user
            try:
                user_conn = Connection(server, user=user_dn, password=password, auto_bind=True)
                user_conn.unbind()
            except LDAPBindError:
                return AuthResult(success=False, error_message="Неверный логин или пароль", error_code="INVALID_PASSWORD")

            # Get user's groups (OpenLDAP: search groups that have this user as member)
            groups = []
            group_base = f"ou=Groups,{self.base_dn}"
            group_filter = f"(member={user_dn})"
            service_conn.search(group_base, group_filter, SUBTREE, attributes=['cn'])
            
            for group_entry in service_conn.entries:
                if group_entry.cn:
                    groups.append(str(group_entry.cn))

            # Build display name
            display_name = None
            if hasattr(entry, 'displayName') and entry.displayName:
                display_name = str(entry.displayName)
            elif hasattr(entry, 'cn') and entry.cn:
                display_name = str(entry.cn)
            else:
                display_name = username

            # Get email
            email = str(entry.mail) if hasattr(entry, 'mail') and entry.mail else f"{username}@dap.local"

            user = User(
                user_id=username,
                full_name=display_name,
                email=email,
                role=Role.from_groups(groups),
                groups=groups
            )
            
            logger.info(f"LDAP auth success: {username}, groups: {groups}, role: {user.role.value}")
            return AuthResult(success=True, user=user)

        except LDAPException as e:
            logger.error(f"LDAP error: {e}")
            return AuthResult(success=False, error_message="Ошибка авторизации", error_code="LDAP_ERROR")
        finally:
            service_conn.unbind()


_client: Optional[LDAPClient] = None

def get_ldap_client() -> LDAPClient:
    global _client
    if _client is None:
        _client = LDAPClient()
    return _client