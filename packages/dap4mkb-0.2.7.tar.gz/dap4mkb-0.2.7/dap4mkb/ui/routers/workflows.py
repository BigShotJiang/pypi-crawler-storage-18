"""
Workflows Router - API endpoints for Camunda integration
"""
from fastapi import APIRouter, Request
from auth import get_current_user
from services.camunda import get_camunda_client

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


@router.get("/stats")
async def get_workflow_stats(request: Request):
    """Get workflow statistics for current user"""
    user = await get_current_user(request)
    if not user:
        return {"error": "Не авторизован"}
    
    client = get_camunda_client()
    stats = await client.get_user_stats(
        user_id=user.user_id,
        groups=user.groups,
        role=user.role.value,
    )
    
    return {
        "my_tasks": stats.my_tasks,
        "group_tasks": stats.group_tasks,
        "active_processes": stats.active_processes,
        "completed_today": stats.completed_today,
        "role": user.role.value,
    }


@router.get("/apps")
async def get_available_apps(request: Request):
    """Get Camunda apps available for current user based on role"""
    user = await get_current_user(request)
    if not user:
        return {"error": "Не авторизован"}
    
    apps = []
    role = user.role.value
    
    # Define app access by role
    app_definitions = [
        {
            "id": "tasklist",
            "name": "Список задач",
            "description": "Управление задачами и выполнение бизнес-процессов",
            "url": "/camunda/app/tasklist/default/",
            "icon": "tasks",
            "roles": ["admin", "manager", "viewer"],
        },
        {
            "id": "cockpit",
            "name": "Мониторинг",
            "description": "Мониторинг процессов и операционная аналитика",
            "url": "/camunda/app/cockpit/default/",
            "icon": "dashboard",
            "roles": ["admin", "manager", "auditor"],
        },
        {
            "id": "admin",
            "name": "Администрирование",
            "description": "Управление пользователями, группами и авторизациями",
            "url": "/camunda/app/admin/default/",
            "icon": "settings",
            "roles": ["admin"],
        },
    ]
    
    for app in app_definitions:
        if role in app["roles"]:
            apps.append({
                "id": app["id"],
                "name": app["name"],
                "description": app["description"],
                "url": f"http://workflows.dap.localhost{app['url']}",
                "icon": app["icon"],
            })
    
    return {"apps": apps}
