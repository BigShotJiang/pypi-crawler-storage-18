"""BI Analytics API Router - Standalone mode"""
import os
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/bi", tags=["bi"])

# In-memory storage for standalone mode (resets on restart)
_user_dashboards = {}


class DashboardAdd(BaseModel):
    dashboard_id: int
    dashboard_title: str


@router.get("/dashboards")
async def get_available_dashboards(request: Request):
    """
    Получить список дашбордов из DAP BI.
    В standalone режиме возвращает пустой список - дашборды будут доступны
    после запуска DAP BI.
    """
    # TODO: При интеграции с DAP BI - запрашивать из SQLite или API
    bi_url = os.environ.get("DAP_BI_URL", "http://127.0.0.1:8088")
    
    # Возвращаем demo-дашборды для тестирования UI
    return [
        {"id": 1, "title": "Демо: Обзор данных", "published": True, "owners": ["Admin"]},
        {"id": 2, "title": "Демо: Качество данных", "published": True, "owners": ["Admin"]},
        {"id": 3, "title": "Демо: Аудит изменений", "published": False, "owners": ["Admin"]},
    ]


@router.get("/my-dashboards")
async def get_my_dashboards(request: Request):
    """Получить добавленные пользователем дашборды"""
    user = getattr(request.state, "user", None)
    user_id = user.user_id if user else "anonymous"
    
    return _user_dashboards.get(user_id, [])


@router.post("/my-dashboards")
async def add_dashboard(request: Request, data: DashboardAdd):
    """Добавить дашборд в список пользователя (макс. 6)"""
    user = getattr(request.state, "user", None)
    user_id = user.user_id if user else "anonymous"
    
    if user_id not in _user_dashboards:
        _user_dashboards[user_id] = []
    
    user_list = _user_dashboards[user_id]
    
    # Проверяем лимит
    if len(user_list) >= 6:
        raise HTTPException(status_code=400, detail="Максимум 6 дашбордов")
    
    # Проверяем дубликат
    if any(d["dashboard_id"] == data.dashboard_id for d in user_list):
        raise HTTPException(status_code=400, detail="Дашборд уже добавлен")
    
    user_list.append({
        "id": len(user_list) + 1,
        "dashboard_id": data.dashboard_id,
        "dashboard_title": data.dashboard_title,
        "position": len(user_list),
    })
    
    return {"status": "ok"}


@router.delete("/my-dashboards/{dashboard_id}")
async def remove_dashboard(request: Request, dashboard_id: int):
    """Удалить дашборд из списка пользователя"""
    user = getattr(request.state, "user", None)
    user_id = user.user_id if user else "anonymous"
    
    if user_id in _user_dashboards:
        _user_dashboards[user_id] = [
            d for d in _user_dashboards[user_id] 
            if d["dashboard_id"] != dashboard_id
        ]
    
    return {"status": "ok"}