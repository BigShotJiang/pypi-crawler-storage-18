"""
Camunda Database Client for DAP Platform
Direct PostgreSQL queries instead of REST API
"""
import asyncpg
from typing import Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import os


@dataclass
class WorkflowStats:
    """Workflow statistics for a user"""
    my_tasks: int = 0
    group_tasks: int = 0
    active_processes: int = 0
    completed_today: int = 0


class CamundaClient:
    """Client for Camunda database queries"""
    
    def __init__(self):
        db_user = os.getenv("DATABASE_USER", os.getenv("POSTGRES_USER", "dap_admin"))
        db_pass = os.getenv("DATABASE_PASSWORD", os.getenv("POSTGRES_PASSWORD", ""))
        db_host = os.getenv("DATABASE_HOST", "dap_db")
        db_name = "camunda_db"
        self.dsn = f"postgresql://{db_user}:{db_pass}@{db_host}:5432/{db_name}"
        self._pool: Optional[asyncpg.Pool] = None
    
    async def get_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            self._pool = await asyncpg.create_pool(self.dsn, min_size=1, max_size=5)
        return self._pool
    
    async def close(self):
        if self._pool:
            await self._pool.close()
    
    async def get_my_tasks_count(self, user_id: str) -> int:
        """Get count of tasks assigned to user"""
        try:
            pool = await self.get_pool()
            count = await pool.fetchval(
                "SELECT COUNT(*) FROM act_ru_task WHERE assignee_ = $1",
                user_id
            )
            return count or 0
        except Exception as e:
            print(f"DB error (my_tasks): {e}")
            return 0
    
    async def get_group_tasks_count(self, groups: list[str]) -> int:
        """Get count of tasks available for user's groups (unassigned)"""
        if not groups:
            return 0
        try:
            pool = await self.get_pool()
            count = await pool.fetchval(
                """
                SELECT COUNT(DISTINCT t.id_) 
                FROM act_ru_task t
                JOIN act_ru_identitylink il ON t.id_ = il.task_id_
                WHERE il.type_ = 'candidate' 
                  AND il.group_id_ = ANY($1)
                  AND t.assignee_ IS NULL
                """,
                groups
            )
            return count or 0
        except Exception as e:
            print(f"DB error (group_tasks): {e}")
            return 0
    
    async def get_active_processes_count(self) -> int:
        """Get count of active process instances"""
        try:
            pool = await self.get_pool()
            count = await pool.fetchval(
                "SELECT COUNT(*) FROM act_ru_execution WHERE parent_id_ IS NULL"
            )
            return count or 0
        except Exception as e:
            print(f"DB error (active_processes): {e}")
            return 0
    
    async def get_completed_today_count(self, user_id: str) -> int:
        """Get count of tasks completed today by user"""
        try:
            pool = await self.get_pool()
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            count = await pool.fetchval(
                """
                SELECT COUNT(*) FROM act_hi_taskinst 
                WHERE assignee_ = $1 
                  AND end_time_ IS NOT NULL 
                  AND end_time_ >= $2
                """,
                user_id, today_start
            )
            return count or 0
        except Exception as e:
            print(f"DB error (completed_today): {e}")
            return 0
    
    async def get_user_stats(self, user_id: str, groups: list[str], role: str) -> WorkflowStats:
        """Get all workflow stats for a user based on their role"""
        stats = WorkflowStats()
        
        # All roles except auditor see their tasks
        stats.my_tasks = await self.get_my_tasks_count(user_id)
        stats.group_tasks = await self.get_group_tasks_count(groups)
        
        # Admin, manager, auditor see active processes
        if role in ("admin", "manager", "auditor"):
            stats.active_processes = await self.get_active_processes_count()
        
        # Everyone sees completed today
        stats.completed_today = await self.get_completed_today_count(user_id)
        
        return stats


# Singleton instance
_camunda_client: Optional[CamundaClient] = None


def get_camunda_client() -> CamundaClient:
    global _camunda_client
    if _camunda_client is None:
        _camunda_client = CamundaClient()
    return _camunda_client