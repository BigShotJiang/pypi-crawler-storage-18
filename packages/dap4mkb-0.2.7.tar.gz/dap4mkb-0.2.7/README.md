# DAP4MKB

**DataAudit Platform** — платформа аудита и аналитики данных для банков.

## Быстрый старт

### Вариант 1: Командная строка
```bash
pip install dap4mkb[bi]
dap4mkb init
dap4mkb start
```

### Вариант 2: Python / Jupyter / Spyder
```python
import dap4mkb

# Первый запуск (создаёт БД и admin пользователя)
dap4mkb.init()

# Запуск платформы
dap4mkb.start()
```

После запуска:
- **DAP UI:** http://127.0.0.1:8000
- **DAP BI:** http://127.0.0.1:8088
- **Логин:** admin / admin123

## Возможности

- 📊 **DAP BI** — дашборды и визуализация (на базе Apache Superset)
- 🔐 **LDAP/AD** — интеграция с Active Directory
- 📁 **Отчёты** — генерация и управление отчётами
- ⚙️ **Workflows** — интеграция с Camunda BPM

## Установка
```bash
# Только UI (без BI)
pip install dap4mkb

# С BI аналитикой (рекомендуется)
pip install dap4mkb[bi]

# С Oracle
pip install dap4mkb[oracle]

# С PostgreSQL/Greenplum
pip install dap4mkb[postgres,greenplum]

# Всё вместе
pip install dap4mkb[all]
```

## Python API
```python
import dap4mkb

# Инициализация
dap4mkb.init()              # Создать конфиг и БД
dap4mkb.init(force=True)    # Переинициализация

# Запуск
dap4mkb.start()                      # UI + BI на стандартных портах
dap4mkb.start(port=9000)             # UI на порту 9000
dap4mkb.start(bi_port=9088)          # BI на порту 9088
dap4mkb.start(no_bi=True)            # Только UI без BI
dap4mkb.start(host="0.0.0.0")        # Доступ из сети
```

## CLI команды
```bash
dap4mkb --help              # Справка
dap4mkb --version           # Версия
dap4mkb init                # Инициализация
dap4mkb init --force        # Переинициализация
dap4mkb start               # Запуск UI + BI
dap4mkb start --no-bi       # Только UI
dap4mkb start --port 9000   # UI на другом порту
dap4mkb config show         # Показать конфигурацию
dap4mkb config set KEY VAL  # Установить параметр
```

## Конфигурация

Файл: `~/.dap/config.env`
```ini
# Режим разработки (без LDAP)
DAP_DEV_MODE=true

# Порты
DAP_UI_PORT=8000
DAP_BI_PORT=8088

# LDAP (для production)
LDAP_SERVER=ldaps://ad.company.ru:636
LDAP_BASE_DN=DC=company,DC=ru
LDAP_BIND_USER=cn=service,ou=users,dc=company,dc=ru
LDAP_BIND_PASSWORD=secret
```

## Структура файлов
```
~/.dap/
├── config.env              # Конфигурация DAP UI
├── dap.db                  # SQLite база DAP UI (будущее)
└── superset/
    ├── superset_config.py  # Конфигурация DAP BI
    └── superset.db         # SQLite база DAP BI
```

## Требования

- Python 3.9 - 3.11 (3.12 не поддерживается)
- 4 GB RAM (рекомендуется 8 GB)
- Windows / Linux / macOS

## Разработка
```bash
git clone https://github.com/pm291097/dap4mkb.git
cd dap4mkb
pip install -e ".[dev]"
```

## Лицензия

MIT