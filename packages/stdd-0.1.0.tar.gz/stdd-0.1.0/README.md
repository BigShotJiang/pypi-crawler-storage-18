# PyQt Template App

Universal template for creating PyQt6 + PyMySQL applications with role-based access control (Admin, Manager, Client).

## Features

- 🎯 **Universal Template** - Easily adaptable to any domain (hotels, car rentals, e-commerce, etc.)
- 🔐 **Role-Based Access** - Built-in support for Admin, Manager, and Client roles
- 📊 **Complete GUI** - Full-featured PyQt6 interface with tabs and forms
- 🗄️ **Database Integration** - Ready-to-use PyMySQL integration
- ⚙️ **Centralized Configuration** - All settings in one `config.py` file
- 🔒 **SQL Injection Protection** - Parameterized queries throughout

## Quick Start

### Installation

```bash
pip install stdd
```

### Basic Usage

#### Using Templates

1. Copy the template files to your project directory
2. Configure `config.py` with your database settings and table names
3. Create your database structure
4. Customize SQL queries in the window modules
5. Run your application

#### Using Examples

After installation, you can access the example application:

```python
# Access example files
import std.examples.main as example_app
# or find them at: site-packages/std/examples/
```

## Project Structure

```
std/
├── config.py                      # Configuration (START HERE!)
├── template_db.py                 # Database module
├── template_main.py               # Entry point
├── template_login_window.py       # Login window
├── template_admin_window.py       # Admin window
├── template_manager_window.py     # Manager window
├── template_client_window.py      # Client window
├── example_database_structure.sql # Example database structure
├── README_template.md             # Detailed instructions
└── examples/                      # Working example application
    ├── main.py                    # Example entry point
    ├── db.py                      # Example database module
    ├── login_window.py            # Example login window
    ├── admin_window.py            # Example admin window
    ├── manager_window.py          # Example manager window
    └── client_window.py           # Example client window
```

## Configuration

All settings are in `config.py`:

```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'your_database',
    'charset': 'utf8mb4'
}

TABLES = {
    'users': 'users',
    'roles': 'roles',
    'items': 'items',      # Your main entity table
    'orders': 'orders',    # Your orders/bookings table
    # ... more tables
}
```

## Example: Car Rental System

```python
TABLES = {
    'users': 'users',
    'roles': 'roles',
    'items': 'cars',           # cars instead of items
    'orders': 'rentals',       # rentals instead of orders
    'categories': 'car_types', # car types instead of categories
    # ...
}
```

## Requirements

- Python >= 3.8
- PyQt6 >= 6.6.0
- PyMySQL >= 1.1.0

## License

MIT License - see LICENSE file for details

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues, questions, or suggestions, please open an issue on GitHub.

---

**Made with ❤️ for the Python community**

