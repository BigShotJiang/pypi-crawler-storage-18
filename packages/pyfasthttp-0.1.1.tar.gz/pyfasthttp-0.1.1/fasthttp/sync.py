"""
Synchronous wrapper utilities for converting async methods to sync.
"""
import asyncio
import functools
import inspect
import threading


def async_to_sync(obj, name):
    """
    Wrap an asynchronous function or asynchronous generator method
    to make it synchronous.

    Parameters:
    - obj: Object containing the method.
    - name: Name of the method to wrap.

    Returns:
    Wrapped synchronous function or generator.
    """
    function = getattr(obj, name)

    try:
        main_loop = asyncio.get_event_loop()
    except RuntimeError:
        # Create and register a loop if none exists for the current thread.
        main_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(main_loop)

    def async_to_sync_gen(agen, loop, is_main_thread):
        async def anext(agen):
            try:
                return await agen.__anext__(), False
            except StopAsyncIteration:
                return None, True

        while True:
            if is_main_thread:
                item, done = loop.run_until_complete(anext(agen))
            else:
                item, done = asyncio.run_coroutine_threadsafe(
                    anext(agen), loop
                ).result()

            if done:
                break

            yield item

    @functools.wraps(function)
    def async_to_sync_wrap(*args, **kwargs):
        coroutine = function(*args, **kwargs)

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if (
            threading.current_thread() is threading.main_thread()
            or not main_loop.is_running()
        ):
            if loop.is_running():
                return coroutine
            else:
                if inspect.iscoroutine(coroutine):
                    return loop.run_until_complete(coroutine)

                if inspect.isasyncgen(coroutine):
                    return async_to_sync_gen(coroutine, loop, True)
        else:
            if inspect.iscoroutine(coroutine):
                if loop.is_running():

                    async def coro_wrapper():
                        return await asyncio.wrap_future(
                            asyncio.run_coroutine_threadsafe(coroutine, main_loop)
                        )

                    return coro_wrapper()
                else:
                    return asyncio.run_coroutine_threadsafe(
                        coroutine, main_loop
                    ).result()

            if inspect.isasyncgen(coroutine):
                if loop.is_running():
                    return coroutine
                else:
                    return async_to_sync_gen(coroutine, main_loop, False)

    setattr(obj, name, async_to_sync_wrap)


def wrap_methods(source):
    """
    Wrap asynchronous methods in a class to make them synchronous.

    Parameters:
    - source: Class containing asynchronous methods.
    """
    for name in dir(source):
        # Skip special methods and private methods
        if name.startswith("_"):
            continue
            
        method = getattr(source, name, None)
        
        # Skip if not a method or if it's a property
        if not callable(method):
            continue

        if inspect.iscoroutinefunction(method) or inspect.isasyncgenfunction(method):
            async_to_sync(source, name)


def enable_sync():
    """
    Enable synchronous wrappers for all async classes.
    This should be called after importing the module.
    """
    from .client import Client
    from .response import Response
    from .pool import ConnectionPool
    from .connection import Connection
    
    wrap_methods(Client)
    wrap_methods(Response)
    wrap_methods(ConnectionPool)
    wrap_methods(Connection)

