# cs_year_explorer
[![PyPI version](https://badge.fury.io/py/cs-year-explorer.svg)](https://badge.fury.io/py/cs-year-explorer)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/cs-year-explorer)](https://pepy.tech/project/cs-year-explorer)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package that provides a structured summary of key developments in computer science for a given year. Quickly access concise and relevant information about major breakthroughs, notable research papers, technological advancements, and influential events in CS history.

---

## 📦 Installation

Install the package using pip:

```bash
pip install cs_year_explorer
```

---

## 🚀 Usage

### Basic Usage (uses default LLM7 model)
```python
from cs_year_explorer import cs_year_explorer

# Example: Get CS developments for the year 2023
response = cs_year_explorer("2023")
print(response)
```

### Custom LLM Integration
You can replace the default LLM (ChatLLM7) with any LangChain-compatible model:

#### Using OpenAI
```python
from langchain_openai import ChatOpenAI
from cs_year_explorer import cs_year_explorer

llm = ChatOpenAI()
response = cs_year_explorer("2020", llm=llm)
print(response)
```

#### Using Anthropic
```python
from langchain_anthropic import ChatAnthropic
from cs_year_explorer import cs_year_explorer

llm = ChatAnthropic()
response = cs_year_explorer("2019", llm=llm)
print(response)
```

#### Using Google Generative AI
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from cs_year_explorer import cs_year_explorer

llm = ChatGoogleGenerativeAI()
response = cs_year_explorer("2022", llm=llm)
print(response)
```

---

## 🔧 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | The year (e.g., `"2023"`) or query to analyze (e.g., `"major CS events in 2020"`) |
| `api_key` | `Optional[str]` | LLM7 API key (default: fetched from `LLM7_API_KEY` environment variable) |
| `llm` | `Optional[BaseChatModel]` | Custom LangChain LLM instance (default: `ChatLLM7`) |

---

## 🔑 API Key
- **Default LLM**: Uses `ChatLLM7` from [langchain_llm7](https://pypi.org/project/langchain-llm7/).
- **Free Tier**: Sufficient for most use cases.
- **Custom API Key**: Pass via environment variable `LLM7_API_KEY` or directly:
  ```python
  cs_year_explorer("2021", api_key="your_api_key_here")
  ```
- **Get a Free Key**: Register at [https://token.llm7.io/](https://token.llm7.io/).

---

## 📜 Features
- Structured summary of **major CS breakthroughs** for any year.
- Covers **research papers, tech advancements, and influential events**.
- Works with **multiple LLM providers** (OpenAI, Anthropic, Google, etc.).
- **Regex-validated output** for consistency.

---

## 📝 Example Output
For `cs_year_explorer("2023")`, the response might include:
```python
[
    "2023: Foundation Models Breakthroughs",
    "   - GPT-4 released by OpenAI (March)",
    "   - Claude 2 by Anthropic (July)",
    "   - Research papers: 'Scaling Laws' (Kaplan et al.)",
    "2023: Quantum Computing Milestones",
    "   - IBM's 433-qubit Osprey processor",
    "   - Google's error-corrected logical qubit demo"
]
```

---

## 🔧 Dependencies
- Python 3.8+
- `langchain-core`, `langchain_llm7` (default), or any LangChain-compatible LLM.

---

## 📢 Support & Issues
For bugs or feature requests, open an issue on [GitHub](https://github.com/chigwell/cs-year-explorer/issues).

---

## 👤 Author
- **Eugene Evstafev** ([@chigwell](https://github.com/chigwell))
- **Email**: [hi@euegne.plus](mailto:hi@euegne.plus)

---

## 📜 License
MIT License (see [LICENSE](https://github.com/chigwell/cs-year-explorer/blob/main/LICENSE)).