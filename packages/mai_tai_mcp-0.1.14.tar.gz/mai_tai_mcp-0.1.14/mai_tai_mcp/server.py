"""MCP server for mai-tai AI agent collaboration platform."""

import signal
import sys
import time
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from .backend import MaiTaiBackend, MaiTaiBackendError, create_backend
from .config import ConfigurationError, get_config

# ============================================================================
# Load Agent Instructions from Prompt File
# ============================================================================

def _load_agent_instructions() -> str:
    """Load agent instructions from the prompts directory.

    Loads once at module import time. Fails fast if the file is missing.

    Returns:
        The contents of agent_instructions.md

    Raises:
        RuntimeError: If the prompt file cannot be found or read
    """
    prompts_dir = Path(__file__).parent / "prompts"
    instructions_file = prompts_dir / "agent_instructions.md"

    if not instructions_file.exists():
        raise RuntimeError(
            f"Missing agent instructions file: {instructions_file}\n"
            "This file is required for the MCP server to start."
        )

    try:
        return instructions_file.read_text(encoding="utf-8")
    except Exception as e:
        raise RuntimeError(
            f"Failed to read agent instructions: {instructions_file}\n"
            f"Error: {e}"
        ) from e


# Load instructions once at module import time
_AGENT_INSTRUCTIONS = _load_agent_instructions()

# ============================================================================
# Global State
# ============================================================================

# Flag for clean shutdown on SIGINT (Ctrl+C)
# When set to True, the server should finish current work and exit gracefully
shutting_down: bool = False


def _handle_shutdown_signal(signum: int, frame: Any) -> None:
    """Handle SIGINT/SIGTERM for clean shutdown."""
    global shutting_down
    shutting_down = True
    print("\nReceived shutdown signal, finishing current work...", file=sys.stderr)

# Create FastMCP server with externalized instructions
mcp = FastMCP(
    name="mai-tai-mcp",
    instructions=_AGENT_INSTRUCTIONS,
)

# Global backend client (initialized on first use)
_backend: Optional[MaiTaiBackend] = None

# Track last seen message ID per channel for unread detection
# Key: channel_id, Value: last message ID the agent has seen
_last_seen_messages: dict[str, str] = {}


def get_backend() -> MaiTaiBackend:
    """Get or create the backend client instance."""
    global _backend
    if _backend is None:
        try:
            config = get_config()
            _backend = create_backend(config)
            _backend.connect()
        except Exception as e:
            raise MaiTaiBackendError(0, f"Failed to initialize mai-tai backend: {e}") from e
    return _backend


def _update_last_seen(channel_id: str, message_id: str) -> None:
    """Update the last seen message ID for a channel."""
    _last_seen_messages[channel_id] = message_id


def _check_unread_messages(backend: MaiTaiBackend, channel_id: str) -> list[dict[str, Any]]:
    """
    Check for unread human messages in a channel since the agent's last interaction.

    Returns a list of unread user messages (empty list if none).
    """
    last_seen = _last_seen_messages.get(channel_id)

    if not last_seen:
        # First interaction with this channel - no unread messages
        return []

    try:
        result = backend.get_messages(channel_id, limit=50, after=last_seen)
        messages = result.get("messages", [])

        # Filter for user messages only
        unread = [
            {
                "content": msg.get("content", ""),
                "sender_id": msg.get("sender_id"),
                "created_at": msg.get("created_at"),
            }
            for msg in messages
            if msg.get("sender_type") == "user"
        ]

        return unread
    except Exception as e:
        print(f"Error checking unread messages: {e}", file=sys.stderr)
        return []


# ============================================================================
# HTTP Polling for Response Detection
# ============================================================================


def _wait_for_response_polling(
    backend: "MaiTaiBackend",
    channel_id: str,
    after_message_id: str,
    timeout_seconds: int,
    poll_interval: float = 3.0,
) -> dict[str, Any] | None:
    """
    Wait for a human response using HTTP polling.

    Simple and reliable - polls for new messages every few seconds.
    Returns the response message or None on timeout.

    Args:
        backend: The backend client instance
        channel_id: Channel to poll for messages
        after_message_id: Only look for messages after this ID (the question we sent)
        timeout_seconds: How long to wait before timing out
        poll_interval: How often to poll (default: 3 seconds)
    """
    start_time = time.time()

    while time.time() - start_time < timeout_seconds:
        try:
            # Get messages after the question we sent
            result = backend.get_messages(channel_id, limit=10, after=after_message_id)
            messages = result.get("messages", [])

            # Look for a user response
            for msg in messages:
                if msg.get("sender_type") == "user":
                    return {
                        "id": msg.get("id"),  # Include ID for last_seen tracking
                        "content": msg.get("content", ""),
                        "sender_id": msg.get("sender_id"),
                        "created_at": msg.get("created_at"),
                    }

            # No response yet, wait before polling again
            time.sleep(poll_interval)

        except Exception as e:
            print(f"Polling error: {e}", file=sys.stderr)
            time.sleep(poll_interval)

    return None  # Timeout


# ============================================================================
# Primary Tool - Chat with Human
# ============================================================================


@mcp.tool()
def chat_with_human(
    message: str,
    channel_name: Optional[str] = None,
    timeout_seconds: int = 300,
) -> dict[str, Any]:
    """Chat with a human - send a message and wait for their response.

    This is your only way to communicate with humans via mai-tai.
    Use it for everything: questions, status updates, progress reports, and check-ins.
    It always waits for a response so the conversation keeps flowing.

    Args:
        message: What you want to say to the human (be clear and conversational)
        channel_name: Optional channel name. If not provided, uses the project's first channel
        timeout_seconds: How long to wait for a response (default: 300 = 5 minutes)

    Returns:
        Dictionary with the human's response, unread messages alert, or timeout status
    """
    backend = get_backend()

    # Get available channels
    channels = backend.list_channels()

    if not channels:
        return {
            "status": "error",
            "error": "No channels found in project. Please create a channel in the mai-tai web UI first.",
        }

    # If no channel specified, use the first available channel
    if channel_name:
        channel = next((c for c in channels if c["name"] == channel_name), None)
    else:
        channel = channels[0]
        channel_name = channel["name"]

    if not channel:
        # List available channels for the agent
        available = [c["name"] for c in channels]
        return {
            "status": "error",
            "error": f"Channel '{channel_name}' not found. Agents cannot create channels.",
            "available_channels": available,
            "hint": "Ask a human to create this channel via the mai-tai web UI, or use one of the available channels.",
        }

    channel_id = channel["id"]

    # Check for unread messages before sending
    unread = _check_unread_messages(backend, channel_id)
    if unread:
        return {
            "status": "unread_messages",
            "unread": unread,
            "channel": channel_name,
            "note": "Human sent messages while you were working. Review before continuing.",
            "pending_message": message,
        }

    # Send the message
    sent_message = backend.send_message(
        channel_id=channel_id,
        content=message,
        sender_type="agent",
        metadata={"type": "chat", "awaiting_response": True},
    )

    # Always wait for response using HTTP polling (simple and reliable)
    response = _wait_for_response_polling(
        backend=backend,
        channel_id=channel_id,
        after_message_id=sent_message["id"],
        timeout_seconds=timeout_seconds,
        poll_interval=3.0,  # Check every 3 seconds
    )

    if response:
        # Update last seen to the response we received (not our sent message)
        # This prevents the response from showing as "unread" on next chat
        _update_last_seen(channel_id, response["id"])
        return {
            "status": "response_received",
            "response": response["content"],
            "channel": channel_name,
        }

    # Update last seen to our sent message on timeout
    _update_last_seen(channel_id, sent_message["id"])
    return {
        "status": "no_response",
        "channel": channel_name,
        "note": f"No response after {timeout_seconds} seconds. Human may respond later - check back with get_messages if needed.",
    }


# ============================================================================
# Channel Management Tools
# ============================================================================


@mcp.tool()
def list_channels() -> dict[str, Any]:
    """List all channels in the mai-tai project.

    Returns:
        Dictionary with 'channels' key containing list of all channels
    """
    backend = get_backend()
    channels = backend.list_channels()
    return {
        "channels": channels,
        "count": len(channels),
        "project": backend.project_name,
    }


# NOTE: create_channel tool has been removed.
# Agents should only send messages to channels created by humans via the UI.
# This prevents confusion from agents creating duplicate or unexpected channels.


@mcp.tool()
def get_channel(channel_name: Optional[str] = None) -> dict[str, Any]:
    """Get details about a specific channel.

    Args:
        channel_name: The channel name. If not provided, uses the project's first channel.

    Returns:
        Channel details including id, name, type, and message count
    """
    backend = get_backend()
    channels = backend.list_channels()

    if not channels:
        return {
            "status": "error",
            "error": "No channels found in project.",
        }

    if channel_name:
        channel = next((c for c in channels if c["name"] == channel_name), None)
    else:
        channel = channels[0]

    if not channel:
        available = [c["name"] for c in channels]
        return {
            "status": "error",
            "error": f"Channel '{channel_name}' not found.",
            "available_channels": available,
        }

    return backend.get_channel(channel["id"])


# ============================================================================
# Message Tools
# ============================================================================


@mcp.tool()
def get_messages(
    channel_name: Optional[str] = None,
    limit: int = 50,
) -> dict[str, Any]:
    """Get messages from a channel.

    Args:
        channel_name: The channel to read from. If not provided, uses the project's first channel.
        limit: Maximum number of messages to return (default: 50)

    Returns:
        Dictionary with 'messages' list and channel info
    """
    backend = get_backend()
    channels = backend.list_channels()

    if not channels:
        return {
            "status": "error",
            "error": "No channels found in project.",
        }

    if channel_name:
        channel = next((c for c in channels if c["name"] == channel_name), None)
    else:
        channel = channels[0]
        channel_name = channel["name"]

    if not channel:
        available = [c["name"] for c in channels]
        return {
            "status": "error",
            "error": f"Channel '{channel_name}' not found.",
            "available_channels": available,
        }

    channel_id = channel["id"]
    result = backend.get_messages(channel_id, limit=limit)

    # Update last seen to the most recent message
    messages = result.get("messages", [])
    if messages:
        latest_message = messages[-1]
        _update_last_seen(channel_id, latest_message.get("id", ""))

    result["channel"] = channel_name
    return result


# ============================================================================
# Utility Tools
# ============================================================================


@mcp.tool()
def get_project_info() -> dict[str, Any]:
    """Get information about the connected mai-tai project.

    Returns:
        Project details including id, name, and connection status
    """
    backend = get_backend()
    return {
        "project_id": backend.project_id,
        "project_name": backend.project_name,
        "api_url": backend.config.api_url,
        "status": "connected",
    }


# ============================================================================
# Main Entry Point
# ============================================================================


def main() -> None:
    """Main entry point for the MCP server.

    v2 behavior:
    - Fail fast on configuration errors (missing env vars)
    - Register signal handlers for clean shutdown
    - Exit cleanly on SIGINT (Ctrl+C) with status 0
    - Exit with non-zero status on fatal errors
    """
    global shutting_down

    # Register signal handlers for clean shutdown
    signal.signal(signal.SIGINT, _handle_shutdown_signal)
    signal.signal(signal.SIGTERM, _handle_shutdown_signal)

    try:
        # Validate configuration early (fail fast on missing env vars)
        # This will raise ConfigurationError with a clear message if config is invalid
        config = get_config()
        print(f"mai-tai-mcp: connecting to {config.api_url}", file=sys.stderr)

        # Run the server with stdio transport
        mcp.run(transport="stdio")

        # Clean exit after server stops
        if shutting_down:
            print("mai-tai-mcp: shutdown complete", file=sys.stderr)
            sys.exit(0)

    except ConfigurationError as e:
        # Configuration errors are fatal - clear message, non-zero exit
        print(f"\n{e}", file=sys.stderr)
        sys.exit(1)

    except KeyboardInterrupt:
        # User pressed Ctrl+C - clean exit
        print("\nmai-tai-mcp: shutdown complete", file=sys.stderr)
        sys.exit(0)

    except Exception as e:
        # Unexpected error - log and exit with non-zero status
        print(f"mai-tai-mcp fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
