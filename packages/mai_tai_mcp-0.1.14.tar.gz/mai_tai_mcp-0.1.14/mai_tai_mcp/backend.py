"""Backend client for communicating with mai-tai API (v2).

This module provides the HTTP client for communicating with the Mai-Tai backend.
In v2, it uses the structured error types from errors.py to classify failures
as recoverable (retry with backoff) or fatal (exit the process).
"""

from typing import Any, Optional

import httpx

from .config import MaiTaiConfig
from .errors import (
    FatalRuntimeError,
    MaiTaiError,
    RecoverableError,
    classify_http_error,
)


class MaiTaiBackendError(MaiTaiError):
    """Legacy error class for backward compatibility.

    New code should catch RecoverableError or FatalRuntimeError instead.
    """

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Backend error ({status_code}): {detail}")


class MaiTaiBackend:
    """Synchronous client for mai-tai backend API (v2).

    Uses synchronous httpx since MCP tools are called synchronously.
    In v2, HTTP errors are classified as recoverable or fatal using
    the errors module.
    """

    def __init__(self, config: MaiTaiConfig):
        """Initialize backend client with configuration."""
        self.config = config
        self._client: Optional[httpx.Client] = None
        self.project_id: Optional[str] = None
        self.project_name: Optional[str] = None

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.config.api_url.rstrip("/"),
                headers={"X-API-Key": self.config.api_key},
                timeout=30.0,
            )
        return self._client

    def _handle_error(self, e: Exception, context: str = "") -> MaiTaiError:
        """Convert an exception to the appropriate MaiTaiError type.

        Args:
            e: The caught exception
            context: Optional context string for the error message

        Returns:
            RecoverableError or FatalRuntimeError based on the error type

        Raises:
            The appropriate error type (never returns normally for HTTP errors)
        """
        prefix = f"{context}: " if context else ""

        if isinstance(e, httpx.HTTPStatusError):
            # HTTP error - classify by status code
            error = classify_http_error(e.response.status_code, e.response.text)
            error.original_error = e
            raise error

        if isinstance(e, httpx.TimeoutException):
            # Timeout - always recoverable
            raise RecoverableError(f"{prefix}Request timed out", original_error=e)

        if isinstance(e, httpx.ConnectError):
            # Connection error - always recoverable
            raise RecoverableError(f"{prefix}Connection failed", original_error=e)

        if isinstance(e, httpx.RequestError):
            # Other request errors - treat as recoverable
            raise RecoverableError(f"{prefix}{str(e)}", original_error=e)

        # Unknown error type - treat as recoverable to be safe
        raise RecoverableError(f"{prefix}Unexpected error: {str(e)}", original_error=e)

    def connect(self) -> bool:
        """Verify connection and get project info.

        Raises:
            RecoverableError: For transient errors (retry with backoff)
            FatalRuntimeError: For permanent errors (auth failure, etc.)
        """
        try:
            client = self._get_client()
            response = client.get("/api/v1/mcp/auth/verify")
            response.raise_for_status()
            data = response.json()
            self.project_id = data["project_id"]
            self.project_name = data["project_name"]
            return True
        except (RecoverableError, FatalRuntimeError):
            raise  # Already classified
        except Exception as e:
            self._handle_error(e, "Failed to connect")

    def list_channels(self) -> list[dict[str, Any]]:
        """List all channels in the project.

        Raises:
            RecoverableError: For transient errors
            FatalRuntimeError: For permanent errors
        """
        try:
            client = self._get_client()
            response = client.get("/api/v1/mcp/channels")
            response.raise_for_status()
            data = response.json()
            return data["channels"]
        except (RecoverableError, FatalRuntimeError):
            raise
        except Exception as e:
            self._handle_error(e, "Failed to list channels")
            return []  # Unreachable, but makes type checker happy

    # NOTE: create_channel method removed - agents should only use channels created by humans

    def get_channel(self, channel_id: str) -> dict[str, Any]:
        """Get a channel by ID.

        Raises:
            RecoverableError: For transient errors
            FatalRuntimeError: For permanent errors
        """
        try:
            client = self._get_client()
            response = client.get(f"/api/v1/mcp/channels/{channel_id}")
            response.raise_for_status()
            return response.json()
        except (RecoverableError, FatalRuntimeError):
            raise
        except Exception as e:
            self._handle_error(e, f"Failed to get channel {channel_id}")
            return {}  # Unreachable

    def send_message(
        self,
        channel_id: str,
        content: str,
        sender_type: str = "agent",
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Send a message to a channel.

        Raises:
            RecoverableError: For transient errors
            FatalRuntimeError: For permanent errors
        """
        try:
            client = self._get_client()
            payload: dict[str, Any] = {
                "content": content,
                "sender_type": sender_type,
            }
            if metadata:
                payload["metadata"] = metadata

            response = client.post(
                f"/api/v1/mcp/channels/{channel_id}/messages",
                json=payload,
            )
            response.raise_for_status()
            return response.json()
        except (RecoverableError, FatalRuntimeError):
            raise
        except Exception as e:
            self._handle_error(e, "Failed to send message")
            return {}  # Unreachable

    def get_messages(
        self,
        channel_id: str,
        limit: int = 50,
        after: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get messages from a channel.

        Raises:
            RecoverableError: For transient errors
            FatalRuntimeError: For permanent errors
        """
        try:
            client = self._get_client()
            params: dict[str, Any] = {"limit": limit}
            if after:
                params["after"] = after

            response = client.get(
                f"/api/v1/mcp/channels/{channel_id}/messages",
                params=params,
            )
            response.raise_for_status()
            return response.json()
        except (RecoverableError, FatalRuntimeError):
            raise
        except Exception as e:
            self._handle_error(e, "Failed to get messages")
            return {}  # Unreachable

    def close(self) -> None:
        """Close the client."""
        if self._client:
            self._client.close()
            self._client = None


def create_backend(config: Optional[MaiTaiConfig] = None) -> MaiTaiBackend:
    """Create a mai-tai backend client instance.

    Args:
        config: Optional configuration. If not provided, loads from environment.

    Returns:
        Configured MaiTaiBackend instance
    """
    if config is None:
        from .config import get_config

        config = get_config()

    return MaiTaiBackend(config)

