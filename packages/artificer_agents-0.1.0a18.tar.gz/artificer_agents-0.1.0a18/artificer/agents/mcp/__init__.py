"""MCP client module for Artificer."""

from artificer.agents.mcp.client import MCPClient

__all__ = [
    "MCPClient",
]
