"""MCP client wrapper for tool discovery and invocation."""

from __future__ import annotations

from typing import Any

from fastmcp import Client

from artificer.agents.models.base import Tool


class MCPClient:
    """MCP client for tool discovery and invocation.

    Wraps fastmcp Client to provide:
    - Connection to MCP servers
    - Tool discovery with namespace filtering
    - Tool invocation
    """

    def __init__(self, servers: list[str | dict[str, Any]]) -> None:
        """Initialize with list of MCP server configs.

        Args:
            servers: List of server URLs or config dicts.
                     Can be URLs, command strings, or full config dicts.
        """
        self._servers = servers
        self._clients: list[Client] = []  # type: ignore[type-arg]
        self._tools: dict[str, tuple[Client, Any]] = {}  # type: ignore[type-arg]
        self._connected = False

    async def connect(self) -> None:
        """Connect to all configured MCP servers and discover tools."""
        if self._connected:
            return

        for server in self._servers:
            client = Client(server)
            await client.__aenter__()  # type: ignore[no-untyped-call]
            self._clients.append(client)

            # Discover and index tools
            tools = await client.list_tools()
            for tool in tools:
                self._tools[tool.name] = (client, tool)

        self._connected = True

    async def get_tools(self, namespaces: list[str] | None = None) -> list[Tool]:
        """Get tools filtered by namespace allowlist.

        Args:
            namespaces: List of namespace prefixes to filter by.
                       If None, returns all tools.

        Returns:
            List of Tool objects for model prompts.
        """
        if not self._connected:
            await self.connect()

        result: list[Tool] = []
        for name, (_, tool) in self._tools.items():
            # Filter by namespace if provided
            if namespaces is not None:
                if not any(name.startswith(ns) for ns in namespaces):
                    continue

            result.append(
                Tool(
                    name=tool.name,
                    description=tool.description or "",
                    parameters=tool.inputSchema or {},
                )
            )

        return result

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        """Invoke a tool by name.

        Args:
            name: Name of the tool to invoke.
            arguments: Arguments to pass to the tool.

        Returns:
            Tool result data.

        Raises:
            KeyError: If tool not found.
            RuntimeError: If tool returns an error.
        """
        if not self._connected:
            await self.connect()

        if name not in self._tools:
            raise KeyError(f"Tool '{name}' not found")

        client, _ = self._tools[name]
        result = await client.call_tool(name, arguments)

        # Check for error flag in result (MCP protocol)
        # Use getattr with default to avoid MagicMock issues in tests
        if getattr(result, "isError", False) is True:
            error_msg = self._extract_error_message(result)
            raise RuntimeError(f"Tool '{name}' returned error: {error_msg}")

        # Extract content from result
        if hasattr(result, "content") and result.content:
            # Check for error content type
            for content in result.content:
                content_type = getattr(content, "type", None)
                if content_type == "error":
                    error_text = getattr(content, "text", str(content))
                    raise RuntimeError(f"Tool '{name}' returned error: {error_text}")
            # Return text content if available
            for content in result.content:
                if hasattr(content, "text"):
                    return content.text
            return result.content
        return result

    def _extract_error_message(self, result: Any) -> str:
        """Extract error message from MCP result."""
        if hasattr(result, "content") and result.content:
            for content in result.content:
                if hasattr(content, "text"):
                    return str(content.text)
        return str(result)

    async def close(self) -> None:
        """Disconnect from all servers."""
        for client in self._clients:
            await client.__aexit__(None, None, None)  # type: ignore[no-untyped-call]
        self._clients.clear()
        self._tools.clear()
        self._connected = False

    async def __aenter__(self) -> MCPClient:
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit."""
        await self.close()
