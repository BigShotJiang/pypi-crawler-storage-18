"""Model abstraction module for Artificer."""

from artificer.agents.models.base import Model, Tool

__all__ = [
    "Model",
    "OpenAIModel",
    "Tool",
]


def __getattr__(name: str) -> type:
    """Lazy import for optional model implementations."""
    if name == "OpenAIModel":
        try:
            from artificer.agents.models.openai import OpenAIModel

            return OpenAIModel
        except ImportError as e:
            raise ImportError(
                "OpenAIModel requires the 'openai' extra. "
                "Install with: pip install artificer-agents[openai]"
            ) from e
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
