"""OpenAI model implementation."""

from typing import Any, cast

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam
from openai.types.shared_params import ResponseFormatJSONObject

from artificer.agents.models.base import Model


class OpenAIModel(Model):
    """OpenAI model implementation."""

    def __init__(
        self,
        model: str = "gpt-4o",
        client: AsyncOpenAI | None = None,
    ) -> None:
        """Initialize OpenAI model.

        Args:
            model: Model identifier (e.g., "gpt-4o", "gpt-4o-mini").
            client: Optional AsyncOpenAI client. Created if not provided.
        """
        self._model = model
        self._client = client or AsyncOpenAI()

    async def call(
        self,
        messages: list[dict[str, Any]],
        response_schema: dict[str, Any] | None = None,
    ) -> str:
        """Call OpenAI model and return text response.

        Note: response_schema is accepted for interface compatibility but not used.
        We use json_object mode which guarantees valid JSON. The schema is included
        in the prompt for the model to follow, and validated with Pydantic after.
        """
        _ = response_schema  # Schema is in prompt, validated after response
        response_format: ResponseFormatJSONObject = {"type": "json_object"}

        # Newer models (o1, o3, gpt-5+) use max_completion_tokens
        uses_new_api = any(self._model.startswith(p) for p in ("o1", "o3", "gpt-5"))

        if uses_new_api:
            response = await self._client.chat.completions.create(
                model=self._model,
                messages=cast(list[ChatCompletionMessageParam], messages),
                response_format=response_format,
                max_completion_tokens=16000,
            )
        else:
            response = await self._client.chat.completions.create(
                model=self._model,
                messages=cast(list[ChatCompletionMessageParam], messages),
                response_format=response_format,
                max_tokens=16000,
            )

        content = response.choices[0].message.content
        if content is None:
            raise ValueError("Model returned no content")

        return str(content)
