"""Model abstraction layer."""

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel


class Tool(BaseModel):
    """Tool definition for model prompts."""

    name: str
    description: str
    parameters: dict[str, Any]


class Model(ABC):
    """Abstract model interface.

    Models implement a simple call interface:
    - Messages in, text out
    - Model-agnostic, no provider-specific features
    """

    @abstractmethod
    async def call(
        self,
        messages: list[dict[str, Any]],
        response_schema: dict[str, Any] | None = None,
    ) -> str:
        """Call the model and return text response.

        Args:
            messages: Chat messages to send to the model.
            response_schema: Optional JSON schema for structured output.

        Returns:
            Text response from the model.
        """
        ...
