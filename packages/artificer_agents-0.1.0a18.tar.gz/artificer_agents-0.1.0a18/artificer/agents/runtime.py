"""Agent runtime loop."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import sys
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel

from artificer.agents.actions import Action, ActionList, build_action_schema
from artificer.agents.context import WorkingMemory
from artificer.agents.debugger import debug_breakpoint
from artificer.agents.models.base import Tool
from artificer.agents.prompts import build_system_prompt

if TYPE_CHECKING:
    from artificer.agents.agent import Agent

logger = logging.getLogger("artificer.agents")
logger.setLevel(logging.WARNING)  # Default to WARNING; verbose mode lowers to DEBUG

# Circuit breaker: disable tools after this many consecutive failures
MAX_TOOL_FAILURES = 3


def _configure_verbose_logging() -> None:
    """Configure the logger for verbose output if not already configured."""
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
        logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


def _parse_actions(text: str) -> list[Action]:
    """Parse ActionList from model response text.

    Extracts JSON from the response, handling markdown code blocks.
    Returns the list of actions.
    """
    # Try to find JSON in code blocks first
    json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1)
    else:
        # Try to find raw JSON object
        json_match = re.search(r"\{.*\}", text, re.DOTALL)
        if json_match:
            json_str = json_match.group(0)
        else:
            raise ValueError(f"No JSON found in response: {text[:200]}")

    data = json.loads(json_str)
    action_list = ActionList.model_validate(data)
    return action_list.actions


class ToolCallRecord(BaseModel):
    """Record of a tool call."""

    tool_name: str
    arguments: dict[str, Any]
    result: Any
    iteration: int


class SubagentCallRecord(BaseModel):
    """Record of a subagent call."""

    subagent_name: str
    input: dict[str, Any]
    output: Any
    iteration: int


class RunResult(BaseModel, arbitrary_types_allowed=True):
    """Result of an agent execution."""

    output: BaseModel | None
    iterations: int
    termination_reason: Literal["done", "max_iterations", "error"]
    tool_calls: list[ToolCallRecord] = []
    subagent_calls: list[SubagentCallRecord] = []
    error: str | None = None


def _truncate(text: str, max_len: int = 200) -> str:
    """Truncate text for logging."""
    if len(text) <= max_len:
        return text
    return text[:max_len] + "..."


async def run_agent(
    agent: Agent,
    input_data: BaseModel,
    *,
    verbose: bool = False,
    debug: bool = False,
) -> RunResult:
    """Execute an agent with the given input.

    The runtime loop:
    1. Build prompt (system + input + context + tools)
    2. Call model -> parse into Action
    3. Execute: CALL_TOOL | SPAWN_SUBAGENT | DONE
    4. Update context
    5. Repeat until DONE or max_iterations

    Args:
        agent: The agent configuration to run.
        input_data: Input data matching the agent's input schema.
        verbose: If True, log detailed execution info to stderr.
        debug: If True, pause between iterations for interactive inspection.
    """
    if verbose:
        _configure_verbose_logging()

    context = WorkingMemory()
    tools = await agent.mcp_client.get_tools(agent.tools) if agent.mcp_client else []
    tool_calls: list[ToolCallRecord] = []
    subagent_calls: list[SubagentCallRecord] = []

    # Circuit breaker: track consecutive failures per tool/subagent
    tool_failures: dict[str, int] = {}
    disabled_tools: set[str] = set()

    # Build response schema with all schemas embedded
    tool_schemas = [t.parameters for t in tools] if tools else None
    subagent_schemas = (
        [s._input_schema.model_json_schema() for s in agent.subagents]
        if agent.subagents
        else None
    )
    response_schema = build_action_schema(
        agent._output_schema.model_json_schema(),
        tool_schemas=tool_schemas,
        subagent_schemas=subagent_schemas,
    )

    for iteration in range(agent.max_iterations):
        logger.debug("[%s] Iteration %d", agent.name, iteration + 1)

        # 1. Build prompt
        messages = _build_messages(agent, input_data, context, tools)
        logger.debug("[%s] Calling model with %d messages", agent.name, len(messages))

        # 2. Call model and parse response
        try:
            response_text = await agent.model.call(messages, response_schema)
            logger.debug(
                "[%s] Model response: %s", agent.name, _truncate(response_text)
            )
            actions = _parse_actions(response_text)
            logger.debug("[%s] Got %d action(s)", agent.name, len(actions))

            # Debug breakpoint: inspect response and parsed actions
            if debug:
                should_continue = await debug_breakpoint(
                    iteration,
                    agent_name=agent.name,
                    messages=messages,
                    response=response_text,
                    actions=actions,
                )
                if not should_continue:
                    return RunResult(
                        output=None,
                        iterations=iteration + 1,
                        termination_reason="error",
                        tool_calls=tool_calls,
                        subagent_calls=subagent_calls,
                        error="Aborted by user in debug mode",
                    )
        except Exception as e:
            logger.warning("[%s] Parse error: %s", agent.name, e)
            # Give the model feedback about the parse error and let it retry
            context.add_tool_result(
                "error",
                f"Failed to parse actions: {e}. "
                'Use format: {"actions": [{"action": "...", ...}]}',
                iteration,
            )
            continue

        # 3. Execute actions (sequentially for now, parallel in future)
        for action in actions:
            logger.debug("[%s] Executing action: %s", agent.name, action.action)

            if action.action == "CALL_TOOL":
                if not action.tool_name:
                    context.add_tool_result(
                        "error", "CALL_TOOL requires tool_name", iteration
                    )
                    continue
                if not agent.mcp_client:
                    context.add_tool_result(
                        "error", "No MCP client configured", iteration
                    )
                    continue
                # Circuit breaker: skip disabled tools
                if action.tool_name in disabled_tools:
                    context.add_tool_result(
                        "error",
                        f"Tool '{action.tool_name}' is disabled due to repeated "
                        f"failures. Use a different approach.",
                        iteration,
                    )
                    continue
                logger.debug(
                    "[%s] Calling tool: %s with args: %s",
                    agent.name,
                    action.tool_name,
                    action.arguments,
                )
                try:
                    # Apply timeout if configured
                    call_coro = agent.mcp_client.call_tool(
                        action.tool_name, action.arguments
                    )
                    if agent.tool_timeout:
                        result: Any = await asyncio.wait_for(
                            call_coro, timeout=agent.tool_timeout
                        )
                    else:
                        result = await call_coro
                    logger.debug(
                        "[%s] Tool result: %s", agent.name, _truncate(str(result))
                    )
                    context.add_tool_result(action.tool_name, result, iteration)
                    tool_calls.append(
                        ToolCallRecord(
                            tool_name=action.tool_name,
                            arguments=action.arguments,
                            result=result,
                            iteration=iteration,
                        )
                    )
                    # Reset failure count on success
                    tool_failures[action.tool_name] = 0
                except asyncio.TimeoutError:
                    # Handle timeout same as other failures
                    tool_failures[action.tool_name] = (
                        tool_failures.get(action.tool_name, 0) + 1
                    )
                    failure_count = tool_failures[action.tool_name]
                    logger.warning(
                        "[%s] Tool '%s' timed out after %.1fs (%d/%d)",
                        agent.name,
                        action.tool_name,
                        agent.tool_timeout,
                        failure_count,
                        MAX_TOOL_FAILURES,
                    )
                    if failure_count >= MAX_TOOL_FAILURES:
                        disabled_tools.add(action.tool_name)
                        context.add_tool_result(
                            "error",
                            f"Tool '{action.tool_name}' has been disabled after "
                            f"{MAX_TOOL_FAILURES} consecutive failures. "
                            f"Last error: timed out. Use a different approach.",
                            iteration,
                        )
                    else:
                        context.add_tool_result(
                            "error",
                            f"Tool '{action.tool_name}' timed out after "
                            f"{agent.tool_timeout}s. You may retry.",
                            iteration,
                        )
                    tool_calls.append(
                        ToolCallRecord(
                            tool_name=action.tool_name,
                            arguments=action.arguments,
                            result="ERROR: timed out",
                            iteration=iteration,
                        )
                    )
                except Exception as e:
                    # Track failure
                    tool_failures[action.tool_name] = (
                        tool_failures.get(action.tool_name, 0) + 1
                    )
                    failure_count = tool_failures[action.tool_name]
                    logger.warning(
                        "[%s] Tool '%s' failed (%d/%d): %s",
                        agent.name,
                        action.tool_name,
                        failure_count,
                        MAX_TOOL_FAILURES,
                        e,
                    )
                    # Disable tool if it fails too many times
                    if failure_count >= MAX_TOOL_FAILURES:
                        disabled_tools.add(action.tool_name)
                        context.add_tool_result(
                            "error",
                            f"Tool '{action.tool_name}' has been disabled after "
                            f"{MAX_TOOL_FAILURES} consecutive failures. "
                            f"Last error: {e}. Use a different approach.",
                            iteration,
                        )
                    else:
                        context.add_tool_result(
                            "error",
                            f"Tool '{action.tool_name}' failed: {e}. "
                            f"You may retry or try a different approach.",
                            iteration,
                        )
                    # Record the failed call
                    tool_calls.append(
                        ToolCallRecord(
                            tool_name=action.tool_name,
                            arguments=action.arguments,
                            result=f"ERROR: {e}",
                            iteration=iteration,
                        )
                    )

            elif action.action == "SPAWN_SUBAGENT":
                if not action.subagent_name:
                    context.add_tool_result(
                        "error", "SPAWN_SUBAGENT requires subagent_name", iteration
                    )
                    continue
                subagent = _find_subagent(agent, action.subagent_name)
                if subagent is None:
                    context.add_tool_result(
                        f"error:{action.subagent_name}",
                        f"Subagent '{action.subagent_name}' not found",
                        iteration,
                    )
                    continue
                # Circuit breaker: skip disabled subagents
                subagent_key = f"subagent:{action.subagent_name}"
                if subagent_key in disabled_tools:
                    context.add_tool_result(
                        "error",
                        f"Subagent '{action.subagent_name}' is disabled due to "
                        f"repeated failures. Use a different approach.",
                        iteration,
                    )
                    continue

                logger.debug(
                    "[%s] Spawning subagent: %s", agent.name, action.subagent_name
                )
                try:
                    # Parse input for subagent
                    parsed_input = subagent._input_schema.model_validate(
                        action.subagent_input
                    )
                    sub_result: RunResult = await run_agent(
                        subagent, parsed_input, verbose=verbose, debug=debug
                    )
                    # Check if subagent failed
                    if sub_result.error:
                        raise RuntimeError(sub_result.error)
                    if sub_result.output is None:
                        raise RuntimeError(
                            f"Subagent terminated without output: "
                            f"{sub_result.termination_reason}"
                        )
                    output_dict = (
                        sub_result.output.model_dump() if sub_result.output else None
                    )
                    logger.debug(
                        "[%s] Subagent %s complete", agent.name, action.subagent_name
                    )
                    context.add_subagent_output(
                        action.subagent_name, output_dict, iteration
                    )
                    subagent_calls.append(
                        SubagentCallRecord(
                            subagent_name=action.subagent_name,
                            input=action.subagent_input,
                            output=output_dict,
                            iteration=iteration,
                        )
                    )
                    # Reset failure count on success
                    tool_failures[subagent_key] = 0
                except Exception as e:
                    # Track failure
                    tool_failures[subagent_key] = tool_failures.get(subagent_key, 0) + 1
                    failure_count = tool_failures[subagent_key]
                    logger.warning(
                        "[%s] Subagent '%s' failed (%d/%d): %s",
                        agent.name,
                        action.subagent_name,
                        failure_count,
                        MAX_TOOL_FAILURES,
                        e,
                    )
                    # Disable subagent if it fails too many times
                    if failure_count >= MAX_TOOL_FAILURES:
                        disabled_tools.add(subagent_key)
                        context.add_tool_result(
                            "error",
                            f"Subagent '{action.subagent_name}' has been disabled "
                            f"after {MAX_TOOL_FAILURES} consecutive failures. "
                            f"Last error: {e}. Use a different approach.",
                            iteration,
                        )
                    else:
                        context.add_tool_result(
                            "error",
                            f"Subagent '{action.subagent_name}' failed: {e}. "
                            f"You may retry or try a different approach.",
                            iteration,
                        )
                    # Record the failed call
                    subagent_calls.append(
                        SubagentCallRecord(
                            subagent_name=action.subagent_name,
                            input=action.subagent_input,
                            output=f"ERROR: {e}",
                            iteration=iteration,
                        )
                    )

            elif action.action == "COMPACT":
                logger.debug("[%s] Compacting context", agent.name)
                try:
                    # Call agent's compact method to summarize
                    summary = await agent.compact(messages)
                    # Clear working memory and add summary
                    context.clear()
                    context.add_tool_result(
                        "context_summary",
                        f"Previous conversation was compacted. Summary:\n{summary}",
                        iteration,
                    )
                    logger.debug("[%s] Context compacted", agent.name)
                except Exception as e:
                    logger.warning("[%s] Compact failed: %s", agent.name, e)
                    context.add_tool_result(
                        "error",
                        f"Failed to compact context: {e}",
                        iteration,
                    )

            elif action.action == "DONE":
                # Validate output against schema
                try:
                    validated_output = agent._output_schema.model_validate(
                        action.output
                    )
                    logger.info(
                        "[%s] Completed in %d iterations", agent.name, iteration + 1
                    )
                    return RunResult(
                        output=validated_output,
                        iterations=iteration + 1,
                        termination_reason="done",
                        tool_calls=tool_calls,
                        subagent_calls=subagent_calls,
                    )
                except Exception as e:
                    return RunResult(
                        output=None,
                        iterations=iteration + 1,
                        termination_reason="error",
                        tool_calls=tool_calls,
                        subagent_calls=subagent_calls,
                        error=f"Output validation failed: {e}",
                    )

    logger.warning("[%s] Max iterations (%d) reached", agent.name, agent.max_iterations)
    return RunResult(
        output=None,
        iterations=agent.max_iterations,
        termination_reason="max_iterations",
        tool_calls=tool_calls,
        subagent_calls=subagent_calls,
    )


def _build_messages(
    agent: Agent,
    input_data: BaseModel,
    context: WorkingMemory,
    tools: list[Tool],
) -> list[dict[str, Any]]:
    """Build messages for model prompt."""
    # Build the full system prompt with tools, subagents, and output schema
    output_schema = agent._output_schema.model_json_schema()
    full_system_prompt = build_system_prompt(
        agent_prompt=agent.system_prompt,
        output_schema=output_schema,
        tools=tools if tools else None,
        subagents=agent.subagents if agent.subagents else None,
    )

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": full_system_prompt},
        {
            "role": "user",
            "content": f"Input:\n{input_data.model_dump_json(indent=2)}",
        },
    ]

    # Add context from previous iterations
    messages.extend(context.to_messages())

    return messages


def _find_subagent(agent: Agent, name: str) -> Agent | None:
    """Find a subagent by name."""
    for subagent in agent.subagents:
        if subagent.name == name:
            return subagent
    return None
