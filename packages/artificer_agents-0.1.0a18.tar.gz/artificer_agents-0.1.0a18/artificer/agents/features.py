"""AgentsFeature for Artificer CLI integration."""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import click
import questionary
from artificer.cli.feature import ArtificerFeature  # type: ignore[import-untyped]
from questionary import Style

from .agent import Agent

if TYPE_CHECKING:
    from artificer.cli.config import ArtificerConfig  # type: ignore[import-untyped]

_style = Style(
    [
        ("qmark", "fg:cyan bold"),
        ("question", "bold"),
        ("answer", "fg:cyan"),
        ("pointer", "fg:cyan bold"),
        ("highlighted", "fg:cyan bold"),
        ("selected", "fg:green"),
    ]
)


def _format_tools(tools: list[str] | None) -> str:
    """Format tools list for display."""
    if tools is None:
        return "(all)"
    if not tools:
        return "(none)"
    return ", ".join(tools)


class AgentsFeature(ArtificerFeature):  # type: ignore[misc]
    """Feature providing CLI commands for agent management."""

    @classmethod
    def register(cls, cli: click.Group, config: "ArtificerConfig") -> None:
        """Register agent commands with the CLI."""
        cls._import_agent_modules(config)

        @cli.group()
        def agents() -> None:
            """Manage and run agents."""
            pass

        @agents.command(name="list")
        def list_cmd() -> None:
            """List all available agents."""
            if not Agent._agent_registry:
                click.echo("No agents registered.")
                return

            # Check if we're in an interactive terminal
            if not sys.stdin.isatty():
                # Non-interactive: just list agents
                click.echo("Available agents:")
                for name, agent in Agent._agent_registry.items():
                    tools_str = _format_tools(agent.tools)
                    click.echo(f"  {name} [tools: {tools_str}]")
                return

            # Build choices for selection
            choices = []
            for name, agent in Agent._agent_registry.items():
                tools_str = _format_tools(agent.tools)
                display = f"{name} [tools: {tools_str}]"
                choices.append(questionary.Choice(title=display, value=name))

            selected = questionary.select(
                "Select an agent:",
                choices=choices,
                style=_style,
                use_shortcuts=False,
                use_indicator=True,
            ).ask()

            if selected is None:
                return

            # Show options for the selected agent
            action = questionary.select(
                f"What would you like to do with '{selected}'?",
                choices=[
                    questionary.Choice(title="Describe", value="describe"),
                    questionary.Choice(title="Run", value="run"),
                    questionary.Choice(title="Cancel", value="cancel"),
                ],
                style=_style,
                use_shortcuts=False,
                use_indicator=True,
            ).ask()

            if action == "describe":
                cls._describe_agent(selected)
            elif action == "run":
                cls._run_agent_interactive(selected)

        @agents.command(name="describe")
        @click.argument("agent_name", required=False)
        def describe_cmd(agent_name: str | None) -> None:
            """Show detailed information about an agent."""
            if agent_name is None:
                agent_name = cls._select_agent("Select an agent to describe:")
                if agent_name is None:
                    return

            cls._describe_agent(agent_name)

        @agents.command(name="run")
        @click.argument("agent_name", required=False)
        @click.argument("input_json", required=False)
        @click.option(
            "-d", "--debug", is_flag=True, help="Enable interactive debug mode"
        )
        @click.option("-v", "--verbose", is_flag=True, help="Enable verbose output")
        def run_cmd(
            agent_name: str | None,
            input_json: str | None,
            debug: bool,
            verbose: bool,
        ) -> None:
            """Run an agent with the given input.

            INPUT_JSON should be a JSON object matching the agent's input schema.
            If not provided, will prompt for input interactively.
            """
            if agent_name is None:
                agent_name = cls._select_agent("Select an agent to run:")
                if agent_name is None:
                    return

            cls._run_agent_interactive(
                agent_name, input_json, debug=debug, verbose=verbose
            )

    @classmethod
    def _select_agent(cls, message: str) -> str | None:
        """Show interactive agent selection."""
        if not Agent._agent_registry:
            click.echo("No agents registered.")
            return None

        # Non-interactive: can't select
        if not sys.stdin.isatty():
            click.echo("No agent specified and not in interactive mode.", err=True)
            return None

        choices = []
        for name, agent in Agent._agent_registry.items():
            tools_str = _format_tools(agent.tools)
            display = f"{name} [tools: {tools_str}]"
            choices.append(questionary.Choice(title=display, value=name))

        result = questionary.select(
            message,
            choices=choices,
            style=_style,
            use_shortcuts=False,
            use_indicator=True,
        ).ask()
        return cast(str | None, result)

    @classmethod
    def _describe_agent(cls, agent_name: str) -> None:
        """Show detailed information about an agent."""
        agent = Agent._agent_registry.get(agent_name)
        if agent is None:
            available = list(Agent._agent_registry.keys())
            click.echo(f"Unknown agent: {agent_name}", err=True)
            if available:
                click.echo(f"Available: {', '.join(available)}", err=True)
            raise SystemExit(1)

        click.echo(f"Agent: {agent.name}")
        click.echo(f"Model: {agent.model}")
        click.echo(f"MCP Client: {agent.mcp_client}")
        click.echo(f"Max Iterations: {agent.max_iterations}")
        click.echo(f"Tools: {_format_tools(agent.tools)}")
        click.echo()
        click.echo("System Prompt:")
        click.echo(agent.system_prompt)
        click.echo()
        click.echo("Input Schema:")
        click.echo(json.dumps(agent._input_schema.model_json_schema(), indent=2))
        click.echo()
        click.echo("Output Schema:")
        click.echo(json.dumps(agent._output_schema.model_json_schema(), indent=2))

        if agent.subagents:
            click.echo()
            click.echo("Subagents:")
            for sub in agent.subagents:
                click.echo(f"  - {sub.name}")

    @classmethod
    def _run_agent_interactive(
        cls,
        agent_name: str,
        input_json: str | None = None,
        *,
        debug: bool = False,
        verbose: bool = False,
    ) -> None:
        """Run an agent, prompting for input if needed."""
        agent_or_cls = Agent._agent_registry.get(agent_name)
        if agent_or_cls is None:
            available = list(Agent._agent_registry.keys())
            click.echo(f"Unknown agent: {agent_name}", err=True)
            if available:
                click.echo(f"Available: {', '.join(available)}", err=True)
            raise SystemExit(1)

        # Get or create agent instance
        if isinstance(agent_or_cls, type):
            agent = agent_or_cls()
        else:
            agent = agent_or_cls

        # Get input JSON
        if input_json is None:
            if not sys.stdin.isatty():
                click.echo("No input provided and not in interactive mode.", err=True)
                raise SystemExit(1)

            schema = agent._input_schema.model_json_schema()
            click.echo("Input Schema:")
            click.echo(json.dumps(schema, indent=2))
            click.echo()
            input_json = questionary.text(
                "Enter input JSON:",
                style=_style,
            ).ask()
            if input_json is None:
                return

        # Parse input
        try:
            input_data = json.loads(input_json)
        except json.JSONDecodeError as e:
            click.echo(f"Invalid JSON input: {e}", err=True)
            raise SystemExit(1)

        # Validate input against schema
        try:
            validated_input = agent._input_schema.model_validate(input_data)
        except Exception as e:
            click.echo(f"Input validation failed: {e}", err=True)
            raise SystemExit(1)

        # Run the agent
        result = asyncio.run(
            cls._run_agent_async(agent, validated_input, debug=debug, verbose=verbose)
        )

        # Output result
        if isinstance(result, dict) and "error" in result:
            click.echo(f"Error: {result['error']}", err=True)
            raise SystemExit(1)

        click.echo(json.dumps(result, indent=2))

    @classmethod
    async def _run_agent_async(
        cls,
        agent: Agent,
        input_data: Any,
        *,
        debug: bool = False,
        verbose: bool = False,
    ) -> dict[str, Any] | None:
        """Run an agent and return the result."""
        from .runtime import RunResult, run_agent

        try:
            result: RunResult = await run_agent(
                agent, input_data, debug=debug, verbose=verbose
            )
            # Cleanup MCP client if present
            if agent.mcp_client:
                await agent.mcp_client.close()
            return result.output.model_dump() if result.output else None
        except Exception as e:
            return {"error": str(e)}

    @classmethod
    def _import_agent_modules(cls, config: "ArtificerConfig") -> None:
        """Import agent modules to register agents."""
        if sys.version_info >= (3, 11):
            import tomllib
        else:
            import tomli as tomllib

        pyproject_path = Path.cwd() / "pyproject.toml"
        if not pyproject_path.exists():
            return

        with open(pyproject_path, "rb") as f:
            pyproject: dict[str, Any] = tomllib.load(f)

        agents_config: dict[str, Any] = (
            pyproject.get("tool", {}).get("artificer", {}).get("agents", {})
        )

        # Add cwd to path so local agent modules can be imported
        cwd = str(Path.cwd())
        if cwd not in sys.path:
            sys.path.insert(0, cwd)

        agent_modules: list[str] = agents_config.get("agents", [])
        for module_path in agent_modules:
            try:
                importlib.import_module(module_path)
            except ImportError as e:
                click.echo(
                    f"Warning: Could not import agent module '{module_path}': {e}",
                    err=True,
                )
