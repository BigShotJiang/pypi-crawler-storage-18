"""Interactive debugger for agent runtime."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import questionary

from artificer.agents.actions import Action


def _format_messages(messages: list[dict[str, Any]]) -> str:
    """Format messages for display."""
    output = []
    for i, msg in enumerate(messages):
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        output.append(f"[{i}] {role.upper()}")
        output.append("-" * 40)
        output.append(content)
        output.append("")
    return "\n".join(output)


def _format_actions(actions: list[Action]) -> str:
    """Format actions for display."""
    output = []
    for i, action in enumerate(actions):
        output.append(f"[{i}] {action.action}")
        output.append(action.model_dump_json(indent=2))
        output.append("")
    return "\n".join(output)


async def _save_to_file(
    messages: list[dict[str, Any]] | None,
    response: str | None,
    actions: list[Action] | None,
    iteration: int,
) -> None:
    """Sub-menu for saving debug data to files."""
    choices = []
    if messages:
        choices.append("Save prompt/messages")
    if response:
        choices.append("Save model response")
    if actions:
        choices.append("Save parsed actions")
    if messages and response and actions:
        choices.append("Save all")
    choices.append("Back")

    choice = await questionary.select(
        "What would you like to save?",
        choices=choices,
    ).ask_async()

    if choice == "Back":
        return

    # Get filename
    default_name = f"debug_iter{iteration + 1}"
    filename = await questionary.text(
        "Filename (without extension):",
        default=default_name,
    ).ask_async()

    if not filename:
        return

    # Choose format (only for messages and actions, response is always plain text)
    save_messages = choice in ("Save prompt/messages", "Save all") and messages
    save_actions = choice in ("Save parsed actions", "Save all") and actions

    use_json = True
    if save_messages or save_actions:
        fmt = await questionary.select(
            "Format:",
            choices=["JSON", "Console-style (readable)"],
        ).ask_async()
        if fmt is None:
            return
        use_json = fmt == "JSON"

    base_path = Path(filename)

    if save_messages and messages:
        if use_json:
            path = base_path.with_suffix(".prompt.json")
            path.write_text(json.dumps(messages, indent=2))
        else:
            path = base_path.with_suffix(".prompt.txt")
            path.write_text(_format_messages(messages))
        print(f"Saved messages to {path}")

    if choice in ("Save model response", "Save all") and response:
        path = base_path.with_suffix(".response.txt")
        path.write_text(response)
        print(f"Saved response to {path}")

    if save_actions and actions:
        if use_json:
            path = base_path.with_suffix(".actions.json")
            actions_data = [a.model_dump() for a in actions]
            path.write_text(json.dumps(actions_data, indent=2))
        else:
            path = base_path.with_suffix(".actions.txt")
            path.write_text(_format_actions(actions))
        print(f"Saved actions to {path}")


async def debug_breakpoint(
    iteration: int,
    *,
    agent_name: str = "",
    messages: list[dict[str, Any]] | None = None,
    response: str | None = None,
    actions: list[Action] | None = None,
) -> bool:
    """Interactive debug breakpoint.

    Shows a menu allowing the user to inspect the current state
    of the agent execution.

    Args:
        iteration: Current iteration number (0-indexed).
        agent_name: Name of the agent being debugged.
        messages: The messages/prompt sent to the model.
        response: The raw response from the model.
        actions: The parsed actions from the response.

    Returns:
        True to continue execution, False to abort.
    """
    if agent_name:
        title = f"{agent_name} | iteration {iteration + 1}"
    else:
        title = f"iteration {iteration + 1}"

    width = max(len(title) + 4, 40)
    print(f"\n┌{'─' * width}┐")
    print(f"│ {title:<{width - 2}} │")
    print(f"└{'─' * width}┘")

    while True:
        choices = []
        if messages:
            choices.append("View prompt/messages")
        if response:
            choices.append("View model response")
        if actions:
            choices.append("View parsed actions")

        has_data = messages or response or actions
        if has_data:
            choices.append("Save to file...")

        choices.extend(["Continue", "Abort"])

        choice = await questionary.select(
            "What would you like to do?",
            choices=choices,
        ).ask_async()

        if choice is None:
            # User pressed Ctrl+C
            return False

        if choice == "View prompt/messages" and messages:
            print("\n" + _format_messages(messages))

        elif choice == "View model response" and response:
            print(f"\n{response}\n")

        elif choice == "View parsed actions" and actions:
            print("\n" + _format_actions(actions))

        elif choice == "Save to file...":
            await _save_to_file(messages, response, actions, iteration)

        elif choice == "Continue":
            return True

        elif choice == "Abort":
            return False
