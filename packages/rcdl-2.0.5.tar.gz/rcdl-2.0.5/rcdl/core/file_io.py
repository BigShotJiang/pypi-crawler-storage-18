# core/file_io.py

import json


def write_json(path, data, mode="w"):
    with open(path, mode) as f:
        json.dump(data, f, indent=4)


def load_json(path) -> dict:
    with open(path, "r") as f:
        data = json.load(f)
    return data
