# core/config.py

from pathlib import Path
import json
import logging
import os

from .file_io import write_json


class Config:
    # paths
    APP_NAME = "cdl"

    BASE_DIR = Path(os.environ.get("RCDL_BASE_DIR", Path.home() / "Videos/rcdl"))

    CACHE_DIR = BASE_DIR / ".cache"
    DB_PATH = CACHE_DIR / "cdl.db"
    LOG_FILE = CACHE_DIR / "cdl.log"
    FUSE_CSV_FILE = CACHE_DIR / "cdl_fuse.csv"
    SETTINGS_FILE = CACHE_DIR / "settings.json"
    CREATORS_FILE = CACHE_DIR / "creators.json"
    DISCOVER_DIR = CACHE_DIR / "discover"

    # defaults
    DEFAULT_SETTINGS = {
        "work_folder": str(BASE_DIR),
        "yt_dlp_args": "--external-downloader aria2c",
        "preset": "veryfast",
    }

    # default creators
    DEFAULT_CREATORS = [
        {"creator_id": "boixd", "service": "onlyfans", "domain": "coomer"}
    ]

    DEBUG = False
    DRY_RUN = False

    # api settings
    POST_PER_PAGE = 50
    DEFAULT_MAX_PAGE = 10
    MAX_FAIL_COUNT = 7

    @classmethod
    def ensure_dirs(cls):
        cls.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cls.DISCOVER_DIR.mkdir(exist_ok=True)

    @classmethod
    def ensure_files(cls):
        files = [
            cls.DB_PATH,
            cls.FUSE_CSV_FILE,
            cls.CREATORS_FILE,
        ]
        for file in files:
            if not file.exists():
                file.touch()
                logging.info("Created file %s", file)
                if file == cls.CREATORS_FILE:
                    write_json(file, cls.DEFAULT_CREATORS)

    @classmethod
    def load_settings(cls):
        if not cls.SETTINGS_FILE.exists():
            with open(cls.SETTINGS_FILE, "w") as f:
                json.dump(cls.DEFAULT_SETTINGS, f, indent=4)
            return cls.DEFAULT_SETTINGS

        with open(cls.SETTINGS_FILE, "r") as f:
            return json.load(f)

    @classmethod
    def creator_folder(cls, creator_id: str) -> Path:
        folder = cls.BASE_DIR / creator_id
        folder.mkdir(exist_ok=True)
        return folder

    @classmethod
    def cache_file(cls, filename: str, ext: str = ".json") -> Path:
        file_name = filename + ext
        file = cls.CACHE_DIR / file_name
        return file

    @classmethod
    def set_debug(cls, debug: bool):
        cls.DEBUG = debug

    @classmethod
    def set_dry_run(cls, dry_run: bool):
        cls.DRY_RUN = dry_run


def setup_logging(log_file: Path, level: int = 0):
    logger = logging.getLogger()
    logger.setLevel(level)
    logger.handlers.clear()  # avoid double handlers if called multiple times

    # file handler
    file_handler = logging.FileHandler(log_file, encoding="utf-8", mode="a")
    file_handler.setFormatter(
        logging.Formatter(
            "{asctime} - {levelname} - {message}",
            style="{",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger.addHandler(file_handler)

    # console handler (stdout)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter("{levelname}: {message}", style="{"))
    logger.addHandler(console_handler)
