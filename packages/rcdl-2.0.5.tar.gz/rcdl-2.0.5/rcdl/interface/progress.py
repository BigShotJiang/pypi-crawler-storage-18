# interface/progress.py

import click

from rcdl.utils import Progress


class ProgressPrinter:
    def __init__(self, total: int, progress=Progress):
        self.progress = progress(total)

    def update(self, ignore=False):
        self.progress.update(ignore=ignore)

    def _format_time(self, seconds: float) -> str:
        total_seconds = int(seconds)
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        secs = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    def display(self):
        msg = f"Progress: {self.progress.current}/{self.progress.total} ({round(self.progress.pourcent, 1)}%)"
        msg += f" ETA: {self._format_time(self.progress.eta)}"
        click.echo(msg)
