from .connection import connect, Connection
from .cursor import Cursor
from .utils.exceptions import (
    DatabaseError,
    IntegrityError,
    OperationalError,
    ProgrammingError,
    NotSupportedError
)

__version__ = "1.0.7"
__author__ = "RibbitX Team"
__all__ = [
    "connect",
    "Connection",
    "Cursor",
    "DatabaseError",
    "IntegrityError",
    "OperationalError",
    "ProgrammingError",
    "NotSupportedError",
]

PARSE_DECLTYPES = 1
PARSE_COLNAMES = 2

# Server components (optional)
try:
    from .server import RibbitXDBServer, start_server
    __all__.extend(['RibbitXDBServer', 'start_server'])
except ImportError:
    pass  # Server dependencies not installed

# Network client
try:
    from .client import NetworkConnection, NetworkCursor
    __all__.extend(['NetworkConnection', 'NetworkCursor'])
except ImportError:
    pass

def connect_network(host: str, port: int = 5432, user: str = None, 
                   password: str = None, **kwargs):
    """Connect to remote RibbitXDB server
    
    Args:
        host: Server hostname or IP
        port: Server port (default: 5432)
        user: Username for authentication
        password: Password for authentication
        **kwargs: Additional arguments (tls_cert, tls_key, tls_ca, tls_verify)
    
    Returns:
        NetworkConnection instance
    """
    from .client import NetworkConnection
    conn = NetworkConnection(host, port, user, password, **kwargs)
    conn.connect()
    return conn

