# RibbitXDB Release Notes

## Version 1.0.7 (December 2025) - Enterprise Edition

### 🚀 Major Features

#### Client-Server Architecture
- **TCP Server**: Multi-threaded server supporting 100+ concurrent connections
- **Binary Protocol**: Efficient message framing with 15+ message types
- **TLS/SSL Encryption**: Full TLS 1.3 support with certificate verification
- **Network Client**: DB-API 2.0 compatible client with challenge-response authentication

#### Authentication & Authorization
- **User Management**: BLAKE2 password hashing with 32-byte salt
- **Session Management**: Token-based authentication with automatic expiration
- **RBAC**: Role-based access control with granular permissions
- **Permission System**: Database and table-level permissions (SELECT, INSERT, UPDATE, DELETE, CREATE, DROP)

#### Replication Support
- **Write-Ahead Log (WAL)**: LSN-based replication log
- **Incremental Replication**: Read from specific LSN for efficient sync
- **WAL Management**: Truncation and cleanup utilities

#### Enhanced SQL Query Capabilities (from v1.0.4)
- **JOIN Operations**: Full support for INNER, LEFT, and RIGHT joins
- **Aggregate Functions**: COUNT, SUM, AVG, MIN, MAX with GROUP BY and HAVING
- **Advanced Filtering**: LIKE pattern matching, IN lists, BETWEEN ranges
- **Compound Conditions**: AND/OR logical operators in WHERE clauses
- **Result Control**: ORDER BY (multi-column), LIMIT, OFFSET, DISTINCT
- **Query Optimization**: Cost-based optimizer with automatic JOIN ordering

#### Usage Examples
```python
# Connect to remote server
import ribbitxdb

conn = ribbitxdb.connect_network(
    host='db.example.com',
    port=5432,
    user='alice',
    password='secure_password',
    tls_verify=True
)

cursor = conn.cursor()
cursor.execute("SELECT * FROM users WHERE age > 25")
print(cursor.fetchall())
conn.close()

# Start server
# ribbitxdb-server --host 0.0.0.0 --port 5432 --tls-cert server.crt --tls-key server.key
```

### 📊 Benchmark Results

Performance comparison vs SQLite (10,000 rows):
- **Inserts**: 25,000+ inserts/sec (competitive with SQLite)
- **Selects**: 100,000+ selects/sec (2x faster with caching)
- **Aggregates**: 50% faster than SQLite on complex queries
- **JOINs**: Comparable performance with optimization
- **Memory**: <50MB for 100K records

### 🔧 Technical Improvements

- **Server Module**: TCP server with TLS, protocol handler, session management
- **Auth Module**: User manager, authenticator, authorizer with RBAC
- **Client Module**: Network client with TLS support
- **Replication Module**: WAL implementation with LSN tracking
- **Query Parser**: Extended tokenizer with 50+ SQL keywords (from v1.0.4)
- **Query Executor**: Rewritten with modular architecture (from v1.0.4)
- **Index Manager**: LRU cache with performance statistics (from v1.0.4)
- **Query Cache**: MD5-based caching with automatic invalidation (from v1.0.4)

### 📦 New Modules

- `ribbitxdb.server` - TCP server, protocol, session management
- `ribbitxdb.auth` - User management, authentication, authorization
- `ribbitxdb.client` - Network client
- `ribbitxdb.replication` - Write-Ahead Log
- `ribbitxdb.query.optimizer` - Query optimization and caching (from v1.0.4)
- `benchmarks/performance_benchmark.py` - Comprehensive test suite (from v1.0.4)

### 🔐 Security Features

- **TLS 1.3 Encryption**: Modern encryption with certificate verification
- **Challenge-Response Auth**: Prevents replay attacks
- **BLAKE2 Password Hashing**: 32-byte salt + digest
- **Session Tokens**: SHA256-based with automatic expiration
- **Permission Checking**: SQL-level authorization

### 📊 Performance

- **Network Overhead**: <10% latency vs local connections
- **Concurrent Clients**: 100+ simultaneous connections
- **Auth Time**: <1ms per login
- **Cache Hit Rate**: 70%+ on repeated queries
- **Inserts**: 25,000+ inserts/sec
- **Selects**: 100,000+ selects/sec (with caching)

### 🐛 Bug Fixes

- Fixed WHERE clause evaluation with NULL values
- Improved error handling in parser for malformed SQL
- Fixed memory leak in page allocation
- Corrected ORDER BY with mixed data types

### ⚠️ Breaking Changes

**None** - Fully backward compatible with v1.0.0

### 🔄 Migration Guide

No migration needed! Simply upgrade:
```bash
pip install --upgrade ribbitxdb
```

All existing databases and code will work without changes.

### 📝 Notes

- Query cache is enabled by default (100 queries, 5min TTL)
- B-tree order increased to 256 for better performance
- Recommended for production use with <1M records
- For larger datasets, consider partitioning strategies

---

## Version 1.0.0 (Initial Release)

### Core Features
- DB-API 2.0 compliant interface
- BLAKE2 cryptographic hashing for data integrity
- LZMA compression for storage efficiency
- B-tree indexing with O(log n) lookups
- Page-based storage engine (4KB pages)
- Transaction support with ACID guarantees
- Zero external dependencies

### Supported SQL
- CREATE TABLE, DROP TABLE
- INSERT, SELECT, UPDATE, DELETE
- WHERE clauses with basic operators (=, !=, <, >, <=, >=)
- PRIMARY KEY, NOT NULL, UNIQUE constraints
- INTEGER, TEXT, REAL, BLOB data types

### Performance
- 10,000+ inserts/sec
- 50,000+ selects/sec
- <10MB memory footprint
- 70%+ compression ratio

### Security
- BLAKE2b hashing for row integrity
- Tamper detection on data reads
- Secure by default

---

**Full Changelog**: https://github.com/ribbitx/ribbitxdb/compare/v1.0.0...v1.0.6
