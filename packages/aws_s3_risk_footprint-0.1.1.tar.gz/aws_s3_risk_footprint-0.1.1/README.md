# where-are-my-buckets 🌍

A CLI tool to visualize AWS S3 buckets by geographic region.

This tool helps you quickly understand **where your data lives**, using a
map-style overview and expandable regional listings — all from the terminal.

---

## Features

- 🌎 Map-style view of S3 bucket distribution by region
- 📊 Bucket counts per AWS region
- 🔍 Expandable view showing individual bucket names
- 🔐 Uses existing AWS credentials (no secrets stored)
- 🧠 Designed for cloud security, compliance, and infrastructure visibility

---

## Installation

```bash
pip install where-are-my-buckets

