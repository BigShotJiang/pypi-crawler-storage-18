def area(r):
    return 3.14*r*r 
def biitu():
    return "abhilash"