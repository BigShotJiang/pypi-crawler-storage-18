from vesta import Server
from os.path import abspath, dirname
import sys
from psycopg import sql

PATH = dirname(abspath(__file__))


class DBInitializer(Server):
    def initUniauth(self):
        if sys.argv[1].upper() == 'Y':
            self.uniauth.initUniauth()

    def initDB(self):
        self.referenceUniauth()
        self.db.cur.execute(open(self.path + "/db/schema.sql", "r").read())
        self.db.conn.commit()

    def referenceUniauth(self):
        self.db.cur.execute("CREATE EXTENSION if not exists postgres_fdw;")
        self.db.cur.execute(
            sql.SQL("""
            CREATE SERVER if not exists uniauth
            FOREIGN DATA WRAPPER postgres_fdw
            OPTIONS (host %s, port %s, dbname %s);
            """),
            (
                self.config.get('UNIAUTH', 'DB_HOST'),
                self.config.get('UNIAUTH', 'DB_PORT'),
                self.config.get('UNIAUTH', 'DB_NAME')
            ))

        self.db.cur.execute(
            sql.SQL("""
            CREATE USER MAPPING if not exists FOR CURRENT_USER SERVER uniauth
            OPTIONS (user %s, password %s);
            """),
            (
                self.config.get('DB', 'DB_USER'),
                self.config.get('DB', 'DB_PASSWORD')
            ))
        self.db.cur.execute(
            """
            CREATE FOREIGN TABLE if not exists account (id bigserial NOT NULL)
            SERVER uniauth
            OPTIONS (schema_name 'public', table_name 'account');
            """)



initializer = DBInitializer(path=PATH[:-3], configFile="/server.ini", noStart=True)
initializer.initUniauth()
initializer.initDB()
print("DB ready")
