class Defect(Exception):
    pass
