import numpy as np
import pandas as pd
import math
import random
from openpyxl import Workbook
from scipy.stats import normaltest
from scipy.spatial.distance import pdist
np.set_printoptions(threshold=np.inf)       #显示全部结果


'读取数据'
def loadDataset(filename):
    Data_E = pd.read_excel(filename, header=None)
    Data = np.array(Data_E)
    return Data


'写入数据'
def writeDataset(F, file):
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = F.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=F[i][j])
    book.save(file)


'总共需要新插值G个样本'
def number_overspl(ml, ms, beta):       # ml多类,ms少类,beta属于[0,1]
    G = int((ml - ms) * beta)
    return G


'计算一个簇距离边界的权重(未归一化)'
def r_weight(ml_centerMat, ms_centerX):     # 多类中心矩阵以及少类中心向量
    n = ml_centerMat.shape[0]
    wgt = Knn(ml_centerMat, ms_centerX)
    distance = wgt.dis_Euclid()
    dist = np.sum(distance, axis=0)
    ri = dist / n
    e_ri = math.exp(- ri)        # e^-ri
    return e_ri


'计算一个簇规模权重(未归一化)'
def n_weight(mat):
    size = mat.shape[0]
    return size     # 簇规模越大,权重越大


'计算一个簇的密度权重(未归一化)'
def p_weight(Mat):
    m = Mat.shape[0]
    Distance_Mat = pdist(Mat, metric = 'euclidean')      # 未归类的各样本相互欧式距离
    Sum_dis = sum(Distance_Mat)     # 距离总和
    density = Sum_dis / m      # 密度(density越大,权重越大)
    return density


'分割出每个簇'
def cluster(data, data_num, center_num, n):       # 带簇标签的data,data_num总样本数,center_num簇个数,n样本特征数
    clusters = globals()
    x = -1
    oneC = 0
    for i in range(center_num):     # 第i个簇
        Ctr = np.empty([0, n])
        # Ctr = clusters.get('Cluster_' + str(i))
        for j in range(data_num):
            if data[j, n] == i:     # 遍历每一个样本的标签
                Nspl = data[j, :-1]
                Ctr = np.append(Ctr, np.array(np.mat(Nspl)), axis=0)
        # print(Ctr.shape[0])
        if Ctr.shape[0] == 1 or Ctr.shape[0] == 2:       # 如果单样本簇产生,则忽略其在过采样中的作用
            oneC += 1
        else:
            x += 1                             
            clusters['Cluster_' + str(x)] = Ctr
    return clusters, oneC     # 返回的是字典,Cluster_i,最后一列为簇标签


'K近邻'
class Knn():
    def __init__(self, dataset, inx):
        self.dataset =dataset
        self.inx = inx

    def dis_Euclid(self):       # 欧式距离,x1为输入向量,x2为所有样本
        size = self.dataset.shape[0]
        self.inx = np.tile(self.inx, (size, 1))     # 复制与dataset大小的矩阵
        dis = np.linalg.norm(self.inx - self.dataset, axis=1)
        return dis

    def choose_K(self, dismat, K):       # dismat为距离矩阵
        ft = self.dataset.shape[1]
        argdis = dismat.argsort()     # 距离从小到大排列
        K_NN = np.zeros((K, ft))
        K_temp = K
        if argdis.shape[0] < K:
            K_temp = argdis.shape[0]
        for l in range(K_temp):
            id = argdis[l]
            K_NN[l, :] = self.dataset[id, :]
        return K_NN         # 返回K近邻矩阵


'检验数据分布并分别插值'
def check_oversampling(CU, CU_centerG, num, K):     # CU簇,num需要插值的数量,K近邻
    CU_copy = CU.copy()
    statistic, Prob = normaltest(CU_copy, axis=None)      # 检验是否是高斯分布
    m, n = np.shape(CU_copy)        # m个样本有n个特征
    Newspl_Mat = np.empty([0, n])
    gn, an = 0, 0
    if Prob > 0.05:       # 当数据符合高斯分布时
        gn += 1
        if num > m:
            indexG = np.empty([0,1])
            for v in range(num):        # 防止indexG不够
                temp_num1 = random.randrange(0, m)
                indexG = np.append(indexG, np.array(np.mat(temp_num1)), axis=0)
        else:
            indexG = np.array(random.sample(range(0, m), num))      # 选取第index行数据
        i, tG  = 0, 0
        while tG < num:
            numG = indexG[i]
            numG = numG.astype('int64')
            Spl_G = CU_copy[numG, :]      # 选中一个样本
            Other_G = np.delete(CU_copy, numG, 0)      # 剩下将与采样点做K近邻的样本
            Spl_random = np.array(pd.DataFrame(Other_G).sample(n=1, axis=0))        # 在除了采样点中随机选取一个样本
            alfaG = np.random.random()
            Gnew_spl = Spl_G + alfaG * (Spl_G - Spl_random)     # SMOTE
            '判断新样本点是否符合高斯分布'
            d = Knn(CU_copy, CU_centerG)
            dis = d.dis_Euclid()
            sigma_D, sigma_D2 = 0, 0
            for h in range(m):
                sigma_D += dis[h]
                sigma_D2 += dis[h] ** 2
            miu = sigma_D / (m - 1)
            fia_2 = sigma_D2 / (m - 1)
            # fia = math.sqrt(fia_2)
            f = math.exp(- ((np.linalg.norm(Gnew_spl - miu)) ** 2) / 2 * (fia_2 ** 2)) / math.sqrt(2 * np.pi * fia_2)
            # print(f)
            if f > 0.3413:     # 如果概率大于一个标准差
                Newspl_Mat = np.append(Newspl_Mat, np.array(np.mat(Gnew_spl)), axis=0)     # 添加到Newspl矩阵
                tG += 1
            i += 1
            indexG = np.append(indexG, random.randrange(0, m))
    else:       # 当数据平均分布时
        an += 1
        if num > m :
            indexA = np.empty([0,1])
            for j in range(num):
                temp_num2 = random.randrange(0, m)
                indexA = np.append(indexA, np.array(np.mat(temp_num2)), axis=0)
        else:
            indexA = np.array(random.sample(range(0, m), num))
        for tA in range(num):
            numA = indexA[tA]
            numA = numA.astype('int64')
            Spl_A = CU_copy[numA, :]        # 选中一个样本
            Other_A = np.delete(CU_copy, numA, 0)       # 删除选中的那一个样本
            Average_Knn = Knn(Other_A, Spl_A)       # 调用Knn类
            Dis = Average_Knn.dis_Euclid()
            KnnMat = Average_Knn.choose_K(Dis, K)  # 得到K个离选取点最近的样本矩阵
            sigma_K = 0
            for ja in range(K):
                sigma_K += (Spl_A - KnnMat[ja, :])
            alfaA = np.random.random()
            Gnew_spl = Spl_A + alfaA * sigma_K / K
            Newspl_Mat = np.append(Newspl_Mat, np.array(np.mat(Gnew_spl)), axis=0)
    return Newspl_Mat, gn, an


'输入矩阵标签0为少类,1为多类'
if __name__ == '__main__':
    beta = 1.0      # 过采样不平衡率
    a = 65     # 边界距离权重参
    b = 20     # 簇规模权重参
    c = 15     # 密度权重参
    K = 5       # 插值K近邻数
    ml = loadDataset('去噪后的多类.xls')
    ms_centerT = loadDataset('少类中心.xls')       # 从0开始排序好的少类中心向量
    ms_center = ms_centerT[np.lexsort(ms_centerT.T)]
    ml_center = loadDataset('多类中心.xls')
    ms_with_cluster_label = loadDataset('少类样本带簇标记.xls')     # 读取少类最后一列带簇标记的样本矩阵
    ms = np.delete(ms_with_cluster_label, -1, axis=1)       # 去噪后不带标签的少类样本
    ms_m, n = np.shape(ms)      # 少类样本数及数据特征数
    center_numS = ms_center.shape[0]        # 少类簇数
    G = number_overspl(ml.shape[0], ms_m, beta)        # 过采样的数量
    S_clusters, oneC = cluster(ms_with_cluster_label, ms_m, center_numS, n)  # 切割完的少类簇,字典模式
    E_r = np.zeros((center_numS - oneC, 1))
    Size = np.zeros((center_numS - oneC, 1))
    Pweight = np.zeros((center_numS - oneC, 1))
    for i in range(center_numS - oneC):
        e_ri = r_weight(ml_center, ms_center[i, :])
        E_r[i, 0] = e_ri    # 距离权重
        size = n_weight(S_clusters['Cluster_' + str(i)])
        Size[i, 0] = size   # 规模权重
        pw = p_weight(S_clusters['Cluster_' + str(i)])
        Pweight[i, 0] = pw      # 密度权重
        print('第' + str(i + 1) + '个簇 距离:', e_ri, '密度:', pw, '规模:', size)
    '以下矩阵每一行代表一个簇的权重'
    e_r = (E_r - np.min(E_r)) / (np.max(E_r) - np.min(E_r))     # 归一化后的距离权重矩阵
    number = (Size - np.min(Size)) / (np.max(Size) - np.min(Size))      # 归一化后的规模权重矩阵
    p = (Pweight - np.min(Pweight)) / (np.max(Pweight) - np.min(Pweight))   # 归一化后的密度权重矩阵
    weight = a * e_r + b * number + c * p   # 合并以上三个参数并赋予权重
    Sum_weight = sum(weight)
    w = weight / Sum_weight     # 生成权重
    g = np.rint(G * w)      # 每个簇过采样的数目(rint四舍五入)
    for cw in range(w.shape[0]):
        print ('第' + str(cw + 1) + '个簇 权重:', w[cw, 0], ' 插值',int(g[cw, 0]) , '个')
    Newspl_mat = np.empty([0, n])
    GN, AN = 0, 0
    for j in range(center_numS - oneC):    # 判断并插值
        if g[j, 0] > 0:
            Newspl, gn, an = check_oversampling(S_clusters['Cluster_' + str(j)], ms_center[j, :], int(g[j, 0]), K)
            writeDataset(Newspl, '第' + str(j+1) + '个簇的插值.xls')
            GN += gn
            AN += an
            Newspl_mat = np.append(Newspl_mat, np.array(np.mat(Newspl)), axis=0)
    print ('符合高斯分布的簇:', GN, '个', ' 符合均匀分布的簇:', AN, '个')
    Whole_ms = np.vstack((ms, Newspl_mat))      # 合并原始去噪后少类与新过采样数据
    label_0 = np.zeros((Whole_ms.shape[0], 1))
    label_1 = np.ones((ml.shape[0], 1))
    MS = np.hstack((Whole_ms, label_0))     # 给新少类贴上0少类标签
    ML = np.hstack((ml, label_1))       # 给新少类贴上0少类标签
    Whole_data = np.vstack((ML, MS))        # 合并多类和少类
    print ('少类:', MS.shape[0], ' 多类:', ML.shape[0])
    OSData = np.empty([0, Whole_data.shape[1]])
    ran = np.array(random.sample(range(0, Whole_data.shape[0]), Whole_data.shape[0]))
    for j in range(Whole_data.shape[0]):
        OSData = np.append(OSData, np.array(np.mat(Whole_data[ran[j], :])), axis=0)
    writeDataset(OSData, '过采样后新数据集.xls')    # 写入Excel表格


    # '''www'''
    # perNum = int(OSData.shape[0] * 0.3)  # 随机选取30%作为测试集
    # TestData = np.empty([0, OSData.shape[1]])
    # TrainData = np.empty([0, OSData.shape[1]])
    # for i in range(perNum):
    #     Randnum = random.randrange(0, OSData.shape[0])
    #     dataTemp = OSData[Randnum, :]
    #     TestData = np.append(TestData, np.array(np.mat(dataTemp)), axis=0)  # 将抽取出的训练集放入训练集列表
    #     OSData = np.delete(OSData, Randnum, axis=0)  # 将抽取出的数据从训练集样本中删除
    # ran = np.array(random.sample(range(0, OSData.shape[0]), OSData.shape[0]))
    # for j in range(OSData.shape[0]):
    #     TrainData = np.append(TrainData, np.array(np.mat(OSData[ran[j], :])), axis=0)
    # writeDataset(TrainData, '过采样后新数据集.xls')
    # writeDataset(TestData, 'EFS后测试集.xls')