import numpy as np
import pandas as pd
import time
import math
import random
from openpyxl import Workbook
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold

'P:目标矩阵,R,Q:分解矩阵,lambda_i:参数'
def Update_R(lambda_i, R, Q, H, P):
    m, n = np.shape(P)
    for k in range(K):
        RQ = np.dot(R, Q)
        for i in range(m):
            Sigma_high, Sigma_low = 0, 0
            for j in range(n):
                if P[i][j] == -1:
                    continue
                else:
                    RQ_ = RQ[i][j] - R[i][k] * Q[k][j]
                    Sigma_high = Sigma_high + (P[i][j] - RQ_) * Q[k][j]
                    Sigma_low = Sigma_low + (Q[k][j]) ** 2
            high = Sigma_high + lambda_i * H[i][k]
            low = Sigma_low + lambda_i
            R[i][k] = high / low
    return R


def Update_Q(lambda_i, R, Q, G, P):
    m, n = np.shape(P)
    for k in range(K):
        RQ = np.dot(R, Q)
        for j in range(n):
            Sigma_high, Sigma_low = 0, 0
            for i in range(m):
                if P[i][j] == -1:
                    continue
                else:
                    RQ_ = RQ[i][j] - R[i][k] * Q[k][j]
                    Sigma_high = Sigma_high + (P[i][j] - RQ_) * R[i][k]
                    Sigma_low = Sigma_low + (R[i][k]) ** 2
            high = Sigma_high + lambda_i * G[k][j]
            low = Sigma_low + lambda_i
            Q[k][j] = high / low
    return Q


def Update_H(R, P, H):
    m, n = np.shape(P)
    for i in range(m):
        for k in range(K):
            H[i][k] = max(R[i][k], 0)
    return H


def Update_G(Q, P, G):
    m, n = np.shape(P)
    for k in range(K):
        for j in range(n):
            G[k][j] = max(Q[k][j], 0)
    return G


'读取数据'
def loadDataset(filename):
    Data_E = pd.read_excel(filename, header=None)
    Data_E = np.array(Data_E)
    Data = np.delete(Data_E, -1, axis=1)
    labels = np.array(np.mat(Data_E[:, -1])).T
    return Data, labels


'填充预测值'
def pack_in(HG, P):
    Pcopy = P.copy()
    m, n = np.shape(P)
    for i in range(m):
        for j in range(n):
            if Pcopy[i][j] == -1:
                Pcopy[i][j] = HG[i][j]
    return Pcopy


'计算精度'
def error_value(OG_P, HG, P):
    Error = 0
    num = 0
    m, n = np.shape(P)
    for i in range(m):
        for j in range(n):
            if P[i][j] == -1:
                num += 1
                Error += (OG_P[i][j] - HG[i][j]) ** 2
    MSE_error = Error / num
    return MSE_error


'写入excel'
def writeDataset(F, file):
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = F.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i+1, column=j+1, value=F[i][j])
    book.save(file)


'K折交叉验证'
def Kfold(OG_P, P, lambda_i):
    P_copy = np.copy(P)
    m, n = np.shape(P)
    Packed_P = np.zeros((m, n))
    R = np.random.rand(m, K)
    Q = np.random.rand(K, n)
    H = np.random.rand(m, K)
    G = np.random.rand(K, n)
    step = 1
    Step = []
    ERROR = []
    error_new = 0
    '更新迭代'
    while step <= S:
        Step.append(step)
        error_old = error_new
        R = Update_R(lambda_i, R, Q, H, P)
        Q = Update_Q(lambda_i, R, Q, G, P)
        H = Update_H(R, P, H)
        G = Update_G(Q, P, G)
        Packed_P = pack_in(np.dot(H, G), P)  # 填充预测值
        error_new = error_value(OG_P, Packed_P, P_copy)
        error = abs(error_new - error_old)
        print('\nstep', step, '\n均方误差:', error_new, '\n与上次更新的误差:', error)
        ERROR.append(error_new)
        step += 1
        if error < 1e-5:  # 设定更新阈值
            break
    print ('迭代结束')
    step = np.array(np.mat(Step))
    ERROR = np.array(np.mat(ERROR))
    # writeDataset(step, '迭代步数.xls')
    # writeDataset(ERROR, 'MSE.xls')
    return Packed_P, error_new, step, ERROR






if __name__ == '__main__':
    OGP, labelOG = loadDataset('原始归一化矩阵P.xls')
    MissP, labelP = loadDataset("归一化后缺失P.xls")
    Kfold_num = 5  # K折交叉验证
    S = 3500                    # 最大迭代次数
    K = 15                      # 潜在因子
    Lambda_i = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]              # lambda取值
    'K折交叉验证'
    kf = KFold(n_splits=Kfold_num)
    everyMSE = []
    allDiffer = []
    for find in range(len(Lambda_i)):       # 寻找最优lambda值
        print('寻找第', find+1, '个lambda')
        lambda_i = Lambda_i[find]
        print('选取lambda:', lambda_i)
        trainWhole_mse, testWhole_mse = 0, 0
        for train_index, test_index in kf.split(OGP, MissP):
            OG_Ptrain, OG_Ptest = OGP[train_index], OGP[test_index]
            Ptrain, Ptest = MissP[train_index], MissP[test_index]
            trainResult, trainMSE, trainStep, trainError = Kfold(OG_Ptrain, Ptrain, lambda_i)
            trainWhole_mse += trainMSE
            testResult, testMSE, testStep, testError = Kfold(OG_Ptest, Ptest, lambda_i)
            testWhole_mse += testMSE
        trainAverage_mse = trainWhole_mse / Kfold_num
        testAverage_mse = testWhole_mse / Kfold_num
        differ = abs(trainAverage_mse - testAverage_mse)
        allDiffer.append(differ)        # 训练集与测试集结果做差放入list中
        everyMSE.append(trainAverage_mse)
    lambda_choosed = Lambda_i[allDiffer.index(min(allDiffer))]      # 选取误差结果最小时的lambda值
    '用选出的lambda代入计算'
    Result, MSE, Step, testError = Kfold(OGP, MissP, lambda_choosed)
    Traintemp = np.hstack((Result, labelP))  # 添加类别标签
    for ese in range(len(Lambda_i)):
        print ('lambda:', Lambda_i[ese], 'MSE:', everyMSE[ese])
    '分离训练集和测试集(均带类别标签)'
    testper = 0.2       # 测试集比例
    print ('选取', str(testper * 100) + '%', '作为测试集')
    perNum = int(Traintemp.shape[0] * testper)        # 随机选取30%作为测试集
    TestData = np.empty([0, Traintemp.shape[1]])
    TrainData = np.empty([0, Traintemp.shape[1]])
    for i in range(perNum):
        Randnum = random.randrange(0, Traintemp.shape[0])
        dataTemp = Traintemp[Randnum, :]
        TestData = np.append(TestData, np.array(np.mat(dataTemp)), axis=0)      # 将抽取出的训练集放入训练集列表
        Traintemp = np.delete(Traintemp, Randnum, axis=0)     # 将抽取出的数据从训练集样本中删除
    ran = np.array(random.sample(range(0, Traintemp.shape[0]), Traintemp.shape[0]))
    for j in range(Traintemp.shape[0]):
        TrainData = np.append(TrainData, np.array(np.mat(Traintemp[ran[j], :])), axis=0)
    writeDataset(TrainData, '填充后训练集.xls')
    writeDataset(TestData, '填充后测试集.xls')
    print('最终选取的lambda值为:', lambda_choosed, '对应的MSE:', testError[0, -1])