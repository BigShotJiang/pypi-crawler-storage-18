import numpy as np
import pandas as pd
from openpyxl import Workbook
from sklearn import svm
from sklearn.svm import SVC


'读取数据'
def loadDataset(filename):     # per训练集百分比
    full = pd.read_excel(filename, header=None)
    after_address = np.array(full)
    traindata = np.delete(after_address, -1, axis=1)
    features = np.array(after_address[:, -1]).T
    return traindata, features


'写入数据'
def writeDataset(Array_in, file):       # 输入array,file文件名
    Array_in = np.array(np.mat(Array_in).T)
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = Array_in.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=Array_in[i][j])
    book.save(file)


def train(c, Kernel, train_data, train_target, test_data, testlabel):
    clf = SVC(C=c, kernel=Kernel)  # 创建svm模型
    # train_data = train_data.tolist()
    # train_target = train_target.tolist()
    clf.fit(train_data, train_target)  # 训练模型
    result = clf.predict(test_data)  # 使用模型预测值
    Test_0 = []
    Real_0 = []
    Test_1 = []
    Real_1 = []
    for s1 in range(test_data.shape[0]):
        if testlabel[s1] == 0:
            Test_0.append(result[s1])
            Real_0.append(testlabel[s1])
    for s2 in range(test_data.shape[0]):
        if testlabel[s2] == 1:
            Test_1.append(result[s2])
            Real_1.append(testlabel[s2])
    return Real_0, Test_0, Real_1, Test_1, result


if __name__ == '__main__':
    c = 2     # 松弛变量
    # Kernel = 'rbf'      # Kernel=linear,rbf,poly多项式,precomputed核矩阵
    Kernel = 'linear'
    # train_data, train_target = loadDataset('过采样后新数据集.xls')
    # mytest_data, mytestlabel = loadDataset('EFS后测试集.xls')
    train_data, train_target = loadDataset('FID训练集.xls')
    mytest_data, mytestlabel = loadDataset('FID测试集.xls')
    # SMtrain_data, SMtrain_target = loadDataset('SMOTE后.xls')
    # ADtrain_data, ADtrain_target = loadDataset('ADASYN后.xls')
    # SAtest_data, SAtestlabel = loadDataset('填充后测试集.xls')
    myReal_0, myTest_0, myReal_1, myTest_1, myresult = train(c, Kernel, train_data, train_target, mytest_data, mytestlabel)
    # SMReal_0, SMTest_0, SMReal_1, SMTest_1, SMresult = train(c, Kernel, SMtrain_data, SMtrain_target, SAtest_data, SAtestlabel)
    # ADReal_0, ADTest_0, ADReal_1, ADTest_1, ADresult = train(c, Kernel, ADtrain_data, ADtrain_target, SAtest_data, SAtestlabel)
    print('少类真实结果:', myReal_0)
    print('少类分类结果:', myTest_0)
    print('多类真实结果:', myReal_1)
    print('多类分类结果:', myTest_1)
    writeDataset(myresult, 'mySVM预测分类后结果.xls')
    writeDataset(mytestlabel, 'mySVM测试集真实标签.xls')
    writeDataset(myresult, 'FIDsvm预测分类后结果.xls')
    writeDataset(mytestlabel, 'FIDsvm测试集真实标签.xls')
    # writeDataset(SMresult, 'SMSVM预测分类后结果.xls')
    # writeDataset(ADresult, 'ADSVM预测分类后结果.xls')
    # writeDataset(SAtestlabel, 'SASVM测试集真实标签.xls')