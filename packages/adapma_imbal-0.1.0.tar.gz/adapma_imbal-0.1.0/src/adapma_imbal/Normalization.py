import numpy as np
import pandas as pd
import math
import random
from openpyxl import Workbook


def loadDataset(filename):
    Data_E = pd.read_csv(filename)
    Data_E = np.array(Data_E)
    Data = np.delete(Data_E, -1, )
    labels = Data_E[:, -1]
    return Data, labels


def writeDataset(F, file):
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = F.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=F[i][j])
    book.save(file)


def FIDloadDataset(filename):
    Data_E = pd.read_excel(filename)
    Data_E = np.array(Data_E)
    Data = np.delete(Data_E, -1, axis=1)
    labels = Data_E[:, -1]
    return Data, labels


if __name__ == '__main__':
    # OG, label = loadDataset('vehicle.csv')
    # OG, label = FIDloadDataset('FID多.xls')
    OG, label = FIDloadDataset('FID少.xls')
    m, n = np.shape(OG)
    print('样本数:', m, '\n特征数:', n)
    per = 0.9       # 缺失率
    Rnum = random.sample(range(0, m), m)  # 随机打乱样本集
    OG_P = np.empty([0, n])
    labels = np.empty([0, 1])
    for x in range(m):
        add = OG[Rnum[x], :]
        lbs = label[Rnum[x]]
        OG_P = np.append(OG_P, np.array(np.mat(add)), axis=0)
        labels = np.append(labels, np.array(np.mat(lbs)), axis=0)
    Norm_P = np.zeros((m, n))
    for i in range(m):
        for j in range(n):
            # Norm_P[i][j] = 1e-30 + (OG_P[i][j] - np.min(OG_P[:, j])) / (np.max(OG_P[:, j]) - np.min(OG_P[:, j])) * (1 - 1e-25)
            Norm_P[i][j] = (OG_P[i][j] - np.min(OG_P[:, j])) / (np.max(OG_P[:, j]) - np.min(OG_P[:, j]))
    '写入归一化后的矩阵'
    NP1 = np.hstack((Norm_P, labels))
    writeDataset(NP1, '原始归一化矩阵P.xls')
    '扣掉，缺失值用0代表示'
    number = int(m * n * per)
    print('缺失率：', int(per * 100), '%')
    s = 1
    while s <= number:
        x = np.random.randint(0, m - 1)
        y = np.random.randint(0, n - 1)
        if Norm_P[x][y] != -1:
            Norm_P[x][y] = -1
            s += 1
    NP2 = np.hstack((Norm_P, labels))
    writeDataset(NP2, '归一化后缺失P.xls')


    '''FID前期'''
    NP1 = np.delete(NP1, -1, axis=1)
    NP2 = np.delete(NP2, -1, axis=1)
    # writeDataset(NP1, 'FID多类原始归一化.xls')
    # writeDataset(NP2, 'FID多类归一化缺失.xls')
    writeDataset(NP1, 'FID少类原始归一化.xls')
    writeDataset(NP2, 'FID少类归一化缺失.xls')


    # '''分割训练和测试'''
    # testper = 0.3
    # Traintemp = NP1
    # perNum = int(Traintemp.shape[0] * testper)  # 随机选取30%作为测试集
    # TestData = np.empty([0, Traintemp.shape[1]])
    # TrainData = np.empty([0, Traintemp.shape[1]])
    # for i in range(perNum):
    #     Randnum = random.randrange(0, Traintemp.shape[0])
    #     dataTemp = Traintemp[Randnum, :]
    #     TestData = np.append(TestData, np.array(np.mat(dataTemp)), axis=0)  # 将抽取出的训练集放入训练集列表
    #     Traintemp = np.delete(Traintemp, Randnum, axis=0)  # 将抽取出的数据从训练集样本中删除
    # ran = np.array(random.sample(range(0, Traintemp.shape[0]), Traintemp.shape[0]))
    # for j in range(Traintemp.shape[0]):
    #     TrainData = np.append(TrainData, np.array(np.mat(Traintemp[ran[j], :])), axis=0)
    # writeDataset(TrainData, '未缺失训练集.xls')
    # writeDataset(TestData, '未缺失测试集.xls')