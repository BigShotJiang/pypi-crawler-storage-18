import numpy as np
import pandas as pd
import math
from openpyxl import Workbook
from sklearn.metrics import roc_auc_score


'读取数据'
def loadDataset(filename):
    Data_E = pd.read_excel(filename, header=None)
    Data = np.array(Data_E)
    return Data


'将少类作为正例计算混淆矩阵'
def confusion_matrix(calculatedResult, realResult):     # 预测值,真实值
    m = calculatedResult.shape[0]
    TP, FN, FP, TN = 0, 0, 0, 0
    for i in range(m):      # 0为少类,1为多类
        if calculatedResult[i] == 0 and realResult[i] == 0:        # 如果为真正例
            TP += 1
        elif calculatedResult[i] == 1 and realResult[i] == 0:       # 假反例
            FN += 1
        elif calculatedResult[i] == 0 and realResult[i] == 1:       # 假正例
            FP += 1
        else:       # 真反例
            TN += 1
    return TP, FN, FP, TN


'性能度量指标'
def performance_measure(TP, FN, FP, TN, mySVMRealResult, mySVMCalculatedResult, beta=1):        # beta为F-measure中参数
    OverallAccuracy = (TP + TN) / (TP + FN + FP + TN)
    Precision = TP / (TP + FP)
    Recall = TP / (TP + FN)
    F_Beta = ((1 + beta ** 2) * Recall * Precision) / ((beta ** 2 * Precision) + Recall)
    G_Mean = math.sqrt(Precision * Recall)
    AUC = roc_auc_score(mySVMRealResult, mySVMCalculatedResult)
    return OverallAccuracy, Precision, Recall, F_Beta, G_Mean, AUC


if __name__ == '__main__':
    mySVMCalculatedResult = loadDataset('FIDsvm预测分类后结果.xls')
    mySVMRealResult = loadDataset('FIDsvm测试集真实标签.xls')
    # mySVMCalculatedResult = loadDataset('mySVM预测分类后结果.xls')
    # mySVMRealResult = loadDataset('mySVM测试集真实标签.xls')
    # mySVMCalculatedResult = loadDataset('SMSVM预测分类后结果.xls')
    # mySVMRealResult = loadDataset('SASVM测试集真实标签.xls')
    mySVMTP, mySVMFN, mySVMFP, mySVMTN = confusion_matrix(mySVMCalculatedResult, mySVMRealResult)
    mySVMOverallAccuracy, mySVMPrecision, mySVMRecall, mySVMF_Beta, mySVMG_Mean, mySVMAUC = performance_measure(mySVMTP, mySVMFN, mySVMFP, mySVMTN, mySVMRealResult, mySVMCalculatedResult, beta=1)
    print('总精度:', mySVMOverallAccuracy)
    print('查准率P:', mySVMPrecision)
    print('查全率R:', mySVMRecall)
    print('F_beta:', mySVMF_Beta)
    print('G_Mean:', mySVMG_Mean)
    print('AUC:', mySVMAUC)