from imblearn.over_sampling import SMOTE, ADASYN
import numpy as np
import pandas as pd
from openpyxl import Workbook


'读excel'
def loadDataset(filename):
    Data_E = pd.read_excel(filename, header=None)
    Data = np.array(Data_E)
    return Data


'写excel'
def writeDataset(F, file):
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = F.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=F[i][j])
    book.save(file)


if __name__ == '__main__':
    KS = 5       # 少类K近邻
    KL = 5       # 多类K近邻
    noise_perS = 0.8     # 少类K近邻中80%为多类就判断为噪声
    noise_perL = 0.8     # 多类K近邻中80%为多类就判断为噪声
    m_label = loadDataset('填充后训练集.xls')     # 带标签的所有样本
    m_data = np.delete(m_label, -1, axis=1)     # 不带标签的所有样本
    labels = m_label[:, -1]
    'SMOTE'
    X_smote, Y_smote = SMOTE().fit_sample(m_data, labels)
    YS = np.array(np.mat(Y_smote).T)
    after_smote = np.hstack((X_smote, YS))
    writeDataset(after_smote, 'SMOTE后.xls')
    'ADASYN'
    X_adasyn, Y_adasyn = ADASYN().fit_sample(m_data, labels)
    YA = np.array(np.mat(Y_adasyn).T)
    after_adasyn = np.hstack((X_adasyn, YA))
    writeDataset(after_adasyn, 'ADASYN后.xls')