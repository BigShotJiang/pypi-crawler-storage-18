"""
@author:DFF
"""
#coding:utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from openpyxl import load_workbook
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfTransformer
import sklearn
from sklearn.metrics import confusion_matrix
import tensorflow as tf
import numpy as np
import xlwt
import xlrd
import time
import pandas as pd
from openpyxl import Workbook
from imblearn.metrics import geometric_mean_score



def loadwrite(datain, dataout):
    fileT = pd.read_excel(datain)
    filet = np.array(fileT)
    featureNum = filet.shape[1] - 1
    firstL = np.ones((1, filet.shape[1]))
    data = np.insert(filet, 0, values=firstL, axis=0)
    datanum = data.shape[0]
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = data.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=data[i][j])
    book.save(dataout)
    return datanum, featureNum


trainnum, featureNum0 = loadwrite('过采样后新数据集.xls', 'trainDNN.xlsx')
testnum, featureNum1 = loadwrite('EFS后测试集.xls', 'testDNN.xlsx')
# trainnum, featureNum0 = loadwrite('SMOTE后.xls', 'trainDNN.xlsx')
# testnum, featureNum1 = loadwrite('填充后测试集.xls', 'testDNN.xlsx')
# trainnum, featureNum0 = loadwrite('ADASYN后.xls', 'trainDNN.xlsx')
# testnum, featureNum1 = loadwrite('填充后测试集.xls', 'testDNN.xlsx')



start=time.clock()
tf.logging.set_verbosity(tf.logging.INFO)

ss_X = StandardScaler()
ss_y = StandardScaler()

# 每行数据4个特征，都是real-value的（需要声明每一行，即每一个样本的特征取值）
feature_columns = [tf.contrib.layers.real_valued_column("", dimension=featureNum0)]#因为iris数据为4个特征

# 构建一个DNN分类器，3层，其中每个隐含层的节点数量分别为10，20，10，目标的分类3个，并且指定了保存位置
classifier = tf.contrib.learn.DNNClassifier(feature_columns=feature_columns,
                                            # hidden_units=[10, 25, 30, 25],
                                            hidden_units=[1024, 512, 256],
                                            # hidden_units=[1024, 512, 256, 128, 64, 8],
                                            activation_fn=tf.nn.relu,
                                            #dropout=0.1,
                                            n_classes=2,
                                            optimizer=tf.train.ProximalAdagradOptimizer(learning_rate=0.1,l2_regularization_strength=0.001),
                                            # optimizer=tf.train.MomentumOptimizer(learning_rate=0.01,momentum=0.9),
                                            #optimizer=tf.train.ProximalGradientDescentOptimizer(learning_rate=0.1,l2_regularization_strength=0.001),
                                            #optimizer=tf.train.AdamOptimizer(learning_rate=0.001),
                                            # optimizer="Momentum",
                                            # optimizer=tf.train.GradientDescentOptimizer(0.1),


                                            model_dir='./aaaaaaaaaaaaaa')#要是想改隐藏层的层数，就把model_dir路径改了，不然会报错，因为tensorflow默认会先去找已经训练过的模型#Tensorflow可以保存一些Checkpoint，这样Tensorflow就可以随时保存训练情况了（还可以暂停后继续训练）
                                                                          #activation_fn/dropout/optimizer三个参数原本没有，可以调节。。
                                                                          #如果model_dir一直不变，那么开始迭代时会一直用上一次训练后保存的权重作为这一次的初始权重，并且迭代次数会累加，这容易造成过拟合。。。
#load data
def load_data(file_name):
    book=load_workbook(filename=file_name)#only load .xlsx。。。读取的文件为带有所有属性值和目标值
    sheet=book.get_sheet_by_name("sheetname")
    train_data=[]
    target_data=[]
    line=[]
    row_num=2#第一行为标题
    col_num=1
    if file_name=='trainDNN.xlsx':#训练集数据读取
        while row_num <= trainnum:#加上标题行后的总行数
            while col_num <= featureNum0:#(除去最后一列标签)总列数
                line.append(sheet.cell(row=row_num,column=col_num).value)
                col_num += 1
            train_data.append(line)
            line=[]
            col_num=1
            row_num+=1
        train_data=np.array(train_data)
        row_num=2
        while row_num<=trainnum:
            target_data.append(sheet.cell(row=row_num, column=featureNum0+1).value)#29为最后一列标签所在列数
            row_num+=1
        target_data=np.array(target_data)
    else:                       #测试集数据读取
        while row_num<=testnum:    #加上标题行后的总行数
            while col_num<=featureNum0: #(除去最后一列标签)总列数
                line.append(sheet.cell(row=row_num,column=col_num).value)
                col_num+=1
            train_data.append(line)
            line=[]
            col_num=1
            row_num+=1
        train_data=np.array(train_data)
        row_num=2
        while row_num<=testnum:
            target_data.append(sheet.cell(row=row_num,column=featureNum0+1).value)
            row_num += 1
        target_data=np.array(target_data)
    return train_data,target_data

def stand(X):
    # X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=44, test_size=0.25)
    X = ss_X.fit_transform(X)
    return X


# transformer=TfidfTransformer()

train_set,target_data=load_data('trainDNN.xlsx')
# # print(type(train_set))
# train_set=list(train_set)
# tfidf=transformer.fit_transform(train_set)
# train_set=tfidf.toarray()
print('train_set:\n',train_set,'\ntarget_data:\n',target_data)

test_data,test_target=load_data('testDNN.xlsx')
# test_data=list(test_data)
# tfidf=transformer.fit_transform(test_data)
# test_data=tfidf.toarray()
print('test_data:\n',test_data,'\ntest_target:\n',test_target)

train_set=stand(train_set)
print('train_set:\n',train_set,'\ntarget_data:\n',target_data)
test_data=stand(test_data,)
print('test_data:\n',test_data,'\ntest_target:\n',test_target)
# print(type(test_target))
y_true=list(test_target)



# 指定数据，以及训练的步数，用fit方法，将数据填入模型
classifier.fit(x=train_set,
               y=target_data,
               steps=5000)
# print('x=\n',training_set.data)
# print(type(training_set.data))
# print('y=\n',training_set.target)

# 模型评估
accuracy_score = classifier.evaluate(x=test_data,
                                     y=test_target)["accuracy"]
print('Accuracy: {0:f}'.format(accuracy_score))
print(classifier.evaluate(x=test_data,y=test_target))#输出‘loss’，‘accuracy’，‘global_step’

end_time=time.clock()-start
print('共耗时：',end_time)

#直接对原始数据进行预测（原始数据为）
original_data,original_label=load_data('testDNN.xlsx')
original_data=stand(original_data)
y=classifier.predict(original_data)
y=list(y)
print('Predictions:{}'.format(y))
y_pred=np.array(y)
# print('y_pred=\n',np.shape(y_pred),type(y_pred))

Array_in = np.array(np.mat(y_pred).T)
book = Workbook()
sheet = book.create_sheet('sheetname', index=0)
[h, l] = Array_in.shape
for i in range(h):
    for j in range(l):
        sheet.cell(row=i + 1, column=j + 1, value=Array_in[i][j])
book.save('预测分类后结果.xls')