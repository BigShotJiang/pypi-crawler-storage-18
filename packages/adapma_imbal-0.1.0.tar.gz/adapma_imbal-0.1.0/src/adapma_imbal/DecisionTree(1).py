"参考网址：https://blog.csdn.net/leaf_zizi/article/details/83105836"

import numpy as np
import pandas as pd
from openpyxl import Workbook
from math import log
import operator
import pickle


'计算香农熵(经验熵)'
def calcShannonEnt(dataSet):        # 最后一列是类别号
    numEntries = len(dataSet)       # 样本数
    labelCounts = {}        # 类别字典(类别的名称为键，该类别的个数为值)
    for featVec in dataSet:     # 取每一行数据(一个样本)
        currentLabel = featVec[-1]      # 字典的键值是最后一列的数值
        if currentLabel not in labelCounts.keys():      # 还没添加到字典里的类型
            labelCounts[currentLabel] = 0       # 扩展键值(占个坑位)
        labelCounts[currentLabel] += 1      # 计数+1,每个键值记录了类别出现次数
    shannonEnt = 0.0
    for key in labelCounts.keys():     # 求出每种类型的熵
        prob = float(labelCounts[key])/numEntries       # 每种类型个数占所有的比值
        shannonEnt -= prob * log(prob, 2)
    return shannonEnt       # 输出香农熵


'按照给定的特征划分数据集'
def splitDataSet(dataSet, axis, value, LorR = 'L'):     # 待划分的数据集,划分数据集的特征(第几个),需要返回的特征的值,LorR:value值左侧(小于)或右侧(大于)的数据集
    retDataSet = []
    if LorR == 'L':
        for featVec in dataSet:     # 按dataSet中的第axis列的值划分数据集
            if float(featVec[axis]) < value:        # 选出值小于value的行,每一行为新的列表
                retDataSet.append(featVec)
    else:
        for featVec in dataSet:
            if float(featVec[axis]) > value:
                retDataSet.append(featVec)
    return retDataSet       # 划分数据集,返回分类后的新矩阵


'选择最好的数据集划分方式(某一维特征)'
def chooseBestFeatureToSplit(dataSet):
    numFeatures = len(dataSet[0]) - 1       # 特征数
    baseEntropy = calcShannonEnt(dataSet)       # 计算根节点的信息熵
    bestInfoGain = 0.0
    bestFeature = -1
    bestPartValue = None  # 连续的特征值，最佳划分值
    for i in range(numFeatures):        # 求所有特征的信息增益,对每个特征循环
        featList = [example[i] for example in dataSet]      # 将dataSet中的数据按行依次放入example中,然后取example中example[i]元素,放入列表featList中
        uniqueVals = set(featList)      # 第i列特征的不同数值集合(所有特征)
        bestPartValuei = None
        sortedUniqueVals = list(uniqueVals)     # 将元组转化为列表
        sortedUniqueVals.sort()     # 对连续型特征值排序
        minEntropy = np.inf
        for j in range(len(sortedUniqueVals) - 1):      # 计算划分点
            partValue = (float(sortedUniqueVals[j]) + float(sortedUniqueVals[j + 1])) / 2       # 对每个划分点，计算信息熵
            dataSetLeft = splitDataSet(dataSet, i, partValue, 'L')
            dataSetRight = splitDataSet(dataSet, i, partValue, 'R')
            probLeft = len(dataSetLeft) / float(len(dataSet))
            probRight = len(dataSetRight) / float(len(dataSet))
            Entropy = probLeft * calcShannonEnt(dataSetLeft) + probRight * calcShannonEnt(dataSetRight)
            if Entropy < minEntropy:        # 取最小的信息熵
                minEntropy = Entropy
                bestPartValuei = partValue
        newEntropy = minEntropy
        infoGain = (baseEntropy - newEntropy) / baseEntropy     # 计算信息增益比
        if infoGain > bestInfoGain:         # 取最大的信息增益比对应的特征
            bestInfoGain = infoGain     # 保存信息增益率最大的信息增益率值以及特征编号
            bestFeature = i
            bestPartValue = bestPartValuei
    return bestFeature, bestPartValue       # 最好的划分维度(第i列特征),最好的划分值


'找出出现次数最多的分类名称'
def majorityCnt(classList):     # 分类类别名称列表
    classCount = {}
    for vote in classList:
        if vote not in classCount.keys():       # 计算每个类标签出现的频率
            classCount[vote] = 0
        classCount[vote] += 1
    sortedClassCount = sorted(classCount.items(), key = operator.itemgetter(1), reverse=True)#iteritems()      # 操作键值排序字典
    return sortedClassCount[0][0]       # 子节点的分类(出现次数最多的分类名称)


'创建树(对连续的特征,不删除该特征,分别构建左子树和右子树)'
def createTree(dataSet, labels):        # 数据集,特征标签列表
    classList = [example[-1] for example in np.array(dataSet)]        # 创建需要创建树的训练数据的结果列表(类别向量)
    if classList.count(classList[0]) == len(classList):     # 如果所有的训练数据都是属于一个类别,则返回该类别
        return classList[0]     # 类别完全相同,停止划分
    # if len(dataSet[0]) == 1:      # 训练数据只给出类别数据(没给任何属性值数据),返回出现次数最多的分类名称
    #     return majorityCnt(classList)       # 遍历完所有特征时返回出现次数最多的
    bestFeat, bestPartValue = chooseBestFeatureToSplit(dataSet)        # 开始创建树,选择信息增益最大的属性进行划分
    if bestFeat == -1:
        return majorityCnt(classList)
    bestFeatLabel = str(labels[bestFeat]) + '<' + str(bestPartValue)
    myTree = {bestFeatLabel: {}}        # 以bestFeatLabel为根节点建一个空树
    subLabels = labels[:]
    valueLeft = '是'     # 构建左子树
    myTree[bestFeatLabel][valueLeft] = createTree(splitDataSet(dataSet, bestFeat, bestPartValue, 'L'), subLabels)
    valueRight = '否'        # 构建右子树
    myTree[bestFeatLabel][valueRight] = createTree(splitDataSet(dataSet, bestFeat, bestPartValue, 'R'), subLabels)
    return myTree  # 返回生成的树


'决策树进行分类'
def classify(inputTree, featLabels, OnetestVec):       # 决策树,分类标签,一条测试数据
    firstStr = list(inputTree.keys())[0]      # 根节点
    lessIndex = str(firstStr).find('<')     # 寻找返回值,返回索引,不存在返回-1
    firstLabel = float(str(firstStr)[:lessIndex])
    secondDict = inputTree[firstStr]
    featIndex = featLabels.index(firstLabel)        # 跟节点对应的特征
    classLabel = None
    for key in secondDict.keys():       # 对每个分支循环,递归遍历整棵树
        partValue = float(str(firstStr)[lessIndex + 1:])
        if float(OnetestVec[featIndex]) < partValue:      # 进入左子树
            if type(secondDict['是']).__name__ == 'dict':        # 该分支不是叶子节点,递归
                classLabel = classify(secondDict['是'], featLabels, OnetestVec)
            else:       # 如果是叶子,返回结果
                classLabel = secondDict['是']
        else:
            if type(secondDict['否']).__name__ == 'dict':        # 该分支不是叶子节点,递归
                classLabel = classify(secondDict['否'], featLabels, OnetestVec)
            else:           # 如果是叶子,返回结果
                classLabel = secondDict['否']
    return classLabel       # 决策结果


'读取数据'
def train_loadDataset(filename):     # per训练集百分比
    full = pd.read_excel(filename, header=None)
    columns = list(full.columns)
    feature = columns[:len(columns)]
    features = columns[:len(columns) - 1]       # 读取第一行的特征值行(除了最后一列标签列)
    temp = np.array(full[feature])
    traindata = temp.tolist()
    return traindata, features

def test_loadDataset(filename):
    full = pd.read_excel(filename, header=None)
    temp = np.array(full)
    temp1 = temp[:, :-1]
    temp2 = temp[:, -1]
    testdata = temp1.tolist()
    testlabel = temp2.tolist()
    return testdata, testlabel


'写入数据'
def writeDataset(Array_in, file):       # 输入array,file文件名
    Array_in = np.array(np.mat(Array_in).T)
    book = Workbook()
    sheet = book.create_sheet('sheetname', index=0)
    [h, l] = Array_in.shape
    for i in range(h):
        for j in range(l):
            sheet.cell(row=i + 1, column=j + 1, value=Array_in[i][j])
    book.save(file)


'保存决策树到文件'
def storeTree(inputTree, filename):     # 决策树，保存文件路径
    fw = open(filename, 'wb')
    pickle.dump(inputTree, fw)
    fw.close()


'从文件读取决策树'
def grabTree(filename):     # 文件路径名
    fr = open(filename, 'rb')
    return pickle.load(fr)      # 返回决策树


def Main(Data_train, labels, DataTest, testlabel):
    Feat = np.zeros((1, np.array(np.mat(Data_train)).shape[1]))
    Datatrain = np.insert(np.array(np.mat(Data_train)), 0, values=Feat, axis=0)       # 添加伪特征行
    DataTrain = Datatrain.tolist()
    labels_copy = labels[:]      # 拷贝，createTree会改变labels
    TreeModel = createTree(DataTrain, labels_copy)      # 训练决策树,返回的是字典形式
    modelName = 'C4.5模型'
    storeTree(TreeModel, modelName)     # 保存树模型
    C45Tree = grabTree(modelName)       # 加载树模型
    m, n = np.shape(DataTest)
    Test_result = []
    for i in range(m):        # 按顺序将每一条数据进行分类
        data = DataTest[i]
        result_Temp = classify(C45Tree, labels_copy, data)      # 输入测试集,返回分类结果
        Test_result.append(result_Temp)       # 将每一条结果添加到空列表中,最后一列为分类结果
    Test_0 = []
    Real_0 = []
    for s in range(m):
        if testlabel[s] == 0:
            Test_0.append(Test_result[s])
            Real_0.append(testlabel[s])
    # print ('少类真实结果:', Real_0)
    # print ('少类分类结果:', Test_0)
    return Test_result


if __name__ == '__main__':
    Data_train, labels = train_loadDataset('过采样后新数据集.xls')
    DataTest, testlabel = test_loadDataset('EFS后测试集.xls')
    Test_result = Main(Data_train, labels, DataTest, testlabel)
    writeDataset(Test_result, '预测分类后结果.xls')
    writeDataset(testlabel, '测试集真实标签.xls')