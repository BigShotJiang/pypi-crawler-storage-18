"""Boring CLI commands."""
