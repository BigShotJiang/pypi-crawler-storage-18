# BHH - A Library for You

## Version: 0.3.10
Changes in this version:

Gameplay feature removed

A fun feature added

## Developer: Aria
[PyPI Page](https://pypi.org/user/ariakm1394/)

---

## License

This project is licensed under the BHAP License - see the [LICENSE](LICENSE.txt) file for details.

### License:

```txt

BHAP License (c) 2025 Aria

The bhh project is an open-source project.

This license allows you to:

- Modify the code

- Redistribute it

- Publish it

- Use the hashing formula or other formulas from this project in your own projects

Conditions for redistribution and release:

1. Your name must be included in the redistributed version.

2. The BHAP License must be included with the project.

3. The project must remain open-source.

This software is provided "as is", without any warranty of any kind. The author shall not be held

liable for any damages arising from the use of this software.

```

---

## Features:

🔒 Hash your passwords with both random and chosen salts

🌐 Add a search engine to your app

🌐 Bind ports to serve static files with a simple HTTP server

💻 Install libraries from PyPI

😊 Reverse the text

---

## Usage:

BHH is a Python toolbox for you. Instead of writing 25 lines of code, you can do it with 1 line. You can use this package as a web server, make your simple games easier, and ......
Other features are mentioned in the Features section ☝️

---

## Installation:

```batch

pip install bhh 



```

---

### Requirements

- requests >= 2.0.0  

- Pillow >= 10.0.0  

---

# How it works

1. Open your Windows Powershell or Command Prompt

2. type 
```batch

pip install bhh

``` 

3. Open your Python IDE or Python Terminal

4. type
```python

import bhh

```

5. Now you can use any of the following commands as you wish:

```python
#hash password
hash1 = print(bhh.hash_password("your password"))
print(hash1)

hash2 = print(bhh.hash_password_with_salt("your password", b"your salt"))
print(hash2)

#verify password
print(bhh.verify_password("your password", hash2)) # True or False

#install package
print(bhh.install_from_pypi("package name"))

#search web
number_of_outputs = 15
print(bhh.search_web("your search", "YOUR_BING_API_KEY", number_of_outputs))

#bind port
port = 1234
print(bhh.apos("service path", port, "ip", "homepage"))

#reverse text (Fun 😊 )
print(bhh.reverse_text("Hello!")) # output: !olleH
```