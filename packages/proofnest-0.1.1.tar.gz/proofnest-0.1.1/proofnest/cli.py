#!/usr/bin/env python3
"""
PROOFNEST CLI - Proof, not promises.

Usage:
    proofnest --version
    proofnest verify <bundle.json>
    proofnest verify <bundle.json> --pubkey <hex>
"""

import argparse
import sys
import json
from pathlib import Path

from proofnest import __version__, Bundle, verify_proofbundle_standalone


def main():
    """Main CLI entrypoint."""
    parser = argparse.ArgumentParser(
        prog="proofnest",
        description="Proof, not promises. Tamper-evident decision logging for AI agents.",
        epilog="https://proofnest.io",
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"proofnest {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # verify command
    verify_parser = subparsers.add_parser(
        "verify",
        help="Verify a proof bundle",
    )
    verify_parser.add_argument(
        "file",
        type=str,
        help="Path to bundle JSON file",
    )
    verify_parser.add_argument(
        "--pubkey", "-k",
        type=str,
        help="Public key in hex format (required for signature verification)",
    )
    verify_parser.add_argument(
        "--verbose", "-V",
        action="store_true",
        help="Show detailed verification info",
    )

    args = parser.parse_args()

    if args.command == "verify":
        verify_bundle(args.file, pubkey=args.pubkey, verbose=args.verbose)
    elif args.command is None:
        parser.print_help()
        sys.exit(0)
    else:
        parser.print_help()
        sys.exit(1)


def verify_bundle(file_path: str, pubkey: str = None, verbose: bool = False) -> None:
    """Verify a proof bundle file."""
    # Security: Check BEFORE resolve (resolve follows symlinks)
    raw_path = Path(file_path)

    if raw_path.is_symlink():
        print(f"ERROR: Symlinks not allowed: {file_path}", file=sys.stderr)
        sys.exit(1)

    if not raw_path.exists():
        print(f"ERROR: File not found: {file_path}", file=sys.stderr)
        sys.exit(1)

    if not raw_path.is_file():
        print(f"ERROR: Not a regular file: {file_path}", file=sys.stderr)
        sys.exit(1)

    # Now safe to resolve
    path = raw_path.resolve()

    try:
        # Load bundle
        bundle_json = path.read_text()
        bundle = Bundle.from_json(bundle_json)

        # Validate schema
        schema_valid = bundle.validate_schema()

        if pubkey:
            # Full signature verification
            try:
                pubkey_bytes = bytes.fromhex(pubkey)
            except ValueError:
                print(f"ERROR: Invalid hex pubkey", file=sys.stderr)
                sys.exit(1)

            is_valid, error = verify_proofbundle_standalone(bundle_json, pubkey_bytes)

            if is_valid:
                print(f"VALID  {path.name}")
                if verbose:
                    print(f"  Type: {bundle.type}")
                    print(f"  ID: {bundle.proof_id[:24]}...")
                    print(f"  Version: {bundle.proofbundle_version}")
                    print(f"  Signature: VERIFIED")
                    if bundle.signer:
                        signer_did = bundle.signer.did if hasattr(bundle.signer, 'did') else str(bundle.signer)[:32]
                        print(f"  Signer: {signer_did}...")
                    if bundle.anchors:
                        print(f"  Anchors: {len(bundle.anchors)}")
                sys.exit(0)
            else:
                print(f"INVALID: {error}", file=sys.stderr)
                sys.exit(1)
        else:
            # Schema-only validation (no signature check)
            if schema_valid:
                print(f"SCHEMA OK  {path.name}")
                if verbose:
                    print(f"  Type: {bundle.type}")
                    print(f"  ID: {bundle.proof_id[:24]}...")
                    print(f"  Version: {bundle.proofbundle_version}")
                    print(f"  Signature: NOT VERIFIED (use --pubkey)")
                    if bundle.signer:
                        signer_did = bundle.signer.did if hasattr(bundle.signer, 'did') else str(bundle.signer)[:32]
                        print(f"  Signer: {signer_did}...")
                print()
                print("Note: Use --pubkey <hex> to verify signature", file=sys.stderr)
                sys.exit(0)
            else:
                print(f"INVALID SCHEMA  {path.name}", file=sys.stderr)
                sys.exit(1)

    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"INVALID: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
