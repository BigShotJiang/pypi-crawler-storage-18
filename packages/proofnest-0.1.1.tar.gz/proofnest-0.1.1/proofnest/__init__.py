"""
PROOFNEST - Proof, not promises.
================================

Tamper-evident decision logging for AI agents.
Post-quantum cryptography. Bitcoin anchoring. Offline verification.

This is the new name for honest-chain. Same functionality, new brand.

Usage:
    from proofnest import ProofNest, RiskLevel

    pn = ProofNest(agent_id="my-agent")
    pn.decide(
        action="Approved loan application",
        reasoning="Credit score 750+, DTI < 40%",
        risk_level=RiskLevel.LOW
    )
    assert pn.verify()

CLI:
    proofnest --version
    proofnest verify <bundle.json>

Migration from honest-chain:
    # OLD                                    # NEW
    from honest_chain import HonestChain     from proofnest import ProofNest
    from honest_chain import DecisionRecord  from proofnest import Decision
    from honest_chain import ProofBundle     from proofnest import Bundle

Copyright (c) 2025 Stellanium Ltd. All rights reserved.
Licensed under Apache License 2.0.
PROOFNEST is a trademark of Stellanium Ltd.
"""

__version__ = "0.1.1"
__author__ = "Stellanium Ltd"
__email__ = "admin@stellanium.io"
__license__ = "Apache-2.0"

# =============================================================================
# Re-export honest-chain with new names
# This is a REBRAND, not a rewrite. Same code, new identity.
# =============================================================================

# Core (renamed for proofnest brand)
from honest_chain import HonestChain as ProofNest
from honest_chain import DecisionRecord as Decision
from honest_chain import Actor, ActorType, RiskLevel
from honest_chain import log_decision

# Identity (quantum-ready)
from honest_chain import (
    AgentIdentity,
    Signature,
    HashCommitment,
    KeyMaterial,
    SignatureAlgorithm,
)

# Bitcoin anchoring (renamed)
from honest_chain import BitcoinAnchorService
from honest_chain import BitcoinAnchor as Anchor
from honest_chain import AnchorMethod
from honest_chain import HonestGroundTruth as GroundTruth
from honest_chain import create_bitcoin_anchor_callback

# P2P network (renamed)
from honest_chain import HonestNode as Node
from honest_chain import MessageType, Message, Peer
from honest_chain import create_anchor_callback

# ProofBundle (renamed)
from honest_chain import ProofBundle as Bundle
from honest_chain import ProofBundleType as BundleType
from honest_chain import Payload, Signer
from honest_chain import ProofSignature
from honest_chain import Anchor as BundleAnchor
from honest_chain import Envelope, Revocation, Attestation
from honest_chain import AnchorStatus
from honest_chain import ProofAnchorMethod
from honest_chain import EnvelopeMessageType
from honest_chain import BroadcastScope, RevocationReason, AttestationMethod
from honest_chain import (
    create_proofbundle,
    verify_proofbundle,
    verify_proofbundle_standalone,
)

# Verification helper
def verify(path: str, public_key: bytes) -> bool:
    """
    Verify a proof bundle file.

    Args:
        path: Path to bundle JSON file
        public_key: Signer's public key (bytes)

    Returns:
        True if bundle is valid and signature matches

    Raises:
        ValueError: If bundle is invalid or tampered
        FileNotFoundError: If file doesn't exist
    """
    from pathlib import Path as _Path

    p = _Path(path)
    if p.is_symlink():
        raise ValueError("Symlinks not allowed for security")
    if not p.is_file():
        raise FileNotFoundError(f"Not a regular file: {path}")

    bundle = Bundle.from_file(str(p.resolve()))
    return bundle.verify(public_key)


__all__ = [
    # Version
    "__version__",

    # Core (rebranded)
    "ProofNest",       # was: HonestChain
    "Decision",        # was: DecisionRecord
    "Actor",
    "ActorType",
    "RiskLevel",
    "log_decision",

    # Identity
    "AgentIdentity",
    "Signature",
    "HashCommitment",
    "KeyMaterial",
    "SignatureAlgorithm",

    # Bitcoin (rebranded)
    "BitcoinAnchorService",
    "Anchor",          # was: BitcoinAnchor
    "AnchorMethod",
    "GroundTruth",     # was: HonestGroundTruth
    "create_bitcoin_anchor_callback",

    # P2P (rebranded)
    "Node",            # was: HonestNode
    "MessageType",
    "Message",
    "Peer",
    "create_anchor_callback",

    # Bundle (rebranded)
    "Bundle",          # was: ProofBundle
    "BundleType",      # was: ProofBundleType
    "Payload",
    "Signer",
    "ProofSignature",
    "BundleAnchor",
    "Envelope",
    "Revocation",
    "Attestation",
    "AnchorStatus",
    "ProofAnchorMethod",
    "EnvelopeMessageType",
    "BroadcastScope",
    "RevocationReason",
    "AttestationMethod",
    "create_proofbundle",
    "verify_proofbundle",
    "verify_proofbundle_standalone",

    # Helpers
    "verify",
]
