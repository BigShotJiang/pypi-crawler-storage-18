"""Schema validation and utilities."""
