"""Message and key generators."""
