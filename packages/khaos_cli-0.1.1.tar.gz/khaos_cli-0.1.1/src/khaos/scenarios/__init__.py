"""Traffic simulation scenarios."""
