"""Tests for rdsai-cli."""
