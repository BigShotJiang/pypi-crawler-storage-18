# Changelog

## [0.3.0](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.2.4...charmarr-lib-testing-v0.3.0) (2025-12-25)


### Features

* **testing:** adds a oci image fetcher utility ([2ad5a1d](https://github.com/charmarr/charmarr-lib/commit/2ad5a1d196f7a8f8e0cdfc7dd2fdf9b347d93b98))


### Bug Fixes

* **testing:** juju wait tolerates transient errors ([18d6798](https://github.com/charmarr/charmarr-lib/commit/18d6798078fa8761a12100b347892ef02a97ef97))

## [0.2.4](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.2.3...charmarr-lib-testing-v0.2.4) (2025-12-24)


### Bug Fixes

* **testing:** code refactor and cleanup ([d80aa0b](https://github.com/charmarr/charmarr-lib/commit/d80aa0b7963a55b5391f52e74f8c912211235bb0))

## [0.2.3](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.2.2...charmarr-lib-testing-v0.2.3) (2025-12-22)


### Bug Fixes

* **core:** fixes lightkube imports ([1c71cb5](https://github.com/charmarr/charmarr-lib/commit/1c71cb51d2fc750a842941d5bcae0116ca3febe0))
* **testing:** adds trust to juju deploy ([e4ef13b](https://github.com/charmarr/charmarr-lib/commit/e4ef13b5bc5eba172cc6497b9a588081811149ed))
* **testing:** fixes jubilant usage ([6ecd668](https://github.com/charmarr/charmarr-lib/commit/6ecd6681ee6e1eab371b892e9264f18344bbe490))

## [0.2.2](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.2.1...charmarr-lib-testing-v0.2.2) (2025-12-16)


### Bug Fixes

* **testing:** fixes local version file update ([71e2dac](https://github.com/charmarr/charmarr-lib/commit/71e2dac22d084dcda68764ae3fe96aecaf6865e3))

## [0.2.1](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.2.0...charmarr-lib-testing-v0.2.1) (2025-12-16)


### Bug Fixes

* **testing:** fixes release please process ([814347f](https://github.com/charmarr/charmarr-lib/commit/814347f3826a61c270aab587099a1ffa7e24824e))

## [0.2.0](https://github.com/charmarr/charmarr-lib/compare/charmarr-lib-testing-v0.1.0...charmarr-lib-testing-v0.2.0) (2025-12-15)


### Features

* adds dev envs for charmarr lib packages ([b8ee5b2](https://github.com/charmarr/charmarr-lib/commit/b8ee5b29bf07a9c4e53a5443da3742c62ec4191c))
* scaffolds monorepo with required packages ([eca8d38](https://github.com/charmarr/charmarr-lib/commit/eca8d38bec8f03dcabd4363b84e1743e495fed4c))
