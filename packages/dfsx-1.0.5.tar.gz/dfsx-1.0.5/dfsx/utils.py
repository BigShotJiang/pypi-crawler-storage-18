import sys

def print_red(text):
    sys.stdout.write(f"\033[91m{text}\033[0m")

def print_green(text):
    sys.stdout.write(f"\033[92m{text}\033[0m")

def print_yellow(text):
    sys.stdout.write(f"\033[93m{text}\033[0m")
