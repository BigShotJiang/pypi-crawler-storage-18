import os
import sys
import json
import shutil
import random
import socket
import subprocess
from pathlib import Path

from dfsx.utils import print_red, print_green, print_yellow

SCRIPT_FILES = [
    "values.json",
    "verifieds.json",
    "app.py",
    "userbot.py"
]

def in_root_directory():
    return os.getcwd() == "/root"

def file_missing_or_empty():
    if not os.listdir():
        return True
    for f in SCRIPT_FILES:
        if not os.path.exists(f) or os.path.getsize(f) == 0:
            return True
    return False

def prompt_inputs():
    api_id = input("\n┌─╼ ENTER API ID\n└────╼ ❯❯❯ ").strip()
    api_hash = input("\n┌─╼ ENTER API HASH\n└────╼ ❯❯❯ ").strip()
    bot_token = input("\n┌─╼ ENTER BOT TOKEN\n└────╼ ❯❯❯ ").strip()
    process_name = input("\n┌─╼ ENTER PROCESS NAME\n└────╼ ❯❯❯ ").strip()
    admin_chat_id = input("\n┌─╼ ENTER ADMIN CHAT ID\n└────╼ ❯❯❯ ").strip()

    return api_id, api_hash, bot_token, process_name, admin_chat_id

def safe_clean_dir():
    for item in os.listdir():
        if item in ["source"]:
            continue
        if os.path.isdir(item):
            shutil.rmtree(item)
        else:
            os.remove(item)

def copy_script_folder():
    src = Path(__file__).resolve().parent / "script"

    if not src.exists():
        print_red("\nInternal script folder missing\n")
        sys.exit(1)

    for item in src.iterdir():
        dest = Path.cwd() / item.name
        if item.is_dir():
            shutil.copytree(item, dest)
        else:
            shutil.copy2(item, dest)

def write_json_files(values, admin_id):
    with open("values.json", "w") as f:
        json.dump(values, f, indent=2)

    with open("verifieds.json", "w") as f:
        json.dump([int(admin_id)], f, indent=2)

def create_venv_and_install():
    subprocess.run(["python3", "-m", "venv", "source"], check=True)
    subprocess.run(
        ["source/bin/pip", "install", "-r", "requirements.txt"],
        check=True
    )

def get_used_ports():
    used = set()
    for conn in socket.socket(socket.AF_INET, socket.SOCK_STREAM):
        pass
    result = subprocess.getoutput("ss -tuln")
    for line in result.splitlines():
        if ":" in line:
            try:
                port = int(line.split(":")[-1])
                used.add(port)
            except:
                pass
    return used

def generate_free_port():
    used = get_used_ports()
    while True:
        port = random.randint(5000, 5999)
        if port not in used:
            return port

def patch_app_py(port):
    with open("app.py", "r") as f:
        data = f.read()

    data = data.replace(
        'uvicorn.run(app, host="0.0.0.0", port=5004)',
        f'uvicorn.run(app, host="0.0.0.0", port={port})'
    )

    with open("app.py", "w") as f:
        f.write(data)

def main():
    if in_root_directory():
        print_red("\nPlease Use in Particular Folder\n")
        sys.exit(1)

    if file_missing_or_empty():
        print_yellow("\nSETUP MODE INITIATED\n")

        api_id, api_hash, bot_token, process_name, admin_id = prompt_inputs()

        safe_clean_dir()
        copy_script_folder()

        write_json_files(
            {
                "api_id": api_id,
                "api_hash": api_hash,
                "bot_token": bot_token,
                "process_name": process_name
            },
            admin_id
        )

        create_venv_and_install()

        print_green("\nScript Loaded Successfully\n")
        sys.exit(0)

    # RUN MODE
    with open("values.json") as f:
        values = json.load(f)

    port = generate_free_port()
    patch_app_py(port)

    rand_process = str(random.randint(100000, 999999))

    subprocess.Popen([
        "supercore",
        "python3",
        "app.py"
    ])

    meta = {
        "vps_ip": subprocess.getoutput("curl -s ifconfig.me"),
        "port": port,
        "process_name": rand_process
    }

    with open("meta_output.json", "w") as f:
        json.dump(meta, f, indent=2)

    print_green("\nSCRIPT HAS RUNNED\n")
    print_green(f"PANEL: http://{meta['vps_ip']}:{port}\n")

if __name__ == "__main__":
    main()
