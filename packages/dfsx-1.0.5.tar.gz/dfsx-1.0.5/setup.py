from setuptools import setup, find_packages

setup(
    name="dfsx",
    version="1.0.5",
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "dfsx=dfsx.cli:main"
        ]
    },
    python_requires=">=3.8",
)
