"""Data sources for SkyCLI."""
