"""
PyLDO - Linked Data Objects for Python

Making RDF as easy as working with plain Python objects.
"""

__version__ = "0.0.1"

__all__ = ["__version__"]
