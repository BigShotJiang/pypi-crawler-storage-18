# PyLDO - Linked Data Objects for Python

🚧 **This package is under active development** 🚧

PyLDO (Linked Data Objects) makes working with RDF data as easy as working with plain Python objects.

## What is PyLDO?

PyLDO is a Python library that lets you interact with RDF (Resource Description Framework) data using familiar object-oriented patterns. It's inspired by the [JavaScript LDO library](https://ldo.js.org/) and designed for building [Solid](https://solidproject.org/) applications.

## Features (Coming Soon)

- 🔄 **Seamless RDF ↔ Python object mapping**
- 📝 **ShEx schema support** - Generate typed Python classes from ShEx shapes
- ⚡ **High performance** - Built on msgspec for speed
- 🔐 **Solid integration** - First-class support for Solid Pods
- 🎯 **Type safe** - Full type hints for IDE support

## Installation

```bash
pip install pyldo
```

## Status

This package is in early development. Star the repo to follow progress!

## License

MIT
