# Third-Party Licenses

This document lists the third-party components used by HONEST CHAIN
and their respective licenses.

## Runtime Dependencies

| Package | License | Purpose |
|---------|---------|---------|
| [dilithium-py](https://pypi.org/project/dilithium-py/) | MIT | Post-quantum signatures (ML-DSA / Dilithium) |
| [pynacl](https://pypi.org/project/PyNaCl/) | Apache-2.0 | Ed25519 signatures, cryptographic primitives |
| [pycryptodome](https://pypi.org/project/pycryptodome/) | BSD-2-Clause / Apache-2.0 | SHA3-256, cryptographic utilities |
| [packaging](https://pypi.org/project/packaging/) | Apache-2.0 / BSD-2-Clause | Version comparison |
| [jsonschema](https://pypi.org/project/jsonschema/) | MIT | JSON Schema validation |

## Optional Dependencies

| Package | License | Purpose |
|---------|---------|---------|
| [bitcoinlib](https://pypi.org/project/bitcoinlib/) | GPL-3.0 | Bitcoin anchoring (optional) |
| [cryptography](https://pypi.org/project/cryptography/) | Apache-2.0 / BSD-3-Clause | Ed25519 alternative backend (optional) |

## Development Dependencies

| Package | License | Purpose |
|---------|---------|---------|
| [pytest](https://pypi.org/project/pytest/) | MIT | Testing framework |
| [pytest-cov](https://pypi.org/project/pytest-cov/) | MIT | Test coverage |
| [black](https://pypi.org/project/black/) | MIT | Code formatting |
| [mypy](https://pypi.org/project/mypy/) | MIT | Type checking |

## Specification Standards

| Standard | License | Usage |
|----------|---------|-------|
| RFC 8785 (JCS) | IETF Trust | JSON Canonicalization Scheme |
| FIPS 203 (ML-DSA) | Public Domain | Post-quantum signature standard |

---

## License Texts

### MIT License (dilithium-py, jsonschema, pytest, black, mypy)

```
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files...
[Full MIT text available at: https://opensource.org/licenses/MIT]
```

### Apache License 2.0 (pynacl, packaging)

```
Licensed under the Apache License, Version 2.0...
[Full Apache 2.0 text available at: https://www.apache.org/licenses/LICENSE-2.0]
```

### BSD-2-Clause (pycryptodome, packaging)

```
Redistribution and use in source and binary forms, with or without
modification, are permitted...
[Full BSD text available at: https://opensource.org/licenses/BSD-2-Clause]
```

---

For the full license text of each dependency, please refer to the
respective package's source repository or PyPI page.
