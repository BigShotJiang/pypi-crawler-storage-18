# Safety Rules for Claude Code Environment

**Version:** 2.0
**Date:** 2025-12-23
**Status:** ACTIVE
**Gate:** `safety-gate-v2.py` (authoritative)

---

## Overview

This document defines safety gates and rules for Claude Code usage on this machine.
The goal is **safe-by-default** operation while preserving productivity.

**Key principle:** BLOCK dangerous operations, don't just warn.

---

## 1. Confirmation Tokens

### Primary Token: `LUBA_OHTLIK: <action>`

To allow a dangerous operation, user must say:
```
LUBA_OHTLIK: <action>
```

Where `<action>` is the specific operation type:

| Action Token | Operation | Example |
|--------------|-----------|---------|
| `sudo` | sudo commands | `LUBA_OHTLIK: sudo` |
| `rm-rf` | recursive delete | `LUBA_OHTLIK: rm-rf` |
| `rm-glob` | delete with wildcards | `LUBA_OHTLIK: rm-glob` |
| `chmod` | recursive chmod | `LUBA_OHTLIK: chmod` |
| `chown` | recursive chown | `LUBA_OHTLIK: chown` |
| `git-push` | git push | `LUBA_OHTLIK: git-push` |
| `git-reset` | git reset --hard | `LUBA_OHTLIK: git-reset` |
| `git-clean` | git clean -f | `LUBA_OHTLIK: git-clean` |
| `publish` | twine/npm/docker publish | `LUBA_OHTLIK: publish` |
| `kubectl` | kubectl delete | `LUBA_OHTLIK: kubectl` |
| `terraform` | terraform destroy | `LUBA_OHTLIK: terraform` |
| `exfil` | curl/wget posting data | `LUBA_OHTLIK: exfil` |

### Web Access Token: `otsi`

To enable web access (WebFetch, WebSearch, Puppeteer to non-allowlisted domains):
```
otsi
```

This is single-use - must be repeated for each web operation.

---

## 2. Secrets Protection

### Rule: Never Print Secrets

If a secret is found, report only:
```
FOUND (redacted) - location: <file or env name>
```

### Protected Files (HARD BLOCKED)

| Pattern | Description |
|---------|-------------|
| `*.env` | Environment files |
| `.credentials.json` | Credential stores |
| `secrets.json` | Secret configs |
| `.netrc` | Network credentials |
| `.pgpass` | PostgreSQL passwords |
| `id_rsa`, `id_ed25519` | SSH private keys |
| `*.pem` | Certificate keys |
| `private*key` | Private key files |

**Note:** These are ALWAYS blocked. No confirmation token bypasses this.

---

## 3. Web Access Policy

### Default: BLOCKED

WebFetch, WebSearch, and Puppeteer navigation are blocked by default.

### How to Enable

1. **Say "otsi"** - enables single web operation
2. **Use allowlisted domain** - automatic for Puppeteer (see below)

### Puppeteer Domain Allowlist

Domains in `~/.claude/config/puppeteer_allowlist.txt` are auto-allowed:

```
docs.python.org
pypi.org
github.com
gitlab.com
bitbucket.org
npmjs.com
rubygems.org
developer.mozilla.org
nodejs.org
rust-lang.org
crates.io
docs.rs
```

To add a domain:
```bash
echo "example.com" >> ~/.claude/config/puppeteer_allowlist.txt
```

### Blocked URL Patterns

Always blocked, no bypass:
- `file://` scheme (local file access)
- `data://` scheme (data URIs)
- `javascript://` scheme
- `127.0.0.1`, `localhost`, `::1` (localhost)
- Private IP ranges (10.x, 172.16-31.x, 192.168.x)
- Link-local addresses

---

## 4. Dangerous Command Patterns

### BLOCKED (require LUBA_OHTLIK)

| Pattern | Token | Description |
|---------|-------|-------------|
| `sudo *` | `sudo` | Privilege escalation |
| `rm -rf`, `rm -fr` | `rm-rf` | Recursive delete |
| `rm *glob*` | `rm-glob` | Delete with wildcards |
| `chmod -R` | `chmod` | Recursive chmod |
| `chmod 777 /` | `chmod` | Wide chmod on root |
| `chown -R` | `chown` | Recursive chown |
| `git push` | `git-push` | Push to remote |
| `git reset --hard` | `git-reset` | Destructive reset |
| `git clean -f` | `git-clean` | Delete untracked files |
| `twine upload` | `publish` | PyPI publish |
| `npm publish` | `publish` | NPM publish |
| `docker push` | `publish` | Docker push |
| `kubectl delete` | `kubectl` | K8s deletion |
| `terraform destroy` | `terraform` | Infra destruction |
| `curl -d $HOME/*` | `exfil` | Data exfiltration |
| `wget --post-file` | `exfil` | Data exfiltration |

### SOFT BLOCKED (warn + log)

| Pattern | Description |
|---------|-------------|
| `~/.claude/*` | Editing Claude config |
| `crontab` | Modifying crontab |
| `systemctl enable/disable` | Systemd service changes |

---

## 5. Testing Safety Rules

### Test 1: Secrets Protection
```bash
# This should be BLOCKED
cat ~/.claude/.env
```
**Expected:** `[GATE] BLOCKED: secrets file pattern: \.env$`

### Test 2: Dangerous Command Gate
```bash
# This should be BLOCKED
sudo apt update
```
**Expected:** `[GATE] BLOCKED: sudo command - privilege escalation`

### Test 3: After Confirmation
```
User: LUBA_OHTLIK: sudo
User: Now run sudo apt update
```
**Expected:** Command proceeds (confirmation file is single-use)

### Test 4: Web Access
```
# This should be BLOCKED without "otsi"
WebSearch for "python docs"
```
**Expected:** `[GATE] BLOCKED: WebSearch requires explicit permission`

### Test 5: Puppeteer Allowlist
```
# This should be ALLOWED (github.com in allowlist)
Navigate Puppeteer to https://github.com
```
**Expected:** Navigation proceeds

### Test 6: Puppeteer Blocked
```
# This should be BLOCKED (localhost)
Navigate Puppeteer to http://localhost:8080
```
**Expected:** `[GATE] BLOCKED: localhost access blocked`

---

## 6. Hook Configuration

### Active Hooks (in order)

| Hook | Trigger | Purpose |
|------|---------|---------|
| `check-memory.py` | Bash, Edit, Write, Read, Grep | Memory integration |
| `pre-dangerous.sh` | Bash, Edit, Write | Block patterns |
| `safety-gate-v2.py` | Bash, Read, WebFetch, WebSearch, Puppeteer | **AUTHORITATIVE GATE** |
| `post-edit.sh` | Edit, Write | Post-modification |
| `security-post-edit.py` | Edit, Write | Security scan |

### Settings Location
```
~/.claude/settings.json
```

---

## 7. Decision Logging

All security decisions are logged to:
```
ops/decision-log.md
```

Format:
```markdown
### 2025-12-23 14:30:00 | Bash | BLOCKED
- Action: sudo apt update
- Reason: sudo command - privilege escalation
```

---

## 8. Emergency Override

### Temporary (single-use)
Create confirmation file:
```bash
echo "sudo" > ~/.claude/safety_confirmed.txt
```

### Permanent (not recommended)
Edit `~/.claude/hooks/safety-gate-v2.py`

**Warning:** Overriding safety is at your own risk.

---

## 9. Safe Operator Workflow

Use the safe wrapper script:
```bash
./scripts/run_claude_safe.sh [claude args...]
```

This:
- Sets SAFE_MODE=1
- Strips secrets from environment
- Runs git status after session
- Logs to ops/changelog.md
- Runs tests if pytest exists

---

**END OF SAFETY RULES v2.0**
