# Hardening Changes Log

**Date:** 2025-12-23
**Version:** 2.0
**Status:** IMPLEMENTED

---

## Summary

Comprehensive hardening of Claude Code environment with:
- Authoritative safety gate (BLOCKS, not warns)
- Web access lockdown (WebFetch, WebSearch, Puppeteer)
- Safe operator workflow
- Dependency hygiene
- Decision logging

---

## Changes Made

### A) Safety Gate v2 (`~/.claude/hooks/safety-gate-v2.py`)

**NEW FILE** - Authoritative security gate

| Feature | Description |
|---------|-------------|
| Exit codes | 0 = ALLOW, 2 = BLOCK |
| Confirmation | `LUBA_OHTLIK: <action>` token |
| Web token | `otsi` for web access |
| Logging | All decisions to `ops/decision-log.md` |

**Blocked patterns:**
- Secrets files (.env, credentials, keys)
- sudo, rm -rf, chmod -R, chown -R
- git push, reset --hard, clean -f
- twine/npm/docker publish
- kubectl delete, terraform destroy
- curl/wget data exfiltration

### B) Web Access Lockdown

**Puppeteer Allowlist:** `~/.claude/config/puppeteer_allowlist.txt`
- docs.python.org, pypi.org
- github.com, gitlab.com, bitbucket.org
- npmjs.com, rubygems.org
- developer.mozilla.org, nodejs.org, rust-lang.org

**Blocked URLs:**
- file://, data://, javascript:// schemes
- localhost (127.0.0.1, ::1)
- Private IPs (10.x, 172.16-31.x, 192.168.x)
- Link-local addresses

**settings.json updated:**
```json
{
  "matcher": "Bash|Read|WebFetch|WebSearch|mcp__puppeteer.*",
  "hooks": [{
    "type": "command",
    "command": "python3 ~/.claude/hooks/safety-gate-v2.py",
    "timeout": 5
  }]
}
```

### C) Safe Operator Workflow

**NEW FILE:** `scripts/run_claude_safe.sh`

Features:
- Sets SAFE_MODE=1, CLAUDE_SAFE_MODE=1
- Strips secrets from environment
- Pre-flight git status check
- Post-session git status
- Runs pytest if available
- Logs to ops/changelog.md

Usage:
```bash
./scripts/run_claude_safe.sh [claude args...]
```

### D) Dependency Hygiene

**Existing:** `requirements.lock.txt` with pinned versions

**Workflow:**
1. `pip-audit` for vulnerability scanning
2. Pin all versions in requirements.lock.txt
3. Update vulnerable packages when safe
4. Document exceptions

### E) Documentation

**Updated:**
- `docs/SAFETY_RULES.md` (v2.0)

**Created:**
- `docs/HARDENING_CHANGES.md` (this file)
- `scripts/run_claude_safe.sh`
- `~/.claude/hooks/safety-gate-v2.py`
- `~/.claude/config/puppeteer_allowlist.txt`

---

## Test Instructions

### 1. Test Secrets Protection
```bash
# Should be BLOCKED
claude -p "read ~/.claude/.env"
```
Expected: `[GATE] BLOCKED: Cannot read secrets file`

### 2. Test Dangerous Command
```bash
# Should be BLOCKED
claude -p "run: sudo apt update"
```
Expected: `[GATE] BLOCKED: sudo command`

### 3. Test Confirmation Token
```bash
# Should work after confirmation
claude -p "LUBA_OHTLIK: sudo. Now run sudo apt update"
```
Expected: Command proceeds

### 4. Test Web Access
```bash
# Should be BLOCKED without "otsi"
claude -p "search for Python documentation"
```
Expected: `[GATE] BLOCKED: WebSearch requires explicit permission`

```bash
# Should work with "otsi"
claude -p "otsi, search for Python documentation"
```
Expected: Search proceeds

### 5. Test Puppeteer Allowlist
```bash
# Should work (github.com in allowlist)
claude -p "navigate puppeteer to https://github.com"
```
Expected: Navigation proceeds

### 6. Test Puppeteer Blocked
```bash
# Should be BLOCKED (localhost)
claude -p "navigate puppeteer to http://localhost:8080"
```
Expected: `[GATE] BLOCKED: localhost access blocked`

### 7. Test Safe Wrapper
```bash
./scripts/run_claude_safe.sh -p "echo hello"
```
Expected: Safe mode banner, command runs, git status shown

---

## Verification Checklist

- [x] safety-gate-v2.py created and executable
- [x] settings.json updated with new hook
- [x] puppeteer_allowlist.txt created
- [x] run_claude_safe.sh created and executable
- [x] SAFETY_RULES.md updated to v2.0
- [x] ops/decision-log.md exists for logging
- [x] requirements.lock.txt exists

---

## Rollback Instructions

If issues occur:

1. **Revert settings.json:**
   ```bash
   git checkout HEAD~1 -- ~/.claude/settings.json
   ```

2. **Disable safety gate:**
   ```bash
   mv ~/.claude/hooks/safety-gate-v2.py ~/.claude/hooks/safety-gate-v2.py.disabled
   ```

3. **Emergency override:**
   ```bash
   echo "*" > ~/.claude/safety_confirmed.txt
   ```

---

## Security Improvements

| Before | After |
|--------|-------|
| Warn on dangerous ops | BLOCK on dangerous ops |
| WebFetch/Search open | Require "otsi" token |
| Puppeteer unrestricted | Domain allowlist |
| No localhost blocking | Block all internal IPs |
| No decision logging | Log to ops/decision-log.md |
| Single confirmation type | Specific action tokens |

---

**END OF HARDENING CHANGES**
