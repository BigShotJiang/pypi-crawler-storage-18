# Hardening Plan

**Date:** 2025-12-23
**Status:** ACTIVE
**Owner:** Stellanium AI Core

---

## Quick Wins (30-60 minutes)

### 1. Clear Secrets from Bash History
```bash
# View current history size
wc -l ~/.bash_history

# Clear history
history -c
history -w
> ~/.bash_history

# Add HISTIGNORE to .bashrc
echo 'HISTIGNORE="*API_KEY*:*TOKEN*:*PASSWORD*:*SECRET*:export *KEY*"' >> ~/.bashrc
source ~/.bashrc
```
**Risk mitigated:** R1 (secrets in history)
**Time:** 5 minutes

### 2. Verify .env Permissions
```bash
# All .env files should be 0600
chmod 600 ~/.claude/.env
chmod 600 ~/.env
chmod 600 ~/.claude/integrations/.env
chmod 600 ~/lumina_project/.env

# Verify
ls -la ~/.claude/.env ~/.env
```
**Risk mitigated:** R2 (file permissions)
**Time:** 2 minutes

### 3. Add MCP Puppeteer Domain Whitelist
Edit `~/.claude/settings.local.json`:
```json
{
  "mcpServers": {
    "puppeteer": {
      "allowedDomains": [
        "localhost",
        "127.0.0.1",
        "github.com",
        "docs.python.org",
        "pypi.org"
      ]
    }
  }
}
```
**Risk mitigated:** R3 (unrestricted browser)
**Time:** 10 minutes

### 4. Pin Python Dependencies
```bash
cd /home/a/.claude/clients/stellanium/honest_chain_pypi

# Generate pinned requirements
pip freeze > requirements.lock.txt

# Or use pip-compile for better control
pip install pip-tools
pip-compile --generate-hashes pyproject.toml -o requirements.lock.txt
```
**Risk mitigated:** R4 (unpinned deps)
**Time:** 15 minutes

### 5. Run Dependency Audit
```bash
pip install pip-audit safety

# Check for vulnerabilities
pip-audit
safety check
```
**Risk mitigated:** Supply chain vulnerabilities
**Time:** 10 minutes

---

## Next Steps (1-2 Days)

### 6. Convert Hook Warnings to Blocks
Edit `~/.claude/hooks/post-edit.sh`:
```bash
# Change exit 0 to exit 2 for critical warnings
if grep -qE "(password|secret|api_key)\s*=\s*['\"][^'\"]+['\"]" "$FILE_PATH"; then
    echo "[HOOK] BLOCKED: Hardcoded secret in $FILE_PATH"
    exit 2  # Changed from warning to block
fi
```
**Risk mitigated:** R7 (weak hooks)
**Time:** 30 minutes

### 7. Remove Unnecessary Group Memberships
```bash
# Check if lxd is actually needed
lxc list 2>/dev/null || echo "lxd not used"

# If not needed:
# sudo gpasswd -d a lxd

# For docker, consider rootless mode instead
```
**Risk mitigated:** R5, R6 (privilege escalation)
**Time:** 1 hour (testing required)

### 8. Add WebFetch/WebSearch Gate Hook
Create `~/.claude/hooks/web-gate.py`:
```python
#!/usr/bin/env python3
import sys
import json

data = json.load(sys.stdin)
tool = data.get('tool_name', '')

if tool in ['WebFetch', 'WebSearch']:
    print("[WEB-GATE] BLOCKED: Web access requires explicit 'otsi' command")
    sys.exit(2)

sys.exit(0)
```
**Risk mitigated:** Accidental data exfiltration
**Time:** 30 minutes

### 9. Enable Command Audit Logging
```bash
# Install auditd
sudo apt install auditd

# Add rules for sensitive files
sudo auditctl -w /home/a/.claude/.env -p rwa -k secrets
sudo auditctl -w /home/a/.ssh -p rwa -k ssh_keys

# Make persistent
echo '-w /home/a/.claude/.env -p rwa -k secrets' | sudo tee -a /etc/audit/rules.d/claude.rules
```
**Risk mitigated:** R10 (no audit logging)
**Time:** 1 hour

---

## Structural Changes (1-2 Weeks)

### 10. Implement Secrets Encryption
```bash
# Option A: age encryption
brew install age  # or apt install age

# Encrypt .env
age -e -p ~/.claude/.env > ~/.claude/.env.age
shred -u ~/.claude/.env

# Create decryption helper script
```
**Risk mitigated:** R2 (unencrypted secrets at rest)
**Time:** 4 hours

### 11. Set Up File Integrity Monitoring
```bash
# Install AIDE
sudo apt install aide

# Initialize database
sudo aideinit

# Configure for home directory
sudo nano /etc/aide/aide.conf
# Add: /home/a/.claude CONTENT_EX
```
**Risk mitigated:** R8 (no file integrity)
**Time:** 2 hours

### 12. Implement Least Privilege for Cron Jobs
```bash
# Create dedicated user for non-interactive tasks
sudo useradd -r -s /bin/false claude-cron

# Move scripts to run as restricted user
# Update crontab entries
```
**Risk mitigated:** R9 (cron privilege)
**Time:** 4 hours

### 13. Set Up Backup Verification
```bash
# Add backup restore test to weekly audit
# Create isolated test environment
# Verify backups monthly
```
**Risk mitigated:** Data loss on compromise
**Time:** 2 hours

### 14. Create Security Monitoring Dashboard
- Log aggregation for hooks, cron, audits
- Alert on blocked operations
- Weekly security summary email
**Time:** 8 hours

---

## Incident Response Checklist

If compromise suspected:

### Immediate (0-15 minutes)
1. [ ] **Disconnect from network** (if safe to do so)
2. [ ] **Don't reboot** (preserve volatile evidence)
3. [ ] **Screenshot current state** (open terminals, processes)

### Assessment (15-60 minutes)
4. [ ] **Check running processes:** `ps auxf`
5. [ ] **Check network connections:** `ss -tulpn`
6. [ ] **Check recent file changes:** `find /home/a -mmin -60`
7. [ ] **Check auth logs:** `sudo tail -100 /var/log/auth.log`
8. [ ] **Check cron:** `crontab -l; ls -la /etc/cron.*`

### Containment (1-4 hours)
9. [ ] **Rotate all API keys:**
   - OpenAI: https://platform.openai.com/api-keys
   - Wise: https://wise.com/settings/api-tokens
   - Telegram: @BotFather /revoke
   - PyPI: https://pypi.org/manage/account/token/
   - Supabase: Project Settings > API

10. [ ] **Revoke SSH keys:**
    ```bash
    # GitHub
    gh ssh-key delete <key-id>

    # Generate new keys
    ssh-keygen -t ed25519 -C "recovery@stellanium.io"
    ```

### Recovery (4-24 hours)
11. [ ] **Restore from clean backup** (dated before compromise)
12. [ ] **Review git history** for unauthorized commits
13. [ ] **Scan all repos** for leaked secrets: `trufflehog`
14. [ ] **Update all dependencies** to latest secure versions
15. [ ] **Document incident** in ops/decision-log.md

### Post-Incident (1-7 days)
16. [ ] **Root cause analysis**
17. [ ] **Update threat model**
18. [ ] **Implement missing controls**
19. [ ] **Share learnings** (if applicable)

---

## Progress Tracking

| Task | Priority | Status | Owner | Due |
|------|----------|--------|-------|-----|
| Clear bash history | P0 | ⬜ TODO | User | Today |
| Verify .env permissions | P0 | ⬜ TODO | User | Today |
| MCP domain whitelist | P0 | ⬜ TODO | User | Today |
| Pin dependencies | P1 | ⬜ TODO | User | This week |
| Dependency audit | P1 | ⬜ TODO | User | This week |
| Convert hooks to blocks | P1 | ⬜ TODO | User | This week |
| Web gate hook | P1 | ⬜ TODO | User | This week |
| Audit logging | P2 | ⬜ TODO | User | Next sprint |
| Secrets encryption | P2 | ⬜ TODO | User | Next sprint |

---

**END OF HARDENING PLAN**
