# HONEST Chain L1 Specification v4.2.13

**Status:** FINAL SUBMISSION

---

## 1. PROTOCOL CONSTANTS

### 1.1 Chain Identity
```
CHAIN_ID = 0x484f4e455354434841494e31  // 12 bytes: "HONESTCHAIN1"
```

### 1.2 Limits (all u64 unless noted)
```
MAX_TX_DATA_LEN       = 65536        // 64 KB
MAX_TXS_PER_BLOCK     = 10000
MAX_VALIDATORS        = 100
MAX_BLOCK_BODY_SIZE   = 10_000_000   // 10 MB
MAX_COMMIT_SIZE       = 3_000_000    // 3 MB
MAX_STAKE             = 2^63 - 1     // u64 positive range
MIN_STAKE             = 10^17        // ~0.1 token at 18 decimals
BASE_FEE              = 1000
MIN_FEE_PER_BYTE      = 100
```

### 1.3 Domain Tags (12 bytes each, unbroken hex)
```
HONESTHEADER = 0x484f4e455354484541444552
HONESTTXFULL = 0x484f4e455354545846554c4c
HONESTTXSIG_ = 0x484f4e45535454585349475f
HONESTVOTES_ = 0x484f4e455354564f5445535f
HONESTMERKLE = 0x484f4e4553544d45524b4c45
HONESTEMPTY_ = 0x484f4e455354454d5054595f
HONESTDACOM_ = 0x484f4e4553544441434f4d5f
HONESTSMTVAL = 0x484f4e455354534d5456414c
HONESTVLDRS_ = 0x484f4e455354564c4452535f
HONESTPUBKY_ = 0x484f4e4553545055424b595f
HONESTLEAF__ = 0x484f4e4553544c4541465f5f
HONESTRECPT_ = 0x484f4e455354524543505445
```

Each tag is exactly 12 bytes (24 hex chars). Verify: `len(bytes.fromhex(tag)) == 12`.

### 1.4 Algorithm Registry (Cryptographic Specs)
```
algorithm_id  Name           sig_len   pubkey_len  Specification
0x0001        ML-DSA-65      3293      1952        FIPS 204 (Dilithium3)
0x0002        ML-DSA-87      4595      2592        FIPS 204 (Dilithium5)
0x0003        SLH-DSA-256f   29792     32          FIPS 205 (SPHINCS+)

Verification:
- Use canonical pubkey/signature encodings per FIPS 204/205
- REJECT non-canonical encodings (trailing bytes, wrong lengths)
- Signatures MUST be deterministic (ML-DSA) or use domain-separated randomness
```

### 1.5 Transaction Types
```
TX_TYPE_TRANSFER = 0x01

NORMATIVE: REJECT if tx.type not in {0x01}
```

### 1.6 Constants
```
ZERO_32 = 0x0000000000000000000000000000000000000000000000000000000000000000
EMPTY_LEAF = 0x21fc4c2bedb8ed0372b08bdbefc53771204d7d514a07195a6517bccf8722e5e0
HONESTEMPTYROOT = 0x149db7e28404205b568efdaf452d57c3b07674d48fe52d71cd9a7d130ea356e7
SMT_EMPTY_ROOT = 0x1f8154e1cc662cfc06d90572f894fd060e37f42b28fdca4cc8365793e07cadad
VALIDATORSET_EMPTY_ROOT = 0x1a9af850b19ee5c7a2a5cbc339ec7e2e2e6811da46a9c638dca3cb43d3e082a3
DA_EMPTY_COMMITMENT = 0x64921fb65d031a9cc303f15376428a8b1cb6a179927dfec867637b54999cb632
```

---

## 2. INTEGER ARITHMETIC (Issue 5 FIX)

**NORMATIVE:** All consensus-critical arithmetic uses u256 intermediate values.

```
safe_add(a: u64, b: u64) -> Result<u64>:
    result = u256(a) + u256(b)
    REJECT if result > MAX_U64
    return u64(result)

safe_mul(a: u64, b: u64) -> Result<u64>:
    result = u256(a) * u256(b)
    REJECT if result > MAX_U64
    return u64(result)

MAX_U64 = 0xFFFFFFFFFFFFFFFF
```

---

## 3. VALIDATOR SET (Issues 1, 3 FIX)

### 3.1 ValidatorEntry (43 bytes)
```
ValidatorEntry =
    identity_hash : fixed(32)   // SHA3-256(HONESTPUBKY_ || 0x00 || u16be(algorithm_id) || pubkey)
    algorithm_id  : u16be
    stake         : u64be
    status        : u8          // 0=UNBONDED, 1=BONDED, 2=UNBONDING, 3=JAILED
```

### 3.2 ValidatorSet Commitment
```
ValidatorSetBytes(validators) -> bytes:
    // Filter: only BONDED (status==1)
    bonded = [v for v in validators if v.status == 1]
    // Sort: stake DESC, then identity_hash ASC
    sorted = sort(bonded, key=(-stake, identity_hash))
    // Encode
    result = u32be(len(sorted))
    for v in sorted:
        result += v.identity_hash
        result += u16be(v.algorithm_id)
        result += u64be(v.stake)
        result += u8(v.status)
    return result

validator_root(validators) = SHA3-256(HONESTVLDRS_ || 0x00 || ValidatorSetBytes(validators))
```

### 3.3 Validator Set Resolution
```
NORMATIVE: At height H, the validator set VS(H) is:
- Defined by validator_root in header(H)
- Computed from state at height H-1 (or genesis for H=0)
- Used for: proposer selection at height H, commit verification for block H

VS(H) = deserialize(ValidatorSetBytes corresponding to header(H).validator_root)
```

---

## 4. PROPOSER SELECTION (Issue 9 FIX)

```
proposer_for_round(height: u64, round: u32, vs: [Validator]) -> u16:
    REJECT if len(vs) == 0  // Cannot have empty validator set

    // All arithmetic in u256
    total_stake: u256 = sum(u256(v.stake) for v in vs)
    REJECT if total_stake == 0

    seed: u256 = (u256(height) * 1000 + u256(round)) * 0xffffffffffffffc5
    index: u256 = seed % total_stake

    cumulative: u256 = 0
    for i, v in enumerate(vs):
        cumulative += u256(v.stake)
        if index < cumulative:
            return u16(i)
    return u16(len(vs) - 1)
```

---

## 5. COMMITS (Issue 2 FIX)

### 5.1 CommitEntry
```
CommitEntry =
    validator_index : u16be
    algorithm_id    : u16be
    pubkey          : fixed(pubkey_len(algorithm_id))
    signature       : fixed(sig_len(algorithm_id))
```

### 5.2 CommitBytes
```
CommitBytes =
    block_hash : fixed(32)
    height     : u64be
    round      : u32be
    n          : u16be
    entries    : CommitEntry[n]
```

### 5.3 serialize_CommitBytes
```
serialize_CommitBytes(commit) -> bytes:
    result = commit.block_hash
    result += u64be(commit.height)
    result += u32be(commit.round)
    result += u16be(len(commit.entries))
    for e in commit.entries:
        result += u16be(e.validator_index)
        result += u16be(e.algorithm_id)
        result += e.pubkey
        result += e.signature
    REJECT if len(result) > MAX_COMMIT_SIZE
    return result
```

### 5.4 parse_CommitBytes
```
parse_CommitBytes(bytes) -> Commit:
    REJECT if len(bytes) > MAX_COMMIT_SIZE
    stream = ByteStream(bytes)
    block_hash = read_fixed(stream, 32)
    height = read_u64be(stream)
    round = read_u32be(stream)
    n = read_u16be(stream)
    REJECT if n > MAX_VALIDATORS
    entries = []
    for i in 0..n-1:
        validator_index = read_u16be(stream)
        algorithm_id = read_u16be(stream)
        REJECT if algorithm_id not in registry
        pubkey = read_fixed(stream, registry[algorithm_id].pubkey_len)
        signature = read_fixed(stream, registry[algorithm_id].sig_len)
        entries.append(CommitEntry{...})
    REJECT if stream.remaining() > 0
    return Commit{block_hash, height, round, entries}
```

### 5.5 validate_commit (Issues 1, 3 FIX)
```
validate_commit(commit, validator_set) -> Result:
    // validator_set is exactly VS(commit.height) derived from header.validator_root

    prev_index = -1
    total_stake: u256 = 0

    for entry in commit.entries:
        REJECT if entry.validator_index <= prev_index  // Strictly increasing
        prev_index = entry.validator_index

        REJECT if entry.validator_index >= len(validator_set)
        validator = validator_set[entry.validator_index]

        REJECT if entry.algorithm_id != validator.algorithm_id

        computed_identity = SHA3-256(HONESTPUBKY_ || 0x00 || u16be(entry.algorithm_id) || entry.pubkey)
        REJECT if computed_identity != validator.identity_hash

        vote_sign_input = SHA3-256(HONESTVOTES_ || 0x00 ||
            serialize_VoteSignBytes(entry.algorithm_id, commit.height, commit.round, 2, commit.block_hash))
        REJECT if !Verify(entry.algorithm_id, entry.pubkey, vote_sign_input, entry.signature)

        total_stake += u256(validator.stake)

    quorum_total: u256 = sum(u256(v.stake) for v in validator_set)
    quorum_threshold: u256 = (quorum_total * 2) / 3 + 1
    REJECT if total_stake < quorum_threshold

    ACCEPT
```

---

## 6. BLOCK EXECUTION (Issue 6 FIX)

### 6.1 Execute Block
```
execute_block(state, block) -> Result<new_state>:
    // Verify header
    REJECT if block.height != state.height + 1
    REJECT if block.prev_hash != state.block_hash
    REJECT if block.timestamp_ns <= state.timestamp_ns

    // Get validator set
    vs = state.bonded_validators()
    REJECT if hash(ValidatorSetBytes(vs)) != block.validator_root  // Unless epoch boundary

    // Verify proposer
    expected = proposer_for_round(block.height, block.round, vs)
    REJECT if block.proposer_index != expected

    // Execute transactions in order
    receipts = []
    for i, tx in enumerate(block.transactions):
        result = execute_tx(state, tx)
        if result.success:
            apply_tx(state, tx)  // Update nonces, balances
            receipts.append(Receipt{status=1, gas_used=tx_byte_length(tx), logs=[]})
        else:
            REJECT  // Invalid tx in block makes block invalid

    // Compute roots
    computed_tx_root = merkle_root([TxHash(tx) for tx in block.transactions])
    computed_receipt_root = merkle_root([receipt_hash(r) for r in receipts])
    computed_state_root = state.smt_root()

    REJECT if block.tx_root != computed_tx_root
    REJECT if block.receipt_root != computed_receipt_root
    REJECT if block.state_root != computed_state_root

    // DA verification (external)
    REJECT if block.da_commitment != da_commitment(block)

    state.height = block.height
    state.block_hash = BlockHash(block)
    state.timestamp_ns = block.timestamp_ns
    return state
```

### 6.2 Apply Transaction
```
apply_tx(state, tx):
    sender = state.get_account(tx.sender)
    recipient = state.get_account(tx.recipient)

    sender.balance = safe_sub(sender.balance, safe_add(tx.amount, tx.fee))
    sender.nonce += 1
    recipient.balance = safe_add(recipient.balance, tx.amount)

    state.set_account(tx.sender, sender)
    state.set_account(tx.recipient, recipient)
    // Fee goes to proposer (not burned)
    state.add_proposer_reward(tx.fee)
```

### 6.3 Receipt Hash
```
receipt_hash(r: Receipt) -> Hash32:
    bytes = u8(r.status) || u64be(r.gas_used) || u32be(len(r.logs)) || r.logs
    return SHA3-256(HONESTRECPT_ || 0x00 || bytes)
```

---

## 7. REMAINING STRUCTURES (brief, as defined in prior versions)

### 7.1 TransactionBytes
```
As defined in v4.2.12 with:
- REJECT if tx.type not in {TX_TYPE_TRANSFER}
- REJECT if data_len > MAX_TX_DATA_LEN
- All arithmetic uses safe_add/safe_mul
```

### 7.2 BlockBodyBytes
```
As defined in v4.2.12:
- Length-prefixed transactions
- REJECT if exceeds MAX_BLOCK_BODY_SIZE
- REJECT on trailing bytes
```

### 7.3 Merkle Root
```
As defined in v4.2.12:
- merkle_leaf_hash, merkle_node_hash
- Bitcoin-style duplicate last for odd counts
- Returns HONESTEMPTYROOT for empty list
```

### 7.4 SMT
```
As defined in v4.2.8:
- 256-bit depth, MSB-first traversal
- key = SHA3-256(address)
- value = nonce:u64be || balance:u64be
- SMT_EMPTY_ROOT for empty tree
```

---

## CHANGES IN v4.2.13

| Issue | Fix |
|-------|-----|
| 1 | Validator set for commit explicitly bound to header.validator_root |
| 2 | serialize_CommitBytes and parse_CommitBytes fully specified |
| 3 | Validator set binding for proposer selection via VS(H) |
| 4 | Transaction type registry (TX_TYPE_TRANSFER=0x01 only) |
| 5 | Integer arithmetic uses u256 with explicit overflow rejection |
| 6 | Block execution and state transition fully specified |
| 7 | Algorithm registry references FIPS 204/205 |
| 8 | Domain tag HONESTTXFULL corrected (no space) |
| 9 | Proposer selection requires non-empty validator set and stake |

---

**END OF SPECIFICATION v4.2.13**
