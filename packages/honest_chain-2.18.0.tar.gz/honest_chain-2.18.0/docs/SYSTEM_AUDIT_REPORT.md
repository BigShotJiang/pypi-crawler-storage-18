# System Audit Report

**Date:** 2025-12-23
**Auditor:** Stellanium AI Core (Claude Opus 4.5)
**Scope:** Machine + Claude Code Environment + honest_chain_pypi repo

---

## Executive Summary

| Priority | Count | Status |
|----------|-------|--------|
| **P0 (Critical)** | 3 | Action required |
| **P1 (High)** | 4 | Should fix within 1 week |
| **P2 (Medium)** | 5 | Improve when possible |

### Top P0 Risks
1. **Bash history contains 5 secret-like patterns** - potential credential exposure
2. **Multiple .env files with 0600 perms but no encryption** - readable by user processes
3. **WebFetch/WebSearch removed but MCP Puppeteer unrestricted** - browser can access any URL

### Top P1 Risks
1. Dependencies in pyproject.toml unpinned
2. Crontab runs scripts with network access every 5-30 minutes
3. Docker group membership allows container escape
4. Hooks warn but don't block most dangerous operations

---

## Evidence Table

| Command | Result Summary |
|---------|----------------|
| `whoami; id` | User: a, uid=1000, groups: sudo, docker, lxd, libvirt |
| `sudo -l` | Requires password (good - not NOPASSWD) |
| `stat ~/.claude/.env` | Permissions: 0600 (owner-only, good) |
| `ls ~/.claude/.env` | Size: 1322 bytes, contains 9 secrets (FOUND - redacted) |
| `find .env` | 4 .env files in /home/a tree |
| `bash_history` | 253 lines, 5 potential secret patterns |
| `crontab -l` | 10 active cron jobs |
| `systemctl list-timers` | 14 system timers (standard Ubuntu) |
| `ps aux` | 662 processes (348 root, 259 user, 24 www-data) |
| `git status` | Repo clean, no uncommitted changes |

---

## Risk Register

| ID | Risk | Impact | Likelihood | Mitigation |
|----|------|--------|------------|------------|
| R1 | Secrets in bash_history | HIGH | MEDIUM | Clear history, use `HISTIGNORE` |
| R2 | Unencrypted .env files | HIGH | LOW | Encrypt at rest or use secrets manager |
| R3 | Puppeteer MCP unrestricted | HIGH | MEDIUM | Add domain whitelist |
| R4 | Unpinned dependencies | MEDIUM | MEDIUM | Pin versions with hashes |
| R5 | Docker group = root equivalent | HIGH | LOW | Remove from docker group or use rootless |
| R6 | lxd group = container escape | MEDIUM | LOW | Remove if not needed |
| R7 | Hooks warn but allow dangerous ops | MEDIUM | MEDIUM | Change to BLOCK (exit 2) |
| R8 | No file integrity monitoring | MEDIUM | LOW | Add AIDE or tripwire |
| R9 | Cron jobs run as user with secrets access | MEDIUM | LOW | Principle of least privilege |
| R10 | No audit logging | MEDIUM | MEDIUM | Enable auditd |

---

## Hooks & Guardrails Matrix

| Protection | check-memory.py | pre-dangerous.sh | safety-gate.py | post-edit.sh | security-post-edit.py |
|------------|-----------------|------------------|----------------|--------------|----------------------|
| **sudo** | ❌ | ❌ | ✅ BLOCK | ❌ | ❌ |
| **rm -rf** | ❌ | ✅ BLOCK | ✅ BLOCK | ❌ | ❌ |
| **read .env** | ❌ | ⚠️ WARN | ✅ BLOCK | ❌ | ❌ |
| **git push** | ❌ | ❌ | ✅ BLOCK | ❌ | ❌ |
| **twine upload** | ❌ | ❌ | ✅ BLOCK | ❌ | ❌ |
| **hardcoded secrets** | ❌ | ❌ | ❌ | ⚠️ WARN | ⚠️ WARN |
| **WebFetch/Search** | ❌ | ❌ | ❌ | ❌ | ❌ |

**Legend:** ✅ BLOCK = prevents action | ⚠️ WARN = allows but warns | ❌ = no protection

---

## Secrets Found (Redacted)

| Location | Variables | Permission |
|----------|-----------|------------|
| `~/.claude/.env` | OPENAI_API_KEY, WISE_API_TOKEN, WISE_PROFILE_ID, TELEGRAM_BOT_TOKEN, TWINE_USERNAME, TWINE_PASSWORD, SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_KEY | FOUND (redacted) - 0600 |
| `~/.env` | Unknown | FOUND (redacted) |
| `~/.claude/integrations/.env` | Unknown | FOUND (redacted) |
| `~/lumina_project/.env` | Unknown | FOUND (redacted) |

---

## Network Exposure

| Service | Status |
|---------|--------|
| SSH | Not detected listening |
| HTTP/HTTPS | www-data processes (likely nginx/apache) |
| PostgreSQL | postgres user running |
| Docker | docker0 bridge active |
| Ollama | ollama user running (AI inference) |

**MCP Puppeteer:** Can navigate to ANY URL, execute JavaScript, take screenshots. No domain restrictions.

---

## Supply Chain (Python)

| Issue | Finding |
|-------|---------|
| Pinned versions | NO - pyproject.toml uses version ranges |
| Hash verification | NO |
| Lock file | NO - no poetry.lock or pip-tools |
| Vulnerable deps | NOT CHECKED (needs safety/pip-audit scan) |

---

## Recommendations (Ordered by Priority)

### P0 - Do Now
1. Clear bash history of secrets: `history -c && history -w`
2. Add `HISTIGNORE` for sensitive commands
3. Add domain whitelist to MCP Puppeteer config

### P1 - This Week
4. Pin all dependencies with hashes
5. Run `pip-audit` on dependencies
6. Evaluate docker/lxd group necessity
7. Convert hook warnings to blocks for critical ops

### P2 - Next Sprint
8. Implement secrets encryption (age, sops, or vault)
9. Enable auditd for command logging
10. Set up file integrity monitoring
11. Review cron job permissions
12. Add WebFetch/WebSearch hook gate

---

## Appendix: Full Command Outputs

See `docs/audit_artifacts/` for complete command outputs.

---

**END OF AUDIT REPORT**
