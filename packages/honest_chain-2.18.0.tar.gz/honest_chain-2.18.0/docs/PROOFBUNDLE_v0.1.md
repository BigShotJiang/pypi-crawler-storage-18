# ProofBundle v0.1 Specification

**Version:** 0.1.0
**Status:** Draft
**Date:** 2025-12-24
**Authors:** Stellanium Ltd

> **License:** This specification is licensed under
> [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).
> You are free to implement, share, and adapt this specification,
> provided you give appropriate credit to Stellanium Ltd.

---

## Abstract

ProofBundle is a portable, verifiable proof format for AI decisions, documents, and agent-to-agent communication. It provides:

- **Post-quantum signatures** (Dilithium / ML-DSA-65)
- **Cryptographic timestamps** via multi-chain anchoring
- **Chain-agnostic design** - works with Bitcoin, Ethereum, or any anchor
- **Privacy modes** - full disclosure, commitment-only, or ZK attestation

---

## 1. Design Principles

| Principle | Implementation |
|-----------|----------------|
| **PQ-native** | All signatures use Dilithium (ML-DSA). SHA3-256 for hashing. |
| **Deterministic** | JCS canonicalization. Same input = same `signing_root`. |
| **Portable** | JSON format. No chain-specific dependencies in core. |
| **Verifiable offline** | Signature verification needs only the public key. |
| **Anchor-agnostic** | Anchors are timestamp/availability layer, not security. |

---

## 2. ProofBundle Structure

```json
{
  "proofbundle_version": "0.1",
  "proof_id": "sha3-256:abc123...",
  "type": "decision|document|envelope|attestation|revocation",

  "payload": {
    "hash": "sha3-256:def456...",
    "hash_algorithm": "sha3-256",
    "content": null,
    "content_type": "application/json",
    "content_url": null,
    "commitment_only": true
  },

  "signer": {
    "key_id": "d4e5f6a1",
    "key_version": 1,
    "algorithm": "dilithium3",
    "public_key_hash": "sha3-256:789abc...",
    "did": "did:honest:d4e5f6a1"
  },

  "timestamp": "2025-12-24T22:00:00.000Z",

  "signature": {
    "algorithm": "dilithium3",
    "signing_root": "sha3-256:fedcba...",
    "value": "base64:...",
    "signed_at": "2025-12-24T22:00:00.000Z"
  },

  "anchors": [],

  "metadata": {}
}
```

---

## 3. Signing Process

### 3.1 Signing Payload

The `signing_payload` includes ALL fields EXCEPT:
- `signature` (the signature itself)
- `anchors[].proof` (chain-specific proof data)
- `anchors[].tx_id` (transaction ID, added after confirmation)
- `proof_id` (derived from signing_root)

```python
signing_payload = {
    "proofbundle_version": "0.1",
    "type": "decision",
    "payload": { ... },
    "signer": { ... },
    "timestamp": "2025-12-24T22:00:00.000Z",
    "anchors": [
        {
            "chain": "bitcoin",
            "method": "opentimestamps",
            "status": "pending",
            "submitted_at": "2025-12-24T22:00:00.000Z"
            # NOTE: proof and tx_id excluded
        }
    ],
    "metadata": { ... }
}
```

### 3.2 Signing Root

```
signing_root = SHA3-256( JCS( signing_payload ) )
```

Where JCS = [JSON Canonicalization Scheme (RFC 8785)](https://www.rfc-editor.org/rfc/rfc8785).

### 3.3 Proof ID

```
proof_id = "sha3-256:" + hex( SHA3-256( signing_root ) )
```

The `proof_id` is:
- **Idempotent**: Same content = same ID
- **URL-safe**: Used in verification URLs (`honest.dev/v/{proof_id}`)
- **Collision-resistant**: SHA3-256 security

### 3.4 Signature

```
signature.value = base64( Dilithium3.sign( signing_root, private_key ) )
signature.signing_root = "sha3-256:" + hex( signing_root )
```

---

## 4. Field Definitions

### 4.1 Core Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `proofbundle_version` | string | YES | Always `"0.1"` |
| `proof_id` | string | YES | `sha3-256:<hex>` - derived from signing_root |
| `type` | enum | YES | One of: `decision`, `document`, `envelope`, `attestation`, `revocation` |
| `timestamp` | string | YES | ISO 8601 with milliseconds and Z suffix |

### 4.2 Payload

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `payload.hash` | string | YES | `sha3-256:<hex>` of content |
| `payload.hash_algorithm` | string | YES | Always `"sha3-256"` |
| `payload.content` | any | NO | Actual content (null if commitment_only) |
| `payload.content_type` | string | YES | MIME type |
| `payload.content_url` | string | NO | URL to content (requires hash match) |
| `payload.commitment_only` | boolean | YES | If true, content is private |

**URL Content Rule:** If `content_url` is provided:
- `payload.hash` MUST match `sha3-256(fetch(content_url))`
- Verifier MUST check hash before accepting

### 4.3 Signer

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `signer.key_id` | string | YES | First 8 chars of `sha3-256(public_key)` |
| `signer.key_version` | integer | YES | Starts at 1, increments on rotation |
| `signer.algorithm` | enum | YES | `"dilithium3"` or `"dilithium5"` |
| `signer.public_key_hash` | string | YES | `sha3-256:<hex>` of full public key |
| `signer.did` | string | YES | `did:honest:<key_id>` |

### 4.4 Signature

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `signature.algorithm` | enum | YES | `"dilithium3"` or `"dilithium5"` |
| `signature.signing_root` | string | YES | `sha3-256:<hex>` of signing_payload |
| `signature.value` | string | YES | Base64-encoded Dilithium signature |
| `signature.signed_at` | string | YES | ISO 8601 timestamp |

### 4.5 Anchors

```json
"anchors": [
  {
    "chain": "bitcoin",
    "method": "opentimestamps",
    "status": "pending|confirmed",
    "submitted_at": "2025-12-24T22:00:00.000Z",
    "confirmed_at": null,
    "block_height": null,
    "tx_id": null,
    "proof": null
  }
]
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `chain` | string | YES | `bitcoin`, `ethereum`, `solana`, etc. |
| `method` | string | YES | `opentimestamps`, `merkle`, `direct` |
| `status` | enum | YES | `pending` or `confirmed` |
| `submitted_at` | string | YES | When anchor was submitted |
| `confirmed_at` | string | NO | When confirmed on chain |
| `block_height` | integer | NO | Block number (if applicable) |
| `tx_id` | string | NO | Transaction ID |
| `proof` | string | NO | Chain-specific proof (base64) |

**Multi-anchor:** A ProofBundle MAY have multiple anchors for availability/speed.
Security does NOT depend on anchor chain (Dilithium signature is the trust root).

---

## 5. Envelope Type (AI-to-AI)

When `type` = `"envelope"`, additional fields:

```json
{
  "type": "envelope",
  "envelope": {
    "from": {
      "agent_id": "sender-agent",
      "key_id": "abc123"
    },
    "to": {
      "mode": "unicast|broadcast",
      "agent_id": "recipient-agent"
    },
    "broadcast_scope": "local|mesh|public",
    "ttl_seconds": 3600,
    "message_type": "request|response|notification",
    "correlation_id": "uuid",
    "reply_to": "sha3-256:previous_proof_id"
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `envelope.from.agent_id` | string | YES | Sender agent identifier |
| `envelope.from.key_id` | string | YES | Sender's signing key |
| `envelope.to.mode` | enum | YES | `unicast` (one recipient) or `broadcast` |
| `envelope.to.agent_id` | string | NO | Required if mode=unicast |
| `envelope.broadcast_scope` | enum | NO | `local`, `mesh`, or `public` |
| `envelope.ttl_seconds` | integer | NO | Time-to-live for broadcast |
| `envelope.message_type` | enum | YES | `request`, `response`, `notification` |
| `envelope.correlation_id` | string | NO | Links request/response pairs |
| `envelope.reply_to` | string | NO | proof_id of message being replied to |

---

## 6. Revocation Type

When `type` = `"revocation"`:

```json
{
  "type": "revocation",
  "revocation": {
    "target_key_id": "d4e5f6a1",
    "target_key_version": 1,
    "reason": "scheduled_rotation|compromise|superseded|cessation",
    "successor_key_id": "a1b2c3d4",
    "effective_at": "2025-12-24T22:00:00.000Z"
  }
}
```

**Rules:**
- Revocation MUST be signed by the key being revoked, OR
- Signed by a designated authority key (for compromise scenarios)
- `successor_key_id` indicates the new key to use

---

## 7. Attestation Type (Privacy/ZK)

When `type` = `"attestation"`:

```json
{
  "type": "attestation",
  "attestation": {
    "claim": "user.age >= 18",
    "method": "commitment|zk_snark|zk_stark|redacted",
    "proof_data": "base64:...",
    "verifier_hint": "groth16"
  }
}
```

**Privacy Modes:**
1. **Full disclosure** - `commitment_only: false`, content visible
2. **Commitment only** - `commitment_only: true`, only hash visible
3. **ZK attestation** - Prove claim without revealing data

---

## 8. Key Lifecycle

### 8.1 Key ID Generation

```
public_key_bytes = Dilithium3.generate_keypair().public_key
key_id = sha3-256(public_key_bytes)[0:16]  # First 8 bytes = 16 hex chars
```

### 8.2 Key Registry Entry

```json
{
  "key_id": "d4e5f6a1",
  "agent_id": "my-agent",
  "versions": [
    {
      "version": 1,
      "algorithm": "dilithium3",
      "public_key": "base64:...",
      "created_at": "2025-01-01T00:00:00Z",
      "revoked_at": "2025-12-24T22:00:00Z",
      "revocation_proof_id": "sha3-256:..."
    },
    {
      "version": 2,
      "algorithm": "dilithium3",
      "public_key": "base64:...",
      "created_at": "2025-12-24T22:00:00Z",
      "revoked_at": null
    }
  ],
  "current_version": 2,
  "rotation_policy": "annual"
}
```

---

## 9. Verification Algorithm

```python
def verify_proofbundle(bundle: dict, public_key: bytes) -> bool:
    # 1. Validate schema
    validate_schema(bundle, PROOFBUNDLE_SCHEMA)

    # 2. Reconstruct signing_payload
    signing_payload = extract_signing_payload(bundle)

    # 3. Compute signing_root
    canonical = jcs_canonicalize(signing_payload)
    computed_root = sha3_256(canonical)

    # 4. Verify signing_root matches
    claimed_root = parse_hash(bundle["signature"]["signing_root"])
    if computed_root != claimed_root:
        return False

    # 5. Verify proof_id
    computed_proof_id = sha3_256(computed_root)
    if bundle["proof_id"] != f"sha3-256:{computed_proof_id.hex()}":
        return False

    # 6. Verify Dilithium signature
    signature = base64_decode(bundle["signature"]["value"])
    if not dilithium3_verify(computed_root, signature, public_key):
        return False

    # 7. Verify payload hash (if content provided)
    if bundle["payload"]["content"] is not None:
        content_hash = sha3_256(serialize(bundle["payload"]["content"]))
        if bundle["payload"]["hash"] != f"sha3-256:{content_hash.hex()}":
            return False

    # 8. Verify content_url (if provided)
    if bundle["payload"].get("content_url"):
        url_content = fetch(bundle["payload"]["content_url"])
        url_hash = sha3_256(url_content)
        if bundle["payload"]["hash"] != f"sha3-256:{url_hash.hex()}":
            return False

    return True
```

---

## 10. Canonical JSON (JCS)

ProofBundle uses [RFC 8785 JSON Canonicalization Scheme](https://www.rfc-editor.org/rfc/rfc8785):

1. **Object keys:** Sorted lexicographically (UTF-16 code units)
2. **Numbers:** No trailing zeros, no leading zeros, no `+` sign
3. **Strings:** UTF-8, minimal escape sequences
4. **No whitespace:** Compact representation
5. **No BOM:** UTF-8 without byte order mark

Example:
```python
import jcs  # pip install jcs

canonical_bytes = jcs.canonicalize(signing_payload)
signing_root = hashlib.sha3_256(canonical_bytes).digest()
```

---

## 11. Hash Format

All hashes use the format: `algorithm:hex_value`

```
sha3-256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069
```

**Supported algorithms (v0.1):**
- `sha3-256` (REQUIRED, default)
- `sha3-512` (OPTIONAL)
- `blake3` (OPTIONAL, for performance)

**NOT supported:**
- `sha256` (SHA-2) - Use SHA3-256 for PQ alignment

---

## 12. MIME Types

| Type | Content |
|------|---------|
| `application/json` | JSON data |
| `application/proofbundle+json` | ProofBundle itself |
| `text/plain` | Plain text |
| `application/pdf` | PDF document |
| `application/octet-stream` | Binary data |

---

## 13. Conformance Levels

### Level 1: Compatible
- Valid JSON structure
- Correct schema
- SHA3-256 hashing
- Dilithium signature verifies

### Level 2: Verified
- Level 1 +
- Registered in public registry
- Key lifecycle implemented

### Level 3: Certified
- Level 2 +
- Security audit passed
- SLA commitment
- Annual re-certification

---

## 14. Test Vectors

See: `tests/vectors/` directory for:
- `decision_minimal.json` - Minimal valid decision
- `envelope_minimal.json` - Minimal valid envelope
- `revocation_event.json` - Key revocation example

---

## 15. Security Considerations

### 15.1 Signature Algorithm
- Dilithium3 (ML-DSA-65) provides NIST Level 3 security
- Resistant to quantum attacks (Shor's algorithm)
- ~2.5KB signatures, ~1.5KB public keys

### 15.2 Hash Algorithm
- SHA3-256 (Keccak) for all hashing
- Different construction than SHA-2, quantum-resistant properties
- 256-bit security level

### 15.3 Anchor vs Signature
- **Signature** = Trust root (who signed, integrity)
- **Anchor** = Timestamp (when it existed)
- Compromised anchor chain does NOT compromise signature
- Multi-anchor provides availability, not security multiplication

### 15.4 Terminology
- Use "post-quantum signatures (Dilithium / ML-DSA-65)"
- Avoid "quantum-proof" (overclaim)
- Avoid "quantum-resistant" (weaker than necessary)

---

## Appendix A: JSON Schema

See: `schemas/proofbundle.v0.1.schema.json`

## Appendix B: Reference Implementation

See: `honest-chain` Python package (`pip install honest-chain`)

## Appendix C: Changelog

- **0.1.0** (2025-12-24): Initial specification

---

© 2025 Stellanium Ltd. Licensed under CC BY 4.0.
