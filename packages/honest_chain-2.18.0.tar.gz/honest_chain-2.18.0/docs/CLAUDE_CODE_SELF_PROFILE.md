# Claude Code CLI Self-Profile Audit
**Generated:** 2025-12-23
**Claude Code Version:** 2.0.76
**Model:** claude-opus-4-5-20251101

---

## Summary

I am **Claude Code CLI v2.0.76** running on a powerful AMD Ryzen 9 workstation with 32GB RAM. I have **full file read/write/execute permissions** on this machine, with custom hooks for memory checking and security validation. I can access the filesystem, run shell commands, make web requests, and interact with MCP servers (Puppeteer). Credentials for OpenAI, Wise, Telegram, PyPI, and Supabase are available (stored in `~/.claude/.env`). This is NOT a sandboxed environment - I operate with user `a`'s full permissions including sudo group membership.

---

## Environment Snapshot

### System
| Property | Value |
|----------|-------|
| **OS** | Ubuntu 22.04 (6.8.0-88-generic x86_64) |
| **Host** | a-X570-AORUS-PRO |
| **Shell** | /bin/bash |
| **User** | a (uid=1000, sudo group member) |

### Hardware
| Property | Value |
|----------|-------|
| **CPU** | AMD Ryzen 9 3900XT 12-Core (24 threads) @ 3.8GHz |
| **RAM** | 32 GB (26GB used, 4.7GB available) |
| **Disk** | 915GB NVMe (127GB used, 742GB free) |
| **Network** | Ethernet (192.168.8.104), Docker bridges active |

### Software Versions
| Tool | Version |
|------|---------|
| **Git** | 2.34.1 |
| **Python** | 3.10.12 |
| **pip** | 22.0.2 |
| **Node.js** | 20.19.6 |
| **npm** | 10.8.2 |
| **Docker** | 29.1.2 |
| **Docker Compose** | 5.0.0 |

---

## Claude Code CLI Configuration

### Binary Location
```
/home/a/.local/bin/claude
```

### Version
```
2.0.76 (Claude Code)
```

### Configuration Files Found
| File | Purpose |
|------|---------|
| `~/.claude/settings.json` | Main settings (permissions, hooks) |
| `~/.claude/settings.local.json` | Local overrides (MCP config) |
| `~/.claude/CLAUDE.md` | User instructions (17KB) |
| `~/.claude/priorities.json` | Task priorities |
| `~/.claude/capabilities.json` | Capability registry (359KB) |
| `~/.claude/.env` | **Secrets** (FOUND - redacted) |

### Hooks (Active)
| Hook | Trigger | File |
|------|---------|------|
| **PreToolUse** | Bash, Edit, Write, Read, Grep | `check-memory.py` |
| **PreToolUse** | Bash, Edit, Write | `pre-dangerous.sh` |
| **PostToolUse** | Edit, Write | `post-edit.sh` |
| **PostToolUse** | Edit, Write | `security-post-edit.py` |

### MCP Servers
| Server | Tools |
|--------|-------|
| **Puppeteer** | `puppeteer_navigate`, `puppeteer_screenshot`, `puppeteer_click`, `puppeteer_fill`, `puppeteer_evaluate` |

### Checkpoint/Undo
**UNKNOWN** - No explicit checkpoint mechanism found in config. Claude Code may have internal conversation history but no file-level undo system detected.

### Plugins/Subagents
Found in settings: `Task(*)` tool enabled with subagent types:
- `general-purpose`
- `Explore`
- `Plan`
- `claude-code-guide`

---

## Permissions & Tooling Matrix

| Capability | Status | Evidence |
|------------|--------|----------|
| **File Read** | ✅ ALLOWED | `Read(*)` in permissions, tested successfully |
| **File Write** | ✅ ALLOWED | `Write(*)` in permissions, tested successfully |
| **File Edit** | ✅ ALLOWED | `Edit(*)` in permissions |
| **Shell Commands** | ✅ ALLOWED | `Bash(*)` in permissions, tested successfully |
| **Git Operations** | ✅ ALLOWED | Git available, user has full access |
| **Git Push** | ✅ ALLOWED (assumption) | No explicit deny, user has SSH keys |
| **Web Fetch** | ✅ ALLOWED | `WebFetch(*)` in permissions |
| **Web Search** | ✅ ALLOWED | `WebSearch(*)` in permissions |
| **Subagents** | ✅ ALLOWED | `Task(*)` in permissions |
| **Browser Automation** | ✅ ALLOWED | Puppeteer MCP server active |
| **sudo** | ⚠️ POSSIBLE | User in sudo group, may require password |

### Permission Test Results
```
Created /tmp/cc_test.txt: OK
Read /tmp/cc_test.txt: OK
Deleted /tmp/cc_test.txt: OK
PERMISSION TEST: PASSED
```

---

## Secrets Found (Redacted)

| Secret | Location | Status |
|--------|----------|--------|
| OPENAI_API_KEY | ~/.claude/.env | FOUND (redacted) |
| WISE_API_TOKEN | ~/.claude/.env | FOUND (redacted) |
| WISE_PROFILE_ID | ~/.claude/.env | FOUND (redacted) |
| TELEGRAM_BOT_TOKEN | ~/.claude/.env | FOUND (redacted) |
| TWINE_USERNAME | ~/.claude/.env | FOUND (redacted) |
| TWINE_PASSWORD | ~/.claude/.env | FOUND (redacted) |
| SUPABASE_URL | ~/.claude/.env | FOUND (redacted) |
| SUPABASE_ANON_KEY | ~/.claude/.env | FOUND (redacted) |
| SUPABASE_SERVICE_KEY | ~/.claude/.env | FOUND (redacted) |

---

## Limits & Unknowns

### Known Limits
- **Context Window:** Unlimited (auto-summarization enabled)
- **Tool Timeout:** 2 minutes default, 10 minutes max
- **Output Truncation:** 30,000 characters per tool output
- **File Read:** 2,000 lines default

### Unknowns
- Exact checkpoint/undo mechanism: **UNKNOWN**
- Rate limits on API calls: **UNKNOWN**
- Maximum concurrent subagents: **UNKNOWN**
- Exact hook timeout enforcement: **UNKNOWN**

---

## Best Practices for This Machine/Repo

### What Works Well
1. **Full autonomy** - defaultMode is "allow", minimal friction
2. **Memory hooks** - `check-memory.py` runs before file operations
3. **Security hooks** - Pre-dangerous and post-edit validation
4. **Powerful hardware** - 24 threads, 32GB RAM for parallel tasks
5. **Docker available** - Can spin up containers for testing
6. **All integrations ready** - OpenAI, Wise, Telegram, PyPI, Supabase

### Anti-Patterns (What NOT to do)
1. **Don't print secrets** - Always use redacted output
2. **Don't skip hooks** - They exist for security/memory reasons
3. **Don't make huge files** - 30K char output limit per tool
4. **Don't forget CLAUDE.md** - Contains critical user instructions
5. **Don't ignore priorities.json** - User has P0/P1/P2 task system
6. **Don't publish without testing** - User learned this the hard way (v2.13.2→v2.13.3)

---

## Example Prompts (Copy-Paste Ready)

### 1. Bugfix Loop
```
Leia bug failist X, paranda see, jooksuta testid, ja kui läbivad siis commit.
```

### 2. Refactor
```
Refaktoreeri moodul Y: eralda puhas loogika, lisa tüübid, testi.
```

### 3. Spec → Code
```
Implementeeri spetsifikatsiooni järgi: loe docs/SPEC.md, loo kood, testi.
```

### 4. Test-First (TDD)
```
Kirjuta kõigepealt testid funktsioonile Z, siis implementeeri kuni testid läbivad.
```

### 5. Docs Generation
```
Genereeri API dokumentatsioon moodulist M: docstringid, README, näited.
```

### 6. Multi-Step Plan
```
/planeeri: Loo 5-sammune plaan feature X implementeerimiseks, siis teosta.
```

### 7. Security Audit
```
Tee turvaaudit failile/moodulile: OWASP top 10, input validation, secrets exposure.
```

### 8. Performance Profile
```
Profilee funktsiooni F: mõõda aega, leia bottleneck, optimeeri.
```

### 9. Migration
```
Migreeri koodbaas versioonilt A versioonile B: sõltuvused, breaking changes, testid.
```

### 10. Review & Second Opinion
```
Kasuta GPT-5.2 second opinion'iks: loe kood, küsi arvamust, integreeri tagasiside.
```

---

## Repo-Specific Notes

**Current Repo:** `/home/a/.claude/clients/stellanium/honest_chain_pypi`
- **Type:** Python package (honest_chain)
- **Git:** Not initialized (no .git directory)
- **Docs:** `docs/` directory exists
- **Latest Work:** HONEST Chain L1 Specification v4.2.13 (GPT-5.2 APPROVED, score 97/100)

---

**END OF SELF-PROFILE AUDIT**
