# Trademark Policy

## Trademarks

The following are trademarks of **Stellanium Ltd**:

- **HONEST CHAIN™**
- **HONEST Verified™**

## Usage Guidelines

### Permitted Uses

You MAY:

1. **Reference** the trademarks when describing compatibility with HONEST CHAIN
   - Example: "Compatible with HONEST CHAIN"
   - Example: "Implements ProofBundle v0.1"

2. **Link** to official Stellanium resources when using the marks

3. **Use** the marks in factual, non-misleading statements about the software

### Restricted Uses

You MAY NOT:

1. **Claim endorsement** without explicit written permission from Stellanium Ltd

2. **Use "HONEST Verified"** badge or mark without passing the official conformance tests and receiving certification

3. **Register** any domain, trademark, or social media account using these marks

4. **Modify** the marks (e.g., "HONESTCHAIN", "Honest-Chain", "HonestVerified")

5. **Use** the marks in a way that implies official affiliation or sponsorship

### "HONEST Verified" Certification Program

The **HONEST Verified™** mark indicates that a product or service has:

1. Passed official conformance tests
2. Been reviewed by Stellanium Ltd
3. Agreed to the certification terms

To apply for certification, contact: admin@stellanium.io

## Contact

For trademark usage questions or permissions:

- Email: admin@stellanium.io
- Web: https://stellanium.io

---

© 2025 Stellanium Ltd. All rights reserved.
