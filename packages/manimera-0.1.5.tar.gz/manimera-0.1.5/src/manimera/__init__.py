print("Hello from manimera")
