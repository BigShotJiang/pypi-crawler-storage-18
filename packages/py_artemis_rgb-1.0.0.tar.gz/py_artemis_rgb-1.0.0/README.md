Artemis RGB python client
