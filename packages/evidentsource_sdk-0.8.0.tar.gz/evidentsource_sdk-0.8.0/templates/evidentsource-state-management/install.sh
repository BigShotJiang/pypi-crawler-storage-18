#!/bin/bash
# Install state change and state view components to EvidentSource server

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Configuration
EVIDENTSOURCE_URL="${EVIDENTSOURCE_URL:-http://localhost:3000}"
DATABASE="{{database_name}}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Automatically discover available components
discover_components() {
    local dir=$1
    local components=()

    if [ -d "$dir" ]; then
        for component_dir in "$dir"/*; do
            if [ -d "$component_dir" ] && [ -f "$component_dir/__init__.py" ]; then
                components+=("$(basename "$component_dir")")
            fi
        done
    fi

    echo "${components[@]}"
}

AVAILABLE_STATE_CHANGES=($(discover_components "state_changes"))
AVAILABLE_STATE_VIEWS=($(discover_components "state_views"))

# Functions
print_usage() {
    echo "Usage: $0 [OPTIONS] [COMPONENTS...]"
    echo ""
    echo "Options:"
    echo "  --list              List available components"
    echo "  --all               Install all components (requires confirmation)"
    echo "  --all-state-changes Install all state changes (requires confirmation)"
    echo "  --all-state-views   Install all state views (requires confirmation)"
    echo ""
    echo "Components:"
    echo "  state-change <name>  Install a specific state change"
    echo "  state-view <name>    Install a specific state view"
    echo ""
    echo "Examples:"
    echo "  $0 --list"
    echo "  $0 state-change {{first_state_change}}"
    echo "  $0 state-view {{first_state_view}}"
    echo "  $0 state-change {{first_state_change}} state-view {{first_state_view}}"
    echo ""
    echo "Environment:"
    echo "  EVIDENTSOURCE_URL  Server URL (default: http://localhost:3000)"
}

list_components() {
    echo "Available components:"
    echo ""
    echo "State Changes:"
    if [ ${#AVAILABLE_STATE_CHANGES[@]} -eq 0 ]; then
        echo "  (none)"
    else
        for sc in "${AVAILABLE_STATE_CHANGES[@]}"; do
            if [ -f "dist/${sc}.wasm" ]; then
                echo -e "  ${GREEN}${sc}${NC} (built)"
            else
                echo -e "  ${YELLOW}${sc}${NC} (not built)"
            fi
        done
    fi
    echo ""
    echo "State Views:"
    if [ ${#AVAILABLE_STATE_VIEWS[@]} -eq 0 ]; then
        echo "  (none)"
    else
        for sv in "${AVAILABLE_STATE_VIEWS[@]}"; do
            if [ -f "dist/${sv}.wasm" ]; then
                echo -e "  ${GREEN}${sv}${NC} (built)"
            else
                echo -e "  ${YELLOW}${sv}${NC} (not built)"
            fi
        done
    fi
    echo ""
    echo "Server: $EVIDENTSOURCE_URL"
    echo "Database: $DATABASE"
}

install_state_change() {
    local name=$1
    local wasm_file="dist/${name}.wasm"

    if [ ! -f "$wasm_file" ]; then
        echo -e "${RED}Error: WASM file not found: $wasm_file${NC}"
        echo "Run ./build_all.sh first"
        return 1
    fi

    echo "Installing state change: $name"

    local response
    response=$(curl -s -w "\n%{http_code}" \
        -X POST \
        -H "Content-Type: application/wasm" \
        --data-binary "@$wasm_file" \
        "${EVIDENTSOURCE_URL}/api/v1/catalog/${DATABASE}/state-changes/${name}")

    local http_code
    http_code=$(echo "$response" | tail -n1)
    local body
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo -e "${GREEN}Successfully installed state change: $name${NC}"
        echo "$body"
    else
        echo -e "${RED}Failed to install state change: $name (HTTP $http_code)${NC}"
        echo "$body"
        return 1
    fi
}

install_state_view() {
    local name=$1
    local wasm_file="dist/${name}.wasm"

    if [ ! -f "$wasm_file" ]; then
        echo -e "${RED}Error: WASM file not found: $wasm_file${NC}"
        echo "Run ./build_all.sh first"
        return 1
    fi

    echo "Installing state view: $name"

    local response
    response=$(curl -s -w "\n%{http_code}" \
        -X POST \
        -H "Content-Type: application/wasm" \
        --data-binary "@$wasm_file" \
        "${EVIDENTSOURCE_URL}/api/v1/catalog/${DATABASE}/state-views/${name}")

    local http_code
    http_code=$(echo "$response" | tail -n1)
    local body
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo -e "${GREEN}Successfully installed state view: $name${NC}"
        echo "$body"
    else
        echo -e "${RED}Failed to install state view: $name (HTTP $http_code)${NC}"
        echo "$body"
        return 1
    fi
}

confirm_bulk_install() {
    local type=$1
    local count=$2

    echo -e "${YELLOW}Warning: You are about to install $count $type(s).${NC}"
    echo "Each installation creates a new version."
    echo ""
    read -p "Are you sure you want to continue? (yes/no): " confirm

    if [ "$confirm" != "yes" ]; then
        echo "Aborted."
        exit 0
    fi
}

# Main logic
if [ $# -eq 0 ]; then
    print_usage
    exit 1
fi

case "$1" in
    --list)
        list_components
        exit 0
        ;;
    --all)
        total=$((${#AVAILABLE_STATE_CHANGES[@]} + ${#AVAILABLE_STATE_VIEWS[@]}))
        confirm_bulk_install "component" $total

        for sc in "${AVAILABLE_STATE_CHANGES[@]}"; do
            install_state_change "$sc" || true
        done
        for sv in "${AVAILABLE_STATE_VIEWS[@]}"; do
            install_state_view "$sv" || true
        done
        ;;
    --all-state-changes)
        confirm_bulk_install "state change" ${#AVAILABLE_STATE_CHANGES[@]}

        for sc in "${AVAILABLE_STATE_CHANGES[@]}"; do
            install_state_change "$sc" || true
        done
        ;;
    --all-state-views)
        confirm_bulk_install "state view" ${#AVAILABLE_STATE_VIEWS[@]}

        for sv in "${AVAILABLE_STATE_VIEWS[@]}"; do
            install_state_view "$sv" || true
        done
        ;;
    *)
        # Process component arguments
        while [ $# -gt 0 ]; do
            case "$1" in
                state-change)
                    if [ -z "$2" ]; then
                        echo -e "${RED}Error: state-change requires a name${NC}"
                        exit 1
                    fi
                    install_state_change "$2"
                    shift 2
                    ;;
                state-view)
                    if [ -z "$2" ]; then
                        echo -e "${RED}Error: state-view requires a name${NC}"
                        exit 1
                    fi
                    install_state_view "$2"
                    shift 2
                    ;;
                *)
                    echo -e "${RED}Unknown argument: $1${NC}"
                    print_usage
                    exit 1
                    ;;
            esac
        done
        ;;
esac
