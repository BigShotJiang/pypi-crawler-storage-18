from rich.console import Group
from rich.table import Table
from rich.text import Text
from rich.align import Align
import requests

from .constants import RELAY_URL


def show_leaderboard():
    """
    Render global leaderboard (cloud-only, no badges).
    Header is handled by __main__.py.
    """

    try:
        resp = requests.get(f"{RELAY_URL}/leaderboard/public", timeout=5)
        resp.raise_for_status()
        data = resp.json()

        players = data.get("leaderboard", data.get("players", []))
        players = sorted(players, key=lambda p: p.get("xp", 0), reverse=True)

        if not players:
            return Text(
                "Leaderboard not available yet.\nRun devopsmind submit and try again.",
                style="yellow",
            )

        table = Table(
            title="🌍 DevOpsMind Global Leaderboard",
            header_style="bold magenta",
        )

        table.add_column("#", style="dim", width=3)
        table.add_column("Gamer", style="cyan")
        table.add_column("Username", style="green")
        table.add_column("XP", justify="right")
        table.add_column("Rank", justify="center")

        for i, player in enumerate(players, 1):
            table.add_row(
                str(i),
                player.get("handle", "-"),
                player.get("username", "-"),
                str(player.get("xp", 0)),
                player.get("rank", "-"),
            )

        footer = Align.center(
            Text(f"Page 1 / 1 · {len(players)} players", style="dim")
        )

        return Group(table, footer)

    except Exception:
        return Text(
            "Leaderboard not available yet.\nRun devopsmind submit and try again.",
            style="yellow",
        )


# Backward compatibility
show_leaderboards = show_leaderboard
