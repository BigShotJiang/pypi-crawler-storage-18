from misc import *

x = [1,2,3]

# x = [1,2,3,56,12,412,31]
scaled  = normalization(x)
print(scaled)