# Link validation rules
