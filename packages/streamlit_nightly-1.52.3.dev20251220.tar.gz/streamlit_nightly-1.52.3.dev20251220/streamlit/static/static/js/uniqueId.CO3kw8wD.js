import{J as i}from"./index.BPAL5EyG.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
