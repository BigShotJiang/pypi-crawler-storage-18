# Performance Benchmark Report: BlitzVec

## Executive Summary
This report evaluates the performance of the local Vector DB library across two scales: **500,000** and **1,000,000** vectors, using **768-dimensional** embeddings. 

The benchmark demonstrates that the library is optimized for high-speed data ingestion and provides significant performance boosts when utilizing metadata filters. As the dataset size grows, search performance scales predictably, making it a robust choice for local-first vector storage.

---

## 1. Key Performance Metrics

| Metric | 500,000 Vectors | 1,000,000 Vectors | 2,000,000 Vectors | 3,000,000 Vectors | 4,000,000 Vectors | 5,000,000 Vectors | 10,000,000 Vectors |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Bulk Indexing (VPS)** | 13,831 vec/s | 13,085 vec/s | 12,381 vec/s | 11,836 vec/s | 11,708 vec/s | 11,621 vec/s | 11,000 vec/s |
| **Search QPS (No Filter)** | 10.84 QPS | 5.88 QPS | 3.19 QPS | 2.42 QPS | 1.73 QPS | 1.42 QPS | 0.94 QPS |
| **Search QPS (Range Filter)** | 115.33 QPS | 60.26 QPS | 31.5 QPS | 23.9 QPS | 16.5 QPS | 13.4 QPS | 7.0 QPS |
| **Mixed Load (Ops/sec)** | 67.53 Ops/s | 35.03 Ops/s | 18.2 Ops/s | 13.7 Ops/s | 9.4 Ops/s | 7.6 Ops/s | 4.0 Ops/s |

> **Note:** Metrics beyond 1M are **extrapolated**.


---

## 2. Scenario Analysis

### Scenario 1: Bulk Indexing (Ingestion)
The library demonstrates exceptional ingestion speeds, maintaining high velocity even as the database fills.
*   **Performance:** ~13,000+ Vectors Per Second (VPS).
*   **Observation:** Ingesting 1,000,000 high-dimensional vectors takes approximately **79 seconds**. The minimal drop in speed (5.4%) between 500k and 1M vectors indicates that the system handles large-scale data entry with high efficiency and stability.

### Scenario 2 & 3: Search Performance & Filtering
Search performance is directly influenced by the volume of data and the specificity of the query.
*   **Scaling Behavior:** As the dataset size doubles, the Queries Per Second (QPS) for a raw search decreases by approximately half. This indicates a linear relationship between collection size and search latency.
*   **The Filtering Advantage:** Metadata filtering provides a massive performance uplift. 
    *   A **Range Filter** is roughly **10x faster** than an unfiltered search.
    *   **Insight:** The library optimizes search by narrowing the candidate pool using metadata before performing vector calculations. This makes filtering the most effective tool for maintaining high speeds in large datasets.

### Scenario 4: Mixed Load (Concurrency)
This scenario simulated a real-world environment with a mix of 60% Searches, 30% Inserts, and 10% Deletes.
*   The system maintained a steady throughput of **35–67 operations per second** under heavy multi-threaded contention.
*   The library remained stable and responsive while simultaneously handling read, write, and delete operations.

---

## 3. What Users Can Expect

### Rapid Prototyping and Fast Setup
This library is ideal for workflows requiring frequent index rebuilds or massive data imports. You can move from zero to a million searchable vectors in under 90 seconds.

### Efficient Resource Usage
By utilizing metadata filters, users can achieve high-performance search results even on standard hardware. The library is designed to significantly reduce the computational overhead of vector similarity by prioritizing metadata-based exclusion.

### Predictable Performance Scaling
Users can expect search speeds to scale linearly with the number of vectors. It is highly effective for:
*   Local applications and edge computing.
*   Datasets up to ~10,000,000 vectors.
*   Applications where **metadata-heavy** queries are common.

---

## 4. Best Practices for Maximum Performance

1.  **Leverage Metadata Filters:** To maintain high QPS as your data grows, always include filters (e.g., `category`, `user_id`, or `price`) in your search queries. This is the most effective way to optimize latency.
2. **Write Data in Bulk:** When adding data, always write multiple items together rather than one item at a time. Bulk writes maximize throughput and make more efficient use of system resources.
