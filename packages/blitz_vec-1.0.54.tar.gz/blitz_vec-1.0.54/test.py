import unittest
import shutil
import tempfile
from bv_engine import VectorExp

class TestVectorExp(unittest.TestCase):
    
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        # Use a class name that matches the test file
        self.db = VectorExp(storage_base_path=self.test_dir, shards=2)

        self.vectors = [
            [1.0, 0.0], [0.9, 0.1], [0.0, 1.0], [0.5, 0.5], [0.1, 0.9]
        ]
        self.metas = [
            {"name": "A", "category": "news", "views": 100, "author": "Alice"},
            {"name": "B", "category": "news", "views": 200, "author": "Bob"},
            {"name": "C", "category": "sports", "views": 50, "author": "Alice"},
            {"name": "D", "category": "sports", "views": 150, "author": "Charlie"},
            {"name": "E", "category": "tech", "views": 300, "author": "Bob"}
        ]
        self.ids = self.db.store_embeddings_batch(self.vectors, self.metas)
        self.name_to_id = {m["name"]: uid for m, uid in zip(self.metas, self.ids)}

    def tearDown(self):
        # Explicitly close handles before removing the directory
        self.db.storage.close()
        self.db.meta_storage.close()
        shutil.rmtree(self.test_dir)

    def _get_names(self, query):
        dummy_vec = [0.0] * 2
        results = self.db.search(dummy_vec, metadata_filter=query, k=100)
        return {res[2]["name"] for res in results}

    def test_exact_match(self):
        names = self._get_names({"category": "news"})
        self.assertEqual(names, {"A", "B"})

    def test_implicit_and(self):
        names = self._get_names({"category": "news", "author": "Bob"})
        self.assertEqual(names, {"B"})

    def test_numeric_range_gt(self):
        names = self._get_names({"views": {"$gt": 100}})
        self.assertEqual(names, {"B", "D", "E"})

    def test_numeric_range_lte(self):
        names = self._get_names({"views": {"$lte": 100}})
        self.assertEqual(names, {"A", "C"})

    def test_in_operator(self):
        names = self._get_names({"author": {"$in": ["Alice", "Charlie"]}})
        self.assertEqual(names, {"A", "C", "D"})

    def test_operator_or(self):
        query = {"$or": [{"category": "tech"}, {"views": {"$lt": 60}}]}
        names = self._get_names(query)
        self.assertEqual(names, {"E", "C"})

    def test_operator_and_explicit(self):
        query = {"$and": [{"views": {"$gt": 100}}, {"author": "Bob"}]}
        names = self._get_names(query)
        self.assertEqual(names, {"B", "E"})

    def test_nested_logic(self):
        query = {
            "category": "news",
            "$or": [{"views": {"$lt": 150}}, {"author": "Bob"}]
        }
        names = self._get_names(query)
        self.assertEqual(names, {"A", "B"})

    def test_nested_complex_or(self):
        query = {
            "$or": [
                {"$and": [{"category": "sports"}, {"views": {"$gt": 100}}]},
                {"$and": [{"category": "news"}, {"views": {"$lt": 150}}]}
            ]
        }
        names = self._get_names(query)
        self.assertEqual(names, {"D", "A"})

    def test_ne_operator(self):
        names = self._get_names({"author": {"$ne": "Alice"}})
        self.assertEqual(names, {"B", "D", "E"})

    def test_search_integration(self):
        q_vec = [1.0, 0.0]
        results = self.db.search(q_vec, metadata_filter={"category": "news"}, k=2)
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0][2]["name"], "A")
        self.assertAlmostEqual(results[0][1], 1.0, places=4)
        self.assertEqual(results[1][2]["name"], "B")

    def test_delete_logic(self):
        count = self.db.delete({"views": {"$lt": 100}})
        self.assertEqual(count, 1)
        names_sports = self._get_names({"category": "sports"})
        self.assertEqual(names_sports, {"D"})
        names_empty = self._get_names({"name": "C"})
        self.assertEqual(names_empty, set())

    def test_count(self):
        self.assertEqual(self.db.count(), 5)
        self.db.delete({"name": "A"})
        self.assertEqual(self.db.count(), 4)

if __name__ == "__main__":
    unittest.main()