#![allow(non_local_definitions)]
use pyo3::prelude::*;
use pyo3::types::{PyList, PyBytes, PyNone, PyTuple, PyAny};
use numpy::{PyReadonlyArray1, PyReadonlyArray2, PyArray1};
use lmdb::{Environment, Transaction, WriteFlags, Database, Cursor, EnvironmentFlags, Error as LmdbError, RwCursor};
use rayon::prelude::*;
use std::sync::{Arc};
use std::path::Path;
use std::fs;
use std::collections::{HashSet};
use byteorder::{ByteOrder, LittleEndian, BigEndian};

const MDB_NOTLS: EnvironmentFlags = EnvironmentFlags::NO_TLS;
const MDB_MAPASYNC: EnvironmentFlags = EnvironmentFlags::MAP_ASYNC;
const MDB_SET_RANGE: u32 = 17;
const MDB_NEXT: u32 = 8;

// Compact page storage: store vectors in fixed-size pages for efficient scanning
const VECTORS_PER_PAGE: usize = 256;
const DELETED_MARKER: i64 = i64::MIN;

#[inline(always)]
fn simd_dot_product(a: &[f32], b: &[f32]) -> f32 {
    // Simple but efficient - compiler will auto-vectorize this on modern CPUs
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}

#[derive(Debug)]
enum StorageError { 
    Lmdb(LmdbError), 
    Io(std::io::Error), 
    Py(PyErr) 
}

impl From<LmdbError> for StorageError { 
    fn from(err: LmdbError) -> Self { StorageError::Lmdb(err) } 
}
impl From<std::io::Error> for StorageError { 
    fn from(err: std::io::Error) -> Self { StorageError::Io(err) } 
}
impl From<PyErr> for StorageError { 
    fn from(err: PyErr) -> Self { StorageError::Py(err) } 
}
impl From<StorageError> for PyErr {
    fn from(err: StorageError) -> PyErr {
        match err {
            StorageError::Lmdb(e) => pyo3::exceptions::PyIOError::new_err(format!("LMDB: {}", e)),
            StorageError::Io(e) => pyo3::exceptions::PyIOError::new_err(format!("IO: {}", e)),
            StorageError::Py(e) => e,
        }
    }
}

#[derive(Debug)]
enum FilterNode { 
    Exact(String), 
    Range(String, String), 
    And(Vec<FilterNode>), 
    Or(Vec<FilterNode>), 
    Not(Box<FilterNode>) 
}

impl FilterNode {
    fn from_py(obj: &PyAny) -> PyResult<Self> {
        let tuple = obj.downcast::<PyTuple>()?;
        let op_code: u8 = tuple.get_item(0)?.extract()?;
        match op_code {
            0 => Ok(FilterNode::Exact(tuple.get_item(1)?.extract()?)),
            1 => Ok(FilterNode::Range(tuple.get_item(1)?.extract()?, tuple.get_item(2)?.extract()?)),
            2 | 3 => {
                let list: &PyList = tuple.get_item(1)?.downcast()?;
                let nodes = list.iter().map(FilterNode::from_py).collect::<PyResult<Vec<_>>>()?;
                if op_code == 2 { Ok(FilterNode::And(nodes)) } else { Ok(FilterNode::Or(nodes)) }
            },
            4 => Ok(FilterNode::Not(Box::new(FilterNode::from_py(tuple.get_item(1)?)?))),
            _ => Err(pyo3::exceptions::PyValueError::new_err("Invalid OpCode")),
        }
    }
}

#[pyclass(module = "blitz_vec")]
struct BlitzIterator {
    ids: HashSet<i64>,
    count: usize,
}

#[pymethods]
impl BlitzIterator {
    fn __len__(&self) -> usize {
        self.count
    }
    
    fn to_list(&self) -> Vec<i64> {
        self.ids.iter().cloned().collect()
    }
}

#[pyclass(module = "blitz_vec")]
struct BlitzVec {
    shards: Vec<Arc<Environment>>,
    dbs: Vec<Database>,
    num_shards: usize,
}

impl BlitzVec {
    fn init(base_path: &str, num_shards: usize, map_size: usize) -> Result<(Vec<Arc<Environment>>, Vec<Database>), StorageError> {
        let mut shards = Vec::with_capacity(num_shards);
        let mut dbs = Vec::with_capacity(num_shards);
        
        for i in 0..num_shards {
            let path_str = format!("{}/shard_{}", base_path, i);
            fs::create_dir_all(&path_str)?;
            let env = Environment::new()
                .set_map_size(map_size)
                .set_max_dbs(1)
                .set_max_readers(2048)
                .set_flags(MDB_MAPASYNC | MDB_NOTLS)
                .open(Path::new(&path_str))?;
            let db = env.open_db(None)?;
            shards.push(Arc::new(env));
            dbs.push(db);
        }
        Ok((shards, dbs))
    }

    #[inline]
    fn shard_for_id(id: i64, num_shards: usize) -> usize {
        (id.unsigned_abs() as usize) % num_shards
    }

    #[inline]
    fn make_vector_page_key(page_id: u32) -> Vec<u8> {
        let mut k = Vec::with_capacity(5);
        k.push(b'p');
        k.extend_from_slice(&page_id.to_be_bytes());
        k
    }

    fn eval_node(&self, node: &FilterNode) -> (HashSet<i64>, bool) {
        match node {
            FilterNode::Exact(key) => {
                let digest = md5::compute(key.as_bytes());
                let hash_int = u128::from_be_bytes(digest.0);
                let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
                
                let env = &self.shards[shard_idx];
                let db = self.dbs[shard_idx];
                let txn = env.begin_ro_txn().expect("RO txn");
                let cursor = txn.open_ro_cursor(db).expect("Cursor"); 
                
                let mut ids = HashSet::new();
                let key_bytes = key.as_bytes();
                
                if let Ok((Some(mut k), _)) = cursor.get(Some(key_bytes), None, MDB_SET_RANGE) {
                    loop {
                        if k.len() < 8 || !k.starts_with(key_bytes) || k.get(key.len()) != Some(&b'|') { 
                            break; 
                        }
                        ids.insert(LittleEndian::read_i64(&k[k.len()-8..]));
                        
                        if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { 
                            k = next_k; 
                        } else { 
                            break; 
                        }
                    }
                }
                (ids, false)
            },
            FilterNode::Range(start, end) => {
                let sep_idx = start.find(':').map(|i| i + 1).unwrap_or(0);
                let field_prefix = &start[0..sep_idx];
                let start_bytes = start.as_bytes();
                let end_bytes = end.as_bytes();
                
                let shard_results: Vec<HashSet<i64>> = (0..self.num_shards)
                    .into_par_iter()
                    .map(|shard_idx| {
                        let mut found = HashSet::new();
                        let env = &self.shards[shard_idx];
                        let db = self.dbs[shard_idx];
                        let txn = env.begin_ro_txn().expect("RO txn");
                        let cursor = txn.open_ro_cursor(db).expect("Cursor");
                        
                        if let Ok((Some(mut k), _)) = cursor.get(Some(start_bytes), None, MDB_SET_RANGE) {
                            loop {
                                if k >= end_bytes || !k.starts_with(field_prefix.as_bytes()) { 
                                    break; 
                                }
                                if k.len() > 8 { 
                                    found.insert(LittleEndian::read_i64(&k[k.len()-8..])); 
                                }
                                
                                if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { 
                                    k = next_k; 
                                } else { 
                                    break; 
                                }
                            }
                        }
                        found
                    })
                    .collect();
                
                (shard_results.into_iter().flatten().collect(), false)
            },
            FilterNode::And(nodes) => {
                if nodes.is_empty() { 
                    return (HashSet::new(), false); 
                }
                
                let results: Vec<(HashSet<i64>, bool)> = nodes
                    .par_iter()
                    .map(|n| self.eval_node(n))
                    .collect();
                
                let (mut base_set, mut base_inv) = results[0].clone();
                
                for (curr_set, curr_inv) in &results[1..] {
                    if !base_inv && !*curr_inv { 
                        base_set.retain(|id| curr_set.contains(id)); 
                    } else if !base_inv && *curr_inv { 
                        base_set.retain(|id| !curr_set.contains(id)); 
                    } else if base_inv && !*curr_inv {
                        let mut new_base = curr_set.clone();
                        new_base.retain(|id| !base_set.contains(id));
                        base_set = new_base;
                        base_inv = false;
                    } else { 
                        base_set.extend(curr_set.iter()); 
                    }
                    
                    if !base_inv && base_set.is_empty() { 
                        break; 
                    }
                }
                (base_set, base_inv)
            },
            FilterNode::Or(nodes) => {
                if nodes.is_empty() { 
                    return (HashSet::new(), false); 
                }
                
                let results: Vec<(HashSet<i64>, bool)> = nodes
                    .par_iter()
                    .map(|n| self.eval_node(n))
                    .collect();
                
                let mut base_set = HashSet::new();
                for (s, inv) in results { 
                    if inv { 
                        return (HashSet::new(), true); 
                    } else { 
                        base_set.extend(s); 
                    }
                }
                (base_set, false)
            },
            FilterNode::Not(node) => { 
                let (s, inv) = self.eval_node(node); 
                (s, !inv) 
            }
        }
    }
}

#[pymethods]
impl BlitzVec {
    #[new] 
    #[pyo3(signature = (base_path, num_shards=5, map_size=200_000_000_000))]
    fn new(base_path: String, num_shards: usize, map_size: usize) -> PyResult<Self> {
        let (shards, dbs) = BlitzVec::init(&base_path, num_shards, map_size)?;
        Ok(BlitzVec { shards, dbs, num_shards })
    }

    fn close(&self) -> PyResult<()> { 
        Ok(()) 
    }

    fn get_ids_from_filter(&self, py: Python<'_>, filter_tree: PyObject) -> PyResult<Option<BlitzIterator>> {
        let node = FilterNode::from_py(filter_tree.as_ref(py))?;
        let (ids, inv) = py.allow_threads(|| self.eval_node(&node));
        
        if inv { 
            Ok(None) 
        } else { 
            let count = ids.len(); 
            Ok(Some(BlitzIterator { ids, count })) 
        }
    }

    #[pyo3(signature = (query_vector, filter_obj=None, k=10))]
    fn search_flat<'py>(&self, py: Python<'py>, query_vector: PyReadonlyArray1<'py, f32>, filter_obj: Option<&BlitzIterator>, k: usize) -> PyResult<Vec<(f32, i64)>> {
        let query_slice = query_vector.as_slice()?;
        let dim = query_slice.len();
        let row_size = 8 + dim * 4;
        let allow_set = filter_obj.map(|iter| &iter.ids);
        
        // Pre-allocate result capacity to reduce allocations
        let estimated_results_per_shard = if allow_set.is_some() { 
            1000 
        } else { 
            10000 
        };
        
        let scores: Vec<(f32, i64)> = py.allow_threads(|| {
            self.shards
                .par_iter()
                .zip(&self.dbs)
                .flat_map(|(env, db)| {
                    let txn = match env.begin_ro_txn() {
                        Ok(t) => t,
                        Err(_) => return Vec::new()
                    };
                    
                    let mut cursor = match txn.open_ro_cursor(*db) {
                        Ok(c) => c,
                        Err(_) => return Vec::new()
                    };
                    
                    let mut results = Vec::with_capacity(estimated_results_per_shard);
                    
                    // Scan vector pages with fast path for no-filter case
                    let start_key = b"p";
                    if let Ok((Some(k), v)) = cursor.get(Some(start_key), None, MDB_SET_RANGE) {
                        let mut curr_k = k;
                        let mut curr_v = v;
                        
                        // Fast path: no filter - skip ID checks
                        if allow_set.is_none() {
                            loop {
                                if !curr_k.starts_with(b"p") { 
                                    break; 
                                }
                                
                                let mut pos = 0;
                                while pos + row_size <= curr_v.len() {
                                    let id = LittleEndian::read_i64(&curr_v[pos..pos+8]);
                                    
                                    if id != DELETED_MARKER {
                                        let vec_ptr = curr_v[pos+8..].as_ptr() as *const f32;
                                        let vec_floats = unsafe { 
                                            std::slice::from_raw_parts(vec_ptr, dim) 
                                        };
                                        results.push((simd_dot_product(query_slice, vec_floats), id));
                                    }
                                    pos += row_size;
                                }
                                
                                match cursor.get(None, None, MDB_NEXT) {
                                    Ok((Some(next_k), next_v)) => { 
                                        curr_k = next_k; 
                                        curr_v = next_v; 
                                    }
                                    _ => break
                                }
                            }
                        } else {
                            // Filtered path
                            let filter_set = allow_set.unwrap();
                            loop {
                                if !curr_k.starts_with(b"p") { 
                                    break; 
                                }
                                
                                let mut pos = 0;
                                while pos + row_size <= curr_v.len() {
                                    let id = LittleEndian::read_i64(&curr_v[pos..pos+8]);
                                    
                                    if id != DELETED_MARKER && filter_set.contains(&id) {
                                        let vec_ptr = curr_v[pos+8..].as_ptr() as *const f32;
                                        let vec_floats = unsafe { 
                                            std::slice::from_raw_parts(vec_ptr, dim) 
                                        };
                                        results.push((simd_dot_product(query_slice, vec_floats), id));
                                    }
                                    pos += row_size;
                                }
                                
                                match cursor.get(None, None, MDB_NEXT) {
                                    Ok((Some(next_k), next_v)) => { 
                                        curr_k = next_k; 
                                        curr_v = next_v; 
                                    }
                                    _ => break
                                }
                            }
                        }
                    }
                    results
                })
                .collect()
        });
        
        let mut final_results = scores;
        
        // Use partial sort for better performance when k << total results
        if final_results.len() > k * 2 {
            final_results.select_nth_unstable_by(k, |a, b| b.0.partial_cmp(&a.0).unwrap());
            final_results.truncate(k);
            final_results.sort_unstable_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
        } else {
            final_results.sort_unstable_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
            final_results.truncate(k);
        }
        
        Ok(final_results)
    }

    fn store_flat_vectors<'py>(&self, py: Python<'py>, data: PyReadonlyArray2<'py, f32>, identifiers: Vec<i64>) -> PyResult<()> {
        let vectors = data.as_array();
        let dim = vectors.shape()[1];
        let row_size = 8 + dim * 4;
        
        // Group by shard and pre-serialize rows
        let mut shard_data: Vec<Vec<Vec<u8>>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for (i, &id) in identifiers.iter().enumerate() {
            let shard_idx = BlitzVec::shard_for_id(id, self.num_shards);
            let mut row_data = Vec::with_capacity(row_size);
            row_data.extend_from_slice(&id.to_le_bytes());
            
            let slice = unsafe { 
                std::slice::from_raw_parts(
                    vectors.row(i).as_ptr() as *const u8, 
                    dim * 4
                ) 
            };
            row_data.extend_from_slice(slice);
            shard_data[shard_idx].push(row_data);
        }
        
        py.allow_threads(|| {
            shard_data
                .into_par_iter()
                .enumerate()
                .for_each(|(shard_idx, rows)| {
                    if rows.is_empty() { 
                        return; 
                    }
                    
                    let env = &self.shards[shard_idx];
                    let db = self.dbs[shard_idx];
                    let mut txn = match env.begin_rw_txn() {
                        Ok(t) => t,
                        Err(_) => return
                    };
                    
                    // Get current page count
                    let mut page_count = 0u32;
                    let mut last_page_data = Vec::new();
                    
                    {
                        let cursor = match txn.open_ro_cursor(db) {
                            Ok(c) => c,
                            Err(_) => return
                        };
                        
                        let search_key = b"p\xff\xff\xff\xff";
                        
                        if let Ok((Some(k), v)) = cursor.get(Some(search_key), None, MDB_SET_RANGE) {
                            if k.starts_with(b"p") && k.len() == 5 {
                                page_count = BigEndian::read_u32(&k[1..5]);
                                
                                // Only fetch last page if it's not full
                                if v.len() < VECTORS_PER_PAGE * row_size {
                                    last_page_data = v.to_vec();
                                } else {
                                    page_count += 1;
                                }
                            }
                        }
                    }
                    
                    let mut page_buffer = last_page_data;
                    
                    for row in rows {
                        // If page would overflow, write it and start new one
                        if !page_buffer.is_empty() && page_buffer.len() + row.len() > VECTORS_PER_PAGE * row_size {
                            let key = BlitzVec::make_vector_page_key(page_count);
                            if txn.put(db, &key, &page_buffer, WriteFlags::empty()).is_err() {
                                return;
                            }
                            page_buffer.clear();
                            page_count += 1;
                        }
                        
                        page_buffer.extend_from_slice(&row);
                    }
                    
                    // Write final page
                    if !page_buffer.is_empty() {
                        let key = BlitzVec::make_vector_page_key(page_count);
                        if txn.put(db, &key, &page_buffer, WriteFlags::empty()).is_err() {
                            return;
                        }
                    }
                    
                    let _ = txn.commit();
                });
            Ok(())
        })
    }
    
    fn delete_flat_vectors<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<()> {
        let delete_set: HashSet<i64> = identifiers.into_iter().collect();
        
        py.allow_threads(|| {
            (0..self.num_shards)
                .into_par_iter()
                .for_each(|shard_idx| {
                    let env = &self.shards[shard_idx];
                    let db = self.dbs[shard_idx];
                    let mut txn = env.begin_rw_txn().unwrap();
                    
                    // Scan pages and mark deletions
                    let mut pages_to_update = Vec::new();
                    {
                        let cursor = txn.open_ro_cursor(db).unwrap();
                        let start_key = b"p";
                        
                        if let Ok((Some(k), v)) = cursor.get(Some(start_key), None, MDB_SET_RANGE) {
                            let mut curr_k = k;
                            let mut curr_v = v;
                            
                            loop {
                                if !curr_k.starts_with(b"p") { 
                                    break; 
                                }
                                
                                let mut page_data = curr_v.to_vec();
                                let mut modified = false;
                                let row_size = if page_data.len() >= 8 { 
                                    let first_id_pos = 0;
                                    if page_data.len() > first_id_pos + 8 {
                                        let remaining = page_data.len() - 8;
                                        8 + (remaining / VECTORS_PER_PAGE.max(1))
                                    } else {
                                        page_data.len()
                                    }
                                } else {
                                    page_data.len()
                                };
                                
                                let mut pos = 0;
                                while pos + 8 <= page_data.len() && pos + row_size <= page_data.len() {
                                    let id = LittleEndian::read_i64(&page_data[pos..pos+8]);
                                    if delete_set.contains(&id) && id != DELETED_MARKER {
                                        LittleEndian::write_i64(&mut page_data[pos..pos+8], DELETED_MARKER);
                                        modified = true;
                                    }
                                    pos += row_size;
                                }
                                
                                if modified {
                                    pages_to_update.push((curr_k.to_vec(), page_data));
                                }
                                
                                match cursor.get(None, None, MDB_NEXT) {
                                    Ok((Some(next_k), next_v)) => { 
                                        curr_k = next_k; 
                                        curr_v = next_v; 
                                    }
                                    _ => break
                                }
                            }
                        }
                    }
                    
                    // Apply updates
                    for (key, data) in pages_to_update {
                        txn.put(db, &key, &data, WriteFlags::empty()).unwrap();
                    }
                    
                    txn.commit().unwrap();
                });
            Ok(())
        })
    }

    fn batch_index_insert(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        if entries.is_empty() {
            return Ok(());
        }
        
        let mut buckets: Vec<Vec<(Vec<u8>, Vec<u8>)>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push((key, Vec::new()));
        }
        
        py.allow_threads(|| {
            buckets
                .into_par_iter()
                .enumerate()
                .for_each(|(shard_idx, mut batch)| {
                    if batch.is_empty() { 
                        return; 
                    }
                    batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));
                    
                    let env = &self.shards[shard_idx];
                    let mut txn = match env.begin_rw_txn() {
                        Ok(t) => t,
                        Err(_) => return
                    };
                    
                    // Batch puts with NO_OVERWRITE flag for speed
                    for (k, v) in batch { 
                        let _ = txn.put(self.dbs[shard_idx], &k, &v, WriteFlags::NO_OVERWRITE);
                    }
                    let _ = txn.commit();
                });
            Ok(())
        })
    }

    fn batch_index_delete(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        if entries.is_empty() {
            return Ok(());
        }
        
        let mut buckets: Vec<Vec<Vec<u8>>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push(key);
        }
        
        py.allow_threads(|| {
            buckets
                .into_par_iter()
                .enumerate()
                .for_each(|(shard_idx, mut keys)| {
                    if keys.is_empty() { 
                        return; 
                    }
                    keys.sort_unstable();
                    
                    let env = &self.shards[shard_idx];
                    let mut txn = match env.begin_rw_txn() {
                        Ok(t) => t,
                        Err(_) => return
                    };
                    
                    for k in keys { 
                        let _ = txn.del(self.dbs[shard_idx], &k, None); 
                    }
                    let _ = txn.commit();
                });
            Ok(())
        })
    }

    fn store_data<'py>(&self, py: Python<'py>, data: Vec<PyObject>, identifiers: Vec<i64>) -> PyResult<()> {
        if data.len() != identifiers.len() { 
            return Err(pyo3::exceptions::PyValueError::new_err("Length mismatch")); 
        }
        
        if data.is_empty() {
            return Ok(());
        }
        
        let pickle = PyModule::import(py, "pickle")?;
        let dumps = pickle.getattr("dumps")?;
        
        let mut buckets: Vec<Vec<([u8; 8], Vec<u8>)>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for (i, &id) in identifiers.iter().enumerate() {
            let shard_idx = BlitzVec::shard_for_id(id, self.num_shards);
            let bytes_obj = dumps.call1((&data[i],))?;
            let val_bytes = bytes_obj.extract::<&PyBytes>()?.as_bytes().to_vec();
            buckets[shard_idx].push((id.to_le_bytes(), val_bytes));
        }
        
        py.allow_threads(|| {
            buckets
                .into_par_iter()
                .enumerate()
                .for_each(|(shard_idx, mut batch)| {
                    if batch.is_empty() { 
                        return; 
                    }
                    batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));
                    
                    let env = &self.shards[shard_idx];
                    let mut txn = match env.begin_rw_txn() {
                        Ok(t) => t,
                        Err(_) => return
                    };
                    
                    for (key_bytes, val_bytes) in batch { 
                        let _ = txn.put(self.dbs[shard_idx], &key_bytes, &val_bytes, WriteFlags::empty());
                    }
                    let _ = txn.commit();
                });
            Ok(())
        })
    }

    fn get_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<&'py PyList> {
        let mut buckets: Vec<Vec<(usize, [u8; 8])>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for (i, &id) in identifiers.iter().enumerate() {
            buckets[BlitzVec::shard_for_id(id, self.num_shards)].push((i, id.to_le_bytes()));
        }
        
        let mut results: Vec<Option<Vec<u8>>> = vec![None; identifiers.len()];
        let result_ptr = results.as_mut_ptr() as usize;
        
        py.allow_threads(|| {
            buckets
                .into_par_iter()
                .enumerate()
                .for_each(move |(shard_idx, reqs)| {
                    if reqs.is_empty() { 
                        return; 
                    }
                    
                    let env = &self.shards[shard_idx]; 
                    let db = self.dbs[shard_idx];
                    let txn = env.begin_ro_txn().unwrap();
                    let res_ptr = result_ptr as *mut Option<Vec<u8>>;
                    
                    for (orig_idx, key_bytes) in reqs {
                        if let Ok(bytes) = txn.get(db, &key_bytes) {
                            unsafe { 
                                std::ptr::write(res_ptr.add(orig_idx), Some(bytes.to_vec())); 
                            }
                        }
                    }
                });
        });
        
        let pickle = PyModule::import(py, "pickle")?;
        let loads = pickle.getattr("loads")?;
        let py_list = PyList::empty(py);
        
        for opt in results {
            let obj = if let Some(bytes) = opt { 
                loads.call1((PyBytes::new(py, &bytes),))? 
            } else { 
                PyNone::get(py).into() 
            };
            py_list.append(obj)?;
        }
        Ok(py_list)
    }

    fn delete_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<()> {
        if identifiers.is_empty() {
            return Ok(());
        }
        
        let mut buckets: Vec<Vec<[u8; 8]>> = (0..self.num_shards)
            .map(|_| Vec::new())
            .collect();
        
        for &id in identifiers.iter() {
            buckets[BlitzVec::shard_for_id(id, self.num_shards)].push(id.to_le_bytes());
        }
        
        py.allow_threads(|| {
            buckets
                .into_par_iter()
                .enumerate()
                .for_each(|(shard_idx, mut keys)| {
                    if keys.is_empty() { 
                        return; 
                    }
                    keys.sort_unstable();
                    
                    let env = &self.shards[shard_idx];
                    let mut txn = match env.begin_rw_txn() {
                        Ok(t) => t,
                        Err(_) => return
                    };
                    
                    for key in keys { 
                        let _ = txn.del(self.dbs[shard_idx], &key, None); 
                    }
                    let _ = txn.commit();
                });
            Ok(())
        })
    }

    fn get_data_count(&self) -> PyResult<usize> {
        let total: usize = self.shards
            .par_iter()
            .map(|env| env.stat().unwrap().entries())
            .sum();
        Ok(total)
    }
    
    // Compact deleted entries from vector pages
    fn compact_vectors<'py>(&self, py: Python<'py>, dim: usize) -> PyResult<usize> {
        let row_size = 8 + dim * 4;
        
        let reclaimed: usize = py.allow_threads(|| {
            (0..self.num_shards)
                .into_par_iter()
                .map(|shard_idx| {
                    let env = &self.shards[shard_idx];
                    let db = self.dbs[shard_idx];
                    let mut txn = env.begin_rw_txn().unwrap();
                    let mut reclaimed_count = 0;
                    
                    let mut pages_to_rewrite = Vec::new();
                    {
                        let cursor = txn.open_ro_cursor(db).unwrap();
                        let start_key = b"p";
                        
                        if let Ok((Some(k), v)) = cursor.get(Some(start_key), None, MDB_SET_RANGE) {
                            let mut curr_k = k;
                            let mut curr_v = v;
                            
                            loop {
                                if !curr_k.starts_with(b"p") { 
                                    break; 
                                }
                                
                                let mut new_page = Vec::new();
                                let mut pos = 0;
                                let mut has_deleted = false;
                                
                                while pos + row_size <= curr_v.len() {
                                    let id = LittleEndian::read_i64(&curr_v[pos..pos+8]);
                                    if id == DELETED_MARKER {
                                        has_deleted = true;
                                        reclaimed_count += 1;
                                    } else {
                                        new_page.extend_from_slice(&curr_v[pos..pos+row_size]);
                                    }
                                    pos += row_size;
                                }
                                
                                if has_deleted {
                                    pages_to_rewrite.push((curr_k.to_vec(), new_page));
                                }
                                
                                match cursor.get(None, None, MDB_NEXT) {
                                    Ok((Some(next_k), next_v)) => { 
                                        curr_k = next_k; 
                                        curr_v = next_v; 
                                    }
                                    _ => break
                                }
                            }
                        }
                    }
                    
                    // Rewrite compacted pages
                    for (key, data) in pages_to_rewrite {
                        if data.is_empty() {
                            let _ = txn.del(db, &key, None);
                        } else {
                            txn.put(db, &key, &data, WriteFlags::empty()).unwrap();
                        }
                    }
                    
                    txn.commit().unwrap();
                    reclaimed_count
                })
                .sum()
        });
        
        Ok(reclaimed)
    }
}

#[pymodule]
fn blitz_vec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<BlitzVec>()?;
    m.add_class::<BlitzIterator>()?;
    Ok(())
}