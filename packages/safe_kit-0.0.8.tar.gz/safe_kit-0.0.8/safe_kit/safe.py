from typing import cast

from hexbytes import HexBytes

from safe_kit.adapter import EthAdapter
from safe_kit.contract_types import (
    SafeApproveHashParams,
    SafeExecTransactionParams,
    SafeGetTransactionHashParams,
    SafeIsOwnerParams,
    SafeRequiredTxGasParams,
)
from safe_kit.errors import handle_contract_error
from safe_kit.managers import (
    GuardManagerMixin,
    ModuleManagerMixin,
    OwnerManagerMixin,
    TokenManagerMixin,
)
from safe_kit.types import SafeTransaction, SafeTransactionData


class Safe(
    OwnerManagerMixin,
    ModuleManagerMixin,
    TokenManagerMixin,
    GuardManagerMixin,
):
    """
    The main class for interacting with a Safe.

    This class provides a comprehensive interface for Safe operations including:
    - Basic Safe info (address, version, balance, nonce, threshold, owners)
    - Transaction creation, signing, and execution
    - Owner management (add, remove, swap owners, change threshold)
    - Module management (enable, disable, list modules)
    - Token transfers (ERC20, ERC721, native ETH)
    - Guard and fallback handler management
    """

    def __init__(
        self, eth_adapter: EthAdapter, safe_address: str, chain_id: int | None = None
    ):
        self.eth_adapter = eth_adapter
        self.safe_address = self.eth_adapter.to_checksum_address(safe_address)

        if not self.eth_adapter.is_contract(self.safe_address):
            raise ValueError(f"Address {self.safe_address} is not a contract")

        self.contract = self.eth_adapter.get_safe_contract(self.safe_address)
        self.chain_id = chain_id

        if self.chain_id is not None:
            adapter_chain_id = self.eth_adapter.get_chain_id()
            if adapter_chain_id != self.chain_id:
                raise ValueError(
                    f"Adapter chain ID ({adapter_chain_id}) does not match "
                    f"Safe chain ID ({self.chain_id})"
                )

    @classmethod
    def create(
        cls, eth_adapter: EthAdapter, safe_address: str, chain_id: int | None = None
    ) -> "Safe":
        """
        Factory method to create a Safe instance.
        """
        return cls(eth_adapter, safe_address, chain_id)

    def get_address(self) -> str:
        """
        Returns the address of the Safe.
        """
        return self.safe_address

    def get_version(self) -> str:
        """
        Returns the version of the Safe contract.
        """
        return cast(str, self.contract.functions.VERSION().call())

    def get_balance(self) -> int:
        """
        Returns the ETH balance of the Safe.
        """
        return self.eth_adapter.get_balance(self.safe_address)

    def get_nonce(self) -> int:
        """
        Returns the current nonce of the Safe.
        """
        return cast(int, self.contract.functions.nonce().call())

    def get_threshold(self) -> int:
        """
        Returns the threshold of the Safe.
        """
        return cast(int, self.contract.functions.getThreshold().call())

    def get_owners(self) -> list[str]:
        """
        Returns the owners of the Safe.
        """
        return cast(list[str], self.contract.functions.getOwners().call())

    def is_owner(self, address: str) -> bool:
        """
        Checks if an address is an owner of the Safe.
        """
        params: SafeIsOwnerParams = {"owner": address}
        return cast(bool, self.contract.functions.isOwner(**params).call())

    def create_transaction(
        self, transaction_data: SafeTransactionData
    ) -> SafeTransaction:
        """
        Creates a Safe transaction ready to be signed.
        """
        if transaction_data.nonce is None:
            transaction_data.nonce = self.get_nonce()

        return SafeTransaction(data=transaction_data)

    def sign_transaction(
        self, safe_transaction: SafeTransaction, method: str = "eth_sign_typed_data"
    ) -> SafeTransaction:
        """
        Signs a Safe transaction with the current signer.
        Supported methods: "eth_sign_typed_data" (EIP-712), "eth_sign" (legacy).
        """
        signer_address = self.eth_adapter.get_signer_address()
        if not signer_address:
            raise ValueError("No signer configured in the adapter")

        chain_id = self.eth_adapter.get_chain_id()

        if method == "eth_sign_typed_data":
            eip712_data = safe_transaction.data.get_eip712_data(
                chain_id, self.safe_address
            )
            signature = self.eth_adapter.sign_typed_data(eip712_data)
        elif method == "eth_sign":
            tx_hash = self.get_transaction_hash(safe_transaction)
            signature = self.eth_adapter.sign_message(tx_hash)
            # Adjust v for eth_sign: v += 4
            # Signature is r(32) + s(32) + v(1)
            # We need to parse it, adjust v, and reconstruct
            sig_bytes = HexBytes(signature)
            r = sig_bytes[:32]
            s = sig_bytes[32:64]
            v = sig_bytes[64]
            v += 4
            signature = (r + s + bytes([v])).hex()
        else:
            raise ValueError(f"Unsupported signing method: {method}")

        safe_transaction.add_signature(signer_address, signature)
        return safe_transaction

    def get_transaction_hash(self, safe_transaction: SafeTransaction) -> str:
        """
        Returns the hash of the Safe transaction.
        """
        params: SafeGetTransactionHashParams = {
            "to": safe_transaction.data.to,
            "value": safe_transaction.data.value,
            "data": HexBytes(safe_transaction.data.data),
            "operation": safe_transaction.data.operation,
            "safeTxGas": safe_transaction.data.safe_tx_gas,
            "baseGas": safe_transaction.data.base_gas,
            "gasPrice": safe_transaction.data.gas_price,
            "gasToken": safe_transaction.data.gas_token,
            "refundReceiver": safe_transaction.data.refund_receiver,
            "_nonce": (
                safe_transaction.data.nonce
                if safe_transaction.data.nonce is not None
                else 0
            ),
        }

        return cast(
            str,
            self.contract.functions.getTransactionHash(**params).call().hex(),
        )

    def approve_hash(self, hash_to_approve: str) -> str:
        """
        Approves a hash on-chain.
        """
        try:
            params: SafeApproveHashParams = {"hashToApprove": HexBytes(hash_to_approve)}
            tx_hash = self.contract.functions.approveHash(**params).transact(
                {"from": self.eth_adapter.get_signer_address()}
            )
            return cast(str, tx_hash.hex())
        except Exception as e:
            raise handle_contract_error(e) from e

    def execute_transaction(self, safe_transaction: SafeTransaction) -> str:
        """
        Executes a Safe transaction.
        """
        # Sort signatures
        sorted_signatures = safe_transaction.sorted_signatures_bytes

        try:
            params: SafeExecTransactionParams = {
                "to": safe_transaction.data.to,
                "value": safe_transaction.data.value,
                "data": HexBytes(safe_transaction.data.data),
                "operation": safe_transaction.data.operation,
                "safeTxGas": safe_transaction.data.safe_tx_gas,
                "baseGas": safe_transaction.data.base_gas,
                "gasPrice": safe_transaction.data.gas_price,
                "gasToken": safe_transaction.data.gas_token,
                "refundReceiver": safe_transaction.data.refund_receiver,
                "signatures": sorted_signatures,
            }

            tx_hash = self.contract.functions.execTransaction(**params).transact(
                {"from": self.eth_adapter.get_signer_address()}
            )

            return cast(str, tx_hash.hex())
        except Exception as e:
            raise handle_contract_error(e) from e

    def estimate_transaction_gas(self, safe_transaction: SafeTransaction) -> int:
        """
        Estimates the gas required for a Safe transaction.
        """
        params: SafeRequiredTxGasParams = {
            "to": safe_transaction.data.to,
            "value": safe_transaction.data.value,
            "data": HexBytes(safe_transaction.data.data),
            "operation": safe_transaction.data.operation,
            "safeTxGas": safe_transaction.data.safe_tx_gas,
            "baseGas": safe_transaction.data.base_gas,
            "gasPrice": safe_transaction.data.gas_price,
            "gasToken": safe_transaction.data.gas_token,
            "refundReceiver": safe_transaction.data.refund_receiver,
            "signatures": safe_transaction.sorted_signatures_bytes,
        }
        return cast(
            int,
            self.contract.functions.requiredTxGas(**params).call(),
        )

    def check_signatures(self, safe_transaction: SafeTransaction) -> None:
        """
        Checks if the signatures on the transaction are valid.
        Raises an error if signatures are invalid.
        """
        tx_hash = self.get_transaction_hash(safe_transaction)
        # Convert hex string hash to bytes
        tx_hash_bytes = HexBytes(tx_hash)

        self.contract.functions.checkSignatures(
            tx_hash_bytes,
            HexBytes(safe_transaction.data.data),
            safe_transaction.sorted_signatures_bytes,
        ).call()
