from xmas.scene import main

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
