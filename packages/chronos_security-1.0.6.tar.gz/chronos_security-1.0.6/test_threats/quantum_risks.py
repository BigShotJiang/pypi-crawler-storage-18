"""
Quantum Risk Scenarios - RSA with weak key sizes
"""

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

# Quantum Risk 1: RSA with 512-bit key (extremely weak)
def generate_weak_rsa():
    """Generates weak 512-bit RSA key - vulnerable to quantum attacks"""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=512,  # QUANTUM RISK: Too small, vulnerable to Shor's algorithm
        backend=default_backend()
    )
    return private_key

# Quantum Risk 2: RSA with 1024-bit key (weak, deprecated)
def generate_1024_rsa():
    """Generates 1024-bit RSA - deprecated and vulnerable"""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=1024,  # QUANTUM RISK: Deprecated, vulnerable
        backend=default_backend()
    )
    return private_key

# Quantum Risk 3: Hardcoded RSA key
def use_hardcoded_rsa():
    """Using hardcoded RSA key string"""
    rsa_key = """
    -----BEGIN RSA PRIVATE KEY-----
    MIIEowIBAAKCAQEAu1SU1LfVLPHCozMxH2Mo4lgOstv82IwvZITVVqAV9bWf8g+O
    -----END RSA PRIVATE KEY-----
    """
    return rsa_key

# Quantum Risk 4: Insecure random for cryptography
import random
import os

def insecure_random_nonce():
    """Using Python's random module for cryptographic purposes"""
    nonce = random.randint(0, 2**32)  # QUANTUM RISK: Insecure random
    return nonce

def insecure_random_key():
    """Generating key with insecure random"""
    key = ''.join([str(random.randint(0, 9)) for _ in range(256)])
    return key

# Quantum Risk 5: MD5 for cryptographic purposes
import hashlib

def insecure_hash():
    """Using MD5 for security-critical operations"""
    data = b"important_data"
    hash_value = hashlib.md5(data).hexdigest()  # QUANTUM RISK: MD5 is broken
    return hash_value

# Quantum Risk 6: SHA-1 usage
def weak_sha1():
    """Using SHA-1 which is cryptographically broken"""
    data = b"sensitive"
    hash_value = hashlib.sha1(data).digest()  # QUANTUM RISK: SHA-1 deprecated
    return hash_value

# Quantum Risk 7: DES encryption (deprecated)
from Crypto.Cipher import DES

def use_deprecated_des():
    """Using DES which is quantum-vulnerable and weak"""
    key = b'12345678'  # 8 bytes for DES
    cipher = DES.new(key, DES.MODE_ECB)  # QUANTUM RISK: DES is deprecated
    return cipher
