"""
Security Vulnerability Test Cases
"""

import sqlite3
import os
import subprocess

# CRITICAL: SQL Injection vulnerability
def get_user_by_name(user_input):
    """SQL Injection vulnerability - DO NOT USE IN PRODUCTION"""
    conn = sqlite3.connect(':memory:')
    # CRITICAL: Direct string concatenation
    query = "SELECT * FROM users WHERE name = '" + user_input + "'"
    cursor = conn.cursor()
    cursor.execute(query)
    return cursor.fetchall()

def search_database(search_term):
    """Another SQL injection vulnerability"""
    conn = sqlite3.connect(':memory:')
    # CRITICAL: f-string with unescaped user input
    query = f"SELECT * FROM products WHERE title LIKE '%{search_term}%'"
    cursor = conn.cursor()
    cursor.execute(query)
    return cursor.fetchall()

# CRITICAL: Command Injection vulnerability
def execute_system_command(user_command):
    """Command injection - attacker can execute arbitrary commands"""
    # CRITICAL: shell=True with user input
    result = subprocess.run(user_command, shell=True, capture_output=True)
    return result.stdout.decode()

def unsafe_os_command(filename):
    """Another command injection vector"""
    # CRITICAL: Direct command with user input
    os.system(f"cat {filename}")

# HIGH: Hardcoded credentials
DATABASE_PASSWORD = "admin123"
API_KEY = "sk-proj-abc123def456ghi789"
PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBA..."
SECRET_TOKEN = "ghp_1234567890abcdef"

# HIGH: Insecure credential storage
CREDENTIALS = {
    "db_user": "root",
    "db_password": "password123",
    "api_key": "AIzaSyDummyKeyForTesting",
}

# HIGH: Weak password hashing
import hashlib

def hash_password_weak(password):
    """Using MD5 for password hashing - INSECURE"""
    return hashlib.md5(password.encode()).hexdigest()

def hash_password_weak_sha1(password):
    """Using SHA-1 for password - DEPRECATED"""
    return hashlib.sha1(password.encode()).hexdigest()

# MEDIUM: Insecure file operations
def read_user_file(user_path):
    """Path traversal vulnerability"""
    with open(user_path, 'r') as f:
        return f.read()

# MEDIUM: Eval usage
def unsafe_eval(code_string):
    """Using eval() with untrusted input"""
    result = eval(code_string)  # DANGEROUS
    return result
