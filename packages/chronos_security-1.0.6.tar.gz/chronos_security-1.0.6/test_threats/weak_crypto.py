from Crypto.PublicKey import RSA

# WEAK RSA KEY - Only 512 bits (should be 2048+)
key = RSA.generate(512)

# Insecure random number generation
import random
secret = random.randint(0, 2**128)

# Hardcoded credentials
API_KEY = "sk-12345abcde"
PASSWORD = "admin123"
