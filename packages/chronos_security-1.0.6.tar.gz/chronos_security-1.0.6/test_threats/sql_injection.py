import sqlite3

def vulnerable_query(user_input):
    # SQL INJECTION VULNERABILITY
    query = "SELECT * FROM users WHERE name = '" + user_input + "'"
    conn = sqlite3.connect("db.sqlite")
    cursor = conn.cursor()
    cursor.execute(query)  # VULNERABLE!
    return cursor.fetchall()

# Command injection vulnerability
import os
def dangerous_command(filename):
    os.system("cat " + filename)  # VULNERABLE!
