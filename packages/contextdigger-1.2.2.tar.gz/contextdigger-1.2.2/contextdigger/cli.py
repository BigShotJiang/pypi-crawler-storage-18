"""
Command-line interface for contextdigger.

Provides all ContextDigger functionality via simple CLI commands.
This eliminates approval prompts when used from Claude Code skills.
"""

import sys
import json
from pathlib import Path
from typing import Optional, List
from dataclasses import asdict
from .manager import FocusManager, FocusArea, Bookmark, ContextSnapshot
from .discover import FocusAreaDiscovery
from .budget import BudgetTracker, create_budget_tracker_from_config
from .refusal import RefusalHandler, should_refuse
from .export import ContextExporter


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print_usage()
        return

    command = sys.argv[1]
    args = sys.argv[2:]

    # Map commands to functions
    commands = {
        # Help & Info
        "--help": print_usage,
        "-h": print_usage,
        "help": print_usage,
        "--version": cmd_version,

        # Core Navigation
        "init": cmd_init,
        "dig": cmd_dig,
        "redig": cmd_redig,
        "status": cmd_status,
        "back": cmd_back,
        "forward": cmd_forward,
        "history": cmd_history,

        # Bookmarks
        "mark-spot": cmd_mark_spot,
        "goto-spot": cmd_goto_spot,
        "list-spots": cmd_list_spots,
        "delete-spot": cmd_delete_spot,

        # Context Snapshots
        "save-context": cmd_save_context,
        "load-context": cmd_load_context,
        "list-contexts": cmd_list_contexts,
        "delete-context": cmd_delete_context,

        # Notes & Documentation
        "note": cmd_note,
        "notes": cmd_notes,
        "wiki": cmd_wiki,

        # Analysis & Intelligence
        "suggest": cmd_suggest,
        "deps": cmd_deps,
        "impact": cmd_impact,
        "map": cmd_map,
        "hotspots": cmd_hotspots,
        "gaps": cmd_gaps,
        "perf": cmd_perf,
        "benchmark": cmd_benchmark,

        # Search & Query
        "search": cmd_search,
        "query": cmd_query,

        # Automation
        "auto": cmd_auto,
        "rules": cmd_rules,

        # Reports & Export
        "analytics": cmd_analytics,
        "report": cmd_report,
        "export": cmd_export,
        "backup": cmd_backup,

        # Dashboard & Monitoring
        "dashboard": cmd_dashboard,
        "health": cmd_health,
        "stats": cmd_stats,

        # Team
        "team": cmd_team,
        "tests": cmd_tests,

        # Aliases
        "list": cmd_list,
        "dig-status": cmd_status,
    }

    if command in commands:
        try:
            commands[command](*args)
        except Exception as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            sys.exit(1)
    else:
        print(f"Unknown command: {command}")
        print_usage()
        sys.exit(1)


def print_usage():
    """Print usage information."""
    print("""
ContextDigger - Dig Deep Into Your Codebase

Usage:
  contextdigger <command> [arguments]

Core Navigation:
  init [-f|--force]     Initialize ContextDigger in current directory
  dig <area>            Dig into a code area
  redig                 Interactive area selector
  status                Show current dig status
  back                  Navigate back in history
  forward               Navigate forward in history

Bookmarks:
  mark-spot [name]      Save current location as bookmark
  goto-spot <name>      Jump to bookmark
  list-spots            List all bookmarks
  delete-spot <name>    Delete a bookmark

Context Snapshots:
  save-context <name>   Save current context snapshot
  load-context <name>   Load context snapshot
  list-contexts         List all saved contexts
  delete-context <name> Delete context snapshot

Notes & Documentation:
  note <text>           Add note to current area
  notes [area]          View notes for area
  wiki                  Generate wiki documentation

Analysis & Intelligence:
  suggest               Get area suggestions
  deps [area]           Show dependencies
  impact <area>         Show impact analysis
  map                   Show codebase map
  hotspots              Find code hotspots
  gaps                  Find coverage gaps
  perf [area]           Performance analysis
  benchmark             Run benchmarks

Search & Query:
  search <query>        Search all data
  query <sql>           Run custom query

Automation:
  auto                  Show automation suggestions
  rules                 List automation rules

Reports & Export:
  analytics             Work analytics
  report [file]         Generate report
  export <format>       Export data
  backup                Create backup

Dashboard & Monitoring:
  dashboard             Show dashboard
  health                Health check
  stats                 Statistics

Team:
  team                  Team activity
  tests                 Test coverage

Options:
  --version             Show version
  --help, -h            Show this help

Claude Code Skills (recommended):
  /init-dig             Initialize context discovery
  /dig <area>           Dig into a code area
  /dig-dashboard        Show dashboard

For full documentation:
  https://contextdigger.com
  https://github.com/ialameh/contextdigger#readme
    """)


def cmd_version():
    """Show version."""
    from . import __version__
    print(f"contextdigger {__version__}")


def get_manager() -> FocusManager:
    """Get manager instance and check if initialized."""
    manager = FocusManager(Path.cwd())
    if not manager.is_initialized():
        print("❌ ContextDigger not initialized")
        print("Run: contextdigger init")
        sys.exit(1)
    return manager


# =============================================================================
# Core Navigation
# =============================================================================

def cmd_init(*args):
    """Initialize context discovery system."""
    manager = FocusManager(Path.cwd())

    # Check for force flag
    force = '--force' in args or '-f' in args

    if manager.is_initialized() and not force:
        print("✓ ContextDigger already initialized")
        print()
        print("Use one of these commands:")
        print("  contextdigger dashboard  - View current status")
        print("  contextdigger list       - See all areas")
        print("  contextdigger init -f    - Force re-initialization")
        return

    manager.initialize()
    print("✓ Initialized .cdg/ directory")

    # Run discovery
    print("\n⛏️  Digging through codebase...")
    discovery = FocusAreaDiscovery(Path.cwd())
    areas = discovery.discover()

    # Save areas
    for area in areas:
        manager.save_area(area)

    print(f"\n✓ Discovered {len(areas)} code areas")
    print("\nUse 'contextdigger list' to see all areas")
    print("Use '/dig <area>' in Claude Code to start digging")


def _interactive_area_picker(manager: FocusManager) -> Optional[FocusArea]:
    """Launch interactive fuzzy picker for area selection.

    Returns:
        Selected FocusArea or None if cancelled/unavailable
    """
    try:
        import inquirer
    except ImportError:
        print("❌ Interactive picker not available")
        print("Install with: pip install 'contextdigger[interactive]'")
        print("\nOr use: cdg dig <area-name> for direct access")
        print("Or use: cdg dig --list for plain list")
        return None

    # Check if running in TTY (interactive terminal)
    if not sys.stdin.isatty():
        print("Not in interactive mode. Use: cdg dig --list")
        return None

    areas = manager.list_areas()

    if len(areas) == 0:
        print("No areas found. Run 'cdg init' first.")
        return None

    # If only 1-3 areas, just show them (no picker needed)
    if len(areas) <= 3:
        cmd_list()
        print("\nOnly a few areas. Use: cdg dig <area-name>")
        return None

    # Prepare choices for inquirer
    choices = []
    for area in areas:
        # Format: "area-name - Description here"
        label = f"{area.name}"
        if area.description:
            # Truncate description to 70 chars
            desc = area.description[:70]
            if len(area.description) > 70:
                desc += "..."
            label += f" - {desc}"
        choices.append((label, area))

    # Launch interactive picker with fuzzy search
    questions = [
        inquirer.List(
            'area',
            message="Select a code area to dig into (type to filter)",
            choices=choices,
            carousel=True,  # Wrap around at edges
        ),
    ]

    try:
        answers = inquirer.prompt(questions)
        if answers is None:  # User pressed Ctrl+C
            print("\nCancelled")
            return None

        selected_area = answers['area']
        print(f"\n✓ Selected: {selected_area.name}")
        return selected_area
    except KeyboardInterrupt:
        print("\nCancelled")
        return None


def cmd_dig(*args):
    """Dig into a code area."""
    manager = get_manager()

    # NEW: If no arguments, launch interactive picker
    if len(args) == 0:
        area = _interactive_area_picker(manager)
        if area is None:
            return  # User cancelled or picker unavailable
        args = (area.id,)  # Continue with selected area

    # Check for --list flag
    if len(args) == 1 and args[0] == "--list":
        cmd_list()
        return

    area_id = args[0]
    area = manager.get_area(area_id)

    if not area:
        # Try fuzzy match
        matches = manager.find_areas(area_id)
        if not matches:
            print(f"❌ No area found matching '{area_id}'")
            print("\nAvailable areas:")
            for a in manager.list_areas():
                print(f"  - {a.id}: {a.name}")
            sys.exit(1)
        elif len(matches) == 1:
            area = matches[0]
            print(f"Matched '{area_id}' to: {area.id}")
        else:
            print(f"Multiple areas match '{area_id}':")
            for i, match in enumerate(matches[:5], 1):
                print(f"  {i}. {match.id} - {match.name}")
            sys.exit(1)

    # Calculate budget and check for refusal
    try:
        config = manager.load_config()
        budget_tracker = create_budget_tracker_from_config(config)
        files = manager.get_files_in_area(area)
        budget_status = budget_tracker.calculate_budget(files)

        # REFUSAL MODE: Check if area exceeds budget
        if budget_status.exceeds:
            refusal_handler = RefusalHandler(
                max_files=budget_tracker.max_files,
                max_lines=budget_tracker.max_lines
            )

            # Display refusal message with suggestions
            refusal_handler.display_refusal(
                area_name=area.name,
                files=files,
                files_used=budget_status.files_used,
                lines_used=budget_status.lines_used,
                project_root=manager.project_root
            )

            # Exit without loading the area
            print("\n💡 Tip: Use 'contextdigger list' to see all areas")
            sys.exit(1)

    except Exception as e:
        # If budget calculation fails, don't block the dig command
        pass

    # Start session (only if budget check passed)
    manager.start_session(area.id)
    manager.add_to_history(area.id)

    print(f"\n⛏️  Digging into: {area.name}")
    print(f"   {area.description}")
    print(f"\n   Language: {area.metadata.get('language', 'unknown')}")
    print(f"   Files: ~{area.metadata.get('fileCount', '?')}")

    if area.metadata.get('primaryFiles'):
        print(f"\n   Key Files:")
        for pf in area.metadata['primaryFiles'][:5]:
            print(f"     - {pf}")

    if area.dependencies:
        print(f"\n   Depends on: {', '.join(area.dependencies)}")

    print(f"\n   Focus count: {area.focusCount} times")

    # Display budget (already calculated above)
    try:
        print(f"\n   {budget_tracker.format_budget_display(budget_status)}")

        # Show warning if at threshold
        if budget_status.at_warning_threshold:
            print(f"   ⚠️  Warning: Budget usage at {max(budget_status.percentage_files, budget_status.percentage_lines):.0%}")
    except Exception as e:
        # If budget display fails, don't block the dig command
        pass

    # Export context file for AI tools
    try:
        # Get bookmarks for this area
        bookmarks = manager.list_bookmarks()
        area_bookmarks = [b for b in bookmarks if b.focusArea == area.id]

        # Create exporter and export
        exporter = ContextExporter(
            project_root=manager.project_root,
            cdg_root=manager.cdg_dir
        )

        context_file = exporter.export_for_ai(
            area_name=area.id,
            area_description=area.description,
            files=files,
            budget_status=budget_status,
            bookmarks=area_bookmarks if area_bookmarks else None
        )

        print(f"\n   📄 Context file: {context_file.relative_to(manager.project_root)}")
    except Exception as e:
        # If context export fails, don't block the dig command
        pass


def cmd_redig(*args):
    """Interactive area selector."""
    manager = get_manager()
    areas = manager.list_areas()

    if not areas:
        print("No areas discovered. Run: contextdigger init")
        return

    current = manager.get_current_focus()

    print("Available areas:\n")
    for i, area in enumerate(areas, 1):
        marker = "⛏️ " if area.id == current else "  "
        print(f"{marker}{i}. {area.id}")
        print(f"   {area.name}")
        print()

    print("Run: contextdigger dig <area-id>")


def cmd_status(*args):
    """Show current dig status."""
    manager = get_manager()
    current_focus = manager.get_current_focus()

    if not current_focus:
        print("Not currently digging")
        print("Use /dig or /redig to start digging into an area")
        return

    area = manager.get_area(current_focus)
    session = manager.get_current_session()

    print(f"⛏️  Current Focus: {area.name}")
    print(f"   Area ID: {area.id}")

    if session:
        from datetime import datetime, timezone
        start = datetime.fromisoformat(session.startedAt.replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        duration = now - start
        hours = int(duration.total_seconds() // 3600)
        minutes = int((duration.total_seconds() % 3600) // 60)
        print(f"   Session: {hours}h {minutes}m")

    files_modified = len(session.activity.get('filesModified', [])) if session else 0
    print(f"   Files modified: {files_modified}")


def cmd_back(*args):
    """Navigate back in history."""
    manager = get_manager()
    success = manager.navigate_backward()

    if success:
        current = manager.get_current_focus()
        if current:
            area = manager.get_area(current)
            print(f"⛏️  Back to: {area.name}")
    else:
        print("Already at oldest history item")


def cmd_forward(*args):
    """Navigate forward in history."""
    manager = get_manager()
    success = manager.navigate_forward()

    if success:
        current = manager.get_current_focus()
        if current:
            area = manager.get_area(current)
            print(f"⛏️  Forward to: {area.name}")
    else:
        print("Already at newest history item")


def cmd_history(*args):
    """Show navigation history."""
    manager = get_manager()
    history = manager.get_history()

    if not history:
        print("No navigation history")
        print("Use: contextdigger dig <area>")
        return

    print(f"📜 Navigation History ({len(history)} entries):\n")

    for entry in history[-10:]:  # Show last 10 entries
        marker = "→" if entry == history[-1] else " "
        print(f"{marker} {entry.areaName}")
        print(f"   Entered: {entry.enteredAt}")
        if entry.exitedAt:
            print(f"   Exited: {entry.exitedAt}")
        if entry.duration:
            minutes = entry.duration // 60
            print(f"   Duration: {minutes}m")
        if entry.actions:
            print(f"   Actions: {', '.join(entry.actions)}")
        print()


def cmd_list(*args):
    """List all discovered code areas."""
    manager = get_manager()
    areas = manager.list_areas()

    if not areas:
        print("No code areas discovered")
        print("Run: contextdigger init")
        return

    print(f"Discovered Code Areas ({len(areas)} total):\n")

    current_focus = manager.get_current_focus()

    for area in areas:
        marker = "⛏️ " if area.id == current_focus else "  "
        lang = area.metadata.get('language', 'unknown')

        # Calculate file count dynamically
        try:
            files = manager.get_files_in_area(area)
            file_count = len(files)
        except Exception:
            file_count = '?'

        print(f"{marker}{area.id}")
        print(f"   {area.name} ({lang}, ~{file_count} files)")
        print(f"   {area.description}")
        print()


# =============================================================================
# Bookmarks
# =============================================================================

def cmd_mark_spot(*args):
    """Save current location as bookmark."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger mark-spot <name> [path] [line]")
        return

    name = args[0]
    path = args[1] if len(args) > 1 else None
    line = int(args[2]) if len(args) > 2 else None

    if not path:
        print("Error: path required")
        print("Usage: contextdigger mark-spot <name> <path> [line]")
        sys.exit(1)

    # Create bookmark
    file_path = Path(path)
    if not file_path.is_absolute():
        file_path = Path.cwd() / file_path

    try:
        rel_path = file_path.relative_to(Path.cwd())
    except ValueError:
        rel_path = file_path

    current_focus = manager.get_current_focus()

    bookmark = Bookmark(
        id=name,
        name=name,
        path=str(rel_path),
        line=line,
        column=1,
        context="",
        focusArea=current_focus,
        tags=[],
        notes=""
    )

    manager.add_bookmark(bookmark)
    print(f"✓ Bookmark created: {bookmark.id}")
    print(f"   File: {bookmark.path}")
    if bookmark.line:
        print(f"   Line: {bookmark.line}")


def cmd_goto_spot(*args):
    """Jump to bookmark."""
    manager = get_manager()

    if not args:
        cmd_list_spots()
        return

    bookmark_id = args[0]
    bookmark = manager.get_bookmark(bookmark_id)

    if not bookmark:
        matches = manager.find_bookmarks(bookmark_id)
        if not matches:
            print(f"❌ No bookmark found: {bookmark_id}")
            sys.exit(1)
        bookmark = matches[0]

    manager.update_bookmark_access(bookmark.id)

    print(f"📍 {bookmark.name}")
    print(f"   File: {bookmark.path}")
    if bookmark.line:
        print(f"   Line: {bookmark.line}")

    # Show file context if it exists
    file_path = Path.cwd() / bookmark.path
    if file_path.exists():
        with open(file_path, 'r') as f:
            lines = f.readlines()

        line_num = bookmark.line or 1
        start = max(0, line_num - 10)
        end = min(len(lines), line_num + 10)

        print(f"\n📄 {bookmark.path}\n")
        for i in range(start, end):
            marker = ">>>" if i + 1 == line_num else "   "
            print(f"{marker} {i+1:4d} │ {lines[i].rstrip()}")


def cmd_list_spots(*args):
    """List all bookmarks."""
    manager = get_manager()
    bookmarks = manager.list_bookmarks()

    if not bookmarks:
        print("No bookmarks found")
        print("Use: contextdigger mark-spot <name> <path>")
        return

    print(f"📑 Bookmarks ({len(bookmarks)} total):\n")
    for bm in bookmarks:
        print(f"  {bm.id}: {bm.path}")
        if bm.line:
            print(f"    Line {bm.line}")
        if bm.context:
            print(f"    {bm.context}")
        print()


def cmd_delete_spot(*args):
    """Delete a bookmark."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger delete-spot <name>")
        return

    bookmark_id = args[0]
    if manager.delete_bookmark(bookmark_id):
        print(f"✓ Deleted bookmark: {bookmark_id}")
    else:
        print(f"❌ Bookmark not found: {bookmark_id}")


# =============================================================================
# Context Snapshots
# =============================================================================

def cmd_save_context(*args):
    """Save current context snapshot."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger save-context <name> [description]")
        return

    name = args[0]
    description = " ".join(args[1:]) if len(args) > 1 else ""

    snapshot = manager.save_context(name, description)
    print(f"✓ Context saved: {snapshot.name}")
    print(f"   Areas: {len(snapshot.markedSpots)}")
    print(f"   Saved at: {snapshot.savedAt}")


def cmd_load_context(*args):
    """Load context snapshot."""
    manager = get_manager()

    if not args:
        cmd_list_contexts()
        return

    name = args[0]
    snapshot = manager.load_context(name)

    if not snapshot:
        print(f"❌ Context not found: {name}")
        sys.exit(1)

    print(f"✓ Context loaded: {snapshot.name}")
    print(f"   {snapshot.description}")
    if snapshot.currentAreaName:
        print(f"   Current area: {snapshot.currentAreaName}")


def cmd_list_contexts(*args):
    """List all saved contexts."""
    manager = get_manager()
    contexts = manager.list_contexts()

    if not contexts:
        print("No saved contexts")
        print("Use: contextdigger save-context <name>")
        return

    print(f"Saved Contexts ({len(contexts)} total):\n")
    for ctx in contexts:
        print(f"  {ctx.name}")
        print(f"    {ctx.description}")
        print(f"    Saved: {ctx.savedAt}")
        print()


def cmd_delete_context(*args):
    """Delete context snapshot."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger delete-context <name>")
        return

    name = args[0]
    if manager.delete_context(name):
        print(f"✓ Deleted context: {name}")
    else:
        print(f"❌ Context not found: {name}")


# =============================================================================
# Notes & Documentation
# =============================================================================

def cmd_note(*args):
    """Add note to current area."""
    manager = get_manager()
    current = manager.get_current_focus()

    if not current:
        print("❌ Not in any area. Use: contextdigger dig <area>")
        sys.exit(1)

    if not args:
        print("Usage: contextdigger note <text>")
        return

    note_text = " ".join(args)
    note = manager.add_note(current, note_text)
    print(f"✓ Note added to {note.areaId}")


def cmd_notes(*args):
    """View notes for area."""
    manager = get_manager()

    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("❌ Not in any area. Use: contextdigger dig <area>")
        sys.exit(1)

    notes = manager.get_notes(area_id)

    if not notes:
        print(f"No notes for area: {area_id}")
        return

    area = manager.get_area(area_id)
    print(f"📝 Notes for {area.name}:\n")
    for note in notes:
        print(f"  • {note.content}")
        print(f"    {note.createdAt}")
        print()


def cmd_wiki(*args):
    """Generate wiki documentation."""
    manager = get_manager()

    print("📚 Wiki Documentation")
    print("="*60)

    areas = manager.list_areas()
    for area in areas:
        print(f"\n## {area.name}\n")
        print(f"{area.description}\n")

        notes = manager.get_notes(area.id)
        if notes:
            print("**Notes:**")
            for note in notes[:3]:
                print(f"- {note.content}")
            print()


# =============================================================================
# Analysis & Intelligence
# =============================================================================

def cmd_suggest(*args):
    """Get area suggestions."""
    manager = get_manager()
    current = manager.get_current_focus()

    suggestions = manager.get_area_suggestions(current)

    if not suggestions:
        print("No suggestions at this time")
        return

    print("💡 Suggestions:\n")
    for sug in suggestions:
        print(f"  • {sug.reason}")
        print(f"    /dig {sug.targetAreaId}")
        print()


def cmd_deps(*args):
    """Show dependencies."""
    manager = get_manager()
    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("Usage: contextdigger deps <area>")
        return

    area = manager.get_area(area_id)
    deps = manager.get_dependencies(area_id)

    print(f"📦 Dependencies for {area.name}:\n")
    for dep in deps:
        print(f"  • {dep.targetArea}")
        print(f"    {dep.relationshipType}: {dep.strength}")
        print()


def cmd_impact(*args):
    """Show impact analysis."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger impact <area>")
        return

    area_id = args[0]
    area = manager.get_area(area_id)
    dependents = manager.get_dependents(area_id)

    print(f"💥 Impact Analysis: {area.name}\n")
    print(f"Areas affected by changes: {len(dependents)}\n")

    for dep in dependents[:10]:
        print(f"  • {dep.targetArea}")
        print(f"    {dep.relationshipType}")
        print()


def cmd_map(*args):
    """Show codebase map."""
    manager = get_manager()
    areas = manager.list_areas()

    print("🗺️  Codebase Map\n")
    for area in areas:
        deps = len(area.dependencies)
        print(f"  {area.id}")
        print(f"    {area.name}")
        if deps > 0:
            print(f"    → Depends on {deps} area(s)")
        print()


def cmd_hotspots(*args):
    """Find code hotspots."""
    manager = get_manager()
    days = int(args[0]) if args else 30

    hotspots = manager.get_hotspots(days=days)

    print(f"🔥 Code Hotspots (last {days} days):\n")
    for hs in hotspots[:10]:
        print(f"  {hs.path}")
        print(f"    Commits: {hs.commitCount}, Complexity: {hs.complexity:.1f}")
        print(f"    Authors: {len(hs.authors)}")
        print()


def cmd_gaps(*args):
    """Find coverage gaps."""
    manager = get_manager()

    gaps = manager.find_coverage_gaps()

    print(f"🔍 Coverage Gaps:\n")
    for gap in gaps:
        print(f"  {gap.areaId}")
        print(f"    Coverage: {gap.lineCoverage:.1f}%")
        print()


def cmd_perf(*args):
    """Performance analysis."""
    manager = get_manager()
    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("Usage: contextdigger perf [area]")
        return

    complexity = manager.get_area_complexity(area_id)
    area = manager.get_area(area_id)

    print(f"⚡ Performance Analysis: {area.name}\n")
    print(f"  Complexity: {complexity:.1f}")


def cmd_benchmark(*args):
    """Run benchmarks."""
    manager = get_manager()
    stats = manager.get_statistics()

    print("📊 Benchmarks:\n")
    print(f"  Total areas: {stats.get('total_areas', 0)}")
    print(f"  Total notes: {stats.get('total_notes', 0)}")
    print(f"  Total bookmarks: {stats.get('total_bookmarks', 0)}")
    print(f"  Total visits: {stats.get('total_visits', 0)}")


# =============================================================================
# Search & Query
# =============================================================================

def cmd_search(*args):
    """Search all data."""
    if not args:
        print("Usage: contextdigger search <query>")
        return

    manager = get_manager()
    query = " ".join(args)

    # Search areas
    areas = manager.find_areas(query)
    print(f"Areas matching '{query}':\n")
    for area in areas[:5]:
        print(f"  • {area.id}: {area.name}")

    # Search bookmarks
    bookmarks = manager.find_bookmarks(query)
    if bookmarks:
        print(f"\nBookmarks matching '{query}':\n")
        for bm in bookmarks[:5]:
            print(f"  • {bm.id}: {bm.path}")


def cmd_query(*args):
    """Run custom query."""
    print("Custom queries not yet implemented")


# =============================================================================
# Automation
# =============================================================================

def cmd_auto(*args):
    """Show automation suggestions."""
    print("💡 Automation Suggestions:\n")
    print("  • Set up area-based test automation")
    print("  • Configure auto-bookmarking on file edit")
    print("  • Enable team activity notifications")


def cmd_rules(*args):
    """List automation rules."""
    manager = get_manager()
    rules = manager.get_automation_rules()

    if not rules:
        print("No automation rules configured")
        return

    print(f"⚙️  Automation Rules ({len(rules)} total):\n")
    for rule in rules:
        print(f"  • {rule.name}")
        print(f"    Trigger: {rule.trigger}")
        print()


# =============================================================================
# Reports & Export
# =============================================================================

def cmd_analytics(*args):
    """Work analytics."""
    manager = get_manager()
    days = int(args[0]) if args else 30

    analytics = manager.get_work_analytics(days=days)

    print(f"📈 Work Analytics (last {days} days):\n")
    print(f"  Total sessions: {analytics.totalSessions}")
    print(f"  Total time: {analytics.totalTime // 3600}h")
    print(f"  Areas worked: {len(analytics.topAreas)}")
    print()

    print("  Top areas:")
    for area_stat in analytics.topAreas[:5]:
        print(f"    • {area_stat['areaName']}: {area_stat['sessionCount']} sessions")


def cmd_report(*args):
    """Generate report."""
    manager = get_manager()
    output_file = args[0] if args else None

    stats = manager.get_statistics()

    report = f"""# ContextDigger Report

## Overview
- Total Areas: {stats.get('total_areas', 0)}
- Total Notes: {stats.get('total_notes', 0)}
- Total Bookmarks: {stats.get('total_bookmarks', 0)}
- Total Snapshots: {stats.get('total_snapshots', 0)}
- Total Visits: {stats.get('total_visits', 0)}

## Areas
"""

    areas = manager.list_areas()
    for area in areas:
        report += f"\n### {area.name}\n"
        report += f"{area.description}\n"

    if output_file:
        Path(output_file).write_text(report)
        print(f"✓ Report saved to: {output_file}")
    else:
        print(report)


def cmd_export(*args):
    """Export data."""
    if not args:
        print("Usage: contextdigger export <format>")
        print("Formats: json, markdown")
        return

    manager = get_manager()
    format_type = args[0]

    if format_type == "json":
        data = {
            "areas": [asdict(a) for a in manager.list_areas()],
            "bookmarks": [asdict(b) for b in manager.list_bookmarks()],
            "contexts": [asdict(c) for c in manager.list_contexts()]
        }
        print(json.dumps(data, indent=2))
    else:
        print(f"Unsupported format: {format_type}")


def cmd_backup(*args):
    """Create backup."""
    import shutil
    from datetime import datetime

    backup_name = datetime.now().strftime("cdg-backup-%Y%m%d-%H%M%S.tar.gz")

    # Create tar.gz of .cdg directory
    import tarfile
    with tarfile.open(backup_name, "w:gz") as tar:
        tar.add(".cdg", arcname="cdg")

    print(f"✓ Backup created: {backup_name}")


# =============================================================================
# Dashboard & Monitoring
# =============================================================================

def cmd_dashboard(*args):
    """Show dashboard."""
    manager = get_manager()
    dashboard = manager.get_dashboard()

    print("📊 ContextDigger Dashboard")
    print("="*60)
    print()

    # Overview
    overview = dashboard["overview"]
    print("## Overview")
    print("-"*60)
    print(f"  Areas: {overview.get('areas', 0)}")
    print(f"  Notes: {overview.get('notes', 0)}")
    print(f"  Bookmarks: {overview.get('bookmarks', 0)}")
    print(f"  Snapshots: {overview.get('snapshots', 0)}")

    if "currentFocus" in overview:
        focus = overview["currentFocus"]
        print()
        print(f"  Currently in: {focus['name']}")
        print(f"  Path: {focus['path']}")
    print()
    print()

    # Alerts
    alerts = dashboard.get("alerts", [])
    if alerts:
        print("## ⚠️  Alerts")
        print("-"*60)
        for alert in alerts:
            severity_icon = {
                "high": "🔴",
                "medium": "🟡",
                "low": "🟢",
            }.get(alert["severity"], "⚪")

            print(f"  {severity_icon} {alert['message']}")
            print(f"     Action: {alert['action']}")
            print()
        print()

    # Recent Activity
    recent = dashboard.get("recent", {}).get("areas", [])
    if recent:
        print("## Recent Activity")
        print("-"*60)
        for area in recent:
            timestamp = area.get("timestamp", "")[:16].replace("T", " ")
            print(f"  • {area['name']} ({timestamp})")
        print()
        print()

    # Suggestions
    suggestions = dashboard.get("suggestions", [])
    if suggestions:
        print("## 💡 Suggestions")
        print("-"*60)
        for suggestion in suggestions:
            print(f"  • {suggestion}")
        print()
        print()


def cmd_health(*args):
    """Health check."""
    manager = get_manager()
    health = manager.get_health_check()

    print("🏥 Health Check")
    print("="*60)
    print()

    status = health.get("status", "unknown")
    print(f"Status: {status.upper()}")
    print()

    issues = health.get("issues", [])
    if issues:
        print("Issues:")
        for issue in issues:
            print(f"  ⚠️  {issue}")
    else:
        print("✓ No issues found")


def cmd_stats(*args):
    """Statistics."""
    manager = get_manager()
    stats = manager.get_statistics()

    print("📊 Statistics")
    print("="*60)
    print()
    print(f"Total Areas: {stats.get('total_areas', 0)}")
    print(f"Total Notes: {stats.get('total_notes', 0)}")
    print(f"Total Bookmarks: {stats.get('total_bookmarks', 0)}")
    print(f"Total Snapshots: {stats.get('total_snapshots', 0)}")
    print(f"Total Visits: {stats.get('total_visits', 0)}")
    print()

    if stats.get('most_common_tags'):
        print("Most Common Tags:")
        for tag_data in stats['most_common_tags']:
            print(f"  • {tag_data['tag']}: {tag_data['count']} times")

    print()
    enabled = stats.get('enabled_rules', 0)
    total_rules = stats.get('automation_rules', 0)
    print(f"Automation Rules: {total_rules} ({enabled} enabled)")


# =============================================================================
# Team
# =============================================================================

def cmd_team(*args):
    """Team activity."""
    manager = get_manager()
    activity = manager.get_team_activity(max_age_hours=24)

    if not activity:
        print("No recent team activity")
        return

    print("👥 Team Activity (last 24h):\n")
    for act in activity[:10]:
        print(f"  • {act.author}")
        print(f"    {act.areaName} - {act.action}")
        print(f"    {act.timestamp}")
        print()


def cmd_tests(*args):
    """Test coverage."""
    manager = get_manager()
    current = args[0] if args else manager.get_current_focus()

    if not current:
        print("Usage: contextdigger tests [area]")
        return

    coverage = manager.get_area_coverage(current)
    area = manager.get_area(current)

    print(f"🧪 Test Coverage: {area.name}\n")
    print(f"  Line coverage: {coverage.lineCoverage:.1f}%")
    print(f"  Branch coverage: {coverage.branchCoverage:.1f}%")
    print(f"  Files: {coverage.totalFiles}")


if __name__ == "__main__":
    main()
