"""
ContextDigger - AI-Powered Context Governance for Codebases

Enforce budget limits, refuse oversized contexts, and generate AI-readable scope definitions.
Transform how AI tools interact with your codebase through disciplined context management.
"""

__version__ = "1.2.2"

from .manager import FocusManager, FocusArea, Session, Bookmark
from .discover import FocusAreaDiscovery, DiscoveryConfig

__all__ = [
    "FocusManager",
    "FocusArea",
    "Session",
    "Bookmark",
    "FocusAreaDiscovery",
    "DiscoveryConfig",
]
