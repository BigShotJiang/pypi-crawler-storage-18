use parking_lot::RwLock;
use pyo3::prelude::*;
use roaring::RoaringBitmap;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap};
use std::collections::hash_map::DefaultHasher;
use std::fs::{File, OpenOptions};
use std::hash::{Hash, Hasher};
use std::io::{BufReader, BufWriter, Read, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::sync::Arc;
use memmap2::MmapMut;

#[cfg(unix)]
use memmap2::Advice;

const M: usize = 12; 
const EF_CONSTRUCTION: usize = 100;
const DIM: usize = 768; 
const U32_SIZE: usize = 4;
const U64_SIZE: usize = 8;
const NODE_SIZE: usize = M * U32_SIZE;

#[inline(always)]
fn quantize(val: f32) -> u8 {
    let clamped = val.clamp(-1.0, 1.0);
    ((clamped + 1.0) * 127.5) as u8
}

#[inline(always)]
fn dist_sq_u8(a: &[u8], b: &[u8]) -> u32 {
    let mut d: u32 = 0;
    for i in 0..a.len() {
        let diff = (a[i] as i32) - (b[i] as i32);
        d += (diff * diff) as u32;
    }
    d
}

fn hash_id(id: &str) -> u64 {
    let mut s = DefaultHasher::new();
    id.hash(&mut s);
    s.finish()
}

// --- Persistence Structures ---

#[derive(Serialize, Deserialize)]
enum WalEntry {
    Insert { id: String, vec: Vec<f32>, meta: Map<String, Value> },
    Delete { id: String },
}

#[derive(Serialize, Deserialize)]
struct SnapshotData {
    enter_point: Option<u32>,
    str_index: HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: HashMap<String, Vec<f32>>,
    valid_ids: RoaringBitmap,
    deleted: RoaringBitmap,
    ext_to_int: HashMap<u64, u32>, 
}

#[derive(Serialize)]
struct SnapshotView<'a> {
    enter_point: Option<u32>,
    str_index: &'a HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: &'a HashMap<String, Vec<f32>>,
    valid_ids: &'a RoaringBitmap,
    deleted: &'a RoaringBitmap,
    ext_to_int: &'a HashMap<u64, u32>,
}

struct CoreIndex {
    vec_mmap: MmapMut,
    vec_file: File,
    graph_mmap: MmapMut,
    graph_file: File,
    offset_mmap: MmapMut,
    offset_file: File,
    ids_file: File, 
    
    capacity: usize,

    enter_point: Option<u32>,
    str_index: HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: HashMap<String, Vec<f32>>,
    valid_ids: RoaringBitmap,
    deleted: RoaringBitmap,
    ext_to_int: HashMap<u64, u32>, 
    ids_file_len: u64,
}

impl CoreIndex {
    fn new(base_path: &PathBuf) -> Self {
        let vec_path = base_path.join("vectors.bin");
        let graph_path = base_path.join("graph.bin");
        let offset_path = base_path.join("offsets.bin");
        let ids_path = base_path.join("ids.bin");

        let vec_file = OpenOptions::new().read(true).write(true).create(true).open(&vec_path).unwrap();
        let graph_file = OpenOptions::new().read(true).write(true).create(true).open(&graph_path).unwrap();
        let offset_file = OpenOptions::new().read(true).write(true).create(true).open(&offset_path).unwrap();
        let ids_file = OpenOptions::new().read(true).write(true).create(true).open(&ids_path).unwrap();

        let vec_len = vec_file.metadata().unwrap().len() as usize;
        let graph_len = graph_file.metadata().unwrap().len() as usize;
        let offset_len = offset_file.metadata().unwrap().len() as usize;
        let ids_file_len = ids_file.metadata().unwrap().len();

        let capacity = std::cmp::max(100_000, vec_len / DIM);
        
        if vec_len < capacity * DIM { vec_file.set_len((capacity * DIM) as u64).unwrap(); }
        if graph_len < capacity * NODE_SIZE { graph_file.set_len((capacity * NODE_SIZE) as u64).unwrap(); }
        if offset_len < capacity * U64_SIZE { offset_file.set_len((capacity * U64_SIZE) as u64).unwrap(); }

        let vec_mmap = unsafe { MmapMut::map_mut(&vec_file).unwrap() };
        let graph_mmap = unsafe { MmapMut::map_mut(&graph_file).unwrap() };
        let offset_mmap = unsafe { MmapMut::map_mut(&offset_file).unwrap() };

        #[cfg(unix)]
        {
            let _ = vec_mmap.advise(Advice::Random);
            let _ = graph_mmap.advise(Advice::Random);
            let _ = offset_mmap.advise(Advice::Random);
        }

        Self {
            vec_mmap, vec_file,
            graph_mmap, graph_file,
            offset_mmap, offset_file,
            ids_file,
            capacity,
            enter_point: None,
            str_index: HashMap::new(),
            num_store: HashMap::new(),
            valid_ids: RoaringBitmap::new(),
            deleted: RoaringBitmap::new(),
            ext_to_int: HashMap::new(),
            ids_file_len,
        }
    }

    fn ensure_capacity(&mut self) {
        let current_count = self.ext_to_int.len();
        if current_count >= self.capacity {
            let new_cap = self.capacity + 100_000;
            
            self.vec_mmap.flush().unwrap();
            self.vec_file.set_len((new_cap * DIM) as u64).unwrap();
            self.vec_mmap = unsafe { MmapMut::map_mut(&self.vec_file).unwrap() };
            
            self.graph_mmap.flush().unwrap();
            self.graph_file.set_len((new_cap * NODE_SIZE) as u64).unwrap();
            self.graph_mmap = unsafe { MmapMut::map_mut(&self.graph_file).unwrap() };

            self.offset_mmap.flush().unwrap();
            self.offset_file.set_len((new_cap * U64_SIZE) as u64).unwrap();
            self.offset_mmap = unsafe { MmapMut::map_mut(&self.offset_file).unwrap() };

            #[cfg(unix)]
            {
                let _ = self.vec_mmap.advise(Advice::Random);
                let _ = self.graph_mmap.advise(Advice::Random);
                let _ = self.offset_mmap.advise(Advice::Random);
            }
            
            self.capacity = new_cap;
        }
    }

    fn get_external_id(&mut self, internal_id: u32) -> String {
        let start_pos = (internal_id as usize) * U64_SIZE;
        let offset_bytes: [u8; 8] = self.offset_mmap[start_pos..start_pos+8].try_into().unwrap();
        let offset = u64::from_ne_bytes(offset_bytes);

        self.ids_file.seek(SeekFrom::Start(offset)).unwrap();
        let mut len_bytes = [0u8; 4];
        self.ids_file.read_exact(&mut len_bytes).unwrap();
        let len = u32::from_le_bytes(len_bytes) as usize;

        let mut str_bytes = vec![0u8; len];
        self.ids_file.read_exact(&mut str_bytes).unwrap();
        
        String::from_utf8(str_bytes).unwrap_or_else(|_| "".to_string())
    }

    fn write_external_id(&mut self, id: &str, internal_id: u32) {
        self.ids_file.seek(SeekFrom::End(0)).unwrap();
        let start_offset = self.ids_file_len;
        
        let bytes = id.as_bytes();
        let len_bytes = (bytes.len() as u32).to_le_bytes();
        
        self.ids_file.write_all(&len_bytes).unwrap();
        self.ids_file.write_all(bytes).unwrap();
        
        self.ids_file_len += 4 + bytes.len() as u64;

        let pos = (internal_id as usize) * U64_SIZE;
        let offset_bytes = start_offset.to_ne_bytes();
        self.offset_mmap[pos..pos+8].copy_from_slice(&offset_bytes);
    }

    #[inline(always)]
    fn get_vector(&self, idx: u32) -> &[u8] {
        let start = (idx as usize) * DIM;
        &self.vec_mmap[start..start + DIM]
    }

    #[inline(always)]
    fn get_neighbors(&self, idx: u32) -> impl Iterator<Item = u32> + '_ {
        let start = (idx as usize) * NODE_SIZE;
        let slice = &self.graph_mmap[start..start + NODE_SIZE];
        (0..M).map(move |i| {
            let offset = i * U32_SIZE;
            u32::from_ne_bytes(slice[offset..offset+4].try_into().unwrap())
        }).take_while(|&x| x != u32::MAX)
    }

    fn add_neighbor(&mut self, node_idx: u32, neighbor_idx: u32) {
        let start = (node_idx as usize) * NODE_SIZE;
        for i in 0..M {
            let offset = start + (i * U32_SIZE);
            let existing = u32::from_ne_bytes(self.graph_mmap[offset..offset+4].try_into().unwrap());
            if existing == u32::MAX {
                let bytes = neighbor_idx.to_ne_bytes();
                self.graph_mmap[offset..offset+4].copy_from_slice(&bytes);
                return;
            }
            if existing == neighbor_idx { return; }
        }
    }

    fn insert_in_mem(&mut self, ext_id: String, vector: Vec<f32>, metadata: Map<String, Value>) {
        let id_hash = hash_id(&ext_id);
        if self.ext_to_int.contains_key(&id_hash) { return; }

        self.ensure_capacity();
        let new_id = self.ext_to_int.len() as u32;

        self.write_external_id(&ext_id, new_id);

        let start = (new_id as usize) * DIM;
        for (i, &val) in vector.iter().take(DIM).enumerate() {
            self.vec_mmap[start + i] = quantize(val);
        }

        let g_start = (new_id as usize) * NODE_SIZE;
        for i in 0..NODE_SIZE { self.graph_mmap[g_start + i] = 0xFF; }

        self.ext_to_int.insert(id_hash, new_id);
        self.valid_ids.insert(new_id);

        let id_usize = new_id as usize;
        for (key, val) in metadata {
            // Memory Optimization: Skip indexing "id" to avoid redundant storage
            if key == "id" || key == "_id" { continue; }

            match val {
                Value::String(s) => { self.str_index.entry(key).or_default().entry(s).or_default().insert(new_id); },
                Value::Number(n) => {
                    if let Some(f) = n.as_f64() {
                        let col = self.num_store.entry(key).or_insert_with(|| vec![f32::NAN; id_usize]);
                        if col.len() < id_usize { col.resize(id_usize, f32::NAN); }
                        col.push(f as f32);
                    }
                },
                Value::Bool(b) => {
                    let s = if b { "true".to_string() } else { "false".to_string() };
                    self.str_index.entry(key).or_default().entry(s).or_default().insert(new_id);
                },
                _ => {} 
            }
        }
        for col in self.num_store.values_mut() {
            if col.len() == id_usize { col.push(f32::NAN); }
        }

        if self.enter_point.is_none() {
            self.enter_point = Some(new_id);
            return;
        }

        let q_vec = self.get_vector(new_id).to_vec();
        let neighbors = self._search_core(&q_vec, EF_CONSTRUCTION, None);
        for (_, neighbor_id) in neighbors.into_iter().take(M) {
            self.add_neighbor(new_id, neighbor_id);
            self.add_neighbor(neighbor_id, new_id);
        }
    }

    fn delete_in_mem(&mut self, ext_id: String) {
        let id_hash = hash_id(&ext_id);
        if let Some(&int_id) = self.ext_to_int.get(&id_hash) {
            self.deleted.insert(int_id);
            self.valid_ids.remove(int_id);
            self.ext_to_int.remove(&id_hash);
            if Some(int_id) == self.enter_point {
                self.enter_point = self.valid_ids.max();
            }
        }
    }

    // --- Filter Logic ---

    fn is_expensive_filter(&self, filter: &Value) -> bool {
        match filter {
            Value::Object(map) => {
                if let Some(clauses) = map.get("$and").or(map.get("$or")) {
                    if let Value::Array(arr) = clauses {
                        return arr.iter().any(|f| self.is_expensive_filter(f));
                    }
                }
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    if self.num_store.contains_key(key) { return true; }
                    if let Value::Object(ops) = val {
                        for (op, _) in ops {
                            if ["$gt", "$gte", "$lt", "$lte"].contains(&op.as_str()) { return true; }
                        }
                    }
                }
                false
            },
            _ => false
        }
    }

    fn evaluate_filter(&self, filter: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        match filter {
            Value::Object(map) => {
                if let Some(clauses) = map.get("$and") {
                    if let Value::Array(arr) = clauses {
                        let (cheap, expensive): (Vec<&Value>, Vec<&Value>) = arr.iter()
                            .partition(|f| !self.is_expensive_filter(f));
                        let mut current_res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
                        for f in cheap {
                            current_res &= self.evaluate_filter(f, None);
                            if current_res.is_empty() { return current_res; }
                        }
                        for f in expensive {
                            current_res &= self.evaluate_filter(f, Some(&current_res));
                            if current_res.is_empty() { return current_res; }
                        }
                        return current_res;
                    }
                }
                if let Some(clauses) = map.get("$or") {
                    if let Value::Array(arr) = clauses {
                        let mut res = RoaringBitmap::new();
                        for sub in arr { res |= self.evaluate_filter(sub, None); }
                        if let Some(m) = mask { res &= m; }
                        return res;
                    }
                }
                if let Some(clause) = map.get("$not") {
                    let sub = self.evaluate_filter(clause, None);
                    let mut res = &self.valid_ids - &sub;
                    if let Some(m) = mask { res &= m; }
                    return res;
                }
                let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    res &= self.evaluate_field_condition(key, val, Some(&res));
                    if res.is_empty() { return res; }
                }
                res
            },
            _ => RoaringBitmap::new(),
        }
    }

    fn evaluate_field_condition(&self, field: &str, condition: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if condition.is_string() || condition.is_boolean() {
            return self.get_bitmap_str_eq(field, condition);
        }
        if condition.is_number() {
            return self.evaluate_numeric_op(field, "$eq", condition.as_f64().unwrap() as f32, mask);
        }
        if let Value::Object(op_map) = condition {
            let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
            for (op, val) in op_map {
                let op_res = match op.as_str() {
                    "$eq" => {
                        if val.is_number() { self.evaluate_numeric_op(field, "$eq", val.as_f64().unwrap() as f32, mask) }
                        else { self.get_bitmap_str_eq(field, val) }
                    },
                    "$ne" => {
                         if val.is_number() { self.evaluate_numeric_op(field, "$ne", val.as_f64().unwrap() as f32, mask) }
                         else { &self.valid_ids - &self.get_bitmap_str_eq(field, val) }
                    },
                    "$in" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr { u |= self.evaluate_field_condition(field, item, None); }
                        }
                        u
                    },
                    "$nin" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr { u |= self.evaluate_field_condition(field, item, None); }
                        }
                        &self.valid_ids - &u
                    },
                    "$gt" | "$gte" | "$lt" | "$lte" => {
                        if let Some(f) = val.as_f64() { self.evaluate_numeric_op(field, op, f as f32, mask) }
                        else { RoaringBitmap::new() }
                    },
                    _ => RoaringBitmap::new()
                };
                res &= op_res;
            }
            return res;
        }
        RoaringBitmap::new()
    }

    fn get_bitmap_str_eq(&self, field: &str, val: &Value) -> RoaringBitmap {
        let key_str = match val {
            Value::String(s) => s.clone(),
            Value::Bool(b) => if *b { "true".to_string() } else { "false".to_string() },
            _ => return RoaringBitmap::new(),
        };

        // --- FIX: Intercept ID lookup and use ext_to_int ---
        if field == "id" || field == "_id" {
             let h = hash_id(&key_str);
             let mut bm = RoaringBitmap::new();
             if let Some(&id) = self.ext_to_int.get(&h) {
                 if self.valid_ids.contains(id) { 
                     bm.insert(id); 
                 }
             }
             return bm;
        }

        self.str_index.get(field)
            .and_then(|m| m.get(&key_str))
            .cloned().unwrap_or_default()
    }

    fn evaluate_numeric_op(&self, field: &str, op: &str, target: f32, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if let Some(column) = self.num_store.get(field) {
            let mut matches: Vec<u32> = Vec::with_capacity(1024); 
            let use_sparse = if let Some(m) = mask { (m.len() as usize) < (self.ext_to_int.len() / 2) } else { false };

            if use_sparse {
                if let Some(m) = mask {
                    for id in m.iter() {
                        if let Some(&val) = column.get(id as usize) {
                            if val.is_nan() { continue; }
                            let is_match = match op {
                                "$gt" => val > target, "$gte" => val >= target,
                                "$lt" => val < target, "$lte" => val <= target,
                                "$eq" => (val - target).abs() < f32::EPSILON,
                                "$ne" => (val - target).abs() > f32::EPSILON,
                                _ => false
                            };
                            if is_match { matches.push(id); }
                        }
                    }
                    return RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap(); 
                }
            }

            for (i, &val) in column.iter().enumerate() {
                 let is_match = match op {
                    "$gt" => val > target, "$gte" => val >= target,
                    "$lt" => val < target, "$lte" => val <= target,
                    "$eq" => (val - target).abs() < f32::EPSILON,
                    "$ne" => (val - target).abs() > f32::EPSILON,
                    _ => false
                };
                if is_match { matches.push(i as u32); }
            }
            let mut bm = RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap();
            if let Some(m) = mask { bm &= m; } else { bm &= &self.valid_ids; }
            return bm;
        }
        RoaringBitmap::new()
    }

    fn _search_core(&self, target_vec: &[u8], ef: usize, filter: Option<&RoaringBitmap>) -> Vec<(u32, u32)> {
        if self.enter_point.is_none() { return vec![]; }
        let mut visited = RoaringBitmap::new();
        let mut candidates = BinaryHeap::new(); 
        let mut results = BinaryHeap::new();
        let ep = self.enter_point.unwrap();
        let d_ep = dist_sq_u8(target_vec, self.get_vector(ep));
        candidates.push(Reverse((d_ep, ep)));
        visited.insert(ep);
        if !self.deleted.contains(ep) && filter.map_or(true, |bm| bm.contains(ep)) { results.push((d_ep, ep)); }

        while let Some(Reverse((d_curr, curr_id))) = candidates.pop() {
            if results.len() >= ef && d_curr > results.peek().unwrap().0 { break; }
            for neighbor in self.get_neighbors(curr_id) {
                if !visited.contains(neighbor) {
                    visited.insert(neighbor);
                    let dist = dist_sq_u8(target_vec, self.get_vector(neighbor));
                    let threshold = if results.len() >= ef { results.peek().unwrap().0 } else { u32::MAX };
                    if dist <= threshold {
                        candidates.push(Reverse((dist, neighbor)));
                        if !self.deleted.contains(neighbor) && filter.map_or(true, |bm| bm.contains(neighbor)) {
                            results.push((dist, neighbor));
                            if results.len() > ef { results.pop(); }
                        }
                    }
                }
            }
        }
        results.into_sorted_vec()
    }
    
    fn compact_memory(&mut self) {
        self.ext_to_int.shrink_to_fit();
        self.num_store.shrink_to_fit();
        for col in self.num_store.values_mut() { col.shrink_to_fit(); }
    }
}

// --- Python Wrapper ---

#[pyclass]
struct LeanDB {
    inner: Arc<RwLock<CoreIndex>>,
    base_path: PathBuf,
    wal_writer: Arc<RwLock<BufWriter<File>>>,
}

#[pymethods]
impl LeanDB {
    #[new]
    fn new(storage_path: String) -> PyResult<Self> {
        let path = PathBuf::from(storage_path);
        std::fs::create_dir_all(&path)?;
        let snapshot_path = path.join("snapshot.bin");
        let wal_path = path.join("wal.bin");

        let mut index = CoreIndex::new(&path);
        
        if snapshot_path.exists() {
            let f = File::open(&snapshot_path)?;
            if let Ok(snap) = bincode::deserialize_from::<_, SnapshotData>(BufReader::new(f)) {
                index.enter_point = snap.enter_point;
                index.str_index = snap.str_index;
                index.num_store = snap.num_store;
                index.valid_ids = snap.valid_ids;
                index.deleted = snap.deleted;
                index.ext_to_int = snap.ext_to_int;
                index.ensure_capacity();
            }
        }

        if wal_path.exists() {
            let f = File::open(&wal_path)?;
            let mut reader = BufReader::new(f);
            while let Ok(entry) = bincode::deserialize_from::<_, WalEntry>(&mut reader) {
                match entry {
                    WalEntry::Insert { id, vec, meta } => index.insert_in_mem(id, vec, meta),
                    WalEntry::Delete { id } => index.delete_in_mem(id),
                }
            }
        }
        
        let wal_file = OpenOptions::new().create(true).append(true).open(&wal_path)?;
        Ok(LeanDB {
            inner: Arc::new(RwLock::new(index)),
            base_path: path,
            wal_writer: Arc::new(RwLock::new(BufWriter::new(wal_file))),
        })
    }

    fn add(&self, id: String, vector: Vec<f32>, metadata: String) -> PyResult<()> {
        let meta_map: Map<String, Value> = serde_json::from_str(&metadata)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON: {}", e)))?;
        let mut guard = self.inner.write();
        
        // WAL
        let mut writer = self.wal_writer.write();
        let entry = WalEntry::Insert { id: id.clone(), vec: vector.clone(), meta: meta_map.clone() };
        bincode::serialize_into(&mut *writer, &entry).unwrap();
        
        guard.insert_in_mem(id, vector, meta_map);
        Ok(())
    }

    fn persist(&self) -> PyResult<()> {
        let snapshot_path = self.base_path.join("snapshot.bin");
        let tmp_path = self.base_path.join("snapshot.bin.tmp");
        {
            let mut guard = self.inner.write();
            guard.compact_memory();
            guard.vec_mmap.flush()?;
            guard.graph_mmap.flush()?;
            guard.offset_mmap.flush()?;
            guard.ids_file.sync_data()?;
        } 
        {
            let guard = self.inner.read();
            let mut writer = BufWriter::with_capacity(1024 * 1024, File::create(&tmp_path)?);
            let view = SnapshotView {
                enter_point: guard.enter_point,
                str_index: &guard.str_index,
                num_store: &guard.num_store,
                valid_ids: &guard.valid_ids,
                deleted: &guard.deleted,
                ext_to_int: &guard.ext_to_int,
            };
            bincode::serialize_into(&mut writer, &view).unwrap();
            writer.flush()?;
        }
        std::fs::rename(&tmp_path, &snapshot_path)?;
        {
            let mut wal_guard = self.wal_writer.write();
            let file = wal_guard.get_mut();
            file.set_len(0)?;
            file.seek(SeekFrom::Start(0))?;
        }
        Ok(())
    }

    fn search(&self, vector: Vec<f32>, k: usize, filter_json: Option<String>) -> PyResult<Vec<(String, f32)>> {
        let mut guard = self.inner.write(); 
        let q_vec: Vec<u8> = vector.iter().take(DIM).map(|&x| quantize(x)).collect();
        
        let mut mask: Option<RoaringBitmap> = None;
        if let Some(json_str) = filter_json {
             if let Ok(filter_val) = serde_json::from_str::<Value>(&json_str) {
                 mask = Some(guard.evaluate_filter(&filter_val, None));
             }
        }

        let raw_results = guard._search_core(&q_vec, k * 5, mask.as_ref());
        
        let mut final_results = Vec::with_capacity(k);
        for (_d, idx) in raw_results.iter().take(k) {
            let s = guard.get_external_id(*idx);
            final_results.push((s, *_d as f32));
        }
        Ok(final_results)
    }
    
    fn count(&self) -> usize { self.inner.read().ext_to_int.len() }
    
    fn delete(&self, id: String) {
        let mut writer = self.wal_writer.write();
        let entry = WalEntry::Delete { id: id.clone() };
        bincode::serialize_into(&mut *writer, &entry).unwrap();
        self.inner.write().delete_in_mem(id);
    }
    
    fn delete_by_filter(&self, filter_json: String) -> PyResult<usize> {
        let filter_val: Value = serde_json::from_str(&filter_json)
             .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid Filter: {}", e)))?;
        let mut guard = self.inner.write();
        let mut writer = self.wal_writer.write();
        let matches = guard.evaluate_filter(&filter_val, None);
        
        let mut count = 0;
        for int_id in matches.iter() {
            let idx = int_id;
            let ext_id = guard.get_external_id(idx); 
            if !ext_id.is_empty() {
                let id_hash = hash_id(&ext_id);
                if guard.ext_to_int.contains_key(&id_hash) {
                    let entry = WalEntry::Delete { id: ext_id.clone() };
                    if bincode::serialize_into(&mut *writer, &entry).is_ok() {
                        guard.deleted.insert(idx);
                        guard.valid_ids.remove(idx);
                        guard.ext_to_int.remove(&id_hash);
                        count += 1;
                    }
                }
            }
        }
        if guard.deleted.contains(guard.enter_point.unwrap_or(u32::MAX)) {
            guard.enter_point = guard.valid_ids.max();
        }
        Ok(count)
    }
}

#[pymodule]
fn leanvec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<LeanDB>()?;
    Ok(())
}