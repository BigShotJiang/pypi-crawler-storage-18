from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from ._generated import (
    InstanceCreateRequest,
    InstanceRegisterRequest,
    RunRequest,
    RuntimeProfileUpsertRequest,
    ToolInvocationRequest,
)

InstanceCreateRequestBody = InstanceCreateRequest
InstanceRegisterRequestBody = InstanceRegisterRequest
RunRequestBody = RunRequest
RuntimeProfileUpsertRequestBody = RuntimeProfileUpsertRequest
ToolInvocationRequestBody = ToolInvocationRequest

class RuntimeGetRunStatusParams(BaseModel):
    run_id: str

class RuntimeGetRunResultParams(BaseModel):
    run_id: str

class RuntimeCancelRunParams(BaseModel):
    run_id: str

class RuntimeStreamRunEventsParams(BaseModel):
    run_id: str

class ToolRegistryGetToolParams(BaseModel):
    tool_id: str

class DaemonDeleteInstanceParams(BaseModel):
    instance_id: str

class DaemonUpsertRuntimeProfileParams(BaseModel):
    runtime_profile: str

class DaemonDeleteRuntimeProfileParams(BaseModel):
    runtime_profile: str

class DaemonListRunsParams(BaseModel):
    page_size: int | None = None
    page_token: str | None = None

class DaemonGetRunStatusParams(BaseModel):
    run_id: str

class DaemonGetRunResultParams(BaseModel):
    run_id: str

class DaemonGetRunTraceParams(BaseModel):
    run_id: str

class RuntimeHealthRequest(BaseModel):
    pass

class RuntimeVersionRequest(BaseModel):
    pass

class RuntimeCreateRunRequest(BaseModel):
    body: RunRequestBody

class RuntimeGetRunStatusRequest(BaseModel):
    params: RuntimeGetRunStatusParams

class RuntimeGetRunResultRequest(BaseModel):
    params: RuntimeGetRunResultParams

class RuntimeCancelRunRequest(BaseModel):
    params: RuntimeCancelRunParams

class RuntimeStreamRunEventsRequest(BaseModel):
    params: RuntimeStreamRunEventsParams

class ToolRegistryHealthRequest(BaseModel):
    pass

class ToolRegistryVersionRequest(BaseModel):
    pass

class ToolRegistryListToolsRequest(BaseModel):
    pass

class ToolRegistryGetToolRequest(BaseModel):
    params: ToolRegistryGetToolParams

class ToolRegistryInvokeToolRequest(BaseModel):
    body: ToolInvocationRequestBody

class DaemonHealthRequest(BaseModel):
    pass

class DaemonVersionRequest(BaseModel):
    pass

class DaemonListInstancesRequest(BaseModel):
    pass

class DaemonCreateInstancesRequest(BaseModel):
    body: InstanceCreateRequestBody

class DaemonDeleteInstanceRequest(BaseModel):
    params: DaemonDeleteInstanceParams

class DaemonRegisterInstanceRequest(BaseModel):
    body: InstanceRegisterRequestBody

class DaemonListRuntimeProfilesRequest(BaseModel):
    pass

class DaemonUpsertRuntimeProfileRequest(BaseModel):
    params: DaemonUpsertRuntimeProfileParams
    body: RuntimeProfileUpsertRequestBody

class DaemonDeleteRuntimeProfileRequest(BaseModel):
    params: DaemonDeleteRuntimeProfileParams

class DaemonListRunsRequest(BaseModel):
    params: DaemonListRunsParams

class DaemonSubmitRunRequest(BaseModel):
    body: RunRequestBody

class DaemonGetRunStatusRequest(BaseModel):
    params: DaemonGetRunStatusParams

class DaemonGetRunResultRequest(BaseModel):
    params: DaemonGetRunResultParams

class DaemonGetRunTraceRequest(BaseModel):
    params: DaemonGetRunTraceParams

__all__ = [
    'InstanceCreateRequestBody',
    'InstanceRegisterRequestBody',
    'RunRequestBody',
    'RuntimeProfileUpsertRequestBody',
    'ToolInvocationRequestBody',
    'RuntimeGetRunStatusParams',
    'RuntimeGetRunResultParams',
    'RuntimeCancelRunParams',
    'RuntimeStreamRunEventsParams',
    'ToolRegistryGetToolParams',
    'DaemonDeleteInstanceParams',
    'DaemonUpsertRuntimeProfileParams',
    'DaemonDeleteRuntimeProfileParams',
    'DaemonListRunsParams',
    'DaemonGetRunStatusParams',
    'DaemonGetRunResultParams',
    'DaemonGetRunTraceParams',
    'RuntimeHealthRequest',
    'RuntimeVersionRequest',
    'RuntimeCreateRunRequest',
    'RuntimeGetRunStatusRequest',
    'RuntimeGetRunResultRequest',
    'RuntimeCancelRunRequest',
    'RuntimeStreamRunEventsRequest',
    'ToolRegistryHealthRequest',
    'ToolRegistryVersionRequest',
    'ToolRegistryListToolsRequest',
    'ToolRegistryGetToolRequest',
    'ToolRegistryInvokeToolRequest',
    'DaemonHealthRequest',
    'DaemonVersionRequest',
    'DaemonListInstancesRequest',
    'DaemonCreateInstancesRequest',
    'DaemonDeleteInstanceRequest',
    'DaemonRegisterInstanceRequest',
    'DaemonListRuntimeProfilesRequest',
    'DaemonUpsertRuntimeProfileRequest',
    'DaemonDeleteRuntimeProfileRequest',
    'DaemonListRunsRequest',
    'DaemonSubmitRunRequest',
    'DaemonGetRunStatusRequest',
    'DaemonGetRunResultRequest',
    'DaemonGetRunTraceRequest',
]
