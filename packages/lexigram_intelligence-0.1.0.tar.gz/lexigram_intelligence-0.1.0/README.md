# lexigram-intelligence
