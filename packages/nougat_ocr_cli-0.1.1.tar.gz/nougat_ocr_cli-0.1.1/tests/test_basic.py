"""Basic functionality tests for nougat_wrapper."""

import pytest
from pathlib import Path
from nougat_wrapper import NougatOCR, OCRResult


def test_import():
    """Test that main classes can be imported."""
    assert NougatOCR is not None
    assert OCRResult is not None


def test_initialization():
    """Test model initialization."""
    ocr = NougatOCR()
    assert ocr.model is not None
    assert ocr.batch_size >= 1


@pytest.mark.skipif(not Path("test.pdf").exists(), reason="No test PDF")
def test_extract_text():
    """Test basic text extraction."""
    ocr = NougatOCR()
    result = ocr.extract_text(Path("test.pdf"))

    assert isinstance(result, OCRResult)
    assert isinstance(result.text, str)
    assert result.pages > 0
    assert result.placeholder_pages >= 0


def test_ocr_result_dataclass():
    """Test OCRResult structure."""
    result = OCRResult(text="Sample text", pages=5, placeholder_pages=1)
    assert result.text == "Sample text"
    assert result.pages == 5
    assert result.placeholder_pages == 1
