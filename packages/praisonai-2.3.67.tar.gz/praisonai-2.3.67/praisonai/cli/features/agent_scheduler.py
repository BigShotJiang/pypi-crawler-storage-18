"""
Agent Scheduler CLI Feature.

Provides CLI commands for scheduling agents to run 24/7 at regular intervals.
"""

import logging

logger = logging.getLogger(__name__)


class AgentSchedulerHandler:
    """Handler for agent scheduler CLI commands."""
    
    @staticmethod
    def handle_daemon_command(subcommand: str, args, unknown_args=None) -> int:
        """
        Handle daemon management commands (start, list, stop, logs, restart).
        
        Args:
            subcommand: Command to execute (start, list, stop, logs, restart)
            args: Parsed command-line arguments
            unknown_args: Additional arguments
            
        Returns:
            Exit code
        """
        from praisonai.scheduler.state_manager import SchedulerStateManager
        from praisonai.scheduler.daemon_manager import DaemonManager
        
        state_manager = SchedulerStateManager()
        daemon_manager = DaemonManager()
        
        if subcommand == "start":
            return AgentSchedulerHandler._handle_start(args, unknown_args, state_manager, daemon_manager)
        elif subcommand == "list":
            return AgentSchedulerHandler._handle_list(state_manager)
        elif subcommand == "stop":
            return AgentSchedulerHandler._handle_stop(unknown_args, state_manager, daemon_manager)
        elif subcommand == "logs":
            return AgentSchedulerHandler._handle_logs(unknown_args, daemon_manager)
        elif subcommand == "restart":
            return AgentSchedulerHandler._handle_restart(unknown_args, state_manager, daemon_manager)
        elif subcommand == "delete":
            return AgentSchedulerHandler._handle_delete(unknown_args, state_manager)
        else:
            print(f"Unknown subcommand: {subcommand}")
            return 1
    
    @staticmethod
    def _handle_start(args, unknown_args, state_manager, daemon_manager) -> int:
        """Handle 'schedule start' command."""
        from datetime import datetime
        
        if not unknown_args:
            print("❌ Error: Please provide scheduler name and task")
            print("\nUsage:")
            print('  praisonai schedule start <name> "Your task" --interval hourly')
            print("\nExample:")
            print('  praisonai schedule start news-checker "Check AI news" --interval hourly')
            return 1
        
        # Parse arguments
        name = unknown_args[0]
        task = unknown_args[1] if len(unknown_args) > 1 else None
        
        if not task:
            print("❌ Error: Please provide a task")
            return 1
        
        # Get options
        interval = getattr(args, 'schedule_interval', None) or 'hourly'
        max_retries = getattr(args, 'schedule_max_retries', None) or 3
        timeout = getattr(args, 'timeout', None)
        max_cost = getattr(args, 'max_cost', None)
        
        # Check if name already exists
        existing = state_manager.load_state(name)
        if existing and daemon_manager.get_status(existing.get('pid', 0))['is_alive']:
            print(f"❌ Error: Scheduler '{name}' is already running (PID: {existing['pid']})")
            print(f"   Use 'praisonai schedule stop {name}' to stop it first")
            return 1
        
        # Start daemon
        print(f"🚀 Starting scheduler '{name}'...")
        print(f"   Task: {task}")
        print(f"   Interval: {interval}")
        if timeout:
            print(f"   Timeout: {timeout}s")
        if max_cost:
            print(f"   Budget: ${max_cost}")
        
        pid = daemon_manager.start_scheduler_daemon(
            name=name,
            task=task,
            interval=interval,
            max_cost=max_cost,
            timeout=timeout,
            max_retries=max_retries
        )
        
        # Save state
        state = {
            "name": name,
            "pid": pid,
            "task": task,
            "interval": interval,
            "timeout": timeout,
            "max_cost": max_cost,
            "max_retries": max_retries,
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "executions": 0,
            "cost": 0.0
        }
        state_manager.save_state(name, state)
        
        print(f"\n✅ Scheduler '{name}' started successfully!")
        print(f"   PID: {pid}")
        print(f"   Logs: ~/.praisonai/logs/{name}.log")
        print(f"\nManage:")
        print(f"   praisonai schedule list")
        print(f"   praisonai schedule logs {name} -f")
        print(f"   praisonai schedule stop {name}")
        
        return 0
    
    @staticmethod
    def _handle_list(state_manager) -> int:
        """Handle 'schedule list' command."""
        states = state_manager.list_all()
        
        if not states:
            print("No schedulers running.")
            print("\nStart one with:")
            print('  praisonai schedule start <name> "Your task" --interval hourly')
            return 0
        
        # Clean up dead processes
        state_manager.cleanup_dead_processes()
        states = state_manager.list_all()
        
        # Display table
        print(f"\n{'Name':<20} {'Status':<10} {'PID':<8} {'Interval':<12} {'Task':<40}")
        print("=" * 90)
        
        for state in states:
            name = state.get('name', 'unknown')[:20]
            pid = state.get('pid', 0)
            status = "running" if state_manager.is_process_alive(pid) else "stopped"
            interval = state.get('interval', 'unknown')[:12]
            task = state.get('task', '')[:40]
            
            status_icon = "🟢" if status == "running" else "🔴"
            print(f"{name:<20} {status_icon} {status:<8} {pid:<8} {interval:<12} {task:<40}")
        
        print(f"\nTotal: {len(states)} scheduler(s)")
        return 0
    
    @staticmethod
    def _handle_stop(unknown_args, state_manager, daemon_manager) -> int:
        """Handle 'schedule stop' command."""
        if not unknown_args:
            print("❌ Error: Please provide scheduler name")
            print("\nUsage: praisonai schedule stop <name>")
            return 1
        
        name = unknown_args[0]
        state = state_manager.load_state(name)
        
        if not state:
            print(f"❌ Error: Scheduler '{name}' not found")
            print("\nList schedulers with: praisonai schedule list")
            return 1
        
        pid = state.get('pid')
        if not pid:
            print(f"❌ Error: No PID found for scheduler '{name}'")
            return 1
        
        print(f"🛑 Stopping scheduler '{name}' (PID: {pid})...")
        
        success = daemon_manager.stop_daemon(pid)
        
        if success:
            state['status'] = 'stopped'
            state_manager.save_state(name, state)
            print(f"✅ Scheduler '{name}' stopped successfully")
            return 0
        else:
            print(f"❌ Failed to stop scheduler '{name}'")
            return 1
    
    @staticmethod
    def _handle_logs(unknown_args, daemon_manager) -> int:
        """Handle 'schedule logs' command."""
        if not unknown_args:
            print("❌ Error: Please provide scheduler name")
            print("\nUsage: praisonai schedule logs <name> [-f]")
            return 1
        
        name = unknown_args[0]
        follow = '-f' in unknown_args or '--follow' in unknown_args
        
        if follow:
            print(f"📋 Following logs for '{name}' (Ctrl+C to stop)...")
            import subprocess
            log_file = daemon_manager.log_dir / f"{name}.log"
            if not log_file.exists():
                print(f"❌ Error: Log file not found for '{name}'")
                return 1
            
            try:
                subprocess.run(['tail', '-f', str(log_file)])
            except KeyboardInterrupt:
                print("\n✅ Stopped following logs")
            return 0
        else:
            logs = daemon_manager.read_logs(name, lines=50)
            if logs:
                print(f"📋 Last 50 lines of logs for '{name}':\n")
                print(logs)
                return 0
            else:
                print(f"❌ Error: No logs found for '{name}'")
                return 1
    
    @staticmethod
    def _handle_restart(unknown_args, state_manager, daemon_manager) -> int:
        """Handle 'schedule restart' command."""
        from datetime import datetime
        import time
        
        if not unknown_args:
            print("❌ Error: Please provide scheduler name")
            print("\nUsage: praisonai schedule restart <name>")
            return 1
        
        name = unknown_args[0]
        state = state_manager.load_state(name)
        
        if not state:
            print(f"❌ Error: Scheduler '{name}' not found")
            return 1
        
        print(f"🔄 Restarting scheduler '{name}'...")
        
        # Stop if running
        pid = state.get('pid')
        if pid and state_manager.is_process_alive(pid):
            daemon_manager.stop_daemon(pid)
            time.sleep(1)
        
        # Start again
        new_pid = daemon_manager.start_scheduler_daemon(
            name=name,
            task=state['task'],
            interval=state['interval'],
            max_cost=state.get('max_cost'),
            timeout=state.get('timeout'),
            max_retries=state.get('max_retries', 3)
        )
        
        state['pid'] = new_pid
        state['status'] = 'running'
        state['started_at'] = datetime.now().isoformat()
        state_manager.save_state(name, state)
        
        print(f"✅ Scheduler '{name}' restarted (PID: {new_pid})")
        return 0
    
    @staticmethod
    def _handle_delete(unknown_args, state_manager) -> int:
        """Handle 'schedule delete' command."""
        if not unknown_args:
            print("❌ Error: Please provide scheduler name")
            print("\nUsage: praisonai schedule delete <name>")
            return 1
        
        name = unknown_args[0]
        
        if state_manager.delete_state(name):
            print(f"✅ Scheduler '{name}' deleted from list")
            return 0
        else:
            print(f"❌ Error: Scheduler '{name}' not found")
            return 1
    
    @staticmethod
    def handle_schedule_command(args, unknown_args=None) -> int:
        """
        Handle the schedule command for running agents periodically.
        
        Supports two modes:
        1. YAML mode: praisonai schedule agents.yaml
        2. Prompt mode: praisonai schedule "Your task here" --interval hourly
        
        Args:
            args: Parsed command-line arguments
            unknown_args: Additional arguments after the command
            
        Returns:
            Exit code (0 for success, 1 for error)
        """
        try:
            from praisonai.scheduler import AgentScheduler
            from praisonaiagents import Agent
        except ImportError:
            print("Error: praisonai.scheduler or praisonaiagents module not found")
            print("Please ensure PraisonAI is properly installed")
            print("pip install praisonai praisonaiagents")
            return 1
        
        # Check if first arg is a YAML file or a prompt
        first_arg = unknown_args[0] if unknown_args else None
        is_yaml_mode = first_arg and (first_arg.endswith('.yaml') or first_arg.endswith('.yml'))
        
        # Get overrides from CLI
        interval_override = getattr(args, 'schedule_interval', None) or 'hourly'
        max_retries_override = getattr(args, 'schedule_max_retries', None) or 3
        timeout_override = getattr(args, 'timeout', None)
        max_cost_override = getattr(args, 'max_cost', None)
        verbose = getattr(args, 'verbose', False)
        
        # Set up logging - only show logs if verbose
        if verbose:
            logging.basicConfig(
                level=logging.INFO,
                format='[%(asctime)s] %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
        else:
            # Suppress scheduler logs in non-verbose mode
            logging.getLogger('praisonai.scheduler').setLevel(logging.WARNING)
        
        try:
            if is_yaml_mode:
                # YAML mode: Load from agents.yaml
                yaml_path = first_arg
                print(f"🤖 Loading agent configuration from: {yaml_path}")
                scheduler = AgentScheduler.from_yaml(
                    yaml_path=yaml_path,
                    interval_override=interval_override,
                    max_retries_override=max_retries_override,
                    timeout_override=timeout_override,
                    max_cost_override=max_cost_override
                )
            else:
                # Prompt mode: Create agent from direct prompt
                if not first_arg:
                    print("❌ Error: Please provide either a YAML file or a task prompt")
                    print("\nExamples:")
                    print("  praisonai schedule agents.yaml")
                    print('  praisonai schedule "Check news every hour" --interval hourly')
                    return 1
                
                task_prompt = first_arg
                print(f"🤖 Creating scheduler for task: {task_prompt[:60]}...")
                
                # Create a simple agent with the prompt
                agent = Agent(
                    name="Scheduled Agent",
                    role="Task Executor",
                    goal=task_prompt,
                    instructions=f"Execute this task: {task_prompt}",
                    verbose=verbose
                )
                
                # Create scheduler
                scheduler = AgentScheduler(
                    agent=agent,
                    task=task_prompt,
                    timeout=timeout_override,
                    max_cost=max_cost_override
                )
            
            # Display configuration
            agent_name = getattr(scheduler.agent, 'name', 'Agent')
            print(f"\n{'='*60}")
            print(f"🤖 Starting 24/7 {agent_name}")
            print(f"{'='*60}")
            print(f"Task: {scheduler.task[:80]}{'...' if len(scheduler.task) > 80 else ''}")
            
            # Get schedule info
            if is_yaml_mode:
                schedule_config = scheduler._yaml_schedule_config
                interval = interval_override or schedule_config.get('interval', 'hourly')
                max_retries = max_retries_override or schedule_config.get('max_retries', 3)
            else:
                interval = interval_override
                max_retries = max_retries_override
            
            print(f"Schedule: {interval}")
            print(f"Max Retries: {max_retries}")
            if scheduler.timeout:
                print(f"Timeout: {scheduler.timeout}s")
            if scheduler.max_cost:
                print(f"Budget: ${scheduler.max_cost}")
            print(f"{'='*60}\n")
            
            # Start scheduler
            print("⏰ Starting scheduler... (Press Ctrl+C to stop)\n")
            if is_yaml_mode:
                scheduler.start_from_yaml_config()
            else:
                scheduler.start(
                    schedule_expr=interval,
                    max_retries=max_retries,
                    run_immediately=True
                )
            
            # Keep running until interrupted
            try:
                while scheduler.is_running:
                    import time
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\n\n🛑 Stopping scheduler...")
                scheduler.stop()
                
                # Display final stats
                stats = scheduler.get_stats()
                print("\n📊 Final Statistics:")
                print(f"  Total Executions: {stats['total_executions']}")
                print(f"  Successful: {stats['successful_executions']}")
                print(f"  Failed: {stats['failed_executions']}")
                print(f"  Success Rate: {stats['success_rate']:.1f}%")
                print("\n✅ Agent stopped successfully\n")
                
            return 0
            
        except FileNotFoundError as e:
            print(f"❌ Error: {e}")
            print(f"\nMake sure {yaml_path} exists in the current directory.")
            print("\nExample agents.yaml structure:")
            print("""
framework: praisonai

agents:
  - name: "AI News Monitor"
    role: "News Analyst"
    instructions: "Search and summarize AI news"
    tools:
      - search_tool

task: "Search for latest AI news"

schedule:
  interval: "hourly"
  max_retries: 3
  run_immediately: true
""")
            return 1
            
        except ValueError as e:
            print(f"❌ Configuration Error: {e}")
            return 1
            
        except Exception as e:
            print(f"❌ Error: {e}")
            if verbose:
                import traceback
                traceback.print_exc()
            return 1
            
    @staticmethod
    def add_schedule_arguments(subparsers):
        """
        Add schedule subcommand and arguments to parser.
        
        Args:
            subparsers: Subparsers object from argparse
        """
        schedule_parser = subparsers.add_parser(
            'schedule',
            help='Schedule an agent to run continuously at regular intervals'
        )
        
        schedule_parser.add_argument(
            'schedule_yaml',
            nargs='?',
            default='agents.yaml',
            help='Path to agents.yaml file (default: agents.yaml)'
        )
        
        schedule_parser.add_argument(
            '--interval',
            dest='schedule_interval',
            type=str,
            help='Override schedule interval (e.g., "hourly", "*/30m", "daily")'
        )
        
        schedule_parser.add_argument(
            '--max-retries',
            dest='schedule_max_retries',
            type=int,
            help='Override maximum retry attempts (default: from YAML or 3)'
        )
        
        schedule_parser.add_argument(
            '--verbose', '-v',
            action='store_true',
            help='Enable verbose logging'
        )
        
        schedule_parser.set_defaults(func=AgentSchedulerHandler.handle_schedule_command)


def setup_scheduler_cli(subparsers):
    """
    Setup scheduler CLI commands.
    
    Args:
        subparsers: Subparsers object from argparse
    """
    AgentSchedulerHandler.add_schedule_arguments(subparsers)
