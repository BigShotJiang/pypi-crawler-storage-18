"""Agent configuration class."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, ClassVar, get_type_hints

from pydantic import BaseModel

if TYPE_CHECKING:
    from artificer.agents.mcp import MCPClient
    from artificer.agents.models import Model


# Default schemas for simple str -> str agents
class StringInput(BaseModel):
    """Default input schema for simple agents."""

    input: str


class StringOutput(BaseModel):
    """Default output schema for simple agents."""

    output: str


def _to_kebab_case(name: str) -> str:
    """Convert CamelCase to kebab-case, removing 'Agent' suffix."""
    # Remove Agent suffix
    if name.endswith("Agent"):
        name = name[:-5]
    # Insert hyphen before uppercase letters and lowercase everything
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1-\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", s1).lower()


class Agent:
    """Agent definition using class-based configuration.

    Define agents as subclasses with class attributes:

        class MyAgent(Agent):
            system_prompt = "You are helpful."
            model = my_model

        result = await MyAgent().run("Hello")

    For custom input/output schemas, add type hints to run():

        class MyAgent(Agent):
            system_prompt = "Process data."
            model = my_model

            async def run(self, data: MyInput) -> MyOutput:
                return await super().run(data)

    Agents auto-register by name when defined.
    """

    _agent_registry: ClassVar[dict[str, Any]] = {}

    # Class attributes (override in subclasses)
    name: str = ""
    system_prompt: str = ""
    model: Model
    mcp_client: MCPClient | None = None
    tools: list[str] = []
    subagents: list[Agent] = []
    max_iterations: int = 50
    _input_schema: type[BaseModel] = StringInput
    _output_schema: type[BaseModel] = StringOutput

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Auto-configure subclasses from class attributes and type hints."""
        super().__init_subclass__(**kwargs)

        # Derive name from class name if not set
        if not cls.name:
            cls.name = _to_kebab_case(cls.__name__)

        # Extract input/output schemas from run() type hints if overridden
        if "run" in cls.__dict__:
            try:
                hints = get_type_hints(cls.run)
                # Get first parameter type (after self) as input schema
                params = [v for k, v in hints.items() if k not in ("return", "self")]
                if params:
                    cls._input_schema = params[0]
                # Get return type as output schema
                if "return" in hints:
                    cls._output_schema = hints["return"]
            except Exception:
                pass  # Keep defaults if type hints fail

        # Register if we have required fields
        if cls.name and cls.system_prompt:
            Agent._agent_registry[cls.name] = cls

    async def run(self, data: Any, *, verbose: bool = False) -> Any:
        """Run the agent with the given input.

        Args:
            data: Input data (string or schema instance)
            verbose: If True, log detailed execution info

        Returns:
            The agent's output
        """
        from artificer.agents.runtime import RunResult, run_agent

        # Handle string input for simple agents
        if isinstance(data, str):
            input_data = self._input_schema(input=data)
        else:
            input_data = data

        result: RunResult = await run_agent(self, input_data, verbose=verbose)

        if result.error:
            raise RuntimeError(result.error)
        if result.output is None:
            raise RuntimeError(f"Agent terminated: {result.termination_reason}")

        return result.output
