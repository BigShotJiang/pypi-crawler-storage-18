"""Base prompts for agent system messages."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from artificer.agents.agent import Agent
    from artificer.agents.models.base import Tool


def _generate_tool_example(tool: Tool) -> str:
    """Generate an example CALL_TOOL action for a tool."""
    # Generate example arguments based on the tool's parameter schema
    example_args: dict[str, Any] = {}
    props = tool.parameters.get("properties", {})
    for param_name, param_schema in props.items():
        param_type = param_schema.get("type", "string")
        if param_type == "string":
            example_args[param_name] = f"<{param_name}>"
        elif param_type == "integer":
            example_args[param_name] = 0
        elif param_type == "number":
            example_args[param_name] = 0.0
        elif param_type == "boolean":
            example_args[param_name] = True
        elif param_type == "array":
            example_args[param_name] = []
        elif param_type == "object":
            example_args[param_name] = {}
        else:
            example_args[param_name] = f"<{param_name}>"

    action = {
        "action": "CALL_TOOL",
        "tool_name": tool.name,
        "arguments": example_args,
    }
    return json.dumps({"actions": [action]})


def _generate_subagent_example(subagent: Agent) -> str:
    """Generate an example SPAWN_SUBAGENT action for a subagent."""
    # Generate example input based on the subagent's input schema
    example_input: dict[str, Any] = {}
    schema = subagent._input_schema.model_json_schema()
    props = schema.get("properties", {})
    for param_name, param_schema in props.items():
        param_type = param_schema.get("type", "string")
        if param_type == "string":
            example_input[param_name] = f"<{param_name}>"
        elif param_type == "integer":
            example_input[param_name] = 0
        elif param_type == "number":
            example_input[param_name] = 0.0
        elif param_type == "boolean":
            example_input[param_name] = True
        elif param_type == "array":
            example_input[param_name] = []
        elif param_type == "object":
            example_input[param_name] = {}
        else:
            example_input[param_name] = f"<{param_name}>"

    action = {
        "action": "SPAWN_SUBAGENT",
        "subagent_name": subagent.name,
        "subagent_input": example_input,
    }
    return json.dumps({"actions": [action]})


def _generate_done_example(output_schema: dict[str, Any]) -> str:
    """Generate an example DONE action for the output schema."""
    example_output: dict[str, Any] = {}
    props = output_schema.get("properties", {})
    for param_name, param_schema in props.items():
        param_type = param_schema.get("type", "string")
        if param_type == "string":
            example_output[param_name] = f"<{param_name}>"
        elif param_type == "integer":
            example_output[param_name] = 0
        elif param_type == "number":
            example_output[param_name] = 0.0
        elif param_type == "boolean":
            example_output[param_name] = True
        elif param_type == "array":
            example_output[param_name] = []
        elif param_type == "object":
            example_output[param_name] = {}
        else:
            example_output[param_name] = f"<{param_name}>"

    action = {"action": "DONE", "output": example_output}
    return json.dumps({"actions": [action]})


def build_system_prompt(
    agent_prompt: str,
    output_schema: dict[str, Any],
    tools: list[Tool] | None = None,
    subagents: list[Agent] | None = None,
) -> str:
    """Build the full system prompt with all instructions and examples.

    Args:
        agent_prompt: The agent's custom system prompt.
        output_schema: JSON schema for the agent's output.
        tools: List of available MCP tools.
        subagents: List of available subagents.

    Returns:
        Complete system prompt with format instructions and examples.
    """
    sections = []

    # Header
    sections.append(
        """You are an AI agent operating in a structured action loop.

## CRITICAL: Response Format

You MUST respond with ONLY a JSON code block. No other text before or after.

Your response must be a JSON object with an "actions" array:

```json
{"actions": [{"action": "ACTION_TYPE", ...}]}
```

You can include multiple actions in the array to execute them in sequence."""
    )

    # Available actions section
    sections.append("## Available Actions")

    # CALL_TOOL section (only if tools available)
    if tools:
        tool_lines = ["### CALL_TOOL - Call an MCP tool", ""]
        tool_lines.append("Available tools:")
        for tool in tools:
            tool_lines.append(f"- **{tool.name}**: {tool.description}")
            params = tool.parameters.get("properties", {})
            if params:
                param_strs = []
                for pname, pschema in params.items():
                    ptype = pschema.get("type", "any")
                    pdesc = pschema.get("description", "")
                    if pdesc:
                        param_strs.append(f"{pname} ({ptype}): {pdesc}")
                    else:
                        param_strs.append(f"{pname} ({ptype})")
                tool_lines.append(f"  Parameters: {', '.join(param_strs)}")
        tool_lines.append("")
        tool_lines.append("Examples:")
        for tool in tools[:3]:  # Show examples for first 3 tools
            tool_lines.append("```json")
            tool_lines.append(_generate_tool_example(tool))
            tool_lines.append("```")
        sections.append("\n".join(tool_lines))

    # SPAWN_SUBAGENT section (only if subagents available)
    if subagents:
        subagent_lines = ["### SPAWN_SUBAGENT - Delegate to a subagent", ""]
        subagent_lines.append("Available subagents:")
        for subagent in subagents:
            subagent_lines.append(f"- **{subagent.name}**")
            input_schema = subagent._input_schema.model_json_schema()
            output_schema_sub = subagent._output_schema.model_json_schema()
            subagent_lines.append(
                f"  Input: {json.dumps(input_schema.get('properties', {}))}"
            )
            subagent_lines.append(
                f"  Output: {json.dumps(output_schema_sub.get('properties', {}))}"
            )
        subagent_lines.append("")
        subagent_lines.append("Examples:")
        for subagent in subagents[:2]:  # Show examples for first 2 subagents
            subagent_lines.append("```json")
            subagent_lines.append(_generate_subagent_example(subagent))
            subagent_lines.append("```")
        sections.append("\n".join(subagent_lines))

    # DONE section (always present)
    done_lines = [
        "### DONE - Complete with final output",
        "",
        "Use this when finished. The output MUST match the schema exactly.",
        "",
        "Output schema:",
        "```json",
        json.dumps(output_schema, indent=2),
        "```",
        "",
        "Example:",
        "```json",
        _generate_done_example(output_schema),
        "```",
    ]
    sections.append("\n".join(done_lines))

    # Rules section
    sections.append(
        """## Rules

1. Your entire response must be a single JSON code block - no text before or after
2. Always wrap actions in an "actions" array, even for a single action
3. Use the DONE action when the task is complete
4. The "output" field in DONE must match the output schema exactly
5. Do not explain or narrate - just output the JSON"""
    )

    # Common mistakes section
    sections.append(
        """## Common Mistakes to Avoid

WRONG - text before JSON:
Let me search for that.
```json
{"actions": [{"action": "CALL_TOOL", "tool_name": "x", "arguments": {}}]}
```

WRONG - text after JSON:
```json
{"actions": [{"action": "DONE", "output": {"result": "done"}}]}
```
I hope this helps!

WRONG - missing "actions" array wrapper:
```json
{"action": "DONE", "output": {"result": "done"}}
```

CORRECT - only the JSON block, with actions array:
```json
{"actions": [{"action": "DONE", "output": {"result": "done"}}]}
```

CORRECT - multiple actions in one response:
```json
{"actions": [
  {"action": "CALL_TOOL", "tool_name": "search", "arguments": {"q": "foo"}},
  {"action": "CALL_TOOL", "tool_name": "search", "arguments": {"q": "bar"}}
]}
```"""
    )

    # Add agent-specific prompt
    if agent_prompt:
        sections.append(f"---\n\n## Your Task\n\n{agent_prompt}")

    return "\n\n".join(sections)
