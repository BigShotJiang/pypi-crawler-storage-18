from abc import ABC, abstractmethod

from pandas.core.frame import DataFrame as PandasDataFrame


class DataPipeline(ABC):
    @abstractmethod
    def run(self) -> PandasDataFrame:
        pass
