"""ProtocolPolicer resource exports."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from f5xc_py_substrate.resources.protocol_policer.models import *
    from f5xc_py_substrate.resources.protocol_policer.resource import ProtocolPolicerResource

# Cache for lazy-loaded modules
_models_module = None


def __getattr__(name: str):
    """Lazy load exports."""
    global _models_module

    if name == "ProtocolPolicerResource":
        from f5xc_py_substrate.resources.protocol_policer.resource import ProtocolPolicerResource
        return ProtocolPolicerResource

    # Load models module once and cache it
    if _models_module is None:
        _models_module = importlib.import_module(
            "f5xc_py_substrate.resources.protocol_policer.models"
        )

    # Try to get attribute from models
    try:
        return getattr(_models_module, name)
    except AttributeError:
        pass

    raise AttributeError(f"module 'f5xc_py_substrate.resources.protocol_policer' has no attribute '{name}'")


__all__ = [
    "ProtocolPolicerResource",
    "ProtobufAny",
    "ObjectCreateMetaType",
    "ObjectRefType",
    "DnsType",
    "IcmpType",
    "TcpType",
    "UdpType",
    "ProtocolType",
    "ProtocolPolicerType",
    "CreateSpecType",
    "CreateRequest",
    "ObjectGetMetaType",
    "GetSpecType",
    "InitializerType",
    "StatusType",
    "InitializersType",
    "ViewRefType",
    "SystemObjectGetMetaType",
    "CreateResponse",
    "DeleteRequest",
    "ObjectReplaceMetaType",
    "ReplaceSpecType",
    "ReplaceRequest",
    "ConditionType",
    "StatusMetaType",
    "StatusObject",
    "GetResponse",
    "ErrorType",
    "ListResponseItem",
    "ListResponse",
    "ReplaceResponse",
    "Spec",
]
