"""
suck-my-d-pussy - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from suck-my-d-pussy!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "suck-my-d-pussy",
        "version": "2.3.2",
        "description": "A useful Python package"
    }

# Package version
__version__ = "2.3.2"
