# embbedFirmata

embbedFirmata is a minimal and experimental Firmata-based Python library
designed to communicate directly with Arduino boards over serial.

⚠️ **This library is in early testing stage**

---

## ⚙️ Supported Boards

Currently supported boards:

- Arduino Uno ✅

More boards may be added in the future.

---

## 📦 Requirements

- Python 3.8+
- pyserial 3.5
- Arduino running **StandardFirmata**

---

## 🚀 Example Usage

Basic example controlling the onboard LED and reading an analog pin:

```python
from embbedFirmata import *
import time

ardu = ArduinoUno()

ardu.start()

ardu.pinMode(13, OUTPUT)
ardu.pinMode(0, ANALOG)

ardu.sample()

while True:
    ardu.digitalWrite(13, 1)
    time.sleep(1)

    ardu.digitalWrite(13, 0)
    time.sleep(1)

    print(ardu.analogRead(0))
