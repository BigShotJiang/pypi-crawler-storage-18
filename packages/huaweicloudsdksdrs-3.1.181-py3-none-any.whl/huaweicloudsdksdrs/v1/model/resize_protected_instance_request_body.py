# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResizeProtectedInstanceRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'resize': 'ResizeProtectedInstanceRequestParams'
    }

    attribute_map = {
        'resize': 'resize'
    }

    def __init__(self, resize=None):
        r"""ResizeProtectedInstanceRequestBody

        The model defined in huaweicloud sdk

        :param resize: 
        :type resize: :class:`huaweicloudsdksdrs.v1.ResizeProtectedInstanceRequestParams`
        """
        
        

        self._resize = None
        self.discriminator = None

        self.resize = resize

    @property
    def resize(self):
        r"""Gets the resize of this ResizeProtectedInstanceRequestBody.

        :return: The resize of this ResizeProtectedInstanceRequestBody.
        :rtype: :class:`huaweicloudsdksdrs.v1.ResizeProtectedInstanceRequestParams`
        """
        return self._resize

    @resize.setter
    def resize(self, resize):
        r"""Sets the resize of this ResizeProtectedInstanceRequestBody.

        :param resize: The resize of this ResizeProtectedInstanceRequestBody.
        :type resize: :class:`huaweicloudsdksdrs.v1.ResizeProtectedInstanceRequestParams`
        """
        self._resize = resize

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResizeProtectedInstanceRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
