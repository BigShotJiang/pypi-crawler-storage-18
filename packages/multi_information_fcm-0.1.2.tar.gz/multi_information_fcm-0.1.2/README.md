# Multi-information-FCM
Install with `pip install .`