"""Tests for prompt handlers."""
