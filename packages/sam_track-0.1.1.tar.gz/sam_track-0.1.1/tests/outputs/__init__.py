"""Tests for output writers."""
