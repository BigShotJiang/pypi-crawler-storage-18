from __future__ import annotations

"""
Policy artifacts for the Readiness Adjustment Layer (RAL).

This module defines portable, immutable policy objects produced by offline
optimization and consumed by deterministic evaluation and production workflows.

Responsibilities:
- Represent learned RAL parameters (global and optional segment-level uplifts)
- Provide a stable, serializable contract between optimization and evaluation
- Support audit and governance workflows

Non-responsibilities:
- Learning or tuning parameters
- Applying policies to data
- Defining metric or loss functions

Design philosophy:
Policies are artifacts, not algorithms. They encode *decisions* derived from
optimization, not the optimization process itself.
"""

from dataclasses import dataclass
from typing import Optional, Sequence
import pandas as pd

@dataclass(frozen=True)
class RALPolicy:
    r"""Portable policy artifact for the Readiness Adjustment Layer (RAL).

    A :class:`~eb_optimization.policies.ral_policy.RALPolicy` is the *output* of an
    offline tuning process (e.g., grid search or evolutionary optimization) and the
    *input* to deterministic evaluation / production application.

    Conceptually, RAL applies a multiplicative uplift to a baseline forecast:

    $$ \hat{y}^{(r)} = u \cdot \hat{y} $$

    where `u` can be either:

    - a **global uplift** (`global_uplift`), applied to all rows, and/or
    - **segment-level** uplifts stored in `uplift_table`, keyed by `segment_cols`

    Segment-level uplifts must fall back to the global uplift for unseen segment
    combinations at application time.

    Attributes
    ----------
    global_uplift
        The global multiplicative uplift used as a fallback and baseline readiness adjustment.
    segment_cols
        The segmentation columns used to key `uplift_table`. Empty means "global-only".
    uplift_table
        Optional DataFrame with columns `[*segment_cols, "uplift"]` containing
        segment-level uplifts. If `None` or empty, the policy is global-only.

    Notes
    -----
    This dataclass is intentionally simple and serializable. It is meant to be:

    - produced offline in `eb-optimization`
    - applied deterministically in `eb-evaluation`
    - loggable/auditable as part of operational governance

    The policy does *not* encode metric definitions or optimization state—only the
    artifacts needed to execute the adjustment.
    """

    global_uplift: float
    segment_cols: Sequence[str] = ()
    uplift_table: Optional[pd.DataFrame] = None

    def is_segmented(self) -> bool:
        """Return True if the policy contains segment-level uplifts."""
        return bool(self.segment_cols) and self.uplift_table is not None and not self.uplift_table.empty

    def adjust_forecast(self, df: pd.DataFrame, forecast_col: str) -> pd.Series:
        """Apply the RAL policy to adjust the forecast values.

        This method applies the global uplift to all rows, and applies segment-level uplifts
        if the policy is segmented and matching segments exist in the `uplift_table`.

        Parameters
        ----------
        df : pd.DataFrame
            The input DataFrame containing the forecast to adjust.
        forecast_col : str
            The name of the column in `df` containing the forecast values to adjust.

        Returns
        -------
        pd.Series
            A series with the adjusted forecast values.
        """
        # Start with the global uplift applied to the forecast column
        adjusted_forecast = df[forecast_col] * self.global_uplift

        # Apply segment-level uplifts if available
        if self.is_segmented():
            # Merge uplift_table with the DataFrame based on segment columns
            uplift_df = df.merge(self.uplift_table, on=self.segment_cols, how="left")
            # Apply the segment-level uplift (if available) to the forecast
            uplifted_forecast = adjusted_forecast * uplift_df["uplift"].fillna(1.0)  # Default to 1.0 if no uplift
            return uplifted_forecast
        return adjusted_forecast

    def transform(self, df: pd.DataFrame, forecast_col: str) -> pd.DataFrame:
        """Transform the input DataFrame by applying the forecast adjustment.

        This method applies the RAL policy to adjust the forecast column and adds a new column
        with the adjusted forecast.

        Parameters
        ----------
        df : pd.DataFrame
            The input DataFrame containing the forecast to adjust.
        forecast_col : str
            The name of the column in `df` containing the forecast values to adjust.

        Returns
        -------
        pd.DataFrame
            The transformed DataFrame with the adjusted forecast values added.
        """
        df_copy = df.copy()
        adjusted_forecast = self.adjust_forecast(df_copy, forecast_col)
        df_copy["readiness_forecast"] = adjusted_forecast
        return df_copy