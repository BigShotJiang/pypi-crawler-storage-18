# Copyright (C) 2006-2017 Canonical Ltd
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

"""Launchpad.net integration plugin.

This plugin provides facilities for working with code hosted on Launchpad
(http://launchpad.net).  It provides a directory service for referring to
Launchpad repositories using the "lp:" prefix.  For example,
lp:~username/project/branch-name can be used to refer to a specific repository.

This plugin provides a bug tracker so that "brz commit --fixes lp:1234" will
record that revision as fixing Launchpad's bug 1234.

The plugin also provides the following commands:

    launchpad-login: Show or set the Launchpad user ID
    launchpad-open: Open a Launchpad page in your web browser

"""

# see http://wiki.bazaar.canonical.com/Specs/BranchRegistrationTool

from ... import version_info  # noqa: F401
from ...commands import plugin_cmds
from ...directory_service import directories
from ...help_topics import topic_registry

for klsname, aliases in [
    ("cmd_launchpad_open", ["lp-open"]),
    ("cmd_launchpad_login", ["lp-login"]),
    ("cmd_launchpad_logout", ["lp-logout"]),
    ("cmd_lp_find_proposal", []),
]:
    plugin_cmds.register_lazy(klsname, aliases, "breezy.plugins.launchpad.cmds")


def _register_directory():
    directories.register_lazy(
        "lp:",
        "breezy.plugins.launchpad.lp_directory",
        "LaunchpadDirectory",
        "Launchpad-based directory service",
    )


_register_directory()


def load_tests(loader, basic_tests, pattern):
    testmod_names = [
        "test_account",
        "test_lp_api",
        "test_lp_directory",
        "test_lp_login",
        "test_uris",
    ]
    basic_tests.addTest(
        loader.loadTestsFromModuleNames(
            ["{}.{}".format(__name__, tmn) for tmn in testmod_names]
        )
    )
    return basic_tests


_launchpad_help = """Integration with Launchpad.net

Launchpad.net provides code hosting with integrated bug and
specification tracking.

The brz client (through the plugin called 'launchpad') has special
features to communicate with Launchpad:

    * The launchpad-login command tells Breezy your Launchpad user name.

    * The 'lp:' transport uses Launchpad as a directory service: for example
      'lp:project' refers to the main branch of a project. You can also use
      the 'lp:' transport to refer to specific repositories, e.g.
      lp:~user/project/branch.

    * The 'lp:' bug tracker alias can expand launchpad bug numbers to their
      URLs for use with 'brz commit --fixes', e.g. 'brz commit --fixes lp:12345'
      will record a revision property that marks that revision as fixing
      Launchpad bug 12345. When you push to Launchpad it will
      automatically be linked to the bug report.

For more information see http://help.launchpad.net/
"""
topic_registry.register("launchpad", _launchpad_help, "Using Breezy with Launchpad.net")


from ...forge import forges

forges.register_lazy("launchpad", __name__ + ".forge", "Launchpad")
