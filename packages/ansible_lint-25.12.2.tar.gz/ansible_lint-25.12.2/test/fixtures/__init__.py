"""Fixtures used in tests."""
