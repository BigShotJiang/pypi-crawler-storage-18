
__version__ = "0.2.2"
__author__ = "asyncuvkit"

# 自动安装 import hook
from . import asyncuvkit

__all__ = ['asyncuvkit']
