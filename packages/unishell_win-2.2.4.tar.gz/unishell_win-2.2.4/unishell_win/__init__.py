from .regedit import *
