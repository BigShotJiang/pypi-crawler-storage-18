KeePass2 Merger
===============

![PyPI](https://img.shields.io/pypi/v/keepass2-merger?logo=pypi&color=brightgreen)
![Python Version](https://img.shields.io/pypi/pyversions/keepass2-merger?logo=python)
![Tests](https://img.shields.io/github/actions/workflow/status/Karol-G/keepass2-merger/workflow.yml?branch=main&logo=github)
![Copier Template](https://img.shields.io/badge/copier-template-blue?logo=jinja)
![License](https://img.shields.io/github/license/Karol-G/keepass2-merger)

A python package to interactively merge two KeePass2 databases.

## Installation

You can install keepass2-merger via [pip](https://pypi.org/project/keepass2-merger/):
```bash
pip install keepass2-merger
```

## Usage

```python
from keepass2_merger import __version__

print(__version__)
```

## Contributing

Contributions are welcome! Please open a pull request with clear changes and add tests when appropriate.

## Issues

Found a bug or have a request? Open an issue at https://github.com/Karol-G/keepass2-merger/issues.

## License

Distributed under the MIT license. See `LICENSE` for details.
