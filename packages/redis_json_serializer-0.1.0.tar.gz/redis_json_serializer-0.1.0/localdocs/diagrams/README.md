# Диаграммы архитектуры redis-json-serializer

Набор диаграмм для визуализации архитектуры и процессов библиотеки.

## Список диаграмм

### 1. `architecture.mmd` - Общая архитектура
Показывает основные компоненты системы и их взаимосвязи:
- Публичное API
- Ядро сериализации (включая namespace wrapper с константами NS_KEY, DATA_KEY и Marks)
- Реестр моделей (REGISTERED_MODELS, MODEL_ALIASES)
- Утилиты
- Интеграции (AiocacheJsonSerializer)

**Актуализация (Issue #007, #008)**:
- Добавлены константы NS_KEY, DATA_KEY для namespace wrapper
- Marks включает все маркеры: MODEL, SET, DATE, DATETIME, DECIMAL, OBJECT_ID, TUPLE
- `OrJsonSerializer` переименован в `AiocacheJsonSerializer`

### 2. `pack_flow.mmd` - Процесс упаковки (pack)
Последовательность обработки объектов при сериализации:
- Проверка простых типов (оптимизирована первая)
- Dispatch-таблица для O(1) поиска (date, Decimal, set, ObjectId)
- Обработка Pydantic с `mode='python'` и проверкой регистрации
- Обработка dataclass с итерацией по полям вручную (не `asdict()`)
- Обработка коллекций (tuple с маркером TUPLE, list, dict)
- Проверка Response в конце (редкий случай)

**Актуализация (Issue #001, #002, #008)**:
- Pydantic использует `model_dump(mode='python')` для сохранения вложенных моделей
- Dataclass использует итерацию по полям вручную (не `asdict()`) для сохранения маркеров
- `tuple` обрабатывается отдельно с маркером `TUPLE` (не преобразуется в list)
- `RegistrationError` вместо `TypeError` для незарегистрированных моделей

### 3. `unpack_flow.mmd` - Процесс распаковки (unpack)
Последовательность обработки при десериализации:
- Обработка namespace-обёртки через константы NS_KEY, DATA_KEY
- Распознавание маркеров типов (MODEL, DATE, DATETIME, DECIMAL, OBJECT_ID, SET, TUPLE)
- Десериализация моделей (с проверкой регистрации)
- Проброс expected_type в коллекции (list, dict, set, tuple)
- Преобразование строк только при expected_type (без агрессивной конвертации)
- Восстановление tuple через маркер TUPLE

**Актуализация (Issue #003, #004, #006, #007, #008)**:
- ✅ Удалена агрессивная конвертация ISO строк (конвертация только при `expected_type`)
- ✅ Добавлен проброс `expected_type` в `set` через обновленную сигнатуру обработчиков
- ✅ Добавлена обработка маркера `TUPLE` для восстановления tuple
- ✅ Использование констант NS_KEY, DATA_KEY вместо строковых литералов
- ✅ `TypeError` вместо `NotImplementedError` для неподдерживаемых типов
- ✅ Обработка всех маркеров через единый узел `CheckMarker`

### 4. `registry_flow.mmd` - Регистрация моделей
Процесс регистрации моделей через `@register_model()`:
- Проверка типа (Pydantic/dataclass)
- Генерация ключа (alias или fallback через module.qualname)
- Проверка дубликатов (строгое поведение: `RegistrationError` при повторной регистрации)
- Сохранение в REGISTERED_MODELS и MODEL_ALIASES

**Актуализация (Issue #005)**:
- ✅ Повторная регистрация того же класса выбрасывает `RegistrationError` (не warning)
- ✅ Строгое поведение для безопасности в production

### 5. `dispatch_tables.mmd` - Dispatch-таблицы
Архитектурное решение для O(1) поиска обработчиков:
- Инициализация таблиц в `__init__()`
- `_pack_handlers` для типов при упаковке (date, Decimal, set, ObjectId)
- `_unpack_handlers` для маркеров при распаковке (DATE, DATETIME, DECIMAL, OBJECT_ID, SET, TUPLE)
- Сигнатура обработчиков: `(dict, expected_type)` для поддержки проброса типов
- Fallback логика для моделей и коллекций

**Актуализация (Issue #004, #008)**:
- ✅ Добавлен маркер `TUPLE` в `_unpack_handlers`
- ✅ Обработчики принимают `expected_type` для проброса типов в коллекции (сигнатура: `(dict, expected_type)`)
- ⚠️ `datetime.datetime` удален из `_pack_handlers` (обрабатывается orjson нативно, если используется passthrough - спорное решение)

### 6. `serialization_cycle.mmd` - Полный цикл сериализации
Sequence диаграмма взаимодействия компонентов:
- Запись в кэш (Application → aiocache → AiocacheJsonSerializer → JsonSerializer → Redis)
- Чтение из кэша (обратный процесс)
- Обработка Pydantic моделей через ModelRegistry

**Актуализация**:
- `OrJsonSerializer` переименован в `AiocacheJsonSerializer` (решение пользователя)

### 7. `key_generation.mmd` - Генерация ключей кэша
Процесс создания стабильных ключей для кэширования:
- Получение module.qualname функции
- Хэширование аргументов с сохранением порядка
- Комбинирование в финальный ключ

## Как использовать

### Просмотр в редакторе
Большинство современных редакторов (VS Code, PyCharm) поддерживают Mermaid через расширения.

### Онлайн просмотр
1. Скопируйте содержимое `.mmd` файла (без тройных backticks)
2. Вставьте на https://mermaid.live/
3. Диаграмма отобразится автоматически

### Экспорт в изображения
Используйте инструменты:
- [Mermaid CLI](https://github.com/mermaid-js/mermaid-cli)
- [Mermaid Live Editor](https://mermaid.live/) - экспорт в PNG/SVG

## Примечания

- Все диаграммы используют синтаксис Mermaid
- Диаграммы обновляются при изменении архитектуры
- Для сложных процессов создаются отдельные диаграммы
- Диаграммы оптимизированы на основе рекомендаций AI-анализа

## История обновлений

### Версия 3.0 (актуализация после issues, 2024-12-23)
**Критические исправления:**
- Issue #001: Dataclass использует итерацию по полям вручную (не `asdict()`) - `pack_flow.mmd`
- Issue #002: Pydantic использует `mode='python'` - `pack_flow.mmd`
- Issue #003: Удалена агрессивная конвертация ISO строк - `unpack_flow.mmd`
- Issue #004: Добавлен проброс `expected_type` в `set` - `unpack_flow.mmd`, `dispatch_tables.mmd`
- Issue #005: Строгое поведение при повторной регистрации - `registry_flow.mmd`, `registration_flow.mmd`
- Issue #006: `NotImplementedError` → `TypeError` - `unpack_flow.mmd`
- Issue #007: Константы NS_KEY, DATA_KEY - `architecture.mmd`, `unpack_flow.mmd`
- Issue #008: Маркер TUPLE для tuple - `pack_flow.mmd`, `unpack_flow.mmd`, `dispatch_tables.mmd`, `architecture.mmd`

**Обновления:**
- Все диаграммы актуализированы в соответствии с исправлениями из issues
- `OrJsonSerializer` → `AiocacheJsonSerializer` во всех диаграммах
- Добавлен маркер `TUPLE` во все соответствующие диаграммы
- Обновлена сигнатура обработчиков для поддержки `expected_type`

### Версия 2.0 (после анализа Claude Sonnet 4.5)
- Оптимизирован порядок проверок в `pack_flow.mmd`
- Добавлена обработка Decimal, ObjectId в `unpack_flow.mmd`
- Улучшена диаграмма архитектуры (добавлены REGISTERED_MODELS, MODEL_ALIASES)
- Созданы новые диаграммы: `registration_flow.mmd`, `dispatch_tables.mmd`, `serialization_cycle.mmd`

**Примечание:** Обработка ISO datetime строк была удалена в версии 3.0 (Issue #003)

### Версия 1.0 (после анализа GPT-5 и Gemini)
- Добавлена обработка namespace wrapper
- Уточнено поведение tuple (преобразование в list)
- Добавлен RegistrationError для незарегистрированных моделей
- Marks вместо TypeMarks

