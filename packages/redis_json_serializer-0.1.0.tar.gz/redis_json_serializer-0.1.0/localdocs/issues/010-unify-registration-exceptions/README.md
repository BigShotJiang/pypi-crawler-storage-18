# Issue #010: Единообразие исключений при регистрации моделей

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический (перед релизом)  
**Источник:** GPT-5  
**Файл:** `src/redis_json_serializer/registry.py`

---

## Проблема

При регистрации моделей используются разные типы исключений для похожих ситуаций:
- Повторная регистрация того же класса → `RegistrationError` ✅
- Конфликт алиаса с другим классом → `ValueError` ❌

Для консистентности API лучше использовать `RegistrationError` в обоих случаях.

### Текущий код

```python
# registry.py, строки 96-109
if model_key in REGISTERED_MODELS:
    existing_cls = REGISTERED_MODELS[model_key]
    if existing_cls is cls:
        # Строгий режим: повторная регистрация не допускается
        raise RegistrationError(  # ✅ Правильно
            f"Model {cls} already registered with key '{model_key}'. "
            "Duplicate registration is not allowed."
        )
    else:
        raise ValueError(  # ❌ Не консистентно
            f"Duplicate alias '{model_key}': already registered for {existing_cls}, "
            f"cannot register {cls}"
        )
```

### Почему это проблема

- ❌ Нарушение консистентности API - разные типы исключений для похожих ситуаций
- ❌ Сложнее обрабатывать ошибки - нужно ловить два типа исключений
- ❌ Не соответствует семантике - обе ситуации связаны с регистрацией

---

## Решение

✅ **РЕАЛИЗОВАНО** Заменён `ValueError` на `RegistrationError` для консистентности

### Реализованный код

**Файл:** `src/redis_json_serializer/registry.py`, функция `register_model()` (строки 105-109)

```python
# Проверка дубликатов
if model_key in REGISTERED_MODELS:
    existing_cls = REGISTERED_MODELS[model_key]
    if existing_cls is cls:
        # Строгий режим: повторная регистрация не допускается
        raise RegistrationError(
            f"Model {cls} already registered with key '{model_key}'. "
            "Duplicate registration is not allowed."
        )
    else:
        # Конфликт алиаса с другим классом - тоже RegistrationError
        raise RegistrationError(  # ← Заменено ValueError на RegistrationError
            f"Duplicate alias '{model_key}': already registered for {existing_cls}, "
            f"cannot register {cls}"
        )
```

**Также обновлены:**
- Docstring функции `register_model()` (строка 77): `ValueError` → `RegistrationError`
- Docstring метода `ModelRegistry.register()` (строка 154): `ValueError` → `RegistrationError`
- Тест `test_duplicate_alias_raises` (строка 57): ожидание `ValueError` → `RegistrationError`

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** При конфликте алиаса выбрасывается `RegistrationError` (не `ValueError`)
- ✅ **ВЫПОЛНЕНО** Сообщение об ошибке информативное
- ✅ **ВЫПОЛНЕНО** Все существующие тесты обновлены и проходят
- ✅ **ВЫПОЛНЕНО** Консистентность API восстановлена

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **Обновить существующие тесты:**

**Файл:** `tests/test_registry.py`

```python
def test_duplicate_alias_raises_registration_error(self):
    """Test that duplicate alias raises RegistrationError (not ValueError)."""
    from redis_json_serializer.registry import RegistrationError
    
    @register_model("test.duplicate.alias")
    class Model1(BaseModel):
        id: str
    
    # Попытка зарегистрировать другой класс с тем же алиасом
    with pytest.raises(RegistrationError, match="Duplicate alias"):  # ← RegistrationError, не ValueError
        @register_model("test.duplicate.alias")
        class Model2(BaseModel):
            name: str
```

**Существующий тест:** `TestRegisterModel::test_duplicate_alias_raises` (если есть)

**Статус теста:** ✅ Все 49 тестов проходят после изменений

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/registry.py`
   - ✅ Заменён `ValueError` на `RegistrationError` в функции `register_model()` (строка 106)
   - ✅ Обновлён docstring функции `register_model()` (строка 77)
   - ✅ Обновлён docstring метода `ModelRegistry.register()` (строка 154)

2. **Файл:** `tests/test_registry.py`
   - ✅ Обновлён тест `test_duplicate_alias_raises` - ожидает `RegistrationError` вместо `ValueError` (строка 57)

### Результаты

- ✅ **Консистентность API восстановлена** - все ошибки регистрации выбрасывают `RegistrationError`
- ✅ **Все ошибки регистрации выбрасывают `RegistrationError`** - единый тип исключения
- ✅ **Проще обрабатывать ошибки** - один тип исключения вместо двух
- ✅ **Соответствует семантике** - все связано с регистрацией моделей
- ✅ **Все 49 тестов проходят** - функциональность сохранена

---

## Обратная совместимость

⚠️ **Breaking change:** Код, который ловит `ValueError` при конфликте алиаса, перестанет работать.

**Миграция:**
```python
# Было:
try:
    register_model("alias")(Model)
except ValueError as e:
    # обработка

# Стало:
try:
    register_model("alias")(Model)
except RegistrationError as e:  # ← Заменить ValueError на RegistrationError
    # обработка
```

**Рекомендация:** Это изменение оправдано для версии 0.1.0 (первый релиз), так как улучшает консистентность API.

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/gpt-5.md` - раздел "Единообразие исключений при регистрации"
- `localdocs/notes/cache_serialization/final_ai_feedback_analysis.md` - раздел 2.3
- `localdocs/external/redis-json-serializer/localdocs/issues/005-stricter-registration-behavior/README.md` - Issue #005 (строгое поведение при регистрации)

---

**Дата создания:** 2024-12-23  
**Версия:** 0.1.0 (критично перед релизом)

