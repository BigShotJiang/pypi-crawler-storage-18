# Issue #003: Удалить агрессивную конвертацию ISO строк в `unpack()`

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический  
**Источник:** GPT-5  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

В методе `unpack()` есть блок кода, который автоматически пытается преобразовать любую строку с символом `'T'` в `datetime.datetime`. Это нарушает архитектурное решение из ТЗ: "НЕ конвертировать строки без `expected_type`".

### Текущий код

```python
# Обработка строк
if isinstance(obj, str):
    # Преобразование при expected_type
    if expected_type:
        converted = self._convert_string_to_type(obj, expected_type)
        if converted is not obj:
            return converted
    
    # Обработка ISO datetime строк (от orjson)
    # Формат: "2024-12-23T10:30:00" или "2024-12-23T10:30:00.123456"
    if len(obj) >= 19 and obj[10] == 'T':  # ← ПРОБЛЕМА: агрессивная конвертация
        try:
            return datetime.datetime.fromisoformat(obj)
        except (ValueError, TypeError):
            pass
    
    return obj
```

### Почему это проблема

- ❌ Нарушает требование ТЗ: "НЕ конвертировать строки без `expected_type`"
- ❌ Возвращает проблему из оригинальной системы (`_get_parsed_str`)
- ❌ Может неправильно преобразовывать строки (например, `"2024-12-23T10:30:00"` → `datetime`, даже если это просто строка)
- ❌ Создает overhead при десериализации (попытка парсинга для каждой строки)

---

## Решение

✅ **РЕАЛИЗОВАНО** Удалён блок агрессивной конвертации ISO строк. Оставлена только конвертация по `expected_type` через `_convert_string_to_type`.

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`, метод `unpack()`

```python
# Обработка строк
if isinstance(obj, str):
    # Преобразование при expected_type
    if expected_type:
        converted = self._convert_string_to_type(obj, expected_type)
        if converted is not obj:
            return converted
    
    # УДАЛЕН блок агрессивной конвертации ISO строк
    # Конвертация происходит только при наличии expected_type
    
    return obj
```

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** Строка `"2024-12-23T10:30:00"` остается строкой, если нет `expected_type=datetime.datetime`
- ✅ **ВЫПОЛНЕНО** Строка `"1.23"` остается строкой, если нет `expected_type=Decimal`
- ✅ **ВЫПОЛНЕНО** Строка длиной 24 символа не преобразуется в `ObjectId` автоматически
- ✅ **ВЫПОЛНЕНО** Конвертация происходит только при наличии `expected_type`
- ✅ **ВЫПОЛНЕНО** Производительность десериализации улучшена (нет лишних попыток преобразования)

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тесты добавлены в `tests/test_serializer.py`:

**Реализованные тесты:** 
- `TestDatetime::test_no_aggressive_string_conversion`
- `TestDatetime::test_string_conversion_with_expected_type`

```python
def test_no_aggressive_string_conversion(self, serializer):
    """Test that strings are not aggressively converted without expected_type."""
    # ISO datetime строка должна остаться строкой
    iso_string = "2024-12-23T10:30:00"
    packed = serializer.pack(iso_string)
    unpacked = serializer.unpack(packed)
    assert unpacked == iso_string
    assert isinstance(unpacked, str)
    assert not isinstance(unpacked, datetime.datetime)

def test_string_conversion_with_expected_type(self, serializer):
    """Test that strings are converted only with expected_type."""
    iso_string = "2024-12-23T10:30:00"
    packed = serializer.pack(iso_string)
    
    # Без expected_type - остается строкой
    unpacked = serializer.unpack(packed)
    assert isinstance(unpacked, str)
    
    # С expected_type - конвертируется
    unpacked = serializer.unpack(packed, expected_type=datetime.datetime)
    assert isinstance(unpacked, datetime.datetime)
```

**Статус теста:** ✅ Все тесты проходят (44/44 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - Метод `unpack()` (строки 394-410)
   - Удалён блок агрессивной конвертации ISO строк (строки 402-408)
   - Оставлена только конвертация через `_convert_string_to_type()` при наличии `expected_type`
   - Это устраняет проблему из оригинальной системы (`_get_parsed_str`)

2. **Файл:** `tests/test_serializer.py`
   - Добавлены тесты `test_no_aggressive_string_conversion` и `test_string_conversion_with_expected_type` (строки 88-110)
   - Тесты проверяют, что строки не преобразуются автоматически без `expected_type`
   - Тесты проверяют, что конвертация работает корректно с `expected_type`

### Результаты

- ✅ Все 44 теста проходят успешно
- ✅ Строки не преобразуются автоматически без `expected_type`
- ✅ Конвертация работает только при наличии `expected_type`
- ✅ Производительность десериализации улучшена (нет лишних попыток преобразования)
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.1
- `localdocs/notes/cache_serialization/ai_responses/gpt-5.md` - раздел "Агрессивная конвертация строк обратно в datetime"
- `localdocs/requirements/technical_specification.md` - раздел 3.2 "Убрать агрессивную конвертацию строк"


