# Issue #006: Заменить `NotImplementedError` на `TypeError` в `unpack()`

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Важный  
**Источник:** Gemini 2.5 Pro  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

В конце метода `unpack()` используется `NotImplementedError`, в то время как в методе `pack()` используется `TypeError`. Для консистентности API лучше использовать `TypeError` в обоих случаях.

### Текущий код

```python
def unpack(self, obj: Any, expected_type: Type | None = None) -> Any:
    # ... обработка различных типов ...
    
    # Fallback для неизвестных типов
    raise NotImplementedError(f"Unpacking for type {type(obj).__name__} not yet implemented")
```

### Сравнение с `pack()`

```python
def pack(self, obj: Any) -> Any:
    # ... обработка различных типов ...
    
    # Fallback: другие типы...
    raise TypeError(f"Unsupported type for packing: {obj_type}")  # ← TypeError
```

---

## Решение

✅ **РЕАЛИЗОВАНО** Заменён `NotImplementedError` на `TypeError` для консистентности с `pack()`.

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`, метод `unpack()` (строка 419)

```python
# Fallback для неизвестных типов
raise TypeError(f"Unsupported type for unpacking: {type(obj).__name__}")
```

**Сравнение:**
- `pack()`: `raise TypeError(f"Unsupported type for packing: {obj_type}")`
- `unpack()`: `raise TypeError(f"Unsupported type for unpacking: {type(obj).__name__}")`

Теперь оба метода используют `TypeError` для консистентности API.

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** `unpack()` выбрасывает `TypeError` для неподдерживаемых типов
- ✅ **ВЫПОЛНЕНО** Сообщение об ошибке информативное
- ✅ **ВЫПОЛНЕНО** Консистентность с `pack()` (оба используют `TypeError`)
- ✅ **ВЫПОЛНЕНО** Тесты обновлены и проходят

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тесты добавлены в `tests/test_serializer.py`:

**Реализованные тесты:** `TestErrorHandling`
- `test_pack_unsupported_type_raises_type_error`
- `test_unpack_unsupported_type_raises_type_error`

```python
class TestErrorHandling:
    """Test error handling for unsupported types."""
    
    def test_pack_unsupported_type_raises_type_error(self, serializer):
        """Test that packing unsupported type raises TypeError."""
        class UnsupportedType:
            pass
        
        obj = UnsupportedType()
        
        with pytest.raises(TypeError, match="Unsupported type for packing"):
            serializer.pack(obj)
    
    def test_unpack_unsupported_type_raises_type_error(self, serializer):
        """Test that unpacking unsupported type raises TypeError."""
        class UnsupportedType:
            pass
        
        obj = UnsupportedType()
        
        # unpack() должен выбрасывать TypeError (не NotImplementedError)
        with pytest.raises(TypeError, match="Unsupported type for unpacking"):
            serializer.unpack(obj)
```

**Статус теста:** ✅ Все тесты проходят (48/48 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - Метод `unpack()` (строка 419)
   - Заменён `NotImplementedError` на `TypeError` для консистентности с `pack()`
   - Сообщение об ошибке обновлено для соответствия формату `pack()`

2. **Файл:** `tests/test_serializer.py`
   - Добавлен новый класс `TestErrorHandling` (строки 250-270)
   - Добавлены тесты для проверки обработки неподдерживаемых типов в `pack()` и `unpack()`
   - Тесты проверяют, что оба метода используют `TypeError`

### Результаты

- ✅ Все 48 тестов проходят успешно
- ✅ `unpack()` выбрасывает `TypeError` для неподдерживаемых типов
- ✅ Сообщение об ошибке информативное
- ✅ Консистентность с `pack()` (оба используют `TypeError`)
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.4
- `localdocs/notes/cache_serialization/ai_responses/gemini-2.5.-pro.md` - раздел "Предложения и уточнения"


