# Issues для команды разработки

Этот каталог содержит описание issues (задач) для команды разработки библиотеки `redis-json-serializer`.

## Структура

Каждый issue находится в отдельной папке с файлом `README.md`, содержащим:
- Описание проблемы
- Текущий код
- Решение
- Критерии приемки
- Тесты
- Ссылки на источники

## Приоритеты

- 🔴 **Критический** - требует немедленного исправления
- 🟡 **Важный** - желательно исправить до релиза

## Список Issues

### Критические (Фаза 1)

1. **[Issue #001](001-fix-dataclass-asdict-loss-of-markers/README.md)** - Потеря маркеров вложенных моделей при использовании `dataclasses.asdict()`
2. **[Issue #002](002-fix-pydantic-mode-python/README.md)** - Потеря типов вложенных моделей в Pydantic v2 без `mode='python'`
3. **[Issue #003](003-remove-aggressive-iso-conversion/README.md)** - Удалить агрессивную конвертацию ISO строк в `unpack()`
4. **[Issue #004](004-add-expected-type-for-set/README.md)** - Реализовать проброс `expected_type` в `set`
5. **[Issue #005](005-stricter-registration-behavior/README.md)** - Строже поведение при повторной регистрации модели
6. **[Issue #006](006-fix-notimplemented-error/README.md)** - Заменить `NotImplementedError` на `TypeError` в `unpack()`

### Важные (Фаза 2)

7. **[Issue #007](007-add-namespace-constants/README.md)** - Вынести константы для namespace-обёртки
8. **[Issue #008](008-add-tuple-marker/README.md)** - Добавить маркер для `tuple` для сохранения типа

### Критические перед релизом (Фаза 3)

9. **[Issue #009](009-add-tuple-to-unpack-handlers/README.md)** - Добавить `TUPLE` в `_unpack_handlers` для консистентности архитектуры
10. **[Issue #010](010-unify-registration-exceptions/README.md)** - Единообразие исключений при регистрации моделей

## Источники

Все issues основаны на анализе отзывов AI:
- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - сравнительный анализ
- Отзывы от Gemini 2.5 Pro, GPT-5, Claude Sonnet 4.5, Claude Opus 4.5

## Исключенные Issues

Следующие замечания **не включены** в issues, так как они спорные или малоприоритетные:

- Обработка `datetime.datetime` - спорное (противоречие с ТЗ: использовать orjson нативно или маркеры)
- Порядок проверок в `pack()` - малоприоритетное (оптимизация производительности)
- `datetime.date` vs `datetime.datetime` - малоприоритетное (улучшение надежности)
- Типизация в `__init__.py` - малоприоритетное (улучшение качества кода)
- Улучшить `hash_args` для нестандартных типов - малоприоритетное
- Именование `AiocacheJsonSerializer` - решение пользователя (не требует изменений)

---

**Дата создания:** 2024-12-23  
**Версия:** 1.0


