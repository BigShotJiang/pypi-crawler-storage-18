# Issue #009: Добавить `TUPLE` в `_unpack_handlers` для консистентности архитектуры

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический (перед релизом)  
**Источник:** Kimi K2, анализ архитектуры  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

Сейчас маркер `TUPLE` обрабатывается напрямую в методе `unpack()`, а не через dispatch-таблицу `_unpack_handlers`. Это нарушает единообразие архитектуры, где все маркеры должны обрабатываться через dispatch-таблицу.

### Текущий код

```python
# В __init__:
self._unpack_handlers: dict[str, Callable[[dict, Type | None], Any]] = {
    str(Marks.DATE): self._unpack_date,
    str(Marks.DATETIME): self._unpack_datetime,
    str(Marks.DECIMAL): self._unpack_decimal,
    str(Marks.OBJECT_ID): self._unpack_object_id,
    str(Marks.SET): self._unpack_set,
    # ❌ TUPLE отсутствует
}

# В unpack():
if isinstance(obj, dict):
    # Проверка TUPLE маркера (обрабатывается отдельно, до других маркеров)
    if str(Marks.TUPLE) in obj:  # ← Прямая проверка, не через dispatch-таблицу
        items = obj[str(Marks.TUPLE)]
        # ... обработка
```

### Почему это проблема

- ❌ Нарушение единообразия - все остальные маркеры обрабатываются через `_unpack_handlers`
- ❌ Сложнее поддерживать - логика обработки TUPLE разбросана по коду
- ❌ Не соответствует архитектуре dispatch-таблиц

---

## Решение

✅ **РЕАЛИЗОВАНО** Добавлен `TUPLE` в `_unpack_handlers` и создан метод `_unpack_tuple()`

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`

1. **Добавлен обработчик в `__init__`** (строка 74):
```python
self._unpack_handlers: dict[str, Callable[[dict, Type | None], Any]] = {
    str(Marks.DATE): self._unpack_date,
    str(Marks.DATETIME): self._unpack_datetime,
    str(Marks.DECIMAL): self._unpack_decimal,
    str(Marks.OBJECT_ID): self._unpack_object_id,
    str(Marks.SET): self._unpack_set,
    str(Marks.TUPLE): self._unpack_tuple,  # ← Добавлено
}
```

2. **Создан метод `_unpack_tuple()`** (строки 125-150):
```python
def _unpack_tuple(self, obj: dict, expected_type: Type | None = None) -> tuple:
    """
    Unpack tuple from dict with TUPLE marker.
    
    Args:
        obj: Dict with Marks.TUPLE marker and list of items
        expected_type: Optional expected type (tuple[Type1, Type2, ...])
        
    Returns:
        tuple with unpacked items
    """
    items = obj[str(Marks.TUPLE)]
    
    if expected_type:
        origin = get_origin(expected_type)
        if origin is tuple:
            # tuple[Type1, Type2, ...] - более точная десериализация
            elem_types = get_args(expected_type)
            return tuple(
                self.unpack(item, elem_types[i] if i < len(elem_types) else None)
                for i, item in enumerate(items)
            )
    
    # Без expected_type - просто восстановление tuple
    return tuple(self.unpack(item) for item in items)
```

3. **Упрощён `unpack()`** (строки 364-371):
```python
# Маркеры типов (dispatch-таблица) - проверяем dict с маркерами
if isinstance(obj, dict):
    # Проверка маркеров через dispatch-таблицу (O(1))
    for marker, handler in self._unpack_handlers.items():
        if marker in obj:
            return handler(obj, expected_type)
    
    # Проверка MODEL (обрабатывается отдельно)
    if str(Marks.MODEL) in obj:
        return self._unpack_model(obj)
```

**Примечание:** Прямая проверка `TUPLE` удалена из `unpack()`, теперь она обрабатывается через dispatch-таблицу, как и все остальные маркеры.

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** `TUPLE` добавлен в `_unpack_handlers`
- ✅ **ВЫПОЛНЕНО** Создан метод `_unpack_tuple()` с поддержкой `expected_type=tuple[Type1, Type2, ...]`
- ✅ **ВЫПОЛНЕНО** Удалена прямая проверка `TUPLE` из `unpack()`
- ✅ **ВЫПОЛНЕНО** Все существующие тесты для `tuple` проходят
- ✅ **ВЫПОЛНЕНО** Единообразие архитектуры восстановлено

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **Существующие тесты должны продолжать работать:**

```python
def test_tuple_preserves_type(self, serializer):
    """Test that tuple preserves its type during serialization."""
    data = (1, 2, 3, "a", "b")
    packed = serializer.pack(data)
    
    # Проверка маркера
    assert isinstance(packed, dict)
    assert str(Marks.TUPLE) in packed
    
    # Round-trip
    unpacked = serializer.unpack(packed)
    assert isinstance(unpacked, tuple)
    assert unpacked == data

def test_tuple_with_nested_types(self, serializer, sample_decimal):
    """Test tuple with nested types."""
    data = (sample_decimal, "123.45", 42)
    packed = serializer.pack(data)
    unpacked = serializer.unpack(packed)
    
    assert isinstance(unpacked, tuple)
    assert isinstance(unpacked[0], Decimal)
    assert unpacked[1] == "123.45"
    assert unpacked[2] == 42
    assert unpacked == data
```

**Статус теста:** ✅ Все 49 тестов проходят после изменений

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - ✅ Добавлен `str(Marks.TUPLE): self._unpack_tuple` в `_unpack_handlers` (строка 74)
   - ✅ Создан метод `_unpack_tuple()` (строки 125-150, после `_unpack_set`)
   - ✅ Упрощён `unpack()` - удалена прямая проверка `TUPLE` (строки 364-371)

### Результаты

- ✅ **Единообразие архитектуры восстановлено** - все маркеры обрабатываются через dispatch-таблицу
- ✅ **Все маркеры обрабатываются через dispatch-таблицу** - единый паттерн для всех типов
- ✅ **Код стал проще и понятнее** - удалена специальная обработка TUPLE
- ✅ **Легче поддерживать и расширять** - добавление новых маркеров требует только добавления в dispatch-таблицу
- ✅ **Все 49 тестов проходят** - функциональность сохранена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/kimi-k2.md` - раздел "TUPLE маркер"
- `localdocs/notes/cache_serialization/final_ai_feedback_analysis.md` - раздел 2.6
- `localdocs/external/redis-json-serializer/localdocs/issues/008-add-tuple-marker/README.md` - Issue #008 (добавление маркера TUPLE)

---

**Дата создания:** 2024-12-23  
**Версия:** 0.1.0 (критично перед релизом)

