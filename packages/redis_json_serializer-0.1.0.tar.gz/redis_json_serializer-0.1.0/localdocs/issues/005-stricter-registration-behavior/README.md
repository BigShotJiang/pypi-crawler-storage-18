# Issue #005: Строже поведение при повторной регистрации модели

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический  
**Источник:** GPT-5  
**Файл:** `src/redis_json_serializer/registry.py`

---

## Проблема

Сейчас повторная регистрация того же класса с тем же ключом даёт `warnings.warn` и пропускается. Для безопасности и предсказуемости в production лучше выбрасывать `RegistrationError`.

### Текущий код

```python
if model_key in REGISTERED_MODELS:
    existing_cls = REGISTERED_MODELS[model_key]
    if existing_cls is cls:
        # Повторная регистрация того же класса - предупреждение
        warnings.warn(
            f"Model {cls} already registered with key '{model_key}'. "
            "Skipping duplicate registration.",
            UserWarning,
            stacklevel=2,
        )
        return cls
    else:
        raise ValueError(
            f"Duplicate alias '{model_key}': already registered for {existing_cls}, "
            f"attempted to register {cls}"
        )
```

### Почему это проблема

- ⚠️ Предупреждение может быть проигнорировано в production
- ⚠️ Непредсказуемое поведение (регистрация "проходит" с предупреждением)
- ⚠️ Может скрыть реальные проблемы (например, дублирование импортов)

---

## Решение

✅ **РЕАЛИЗОВАНО** Выбрасывается `RegistrationError` при повторной регистрации того же класса. Это обеспечивает строгое поведение и явную ошибку.

### Реализованный код

**Файл:** `src/redis_json_serializer/registry.py`, функция `register_model()` (строки 96-112)

```python
# Проверка дубликатов
if model_key in REGISTERED_MODELS:
    existing_cls = REGISTERED_MODELS[model_key]
    if existing_cls is cls:
        # Строгий режим: повторная регистрация не допускается
        raise RegistrationError(
            f"Model {cls} already registered with key '{model_key}'. "
            "Duplicate registration is not allowed."
        )
    else:
        raise ValueError(
            f"Duplicate alias '{model_key}': already registered for {existing_cls}, "
            f"cannot register {cls}"
        )
```

**Примечание:** Реализован строгий режим по умолчанию без опционального флага `strict`, так как это обеспечивает более предсказуемое поведение в production.

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** Повторная регистрация того же класса выбрасывает `RegistrationError`
- ✅ **ВЫПОЛНЕНО** Сообщение об ошибке информативное
- ✅ **ВЫПОЛНЕНО** Регистрация разных классов с одним алиасом по-прежнему выбрасывает `ValueError`
- ✅ **ВЫПОЛНЕНО** Тесты обновлены и проходят

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тесты обновлены в `tests/test_registry.py`:

**Обновлённый тест:** `TestRegisterModel::test_duplicate_registration_raises_error`

```python
def test_duplicate_registration_raises_error(self):
    """Test that duplicate registration raises RegistrationError."""
    @register_model("test.duplicate.reg")
    class Model1(BaseModel):
        id: str
    
    # Повторная регистрация того же класса должна вызвать RegistrationError
    with pytest.raises(RegistrationError, match="already registered"):
        register_model("test.duplicate.reg")(Model1)
```

**Существующий тест:** `TestRegisterModel::test_duplicate_alias_raises` (проверяет регистрацию разных классов с одним алиасом)

**Статус теста:** ✅ Все тесты проходят (46/46 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/registry.py`
   - Функция `register_model()` (строки 96-112)
   - Заменён `warnings.warn()` на `raise RegistrationError()` при повторной регистрации того же класса
   - Удалён код, который пропускал повторную регистрацию с предупреждением
   - Это обеспечивает строгое поведение и явную ошибку в production

2. **Файл:** `tests/test_registry.py`
   - Обновлён тест `test_duplicate_registration_raises_error` (строки 62-70)
   - Тест теперь проверяет, что повторная регистрация выбрасывает `RegistrationError`
   - Удалён старый тест `test_same_class_same_alias_ok`, который проверял предупреждение

### Результаты

- ✅ Все 46 тестов проходят успешно
- ✅ Повторная регистрация того же класса выбрасывает `RegistrationError`
- ✅ Сообщение об ошибке информативное
- ✅ Регистрация разных классов с одним алиасом по-прежнему выбрасывает `ValueError`
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.3
- `localdocs/notes/cache_serialization/ai_responses/gpt-5.md` - раздел "Поведение при повторной регистрации модели"


