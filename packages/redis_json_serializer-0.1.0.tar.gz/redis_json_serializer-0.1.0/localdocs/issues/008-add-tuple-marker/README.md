# Issue #008: Добавить маркер для `tuple` для сохранения типа

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🟡 Важный  
**Источник:** Claude Sonnet 4.5, Claude Opus 4.5  
**Файлы:** `src/redis_json_serializer/types.py`, `src/redis_json_serializer/serializer.py`

---

## Проблема

Сейчас `tuple` преобразуется в `list` при сериализации через `pack()`. При десериализации без `expected_type` получим `list`, а не `tuple`, что приводит к потере типа.

### Текущий код

```python
def pack(self, obj: Any) -> Any:
    # ...
    if isinstance(obj, (list, tuple)):
        return [self.pack(item) for item in obj]  # ← tuple преобразуется в list
```

### Пример проблемы

```python
serializer = JsonSerializer()

data = (1, 2, 3)
packed = serializer.pack(data)  # [1, 2, 3] - list
print(type(packed))  # <class 'list'>

unpacked = serializer.unpack(packed)  # list, не tuple!
print(type(unpacked))  # <class 'list'>
```

---

## Решение

✅ **РЕАЛИЗОВАНО** Добавлен маркер `TUPLE` в `types.py` и реализована обработка `tuple` отдельно от `list` в `pack()` и `unpack()`.

### Реализованный код

1. **Файл:** `src/redis_json_serializer/types.py` (строка 19)
```python
class Marks(StrEnum):
    # ... существующие маркеры ...
    TUPLE = "d7e4f5a6-3b7c-4d8e-9f0a-1b2c3d4e5f6a"
```

2. **Файл:** `src/redis_json_serializer/serializer.py`
   - В методе `pack()` (строки 327-332):
```python
# Обработка list (рекурсивная упаковка)
if isinstance(obj, list):
    return [self.pack(item) for item in obj]

# Обработка tuple (сериализуется как dict с маркером)
if isinstance(obj, tuple):
    return {str(Marks.TUPLE): [self.pack(item) for item in obj]}
```

   - В методе `unpack()` (строки 361-375):
```python
if isinstance(obj, dict):
    # Проверка TUPLE маркера (обрабатывается отдельно, до других маркеров)
    if str(Marks.TUPLE) in obj:
        items = obj[str(Marks.TUPLE)]
        if expected_type:
            origin = get_origin(expected_type)
            if origin is tuple:
                # tuple[Type1, Type2, ...] - более точная десериализация
                elem_types = get_args(expected_type)
                return tuple(
                    self.unpack(item, elem_types[i] if i < len(elem_types) else None)
                    for i, item in enumerate(items)
                )
        # Без expected_type или если expected_type не tuple - просто восстановление tuple
        return tuple(self.unpack(item) for item in items)
```

**Примечание:** Реализована поддержка `expected_type=tuple[Type1, Type2, ...]` для более точной десериализации элементов.

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** `tuple` сохраняет свой тип при round-trip сериализации/десериализации
- ✅ **ВЫПОЛНЕНО** `list` продолжает работать как раньше
- ✅ **ВЫПОЛНЕНО** Маркер `TUPLE` добавлен в `types.py`
- ✅ **ВЫПОЛНЕНО** Тесты для `tuple` проходят

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тесты добавлены в `tests/test_serializer.py`:

**Реализованные тесты:** `TestCollections`
- `test_tuple_preserves_type`
- `test_tuple_with_nested_types`

```python
def test_tuple_preserves_type(self, serializer):
    """Test that tuple preserves its type during serialization."""
    data = (1, 2, 3, "a", "b")
    packed = serializer.pack(data)
    
    # Проверка маркера
    assert isinstance(packed, dict)
    assert str(Marks.TUPLE) in packed
    
    # Round-trip
    unpacked = serializer.unpack(packed)
    assert isinstance(unpacked, tuple)
    assert unpacked == data

def test_tuple_with_nested_types(self, serializer, sample_decimal):
    """Test tuple with nested types."""
    data = (sample_decimal, "123.45", 42)
    packed = serializer.pack(data)
    unpacked = serializer.unpack(packed)
    
    assert isinstance(unpacked, tuple)
    assert isinstance(unpacked[0], Decimal)
    assert unpacked[1] == "123.45"
    assert unpacked[2] == 42
    assert unpacked == data
```

**Статус теста:** ✅ Все тесты проходят (49/49 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/types.py`
   - Добавлен маркер `TUPLE = "d7e4f5a6-3b7c-4d8e-9f0a-1b2c3d4e5f6a"` в класс `Marks` (строка 19)

2. **Файл:** `src/redis_json_serializer/serializer.py`
   - Метод `pack()` (строки 327-332): разделена обработка `list` и `tuple`, `tuple` сериализуется как dict с маркером
   - Метод `unpack()` (строки 361-375): добавлена проверка маркера `TUPLE` перед другими маркерами, поддержка `expected_type=tuple[Type1, Type2, ...]`

3. **Файл:** `tests/test_serializer.py`
   - Обновлён тест `test_tuple_preserves_type` (строки 190-202)
   - Добавлен тест `test_tuple_with_nested_types` (строки 204-214)
   - Удалён старый тест `test_tuple`, который проверял старое поведение (tuple -> list)

### Результаты

- ✅ Все 49 тестов проходят успешно
- ✅ `tuple` сохраняет свой тип при round-trip сериализации/десериализации
- ✅ `list` продолжает работать как раньше
- ✅ Маркер `TUPLE` добавлен в `types.py`
- ✅ Поддержка `expected_type=tuple[Type1, Type2, ...]` для точной десериализации
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.9
- `localdocs/notes/cache_serialization/ai_responses/claude-sonnet-4.5.md` - раздел "Проблема: Обработка tuple"
- `localdocs/notes/cache_serialization/ai_responses/claude-opus-4.5.md` - раздел "Добавить обработку tuple"


