# Issue #001: Потеря маркеров вложенных моделей при использовании `dataclasses.asdict()`

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический  
**Источник:** Claude Sonnet 4.5  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

В методе `_pack_dataclass()` используется `dataclasses.asdict()`, который рекурсивно преобразует вложенные dataclass в dict. Затем `pack(value)` еще раз упаковывает значения, что приводит к **потере маркеров** вложенных моделей.

### Текущий код

```python
def _pack_dataclass(self, obj: Any) -> dict:
    # ...
    data = dataclasses.asdict(obj)  # ← Рекурсивно преобразует вложенные dataclass в dict
    
    packed_data = {}
    for key, value in data.items():
        packed_data[key] = self.pack(value)  # ← Двойная упаковка!
```

### Пример проблемы

```python
@register_model("inner.v1")
@dataclass
class Inner:
    value: int

@register_model("outer.v1")
@dataclass
class Outer:
    inner: Inner

serializer = JsonSerializer()
obj = Outer(inner=Inner(value=42))
packed = serializer.pack(obj)

# Ожидается:
# {MODEL: "outer.v1", "inner": {MODEL: "inner.v1", "value": 42}}

# Получим:
# {MODEL: "outer.v1", "inner": {"value": 42}}  ← Потеря маркера!
```

---

## Решение

✅ **РЕАЛИЗОВАНО** Заменён `dataclasses.asdict()` на итерацию по полям вручную, чтобы сохранить вложенные объекты как есть и позволить `pack()` корректно обработать их.

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`, метод `_pack_dataclass()`

```python
def _pack_dataclass(self, obj: Any) -> dict:
    cls = type(obj)
    model_key = MODEL_ALIASES.get(cls)
    
    if model_key is None:
        raise RegistrationError(
            f"Dataclass {cls} is not registered. Use @register_model()"
        )
    
    # Извлечь поля вручную (без asdict для сохранения вложенных объектов)
    packed_data = {}
    for field in dataclasses.fields(obj):
        value = getattr(obj, field.name)
        packed_data[field.name] = self.pack(value)  # ← Рекурсивная упаковка
    
    return {str(Marks.MODEL): model_key, **packed_data}
```

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** Вложенные зарегистрированные dataclass сохраняют маркер `MODEL`
- ✅ **ВЫПОЛНЕНО** Round-trip сериализация/десериализация работает корректно для вложенных моделей
- ✅ **ВЫПОЛНЕНО** Тесты для вложенных dataclass проходят

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тест добавлен в `tests/test_serializer.py`:

**Реализованный тест:** `TestDataclass::test_nested_dataclass_preserves_markers`

```python
def test_nested_dataclass_preserves_markers(self, serializer):
    """Test that nested dataclass preserves MODEL markers."""
    @register_model("inner.v1")
    @dataclass
    class Inner:
        value: int
    
    @register_model("outer.v1")
    @dataclass
    class Outer:
        inner: Inner
    
    obj = Outer(inner=Inner(value=42))
    packed = serializer.pack(obj)
    
    # Проверка маркера для внешней модели
    assert str(Marks.MODEL) in packed
    assert packed[str(Marks.MODEL)] == "outer.v1"
    
    # Проверка маркера для вложенной модели
    assert str(Marks.MODEL) in packed["inner"]
    assert packed["inner"][str(Marks.MODEL)] == "inner.v1"
    
    # Round-trip
    unpacked = serializer.unpack(packed)
    assert isinstance(unpacked, Outer)
    assert isinstance(unpacked.inner, Inner)
    assert unpacked.inner.value == 42
```

**Статус теста:** ✅ Все тесты проходят (41/41 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - Метод `_pack_dataclass()` (строки 227-233)
   - Заменён `dataclasses.asdict(obj)` на ручную итерацию по полям через `dataclasses.fields(obj)`
   - Используется `getattr(obj, field.name)` для получения значений полей
   - Это позволяет сохранить вложенные dataclass объекты как есть, чтобы `pack()` мог корректно обработать их

2. **Файл:** `tests/test_serializer.py`
   - Добавлен тест `TestDataclass::test_nested_dataclass_preserves_markers` (строки 223-245)
   - Тест проверяет сохранение маркеров для внешней и вложенной моделей
   - Тест проверяет корректность round-trip сериализации

### Результаты

- ✅ Все 41 тест проходят успешно
- ✅ Вложенные dataclass сохраняют маркеры моделей
- ✅ Round-trip сериализация работает корректно
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.6
- `localdocs/notes/cache_serialization/ai_responses/claude-sonnet-4.5.md` - раздел "Проблема: Рекурсия в `dataclasses.asdict()`"


