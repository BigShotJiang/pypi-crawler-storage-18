# Issue #004: Реализовать проброс `expected_type` в `set`

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический  
**Источник:** GPT-5  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

Сейчас `set` распаковывается через `_unpack_handlers` без возможности передать `expected_type` для элементов множества. Это лишает точности десериализации для `set[Type]` и не соответствует логике для `list[Type]` и `dict[str, Type]`.

### Текущий код

```python
# В __init__:
self._unpack_handlers: dict[str, Callable[[dict], Any]] = {
    # ...
    str(Marks.SET): self._unpack_set,
}

def _unpack_set(self, obj: dict) -> set:
    """Unpack set from dict with marker."""
    return {self.unpack(item) for item in obj[str(Marks.SET)]}  # ← Нет expected_type
```

### Пример проблемы

```python
# Нельзя точно десериализовать set[Decimal]
data = {str(Marks.SET): ["123.45", "67.89"]}
unpacked = serializer.unpack(data, expected_type=set[Decimal])
# Элементы останутся строками, а не Decimal
```

---

## Решение

✅ **РЕАЛИЗОВАНО** Изменена сигнатура обработчиков в `_unpack_handlers`, чтобы они принимали `expected_type`, и обновлён `_unpack_set` для поддержки `set[Type]`.

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`

1. **Изменена сигнатура обработчиков в `__init__`** (строки 65-73):
```python
self._unpack_handlers: dict[str, Callable[[dict, Type | None], Any]] = {
    str(Marks.DATE): self._unpack_date,
    str(Marks.DATETIME): self._unpack_datetime,
    str(Marks.DECIMAL): self._unpack_decimal,
    str(Marks.OBJECT_ID): self._unpack_object_id,
    str(Marks.SET): self._unpack_set,
}
```

2. **Обновлён вызов в `unpack()`** (строки 352-354):
```python
for marker, handler in self._unpack_handlers.items():
    if marker in obj:
        return handler(obj, expected_type)  # ← Передаем expected_type
```

3. **Обновлён `_unpack_set`** (строки 111-118):
```python
def _unpack_set(self, obj: dict, expected_type: Type | None = None) -> set:
    """Unpack set from dict with marker."""
    elem_type = None
    if expected_type:
        origin = get_origin(expected_type)
        if origin is set:
            args = get_args(expected_type)
            elem_type = args[0] if args else None
    return {self.unpack(item, elem_type) for item in obj[str(Marks.SET)]}
```

4. **Обновлены остальные обработчики** для консистентности (принимают `expected_type`, но игнорируют его, так как тип уже определён маркером):
- `_unpack_datetime`, `_unpack_date`, `_unpack_decimal`, `_unpack_object_id`

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** `set[Type]` корректно десериализуется с указанным типом элементов
- ✅ **ВЫПОЛНЕНО** `set` без `expected_type` работает как раньше
- ✅ **ВЫПОЛНЕНО** Консистентность с `list[Type]` и `dict[str, Type]`
- ✅ **ВЫПОЛНЕНО** Тесты для `set[Decimal]`, `set[datetime.datetime]` и других типов проходят

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тесты добавлены в `tests/test_serializer.py`:

**Реализованные тесты:**
- `TestCollections::test_unpack_set_with_expected_type`
- `TestCollections::test_unpack_set_with_datetime`

```python
def test_unpack_set_with_expected_type(self, serializer, sample_decimal):
    """Test unpacking set with expected type."""
    # Создаем set с Decimal (в виде строк)
    data = {str(Marks.SET): [str(sample_decimal), "123.456"]}
    
    # Без expected_type - элементы остаются строками
    unpacked = serializer.unpack(data)
    assert isinstance(unpacked, set)
    assert all(isinstance(x, str) for x in unpacked)
    
    # С expected_type=set[Decimal] - элементы конвертируются
    unpacked = serializer.unpack(data, expected_type=set[Decimal])
    assert isinstance(unpacked, set)
    assert all(isinstance(x, Decimal) for x in unpacked)
    assert Decimal("123.456") in unpacked
    assert sample_decimal in unpacked

def test_unpack_set_with_datetime(self, serializer, sample_datetime):
    """Test unpacking set with datetime elements."""
    iso_string = sample_datetime.isoformat()
    data = {str(Marks.SET): [iso_string, "2024-01-01T00:00:00"]}
    
    unpacked = serializer.unpack(data, expected_type=set[datetime.datetime])
    assert isinstance(unpacked, set)
    assert all(isinstance(x, datetime.datetime) for x in unpacked)
    assert sample_datetime in unpacked
    assert datetime.datetime(2024, 1, 1, 0, 0, 0) in unpacked
```

**Статус теста:** ✅ Все тесты проходят (46/46 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - Изменена сигнатура `_unpack_handlers` для поддержки `expected_type` (строки 67-73)
   - Обновлён вызов обработчиков в `unpack()` для передачи `expected_type` (строки 352-354)
   - Обновлён `_unpack_set()` для поддержки `set[Type]` (строки 111-118)
   - Обновлены остальные обработчики для консистентности (принимают `expected_type`, но игнорируют его)

2. **Файл:** `tests/test_serializer.py`
   - Добавлены тесты `test_unpack_set_with_expected_type` и `test_unpack_set_with_datetime` (строки 162-186)
   - Тесты проверяют корректную десериализацию `set[Type]` с указанным типом элементов
   - Тесты проверяют обратную совместимость (set без `expected_type` работает как раньше)

### Результаты

- ✅ Все 46 тестов проходят успешно
- ✅ `set[Type]` корректно десериализуется с указанным типом элементов
- ✅ `set` без `expected_type` работает как раньше
- ✅ Консистентность с `list[Type]` и `dict[str, Type]`
- ✅ Проблема полностью решена

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.2
- `localdocs/notes/cache_serialization/ai_responses/gpt-5.md` - раздел "Проброс ожидаемого типа для set"


