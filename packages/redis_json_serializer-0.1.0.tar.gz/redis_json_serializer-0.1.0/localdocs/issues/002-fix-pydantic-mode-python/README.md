# Issue #002: Потеря типов вложенных моделей в Pydantic v2 без `mode='python'`

**Статус:** ✅ **РЕАЛИЗОВАНО**  
**Приоритет:** 🔴 Критический  
**Источник:** Claude Sonnet 4.5  
**Файл:** `src/redis_json_serializer/serializer.py`

---

## Проблема

В методе `_pack_pydantic()` для Pydantic v2 используется `model_dump()` без параметра `mode='python'`. Это приводит к тому, что вложенные модели сериализуются в dict, и при последующей упаковке теряется информация о типе.

### Текущий код

```python
if hasattr(obj, 'model_dump'):
    # Pydantic v2
    data = obj.model_dump()  # ← Без mode='python'
```

### Пример проблемы

```python
@register_model("inner.v1")
class Inner(BaseModel):
    value: int

@register_model("outer.v1")
class Outer(BaseModel):
    inner: Inner

serializer = JsonSerializer()
obj = Outer(inner=Inner(value=42))
packed = serializer.pack(obj)

# С mode='python':
# {MODEL: "outer.v1", "inner": Inner(value=42)} → {MODEL: "outer.v1", "inner": {MODEL: "inner.v1", ...}}

# Без mode='python':
# {MODEL: "outer.v1", "inner": {"value": 42}} ← Потеря типа!
```

---

## Решение

✅ **РЕАЛИЗОВАНО** Использована итерация по полям модели напрямую (аналогично dataclass), чтобы сохранить вложенные модели как объекты Python, а не как dict. `model_dump()` и `dict()` всегда возвращают dict для вложенных моделей, даже с `mode='python'`.

### Реализованный код

**Файл:** `src/redis_json_serializer/serializer.py`, метод `_pack_pydantic()`

```python
# Извлечение полей вручную (без model_dump/dict для сохранения вложенных объектов)
# model_dump() и dict() рекурсивно преобразуют вложенные модели в dict,
# что приводит к потере маркеров моделей при последующей упаковке
packed_data = {}
if hasattr(cls, 'model_fields'):
    # Pydantic v2 - итерация по model_fields класса (не экземпляра)
    for field_name in cls.model_fields:
        value = getattr(obj, field_name)
        packed_data[field_name] = self.pack(value)  # Рекурсивная упаковка
elif hasattr(cls, '__fields__'):
    # Pydantic v1 - итерация по __fields__ класса
    for field_name in cls.__fields__:
        value = getattr(obj, field_name)
        packed_data[field_name] = self.pack(value)  # Рекурсивная упаковка
else:
    # Fallback для совместимости
    if hasattr(obj, 'model_dump'):
        data = obj.model_dump(mode='python')
    else:
        data = obj.dict()
    for key, value in data.items():
        packed_data[key] = self.pack(value)
```

---

## Критерии приемки

- ✅ **ВЫПОЛНЕНО** Вложенные зарегистрированные Pydantic модели сохраняют маркер `MODEL`
- ✅ **ВЫПОЛНЕНО** Round-trip сериализация/десериализация работает корректно для вложенных моделей
- ✅ **ВЫПОЛНЕНО** Тесты для вложенных Pydantic моделей проходят
- ✅ **ВЫПОЛНЕНО** Работает как с Pydantic v1, так и с v2

**Все критерии приемки выполнены. Проблема решена.**

---

## Тесты

✅ **РЕАЛИЗОВАНО** Тест добавлен в `tests/test_serializer.py`:

**Реализованный тест:** `TestPydanticModels::test_nested_pydantic_preserves_markers`

```python

```python
@pytest.mark.requires_pydantic
def test_nested_pydantic_preserves_markers(self, serializer):
    """Test that nested Pydantic model preserves MODEL markers."""
    @register_model("inner.v1")
    class Inner(BaseModel):
        value: int
    
    @register_model("outer.v1")
    class Outer(BaseModel):
        inner: Inner
    
    obj = Outer(inner=Inner(value=42))
    packed = serializer.pack(obj)
    
    # Проверка маркера для внешней модели
    assert str(Marks.MODEL) in packed
    assert packed[str(Marks.MODEL)] == "outer.v1"
    
    # Проверка маркера для вложенной модели
    assert str(Marks.MODEL) in packed["inner"]
    assert packed["inner"][str(Marks.MODEL)] == "inner.v1"
    
    # Round-trip
    unpacked = serializer.unpack(packed)
    assert isinstance(unpacked, Outer)
    assert isinstance(unpacked.inner, Inner)
    assert unpacked.inner.value == 42
```

**Статус теста:** ✅ Все тесты проходят (42/42 passed)

---

## Реализация

### Изменения в коде

1. **Файл:** `src/redis_json_serializer/serializer.py`
   - Метод `_pack_pydantic()` (строки 191-210)
   - Заменён `model_dump()`/`dict()` на ручную итерацию по полям через `cls.model_fields` (Pydantic v2) или `cls.__fields__` (Pydantic v1)
   - Используется `getattr(obj, field_name)` для получения значений полей
   - Это позволяет сохранить вложенные Pydantic модели как объекты, чтобы `pack()` мог корректно обработать их

2. **Файл:** `tests/test_serializer.py`
   - Добавлен тест `TestPydanticModels::test_nested_pydantic_preserves_markers` (строки 197-221)
   - Тест проверяет сохранение маркеров для внешней и вложенной моделей
   - Тест проверяет корректность round-trip сериализации

### Результаты

- ✅ Все 42 теста проходят успешно
- ✅ Вложенные Pydantic модели сохраняют маркеры моделей
- ✅ Round-trip сериализация работает корректно
- ✅ Поддержка Pydantic v1 и v2
- ✅ Проблема полностью решена

### Примечание

Изначально планировалось использовать `mode='python'` для `model_dump()`, но выяснилось, что даже с этим параметром `model_dump()` всегда возвращает dict для вложенных моделей. Поэтому был использован подход с прямой итерацией по полям модели, аналогичный решению для dataclass (Issue #001).

---

## Ссылки

- `localdocs/notes/cache_serialization/ai_responses/review_ai_feedback_comparison.md` - раздел 3.7
- `localdocs/notes/cache_serialization/ai_responses/claude-sonnet-4.5.md` - раздел "Обработка Pydantic v1/v2"


