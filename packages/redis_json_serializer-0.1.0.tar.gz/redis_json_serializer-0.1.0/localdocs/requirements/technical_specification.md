# Техническое задание: redis-json-serializer

## 1. Общая информация

### 1.1 Название проекта
**redis-json-serializer** - быстрый и безопасный JSON-сериализатор для кэширования в Redis с поддержкой Pydantic моделей и dataclass.

### 1.2 Цель проекта
Создать выделенную библиотеку для сериализации данных в Redis, которая:
- Устраняет критические баги оригинальной системы
- Упрощает архитектуру для лучшей поддерживаемости
- Готова к публикации на PyPI
- Обеспечивает высокую производительность и безопасность

### 1.3 Статус проекта
**Скелетон готов** - структура проекта создана, код требует реализации.

### 1.4 Репозиторий
- GitHub: `git@github.com:seligoroff/redis-json-serializer.git`
- URL: `https://github.com/seligoroff/redis-json-serializer`

---

## 2. Требования к функциональности

### 2.1 Основной функционал

#### 2.1.1 Сериализация базовых типов
**Требования:**
- Поддержка нативных JSON типов: `str`, `int`, `float`, `bool`, `None`
- Поддержка коллекций: `list`, `tuple`, `dict`, `set`
  - **ВАЖНО**: `tuple` при `pack()` преобразуется в JSON-массив (`list`), исходный тип не сохраняется
  - Восстановление `tuple` происходит при `unpack()` только если передан `expected_type=tuple[...]`
- Поддержка дат: `datetime.datetime`, `datetime.date`
- Поддержка `Decimal` для точных вычислений
- Опциональная поддержка `ObjectId` (MongoDB) при установке `pymongo`

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Метод: `JsonSerializer.pack(obj: Any) -> Any`
- Метод: `JsonSerializer.dumps(value: Any) -> bytes`

#### 2.1.2 Десериализация
**Требования:**
- Обратная десериализация всех поддерживаемых типов
- Поддержка `expected_type` для улучшения точности десериализации
- Проброс `expected_type` в коллекции (`list[Type]`, `dict[str, Type]`, `tuple[Type1, Type2]`)

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Метод: `JsonSerializer.unpack(obj: Any, expected_type: Type | None = None) -> Any`
- Метод: `JsonSerializer.loads(value: bytes | None) -> Any`

#### 2.1.3 Поддержка Pydantic моделей
**Требования:**
- Сериализация и десериализация Pydantic моделей
- Обязательная регистрация моделей через `@register_model()` для безопасности
- Поддержка стабильных алиасов для версионирования

**Реализация:**
- Файл: `src/redis_json_serializer/registry.py`
- Декоратор: `@register_model(alias: str | None = None)`
- Файл: `src/redis_json_serializer/serializer.py`
- Метод: `JsonSerializer._pack_pydantic(obj: BaseModel) -> dict`

#### 2.1.4 Поддержка dataclass
**Требования:**
- Сериализация и десериализация dataclass
- Обязательная регистрация через `@register_model()`
- Единая логика с Pydantic моделями

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Метод: `JsonSerializer._pack_dataclass(obj: Any) -> dict`

#### 2.1.5 Регистрация моделей
**Требования:**
- Whitelist-подход: только зарегистрированные модели могут быть десериализованы
- Поддержка стабильных алиасов (рекомендуется для production)
- O(1) поиск модели по алиасу через `MODEL_ALIASES`
- Защита от дублирования алиасов
- При попытке десериализации незарегистрированной модели выбрасывается `RegistrationError` (из `registry.py`)

**Реализация:**
- Файл: `src/redis_json_serializer/registry.py`
- Глобальный словарь: `REGISTERED_MODELS: dict[str, Type]`
- Глобальный словарь: `MODEL_ALIASES: dict[Type, str]`
- Исключение: `RegistrationError(SerializationSecurityError)` - для незарегистрированных моделей
- Функция: `get_key_model(cls: Type, alias: str | None = None) -> str`
- Декоратор: `register_model(alias: str | None = None)`
- Класс: `ModelRegistry`

#### 2.1.6 Интеграция с aiocache
**Требования:**
- Адаптер для использования с библиотекой `aiocache`
- Реализация интерфейса `BaseSerializer`

**Реализация:**
- Файл: `src/redis_json_serializer/aiocache.py`
- Класс: `AiocacheJsonSerializer(BaseSerializer)`

#### 2.1.7 Утилиты для генерации ключей кэша
**Требования:**
- Генерация стабильных ключей кэша для функций
- Сохранение порядка позиционных аргументов
- Использование `module.qualname` вместо `str(func)`

**Реализация:**
- Файл: `src/redis_json_serializer/utils.py`
- Функция: `hash_args(*args, **kwargs) -> str`
- Функция: `default_key_builder(func: Any, *args, **kwargs) -> str`

### 2.2 Дополнительный функционал

#### 2.2.1 Namespace для версионирования
**Требования:**
- Поддержка префикса namespace в конструкторе `JsonSerializer`
- Позволяет безопасно мигрировать между версиями формата
- При наличии `namespace` в `dumps()` оборачивает полезную нагрузку: `{"$ns": namespace, "$data": payload}`
- В `loads()` распознаёт namespace-обёртку и извлекает `$data`

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Параметр: `JsonSerializer.__init__(namespace: str = "")`
- Методы: `dumps()` и `loads()` обрабатывают namespace-обёртку

---

## 3. Критические исправления (приоритет: ВЫСОКИЙ)

### 3.1 Исправление генерации ключей кэша

**Проблема:**
1. `f"{func}"` включает адрес в памяти → нестабильный ключ между перезапусками
2. В `hash_args` позиционные аргументы сортируются → коллизии: `f(1, 2)` и `f(2, 1)` дают один ключ

**Требования к исправлению:**
- Использовать `module.qualname` вместо `str(func)`
- Сохранять порядок позиционных аргументов (не сортировать!)
- Сортировать только keyword arguments для детерминированности

**Реализация:**
- Файл: `src/redis_json_serializer/utils.py`
- Функция: `hash_args(*args, **kwargs) -> str`
  ```python
  def hash_args(*args, **kwargs) -> str:
      # Сохраняем порядок позиционных аргументов
      return hashlib.sha1(
          repr(args).encode("utf-8")
          + repr(tuple(sorted(kwargs.items()))).encode("utf-8")
      ).hexdigest()
  ```
- Функция: `default_key_builder(func: Any, *args, **kwargs) -> str`
  ```python
  def default_key_builder(func: Any, *args, **kwargs) -> str:
      module = getattr(func, "__module__", "")
      qualname = getattr(func, "__qualname__", getattr(func, "__name__", ""))
      return f"{module}.{qualname}:{hash_args(*args, **kwargs)}"
  ```

**Критерии приемки:**
- ✅ `default_key_builder(f, 1, 2)` и `default_key_builder(f, 2, 1)` дают разные ключи
- ✅ `default_key_builder(f, a=1, b=2)` и `default_key_builder(f, b=2, a=1)` дают одинаковый ключ
- ✅ Ключ стабилен между перезапусками (не содержит адресов в памяти)

**Ссылки:**
- `comparison_report.md` раздел "Критические проблемы" → "Некорректная генерация ключей кэша"

### 3.2 Убрать агрессивную конвертацию строк

**Проблема:**
- Функция `_get_parsed_str` пытается преобразовать каждую строку в `datetime`, `ObjectId` или `Decimal`
- Вызывается для каждой строки при десериализации → огромный overhead
- Может неправильно преобразовывать строки (например, `"1.23"` → `Decimal('1.23')`)

**Требования к исправлению:**
- **НЕ создавать** функцию `_get_parsed_str`
- Преобразовывать строки **только** если есть `expected_type`
- Преобразование должно быть явным и безопасным

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Метод: `JsonSerializer._convert_string_to_type(obj: str, expected_type: Type) -> Any`
  ```python
  def _convert_string_to_type(self, obj: str, expected_type: Type) -> Any:
      """Convert string to expected type (only when explicitly expected)."""
      try:
          if expected_type is Decimal:
              return Decimal(obj)
          if expected_type is ObjectId and ObjectId:
              return ObjectId(obj)
          if expected_type is datetime.datetime:
              return datetime.datetime.fromisoformat(obj)
          if expected_type is datetime.date:
              return datetime.date.fromisoformat(obj)
      except (ValueError, TypeError):
          pass
      return obj
  ```
- Использовать только в `unpack()` при наличии `expected_type`

**Критерии приемки:**
- ✅ Строка `"1.23"` остается строкой, если нет `expected_type=Decimal`
- ✅ Строка длиной 24 символа не преобразуется в `ObjectId` автоматически
- ✅ Производительность десериализации улучшена (нет лишних попыток преобразования)

**Ссылки:**
- `comparison_report.md` раздел "Критические проблемы" → "Агрессивное преобразование строк"

### 3.3 Исправление ResponseSerializer

**Проблема:**
- `ResponseSerializer.pack()` возвращает `None` вместо явного запрета
- Это приводит к кэшированию `None` вместо данных

**Требования к исправлению:**
- Явно запретить сериализацию `Response` объектов
- Выбрасывать `TypeError` при попытке сериализации

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- В методе `pack()` добавить проверку:
  ```python
  if isinstance(obj, Response):
      raise TypeError("Response objects cannot be serialized")
  ```

**Критерии приемки:**
- ✅ Попытка сериализации `Response` объекта выбрасывает `TypeError`
- ✅ Сообщение об ошибке информативное

**Ссылки:**
- `comparison_report.md` раздел "Критические проблемы" → "ResponseSerializer возвращает None"

---

## 4. Архитектурные решения (приоритет: ВЫСОКИЙ)

### 4.1 Dispatch-таблицы вместо цепочки сериализаторов

**Текущая проблема:**
- Цепочка сериализаторов делает до 7 проверок типов для каждого объекта (O(N))
- Неэффективно для частых вызовов

**Требования:**
- Использовать dispatch-таблицы для O(1) поиска обработчика
- Хранить обработчики в словаре `dict[Type, Callable]`

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- В `__init__()` создать dispatch-таблицы:
  ```python
  self._pack_handlers: dict[Type, Callable[[Any], Any]] = {
      datetime.datetime: self._pack_datetime,
      datetime.date: self._pack_date,
      Decimal: self._pack_decimal,
      set: self._pack_set,
  }
  # ObjectId добавляется условно, если pymongo установлен
  if ObjectId:
      self._pack_handlers[ObjectId] = self._pack_object_id
  ```
- **ВАЖНО**: ObjectId должен быть в dispatch-таблице, а не отдельной проверкой для консистентности кода
- В `pack()` использовать:
  ```python
  obj_type = type(obj)
  handler = self._pack_handlers.get(obj_type)
  if handler:
      return handler(obj)
  ```

**Критерии приемки:**
- ✅ Поиск обработчика O(1) вместо O(N)
- ✅ Производительность улучшена для частых вызовов

**Ссылки:**
- `comparison_report.md` раздел "Архитектурные улучшения" → "Замена цепочки на dispatch-таблицы"

### 4.2 Использование orjson как быстрого движка (без passthrough)

**Требования:**
- Использовать `orjson.dumps()` как быстрый JSON-движок.
- Все нестандартные типы (datetime, date, Decimal, ObjectId, Pydantic, dataclass, set) должны проходить через `pack()` для добавления маркеров типов.
- **Не использовать** `OPT_PASSTHROUGH_DATETIME` и `OPT_PASSTHROUGH_DATACLASS`, чтобы не потерять маркеры типов.
- Опционально оставить `default` как аварийный обработчик для неожиданных типов (или опустить, если `pack` покрывает всё).

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- В `dumps()`:
  ```python
  import orjson
  # Вариант 1 (рекомендуемый, если pack покрывает все типы):
  return orjson.dumps(self.pack(value))

  # Вариант 2 (если нужен fallback):
  return orjson.dumps(
      self.pack(value),
      default=self._orjson_default,  # обработчик для неожиданных типов
  )
  ```
- Логика обработки datetime/dataclass должна быть в `pack()` с добавлением маркеров, а не делегирована orjson.

**Критерии приемки:**
- ✅ Маркеры типов для datetime/dataclass/моделей сохраняются (нет потери при сериализации).
- ✅ Нет использования `OPT_PASSTHROUGH_DATETIME` и `OPT_PASSTHROUGH_DATACLASS`.
- ✅ Производительность на уровне orjson без лишних преобразований.

**Ссылки:**
- `comparison_report.md` раздел "Архитектурные улучшения" → корректировка пункта по orjson

### 4.3 Объединение Pydantic/Dataclass сериализаторов

**Требования:**
- Единая логика для обоих типов моделей
- Использование общих функций где возможно

**Реализация:**
- Файл: `src/redis_json_serializer/serializer.py`
- Методы `_pack_pydantic()` и `_pack_dataclass()` используют общую логику:
  - Получение алиаса через `MODEL_ALIASES` (O(1))
  - Извлечение данных из модели
  - Формирование словаря с маркером типа

**Критерии приемки:**
- ✅ Код не дублируется
- ✅ Оба типа моделей обрабатываются одинаково

**Ссылки:**
- `comparison_report.md` раздел "Архитектурные улучшения" → "Объединение сериализаторов"

### 4.4 Стабильные алиасы для моделей

**Требования:**
- Параметр `alias` в `@register_model()` обязателен для production
- Алиас не зависит от структуры модулей (не ломается при рефакторинге)
- Поддержка версионирования через алиасы (например, `"user.v1"`, `"user.v2"`)

**Реализация:**
- Файл: `src/redis_json_serializer/registry.py`
- В `register_model()`:
  ```python
  def register_model(alias: str | None = None) -> Callable[[Type[T]], Type[T]]:
      def decorator(cls: Type[T]) -> Type[T]:
          model_key = alias or get_key_model(cls)  # Использовать алиас если есть
          # ... регистрация
  ```

**Критерии приемки:**
- ✅ Алиас не меняется при перемещении класса между модулями
- ✅ Поддержка версионирования через алиасы

**Ссылки:**
- `comparison_report.md` раздел "Архитектурные улучшения" → "Стабильные алиасы"

### 4.5 Оптимизация поиска алиаса

**Требования:**
- O(1) поиск алиаса модели через `MODEL_ALIASES`
- Избегать вызова `get_key_model()` при каждом `pack()`

**Реализация:**
- Файл: `src/redis_json_serializer/registry.py`
- В `register_model()` сохранять в `MODEL_ALIASES`:
  ```python
  REGISTERED_MODELS[model_key] = cls
  MODEL_ALIASES[cls] = model_key  # O(1) lookup
  ```
- В `_pack_pydantic()` и `_pack_dataclass()` использовать:
  ```python
  model_key = MODEL_ALIASES.get(cls)  # O(1)
  if model_key is None:
      # Fallback: try to generate key
  ```

**Критерии приемки:**
- ✅ Поиск алиаса O(1) вместо O(N) или вызова функции
- ✅ Производительность улучшена

**Ссылки:**
- `comparison_report.md` раздел "Архитектурные улучшения" → "Оптимизация поиска алиаса"

---

## 5. Приоритеты задач

### Фаза 1: Критические исправления (ПРИОРИТЕТ: ВЫСОКИЙ)
1. ✅ Исправление генерации ключей кэша (`utils.py`)
2. ✅ Убрать агрессивную конвертацию строк
3. ✅ Исправить ResponseSerializer

### Фаза 2: Архитектурные улучшения (ПРИОРИТЕТ: ВЫСОКИЙ)
1. ✅ Реализовать dispatch-таблицы
2. ✅ Использовать возможности orjson
3. ✅ Объединить Pydantic/Dataclass сериализаторы
4. ✅ Реализовать стабильные алиасы
5. ✅ Оптимизировать поиск алиаса
6. ✅ Добавить namespace для версионирования

### Фаза 3: Доработка (ПРИОРИТЕТ: СРЕДНИЙ)
1. Проброс `expected_type` в коллекции
2. Улучшение обработки ошибок
3. Добавление тестов

### Фаза 4: Подготовка к PyPI (ПРИОРИТЕТ: СРЕДНИЙ)
1. Расширение документации
2. Финальное тестирование
3. Публикация на PyPI

---

## 6. Критерии приемки

### 6.1 Функциональные требования
- ✅ Все базовые типы сериализуются и десериализуются корректно
- ✅ Pydantic модели и dataclass поддерживаются
- ✅ Регистрация моделей работает корректно
- ✅ Интеграция с aiocache работает
- ✅ Ключи кэша генерируются стабильно

### 6.2 Требования к производительности
- ✅ Dispatch-таблицы обеспечивают O(1) поиск
- ✅ Нет лишних преобразований строк
- ✅ Используются возможности orjson

### 6.3 Требования к безопасности
- ✅ Только зарегистрированные модели могут быть десериализованы
- ✅ Whitelist-подход предотвращает произвольное выполнение кода

### 6.4 Требования к качеству кода
- ✅ Все тесты проходят
- ✅ Покрытие тестами > 80%
- ✅ Код соответствует стилю (ruff, black)
- ✅ Типы проверены (mypy)

---

## 7. Структура файлов для реализации

### 7.1 Основные файлы
```
src/redis_json_serializer/
├── __init__.py          # Экспорт API (готово)
├── serializer.py        # Основной сериализатор (требует реализации)
├── registry.py          # Регистрация моделей (требует реализации)
├── utils.py            # Утилиты (требует реализации)
├── types.py            # Маркеры типов (готово)
└── aiocache.py         # Интеграция с aiocache (требует реализации)
```

### 7.2 Тесты
```
tests/
├── test_serializer.py   # Тесты сериализатора (структура готова)
├── test_registry.py     # Тесты регистрации (структура готова)
└── test_utils.py        # Тесты утилит (структура готова)
```

---

## 8. Ссылки на документацию

### 8.1 Основная документация
- `README.md` - общее описание проекта
- `START_HERE.md` - точка входа для команды разработки
- `DEVELOPMENT.md` - архитектурные решения и требования
- `TODO.md` - список задач с приоритетами
- `PROJECT_STATUS.md` - текущий статус проекта

### 8.2 Анализ и предложения
- `../../notes/cache_serialization/comparison_report.md` - сравнительный анализ предложений AI
- `../../notes/cache_serialization/README.md` - описание оригинальной системы
- `../../notes/cache_serialization/ai_responses/` - предложения от AI

### 8.3 Примеры
- `examples/basic_usage.py` - базовое использование
- `examples/with_pydantic.py` - с Pydantic моделями
- `examples/with_aiocache.py` - с aiocache

---

## 9. Процесс разработки

### 9.1 Начало работы
1. Изучить `START_HERE.md`
2. Изучить `DEVELOPMENT.md` и `comparison_report.md`
3. Ознакомиться со структурой проекта

### 9.2 Реализация
1. Начать с критических исправлений (Фаза 1)
2. Реализовать архитектурные улучшения (Фаза 2)
3. Написать тесты параллельно с кодом
4. Доработать функционал (Фаза 3)

### 9.3 Ревью
- Код проверяется на соответствие техническому заданию
- Проверяется реализация критических исправлений
- Проверяется соответствие архитектурным решениям
- Проверяется качество кода и тестов

### 9.4 Приемка
- Все тесты проходят
- Покрытие тестами > 80%
- Код соответствует стилю
- Документация обновлена

---

## 10. Контакты и вопросы

При возникновении вопросов:
1. Изучить документацию в `localdocs/`
2. Обратиться к ревьюеру (AI)
3. Проверить примеры в `examples/`

---

**Версия документа:** 1.0  
**Дата создания:** 2024-12-23  
**Статус:** Актуально

