# План реализации redis-json-serializer

## Общая информация

**Статус:** В процессе реализации  
**Дата создания:** 2024-12-23  
**Версия плана:** 1.0  
**Последнее обновление:** 2024-12-23

## Прогресс выполнения

### Фаза 1: Критические исправления
- ✅ Задача 1.1: Исправление генерации ключей кэша — **ВЫПОЛНЕНО**
- ✅ Задача 1.2: Убрать агрессивную конвертацию строк — **ВЫПОЛНЕНО**
- ✅ Задача 1.3: Исправить ResponseSerializer — **ВЫПОЛНЕНО**

**🎉 Фаза 1 полностью завершена!**

### Фаза 2: Архитектурные улучшения
- ✅ Задача 2.1: Реализовать dispatch-таблицы — **ВЫПОЛНЕНО**
- ✅ Задача 2.2: Реализовать регистрацию моделей — **ВЫПОЛНЕНО**
- ✅ Задача 2.3: Реализовать обработку Pydantic и dataclass — **ВЫПОЛНЕНО**
- ✅ Задача 2.4: Реализовать обработку коллекций — **ВЫПОЛНЕНО**
- ✅ Задача 2.5: Реализовать `unpack()` — **ВЫПОЛНЕНО**
- ✅ Задача 2.6: Реализовать `dumps()` и `loads()` — **ВЫПОЛНЕНО**
- ✅ Задача 2.7: Реализовать интеграцию с aiocache — **ВЫПОЛНЕНО**

### Фаза 3: Доработка и тестирование
- ⏳ Все задачи в ожидании

### Фаза 4: Подготовка к PyPI
- ⏳ Все задачи в ожидании

**Общий прогресс:** 10 из 20+ задач выполнено (~50%)

**✅ Фаза 1 (Критические исправления) — 100% завершена!**
**✅ Фаза 2 (Архитектурные улучшения) — 100% завершена!**

## Структура плана

План разбит на фазы с учетом приоритетов из технического задания. Каждая фаза содержит детальные задачи с указанием:
- Файлов для изменения
- Методов/функций для реализации
- Критериев приемки
- Связей с диаграммами и ТЗ

---

## Фаза 1: Критические исправления (ПРИОРИТЕТ: ВЫСОКИЙ)

### Задача 1.1: Исправление генерации ключей кэша ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/utils.py`

#### 1.1.1 Реализовать `hash_args()` ✅

**Требования:**
- Сохранять порядок позиционных аргументов (НЕ сортировать!)
- Сортировать только keyword arguments для детерминированности
- Использовать `hashlib.sha1` для хэширования

**Реализация:**
```python
def hash_args(*args, **kwargs) -> str:
    import hashlib
    # Сохраняем порядок позиционных аргументов
    args_repr = repr(args).encode("utf-8")
    # Сортируем только kwargs для детерминированности
    kwargs_repr = repr(tuple(sorted(kwargs.items()))).encode("utf-8")
    return hashlib.sha1(args_repr + kwargs_repr).hexdigest()
```

**Критерии приемки:**
- ✅ `hash_args(1, 2)` и `hash_args(2, 1)` дают разные хэши
- ✅ `hash_args(a=1, b=2)` и `hash_args(b=2, a=1)` дают одинаковый хэш
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/utils.py`

**Ссылки:**
- ТЗ раздел 3.1
- Диаграмма: `key_generation.mmd`

#### 1.1.2 Реализовать `default_key_builder()` ✅

**Требования:**
- Использовать `module.qualname` вместо `str(func)`
- Комбинировать с результатом `hash_args()`
- Формат: `{module}.{qualname}:{hash}`

**Реализация:**
```python
def default_key_builder(func: Any, *args, **kwargs) -> str:
    module = getattr(func, "__module__", "")
    qualname = getattr(func, "__qualname__", getattr(func, "__name__", ""))
    func_key = f"{module}.{qualname}"
    args_hash = hash_args(*args, **kwargs)
    return f"{func_key}:{args_hash}"
```

**Критерии приемки:**
- ✅ Ключ стабилен между перезапусками (не содержит адресов в памяти)
- ✅ `default_key_builder(f, 1, 2)` и `default_key_builder(f, 2, 1)` дают разные ключи
- ✅ `default_key_builder(f, a=1, b=2)` и `default_key_builder(f, b=2, a=1)` дают одинаковый ключ
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/utils.py`

**Ссылки:**
- ТЗ раздел 3.1
- Диаграмма: `key_generation.mmd`

---

### Задача 1.2: Убрать агрессивную конвертацию строк ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/serializer.py`

#### 1.2.1 Реализовать `_convert_string_to_type()` ✅

**Требования:**
- Преобразовывать строки ТОЛЬКО при наличии `expected_type`
- Поддерживать: `Decimal`, `ObjectId`, `datetime.datetime`, `datetime.date`
- Безопасная обработка ошибок (возврат исходной строки при неудаче)

**Реализация:**
```python
def _convert_string_to_type(self, obj: str, expected_type: Type) -> Any:
    """Convert string to expected type (only when explicitly expected)."""
    # Если expected_type это str, возвращаем как есть
    if expected_type is str:
        return obj
    
    try:
        if expected_type is Decimal:
            return Decimal(obj)
        if expected_type is ObjectId and ObjectId:
            return ObjectId(obj)
        if expected_type is datetime.datetime:
            return datetime.datetime.fromisoformat(obj)
        if expected_type is datetime.date:
            return datetime.date.fromisoformat(obj)
    except (ValueError, TypeError, Exception):
        # Перехватываем все исключения, включая decimal.InvalidOperation
        pass
    return obj
```

**Критерии приемки:**
- ✅ Строка `"1.23"` остается строкой, если нет `expected_type=Decimal`
- ✅ Строка длиной 24 символа не преобразуется в `ObjectId` автоматически
- ✅ Преобразование работает только при явном указании `expected_type`
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 3.2
- Диаграмма: `unpack_flow.mmd` (ветка "expected_type указан?")

---

### Задача 1.3: Исправить ResponseSerializer ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/serializer.py`

#### 1.3.1 Добавить проверку Response в `pack()` ✅

**Требования:**
- Явно запретить сериализацию `Response` объектов
- Выбрасывать `TypeError` с информативным сообщением

**Реализация:**
```python
# Условный импорт Response (FastAPI)
try:
    from fastapi import Response
except ImportError:
    Response = None

# В методе pack(), после проверки простых типов:
if Response and isinstance(obj, Response):
    raise TypeError("Response objects cannot be serialized")
```

**Критерии приемки:**
- ✅ Попытка сериализации `Response` объекта выбрасывает `TypeError`
- ✅ Сообщение об ошибке информативное
- ✅ Тесты проходят
- ✅ Проверка работает только если FastAPI установлен (условный импорт)

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 3.3
- Диаграмма: `pack_flow.mmd` (ветка "Response?")

---

## Фаза 2: Архитектурные улучшения (ПРИОРИТЕТ: ВЫСОКИЙ)

### Задача 2.1: Реализовать dispatch-таблицы ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/serializer.py`

#### 2.1.1 Инициализация dispatch-таблиц в `__init__()` ✅

**Требования:**
- Создать `_pack_handlers` для типов при упаковке
- Создать `_unpack_handlers` для маркеров при распаковке
- Условно добавить `ObjectId` если `pymongo` установлен

**Реализация:**
```python
def __init__(self, namespace: str = ""):
    self.namespace = namespace
    
    # Dispatch-таблица для pack() - O(1) поиск обработчика по типу
    self._pack_handlers: dict[Type, Callable[[Any], Any]] = {
        datetime.datetime: self._pack_datetime,
        datetime.date: self._pack_date,
        Decimal: self._pack_decimal,
        set: self._pack_set,
    }
    
    # Условно добавляем ObjectId если pymongo установлен
    if ObjectId:
        self._pack_handlers[ObjectId] = self._pack_object_id
    
    # Dispatch-таблица для unpack() - O(1) поиск обработчика по маркеру
    self._unpack_handlers: dict[str, Callable[[dict], Any]] = {
        Marks.DATE: self._unpack_date,
        Marks.DATETIME: self._unpack_datetime,
        Marks.DECIMAL: self._unpack_decimal,
        Marks.OBJECT_ID: self._unpack_object_id,
        Marks.SET: self._unpack_set,
    }
```

**Критерии приемки:**
- ✅ Таблицы инициализируются в `__init__()`
- ✅ ObjectId добавляется условно
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 4.1
- Диаграмма: `dispatch_tables.mmd`

#### 2.1.2 Реализовать обработчики для базовых типов ✅

**Методы для реализации:**
- `_pack_datetime(obj: datetime.datetime) -> dict`
- `_pack_date(obj: datetime.date) -> dict`
- `_pack_decimal(obj: Decimal) -> dict`
- `_pack_set(obj: set) -> dict`
- `_pack_object_id(obj: ObjectId) -> dict`
- `_unpack_datetime(obj: dict) -> datetime.datetime`
- `_unpack_date(obj: dict) -> datetime.date`
- `_unpack_decimal(obj: dict) -> Decimal`
- `_unpack_set(obj: dict) -> set`
- `_unpack_object_id(obj: dict) -> ObjectId`

**Формат маркеров:**
```python
# Для pack:
{Marks.DATETIME: obj.isoformat()}
{Marks.DATE: obj.isoformat()}
{Marks.DECIMAL: str(obj)}
{Marks.SET: [pack(item) for item in obj]}
{Marks.OBJECT_ID: str(obj)}
```

**Критерии приемки:**
- ✅ Все обработчики реализованы
- ✅ Маркеры типов сохраняются корректно
- ✅ Обратная десериализация работает (round-trip тесты пройдены)
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 4.1
- Диаграмма: `dispatch_tables.mmd`

#### 2.1.3 Использовать dispatch-таблицы в `pack()` ✅

**Требования:**
- O(1) поиск обработчика через `type(obj)`
- Fallback на другие проверки (Pydantic, dataclass, коллекции)

**Реализация:**
```python
def pack(self, obj: Any) -> Any:
    # Простые типы (быстрая проверка)
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    
    # Проверка Response объектов
    if Response and isinstance(obj, Response):
        raise TypeError("Response objects cannot be serialized")
    
    # Dispatch-таблица (O(1) поиск обработчика)
    obj_type = type(obj)
    handler = self._pack_handlers.get(obj_type)
    if handler:
        return handler(obj)
    
    # Fallback: Pydantic, dataclass, коллекции...
    # (будет реализовано в следующих задачах)
    raise NotImplementedError(f"Packing for type {obj_type} not yet implemented")
```

**Критерии приемки:**
- ✅ Поиск обработчика O(1) вместо O(N)
- ✅ Производительность улучшена (10000 вызовов за ~7ms)
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 4.1
- Диаграмма: `pack_flow.mmd`

---

### Задача 2.2: Реализовать регистрацию моделей

**Файл:** `src/redis_json_serializer/registry.py`

#### 2.2.1 Реализовать `get_key_model()` ✅

**Требования:**
- Использовать `alias` если указан
- Fallback: `{module}.{qualname}` если alias не указан
- Поддержка версионирования через алиасы

**Реализация:**
```python
def get_key_model(cls: Type, alias: str | None = None) -> str:
    if alias:
        return alias
    
    # Fallback: use module.qualname for stable identification
    module = getattr(cls, "__module__", "")
    qualname = getattr(cls, "__qualname__", getattr(cls, "__name__", ""))
    return f"{module}.{qualname}"
```

**Критерии приемки:**
- ✅ Алиас используется если указан
- ✅ Fallback работает корректно (module.qualname или module.name)
- ✅ Поддержка версионирования через алиасы (user.v1, user.v2)
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/registry.py`

**Ссылки:**
- ТЗ раздел 2.1.5, 4.4
- Диаграмма: `registration_flow.mmd`

#### 2.2.2 Реализовать `register_model()` ✅

**Требования:**
- Проверка типа (Pydantic или dataclass)
- Проверка дубликатов (с предупреждением при повторной регистрации того же класса)
- Сохранение в `REGISTERED_MODELS` и `MODEL_ALIASES`
- Защита от дублирования алиасов

**Реализация:**
```python
def register_model(alias: str | None = None) -> Callable[[Type[T]], Type[T]]:
    def decorator(cls: Type[T]) -> Type[T]:
        # Проверка типа
        is_pydantic = (
            BaseModel is not None
            and isinstance(cls, type)
            and issubclass(cls, BaseModel)
        )
        is_dataclass = dataclasses.is_dataclass(cls)
        
        if not (is_pydantic or is_dataclass):
            raise TypeError(
                f"Model must be Pydantic BaseModel or dataclass, got {type(cls).__name__}"
            )
        
        # Генерация ключа
        model_key = get_key_model(cls, alias)
        
        # Проверка дубликатов
        if model_key in REGISTERED_MODELS:
            existing_cls = REGISTERED_MODELS[model_key]
            if existing_cls is cls:
                # Повторная регистрация того же класса - предупреждение
                warnings.warn(
                    f"Model {cls} already registered with key '{model_key}'. "
                    "Skipping duplicate registration.",
                    UserWarning,
                    stacklevel=2,
                )
                return cls
            else:
                raise ValueError(
                    f"Duplicate alias '{model_key}': already registered for {existing_cls}, "
                    f"cannot register {cls}"
                )
        
        # Регистрация
        REGISTERED_MODELS[model_key] = cls
        MODEL_ALIASES[cls] = model_key  # O(1) lookup
        
        return cls
    
    return decorator
```

**Критерии приемки:**
- ✅ Только Pydantic и dataclass могут быть зарегистрированы
- ✅ Дубликаты алиасов запрещены (ValueError при попытке зарегистрировать другой класс)
- ✅ Повторная регистрация того же класса - предупреждение (UserWarning)
- ✅ O(1) поиск алиаса через `MODEL_ALIASES`
- ✅ Работает с алиасом и без (fallback на module.qualname)
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/registry.py`

**Ссылки:**
- ТЗ раздел 2.1.5, 4.4, 4.5
- Диаграмма: `registration_flow.mmd`, `registry_flow.mmd`

#### 2.2.3 Реализовать `ModelRegistry` ✅

**Требования:**
- Методы: `register()`, `get()`, `get_alias()`, `is_registered()`
- Использовать те же глобальные словари

**Реализация:**
```python
class ModelRegistry:
    def register(self, cls: Type[T], alias: str | None = None) -> Type[T]:
        # Использовать тот же декоратор для консистентности
        return register_model(alias)(cls)
    
    def get(self, key: str) -> Type | None:
        return REGISTERED_MODELS.get(key)
    
    def get_alias(self, cls: Type) -> str | None:
        return MODEL_ALIASES.get(cls)
    
    def is_registered(self, cls: Type) -> bool:
        return cls in MODEL_ALIASES
```

**Критерии приемки:**
- ✅ Все методы работают корректно
- ✅ Используются глобальные словари (REGISTERED_MODELS и MODEL_ALIASES)
- ✅ Работает с моделями, зарегистрированными через @register_model
- ✅ Глобальный экземпляр registry доступен
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/registry.py`

**Ссылки:**
- ТЗ раздел 2.1.5

---

### Задача 2.3: Реализовать обработку Pydantic и dataclass ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/serializer.py`

#### 2.3.1 Реализовать `_pack_pydantic()` ✅

**Требования:**
- Проверка регистрации через `MODEL_ALIASES` (O(1))
- Извлечение данных из модели
- Формирование словаря с маркером `Marks.MODEL`
- Рекурсивная упаковка данных модели

**Реализация:**
```python
def _pack_pydantic(self, obj: Any) -> dict:
    cls = type(obj)
    model_key = MODEL_ALIASES.get(cls)
    
    if model_key is None:
        raise RegistrationError(
            f"Pydantic model {cls} is not registered. Use @register_model()"
        )
    
    # Извлечение данных (поддержка Pydantic v1 и v2)
    if hasattr(obj, 'model_dump'):
        # Pydantic v2
        data = obj.model_dump()
    else:
        # Pydantic v1
        data = obj.dict()
    
    # Рекурсивно упаковываем данные модели
    packed_data = {}
    for key, value in data.items():
        packed_data[key] = self.pack(value)
    
    return {Marks.MODEL: model_key, **packed_data}
```

**Критерии приемки:**
- ✅ Незарегистрированные модели выбрасывают `RegistrationError`
- ✅ Маркер `Marks.MODEL` сохраняется
- ✅ Данные извлекаются корректно (поддержка Pydantic v1 и v2)
- ✅ Рекурсивная упаковка данных модели работает (Decimal, datetime и т.д.)
- ✅ Интеграция в `pack()` после dispatch-таблицы
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.3, 4.3
- Диаграмма: `pack_flow.mmd`

#### 2.3.2 Реализовать `_pack_dataclass()` ✅

**Требования:**
- Единая логика с Pydantic
- Использование `dataclasses.asdict()`
- Рекурсивная упаковка данных

**Реализация:**
```python
def _pack_dataclass(self, obj: Any) -> dict:
    cls = type(obj)
    model_key = MODEL_ALIASES.get(cls)
    
    if model_key is None:
        raise RegistrationError(
            f"Dataclass {cls} is not registered. Use @register_model()"
        )
    
    # Извлечение данных из dataclass
    data = dataclasses.asdict(obj)
    
    # Рекурсивно упаковываем данные модели
    packed_data = {}
    for key, value in data.items():
        packed_data[key] = self.pack(value)
    
    return {Marks.MODEL: model_key, **packed_data}
```

**Критерии приемки:**
- ✅ Незарегистрированные dataclass выбрасывают `RegistrationError`
- ✅ Единая логика с Pydantic (та же структура результата)
- ✅ Рекурсивная упаковка данных работает (Decimal, datetime и т.д.)
- ✅ Интеграция в `pack()` после проверки Pydantic
- ✅ Проверка `is_dataclass(obj) and not isinstance(obj, type)` предотвращает обработку классов
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.4, 4.3
- Диаграмма: `pack_flow.mmd`

#### 2.3.3 Интегрировать в `pack()` ✅

**Требования:**
- Проверка Pydantic после dispatch-таблицы
- Проверка dataclass после Pydantic
- Вызов соответствующих методов

**Реализация:**
```python
# В методе pack(), после dispatch-таблицы:

# Проверка Pydantic моделей
if BaseModel and isinstance(obj, BaseModel):
    return self._pack_pydantic(obj)

# Проверка dataclass
if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
    return self._pack_dataclass(obj)
```

**Критерии приемки:**
- ✅ Порядок проверок корректный (dispatch → Pydantic → dataclass)
- ✅ Оба типа моделей обрабатываются через `pack()`
- ✅ Проверка `is_dataclass(obj) and not isinstance(obj, type)` предотвращает обработку классов
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- Диаграмма: `pack_flow.mmd`

---

### Задача 2.4: Реализовать обработку коллекций ✅ **ВЫПОЛНЕНО**

**Файл:** `src/redis_json_serializer/serializer.py`

#### 2.4.1 Реализовать обработку `list` и `tuple` в `pack()` ✅

**Требования:**
- Рекурсивный вызов `pack()` для элементов
- `tuple` преобразуется в `list` (JSON-массив)

**Реализация:**
```python
# В методе pack(), после проверки dataclass:
if isinstance(obj, (list, tuple)):
    return [self.pack(item) for item in obj]
```

**Критерии приемки:**
- ✅ Рекурсия работает корректно (вложенные list и tuple обрабатываются)
- ✅ `tuple` становится `list` (включая вложенные tuple)
- ✅ Рекурсивная упаковка элементов работает (Decimal, datetime, set и т.д.)
- ✅ Пустые list и tuple обрабатываются корректно
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.1
- Диаграмма: `pack_flow.mmd`

#### 2.4.2 Реализовать обработку `dict` в `pack()` ✅

**Требования:**
- Рекурсивный вызов `pack()` для значений
- Ключи остаются строками

**Реализация:**
```python
# В методе pack(), после обработки list/tuple:
if isinstance(obj, dict):
    return {k: self.pack(v) for k, v in obj.items()}
```

**Критерии приемки:**
- ✅ Рекурсия работает корректно (вложенные dict обрабатываются)
- ✅ Ключи не изменяются (остаются строками)
- ✅ Значения рекурсивно упаковываются (Decimal, datetime, set, list, tuple и т.д.)
- ✅ Пустые dict обрабатываются корректно
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- Диаграмма: `pack_flow.mmd`

---

### Задача 2.5: Реализовать `unpack()`

**Файл:** `src/redis_json_serializer/serializer.py`

#### 2.5.1 Реализовать обработку маркеров типов ✅

**Требования:**
- Проверка маркеров через dispatch-таблицу `_unpack_handlers`
- Обработка: `MODEL`, `DATE`, `DATETIME`, `DECIMAL`, `OBJECT_ID`, `SET`

**Реализация:**
```python
def unpack(self, obj: Any, expected_type: Type | None = None) -> Any:
    # None
    if obj is None:
        return None
    
    # Простые типы (быстрая проверка)
    if isinstance(obj, (str, int, float, bool)):
        return obj
    
    # Маркеры типов (dispatch-таблица) - проверяем dict с маркерами
    if isinstance(obj, dict):
        # Проверка маркеров через dispatch-таблицу (O(1))
        for marker, handler in self._unpack_handlers.items():
            if marker in obj:
                return handler(obj)
        
        # Проверка MODEL (обрабатывается отдельно)
        if Marks.MODEL in obj:
            return self._unpack_model(obj)
    
    # ... остальная логика (коллекции, строки с expected_type)
```

**Дополнительно реализовано:**
- Метод `_unpack_model()` для распаковки Pydantic и dataclass моделей
- Обработка простых типов для работы рекурсивных вызовов

**Критерии приемки:**
- ✅ Все маркеры обрабатываются (DATE, DATETIME, DECIMAL, SET, OBJECT_ID)
- ✅ Маркер MODEL обрабатывается отдельно
- ✅ Dispatch-таблица используется (O(1) поиск)
- ✅ Простые типы обрабатываются для рекурсивных вызовов
- ✅ Round-trip тесты для моделей проходят
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.2
- Диаграмма: `unpack_flow.mmd`

#### 2.5.2 Реализовать `_unpack_model()` ✅

**Требования:**
- Получение класса модели через `REGISTERED_MODELS`
- Проверка регистрации (выброс `RegistrationError` если не зарегистрирована)
- Рекурсивный unpack полей
- Создание экземпляра модели

**Реализация:**
```python
def _unpack_model(self, obj: dict) -> Any:
    from .registry import REGISTERED_MODELS
    
    model_key = obj[Marks.MODEL]
    cls = REGISTERED_MODELS.get(model_key)
    
    if cls is None:
        raise RegistrationError(
            f"Model with key '{model_key}' is not registered. Use @register_model()"
        )
    
    # Рекурсивный unpack полей
    data = {}
    for key, value in obj.items():
        if key != Marks.MODEL:
            # Получаем тип поля из аннотаций
            field_type = None
            if hasattr(cls, '__annotations__'):
                field_type = cls.__annotations__.get(key)
            data[key] = self.unpack(value, field_type)
    
    # Создание экземпляра
    if BaseModel and issubclass(cls, BaseModel):
        if hasattr(cls, 'model_validate'):
            # Pydantic v2
            return cls.model_validate(data)
        else:
            # Pydantic v1
            return cls(**data)
    else:
        # Dataclass
        return cls(**data)
```

**Критерии приемки:**
- ✅ Незарегистрированные модели выбрасывают `RegistrationError`
- ✅ Рекурсивный unpack работает (Decimal, datetime и т.д.)
- ✅ Экземпляры создаются корректно (Pydantic v1/v2 и dataclass)
- ✅ Получение типа из аннотаций работает
- ✅ Round-trip тесты для моделей проходят
- ✅ Тесты проходят

**Примечание:** Проброс типов из аннотаций для коллекций (например, `list[str]`) будет работать после реализации задачи 2.5.3 (обработка коллекций в `unpack()`).

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.2, 2.1.5
- Диаграмма: `unpack_flow.mmd`

#### 2.5.3 Реализовать обработку коллекций в `unpack()` ✅

**Требования:**
- Рекурсивный unpack элементов
- Проброс `expected_type` для `list[Type]`, `dict[str, Type]`, `tuple[Type1, Type2]`
- Восстановление `tuple` только при `expected_type=tuple[...]`

**Реализация:**
```python
from typing import get_origin, get_args

# В методе unpack(), после проверки маркеров типов:

# list
if isinstance(obj, list):
    if expected_type:
        origin = get_origin(expected_type)
        if origin is list:
            # list[Type]
            args = get_args(expected_type)
            elem_type = args[0] if args else None
            return [self.unpack(item, elem_type) for item in obj]
        elif origin is tuple:
            # tuple[Type1, Type2, ...] - восстановление tuple
            elem_types = get_args(expected_type)
            return tuple(
                self.unpack(item, elem_types[i] if i < len(elem_types) else None)
                for i, item in enumerate(obj)
            )
    
    # Без expected_type - просто рекурсивный unpack
    return [self.unpack(item) for item in obj]

# dict (обычный, без маркеров)
if isinstance(obj, dict):
    if expected_type:
        origin = get_origin(expected_type)
        if origin is dict:
            # dict[str, Type]
            args = get_args(expected_type)
            value_type = args[1] if len(args) > 1 else None
            return {k: self.unpack(v, value_type) for k, v in obj.items()}
    
    # Без expected_type - просто рекурсивный unpack
    return {k: self.unpack(v) for k, v in obj.items()}
```

**Критерии приемки:**
- ✅ Проброс `expected_type` работает для всех коллекций (`list[Type]`, `dict[str, Type]`, `tuple[Type1, Type2]`)
- ✅ `tuple` восстанавливается только при `expected_type=tuple[...]`
- ✅ `list` без `expected_type` остается `list` (не становится `tuple`)
- ✅ Рекурсия работает корректно (вложенные коллекции обрабатываются)
- ✅ Round-trip тесты для коллекций проходят
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.1.2, 3.1 (tuple)
- Диаграмма: `unpack_flow.mmd`

#### 2.5.4 Реализовать обработку строк в `unpack()` ✅

**Требования:**
- Преобразование только при наличии `expected_type`
- Обработка ISO datetime строк (от orjson)
- Использование `_convert_string_to_type()`

**Реализация:**
```python
# В методе unpack(), после обработки коллекций:

# Обработка строк
if isinstance(obj, str):
    # Преобразование при expected_type
    if expected_type:
        converted = self._convert_string_to_type(obj, expected_type)
        if converted is not obj:
            return converted
    
    # Обработка ISO datetime строк (от orjson)
    # Формат: "2024-12-23T10:30:00" или "2024-12-23T10:30:00.123456"
    if len(obj) >= 19 and obj[10] == 'T':
        try:
            return datetime.datetime.fromisoformat(obj)
        except (ValueError, TypeError):
            pass
    
    return obj
```

**Важные изменения:**
- Убрана строка из быстрой проверки простых типов (строка обрабатывается отдельно)
- Обработка строк происходит после проверки маркеров типов и коллекций
- Преобразование через `_convert_string_to_type()` только при наличии `expected_type`
- Автоматическое распознавание ISO datetime строк (формат от orjson)

**Критерии приемки:**
- ✅ Преобразование только при `expected_type` (Decimal, datetime, date, ObjectId)
- ✅ ISO datetime строки обрабатываются автоматически (без `expected_type`)
- ✅ Обычные строки остаются строками
- ✅ Строки с `expected_type=str` остаются строками
- ✅ Невалидные строки остаются строками (без ошибок)
- ✅ Все edge cases обработаны корректно
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 3.2
- Диаграмма: `unpack_flow.mmd`

---

### Задача 2.6: Реализовать `dumps()` и `loads()`

**Файл:** `src/redis_json_serializer/serializer.py`

#### 2.6.1 Реализовать `dumps()` ✅

**Требования:**
- Использовать `orjson.dumps()` для сериализации
- Вызывать `pack()` перед сериализацией
- Обработка namespace-обёртки (если `namespace` указан)

**Реализация:**
```python
def dumps(self, value: Any) -> bytes:
    import orjson
    
    # Pack объект (добавляет маркеры типов для нестандартных типов)
    packed = self.pack(value)
    
    # Namespace-обёртка (для версионирования)
    if self.namespace:
        packed = {"$ns": self.namespace, "$data": packed}
    
    # Сериализация через orjson (без passthrough опций, так как все типы уже обработаны в pack)
    return orjson.dumps(packed)
```

**Важное исправление:**
- Использование `str(Marks.KEY)` вместо `Marks.KEY` для ключей словаря, так как `orjson` не может сериализовать enum-ключи
- Все маркеры типов теперь сохраняются как строки в JSON

**Критерии приемки:**
- ✅ Сериализация работает для всех типов
- ✅ Namespace-обёртка добавляется при наличии `namespace`
- ✅ Маркеры типов сохраняются корректно (как строки)
- ✅ Round-trip тесты проходят
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.2.1, 4.2
- Диаграмма: `serialization_cycle.mmd`

#### 2.6.2 Реализовать `loads()` ✅

**Требования:**
- Использовать `orjson.loads()` для десериализации
- Обработка namespace-обёртки (извлечение `$data`)
- Вызов `unpack()` после десериализации

**Реализация:**
```python
def loads(self, value: bytes | None) -> Any:
    import orjson
    
    if value is None:
        return None
    
    # Десериализация через orjson
    data = orjson.loads(value)
    
    # Обработка namespace-обёртки
    if isinstance(data, dict) and "$ns" in data and "$data" in data:
        data = data["$data"]
    
    # Unpack объект (восстанавливает типы по маркерам)
    return self.unpack(data)
```

**Важное исправление:**
- Использование `str(Marks.KEY)` при чтении из словаря для консистентности
- Dispatch-таблица для unpack использует строковые ключи

**Критерии приемки:**
- ✅ Десериализация работает для всех типов
- ✅ Namespace-обёртка обрабатывается корректно
- ✅ Маркеры типов распознаются корректно
- ✅ Round-trip тесты проходят
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/serializer.py`

**Ссылки:**
- ТЗ раздел 2.2.1, 4.2
- Диаграмма: `serialization_cycle.mmd`

---

### Задача 2.7: Реализовать интеграцию с aiocache

**Файл:** `src/redis_json_serializer/aiocache.py`

#### 2.7.1 Реализовать `AiocacheJsonSerializer` ✅

**Требования:**
- Наследование от `BaseSerializer`
- Использование `JsonSerializer` внутри
- Реализация `dumps()` и `loads()`

**Реализация:**
```python
if BaseSerializer:
    class AiocacheJsonSerializer(BaseSerializer):
        """
        aiocache serializer adapter using JsonSerializer.
        
        This class provides integration with aiocache library by implementing
        the BaseSerializer interface and delegating to JsonSerializer.
        """
        DEFAULT_ENCODING = None
        
        def __init__(self, namespace: str = ""):
            super().__init__()
            from redis_json_serializer.serializer import JsonSerializer
            self._serializer = JsonSerializer(namespace=namespace)
        
        def dumps(self, value: Any) -> bytes:
            return self._serializer.dumps(value)
        
        def loads(self, value: bytes | None) -> Any:
            return self._serializer.loads(value)
```

**Дополнительно реализовано:**
- Условный экспорт в `__init__.py` (класс доступен только если aiocache установлен)
- Полная документация методов
- Поддержка namespace для версионирования

**Критерии приемки:**
- ✅ Класс наследуется от `BaseSerializer`
- ✅ Использует `JsonSerializer` внутри
- ✅ Реализует `dumps()` и `loads()`
- ✅ `DEFAULT_ENCODING = None` установлен
- ✅ Поддержка namespace работает
- ✅ Условный импорт работает (класс не определен если aiocache не установлен)
- ✅ Round-trip тесты проходят
- ✅ Тесты проходят

**Статус:** ✅ Реализовано в `src/redis_json_serializer/aiocache.py`

**Ссылки:**
- ТЗ раздел 2.1.6
- Диаграмма: `serialization_cycle.mmd`

---

## Фаза 3: Доработка и тестирование (ПРИОРИТЕТ: СРЕДНИЙ)

### Задача 3.1: Улучшение проброса expected_type

**Файл:** `src/redis_json_serializer/serializer.py`

#### 3.1.1 Улучшить обработку generic типов

**Требования:**
- Поддержка `typing.get_args()` и `typing.get_origin()` для совместимости
- Обработка вложенных generic типов
- Улучшенная обработка `Optional[Type]`

**Критерии приемки:**
- ✅ Все варианты generic типов обрабатываются
- ✅ Тесты проходят

---

### Задача 3.2: Улучшение обработки ошибок

**Файл:** `src/redis_json_serializer/serializer.py`, `src/redis_json_serializer/registry.py`

#### 3.2.1 Информативные сообщения об ошибках

**Требования:**
- Подсказки при незарегистрированных моделях
- Улучшенные сообщения для TypeError
- Обработка edge cases

**Критерии приемки:**
- ✅ Сообщения об ошибках информативные
- ✅ Подсказки помогают пользователю

---

### Задача 3.3: Написание тестов

**Файлы:** `tests/test_*.py`

#### 3.3.1 Тесты для всех компонентов

**Требования:**
- Покрытие > 80%
- Тесты для всех edge cases
- Интеграционные тесты с aiocache
- Тесты производительности

**Критерии приемки:**
- ✅ Все тесты проходят
- ✅ Покрытие > 80%

---

## Фаза 4: Подготовка к PyPI (ПРИОРИТЕТ: СРЕДНИЙ)

### Задача 4.1: Документация

- Обновить README.md
- Добавить docstrings
- Создать примеры использования
- Руководство по миграции

### Задача 4.2: CI/CD

- Настроить GitHub Actions
- Автоматические тесты
- Автоматическая публикация на PyPI

### Задача 4.3: Публикация

- Первый релиз v0.1.0
- Публикация на PyPI

---

## Порядок выполнения

### Рекомендуемая последовательность:

1. **Фаза 1** (критические исправления) - начать с этого
   - Задача 1.1 → Задача 1.2 → Задача 1.3

2. **Фаза 2** (архитектурные улучшения) - после Фазы 1
   - Задача 2.1 → Задача 2.2 → Задача 2.3 → Задача 2.4 → Задача 2.5 → Задача 2.6 → Задача 2.7

3. **Фаза 3** (доработка) - параллельно с тестами
   - Задача 3.1 → Задача 3.2 → Задача 3.3

4. **Фаза 4** (PyPI) - финальная подготовка

---

## Критерии готовности

### Готовность к использованию:
- ✅ Все задачи Фазы 1 выполнены
- ✅ Все задачи Фазы 2 выполнены
- ✅ Базовые тесты написаны и проходят

### Готовность к PyPI:
- ✅ Все задачи Фазы 3 выполнены
- ✅ Покрытие тестами > 80%
- ✅ Документация полная
- ✅ Примеры работают
- ✅ CI/CD настроен

---

## Примечания

- Все ссылки на ТЗ относятся к `technical_specification.md`
- Все ссылки на диаграммы относятся к `localdocs/diagrams/`
- При реализации следовать архитектурным решениям из ТЗ
- Тесты писать параллельно с кодом
- Документацию обновлять по мере реализации

---

**Версия плана:** 1.0  
**Дата создания:** 2024-12-23  
**Статус:** Готов к использованию

