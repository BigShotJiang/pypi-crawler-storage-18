# Описание скелетона проекта

## Что создано

### ✅ Структура проекта
- Полная структура пакета для PyPI (`src/redis_json_serializer/`)
- Структура тестов (`tests/`)
- Примеры использования (`examples/`)
- Конфигурация проекта (`pyproject.toml`, `Makefile`)
- CI/CD конфигурация (`.github/workflows/ci.yml`)
- Документация (README, CONTRIBUTING, DEVELOPMENT, TODO, PROJECT_STATUS, START_HERE)

### ✅ Файлы с кодом (заглушки)
Все файлы содержат только:
- Сигнатуры функций/классов
- Docstrings с описанием
- `TODO: Реализовать команде разработки`
- `raise NotImplementedError` в методах

**Файлы:**
- `src/redis_json_serializer/serializer.py` - основной сериализатор
- `src/redis_json_serializer/registry.py` - регистрация моделей
- `src/redis_json_serializer/utils.py` - утилиты (ключи кэша)
- `src/redis_json_serializer/aiocache.py` - интеграция с aiocache
- `src/redis_json_serializer/types.py` - маркеры типов (готово, enum)
- `src/redis_json_serializer/__init__.py` - экспорт API

### ✅ Тесты (структура)
Все тесты содержат:
- Структуру тестовых классов
- Заглушки методов с `pytest.skip("Not implemented yet")`
- Комментарии с описанием того, что нужно тестировать

**Файлы:**
- `tests/test_serializer.py` - тесты сериализатора
- `tests/test_registry.py` - тесты регистрации
- `tests/test_utils.py` - тесты утилит

### ✅ Примеры (закомментированы)
Все примеры содержат:
- Закомментированный код
- Комментарий `TODO: Раскомментировать после реализации`

**Файлы:**
- `examples/basic_usage.py` - базовое использование
- `examples/with_pydantic.py` - с Pydantic моделями
- `examples/with_aiocache.py` - с aiocache

### ✅ Документация
- `README.md` - документация для пользователей (с пометкой о статусе)
- `START_HERE.md` - точка входа для команды разработки
- `DEVELOPMENT.md` - архитектурные решения и требования
- `TODO.md` - список задач с приоритетами
- `PROJECT_STATUS.md` - текущий статус проекта
- `CONTRIBUTING.md` - руководство по контрибьюции
- `CHANGELOG.md` - история изменений

## Что НЕ реализовано (требует реализации командой)

### ❌ Весь функционал
- Все методы содержат `raise NotImplementedError`
- Все тесты пропускаются (`pytest.skip`)
- Все примеры закомментированы

### ❌ Критические исправления
Требуется реализовать на основе `comparison_report.md`:
1. Исправление генерации ключей кэша (`utils.py`)
2. Убрать агрессивную конвертацию строк
3. Исправить ResponseSerializer

### ❌ Архитектурные решения
Требуется реализовать на основе `DEVELOPMENT.md`:
1. Dispatch-таблицы вместо цепочки
2. Использование возможностей orjson
3. Стабильные алиасы для моделей
4. Оптимизация поиска алиаса
5. Namespace для версионирования

## Как использовать скелетон

1. **Команда разработки:**
   - Начинает с `START_HERE.md`
   - Изучает `DEVELOPMENT.md` и `comparison_report.md`
   - Реализует код по приоритетам из `TODO.md`
   - Отправляет на ревью

2. **Ревьюер (AI):**
   - Проверяет соответствие архитектурным решениям
   - Проверяет реализацию критических исправлений
   - Проверяет качество кода и тестов
   - Проверяет соответствие требованиям PyPI

## Структура файлов

```
redis-json-serializer/
├── src/redis_json_serializer/    # Код (заглушки)
│   ├── __init__.py               # Экспорт API
│   ├── serializer.py             # Основной сериализатор (TODO)
│   ├── registry.py               # Регистрация моделей (TODO)
│   ├── utils.py                  # Утилиты (TODO)
│   ├── aiocache.py               # Интеграция (TODO)
│   └── types.py                  # Маркеры типов (готово)
├── tests/                        # Тесты (структура)
│   ├── test_serializer.py        # TODO
│   ├── test_registry.py          # TODO
│   └── test_utils.py             # TODO
├── examples/                     # Примеры (закомментированы)
│   ├── basic_usage.py            # TODO
│   ├── with_pydantic.py          # TODO
│   └── with_aiocache.py          # TODO
├── pyproject.toml                # Конфигурация (готово)
├── README.md                      # Документация
├── START_HERE.md                  # Точка входа
├── DEVELOPMENT.md                 # Архитектурные решения
├── TODO.md                        # Список задач
└── PROJECT_STATUS.md              # Статус проекта
```

## Проверка скелетона

```bash
# Импорты работают
python3 -c "from src.redis_json_serializer import JsonSerializer; print('OK')"

# Методы выбрасывают NotImplementedError (как и должно быть)
python3 -c "from src.redis_json_serializer import JsonSerializer; s = JsonSerializer(); s.pack({})"
# Ожидается: NotImplementedError

# Тесты можно запустить (все пропустятся)
pytest tests/
```

## Следующие шаги

1. Команда разработки начинает реализацию
2. Ревьюер проверяет код на соответствие требованиям
3. После реализации - подготовка к публикации на PyPI





