---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "打开 CGS"
  text: "鼠标点几点轻松下漫画"
  tagline: 最自在
  image:
    src: /cgs_sleep.png
    alt: CGS
  actions:
    - theme: brand
      text: 快速上手
      link: /deploy/quick-start
    - theme: alt
      text: 配置
      link: /config
    - theme: brand
      text: 🎸功能
      link: /feat
    - theme: alt
      text: FAQ
      link: /faq
    - theme: sponsor
      text: 🍖投喂
      link: https://ko-fi.com/jsoneri

---

<table><tbody>  
  <tr>
    <td><div align="center"><a href="https://www.2025copy.com/" target="_blank">
      <img src="/assets/img/icons/website/copy.png" alt="logo" style="max-height: 80px">
      </a></div></td>
    <td><div align="center"><a href="https://mangabz.com" target="_blank">
      <img src="/assets/img/icons/website/mangabz.png" alt="logo" style="max-height: 80px">
      </a></div></td>
    <td><div align="center"><a href="https://18comic.vip/" target="_blank">
      <img src="/assets/img/icons/website/jm.png" alt="logo" style="max-height: 80px">
      </a></div></td>
    <td><div align="center"><a href="https://www.wnacg.com/" target="_blank">
      <img src="/assets/img/icons/website/wnacg.png" alt="logo" style="max-height: 80px">
      </a></div></td>
    <td><div align="center"><a href="https://exhentai.org/" target="_blank">
      <img src="/assets/img/icons/website/ehentai.png" alt="logo" style="max-height: 80px">
      </a></div></td>
    <td><div align="center"><a href="https://hitomi.la/" target="_blank">
      <img src="/assets/img/icons/website/hitomi.png" alt="logo" style="max-height: 80px">
      </a></div></td>
  </tr>
  <tr>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_kaobei.json"></td>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_mangabz.json"></td>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_jm.json"></td>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_wnacg.json"></td>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_ehentai.json"></td>
    <td><img src="https://img.shields.io/endpoint?url=https://cgs-status-badges.pages.dev/status_hitomi.json"></td>
  </tr>
</tbody></table>
<table><tbody>
  <tr>
    <td><img src="https://img.comicguispider.nyc.mn/file/1764957470369_common-usage.gif"></td>
    <td><img src="https://img.comicguispider.nyc.mn/file/1764957479778_load_clip.gif"></td>
  </tr>  
  <tr>
    <td><img src="https://img.comicguispider.nyc.mn/file/1764957291429_ags.gif"></td>
  </tr>  
</tbody></table>

## 功能特性

- 如上动图演示的多种使用方式，方便的内置重启，多开同时操作不同网站等
- 开预览后随便点点就能下载，预览窗口充当于微型浏览器
- 丰富多样的输入规则，能方便指定选择
- 基于翻页保留，体验如同塞进购物车
- 预设，去重，加标识符等自定义设置

## 食用搭配(阅读器)

`rV (redViewer)`, 完全适配 CGS  
已内置显眼按钮以及小窗管理，后续会基于 rV 展开  

[![点击前往redViewer](https://github-readme-stats.vercel.app/api/pin/?username=jasoneri&repo=redViewer&show_icons=true&bg_color=60,ef4057,cf4057,c44490&title_color=4df5b4&hide_border=true&icon_color=e9ede1&text_color=e9ede1)](https://github.com/jasoneri/redViewer)

## 致谢声明

### Credits

Thanks to

- [PyStand](https://github.com/skywind3000/PyStand) / [Platypus](https://github.com/sveinbjornt/Platypus) for providing win/macOS packaging.
- [Ditto](https://github.com/sabrogden/Ditto) / [Maccy](https://github.com/p0deje/Maccy) for providing great win/macOS Clipboard Soft.
- [PyQt-Fluent-Widgets](https://github.com/zhiyiYo/PyQt-Fluent-Widgets/) for providing elegant qfluent ui.
- [VitePress](https://vitepress.dev) for providing a great documentation framework.
- [astral-sh/uv](https://github.com/astral-sh/uv) for providing a great requirements manager.
- Every comic production team / translator team / fans.

## 贡献

欢迎提供 ISSUE 或者 PR

<a href="https://github.com/jasoneri/ComicGUISpider/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=jasoneri/ComicGUISpider" />
</a>

## 传播声明

- **请勿**将 ComicGUISpider 用于商业用途。
- **请勿**将 ComicGUISpider 制作为视频内容，于境内视频网站(版权利益方)传播。
- **请勿**将 ComicGUISpider 用于任何违反法律法规的行为。

ComicGUISpider 仅供学习交流使用。

## Licence

[MIT licence](https://github.com/jasoneri/ComicGUISpider/blob/GUI/LICENSE)

---

![CGS](https://count.getloli.com/get/@CGS?theme=asoul)
