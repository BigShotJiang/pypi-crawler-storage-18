# Eldar Mini ORM

Sadə və öyrədici Python ORM kitabxanası.

## Quraşdırma
pip install eldar-mini-orm

## İstifadə

```python
from eldar_mini_orm import Model

class User(Model):
    table_name = "users"
    name: str
    email: str

User.create_table()

u = User()
u.name = "Eldar"
u.email = "eldar@mail.com"
u.save()

print(User.all())
print(User.filter(name="Eldar"))
