"""Main entry point for the NoCapLang compiler CLI."""

import sys
import argparse
from pathlib import Path
from typing import Optional

from ..compiler import Compiler, Target


def main() -> int:
    """Main entry point for the NoCapLang compiler.
    
    Returns:
        Exit code (0 for success, non-zero for error)
    """
    parser = argparse.ArgumentParser(
        prog="nocap",
        description="NoCapLang - A Gen Z slang-based programming language compiler",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  nocap program.nocap              Compile to C++ (default)
  nocap --target cpp program.nocap Compile to C++
  nocap --target java program.nocap Compile to Java
  nocap --output myprogram program.nocap Specify output file
  nocap --repl                     Start interactive REPL
        """
    )
    
    parser.add_argument(
        "file",
        nargs="?",
        type=str,
        help="NoCapLang source file (.nocap)"
    )
    
    parser.add_argument(
        "--target",
        choices=["cpp", "java"],
        default="cpp",
        help="Target language for compilation (default: cpp)"
    )
    
    parser.add_argument(
        "--output", "-o",
        type=str,
        help="Output file path"
    )
    
    parser.add_argument(
        "--repl",
        action="store_true",
        help="Start interactive REPL"
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version="NoCapLang 0.1.0"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )
    
    parser.add_argument(
        "--no-optimize",
        action="store_true",
        help="Disable optimization passes"
    )
    
    args = parser.parse_args()
    
    # Start REPL if requested
    if args.repl:
        from ..repl import start_repl
        target = Target.CPP if args.target == "cpp" else Target.JAVA
        start_repl(target=target)
        return 0
    
    # Require input file if not in REPL mode
    if not args.file:
        parser.error("the following arguments are required: file (or use --repl)")
        return 1
    
    # Validate input file
    input_path = Path(args.file)
    if not input_path.exists():
        print(f"Error: File not found: {args.file}", file=sys.stderr)
        return 1
    
    if input_path.suffix != ".nocap":
        print(f"Warning: File does not have .nocap extension: {args.file}", file=sys.stderr)
    
    # Create compiler with specified target
    target = Target.CPP if args.target == "cpp" else Target.JAVA
    optimize = not args.no_optimize
    compiler = Compiler(target=target, verbose=args.verbose, optimize=optimize)
    
    # Determine output file
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = compiler.get_default_output_path(input_path)
    
    if args.verbose:
        print(f"Input: {input_path}")
        print(f"Output: {output_path}")
        print(f"Target: {args.target}")
    
    print(f"Compiling {input_path} to {args.target.upper()}...")
    
    # Compile the file
    result = compiler.compile_file(input_path, output_path)
    
    if result.success:
        print(f"✓ Compilation successful! Output written to: {output_path}")
        return 0
    else:
        print("✗ Compilation failed with errors:", file=sys.stderr)
        for error in result.errors:
            print(error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
