from setuptools import setup, find_packages
from pathlib import Path

# Read the README file for long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="nocaplang",
    version="0.1.3",
    description="NoCapLang - A Gen Z slang-based programming language that compiles to C++ or Java",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="NoCapLang Team",
    author_email="soumikmukherjee1608@gmail.com",
    license="MIT",
    packages=find_packages(where="python"),
    package_dir={"": "python"},
    install_requires=[
        "hypothesis>=6.0.0",  # Property-based testing
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=0.990",
        ],
    },
    entry_points={
        "console_scripts": [
            "nocap=nocaplang.cli.main:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Compilers",
        "Topic :: Software Development :: Code Generators",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    keywords="programming-language compiler gen-z slang nocap transpiler",
    python_requires=">=3.8",
    project_urls={
        "Documentation": "https://nocaplang.com/docs",
        "Bug Reports": "https://nocaplang.com/contact?type=bug",
        "Source": "https://nocaplang.com",
    },
)
