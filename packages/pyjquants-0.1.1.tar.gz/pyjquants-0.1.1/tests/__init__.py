"""Tests for pyjquants."""
