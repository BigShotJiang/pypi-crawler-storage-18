class RemovedInNextVersionWarning(DeprecationWarning):
    pass
