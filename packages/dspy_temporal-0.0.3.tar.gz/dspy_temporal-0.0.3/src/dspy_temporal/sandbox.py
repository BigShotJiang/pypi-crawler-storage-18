from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner, SandboxRestrictions


def get_passthrough_modules() -> list[str]:
    """Get the list of modules that should be passthrough by the sandbox."""
    return [
        "dspy",
        "litellm",
        "openai",
        "httpx",
        "urllib3",
    ]


def get_default_sandbox_restrictions() -> SandboxRestrictions:
    return SandboxRestrictions.default.with_passthrough_modules(*get_passthrough_modules())


def get_default_sandbox_runner(restrictions: SandboxRestrictions | None = None) -> SandboxedWorkflowRunner:
    if restrictions is None:
        restrictions = get_default_sandbox_restrictions()
    return SandboxedWorkflowRunner(restrictions=restrictions)
