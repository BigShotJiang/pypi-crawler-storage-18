"""Notes package."""
