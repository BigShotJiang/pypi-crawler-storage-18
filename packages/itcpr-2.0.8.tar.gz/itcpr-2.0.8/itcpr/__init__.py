"""ITCPR Agent - CLI tool for syncing GitHub repositories."""

__version__ = "2.0.8"

