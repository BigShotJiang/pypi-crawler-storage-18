from typing import Annotated, Any, Literal

from pydantic import BaseModel, BeforeValidator, Field, RootModel, StringConstraints, model_validator

from memu.prompts.memory_type import DEFAULT_MEMORY_TYPES
from memu.prompts.memory_type import PROMPTS as DEFAULT_MEMORY_TYPE_PROMPTS


def normalize_value(v: str) -> str:
    if isinstance(v, str):
        return v.strip().lower()
    return v


Normalize = BeforeValidator(normalize_value)


def _default_memory_types() -> list[str]:
    return list(DEFAULT_MEMORY_TYPES)


def _default_memory_type_prompts() -> dict[str, str]:
    return dict(DEFAULT_MEMORY_TYPE_PROMPTS)


def _default_memory_categories() -> list[dict[str, str]]:
    return [
        {"name": "personal_info", "description": "Personal information about the user"},
        {"name": "preferences", "description": "User preferences, likes and dislikes"},
        {"name": "relationships", "description": "Information about relationships with others"},
        {"name": "activities", "description": "Activities, hobbies, and interests"},
        {"name": "goals", "description": "Goals, aspirations, and objectives"},
        {"name": "experiences", "description": "Past experiences and events"},
        {"name": "knowledge", "description": "Knowledge, facts, and learned information"},
        {"name": "opinions", "description": "Opinions, viewpoints, and perspectives"},
        {"name": "habits", "description": "Habits, routines, and patterns"},
        {"name": "work_life", "description": "Work-related information and professional life"},
    ]


class LLMConfig(BaseModel):
    provider: str = Field(
        default="openai",
        description="Identifier for the LLM provider implementation (used by HTTP client backend).",
    )
    base_url: str = Field(default="https://api.openai.com/v1")
    api_key: str = Field(default="OPENAI_API_KEY")
    chat_model: str = Field(default="gpt-4o-mini")
    client_backend: str = Field(
        default="sdk",
        description="Which LLM client backend to use: 'httpx' (httpx) or 'sdk' (official OpenAI).",
    )
    endpoint_overrides: dict[str, str] = Field(
        default_factory=dict,
        description="Optional overrides for HTTP endpoints (keys: 'chat'/'summary').",
    )
    embed_model: str = Field(
        default="text-embedding-3-small",
        description="Default embedding model used for vectorization.",
    )
    embed_batch_size: int = Field(
        default=25,
        description="Maximum batch size for embedding API calls (used by SDK client backends).",
    )


class BlobConfig(BaseModel):
    provider: str = Field(default="local")
    resources_dir: str = Field(default="./data/resources")


class RetrieveConfig(BaseModel):
    """Configure retrieval behavior for `MemoryUser.retrieve`.

    Attributes:
        method: Retrieval strategy. Use "rag" for embedding-based vector search or
            "llm" to delegate ranking to the LLM.
        top_k: Maximum number of results to return per category (and per stage),
            controlling breadth of the retrieved context.
    """

    method: Annotated[Literal["rag", "llm"], Normalize] = "rag"
    top_k: int = Field(
        default=5,
        description="Maximum number of results to return per category.",
    )


class MemorizeConfig(BaseModel):
    category_assign_threshold: float = Field(default=0.25)
    default_summary_prompt: str = Field(default="Summarize the text in one short paragraph.")
    summary_prompts: dict[str, str] = Field(
        default_factory=dict,
        description="Optional mapping of modality -> summary system prompt.",
    )
    memory_categories: list[dict[str, str]] = Field(
        default_factory=_default_memory_categories,
        description="Global memory category definitions embedded at service startup.",
    )
    category_summary_target_length: int = Field(
        default=400,
        description="Target max length for auto-generated category summaries.",
    )
    memory_types: list[str] = Field(
        default_factory=_default_memory_types,
        description="Ordered list of memory types (profile/event/knowledge/behavior by default).",
    )
    memory_type_prompts: dict[str, str] = Field(
        default_factory=_default_memory_type_prompts,
        description="System prompt overrides for each memory type extraction.",
    )


class DefaultUserModel(BaseModel):
    user_id: str | None = None


class UserConfig(BaseModel):
    model: type[BaseModel] = Field(default=DefaultUserModel)


Key = Annotated[str, StringConstraints(min_length=1)]


class LLMProfilesConfig(RootModel[dict[Key, LLMConfig]]):
    root: dict[str, LLMConfig] = Field(default_factory=lambda: {"default": LLMConfig()})

    def get(self, key: str, default: LLMConfig | None = None) -> LLMConfig | None:
        return self.root.get(key, default)

    @model_validator(mode="before")
    @classmethod
    def ensure_default(cls, data: Any) -> Any:
        if data is None:
            return {"default": LLMConfig()}
        if isinstance(data, dict) and "default" not in data:
            data = dict(data)
            data["default"] = LLMConfig()
        return data

    @property
    def profiles(self) -> dict[str, LLMConfig]:
        return self.root

    @property
    def default(self) -> LLMConfig:
        return self.root.get("default", LLMConfig())


class MetadataStoreConfig(BaseModel):
    provider: Annotated[Literal["inmemory", "postgres"], Normalize] = "inmemory"
    ddl_mode: Annotated[Literal["create", "validate"], Normalize] = "create"
    dsn: str | None = Field(default=None, description="Postgres connection string when provider=postgres.")


class VectorIndexConfig(BaseModel):
    provider: Annotated[Literal["bruteforce", "pgvector", "none"], Normalize] = "bruteforce"
    dsn: str | None = Field(default=None, description="Postgres connection string when provider=pgvector.")


class DatabaseConfig(BaseModel):
    metadata_store: MetadataStoreConfig = Field(default_factory=MetadataStoreConfig)
    vector_index: VectorIndexConfig | None = Field(default=None)

    def model_post_init(self, __context: Any) -> None:
        if self.vector_index is None:
            if self.metadata_store.provider == "postgres":
                self.vector_index = VectorIndexConfig(provider="pgvector", dsn=self.metadata_store.dsn)
            else:
                self.vector_index = VectorIndexConfig(provider="bruteforce")
        elif self.vector_index.provider == "pgvector" and self.vector_index.dsn is None:
            self.vector_index = self.vector_index.model_copy(update={"dsn": self.metadata_store.dsn})
