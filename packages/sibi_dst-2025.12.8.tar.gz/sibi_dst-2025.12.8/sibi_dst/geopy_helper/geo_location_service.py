import os
import asyncio
from typing import Optional, Any, Union
from urllib.parse import urlparse
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderServiceError

app_nominatim_url = os.environ.get('NOMINATIM_URL', None)
app_geo_locator_test_place = os.environ.get('GEO_LOCATOR_TEST_PLACE', "San Jose, Costa Rica")


class GeolocationService:
    """
    Provides geolocation services, such as forward and reverse geocoding.

    This class interfaces with a geocoding service (e.g., Nominatim).
    Refactored to support lazy initialization and async execution to avoid
    blocking the main thread during startup or network I/O.
    """
    debug: bool = False

    def __init__(self, debug: bool = False):
        """
        Initialize the service without triggering network calls.
        """
        self.geolocator: Optional[Nominatim] = None
        self.debug = debug
        self._initialized = False

    def _ensure_geolocator(self) -> None:
        """
        Lazy initialization of the geolocator client.
        Checks environment variables and sets up the client if possible.
        """
        if self._initialized:
            return

        nominatim_url = app_nominatim_url
        if not nominatim_url:
            if self.debug:
                print("Nominatim URL not provided in environment variables.")
            self._initialized = True
            return

        try:
            parsed_url = urlparse(nominatim_url)
            # Domain for Nominatim init usually expects just the domain if custom,
            # or we might need the full scheme/url depending on geopy version quirks.
            # Preserving original logic: usage of netloc as domain
            domain = parsed_url.netloc
            
            # Note: Geopy's Nominatim 'domain' arg is for the hostname (e.g. 'nominatim.openstreetmap.org')
            # If using a custom server, 'scheme' and 'domain' must be set correctly.
            self.geolocator = Nominatim(user_agent="ibis", scheme="http", domain=domain)
            
            if self.debug:
                print(f"Geolocator client configured with domain: {domain}")
                
        except Exception as e:
            print(f"Error configuring geolocator: {e}")
            self.geolocator = None
        
        self._initialized = True

    def geocode(self, address: str) -> Any:
        """Synchronous geocode (blocking). deprecated for async contexts."""
        self._ensure_geolocator()
        if not self.geolocator:
            if self.debug:
                print("Geolocator is not available.")
            return None
        try:
            return self.geolocator.geocode(address)
        except (GeocoderTimedOut, GeocoderServiceError) as e:
            print(f"Error during geocoding: {e}")
            return None

    async def geocode_async(self, address: str) -> Any:
        """
        Asynchronous wrapper for geocode to prevent blocking the event loop.
        """
        return await asyncio.to_thread(self.geocode, address)

    def reverse(self, coordinates: Union[str, tuple], exactly_one: bool = True) -> Any:
        """Synchronous reverse geocode (blocking). deprecated for async contexts."""
        self._ensure_geolocator()
        if not self.geolocator:
            if self.debug:
                print("Geolocator is not available.")
            return None
        try:
            return self.geolocator.reverse(coordinates, exactly_one=exactly_one)
        except (GeocoderTimedOut, GeocoderServiceError) as e:
            print(f"Error during reverse geocoding: {e}")
            return None

    async def reverse_async(self, coordinates: Union[str, tuple], exactly_one: bool = True) -> Any:
        """
        Asynchronous wrapper for reverse geocoding to prevent blocking the event loop.
        """
        return await asyncio.to_thread(self.reverse, coordinates, exactly_one=exactly_one)
