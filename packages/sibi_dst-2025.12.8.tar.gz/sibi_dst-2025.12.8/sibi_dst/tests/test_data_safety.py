import pytest
import dask.dataframe as dd
import pandas as pd
from unittest.mock import MagicMock, patch
from sibi_dst.df_helper._df_helper import _maybe_compute, SqlAlchemyBackend, DfHelper

def test_maybe_compute_respects_limit():
    """Verify _maybe_compute uses head() when limit is provided."""
    # Create a mock dask dataframe
    df = dd.from_pandas(pd.DataFrame({'a': range(100)}), npartitions=2)
    
    # Test with limit
    result = _maybe_compute(df, as_pandas=True, limit=5)
    assert len(result) == 5
    assert isinstance(result, pd.DataFrame)
    
    # Test without limit
    result_full = _maybe_compute(df, as_pandas=True)
    assert len(result_full) == 100
    assert isinstance(result_full, pd.DataFrame)

def test_sqlalchemy_backend_propagates_exceptions():
    """Verify SqlAlchemyBackend.load raises exceptions instead of swallowing them."""
    mock_helper = MagicMock()
    mock_helper.logger = MagicMock()
    mock_helper.debug = False
    
    backend = SqlAlchemyBackend(mock_helper)
    
    # Mock the internal loader context manager to raise an exception
    with patch("sibi_dst.df_helper._df_helper.SqlAlchemyLoadFromDb") as MockLoader:
        instance = MockLoader.return_value
        instance.__enter__.side_effect = ValueError("Fatal DB Connection Error")
        
        with pytest.raises(ValueError, match="Fatal DB Connection Error"):
            backend.load(some_param="test")

    # Verify we didn't log a generic "Failed to load" error in the backend itself 
    # (since we removed the try/except)
    mock_helper.logger.error.assert_not_called()
