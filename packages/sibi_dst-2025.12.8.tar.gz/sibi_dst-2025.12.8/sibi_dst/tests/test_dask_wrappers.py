
import sys
from unittest.mock import MagicMock

# MOCK MISSING DEPENDENCIES BEFORE IMPORTS
# This allows testing utils without needing heavy GIS libs or DB drivers installed
sys.modules["geopandas"] = MagicMock()
sys.modules["osmnx"] = MagicMock()
sys.modules["shapely"] = MagicMock()
sys.modules["shapely.geometry"] = MagicMock()
sys.modules["fiona"] = MagicMock()
sys.modules["pyiceberg"] = MagicMock()
sys.modules["pyiceberg.catalog"] = MagicMock()
sys.modules["clickhouse_connect"] = MagicMock()

import asyncio
import pytest
import threading
from unittest.mock import MagicMock, patch
import pandas as pd
import dask.dataframe as dd

# Import target classes
from sibi_dst.utils.iceberg_saver import IcebergSaver
from sibi_dst.utils.clickhouse_writer import ClickHouseWriter
from sibi_dst.utils.df_utils import DfUtils
import fsspec

class MockFS(fsspec.AbstractFileSystem):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

@pytest.fixture
def mock_dask_df():
    pdf = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    return dd.from_pandas(pdf, npartitions=1)

@pytest.fixture
def mock_dask_huge_df():
    """A 'huge' DF with many partitions to trigger safety checks."""
    pdf = pd.DataFrame({"a": range(100), "b": range(100)})
    # npartitions=51 to exceed the default limit of 50
    return dd.from_pandas(pdf, npartitions=51)

@pytest.mark.asyncio
async def test_iceberg_asave_offloads_to_thread(mock_dask_df):
    """Verify asave runs save in a separate thread."""
    with patch.object(IcebergSaver, "save") as mock_save:
        # Capture the thread ID inside the mock
        captured_thread_id = None
        def side_effect(*args, **kwargs):
            nonlocal captured_thread_id
            captured_thread_id = threading.get_ident()
        
        mock_save.side_effect = side_effect
        
        # Init saver with dummies
        saver = IcebergSaver(
            df_result=mock_dask_df,
            catalog_name="mock_catalog",
            table_name="mock_table",
            fs=MockFS()
        )
        
        main_thread_id = threading.get_ident()
        await saver.asave(mode="append")
        
        assert mock_save.called
        assert captured_thread_id is not None
        assert captured_thread_id != main_thread_id, "save() ran on the main thread!"

@pytest.mark.asyncio
async def test_iceberg_overwrite_safety_guard(mock_dask_huge_df):
    """Verify that _overwrite_atomic raises ValueError if partitions > 50."""
    saver = IcebergSaver(
        df_result=mock_dask_huge_df,
        catalog_name="mock_catalog",
        table_name="mock_table",
        fs=MockFS(),
        repartition_size=None  # Disable repartitioning to preserve high partition count
    )
    
    # Needs to allow compute but we can mock map_partitions return
    # actually save -> _overwrite_atomic -> map_partitions..
    # We just want to check the pre-check.
    
    with pytest.raises(ValueError, match="Safety Guard"):
        # We can call the internal method directly or via save
        saver.save(mode="overwrite")

@pytest.mark.asyncio
async def test_clickhouse_asave_offloads_to_thread(mock_dask_df):
    """Verify asave_to_clickhouse runs in a separate thread."""
    with patch.object(ClickHouseWriter, "save_to_clickhouse") as mock_save:
        captured_thread_id = None
        def side_effect(*args, **kwargs):
            nonlocal captured_thread_id
            captured_thread_id = threading.get_ident()
        mock_save.side_effect = side_effect

        writer = ClickHouseWriter(
            host="localhost",
            table="test_table",
            database="default"
        )
        
        main_thread_id = threading.get_ident()
        await writer.asave_to_clickhouse(mock_dask_df)
        
        assert mock_save.called
        assert captured_thread_id != main_thread_id, "save_to_clickhouse() ran on the main thread!"

@pytest.mark.asyncio
async def test_df_utils_asummarise_offloads_to_thread(mock_dask_df):
    """Verify asummarise_data runs in a separate thread."""
    utils = DfUtils()
    
    with patch.object(utils, "summarise_data") as mock_summary:
        captured_thread_id = None
        def side_effect(*args, **kwargs):
            nonlocal captured_thread_id
            captured_thread_id = threading.get_ident()
            return pd.DataFrame()
        mock_summary.side_effect = side_effect
        
        main_thread_id = threading.get_ident()
        await utils.asummarise_data(mock_dask_df, "a", "b")
        
        assert mock_summary.called
        assert captured_thread_id != main_thread_id, "summarise_data() ran on the main thread!"
