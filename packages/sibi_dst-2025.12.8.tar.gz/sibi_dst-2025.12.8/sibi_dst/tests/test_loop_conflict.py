
import asyncio
import pytest
from sibi_dst.utils.dask_resilience.client_manager import get_persistent_client

async def async_worker():
    # Simulate work inside a Uvicorn-like loop
    loop = asyncio.get_running_loop()
    print(f"Running loop: {loop}")
    
    # Call the sync function directly (blocking the loop, which is what the user code does)
    # This triggers the "sync in async" pattern.
    client = get_persistent_client(n_workers=1, threads_per_worker=1)
    return client

@pytest.mark.asyncio
async def test_reproduce_loop_conflict():
    try:
        client = await async_worker()
        print(f"Success: {client}")
        client.close()
    except AssertionError as e:
        print(f"Caught expected AssertionError: {e}")
        raise
    except Exception as e:
        print(f"Caught unexpected {type(e)}: {e}")
        raise
