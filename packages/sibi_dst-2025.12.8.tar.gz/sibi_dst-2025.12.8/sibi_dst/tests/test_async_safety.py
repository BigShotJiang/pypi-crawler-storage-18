import pytest
import asyncio
import time
from unittest.mock import MagicMock, patch
from sibi_dst.geopy_helper.geo_location_service import GeolocationService
from sibi_dst.osmnx_helper.base_osm_map import BaseOsmMap

# ---- GeolocationService Tests ----

@pytest.mark.asyncio
async def test_geolocation_service_lazy_init():
    """Verify initialization is instant and does not trigger network calls."""
    start = time.perf_counter()
    service = GeolocationService(debug=True)
    duration = time.perf_counter() - start
    
    assert duration < 0.1, "Initialization took too long, likely blocking."
    assert service.geolocator is None, "Geolocator should be None before use."
    
    # Test lazy init logic (mocking env vars is tricky in parallel, so we just verify logic)
    with patch("sibi_dst.geopy_helper.geo_location_service.Nominatim") as MockNominatim:
        service._ensure_geolocator()
        assert service._initialized is True

@pytest.mark.asyncio
async def test_geolocation_service_async_wrappers():
    """Verify async wrappers delegate to thread and don't block loop."""
    service = GeolocationService()
    
    # Mock the synchronous methods to simulate blocking work
    with patch.object(service, "geocode", return_value="Mock Location") as mock_geocode:
        with patch.object(service, "reverse", return_value="Mock Address") as mock_reverse:
            
            # Run async wrappers
            loc = await service.geocode_async("test query")
            addr = await service.reverse_async((10, 10))
            
            assert loc == "Mock Location"
            assert addr == "Mock Address"
            
            # Verify they were called (implying to_thread worked)
            mock_geocode.assert_called_once()
            mock_reverse.assert_called_once()

# ---- BaseOsmMap Tests ----

class MockOsmMap(BaseOsmMap):
    """Subclass for testing, as BaseOsmMap is abstract."""
    def process_map(self):
        pass

@pytest.mark.asyncio
async def test_base_osm_map_deferred_init():
    """Verify deferred initialization is instant."""
    mock_graph = MagicMock()
    mock_df = MagicMock()
    mock_df.empty = False
    mock_df.copy.return_value = mock_df

    start = time.perf_counter()
    # defer_initialization=True should skip _prepare_df and _initialise_map
    map_obj = MockOsmMap(osmnx_graph=mock_graph, df=mock_df, defer_initialization=True)
    duration = time.perf_counter() - start
    
    assert duration < 0.1, "Init took too long, defer_initialization failed."
    assert map_obj.osm_map is None, "osm_map should be None when deferred."

@pytest.mark.asyncio
async def test_base_osm_map_async_init_factory():
    """Verify initialize_async runs heavy methods in thread."""
    mock_graph = MagicMock()
    mock_df = MagicMock()
    mock_df.empty = False  # satisfy validation
    mock_df.copy.return_value = mock_df

    map_obj = MockOsmMap(osmnx_graph=mock_graph, df=mock_df, defer_initialization=True)
    
    # Mock the heavy internal methods
    with patch.object(map_obj, "_prepare_df") as mock_prep:
        with patch.object(map_obj, "_initialise_map") as mock_init_map:
            
            await map_obj.initialize_async()
            
            mock_prep.assert_called_once()
            mock_init_map.assert_called_once()
