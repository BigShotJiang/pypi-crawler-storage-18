import pytest
import asyncio
import pandas as pd
import dask.dataframe as dd
from unittest.mock import MagicMock, AsyncMock, patch
from sibi_dst.utils.df_enricher.async_enricher import AsyncDfEnricher
from sibi_dst.utils.df_enricher.specs import AttachmentSpec

# Mock for AttachmentSpec.attachment_fn
async def mock_attachment_fn(**kwargs):
    return pd.DataFrame({"id": [1], "val": ["enriched"]})

@pytest.fixture
def mock_spec():
    return AttachmentSpec(
        key="test_spec",
        required_cols={"user_id"},
        attachment_fn=mock_attachment_fn,
        col_to_kwarg={"user_id": "user_ids"},
        left_on=["user_id"],
        right_on=["id"],
        drop_cols=[]
    )

@pytest.mark.asyncio
async def test_enricher_unique_limit_enforcement():
    """Verify Enricher raises ValueError if unique values exceed limit."""
    # Create DF with 20 unique values
    df = pd.DataFrame({"user_id": range(20)})
    ddf = dd.from_pandas(df, npartitions=1)
    
    # Init enricher with strict limit of 10
    enricher = AsyncDfEnricher(ddf, [], max_unique=10)
    
    # Direct test of private method _get_unique_values
    with pytest.raises(ValueError, match="exceeding limit"):
        await enricher._get_unique_values("user_id")

@pytest.mark.asyncio
async def test_enricher_parallel_setup(mock_spec):
    """Verify that spec kwargs are resolved."""
    df = pd.DataFrame({"user_id": [1, 2, 3]})
    ddf = dd.from_pandas(df, npartitions=1)
    
    enricher = AsyncDfEnricher(ddf, [mock_spec])
    
    # We want to verify that _resolve_spec_kwargs calls _get_unique_values
    # and returns the correct dict
    
    with patch.object(enricher, "_get_unique_values", side_effect=[[1, 2, 3]]) as mock_get_unique:
        resolved = await enricher._resolve_spec_kwargs(mock_spec)
        
        assert resolved == {"user_ids": [1, 2, 3]}
        mock_get_unique.assert_called_once_with("user_id")

@pytest.mark.asyncio
async def test_run_attachments_flow(mock_spec):
    """Verify the full run_attachments flow works with mocks."""
    df = pd.DataFrame({"user_id": [1]})
    ddf = dd.from_pandas(df, npartitions=1)
    
    enricher = AsyncDfEnricher(ddf, [mock_spec])
    
    with patch.object(enricher, "_resolve_spec_kwargs", return_value={"user_ids": [1]}) as mock_resolve:
        results, valid = await enricher._run_attachments(["user_id"])
        
        assert len(results) == 1
        assert "test_spec" in results
        assert valid == [mock_spec]
        mock_resolve.assert_called_once()
