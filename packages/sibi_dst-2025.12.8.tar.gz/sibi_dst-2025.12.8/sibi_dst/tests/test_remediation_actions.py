
import asyncio
import pytest
import datetime
import pandas as pd
import dask.dataframe as dd
from unittest.mock import MagicMock, patch, AsyncMock
from sqlalchemy.exc import OperationalError
from pydantic import SecretStr
import fsspec

from sibi_dst.df_helper.backends.sqlalchemy._load_from_db import SqlAlchemyLoadFromDb
from sibi_dst.df_helper.backends.sqlalchemy._db_connection import SqlAlchemyConnectionConfig
from sibi_dst.df_helper.backends.http._http_config import HttpConfig
from etl.extract.extract_wrapper import UpdateWrapper
from sibi_dst.utils import Logger
from sibi_dst.df_helper._df_helper import _maybe_compute

# Only available in recent python versions or with extra deps, but standard in this env
try:
    import httpx
except ImportError:
    httpx = None

@pytest.fixture
def mock_logger():
    return MagicMock(spec=Logger)

@pytest.fixture
def mock_fs():
    # UpdateWrapper checks isinstance(fs, AbstractFileSystem)
    fs = MagicMock(spec=fsspec.AbstractFileSystem)
    return fs

# ---------------------------------------------------------------------------
# 1. DB Failure Injection (Fix 1 verification - Adjusted)
# ---------------------------------------------------------------------------
def test_db_failure_propagation(mock_logger):
    """
    Verify that SqlAlchemyLoadFromDb handles exceptions by returning -1 and empty DF.
    (User requested safe handling of errors/empty results).
    """
    mock_conn_config = MagicMock(spec=SqlAlchemyConnectionConfig)
    
    # Create a dedicated mock for the model and explicitly attach __table__
    mock_model = MagicMock()
    mock_model.__name__ = "MockModel"  # Needed for logging access
    mock_table = MagicMock()
    mock_col = MagicMock()
    mock_col.name = "col1"
    mock_table.columns = [mock_col]
    
    # Use configure_mock to safely attach dunder-like attributes if needed, 
    # though simple assignment usually works.
    mock_model.configure_mock(**{"__table__": mock_table})
    
    mock_conn_config.model = mock_model
    mock_conn_config.engine = MagicMock()
    
    # Mocking the context manager to raise an error
    mock_loader_cm = MagicMock()
    mock_loader_cm.__enter__.side_effect = OperationalError("DB is dead", None, None)
    mock_loader_cm.__exit__.return_value = None

    with patch("sibi_dst.df_helper.backends.sqlalchemy._load_from_db.SQLAlchemyDask") as MockLoader:
        MockLoader.return_value = mock_loader_cm
        
        loader = SqlAlchemyLoadFromDb(
            plugin_sqlalchemy=mock_conn_config,
            logger=mock_logger
        )
        
        # Should NOT raise, but return -1 and empty dask df
        count, df = loader.build_and_load()
        assert count == -1
        assert isinstance(df, dd.DataFrame)
        assert "col1" in df.columns

# ---------------------------------------------------------------------------
# 2. DB Timeouts (Fix 2 verification)
# ---------------------------------------------------------------------------
def test_db_connection_timeouts():
    """
    Verify create_engine receives connect_args={'connect_timeout': 10}.
    """
    with patch("sibi_dst.df_helper.backends.sqlalchemy._db_connection.create_engine") as mock_create:
        # Use model_construct (v2) to bypass validation
        config = SqlAlchemyConnectionConfig.model_construct(
            connection_url=SecretStr("postgresql://user:pass@host/db"),
            table="my_table",
            pool_size=5,
            max_overflow=10,
            pool_timeout=30,
            pool_recycle=1800,
            pool_pre_ping=True,
            logger_extra={}
        )
        # Manually trigger the engine init logic we want to test
        config._engine_key_instance = ("dummy_key",)
        config._logger = MagicMock()
        
        # Now call the method under test
        config._init_engine()
        
        assert mock_create.called
        args, kwargs = mock_create.call_args
        assert "connect_args" in kwargs
        assert kwargs["connect_args"]["connect_timeout"] == 10

# ... (HTTP pooling test was correct, keeping it or assuming it is outside this chunk) ...

# ---------------------------------------------------------------------------
# 7. Cancellation Propagation
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_update_wrapper_async_entry_and_cleanup(mock_logger, mock_fs):
    """
    Verify that entering async context starts the cluster, and exit cleans it up.
    """
    wrapper = UpdateWrapper(wrapped_classes={}, logger=mock_logger, fs=mock_fs)
    
    # Mock the internal start method to avoid real cluster spawning
    with patch.object(wrapper, "_start_dask_cluster") as mock_start:
        async with wrapper as w:
            assert w is wrapper
            mock_start.assert_called_once()
            
            # Pretend client was created 
            w.dask_client = MagicMock()
            w.dask_client.close = MagicMock() 
            w.dask_client.shutdown = MagicMock()
            
            # CRITICAL: dask_utils._has_inflight checks scheduler_info.
            # If it returns a Mock, it might evaluate as "having inflight tasks" and skip close.
            # Ensure it looks empty.
            w.dask_client.scheduler_info.return_value = {
                "processing": {}, 
                "tasks": 0, 
                "task_counts": {}
            }
            
            w.own_dask_client = True
        
        # On exit, client should be closed
        assert w.dask_client.close.called or w.dask_client.shutdown.called

# ---------------------------------------------------------------------------
# 8. Compute Limits check
# ---------------------------------------------------------------------------
def test_compute_limits_safety():
    """
    Verify _maybe_compute respects limit param to avoid OOM.
    """
    # Create a 'large' dask dataframe (conceptually)
    pdf = pd.DataFrame({"a": range(1000)})
    ddf = dd.from_pandas(pdf, npartitions=10)
    
    # Request only 10 rows
    result = _maybe_compute(ddf, as_pandas=True, limit=10)
    
    assert len(result) == 10
    assert isinstance(result, pd.DataFrame)
