
import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from main import app

def test_lifespan_dask_cleanup():
    """
    Verify that shutting down the FastAPI app (via TestClient context)
    calls `force_close_persistent_client` to prevent Dask leaks.
    """
    with patch("main.force_close_persistent_client") as mock_close:
        # TestClient with 'with' block triggers startup/shutdown lifespan
        with TestClient(app) as client:
            # Startup phase - nothing specific yet verify app is up
            response = client.get("/docs")
            assert response.status_code == 200
            
            # Shutdown has not happened yet
            mock_close.assert_not_called()
        
        # Shutdown phase - triggered on exit
        mock_close.assert_called_once()

# Future: Add tests for middleware blocking checks if needed
# For now, lifespan cleanup is the critical safety fix we promised.
