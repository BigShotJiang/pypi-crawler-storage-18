
import asyncio
import pytest
from sibi_dst.utils.dask_resilience.client_manager import get_persistent_client

@pytest.mark.asyncio
async def test_persistent_client_in_async_loop():
    """
    Verify that get_persistent_client() works when called synchronously 
    from within an async function (running event loop).
    This reproduces the 'assert loop is not None' crash.
    """
    print("\nCalling get_persistent_client from async loop...")
    # This call is synchronous, but we are in an async task.
    # Without the fix, this crashes.
    client = get_persistent_client(n_workers=1, threads_per_worker=1)
    
    print(f"Client obtained: {client}")
    assert client.status == "running"
    
    # Clean up
    client.close()
    await asyncio.sleep(0.5)
