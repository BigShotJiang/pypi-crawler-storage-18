
import pytest
import pandas as pd
import dask.dataframe as dd
from sibi_dst.utils.df_enricher.merger import DfMerger

def test_merger_int_float_mismatch():
    """
    Verify that merging Int64 (Left) with float64 (Right) works by casting Left -> Right.
    Current behavior (cast to string) fails because "1" != "1.0".
    Desired behavior: Left becomes float64 (1.0), matching Right.
    """
    # Left: Int64 [1, 2]
    pdf_left = pd.DataFrame({"id": pd.Series([1, 2], dtype="Int64"), "val": ["L1", "L2"]})
    ddf_left = dd.from_pandas(pdf_left, npartitions=1)

    # Right: float64 [1.0, 3.0] (1.0 should match 1)
    pdf_right = pd.DataFrame({"pid": [1.0, 3.0], "extra": ["R1", "R3"]})
    ddf_right = dd.from_pandas(pdf_right, npartitions=1)

    merger = DfMerger()
    
    # Merge Plan: left["id"] == right["pid"]
    merge_plan = [("key1", ["id"], ["pid"], [])]
    results = {"key1": ddf_right}
    
    # Run merge
    out = merger.apply_merges(ddf_left, results, merge_plan)
    res = out.compute()
    
    # Expectation: row with id=1 should pick up extra="R1"
    # If cast to string ("1" vs "1.0"), this will be NaN.
    # If cast to float, it matches.
    
    row1 = res[res["id"] == 1]
    assert not row1.empty
    assert row1["extra"].iloc[0] == "R1"
    assert row1["id"].dtype == "float64" or pd.api.types.is_float_dtype(row1["id"])

def test_merger_compound_key_mismatch():
    """Verify compound keys where one part matches and another needs casting."""
    # Left: id=Int64, code=string
    pdf_left = pd.DataFrame({
        "id": pd.Series([10, 20], dtype="Int64"),
        "code": ["A", "B"],
        "val": ["L10", "L20"]
    })
    ddf_left = dd.from_pandas(pdf_left, npartitions=1)

    # Right: pid=float64, pcode=string
    pdf_right = pd.DataFrame({
        "pid": [10.0, 99.0],
        "pcode": ["A", "C"],
        "info": ["Found", "Miss"]
    })
    ddf_right = dd.from_pandas(pdf_right, npartitions=1)

    merger = DfMerger()
    # Merge on (id, code) == (pid, pcode)
    merge_plan = [("mix", ["id", "code"], ["pid", "pcode"], [])]
    results = {"mix": ddf_right}

    out = merger.apply_merges(ddf_left, results, merge_plan)
    res = out.compute()

    # Expectation: 10/A should match 10.0/A
    row = res[res["id"] == 10]
    assert not row.empty
    assert row["info"].iloc[0] == "Found"

def test_merger_mixed_string_numeric():
    """Verify that Int vs String casts to String (safe fallback)."""
    # Left: id=Int64
    pdf_left = pd.DataFrame({"id": pd.Series([10, 20], dtype="Int64"), "val": ["A", "B"]})
    ddf_left = dd.from_pandas(pdf_left, npartitions=1)
    
    # Right: pid=string "10"
    pdf_right = pd.DataFrame({"pid": ["10", "20"], "extra": ["X", "Y"]})
    ddf_right = dd.from_pandas(pdf_right, npartitions=1)
    
    merger = DfMerger()
    merge_plan = [("key", ["id"], ["pid"], [])]
    results = {"key": ddf_right}
    
    # Should cast Left 'id' to string to match Right 'pid'
    out = merger.apply_merges(ddf_left, results, merge_plan)
    res = out.compute()
    
    row = res[res["val"] == "A"]
    assert not row.empty
    assert row["extra"].iloc[0] == "X"
    # Ensure id became string (or object)
    assert pd.api.types.is_string_dtype(res["id"]) or res["id"].dtype == "object"
