from setuptools import setup, find_packages

setup(
    name="aerri_ai",  # package name on PyPI
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "langchain-groq",
        "langgraph",
        "youtube-transcript-api",
    ],
    entry_points={
        "console_scripts": [
            "aerri-ai=copilot.cli:main",  # CLI command to run your main()
        ]
    },
    python_requires=">=3.10",
    author="Adu",
    description="Advanced AI coding assistant CLI tool",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/username/aerri_ai",  # your repo URL
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
