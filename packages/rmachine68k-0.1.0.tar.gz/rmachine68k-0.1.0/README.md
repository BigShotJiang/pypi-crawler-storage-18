# rmachine68k - run machine68k as a remote service

- written by Christian Vogelgsang <chris@vogelgsang.org>
- under the GNU Public License V2

## Introduction

`rmachine68k` is a Python package that allows to access a
`machine68k` remotely.

## Prerequisites

- Python >= ```3.9```
- [rpyc][2]
- [machine68k][1]

## Installation

### Stable/Release Version

```bash
pip3 install rmachine68k
```

Note:

- on Linux/macOS may use ``sudo`` to install for all users
- the version may be a bit outdated. If you need recent changes use the
  current version.

### Current Version from GitHub

Ensure you have rpyc installed:

```bash
pip3 install rpyc
```

Then install `rmachine68k` directly from the git repository:

```bash
pip3 install -U git+https://github.com/cnvogelg/rmachine68k.git
```

Or if you have a local clone of the repository:

```bash
pip3 install .
```

Note:

- This will install the latest version found in the github repository.
- You find the latest features but it may also be unstable from time to time.
- Repeat this command to update to the latest version.

### Developers

- Follow this route if you want to hack around with the codebase
- Clone the Git repo: [`rmachine68k@git`](https://github.com/cnvogelg/rmachine68k)

- Enter the directory of the cloned repo and install via pip:

```bash
pip3 install -U -e .
```

This install `rmachine68k` in your current Python environment but takes the
source files still from this repository. So you can change the code there
and directly test the machine.

## Usage

### Tools

The package contains two executable scripts

* `rm68kd` the `machine68k` server process
* `rm68k-cli` a small client to test the server

### Run the server

Just run `m68kd` with arguments on a shell to get a default server running.

### Run the client

While the server is running issue `m68k-cli` to test the server connection.


[1]: https://github.com/cnvogelg/machine68k
[2]: https://rpyc.readthedocs.io/en/latest/

