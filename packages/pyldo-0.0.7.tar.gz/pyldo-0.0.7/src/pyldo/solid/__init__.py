"""
Solid integration module for pyldo.

Provides authentication and client functionality for interacting with Solid Pods.
"""

from .auth import (
    ClientCredentials,
    DPoPToken,
    SolidAuth,
    SolidSession,
)
from .client import (
    SolidClient,
    SolidContainer,
    SolidResource,
)
from .webid import (
    WebIdProfile,
    fetch_webid_profile,
)

__all__ = [
    # Authentication
    "SolidAuth",
    "SolidSession",
    "DPoPToken",
    "ClientCredentials",
    # Client
    "SolidClient",
    "SolidResource",
    "SolidContainer",
    # WebID
    "WebIdProfile",
    "fetch_webid_profile",
]
