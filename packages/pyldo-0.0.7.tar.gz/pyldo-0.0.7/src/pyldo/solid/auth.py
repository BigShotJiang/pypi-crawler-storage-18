"""
Solid authentication module.

Implements DPoP (Demonstration of Proof-of-Possession) token authentication
and client credentials flow for Solid Pod access.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urlparse

import httpx
import jwt
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec


@dataclass
class ClientCredentials:
    """Client credentials for Solid authentication."""
    
    client_id: str
    client_secret: str
    token_endpoint: Optional[str] = None
    
    @classmethod
    def from_json(cls, data: dict) -> "ClientCredentials":
        """Create credentials from JSON data (e.g., from client registration)."""
        return cls(
            client_id=data["client_id"],
            client_secret=data["client_secret"],
            token_endpoint=data.get("token_endpoint"),
        )
    
    @classmethod
    def from_file(cls, path: str) -> "ClientCredentials":
        """Load credentials from a JSON file."""
        with open(path, "r") as f:
            return cls.from_json(json.load(f))


@dataclass
class DPoPToken:
    """
    DPoP (Demonstration of Proof-of-Possession) token handler.
    
    DPoP is used by Solid servers to bind access tokens to a specific client
    by requiring proof of possession of a private key.
    """
    
    private_key: ec.EllipticCurvePrivateKey = field(default_factory=lambda: None)
    public_key: ec.EllipticCurvePublicKey = field(default=None)
    _jwk_thumbprint: Optional[str] = field(default=None, repr=False)
    
    def __post_init__(self):
        """Generate a new EC key pair if not provided."""
        if self.private_key is None:
            self.private_key = ec.generate_private_key(
                ec.SECP256R1(),
                default_backend()
            )
        if self.public_key is None:
            self.public_key = self.private_key.public_key()
    
    def get_public_jwk(self) -> dict:
        """Get the public key as a JWK (JSON Web Key)."""
        public_numbers = self.public_key.public_numbers()
        
        # Convert coordinates to base64url
        x_bytes = public_numbers.x.to_bytes(32, byteorder="big")
        y_bytes = public_numbers.y.to_bytes(32, byteorder="big")
        
        return {
            "kty": "EC",
            "crv": "P-256",
            "x": base64.urlsafe_b64encode(x_bytes).rstrip(b"=").decode("ascii"),
            "y": base64.urlsafe_b64encode(y_bytes).rstrip(b"=").decode("ascii"),
        }
    
    def get_jwk_thumbprint(self) -> str:
        """Calculate the JWK thumbprint (used for token binding)."""
        if self._jwk_thumbprint is None:
            jwk = self.get_public_jwk()
            # Canonical JSON representation per RFC 7638
            canonical = json.dumps(
                {"crv": jwk["crv"], "kty": jwk["kty"], "x": jwk["x"], "y": jwk["y"]},
                separators=(",", ":"),
                sort_keys=True,
            )
            digest = hashlib.sha256(canonical.encode()).digest()
            self._jwk_thumbprint = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        return self._jwk_thumbprint
    
    def create_proof(self, method: str, url: str, access_token: Optional[str] = None) -> str:
        """
        Create a DPoP proof JWT for the given HTTP method and URL.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            url: Target URL
            access_token: Optional access token to bind (for authenticated requests)
        
        Returns:
            DPoP proof JWT string
        """
        # Parse URL to get just scheme + authority + path (no query/fragment)
        parsed = urlparse(url)
        htu = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        
        # Build the DPoP proof claims
        claims = {
            "jti": str(uuid.uuid4()),
            "htm": method.upper(),
            "htu": htu,
            "iat": int(time.time()),
        }
        
        # If we have an access token, include its hash (ath claim)
        if access_token:
            token_hash = hashlib.sha256(access_token.encode()).digest()
            claims["ath"] = base64.urlsafe_b64encode(token_hash).rstrip(b"=").decode("ascii")
        
        # Build the header with the public key
        headers = {
            "typ": "dpop+jwt",
            "alg": "ES256",
            "jwk": self.get_public_jwk(),
        }
        
        # Sign the JWT
        return jwt.encode(claims, self.private_key, algorithm="ES256", headers=headers)


@dataclass
class SolidSession:
    """
    Active Solid authentication session.
    
    Holds access tokens and handles token refresh.
    """
    
    access_token: str
    token_type: str = "DPoP"
    expires_at: Optional[float] = None
    refresh_token: Optional[str] = None
    webid: Optional[str] = None
    dpop: Optional[DPoPToken] = None
    _token_endpoint: Optional[str] = None
    _client_id: Optional[str] = None
    _client_secret: Optional[str] = None
    
    @property
    def is_expired(self) -> bool:
        """Check if the access token has expired."""
        if self.expires_at is None:
            return False
        return time.time() >= self.expires_at - 60  # 60 second buffer
    
    def get_auth_headers(self, method: str, url: str) -> dict:
        """
        Get authorization headers for an HTTP request.
        
        Args:
            method: HTTP method
            url: Request URL
        
        Returns:
            Dict of headers to add to the request
        """
        headers = {}
        
        if self.token_type == "DPoP" and self.dpop:
            # DPoP authentication
            headers["Authorization"] = f"DPoP {self.access_token}"
            headers["DPoP"] = self.dpop.create_proof(method, url, self.access_token)
        else:
            # Bearer token fallback
            headers["Authorization"] = f"Bearer {self.access_token}"
        
        return headers
    
    async def refresh(self, http_client: httpx.AsyncClient) -> bool:
        """
        Refresh the access token using the refresh token.
        
        Returns:
            True if refresh succeeded, False otherwise
        """
        if not self.refresh_token or not self._token_endpoint:
            return False
        
        try:
            # Prepare DPoP proof for token endpoint
            dpop_proof = None
            if self.dpop:
                dpop_proof = self.dpop.create_proof("POST", self._token_endpoint)
            
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            if dpop_proof:
                headers["DPoP"] = dpop_proof
            
            data = {
                "grant_type": "refresh_token",
                "refresh_token": self.refresh_token,
                "client_id": self._client_id,
            }
            if self._client_secret:
                data["client_secret"] = self._client_secret
            
            response = await http_client.post(
                self._token_endpoint,
                headers=headers,
                data=data,
            )
            response.raise_for_status()
            
            token_data = response.json()
            self.access_token = token_data["access_token"]
            if "refresh_token" in token_data:
                self.refresh_token = token_data["refresh_token"]
            if "expires_in" in token_data:
                self.expires_at = time.time() + token_data["expires_in"]
            
            return True
            
        except Exception:
            return False


class SolidAuth:
    """
    Solid authentication handler.
    
    Supports client credentials flow with DPoP for machine-to-machine auth.
    """
    
    def __init__(
        self,
        credentials: Optional[ClientCredentials] = None,
        issuer: Optional[str] = None,
    ):
        """
        Initialize Solid auth handler.
        
        Args:
            credentials: Client credentials for authentication
            issuer: OIDC issuer URL (e.g., https://solidcommunityserver.net)
        """
        self.credentials = credentials
        self.issuer = issuer
        self._openid_config: Optional[dict] = None
        self._dpop = DPoPToken()
    
    async def discover_openid_config(self, http_client: httpx.AsyncClient) -> dict:
        """
        Discover OpenID Connect configuration from the issuer.
        
        Returns:
            OpenID configuration dict
        """
        if self._openid_config:
            return self._openid_config
        
        if not self.issuer:
            raise ValueError("No issuer configured for OIDC discovery")
        
        # Fetch .well-known/openid-configuration
        config_url = f"{self.issuer.rstrip('/')}/.well-known/openid-configuration"
        response = await http_client.get(config_url)
        response.raise_for_status()
        
        self._openid_config = response.json()
        return self._openid_config
    
    async def login_with_credentials(
        self,
        http_client: httpx.AsyncClient,
        credentials: Optional[ClientCredentials] = None,
    ) -> SolidSession:
        """
        Authenticate using client credentials flow.
        
        This is typically used for server-to-server authentication where
        a client has been pre-registered with the identity provider.
        
        Args:
            http_client: HTTP client for making requests
            credentials: Optional credentials override
        
        Returns:
            SolidSession with access token
        """
        creds = credentials or self.credentials
        if not creds:
            raise ValueError("No credentials provided")
        
        # Get token endpoint
        token_endpoint = creds.token_endpoint
        if not token_endpoint:
            config = await self.discover_openid_config(http_client)
            token_endpoint = config["token_endpoint"]
        
        # Generate DPoP proof
        dpop_proof = self._dpop.create_proof("POST", token_endpoint)
        
        # Request token
        response = await http_client.post(
            token_endpoint,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "DPoP": dpop_proof,
            },
            data={
                "grant_type": "client_credentials",
                "client_id": creds.client_id,
                "client_secret": creds.client_secret,
            },
        )
        response.raise_for_status()
        
        token_data = response.json()
        
        # Calculate expiration time
        expires_at = None
        if "expires_in" in token_data:
            expires_at = time.time() + token_data["expires_in"]
        
        # Extract WebID from id_token if present
        webid = None
        if "id_token" in token_data:
            try:
                # Decode without verification to extract WebID
                id_token = jwt.decode(
                    token_data["id_token"],
                    options={"verify_signature": False}
                )
                webid = id_token.get("webid") or id_token.get("sub")
            except Exception:
                pass
        
        return SolidSession(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "DPoP"),
            expires_at=expires_at,
            refresh_token=token_data.get("refresh_token"),
            webid=webid,
            dpop=self._dpop,
            _token_endpoint=token_endpoint,
            _client_id=creds.client_id,
            _client_secret=creds.client_secret,
        )
    
    @staticmethod
    async def fetch_unauthenticated(
        http_client: httpx.AsyncClient,
        url: str,
    ) -> tuple[str, str]:
        """
        Fetch a public Solid resource without authentication.
        
        Args:
            http_client: HTTP client
            url: Resource URL
        
        Returns:
            Tuple of (content, content_type)
        """
        response = await http_client.get(
            url,
            headers={"Accept": "text/turtle, application/ld+json"},
        )
        response.raise_for_status()
        
        content_type = response.headers.get("content-type", "text/turtle")
        return response.text, content_type
