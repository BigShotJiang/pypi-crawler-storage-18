"""
Solid client for interacting with Solid Pods.

Provides high-level operations for fetching, updating, and managing
resources in Solid Pods using the Solid Protocol.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx
from rdflib import RDF, Graph, Namespace, URIRef

from .auth import SolidAuth, SolidSession

# Solid-specific namespaces
LDP = Namespace("http://www.w3.org/ns/ldp#")
PIM = Namespace("http://www.w3.org/ns/pim/space#")
SOLID = Namespace("http://www.w3.org/ns/solid/terms#")
ACL = Namespace("http://www.w3.org/ns/auth/acl#")


@dataclass
class SolidResource:
    """
    Represents a resource in a Solid Pod.
    
    Contains the resource's URL, content, metadata, and RDF graph.
    """
    
    url: str
    content: Optional[str] = None
    content_type: str = "text/turtle"
    graph: Optional[Graph] = None
    etag: Optional[str] = None
    wac_allow: Optional[dict] = None  # Access control info
    last_modified: Optional[str] = None
    
    @property
    def is_container(self) -> bool:
        """Check if this resource is a container (folder)."""
        return self.url.endswith("/")
    
    @property
    def name(self) -> str:
        """Get the resource name from the URL."""
        parsed = urlparse(self.url)
        path = parsed.path.rstrip("/")
        return path.split("/")[-1] if path else ""
    
    def parse_graph(self) -> Graph:
        """Parse the content into an RDF graph."""
        if self.graph is None:
            self.graph = Graph()
            if self.content:
                if "json" in self.content_type:
                    self.graph.parse(data=self.content, format="json-ld", publicID=self.url)
                else:
                    self.graph.parse(data=self.content, format="turtle", publicID=self.url)
        return self.graph
    
    def get_contained_resources(self) -> list[str]:
        """
        Get URLs of resources contained in this container.
        
        Returns:
            List of resource URLs if this is a container, empty list otherwise
        """
        if not self.is_container:
            return []
        
        graph = self.parse_graph()
        container = URIRef(self.url)
        
        contained = []
        for obj in graph.objects(container, LDP.contains):
            contained.append(str(obj))
        
        return contained


@dataclass
class SolidContainer(SolidResource):
    """
    Represents a container (folder) in a Solid Pod.
    
    Extends SolidResource with container-specific functionality.
    """
    
    children: list[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Ensure URL ends with slash for containers."""
        if not self.url.endswith("/"):
            self.url = self.url + "/"


class SolidClient:
    """
    High-level client for interacting with Solid Pods.
    
    Provides methods for:
    - Fetching resources (GET)
    - Creating resources (POST/PUT)
    - Updating resources (PATCH with SPARQL UPDATE)
    - Deleting resources (DELETE)
    - Managing containers
    """
    
    def __init__(
        self,
        session: Optional[SolidSession] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ):
        """
        Initialize the Solid client.
        
        Args:
            session: Optional authenticated session
            http_client: Optional HTTP client (created if not provided)
        """
        self.session = session
        self._http_client = http_client
        self._owns_client = http_client is None
    
    async def __aenter__(self) -> "SolidClient":
        """Async context manager entry."""
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                follow_redirects=True,
                timeout=30.0,
            )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._owns_client and self._http_client:
            await self._http_client.aclose()
    
    @property
    def http(self) -> httpx.AsyncClient:
        """Get the HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                follow_redirects=True,
                timeout=30.0,
            )
            self._owns_client = True
        return self._http_client
    
    def _get_auth_headers(self, method: str, url: str) -> dict:
        """Get authentication headers for a request."""
        if self.session:
            return self.session.get_auth_headers(method, url)
        return {}
    
    async def get(
        self,
        url: str,
        accept: str = "text/turtle",
    ) -> SolidResource:
        """
        Fetch a resource from a Solid Pod.
        
        Args:
            url: Resource URL
            accept: Preferred content type
        
        Returns:
            SolidResource with the fetched content
        """
        headers = {
            "Accept": accept,
            **self._get_auth_headers("GET", url),
        }
        
        response = await self.http.get(url, headers=headers)
        response.raise_for_status()
        
        # Parse WAC-Allow header if present
        wac_allow = None
        if "wac-allow" in response.headers:
            wac_allow = self._parse_wac_allow(response.headers["wac-allow"])
        
        content_type = response.headers.get("content-type", "text/turtle")
        # Strip charset from content type
        if ";" in content_type:
            content_type = content_type.split(";")[0].strip()
        
        return SolidResource(
            url=str(response.url),  # Use final URL after redirects
            content=response.text,
            content_type=content_type,
            etag=response.headers.get("etag"),
            wac_allow=wac_allow,
            last_modified=response.headers.get("last-modified"),
        )
    
    async def get_container(self, url: str) -> SolidContainer:
        """
        Fetch a container from a Solid Pod.
        
        Args:
            url: Container URL (should end with /)
        
        Returns:
            SolidContainer with contained resources
        """
        if not url.endswith("/"):
            url = url + "/"
        
        resource = await self.get(url)
        
        container = SolidContainer(
            url=resource.url,
            content=resource.content,
            content_type=resource.content_type,
            graph=resource.graph,
            etag=resource.etag,
            wac_allow=resource.wac_allow,
            last_modified=resource.last_modified,
        )
        
        # Parse contained resources
        container.children = container.get_contained_resources()
        
        return container
    
    async def put(
        self,
        url: str,
        content: str,
        content_type: str = "text/turtle",
        if_none_match: bool = False,
        if_match: Optional[str] = None,
    ) -> SolidResource:
        """
        Create or replace a resource.
        
        Args:
            url: Resource URL
            content: Resource content
            content_type: Content MIME type
            if_none_match: Set True to only create if resource doesn't exist
            if_match: ETag to match for conditional update
        
        Returns:
            SolidResource representing the created/updated resource
        """
        headers = {
            "Content-Type": content_type,
            **self._get_auth_headers("PUT", url),
        }
        
        if if_none_match:
            headers["If-None-Match"] = "*"
        if if_match:
            headers["If-Match"] = if_match
        
        response = await self.http.put(url, headers=headers, content=content)
        response.raise_for_status()
        
        return SolidResource(
            url=str(response.url),
            content=content,
            content_type=content_type,
            etag=response.headers.get("etag"),
        )
    
    async def post(
        self,
        container_url: str,
        content: str,
        content_type: str = "text/turtle",
        slug: Optional[str] = None,
        link_type: Optional[str] = None,
    ) -> SolidResource:
        """
        Create a new resource in a container.
        
        Args:
            container_url: Container URL
            content: Resource content
            content_type: Content MIME type
            slug: Suggested resource name
            link_type: Resource type (ldp:Resource or ldp:BasicContainer)
        
        Returns:
            SolidResource representing the created resource
        """
        headers = {
            "Content-Type": content_type,
            **self._get_auth_headers("POST", container_url),
        }
        
        if slug:
            headers["Slug"] = slug
        
        if link_type:
            headers["Link"] = f'<{link_type}>; rel="type"'
        
        response = await self.http.post(container_url, headers=headers, content=content)
        response.raise_for_status()
        
        # Get the created resource URL from Location header
        location = response.headers.get("location")
        if location:
            created_url = urljoin(container_url, location)
        else:
            created_url = container_url
        
        return SolidResource(
            url=created_url,
            content=content,
            content_type=content_type,
            etag=response.headers.get("etag"),
        )
    
    async def patch(
        self,
        url: str,
        sparql_update: str,
        if_match: Optional[str] = None,
    ) -> bool:
        """
        Update a resource using SPARQL UPDATE.
        
        Args:
            url: Resource URL
            sparql_update: SPARQL UPDATE query
            if_match: Optional ETag for conditional update
        
        Returns:
            True if update succeeded
        """
        headers = {
            "Content-Type": "application/sparql-update",
            **self._get_auth_headers("PATCH", url),
        }
        
        if if_match:
            headers["If-Match"] = if_match
        
        response = await self.http.patch(url, headers=headers, content=sparql_update)
        response.raise_for_status()
        
        return response.status_code in (200, 204)
    
    async def delete(
        self,
        url: str,
        if_match: Optional[str] = None,
    ) -> bool:
        """
        Delete a resource.
        
        Args:
            url: Resource URL
            if_match: Optional ETag for conditional delete
        
        Returns:
            True if deletion succeeded
        """
        headers = self._get_auth_headers("DELETE", url)
        
        if if_match:
            headers["If-Match"] = if_match
        
        response = await self.http.delete(url, headers=headers)
        response.raise_for_status()
        
        return response.status_code in (200, 204)
    
    async def create_container(
        self,
        parent_url: str,
        name: str,
    ) -> SolidContainer:
        """
        Create a new container (folder).
        
        Args:
            parent_url: Parent container URL
            name: Container name
        
        Returns:
            SolidContainer representing the created container
        """
        if not parent_url.endswith("/"):
            parent_url = parent_url + "/"
        
        resource = await self.post(
            container_url=parent_url,
            content="",
            content_type="text/turtle",
            slug=name,
            link_type=str(LDP.BasicContainer),
        )
        
        return SolidContainer(
            url=resource.url,
            content=resource.content,
            content_type=resource.content_type,
            etag=resource.etag,
        )
    
    async def delete_container(
        self,
        url: str,
        recursive: bool = False,
    ) -> bool:
        """
        Delete a container.
        
        Args:
            url: Container URL
            recursive: If True, delete all contained resources first
        
        Returns:
            True if deletion succeeded
        """
        if recursive:
            container = await self.get_container(url)
            for child_url in container.children:
                if child_url.endswith("/"):
                    await self.delete_container(child_url, recursive=True)
                else:
                    await self.delete(child_url)
        
        return await self.delete(url)
    
    async def resource_exists(self, url: str) -> bool:
        """
        Check if a resource exists.
        
        Args:
            url: Resource URL
        
        Returns:
            True if resource exists
        """
        headers = self._get_auth_headers("HEAD", url)
        
        try:
            response = await self.http.head(url, headers=headers)
            return response.status_code == 200
        except httpx.HTTPStatusError:
            return False
    
    @staticmethod
    def _parse_wac_allow(header: str) -> dict:
        """
        Parse WAC-Allow header to extract permissions.
        
        Example header: user="read write", public="read"
        """
        permissions = {}
        
        # Parse user="..." and public="..." parts
        pattern = r'(\w+)="([^"]*)"'
        matches = re.findall(pattern, header)
        
        for key, value in matches:
            permissions[key] = value.split()
        
        return permissions
