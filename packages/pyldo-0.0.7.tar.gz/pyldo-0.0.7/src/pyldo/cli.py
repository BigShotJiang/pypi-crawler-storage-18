"""
PyLDO Command Line Interface

Provides commands for generating Python code from ShEx schemas.

Usage:
    pyldo generate shapes/*.shex --output .ldo/
    pyldo init
"""

import sys
from pathlib import Path

import click


@click.group()
@click.version_option()
def main():
    """PyLDO - Linked Data Objects for Python.

    Generate type-safe Python code from ShEx schemas for working with RDF data.
    """
    pass


@main.command()
@click.argument("shex_files", nargs=-1, type=click.Path(exists=True, path_type=Path))
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default=Path(".ldo"),
    help="Output directory for generated files (default: .ldo/)",
)
@click.option(
    "--base-iri",
    "-b",
    type=str,
    default="http://example.org/",
    help="Base IRI for resolving relative IRIs",
)
def generate(shex_files: tuple[Path, ...], output: Path, base_iri: str):
    """Generate Python types and JSON-LD contexts from ShEx schemas.

    SHEX_FILES: One or more .shex files to process

    Example:
        pyldo generate shapes/person.shex shapes/post.shex -o .ldo/
    """
    if not shex_files:
        click.echo("Error: No ShEx files specified", err=True)
        click.echo("Usage: pyldo generate <shex_files> [--output <dir>]", err=True)
        sys.exit(1)

    # Ensure output directory exists
    output.mkdir(parents=True, exist_ok=True)

    try:
        from pyldo.converter import (
            generate_jsonld_context,
            generate_python_types,
            generate_schema_file,
            generate_shapetypes_file,
            parse_shex,
        )
        from pyldo.converter.context_generator import generate_context_file
    except ImportError as e:
        click.echo(f"Error: Missing dependency - {e}", err=True)
        click.echo("Install dependencies with: pip install pyldo[dev]", err=True)
        sys.exit(1)

    for shex_path in shex_files:
        click.echo(f"Processing {shex_path}...")

        try:
            # Read and parse ShEx
            shex_source = shex_path.read_text()
            schema = parse_shex(shex_source, base_iri)

            if not schema.shapes:
                click.echo(f"  Warning: No shapes found in {shex_path}", err=True)
                continue

            # Generate base filename
            base_name = shex_path.stem

            # Generate Python types
            types_code = generate_python_types(schema, base_name)
            types_path = output / f"{base_name}_types.py"
            types_path.write_text(types_code)
            click.echo(f"  Generated {types_path}")

            # Generate JSON-LD context
            context_var_name = f"{base_name}_context"
            context_code = generate_context_file(schema, context_var_name)
            context_path = output / f"{base_name}_context.py"
            context_path.write_text(context_code)
            click.echo(f"  Generated {context_path}")

            # Generate ShEx schema as JSON
            schema_var_name = f"{base_name}_schema"
            schema_code = generate_schema_file(schema, schema_var_name)
            schema_path = output / f"{base_name}_schema.py"
            schema_path.write_text(schema_code)
            click.echo(f"  Generated {schema_path}")

            # Generate ShapeTypes
            shapetypes_code = generate_shapetypes_file(
                schema,
                types_module=f"{base_name}_types",
                context_module=context_var_name,
                schema_module=schema_var_name,
            )
            shapetypes_path = output / f"{base_name}_shapetypes.py"
            shapetypes_path.write_text(shapetypes_code)
            click.echo(f"  Generated {shapetypes_path}")

            # Report shapes found
            shape_names = [s.id.rsplit("#", 1)[-1].rsplit("/", 1)[-1] for s in schema.shapes]
            click.echo(f"  Shapes: {', '.join(shape_names)}")

        except Exception as e:
            click.echo(f"  Error processing {shex_path}: {e}", err=True)
            continue

    click.echo("Done!")


@main.command()
@click.option(
    "--shapes-dir",
    "-s",
    type=click.Path(path_type=Path),
    default=Path("shapes"),
    help="Directory for ShEx schemas (default: shapes/)",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=Path(".ldo"),
    help="Output directory for generated files (default: .ldo/)",
)
def init(shapes_dir: Path, output_dir: Path):
    """Initialize a new pyldo project structure.

    Creates the necessary directories and a sample ShEx schema.
    """
    # Create directories
    shapes_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Create sample ShEx schema
    sample_shex = shapes_dir / "profile.shex"
    if not sample_shex.exists():
        sample_shex.write_text(
            '''# Sample profile shape for Solid Pod profiles
PREFIX foaf: <http://xmlns.com/foaf/0.1/>
PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

<ProfileShape> {
    a [ foaf:Person ] ;
    foaf:name xsd:string ;
    foaf:nick xsd:string ? ;
    foaf:mbox IRI ? ;
    foaf:knows @<ProfileShape> *
}
'''
        )
        click.echo(f"Created sample schema: {sample_shex}")
    else:
        click.echo(f"Sample schema already exists: {sample_shex}")

    # Create __init__.py in output dir
    init_file = output_dir / "__init__.py"
    if not init_file.exists():
        init_file.write_text(
            '"""Generated pyldo types and contexts."""\n'
        )
        click.echo(f"Created {init_file}")

    click.echo()
    click.echo("Project initialized! Next steps:")
    click.echo(f"  1. Edit your ShEx schemas in {shapes_dir}/")
    click.echo(f"  2. Run: pyldo generate {shapes_dir}/*.shex -o {output_dir}/")
    click.echo("  3. Import generated types in your code")


@main.command()
@click.argument("shex_file", type=click.Path(exists=True, path_type=Path))
def validate(shex_file: Path):
    """Validate a ShEx schema file.

    Checks if the schema can be parsed without generating any output.
    """
    try:
        from pyldo.converter import parse_shex
    except ImportError as e:
        click.echo(f"Error: Missing dependency - {e}", err=True)
        sys.exit(1)

    try:
        shex_source = shex_file.read_text()
        schema = parse_shex(shex_source)

        click.echo(f"✓ Valid ShEx schema: {shex_file}")
        click.echo(f"  Shapes: {len(schema.shapes)}")
        for shape in schema.shapes:
            name = shape.id.rsplit("#", 1)[-1].rsplit("/", 1)[-1]
            click.echo(f"    - {name}")

    except Exception as e:
        click.echo(f"✗ Invalid ShEx schema: {shex_file}", err=True)
        click.echo(f"  Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
