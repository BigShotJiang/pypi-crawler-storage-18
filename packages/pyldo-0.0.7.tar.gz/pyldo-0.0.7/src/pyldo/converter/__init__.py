"""
Schema Converter - transforms ShEx schemas to Python types and JSON-LD contexts.

This is the Python equivalent of @ldo/schema-converter-shex from the JS LDO package.
It takes a ShEx schema and generates:
  1. Python Pydantic models for type-safe data access
  2. JSON-LD context dictionaries for RDF serialization/deserialization

Example:
    >>> from pyldo.converter import parse_shex, generate_python_types, generate_jsonld_context
    >>> 
    >>> shex = '''
    ... PREFIX foaf: <http://xmlns.com/foaf/0.1/>
    ... PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
    ... 
    ... <PersonShape> {
    ...     foaf:name xsd:string ;
    ...     foaf:age xsd:integer ?
    ... }
    ... '''
    >>> schema = parse_shex(shex)
    >>> python_code = generate_python_types(schema)
    >>> context = generate_jsonld_context(schema)
"""

from .context_generator import generate_jsonld_context
from .shapetype_generator import (
    generate_schema_file,
    generate_shapetypes_file,
)
from .shex_parser import ShExSchema, parse_shex
from .type_generator import generate_python_types

__all__ = [
    "parse_shex",
    "ShExSchema",
    "generate_python_types",
    "generate_jsonld_context",
    "generate_shapetypes_file",
    "generate_schema_file",
]
