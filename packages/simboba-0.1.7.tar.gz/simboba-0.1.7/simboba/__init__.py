"""Simboba - Lightweight eval tracking and LLM-as-judge evaluations."""

from simboba.boba import Boba
from simboba.schemas import AgentResponse, MessageInput

__version__ = "0.1.7"
__all__ = ["Boba", "AgentResponse", "MessageInput"]
