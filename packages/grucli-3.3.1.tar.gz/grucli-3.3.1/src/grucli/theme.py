"""
Centralized theme and color constants for grucli UI.
All ANSI color codes and styling are defined here for consistency.
"""

import shutil


class Colors:
    """ANSI color codes for terminal output."""
    
    # Branding colors
    PRIMARY = "\033[38;5;33m"      # Deep sky blue (better contrast than 39)
    SECONDARY = "\033[38;5;135m"   # Medium purple (better contrast than 141)
    ACCENT = "\033[38;5;214m"     # Orange/Gold
    
    # Semantic colors
    SUCCESS = "\033[38;5;71m"      # Medium green
    WARNING = "\033[38;5;214m"     # Orange
    ERROR = "\033[38;5;196m"       # Red
    INFO = "\033[38;5;33m"         # Blue
    MUTED = "\033[38;5;244m"       # Medium gray (readable on both)
    WHITE = "\033[97m"             # Bright white
    THINK_COLOR = "\033[38;5;213m" # Pinkish for reasoning
    
    # Tool category colors
    READ_OP = "\033[38;5;45m"      # Cyan for read operations
    WRITE_OP = "\033[38;5;214m"    # Orange for write operations
    DESTRUCTIVE_OP = "\033[91m"   # Red for destructive operations
    
    # UI element colors
    PROMPT = "\033[38;5;39;1m"    # Bold blue for prompts
    HEADER = "\033[1;4m"          # Bold underline for headers
    TITLE = "\033[38;5;39;1m"     # Bold blue for titles
    SUBTITLE = "\033[38;5;245m"   # Dim gray for subtitles
    
    # Text modifiers
    DIM = "\033[2m"
    BOLD = "\033[1m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    REVERSE = "\033[7m"
    RESET = "\033[0m"
    
    # Input states
    INPUT_ACTIVE = "\033[38;5;39m"      # Blue for active input
    INPUT_DISABLED = "\033[38;5;240m"   # Dark gray for disabled
    INPUT_CONFIRM = "\033[38;5;220m"    # Gold for confirmation
    INPUT_ERROR = "\033[91m"            # Red for error state


class Borders:
    """Box drawing characters for clean UI elements."""
    
    # Rounded corners
    TOP_LEFT = "╭"
    TOP_RIGHT = "╮"
    BOTTOM_LEFT = "╰"
    BOTTOM_RIGHT = "╯"
    
    # Lines
    HORIZONTAL = "─"
    VERTICAL = "│"
    
    # T-junctions
    T_LEFT = "├"
    T_RIGHT = "┤"
    T_TOP = "┬"
    T_BOTTOM = "┴"
    
    # Cross
    CROSS = "┼"


class Icons:
    """Unicode icons for visual enhancement."""
    
    # Status icons
    CHECK = "✓"
    CROSS = "✗"
    WARNING = "⚠"
    INFO = "ℹ"
    
    # Tool icons
    READ = "[READ]"
    WRITE = "[WRITE]"
    DELETE = "[DELETE]"
    FOLDER = "[FOLDER]"
    
    # UI icons
    ARROW_RIGHT = "→"
    ARROW_DOWN = "↓"
    BULLET = "•"
    DIAMOND = "◆"
    CIRCLE = "○"
    CIRCLE_FILLED = "●"
    
    # Spinner frames
    SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


class Styles:
    """Pre-composed style combinations."""
    
    @staticmethod
    def success(text: str) -> str:
        return f"{Colors.SUCCESS}{text}{Colors.RESET}"
    
    @staticmethod
    def error(text: str) -> str:
        return f"{Colors.ERROR}{text}{Colors.RESET}"
    
    @staticmethod
    def warning(text: str) -> str:
        return f"{Colors.WARNING}{text}{Colors.RESET}"
    
    @staticmethod
    def info(text: str) -> str:
        return f"{Colors.INFO}{text}{Colors.RESET}"
    
    @staticmethod
    def muted(text: str) -> str:
        return f"{Colors.MUTED}{text}{Colors.RESET}"
    
    @staticmethod
    def bold(text: str) -> str:
        return f"{Colors.BOLD}{text}{Colors.RESET}"
    
    @staticmethod
    def primary(text: str) -> str:
        return f"{Colors.PRIMARY}{text}{Colors.RESET}"
    
    @staticmethod
    def accent(text: str) -> str:
        return f"{Colors.ACCENT}{text}{Colors.RESET}"


def get_terminal_width() -> int:
    """Get terminal width, defaulting to 80 if unavailable."""
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return 80
