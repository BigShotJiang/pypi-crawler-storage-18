# BudgetScribe Package
[![PyPI version](https://badge.fury.io/py/budgetscribe.svg)](https://badge.fury.io/py/budgetscribe)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/budgetscribe)](https://pepy.tech/project/budgetscribe)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A new package that analyzes user-provided text descriptions of their monthly expenses and income to generate a structured affordability assessment.

## Overview

This package categorizes spending, identifies potential savings areas, and returns a clear breakdown of financial health without requiring sensitive data like bank statements. It helps users understand their budget can be optimized in a private, non-intrusive way.

## Installation

```bash
pip install budgetscribe
```

## Usage

```python
from budgetscribe import budgetscribe

user_input = "I spend $500 on rent, $300 on groceries, and $200 on entertainment."
response = budgetscribe(user_input)
print(response)
```

## Parameters

* `user_input`: str : the user input text to process
* `llm`: Optional[BaseChatModel] : the langchain llm instance to use, if not provided the default `ChatLLM7` will be used.
* `api_key`: Optional[str] : the api key for `llm7`, if not provided the `LLM7_API_KEY` environment variable will be used.

## LLM Integration

This package uses `ChatLLM7` from `langchain_llm7` by default. However, developers can safely pass their own `llm` instance (based on `https://docs.langchain.com`) if they want to use another LLM.

For example, to use the `openai` LLM:

```python
from langchain_openai import ChatOpenAI
from budgetscribe import budgetscribe

llm = ChatOpenAI()
response = budgetscribe(user_input, llm=llm)
```

or to use the `anthropic` LLM:

```python
from langchain_anthropic import ChatAnthropic
from budgetscribe import budgetscribe

llm = ChatAnthropic()
response = budgetscribe(user_input, llm=llm)
```

or to use the `google` LLM:

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from budgetscribe import budgetscribe

llm = ChatGoogleGenerativeAI()
response = budgetscribe(user_input, llm=llm)
```

## LLM7 Rate Limits

The default rate limits for `LLM7` free tier are sufficient for most use cases of this package. However, if higher rate limits are needed, developers can pass their own `api_key` via environment variable `LLM7_API_KEY` or directly like `budgetscribe(user_input, api_key="their_api_key")`.

To get a free API key, visit `https://token.llm7.io/`.

## Documentation and Support

Issues and feature requests: https://github.com/chigwell/budgetscribe

Author: Eugene Evstafev (<hi@eugene.plus>)