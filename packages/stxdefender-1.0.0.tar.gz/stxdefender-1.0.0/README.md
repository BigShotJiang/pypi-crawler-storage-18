# JSDefender - JavaScript Source Code Encryption Tool

JSDefender is a SourceDefender-like tool for protecting JavaScript source code with AES-256-GCM encryption. It provides enterprise-grade protection for your intellectual property without compromising performance.

## Features

- ✅ **AES-256-GCM Encryption** - Industry-standard symmetric encryption
- ✅ **License Activation** - Online token-based activation system
- ✅ **Enforced Expiry (TTL)** - Control access with expiration times
- ✅ **Custom Password Support** - Use custom passwords or auto-generated ones
- ✅ **Trial Mode** - 24-hour limit without activation
- ✅ **Shebang Support** - Direct execution of encrypted files
- ✅ **Simple CLI** - Easy-to-use commands: activate, validate, encrypt
- ✅ **Web Dashboard** - Manage licenses and tokens through a web interface

## Installation

### Quick Start (Windows)

**Easiest way - does everything automatically:**

1. Double-click `setup_and_run.bat`
   - Installs all dependencies
   - Sets up the CLI tool
   - Starts the server
   
2. Or use `START.bat` for a quick start (assumes dependencies are installed)

3. Or use `INSTALL.bat` to just install dependencies without starting

### Quick Start (Linux/Mac)

```bash
chmod +x setup_and_run.sh
./setup_and_run.sh
```

### Manual Installation

**Install from source (required - not on PyPI yet):**

```bash
# Navigate to project directory
cd "path/to/sourcedefender remake"

# Install STXDefender
pip install -e .
```

This installs STXDefender in "editable" mode, making the `stxdefender` command available globally.

**Alternative: Use directly**

```bash
# Run the Python file directly (no installation needed)
python stxdefender.py --help
```

## Quick Start

### 1. Start the Backend Server

```bash
cd backend
python app.py
```

The server will start on `http://localhost:5000`

### 2. Create an Account

1. Open your browser and go to `http://localhost:5000`
2. Click "Sign up" and create an account
3. Log in to access the dashboard

### 3. Generate an Activation Token

1. In the dashboard, click "Generate New Token"
2. Copy the token (you'll only see it once!)

### 4. Activate JSDefender

```bash
jsdefender activate --token YOUR_TOKEN_HERE
```

### 5. Validate Activation

```bash
jsdefender validate
```

### 6. Encrypt Your JavaScript Files

```bash
# Basic encryption
jsdefender encrypt myapp.js

# With expiration (24 hours)
jsdefender encrypt --ttl=24h myapp.js

# With custom password
jsdefender encrypt --password=mysupersecret myapp.js

# Remove original file after encryption
jsdefender encrypt --remove myapp.js
```

### 7. Run Encrypted Files

```bash
# Run encrypted file
node myapp.jse

# With custom password (if used during encryption)
export JSDEFENDER_PASSWORD="mysupersecret"
node myapp.jse

# Make executable and run directly (Unix/Linux/Mac)
chmod +x myapp.jse
./myapp.jse
```

## Command Reference

### `jsdefender activate --token <token>`

Activate your license with a token obtained from the dashboard.

```bash
jsdefender activate --token 470a7f2e76ac11eb94390242ac130002
```

### `jsdefender validate`

Validate your current license activation.

```bash
jsdefender validate
```

### `jsdefender encrypt [options] <file>`

Encrypt a JavaScript file.

**Options:**
- `--remove` - Remove the original file after encryption
- `--ttl=<time>` - Set expiration time (e.g., `24h`, `7d`, `30m`, `1w`)
- `--password=<pass>` - Use a custom password (otherwise auto-generated)

**Examples:**
```bash
# Basic encryption
jsdefender encrypt script.js

# With 24-hour expiration and remove original
jsdefender encrypt --remove --ttl=24h myapp.js

# With custom password
jsdefender encrypt --password=mysecret script.js

# Complex example
jsdefender encrypt --remove --ttl=7d --password=supersecret myapp.js
```

## TTL (Time To Live) Format

The `--ttl` option accepts the following formats:

- `30s` - 30 seconds
- `5m` - 5 minutes
- `24h` - 24 hours
- `7d` - 7 days
- `2w` - 2 weeks
- `365` - 365 seconds (numeric only = seconds)

## Password Handling

### Auto-generated Password

If no password is specified, JSDefender generates a secure random password. This password is embedded in the encrypted file, so the file is self-contained.

### Custom Password

You can specify a custom password:

```bash
jsdefender encrypt --password=mypassword script.js
```

When running the encrypted file, set the password as an environment variable:

```bash
export JSDEFENDER_PASSWORD="mypassword"
node script.jse
```

If the environment variable is not set, it will use the password embedded in the file (or the one you specified during encryption).

## Trial Mode

Without a valid license activation, JSDefender operates in trial mode:

- ✅ Encryption works normally
- ⚠️ Maximum TTL is limited to 24 hours
- ⚠️ A warning message is displayed

To remove trial limitations, activate with a valid token from the dashboard.

## Project Structure

```
.
├── backend/
│   └── app.py              # Flask backend API
├── frontend/
│   ├── index.html          # Landing page
│   ├── login.html          # Login/signup page
│   ├── dashboard.html      # User dashboard
│   └── static/
│       ├── style.css       # Styles
│       ├── auth.js         # Auth page JavaScript
│       ├── dashboard.js    # Dashboard JavaScript
│       └── main.js         # Main page JavaScript
├── jsdefender.py           # Main CLI tool
├── requirements.txt        # Python dependencies
├── setup.py               # Package setup
└── README.md              # This file
```

## Development

### Running the Backend

**Windows:**
- Use `setup_and_run.bat` (installs and runs)
- Use `START.bat` (quick start)
- Use `run_server.bat` (assumes dependencies installed)

**Linux/Mac:**
```bash
./setup_and_run.sh
# OR
cd backend
python3 app.py
```

The server runs on `http://localhost:5000` by default.

### Environment Variables

- `JSDEFENDER_API_URL` - API endpoint URL (default: `http://localhost:5000`)
- `SECRET_KEY` - Flask secret key (default: auto-generated)
- `JSDEFENDER_PASSWORD` - Default password for encrypted files

### Database

The backend uses SQLite by default (`jsdefender.db`). For production, consider using PostgreSQL or MySQL.

## Security Notes

- Passwords are hashed using SHA-256 (consider upgrading to bcrypt for production)
- Tokens are generated using secure random generation
- Encryption uses AES-256-GCM with PBKDF2 key derivation (200,000 iterations)
- License validation happens locally and remotely
- System fingerprinting is used to bind licenses to machines

## License

This project is provided as-is for educational and development purposes.

## Contributing

Contributions are welcome! Please feel free to submit issues and pull requests.

## Support

For issues and questions, please open an issue on the project repository.

