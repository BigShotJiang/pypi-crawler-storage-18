"""
Command-line interface with interactive menu-based navigation.
"""

import sys
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import print as rprint
from rich.console import Group
from rich.align import Align

from infiltrator.core.updater import check_for_updates
from infiltrator import __version__

console = Console()

# Define styles for questionary
custom_style = questionary.Style([
    ('qmark', 'fg:#00FF00 bold'),      # Green question mark
    ('question', 'bold'),              # Bold question text
    ('answer', 'fg:#00FFFF bold'),     # Cyan answer
    ('pointer', 'fg:#FF0000 bold'),    # Red pointer
    ('highlighted', 'fg:#00FFFF bold'), # Cyan highlighted choice
    ('selected', 'fg:#00FFFF'),        # Cyan selected
    ('separator', 'fg:#666666'),       # Grey separator
    ('instruction', 'fg:#666666'),     # Grey instructions
])

class CLI:
    """Main CLI interface for Infiltrator."""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.running = True
        
        # Check for updates
        self._check_update_status()
        
        # Import adapter manager
        from infiltrator.core.adapter_manager import AdapterManager
        self.adapter_manager = AdapterManager(logger)
        
        # Import module managers
        try:
            from infiltrator.modules.reconnaissance import ReconnaissanceModule
            from infiltrator.modules.exploitation import ExploitationModule
            from infiltrator.modules.post_attack import PostAttackModule
            
            self.recon_module = ReconnaissanceModule(config, logger, self.adapter_manager)
            self.exploit_module = ExploitationModule(config, logger, self.adapter_manager)
            self.post_module = PostAttackModule(config, logger, self.adapter_manager)
        except ImportError as e:
            console.print(f"[bold red]Warning: Some modules could not be loaded: {e}[/]")
        
        # Ensure directories exist
        self.config.ensure_directories()
    
    def _check_update_status(self):
        """Check for updates and display notification if available."""
        latest = check_for_updates(__version__)
        if latest:
            console.print(Panel(
                f"[bold green]New version available: {latest}[/]\n"
                f"Current version: {__version__}\n"
                f"Run: [bold cyan]pip install --upgrade infiltrator-wifi[/] to update.",
                title="[bold yellow]Update Available[/]",
                border_style="yellow"
            ))

    def run(self):
        """Main CLI loop."""
        # Initial setup
        self._setup_adapters()
        
        while self.running:
            # Clear screen for a fresh look (optional, but cleaner)
            # console.clear() 
            # We won't clear screen to keep history visible, but we print a separator
            console.print(Align.center("[dim]─" * 50 + "[/]"))
            
            choice = questionary.select(
                "Select a category:",
                choices=[
                    questionary.Choice("Reconnaissance & Intelligence", value="recon"),
                    questionary.Choice("Exploitation & Attack", value="exploit"),
                    questionary.Choice("Post-Attack Operations", value="post"),
                    questionary.Separator(),
                    questionary.Choice("Adapter Management", value="adapter"),
                    questionary.Choice("Settings & Configuration", value="settings"),
                    questionary.Separator(),
                    questionary.Choice("Exit", value="exit"),
                ],
                style=custom_style,
                use_indicator=True
            ).ask()
            
            if choice == 'recon':
                self._reconnaissance_menu()
            elif choice == 'exploit':
                self._exploitation_menu()
            elif choice == 'post':
                self._post_attack_menu()
            elif choice == 'adapter':
                self._adapter_menu()
            elif choice == 'settings':
                self._settings_menu()
            elif choice == 'exit':
                self._exit()
    
    def _setup_adapters(self):
        """Initial adapter setup."""
        adapters = self.adapter_manager.scan_adapters()
        
        if not adapters:
            console.print(Panel("[bold red]No wireless adapters found![/]\n[yellow]Please connect a wireless adapter and restart.[/]", border_style="red"))
            return
        
        # Display found adapters nicely
        table = Table(title="Connected Adapters", box=None, show_header=True, header_style="bold magenta")
        table.add_column("Interface", style="green")
        table.add_column("Status", style="cyan")
        table.add_column("MAC Address", style="dim")
        
        for adapter in adapters:
            status = "Monitor Mode" if adapter.is_monitor else "Managed Mode"
            style = "bold green" if adapter.is_monitor else "yellow"
            table.add_row(adapter.interface, f"[{style}]{status}[/]", adapter.mac_address)
        
        console.print(table)
        print()

        # Check if any monitor mode
        needs_monitor = any(not a.is_monitor for a in adapters)
        if needs_monitor:
            if questionary.confirm("Enable monitor mode on all adapters?", default=True, style=custom_style).ask():
                for adapter in adapters:
                    if not adapter.is_monitor:
                        self.adapter_manager.enable_monitor_mode(adapter.interface)
    
    def _reconnaissance_menu(self):
        """Reconnaissance submenu."""
        while True:
            choice = questionary.select(
                "Reconnaissance Ops:",
                choices=[
                    questionary.Choice("1. Passive Scanner & Analyzer", value="1"),
                    questionary.Choice("2. Client Probe Monitor", value="2"),
                    questionary.Choice("3. Target Tracker", value="3"),
                    questionary.Choice("4. Geo-Spatial Mapper", value="4"),
                    questionary.Choice("5. Protocol Fingerprinter", value="5"),
                    questionary.Separator(),
                    questionary.Choice("Back to Main Menu", value="back"),
                ],
                style=custom_style
            ).ask()
            
            if choice == 'back':
                break
            
            # Execute module
            if choice == '1': self.recon_module.passive_scanner()
            elif choice == '2': self.recon_module.client_probe_monitor()
            elif choice == '3': self.recon_module.target_tracker()
            elif choice == '4': self.recon_module.geo_mapper()
            elif choice == '5': self.recon_module.protocol_fingerprinter()
    
    def _exploitation_menu(self):
        while True:
            choice = questionary.select(
                "Exploitation Ops:",
                choices=[
                    questionary.Choice("1. Deauth Attack Suite", value="1"),
                    questionary.Choice("2. Handshake Capture", value="2"),
                    questionary.Choice("3. Evil Twin (MiTM)", value="3"),
                    questionary.Choice("4. WPS Brute-Forcer", value="4"),
                    questionary.Choice("5. WPA3 Downgrade", value="5"),
                    questionary.Choice("6. 802.1X Phishing", value="6"),
                    questionary.Separator(),
                    questionary.Choice("Back to Main Menu", value="back"),
                ],
                style=custom_style
            ).ask()
            
            if choice == 'back':
                break

            if choice == '1': self.exploit_module.deauth_attack()
            elif choice == '2': self.exploit_module.handshake_capture()
            elif choice == '3': self.exploit_module.evil_twin()
            elif choice == '4': self.exploit_module.wps_attack()
            elif choice == '5': self.exploit_module.wpa3_downgrade()
            elif choice == '6': self.exploit_module.eap_phishing()

    def _post_attack_menu(self):
        while True:
            choice = questionary.select(
                "Post-Attack Ops:",
                choices=[
                    questionary.Choice("1. Offline Cracking", value="1"),
                    questionary.Choice("2. Automated Chain", value="2"),
                    questionary.Choice("3. Stealth & OPSEC", value="3"),
                    questionary.Choice("4. Cloud Cracking API", value="4"),
                    questionary.Separator(),
                    questionary.Choice("Back to Main Menu", value="back"),
                ],
                style=custom_style
            ).ask()
            
            if choice == 'back':
                break

            if choice == '1': self.post_module.offline_cracking()
            elif choice == '2': self.post_module.chain_execution()
            elif choice == '3': self.post_module.stealth_opsec()
            elif choice == '4': self.post_module.cloud_cracking()

    def _adapter_menu(self):
        while True:
            # Display current state
            adapters = list(self.adapter_manager.adapters.values())
            if adapters:
                table = Table(box=None, padding=(0,2))
                table.add_column("Interface", style="green")
                table.add_column("Mode", style="cyan")
                table.add_column("Channel")
                for a in adapters:
                    table.add_row(a.interface, "Monitor" if a.is_monitor else "Managed", str(a.channel or "Auto"))
                console.print(table)
            
            choice = questionary.select(
                "Adapter Management:",
                choices=[
                    "Rescan Adapters",
                    "Enable Monitor Mode",
                    "Disable Monitor Mode",
                    "Spoof MAC Address",
                    "Restore MAC Address",
                    "Set Channel",
                    questionary.Separator(),
                    "Back to Main Menu"
                ],
                style=custom_style
            ).ask()
            
            if choice == "Back to Main Menu": break
            
            if choice == "Rescan Adapters":
                self.adapter_manager.scan_adapters()
            elif choice == "Enable Monitor Mode":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.enable_monitor_mode(iface)
            elif choice == "Disable Monitor Mode":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.disable_monitor_mode(iface)
            elif choice == "Spoof MAC Address":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.spoof_mac(iface)
            elif choice == "Restore MAC Address":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.restore_mac(iface)
            elif choice == "Set Channel":
                iface = questionary.text("Interface name:").ask()
                ch = questionary.text("Channel:").ask()
                if ch.isdigit():
                    self.adapter_manager.set_channel(iface, int(ch))

    def _settings_menu(self):
        while True:
            choice = questionary.select(
                "Settings:",
                choices=[
                    "View Current Config",
                    "Run Configuration Wizard",
                    questionary.Separator(),
                    "Back to Main Menu"
                ],
                style=custom_style
            ).ask()
            
            if choice == "Back to Main Menu": break
            
            if choice == "View Current Config":
                self._view_config()
            elif choice == "Run Configuration Wizard":
                console.print("[yellow]Please run 'infiltrator-config' in a new terminal window.[/]")

    def _view_config(self):
        import json
        console.print(Panel(json.dumps(self.config.config, indent=2), title="Current Configuration", border_style="cyan"))

    def _exit(self):
        if questionary.confirm("Are you sure you want to exit?").ask():
            console.print("[yellow]Cleaning up processes...[/]")
            self.cleanup()
            console.print("[bold green]Goodbye, happy hunting![/]")
            self.running = False
    
    def cleanup(self):
        for interface in self.adapter_manager.monitor_adapters[:]:
            self.adapter_manager.disable_monitor_mode(interface)
        
        for adapter in self.adapter_manager.adapters.values():
            if adapter.mac_address != adapter.original_mac:
                self.adapter_manager.restore_mac(adapter.interface)
