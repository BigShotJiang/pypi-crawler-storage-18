"""
Banner and branding for Infiltrator.
"""
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align

console = Console()

def display_banner():
    """Display the Infiltrator ASCII art banner using Rich."""
    ascii_art = r"""
   _____  ____________ _________  ___ __________  ___ 
  /  _/ |/ / __/  _/ //_  __/ _ \/ _ /_  __/ __ \/ _ \
 _/ //    / _/_/ // /__/ / / , _/ __ |/ / / /_/ / , _/
/___/_/|_/_/ /___/____/_/ /_/|_/_/ |_/_/  \____/_/|_|                                                                               
                                                                                      
"""
    
    # Create the text object with a gradient-like style using Rich
    text = Text(ascii_art, style="bold cyan")
    
    # Print the banner simply without a heavy container for a cleaner look
    console.print()
    console.print(Align.center(text))
    console.print(Align.center("[bold white]Wi-Fi Red Team Auditing Suite[/] [bold yellow]v1.1.2[/]"))
    console.print(Align.center("[dim]Designed by LAKSHMIKANTHAN K (letchupkt)[/]"))
    console.print()