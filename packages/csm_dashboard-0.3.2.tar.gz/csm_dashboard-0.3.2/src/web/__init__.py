"""Web module - FastAPI application."""
