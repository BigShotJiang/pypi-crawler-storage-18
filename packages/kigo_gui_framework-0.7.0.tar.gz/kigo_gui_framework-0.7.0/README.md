This is the official documentation of kigo-gui-framework v0.5.0
INTRODUCTION-
This is a Python library that enables you to make apps in Python. Basically, an SDK (I think its not an sdk, but whatever, idc) 
It is an easier way to write apps in PyQt6. If you've noticed, making an app in PyQt6 is pure hell. This way and that, this way and that. This happens to me sometimes that i rewrote a tkinter app to pyqt, and then i wrote everything wrong. I had to learn 6 months of PyQt before i was abe to rewrite it. kigo-gui-framework aims to make everything much easier. Instead of this (the line of code required to terminate\kill the Python interpreter)shit:
sys.exit(app.exec_())
kigo-gui-framework uses
main()
Cleaner, right? 
I hope you will like this framework. Feedback accepted at 
+91 9051422285