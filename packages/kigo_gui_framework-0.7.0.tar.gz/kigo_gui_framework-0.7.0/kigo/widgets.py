import os
from PyQt6.QtWidgets import (
    QLabel, QPushButton, QLineEdit, QComboBox, QWidget,
    QCheckBox, QProgressBar, QScrollBar, QSlider, 
    QVBoxLayout, QHBoxLayout, QTabWidget, QGraphicsBlurEffect,
    QGraphicsOpacityEffect, QFrame
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings, QWebEnginePage
from PyQt6.QtCore import QUrl, Qt, QPropertyAnimation, QEasingCurve, QPoint
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput 

# --- Private Browser Engine ---
class QPrivateBrowser:
    """A browser widget using an off-the-record profile to bypass tracking/login issues."""
    def __init__(self, url="https://pypi.org/manage/account/", parent=None):
        self.qt_widget = QWebEngineView(parent)
        
        # Off-the-record (Incognito) profile prevents session fingerprinting
        # Helps bypass 'unrecognized device' loops on PyPI
        self.profile = QWebEngineProfile("", self.qt_widget) 
        self.profile.setHttpUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
        
        self.page = QWebEnginePage(self.profile, self.qt_widget)
        self.qt_widget.setPage(self.page)
        
        settings = self.qt_widget.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        
        self.load_url(url)

    def load_url(self, url):
        self.qt_widget.setUrl(QUrl(url))

# --- Animation & Transparency Controller ---
class Animator:
    """Handles smooth UI transitions for v0.7.0."""
    @staticmethod
    def fade_in(kigo_widget, duration=800):
        target = kigo_widget.qt_widget
        effect = QGraphicsOpacityEffect(target)
        target.setGraphicsEffect(effect)
        
        anim = QPropertyAnimation(effect, b"opacity")
        anim.setDuration(duration)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutQuad)
        anim.start()
        return anim

    @staticmethod
    def slide_up(kigo_widget, duration=600, distance=50):
        target = kigo_widget.qt_widget
        pos = target.pos()
        
        anim = QPropertyAnimation(target, b"pos")
        anim.setDuration(duration)
        anim.setStartValue(QPoint(pos.x(), pos.y() + distance))
        anim.setEndValue(pos)
        anim.setEasingCurve(QEasingCurve.Type.OutBack)
        anim.start()
        return anim

# --- Core Widgets ---

class Label:
    def __init__(self, text="Label"):
        self.qt_widget = QLabel(text)
        self.qt_widget.setStyleSheet("font-size: 13pt; background: transparent; color: #333;")
    
    def set_text(self, t): 
        self.qt_widget.setText(t)

    def set_opacity(self, value):
        effect = QGraphicsOpacityEffect(self.qt_widget)
        effect.setOpacity(value)
        self.qt_widget.setGraphicsEffect(effect)

class Button:
    def __init__(self, text="Button", on_click=None):
        self.qt_widget = QPushButton(text)
        self.qt_widget.setCursor(Qt.CursorShape.PointingHandCursor)
        self.qt_widget.setStyleSheet("""
            QPushButton { 
                padding: 12px 20px; background-color: #4CAF50; color: white; 
                border-radius: 8px; font-weight: bold; border: none;
            }
            QPushButton:hover { background-color: #45a049; }
        """)
        if on_click: 
            self.qt_widget.clicked.connect(on_click)

class Row:
    def __init__(self):
        self.qt_widget = QWidget()
        self.layout = QHBoxLayout(self.qt_widget)
        self.layout.setContentsMargins(5, 5, 5, 5)

    def add_widget(self, widget):
        if hasattr(widget, 'qt_widget'): 
            self.layout.addWidget(widget.qt_widget)

class TabContainer:
    def __init__(self):
        self.qt_widget = QTabWidget()
        self.qt_widget.setTabsClosable(True)
        self.qt_widget.tabCloseRequested.connect(self.qt_widget.removeTab)
        self.qt_widget.setStyleSheet("QTabBar::tab { padding: 10px; min-width: 100px; }")

    def add_tab(self, widget, title="Tab"):
        if hasattr(widget, 'qt_widget'):
            return self.qt_widget.addTab(widget.qt_widget, title)

class TransparentWindow(QWidget):
    """A window that supports background transparency for modern glass effects."""
    def __init__(self, opacity=0.95):
        super().__init__()
        self.setWindowOpacity(opacity)
        self.main_layout = QVBoxLayout(self)

    def add_widget(self, widget):
        if hasattr(widget, 'qt_widget'): 
            self.main_layout.addWidget(widget.qt_widget)

class WavPlayer:
    def __init__(self, filepath=None):
        self.qt_widget = QWidget()
        self.media_player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.media_player.setAudioOutput(self.audio_output)
        
        layout = QHBoxLayout(self.qt_widget)
        self.play_btn = QPushButton("▶")
        self.stop_btn = QPushButton("■")
        layout.addWidget(self.play_btn)
        layout.addWidget(self.stop_btn)
        
        self.play_btn.clicked.connect(self.media_player.play)
        self.stop_btn.clicked.connect(self.media_player.stop)
        
        if filepath: 
            self.media_player.setSource(QUrl.fromLocalFile(filepath))

# Utils
def set_blur(kigo_widget, radius):
    blur = QGraphicsBlurEffect()
    blur.setBlurRadius(radius)
    kigo_widget.qt_widget.setGraphicsEffect(blur)

# Always remember: somewhere, somehow, a duck is watching you.
__all__ = [
    'Label', 'Button', 'Row', 'TabContainer', 'QPrivateBrowser', 
    'TransparentWindow', 'WavPlayer', 'Animator', 'set_blur'
]