# vecfield

> **Numerical vector calculus for physics (v0.1.0)**  
> Experimental, educational, and physics-focused.

`vecfield` is a small Python library for **numerical vector calculus on 2D scalar and vector fields**, designed to closely mirror how fields are treated in physics (electrostatics, fluids, diffusion).

The emphasis is on **clarity, correctness, and physical meaning**, not performance or abstraction depth.

---

## ✨ Core idea

In physics, many systems are described by a **scalar field** (such as a potential), from which all other quantities are derived:

\[
\mathbf{E} = -\nabla V,\quad
\nabla \cdot \mathbf{E},\quad
\nabla \times \mathbf{E},\quad
\nabla^2 V
\]

`vecfield` lets you write this **almost exactly as the math**.

---

## 🚀 Features (v0.1.0)

- 2D scalar and vector fields on a uniform rectangular grid
- Gradient, divergence, curl (2D)
- Laplacian via operator composition
- Vector field magnitude
- Visualization (contours + quiver plots)
- Clean, physics-oriented API
- No circular imports, no hidden state

---

## 📦 Installation

From the project root:

```bash
python -m pip install -e .
