# peepfilt

Filter images without people using YOLOv8 (Ultralytics). Supports CLI, FastAPI, and a minimal frontend. Auto-selects CUDA if available, otherwise CPU.

## Install

**For CPU only:**
```bash
pip install peepfilt[cpu]
```

**For GPU (CUDA 12.1):**
```bash
pip install peepfilt[gpu] --extra-index-url https://download.pytorch.org/whl/cu121
```

## CLI

```bash
peepfilt images/ \
  --no-people-dir images/no_people \
  --conf 0.25 \
  --batch-size 16
```

## Web UI

Start the API server with the web interface:

```bash
peepfilt-ui
```

Open `http://localhost:8090` in your browser to access the UI. Endpoints:

- GET `/health` – health check
- POST `/scan-dir` – scan a directory for images without people

## Notes
 
- Model: `yolov8n.pt` (Ultralytics)
- Person class only
- Image size: 640
- Defaults: conf 0.25, batch size 16
