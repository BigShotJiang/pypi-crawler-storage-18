import sys
from pathlib import Path

# Add src to path for tests
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import importlib


def test_can_import_detector_utils():
    mod = importlib.import_module("peepfilt.detector")
    assert hasattr(mod, "get_default_device")
    dev = mod.get_default_device()
    assert dev in ("cpu", "cuda")
