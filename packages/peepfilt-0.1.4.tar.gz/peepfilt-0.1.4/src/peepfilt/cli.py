"""Argparse CLI for peepfilt."""

import argparse
from pathlib import Path

from peepfilt.config import DEFAULT_CONF, DEFAULT_BATCH_SIZE
from peepfilt.utils import get_logger

logger = get_logger("peepfilt.cli")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="peepfilt",
        description="Filter images without people using YOLOv8 (ultralytics)",
    )
    parser.add_argument(
        "images_dir",
        help="Directory of images to scan",
    )
    parser.add_argument(
        "--no-people-dir",
        dest="no_people_dir",
        default=None,
        help="Directory to move images without people (default: <images_dir>/no_people)",
    )
    parser.add_argument(
        "--conf",
        type=float,
        default=DEFAULT_CONF,
        help=f"Confidence threshold (default: {DEFAULT_CONF})",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=DEFAULT_BATCH_SIZE,
        help=f"Batch size (default: {DEFAULT_BATCH_SIZE})",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    from peepfilt.batch import scan_and_filter

    stats = scan_and_filter(
        input_dir=Path(args.images_dir),
        no_people_dir=args.no_people_dir,
        conf=args.conf,
        batch_size=args.batch_size,
    )

    device_line = stats.get(0) or stats.get("0") or "UNKNOWN"
    logger.info(f"{device_line}")
    for k in sorted(k for k in stats.keys() if isinstance(k, int) and k >= 1):
        logger.info(f"{k}: {stats[k]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
