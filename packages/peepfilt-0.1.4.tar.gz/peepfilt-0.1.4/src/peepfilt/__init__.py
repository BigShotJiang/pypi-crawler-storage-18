"""peepfilt: Filter images by detecting human presence using YOLOv8."""

import os
from pathlib import Path

# Configure YOLO cache location before any imports
# Downloads model to user's home directory instead of current working directory
_yolo_cache = Path.home() / ".yolo"
_yolo_cache.mkdir(parents=True, exist_ok=True)

# Set environment variables that ultralytics checks
os.environ.setdefault("YOLO_CONFIG_DIR", str(_yolo_cache))

# Configure ultralytics settings to download models to the cache directory
try:
    from ultralytics import settings

    _weights_dir = _yolo_cache / "weights"
    _weights_dir.mkdir(parents=True, exist_ok=True)
    settings.update(
        {
            "weights_dir": str(_weights_dir),
            "datasets_dir": str(_yolo_cache / "datasets"),
        }
    )
except Exception:
    pass  # Settings update is optional

__all__ = [
    "config",
    "detector",
    "batch",
    "cli",
    "api",
    "utils",
]

__version__ = "0.1.0"
