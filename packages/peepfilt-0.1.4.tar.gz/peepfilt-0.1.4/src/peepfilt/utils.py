"""Utility helpers for peepfilt (logging, etc.)."""

import logging
import os
from peepfilt.config import LOG_LEVEL_ENV

_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"


def get_logger(name: str) -> logging.Logger:
    """Return a configured logger.

    Honors environment variable `PEEPFILT_LOG_LEVEL` for level override.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        level_str = os.getenv(LOG_LEVEL_ENV, "INFO").upper()
        level = getattr(logging, level_str, logging.INFO)
        logger.setLevel(level)
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        logger.addHandler(handler)
        logger.propagate = False
    return logger
