"""Project-wide configuration constants for peepfilt."""

from pathlib import Path
from typing import Set

# Detection/model constants
MODEL_NAME: str = "yolov8n.pt"
PERSON_CLASS_ID: int = 0
IMAGE_SIZE: int = 640


def get_model_path(model_name: str = MODEL_NAME) -> str:
    """Get the full path to the model file in the cache directory."""
    cache_dir = Path.home() / ".yolo" / "weights"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return str(cache_dir / model_name)


# Defaults
DEFAULT_CONF: float = 0.25
DEFAULT_BATCH_SIZE: int = 16

# API server
PORT: int = 8090

# Accepted image extensions (lowercase)
IMAGE_EXTENSIONS: Set[str] = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# Logging
LOG_LEVEL_ENV: str = "PEEPFILT_LOG_LEVEL"
