"""
----------------------------------------------------------------------
>>> Author       : Junshan Yin  
>>> Last Updated : 2025-10-28
----------------------------------------------------------------------
"""

import torchvision, torch
import torchvision.transforms as transforms
import pandas as pd
from torch.utils.data import random_split, Subset

from junshan_kit import DataSets, DataProcessor, ParametersHub

def Adult_Income_Prediction(Paras):

    df = DataSets.adult_income_prediction() 
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='income'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform


def Credit_Card_Fraud_Detection(Paras):
    df = DataSets.credit_card_fraud_detection()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='Class'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def Diabetes_Health_Indicators(Paras):
    df = DataSets.diabetes_health_indicators()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='diagnosed_diabetes'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def Electric_Vehicle_Population(Paras): 
    df = DataSets.electric_vehicle_population()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='Electric Vehicle Type'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def Global_House_Purchase(Paras): 
    df = DataSets.global_house_purchase()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='decision'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def Health_Lifestyle(Paras): 
    df = DataSets.health_lifestyle()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='disease_risk'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def Homesite_Quote_Conversion(Paras): 
    df = DataSets.Homesite_Quote_Conversion()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='QuoteConversion_Flag'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform

def TN_Weather_2020_2025(Paras): 
    df = DataSets.TamilNadu_weather_2020_2025()
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='rain_tomorrow'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, Paras)

    return train_dataset, test_dataset, transform


def MNIST(model_type):
    """
    Load the MNIST dataset and return both the training and test sets,
    along with the transformation applied (ToTensor).
    """
    transform = torchvision.transforms.ToTensor()

    train_dataset = torchvision.datasets.MNIST(
        root='./exp_data/MNIST',
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.MNIST(
        root='./exp_data/MNIST',
        train=False,
        download=True,
        transform=transform
    )

    if model_type == "binary":

        train_mask = (train_dataset.targets == 0) | (train_dataset.targets == 1)
        test_mask = (test_dataset.targets == 0) | (test_dataset.targets == 1)

        train_indices = torch.nonzero(train_mask, as_tuple=True)[0]
        test_indices = torch.nonzero(test_mask, as_tuple=True)[0]

        train_dataset = torch.utils.data.Subset(train_dataset, train_indices.tolist())
        test_dataset = torch.utils.data.Subset(test_dataset, test_indices.tolist())

    return train_dataset, test_dataset, transform


def CIFAR100(model_type, root='./exp_data/CIFAR100'):
    """
    Load the CIFAR-100 dataset with standard normalization and return both
    the training and test sets, along with the transformation applied.
    """
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5071, 0.4867, 0.4408],   
                            std=[0.2675, 0.2565, 0.2761])     
    ])

    train_dataset = torchvision.datasets.CIFAR100(
        root=root,
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.CIFAR100(
        root=root,
        train=False,
        download=True,
        transform=transform
    )

    if  model_type== "binary":
        train_mask = (torch.tensor(train_dataset.targets) == 0) | (torch.tensor(train_dataset.targets) == 1)
        test_mask = (torch.tensor(test_dataset.targets) == 0) | (torch.tensor(test_dataset.targets) == 1)

        train_indices = torch.nonzero(train_mask, as_tuple=True)[0]
        test_indices = torch.nonzero(test_mask, as_tuple=True)[0]

        train_dataset = torch.utils.data.Subset(train_dataset, train_indices.tolist())
        test_dataset = torch.utils.data.Subset(test_dataset, test_indices.tolist())

    return train_dataset, test_dataset, transform


def Caltech101_Resize_32(model_type,  train_ratio=0.7, split=True, root='./exp_data/Caltech101'):
    """
    Caltech101 resized to 32x32.
    If model_type == 'binary', only keep classes 0 and 1.
    """

    transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((32, 32)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])

    full_dataset = torchvision.datasets.Caltech101(
        root=root,
        download=True,
        transform=transform
    )

    # --------- only keep classes 0 and 1 ---------
    if model_type == "binary":
        targets = torch.tensor(full_dataset.y)
        mask = (targets == 0) | (targets == 1)
        indices = torch.nonzero(mask, as_tuple=True)[0].tolist()
        full_dataset = Subset(full_dataset, indices)

    # --------- train / test split ---------
    if split:
        total_size = len(full_dataset)
        train_size = int(train_ratio * total_size)
        test_size = total_size - train_size

        train_dataset, test_dataset = random_split(
            full_dataset, [train_size, test_size]
        )
    else:
        train_dataset = full_dataset
        test_dataset = Subset(full_dataset, [])

    return train_dataset, test_dataset, transform
# <caltech101_Resize_32>

def SVHN(binary, root="./exp_data/SVHN"):
    # Data transformation
    transform = transforms.Compose([
        transforms.ToTensor()
    ])

    # Load dataset
    train_dataset = torchvision.datasets.SVHN(
        root=root,
        split="train",
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.SVHN(
        root=root,
        split="test",
        download=True,
        transform=transform
    )

    # Handle binary classification case
    if binary:
        # Method 1: directly filter the dataset (recommended)
        train_indices = []
        test_indices = []

        # Get training set indices
        for i in range(len(train_dataset)):
            # SVHN label access: train_dataset.labels[i] or train_dataset[i][1]
            label = train_dataset[i][1]
            if label in [0, 1]:
                train_indices.append(i)

        # Get test set indices
        for i in range(len(test_dataset)):
            label = test_dataset[i][1]
            if label in [0, 1]:
                test_indices.append(i)

        # Create subsets
        train_dataset = Subset(train_dataset, train_indices)
        test_dataset = Subset(test_dataset, test_indices)

    return train_dataset, test_dataset, transform
