# dspy_call_sig_plugin.py
from __future__ import annotations

from typing import Callable, Optional, List, Tuple

from mypy.plugin import Plugin, MethodSigContext, AttributeContext
from mypy.types import CallableType, Type, Instance, AnyType, TypeOfAny, TypeType
from mypy.nodes import (
    TypeInfo,
    Var,
    CallExpr,
    NameExpr,
    MemberExpr,
    ARG_NAMED,
    AssignmentStmt,
)


DSPY_MODULE_FULLNAME = "dspy.Module"
DSPY_SIGNATURE_FULLNAME = "dspy.Signature"
DSPY_PREDICTION_FULLNAME = "dspy.Prediction"


def is_subclass_of(info: TypeInfo, fullname: str) -> bool:
    for cls in info.mro:
        if cls.fullname == fullname:
            return True
    return False


class DspyCallSigPlugin(Plugin):
    def get_method_signature_hook(
        self, fullname: str
    ) -> Optional[Callable[[MethodSigContext], CallableType]]:
        if fullname.endswith(".__call__"):
            return self._call_signature_hook
        return None

    def get_attribute_hook(
        self, fullname: str
    ) -> Optional[Callable[[AttributeContext], Type]]:
        if fullname.startswith(f"{DSPY_PREDICTION_FULLNAME}."):
            attr_name = fullname.split(".")[-1]
            return lambda ctx: self._prediction_attribute_hook(ctx, attr_name)
        return None

    def _call_signature_hook(self, ctx: MethodSigContext) -> CallableType:
        recv = ctx.type
        if not isinstance(recv, Instance):
            return ctx.default_signature

        sig_info = self._get_signature_info(recv)
        if not sig_info:
            return self._fallback_forward_hook(ctx)

        inputs, outputs = self._extract_fields(sig_info)

        new_arg_types = [t for _, t in inputs]
        new_arg_names = [n for n, _ in inputs]
        new_arg_kinds = [ARG_NAMED] * len(inputs)

        # Return type: dspy.Prediction[Sig]
        try:
            prediction_type = ctx.api.named_type(DSPY_PREDICTION_FULLNAME)
            if isinstance(prediction_type, Instance):
                prediction_type = prediction_type.copy_modified(
                    args=[Instance(sig_info, [])]
                )
        except Exception:
            prediction_type = AnyType(TypeOfAny.from_error)

        return ctx.default_signature.copy_modified(
            arg_types=new_arg_types,
            arg_kinds=new_arg_kinds,
            arg_names=new_arg_names,
            ret_type=prediction_type,
        )

    def _fallback_forward_hook(self, ctx: MethodSigContext) -> CallableType:
        recv = ctx.type
        if not isinstance(recv, Instance):
            return ctx.default_signature

        info = recv.type
        if not is_subclass_of(info, DSPY_MODULE_FULLNAME):
            return ctx.default_signature

        sym = info.names.get("forward")
        if sym and sym.node and sym.type and isinstance(sym.type, CallableType):
            forward_sig = sym.type
            if forward_sig.arg_types:
                new_arg_types = forward_sig.arg_types[1:]
                new_arg_kinds = forward_sig.arg_kinds[1:]
                new_arg_names = forward_sig.arg_names[1:]
            else:
                new_arg_types, new_arg_kinds, new_arg_names = [], [], []

            return ctx.default_signature.copy_modified(
                arg_types=new_arg_types,
                arg_kinds=new_arg_kinds,
                arg_names=new_arg_names,
                ret_type=forward_sig.ret_type,
            )

        return ctx.default_signature.copy_modified(ret_type=AnyType(TypeOfAny.explicit))

    def _get_signature_info(self, instance: Instance) -> Optional[TypeInfo]:
        if instance.args:
            arg = instance.args[0]
            if isinstance(arg, Instance) and is_subclass_of(
                arg.type, DSPY_SIGNATURE_FULLNAME
            ):
                return arg.type

        info = instance.type
        for cls in info.mro:
            if "signature" in cls.names:
                sym = cls.names["signature"]
                if isinstance(sym.type, TypeType) and isinstance(
                    sym.type.item, Instance
                ):
                    if is_subclass_of(sym.type.item.type, DSPY_SIGNATURE_FULLNAME):
                        return sym.type.item.type
                if isinstance(sym.type, Instance):
                    if is_subclass_of(sym.type.type, DSPY_SIGNATURE_FULLNAME):
                        return sym.type.type
        return None

    def _extract_fields(
        self, sig_info: TypeInfo
    ) -> Tuple[List[Tuple[str, Type]], List[Tuple[str, Type]]]:
        inputs = []
        outputs = []
        class_def = sig_info.defn
        if not class_def:
            return [], []

        for stmt in class_def.defs.body:
            if isinstance(stmt, AssignmentStmt):
                field_type = self._get_field_type_from_expr(stmt.rvalue)
                if field_type:
                    for lvalue in stmt.lvalues:
                        if isinstance(lvalue, NameExpr):
                            name = lvalue.name
                            sym = sig_info.names.get(name)
                            if sym and sym.type:
                                if field_type == "InputField":
                                    inputs.append((name, sym.type))
                                elif field_type == "OutputField":
                                    outputs.append((name, sym.type))
        return inputs, outputs

    def _get_field_type_from_expr(self, expr: object) -> Optional[str]:
        if isinstance(expr, CallExpr):
            callee = expr.callee
            if isinstance(callee, MemberExpr) and callee.name in (
                "InputField",
                "OutputField",
            ):
                return callee.name
            if isinstance(callee, NameExpr) and callee.name in (
                "InputField",
                "OutputField",
            ):
                return callee.name
        return None

    def _prediction_attribute_hook(self, ctx: AttributeContext, attr_name: str) -> Type:
        if isinstance(ctx.type, Instance) and ctx.type.args:
            sig_type = ctx.type.args[0]
            if isinstance(sig_type, Instance):
                sig_info = sig_type.type
                _, outputs = self._extract_fields(sig_info)
                for name, itype in outputs:
                    if name == attr_name:
                        return itype

        # Fallback to default attribute lookup if it's not an output field.
        # This allows accessing methods like 'from_completions' or 'copy' defined in the stub/class.
        if ctx.default_attr_type != AnyType(TypeOfAny.from_error):
            return ctx.default_attr_type

        # If we reach here, the attribute is not a known output field and not in the class.
        # Since we want to be strict, we report an error.
        ctx.api.fail(
            f'"{DSPY_PREDICTION_FULLNAME}" has no attribute "{attr_name}"', ctx.context
        )
        return AnyType(TypeOfAny.from_error)


def plugin(version: str) -> type[Plugin]:
    return DspyCallSigPlugin
