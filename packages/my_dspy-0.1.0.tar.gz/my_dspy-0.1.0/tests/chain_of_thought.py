import dspy


class SummarySig(dspy.Signature):
    text: str = dspy.InputField()
    summary: str = dspy.OutputField()


# ChainOfThought should work similarly to Predict
cot = dspy.ChainOfThought(SummarySig)

result = cot(text="Long text here...")

# COT usually adds a 'rationale' field if not specified otherwise,
# but the plugin currently only extracts fields from the Signature.
# If we want to support 'rationale', it might need to be in the stub or handled specially.

res_text: str = result.summary

print(res_text)
