import dspy
from typing import Optional


class MySig(dspy.Signature):
    input: str = dspy.InputField()
    output: str = dspy.OutputField()


class CustomModule(dspy.Module):
    def __init__(self):
        super().__init__()
        self.predictor = dspy.Predict(MySig)

    def forward(self, text: str, mode: Optional[str] = None) -> str:  # type: ignore[override]
        result = self.predictor(input=text)
        return result.output


module = CustomModule()

# The plugin should pick up the signature from 'forward' for the module's __call__
res = module(text="hello", mode="polite")
# Also test without optional arg
res2 = module(text="hi")

print(res, res2)
