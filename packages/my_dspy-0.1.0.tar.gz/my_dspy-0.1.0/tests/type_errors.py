import dspy


class TypeSig(dspy.Signature):
    input_str: str = dspy.InputField()
    input_int: int = dspy.InputField()

    output_str: str = dspy.OutputField()
    output_float: float = dspy.OutputField()


predict = dspy.Predict(TypeSig)

# Correct call (for reference)
result = predict(input_str="hello", input_int=42)

# --- Errors that should be caught by mypy ---

# 1. Missing required argument
predict(input_str="only one")

# 2. Extra argument
predict(input_str="hi", input_int=1, extra="not here")

# 3. Wrong argument type
predict(input_str=123, input_int="not an int")

# 4. Accessing non-existent output field
val = result.no_such_field

# 5. Wrong type assignment from output field
out_int: int = result.output_str
