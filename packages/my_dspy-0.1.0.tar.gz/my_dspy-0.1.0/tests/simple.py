import dspy


class MySig(dspy.Signature):
    """
    This is my prompt
    """

    hello: str = dspy.InputField(description="The name to say hello to")
    goodbye: str = dspy.OutputField(description="The name to say goodbye to")


predict = dspy.Predict(MySig)


result = predict(hello="world")
# result = predict(hello="World")
result.goodbye
result.from_completions([{"goodbye": "world"}])
print(result)
