import dspy


class MultiSig(dspy.Signature):
    """Multiple inputs and outputs."""

    question: str = dspy.InputField()
    context: list[str] = dspy.InputField()

    answer: str = dspy.OutputField()
    confidence: float = dspy.OutputField()


predict = dspy.Predict(MultiSig)

# Test correct call
result = predict(
    question="What is the capital of France?", context=["Paris is the capital."]
)

# Test output attribute access
ans: str = result.answer
conf: float = result.confidence

print(f"Answer: {ans}, Confidence: {conf}")
