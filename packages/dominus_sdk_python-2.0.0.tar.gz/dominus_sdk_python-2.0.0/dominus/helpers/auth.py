"""
Token and URL resolution helpers.

Handles resolution of authentication token and service URLs
with support for environment variables and hardcoded fallbacks.
"""
import os
from typing import Optional


def _resolve_token(hardcoded_token: Optional[str] = None) -> Optional[str]:
    """
    Resolve auth token.
    
    Priority:
    1. Environment variable: DOMINUS_TOKEN
    2. Hardcoded fallback (passed as parameter)
    
    Note: When fetching from Infisical via Sovereign, the secret is stored as
    PROVISION_DOMINUS_TOKEN but should be set as DOMINUS_TOKEN in environment.
    The PROVISION_ prefix is dropped when setting environment variables.
    
    Args:
        hardcoded_token: Optional hardcoded token for development
        
    Returns:
        Token string or None
    """
    token = os.getenv("DOMINUS_TOKEN")
    if token:
        return token
    if hardcoded_token:
        return hardcoded_token
    return None


def _resolve_sovereign_url(environment: str = None) -> str:
    """
    Resolve Sovereign base URL from SDK flat file config.

    Args:
        environment: Environment override (development, staging, production)

    Returns:
        Sovereign base URL string
    """
    from ..config.endpoints import get_sovereign_url
    return get_sovereign_url(environment)

