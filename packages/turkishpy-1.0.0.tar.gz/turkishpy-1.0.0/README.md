# turkishpy

Python'u Türkçe komutlarla yaz.