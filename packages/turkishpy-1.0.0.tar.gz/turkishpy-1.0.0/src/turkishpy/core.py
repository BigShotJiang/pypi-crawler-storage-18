
__all__ = [
    "çıktı","girdi","uzunluk","tür","liste","sözlük","küme","aralık",
    "toplam","en_büyük","en_küçük","sırala","tersine","mutlak","yuvarla",
    "tam_sayı","ondalık","mantıksal","hepsi","herhangi","say","ekle","sil","bekle"
]

import time

def çıktı(*args, **kwargs): print(*args, **kwargs)
def girdi(mesaj=""): return input(mesaj)
def uzunluk(x): return len(x)
def tür(x): return type(x)

def liste(*args): return list(args)
def sözlük(**kwargs): return dict(kwargs)
def küme(*args): return set(args)
def aralık(*args): return range(*args)

def toplam(x): return sum(x)
def en_büyük(x): return max(x)
def en_küçük(x): return min(x)
def sırala(x): return sorted(x)
def tersine(x): return list(reversed(x))

def mutlak(x): return abs(x)
def yuvarla(x, n=0): return round(x, n)
def tam_sayı(x): return int(x)
def ondalık(x): return float(x)

def mantıksal(x): return bool(x)
def hepsi(x): return all(x)
def herhangi(x): return any(x)
def say(x): return len(x)

def ekle(x, y): x.append(y)
def sil(x, y): x.remove(y)
def bekle(saniye): time.sleep(saniye)
