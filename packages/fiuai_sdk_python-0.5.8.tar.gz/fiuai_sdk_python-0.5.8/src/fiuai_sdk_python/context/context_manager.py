# -- coding: utf-8 --
# Project: fiuai-world
# Created Date: 2025-01-27
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

import uuid
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from fiuai_sdk_python.context import RequestContext
from fiuai_sdk_python.auth.type import AuthData
from logging import getLogger

logger = getLogger(__name__)


class WorldData(BaseModel):
    """World 上下文数据模型"""
    event_id: Optional[str] = Field(default=None, description="事件ID")
    task_id: Optional[str] = Field(default=None, description="任务ID")


class ContextManager:
    """
    上下文管理器，用于在后台任务中初始化和管理请求上下文
    使用 context manager 模式，确保上下文在任务结束时自动清理
    
    注意：
    - 上下文只在 `with` 语句块内生效
    - 退出 `with` 块时，上下文会被自动清理
    - 在异步环境中，上下文会在同一个异步任务中保持
    - 如果需要在多个函数调用中共享上下文，需要在整个调用链中使用同一个 `with` 块
    """
    
    def __init__(
        self,
        auth_data: Optional[AuthData] = None,
        headers: Optional[Dict[str, Any]] = None,
        world_data: Optional[WorldData] = None,
        event_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ):
        """
        初始化上下文管理器
        
        Args:
            auth_data: 认证数据对象，如果提供则从认证数据创建上下文
            headers: 请求头字典，如果提供则直接使用
            world_data: World 上下文数据对象，可选
            event_id: 事件ID，可选（如果提供了 world_data，则忽略此参数）
            task_id: 任务ID，可选（如果提供了 world_data，则忽略此参数）
        """
        if auth_data and headers:
            raise ValueError("不能同时提供 auth_data 和 headers，请只提供其中一个")
        
        # 处理 world_data
        if world_data:
            self.world_data = world_data
        elif event_id is not None or task_id is not None:
            self.world_data = WorldData(event_id=event_id, task_id=task_id)
        else:
            self.world_data = WorldData()
        
        if auth_data:
            self._context = self._create_context_from_auth_data(auth_data)
        elif headers:
            self._context = RequestContext.from_dict(headers)
        else:
            raise ValueError("必须提供 auth_data 或 headers 之一")
    
    def _create_context_from_auth_data(self, auth_data: AuthData) -> RequestContext:
        """
        从认证数据创建请求上下文
        
        Args:
            auth_data: 认证数据对象
            
        Returns:
            RequestContext: 请求上下文对象
        """
        headers = {
            "x-fiuai-user": auth_data.user_id,
            "x-fiuai-auth-tenant-id": auth_data.auth_tenant_id,
            "x-fiuai-current-company": auth_data.current_company,
            "x-fiuai-impersonation": auth_data.impersonation or "",
            "x-fiuai-unique-no": auth_data.company_unique_no or auth_data.current_company,
            "x-fiuai-trace-id": auth_data.trace_id or str(uuid.uuid4()),
            "x-fiuai-client": auth_data.client or "unknown",
            "x-fiuai-lang": "zh",
            "accept-language": "zh",
        }
        return RequestContext.from_dict(headers)
    
    def __enter__(self):
        """进入上下文"""
        # 设置全局 ContextManager 实例
        from . import auth_data
        auth_data._current_context_manager = self
        
        self._context.__enter__()
        logger.debug("Context initialized")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文"""
        self._context.__exit__(exc_type, exc_val, exc_tb)
        
        # 清除全局 ContextManager 实例
        from . import auth_data
        auth_data._current_context_manager = None
        
        logger.debug("Context cleaned up")
    
    def update_auth_data(self, auth_data: AuthData):
        """
        更新上下文中的认证数据
        
        Args:
            auth_data: 新的认证数据对象
        """
        new_context = self._create_context_from_auth_data(auth_data)
        # 退出旧上下文
        if hasattr(self._context, '_token') and self._context._token:
            self._context.__exit__(None, None, None)
        # 进入新上下文
        self._context = new_context
        self._context.__enter__()
        logger.debug("Context auth data updated")
    
    def update_headers(self, headers: Dict[str, Any]):
        """
        更新上下文中的请求头
        
        Args:
            headers: 新的请求头字典
        """
        new_context = RequestContext.from_dict(headers)
        # 退出旧上下文
        if hasattr(self._context, '_token') and self._context._token:
            self._context.__exit__(None, None, None)
        # 进入新上下文
        self._context = new_context
        self._context.__enter__()
        logger.debug("Context headers updated")


def init_context(
    auth_data: Optional[AuthData] = None,
    headers: Optional[Dict[str, Any]] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    current_company: Optional[str] = None,
    world_data: Optional[WorldData] = None,
    event_id: Optional[str] = None,
    task_id: Optional[str] = None,
    **kwargs
) -> ContextManager:
    """
    初始化上下文，用于后台任务
    
    注意：返回的 ContextManager 实例只在 `with` 语句块内生效。
    一旦退出 `with` 块，上下文会被自动清理。
    在异步环境中，上下文会在同一个异步任务（task）中保持，
    但如果创建了新的任务（如 asyncio.create_task），新任务会继承父任务的上下文。
    
    支持多种初始化方式：
    1. 提供 auth_data 对象
    2. 提供 headers 字典
    3. 提供基本认证参数（user_id, auth_tenant_id, current_company）
    
    Args:
        auth_data: 认证数据对象
        headers: 请求头字典
        user_id: 用户ID
        auth_tenant_id: 租户ID
        current_company: 当前公司ID
        world_data: World 上下文数据对象，可选
        event_id: 事件ID，可选（如果提供了 world_data，则忽略此参数）
        task_id: 任务ID，可选（如果提供了 world_data，则忽略此参数）
        **kwargs: 其他认证参数（impersonation, company_unique_no, trace_id, client等）
        
    Returns:
        ContextManager: 上下文管理器对象，必须在 `with` 语句中使用
        
    Examples:
        # 方式1: 使用 AuthData 对象
        auth_data = AuthData(user_id="user1", auth_tenant_id="tenant1", current_company="company1")
        with init_context(auth_data=auth_data):
            # 执行任务，上下文在此块内有效
            auth = get_auth_data()  # 可以获取认证数据
            # 执行其他操作...
        # 退出 with 块后，上下文被清理
        
        # 方式2: 使用 headers 字典
        headers = {"x-fiuai-user": "user1", "x-fiuai-auth-tenant-id": "tenant1", ...}
        with init_context(headers=headers):
            # 执行任务
            pass
        
        # 方式3: 使用基本参数
        with init_context(user_id="user1", auth_tenant_id="tenant1", current_company="company1"):
            # 执行任务
            pass
        
        # 异步任务示例
        async def background_task():
            with init_context(user_id="user1", auth_tenant_id="tenant1", current_company="company1"):
                # 在这个异步函数中，上下文有效
                auth = get_auth_data()
                # 执行异步操作...
                await some_async_operation()
    """
    if auth_data:
        return ContextManager(auth_data=auth_data, world_data=world_data, event_id=event_id, task_id=task_id)
    elif headers:
        return ContextManager(headers=headers, world_data=world_data, event_id=event_id, task_id=task_id)
    elif user_id and auth_tenant_id and current_company:
        # 从基本参数创建 AuthData
        auth_data = AuthData(
            user_id=user_id,
            auth_tenant_id=auth_tenant_id,
            current_company=current_company,
            impersonation=kwargs.get("impersonation", ""),
            company_unique_no=kwargs.get("company_unique_no", current_company),
            trace_id=kwargs.get("trace_id", str(uuid.uuid4())),
            client=kwargs.get("client", "unknown"),
        )
        return ContextManager(auth_data=auth_data, world_data=world_data, event_id=event_id, task_id=task_id)
    else:
        raise ValueError(
            "必须提供以下之一："
            "1. auth_data 对象"
            "2. headers 字典"
            "3. user_id, auth_tenant_id, current_company 基本参数"
        )

