# -- coding: utf-8 --
# Project: fiuai-world
# Created Date: 2025-01-27
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Optional
from fiuai_sdk_python.auth.type import AuthData
from fiuai_sdk_python.context import get_current_headers, is_current_context_valid
from logging import getLogger

logger = getLogger(__name__)

# 全局变量，用于存储当前的 ContextManager 实例
# 使用 TYPE_CHECKING 避免循环导入
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .context_manager import ContextManager, WorldData

_current_context_manager: Optional['ContextManager'] = None


def get_auth_data() -> Optional[AuthData]:
    """
    从当前上下文中获取认证数据
    
    Returns:
        Optional[AuthData]: 认证数据对象，如果上下文无效或不存在则返回 None
        
    Examples:
        auth_data = get_auth_data()
        if auth_data:
            print(f"当前用户: {auth_data.user_id}")
    """
    try:
        # 检查上下文是否有效
        if not is_current_context_valid():
            logger.warning("Current context is invalid, cannot get auth data")
            return None
        
        # 获取当前上下文中的请求头
        headers = get_current_headers()
        if not headers:
            logger.warning("Cannot get headers from current context")
            return None
        
        # 从请求头中提取认证信息
        auth_data = AuthData(
            user_id=headers.get("x-fiuai-user", ""),
            auth_tenant_id=headers.get("x-fiuai-auth-tenant-id", ""),
            current_company=headers.get("x-fiuai-current-company", ""),
            impersonation=headers.get("x-fiuai-impersonation", ""),
            company_unique_no=headers.get("x-fiuai-unique-no", ""),
            trace_id=headers.get("x-fiuai-trace-id", ""),
            client=headers.get("x-fiuai-client", "unknown"),
        )
        
        return auth_data
        
    except Exception as e:
        logger.error(f"Failed to get auth data: {e}")
        return None


def set_auth_data(auth_data: AuthData) -> bool:
    """
    设置当前上下文中的认证数据
    注意：此函数需要在已初始化的 ContextManager 中使用，否则会失败
    
    Args:
        auth_data: 认证数据对象
        
    Returns:
        bool: 是否设置成功
        
    Examples:
        auth_data = AuthData(user_id="user1", auth_tenant_id="tenant1", current_company="company1")
        if set_auth_data(auth_data):
            print("认证数据设置成功")
    """
    global _current_context_manager
    
    try:
        if _current_context_manager is None:
            logger.warning("ContextManager does not exist, cannot set auth data. Please initialize context with init_context first")
            return False
        
        # 使用 ContextManager 的 update_auth_data 方法
        _current_context_manager.update_auth_data(auth_data)
        return True
        
    except Exception as e:
        logger.error(f"Failed to set auth data: {e}")
        return False


def update_auth_data(
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    current_company: Optional[str] = None,
    **kwargs
) -> bool:
    """
    更新当前上下文中的部分认证数据
    只更新提供的字段，未提供的字段保持不变
    
    Args:
        user_id: 用户ID
        auth_tenant_id: 租户ID
        current_company: 当前公司ID
        **kwargs: 其他认证参数（impersonation, company_unique_no, trace_id, client等）
        
    Returns:
        bool: 是否更新成功
        
    Examples:
        # 只更新用户ID
        update_auth_data(user_id="new_user")
        
        # 更新多个字段
        update_auth_data(user_id="new_user", current_company="new_company")
    """
    try:
        # 获取当前认证数据
        current_auth_data = get_auth_data()
        if not current_auth_data:
            logger.warning("Cannot get current auth data, please initialize context first")
            return False
        
        # 创建新的认证数据，只更新提供的字段
        new_auth_data = AuthData(
            user_id=user_id or current_auth_data.user_id,
            auth_tenant_id=auth_tenant_id or current_auth_data.auth_tenant_id,
            current_company=current_company or current_auth_data.current_company,
            impersonation=kwargs.get("impersonation", current_auth_data.impersonation),
            company_unique_no=kwargs.get("company_unique_no", current_auth_data.company_unique_no),
            trace_id=kwargs.get("trace_id", current_auth_data.trace_id),
            client=kwargs.get("client", current_auth_data.client),
        )
        
        # 使用 set_auth_data 更新
        return set_auth_data(new_auth_data)
        
    except Exception as e:
        logger.error(f"Failed to update auth data: {e}")
        return False


def get_world_data() -> Optional['WorldData']:
    """
    从当前上下文中获取 World 上下文数据
    
    Returns:
        Optional[WorldData]: World 上下文数据对象，如果上下文无效或不存在则返回 None
        
    Examples:
        world_data = get_world_data()
        if world_data:
            print(f"当前事件ID: {world_data.event_id}")
            print(f"当前任务ID: {world_data.task_id}")
    """
    global _current_context_manager
    
    try:
        if _current_context_manager is None:
            return None
        
        return _current_context_manager.world_data
        
    except Exception as e:
        logger.error(f"Failed to get world data: {e}")
        return None

