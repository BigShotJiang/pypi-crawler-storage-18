"""
Wikilangs - A Python package for consuming Wikilangs NLP models.
"""

from .main import hello, tokenizer, ngram, markov, vocabulary

__version__ = "0.1.0"
__all__ = ["tokenizer", "ngram", "markov", "vocabulary"]
