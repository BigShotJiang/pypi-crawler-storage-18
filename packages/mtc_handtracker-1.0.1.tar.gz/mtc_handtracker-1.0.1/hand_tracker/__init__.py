from .detector import HandTrackingModule
