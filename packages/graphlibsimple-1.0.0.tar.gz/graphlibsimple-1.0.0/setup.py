from setuptools import setup, find_packages

setup(
    name="graphlibsimple",  # Имя для pip install
    version="1.0.0",
    author="Ваше Имя",
    description="Очень простая библиотека для работы с графами",
    packages=find_packages(),  # Находит все папки с __init__.py
    python_requires=">=3.6",
)