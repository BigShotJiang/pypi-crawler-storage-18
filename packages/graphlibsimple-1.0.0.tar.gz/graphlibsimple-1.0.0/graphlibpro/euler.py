"""
Модуль для поиска эйлерова пути (пройти все рёбра по одному разу)
"""


def find_euler_path(edges):
    """
    Найти путь, который проходит по всем рёбрам по одному разу

    Аргументы:
        edges: список рёбер, например [(0,1), (1,2), (2,0)]

    Возвращает:
        список вершин в порядке прохождения или None
    """

    if not edges:
        return []

    # 1. Создаём граф (список соседей)
    graph = {}
    for a, b in edges:
        if a not in graph:
            graph[a] = []
        if b not in graph:
            graph[b] = []

        graph[a].append(b)
        graph[b].append(a)

    # 2. Проверяем, можно ли найти путь
    #    Нужно 0 или 2 вершины с нечётным числом рёбер
    odd_count = 0
    start_vertex = list(graph.keys())[0]  # Берём первую вершину

    for vertex in graph:
        # Считаем сколько рёбер из вершины
        edge_count = len(graph[vertex])

        if edge_count % 2 == 1:  # Нечётное число рёбер
            odd_count += 1
            start_vertex = vertex  # Начинаем с нечётной

    if odd_count not in [0, 2]:
        return None  # Путь невозможен

    # 3. Ищем путь (простой алгоритм)
    stack = [start_vertex]  # Вершины для обработки
    path = []  # Конечный путь

    while stack:
        current = stack[-1]  # Берём последнюю вершину

        if graph[current]:  # Если есть куда идти
            # Идём по первому доступному ребру
            next_vertex = graph[current].pop()
            # Удаляем обратное ребро
            graph[next_vertex].remove(current)
            # Переходим в следующую вершину
            stack.append(next_vertex)
        else:
            # Тупик - добавляем в путь
            path.append(stack.pop())

    # 4. Переворачиваем путь
    return path[::-1]