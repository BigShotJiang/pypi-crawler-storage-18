# Просто импортируем всё из наших модулей
from .euler import find_euler_path
from .dijkstra import find_shortest_path
from .hamilton import find_hamilton_cycle

# Версия библиотеки
__version__ = "1.0.0"