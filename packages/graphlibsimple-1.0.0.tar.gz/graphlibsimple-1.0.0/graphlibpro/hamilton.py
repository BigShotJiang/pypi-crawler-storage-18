def find_hamilton_cycle(edges, vertices):
    """
    Найти цикл, который проходит по всем вершинам по одному разу

    Аргументы:
        edges: список рёбер, например [(0,1), (1,2), (2,0)]
        vertices: список всех вершин, например [0,1,2]

    Возвращает:
        список вершин цикла или None
    """

    # 1. Создаём граф
    graph = {}
    for vertex in vertices:
        graph[vertex] = []

    for a, b in edges:
        if a in graph and b in graph:
            graph[a].append(b)
            graph[b].append(a)

    # 2. Начинаем поиск
    path = [vertices[0]]  # Начинаем с первой вершины

    def backtrack():
        # Если прошли все вершины
        if len(path) == len(vertices):
            # Проверяем, можно ли вернуться в начало
            if path[0] in graph[path[-1]]:
                return path + [path[0]]  # Замыкаем цикл
            return None

        current = path[-1]

        # Пробуем все возможные следующие вершины
        for next_vertex in graph[current]:
            if next_vertex not in path:  # Ещё не были
                path.append(next_vertex)

                result = backtrack()
                if result is not None:
                    return result

                path.pop()  # Откат

        return None

    # 3. Запускаем поиск
    return backtrack()