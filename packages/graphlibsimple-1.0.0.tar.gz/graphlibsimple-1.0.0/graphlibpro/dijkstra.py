"""
Модуль для поиска самого короткого пути
"""


def find_shortest_path(edges, start, end):
    """
    Найти самый короткий путь от start до end

    Аргументы:
        edges: список рёбер с весом, например [('A','B',5), ('B','C',3)]
        start: начальная вершина
        end: конечная вершина

    Возвращает:
        (путь, расстояние) или (None, бесконечность) если нет пути
    """

    # 1. Создаём граф
    graph = {}
    for a, b, weight in edges:
        if a not in graph:
            graph[a] = []
        if b not in graph:
            graph[b] = []

        graph[a].append((b, weight))
        graph[b].append((a, weight))

    # 2. Инициализация
    # Бесконечно большие расстояния
    distances = {vertex: float('inf') for vertex in graph}
    distances[start] = 0

    # Откуда пришли
    previous = {vertex: None for vertex in graph}

    # Непосещённые вершины
    unvisited = set(graph.keys())

    # 3. Основной алгоритм
    while unvisited:
        # Находим ближайшую непосещённую вершину
        current = None
        min_dist = float('inf')

        for vertex in unvisited:
            if distances[vertex] < min_dist:
                min_dist = distances[vertex]
                current = vertex

        if current is None or current == end:
            break

        unvisited.remove(current)

        # Смотрим соседей
        for neighbor, weight in graph[current]:
            new_dist = distances[current] + weight

            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                previous[neighbor] = current

    # 4. Восстанавливаем путь
    if distances[end] == float('inf'):
        return None, float('inf')

    path = []
    current = end

    while current is not None:
        path.append(current)
        current = previous[current]

    path.reverse()

    return path, distances[end]