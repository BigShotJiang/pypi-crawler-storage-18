# Импортируем нашу функцию
from graphlibpro.euler import find_euler_path


def test_simple_cycle():
    """Тест простого цикла"""
    # Треугольник: 0-1-2-0
    edges = [(0, 1), (1, 2), (2, 0)]

    path = find_euler_path(edges)

    # Проверяем что путь найден и правильной длины
    assert path is not None
    assert len(path) == 4  # 3 вершины + возврат к началу

    print("✓ Тест 1 пройден: простой цикл")


def test_no_path():
    """Тест когда пути нет"""
    # Граф где нельзя пройти все рёбра
    edges = [(0, 1), (0, 2), (1, 2), (2, 3)]

    path = find_euler_path(edges)

    # Должен быть None
    assert path is None

    print("✓ Тест 2 пройден: путь невозможен")


# Запуск тестов
if __name__ == "__main__":
    test_simple_cycle()
    test_no_path()
    print("Все тесты пройдены!")