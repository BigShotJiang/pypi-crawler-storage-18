from graphlibpro.hamilton import find_hamilton_cycle

def test_square():
    """Тест квадрата"""
    # Квадрат: 0-1-2-3-0
    vertices = [0, 1, 2, 3]
    edges = [(0, 1), (1, 2), (2, 3), (3, 0), (0, 2)]

    cycle = find_hamilton_cycle(edges, vertices)

    # Проверяем что цикл найден
    assert cycle is not None
    # Должны посетить все вершины + вернуться в начало
    assert len(cycle) == len(vertices) + 1

    print("1 тест пройден: квадрат")


def test_no_cycle():
    """Тест когда цикла нет"""
    # Просто линия: 0-1-2
    vertices = [0, 1, 2]
    edges = [(0, 1), (1, 2)]

    cycle = find_hamilton_cycle(edges, vertices)

    # Не должно быть цикла
    assert cycle is None

    print("2 тест пройден: цикла нет")


if __name__ == "__main__":
    test_square()
    test_no_cycle()
    print("Все тесты пройдены!")