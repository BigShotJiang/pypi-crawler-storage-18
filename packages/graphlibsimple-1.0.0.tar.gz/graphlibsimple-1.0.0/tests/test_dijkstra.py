"""
Тест для алгоритма Дейкстры
"""

from graphlibpro.dijkstra import find_shortest_path


def test_simple_path():
    """Тест простого пути"""
    # A --5-- B --3-- C
    edges = [('A', 'B', 5), ('B', 'C', 3)]

    path, dist = find_shortest_path(edges, 'A', 'C')

    # Проверяем
    assert path == ['A', 'B', 'C']
    assert dist == 8

    print("✓ Тест 1 пройден: простой путь")


def test_no_path():
    """Тест когда пути нет"""
    # A --5-- B    C (изолированная)
    edges = [('A', 'B', 5)]

    path, dist = find_shortest_path(edges, 'A', 'C')

    # Должен быть None и бесконечность
    assert path is None
    assert dist == float('inf')

    print("✓ Тест 2 пройден: путь не найден")


if __name__ == "__main__":
    test_simple_path()
    test_no_path()
    print("Все тесты пройдены!")