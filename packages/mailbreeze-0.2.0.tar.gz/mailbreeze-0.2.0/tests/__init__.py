"""MailBreeze SDK tests."""
