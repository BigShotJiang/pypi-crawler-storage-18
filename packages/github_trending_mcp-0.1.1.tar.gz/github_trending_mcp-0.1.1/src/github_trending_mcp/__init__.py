"""GitHub Trending MCP Server - Get GitHub trending repositories via MCP protocol."""

__version__ = "0.1.1"



