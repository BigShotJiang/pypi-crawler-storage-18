"""Entry point for python -m github_trending_mcp."""

from github_trending_mcp.server import main

if __name__ == "__main__":
    main()

