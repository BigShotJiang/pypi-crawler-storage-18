# noun-verb
[![PyPI version](https://badge.fury.io/py/noun-verb.svg)](https://badge.fury.io/py/noun-verb)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/noun-verb)](https://pepy.tech/project/noun-verb)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package that helps users reframe their self-perception from static identity labels (nouns) to dynamic actions and processes (verbs). It uses structured LLM interactions to process user-provided text reflections and returns a transformed perspective that emphasizes growth, change, and agency.

## Installation

```bash
pip install noun_verb
```

## Usage

Import and use the `noun_verb` function to process user input:

```python
from noun_verb import noun_verb

user_input = "I am a shy person."
result = noun_verb(user_input)
print(result)
```

### Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): A LangChain LLM instance. If not provided, the default `ChatLLM7` is used.
- `api_key` (Optional[str]): API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` is used.

### Using a Custom LLM

You can use any LangChain-compatible LLM by passing it to the `llm` parameter:

#### OpenAI Example
```python
from langchain_openai import ChatOpenAI
from noun_verb import noun_verb

llm = ChatOpenAI()
response = noun_verb(user_input, llm=llm)
```

#### Anthropic Example
```python
from langchain_anthropic import ChatAnthropic
from noun_verb import noun_verb

llm = ChatAnthropic()
response = noun_verb(user_input, llm=llm)
```

#### Google Generative AI Example
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from noun_verb import noun_verb

llm = ChatGoogleGenerativeAI()
response = noun_verb(user_input, llm=llm)
```

### Using a Custom API Key for LLM7

To use your own LLM7 API key:

```python
from noun_verb import noun_verb

response = noun_verb(user_input, api_key="your_api_key_here")
```

Or set the environment variable:
```bash
export LLM7_API_KEY="your_api_key_here"
```

You can get a free API key by registering at [https://token.llm7.io/](https://token.llm7.io/).

## Default LLM

By default, the package uses `ChatLLM7` from the `langchain_llm7` package (available at [PyPI](https://pypi.org/project/langchain-llm7/)). The free tier rate limits are sufficient for most use cases.

## Contributing

If you encounter any issues or have suggestions, please open an issue on [GitHub](https://github.com/chigwell/noun-verb/issues).

## Author

Eugene Evstafev  
Email: hi@euegne.plus  
GitHub: [chigwell](https://github.com/chigwell)