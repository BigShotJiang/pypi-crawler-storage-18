# Unistruct
[![PyPI version](https://badge.fury.io/py/unistruct.svg)](https://badge.fury.io/py/unistruct)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/unistruct)](https://pepy.tech/project/unistruct)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


Extract structured information from unstructured text inputs with ease.

Unistruct is a Python package that takes unstructured text, such as project descriptions, meeting notes, or customer feedback, and converts it into actionable data with key details like project name, duration, milestones, and resources required.

## Installation

Get started with Unistruct by installing it with pip:
```
bash
pip install unistruct
```

## Usage

Unistruct uses the ChatLLM7 from langchain_llm7 by default, but you can pass your own LL.M instance using the `llm` parameter.

```python
from unistruct import unistruct
import os

user_input = "....... 
response = unistruct(user_input)
```

## Using your own LLM instance

To use a different LLM instance, such as the OpenAI or Anthropic models, you can pass your own instance using the `llm` parameter.

```python
from langchain_openai import ChatOpenAI
from unistruct import unistruct

llm = ChatOpenAI()
response = unistruct(user_input, llm=llm)
```

Or with Anthropic:
```python
from langchain_anthropic import ChatAnthropic
from unistruct import unistruct

llm = ChatAnthropic()
response = unistruct(user_input, llm=llm)
```

Or with Google Generative AI:
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from unistruct import unistruct

llm = ChatGoogleGenerativeAI()
response = unistruct(user_input, llm=llm)
```

## Environment Variables

You can set your LLM7 API key as an environment variable `LLM7_API_KEY` to use the higher rate limits for the LLM7 free tier.

```bash
export LLM7_API_KEY="your_api_key"
```

Or, you can pass the API key directly using the `api_key` parameter.

```python
response = unistruct(user_input, api_key="your_api_key")
```

## Support and Discuss

Head over to the GitHub issues page to report any issues or discuss Unistruct: https://github.com/chigwell/unistruct

## Author

Eugene Evstafev (hi@euegne.plus)

## License

Unistruct is released under the MIT License.

## Version History

Check the CHANGELOG for the latest changes.

## Thanks

Thanks to the langchain_llm7 and langchain_openai packages for the underlying LLM functionality.