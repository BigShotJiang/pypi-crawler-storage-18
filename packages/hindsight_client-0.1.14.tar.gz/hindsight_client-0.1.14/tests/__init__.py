"""Tests for Memora client."""
