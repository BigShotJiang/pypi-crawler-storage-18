# funfedi_runner

Running tests

## steps

```
docker compose up
docker compose exec pasture-one-actor /opt/test_shell.sh /bin/sh
```

Run tests via

```bash
PYTHONPATH=$(pwd) FEDI_APP=name \
    pytest --alluredir  allure-results tests
```

### Running allure

```bash
docker run --rm -ti -v .:/work --workdir /work helgekr/allure ./allure.sh
```

and serve via

```bash
python -mhttp.server -dallure-report
```