import os


def get_app_name() -> str:
    app_name = os.environ.get("FEDI_APP")
    if app_name is None:
        raise Exception("Need to specify an application")
    return app_name
