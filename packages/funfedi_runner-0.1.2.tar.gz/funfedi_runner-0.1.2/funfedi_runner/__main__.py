import click

from .allure import Results


@click.command
def main():
    results = Results.load()

    passing = []

    for name, failing in results.fails_for.items():
        if len(failing) > 0:
            print(f"{name[0]:>50},{name[1]:<20}: " + ", ".join(sorted(failing)))
        else:
            passing.append(f"{name[0]:>50},{name[1]:<20}")

    print("Passing: ")
    for x in passing:
        print(x)


if __name__ == "__main__":
    main()
