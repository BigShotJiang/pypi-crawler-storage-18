from .parse import AllureResult, load_results


data = {
    "name": "test_activity_context[mitra-Varying the value of the @context property-AP context]",
    "status": "passed",
    "attachments": [
        {
            "name": "comments",
            "source": "f29accbb-f374-4e72-9b4d-296c5d720f67-attachment.json",
            "type": "application/json",
        },
        {
            "name": "activity",
            "source": "013a1544-16e8-4f1a-83db-989ace47d0b4-attachment.json",
            "type": "application/json",
        },
        {
            "name": "api result",
            "source": "6efdca2a-b63d-4170-af24-d4cdb29379bc-attachment.json",
            "type": "application/json",
        },
    ],
    "parameters": [
        {"name": "app_name", "value": "'mitra'"},
        {"name": "name", "value": "'Varying the value of the @context property'"},
        {"name": "case_name", "value": "'AP context'"},
    ],
    "start": 1766417613602,
    "stop": 1766417614644,
    "uuid": "79ddd86c-e296-4c73-b284-9afbbe1d85b2",
    "historyId": "b73589ea02bb8794b194df33254d086b",
    "testCaseId": "92a174b4ff935c4655389eaa12f54183",
    "fullName": "tests.test_activies#test_activity_context",
    "labels": [
        {"name": "suite", "value": "Varying the value of the @context property"},
        {"name": "subSuite", "value": "unknown"},
        {"name": "parentSuite", "value": "Application mitra"},
        {"name": "tag", "value": "asyncio"},
        {"name": "host", "value": "2f2ed6035f9c"},
        {"name": "thread", "value": "388-MainThread"},
        {"name": "framework", "value": "pytest"},
        {"name": "language", "value": "cpython3"},
        {"name": "package", "value": "tests.test_activies"},
    ],
    "titlePath": ["tests", "test_activies.py"],
}


def test_parse():
    result = AllureResult.from_data(data)

    assert isinstance(result, AllureResult)
    assert result.app_name == "mitra"


def test_load_results():
    load_results()
