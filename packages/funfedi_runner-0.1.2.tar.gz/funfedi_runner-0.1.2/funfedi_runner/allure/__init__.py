from dataclasses import dataclass

from .parse import load_results


@dataclass
class Results:
    test_names: list[tuple[str, str]]
    fails_for: dict[tuple[str, str], list[str]]

    @staticmethod
    def load():
        results = load_results()

        names = {(x.test_name, x.case_name) for x in results}
        test_names = sorted(list(names))
        fails_for = {name: [] for name in test_names}

        for r in results:
            if r.result != "passed":
                fails_for[(r.test_name, r.case_name)].append(r.app_name)

        return Results(test_names=test_names, fails_for=fails_for)
