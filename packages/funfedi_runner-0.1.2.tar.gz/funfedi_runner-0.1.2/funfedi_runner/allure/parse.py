from dataclasses import dataclass
from glob import glob
import json


def cleanup_value(s: str) -> str:
    if s[0] == "'" and s[-1] == "'":
        s = s[1:-1]
    return s


@dataclass
class AllureResult:
    app_name: str
    test_name: str
    case_name: str
    result: str

    @staticmethod
    def from_data(data: dict):
        app_name: str | None = None
        case_name: str | None = None
        test_name: str | None = None
        parameters = data.get("parameters", [])

        for param in parameters:
            match param.get("name"):
                case "app_name":
                    app_name = cleanup_value(param.get("value"))
                case "case_name":
                    case_name = cleanup_value(param.get("value"))
                case "name":
                    test_name = cleanup_value(param.get("value"))

        if app_name is None:
            raise ValueError("app_name not found")
        if test_name is None:
            raise ValueError("test_name not found")
        if case_name is None:
            raise ValueError("case_name not found")
        return AllureResult(
            app_name=app_name,
            case_name=case_name,
            test_name=test_name,
            result=data.get("status", ""),
        )


def load_results() -> list[AllureResult]:
    results = []
    for filename in glob("allure-results/*-result.json"):
        with open(filename) as f:
            data = json.load(f)
        try:
            results.append(AllureResult.from_data(data))
        except ValueError:
            print("Failed to parse:")
            print(data)

    return results
