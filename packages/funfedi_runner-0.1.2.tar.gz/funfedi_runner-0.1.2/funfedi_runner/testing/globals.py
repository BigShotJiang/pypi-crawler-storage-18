from typing import Any
from funfedi_runner.runner import Runner
from funfedi_runner.tools import get_app_name

app_name: str = get_app_name()
runner: Runner | None = None

parsing: Any | None = None
