from .globals import app_name

__all__ = ["app_name"]
