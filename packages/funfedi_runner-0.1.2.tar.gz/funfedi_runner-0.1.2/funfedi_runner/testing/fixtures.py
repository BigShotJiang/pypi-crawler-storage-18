import pytest

from funfedi_connect import application_for_name
from funfedi_runner.runner import Runner

from . import globals


@pytest.fixture(scope="module")
def runner() -> Runner:
    if globals.runner:
        return globals.runner
    application = application_for_name(globals.app_name)

    globals.runner = Runner(application)
    return globals.runner


@pytest.fixture(scope="function")
async def parsing_and_run(runner):
    async with runner.runner() as (session, parsing, run):
        yield session, parsing, run
