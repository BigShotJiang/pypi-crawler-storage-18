# semantic-complexity (Python)

Multi-dimensional code complexity analyzer for Python.

## Installation

```bash
pip install semantic-complexity
```

## Usage

### CLI

```bash
# Analyze a file
semantic-complexity path/to/file.py

# Analyze a directory
semantic-complexity path/to/project/

# Output as Markdown report
semantic-complexity path/to/project/ -f markdown -o report.md

# Filter by threshold
semantic-complexity path/to/project/ --threshold 20
```

### Python API

```python
from semantic_complexity import analyze_source, analyze_functions

# Analyze source code
result = analyze_source("""
def complex_function(x):
    if x > 0:
        for i in range(x):
            if i % 2 == 0:
                print(i)
""")

print(f"Weighted complexity: {result.weighted}")
print(f"Control: {result.control}")
print(f"Nesting: {result.nesting}")
print(f"Contributions: {result.contributions}")

# Analyze functions individually
functions = analyze_functions(source)
for fn in functions:
    print(f"{fn.name}: McCabe={fn.cyclomatic}, Dimensional={fn.dimensional.weighted}")
```

## Domains

| Domain | Weight | Description |
|--------|--------|-------------|
| Control (C) | 1.0 | Cyclomatic complexity (branches, loops) |
| Nesting (N) | 1.5 | Depth penalty |
| State (S) | 2.0 | State mutations and transitions |
| Async (A) | 2.5 | Async/await, coroutines |
| Coupling (Λ) | 3.0 | Hidden dependencies, side effects |

## License

MIT
