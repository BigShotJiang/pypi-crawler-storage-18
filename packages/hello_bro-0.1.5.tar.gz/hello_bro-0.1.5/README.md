HELLO PROJECT (X-Mas edition)

Ho ho ho!

This repository contains a small, clean Python library named "hello-bro",
authored by bro.

The purpose of this project is to demonstrate how a minimal Python library
can still be structured in a professional, future-proof way.

The core library lives in the "hello" directory and provides a single public
function that prints:

Hello, World!

This project is intentionally simple, readable, and easy to extend.

What this project focuses on:

- Clean Python packaging
- Modern pyproject.toml usage
- Clear separation between library code, tests, docs, and scripts
- ASCII-safe output for maximum compatibility
- Beginner-friendly structure without hiding complexity

This repository may also contain:

- Examples showing how to use the library
- Notes about design decisions or future ideas
- Release artifacts for distribution

This is not a framework.
This is not overengineered.
This is a clean foundation.

Use it as a reference, a template, or a starting point.

License: MIT
