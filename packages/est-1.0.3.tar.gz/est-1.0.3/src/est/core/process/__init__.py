"""est core processing module"""
