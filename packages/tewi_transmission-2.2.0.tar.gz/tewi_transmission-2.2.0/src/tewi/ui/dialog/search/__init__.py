"""Web search dialogs."""
