"""LAIDA CLI - Agent-executable software architecture methodology."""

__version__ = "0.1.0b24"
