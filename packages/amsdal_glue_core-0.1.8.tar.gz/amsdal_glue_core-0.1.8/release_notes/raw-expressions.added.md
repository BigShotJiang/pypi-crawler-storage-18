Raw expressions, conditions improvements
