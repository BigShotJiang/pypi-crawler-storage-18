"""
代码执行模块
提供代码执行功能
"""

import time
import json
import uuid
from typing import Any, Dict, Optional, List
from .base import client
from .session import session

try:
    import websocket
    WEBSOCKET_AVAILABLE = True
except ImportError:
    WEBSOCKET_AVAILABLE = False


def _get_default_kernel() -> str:
    """获取服务器默认内核"""
    try:
        kernelspecs = client.request('/api/kernelspecs')
        return kernelspecs.get('default', 'python3')
    except:
        return 'python3'


class CodeExecutor:
    """代码执行器"""
    
    @staticmethod
    def execute(notebook_path: str, code: str, timeout: int = 60) -> Dict[str, Any]:
        """
        在指定笔记本中执行代码并等待结果
        
        Args:
            notebook_path: 笔记本路径
            code: 要执行的代码
            timeout: 超时时间（秒），默认60秒
            
        Returns:
            执行结果信息
        """
        if not WEBSOCKET_AVAILABLE:
            return CodeExecutor._execute_no_wait(notebook_path, code)
        
        # 获取或创建会话
        sessions = client.request('/api/sessions')
        
        # 查找对应笔记本的会话
        kernel_id = None
        
        for sess in sessions:
            if sess.get('path') == notebook_path:
                kernel_id = sess.get('kernel', {}).get('id')
                break
        
        # 如果没有找到会话，创建一个新的
        if not kernel_id:
            # 获取默认内核
            default_kernel = _get_default_kernel()
            
            session_data = {
                "path": notebook_path,
                "type": "notebook",
                "kernel": {
                    "name": default_kernel
                }
            }
            new_session = client.request('/api/sessions', 'POST', session_data)
            kernel_id = new_session.get('kernel', {}).get('id')
        
        if not kernel_id:
            raise Exception("无法获取或创建内核")
        
        # 构建WebSocket URL
        url = session.get_url()
        token = session.get_token()
        ws_url = url.replace('http://', 'ws://').replace('https://', 'wss://').rstrip('/')
        ws_endpoint = f"{ws_url}/api/kernels/{kernel_id}/channels"
        
        if token:
            ws_endpoint += f"?token={token}"
        
        # 通过WebSocket执行代码并获取结果
        try:
            result = CodeExecutor._execute_via_websocket(ws_endpoint, code, timeout)
            result['kernel_id'] = kernel_id
            result['notebook_path'] = notebook_path
            return result
        except Exception as e:
            return {
                "kernel_id": kernel_id,
                "notebook_path": notebook_path,
                "execution_status": "error",
                "error": str(e),
                "outputs": []
            }
    
    @staticmethod
    def _execute_via_websocket(ws_endpoint: str, code: str, timeout: int) -> Dict[str, Any]:
        """
        通过WebSocket执行代码并获取结果
        
        Args:
            ws_endpoint: WebSocket端点
            code: 要执行的代码
            timeout: 超时时间
            
        Returns:
            执行结果
        """
        ws = websocket.create_connection(ws_endpoint, timeout=timeout)
        
        try:
            # 生成消息ID
            msg_id = str(uuid.uuid4())
            
            # 构建执行请求
            execute_request = {
                "header": {
                    "msg_id": msg_id,
                    "username": "",
                    "session": "",
                    "msg_type": "execute_request",
                    "version": "5.3"
                },
                "parent_header": {},
                "metadata": {},
                "content": {
                    "code": code,
                    "silent": False,
                    "store_history": True,
                    "user_expressions": {},
                    "allow_stdin": False,
                    "stop_on_error": True
                },
                "channel": "shell"
            }
            
            # 发送执行请求
            ws.send(json.dumps(execute_request))
            
            # 收集输出
            outputs = []
            execution_count = None
            status = "ok"
            error_info = None
            
            # 接收消息直到执行完成
            start_time = time.time()
            while True:
                if time.time() - start_time > timeout:
                    status = "timeout"
                    break
                
                try:
                    msg = ws.recv()
                    if not msg:
                        continue
                    
                    msg_data = json.loads(msg)
                    msg_type = msg_data.get('msg_type', '')
                    
                    # 检查是否是我们的消息
                    parent_msg_id = msg_data.get('parent_header', {}).get('msg_id', '')
                    if parent_msg_id != msg_id:
                        continue
                    
                    # 处理不同类型的消息
                    if msg_type == 'execute_input':
                        execution_count = msg_data.get('content', {}).get('execution_count')
                    
                    elif msg_type == 'stream':
                        content = msg_data.get('content', {})
                        outputs.append({
                            'output_type': 'stream',
                            'name': content.get('name', 'stdout'),
                            'text': content.get('text', '')
                        })
                    
                    elif msg_type == 'execute_result':
                        content = msg_data.get('content', {})
                        outputs.append({
                            'output_type': 'execute_result',
                            'execution_count': content.get('execution_count'),
                            'data': content.get('data', {}),
                            'metadata': content.get('metadata', {})
                        })
                    
                    elif msg_type == 'display_data':
                        content = msg_data.get('content', {})
                        outputs.append({
                            'output_type': 'display_data',
                            'data': content.get('data', {}),
                            'metadata': content.get('metadata', {})
                        })
                    
                    elif msg_type == 'error':
                        content = msg_data.get('content', {})
                        error_info = {
                            'ename': content.get('ename', ''),
                            'evalue': content.get('evalue', ''),
                            'traceback': content.get('traceback', [])
                        }
                        outputs.append({
                            'output_type': 'error',
                            **error_info
                        })
                        status = "error"
                    
                    elif msg_type == 'execute_reply':
                        reply_status = msg_data.get('content', {}).get('status', '')
                        if reply_status == 'error':
                            status = "error"
                        # 执行完成，退出循环
                        break
                
                except websocket.WebSocketTimeoutException:
                    continue
                except Exception as e:
                    status = "error"
                    error_info = {"error": str(e)}
                    break
            
            return {
                "execution_status": status,
                "execution_count": execution_count,
                "outputs": outputs,
                "error": error_info
            }
        
        finally:
            ws.close()
    
    @staticmethod
    def _execute_no_wait(notebook_path: str, code: str) -> Dict[str, Any]:
        """
        执行代码但不等待结果（当websocket不可用时）
        
        Args:
            notebook_path: 笔记本路径
            code: 要执行的代码
            
        Returns:
            执行提交信息
        """
        # 获取或创建会话
        sessions = client.request('/api/sessions')
        
        # 查找对应笔记本的会话
        kernel_id = None
        
        for sess in sessions:
            if sess.get('path') == notebook_path:
                kernel_id = sess.get('kernel', {}).get('id')
                break
        
        # 如果没有找到会话，创建一个新的
        if not kernel_id:
            # 获取默认内核
            default_kernel = _get_default_kernel()
            
            session_data = {
                "path": notebook_path,
                "type": "notebook",
                "kernel": {
                    "name": default_kernel
                }
            }
            new_session = client.request('/api/sessions', 'POST', session_data)
            kernel_id = new_session.get('kernel', {}).get('id')
        
        if not kernel_id:
            raise Exception("无法获取或创建内核")
        
        return {
            "kernel_id": kernel_id,
            "code": code,
            "execution_status": "submitted",
            "message": "代码已提交执行（websocket-client未安装，无法获取执行结果）",
            "notebook_path": notebook_path
        }


# 导出单例
code_executor = CodeExecutor()
