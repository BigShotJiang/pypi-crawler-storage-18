"""
终端操作模块
提供终端管理和命令执行功能
"""

import json
import time
import threading
from typing import Any, Dict, Optional, List
from .base import client
from .session import session

try:
    import websocket
    WEBSOCKET_AVAILABLE = True
except ImportError:
    WEBSOCKET_AVAILABLE = False


class TerminalManager:
    """终端管理器"""
    
    def __init__(self):
        """初始化终端管理器"""
        self._terminals = {}  # 存储终端连接 {terminal_name: {"ws": ws, "output": [], "thread": thread}}
        self._lock = threading.Lock()
    
    def list_all(self) -> List[Dict[str, Any]]:
        """
        列出所有终端
        
        Returns:
            终端列表
        """
        terminals = client.request('/api/terminals')
        return terminals
    
    def create(self, cwd: Optional[str] = None) -> Dict[str, Any]:
        """
        创建新终端
        
        Args:
            cwd: 工作目录（可选）
            
        Returns:
            终端信息
        """
        terminal_data = {}
        if cwd:
            terminal_data['cwd'] = cwd
        
        return client.request('/api/terminals', 'POST', terminal_data)
    
    def delete(self, terminal_name: str) -> Dict[str, Any]:
        """
        删除终端
        
        Args:
            terminal_name: 终端名称
            
        Returns:
            删除结果
        """
        # 如果有WebSocket连接，先关闭
        with self._lock:
            if terminal_name in self._terminals:
                terminal_info = self._terminals[terminal_name]
                ws = terminal_info.get('ws')
                if ws:
                    try:
                        ws.close()
                    except:
                        pass
                del self._terminals[terminal_name]
        
        client.request(f'/api/terminals/{terminal_name}', 'DELETE')
        return {"terminal_name": terminal_name, "status": "deleted"}
    
    def get_or_create_terminal(self, terminal_name: Optional[str] = None) -> str:
        """
        获取或创建终端
        
        Args:
            terminal_name: 终端名称（可选，如果不提供则创建新终端）
            
        Returns:
            终端名称
        """
        # 如果指定了终端名称，检查是否存在
        if terminal_name:
            terminals = self.list_all()
            for term in terminals:
                if term.get('name') == terminal_name:
                    return terminal_name
        
        # 创建新终端
        new_terminal = self.create()
        return new_terminal.get('name')
    
    def execute_command(self, command: str, terminal_name: Optional[str] = None, 
                       timeout: int = 60) -> Dict[str, Any]:
        """
        在终端中执行命令并获取输出
        
        Args:
            command: 要执行的命令
            terminal_name: 终端名称（可选，不提供则使用或创建默认终端）
            timeout: 超时时间（秒），默认60秒
            
        Returns:
            执行结果
        """
        if not WEBSOCKET_AVAILABLE:
            return {
                "success": False,
                "error": "websocket-client未安装，无法执行终端命令"
            }
        
        # 获取或创建终端
        terminal_name = self.get_or_create_terminal(terminal_name)
        
        # 构建WebSocket URL
        url = session.get_url()
        token = session.get_token()
        ws_url = url.replace('http://', 'ws://').replace('https://', 'wss://').rstrip('/')
        ws_endpoint = f"{ws_url}/terminals/websocket/{terminal_name}"
        
        if token:
            ws_endpoint += f"?token={token}"
        
        try:
            # 创建WebSocket连接
            ws = websocket.create_connection(ws_endpoint, timeout=timeout)
            
            # 发送命令
            message = json.dumps(["stdin", command + "\n"])
            ws.send(message)
            
            # 收集输出
            output_lines = []
            start_time = time.time()
            
            # 等待一小段时间收集输出
            while time.time() - start_time < min(timeout, 5):  # 最多等待5秒或timeout
                try:
                    ws.settimeout(0.5)
                    msg = ws.recv()
                    if msg:
                        data = json.loads(msg)
                        if isinstance(data, list) and len(data) >= 2:
                            msg_type = data[0]
                            content = data[1]
                            if msg_type == "stdout":
                                output_lines.append(content)
                except websocket.WebSocketTimeoutException:
                    # 如果已经有输出且超过1秒没有新输出，认为命令执行完成
                    if output_lines and time.time() - start_time > 1:
                        break
                    continue
                except Exception:
                    break
            
            ws.close()
            
            # 合并输出
            output = ''.join(output_lines)
            
            return {
                "success": True,
                "terminal_name": terminal_name,
                "command": command,
                "output": output,
                "execution_time": time.time() - start_time
            }
        
        except Exception as e:
            return {
                "success": False,
                "terminal_name": terminal_name,
                "command": command,
                "error": str(e)
            }
    
    def connect_terminal(self, terminal_name: str) -> Dict[str, Any]:
        """
        连接到终端并保持WebSocket连接
        
        Args:
            terminal_name: 终端名称
            
        Returns:
            连接信息
        """
        if not WEBSOCKET_AVAILABLE:
            return {
                "success": False,
                "error": "websocket-client未安装"
            }
        
        # 检查是否已经连接
        with self._lock:
            if terminal_name in self._terminals:
                return {
                    "success": True,
                    "terminal_name": terminal_name,
                    "status": "already_connected"
                }
        
        # 构建WebSocket URL
        url = session.get_url()
        token = session.get_token()
        ws_url = url.replace('http://', 'ws://').replace('https://', 'wss://').rstrip('/')
        ws_endpoint = f"{ws_url}/terminals/websocket/{terminal_name}"
        
        if token:
            ws_endpoint += f"?token={token}"
        
        try:
            # 创建WebSocket连接
            ws = websocket.create_connection(ws_endpoint)
            
            # 创建输出缓冲区
            output_buffer = []
            
            # 创建接收线程
            def receive_output():
                while True:
                    try:
                        msg = ws.recv()
                        if msg:
                            data = json.loads(msg)
                            if isinstance(data, list) and len(data) >= 2:
                                msg_type = data[0]
                                content = data[1]
                                if msg_type == "stdout":
                                    with self._lock:
                                        output_buffer.append(content)
                                        # 只保留最近1000行
                                        if len(output_buffer) > 1000:
                                            output_buffer.pop(0)
                    except:
                        break
            
            thread = threading.Thread(target=receive_output, daemon=True)
            thread.start()
            
            # 保存连接信息
            with self._lock:
                self._terminals[terminal_name] = {
                    "ws": ws,
                    "output": output_buffer,
                    "thread": thread
                }
            
            return {
                "success": True,
                "terminal_name": terminal_name,
                "status": "connected"
            }
        
        except Exception as e:
            return {
                "success": False,
                "terminal_name": terminal_name,
                "error": str(e)
            }
    
    def disconnect_terminal(self, terminal_name: str) -> Dict[str, Any]:
        """
        断开终端连接
        
        Args:
            terminal_name: 终端名称
            
        Returns:
            断开结果
        """
        with self._lock:
            if terminal_name not in self._terminals:
                return {
                    "success": False,
                    "error": "终端未连接"
                }
            
            terminal_info = self._terminals[terminal_name]
            ws = terminal_info.get('ws')
            if ws:
                try:
                    ws.close()
                except:
                    pass
            
            del self._terminals[terminal_name]
        
        return {
            "success": True,
            "terminal_name": terminal_name,
            "status": "disconnected"
        }


# 导出单例
terminal_manager = TerminalManager()
