"""
Jupyter Controller 模块
提供模块化的Jupyter Lab控制接口
"""

from .session import session, SessionManager
from .base import client, BaseClient
from .notebook import notebook_manager, NotebookManager
from .kernel import kernel_manager, KernelManager
from .file import file_manager, FileManager
from .executor import code_executor, CodeExecutor
from .terminal import terminal_manager, TerminalManager

__all__ = [
    # 会话管理
    'session',
    'SessionManager',
    
    # HTTP客户端
    'client',
    'BaseClient',
    
    # 笔记本管理
    'notebook_manager',
    'NotebookManager',
    
    # 内核管理
    'kernel_manager',
    'KernelManager',
    
    # 文件管理
    'file_manager',
    'FileManager',
    
    # 代码执行
    'code_executor',
    'CodeExecutor',
    
    # 终端管理
    'terminal_manager',
    'TerminalManager',
]
