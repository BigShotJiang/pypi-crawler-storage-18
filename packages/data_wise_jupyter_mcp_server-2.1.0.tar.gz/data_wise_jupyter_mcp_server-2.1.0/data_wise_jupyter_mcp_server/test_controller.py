"""
Controller模块测试
测试新的模块化controller
使用方法: python test_controller.py <token>
"""

import sys
import json

# 导入controller模块
from controller import (
    session,
    notebook_manager,
    kernel_manager,
    file_manager,
    code_executor,
    terminal_manager
)


def test_session(url: str, token: str):
    """测试会话管理"""
    print("\n" + "="*60)
    print("测试会话管理")
    print("="*60)
    
    try:
        # 测试连接
        print("\n1. 测试连接...")
        session.connect(url, token)
        print(f"✓ 连接成功: {url}")
        
        # 测试状态
        print("\n2. 测试获取状态...")
        status = session.get_status()
        print(f"✓ 连接状态: {status['connected']}")
        print(f"  URL: {status['url']}")
        print(f"  有Token: {status['has_token']}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        return False


def test_kernel():
    """测试内核管理"""
    print("\n" + "="*60)
    print("测试内核管理")
    print("="*60)
    
    try:
        # 测试列出内核
        print("\n1. 测试列出内核和规格...")
        kernel_info = kernel_manager.list_all()
        print(f"✓ 运行中的内核: {kernel_info['running_count']} 个")
        print(f"  默认内核: {kernel_info['default_kernel']}")
        print(f"  可用内核规格: {list(kernel_info['available_specs'].keys())}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        return False


def test_file():
    """测试文件管理"""
    print("\n" + "="*60)
    print("测试文件管理")
    print("="*60)
    
    try:
        # 测试列出目录
        print("\n1. 测试列出根目录...")
        items = file_manager.list_directory("")
        print(f"✓ 找到 {len(items)} 个项目")
        
        # 显示前5个
        for item in items[:5]:
            print(f"  - {item['name']} ({item['type']})")
        
        # 测试创建目录
        print("\n2. 测试创建目录...")
        test_dir = "test_controller_dir"
        try:
            file_manager.create_directory(test_dir)
            print(f"✓ 目录创建成功: {test_dir}")
        except Exception as e:
            if "already exists" in str(e).lower():
                print(f"✓ 目录已存在: {test_dir}")
            else:
                raise
        
        # 测试写入文件
        print("\n3. 测试写入文件...")
        test_file = f"{test_dir}/test.txt"
        file_manager.write(test_file, "Hello from controller test!")
        print(f"✓ 文件写入成功: {test_file}")
        
        # 测试读取文件
        print("\n4. 测试读取文件...")
        content = file_manager.read(test_file)
        print(f"✓ 文件读取成功")
        print(f"  内容: {content.get('content', '')[:50]}...")
        
        # 测试获取文件信息
        print("\n5. 测试获取文件信息...")
        info = file_manager.get_info(test_file)
        print(f"✓ 文件信息:")
        print(f"  名称: {info['name']}")
        print(f"  大小: {info['size']} 字节")
        print(f"  类型: {info['type']}")
        
        # 测试删除文件
        print("\n6. 测试删除文件...")
        file_manager.delete(test_file)
        print(f"✓ 文件删除成功: {test_file}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_notebook():
    """测试笔记本管理"""
    print("\n" + "="*60)
    print("测试笔记本管理")
    print("="*60)
    
    try:
        # 测试列出笔记本
        print("\n1. 测试列出笔记本...")
        notebooks = notebook_manager.list_all()
        print(f"✓ 找到 {len(notebooks)} 个笔记本")
        
        # 测试创建笔记本（使用默认内核）
        print("\n2. 测试创建笔记本（使用默认内核）...")
        test_nb = "test_controller.ipynb"
        result = notebook_manager.create(test_nb)
        print(f"✓ 笔记本创建成功: {test_nb}")
        if result and result.get('content'):
            kernel = result.get('content', {}).get('metadata', {}).get('kernelspec', {}).get('name', 'unknown')
            print(f"  使用内核: {kernel}")
        else:
            print(f"  笔记本已创建（无返回内容）")
        
        # 测试获取笔记本
        print("\n3. 测试获取笔记本内容...")
        content = notebook_manager.get(test_nb)
        cells_count = len(content.get('content', {}).get('cells', []))
        print(f"✓ 笔记本内容获取成功，包含 {cells_count} 个单元格")
        
        # 测试添加单元格
        print("\n4. 测试添加代码单元格...")
        notebook_manager.add_cell(test_nb, "print('Hello from controller!')", "code")
        print(f"✓ 代码单元格添加成功")
        
        # 测试添加包含转义字符的代码单元格
        print("\n4.5. 测试添加包含转义字符的代码单元格...")
        multiline_code = "# 测试转义字符\nprint('第一行')\nprint('第二行\\t带tab')\nresult = 10 + 20\nprint(f'结果: {result}')"
        notebook_manager.add_cell(test_nb, multiline_code, "code")
        print(f"✓ 包含转义字符的代码单元格添加成功")
        
        # 验证转义字符是否正确保存
        nb_check = notebook_manager.get(test_nb)
        cells_check = nb_check.get('content', {}).get('cells', [])
        if len(cells_check) >= 2:
            last_cell_source = cells_check[-1].get('source', '')
            if isinstance(last_cell_source, list):
                last_cell_source = ''.join(last_cell_source)
            # 检查是否包含真正的换行符
            if '\n' in last_cell_source and 'print' in last_cell_source:
                print(f"✓ 转义字符验证成功：检测到真正的换行符")
                # 显示前50个字符
                print(f"  内容预览: {repr(last_cell_source[:50])}...")
            else:
                print(f"✗ 转义字符验证失败：未检测到换行符")
                print(f"  实际内容: {repr(last_cell_source[:100])}")
        
        # 测试添加markdown单元格
        print("\n5. 测试添加markdown单元格...")
        notebook_manager.add_cell(test_nb, "# Test Notebook", "markdown", position=0)
        print(f"✓ Markdown单元格添加成功")
        
        # 测试更新单元格
        print("\n6. 测试更新单元格...")
        notebook_manager.update_cell(test_nb, 1, "print('Updated code!')")
        print(f"✓ 单元格更新成功")
        
        # 测试获取更新后的内容
        print("\n7. 测试获取更新后的内容...")
        updated = notebook_manager.get(test_nb)
        cells = updated.get('content', {}).get('cells', [])
        print(f"✓ 笔记本现在有 {len(cells)} 个单元格")
        for i, cell in enumerate(cells):
            cell_type = cell.get('cell_type')
            source = ''.join(cell.get('source', []))[:50]
            print(f"  单元格 {i}: [{cell_type}] {source}...")
        
        # 测试删除单元格
        print("\n8. 测试删除单元格...")
        notebook_manager.delete_cell(test_nb, 0)
        print(f"✓ 单元格删除成功")
        
        # 测试执行单元格
        print("\n9. 测试执行单元格...")
        # 先添加一个测试单元格
        test_code = "result = 10 + 20\nprint(f'计算结果: {result}')\nresult"
        notebook_manager.add_cell(test_nb, test_code, "code")
        # 执行这个单元格（现在是第0个）
        from controller import code_executor
        nb = notebook_manager.get(test_nb)
        cells = nb.get('content', {}).get('cells', [])
        if cells:
            code = cells[0].get('source', '')
            if isinstance(code, list):
                code = ''.join(code)
            exec_result = code_executor.execute(test_nb, code)
            print(f"✓ 单元格执行成功")
            print(f"  内核ID: {exec_result.get('kernel_id')}")
            print(f"  状态: {exec_result.get('execution_status')}")
            print(f"  执行计数: {exec_result.get('execution_count')}")
            
            # 显示输出
            outputs = exec_result.get('outputs', [])
            if outputs:
                print(f"  输出数量: {len(outputs)}")
                for i, output in enumerate(outputs[:2]):  # 只显示前2个
                    output_type = output.get('output_type')
                    if output_type == 'stream':
                        text = output.get('text', '')
                        print(f"    [{output_type}] {text.strip()}")
                    elif output_type == 'execute_result':
                        data = output.get('data', {})
                        print(f"    [{output_type}] {data.get('text/plain', '')}")
        
        # 测试删除笔记本
        print("\n10. 测试删除笔记本...")
        notebook_manager.delete(test_nb)
        print(f"✓ 笔记本删除成功: {test_nb}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_executor():
    """测试代码执行"""
    print("\n" + "="*60)
    print("测试代码执行")
    print("="*60)
    
    try:
        # 先创建一个测试笔记本
        print("\n1. 创建测试笔记本...")
        test_nb = "test_executor.ipynb"
        notebook_manager.create(test_nb)
        print(f"✓ 笔记本创建成功: {test_nb}")
        
        # 测试执行简单代码
        print("\n2. 测试执行简单代码...")
        code = """
import datetime
print(f"Hello from executor test!")
print(f"Current time: {datetime.datetime.now()}")
result = 2 + 2
print(f"2 + 2 = {result}")
"""
        result = code_executor.execute(test_nb, code)
        print(f"✓ 代码执行完成")
        print(f"  内核ID: {result.get('kernel_id')}")
        print(f"  状态: {result.get('execution_status')}")
        print(f"  执行计数: {result.get('execution_count')}")
        
        # 显示输出
        outputs = result.get('outputs', [])
        if outputs:
            print(f"  输出数量: {len(outputs)}")
            for i, output in enumerate(outputs):
                output_type = output.get('output_type')
                if output_type == 'stream':
                    text = output.get('text', '')
                    print(f"    输出 {i}: [stream] {text.strip()[:50]}...")
                elif output_type == 'execute_result':
                    data = output.get('data', {})
                    print(f"    输出 {i}: [result] {str(data)[:50]}...")
                elif output_type == 'error':
                    print(f"    输出 {i}: [error] {output.get('ename')}: {output.get('evalue')}")
        
        # 测试执行带错误的代码
        print("\n3. 测试执行带错误的代码...")
        error_code = "print(undefined_variable)"
        error_result = code_executor.execute(test_nb, error_code)
        print(f"✓ 错误代码执行完成")
        print(f"  状态: {error_result.get('execution_status')}")
        if error_result.get('error'):
            error_info = error_result.get('error')
            print(f"  错误类型: {error_info.get('ename')}")
            print(f"  错误信息: {error_info.get('evalue')}")
        
        # 测试执行返回值的代码
        print("\n4. 测试执行返回值的代码...")
        value_code = "x = 100\ny = 200\nx + y"
        value_result = code_executor.execute(test_nb, value_code)
        print(f"✓ 返回值代码执行完成")
        print(f"  状态: {value_result.get('execution_status')}")
        outputs = value_result.get('outputs', [])
        for output in outputs:
            if output.get('output_type') == 'execute_result':
                data = output.get('data', {})
                print(f"  返回值: {data.get('text/plain', '')}")
        
        # 测试执行复杂代码（循环、数据处理、多行输出）
        print("\n5. 测试执行复杂代码...")
        complex_code = """
import time
import random

# 数据处理
data = [random.randint(1, 100) for i in range(10)]
print(f"生成的数据: {data}")

# 统计分析
total = sum(data)
avg = total / len(data)
max_val = max(data)
min_val = min(data)

print(f"总和: {total}")
print(f"平均值: {avg:.2f}")
print(f"最大值: {max_val}")
print(f"最小值: {min_val}")

# 循环处理
result = []
for i, val in enumerate(data):
    if val > 50:
        result.append(f"第{i}个值{val}大于50")

if result:
    print("\\n筛选结果:")
    for r in result:
        print(f"  - {r}")
else:
    print("\\n没有大于50的值")

# 返回结果字典
{"total": total, "avg": avg, "count": len(result)}
"""
        complex_result = code_executor.execute(test_nb, complex_code, timeout=60)
        print(f"✓ 复杂代码执行完成")
        print(f"  状态: {complex_result.get('execution_status')}")
        print(f"  执行计数: {complex_result.get('execution_count')}")
        
        # 显示所有输出
        outputs = complex_result.get('outputs', [])
        if outputs:
            print(f"  输出数量: {len(outputs)}")
            for i, output in enumerate(outputs):
                output_type = output.get('output_type')
                if output_type == 'stream':
                    text = output.get('text', '').strip()
                    lines = text.split('\n')
                    print(f"    输出 {i} [stream]:")
                    for line in lines[:5]:  # 只显示前5行
                        print(f"      {line}")
                    if len(lines) > 5:
                        print(f"      ... (还有{len(lines)-5}行)")
                elif output_type == 'execute_result':
                    data = output.get('data', {})
                    print(f"    输出 {i} [result]: {data.get('text/plain', '')}")
        
        # 清理
        print("\n6. 清理测试笔记本...")
        notebook_manager.delete(test_nb)
        print(f"✓ 笔记本删除成功")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_terminal():
    """测试终端功能"""
    print("\n" + "="*60)
    print("测试终端功能")
    print("="*60)
    
    try:
        # 测试执行简单命令
        print("\n1. 测试执行简单命令...")
        result = terminal_manager.execute_command("echo 'Hello from terminal!'")
        if result.get('success'):
            print(f"✓ 命令执行成功")
            print(f"  终端名称: {result.get('terminal_name')}")
            print(f"  命令: {result.get('command')}")
            print(f"  输出: {result.get('output', '').strip()[:100]}")
        else:
            print(f"✗ 命令执行失败: {result.get('error')}")
            return False
        
        # 测试执行ls命令
        print("\n2. 测试执行ls命令...")
        result = terminal_manager.execute_command("ls -la")
        if result.get('success'):
            print(f"✓ ls命令执行成功")
            output_lines = result.get('output', '').strip().split('\n')
            print(f"  输出行数: {len(output_lines)}")
            print(f"  前3行:")
            for line in output_lines[:3]:
                print(f"    {line[:80]}")
        else:
            print(f"✗ ls命令执行失败: {result.get('error')}")
        
        # 测试执行pwd命令
        print("\n3. 测试执行pwd命令...")
        result = terminal_manager.execute_command("pwd")
        if result.get('success'):
            print(f"✓ pwd命令执行成功")
            print(f"  当前目录: {result.get('output', '').strip()}")
        else:
            print(f"✗ pwd命令执行失败: {result.get('error')}")
        
        # 测试执行Python命令
        print("\n4. 测试执行Python命令...")
        result = terminal_manager.execute_command("python -c \"print('Python version:'); import sys; print(sys.version)\"")
        if result.get('success'):
            print(f"✓ Python命令执行成功")
            output = result.get('output', '').strip()
            print(f"  输出: {output[:100]}...")
        else:
            print(f"✗ Python命令执行失败: {result.get('error')}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主测试函数"""
    if len(sys.argv) < 2:
        print("使用方法: python test_controller.py <token>")
        print("示例: python test_controller.py b0fc5c838e90fe1a9354c19598696e056e660fdc8305f39e")
        sys.exit(1)
    
    token = sys.argv[1]
    url = "http://localhost:8888"
    
    print("="*60)
    print("Controller模块测试")
    print("="*60)
    print(f"服务器: {url}")
    print(f"Token: {token[:20]}...")
    
    tests = [
        ("会话管理", lambda: test_session(url, token)),
        ("内核管理", test_kernel),
        ("文件管理", test_file),
        ("笔记本管理", test_notebook),
        ("代码执行", test_executor),
        ("终端功能", test_terminal),
    ]
    
    passed = 0
    total = len(tests)
    
    for name, test_func in tests:
        try:
            if test_func():
                passed += 1
                print(f"\n✅ {name}测试通过")
            else:
                print(f"\n❌ {name}测试失败")
        except Exception as e:
            print(f"\n❌ {name}测试异常: {str(e)}")
    
    # 断开连接
    print("\n" + "="*60)
    print("清理")
    print("="*60)
    session.disconnect()
    print("✓ 已断开连接")
    
    # 总结
    print("\n" + "="*60)
    print(f"测试结果: {passed}/{total} 通过")
    print("="*60)
    
    if passed == total:
        print("🎉 所有测试通过!")
        print("\n✅ 验证的功能:")
        print("   - 会话管理（连接/断开/状态）")
        print("   - 内核管理（列出运行中内核和可用规格）")
        print("   - 文件管理（目录/文件的增删改查）")
        print("   - 笔记本管理（创建/读取/更新/删除/单元格操作）")
        print("   - 代码执行（提交代码到内核并获取结果）")
        print("   - 终端功能（执行shell命令）")
    else:
        print("⚠️  部分测试失败")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
