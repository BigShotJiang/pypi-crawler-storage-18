# Release Structurer

[![PyPI version](https://badge.fury.io/py/release-structurer.svg)](https://pypi.org/project/release-structurer)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/personalized-badge/release-structurer?period=total&units=international_system&left_color=grey&right_color=orange&left_text=Downloads)](https://pepy.tech/project/release-structurer)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=flat&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/eugene-evstafev/)

A Python package designed to process and structure text inputs related to software development and release notes. The package leverages `llmatch-messages` to ensure that the input text is parsed and formatted consistently.

## Installation

```bash
pip install release-structurer
```

## Usage

### Basic Usage

```python
from release_structurer import release_structurer

user_input = "GDB 17.1 Released with shadow and guard stack support"
response = release_structurer(user_input)
print(response)
```

### Using a Custom LLM

By default, the package uses `ChatLLM7` from `langchain_llm7`. However, you can pass your own LLM instance if you want to use another LLM.

#### Example with OpenAI

```python
from langchain_openai import ChatOpenAI
from release_structurer import release_structurer

llm = ChatOpenAI()
response = release_structurer(user_input, llm=llm)
print(response)
```

#### Example with Anthropic

```python
from langchain_anthropic import ChatAnthropic
from release_structurer import release_structurer

llm = ChatAnthropic()
response = release_structurer(user_input, llm=llm)
print(response)
```

#### Example with Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from release_structurer import release_structurer

llm = ChatGoogleGenerativeAI()
response = release_structurer(user_input, llm=llm)
print(response)
```

### Using a Custom API Key

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits, you can pass your own API key via the `api_key` parameter or set the `LLM7_API_KEY` environment variable.

#### Example with API Key

```python
from release_structurer import release_structurer

user_input = "GDB 17.1 Released with shadow and guard stack support"
response = release_structurer(user_input, api_key="your_api_key")
print(response)
```

You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the package will use the `LLM7_API_KEY` environment variable or default to `None`.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Author

- **Eugene Evstafev** - [chigwell](https://github.com/chigwell) - [hi@eugene.plus](mailto:hi@eugene.plus)

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/release-structurer/issues).