# chad/ui

Beautifully designed components based on the Cotton/HTMX/AlpineJS stack for Django.

---

## What is chad/ui?

chad/ui is a collection of re-usable components that you can copy and paste into your Django apps.

Inspired by [shadcn/ui](https://ui.shadcn.com), chad/ui builds directly on [shadcn-django](https://github.com/shadcn-django)'s excellent foundation and faithful port of shadcn/ui to Django.
It's a slightly different & opinionated flavor with:

- 🧩 **Additional components** - File upload, filter, radio group, spinner, and more
- 🔌 **Third-party integrations** - AG Grid, TradingView widgets, etc.
- 🛠️ **Backend integration** - Seamless data fetch, client-side validation, etc.
- 📱 **Enhanced patterns & design** - Responsive layouts, improved mobile interactions, visual feedback during async requests, etc. 

If you want the core shadcn/ui experience in Django, use shadcn-django. If you would like these additional features and enhancements, use chad/ui.

---

## Why chad/ui?

- **Own your code** - Components live in your project, not hidden in a package
- **Customize everything** - Change the code however you want since you own it
- **Django-native** - Built using standard django template language and django-cotton for progressive enhancement
- **Interactive without JavaScript fatigue** - HTMX for server interactions, Alpine.js for client-side reactivity
- **Adapt to your setup** - Compatible with HTMX/AlpineJS as CDN links or as an npm modules
- **Tailwind for styling** - Utility-first CSS that's easy to customize

---

## Getting Started

### Important: CDN vs npm Approach

How you install dependencies and will use `chad/ui` depends on your setup:

**CDN Approach** - Simple script tags, no build step needed.

**npm Approach** - Requires Node.js. Recommended for complex components because it allows cleaner code organization.

For instance, with AlpineJS via CDN, directives are written directly in HTML:

```html
<div
  x-data="{
    open: false,
    initValue: '{{ value }}',
    value: '{{ value }}',
    displayText: '',
    itemValues: [],
    toggle() {
      this.open = !this.open;
    },
    close() {
      this.open = false;
    },
    ...
    "
>
</div>
```

With `npm`, we utilize `Alpine.data()` to abstract the `x-data` logic and other directives from HTML to JS files and reduce the size of the DOM:

```js
import select from "./chadui/select/select.js"

window.Alpine = Alpine
Alpine.data('select', select)
Alpine.start()
```

```html
<div
  x-data="select"
>
</div>
```

This reduces DOM size, improves reusability, and enables centralized configuration. For example, in our AG Grid component, you can adjust themes in one `theme.js` file instead of editing HTML inline.

**For this reason, we recommend at least considering installing AlpineJS as a module via `npm`.**

---

### 1. Install Dependencies

Skip to `2. I

### 1.1 django-cotton

See the [`django-cotton` installation instructions](https://django-cotton.com/docs/quickstart).

### 1.2 HTMX

**Option A - CDN:**

```html
<script src="https://cdn.jsdelivr.net/npm/htmx.org@2.0.8/dist/htmx.min.js"></script>
```

**Option B - Download:**
Download [htmx.min.js](https://unpkg.com/htmx.org@2.0.8/dist/htmx.min.js) to your static files and reference via script tag.

**Option C - npm:**
```bash
npm install htmx.org@2.0.8
```

Use in your bundle (e.g., `index.js`):
```js
import 'htmx.org';
```

For global `htmx` variable access (recommended):
```js
window.htmx = require('htmx.org');
```

See [HTMX installation docs](https://htmx.org/docs/#installing) for more options.

---

### 1.3 AlpineJS

**Option A - CDN:**
```html
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
```

**Option B - npm:**
```bash
npm install alpinejs
```

Add to your JS bundle:
```js
import Alpine from 'alpinejs'
window.Alpine = Alpine
Alpine.start()
```

See [Alpine.js installation docs](https://alpinejs.dev/essentials/installation) for more details.

---

### 1.4 Tailwind CSS

**Option A - CDN (Development):**
```html
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
```

**Option B - Tailwind CLI (Production):**
```bash
npm install -D tailwindcss
npx tailwindcss init
```

See the [Tailwind CSS installation docs](https://tailwindcss.com/docs/installation) for full setup.

---

### 2. Add Components

Use `pipx` or `uvx` to interact with `chad/ui`.

To view an index of all available components:
```bash
pipx run chad-ui index
```

To add a component:
```bash
pipx run chad-ui add <component>
```

---