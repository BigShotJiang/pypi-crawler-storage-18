import click
import shutil
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from .dependencies import DEPENDENCIES

DIR_PACKAGE = Path(__file__).resolve().parent
DIR_NATIVE = DIR_PACKAGE / "native"
DIR_THIRD_PARTY = DIR_PACKAGE / "third_party"
DIR_DEFAULT_TARGET = "chadcn-ui"

console = Console()

@click.group()
def cli():
    """cotton/htmx/alpineJS Django components in the style of shadcn/ui."""
    pass

@cli.command()
def index():
    """Provide an index of all available components"""
    SRC_NATIVE: Path = DIR_NATIVE / 'templates' / 'cotton'
    SRC_THIRD_PARTY: Path = DIR_THIRD_PARTY / 'templates' / 'cotton'

    components_native = [x.parts[-1] for x in Path.iterdir(SRC_NATIVE) if x.is_dir()]
    components_third_party = [x.parts[-1] for x in Path.iterdir(SRC_THIRD_PARTY) if x.is_dir()]

    components_native.sort()
    components_third_party.sort()

    msg = f"""
Native components:
[green]{'\n'.join(components_native)}[/green]

Third-party integrations:
[green]{'\n'.join(components_third_party)}[/green]
    """ 
    console.print(Panel(msg, title="chadcn components index", expand=False))

@cli.command()
@click.argument('component')
@click.option('--path', default=f'{DIR_DEFAULT_TARGET}', help=f'Target directory (default: {DIR_DEFAULT_TARGET})')
def add(component, path):
    """Install a component into your project."""
    
    dir = _find_dir(component)
    if not dir:
        console.print(f"[red]ERROR: Invalid component '{component}'.[/red]")
        return
    
    installed = set()
    
    def install_with_dependencies(component: str):
        if component in installed:
            return

        dir = _find_dir(component)
        if not dir:
            console.print(f"[yellow]WARNING: Dependency '{component}' not found in source.[/yellow]")
            return
        
        dependencies = DEPENDENCIES.get(component, [])
        for dep in dependencies:
            install_with_dependencies(dep)

        try:
            _copy(dir, path, component)
            installed.add(component)
        except Exception as e:
            console.print(f"[red]ERROR: Failed to install component '{component}'.[/red]")

    install_with_dependencies(component)

def _find_dir(component):
    """Find the source directory for a component."""
    for dir in (DIR_NATIVE, DIR_THIRD_PARTY):
        src_path: Path = dir / 'templates' / 'cotton' / component
        if src_path.exists():
            return dir
    return None

def _copy(src_dir: Path, path: str, component: str):
    SRC_TEMPLATES: Path = src_dir / 'templates' / 'cotton' / component
    SRC_STATIC: Path = src_dir / 'static' / 'js' / component
    
    DST_TEMPLATES = Path(path) / 'templates' / 'cotton' / component
    DST_STATIC = Path(path) / 'static' / 'js' / component

    files_copied = 0

    # copy templates
    DST_TEMPLATES.mkdir(parents=True, exist_ok=True)
    for html_file in SRC_TEMPLATES.glob('*.html'):
        dst_path = DST_TEMPLATES / html_file.name
        if dst_path.exists():
            console.print(f"[dim]x Skipped '{dst_path}' (already exists)[/dim]")
        else:
            shutil.copy(html_file, DST_TEMPLATES / html_file.name)
            console.print(f"[green]✓ Added '{DST_TEMPLATES / html_file.name}'")
            files_copied += 1

    # copy static
    if SRC_STATIC.exists():
        DST_STATIC.mkdir(parents=True, exist_ok=True)
        for js_file in SRC_STATIC.glob('*.js'):
            dst_path = DST_STATIC / js_file.name
            if dst_path.exists():
                console.print(f"[dim]x Skipped '{dst_path}' (already exists)[/dim]")
            else:
                shutil.copy(js_file, DST_STATIC / js_file.name)
                console.print(f"[green]✓ Added '{DST_STATIC / js_file.name}'")
                files_copied += 1

    if files_copied > 0:
        console.print(f"[bold green]Component '{component}' successfully installed.[/bold green]")