DEPENDENCIES = {
    'button': ['spinner'],
}
