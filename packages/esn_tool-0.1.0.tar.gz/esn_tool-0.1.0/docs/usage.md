# ESN Tool 使用指南

ESN Tool 是一个用于管理多个 Git 项目的 CLI 工具，支持批量 Git 操作和 AI 自动生成提交信息。

## 目录

- [安装](#安装)
- [配置](#配置)
- [命令](#命令)
  - [esntool acm - 自动提交](#esntool-acm---自动提交)
  - [esntool git - 批量 Git 操作](#esntool-git---批量-git-操作)
  - [esntool config - 配置管理](#esntool-config---配置管理)

---

## 安装

### 前提条件

- Python 3.12 或更高版本
- [uv](https://docs.astral.sh/uv/) 包管理器

#### 安装 uv

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

### 安装 esn-tool

```bash
uv tool install esn-tool
```

### 验证安装

```bash
esntool --version
esntool --help
```

### 升级

```bash
uv tool upgrade esn-tool
```

### 卸载

```bash
uv tool uninstall esn-tool
```

---

## 配置

首次使用前，需要配置 AI 接口。运行以下命令进入交互式配置：

```bash
esntool config
```

在配置界面中：
- 使用 **↑↓** 选择配置项
- 按 **Enter** 编辑选中项
- 选择 **保存并退出** 完成配置

### 配置项说明

| 配置项 | 说明 | 示例 |
|--------|------|------|
| API Key | AI 接口的 API Key | `sk-xxxxxxxxxxxx` |
| Base URL | API 地址 | `https://api.siliconflow.cn/v1` |
| Model | 使用的模型 | `Qwen/Qwen2.5-32B-Instruct` |

### 配置文件位置

配置保存在 `~/.esntool/config.json`

---

## 命令

### esntool acm - 自动提交

**ACM (Auto Commit Message)** 命令用于自动生成 Git 提交信息并提交。

#### 工作流程

1. 扫描指定目录下的所有一级 Git 仓库
2. 检测每个仓库的待提交文件
3. 显示交互式文件选择器，选择要提交的文件
4. 调用 AI 生成符合 Conventional Commits 规范的提交信息
5. 确认后执行 `git add` 和 `git commit`

#### 基本用法

```bash
# 在当前目录下扫描所有 Git 项目
esntool acm

# 指定目录
esntool acm -d /path/to/projects

# 自动暂存所有更改
esntool acm -a

# 跳过文件选择，使用所有更改
esntool acm -y

# 指定 AI 模型
esntool acm -m Qwen/Qwen2.5-72B-Instruct
```

#### 选项

| 选项 | 说明 |
|------|------|
| `-d, --directory` | 指定要搜索的目录，默认为当前目录 |
| `-m, --model` | 指定 AI 模型 |
| `-a, --auto-stage` | 自动暂存所有更改后再生成提交信息 |
| `-y, --yes` | 跳过确认直接提交 |

#### 交互式文件选择器

在文件选择界面中：

| 快捷键 | 功能 |
|--------|------|
| `空格` | 选择/取消选择当前文件 |
| `a` | 全选 |
| `n` | 全不选 |
| `c` | 确认选择，进入下一步 |
| `q` | 取消操作 |
| `Tab` | 在文件列表和 Diff 预览之间切换焦点 |
| `←` / `→` | 切换焦点 |
| `j` / `k` | 在 Diff 预览区滚动 |

#### 生成的提交信息格式

遵循 [Conventional Commits](https://www.conventionalcommits.org/) 规范：

```
<type>(<scope>): <subject>

<body>
```

类型包括：
- `feat`: 新功能
- `fix`: 修复 Bug
- `docs`: 文档更新
- `style`: 代码格式调整
- `refactor`: 重构
- `perf`: 性能优化
- `test`: 测试相关
- `chore`: 构建或辅助工具变动

---

### esntool git - 批量 Git 操作

对当前目录下的所有 Git 项目批量执行 Git 命令。

#### 工作流程

1. 扫描指定目录下的所有一级子文件夹
2. 筛选出包含 `.git` 目录的 Git 仓库
3. 对每个仓库执行相同的 Git 命令
4. 汇总显示执行结果

#### 基本用法

```bash
# 拉取所有项目的最新代码
esntool git pull

# 查看所有项目的状态
esntool git status

# 切换所有项目到 main 分支
esntool git checkout main

# 创建新分支（所有项目）
esntool git checkout -b feature/new-branch

# 获取所有远程更新
esntool git fetch --all

# 指定目录
esntool git -d /path/to/projects pull

# 显示详细输出
esntool git -v status
```

#### 选项

| 选项 | 说明 |
|------|------|
| `-d, --directory` | 指定要搜索的目录，默认为当前目录 |
| `-v, --verbose` | 显示详细输出 |

#### 输出示例

```
📂 在 /path/to/projects 下找到 5 个 Git 项目
执行命令: git pull

┏━━━━━━━━━━━━━━┳━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ 项目          ┃ 状态   ┃ 信息                   ┃
┡━━━━━━━━━━━━━━╇━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━┩
│ project-1    │ ✓     │ Already up to date.    │
│ project-2    │ ✓     │ Fast-forward           │
│ project-3    │ ✗     │ error: cannot pull...  │
└──────────────┴───────┴────────────────────────┘

完成: 2 成功, 1 失败
```

---

### esntool config - 配置管理

管理 ESN Tool 的配置，包括 AI 接口设置等。

```bash
esntool config
```

进入交互式配置界面，可以设置：
- API Key
- Base URL  
- Model

配置保存在 `~/.esntool/config.json`

---

## 常见问题

### API 请求失败

确保已正确配置 API Key 和 Base URL：

```bash
esntool config show
```

如果报错，会显示详细的错误信息，包括 HTTP 状态码和 API 返回的错误消息。

### 命令未找到

确保已正确安装：

```bash
uv tool list
```

如果 `esn-tool` 不在列表中，执行：

```bash
uv tool install esn-tool
```

### 更新到最新版本

```bash
uv tool upgrade esn-tool
```

---

## 依赖

| 包 | 用途 |
|----|------|
| `click` | 命令行框架 |
| `rich` | 终端美化输出 |
| `httpx` | HTTP 客户端 |
| `questionary` | 交互式提示 |
| `textual` | TUI 界面框架 |

---

## 开发

### 安装开发依赖

```bash
uv sync
```

### 运行测试

```bash
uv run pytest
```

### 代码格式化

```bash
uv run ruff format src/
uv run ruff check src/ --fix
```
