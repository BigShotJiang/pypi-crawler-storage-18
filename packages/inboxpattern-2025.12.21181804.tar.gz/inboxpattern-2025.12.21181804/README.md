# inboxpattern
[![PyPI version](https://badge.fury.io/py/inboxpattern.svg)](https://badge.fury.io/py/inboxpattern)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/inboxpattern)](https://pepy.tech/project/inboxpattern)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


**inboxpattern** is a lightweight Python package that helps users and organizations analyze and categorize email account usage patterns.  
Give it a brief text describing your email habits – it will return a structured reply that outlines:
- How many email accounts you use
- The purpose of each account
- Any challenges you face managing them

The output is a list of strings that can be fed straight into a workflow, shared in dashboards, or used for tooling that reduces inbox clutter.

> **Author:** Eugene Evstafev (`hi@euegne.plus`)  
> **GitHub owner:** `chigwell`

## Quick Start

```bash
pip install inboxpattern
```

### Basic usage

```python
from inboxpattern import inboxpattern

user_input = (
    "I maintain three email addresses: a personal Gmail, a work Outlook account, "
    "and a project-specific ProtonMail. I often forget which account to use for "
    "which purpose, and I sometimes receive spam in my personal address."
)

response = inboxpattern(user_input)
print(response)
# Example output: [
#   "Accounts: 3",
#   "Personal: Gmail",
#   "Work: Outlook",
#   "Project: ProtonMail",
#   "Challenges: Misattributed emails, spam in personal inbox"
# ]
```

## Using a different LLM

`inboxpattern` ships with **ChatLLM7** from the `langchain_llm7` package by default.  
If you already have a LangChain LLM provider (OpenAI, Anthropic, Google, etc.), you can pass it in:

### OpenAI
```python
from langchain_openai import ChatOpenAI
from inboxpattern import inboxpattern

llm = ChatOpenAI()      # your own OpenAI key already configured
response = inboxpattern(user_input, llm=llm)
```

### Anthropic
```python
from langchain_anthropic import ChatAnthropic
from inboxpattern import inboxpattern

llm = ChatAnthropic()
response = inboxpattern(user_input, llm=llm)
```

### Google Gemini
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from inboxpattern import inboxpattern

llm = ChatGoogleGenerativeAI()
response = inboxpattern(user_input, llm=llm)
```

## Optional API key

The free tier of LLM7 comes with generous limits that are usually enough for most use‑cases.  
If you need higher throughput, obtain a key at <https://token.llm7.io/> and provide it:

```bash
export LLM7_API_KEY="your_llm7_token"    # or
inboxpattern(user_input, api_key="your_llm7_token")
```

## Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | Text describing your email‑management habits. |
| `llm` | `Optional[BaseChatModel]` | A LangChain LLM instance to use; defaults to `ChatLLM7`. |
| `api_key` | `Optional[str]` | LLM7 API key; if omitted, the library will look for the `LLM7_API_KEY` environment variable or default to `"None"`. |

## Development & Issues

If you encounter bugs or want to request a feature, please open an issue in the repository:

<https://github.com/chigwell/inboxpattern/issues>

Happy coding, and may your inboxes stay tidy!