"""
Tests for sub-area analyzer module (v1.3.0).
"""

import pytest
from pathlib import Path
import tempfile
from contextdigger.subarea_analyzer import (
    SubAreaAnalyzer,
    VerbosityRenderer,
    FileInfo,
    SubAreaSuggestion,
    SplitAnalysis
)
from contextdigger.budget import BudgetTracker


@pytest.fixture
def temp_project():
    """Create a temporary project with test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # Create test file structure
        # Python files
        (project_root / "src").mkdir()
        (project_root / "src" / "models").mkdir()
        (project_root / "src" / "controllers").mkdir()
        (project_root / "src" / "views").mkdir()

        # Create model files
        for name in ["account", "opportunity", "lead"]:
            model_file = project_root / "src" / "models" / f"{name}_model.py"
            model_file.write_text(f'''"""
{name.title()} model for CRM system.
"""

class {name.title()}Model:
    """Represents a {name}."""
    pass
''')

        # Create controller files
        for name in ["account", "opportunity"]:
            controller_file = project_root / "src" / "controllers" / f"{name}_controller.py"
            controller_file.write_text(f'''"""
{name.title()} controller.
"""

from models.{name}_model import {name.title()}Model

class {name.title()}Controller:
    """Handles {name} operations."""
    pass
''')

        # Create test files
        (project_root / "tests").mkdir()
        for name in ["account", "opportunity"]:
            test_file = project_root / "tests" / f"test_{name}.py"
            test_file.write_text(f'''"""
Tests for {name}.
"""

import pytest
from src.models.{name}_model import {name.title()}Model

def test_{name}_creation():
    """Test {name} creation."""
    model = {name.title()}Model()
    assert model is not None
''')

        yield project_root


class TestFileIntelligence:
    """Test file intelligence extraction."""

    def test_detect_python_language(self, temp_project):
        """Test Python language detection."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        model_file = temp_project / "src" / "models" / "account_model.py"
        file_info = analyzer._extract_file_intelligence(model_file)

        assert file_info.language == "python"
        assert file_info.lines > 0

    def test_extract_purpose_from_docstring(self, temp_project):
        """Test purpose extraction from docstrings."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        model_file = temp_project / "src" / "models" / "account_model.py"
        file_info = analyzer._extract_file_intelligence(model_file)

        assert file_info.purpose is not None
        assert "Account model" in file_info.purpose

    def test_detect_file_role_model(self, temp_project):
        """Test model role detection."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        model_file = temp_project / "src" / "models" / "account_model.py"
        file_info = analyzer._extract_file_intelligence(model_file)

        assert file_info.role == "model"

    def test_detect_file_role_test(self, temp_project):
        """Test test role detection."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        test_file = temp_project / "tests" / "test_account.py"
        file_info = analyzer._extract_file_intelligence(test_file)

        assert file_info.role == "test"
        assert file_info.test_file is True

    def test_detect_file_role_controller(self, temp_project):
        """Test controller role detection."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        controller_file = temp_project / "src" / "controllers" / "account_controller.py"
        file_info = analyzer._extract_file_intelligence(controller_file)

        assert file_info.role == "controller"

    def test_extract_imports(self, temp_project):
        """Test import extraction."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        controller_file = temp_project / "src" / "controllers" / "account_controller.py"
        file_info = analyzer._extract_file_intelligence(controller_file)

        assert len(file_info.imports) > 0
        assert any("account_model" in imp for imp in file_info.imports)

    def test_extract_naming_components(self, temp_project):
        """Test naming component extraction."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        model_file = temp_project / "src" / "models" / "account_model.py"
        file_info = analyzer._extract_file_intelligence(model_file)

        assert "account" in file_info.naming_components or "model" in file_info.naming_components


class TestSubAreaSuggestions:
    """Test sub-area suggestion strategies."""

    def test_suggest_by_directory(self, temp_project):
        """Test directory-based grouping."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        # Get all Python files
        all_files = list(temp_project.rglob("*.py"))
        file_infos = [analyzer._get_file_info(f) for f in all_files]

        suggestions = analyzer.suggest_by_directory(file_infos, "test-area")

        assert len(suggestions) > 0
        # Should have suggestions for different directories
        dir_names = [s.metadata.get("directory_path") for s in suggestions]
        assert any("models" in str(d) for d in dir_names)

    def test_suggest_by_naming_patterns(self, temp_project):
        """Test naming pattern clustering."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        all_files = list(temp_project.rglob("*.py"))
        file_infos = [analyzer._get_file_info(f) for f in all_files]

        suggestions = analyzer.suggest_by_naming_patterns(file_infos, "test-area")

        # Should find "account" or "opportunity" as common components
        assert len(suggestions) > 0

    def test_suggest_by_role(self, temp_project):
        """Test role-based grouping."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        all_files = list(temp_project.rglob("*.py"))
        file_infos = [analyzer._get_file_info(f) for f in all_files]

        suggestions = analyzer.suggest_by_role(file_infos, "test-area")

        # Should have suggestions for models, controllers, tests
        assert len(suggestions) > 0
        roles = [s.metadata.get("file_role") for s in suggestions]
        assert "model" in roles or "test" in roles or "controller" in roles

    def test_suggest_by_imports(self, temp_project):
        """Test import-based clustering."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        all_files = list(temp_project.rglob("*.py"))
        file_infos = [analyzer._get_file_info(f) for f in all_files]

        suggestions = analyzer.suggest_by_imports(file_infos, "test-area")

        # May or may not have import-based suggestions depending on imports
        assert isinstance(suggestions, list)


class TestSplitAnalysis:
    """Test complete split analysis."""

    def test_analyze_area(self, temp_project):
        """Test complete area analysis."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        all_files = list(temp_project.rglob("*.py"))

        analysis = analyzer.analyze_area(all_files, "test-area", max_depth=2)

        assert isinstance(analysis, SplitAnalysis)
        assert analysis.original_area == "test-area"
        assert analysis.original_file_count == len(all_files)
        assert len(analysis.suggestions) > 0
        assert 0.0 <= analysis.coverage <= 1.0
        assert 0.0 <= analysis.avg_confidence <= 1.0

    def test_build_hierarchy(self, temp_project):
        """Test hierarchical tree building."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        all_files = list(temp_project.rglob("*.py"))

        analysis = analyzer.analyze_area(all_files, "test-area", max_depth=2)

        assert analysis.tree is not None
        assert analysis.tree.name == "test-area"
        assert analysis.tree.depth == 0
        # Should have children
        assert len(analysis.tree.children) > 0

    def test_deduplication(self, temp_project):
        """Test suggestion deduplication."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        # Create duplicate suggestions manually
        file1 = temp_project / "src" / "models" / "account_model.py"
        file2 = temp_project / "src" / "models" / "opportunity_model.py"

        suggestion1 = SubAreaSuggestion(
            name="test1",
            description="Test 1",
            patterns={},
            files=[file1, file2],
            file_count=2,
            line_count=100,
            strategy="test",
            confidence=0.8
        )

        suggestion2 = SubAreaSuggestion(
            name="test2",
            description="Test 2",
            patterns={},
            files=[file1, file2],  # Same files - 100% overlap
            file_count=2,
            line_count=100,
            strategy="test",
            confidence=0.7
        )

        suggestions = [suggestion1, suggestion2]
        deduplicated = analyzer._deduplicate_suggestions(suggestions)

        # Should remove the duplicate (80%+ overlap)
        assert len(deduplicated) == 1


class TestVerbosityRenderer:
    """Test verbosity rendering."""

    def test_render_compact(self, temp_project):
        """Test compact rendering."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())
        all_files = list(temp_project.rglob("*.py"))

        analysis = analyzer.analyze_area(all_files, "test-area")

        renderer = VerbosityRenderer(BudgetTracker())
        output = renderer.render_compact(analysis)

        assert "Sub-Area Analysis" in output
        assert "test-area" in output
        assert "Budget Limit" in output

    def test_render_horizontal_verbose(self, temp_project):
        """Test horizontal verbose rendering."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())
        all_files = list(temp_project.rglob("*.py"))

        analysis = analyzer.analyze_area(all_files, "test-area")

        budget_tracker = BudgetTracker()
        budget_tracker.project_root = temp_project  # Set for rendering
        renderer = VerbosityRenderer(budget_tracker)
        output = renderer.render_horizontal_verbose(analysis)

        assert "DETAILED Sub-Area Analysis" in output
        assert "Patterns:" in output
        assert "Sample Files" in output

    def test_render_vertical_verbose(self, temp_project):
        """Test vertical tree rendering."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())
        all_files = list(temp_project.rglob("*.py"))

        analysis = analyzer.analyze_area(all_files, "test-area", max_depth=2)

        renderer = VerbosityRenderer(BudgetTracker())
        output = renderer.render_vertical_verbose(analysis)

        assert "HIERARCHICAL Tree View" in output
        assert "test-area" in output
        # Should have tree characters
        assert "├─" in output or "└─" in output or "✓" in output or "⚠️" in output


class TestBudgetValidation:
    """Test budget validation in suggestions."""

    def test_suggestions_within_budget(self, temp_project):
        """Test that suggestions respect budget limits."""
        # Create small budget
        budget_tracker = BudgetTracker(max_files=3, max_lines=500)
        analyzer = SubAreaAnalyzer(temp_project, budget_tracker)

        all_files = list(temp_project.rglob("*.py"))
        analysis = analyzer.analyze_area(all_files, "test-area")

        # All suggestions should be within budget (or at least attempted)
        for suggestion in analysis.suggestions:
            # Suggestions are filtered to be within budget during creation
            assert suggestion.file_count <= budget_tracker.max_files or suggestion.file_count > 0


class TestCaching:
    """Test file info caching."""

    def test_file_info_cached(self, temp_project):
        """Test that file info is cached."""
        analyzer = SubAreaAnalyzer(temp_project, BudgetTracker())

        file_path = temp_project / "src" / "models" / "account_model.py"

        # First call
        info1 = analyzer._get_file_info(file_path)

        # Second call should use cache
        info2 = analyzer._get_file_info(file_path)

        # Should be the same object (from cache)
        assert info1 is info2
        assert len(analyzer._file_info_cache) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
