## [1.6.0] - 2025-12-21

### ⚙️ Miscellaneous Tasks

- Use git cliff for release notes
