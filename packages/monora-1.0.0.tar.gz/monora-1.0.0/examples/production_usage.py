import logging

import monora


monora.init(config_path="monora.yml", fail_fast=True)


def alert_security(violation: monora.PolicyViolation) -> None:
    logging.error("Policy violation: %s - %s", violation.model, violation.message)


monora.set_violation_handler(alert_security)


@monora.llm_call(
    data_classification="secret",
    purpose="pii_redaction",
    reason="Redact SSNs from support tickets",
)
def redact_pii(text: str, model: str = "claude-3-opus-20240229"):
    return {"redacted": text, "model": model}


@monora.tool_call(
    tool_name="database_query",
    purpose="analytics",
    reason="Fetch user churn metrics",
)
def query_db(sql: str):
    return {"rows": 10, "query": sql}


with monora.trace("batch_job_456", metadata={"job_id": "456"}):
    clean = redact_pii("My SSN is 123-45-6789")
    stats = query_db("SELECT * FROM churn")
    print(clean, stats)
