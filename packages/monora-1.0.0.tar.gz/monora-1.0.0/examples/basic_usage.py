"""Basic usage example for Monora SDK."""
import monora

# Initialize with stdout logging (dev mode)
monora.init()


@monora.llm_call(purpose="customer_support")
def ask_gpt(prompt: str, model: str = "gpt-4o-mini"):
    """Simulate an LLM API call."""
    print(f"Calling {model} with prompt: {prompt}")
    # In real usage, call your LLM API here
    return {
        "choices": [
            {
                "message": {"content": "To reset your password, click the 'Forgot Password' link."},
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": 15,
            "completion_tokens": 25,
            "total_tokens": 40
        }
    }


@monora.tool_call(tool_name="database_query", purpose="analytics")
def query_db(sql: str):
    """Simulate a database query."""
    print(f"Executing SQL: {sql}")
    return {"rows": 42}


def main():
    # Use trace context to group related events
    with monora.trace("support_ticket_123", metadata={"user_id": "user_456"}):
        # Make LLM call
        response = ask_gpt("How do I reset my password?")
        print(f"Response: {response}")

        # Make tool call
        stats = query_db("SELECT COUNT(*) FROM tickets")
        print(f"Stats: {stats}")

        # Log custom event
        monora.log_event(
            "custom_metric",
            {"metric": "response_time", "value_ms": 123},
            purpose="monitoring"
        )


if __name__ == "__main__":
    main()
