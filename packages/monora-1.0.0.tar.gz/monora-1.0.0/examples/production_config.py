"""Production configuration example with policies and file logging."""
import monora
import tempfile
from pathlib import Path

# Create temp directory for demo
tmpdir = Path(tempfile.mkdtemp())
log_path = tmpdir / "events.jsonl"

# Initialize with production config
monora.init(
    config_dict={
        "defaults": {
            "data_classification": "internal",
            "environment": "production",
        },
        "sinks": [
            {
                "type": "file",
                "path": str(log_path),
                "batch_size": 50,
                "flush_interval_sec": 2.0,
            }
        ],
        "policies": {
            "enforce": True,
            "model_allowlist": ["gpt-4*", "claude-3-*"],
            "model_denylist": ["*alpha*", "*beta*"],
            "classification_max_models": {
                "secret": {
                    "allowed": ["claude-3-opus-20240229"]
                }
            }
        },
        "immutability": {
            "enabled": True,
            "scope": "per_trace",
        },
        "error_handling": {
            "sink_failure_mode": "warn",
            "fallback_path": str(tmpdir / "fallback.jsonl"),
        }
    }
)


# Set up violation handler
def alert_security(violation: monora.PolicyViolation):
    print(f"🚨 SECURITY ALERT: {violation.policy_name}")
    print(f"   Model: {violation.model}")
    print(f"   Message: {violation.message}")


monora.set_violation_handler(alert_security)


@monora.llm_call(
    data_classification="secret",
    purpose="pii_redaction",
    reason="Redact sensitive information from user data"
)
def redact_pii(text: str, model: str = "claude-3-opus-20240229"):
    """Redact PII - only allowed for secret data with specific models."""
    print(f"Redacting PII with {model}")
    return {"redacted_text": "[REDACTED]"}


@monora.llm_call(purpose="general_qa")
def ask_question(query: str, model: str = "gpt-4"):
    """General Q&A - allowed with gpt-4*."""
    print(f"Answering with {model}: {query}")
    return {"answer": "42"}


def main():
    # This will work - approved model for secret data
    with monora.trace("job_001"):
        result = redact_pii("SSN: 123-45-6789")
        print(f"Redaction result: {result}")

    # This will work - gpt-4 is in allowlist
    with monora.trace("job_002"):
        result = ask_question("What is the answer?", model="gpt-4")
        print(f"Answer: {result}")

    # This will be blocked - gpt-4 not allowed for secret data
    try:
        with monora.trace("job_003"):
            result = redact_pii("SSN: 123-45-6789", model="gpt-4")
    except monora.PolicyViolation as e:
        print(f"\n❌ Blocked: {e}")

    # This will be blocked - deepseek not in allowlist
    try:
        with monora.trace("job_004"):
            @monora.llm_call(purpose="test")
            def test_blocked(model: str = "deepseek-v3"):
                return {}
            test_blocked()
    except monora.PolicyViolation as e:
        print(f"\n❌ Blocked: {e}")

    # Shutdown and flush
    from monora.runtime import shutdown
    import time
    time.sleep(0.5)
    shutdown()

    print(f"\n✅ Events logged to: {log_path}")
    print(f"Total events: {sum(1 for _ in open(log_path))}")


if __name__ == "__main__":
    main()
