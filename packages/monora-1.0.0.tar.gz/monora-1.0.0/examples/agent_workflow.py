"""Example of using Monora with an agent workflow."""
import monora

monora.init()


@monora.agent_step(agent_name="planner", step_type="planning", purpose="research")
def plan_research(goal: str):
    """Plan research steps."""
    print(f"Planning for goal: {goal}")
    return {
        "steps": [
            "Search for recent papers",
            "Analyze findings",
            "Summarize results"
        ]
    }


@monora.tool_call(tool_name="web_search", purpose="research")
def search_web(query: str):
    """Search the web."""
    print(f"Searching for: {query}")
    return {"results": ["result1", "result2", "result3"]}


@monora.llm_call(purpose="research")
def analyze_results(data: dict, model: str = "gpt-4"):
    """Analyze search results."""
    print(f"Analyzing {len(data['results'])} results with {model}")
    return {"analysis": "Key findings..."}


@monora.agent_step(agent_name="planner", step_type="reflection", purpose="research")
def reflect_on_findings(analysis: dict):
    """Reflect on analysis."""
    print("Reflecting on findings...")
    return {"reflection": "We found that...", "confidence": 0.85}


def main():
    # Execute agent workflow within a trace
    with monora.trace("research_task_789", metadata={"task": "AI regulations"}):
        # Step 1: Plan
        plan = plan_research("Research latest AI regulations")

        # Step 2: Execute research
        for step in plan["steps"]:
            if "Search" in step:
                results = search_web("AI regulations 2025")
            elif "Analyze" in step:
                analysis = analyze_results(results)
            elif "Summarize" in step:
                reflection = reflect_on_findings(analysis)

        print(f"\nFinal reflection: {reflection}")


if __name__ == "__main__":
    main()
