import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest

from monora.cli.security_report import (
    generate_security_report,
    _build_report_metadata,
    _build_config_snapshot,
    _verify_chain_integrity,
    _build_compliance_summary,
    _assess_risks,
    _build_operational_metrics,
    _build_attestation,
)


@pytest.fixture
def sample_events():
    """Sample events for testing."""
    return [
        {
            "event_id": "evt_1",
            "event_type": "llm_call",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "trace_id": "trace_1",
            "data_classification": "internal",
            "body": {
                "model": "gpt-4o-mini",
                "provider": "openai",
                "status": "success",
                "response": {
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 50,
                        "total_tokens": 150,
                    }
                },
            },
            "prev_hash": None,
            "event_hash": "sha256:abc123",
        },
        {
            "event_id": "evt_2",
            "event_type": "llm_call",
            "timestamp": "2025-01-02T00:00:00.000Z",
            "trace_id": "trace_1",
            "data_classification": "internal",
            "body": {
                "model": "claude-3-opus-20240229",
                "provider": "anthropic",
                "status": "success",
                "response": {
                    "usage": {
                        "prompt_tokens": 200,
                        "completion_tokens": 100,
                        "total_tokens": 300,
                    }
                },
            },
            "prev_hash": "sha256:abc123",
            "event_hash": "sha256:def456",
        },
        {
            "event_id": "evt_3",
            "event_type": "llm_call",
            "timestamp": "2025-01-03T00:00:00.000Z",
            "trace_id": "trace_2",
            "data_classification": "secret",
            "body": {
                "model": "deepseek:v3",
                "provider": "deepseek",
                "status": "policy_violation",
                "policy_name": "model_denylist",
                "message": "Model matches denylist pattern",
            },
            "prev_hash": "sha256:def456",
            "event_hash": "sha256:ghi789",
        },
    ]


@pytest.fixture
def sample_config():
    """Sample configuration for testing."""
    return {
        "policies": {
            "model_allowlist": ["gpt-4*", "claude-3-*"],
            "model_denylist": ["deepseek:*"],
            "enforce": True,
        },
        "registry": {
            "version": "1.0.0",
            "history": [],
            "default_provider": "unknown",
            "allow_unknown": True,
            "providers": [
                {
                    "name": "openai",
                    "model_patterns": ["gpt-*", "o1-*"],
                    "version_range": ">=1.0.0,<2.0.0",
                    "deprecated": False,
                },
                {
                    "name": "anthropic",
                    "model_patterns": ["claude-*"],
                    "version_range": ">=1.0.0,<2.0.0",
                    "deprecated": False,
                },
                {
                    "name": "deepseek",
                    "model_patterns": ["deepseek:*", "deepseek*"],
                    "version_range": ">=0.9.0,<1.0.0",
                    "deprecated": True,
                    "deprecation_message": "DeepSeek v0.x models are deprecated",
                },
            ],
        },
        "immutability": {
            "enabled": True,
            "scope": "per_trace",
            "hash_algorithm": "sha256",
        },
        "defaults": {
            "data_classification": "internal",
            "purpose": "general",
            "service_name": "test-app",
            "environment": "production",
        },
    }


def test_generate_security_report_basic(sample_events, sample_config):
    """Test basic security report generation."""
    report = generate_security_report(sample_events, config_dict=sample_config)

    assert report["report_metadata"]["report_type"] == "security_review"
    assert report["report_metadata"]["format_version"] == "1.0.0"
    assert "report_id" in report["report_metadata"]
    assert "configuration_snapshot" in report
    assert "chain_integrity" in report
    assert "compliance_summary" in report
    assert "risk_assessment" in report
    assert "operational_metrics" in report
    assert "attestation" in report


def test_report_metadata(sample_events):
    """Test report metadata generation."""
    metadata = _build_report_metadata(sample_events)

    assert metadata["report_type"] == "security_review"
    assert metadata["format_version"] == "1.0.0"
    assert metadata["event_source"]["total_events"] == 3
    assert metadata["event_source"]["hash_verified"] is True
    assert metadata["report_period"]["duration_days"] == 2


def test_config_snapshot(sample_config):
    """Test configuration snapshot with hash."""
    snapshot = _build_config_snapshot(sample_config)

    assert snapshot["config_hash"].startswith("sha256:")
    assert len(snapshot["config_hash"].split(":")[1]) == 64  # SHA-256 hex length
    assert snapshot["policies"] == sample_config["policies"]
    assert snapshot["immutability"] == sample_config["immutability"]
    assert snapshot["defaults"] == sample_config["defaults"]
    assert snapshot["registry"] == sample_config["registry"]


def test_config_snapshot_deterministic(sample_config):
    """Test config snapshot hash is deterministic."""
    snapshot1 = _build_config_snapshot(sample_config)
    snapshot2 = _build_config_snapshot(sample_config)

    assert snapshot1["config_hash"] == snapshot2["config_hash"]


def test_chain_integrity_verification(sample_events):
    """Test chain integrity verification."""
    integrity = _verify_chain_integrity(sample_events)

    assert "verification_status" in integrity
    assert integrity["verification_algorithm"] == "sha256"
    assert integrity["total_events_verified"] == 3
    assert integrity["traces_verified"] == 2
    assert "tampering_detected" in integrity


def test_compliance_summary(sample_events, sample_config):
    """Test compliance summary generation."""
    compliance = _build_compliance_summary(sample_events, sample_config)

    assert "policy_violations" in compliance
    assert "model_compliance" in compliance
    assert "classification_compliance" in compliance

    violations = compliance["policy_violations"]
    assert violations["total_violations"] == 1
    assert "deepseek:v3" in violations["unique_models_blocked"]


def test_compliance_violation_rate(sample_events, sample_config):
    """Test violation rate calculation."""
    compliance = _build_compliance_summary(sample_events, sample_config)

    violations_per_day = compliance["policy_violations"]["violations_per_day"]
    assert violations_per_day == 0.5  # 1 violation over 2 days


def test_classification_compliance(sample_events, sample_config):
    """Test classification compliance breakdown."""
    compliance = _build_compliance_summary(sample_events, sample_config)

    class_compliance = compliance["classification_compliance"]
    assert "internal" in class_compliance
    assert "secret" in class_compliance

    assert class_compliance["internal"]["total_events"] == 2
    assert class_compliance["internal"]["violations"] == 0

    assert class_compliance["secret"]["total_events"] == 1
    assert class_compliance["secret"]["violations"] == 1


def test_risk_assessment(sample_events, sample_config):
    """Test risk assessment scoring."""
    assessment = _assess_risks(sample_events, sample_config)

    assert "overall_risk_level" in assessment
    assert assessment["overall_risk_level"] in ["low", "medium", "high"]
    assert "risk_factors" in assessment
    assert len(assessment["risk_factors"]) == 4  # violations, unknown_models, chain_integrity, completeness
    assert "total_risk_score" in assessment


def test_risk_factors_structure(sample_events, sample_config):
    """Test risk factors have correct structure."""
    assessment = _assess_risks(sample_events, sample_config)

    for factor in assessment["risk_factors"]:
        assert "factor" in factor
        assert "severity" in factor
        assert "score" in factor
        assert "details" in factor
        assert factor["severity"] in ["none", "low", "medium", "high", "critical"]


def test_operational_metrics(sample_events, sample_config):
    """Test operational metrics aggregation."""
    metrics = _build_operational_metrics(sample_events, sample_config)

    assert metrics["total_traces"] == 2
    assert metrics["total_llm_calls"] == 3
    assert "by_provider" in metrics
    assert "by_model" in metrics
    assert "token_usage" in metrics
    assert "errors" in metrics


def test_operational_metrics_provider_aggregation(sample_events, sample_config):
    """Test provider aggregation in operational metrics."""
    metrics = _build_operational_metrics(sample_events, sample_config)

    # Check provider counts
    by_provider = metrics["by_provider"]
    assert by_provider.get("openai", 0) == 1
    assert by_provider.get("anthropic", 0) == 1
    assert by_provider.get("deepseek", 0) == 1


def test_attestation_structure():
    """Test attestation section structure."""
    attestation = _build_attestation()

    assert attestation["attestation_type"] == "hash_verification"
    assert attestation["attester"] == "monora-cli"
    assert attestation["verified_by"] is None
    assert attestation["approval_status"] == "pending_review"
    assert isinstance(attestation["notes"], list)


def test_full_report_with_violations(sample_config):
    """Test full report with policy violations."""
    events = [
        {
            "event_id": "evt_1",
            "event_type": "llm_call",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "trace_id": "trace_1",
            "data_classification": "internal",
            "body": {
                "model": "forbidden-model",
                "status": "policy_violation",
                "policy_name": "model_denylist",
                "message": "Model not allowed",
            },
            "prev_hash": None,
            "event_hash": "sha256:abc123",
        }
    ]

    report = generate_security_report(events, config_dict=sample_config)

    assert report["compliance_summary"]["policy_violations"]["total_violations"] == 1
    assert report["risk_assessment"]["overall_risk_level"] in ["low", "medium", "high"]


def test_full_report_no_config():
    """Test report generation with no config."""
    events = [
        {
            "event_id": "evt_1",
            "event_type": "llm_call",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "body": {"model": "gpt-4o-mini", "status": "success"},
            "event_hash": "sha256:abc123",
        }
    ]

    report = generate_security_report(events)

    assert report["report_metadata"]["event_source"]["total_events"] == 1
    assert report["configuration_snapshot"]["policies"] == {}


def test_empty_events_list():
    """Test report generation with empty events list."""
    report = generate_security_report([])

    assert report["report_metadata"]["event_source"]["total_events"] == 0
    assert report["operational_metrics"]["total_llm_calls"] == 0


def test_report_id_unique():
    """Test that report IDs are unique."""
    events = [
        {
            "event_id": "evt_1",
            "event_type": "llm_call",
            "timestamp": "2025-01-01T00:00:00.000Z",
            "event_hash": "sha256:abc123",
        }
    ]

    report1 = generate_security_report(events)
    report2 = generate_security_report(events)

    # Report IDs should be different (timestamp-based)
    # They might be the same if generated in the same second, but structure should be valid
    assert "sreport_" in report1["report_metadata"]["report_id"]
    assert "sreport_" in report2["report_metadata"]["report_id"]


def test_integration_with_cli(sample_events, sample_config):
    """Test integration with CLI command."""
    # Create temp files
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".jsonl", delete=False
    ) as events_file:
        for event in sample_events:
            events_file.write(json.dumps(event) + "\n")
        events_path = events_file.name

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as config_file:
        json.dump(sample_config, config_file)
        config_path = config_file.name

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as output_file:
        output_path = output_file.name

    try:
        # Import and test the CLI command
        from monora.cli.report import _load_jsonl
        from monora.cli.security_report import generate_security_report

        # Load events
        loaded_events = _load_jsonl(events_path)
        assert len(loaded_events) == 3

        # Generate report
        report = generate_security_report(loaded_events, config_path=config_path)

        # Write report
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)

        # Verify report was written
        with open(output_path, "r") as f:
            saved_report = json.load(f)

        assert saved_report["report_metadata"]["report_type"] == "security_review"
        assert saved_report["compliance_summary"]["policy_violations"]["total_violations"] == 1

    finally:
        Path(events_path).unlink()
        Path(config_path).unlink()
        Path(output_path).unlink()
