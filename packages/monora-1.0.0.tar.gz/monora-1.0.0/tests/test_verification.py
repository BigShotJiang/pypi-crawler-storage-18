"""Tests for hash chain verification utilities."""
import json

import pytest

from monora.verify import (
    ChainVerificationError,
    detect_tampering,
    verify_chain,
    verify_event_hash,
    verify_trace_chain,
)


def test_verify_valid_event_hash():
    """Test verification of a valid event hash."""
    import hashlib

    event = {
        "event_id": "evt_123",
        "event_type": "llm_call",
        "timestamp": "2025-12-21T10:00:00Z",
        "body": {"model": "gpt-4"},
    }

    # Compute hash
    canonical = json.dumps(event, sort_keys=True, separators=(",", ":"))
    hasher = hashlib.sha256()
    hasher.update(canonical.encode("utf-8"))
    event_hash = f"sha256:{hasher.hexdigest()}"

    event["event_hash"] = event_hash
    event["prev_hash"] = None

    assert verify_event_hash(event) is True


def test_verify_invalid_event_hash():
    """Test detection of tampered event hash."""
    event = {
        "event_id": "evt_123",
        "event_type": "llm_call",
        "timestamp": "2025-12-21T10:00:00Z",
        "body": {"model": "gpt-4"},
        "event_hash": "sha256:invalid_hash",
        "prev_hash": None,
    }

    assert verify_event_hash(event) is False


def test_verify_valid_chain():
    """Test verification of a valid hash chain."""
    import hashlib

    events = []

    # Create first event
    event1 = {"event_id": "evt_1", "data": "first"}
    canonical1 = json.dumps(event1, sort_keys=True, separators=(",", ":"))
    hash1 = hashlib.sha256(canonical1.encode()).hexdigest()
    event1["event_hash"] = f"sha256:{hash1}"
    event1["prev_hash"] = None
    events.append(event1)

    # Create second event chained to first
    event2 = {"event_id": "evt_2", "data": "second"}
    canonical2 = json.dumps(event2, sort_keys=True, separators=(",", ":"))
    hasher2 = hashlib.sha256()
    hasher2.update(event1["event_hash"].encode())
    hasher2.update(canonical2.encode())
    hash2 = hasher2.hexdigest()
    event2["event_hash"] = f"sha256:{hash2}"
    event2["prev_hash"] = event1["event_hash"]
    events.append(event2)

    is_valid, error = verify_chain(events)
    assert is_valid is True
    assert error is None


def test_verify_chain_with_break():
    """Test detection of broken chain."""
    import hashlib

    # Create valid events first
    event1 = {"event_id": "evt_1", "data": "first"}
    canonical1 = json.dumps(event1, sort_keys=True, separators=(",", ":"))
    hash1 = hashlib.sha256(canonical1.encode()).hexdigest()
    event1["event_hash"] = f"sha256:{hash1}"
    event1["prev_hash"] = None

    event2 = {"event_id": "evt_2", "data": "second"}
    canonical2 = json.dumps(event2, sort_keys=True, separators=(",", ":"))
    hasher2 = hashlib.sha256()
    hasher2.update(event1["event_hash"].encode())  # Use correct prev_hash
    hasher2.update(canonical2.encode())
    hash2 = hasher2.hexdigest()
    event2["event_hash"] = f"sha256:{hash2}"
    event2["prev_hash"] = "sha256:wrong_hash"  # But set WRONG prev_hash

    events = [event1, event2]

    is_valid, error = verify_chain(events)
    assert is_valid is False
    assert "Chain break" in error


def test_verify_first_event_with_prev_hash():
    """Test that first event with prev_hash is invalid."""
    events = [
        {
            "event_id": "evt_1",
            "event_hash": "sha256:hash1",
            "prev_hash": "sha256:should_be_none",
        }
    ]

    is_valid, error = verify_chain(events)
    assert is_valid is False
    assert "First event" in error and "prev_hash" in error


def test_verify_trace_chain():
    """Test verification of trace-specific chain."""
    import hashlib

    # Create events for two different traces
    events = []

    # Trace 1
    event1 = {
        "event_id": "evt_1",
        "trace_id": "trace_1",
        "timestamp": "2025-12-21T10:00:00Z",
        "data": "a",
    }
    canonical1 = json.dumps(event1, sort_keys=True, separators=(",", ":"))
    hash1 = hashlib.sha256(canonical1.encode()).hexdigest()
    event1["event_hash"] = f"sha256:{hash1}"
    event1["prev_hash"] = None
    events.append(event1)

    # Trace 2
    event2 = {
        "event_id": "evt_2",
        "trace_id": "trace_2",
        "timestamp": "2025-12-21T10:01:00Z",
        "data": "b",
    }
    canonical2 = json.dumps(event2, sort_keys=True, separators=(",", ":"))
    hash2 = hashlib.sha256(canonical2.encode()).hexdigest()
    event2["event_hash"] = f"sha256:{hash2}"
    event2["prev_hash"] = None
    events.append(event2)

    # Verify each trace independently
    is_valid1, error1 = verify_trace_chain(events, "trace_1")
    is_valid2, error2 = verify_trace_chain(events, "trace_2")

    assert is_valid1 is True
    assert is_valid2 is True


def test_detect_tampering():
    """Test detection of tampered events."""
    events = [
        {
            "event_id": "evt_1",
            "event_hash": "sha256:valid_looking_but_wrong",
            "prev_hash": None,
            "timestamp": "2025-12-21T10:00:00Z",
        },
        {
            "event_id": "evt_2",
            "event_hash": "sha256:hash2",
            "prev_hash": "sha256:wrong_link",
            "timestamp": "2025-12-21T10:01:00Z",
        },
    ]

    tampered = detect_tampering(events)

    # Should detect both invalid hash and chain break
    assert len(tampered) >= 1
    assert any(t["event_id"] == "evt_1" for t in tampered)


def test_verify_empty_chain():
    """Test that empty chain is valid."""
    is_valid, error = verify_chain([])
    assert is_valid is True
    assert error is None
