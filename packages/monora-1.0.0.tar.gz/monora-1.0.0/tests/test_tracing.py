from monora.context import get_current_span, pop_span, start_span, trace


def test_trace_context_stack():
    with trace("root") as root:
        assert get_current_span().span_id == root.span_id
        child = start_span("child")
        assert child.parent_span_id == root.span_id
        pop_span()
        assert get_current_span().span_id == root.span_id


def test_pop_span_clears_context():
    start_span("root")
    pop_span()
    assert get_current_span() is None
