from monora.cli.report import _build_report


def test_report_unused_allowlist_patterns_and_unknown_models():
    events = [
        {
            "event_type": "llm_call",
            "trace_id": "trc_1",
            "timestamp": "2025-01-01T00:00:00Z",
            "body": {"model": "gpt-4o-mini", "response": {"usage": {}}},
        },
        {
            "event_type": "llm_call",
            "trace_id": "trc_2",
            "timestamp": "2025-01-01T00:00:01Z",
            "body": {"model": "claude-3-opus-20240229", "response": {"usage": {}}},
        },
        {
            "event_type": "llm_call",
            "trace_id": "trc_3",
            "timestamp": "2025-01-01T00:00:02Z",
            "body": {"model": "unknown-model", "response": {"usage": {}}},
        },
    ]

    policies = {
        "model_allowlist": ["gpt-4*", "claude-3-*", "gpt-3.5*"],
        "model_denylist": ["deepseek:*"]
    }

    report = _build_report(events, policies=policies)
    compliance = report["model_compliance"]

    assert sorted(compliance["allowed_models_used"]) == [
        "claude-3-opus-20240229",
        "gpt-4o-mini",
    ]
    assert compliance["unused_allowlist_patterns"] == ["gpt-3.5*"]
    assert compliance["unknown_models_used"] == ["unknown-model"]
