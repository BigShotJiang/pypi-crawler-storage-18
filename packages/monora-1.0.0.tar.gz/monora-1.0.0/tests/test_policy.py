import pytest

from monora.policy import PolicyEngine, PolicyViolation


def test_denylist_blocks_exact_match():
    engine = PolicyEngine({"model_denylist": ["deepseek:v3"], "enforce": True})
    with pytest.raises(PolicyViolation) as exc_info:
        engine.check_model("deepseek:v3", "internal")
    assert exc_info.value.model == "deepseek:v3"
    assert "denylist" in exc_info.value.policy_name


def test_allowlist_permits_glob():
    engine = PolicyEngine({"model_allowlist": ["gpt-4*"], "enforce": True})
    engine.check_model("gpt-4o-mini", "internal")


def test_classification_restrictions():
    engine = PolicyEngine(
        {
            "classification_max_models": {
                "secret": {"allowed": ["claude-3-opus*"]}
            },
            "enforce": True,
        }
    )
    with pytest.raises(PolicyViolation):
        engine.check_model("gpt-4o-mini", "secret")


# Tests for get_allowed_patterns()
def test_get_allowed_patterns_returns_list():
    engine = PolicyEngine({"model_allowlist": ["gpt-4*", "claude-3-*"]})
    patterns = engine.get_allowed_patterns()
    assert patterns == ["gpt-4*", "claude-3-*"]


def test_get_allowed_patterns_empty_config():
    engine = PolicyEngine({})
    patterns = engine.get_allowed_patterns()
    assert patterns == []


def test_get_allowed_patterns_preserves_order():
    engine = PolicyEngine({"model_allowlist": ["z-model", "a-model", "m-model"]})
    patterns = engine.get_allowed_patterns()
    assert patterns == ["z-model", "a-model", "m-model"]


# Tests for get_denied_patterns()
def test_get_denied_patterns_returns_list():
    engine = PolicyEngine({"model_denylist": ["deepseek:*", "*alpha*"]})
    patterns = engine.get_denied_patterns()
    assert patterns == ["deepseek:*", "*alpha*"]


def test_get_denied_patterns_empty_config():
    engine = PolicyEngine({})
    patterns = engine.get_denied_patterns()
    assert patterns == []


def test_get_denied_patterns_with_exact_strings():
    engine = PolicyEngine({"model_denylist": ["exact-match", "another-exact"]})
    patterns = engine.get_denied_patterns()
    assert patterns == ["exact-match", "another-exact"]


# Tests for is_model_allowed()
def test_is_model_allowed_returns_true_for_allowed():
    engine = PolicyEngine({"model_allowlist": ["gpt-4*"], "enforce": True})
    assert engine.is_model_allowed("gpt-4o-mini", "internal") is True


def test_is_model_allowed_returns_false_for_denied():
    engine = PolicyEngine({"model_denylist": ["deepseek:*"], "enforce": True})
    assert engine.is_model_allowed("deepseek:v3", "internal") is False


def test_is_model_allowed_handles_none_model():
    engine = PolicyEngine({"model_denylist": ["*"]})
    assert engine.is_model_allowed(None, "internal") is True


def test_is_model_allowed_respects_classification():
    engine = PolicyEngine({
        "classification_max_models": {
            "secret": {"allowed": ["claude-3-opus*"]}
        },
        "enforce": True
    })
    assert engine.is_model_allowed("claude-3-opus-20240229", "secret") is True
    assert engine.is_model_allowed("gpt-4o-mini", "secret") is False


# Tests for get_classification_rules()
def test_get_classification_rules_returns_dict():
    engine = PolicyEngine({
        "classification_max_models": {
            "secret": {"allowed": ["claude-3-opus*"]},
            "confidential": {"denied": ["*-mini"]}
        }
    })
    rules = engine.get_classification_rules()
    assert rules == {
        "secret": {"allowed": ["claude-3-opus*"], "denied": []},
        "confidential": {"allowed": [], "denied": ["*-mini"]}
    }


def test_get_classification_rules_empty_config():
    engine = PolicyEngine({})
    rules = engine.get_classification_rules()
    assert rules == {}


# Tests for get_matching_patterns()
def test_get_matching_patterns_finds_matches():
    engine = PolicyEngine({
        "model_allowlist": ["gpt-4*", "claude-*"],
        "model_denylist": ["*alpha*"]
    })
    matches = engine.get_matching_patterns("gpt-4-alpha")
    assert "gpt-4*" in matches["allowed"]
    assert "*alpha*" in matches["denied"]


def test_get_matching_patterns_handles_no_matches():
    engine = PolicyEngine({"model_allowlist": ["gpt-4*"]})
    matches = engine.get_matching_patterns("claude-3-opus")
    assert matches == {"allowed": [], "denied": []}


# Test for is_enforcement_enabled()
def test_is_enforcement_enabled_returns_bool():
    engine1 = PolicyEngine({"enforce": True})
    assert engine1.is_enforcement_enabled() is True

    engine2 = PolicyEngine({"enforce": False})
    assert engine2.is_enforcement_enabled() is False

    engine3 = PolicyEngine({})  # Default is True
    assert engine3.is_enforcement_enabled() is True
