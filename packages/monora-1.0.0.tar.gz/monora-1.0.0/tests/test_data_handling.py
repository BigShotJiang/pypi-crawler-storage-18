import json
import tempfile
from pathlib import Path

import pytest

import monora
from monora import llm_call, trace
from monora.data_handling import DataHandlingViolation


EMAIL_RULE = {
    "name": "email",
    "pattern": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    "replace": "[REDACTED_EMAIL]",
    "classifications": ["confidential", "secret"],
    "apply_to": ["request", "response"],
}


def _read_events(path: Path):
    events = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                events.append(json.loads(line))
    return events


def test_redaction_applied_to_llm_call_request_and_response():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"
        monora.init(
            config_dict={
                "sinks": [
                    {
                        "type": "file",
                        "path": str(log_path),
                        "batch_size": 1,
                        "flush_interval_sec": 0.0,
                    }
                ],
                "data_handling": {
                    "enabled": True,
                    "mode": "redact",
                    "rules": [EMAIL_RULE],
                },
            }
        )

        @llm_call(purpose="testing", data_classification="confidential")
        def mock_llm(prompt: str, model: str = "gpt-4"):
            return {
                "choices": [
                    {
                        "message": {"content": "Email me at foo@bar.com"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {},
            }

        with trace("test_trace"):
            mock_llm("Contact me at foo@bar.com")

        monora.shutdown()

        events = _read_events(log_path)
        assert len(events) == 1
        body = events[0]["body"]
        assert "[REDACTED_EMAIL]" in body["request"]["prompt"]
        assert "[REDACTED_EMAIL]" in body["response"]["content"]
        assert body["redaction"]["applied"] is True
        assert "email" in body["redaction"]["rules"]


def test_blocking_on_sensitive_data():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"
        monora.init(
            config_dict={
                "sinks": [
                    {
                        "type": "file",
                        "path": str(log_path),
                        "batch_size": 1,
                        "flush_interval_sec": 0.0,
                    }
                ],
                "data_handling": {
                    "enabled": True,
                    "mode": "block",
                    "rules": [EMAIL_RULE],
                },
            }
        )

        called = {"flag": False}

        @llm_call(purpose="testing", data_classification="secret")
        def mock_llm(prompt: str, model: str = "gpt-4"):
            called["flag"] = True
            return {"choices": [], "usage": {}}

        with trace("block_trace"):
            with pytest.raises(DataHandlingViolation):
                mock_llm("Email me at foo@bar.com")

        monora.shutdown()

        assert called["flag"] is False

        events = _read_events(log_path)
        assert len(events) == 1
        body = events[0]["body"]
        assert body["status"] == "policy_violation"
        assert body["data_handling"]["action"] == "block"
        assert "email" in body["data_handling"]["rules"]
