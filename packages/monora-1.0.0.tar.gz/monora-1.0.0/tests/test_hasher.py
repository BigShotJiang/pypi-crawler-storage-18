from monora.hasher import Hasher


def test_hash_determinism():
    event = {"event_id": "123", "timestamp": "2025-12-21T10:00:00Z", "body": {"a": 1}}
    hasher = Hasher({"enabled": True, "scope": "per_trace"})

    _, hash1 = hasher.hash_event(event)
    _, hash2 = hasher.hash_event(event)
    assert hash1 == hash2


def test_hash_chain_integrity():
    hasher = Hasher({"enabled": True, "scope": "global"})
    events = [{"event_id": str(i)} for i in range(5)]

    hashes = []
    for event in events:
        prev, curr = hasher.hash_event(event)
        hashes.append((prev, curr))

    assert hashes[0][0] is None
    assert hashes[1][0] == hashes[0][1]
    assert hashes[2][0] == hashes[1][1]
