import json
import tempfile
from pathlib import Path

import monora
from monora import llm_call, trace
from monora.registry import ModelRegistry


def test_registry_resolves_provider():
    registry = ModelRegistry(
        {
            "version": "2025.1",
            "history": [{"version": "2025.1", "date": "2025-01-01", "changes": ["init"]}],
            "default_provider": "default",
            "allow_unknown": True,
            "providers": [
                {
                    "name": "openai",
                    "model_patterns": ["gpt-*"],
                    "version_range": ">=1.0.0,<2.0.0",
                    "deprecated": True,
                    "deprecation_message": "Deprecated provider",
                },
                {"name": "anthropic", "model_patterns": ["claude-*"]},
            ],
        }
    )

    assert registry.version == "2025.1"
    assert registry.history[0].version == "2025.1"
    provider, matched = registry.resolve("gpt-4o-mini")
    assert provider == "openai"
    assert matched is True

    provider, matched = registry.resolve("unknown-model")
    assert provider == "default"
    assert matched is False


def test_unknown_model_logs_policy_violation():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"
        monora.init(
            config_dict={
                "sinks": [
                    {
                        "type": "file",
                        "path": str(log_path),
                        "batch_size": 1,
                        "flush_interval_sec": 0.0,
                    }
                ],
                "registry": {
                    "default_provider": "openai",
                    "allow_unknown": False,
                    "providers": [
                        {"name": "openai", "model_patterns": ["gpt-*"]}
                    ],
                },
            }
        )

        called = {"flag": False}

        @llm_call(purpose="testing")
        def mock_llm(prompt: str, model: str = "weird-model"):
            called["flag"] = True
            return {"choices": [{"message": {"content": "ok"}}], "usage": {}}

        with trace("registry_trace"):
            mock_llm("hello")

        monora.shutdown()

        assert called["flag"] is True

        events = [
            json.loads(line)
            for line in log_path.read_text().splitlines()
            if line.strip()
        ]
        assert len(events) == 2

        violation = [e for e in events if e["body"].get("status") == "policy_violation"]
        assert violation
        assert violation[0]["body"]["policy_name"] == "model_registry.unknown_model"

        success = [e for e in events if e["body"].get("status") == "success"]
        assert success
        assert success[0]["body"]["provider"] == "openai"


def test_registry_metadata_attached_to_event():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"
        monora.init(
            config_dict={
                "sinks": [
                    {
                        "type": "file",
                        "path": str(log_path),
                        "batch_size": 1,
                        "flush_interval_sec": 0.0,
                    }
                ],
                "registry": {
                    "version": "2025.2",
                    "history": [],
                    "default_provider": "unknown",
                    "allow_unknown": True,
                    "providers": [
                        {
                            "name": "openai",
                            "model_patterns": ["gpt-*"],
                            "version_range": ">=1.0.0,<2.0.0",
                            "deprecated": True,
                            "deprecation_message": "OpenAI v1 registry deprecated",
                        }
                    ],
                },
            }
        )

        @llm_call(purpose="testing")
        def mock_llm(prompt: str, model: str = "gpt-4o-mini"):
            return {"choices": [{"message": {"content": "ok"}}], "usage": {}}

        with trace("registry_meta_trace"):
            mock_llm("hello")

        monora.shutdown()

        events = [
            json.loads(line)
            for line in log_path.read_text().splitlines()
            if line.strip()
        ]
        assert events
        body = events[0]["body"]
        metadata = body.get("provider_metadata")
        assert metadata
        assert metadata["registry_version"] == "2025.2"
        assert metadata["version_range"] == ">=1.0.0,<2.0.0"
        assert metadata["deprecated"] is True
        assert metadata["deprecation_message"] == "OpenAI v1 registry deprecated"
