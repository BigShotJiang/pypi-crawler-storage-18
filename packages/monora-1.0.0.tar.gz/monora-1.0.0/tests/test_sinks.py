import json
import tempfile

import requests

from monora.sinks.file import FileSink
from monora.sinks.https import HttpSink


def test_http_sink_retries_on_failure(mocker):
    response = mocker.Mock()
    response.raise_for_status.return_value = None
    mock_post = mocker.patch(
        "monora.sinks.https.requests.post",
        side_effect=[requests.Timeout(), requests.Timeout(), response],
    )

    sink = HttpSink("http://test", {}, batch_size=1, retry_attempts=3)
    sink.emit([{"event_id": "1"}])
    sink.flush()

    assert mock_post.call_count == 3


def test_file_sink_batching():
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        path = tmp.name

    sink = FileSink(path, batch_size=2, flush_interval_sec=0.0)
    sink.emit([{"a": 1}])

    with open(path, "r", encoding="utf-8") as handle:
        assert len(handle.readlines()) == 0

    sink.emit([{"b": 2}])

    with open(path, "r", encoding="utf-8") as handle:
        lines = handle.readlines()
        assert len(lines) == 2
        assert json.loads(lines[0]) == {"a": 1}
        assert json.loads(lines[1]) == {"b": 2}

    sink.close()


def test_file_sink_concurrent_writes():
    """Test file sink handles concurrent writes safely."""
    import threading

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        path = tmp.name

    sink = FileSink(path, batch_size=100, flush_interval_sec=0.0)

    def write_events(start_id: int, count: int):
        events = [{"id": i} for i in range(start_id, start_id + count)]
        sink.emit(events)

    # Spawn multiple threads writing concurrently
    threads = []
    for i in range(5):
        t = threading.Thread(target=write_events, args=(i * 10, 10))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    sink.flush()
    sink.close()

    # Verify all events were written
    with open(path, "r", encoding="utf-8") as handle:
        lines = handle.readlines()
        assert len(lines) == 50  # 5 threads × 10 events


def test_http_sink_permanent_failure(mocker):
    """Test HTTP sink handles permanent failures gracefully."""
    mock_post = mocker.patch(
        "monora.sinks.https.requests.post",
        side_effect=requests.ConnectionError("Service unavailable"),
    )

    from monora.sinks.base import SinkError
    import pytest

    sink = HttpSink("http://test", {}, batch_size=1, retry_attempts=3)

    with pytest.raises(SinkError):
        sink.emit([{"event_id": "1"}])
        sink.flush()

    assert mock_post.call_count == 3


def test_file_sink_flush_on_interval():
    """Test file sink flushes after time interval."""
    import time

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        path = tmp.name

    # Set very short flush interval
    sink = FileSink(path, batch_size=100, flush_interval_sec=0.1)
    sink.emit([{"test": 1}])

    # Wait for flush interval
    time.sleep(0.3)

    with open(path, "r", encoding="utf-8") as handle:
        lines = handle.readlines()
        assert len(lines) == 1

    sink.close()


def test_http_sink_exponential_backoff(mocker):
    """Test HTTP sink uses exponential backoff between retries."""
    import time

    call_times = []

    def mock_post_with_timing(*_args, **_kwargs):
        call_times.append(time.time())
        raise requests.Timeout()

    mocker.patch("monora.sinks.https.requests.post", side_effect=mock_post_with_timing)
    mock_sleep = mocker.patch("monora.sinks.https.time.sleep")

    from monora.sinks.base import SinkError
    import pytest

    sink = HttpSink("http://test", {}, batch_size=1, retry_attempts=3, backoff_base_sec=1.0)

    with pytest.raises(SinkError):
        sink.emit([{"event_id": "1"}])
        sink.flush()

    # Verify backoff was called with increasing delays
    assert mock_sleep.call_count == 2  # 2 retries after first attempt
    sleep_calls = [call[0][0] for call in mock_sleep.call_args_list]

    # First backoff: base * 2^0 + jitter = ~1.0-1.1
    assert 1.0 <= sleep_calls[0] <= 1.2

    # Second backoff: base * 2^1 + jitter = ~2.0-2.1 (exponential)
    assert 2.0 <= sleep_calls[1] <= 2.2
