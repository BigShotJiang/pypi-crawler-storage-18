"""Error recovery and resilience tests."""
import tempfile
from pathlib import Path

import monora


def test_sink_failure_with_fallback():
    """Test that fallback sink works when primary fails."""
    with tempfile.TemporaryDirectory() as tmpdir:
        primary_path = Path(tmpdir) / "nonexistent" / "events.jsonl"
        fallback_path = Path(tmpdir) / "fallback.jsonl"

        # Primary will fail (directory doesn't exist), fallback should work
        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(primary_path)}],
                "error_handling": {
                    "sink_failure_mode": "warn",
                    "fallback_path": str(fallback_path),
                },
            },
            fail_fast=False,  # Don't fail on sink init error
        )

        @monora.llm_call(purpose="test")
        def test_call(model: str = "gpt-4"):
            return {"response": "ok"}

        with monora.trace("test"):
            test_call()

        from monora.runtime import shutdown
        import time

        time.sleep(0.5)
        shutdown()

        # Fallback file should have events
        assert fallback_path.exists()
        with open(fallback_path) as f:
            lines = f.readlines()
            assert len(lines) > 0


def test_queue_overflow_handling():
    """Test queue overflow with warn mode."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "buffering": {"queue_size": 10},  # Very small queue
                "error_handling": {"queue_full_mode": "warn"},
            }
        )

        @monora.llm_call(purpose="overflow_test")
        def rapid_call(i: int, model: str = "gpt-4"):
            return {"id": i}

        # Try to overflow queue
        with monora.trace("overflow"):
            for i in range(100):
                rapid_call(i)

        from monora.runtime import shutdown
        import time

        time.sleep(1.0)
        shutdown()

        # Some events should still be logged (queue processed events)
        assert log_path.exists()


def test_policy_violation_does_not_break_trace():
    """Test that policy violations don't break the trace context."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "policies": {"enforce": True, "model_denylist": ["forbidden-*"]},
            }
        )

        @monora.llm_call(purpose="test")
        def allowed_call(model: str = "gpt-4"):
            return {"response": "ok"}

        @monora.llm_call(purpose="test")
        def forbidden_call(model: str = "forbidden-model"):
            return {"response": "blocked"}

        with monora.trace("resilience_test"):
            # First call succeeds
            allowed_call()

            # Second call fails
            try:
                forbidden_call()
            except monora.PolicyViolation:
                pass

            # Third call should still work (trace not broken)
            allowed_call()

        from monora.runtime import shutdown
        import time

        time.sleep(0.5)
        shutdown()

        # Should have 3 events: 2 successes + 1 violation
        with open(log_path) as f:
            import json

            events = [json.loads(line) for line in f if line.strip()]
            assert len(events) == 3


def test_exception_in_decorated_function():
    """Test that exceptions in user code are handled correctly."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "error_handling": {"log_user_exceptions": True},
            }
        )

        @monora.llm_call(purpose="exception_test")
        def failing_call(model: str = "gpt-4"):
            raise ValueError("User error")

        import pytest

        with monora.trace("exception_test"):
            with pytest.raises(ValueError, match="User error"):
                failing_call()

        from monora.runtime import shutdown
        import time

        time.sleep(0.5)
        shutdown()

        # Error should be logged
        with open(log_path) as f:
            import json

            events = [json.loads(line) for line in f if line.strip()]
            assert len(events) == 1
            assert events[0]["body"]["status"] == "error"
            assert events[0]["body"]["error"]["type"] == "ValueError"


def test_multiple_init_calls():
    """Test that reinitializing SDK works correctly."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path1 = Path(tmpdir) / "events1.jsonl"
        log_path2 = Path(tmpdir) / "events2.jsonl"

        # First init
        monora.init(config_dict={"sinks": [{"type": "file", "path": str(log_path1)}]})

        @monora.llm_call(purpose="test")
        def test_call(model: str = "gpt-4"):
            return {"response": "ok"}

        with monora.trace("test1"):
            test_call()

        # Reinitialize with different config
        monora.init(config_dict={"sinks": [{"type": "file", "path": str(log_path2)}]})

        with monora.trace("test2"):
            test_call()

        from monora.runtime import shutdown
        import time

        time.sleep(0.5)
        shutdown()

        # Both log files should exist
        assert log_path1.exists()
        assert log_path2.exists()


def test_graceful_shutdown_with_pending_events():
    """Test that shutdown waits for pending events."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "buffering": {"queue_size": 10000, "flush_interval_sec": 10.0},
            }
        )

        @monora.llm_call(purpose="shutdown_test")
        def create_event(i: int, model: str = "gpt-4"):
            return {"id": i}

        # Create many events
        with monora.trace("shutdown_test"):
            for i in range(100):
                create_event(i)

        # Shutdown should flush all events
        from monora.runtime import shutdown

        shutdown()

        # All events should be written
        with open(log_path) as f:
            import json

            events = [json.loads(line) for line in f if line.strip()]
            # Should have 100 events (may be slightly less due to timing)
            assert len(events) >= 95


def test_violation_handler_exception_handling():
    """Test that exceptions in violation handler don't crash SDK."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "policies": {"enforce": True, "model_denylist": ["forbidden-*"]},
            }
        )

        def bad_handler(violation):
            raise RuntimeError("Handler error")

        monora.set_violation_handler(bad_handler)

        @monora.llm_call(purpose="test")
        def forbidden_call(model: str = "forbidden-model"):
            return {"response": "blocked"}

        import pytest

        # Violation should still be raised despite handler error
        with pytest.raises(monora.PolicyViolation):
            forbidden_call()

        from monora.runtime import shutdown

        shutdown()
