from monora.attestation import (
    SignatureResult,
    build_attestation_bundle,
    compute_sha256,
    serialize_report,
)


def test_serialize_report_is_stable():
    report = {"b": 2, "a": 1}
    first = serialize_report(report)
    second = serialize_report(report)
    assert first == second


def test_build_attestation_bundle_structure():
    report = {"report": "ok"}
    report_bytes = serialize_report(report)
    signature = SignatureResult(
        signature="sig",
        signature_type="gpg",
        key_id="ABC123",
        fingerprint="FPR",
    )
    bundle = build_attestation_bundle(report, report_bytes, signature)

    assert bundle["bundle_version"] == "1.0.0"
    assert bundle["report_sha256"] == compute_sha256(report_bytes)
    assert bundle["report_json"] == report_bytes.decode("utf-8")
    assert bundle["signature"]["type"] == "gpg"
    assert bundle["signature"]["value"] == "sig"
    assert bundle["signature"]["key_id"] == "ABC123"
    assert bundle["signature"]["fingerprint"] == "FPR"
