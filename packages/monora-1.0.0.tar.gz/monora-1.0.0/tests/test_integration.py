"""Integration tests for Monora SDK."""
import tempfile
import json
from pathlib import Path

import monora
from monora import trace, llm_call, tool_call, agent_step


def test_end_to_end_flow():
    """Test complete end-to-end flow with file sink."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        # Initialize with file sink
        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "immutability": {"enabled": True, "scope": "per_trace"},
                "policies": {
                    "enforce": True,
                    "model_allowlist": ["gpt-4*", "claude-3-*"],
                },
            }
        )

        # Define decorated functions
        @llm_call(purpose="testing")
        def mock_llm(prompt: str, model: str = "gpt-4"):
            return {"choices": [{"message": {"content": "response"}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30}}

        @tool_call(tool_name="test_tool", purpose="testing")
        def mock_tool(arg: str):
            return {"result": arg}

        @agent_step(agent_name="test_agent", step_type="planning", purpose="testing")
        def mock_step(goal: str):
            return ["step1", "step2"]

        # Execute within trace
        with trace("test_trace"):
            mock_llm("hello")
            mock_tool("test")
            mock_step("achieve goal")

        # Give time for background worker to flush
        import time
        time.sleep(0.5)

        # Force shutdown to flush
        from monora.runtime import shutdown
        shutdown()

        # Verify events were written
        assert log_path.exists()
        events = []
        with open(log_path) as f:
            for line in f:
                if line.strip():
                    events.append(json.loads(line))

        assert len(events) == 3
        assert events[0]["event_type"] == "llm_call"
        assert events[1]["event_type"] == "tool_call"
        assert events[2]["event_type"] == "agent_step"

        # Verify hash chain
        assert events[0]["prev_hash"] is None
        assert events[0]["event_hash"] is not None
        assert events[1]["prev_hash"] == events[0]["event_hash"]
        assert events[2]["prev_hash"] == events[1]["event_hash"]


def test_policy_violation():
    """Test policy violation enforcement."""
    monora.init(
        config_dict={
            "sinks": [{"type": "stdout"}],
            "policies": {
                "enforce": True,
                "model_denylist": ["forbidden-*"],
            },
        }
    )
    try:
        @llm_call(purpose="testing")
        def bad_llm(prompt: str, model: str = "forbidden-model"):
            return {"response": "should not reach here"}

        from monora.policy import PolicyViolation
        import pytest

        with pytest.raises(PolicyViolation):
            bad_llm("test")
    finally:
        monora.shutdown()
