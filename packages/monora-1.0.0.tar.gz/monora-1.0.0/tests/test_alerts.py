import os

import pytest

from monora.alerts import AlertError, ViolationWebhookDispatcher, build_violation_payload, expand_headers


@pytest.mark.usefixtures("mocker")
def test_violation_webhook_dispatcher_sends(mocker):
    _ = pytest.importorskip("requests")
    response = mocker.Mock()
    response.raise_for_status.return_value = None
    mock_post = mocker.patch(
        "monora.alerts.requests.post",
        return_value=response,
    )

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        retry_attempts=1,
        queue_size=10,
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    assert mock_post.call_count >= 1


# Retry Logic Tests


def test_webhook_retries_on_failure(mocker):
    """Test webhook retries on transient failures."""
    requests = pytest.importorskip("requests")
    response = mocker.Mock()
    response.raise_for_status.return_value = None
    mock_post = mocker.patch(
        "monora.alerts.requests.post",
        side_effect=[
            requests.Timeout(),
            requests.Timeout(),
            response,  # Success on 3rd attempt
        ],
    )

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        retry_attempts=3,
        queue_size=10,
        failure_mode="warn",
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    assert mock_post.call_count == 3


def test_webhook_permanent_failure_warn_mode(mocker):
    """Test webhook handles permanent failures in warn mode."""
    requests = pytest.importorskip("requests")
    mock_post = mocker.patch(
        "monora.alerts.requests.post",
        side_effect=requests.ConnectionError("Service unavailable"),
    )

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        retry_attempts=3,
        failure_mode="warn",  # Should not raise
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    assert mock_post.call_count == 3  # All retries attempted


def test_webhook_permanent_failure_raise_mode(mocker):
    """Test webhook handles permanent failures in raise mode."""
    requests = pytest.importorskip("requests")
    mock_post = mocker.patch(
        "monora.alerts.requests.post",
        side_effect=requests.ConnectionError("Service unavailable"),
    )

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        retry_attempts=3,
        failure_mode="raise",
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    # Next send should raise due to fatal error
    with pytest.raises(AlertError):
        dispatcher.send({"event_type": "policy_violation"})


# Backoff Logic Test


def test_webhook_exponential_backoff(mocker):
    """Test webhook uses exponential backoff between retries."""
    requests = pytest.importorskip("requests")
    mock_post = mocker.patch(
        "monora.alerts.requests.post", side_effect=requests.Timeout()
    )
    mock_sleep = mocker.patch("monora.alerts.time.sleep")

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        retry_attempts=3,
        backoff_base_sec=1.0,
        failure_mode="warn",
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    # Verify backoff was called with increasing delays
    assert mock_sleep.call_count == 2  # 2 retries after first attempt
    sleep_calls = [call[0][0] for call in mock_sleep.call_args_list]

    # First backoff: base * 2^0 + jitter = ~1.0-1.1
    assert 1.0 <= sleep_calls[0] <= 1.2

    # Second backoff: base * 2^1 + jitter = ~2.0-2.1 (exponential)
    assert 2.0 <= sleep_calls[1] <= 2.2


# Queue Behavior Tests


def test_webhook_queue_overflow_warn_mode(mocker, capsys):
    """Test webhook handles queue overflow in warn mode."""
    _ = pytest.importorskip("requests")
    mock_post = mocker.patch("monora.alerts.requests.post")

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        queue_size=2,  # Very small queue
        queue_full_mode="warn",
    )
    dispatcher.start()

    # Fill queue
    dispatcher.send({"id": 1})
    dispatcher.send({"id": 2})

    # This should trigger queue full warning
    dispatcher.send({"id": 3})

    captured = capsys.readouterr()
    assert "queue full" in captured.err.lower()

    dispatcher.close()


def test_webhook_queue_overflow_raise_mode(mocker):
    """Test webhook raises on queue overflow in raise mode."""
    _ = pytest.importorskip("requests")
    mock_post = mocker.patch("monora.alerts.requests.post")

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {},
        queue_size=2,
        queue_full_mode="raise",
    )
    dispatcher.start()

    # Fill queue
    dispatcher.send({"id": 1})
    dispatcher.send({"id": 2})

    # This should raise
    with pytest.raises(AlertError, match="queue full"):
        dispatcher.send({"id": 3})

    dispatcher.close()


# Configuration Tests


def test_webhook_timeout_configuration(mocker):
    """Test webhook respects timeout configuration."""
    _ = pytest.importorskip("requests")
    mock_post = mocker.patch("monora.alerts.requests.post")

    dispatcher = ViolationWebhookDispatcher(
        "https://hooks.example.com/monora",
        {"Authorization": "Bearer token123"},
        timeout_sec=10.0,
    )
    dispatcher.start()
    dispatcher.send({"event_type": "policy_violation"})
    dispatcher.close()

    # Verify timeout was passed to requests.post
    call_kwargs = mock_post.call_args[1]
    assert call_kwargs["timeout"] == 10.0
    assert call_kwargs["headers"] == {"Authorization": "Bearer token123"}


def test_webhook_header_expansion(monkeypatch):
    """Test webhook expands environment variables in headers."""
    monkeypatch.setenv("TEST_API_KEY", "secret123")

    headers = {"Authorization": "Bearer ${TEST_API_KEY}"}
    expanded = expand_headers(headers)

    assert expanded == {"Authorization": "Bearer secret123"}



# Payload Structure Test


def test_build_violation_payload_structure():
    """Test violation payload has correct structure."""
    from datetime import datetime, timezone

    from monora.policy import PolicyViolation

    violation = PolicyViolation(
        event_type="llm_call",
        model="forbidden-model",
        policy_name="model_denylist",
        message="Model matches denylist pattern",
        timestamp=datetime.now(timezone.utc).isoformat(),
    )

    payload = build_violation_payload(
        violation=violation,
        trace_id="trace_123",
        span_id="span_456",
        parent_span_id="span_000",
        service_name="my-app",
        environment="production",
    )

    assert payload["event_type"] == "policy_violation"
    assert payload["policy_event_type"] == "llm_call"
    assert payload["model"] == "forbidden-model"
    assert payload["policy_name"] == "model_denylist"
    assert payload["message"] == "Model matches denylist pattern"
    assert payload["trace_id"] == "trace_123"
    assert payload["span_id"] == "span_456"
    assert payload["parent_span_id"] == "span_000"
    assert payload["service_name"] == "my-app"
    assert payload["environment"] == "production"


# Integration Test


def test_webhook_integration_with_runtime(mocker):
    """Test webhook dispatcher integrates correctly with runtime."""
    _ = pytest.importorskip("requests")
    import monora

    mock_post = mocker.patch("monora.alerts.requests.post")

    monora.init(
        config_dict={
            "alerts": {
                "violation_webhook": "https://hooks.example.com/monora",
                "headers": {"Authorization": "Bearer test"},
                "retry_attempts": 1,
            },
            "policies": {
                "model_denylist": ["forbidden-model"],
                "enforce": False,  # Warn mode to continue execution
            },
        }
    )

    # Trigger violation via decorator
    @monora.llm_call(model="forbidden-model", purpose="testing")
    def test_call():
        return {"response": "test"}

    test_call()
    monora.shutdown()

    # Verify webhook was called
    assert mock_post.call_count >= 1
    call_kwargs = mock_post.call_args[1]
    assert "forbidden-model" in str(call_kwargs["json"])
