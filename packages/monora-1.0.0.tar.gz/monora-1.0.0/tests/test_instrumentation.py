"""Tests for auto-instrumentation."""
from __future__ import annotations

import contextlib
import sys
import types

from monora.instrumentation import auto_instrument


@contextlib.contextmanager
def _patch_modules(modules: dict[str, types.ModuleType]):
    original = {}
    for name, module in modules.items():
        original[name] = sys.modules.get(name)
        sys.modules[name] = module
    try:
        yield
    finally:
        for name in modules:
            if original[name] is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = original[name]


def _openai_stub():
    openai = types.ModuleType("openai")
    openai.__path__ = []
    resources = types.ModuleType("openai.resources")
    resources.__path__ = []
    chat = types.ModuleType("openai.resources.chat")
    chat.__path__ = []
    completions = types.ModuleType("openai.resources.chat.completions")

    class Completions:
        def create(self, model: str = "gpt-4"):
            return {"ok": True, "model": model}

    completions.Completions = Completions
    return {
        "openai": openai,
        "openai.resources": resources,
        "openai.resources.chat": chat,
        "openai.resources.chat.completions": completions,
    }, Completions


def _anthropic_stub():
    anthropic = types.ModuleType("anthropic")
    anthropic.__path__ = []
    resources = types.ModuleType("anthropic.resources")
    resources.__path__ = []
    messages = types.ModuleType("anthropic.resources.messages")

    class Messages:
        def create(self, model: str = "claude-3-opus"):
            return {"ok": True, "model": model}

    messages.Messages = Messages
    return {
        "anthropic": anthropic,
        "anthropic.resources": resources,
        "anthropic.resources.messages": messages,
    }, Messages


def test_auto_instrument_patches_openai_and_anthropic():
    openai_modules, openai_cls = _openai_stub()
    anthropic_modules, anthropic_cls = _anthropic_stub()
    modules = {}
    modules.update(openai_modules)
    modules.update(anthropic_modules)

    config = {
        "defaults": {"purpose": "auto"},
        "instrumentation": {"enabled": True, "targets": ["openai", "anthropic"]},
    }

    with _patch_modules(modules):
        auto_instrument(config)
        assert getattr(openai_cls.create, "__monora_wrapped__", False) is True
        assert getattr(anthropic_cls.create, "__monora_wrapped__", False) is True
