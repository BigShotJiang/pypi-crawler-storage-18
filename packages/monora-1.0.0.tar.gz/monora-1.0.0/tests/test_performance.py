"""Performance benchmarks for Monora SDK."""
import tempfile
import time
from pathlib import Path

import monora


def test_event_emission_latency():
    """Test that event emission is non-blocking (< 1ms)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "buffering": {"queue_size": 10000},
            }
        )

        @monora.llm_call(purpose="benchmark")
        def fast_call(model: str = "gpt-4"):
            return {"response": "ok"}

        # Measure emission time
        iterations = 100
        start = time.perf_counter()

        with monora.trace("perf_test"):
            for _ in range(iterations):
                fast_call()

        elapsed = time.perf_counter() - start
        avg_latency_ms = (elapsed / iterations) * 1000

        # Should be < 1ms per call (non-blocking)
        assert avg_latency_ms < 1.0, f"Average latency {avg_latency_ms:.2f}ms too high"

        from monora.runtime import shutdown

        shutdown()


def test_high_throughput():
    """Test SDK can handle high event throughput."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [
                    {
                        "type": "file",
                        "path": str(log_path),
                        "batch_size": 100,
                        "flush_interval_sec": 0.5,
                    }
                ],
                "buffering": {"queue_size": 10000, "batch_size": 100},
            }
        )

        @monora.llm_call(purpose="throughput_test")
        def emit_event(i: int, model: str = "gpt-4"):
            return {"id": i}

        # Emit many events quickly
        count = 1000
        start = time.perf_counter()

        with monora.trace("throughput"):
            for i in range(count):
                emit_event(i)

        elapsed = time.perf_counter() - start
        throughput = count / elapsed

        # Should handle > 10k events/sec
        assert throughput > 1000, f"Throughput {throughput:.0f} events/sec too low"

        from monora.runtime import shutdown

        time.sleep(1.0)  # Allow background flush
        shutdown()


def test_policy_check_performance():
    """Test policy checking is fast."""
    from monora.policy import PolicyEngine

    engine = PolicyEngine(
        {
            "model_allowlist": ["gpt-4*", "claude-3-*", "gemini-*"],
            "model_denylist": ["deepseek:*", "*alpha*", "*beta*"],
            "classification_max_models": {
                "secret": {"allowed": ["claude-3-opus*"]},
                "confidential": {"denied": ["*mini*"]},
            },
            "enforce": True,
        }
    )

    # Measure policy check time
    iterations = 10000
    start = time.perf_counter()

    for _ in range(iterations):
        engine.check_model("gpt-4o-mini", "internal")

    elapsed = time.perf_counter() - start
    avg_time_us = (elapsed / iterations) * 1_000_000

    # Should be < 10 microseconds per check
    assert avg_time_us < 10.0, f"Policy check {avg_time_us:.2f}μs too slow"


def test_hash_computation_performance():
    """Test hash computation is fast."""
    from monora.hasher import Hasher

    hasher = Hasher({"enabled": True, "scope": "global", "hash_algorithm": "sha256"})

    event = {
        "event_id": "evt_123",
        "event_type": "llm_call",
        "timestamp": "2025-12-21T10:00:00Z",
        "trace_id": "trc_456",
        "span_id": "spn_789",
        "body": {
            "model": "gpt-4",
            "request": {"messages": ["test"] * 10},
            "response": {"content": "response text here"},
        },
    }

    # Measure hash time
    iterations = 1000
    start = time.perf_counter()

    for _ in range(iterations):
        hasher.hash_event(event.copy())

    elapsed = time.perf_counter() - start
    avg_time_us = (elapsed / iterations) * 1_000_000

    # Should be < 100 microseconds per hash
    assert avg_time_us < 100.0, f"Hash computation {avg_time_us:.2f}μs too slow"


def test_concurrent_event_emission():
    """Test concurrent event emission from multiple threads."""
    import threading

    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "buffering": {"queue_size": 50000},
            }
        )

        @monora.llm_call(purpose="concurrency_test")
        def thread_call(thread_id: int, i: int, model: str = "gpt-4"):
            return {"thread": thread_id, "id": i}

        def worker(thread_id: int, count: int):
            with monora.trace(f"thread_{thread_id}"):
                for i in range(count):
                    thread_call(thread_id, i)

        # Spawn multiple threads
        num_threads = 10
        events_per_thread = 100
        threads = []

        start = time.perf_counter()

        for i in range(num_threads):
            t = threading.Thread(target=worker, args=(i, events_per_thread))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        elapsed = time.perf_counter() - start
        total_events = num_threads * events_per_thread
        throughput = total_events / elapsed

        # Should handle concurrent load
        assert throughput > 500, f"Concurrent throughput {throughput:.0f} too low"

        from monora.runtime import shutdown

        time.sleep(1.0)
        shutdown()


def test_memory_efficiency():
    """Test memory usage stays reasonable under load."""
    import sys

    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "events.jsonl"

        monora.init(
            config_dict={
                "sinks": [{"type": "file", "path": str(log_path)}],
                "buffering": {"queue_size": 1000},
            }
        )

        @monora.llm_call(purpose="memory_test")
        def create_event(i: int, model: str = "gpt-4"):
            return {"id": i, "data": "x" * 100}

        # Create many events
        with monora.trace("memory_test"):
            for i in range(5000):
                create_event(i)

        # Queue should not grow unbounded (background worker processes)
        from monora.runtime import ensure_state

        state = ensure_state()
        queue_size = state.dispatcher.queue.qsize()

        # Queue should be mostly empty (processed by worker)
        assert queue_size < 100, f"Queue size {queue_size} too large"

        from monora.runtime import shutdown

        time.sleep(0.5)
        shutdown()
