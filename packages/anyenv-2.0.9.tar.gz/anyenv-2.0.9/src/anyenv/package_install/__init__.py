"""Package installation utilities."""
