# Middleman CLI

Command-line interface for the Middleman GPU compute platform.

## Installation

```bash
pip install middleman-cli
```

## Quick Start

```bash
# Authenticate with your API key
middleman login

# Submit a training job
middleman run train.py --gpu a100

# Check job status
middleman jobs list
middleman jobs status <job-id>

# View logs
middleman jobs logs <job-id> --follow

# Check credit balance
middleman credits
```

## Commands

### Authentication

```bash
# Login with API key
middleman login

# Show current user
middleman whoami

# Logout
middleman logout
```

### Running Jobs

```bash
# Basic job submission
middleman run train.py --gpu t4

# Advanced options
middleman run train.py \
  --gpu a100 \
  --name "my-experiment" \
  --framework pytorch \
  --max-runtime 8 \
  --env WANDB_API_KEY=xxx \
  --requirements requirements.txt \
  --wait

# GPU options: t4, v100, a100, a100-80gb, h100
# Framework options: pytorch, tensorflow, jax, custom
```

### Managing Jobs

```bash
# List jobs
middleman jobs list
middleman jobs list --status running
middleman jobs list --all

# Get job status
middleman jobs status <job-id>
middleman jobs status <job-id> --watch

# View logs
middleman jobs logs <job-id>
middleman jobs logs <job-id> --tail 200
middleman jobs logs <job-id> --follow

# Cancel job
middleman jobs cancel <job-id>
```

### Credits

```bash
# Show credit balance
middleman credits
```

### Configuration

```bash
# Show config
middleman configure --show

# Set custom API URL
middleman configure --api-url https://custom.api.url

# Reset config
middleman configure --reset
```

## Configuration

Configuration is stored in `~/.middleman/config.yaml`:

```yaml
api_key: mdlm_xxxxx
api_url: https://api.middleman.run/api/v1
```

## Environment Variables

- `MIDDLEMAN_API_KEY` - API key (overrides config file)
- `MIDDLEMAN_API_URL` - API URL (overrides config file)

## Get Your API Key

1. Sign up at https://middleman.run
2. Go to https://app.middleman.run/dashboard/api-keys
3. Create a new API key
4. Run `middleman login`

## Support

- Documentation: https://docs.middleman.run
- Email: support@middleman.run
- Dashboard: https://app.middleman.run
