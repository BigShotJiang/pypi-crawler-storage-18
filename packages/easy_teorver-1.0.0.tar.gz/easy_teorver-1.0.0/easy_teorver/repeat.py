from .no_repeat import factorial

def comb_with_rep(n: int, k: int) -> int:
    """Сочетания С повторениями: C̄(n,k) = (n+k-1)!/(k!*(n-1)!)"""
    if n <= 0 or k < 0:
        return 0
    return factorial(n + k - 1) // (factorial(k) * factorial(n - 1))

def perm_with_rep(n: int, *reps: int) -> int:
    """Перестановки С повторениями: P(n; n1,n2...) = n!/(n1!*n2!*...)"""
    if n < 0:
        return 0
    if sum(reps) != n:
        return 0
    
    top = factorial(n)
    bottom = 1
    for r in reps:
        bottom *= factorial(r)
    return top // bottom

def arr_with_rep(n: int, k: int) -> int:
    """Размещения С повторениями: Ā(n,k) = n^k"""
    if n <= 0 or k < 0:
        return 0
    result = 1
    for _ in range(k):
        result *= n
    return result