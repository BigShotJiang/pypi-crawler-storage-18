def factorial(n: int) -> int:
    """Вычисление факториала"""
    if n < 0:
        return 0
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def comb_no_rep(n: int, k: int) -> int:
    """Сочетания БЕЗ повторений: C(n,k) = n!/(k!*(n-k)!)"""
    if n < 0 or k < 0 or k > n:
        return 0
    return factorial(n) // (factorial(k) * factorial(n - k))

def perm_no_rep(n: int) -> int:
    """Перестановки БЕЗ повторений: P(n) = n!"""
    return factorial(n)

def arr_no_rep(n: int, k: int) -> int:
    """Размещения БЕЗ повторений: A(n,k) = n!/(n-k)!"""
    if n < 0 or k < 0 or k > n:
        return 0
    return factorial(n) // factorial(n - k)