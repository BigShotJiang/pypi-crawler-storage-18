"""
easy_teorver - простая библиотека формул теории вероятностей
Версия 1.0.0
"""

from .no_repeat import comb_no_rep, perm_no_rep, arr_no_rep
from .repeat import comb_with_rep, perm_with_rep, arr_with_rep

__version__ = "1.0.0"
__all__ = [
    'comb_no_rep',
    'perm_no_rep', 
    'arr_no_rep',
    'comb_with_rep',
    'perm_with_rep',
    'arr_with_rep'
]