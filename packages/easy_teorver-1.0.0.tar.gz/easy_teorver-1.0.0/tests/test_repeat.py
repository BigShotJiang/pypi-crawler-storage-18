from easy_teorver import comb_with_rep, perm_with_rep, arr_with_rep

print("=== Тесты для формул С повторениями ===\n")

print("1. Сочетания с повторениями:")
print(f"   C̄(3,2) = {comb_with_rep(3, 2)} (ожидается: 6)")
print(f"   C̄(5,0) = {comb_with_rep(5, 0)} (ожидается: 1)")
print(f"   C̄(1,5) = {comb_with_rep(1, 5)} (ожидается: 1)")

print("\n2. Перестановки с повторениями:")
print(f"   P(5; 3,2) = {perm_with_rep(5, 3, 2)} (ожидается: 10)")
print(f"   P(6; 2,2,2) = {perm_with_rep(6, 2, 2, 2)} (ожидается: 90)")

print("\n3. Размещения с повторениями:")
print(f"   Ā(3,2) = {arr_with_rep(3, 2)} (ожидается: 9)")
print(f"   Ā(5,0) = {arr_with_rep(5, 0)} (ожидается: 1)")
print(f"   Ā(2,3) = {arr_with_rep(2, 3)} (ожидается: 8)")

print("\n Тесты пройдены")