from easy_teorver import comb_no_rep, perm_no_rep, arr_no_rep

print("=== Тесты для формул БЕЗ повторений ===\n")

print("1. Сочетания без повторений:")
print(f"   C(5,2) = {comb_no_rep(5, 2)} (ожидается: 10)")
print(f"   C(5,5) = {comb_no_rep(5, 5)} (ожидается: 1)")
print(f"   C(5,0) = {comb_no_rep(5, 0)} (ожидается: 1)")
print(f"   C(5,6) = {comb_no_rep(5, 6)} (ожидается: 0)")

print("\n2. Перестановки без повторений:")
print(f"   P(5) = {perm_no_rep(5)} (ожидается: 120)")
print(f"   P(0) = {perm_no_rep(0)} (ожидается: 1)")
print(f"   P(1) = {perm_no_rep(1)} (ожидается: 1)")

print("\n3. Размещения без повторений:")
print(f"   A(5,2) = {arr_no_rep(5, 2)} (ожидается: 20)")
print(f"   A(5,5) = {arr_no_rep(5, 5)} (ожидается: 120)")
print(f"   A(5,0) = {arr_no_rep(5, 0)} (ожидается: 1)")

print("\n Тесты пройдены")