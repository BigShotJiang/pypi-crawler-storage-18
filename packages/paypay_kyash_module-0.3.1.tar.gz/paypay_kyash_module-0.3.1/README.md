# testtt

testでモジュール作成
使用例
 kyash = Kyash("メールアドレス", "パスワード", proxy=None)
    otp = input("OTP? :")
    kyash.login(otp)
    print(f"Access Token: {kyash.access_token}")
    print(f"Client UUID: {kyash.client_uuid}")
    print(f"Installation UUID: {kyash.installation_uuid}")
 
    profile = kyash.get_profile()
    print(f"ユーザー名: {profile.username}")
    print(f"アイコン: {profile.icon}")
    print(f"苗字: {profile.myouzi}")
    print(f"名前: {profile.namae}")
    print(f"電話番号: {profile.phone}")
    print(f"本人確認: {profile.is_kyc}")
    
    wallet = kyash.get_wallet()
    print(f"おさいふUUID: {wallet.uuid}")
    print(f"合計残高: {wallet.all_balance}")
    print(f"マネー: {wallet.money}")
    print(f"バリュー: {wallet.value}")
    print(f"ポイント: {wallet.point}")
    
    history = kyash.get_history(wallet_uuid=wallet.uuid, limit=3)
    print(f"履歴: {history.timelines}")
    
    summary = kyash.get_summary(year=2024, month=6)
    print(f"サマリー: {summary.summary}")
    
    create_link = kyash.create_link(amount=100, message="テストリンク", is_claim=False)
    print(f"リンク: {create_link.link}")
    
    link_info = kyash.link_check(create_link.link)
    print(f"金額: {link_info.amount}")
    print(f"UUID: {link_info.uuid}")
    print(f"受け取りリンク: {link_info.send_to_me}")


    paypay = PayPay("080-1234-5678", "パスワード")
    url = input("URL?: ")
    paypay.login(url)
    print(f"Access Token: {paypay.access_token}")
    print(f"Refresh Token: {paypay.refresh_token}")
    print(f"Device UUID: {paypay.device_uuid}")
    print(f"Client UUID: {paypay.client_uuid}")
    
    profile = paypay.get_profile()
    print(f"ユーザー名: {profile.name}")
    print(f"External User ID: {profile.external_user_id}")
    print(f"アイコン: {profile.icon}")
    
    balance = paypay.get_balance()
    print(f"全残高: {balance.all_balance}")
    print(f"使用可能残高: {balance.useable_balance}")
    print(f"マネーライト: {balance.money_light}")
    print(f"マネー: {balance.money}")
    print(f"ポイント: {balance.points}")
    
    history = paypay.get_history(size=20)
    print(f"履歴: {history}")
    
    chat_rooms = paypay.get_chat_rooms(size=20)
    print(f"DMリスト: {chat_rooms}")
    
    point_history = paypay.get_point_history()
    print(f"ポイント履歴: {point_history}")

    link_info = paypay.link_check("KT975hvzbH1EulTr")
    print(f"金額: {link_info.amount}")
    print(f"マネーライト: {link_info.money_light}")
    print(f"マネー: {link_info.money}")
    print(f"パスワードあり: {link_info.has_password}")
    print(f"ステータス: {link_info.status}")
 
    create_link = paypay.create_link(amount=100, passcode="4602")
    print(f"リンク: {create_link.link}")
    print(f"チャットルームID: {create_link.chat_room_id}")
    
    create_p2pcode = paypay.create_p2pcode()
    print(f"P2Pコード: {create_p2pcode.p2pcode}")
