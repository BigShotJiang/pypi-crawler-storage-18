"""Update command for upgrading the glaip-sdk package.

Author:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import subprocess
import sys
from collections.abc import Sequence

import click
from rich.console import Console

from glaip_sdk.branding import ACCENT_STYLE, ERROR_STYLE, INFO_STYLE, SUCCESS_STYLE

PACKAGE_NAME = "glaip-sdk"


def _is_uv_managed_environment() -> bool:
    """Check if running in a uv-managed tool environment.

    Uses a path-based heuristic that may need updates if uv changes its layout.
    """
    executable = str(sys.executable)
    # Check for uv tool install paths: ~/.local/share/uv/tools/*/bin/python*
    return ".local/share/uv/tools" in executable or "/uv/tools/" in executable


def _build_command_parts(
    *,
    package_name: str = PACKAGE_NAME,
    is_uv: bool | None = None,
    force_reinstall: bool = False,
    include_prerelease: bool = False,
) -> tuple[list[str], str]:
    """Build the common parts of upgrade commands.

    Returns:
        Tuple of (command parts list, force_reinstall flag name).
        For uv: (["uv", "tool", "install", "--upgrade", package_name], "--reinstall")
        For pip: (["pip", "install", "--upgrade", package_name], "--force-reinstall")
    """
    if is_uv is None:
        is_uv = _is_uv_managed_environment()

    if is_uv:
        command = ["uv", "tool", "install", "--upgrade", package_name]
        reinstall_flag = "--reinstall"
    else:
        command = ["pip", "install", "--upgrade", package_name]
        reinstall_flag = "--force-reinstall"

    if force_reinstall:
        command.insert(-1, reinstall_flag)

    if include_prerelease:
        command.append("--pre")

    return command, reinstall_flag


def _build_upgrade_command(
    include_prerelease: bool,
    *,
    package_name: str = PACKAGE_NAME,
    is_uv: bool | None = None,
    force_reinstall: bool = False,
) -> Sequence[str]:
    """Return the command used to upgrade the SDK (pip or uv tool install)."""
    if is_uv is None:
        is_uv = _is_uv_managed_environment()

    command_parts, _ = _build_command_parts(
        package_name=package_name,
        is_uv=is_uv,
        force_reinstall=force_reinstall,
        include_prerelease=include_prerelease,
    )

    # For pip, prepend sys.executable and -m
    if not is_uv:
        command_parts = [sys.executable, "-m"] + command_parts

    return command_parts


def _build_manual_upgrade_command(
    include_prerelease: bool,
    *,
    package_name: str = PACKAGE_NAME,
    is_uv: bool | None = None,
    force_reinstall: bool = False,
) -> str:
    """Return a manual upgrade command string matching the active environment."""
    command_parts, _ = _build_command_parts(
        package_name=package_name,
        is_uv=is_uv,
        force_reinstall=force_reinstall,
        include_prerelease=include_prerelease,
    )
    return " ".join(command_parts)


@click.command(name="update")
@click.option(
    "--pre",
    "include_prerelease",
    is_flag=True,
    help="Include pre-release versions when upgrading.",
)
def update_command(include_prerelease: bool) -> None:
    """Upgrade the glaip-sdk package using pip or uv tool install."""
    console = Console()
    # Call _is_uv_managed_environment() once and pass explicitly to avoid redundant calls
    is_uv = _is_uv_managed_environment()
    upgrade_cmd = _build_upgrade_command(include_prerelease, is_uv=is_uv)

    # Determine the appropriate manual command for error messages
    manual_cmd = _build_manual_upgrade_command(include_prerelease, is_uv=is_uv)

    console.print(f"[{ACCENT_STYLE}]Upgrading {PACKAGE_NAME} using[/] [{INFO_STYLE}]{' '.join(upgrade_cmd)}[/]")

    try:
        subprocess.run(upgrade_cmd, check=True)
    except FileNotFoundError as exc:
        if is_uv:
            raise click.ClickException(
                f"Unable to locate uv executable. Please ensure uv is installed and on your PATH.\n"
                f"Install uv: curl -LsSf https://astral.sh/uv/install.sh | sh\n"
                f"Or run manually: {manual_cmd}"
            ) from exc
        raise click.ClickException(
            "Unable to locate Python executable to run pip. Please ensure Python is installed and try again."
        ) from exc
    except subprocess.CalledProcessError as exc:
        console.print(f"[{ERROR_STYLE}]Automatic upgrade failed.[/] Please run `{manual_cmd}` manually.")
        raise click.ClickException("Automatic upgrade failed.") from exc

    console.print(f"[{SUCCESS_STYLE}]✅ {PACKAGE_NAME} upgraded successfully.[/]")
