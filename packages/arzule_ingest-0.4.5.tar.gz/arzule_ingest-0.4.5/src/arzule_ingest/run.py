"""ArzuleRun - Core runtime context manager for trace collection."""

from __future__ import annotations

import threading
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from .ids import new_run_id, new_span_id, new_trace_id

if TYPE_CHECKING:
    from .sinks.base import TelemetrySink

_active_run: ContextVar[Optional["ArzuleRun"]] = ContextVar("_active_run", default=None)


def current_run() -> Optional["ArzuleRun"]:
    """Get the currently active ArzuleRun from context."""
    return _active_run.get()


@dataclass
class ArzuleRun:
    """
    Context manager for a single observability run.

    Manages trace lifecycle, sequence numbering, and event emission.
    Supports concurrent task execution with per-task span tracking.
    """

    tenant_id: str
    project_id: str
    sink: "TelemetrySink"
    run_id: str = field(default_factory=new_run_id)
    trace_id: str = field(default_factory=new_trace_id)

    # Internal state
    _seq: int = field(default=0, repr=False)
    _seq_lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    _root_span_id: Optional[str] = field(default=None, repr=False)

    # Maps for correlating start/end hooks
    _inflight: dict[str, str] = field(default_factory=dict, repr=False)

    # Pending handoffs awaiting ack/complete
    _handoff_pending: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)

    # Span stack for parent/child relationships (legacy, for sequential execution)
    _span_stack: list[str] = field(default_factory=list, repr=False)

    # Per-task span tracking for concurrent execution
    # Maps task_key -> {"root_span_id": str, "current_span_id": str, "stack": list[str]}
    _task_spans: dict[str, dict[str, Any]] = field(default_factory=dict, repr=False)
    _task_spans_lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    # Maps agent_key -> current task_key (for correlating agent events to tasks)
    _agent_task_map: dict[str, str] = field(default_factory=dict, repr=False)

    # Crew-level span ID (parent for all concurrent task branches)
    _crew_span_id: Optional[str] = field(default=None, repr=False)

    def next_seq(self) -> int:
        """Get the next monotonically increasing sequence number (thread-safe)."""
        with self._seq_lock:
            self._seq += 1
            return self._seq

    def now(self) -> str:
        """Get current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()

    def current_parent_span_id(self) -> Optional[str]:
        """Get the current parent span ID from the stack (legacy sequential mode)."""
        return self._span_stack[-1] if self._span_stack else self._root_span_id

    def push_span(self, span_id: str) -> None:
        """Push a span onto the stack (legacy sequential mode)."""
        self._span_stack.append(span_id)

    def pop_span(self) -> Optional[str]:
        """Pop a span from the stack (legacy sequential mode)."""
        return self._span_stack.pop() if self._span_stack else None

    # =========================================================================
    # Per-Task Span Management (for concurrent/async execution)
    # =========================================================================

    def set_crew_span(self, span_id: str) -> None:
        """Set the crew-level span ID (parent for concurrent task branches)."""
        self._crew_span_id = span_id

    def get_crew_span(self) -> Optional[str]:
        """Get the crew-level span ID."""
        return self._crew_span_id or self._root_span_id

    def start_task_span(self, task_key: str, agent_key: Optional[str] = None) -> str:
        """
        Start a new span tree for a task (used for concurrent execution).

        Args:
            task_key: Unique identifier for the task (e.g., task.id or generated)
            agent_key: Optional agent key to associate with this task

        Returns:
            The root span ID for this task
        """
        span_id = new_span_id()
        with self._task_spans_lock:
            self._task_spans[task_key] = {
                "root_span_id": span_id,
                "current_span_id": span_id,
                "stack": [span_id],
                "agent_key": agent_key,
            }
            if agent_key:
                self._agent_task_map[agent_key] = task_key
        return span_id

    def end_task_span(self, task_key: str) -> Optional[str]:
        """
        End a task's span tree.

        Args:
            task_key: The task identifier

        Returns:
            The root span ID that was ended, or None
        """
        with self._task_spans_lock:
            task_info = self._task_spans.pop(task_key, None)
            if task_info:
                agent_key = task_info.get("agent_key")
                if agent_key and self._agent_task_map.get(agent_key) == task_key:
                    self._agent_task_map.pop(agent_key, None)
                return task_info["root_span_id"]
        return None

    def get_task_parent_span(self, task_key: Optional[str] = None, agent_key: Optional[str] = None) -> Optional[str]:
        """
        Get the current parent span for a task.

        Args:
            task_key: The task identifier
            agent_key: Alternative - look up task by agent key

        Returns:
            The current parent span ID for the task, or crew/root span if not found
        """
        with self._task_spans_lock:
            # Try task_key first
            if task_key and task_key in self._task_spans:
                return self._task_spans[task_key]["current_span_id"]

            # Fall back to agent_key lookup
            if agent_key and agent_key in self._agent_task_map:
                task_key = self._agent_task_map[agent_key]
                if task_key in self._task_spans:
                    return self._task_spans[task_key]["current_span_id"]

        # Fall back to crew span or root span
        return self._crew_span_id or self._root_span_id

    def get_task_root_span(self, task_key: str) -> Optional[str]:
        """Get the root span ID for a task."""
        with self._task_spans_lock:
            task_info = self._task_spans.get(task_key)
            return task_info["root_span_id"] if task_info else None

    def push_task_span(self, task_key: str, span_id: str) -> None:
        """Push a child span onto a task's span stack."""
        with self._task_spans_lock:
            if task_key in self._task_spans:
                self._task_spans[task_key]["stack"].append(span_id)
                self._task_spans[task_key]["current_span_id"] = span_id

    def pop_task_span(self, task_key: str) -> Optional[str]:
        """Pop a span from a task's span stack."""
        with self._task_spans_lock:
            if task_key in self._task_spans:
                stack = self._task_spans[task_key]["stack"]
                if len(stack) > 1:  # Keep at least the root
                    popped = stack.pop()
                    self._task_spans[task_key]["current_span_id"] = stack[-1]
                    return popped
        return None

    def get_task_key_for_agent(self, agent_key: str) -> Optional[str]:
        """Get the current task key associated with an agent."""
        with self._task_spans_lock:
            return self._agent_task_map.get(agent_key)

    def associate_agent_with_task(self, agent_key: str, task_key: str) -> None:
        """Associate an agent with a task for event correlation."""
        with self._task_spans_lock:
            self._agent_task_map[agent_key] = task_key
            if task_key in self._task_spans:
                self._task_spans[task_key]["agent_key"] = agent_key

    def has_concurrent_tasks(self) -> bool:
        """Check if there are multiple concurrent tasks being tracked."""
        with self._task_spans_lock:
            return len(self._task_spans) > 1

    def emit(self, evt: dict[str, Any]) -> None:
        """Emit a trace event to the configured sink."""
        self.sink.write(evt)

    def _make_event(
        self,
        event_type: str,
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        status: str = "ok",
        summary: str = "",
        agent: Optional[dict[str, Any]] = None,
        workstream_id: Optional[str] = None,
        task_id: Optional[str] = None,
        attrs_compact: Optional[dict[str, Any]] = None,
        payload: Optional[dict[str, Any]] = None,
        raw_ref: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Create a fully-formed TraceEvent dict."""
        return {
            "schema_version": "trace_event.v0_1",
            "run_id": self.run_id,
            "tenant_id": self.tenant_id,
            "project_id": self.project_id,
            "trace_id": self.trace_id,
            "span_id": span_id or new_span_id(),
            "parent_span_id": parent_span_id,
            "seq": self.next_seq(),
            "ts": self.now(),
            "agent": agent,
            "workstream_id": workstream_id,
            "task_id": task_id,
            "event_type": event_type,
            "status": status,
            "summary": summary,
            "attrs_compact": attrs_compact or {},
            "payload": payload or {},
            "raw_ref": raw_ref or {"storage": "inline"},
        }

    def __enter__(self) -> "ArzuleRun":
        """Start the run context."""
        _active_run.set(self)
        self._root_span_id = new_span_id()

        self.emit(
            self._make_event(
                event_type="run.start",
                span_id=self._root_span_id,
                parent_span_id=None,
                status="ok",
                summary="run started",
            )
        )
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """End the run context and flush events."""
        status = "error" if exc else "ok"
        attrs = {}
        if exc:
            attrs["exc_type"] = exc_type.__name__ if exc_type else None
            attrs["exc_msg"] = str(exc)[:200] if exc else None

        self.emit(
            self._make_event(
                event_type="run.end",
                span_id=new_span_id(),
                parent_span_id=self._root_span_id,
                status=status,
                summary="run ended",
                attrs_compact=attrs,
            )
        )

        try:
            self.sink.flush()
        finally:
            _active_run.set(None)





