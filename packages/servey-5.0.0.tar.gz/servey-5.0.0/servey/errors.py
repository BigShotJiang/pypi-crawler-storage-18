class ServeyError(Exception):
    pass
