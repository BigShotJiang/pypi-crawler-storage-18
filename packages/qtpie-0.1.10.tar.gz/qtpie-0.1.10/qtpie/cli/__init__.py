"""QtPie CLI."""
