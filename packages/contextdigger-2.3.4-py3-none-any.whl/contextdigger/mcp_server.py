"""
ContextDigger MCP Server (Phase 12)

Local Model Context Protocol server that exposes ContextDigger functionality
to AI tools (Claude Desktop, Cursor, Windsurf, etc.).

Architecture:
- Pure Python, no external services
- Reads/writes .cdg/ directory directly
- Leverages existing service layer (no code duplication)
- Fully local, works offline

Resources Provided:
- cdg://areas - List all focus areas with metadata
- cdg://context/<area-id> - Governed context bundle for an area
- cdg://contracts - Active and recent continuation contracts
- cdg://governance - Current budget and policy status
- cdg://insights - Generated insights and recommendations
- cdg://provenance - File provenance for current session

Tools Provided:
- init_project - Initialize .cdg/ if missing
- dig_area - Set focus area and return governed context
- continue_work - Resume continuation contract
- pause_work - Pause current work and save state
- show_insights - Generate and return insights
- check_budget - Check budget compliance
- show_provenance - Get file provenance details
- list_areas - Get all areas with metadata
- export_context - Export area context to file

Key Design Decisions:
1. Local-only: No network calls, no external dependencies
2. Stateless: Each request reads current .cdg/ state
3. Governed: All context respects budget and policy limits
4. Idempotent: Safe to call tools multiple times
5. Descriptive errors: Clear messages for governance violations
"""

from pathlib import Path
from typing import Dict, List, Optional, Any
import json
from dataclasses import dataclass, asdict, field
from enum import Enum


# ============================================================================
# MCP Protocol Types
# ============================================================================


class ResourceType(Enum):
    """Types of resources exposed by the MCP server."""
    AREAS = "areas"
    CONTEXT = "context"
    CONTRACTS = "contracts"
    GOVERNANCE = "governance"
    INSIGHTS = "insights"
    PROVENANCE = "provenance"


class ToolType(Enum):
    """Types of tools provided by the MCP server."""
    INIT_PROJECT = "init_project"
    DIG_AREA = "dig_area"
    CONTINUE_WORK = "continue_work"
    PAUSE_WORK = "pause_work"
    SHOW_INSIGHTS = "show_insights"
    CHECK_BUDGET = "check_budget"
    SHOW_PROVENANCE = "show_provenance"
    LIST_AREAS = "list_areas"
    EXPORT_CONTEXT = "export_context"


@dataclass
class MCPResource:
    """Represents an MCP resource."""
    uri: str
    name: str
    description: str
    mimeType: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPTool:
    """Represents an MCP tool."""
    name: str
    description: str
    inputSchema: Dict[str, Any]
    outputSchema: Optional[Dict[str, Any]] = None


@dataclass
class MCPToolResult:
    """Result from executing an MCP tool."""
    success: bool
    data: Any
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# MCP Server
# ============================================================================


class ContextDiggerMCPServer:
    """
    Local MCP server for ContextDigger.

    Exposes ContextDigger functionality via Model Context Protocol,
    enabling AI tools to access governed context, areas, contracts,
    and insights directly.

    Usage:
        server = ContextDiggerMCPServer(project_root="/path/to/project")

        # List resources
        resources = server.list_resources()

        # Get resource content
        context = server.get_resource("cdg://context/backend-api")

        # Execute tools
        result = server.execute_tool("dig_area", {"area_id": "backend-api"})
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize MCP server.

        Args:
            project_root: Path to project root. If None, uses current directory.
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.cdg_dir = self.project_root / ".cdg"

        # Lazy-load manager only when needed
        self._manager = None

    @property
    def manager(self):
        """Lazy-load FocusManager."""
        if self._manager is None:
            from .manager import FocusManager
            self._manager = FocusManager(self.project_root)
        return self._manager

    # ========================================================================
    # Resource Handlers
    # ========================================================================

    def list_resources(self) -> List[MCPResource]:
        """
        List all available MCP resources.

        Returns:
            List of MCPResource objects
        """
        resources = []

        # cdg://areas - All focus areas
        all_areas = self.manager.areas.list_areas()
        resources.append(MCPResource(
            uri="cdg://areas",
            name="Focus Areas",
            description="List of all discovered code areas in the project",
            mimeType="application/json",
            metadata={"count": len(all_areas)}
        ))

        # cdg://context/<area-id> - Context for each area
        for area in all_areas:
            resources.append(MCPResource(
                uri=f"cdg://context/{area.id}",
                name=f"Context: {area.name}",
                description=f"Governed context bundle for {area.name}",
                mimeType="text/plain",
                metadata={
                    "area_id": area.id,
                    "area_type": area.type,
                    "language": area.metadata.get("language"),
                }
            ))

        # cdg://contracts - Continuation contracts
        resources.append(MCPResource(
            uri="cdg://contracts",
            name="Continuation Contracts",
            description="Active and recent continuation contracts",
            mimeType="application/json"
        ))

        # cdg://governance - Budget and policy status
        resources.append(MCPResource(
            uri="cdg://governance",
            name="Governance Status",
            description="Current budget limits, policy, and compliance status",
            mimeType="application/json"
        ))

        # cdg://insights - Generated insights
        resources.append(MCPResource(
            uri="cdg://insights",
            name="Insights & Recommendations",
            description="Intelligent insights from pattern detection",
            mimeType="application/json"
        ))

        # cdg://provenance - File provenance
        resources.append(MCPResource(
            uri="cdg://provenance",
            name="File Provenance",
            description="Provenance tracking for loaded files",
            mimeType="application/json"
        ))

        return resources

    def get_resource(self, uri: str) -> Dict[str, Any]:
        """
        Get content of an MCP resource.

        Args:
            uri: Resource URI (e.g., "cdg://areas", "cdg://context/backend-api")

        Returns:
            Resource content

        Raises:
            ValueError: If URI is invalid or resource not found
        """
        if not uri.startswith("cdg://"):
            raise ValueError(f"Invalid URI scheme: {uri}")

        path = uri[6:]  # Remove "cdg://" prefix

        # Handle different resource types
        if path == "areas":
            return self._get_areas_resource()
        elif path.startswith("context/"):
            area_id = path[8:]  # Remove "context/" prefix
            return self._get_context_resource(area_id)
        elif path == "contracts":
            return self._get_contracts_resource()
        elif path == "governance":
            return self._get_governance_resource()
        elif path == "insights":
            return self._get_insights_resource()
        elif path == "provenance":
            return self._get_provenance_resource()
        else:
            raise ValueError(f"Unknown resource path: {path}")

    def _get_areas_resource(self) -> Dict[str, Any]:
        """Get list of all areas."""
        all_areas = self.manager.areas.list_areas()
        areas = []
        for area in all_areas:
            areas.append({
                "id": area.id,
                "name": area.name,
                "description": area.description,
                "type": area.type,
                "language": area.metadata.get("language"),
                "file_count": len(area.patterns.get("include", [])),
                "metadata": area.metadata,
            })

        return {
            "total_areas": len(areas),
            "areas": areas,
        }

    def _get_context_resource(self, area_id: str) -> Dict[str, Any]:
        """
        Get governed context for an area.

        Args:
            area_id: Area identifier

        Returns:
            Context content with budget status
        """
        area = self.manager.areas.get_area(area_id)
        if not area:
            raise ValueError(f"Area not found: {area_id}")

        # Get governed context through ContextExporter
        from .export import ContextExporter
        exporter = ContextExporter(self.manager)

        # Export context (respects budget limits)
        context_file = self.cdg_dir / "context" / f"{area_id}.txt"
        exporter.export_area_context(area_id, context_file)

        # Read exported context
        with open(context_file, "r") as f:
            context_content = f.read()

        # Get budget status (if available)
        try:
            from .budget import BudgetTracker, BudgetStatus, PolicyManager
            policy_mgr = PolicyManager(self.project_root)
            policy = policy_mgr.get_active_policy()
            tracker = BudgetTracker(
                max_files=policy.max_files,
                max_lines=policy.max_lines,
                alert_thresholds=policy.alert_thresholds,
            )

            # Count files and lines in context
            files = context_content.count("File:")
            lines = len(context_content.split("\n"))
            budget = BudgetStatus(
                files_used=files,
                files_max=policy.max_files,
                lines_used=lines,
                lines_max=policy.max_lines,
            )

            budget_info = {
                "files_used": budget.files_used,
                "files_max": budget.files_max,
                "lines_used": budget.lines_used,
                "lines_max": budget.lines_max,
                "health": tracker.get_budget_health(budget),
            }
        except Exception:
            # Budget system not available or error occurred
            budget_info = None

        return {
            "area_id": area_id,
            "area_name": area.name,
            "context": context_content,
            "budget": budget_info,
        }

    def _get_contracts_resource(self) -> Dict[str, Any]:
        """Get continuation contracts."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        active = contract_mgr.get_active_contract()
        history = contract_mgr.get_contract_history(limit=10)

        return {
            "active_contract": active.to_dict() if active else None,
            "recent_contracts": [c.to_dict() for c in history],
        }

    def _get_governance_resource(self) -> Dict[str, Any]:
        """Get governance status."""
        from .budget import PolicyManager, BudgetTracker, BudgetStatus
        policy_mgr = PolicyManager(self.project_root)
        policy = policy_mgr.get_active_policy()

        # Create budget tracker
        tracker = BudgetTracker(
            max_files=policy.max_files,
            max_lines=policy.max_lines,
            alert_thresholds=policy.alert_thresholds,
        )

        # Get current session or default to 0
        files_used = 0
        lines_used = 0
        budget = BudgetStatus(
            files_used=files_used,
            files_max=policy.max_files,
            lines_used=lines_used,
            lines_max=policy.max_lines,
        )

        return {
            "policy": {
                "id": policy.policy_id,
                "name": policy.name,
                "enforcement_mode": policy.enforcement_mode.value,
                "max_files": policy.max_files,
                "max_lines": policy.max_lines,
            },
            "budget": {
                "files_used": budget.files_used,
                "files_max": budget.files_max,
                "lines_used": budget.lines_used,
                "lines_max": budget.lines_max,
                "health": tracker.get_budget_health(budget),
            },
        }

    def _get_insights_resource(self) -> Dict[str, Any]:
        """Get generated insights."""
        from .insights import InsightEngine
        engine = InsightEngine(self.project_root)
        insights = engine.generate_insights()

        return {
            "total_insights": len(insights),
            "insights": [i.to_dict() for i in insights],
            "summary": engine.get_summary(insights),
        }

    def _get_provenance_resource(self) -> Dict[str, Any]:
        """Get file provenance."""
        from .provenance import ProvenanceTracker
        tracker = ProvenanceTracker(self.project_root)

        # Get most recent session
        provenance_dir = self.cdg_dir / "provenance"
        if not provenance_dir.exists():
            return {"sessions": []}

        sessions = sorted(provenance_dir.glob("session-*.json"))
        if not sessions:
            return {"sessions": []}

        latest_session = sessions[-1].stem
        provenance = tracker.get_provenance(latest_session)

        return {
            "session_id": latest_session,
            "total_files": len(provenance),
            "provenance": provenance,
        }

    # ========================================================================
    # Tool Handlers
    # ========================================================================

    def list_tools(self) -> List[MCPTool]:
        """
        List all available MCP tools.

        Returns:
            List of MCPTool objects
        """
        return [
            MCPTool(
                name="init_project",
                description="Initialize ContextDigger in the project (creates .cdg/ directory)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="dig_area",
                description="Set focus to an area and return governed context",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                    },
                    "required": ["area_id"],
                },
            ),
            MCPTool(
                name="continue_work",
                description="Resume the active continuation contract",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="pause_work",
                description="Pause current work and save continuation contract",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_insights",
                description="Generate intelligent insights from usage patterns",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "level": {
                            "type": "string",
                            "enum": ["all", "critical", "warnings"],
                            "description": "Filter insights by level",
                        },
                    },
                },
            ),
            MCPTool(
                name="check_budget",
                description="Check budget compliance against governance policy",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_provenance",
                description="Show file provenance (why files were loaded)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="list_areas",
                description="List all discovered code areas",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="export_context",
                description="Export area context to file",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                        "output_file": {
                            "type": "string",
                            "description": "Output file path (optional)",
                        },
                    },
                    "required": ["area_id"],
                },
            ),
        ]

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> MCPToolResult:
        """
        Execute an MCP tool.

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            MCPToolResult with success status and data
        """
        try:
            if tool_name == "init_project":
                return self._tool_init_project()
            elif tool_name == "dig_area":
                return self._tool_dig_area(arguments["area_id"])
            elif tool_name == "continue_work":
                return self._tool_continue_work()
            elif tool_name == "pause_work":
                return self._tool_pause_work()
            elif tool_name == "show_insights":
                level = arguments.get("level", "all")
                return self._tool_show_insights(level)
            elif tool_name == "check_budget":
                return self._tool_check_budget()
            elif tool_name == "show_provenance":
                return self._tool_show_provenance()
            elif tool_name == "list_areas":
                return self._tool_list_areas()
            elif tool_name == "export_context":
                area_id = arguments["area_id"]
                output_file = arguments.get("output_file")
                return self._tool_export_context(area_id, output_file)
            else:
                return MCPToolResult(
                    success=False,
                    data=None,
                    error=f"Unknown tool: {tool_name}",
                )
        except Exception as e:
            return MCPToolResult(
                success=False,
                data=None,
                error=str(e),
            )

    def _tool_init_project(self) -> MCPToolResult:
        """Initialize .cdg/ directory."""
        if self.cdg_dir.exists():
            return MCPToolResult(
                success=True,
                data={"message": "Project already initialized"},
                metadata={"cdg_dir": str(self.cdg_dir)},
            )

        # Initialize through manager
        self.manager.initialize()

        return MCPToolResult(
            success=True,
            data={
                "message": "Project initialized successfully",
                "areas_discovered": len(self.manager.areas),
            },
            metadata={"cdg_dir": str(self.cdg_dir)},
        )

    def _tool_dig_area(self, area_id: str) -> MCPToolResult:
        """Dig into an area and return context."""
        area = self.manager.areas.get_area(area_id)
        if not area:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Area not found: {area_id}",
            )

        # Get context (governed by budget)
        context_data = self._get_context_resource(area_id)

        return MCPToolResult(
            success=True,
            data=context_data,
            metadata={"area_id": area_id},
        )

    def _tool_continue_work(self) -> MCPToolResult:
        """Resume continuation contract."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        contract = contract_mgr.get_active_contract()
        if not contract:
            return MCPToolResult(
                success=False,
                data=None,
                error="No active contract to resume",
            )

        return MCPToolResult(
            success=True,
            data=contract.to_dict(),
            metadata={"contract_id": contract.id},
        )

    def _tool_pause_work(self) -> MCPToolResult:
        """Pause current work."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        contract = contract_mgr.get_active_contract()
        if not contract:
            return MCPToolResult(
                success=False,
                data=None,
                error="No active contract to pause",
            )

        # Pause contract
        contract_mgr.pause_contract()

        return MCPToolResult(
            success=True,
            data={"message": "Work paused successfully"},
            metadata={"contract_id": contract.id},
        )

    def _tool_show_insights(self, level: str = "all") -> MCPToolResult:
        """Generate and return insights."""
        from .insights import InsightEngine, InsightLevel
        engine = InsightEngine(self.project_root)
        insights = engine.generate_insights()

        # Filter by level
        if level == "critical":
            insights = engine.get_insights_by_level(insights, InsightLevel.CRITICAL)
        elif level == "warnings":
            insights = engine.get_insights_by_level(insights, InsightLevel.WARNING)

        return MCPToolResult(
            success=True,
            data={
                "total_insights": len(insights),
                "insights": [i.to_dict() for i in insights],
            },
        )

    def _tool_check_budget(self) -> MCPToolResult:
        """Check budget compliance."""
        from .budget import PolicyManager, BudgetTracker, BudgetStatus
        policy_mgr = PolicyManager(self.project_root)
        policy = policy_mgr.get_active_policy()

        # Create tracker
        tracker = BudgetTracker(
            max_files=policy.max_files,
            max_lines=policy.max_lines,
            alert_thresholds=policy.alert_thresholds,
        )

        # Get current status (default to 0 if no active session)
        files_used = 0
        lines_used = 0
        budget = BudgetStatus(
            files_used=files_used,
            files_max=policy.max_files,
            lines_used=lines_used,
            lines_max=policy.max_lines,
        )

        # Check compliance
        is_compliant, violations = tracker.check_policy_compliance(budget, policy)

        return MCPToolResult(
            success=True,
            data={
                "compliant": is_compliant,
                "violations": violations,
                "budget": {
                    "files_used": budget.files_used,
                    "files_max": budget.files_max,
                    "lines_used": budget.lines_used,
                    "lines_max": budget.lines_max,
                    "health": tracker.get_budget_health(budget),
                },
            },
        )

    def _tool_show_provenance(self) -> MCPToolResult:
        """Show file provenance."""
        data = self._get_provenance_resource()

        return MCPToolResult(
            success=True,
            data=data,
        )

    def _tool_list_areas(self) -> MCPToolResult:
        """List all areas."""
        data = self._get_areas_resource()

        return MCPToolResult(
            success=True,
            data=data,
        )

    def _tool_export_context(
        self, area_id: str, output_file: Optional[str] = None
    ) -> MCPToolResult:
        """Export area context."""
        area = self.manager.areas.get_area(area_id)
        if not area:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Area not found: {area_id}",
            )

        # Determine output file
        if output_file:
            output_path = Path(output_file)
        else:
            output_path = self.cdg_dir / "context" / f"{area_id}.txt"

        # Export context
        from .export import ContextExporter
        exporter = ContextExporter(self.manager)
        exporter.export_area_context(area_id, output_path)

        return MCPToolResult(
            success=True,
            data={
                "message": "Context exported successfully",
                "output_file": str(output_path),
            },
            metadata={"area_id": area_id},
        )


# ============================================================================
# JSON-RPC Protocol Handler
# ============================================================================


class MCPProtocolHandler:
    """
    Handles JSON-RPC protocol for MCP server.

    Implements the Model Context Protocol specification for communication
    with AI tools via stdin/stdout.
    """

    def __init__(self, server: ContextDiggerMCPServer):
        """
        Initialize protocol handler.

        Args:
            server: ContextDiggerMCPServer instance
        """
        self.server = server
        import sys
        import logging

        self.stdin = sys.stdin
        self.stdout = sys.stdout
        self.logger = logging.getLogger(__name__)

    def run(self):
        """
        Run the JSON-RPC message loop.

        Reads JSON-RPC requests from stdin and writes responses to stdout.
        """
        self.logger.info("JSON-RPC message loop started")

        try:
            for line in self.stdin:
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    response = self.handle_request(request)

                    if response:
                        self.stdout.write(json.dumps(response) + "\n")
                        self.stdout.flush()

                except json.JSONDecodeError as e:
                    self.logger.error(f"Invalid JSON: {e}")
                    error_response = self._error_response(
                        None, -32700, "Parse error"
                    )
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

                except Exception as e:
                    self.logger.error(f"Error handling request: {e}", exc_info=True)
                    error_response = self._error_response(
                        None, -32603, f"Internal error: {str(e)}"
                    )
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

        except KeyboardInterrupt:
            self.logger.info("Server shutdown requested")
        except Exception as e:
            self.logger.error(f"Fatal error in message loop: {e}", exc_info=True)

    def handle_request(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle a JSON-RPC request.

        Args:
            request: JSON-RPC request object

        Returns:
            JSON-RPC response object or None for notifications
        """
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")

        self.logger.debug(f"Handling request: {method}")

        try:
            # Route to appropriate handler
            if method == "initialize":
                result = self._handle_initialize(params)
            elif method == "resources/list":
                result = self._handle_list_resources()
            elif method == "resources/read":
                result = self._handle_read_resource(params)
            elif method == "tools/list":
                result = self._handle_list_tools()
            elif method == "tools/call":
                result = self._handle_call_tool(params)
            elif method == "ping":
                result = {"status": "ok"}
            else:
                return self._error_response(request_id, -32601, f"Method not found: {method}")

            # Return response (None for notifications)
            if request_id is not None:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result,
                }

            return None

        except Exception as e:
            # Catch any errors and return as JSON-RPC error
            self.logger.error(f"Error in request handler: {e}", exc_info=True)
            return self._error_response(request_id, -32603, f"Internal error: {str(e)}")

    def _handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        return {
            "protocolVersion": "1.0",
            "serverInfo": {
                "name": "contextdigger",
                "version": "2.0.0",
            },
            "capabilities": {
                "resources": {"subscribe": False, "listChanged": False},
                "tools": {},
            },
        }

    def _handle_list_resources(self) -> Dict[str, Any]:
        """Handle resources/list request."""
        resources = self.server.list_resources()

        return {
            "resources": [
                {
                    "uri": r.uri,
                    "name": r.name,
                    "description": r.description,
                    "mimeType": r.mimeType,
                }
                for r in resources
            ]
        }

    def _handle_read_resource(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle resources/read request."""
        uri = params.get("uri")
        if not uri:
            raise ValueError("Missing required parameter: uri")

        content = self.server.get_resource(uri)

        return {
            "contents": [
                {
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps(content, indent=2),
                }
            ]
        }

    def _handle_list_tools(self) -> Dict[str, Any]:
        """Handle tools/list request."""
        tools = self.server.list_tools()

        return {
            "tools": [
                {
                    "name": t.name,
                    "description": t.description,
                    "inputSchema": t.inputSchema,
                }
                for t in tools
            ]
        }

    def _handle_call_tool(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        if not tool_name:
            raise ValueError("Missing required parameter: name")

        result = self.server.execute_tool(tool_name, arguments)

        if result.success:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(result.data, indent=2),
                    }
                ],
                "isError": False,
            }
        else:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Error: {result.error}",
                    }
                ],
                "isError": True,
            }

    def _error_response(
        self, request_id: Any, code: int, message: str
    ) -> Dict[str, Any]:
        """Create JSON-RPC error response."""
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            },
        }


# ============================================================================
# MCP Server Entry Point (for stdio mode)
# ============================================================================


def main():
    """
    Run MCP server in stdio mode for integration with AI tools.

    This is the entry point that will be called by AI tools like Claude Desktop.
    The server communicates via JSON-RPC over stdin/stdout.
    """
    import sys
    import logging

    # Set up logging to stderr (stdout is used for MCP protocol)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stderr,
    )

    logger = logging.getLogger(__name__)
    logger.info("Starting ContextDigger MCP Server...")

    # Initialize server with current directory
    server = ContextDiggerMCPServer()

    logger.info(f"Server initialized for project: {server.project_root}")
    logger.info(f"Available resources: {len(server.list_resources())}")
    logger.info(f"Available tools: {len(server.list_tools())}")

    # Run JSON-RPC protocol handler
    handler = MCPProtocolHandler(server)
    logger.info("Server ready - waiting for requests...")
    handler.run()

    logger.info("Server shutdown complete")


if __name__ == "__main__":
    main()
