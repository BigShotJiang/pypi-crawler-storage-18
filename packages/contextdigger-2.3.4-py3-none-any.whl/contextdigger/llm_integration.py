"""
Optional Local LLM Integration (Phase 13)

Provides AI-enhanced suggestions using local LLM via Ollama.
- Completely optional (ContextDigger works fine without it)
- Local-first (no external APIs, runs on your machine)
- Privacy-preserving (your code never leaves your computer)
- Configurable (supports any Ollama model)

Recommended: Qwen 3B for fast, lightweight suggestions
"""

from dataclasses import dataclass
from typing import List, Optional, Dict
import json
import subprocess
from pathlib import Path

from .trends import RemediationSuggestion, Trend, Prediction
from .insights import Insight, InsightLevel


# ============================================================================
# Configuration
# ============================================================================


@dataclass
class LLMConfig:
    """Configuration for local LLM integration."""

    enabled: bool = False  # Disabled by default
    provider: str = "ollama"  # Currently only ollama supported
    model: str = "qwen:3b"  # Default to Qwen 3B (fast, small)
    base_url: str = "http://localhost:11434"  # Default Ollama endpoint
    timeout: int = 30  # Timeout in seconds
    temperature: float = 0.7  # Creativity (0.0 = deterministic, 1.0 = creative)
    max_tokens: int = 500  # Max response length

    @classmethod
    def load_from_file(cls, config_file: Path) -> "LLMConfig":
        """Load configuration from file."""
        if not config_file.exists():
            return cls()  # Return disabled config

        try:
            with open(config_file, "r") as f:
                data = json.load(f)
            return cls(**data.get("llm", {}))
        except Exception:
            return cls()  # Return disabled config on error

    def save_to_file(self, config_file: Path) -> None:
        """Save configuration to file."""
        config_file.parent.mkdir(parents=True, exist_ok=True)

        # Load existing config
        if config_file.exists():
            with open(config_file, "r") as f:
                data = json.load(f)
        else:
            data = {}

        # Update LLM section
        data["llm"] = {
            "enabled": self.enabled,
            "provider": self.provider,
            "model": self.model,
            "base_url": self.base_url,
            "timeout": self.timeout,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

        # Save
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)


# ============================================================================
# Ollama Client
# ============================================================================


class OllamaClient:
    """
    Client for interacting with local Ollama instance.

    Ollama runs models like Qwen, Llama, Mistral, etc. locally.
    """

    def __init__(self, config: LLMConfig):
        """Initialize with configuration."""
        self.config = config

    def is_available(self) -> bool:
        """
        Check if Ollama is running and the model is available.

        Returns:
            True if Ollama is available, False otherwise
        """
        try:
            # Check if Ollama is running
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode != 0:
                return False

            # Check if our model is available
            model_name = self.config.model.split(":")[0]
            return model_name in result.stdout

        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            return False

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> Optional[str]:
        """
        Generate text using Ollama.

        Args:
            prompt: User prompt
            system_prompt: Optional system prompt

        Returns:
            Generated text or None if failed
        """
        if not self.config.enabled:
            return None

        if not self.is_available():
            return None

        try:
            # Build command
            cmd = [
                "ollama",
                "run",
                self.config.model,
            ]

            # Combine prompts
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\n{prompt}"

            # Run ollama
            result = subprocess.run(
                cmd,
                input=full_prompt,
                capture_output=True,
                text=True,
                timeout=self.config.timeout,
            )

            if result.returncode == 0:
                return result.stdout.strip()
            else:
                return None

        except (subprocess.TimeoutExpired, Exception):
            return None


# ============================================================================
# AI-Enhanced Suggester
# ============================================================================


class AIEnhancedSuggester:
    """
    Provides AI-enhanced suggestions using local LLM.

    Falls back gracefully if LLM is not available.
    """

    def __init__(self, cdg_dir: Path):
        """Initialize with .cdg directory."""
        self.cdg_dir = Path(cdg_dir)
        self.config = LLMConfig.load_from_file(self.cdg_dir / "config.json")
        self.client = OllamaClient(self.config) if self.config.enabled else None

    def enhance_remediation(
        self, suggestion: RemediationSuggestion, context: Optional[Dict] = None
    ) -> RemediationSuggestion:
        """
        Enhance a remediation suggestion with AI insights.

        Args:
            suggestion: Base remediation suggestion
            context: Optional context about the codebase

        Returns:
            Enhanced suggestion (or original if LLM not available)
        """
        if not self.client or not self.config.enabled:
            return suggestion  # Return original if LLM disabled

        if not self.client.is_available():
            return suggestion  # Return original if Ollama not running

        # Build prompt
        system_prompt = """You are a helpful code analysis assistant.
Provide specific, actionable suggestions for improving code organization and structure.
Be concise and practical. Focus on ContextDigger area management."""

        context_str = json.dumps(context, indent=2) if context else "No context provided"

        prompt = f"""Given this code issue:

Title: {suggestion.title}
Description: {suggestion.description}
Type: {suggestion.remediation_type.value}
Current Steps: {json.dumps(suggestion.steps, indent=2)}

Codebase Context:
{context_str}

Provide 2-3 additional specific, actionable suggestions that are tailored to this situation.
Be concise (max 3 sentences per suggestion)."""

        # Generate enhancement
        response = self.client.generate(prompt, system_prompt)

        if response:
            # Add AI suggestions to existing steps
            suggestion.steps.append("")
            suggestion.steps.append("AI-Enhanced Suggestions:")
            for line in response.split("\n"):
                if line.strip():
                    suggestion.steps.append(f"  • {line.strip()}")

            suggestion.metadata["ai_enhanced"] = True
            suggestion.metadata["ai_model"] = self.config.model

        return suggestion

    def generate_custom_insight(
        self, trends: List[Trend], predictions: List[Prediction], context: Dict
    ) -> Optional[str]:
        """
        Generate a custom insight summary using AI.

        Args:
            trends: Detected trends
            predictions: Predictions
            context: Codebase context

        Returns:
            AI-generated summary or None
        """
        if not self.client or not self.config.enabled:
            return None

        if not self.client.is_available():
            return None

        # Build prompt
        system_prompt = """You are a codebase health analyst.
Provide a brief executive summary of code health based on trends and predictions.
Be specific, actionable, and focus on key risks. Max 4 sentences."""

        trends_summary = "\n".join(
            [
                f"- {t.pattern_type.value}: {t.direction.value} (confidence: {t.confidence:.0%})"
                for t in trends[:5]
            ]
        )

        predictions_summary = "\n".join(
            [
                f"- {p.prediction_type}: {p.probability:.0%} within {p.timeframe} (risk: {p.risk_score:.0%})"
                for p in predictions[:5]
            ]
        )

        prompt = f"""Analyze this codebase health data:

TRENDS:
{trends_summary}

PREDICTIONS:
{predictions_summary}

CONTEXT:
- Total areas: {context.get('total_areas', 'unknown')}
- Active sessions: {context.get('active_sessions', 'unknown')}

Provide a brief executive summary (max 4 sentences) highlighting key risks and recommendations."""

        # Generate summary
        response = self.client.generate(prompt, system_prompt)
        return response

    def suggest_area_split(
        self, area_name: str, file_count: int, patterns: List[str]
    ) -> Optional[Dict]:
        """
        Get AI suggestions for how to split an oversized area.

        Args:
            area_name: Name of the area
            file_count: Number of files in area
            patterns: Current path patterns

        Returns:
            Dict with suggested sub-areas or None
        """
        if not self.client or not self.config.enabled:
            return None

        if not self.client.is_available():
            return None

        system_prompt = """You are a code organization expert.
Suggest logical sub-areas for splitting large code areas.
Output valid JSON with sub-area names and patterns."""

        prompt = f"""The code area '{area_name}' has {file_count} files and is too large.

Current patterns: {json.dumps(patterns, indent=2)}

Suggest 2-4 logical sub-areas to split this into.
For each sub-area, provide:
1. A descriptive name
2. Path patterns (glob format)
3. Brief description

Output as JSON:
{{
  "sub_areas": [
    {{"name": "...", "patterns": ["..."], "description": "..."}}
  ]
}}"""

        response = self.client.generate(prompt, system_prompt)

        if response:
            try:
                # Extract JSON from response
                # LLM might include extra text, so find JSON block
                start = response.find("{")
                end = response.rfind("}") + 1
                if start >= 0 and end > start:
                    json_str = response[start:end]
                    return json.loads(json_str)
            except json.JSONDecodeError:
                pass

        return None


# ============================================================================
# Integration Functions
# ============================================================================


def enable_llm(
    cdg_dir: Path,
    model: str = "qwen:3b",
    temperature: float = 0.7,
) -> bool:
    """
    Enable local LLM integration.

    Args:
        cdg_dir: Path to .cdg directory
        model: Ollama model to use (default: qwen:3b)
        temperature: Creativity setting (default: 0.7)

    Returns:
        True if successfully enabled, False if Ollama not available
    """
    # Check if Ollama is available
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False

    # Create and save config
    config = LLMConfig(
        enabled=True,
        model=model,
        temperature=temperature,
    )
    config.save_to_file(cdg_dir / "config.json")

    return True


def disable_llm(cdg_dir: Path) -> None:
    """Disable local LLM integration."""
    config = LLMConfig(enabled=False)
    config.save_to_file(cdg_dir / "config.json")


def get_llm_status(cdg_dir: Path) -> Dict:
    """
    Get status of LLM integration.

    Returns:
        Dict with status information
    """
    config = LLMConfig.load_from_file(cdg_dir / "config.json")

    if not config.enabled:
        return {
            "enabled": False,
            "status": "disabled",
            "message": "Local LLM integration is disabled",
        }

    client = OllamaClient(config)

    if not client.is_available():
        return {
            "enabled": True,
            "status": "unavailable",
            "model": config.model,
            "message": f"Ollama is not running or model '{config.model}' is not installed",
            "help": f"Install model with: ollama pull {config.model}",
        }

    return {
        "enabled": True,
        "status": "available",
        "model": config.model,
        "temperature": config.temperature,
        "message": f"Local LLM ready (using {config.model})",
    }
