"""
ContextDigger - Context Aperture Management for AI Coding Tools

Enforce attention budget limits through context aperture control.
Transform how AI tools interact with your codebase through focus discipline.

Key Concepts:
- Context Aperture: Constraint on file count (e.g., f/15 = 15 files max)
- Attention Budget: Maximum context AI can process effectively
- Focus Discipline: Practice of deliberately constraining context
- Context Scoping: Process of selecting optimal code areas

Narrower aperture (fewer files) = sharper AI focus.
"""

__version__ = "2.3.4"

from .manager import FocusManager, FocusArea, Session, Bookmark
from .discover import FocusAreaDiscovery, DiscoveryConfig

__all__ = [
    "FocusManager",
    "FocusArea",
    "Session",
    "Bookmark",
    "FocusAreaDiscovery",
    "DiscoveryConfig",
]
