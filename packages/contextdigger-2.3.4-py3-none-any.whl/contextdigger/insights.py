"""
ContextDigger Insights Engine (Phase 2.1)

Analyzes patterns in audit logs, usage data, and provenance to provide
actionable insights about codebase health and usage patterns.

Key Features:
- Budget hotspot detection
- Recurring violation pattern analysis
- Usage trend detection
- Smart recommendations based on patterns
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Optional, Dict
import json
from collections import defaultdict, Counter

from .budget import AuditLog, AuditEventType


# ============================================================================
# Enums
# ============================================================================


class PatternType(Enum):
    """Types of patterns that can be detected."""

    BUDGET_HOTSPOT = "budget_hotspot"
    RECURRING_VIOLATION = "recurring_violation"
    USAGE_SPIKE = "usage_spike"
    COMPLEXITY_INCREASE = "complexity_increase"
    FREQUENT_CHANGES = "frequent_changes"


class InsightLevel(Enum):
    """Severity levels for insights."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


# ============================================================================
# Pattern & Insight Dataclasses
# ============================================================================


@dataclass
class Pattern:
    """Represents a detected pattern in codebase usage."""

    pattern_type: PatternType
    description: str
    occurrences: int
    affected_areas: List[str]
    confidence: float  # 0.0-1.0
    metadata: Dict = field(default_factory=dict)
    detected_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        """Serialize pattern to dictionary."""
        return {
            "pattern_type": self.pattern_type.value,
            "description": self.description,
            "occurrences": self.occurrences,
            "affected_areas": self.affected_areas,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "detected_at": self.detected_at,
        }


@dataclass
class Insight:
    """Actionable insight derived from patterns."""

    level: InsightLevel
    title: str
    description: str
    pattern: Pattern
    recommendations: List[str]
    impact_score: float  # 0.0-1.0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        """Serialize insight to dictionary."""
        return {
            "level": self.level.value,
            "title": self.title,
            "description": self.description,
            "pattern": self.pattern.to_dict(),
            "recommendations": self.recommendations,
            "impact_score": self.impact_score,
            "created_at": self.created_at,
        }


# ============================================================================
# Pattern Detectors
# ============================================================================


class PatternDetector:
    """Base class for pattern detectors."""

    def __init__(self, project_root: Path):
        """Initialize pattern detector."""
        self.project_root = Path(project_root)
        self.audit_log = AuditLog(project_root)

    def detect_patterns(self) -> List[Pattern]:
        """Detect patterns. Override in subclasses."""
        raise NotImplementedError


class HotspotDetector(PatternDetector):
    """Detects areas that frequently exceed budget limits."""

    def __init__(self, project_root: Path, min_violations: int = 2):
        """
        Initialize hotspot detector.

        Args:
            project_root: Project root directory
            min_violations: Minimum violations to consider an area a hotspot
        """
        super().__init__(project_root)
        self.min_violations = min_violations

    def detect_patterns(self) -> List[Pattern]:
        """Detect budget hotspots."""
        patterns = []

        # Get all violation events
        violations = self.audit_log.get_entries(
            event_type=AuditEventType.POLICY_VIOLATION
        )

        if not violations:
            return patterns

        # Count violations by area
        area_violations = defaultdict(list)
        for entry in violations:
            area = entry.metadata.get("area", "unknown")
            area_violations[area].append(entry)

        # Detect hotspots
        for area, entries in area_violations.items():
            if len(entries) >= self.min_violations:
                # Calculate confidence based on frequency
                confidence = min(1.0, len(entries) / (self.min_violations * 2))

                # Calculate average budget overage
                total_overage = 0
                count = 0
                for entry in entries:
                    budget = entry.budget_status
                    if budget:
                        lines_over = budget.get("lines_used", 0) - budget.get("lines_max", 0)
                        files_over = budget.get("files_used", 0) - budget.get("files_max", 0)
                        if lines_over > 0 or files_over > 0:
                            total_overage += max(lines_over, files_over * 100)
                            count += 1

                avg_overage = total_overage / count if count > 0 else 0

                pattern = Pattern(
                    pattern_type=PatternType.BUDGET_HOTSPOT,
                    description=f"Area '{area}' frequently exceeds budget limits",
                    occurrences=len(entries),
                    affected_areas=[area],
                    confidence=confidence,
                    metadata={
                        "avg_overage": avg_overage,
                        "total_violations": len(entries),
                    },
                )
                patterns.append(pattern)

        return patterns


class ViolationPatternDetector(PatternDetector):
    """Detects recurring violation patterns."""

    def detect_patterns(self) -> List[Pattern]:
        """Detect recurring violation patterns."""
        patterns = []

        # Get all violation events
        violations = self.audit_log.get_entries(
            event_type=AuditEventType.POLICY_VIOLATION
        )

        if not violations:
            return patterns

        # Group by area
        area_violations = defaultdict(list)
        for entry in violations:
            area = entry.metadata.get("area", "unknown")
            area_violations[area].append(entry)

        # Analyze patterns
        for area, entries in area_violations.items():
            if len(entries) >= 2:
                # If area has multiple violations, consider it a recurring pattern
                # even if violation types differ
                total_violations = len(entries)
                confidence = min(1.0, total_violations / 3)  # 3+ violations = full confidence

                # Count all violations
                all_violations = []
                for entry in entries:
                    all_violations.extend(entry.violations)

                pattern = Pattern(
                    pattern_type=PatternType.RECURRING_VIOLATION,
                    description=f"Recurring policy violations in '{area}' ({total_violations} violations detected)",
                    occurrences=total_violations,
                    affected_areas=[area],
                    confidence=confidence,
                    metadata={
                        "total_violations": total_violations,
                        "unique_violations": len(set(all_violations)),
                    },
                )
                patterns.append(pattern)

            # Also analyze specific violation types if available
            violation_types = Counter()
            for entry in entries:
                for violation in entry.violations:
                    # Extract violation type (e.g., "Files exceeded", "Lines at 80%")
                    violation_type = violation.split(":")[0].strip()
                    violation_types[violation_type] += 1

            # Find most common violations (2+ occurrences)
            for violation_type, count in violation_types.most_common(3):
                if count >= 2:
                    confidence = min(1.0, count / len(entries))

                    pattern = Pattern(
                        pattern_type=PatternType.RECURRING_VIOLATION,
                        description=f"Recurring '{violation_type}' violations in '{area}'",
                        occurrences=count,
                        affected_areas=[area],
                        confidence=confidence,
                        metadata={
                            "violation_type": violation_type,
                            "total_in_area": len(entries),
                        },
                    )
                    patterns.append(pattern)

        return patterns


class UsageTrendDetector(PatternDetector):
    """Detects usage trends and frequently accessed areas."""

    def __init__(self, project_root: Path, min_events: int = 3):
        """
        Initialize usage trend detector.

        Args:
            project_root: Project root directory
            min_events: Minimum events to consider a trend
        """
        super().__init__(project_root)
        self.min_events = min_events

    def detect_patterns(self) -> List[Pattern]:
        """Detect usage trends."""
        patterns = []

        # Get all audit events
        all_events = self.audit_log.get_entries()

        if not all_events:
            return patterns

        # Count events by area
        area_events = defaultdict(int)
        for entry in all_events:
            area = entry.metadata.get("area")
            if area:
                area_events[area] += 1

        # Detect frequently used areas
        for area, count in area_events.items():
            if count >= self.min_events:
                # Calculate confidence
                total_events = len(all_events)
                frequency = count / total_events if total_events > 0 else 0
                confidence = min(1.0, frequency * 2)  # Scale up to 50% = full confidence

                pattern = Pattern(
                    pattern_type=PatternType.USAGE_SPIKE if count > self.min_events * 2 else PatternType.FREQUENT_CHANGES,
                    description=f"Area '{area}' is frequently accessed ({count} events)",
                    occurrences=count,
                    affected_areas=[area],
                    confidence=confidence,
                    metadata={
                        "event_count": count,
                        "frequency": frequency,
                    },
                )
                patterns.append(pattern)

        return patterns


# ============================================================================
# Insight Engine
# ============================================================================


class InsightEngine:
    """
    Main engine for generating insights from patterns.

    Coordinates pattern detectors and generates actionable insights.
    """

    def __init__(self, project_root: Path):
        """
        Initialize insight engine.

        Args:
            project_root: Project root directory
        """
        self.project_root = Path(project_root)
        self.audit_log = AuditLog(project_root)

        # Initialize detectors
        self.detectors = [
            HotspotDetector(project_root),
            ViolationPatternDetector(project_root),
            UsageTrendDetector(project_root),
        ]

    def generate_insights(self) -> List[Insight]:
        """
        Generate insights from all pattern detectors.

        Returns:
            List of Insight objects
        """
        insights = []

        # Run all detectors
        for detector in self.detectors:
            patterns = detector.detect_patterns()

            # Convert patterns to insights
            for pattern in patterns:
                insight = self._pattern_to_insight(pattern)
                if insight:
                    insights.append(insight)

        return insights

    def _pattern_to_insight(self, pattern: Pattern) -> Optional[Insight]:
        """
        Convert a pattern to an actionable insight.

        Args:
            pattern: Detected pattern

        Returns:
            Insight object or None
        """
        # Determine insight level based on pattern type and confidence
        if pattern.pattern_type == PatternType.BUDGET_HOTSPOT:
            if pattern.occurrences >= 5:
                level = InsightLevel.CRITICAL
                impact_score = 0.9
            elif pattern.occurrences >= 3:
                level = InsightLevel.WARNING
                impact_score = 0.7
            else:
                level = InsightLevel.INFO
                impact_score = 0.5

            title = f"Budget Hotspot: {pattern.affected_areas[0]}"
            description = f"This area has exceeded budget limits {pattern.occurrences} times. Consider optimization."

            recommendations = [
                "Split the area into smaller, more focused sub-areas",
                "Review file selection criteria to reduce scope",
                "Increase budget limits if this area requires more context",
                "Use bookmarks to focus on specific files instead of entire area",
            ]

        elif pattern.pattern_type == PatternType.RECURRING_VIOLATION:
            level = InsightLevel.WARNING
            impact_score = 0.6

            violation_type = pattern.metadata.get("violation_type", "policy violation")
            title = f"Recurring Violations: {pattern.affected_areas[0]}"
            description = f"'{violation_type}' violations occur frequently in this area ({pattern.occurrences} times)."

            recommendations = [
                f"Address the root cause of '{violation_type}' violations",
                "Adjust governance policy thresholds if violations are expected",
                "Refactor area to reduce complexity and size",
            ]

        elif pattern.pattern_type in [PatternType.USAGE_SPIKE, PatternType.FREQUENT_CHANGES]:
            level = InsightLevel.INFO
            impact_score = 0.4

            title = f"High Activity: {pattern.affected_areas[0]}"
            description = f"This area is accessed frequently ({pattern.occurrences} events), indicating high development activity."

            recommendations = [
                "Consider creating a continuation contract for ongoing work",
                "Document patterns and insights for this active area",
                "Ensure adequate test coverage for frequently changed code",
            ]

        else:
            # Default case
            level = InsightLevel.INFO
            impact_score = 0.3

            title = f"Pattern Detected: {pattern.pattern_type.value}"
            description = pattern.description

            recommendations = [
                "Review the pattern and determine appropriate action",
            ]

        # Adjust impact score based on confidence
        impact_score = impact_score * pattern.confidence

        return Insight(
            level=level,
            title=title,
            description=description,
            pattern=pattern,
            recommendations=recommendations,
            impact_score=impact_score,
        )

    def get_insights_by_level(self, insights: List[Insight], level: InsightLevel) -> List[Insight]:
        """Filter insights by level."""
        return [i for i in insights if i.level == level]

    def get_insights_by_area(self, insights: List[Insight], area: str) -> List[Insight]:
        """Filter insights by affected area."""
        return [i for i in insights if area in i.pattern.affected_areas]

    def get_top_insights(self, insights: List[Insight], limit: int = 10) -> List[Insight]:
        """Get top insights by impact score."""
        sorted_insights = sorted(insights, key=lambda i: i.impact_score, reverse=True)
        return sorted_insights[:limit]

    def save_insights(self, insights: List[Insight], output_file: Path) -> None:
        """
        Save insights to JSON file.

        Args:
            insights: List of insights to save
            output_file: Path to output file
        """
        data = {
            "generated_at": datetime.now().isoformat(),
            "total_insights": len(insights),
            "insights": [i.to_dict() for i in insights],
        }

        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, "w") as f:
            json.dump(data, f, indent=2)

    def load_insights(self, input_file: Path) -> List[Insight]:
        """
        Load insights from JSON file.

        Args:
            input_file: Path to input file

        Returns:
            List of Insight objects
        """
        if not input_file.exists():
            return []

        with open(input_file, "r") as f:
            data = json.load(f)

        insights = []
        for insight_data in data.get("insights", []):
            # Reconstruct pattern
            pattern_data = insight_data["pattern"]
            pattern = Pattern(
                pattern_type=PatternType(pattern_data["pattern_type"]),
                description=pattern_data["description"],
                occurrences=pattern_data["occurrences"],
                affected_areas=pattern_data["affected_areas"],
                confidence=pattern_data["confidence"],
                metadata=pattern_data.get("metadata", {}),
                detected_at=pattern_data.get("detected_at", ""),
            )

            # Reconstruct insight
            insight = Insight(
                level=InsightLevel(insight_data["level"]),
                title=insight_data["title"],
                description=insight_data["description"],
                pattern=pattern,
                recommendations=insight_data["recommendations"],
                impact_score=insight_data["impact_score"],
                created_at=insight_data.get("created_at", ""),
            )
            insights.append(insight)

        return insights

    def get_summary(self, insights: List[Insight]) -> Dict:
        """
        Get summary statistics for insights.

        Args:
            insights: List of insights

        Returns:
            Dictionary with summary statistics
        """
        if not insights:
            return {
                "total_insights": 0,
                "by_level": {},
                "by_type": {},
                "avg_impact_score": 0.0,
            }

        # Count by level
        by_level = Counter(i.level.value for i in insights)

        # Count by pattern type
        by_type = Counter(i.pattern.pattern_type.value for i in insights)

        # Calculate average impact score
        avg_impact = sum(i.impact_score for i in insights) / len(insights)

        return {
            "total_insights": len(insights),
            "by_level": dict(by_level),
            "by_type": dict(by_type),
            "avg_impact_score": avg_impact,
        }
