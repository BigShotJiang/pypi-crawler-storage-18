"""
ContextDigger Context Export

Generates AI-readable context files (.cdg/context/<area>.txt) that define
exactly what files an AI should load and work with.
"""

from pathlib import Path
from typing import List, Optional
from datetime import datetime


# Import TYPE_CHECKING to avoid circular imports
try:
    from contextdigger.provenance import ProvenanceTracker
except ImportError:
    ProvenanceTracker = None


class ContextExporter:
    """
    Exports context for AI tools.

    Generates .cdg/context/<area>.txt files that contain:
    - Instructions for the AI
    - List of files to load with descriptions
    - Budget information
    - Bookmarks and entry points
    """

    def __init__(self, project_root: Path, cdg_root: Path):
        """
        Initialize context exporter.

        Args:
            project_root: Root directory of the project
            cdg_root: .cdg directory path
        """
        self.project_root = Path(project_root)
        self.cdg_root = Path(cdg_root)
        self.context_dir = self.cdg_root / "context"

    def export_for_ai(
        self,
        area_name: str,
        area_description: str,
        files: List[Path],
        budget_status,  # BudgetStatus from budget.py
        bookmarks: Optional[List] = None,
        output_path: Optional[Path] = None,
        provenance_tracker: Optional["ProvenanceTracker"] = None,
        session_id: Optional[str] = None,
    ) -> Path:
        """
        Generate AI-readable context file.

        Args:
            area_name: Name of the area
            area_description: Description of the area
            files: List of files in the area
            budget_status: BudgetStatus object with budget information
            bookmarks: Optional list of bookmarks
            output_path: Optional custom output path
            provenance_tracker: Optional ProvenanceTracker for tracking file loads
            session_id: Optional session ID for provenance tracking

        Returns:
            Path to generated context file
        """
        # Track provenance for exported files
        if provenance_tracker and session_id:
            for file_path in files:
                # Get relative path for provenance
                try:
                    rel_path = file_path.relative_to(self.project_root)
                except ValueError:
                    rel_path = file_path

                provenance_tracker.track_file_load(
                    file_path=str(rel_path),
                    reason_type="export",
                    description=f"Exported as part of {area_name} area context",
                    loaded_by="export",
                    session_id=session_id,
                    area_id=area_name,
                )
        context_lines = []

        # Header
        context_lines.append(f"# ContextDigger Context: {area_name}")
        context_lines.append(f"# Area: {area_description}")
        context_lines.append(
            f"# Budget: {budget_status.files_used}/{budget_status.files_max} files, "
            f"{budget_status.lines_used:,}/{budget_status.lines_max:,} lines"
        )
        context_lines.append(f"# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        context_lines.append("")

        # Instructions
        context_lines.append("## Instructions")
        context_lines.append(f"You are working on the {area_name} area.")
        context_lines.append("Focus ONLY on the files listed below.")
        context_lines.append("Do not search for or read files outside this scope.")
        context_lines.append("")

        # Files to Load
        context_lines.append("## Files to Load")
        context_lines.append("")

        for i, file_path in enumerate(files, 1):
            # Get relative path
            try:
                rel_path = file_path.relative_to(self.project_root)
            except ValueError:
                rel_path = file_path

            # Count lines
            line_count = self._count_lines(file_path)

            context_lines.append(f"{i}. {rel_path}")
            context_lines.append(f"   - Lines: {line_count:,} lines")
            context_lines.append("")

        # Bookmarks (if any)
        if bookmarks:
            context_lines.append("## Bookmarks")
            for bookmark in bookmarks:
                context_lines.append(f"- {bookmark.path}:{bookmark.line} - {bookmark.name}")
            context_lines.append("")

        # File Provenance (if tracked)
        if provenance_tracker and session_id:
            context_lines.append("## File Provenance")
            context_lines.append("Why each file was included in this context:")
            context_lines.append("")

            for file_path in files:
                # Get relative path
                try:
                    rel_path = file_path.relative_to(self.project_root)
                except ValueError:
                    rel_path = file_path

                # Get provenance for this file
                file_prov = provenance_tracker.get_file_provenance(str(rel_path), session_id)
                if file_prov:
                    context_lines.append(f"**{rel_path}**")
                    for reason in file_prov.reasons:
                        context_lines.append(f"  - {reason.type}: {reason.description}")
                        if reason.source:
                            context_lines.append(f"    (source: {reason.source})")
                    context_lines.append("")

        # Attention Budget Used
        context_lines.append("## Attention Budget Used")
        context_lines.append(
            f"Files: {budget_status.files_used}/{budget_status.files_max} "
            f"({budget_status.percentage_files:.0%})"
        )
        context_lines.append(
            f"Lines: {budget_status.lines_used:,}/{budget_status.lines_max:,} "
            f"({budget_status.percentage_lines:.0%})"
        )

        status_symbol = "✓" if budget_status.within_budget else "⚠️"
        status_text = "Within budget" if budget_status.within_budget else "Exceeds budget"
        context_lines.append(f"Status: {status_text} {status_symbol}")
        context_lines.append("")

        # Usage instructions
        context_lines.append("## How to Use")
        context_lines.append("Load all files listed above into your context, then:")
        context_lines.append("1. Read and understand the codebase structure")
        context_lines.append("2. Make changes within this bounded scope")
        context_lines.append("3. Do not search for or modify files outside this list")
        context_lines.append("")

        # Write to file
        if output_path is None:
            self.context_dir.mkdir(parents=True, exist_ok=True)
            output_path = self.context_dir / f"{area_name}.txt"

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(context_lines))

        return output_path

    def _count_lines(self, file_path: Path) -> int:
        """
        Count lines in a file.

        Args:
            file_path: Path to file

        Returns:
            Number of lines in file
        """
        try:
            if not file_path.exists():
                return 0

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for _ in f)
        except Exception:
            return 0


def export_context_for_area(
    project_root: Path,
    cdg_root: Path,
    area_name: str,
    area_description: str,
    files: List[Path],
    budget_status,
    bookmarks: Optional[List] = None
) -> Path:
    """
    Convenience function to export context for an area.

    Args:
        project_root: Root directory of the project
        cdg_root: .cdg directory path
        area_name: Name of the area
        area_description: Description of the area
        files: List of files in the area
        budget_status: BudgetStatus object
        bookmarks: Optional list of bookmarks

    Returns:
        Path to generated context file
    """
    exporter = ContextExporter(project_root, cdg_root)
    return exporter.export_for_ai(
        area_name=area_name,
        area_description=area_description,
        files=files,
        budget_status=budget_status,
        bookmarks=bookmarks
    )
