"""
Sub-Area Analysis Engine for ContextDigger

Provides multi-strategy splitting of oversized focus areas using:
- Directory-based grouping
- Naming pattern clustering
- File role detection
- Import relationship analysis
- Hybrid multi-strategy approaches

Extracts file intelligence WITHOUT AI using:
- Docstring/comment parsing
- Import analysis
- Naming convention extraction
- Content pattern matching
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional, Set, Tuple
from collections import defaultdict, Counter
import re
import fnmatch


@dataclass
class FileInfo:
    """Extracted file intelligence (NO AI)."""
    path: Path
    lines: int
    language: str
    purpose: Optional[str] = None  # From docstrings/comments
    role: str = "unknown"  # test, model, controller, view, util, config
    imports: List[str] = field(default_factory=list)
    naming_components: List[str] = field(default_factory=list)  # CamelCase/snake_case parts
    test_file: bool = False
    framework_hints: List[str] = field(default_factory=list)


@dataclass
class SubAreaSuggestion:
    """Enhanced suggestion with metadata and tree support."""
    name: str
    description: str
    patterns: Dict[str, List[str]]
    files: List[Path]
    file_count: int
    line_count: int
    strategy: str  # "directory", "naming", "role", "import", "hybrid"
    confidence: float
    sample_files: List[FileInfo] = field(default_factory=list)  # First 5-10 with intelligence
    metadata: Dict[str, Any] = field(default_factory=dict)
    related_areas: List[str] = field(default_factory=list)
    children: List['SubAreaSuggestion'] = field(default_factory=list)  # For tree view
    depth: int = 0


@dataclass
class SplitAnalysis:
    """Complete analysis result."""
    original_area: str
    original_file_count: int
    original_line_count: int
    suggestions: List[SubAreaSuggestion]  # Top 10
    tree: Optional[SubAreaSuggestion] = None  # Root with recursive children
    coverage: float = 0.0  # % of files covered
    avg_confidence: float = 0.0


class SubAreaAnalyzer:
    """Multi-strategy sub-area analysis engine."""

    def __init__(self, project_root: Path, budget_tracker):
        self.project_root = project_root
        self.budget_tracker = budget_tracker
        self._file_info_cache: Dict[Path, FileInfo] = {}

    def analyze_area(
        self,
        files: List[Path],
        area_name: str,
        max_depth: int = 2
    ) -> SplitAnalysis:
        """
        Main entry point for sub-area analysis.

        Args:
            files: List of file paths in the oversized area
            area_name: Name of the original area
            max_depth: Maximum depth for hierarchical splitting

        Returns:
            Complete SplitAnalysis with suggestions and tree
        """
        # Extract file intelligence for all files (cached)
        file_infos = [self._get_file_info(f) for f in files]

        # Run multiple strategies
        suggestions = []
        suggestions.extend(self.suggest_by_directory(file_infos, area_name))
        suggestions.extend(self.suggest_by_naming_patterns(file_infos, area_name))
        suggestions.extend(self.suggest_by_role(file_infos, area_name))
        suggestions.extend(self.suggest_by_imports(file_infos, area_name))

        # Deduplicate and score
        suggestions = self._deduplicate_suggestions(suggestions)
        suggestions = sorted(suggestions, key=lambda s: s.confidence, reverse=True)[:10]

        # Calculate coverage
        covered_files = set()
        for suggestion in suggestions:
            covered_files.update(suggestion.files)
        coverage = len(covered_files) / len(files) if files else 0.0

        # Calculate average confidence
        avg_confidence = sum(s.confidence for s in suggestions) / len(suggestions) if suggestions else 0.0

        # Build hierarchical tree
        tree = self.build_hierarchy(suggestions, files, area_name, max_depth)

        return SplitAnalysis(
            original_area=area_name,
            original_file_count=len(files),
            original_line_count=sum(fi.lines for fi in file_infos),
            suggestions=suggestions,
            tree=tree,
            coverage=coverage,
            avg_confidence=avg_confidence
        )

    def suggest_by_directory(
        self,
        file_infos: List[FileInfo],
        area_name: str
    ) -> List[SubAreaSuggestion]:
        """Group files by parent directory at depths 1-3."""
        suggestions = []

        for depth in [1, 2, 3]:
            dir_groups = defaultdict(list)

            for fi in file_infos:
                # Get directory at specified depth
                parts = fi.path.parts
                if len(parts) > depth:
                    dir_key = "/".join(parts[:depth])
                    dir_groups[dir_key].append(fi)

            # Create suggestions from groups
            for dir_path, group_files in dir_groups.items():
                if len(group_files) < 3:  # Skip tiny groups
                    continue

                file_paths = [fi.path for fi in group_files]
                file_count = len(file_paths)
                line_count = sum(fi.lines for fi in group_files)

                # Validate against budget
                if not self._is_within_budget(file_count, line_count):
                    continue

                # Generate name and description
                dir_name = Path(dir_path).name
                name = f"{area_name}-{dir_name}".lower().replace("_", "-")
                description = f"Files in {dir_path} directory"

                # Detect common language
                languages = [fi.language for fi in group_files]
                common_lang = Counter(languages).most_common(1)[0][0] if languages else "unknown"

                suggestions.append(SubAreaSuggestion(
                    name=name,
                    description=description,
                    patterns={
                        "include": [f"{dir_path}/**/*"],
                        "exclude": []
                    },
                    files=file_paths,
                    file_count=file_count,
                    line_count=line_count,
                    strategy="directory",
                    confidence=0.8,  # Directory-based is highly reliable
                    sample_files=group_files[:5],
                    metadata={
                        "language": common_lang,
                        "directory_depth": depth,
                        "directory_path": dir_path
                    }
                ))

        return suggestions

    def suggest_by_naming_patterns(
        self,
        file_infos: List[FileInfo],
        area_name: str
    ) -> List[SubAreaSuggestion]:
        """Find common naming components (Account*, Opportunity*, etc.)."""
        suggestions = []

        # Extract all naming components
        all_components = []
        for fi in file_infos:
            all_components.extend(fi.naming_components)

        # Find common components (appear in 3+ files)
        component_counts = Counter(all_components)
        common_components = [
            comp for comp, count in component_counts.items()
            if count >= 3 and len(comp) > 2  # At least 3 files, component length > 2
        ]

        # Group files by common components
        for component in common_components[:10]:  # Limit to top 10
            matching_files = [
                fi for fi in file_infos
                if component in fi.naming_components
            ]

            if len(matching_files) < 3:
                continue

            file_paths = [fi.path for fi in matching_files]
            file_count = len(file_paths)
            line_count = sum(fi.lines for fi in matching_files)

            if not self._is_within_budget(file_count, line_count):
                continue

            # Generate pattern
            pattern = f"**/*{component.title()}*"
            name = f"{area_name}-{component.lower()}"
            description = f"Files related to {component.title()}"

            # Detect common language
            languages = [fi.language for fi in matching_files]
            common_lang = Counter(languages).most_common(1)[0][0] if languages else "unknown"

            suggestions.append(SubAreaSuggestion(
                name=name,
                description=description,
                patterns={
                    "include": [pattern],
                    "exclude": []
                },
                files=file_paths,
                file_count=file_count,
                line_count=line_count,
                strategy="naming",
                confidence=0.7,
                sample_files=matching_files[:5],
                metadata={
                    "language": common_lang,
                    "naming_component": component
                }
            ))

        return suggestions

    def suggest_by_role(
        self,
        file_infos: List[FileInfo],
        area_name: str
    ) -> List[SubAreaSuggestion]:
        """Group by file role (test, model, controller, view, util, config)."""
        suggestions = []

        # Group by role
        role_groups = defaultdict(list)
        for fi in file_infos:
            role_groups[fi.role].append(fi)

        # Create suggestions for each role
        for role, group_files in role_groups.items():
            if role == "unknown" or len(group_files) < 3:
                continue

            file_paths = [fi.path for fi in group_files]
            file_count = len(file_paths)
            line_count = sum(fi.lines for fi in group_files)

            if not self._is_within_budget(file_count, line_count):
                continue

            name = f"{area_name}-{role}s"
            description = f"{role.title()} files"

            # Detect common language
            languages = [fi.language for fi in group_files]
            common_lang = Counter(languages).most_common(1)[0][0] if languages else "unknown"

            suggestions.append(SubAreaSuggestion(
                name=name,
                description=description,
                patterns={
                    "include": ["**/*"],  # Generic pattern, refined by role detection
                    "exclude": []
                },
                files=file_paths,
                file_count=file_count,
                line_count=line_count,
                strategy="role",
                confidence=0.65,
                sample_files=group_files[:5],
                metadata={
                    "language": common_lang,
                    "file_role": role
                }
            ))

        return suggestions

    def suggest_by_imports(
        self,
        file_infos: List[FileInfo],
        area_name: str
    ) -> List[SubAreaSuggestion]:
        """Cluster by import relationships."""
        suggestions = []

        # Extract common imports (appear in 3+ files)
        all_imports = []
        for fi in file_infos:
            all_imports.extend(fi.imports)

        import_counts = Counter(all_imports)
        common_imports = [
            imp for imp, count in import_counts.items()
            if count >= 3
        ]

        # Group files by common imports
        for common_import in common_imports[:10]:  # Limit to top 10
            matching_files = [
                fi for fi in file_infos
                if common_import in fi.imports
            ]

            if len(matching_files) < 3:
                continue

            file_paths = [fi.path for fi in matching_files]
            file_count = len(file_paths)
            line_count = sum(fi.lines for fi in matching_files)

            if not self._is_within_budget(file_count, line_count):
                continue

            # Generate name from import
            import_name = common_import.split(".")[-1].split("/")[-1]
            name = f"{area_name}-{import_name.lower()}"
            description = f"Files importing {common_import}"

            # Detect common language
            languages = [fi.language for fi in matching_files]
            common_lang = Counter(languages).most_common(1)[0][0] if languages else "unknown"

            suggestions.append(SubAreaSuggestion(
                name=name,
                description=description,
                patterns={
                    "include": ["**/*"],
                    "exclude": []
                },
                files=file_paths,
                file_count=file_count,
                line_count=line_count,
                strategy="import",
                confidence=0.6,
                sample_files=matching_files[:5],
                metadata={
                    "language": common_lang,
                    "common_import": common_import
                }
            ))

        return suggestions

    def build_hierarchy(
        self,
        suggestions: List[SubAreaSuggestion],
        original_files: List[Path],
        area_name: str,
        max_depth: int
    ) -> SubAreaSuggestion:
        """Build hierarchical tree with recursive splitting."""
        # Create root node
        root = SubAreaSuggestion(
            name=area_name,
            description=f"Root area with {len(original_files)} files",
            patterns={"include": ["**/*"], "exclude": []},
            files=original_files,
            file_count=len(original_files),
            line_count=sum(self._get_file_info(f).lines for f in original_files),
            strategy="root",
            confidence=1.0,
            depth=0
        )

        # Add top-level suggestions as children
        for suggestion in suggestions:
            suggestion.depth = 1
            root.children.append(suggestion)

            # Recursively split children if needed
            if max_depth > 1:
                self._recursive_split(suggestion, current_depth=1, max_depth=max_depth)

        return root

    def _recursive_split(
        self,
        suggestion: SubAreaSuggestion,
        current_depth: int,
        max_depth: int
    ):
        """Recursively split until under budget or max depth reached."""
        # Stop conditions
        if current_depth >= max_depth:
            return

        if self._is_within_budget(suggestion.file_count, suggestion.line_count):
            return  # Under budget, no need to split

        # Analyze files for further splits
        file_infos = [self._get_file_info(f) for f in suggestion.files]

        # Use simpler strategies for deeper splits
        sub_suggestions = []
        sub_suggestions.extend(self.suggest_by_directory(file_infos, suggestion.name))
        sub_suggestions.extend(self.suggest_by_naming_patterns(file_infos, suggestion.name))

        # Deduplicate and take top 5
        sub_suggestions = self._deduplicate_suggestions(sub_suggestions)
        sub_suggestions = sorted(sub_suggestions, key=lambda s: s.confidence, reverse=True)[:5]

        # Add as children and recurse
        for sub in sub_suggestions:
            sub.depth = current_depth + 1
            suggestion.children.append(sub)
            self._recursive_split(sub, current_depth + 1, max_depth)

    def _get_file_info(self, file_path: Path) -> FileInfo:
        """Get or create cached FileInfo."""
        if file_path in self._file_info_cache:
            return self._file_info_cache[file_path]

        file_info = self._extract_file_intelligence(file_path)
        self._file_info_cache[file_path] = file_info
        return file_info

    def _extract_file_intelligence(self, file_path: Path) -> FileInfo:
        """Extract metadata WITHOUT AI."""
        try:
            content = file_path.read_text(errors='ignore')
        except Exception:
            content = ""

        lines = len(content.splitlines())
        language = self._detect_language(file_path)
        purpose = self._extract_purpose_from_docstring(content, language)
        role = self._detect_file_role(file_path, content)
        imports = self._extract_imports(content, language)
        naming = self._extract_naming_components(file_path)
        test_file = role == "test"
        framework_hints = self._detect_framework_hints(content, language)

        return FileInfo(
            path=file_path,
            lines=lines,
            language=language,
            purpose=purpose,
            role=role,
            imports=imports,
            naming_components=naming,
            test_file=test_file,
            framework_hints=framework_hints
        )

    def _detect_language(self, file_path: Path) -> str:
        """Detect programming language from file extension."""
        ext = file_path.suffix.lower()
        language_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.tsx': 'typescript',
            '.jsx': 'javascript',
            '.cls': 'apex',
            '.trigger': 'apex',
            '.java': 'java',
            '.rb': 'ruby',
            '.go': 'go',
            '.rs': 'rust',
            '.php': 'php',
            '.astro': 'astro',
            '.vue': 'vue',
            '.svelte': 'svelte'
        }
        return language_map.get(ext, 'unknown')

    def _extract_purpose_from_docstring(self, content: str, language: str) -> Optional[str]:
        """Parse module docstring or top comment."""
        if not content:
            return None

        if language == "python":
            # Module docstring
            match = re.search(r'^"""(.*?)"""', content, re.MULTILINE | re.DOTALL)
            if match:
                lines = match.group(1).strip().split('\n')
                return lines[0][:100] if lines else None

            # Top comment
            match = re.search(r'^#\s*(.*?)$', content, re.MULTILINE)
            if match:
                return match.group(1).strip()[:100]

        elif language in ["javascript", "typescript"]:
            # JSDoc or block comment
            match = re.search(r'/\*\*\n\s*\*\s*(.*?)\n', content)
            if match:
                return match.group(1).strip()[:100]

            # Single line comment at top
            match = re.search(r'^//\s*(.*?)$', content, re.MULTILINE)
            if match:
                return match.group(1).strip()[:100]

        elif language == "apex":
            # Apex comment
            match = re.search(r'/\*\*\n\s*\*\s*(.*?)\n', content)
            if match:
                return match.group(1).strip()[:100]

        return None

    def _detect_file_role(self, file_path: Path, content: str) -> str:
        """Detect: test, model, controller, view, util, config."""
        name_lower = file_path.name.lower()

        # Test files
        if any(x in name_lower for x in ['test', 'spec', '_test.', '.test.', 'Test.cls']):
            return "test"

        # Config
        if 'config' in name_lower or 'settings' in name_lower:
            return "config"

        # Models
        if 'model' in name_lower or 'schema' in name_lower:
            return "model"

        # Controllers
        if 'controller' in name_lower or 'handler' in name_lower:
            return "controller"

        # Views/UI
        if any(x in name_lower for x in ['view', 'component', 'page', '.astro', '.vue']):
            return "view"

        # Utils
        if 'util' in name_lower or 'helper' in name_lower:
            return "util"

        # Content analysis
        if content:
            if re.search(r'class.*Controller|def.*handler', content):
                return "controller"
            if re.search(r'class.*Model|@entity|schema =', content, re.IGNORECASE):
                return "model"

        return "unknown"

    def _extract_imports(self, content: str, language: str) -> List[str]:
        """Extract imports with regex."""
        imports = []

        if not content:
            return imports

        if language == "python":
            # import foo
            matches = re.findall(r'^import\s+([\w.]+)', content, re.MULTILINE)
            imports.extend(matches)
            # from foo import bar
            matches = re.findall(r'^from\s+([\w.]+)', content, re.MULTILINE)
            imports.extend(matches)

        elif language in ["javascript", "typescript"]:
            # import foo from 'bar'
            matches = re.findall(r'import.*from\s+[\'"]([^\'"]+)[\'"]', content)
            imports.extend(matches)
            # require('foo')
            matches = re.findall(r'require\([\'"]([^\'"]+)[\'"]\)', content)
            imports.extend(matches)

        elif language == "apex":
            # No standard imports in Apex (uses namespaces differently)
            pass

        return imports[:20]  # Limit to first 20 imports

    def _extract_naming_components(self, file_path: Path) -> List[str]:
        """Extract CamelCase/snake_case parts."""
        stem = file_path.stem
        components = []

        # Split snake_case
        if '_' in stem:
            components.extend(stem.split('_'))

        # Split CamelCase
        camel_parts = re.findall(r'[A-Z][a-z]+|[a-z]+', stem)
        components.extend(camel_parts)

        # Remove noise words
        noise = {'test', 'spec', 'index', 'main', 'app', 'base', 'default'}
        cleaned = [c.lower() for c in components if c.lower() not in noise and len(c) > 2]

        return list(set(cleaned))  # Unique components

    def _detect_framework_hints(self, content: str, language: str) -> List[str]:
        """Detect framework usage from imports and patterns."""
        hints = []

        if not content:
            return hints

        # Common framework patterns
        framework_patterns = {
            'react': r'from\s+[\'"]react[\'"]|import\s+React',
            'vue': r'from\s+[\'"]vue[\'"]|import\s+Vue',
            'angular': r'from\s+[\'"]@angular',
            'express': r'from\s+[\'"]express[\'"]',
            'django': r'from\s+django\.',
            'flask': r'from\s+flask',
            'fastapi': r'from\s+fastapi',
            'pytest': r'import\s+pytest',
            'jest': r'from\s+[\'"]@jest',
            'mocha': r'from\s+[\'"]mocha[\'"]'
        }

        for framework, pattern in framework_patterns.items():
            if re.search(pattern, content):
                hints.append(framework)

        return hints

    def _is_within_budget(self, file_count: int, line_count: int) -> bool:
        """Check if counts are within budget."""
        return (
            file_count <= self.budget_tracker.max_files and
            line_count <= self.budget_tracker.max_lines
        )

    def _deduplicate_suggestions(
        self,
        suggestions: List[SubAreaSuggestion]
    ) -> List[SubAreaSuggestion]:
        """Remove duplicate suggestions based on file overlap."""
        unique = []
        seen_file_sets = []

        for suggestion in suggestions:
            file_set = set(suggestion.files)

            # Check overlap with existing suggestions
            is_duplicate = False
            for seen_set in seen_file_sets:
                overlap = len(file_set & seen_set) / len(file_set) if file_set else 0
                if overlap > 0.8:  # 80% overlap = duplicate
                    is_duplicate = True
                    break

            if not is_duplicate:
                unique.append(suggestion)
                seen_file_sets.append(file_set)

        return unique


class VerbosityRenderer:
    """Renders SplitAnalysis at different verbosity levels."""

    def __init__(self, budget_tracker):
        self.budget_tracker = budget_tracker

    def render_compact(self, analysis: SplitAnalysis) -> str:
        """Default: Show top 4 suggestions with basic info."""
        lines = []
        lines.append(f"\n{'='*60}")
        lines.append(f"📊 Sub-Area Analysis: {analysis.original_area}")
        lines.append(f"{'='*60}")
        lines.append(f"Original: {analysis.original_file_count} files, {analysis.original_line_count:,} lines")
        lines.append(f"Budget Limit: {self.budget_tracker.max_files} files, {self.budget_tracker.max_lines:,} lines")
        lines.append(f"Coverage: {analysis.coverage*100:.1f}% | Avg Confidence: {analysis.avg_confidence*100:.1f}%\n")

        top_suggestions = analysis.suggestions[:4]
        for i, suggestion in enumerate(top_suggestions, 1):
            status = "✓" if suggestion.file_count <= self.budget_tracker.max_files else "⚠️"
            lines.append(f"{i}. {status} {suggestion.name}")
            lines.append(f"   {suggestion.file_count} files, {suggestion.line_count:,} lines")
            lines.append(f"   Strategy: {suggestion.strategy} | Confidence: {suggestion.confidence*100:.0f}%")
            lines.append(f"   {suggestion.description}\n")

        lines.append(f"Showing top {len(top_suggestions)} of {len(analysis.suggestions)} suggestions")
        lines.append(f"{'='*60}\n")

        return "\n".join(lines)

    def render_horizontal_verbose(self, analysis: SplitAnalysis) -> str:
        """Show file previews, patterns, metadata, related areas."""
        lines = []
        lines.append(f"\n{'='*80}")
        lines.append(f"📊 DETAILED Sub-Area Analysis: {analysis.original_area}")
        lines.append(f"{'='*80}")
        lines.append(f"Original: {analysis.original_file_count} files, {analysis.original_line_count:,} lines")
        lines.append(f"Budget Limit: {self.budget_tracker.max_files} files, {self.budget_tracker.max_lines:,} lines")
        lines.append(f"Coverage: {analysis.coverage*100:.1f}% | Avg Confidence: {analysis.avg_confidence*100:.1f}%\n")

        for i, suggestion in enumerate(analysis.suggestions[:6], 1):
            status = "✓" if suggestion.file_count <= self.budget_tracker.max_files else "⚠️"
            lines.append(f"\n{'-'*80}")
            lines.append(f"{i}. {status} {suggestion.name}")
            lines.append(f"{'-'*80}")
            lines.append(f"Files: {suggestion.file_count} | Lines: {suggestion.line_count:,} | Strategy: {suggestion.strategy}")
            lines.append(f"Confidence: {suggestion.confidence*100:.0f}% | {suggestion.description}\n")

            # Patterns
            lines.append("📋 Patterns:")
            for pattern in suggestion.patterns.get('include', [])[:3]:
                lines.append(f"   Include: {pattern}")
            if suggestion.patterns.get('exclude'):
                lines.append(f"   Exclude: {suggestion.patterns['exclude'][0]}")

            # Metadata
            if suggestion.metadata:
                lines.append("\n🏷️  Metadata:")
                for key, value in list(suggestion.metadata.items())[:4]:
                    lines.append(f"   {key}: {value}")

            # Sample files with intelligence
            if suggestion.sample_files:
                lines.append("\n📁 Sample Files (with intelligence):")
                for fi in suggestion.sample_files[:5]:
                    rel_path = fi.path.relative_to(self.budget_tracker.project_root if hasattr(self.budget_tracker, 'project_root') else Path.cwd())
                    lines.append(f"   • {rel_path} ({fi.lines} lines)")
                    if fi.purpose:
                        lines.append(f"     Purpose: {fi.purpose[:60]}")
                    if fi.role != "unknown":
                        lines.append(f"     Role: {fi.role}")
                    if fi.imports:
                        top_imports = ", ".join(fi.imports[:3])
                        lines.append(f"     Imports: {top_imports}")

            # Related areas
            if suggestion.related_areas:
                lines.append(f"\n🔗 Related: {', '.join(suggestion.related_areas[:3])}")

        lines.append(f"\n{'='*80}")
        lines.append(f"Showing {min(6, len(analysis.suggestions))} of {len(analysis.suggestions)} suggestions")
        lines.append(f"{'='*80}\n")

        return "\n".join(lines)

    def render_vertical_verbose(self, analysis: SplitAnalysis) -> str:
        """Show full hierarchical tree with box-drawing."""
        lines = []
        lines.append(f"\n{'='*80}")
        lines.append(f"🌳 HIERARCHICAL Tree View: {analysis.original_area}")
        lines.append(f"{'='*80}")
        lines.append(f"Budget Limit: {self.budget_tracker.max_files} files, {self.budget_tracker.max_lines:,} lines\n")

        if analysis.tree:
            self._render_tree_node(analysis.tree, lines, "", True)

        lines.append(f"\n{'='*80}")
        lines.append("Legend: ✓ = Under budget | ⚠️  = Over budget | 📁 = Leaf node")
        lines.append(f"{'='*80}\n")

        return "\n".join(lines)

    def _render_tree_node(
        self,
        node: SubAreaSuggestion,
        lines: List[str],
        prefix: str,
        is_last: bool
    ):
        """Recursively render tree node with box-drawing characters."""
        # Determine status
        if node.file_count <= self.budget_tracker.max_files:
            status = "✓"
        else:
            status = "⚠️"

        # Build line
        connector = "└─ " if is_last else "├─ "
        if node.depth == 0:
            line = f"{status} {node.name} ({node.file_count} files, {node.line_count:,} lines)"
        else:
            line = f"{prefix}{connector}{status} {node.name} ({node.file_count} files)"

        lines.append(line)

        # Render children
        if node.children:
            child_prefix = prefix + ("   " if is_last else "│  ")
            for i, child in enumerate(node.children):
                is_last_child = (i == len(node.children) - 1)
                self._render_tree_node(child, lines, child_prefix, is_last_child)
