"""File Provenance Tracking System.

This module tracks WHY files were loaded into context, providing transparent
accountability for all context decisions. Every file included in a context
bundle must have at least one provenance reason.

Key Concepts:
    - FileProvenance: Records why a specific file was loaded
    - ProvenanceReason: Individual justification for loading (e.g., dependency, bookmark)
    - ProvenanceTracker: Manages provenance tracking and persistence

Design Principles:
    - 100% Coverage: Every file in context must have provenance
    - Multi-Reason: Files can have multiple reasons (entry point + bookmark + dependency)
    - Session-Scoped: Provenance is tracked per session for auditability
    - Explainable: All reasons include human-readable descriptions
"""

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional, Dict
from datetime import datetime


@dataclass
class ProvenanceReason:
    """Individual reason for loading a file into context.

    Attributes:
        type: Category of reason (entry_point, dependency, bookmark, etc.)
        description: Human-readable explanation
        source: File or area that caused this load (if applicable)
        confidence: How confident we are this reason is valid (0.0-1.0)
    """

    type: str
    description: str
    source: Optional[str] = None
    confidence: float = 1.0

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return asdict(self)

    @staticmethod
    def from_dict(data: Dict) -> "ProvenanceReason":
        """Create from dictionary."""
        return ProvenanceReason(
            type=data["type"],
            description=data["description"],
            source=data.get("source"),
            confidence=data.get("confidence", 1.0),
        )


@dataclass
class FileProvenance:
    """Tracks why a file was loaded into context.

    Attributes:
        file_path: Path to the file (relative to project root)
        reasons: List of reasons why this file was loaded
        loaded_by: What triggered the load (dig, export, split, suggest)
        loaded_at: ISO timestamp when file was loaded
        session_id: Session that loaded this file
        area_id: Focus area context (None for exports)
    """

    file_path: str
    reasons: List[ProvenanceReason]
    loaded_by: str
    loaded_at: str
    session_id: str
    area_id: Optional[str] = None

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            "file_path": self.file_path,
            "reasons": [r.to_dict() for r in self.reasons],
            "loaded_by": self.loaded_by,
            "loaded_at": self.loaded_at,
            "session_id": self.session_id,
            "area_id": self.area_id,
        }

    @staticmethod
    def from_dict(data: Dict) -> "FileProvenance":
        """Create from dictionary."""
        return FileProvenance(
            file_path=data["file_path"],
            reasons=[ProvenanceReason.from_dict(r) for r in data["reasons"]],
            loaded_by=data["loaded_by"],
            loaded_at=data["loaded_at"],
            session_id=data["session_id"],
            area_id=data.get("area_id"),
        )


class ProvenanceTracker:
    """Tracks file provenance across sessions.

    Manages provenance tracking, persistence, and querying. Ensures every file
    loaded into context has documented reasons.

    Usage:
        tracker = ProvenanceTracker(project_root)

        # Track file load
        tracker.track_file_load(
            file_path="api/models.py",
            reason_type="entry_point",
            description="Main API module",
            loaded_by="dig",
            session_id="session-001",
            area_id="backend-api"
        )

        # Get provenance
        provenance = tracker.get_file_provenance("api/models.py", "session-001")

        # Save to disk
        tracker.save_session_provenance("session-001")
    """

    def __init__(self, focus_root: Path):
        """Initialize provenance tracker.

        Args:
            focus_root: Project root directory (contains .cdg/)
        """
        self.focus_root = Path(focus_root)
        self.provenance_dir = self.focus_root / ".cdg" / "provenance"

        # In-memory cache: {session_id: {file_path: FileProvenance}}
        self._provenance_cache: Dict[str, Dict[str, FileProvenance]] = {}

    def _ensure_provenance_dir(self) -> None:
        """Create .cdg/provenance/ directory if it doesn't exist."""
        self.provenance_dir.mkdir(parents=True, exist_ok=True)

    def track_file_load(
        self,
        file_path: str,
        reason_type: str,
        description: str,
        loaded_by: str,
        session_id: str,
        area_id: Optional[str] = None,
        source: Optional[str] = None,
        confidence: float = 1.0,
    ) -> None:
        """Track that a file was loaded into context.

        Args:
            file_path: Path to file (relative to project root)
            reason_type: Type of reason (entry_point, dependency, bookmark, etc.)
            description: Human-readable explanation
            loaded_by: What triggered the load (dig, export, etc.)
            session_id: Session ID
            area_id: Focus area (if applicable)
            source: File/area that caused this load (if applicable)
            confidence: Confidence in this reason (0.0-1.0)
        """
        # Initialize session cache if needed
        if session_id not in self._provenance_cache:
            self._provenance_cache[session_id] = {}

        # Create reason
        reason = ProvenanceReason(
            type=reason_type,
            description=description,
            source=source,
            confidence=confidence,
        )

        # Get or create file provenance
        if file_path in self._provenance_cache[session_id]:
            # Append reason to existing provenance
            provenance = self._provenance_cache[session_id][file_path]
            provenance.reasons.append(reason)
        else:
            # Create new provenance
            provenance = FileProvenance(
                file_path=file_path,
                reasons=[reason],
                loaded_by=loaded_by,
                loaded_at=datetime.utcnow().isoformat() + "Z",
                session_id=session_id,
                area_id=area_id,
            )
            self._provenance_cache[session_id][file_path] = provenance

    def get_file_provenance(
        self, file_path: str, session_id: str
    ) -> Optional[FileProvenance]:
        """Get provenance for a specific file in a session.

        Args:
            file_path: Path to file
            session_id: Session ID

        Returns:
            FileProvenance if found, None otherwise
        """
        if session_id not in self._provenance_cache:
            return None

        return self._provenance_cache[session_id].get(file_path)

    def get_session_provenance(self, session_id: str) -> List[FileProvenance]:
        """Get all provenance records for a session.

        Args:
            session_id: Session ID

        Returns:
            List of FileProvenance records
        """
        if session_id not in self._provenance_cache:
            return []

        return list(self._provenance_cache[session_id].values())

    def save_session_provenance(self, session_id: str) -> None:
        """Persist provenance to disk for a session.

        Args:
            session_id: Session ID to save
        """
        self._ensure_provenance_dir()

        if session_id not in self._provenance_cache:
            return

        # Build provenance data
        provenance_data = {
            "session_id": session_id,
            "files": [
                p.to_dict() for p in self._provenance_cache[session_id].values()
            ],
        }

        # Write to file
        provenance_file = self.provenance_dir / f"session-{session_id}.json"
        with open(provenance_file, "w") as f:
            json.dump(provenance_data, f, indent=2)

    def load_session_provenance(self, session_id: str) -> None:
        """Load provenance from disk for a session.

        Args:
            session_id: Session ID to load
        """
        provenance_file = self.provenance_dir / f"session-{session_id}.json"

        if not provenance_file.exists():
            return

        # Load from file
        with open(provenance_file) as f:
            data = json.load(f)

        # Reconstruct provenance cache
        self._provenance_cache[session_id] = {}
        for file_data in data.get("files", []):
            provenance = FileProvenance.from_dict(file_data)
            self._provenance_cache[session_id][provenance.file_path] = provenance

    def get_provenance_completeness(
        self, session_id: str, total_files: int
    ) -> float:
        """Calculate provenance completeness score for a session.

        Args:
            session_id: Session ID
            total_files: Total number of files in context

        Returns:
            Percentage of files with provenance (0.0-1.0)
        """
        if total_files == 0:
            return 1.0

        provenance_count = len(self.get_session_provenance(session_id))
        return provenance_count / total_files


# Provenance reason type constants
REASON_ENTRY_POINT = "entry_point"
REASON_DEPENDENCY = "dependency"
REASON_BOOKMARK = "bookmark"
REASON_HISTORY = "history"
REASON_PATTERN_MATCH = "pattern_match"
REASON_USER_REQUEST = "user_request"
