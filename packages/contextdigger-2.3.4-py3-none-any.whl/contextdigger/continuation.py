"""Continuation Contracts - Preserve Developer Intent Across Sessions.

This module implements continuation contracts that eliminate "What was I doing?"
moments by capturing and restoring complete work context.

Key Concepts:
    - ContinuationContract: Preserves intent, problem, goal, and progress
    - ContractContext: Snapshot of files, bookmarks, commands, notes
    - ContractManager: Manages active contract and history

Design Principles:
    - Auto-capture context on area switch
    - Resume exactly where you left off
    - Track progress and status
    - Support contract templates
"""

import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional, Dict
from datetime import datetime


@dataclass
class ContractContext:
    """Snapshot of work context at a point in time.

    Captures everything needed to resume work:
    - Files being worked on
    - Bookmarks and reference points
    - Recent search queries
    - Commands executed
    - Notes and thoughts
    - Next planned actions

    Attributes:
        open_files: Files currently being worked on
        bookmarks: Bookmarked locations for reference
        search_queries: Recent search queries
        last_commands: Recently executed commands
        notes: Developer notes and thoughts
        next_actions: Planned next steps
    """

    open_files: List[str]
    bookmarks: List[str]
    search_queries: List[str]
    last_commands: List[str]
    notes: str
    next_actions: List[str]

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return asdict(self)

    @staticmethod
    def from_dict(data: Dict) -> "ContractContext":
        """Create from dictionary."""
        return ContractContext(
            open_files=data.get("open_files", []),
            bookmarks=data.get("bookmarks", []),
            search_queries=data.get("search_queries", []),
            last_commands=data.get("last_commands", []),
            notes=data.get("notes", ""),
            next_actions=data.get("next_actions", []),
        )


@dataclass
class ContinuationContract:
    """Preserves developer intent and context across sessions.

    A continuation contract answers:
    - What am I working on? (intent)
    - Why am I working on this? (problem)
    - What does success look like? (goal)
    - Where am I in the process? (status, progress)
    - What context do I need? (context snapshot)

    Attributes:
        id: Unique contract identifier
        area_id: Focus area this contract is for
        area_name: Human-readable area name
        intent: What you're trying to accomplish
        problem: The problem you're solving
        goal: What success looks like
        status: Current workflow status
        progress: Progress percentage (0.0-1.0)
        context: Snapshot of work context
        created_at: When contract was created
        updated_at: When contract was last updated
        completed_at: When contract was completed (if applicable)
        tags: Tags for organization
    """

    id: str
    area_id: str
    area_name: str
    intent: str
    problem: str
    goal: str
    status: str  # investigating, implementing, testing, blocked, completed
    progress: float  # 0.0-1.0
    context: ContractContext
    created_at: str
    updated_at: str
    completed_at: Optional[str]
    tags: List[str]

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        data = asdict(self)
        # Ensure context is serialized
        data["context"] = self.context.to_dict()
        return data

    @staticmethod
    def from_dict(data: Dict) -> "ContinuationContract":
        """Create from dictionary."""
        return ContinuationContract(
            id=data["id"],
            area_id=data["area_id"],
            area_name=data["area_name"],
            intent=data["intent"],
            problem=data["problem"],
            goal=data["goal"],
            status=data["status"],
            progress=data["progress"],
            context=ContractContext.from_dict(data["context"]),
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            completed_at=data.get("completed_at"),
            tags=data.get("tags", []),
        )


class ContractManager:
    """Manages continuation contracts.

    Handles creating, saving, updating, and retrieving contracts.
    Manages active contract and contract history.

    Usage:
        manager = ContractManager(project_root)

        # Create new contract
        contract = manager.create_contract(
            area_id="backend-api",
            area_name="Backend API",
            intent="Fix authentication bug",
            problem="Users can't log in with valid credentials",
            goal="Users can successfully log in"
        )

        # Save as active
        manager.save_active_contract(contract)

        # Update progress
        manager.update_contract(contract.id, status="implementing", progress=0.6)

        # Complete
        manager.complete_contract(contract.id)

        # Resume
        active = manager.get_active_contract()
    """

    def __init__(self, focus_root: Path):
        """Initialize contract manager.

        Args:
            focus_root: Project root directory (contains .cdg/)
        """
        self.focus_root = Path(focus_root)
        self.contracts_dir = self.focus_root / ".cdg" / "contracts"

        # In-memory cache
        self._active_contract: Optional[ContinuationContract] = None

    def _ensure_contracts_dir(self) -> None:
        """Create contracts directory structure if it doesn't exist."""
        self.contracts_dir.mkdir(parents=True, exist_ok=True)
        (self.contracts_dir / "history").mkdir(exist_ok=True)
        (self.contracts_dir / "templates").mkdir(exist_ok=True)

    def create_contract(
        self,
        area_id: str,
        area_name: str,
        intent: str,
        problem: str,
        goal: str,
        tags: Optional[List[str]] = None,
        context: Optional[ContractContext] = None,
    ) -> ContinuationContract:
        """Create a new continuation contract.

        Args:
            area_id: Focus area ID
            area_name: Focus area name
            intent: What you're trying to accomplish
            problem: The problem you're solving
            goal: What success looks like
            tags: Optional tags for organization
            context: Optional initial context (auto-captured if None)

        Returns:
            New ContinuationContract
        """
        contract_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat() + "Z"

        # Create empty context if not provided
        if context is None:
            context = ContractContext(
                open_files=[],
                bookmarks=[],
                search_queries=[],
                last_commands=[],
                notes="",
                next_actions=[],
            )

        contract = ContinuationContract(
            id=contract_id,
            area_id=area_id,
            area_name=area_name,
            intent=intent,
            problem=problem,
            goal=goal,
            status="investigating",
            progress=0.0,
            context=context,
            created_at=now,
            updated_at=now,
            completed_at=None,
            tags=tags or [],
        )

        return contract

    def save_active_contract(self, contract: ContinuationContract) -> None:
        """Save contract as the active contract.

        Args:
            contract: Contract to save as active
        """
        self._ensure_contracts_dir()

        # Update in-memory cache
        self._active_contract = contract

        # Save to disk
        active_file = self.contracts_dir / "active.json"
        with open(active_file, "w") as f:
            json.dump(contract.to_dict(), f, indent=2)

    def get_active_contract(self) -> Optional[ContinuationContract]:
        """Get the currently active contract.

        Returns:
            Active contract if one exists, None otherwise
        """
        # Check cache first
        if self._active_contract:
            return self._active_contract

        # Load from disk
        active_file = self.contracts_dir / "active.json"
        if not active_file.exists():
            return None

        with open(active_file) as f:
            data = json.load(f)

        contract = ContinuationContract.from_dict(data)
        self._active_contract = contract
        return contract

    def update_contract(
        self,
        contract_id: str,
        status: Optional[str] = None,
        progress: Optional[float] = None,
        context: Optional[ContractContext] = None,
        notes: Optional[str] = None,
    ) -> None:
        """Update an active contract.

        Args:
            contract_id: Contract ID to update
            status: New status
            progress: New progress (0.0-1.0)
            context: New context snapshot
            notes: New notes
        """
        active = self.get_active_contract()
        if not active or active.id != contract_id:
            return

        # Update fields
        if status:
            active.status = status
        if progress is not None:
            active.progress = progress
        if context:
            active.context = context
        if notes is not None:
            active.context.notes = notes

        # Update timestamp
        active.updated_at = datetime.utcnow().isoformat() + "Z"

        # Save
        self.save_active_contract(active)

    def complete_contract(self, contract_id: str) -> None:
        """Mark contract as completed and move to history.

        Args:
            contract_id: Contract ID to complete
        """
        active = self.get_active_contract()
        if not active or active.id != contract_id:
            return

        # Mark as completed
        active.status = "completed"
        active.progress = 1.0
        active.completed_at = datetime.utcnow().isoformat() + "Z"
        active.updated_at = active.completed_at

        # Move to history
        self._ensure_contracts_dir()
        history_file = self.contracts_dir / "history" / f"{contract_id}.json"
        with open(history_file, "w") as f:
            json.dump(active.to_dict(), f, indent=2)

        # Remove active contract
        active_file = self.contracts_dir / "active.json"
        if active_file.exists():
            active_file.unlink()

        # Clear cache
        self._active_contract = None

    def pause_contract(self) -> None:
        """Pause active contract and move to history (without completing)."""
        active = self.get_active_contract()
        if not active:
            return

        # Save to history with current status
        self._ensure_contracts_dir()
        history_file = self.contracts_dir / "history" / f"{active.id}.json"
        active.updated_at = datetime.utcnow().isoformat() + "Z"

        with open(history_file, "w") as f:
            json.dump(active.to_dict(), f, indent=2)

        # Remove active contract
        active_file = self.contracts_dir / "active.json"
        if active_file.exists():
            active_file.unlink()

        # Clear cache
        self._active_contract = None

    def get_contract_history(self, limit: Optional[int] = None) -> List[ContinuationContract]:
        """Get contract history.

        Args:
            limit: Maximum number of contracts to return

        Returns:
            List of contracts, newest first
        """
        history_dir = self.contracts_dir / "history"
        if not history_dir.exists():
            return []

        contracts = []
        for contract_file in history_dir.glob("*.json"):
            with open(contract_file) as f:
                data = json.load(f)
            contracts.append(ContinuationContract.from_dict(data))

        # Sort by updated_at, newest first
        contracts.sort(key=lambda c: c.updated_at, reverse=True)

        if limit:
            contracts = contracts[:limit]

        return contracts

    def get_contract(self, contract_id: str) -> Optional[ContinuationContract]:
        """Get contract by ID from active or history.

        Args:
            contract_id: Contract ID

        Returns:
            Contract if found, None otherwise
        """
        # Check active first
        active = self.get_active_contract()
        if active and active.id == contract_id:
            return active

        # Check history
        history_file = self.contracts_dir / "history" / f"{contract_id}.json"
        if history_file.exists():
            with open(history_file) as f:
                data = json.load(f)
            return ContinuationContract.from_dict(data)

        return None

    def capture_current_context(
        self,
        open_files: Optional[List[str]] = None,
        bookmarks: Optional[List[str]] = None,
        search_queries: Optional[List[str]] = None,
        last_commands: Optional[List[str]] = None,
        notes: Optional[str] = None,
        next_actions: Optional[List[str]] = None,
    ) -> ContractContext:
        """Capture current work context.

        Args:
            open_files: Files currently being worked on
            bookmarks: Bookmarked locations
            search_queries: Recent search queries
            last_commands: Recently executed commands
            notes: Developer notes
            next_actions: Planned next steps

        Returns:
            ContractContext snapshot
        """
        return ContractContext(
            open_files=open_files or [],
            bookmarks=bookmarks or [],
            search_queries=search_queries or [],
            last_commands=last_commands or [],
            notes=notes or "",
            next_actions=next_actions or [],
        )


# Contract status constants
STATUS_INVESTIGATING = "investigating"
STATUS_IMPLEMENTING = "implementing"
STATUS_TESTING = "testing"
STATUS_BLOCKED = "blocked"
STATUS_COMPLETED = "completed"
