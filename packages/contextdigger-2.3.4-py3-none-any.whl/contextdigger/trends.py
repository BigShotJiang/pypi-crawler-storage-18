"""
ContextDigger Trend Analysis & Predictive Insights (Phase 13)

Extends the Insights Engine with:
- Historical pattern tracking
- Trend analysis (improving, degrading, stable)
- Predictive insights and forecasting
- Automated remediation suggestions

All features are local-first with no external dependencies.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import List, Optional, Dict, Tuple
import json
from collections import defaultdict
import statistics

from .insights import Pattern, Insight, InsightLevel, PatternType


# ============================================================================
# Enums
# ============================================================================


class TrendDirection(Enum):
    """Direction of trend over time."""

    IMPROVING = "improving"  # Getting better (fewer violations, lower usage)
    DEGRADING = "degrading"  # Getting worse (more violations, higher usage)
    STABLE = "stable"  # No significant change
    INSUFFICIENT_DATA = "insufficient_data"  # Not enough data points


class RemediationType(Enum):
    """Types of automated remediation suggestions."""

    SPLIT_AREA = "split_area"  # Split area into smaller sub-areas
    REDUCE_SCOPE = "reduce_scope"  # Reduce number of files in area
    INCREASE_BUDGET = "increase_budget"  # Adjust budget limits
    REFACTOR_CODE = "refactor_code"  # Refactoring suggestions
    UPDATE_PATTERNS = "update_patterns"  # Update area patterns
    POLICY_ADJUSTMENT = "policy_adjustment"  # Adjust governance policy


# ============================================================================
# Dataclasses
# ============================================================================


@dataclass
class PatternSnapshot:
    """
    A snapshot of patterns at a specific point in time.

    Used for trend analysis and historical comparisons.
    """

    timestamp: datetime
    patterns: List[Pattern]
    session_id: Optional[str] = None
    area_id: Optional[str] = None
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "patterns": [
                {
                    "type": p.pattern_type.value,
                    "description": p.description,
                    "confidence": p.confidence,
                    "occurrences": p.occurrences,
                    "detected_at": p.detected_at if hasattr(p, 'detected_at') else None,
                    "affected_areas": p.affected_areas,
                    "metadata": p.metadata,
                }
                for p in self.patterns
            ],
            "session_id": self.session_id,
            "area_id": self.area_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "PatternSnapshot":
        """Create from dictionary."""
        patterns = []
        for p in data.get("patterns", []):
            pattern = Pattern(
                pattern_type=PatternType(p["type"]),
                description=p["description"],
                occurrences=p["occurrences"],
                affected_areas=p.get("affected_areas", []),
                confidence=p["confidence"],
                metadata=p.get("metadata", {}),
            )
            # Preserve detected_at if present
            if "detected_at" in p:
                pattern.detected_at = p["detected_at"]
            patterns.append(pattern)

        return cls(
            timestamp=datetime.fromisoformat(data["timestamp"]),
            patterns=patterns,
            session_id=data.get("session_id"),
            area_id=data.get("area_id"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class Trend:
    """
    Represents a trend detected across historical snapshots.
    """

    pattern_type: PatternType
    direction: TrendDirection
    description: str
    confidence: float  # 0.0-1.0
    data_points: int  # Number of snapshots analyzed
    start_date: datetime
    end_date: datetime
    change_rate: float  # Rate of change (positive = increasing, negative = decreasing)
    affected_areas: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "pattern_type": self.pattern_type.value,
            "direction": self.direction.value,
            "description": self.description,
            "confidence": self.confidence,
            "data_points": self.data_points,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "change_rate": self.change_rate,
            "affected_areas": self.affected_areas,
            "metadata": self.metadata,
        }


@dataclass
class Prediction:
    """
    A predictive insight based on historical trends.
    """

    prediction_type: str  # Type of prediction (e.g., "budget_violation", "hotspot")
    description: str
    probability: float  # 0.0-1.0 likelihood of occurring
    timeframe: str  # When it's likely to occur (e.g., "1 week", "1 month")
    risk_score: float  # 0.0-1.0 severity if it occurs
    affected_areas: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    based_on_trend: Optional[Trend] = None
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "prediction_type": self.prediction_type,
            "description": self.description,
            "probability": self.probability,
            "timeframe": self.timeframe,
            "risk_score": self.risk_score,
            "affected_areas": self.affected_areas,
            "recommendations": self.recommendations,
            "based_on_trend": (
                self.based_on_trend.to_dict() if self.based_on_trend else None
            ),
            "metadata": self.metadata,
        }


@dataclass
class RemediationSuggestion:
    """
    An automated suggestion for fixing an issue.
    """

    remediation_type: RemediationType
    title: str
    description: str
    steps: List[str]  # Step-by-step instructions
    code_examples: List[str] = field(default_factory=list)
    estimated_effort: str = "medium"  # low, medium, high
    priority: InsightLevel = InsightLevel.INFO
    applicable_to: List[str] = field(default_factory=list)  # Area IDs
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "remediation_type": self.remediation_type.value,
            "title": self.title,
            "description": self.description,
            "steps": self.steps,
            "code_examples": self.code_examples,
            "estimated_effort": self.estimated_effort,
            "priority": self.priority.value,
            "applicable_to": self.applicable_to,
            "metadata": self.metadata,
        }


# ============================================================================
# Historical Pattern Storage
# ============================================================================


class PatternHistory:
    """
    Manages historical snapshots of patterns for trend analysis.

    Stores snapshots in .cdg/insights/history/ as JSONL files.
    """

    def __init__(self, cdg_dir: Path):
        """Initialize with .cdg directory."""
        self.cdg_dir = Path(cdg_dir)
        self.history_dir = self.cdg_dir / "insights" / "history"
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.history_file = self.history_dir / "snapshots.jsonl"

    def save_snapshot(self, snapshot: PatternSnapshot) -> None:
        """
        Save a pattern snapshot to history.

        Args:
            snapshot: Pattern snapshot to save
        """
        with open(self.history_file, "a") as f:
            json.dump(snapshot.to_dict(), f)
            f.write("\n")

    def get_snapshots(
        self,
        area_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: Optional[int] = None,
    ) -> List[PatternSnapshot]:
        """
        Retrieve historical snapshots.

        Args:
            area_id: Filter by area ID
            since: Only get snapshots after this datetime
            limit: Maximum number of snapshots to return

        Returns:
            List of pattern snapshots
        """
        if not self.history_file.exists():
            return []

        snapshots = []
        with open(self.history_file, "r") as f:
            for line in f:
                if not line.strip():
                    continue
                data = json.loads(line)
                snapshot = PatternSnapshot.from_dict(data)

                # Apply filters
                if area_id and snapshot.area_id != area_id:
                    continue
                if since and snapshot.timestamp < since:
                    continue

                snapshots.append(snapshot)

        # Sort by timestamp (newest first)
        snapshots.sort(key=lambda s: s.timestamp, reverse=True)

        # Apply limit
        if limit:
            snapshots = snapshots[:limit]

        return snapshots

    def get_latest_snapshot(
        self, area_id: Optional[str] = None
    ) -> Optional[PatternSnapshot]:
        """Get the most recent snapshot."""
        snapshots = self.get_snapshots(area_id=area_id, limit=1)
        return snapshots[0] if snapshots else None


# ============================================================================
# Trend Analyzer
# ============================================================================


class TrendAnalyzer:
    """
    Analyzes historical patterns to detect trends.
    """

    def __init__(self, pattern_history: PatternHistory):
        """Initialize with pattern history."""
        self.history = pattern_history

    def analyze_trends(
        self, area_id: Optional[str] = None, days: int = 30
    ) -> List[Trend]:
        """
        Analyze trends over a time period.

        Args:
            area_id: Filter by area ID
            days: Number of days to analyze

        Returns:
            List of detected trends
        """
        since = datetime.now() - timedelta(days=days)
        snapshots = self.history.get_snapshots(area_id=area_id, since=since)

        if len(snapshots) < 2:
            return []

        trends = []

        # Group patterns by type
        patterns_by_type = defaultdict(list)
        for snapshot in snapshots:
            for pattern in snapshot.patterns:
                patterns_by_type[pattern.pattern_type].append(
                    (snapshot.timestamp, pattern)
                )

        # Analyze each pattern type
        for pattern_type, data_points in patterns_by_type.items():
            trend = self._analyze_pattern_trend(pattern_type, data_points)
            if trend:
                trends.append(trend)

        return trends

    def _analyze_pattern_trend(
        self, pattern_type: PatternType, data_points: List[Tuple[datetime, Pattern]]
    ) -> Optional[Trend]:
        """
        Analyze trend for a specific pattern type.

        Args:
            pattern_type: Type of pattern
            data_points: List of (timestamp, pattern) tuples

        Returns:
            Trend if detected, None otherwise
        """
        if len(data_points) < 2:
            return Trend(
                pattern_type=pattern_type,
                direction=TrendDirection.INSUFFICIENT_DATA,
                description=f"Insufficient data for {pattern_type.value} trend analysis",
                confidence=0.0,
                data_points=len(data_points),
                start_date=data_points[0][0],
                end_date=data_points[0][0],
                change_rate=0.0,
            )

        # Sort by timestamp
        data_points.sort(key=lambda x: x[0])

        # Extract occurrences over time
        occurrences = [pattern.occurrences for _, pattern in data_points]

        # Calculate trend
        if len(occurrences) < 2:
            change_rate = 0.0
        else:
            # Simple linear regression
            change_rate = (occurrences[-1] - occurrences[0]) / len(occurrences)

        # Determine direction
        if abs(change_rate) < 0.5:  # Threshold for stability
            direction = TrendDirection.STABLE
        elif change_rate > 0:
            direction = TrendDirection.DEGRADING  # More occurrences = worse
        else:
            direction = TrendDirection.IMPROVING  # Fewer occurrences = better

        # Calculate confidence based on data consistency
        if len(occurrences) >= 3:
            std_dev = statistics.stdev(occurrences)
            mean = statistics.mean(occurrences)
            # Lower std dev relative to mean = higher confidence
            confidence = max(0.0, min(1.0, 1.0 - (std_dev / (mean + 1))))
        else:
            confidence = 0.5  # Medium confidence with limited data

        # Collect affected areas
        affected_areas = []
        for _, pattern in data_points:
            affected_areas.extend(pattern.affected_areas)
        affected_areas = list(set(affected_areas))

        # Generate description
        direction_str = {
            TrendDirection.IMPROVING: "improving",
            TrendDirection.DEGRADING: "degrading",
            TrendDirection.STABLE: "stable",
        }.get(direction, "unknown")

        description = f"{pattern_type.value.replace('_', ' ').title()} is {direction_str} over the last {len(data_points)} data points"

        return Trend(
            pattern_type=pattern_type,
            direction=direction,
            description=description,
            confidence=confidence,
            data_points=len(data_points),
            start_date=data_points[0][0],
            end_date=data_points[-1][0],
            change_rate=change_rate,
            affected_areas=affected_areas,
            metadata={
                "occurrences": occurrences,
                "min": min(occurrences),
                "max": max(occurrences),
                "mean": statistics.mean(occurrences),
            },
        )


# ============================================================================
# Predictive Engine
# ============================================================================


class PredictiveEngine:
    """
    Generates predictive insights based on trends.
    """

    def __init__(self, trend_analyzer: TrendAnalyzer):
        """Initialize with trend analyzer."""
        self.analyzer = trend_analyzer

    def generate_predictions(
        self, area_id: Optional[str] = None, days: int = 30
    ) -> List[Prediction]:
        """
        Generate predictive insights.

        Args:
            area_id: Filter by area ID
            days: Historical days to analyze

        Returns:
            List of predictions
        """
        trends = self.analyzer.analyze_trends(area_id=area_id, days=days)
        predictions = []

        for trend in trends:
            if trend.direction == TrendDirection.DEGRADING:
                prediction = self._predict_from_degrading_trend(trend)
                if prediction:
                    predictions.append(prediction)
            elif trend.direction == TrendDirection.IMPROVING:
                prediction = self._predict_from_improving_trend(trend)
                if prediction:
                    predictions.append(prediction)

        return predictions

    def _predict_from_degrading_trend(self, trend: Trend) -> Optional[Prediction]:
        """Generate prediction from degrading trend."""
        # Estimate time until critical threshold
        if trend.change_rate > 0:
            # Rough estimate: when will occurrences reach 10?
            current_occurrences = trend.metadata.get("mean", 0)
            days_to_critical = (10 - current_occurrences) / max(
                trend.change_rate, 0.1
            )
            days_to_critical = max(1, int(days_to_critical))

            if days_to_critical < 7:
                timeframe = f"{days_to_critical} days"
                probability = min(1.0, trend.confidence * 1.2)
                risk_score = 0.8
            elif days_to_critical < 30:
                timeframe = f"{days_to_critical // 7} weeks"
                probability = trend.confidence
                risk_score = 0.6
            else:
                timeframe = f"{days_to_critical // 30} months"
                probability = trend.confidence * 0.8
                risk_score = 0.4

            return Prediction(
                prediction_type=f"{trend.pattern_type.value}_escalation",
                description=f"Based on current trends, {trend.pattern_type.value.replace('_', ' ')} is likely to escalate",
                probability=probability,
                timeframe=timeframe,
                risk_score=risk_score,
                affected_areas=trend.affected_areas,
                recommendations=[
                    f"Monitor {', '.join(trend.affected_areas)} closely",
                    "Consider implementing preventive measures",
                    "Review and adjust budget limits if needed",
                ],
                based_on_trend=trend,
            )

        return None

    def _predict_from_improving_trend(self, trend: Trend) -> Optional[Prediction]:
        """Generate prediction from improving trend (informational)."""
        return Prediction(
            prediction_type=f"{trend.pattern_type.value}_resolution",
            description=f"{trend.pattern_type.value.replace('_', ' ').title()} is showing signs of improvement",
            probability=trend.confidence,
            timeframe="ongoing",
            risk_score=0.1,  # Low risk, positive trend
            affected_areas=trend.affected_areas,
            recommendations=[
                "Continue current practices",
                "Document successful changes",
                "Consider applying similar approaches to other areas",
            ],
            based_on_trend=trend,
        )


# ============================================================================
# Remediation Suggester
# ============================================================================


class RemediationSuggester:
    """
    Generates automated remediation suggestions.
    """

    def suggest_remediations(
        self, insights: List[Insight], trends: List[Trend], predictions: List[Prediction]
    ) -> List[RemediationSuggestion]:
        """
        Generate remediation suggestions based on insights, trends, and predictions.

        Args:
            insights: Current insights
            trends: Detected trends
            predictions: Predictive insights

        Returns:
            List of remediation suggestions
        """
        suggestions = []

        # Analyze critical insights for budget hotspots
        for insight in insights:
            if insight.level == InsightLevel.CRITICAL:
                if "exceeds budget" in insight.description.lower():
                    suggestions.append(self._suggest_split_area(insight))
                elif "violation" in insight.description.lower():
                    suggestions.append(self._suggest_policy_adjustment(insight))

        # Analyze degrading trends
        for trend in trends:
            if (
                trend.direction == TrendDirection.DEGRADING
                and trend.confidence > 0.7
            ):
                suggestions.append(self._suggest_preventive_action(trend))

        # Analyze high-risk predictions
        for prediction in predictions:
            if prediction.risk_score > 0.7:
                suggestions.append(self._suggest_proactive_remediation(prediction))

        return suggestions

    def _suggest_split_area(self, insight: Insight) -> RemediationSuggestion:
        """Suggest splitting an area that exceeds budget."""
        area = insight.affected_areas[0] if insight.affected_areas else "unknown"

        return RemediationSuggestion(
            remediation_type=RemediationType.SPLIT_AREA,
            title=f"Split '{area}' into smaller sub-areas",
            description=f"Area '{area}' consistently exceeds budget limits. Splitting it into smaller, focused sub-areas will improve context management.",
            steps=[
                f"1. Identify logical sub-components within '{area}'",
                "2. Use `contextdigger dig {area}` to review current structure",
                "3. Create sub-areas using custom area definitions",
                "4. Update patterns to match new sub-areas",
                "5. Test new areas with budget checks",
            ],
            code_examples=[
                f"# Example: Split '{area}' into sub-areas",
                "{",
                f'  "{area}-core": {{',
                f'    "path_patterns": ["{area}/core/**"],',
                '    "budget": { "max_files": 50, "max_lines": 10000 }',
                "  },",
                f'  "{area}-utils": {{',
                f'    "path_patterns": ["{area}/utils/**"],',
                '    "budget": { "max_files": 30, "max_lines": 5000 }',
                "  }",
                "}",
            ],
            estimated_effort="medium",
            priority=InsightLevel.CRITICAL,
            applicable_to=[area],
        )

    def _suggest_policy_adjustment(self, insight: Insight) -> RemediationSuggestion:
        """Suggest adjusting governance policy."""
        return RemediationSuggestion(
            remediation_type=RemediationType.POLICY_ADJUSTMENT,
            title="Adjust governance policy enforcement mode",
            description="Recurring violations suggest policy may be too strict for current workflow. Consider adjusting enforcement mode or budget limits.",
            steps=[
                "1. Review current policy: `contextdigger policy`",
                "2. Check violation patterns: `contextdigger audit violations`",
                "3. Adjust enforcement mode: `contextdigger policy warning`",
                "4. Or increase budget limits for specific areas",
                "5. Monitor for 1-2 weeks and re-evaluate",
            ],
            code_examples=[
                "# Set policy to warning mode (less strict)",
                "contextdigger policy warning",
                "",
                "# Or increase budget limits",
                "contextdigger policy --max-files 300 --max-lines 75000",
            ],
            estimated_effort="low",
            priority=InsightLevel.WARNING,
            applicable_to=insight.affected_areas,
        )

    def _suggest_preventive_action(self, trend: Trend) -> RemediationSuggestion:
        """Suggest preventive action for degrading trend."""
        return RemediationSuggestion(
            remediation_type=RemediationType.REFACTOR_CODE,
            title=f"Address degrading trend: {trend.pattern_type.value.replace('_', ' ').title()}",
            description=f"Trend analysis shows {trend.pattern_type.value} is degrading. Take preventive action now before it becomes critical.",
            steps=[
                "1. Review recent changes in affected areas",
                "2. Identify root cause of increasing violations",
                "3. Refactor or reorganize code structure",
                "4. Consider splitting large files or areas",
                "5. Update patterns to better match current structure",
            ],
            estimated_effort="medium",
            priority=InsightLevel.WARNING,
            applicable_to=trend.affected_areas,
        )

    def _suggest_proactive_remediation(
        self, prediction: Prediction
    ) -> RemediationSuggestion:
        """Suggest proactive remediation for high-risk prediction."""
        return RemediationSuggestion(
            remediation_type=RemediationType.REDUCE_SCOPE,
            title=f"Proactive remediation: {prediction.prediction_type}",
            description=f"Predictive analysis indicates a {int(prediction.probability * 100)}% likelihood of {prediction.prediction_type} within {prediction.timeframe}. Act now to prevent issues.",
            steps=[
                "1. Review predictive analysis details",
                "2. Implement recommended preventive measures",
                "3. Monitor affected areas closely",
                "4. Set up automated alerts for early warning",
                "5. Re-assess prediction in 1 week",
            ] + prediction.recommendations,
            estimated_effort="high",
            priority=(
                InsightLevel.CRITICAL
                if prediction.risk_score > 0.8
                else InsightLevel.WARNING
            ),
            applicable_to=prediction.affected_areas,
        )
