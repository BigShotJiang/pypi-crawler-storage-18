"""
BookmarksService - Handles bookmark CRUD and management operations.

This service is responsible for:
- Creating, reading, updating, and deleting bookmarks
- Searching and filtering bookmarks
- Tracking bookmark access counts and timestamps
- Managing bookmark collections
"""

from pathlib import Path
from typing import List, Optional
from dataclasses import asdict
from datetime import datetime

from .storage import StorageService


class BookmarksService:
    """Handles bookmark management operations."""

    def __init__(self, cdg_dir: Path):
        """
        Initialize BookmarksService.

        Args:
            cdg_dir: Path to the .cdg directory
        """
        self.cdg_dir = Path(cdg_dir)
        self.storage = StorageService(self.cdg_dir.parent)
        self.bookmarks_file = self.cdg_dir / "bookmarks" / "bookmarks.json"

    # CRUD Operations

    def add_bookmark(self, bookmark) -> None:
        """
        Add a bookmark to the collection.

        Args:
            bookmark: Bookmark dataclass instance

        Note:
            Automatically handles duplicate IDs by appending a counter (_1, _2, etc.)
            Updates the bookmarks file and metadata.
        """
        bookmarks_data = self.storage.read_json(self.bookmarks_file)

        # Check for duplicate ID
        existing_ids = {b["id"] for b in bookmarks_data["bookmarks"]}
        if bookmark.id in existing_ids:
            # Generate unique ID
            counter = 1
            base_id = bookmark.id
            while bookmark.id in existing_ids:
                bookmark.id = f"{base_id}_{counter}"
                counter += 1

        bookmarks_data["bookmarks"].append(asdict(bookmark))
        bookmarks_data["totalBookmarks"] = len(bookmarks_data["bookmarks"])
        bookmarks_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self.storage.write_json(self.bookmarks_file, bookmarks_data)

    def get_bookmark(self, bookmark_id: str):
        """
        Get a bookmark by ID.

        Args:
            bookmark_id: Unique identifier for the bookmark

        Returns:
            Bookmark instance if found, None otherwise
        """
        # Import here to avoid circular imports
        from ..manager import Bookmark

        bookmarks_data = self.storage.read_json(self.bookmarks_file)
        for b_data in bookmarks_data["bookmarks"]:
            if b_data["id"] == bookmark_id:
                return Bookmark(**b_data)
        return None

    def delete_bookmark(self, bookmark_id: str) -> bool:
        """
        Delete a bookmark.

        Args:
            bookmark_id: ID of the bookmark to delete

        Returns:
            True if bookmark was deleted, False if bookmark didn't exist
        """
        bookmarks_data = self.storage.read_json(self.bookmarks_file)

        initial_count = len(bookmarks_data["bookmarks"])
        bookmarks_data["bookmarks"] = [
            b for b in bookmarks_data["bookmarks"] if b["id"] != bookmark_id
        ]

        if len(bookmarks_data["bookmarks"]) == initial_count:
            return False

        bookmarks_data["totalBookmarks"] = len(bookmarks_data["bookmarks"])
        bookmarks_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self.storage.write_json(self.bookmarks_file, bookmarks_data)
        return True

    # Search and Query Operations

    def find_bookmarks(self, query: str) -> List:
        """
        Find bookmarks matching a search query.

        Args:
            query: Search string to match against ID, name, and path

        Returns:
            List of matching Bookmark instances, sorted by relevance

        Scoring:
            - Exact ID match: 100 points
            - Exact name match: 90 points
            - ID contains query: 70 points
            - Name contains query: 60 points
            - Path contains query: 50 points
        """
        # Import here to avoid circular imports
        from ..manager import Bookmark

        bookmarks_data = self.storage.read_json(self.bookmarks_file)
        query_lower = query.lower()

        matches = []
        for b_data in bookmarks_data["bookmarks"]:
            bookmark = Bookmark(**b_data)

            # Exact match on ID
            if bookmark.id == query or bookmark.id.lower() == query_lower:
                matches.append((bookmark, 100))
            # Exact match on name
            elif bookmark.name.lower() == query_lower:
                matches.append((bookmark, 90))
            # ID contains query
            elif query_lower in bookmark.id.lower():
                matches.append((bookmark, 70))
            # Name contains query
            elif query_lower in bookmark.name.lower():
                matches.append((bookmark, 60))
            # Path contains query
            elif query_lower in bookmark.path.lower():
                matches.append((bookmark, 50))

        # Sort by relevance score (highest first)
        matches.sort(key=lambda x: -x[1])
        return [bookmark for bookmark, score in matches]

    def list_bookmarks(self, focus_area: Optional[str] = None) -> List:
        """
        List all bookmarks, optionally filtered by focus area.

        Args:
            focus_area: Optional focus area ID to filter by

        Returns:
            List of Bookmark instances, sorted by access count (most accessed first),
            then by created date

        Note:
            Returns all bookmarks if focus_area is None.
            Filters to specific focus area if provided.
        """
        # Import here to avoid circular imports
        from ..manager import Bookmark

        bookmarks_data = self.storage.read_json(self.bookmarks_file)
        bookmarks = [Bookmark(**b) for b in bookmarks_data["bookmarks"]]

        if focus_area:
            bookmarks = [b for b in bookmarks if b.focusArea == focus_area]

        # Sort by access count (most accessed first), then by created date
        bookmarks.sort(key=lambda b: (-b.accessCount, b.created), reverse=False)
        return bookmarks

    # Access Tracking

    def update_bookmark_access(self, bookmark_id: str) -> None:
        """
        Update bookmark access count and timestamp.

        Args:
            bookmark_id: ID of the bookmark that was accessed

        Note:
            Increments accessCount and updates lastAccessed timestamp.
            Does nothing if bookmark doesn't exist.
        """
        bookmarks_data = self.storage.read_json(self.bookmarks_file)

        for b in bookmarks_data["bookmarks"]:
            if b["id"] == bookmark_id:
                b["accessCount"] = b.get("accessCount", 0) + 1
                b["lastAccessed"] = datetime.utcnow().isoformat() + "Z"
                break

        bookmarks_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self.storage.write_json(self.bookmarks_file, bookmarks_data)
