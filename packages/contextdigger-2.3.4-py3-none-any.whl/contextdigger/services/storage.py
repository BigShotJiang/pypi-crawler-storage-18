"""
StorageService - Handles all file I/O and JSON operations for ContextDigger.

This service is responsible for:
- Reading and writing JSON files
- Managing index files (areas, sessions, snapshots)
- Directory and file operations
- Path resolution and validation
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime


class StorageService:
    """Handles file I/O and storage operations."""

    def __init__(self, root_dir: Path | str):
        """
        Initialize StorageService.

        Args:
            root_dir: Root directory for storage operations
        """
        self.root_dir = Path(root_dir).resolve()

    # JSON Operations

    def write_json(self, file_path: Path, data: Dict[str, Any]) -> None:
        """
        Write JSON data to a file with proper formatting.

        Args:
            file_path: Path to the JSON file
            data: Dictionary to write as JSON

        Note:
            Automatically creates parent directories if they don't exist.
            Formats JSON with 2-space indentation for readability.
        """
        # Ensure parent directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write JSON with indentation
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)

    def read_json(self, file_path: Path) -> Dict[str, Any]:
        """
        Read JSON data from a file.

        Args:
            file_path: Path to the JSON file

        Returns:
            Dictionary containing the JSON data

        Raises:
            FileNotFoundError: If the file doesn't exist
        """
        with open(file_path, 'r') as f:
            return json.load(f)

    # Index Operations

    def update_area_index(self, index_file: Path, area: Any) -> None:
        """
        Update area index with area information.

        Args:
            index_file: Path to the areas/index.json file
            area: FocusArea dataclass instance

        Note:
            If area already exists in index, it will be replaced with new data.
        """
        index = self.read_json(index_file)

        # Remove existing entry if present
        index["areas"] = [a for a in index["areas"] if a["id"] != area.id]

        # Add updated entry
        index["areas"].append({
            "id": area.id,
            "name": area.name,
            "type": area.type,
            "created": area.created,
            "lastFocused": area.lastFocused,
            "focusCount": area.focusCount,
            "tags": area.metadata.get("tags", [])
        })

        # Update metadata
        index["totalAreas"] = len(index["areas"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self.write_json(index_file, index)

    def update_session_index(self, index_file: Path, session: Any) -> None:
        """
        Update session index with session information.

        Args:
            index_file: Path to the sessions/index.json file
            session: Session dataclass instance

        Note:
            If session already exists in index, it will be replaced with new data.
        """
        index = self.read_json(index_file)

        # Remove existing entry if present
        index["sessions"] = [s for s in index["sessions"] if s["sessionId"] != session.sessionId]

        # Add updated entry
        index["sessions"].append({
            "sessionId": session.sessionId,
            "areaId": session.areaId,
            "startedAt": session.startedAt,
            "endedAt": session.endedAt,
            "duration": session.duration,
            "summary": session.summary
        })

        # Update metadata
        index["totalSessions"] = len(index["sessions"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self.write_json(index_file, index)

    def update_snapshot_index(self, index_file: Path, snapshot: Any) -> None:
        """
        Update snapshot index with snapshot information.

        Args:
            index_file: Path to the snapshots/index.json file
            snapshot: ContextSnapshot dataclass instance

        Note:
            If snapshot already exists in index, it will be replaced with new data.
        """
        index = self.read_json(index_file)

        # Remove existing entry if present
        index["snapshots"] = [s for s in index["snapshots"] if s["name"] != snapshot.name]

        # Add updated entry
        index["snapshots"].append({
            "name": snapshot.name,
            "description": snapshot.description,
            "savedAt": snapshot.savedAt,
            "currentArea": snapshot.currentArea,
            "tags": snapshot.tags
        })

        # Update metadata
        index["totalSnapshots"] = len(index["snapshots"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self.write_json(index_file, index)

    # Directory Operations

    def ensure_directory(self, dir_path: Path) -> None:
        """
        Ensure a directory exists, creating it if necessary.

        Args:
            dir_path: Path to the directory

        Note:
            Creates all parent directories as needed.
            Does not fail if directory already exists.
        """
        dir_path.mkdir(parents=True, exist_ok=True)

    # File Operations

    def file_exists(self, file_path: Path) -> bool:
        """
        Check if a file exists.

        Args:
            file_path: Path to the file

        Returns:
            True if file exists, False otherwise
        """
        return file_path.exists() and file_path.is_file()

    def list_files(self, dir_path: Path, pattern: str = "*") -> List[Path]:
        """
        List files in a directory matching a pattern.

        Args:
            dir_path: Path to the directory
            pattern: Glob pattern to match files (default: "*")

        Returns:
            List of Path objects matching the pattern

        Example:
            list_files(Path("/areas"), "*.json")  # All JSON files
        """
        if not dir_path.exists():
            return []

        return list(dir_path.glob(pattern))

    def delete_file(self, file_path: Path, missing_ok: bool = False) -> None:
        """
        Delete a file.

        Args:
            file_path: Path to the file to delete
            missing_ok: If True, don't raise error if file doesn't exist

        Raises:
            FileNotFoundError: If file doesn't exist and missing_ok is False
        """
        if not file_path.exists():
            if not missing_ok:
                raise FileNotFoundError(f"File not found: {file_path}")
            return

        file_path.unlink()
