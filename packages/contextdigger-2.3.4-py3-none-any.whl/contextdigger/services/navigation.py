"""
NavigationService - Handles navigation history and breadcrumb operations.

This service is responsible for:
- Managing navigation history (dig history)
- Back/forward navigation through history
- Closing history entries with duration tracking
- Managing current history index
"""

from pathlib import Path
from typing import List, Optional
from dataclasses import asdict
from datetime import datetime

from .storage import StorageService


class NavigationService:
    """Handles navigation history and breadcrumb operations."""

    def __init__(self, cdg_dir: Path):
        """
        Initialize NavigationService.

        Args:
            cdg_dir: Path to the .cdg directory
        """
        self.cdg_dir = Path(cdg_dir)
        self.storage = StorageService(self.cdg_dir.parent)
        self.history_file = self.cdg_dir / "history" / "history.json"
        self.config_file = self.cdg_dir / "config.json"

    # History Operations

    def get_dig_history(self, limit: Optional[int] = None) -> List:
        """
        Get dig navigation history.

        Args:
            limit: Maximum number of entries to return (None for all)

        Returns:
            List of DigHistoryEntry instances, newest first
        """
        # Import here to avoid circular imports
        from ..manager import DigHistoryEntry

        if not self.history_file.exists():
            return []

        history_data = self.storage.read_json(self.history_file)
        entries = [DigHistoryEntry(**entry) for entry in history_data.get("entries", [])]

        # Return newest first
        entries.reverse()

        if limit:
            entries = entries[:limit]

        return entries

    def add_to_history(self, area_id: str, areas_service) -> None:
        """
        Add current area transition to history.

        Args:
            area_id: Area ID being navigated to
            areas_service: AreasService instance for getting area info

        Note:
            Automatically closes previous history entry.
            Truncates future entries if navigating from middle of history.
            Respects max history size from config.
        """
        # Get area info
        area = areas_service.get_area(area_id)
        if not area:
            return

        # Close previous history entry if exists
        self._close_current_history_entry()

        # Get current history
        history_data = self.storage.read_json(self.history_file)
        entries = history_data.get("entries", [])

        # Get config for max size
        config = self.storage.read_json(self.config_file)
        max_size = config.get("history", {}).get("maxSize", 50)
        current_index = config.get("history", {}).get("currentIndex", -1)

        # If navigating from middle of history, truncate future entries
        if current_index >= 0 and current_index < len(entries) - 1:
            entries = entries[:current_index + 1]

        # Import here to avoid circular imports
        from ..manager import DigHistoryEntry

        # Create new history entry
        new_entry = DigHistoryEntry(
            areaId=area_id,
            areaName=area.name,
            enteredAt=datetime.utcnow().isoformat() + "Z"
        )

        # Add to entries
        entries.append(asdict(new_entry))

        # Trim to max size (keep most recent)
        if len(entries) > max_size:
            entries = entries[-max_size:]

        # Update history file
        history_data["entries"] = entries
        history_data["totalEntries"] = len(entries)
        history_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self.storage.write_json(self.history_file, history_data)

        # Update current index in config
        config["history"]["currentIndex"] = len(entries) - 1
        self.storage.write_json(self.config_file, config)

    # Navigation Operations

    def navigate_back(self) -> Optional[str]:
        """
        Navigate to previous area in history.

        Returns:
            Area ID to navigate to, or None if can't go back
        """
        config = self.storage.read_json(self.config_file)
        current_index = config.get("history", {}).get("currentIndex", -1)

        # Can't go back if at start or no history
        if current_index <= 0:
            return None

        # Get history
        history_data = self.storage.read_json(self.history_file)
        entries = history_data.get("entries", [])

        if current_index >= len(entries):
            return None

        # Go back one
        new_index = current_index - 1
        prev_entry = entries[new_index]

        # Update config
        config["history"]["currentIndex"] = new_index
        self.storage.write_json(self.config_file, config)

        return prev_entry["areaId"]

    def navigate_forward(self) -> Optional[str]:
        """
        Navigate to next area in history.

        Returns:
            Area ID to navigate to, or None if can't go forward
        """
        config = self.storage.read_json(self.config_file)
        current_index = config.get("history", {}).get("currentIndex", -1)

        # Get history
        history_data = self.storage.read_json(self.history_file)
        entries = history_data.get("entries", [])

        # Can't go forward if at end or no history
        if current_index < 0 or current_index >= len(entries) - 1:
            return None

        # Go forward one
        new_index = current_index + 1
        next_entry = entries[new_index]

        # Update config
        config["history"]["currentIndex"] = new_index
        self.storage.write_json(self.config_file, config)

        return next_entry["areaId"]

    # Internal Methods

    def _close_current_history_entry(self) -> None:
        """
        Close the current history entry by setting exit time and duration.

        Note:
            Internal method called automatically by add_to_history.
            Only closes entry if not already closed.
        """
        config = self.storage.read_json(self.config_file)
        current_index = config.get("history", {}).get("currentIndex", -1)

        if current_index < 0:
            return

        history_data = self.storage.read_json(self.history_file)
        entries = history_data.get("entries", [])

        if current_index >= len(entries):
            return

        current_entry = entries[current_index]

        # Only close if not already closed
        if current_entry.get("exitedAt"):
            return

        # Set exit time
        now = datetime.utcnow().isoformat() + "Z"
        current_entry["exitedAt"] = now

        # Calculate duration
        entered_at = datetime.fromisoformat(current_entry["enteredAt"].replace("Z", "+00:00"))
        exited_at = datetime.fromisoformat(now.replace("Z", "+00:00"))
        duration = int((exited_at - entered_at).total_seconds())
        current_entry["duration"] = duration

        # Save updated history
        self.storage.write_json(self.history_file, history_data)
