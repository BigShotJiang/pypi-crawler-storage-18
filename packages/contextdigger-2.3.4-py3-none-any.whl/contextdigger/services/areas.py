"""
AreasService - Handles focus area CRUD and management operations.

This service is responsible for:
- Creating, reading, updating, and deleting focus areas
- Searching and querying areas
- Pattern matching for area files
- File discovery within areas
"""

import fnmatch
from pathlib import Path
from typing import List, Optional
from dataclasses import asdict
from datetime import datetime

from .storage import StorageService


class AreasService:
    """Handles focus area management operations."""

    def __init__(self, cdg_dir: Path):
        """
        Initialize AreasService.

        Args:
            cdg_dir: Path to the .cdg directory
        """
        self.cdg_dir = Path(cdg_dir)
        self.storage = StorageService(self.cdg_dir.parent)
        self.areas_dir = self.cdg_dir / "areas"

    # CRUD Operations

    def save_area(self, area) -> None:
        """
        Save a focus area to disk.

        Args:
            area: FocusArea dataclass instance

        Note:
            Automatically updates the areas index.
        """
        area_file = self.areas_dir / f"{area.id}.json"
        self.storage.write_json(area_file, asdict(area))

        # Update index
        index_file = self.areas_dir / "index.json"
        self.storage.update_area_index(index_file, area)

    def get_area(self, area_id: str):
        """
        Load a focus area by ID.

        Args:
            area_id: Unique identifier for the area

        Returns:
            FocusArea instance if found, None otherwise
        """
        # Import here to avoid circular imports
        from ..manager import FocusArea

        area_file = self.areas_dir / f"{area_id}.json"
        if not area_file.exists():
            return None

        data = self.storage.read_json(area_file)
        return FocusArea(**data)

    def list_areas(self) -> List:
        """
        List all focus areas.

        Returns:
            List of FocusArea instances, sorted by focus count (most used first), then by name
        """
        # Import here to avoid circular imports
        from ..manager import FocusArea

        if not self.areas_dir.exists():
            return []

        areas = []
        for area_file in self.areas_dir.glob("*.json"):
            if area_file.name == "index.json":
                continue
            data = self.storage.read_json(area_file)
            areas.append(FocusArea(**data))

        # Sort by focus count (most used first), then by name
        areas.sort(key=lambda a: (-a.focusCount, a.name))
        return areas

    def find_areas(self, query: str) -> List:
        """
        Find areas matching a search query.

        Args:
            query: Search string to match against ID, name, description, and tags

        Returns:
            List of matching FocusArea instances, sorted by relevance

        Scoring:
            - Exact ID match: 100 points
            - Exact name match: 90 points
            - ID contains query: 70 points
            - Name contains query: 60 points
            - Tags contain query: 50 points
            - Description contains query: 40 points
        """
        all_areas = self.list_areas()
        query_lower = query.lower()

        matches = []
        for area in all_areas:
            # Exact match on ID
            if area.id == query or area.id.lower() == query_lower:
                matches.append((area, 100))
            # Exact match on name
            elif area.name.lower() == query_lower:
                matches.append((area, 90))
            # ID contains query
            elif query_lower in area.id.lower():
                matches.append((area, 70))
            # Name contains query
            elif query_lower in area.name.lower():
                matches.append((area, 60))
            # Description contains query
            elif query_lower in area.description.lower():
                matches.append((area, 40))
            # Tags contain query
            elif any(query_lower in tag.lower() for tag in area.metadata.get("tags", [])):
                matches.append((area, 50))

        # Sort by relevance score (highest first)
        matches.sort(key=lambda x: -x[1])
        return [area for area, score in matches]

    def delete_area(self, area_id: str) -> bool:
        """
        Delete a focus area.

        Args:
            area_id: ID of the area to delete

        Returns:
            True if area was deleted, False if area didn't exist
        """
        area_file = self.areas_dir / f"{area_id}.json"
        if not area_file.exists():
            return False

        area_file.unlink()

        # Update index
        index_file = self.areas_dir / "index.json"
        index = self.storage.read_json(index_file)
        index["areas"] = [a for a in index["areas"] if a["id"] != area_id]
        index["totalAreas"] = len(index["areas"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self.storage.write_json(index_file, index)

        return True

    # Pattern Matching

    def matches_pattern(self, file_path: str, area) -> bool:
        """
        Check if a file path matches an area's include/exclude patterns.

        Args:
            file_path: File path to check (relative to project root)
            area: FocusArea instance with patterns

        Returns:
            True if file matches (included and not excluded), False otherwise

        Pattern Matching:
            - Exclude patterns are checked first
            - If file matches any exclude pattern, returns False
            - Then checks if file matches any include pattern
            - Supports glob patterns including ** (recursive)
        """
        path = Path(file_path)
        file_path_str = str(file_path)

        # Helper to match a pattern
        def pattern_matches(pattern_str: str) -> bool:
            # Try Path.match (handles ** well for many cases)
            try:
                if path.match(pattern_str):
                    return True
            except ValueError:
                pass

            # Also try fnmatch for simple patterns
            if fnmatch.fnmatch(file_path_str, pattern_str):
                return True

            # Handle ** explicitly by replacing with * for intermediate dirs
            if '**' in pattern_str:
                # Convert ** to match zero or more path segments
                parts = pattern_str.split('/')

                # Build regex-like matching
                from pathlib import PurePath
                test_path = PurePath(file_path)
                test_parts = test_path.parts

                # Simple check: if pattern is like "src/**/*.py"
                # Match paths like "src/main.py" or "src/utils/helper.py"
                if len(parts) >= 2:
                    # Check if first part matches
                    if parts[0] != '**' and len(test_parts) > 0:
                        if not fnmatch.fnmatch(test_parts[0], parts[0]):
                            return False

                    # Check if last part matches
                    if parts[-1] != '**' and len(test_parts) > 0:
                        if not fnmatch.fnmatch(test_parts[-1], parts[-1]):
                            return False

                    # If we get here, it's a potential match
                    # Full path should start with first non-** part and end with last non-** part
                    if parts[0] != '**' and parts[-1] != '**':
                        # For pattern src/**/*.py, accept src/main.py, src/a/b.py, etc.
                        return True

            return False

        # Check exclude patterns first
        for pattern in area.patterns.get("exclude", []):
            if pattern_matches(pattern):
                return False

        # Check include patterns
        for pattern in area.patterns.get("include", []):
            if pattern_matches(pattern):
                return True

        return False

    # File Discovery

    def get_files_in_area(self, area, project_root: Path, max_files: int = 1000) -> List[Path]:
        """
        Get all files matching an area's patterns.

        Args:
            area: FocusArea instance
            project_root: Root directory to search from
            max_files: Maximum number of files to return

        Returns:
            List of relative file paths matching the area's patterns

        Note:
            Files are discovered using glob patterns from area.patterns["include"]
            and filtered by area.patterns["exclude"]
        """
        files = []
        exclude_patterns = area.patterns.get("exclude", [])
        project_root = Path(project_root)

        for include_pattern in area.patterns.get("include", []):
            # Use glob to find matching files
            for file_path in project_root.glob(include_pattern):
                if not file_path.is_file():
                    continue

                # Get relative path
                try:
                    rel_path = file_path.relative_to(project_root)
                except ValueError:
                    continue

                # Check exclude patterns
                excluded = False
                for exclude_pattern in exclude_patterns:
                    if fnmatch.fnmatch(str(rel_path), exclude_pattern):
                        excluded = True
                        break

                if not excluded:
                    files.append(rel_path)
                    if len(files) >= max_files:
                        return files

        return files
