"""
SessionsService - Handles session lifecycle and tracking operations.

This service is responsible for:
- Starting and ending focus sessions
- Tracking current active session
- Session history and archiving
- Integration with areas (focus count, last focused)
"""

from pathlib import Path
from typing import List, Optional
from dataclasses import asdict
from datetime import datetime

from .storage import StorageService


class SessionsService:
    """Handles session lifecycle and tracking operations."""

    def __init__(self, cdg_dir: Path):
        """
        Initialize SessionsService.

        Args:
            cdg_dir: Path to the .cdg directory
        """
        self.cdg_dir = Path(cdg_dir)
        self.storage = StorageService(self.cdg_dir.parent)
        self.sessions_dir = self.cdg_dir / "sessions"

    # Session Lifecycle

    def get_current_session(self):
        """
        Get the current active session.

        Returns:
            Session instance if active session exists, None otherwise
        """
        # Import here to avoid circular imports
        from ..manager import Session

        session_file = self.sessions_dir / "current.json"
        if not session_file.exists():
            return None

        data = self.storage.read_json(session_file)
        return Session(**data)

    def start_session(self, area_id: str, areas_service):
        """
        Start a new focus session for an area.

        Args:
            area_id: ID of the area to start session for
            areas_service: AreasService instance for updating area metadata

        Returns:
            Created Session instance

        Note:
            Automatically ends current session if one is active.
            Updates area's focusCount and lastFocused timestamp.
        """
        # Import here to avoid circular imports
        from ..manager import Session

        # End current session if exists
        current = self.get_current_session()
        if current:
            self.end_session()

        # Create new session
        session_id = datetime.utcnow().isoformat() + "Z"
        session = Session(
            sessionId=session_id,
            areaId=area_id,
            startedAt=session_id
        )

        # Save as current
        session_file = self.sessions_dir / "current.json"
        self.storage.write_json(session_file, asdict(session))

        # Update area's focus count and last focused
        area = areas_service.get_area(area_id)
        if area:
            area.focusCount += 1
            area.lastFocused = session_id
            areas_service.save_area(area)

        return session

    def end_session(self, summary: str = ""):
        """
        End the current active session.

        Args:
            summary: Optional summary of session activities

        Returns:
            Ended Session instance if session was active, None otherwise

        Note:
            Archives session to disk and removes current session file.
            Updates session index.
        """
        session_file = self.sessions_dir / "current.json"
        if not session_file.exists():
            return None

        # Load current session
        session = self.get_current_session()
        if not session:
            return None

        # Update session
        session.endedAt = datetime.utcnow().isoformat() + "Z"
        start = datetime.fromisoformat(session.startedAt.replace("Z", "+00:00"))
        end = datetime.fromisoformat(session.endedAt.replace("Z", "+00:00"))
        session.duration = int((end - start).total_seconds())

        if summary:
            session.summary = summary

        # Archive session
        archive_file = self.sessions_dir / f"{session.sessionId.replace(':', '-')}.json"
        self.storage.write_json(archive_file, asdict(session))

        # Update index
        index_file = self.sessions_dir / "index.json"
        self.storage.update_session_index(index_file, session)

        # Remove current session file
        session_file.unlink()

        return session

    # Session History

    def get_session_history(self, limit: int = 10) -> List:
        """
        Get recent session history.

        Args:
            limit: Maximum number of sessions to return (default 10)

        Returns:
            List of Session instances, sorted by start time (most recent first)

        Note:
            Only returns archived sessions (excludes current active session).
        """
        # Import here to avoid circular imports
        from ..manager import Session

        if not self.sessions_dir.exists():
            return []

        sessions = []
        for session_file in self.sessions_dir.glob("*.json"):
            # Skip index and current session files
            if session_file.name in ("index.json", "current.json"):
                continue

            data = self.storage.read_json(session_file)
            sessions.append(Session(**data))

        # Sort by start time (most recent first)
        sessions.sort(key=lambda s: s.startedAt, reverse=True)
        return sessions[:limit]
