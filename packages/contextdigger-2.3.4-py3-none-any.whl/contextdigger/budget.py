"""
ContextDigger Attention Budget System

Tracks and enforces attention budgets through context aperture control.
Implements focus discipline through attention budget limits.

Context Aperture: f/15 (15 files maximum) - like a camera aperture
Attention Budget: 3,000 lines maximum - optimal AI context processing

Phase 1.3: Budget Governance
- Budget alerts at configurable thresholds
- Governance policies with enforcement modes
- Budget violation handling
- Policy compliance checking
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Optional, Dict, Tuple
import json


# ============================================================================
# Enums for Budget Governance
# ============================================================================


class AlertLevel(Enum):
    """Alert severity levels for budget warnings."""

    INFO = "info"  # 50% threshold
    WARNING = "warning"  # 80% threshold
    CRITICAL = "critical"  # 90% threshold
    EXCEEDED = "exceeded"  # Over budget


class EnforcementMode(Enum):
    """Policy enforcement modes."""

    STRICT = "strict"  # Block operations that violate budget
    WARNING = "warning"  # Warn but allow operations
    ADVISORY = "advisory"  # Suggest alternatives only


class ViolationAction(Enum):
    """Actions to take when budget is violated."""

    BLOCK = "block"  # Block the operation
    LOG = "log"  # Log the violation
    NOTIFY = "notify"  # Notify user
    SUGGEST = "suggest"  # Suggest alternatives


# ============================================================================
# Budget Alert
# ============================================================================


@dataclass
class BudgetAlert:
    """Represents a budget alert when thresholds are exceeded."""

    level: AlertLevel
    metric: str  # "files" or "lines"
    current_value: int
    max_value: int
    threshold: float  # 0.0-1.0
    message: str
    triggered_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def percentage(self) -> float:
        """Calculate percentage of budget used."""
        if self.max_value == 0:
            return 0.0
        return self.current_value / self.max_value

    @property
    def icon(self) -> str:
        """Get icon for alert level."""
        icons = {
            AlertLevel.INFO: "ℹ️",
            AlertLevel.WARNING: "⚠️",
            AlertLevel.CRITICAL: "🔴",
            AlertLevel.EXCEEDED: "❌",
        }
        return icons.get(self.level, "⚠️")

    def format_message(self) -> str:
        """Format alert message for display."""
        percentage = self.percentage * 100
        return (
            f"{self.icon} {self.message}: "
            f"{self.current_value:,}/{self.max_value:,} {self.metric} "
            f"({percentage:.0f}%)"
        )


# ============================================================================
# Governance Policy
# ============================================================================


@dataclass
class GovernancePolicy:
    """Defines governance rules for budget enforcement."""

    policy_id: str
    name: str
    enabled: bool
    enforcement_mode: EnforcementMode
    max_files: int
    max_lines: int
    alert_thresholds: List[float] = field(default_factory=lambda: [0.8, 0.9])
    violation_actions: List[ViolationAction] = field(
        default_factory=lambda: [ViolationAction.LOG, ViolationAction.NOTIFY]
    )
    description: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def is_strict(self) -> bool:
        """Check if policy uses strict enforcement."""
        return self.enforcement_mode == EnforcementMode.STRICT

    @property
    def allows_blocking(self) -> bool:
        """Check if policy allows blocking operations."""
        return ViolationAction.BLOCK in self.violation_actions

    def to_dict(self) -> dict:
        """Serialize policy to dictionary."""
        return {
            "policy_id": self.policy_id,
            "name": self.name,
            "enabled": self.enabled,
            "enforcement_mode": self.enforcement_mode.value,
            "max_files": self.max_files,
            "max_lines": self.max_lines,
            "alert_thresholds": self.alert_thresholds,
            "violation_actions": [a.value for a in self.violation_actions],
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @staticmethod
    def from_dict(data: dict) -> "GovernancePolicy":
        """Deserialize policy from dictionary."""
        return GovernancePolicy(
            policy_id=data["policy_id"],
            name=data["name"],
            enabled=data["enabled"],
            enforcement_mode=EnforcementMode(data["enforcement_mode"]),
            max_files=data["max_files"],
            max_lines=data["max_lines"],
            alert_thresholds=data.get("alert_thresholds", [0.8, 0.9]),
            violation_actions=[
                ViolationAction(a) for a in data.get("violation_actions", ["log", "notify"])
            ],
            description=data.get("description", ""),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
        )


# ============================================================================
# Violation Result
# ============================================================================


@dataclass
class ViolationResult:
    """Result of handling a budget violation."""

    blocked: bool
    actions_taken: List[str]
    alerts: List[BudgetAlert]
    policy: GovernancePolicy
    budget: "BudgetStatus"

    @property
    def has_violations(self) -> bool:
        """Check if there are any violations."""
        return len(self.alerts) > 0


# ============================================================================
# Budget Status
# ============================================================================


@dataclass
class BudgetStatus:
    """Represents the attention budget status for a set of files."""

    files_used: int
    files_max: int
    lines_used: int
    lines_max: int

    @property
    def percentage_files(self) -> float:
        """Percentage of context aperture used."""
        if self.files_max == 0:
            return 0.0
        return self.files_used / self.files_max

    @property
    def percentage_lines(self) -> float:
        """Percentage of attention budget used."""
        if self.lines_max == 0:
            return 0.0
        return self.lines_used / self.lines_max

    @property
    def exceeds(self) -> bool:
        """True if attention budget is exceeded."""
        return self.files_used > self.files_max or self.lines_used > self.lines_max

    @property
    def within_budget(self) -> bool:
        """True if within attention budget."""
        return not self.exceeds

    @property
    def at_warning_threshold(self) -> bool:
        """True if at or above 80% attention budget usage."""
        return self.percentage_files >= 0.8 or self.percentage_lines >= 0.8


class BudgetTracker:
    """
    Tracks attention budget usage through context aperture control.

    Implements the core governance mechanism: attention budgets are ENFORCED
    through aperture constraints. This is the foundation of focus discipline.

    Context Aperture: f/15 (15 files) - narrower = sharper AI focus
    Attention Budget: 3,000 lines - optimal AI context processing

    Phase 1.3: Enhanced with budget alerts and policy enforcement.
    """

    def __init__(
        self,
        max_files: int = 15,
        max_lines: int = 3000,
        alert_thresholds: Optional[List[float]] = None,
    ):
        """
        Initialize attention budget tracker.

        Args:
            max_files: Context aperture setting (default: f/15)
            max_lines: Attention budget limit (default: 3,000 lines)
            alert_thresholds: List of thresholds for alerts (default: [0.8, 0.9])
        """
        self.max_files = max_files
        self.max_lines = max_lines
        self.alert_thresholds = alert_thresholds or [0.8, 0.9]
        self._line_count_cache = {}  # Cache for file line counts

    def calculate_budget(self, files: List[Path]) -> BudgetStatus:
        """
        Calculate attention budget usage for a set of files.

        Args:
            files: List of file paths

        Returns:
            BudgetStatus with context aperture and attention budget usage
        """
        file_count = len(files)
        line_count = sum(self._count_lines(f) for f in files)

        return BudgetStatus(
            files_used=file_count,
            files_max=self.max_files,
            lines_used=line_count,
            lines_max=self.max_lines
        )

    def is_within_budget(self, files: List[Path]) -> bool:
        """
        Check if files fit within budget.

        Args:
            files: List of file paths

        Returns:
            True if within budget, False otherwise
        """
        budget = self.calculate_budget(files)
        return budget.within_budget

    def format_budget_display(self, budget: BudgetStatus) -> str:
        """
        Format budget for display.

        Args:
            budget: BudgetStatus to format

        Returns:
            Formatted string like "Budget: 12/15 files, 2,340/3,000 lines."
        """
        return (
            f"Budget: {budget.files_used}/{budget.files_max} files, "
            f"{budget.lines_used:,}/{budget.lines_max:,} lines."
        )

    def _count_lines(self, file_path: Path) -> int:
        """
        Count lines in a file.

        Uses cache to avoid re-counting unchanged files.

        Args:
            file_path: Path to file

        Returns:
            Number of lines in file
        """
        file_path = Path(file_path)

        # Check cache
        cache_key = str(file_path.absolute())
        if cache_key in self._line_count_cache:
            cached_mtime, cached_count = self._line_count_cache[cache_key]
            if file_path.exists() and file_path.stat().st_mtime == cached_mtime:
                return cached_count

        # Count lines
        try:
            if not file_path.exists():
                return 0

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                count = sum(1 for _ in f)

            # Update cache
            self._line_count_cache[cache_key] = (file_path.stat().st_mtime, count)
            return count

        except Exception:
            # If we can't read the file, assume 0 lines
            return 0

    def get_budget_breakdown(self, files: List[Path]) -> dict:
        """
        Get detailed budget breakdown by file.

        Args:
            files: List of file paths

        Returns:
            Dict with per-file line counts and totals
        """
        file_details = []
        total_lines = 0

        for file_path in files:
            lines = self._count_lines(file_path)
            total_lines += lines
            file_details.append({
                'file': str(file_path),
                'lines': lines,
                'percentage': 0.0  # Will calculate after we have total
            })

        # Calculate percentages
        for detail in file_details:
            if total_lines > 0:
                detail['percentage'] = detail['lines'] / total_lines

        return {
            'files': file_details,
            'total_files': len(files),
            'total_lines': total_lines,
            'max_files': self.max_files,
            'max_lines': self.max_lines
        }

    def generate_alerts(self, budget: BudgetStatus) -> List[BudgetAlert]:
        """
        Generate budget alerts based on current usage and thresholds.

        Args:
            budget: Current budget status

        Returns:
            List of triggered alerts
        """
        alerts = []

        # Check files metric
        files_pct = budget.percentage_files
        files_alerts = self._generate_metric_alerts(
            metric="files",
            current=budget.files_used,
            maximum=budget.files_max,
            percentage=files_pct,
        )
        alerts.extend(files_alerts)

        # Check lines metric
        lines_pct = budget.percentage_lines
        lines_alerts = self._generate_metric_alerts(
            metric="lines",
            current=budget.lines_used,
            maximum=budget.lines_max,
            percentage=lines_pct,
        )
        alerts.extend(lines_alerts)

        return alerts

    def _generate_metric_alerts(
        self, metric: str, current: int, maximum: int, percentage: float
    ) -> List[BudgetAlert]:
        """Generate alerts for a specific metric."""
        alerts = []

        # Check if exceeded
        if current > maximum:
            alerts.append(
                BudgetAlert(
                    level=AlertLevel.EXCEEDED,
                    metric=metric,
                    current_value=current,
                    max_value=maximum,
                    threshold=1.0,
                    message=f"Budget exceeded for {metric}",
                )
            )
            return alerts  # Return early if exceeded

        # Check thresholds
        for threshold in sorted(self.alert_thresholds, reverse=True):
            if percentage >= threshold:
                # Determine alert level based on threshold
                if threshold >= 0.9:
                    level = AlertLevel.CRITICAL
                    message = f"Critical: {metric} at {threshold * 100:.0f}% of budget"
                elif threshold >= 0.8:
                    level = AlertLevel.WARNING
                    message = f"Warning: {metric} at {threshold * 100:.0f}% of budget"
                else:
                    level = AlertLevel.INFO
                    message = f"Info: {metric} at {threshold * 100:.0f}% of budget"

                alerts.append(
                    BudgetAlert(
                        level=level,
                        metric=metric,
                        current_value=current,
                        max_value=maximum,
                        threshold=threshold,
                        message=message,
                    )
                )
                break  # Only trigger highest applicable threshold

        return alerts

    def check_policy_compliance(
        self, budget: BudgetStatus, policy: GovernancePolicy
    ) -> Tuple[bool, List[str]]:
        """
        Check if budget complies with governance policy.

        Args:
            budget: Current budget status
            policy: Governance policy to check against

        Returns:
            Tuple of (is_compliant, list_of_violations)
        """
        if not policy.enabled:
            return True, []

        violations = []

        # Check files limit
        if budget.files_used > policy.max_files:
            violations.append(
                f"Files ({budget.files_used}) exceed policy limit ({policy.max_files})"
            )

        # Check lines limit
        if budget.lines_used > policy.max_lines:
            violations.append(
                f"Lines ({budget.lines_used:,}) exceed policy limit ({policy.max_lines:,})"
            )

        # Check alert thresholds
        files_pct = budget.percentage_files
        lines_pct = budget.percentage_lines

        for threshold in policy.alert_thresholds:
            if files_pct >= threshold:
                violations.append(
                    f"Files at {files_pct * 100:.0f}% (threshold: {threshold * 100:.0f}%)"
                )
                break

        for threshold in policy.alert_thresholds:
            if lines_pct >= threshold:
                violations.append(
                    f"Lines at {lines_pct * 100:.0f}% (threshold: {threshold * 100:.0f}%)"
                )
                break

        return len(violations) == 0, violations

    def handle_violation(
        self, budget: BudgetStatus, policy: GovernancePolicy
    ) -> ViolationResult:
        """
        Handle budget violations according to policy.

        Args:
            budget: Current budget status
            policy: Governance policy

        Returns:
            ViolationResult with actions taken
        """
        # Generate alerts
        alerts = self.generate_alerts(budget)

        # Check compliance
        compliant, violations = self.check_policy_compliance(budget, policy)

        # Determine if operation should be blocked
        blocked = False
        actions_taken = []

        if not compliant and policy.enabled:
            # Handle based on enforcement mode
            if policy.enforcement_mode == EnforcementMode.STRICT:
                if ViolationAction.BLOCK in policy.violation_actions:
                    blocked = True
                    actions_taken.append("Block operation due to budget violation")

            # Log violation
            if ViolationAction.LOG in policy.violation_actions:
                actions_taken.append(f"Log violation: {', '.join(violations)}")

            # Notify user
            if ViolationAction.NOTIFY in policy.violation_actions:
                actions_taken.append("Notify user of budget violation")

            # Suggest alternatives
            if ViolationAction.SUGGEST in policy.violation_actions:
                actions_taken.append("Suggest reducing file count or narrowing focus")

        return ViolationResult(
            blocked=blocked,
            actions_taken=actions_taken,
            alerts=alerts,
            policy=policy,
            budget=budget,
        )

    def get_budget_health(self, budget: BudgetStatus) -> str:
        """
        Get overall budget health status.

        Args:
            budget: Current budget status

        Returns:
            Health status: "healthy", "warning", "critical", "exceeded"
        """
        # Check if exceeded
        if budget.exceeds:
            return "exceeded"

        # Get max percentage
        max_pct = max(budget.percentage_files, budget.percentage_lines)

        # Determine health level
        if max_pct >= 0.9:
            return "critical"
        elif max_pct >= 0.8:
            return "warning"
        else:
            return "healthy"


def create_budget_tracker_from_config(config: dict) -> BudgetTracker:
    """
    Create BudgetTracker from configuration.

    Args:
        config: Configuration dict with 'budgets' section

    Returns:
        BudgetTracker instance
    """
    budgets = config.get('budgets', {})
    max_files = budgets.get('max_files', 15)
    max_lines = budgets.get('max_lines', 3000)

    return BudgetTracker(max_files=max_files, max_lines=max_lines)


# ============================================================================
# Phase 1.4: Policy Persistence & Audit Logging
# ============================================================================


class AuditEventType(Enum):
    """Types of audit events."""

    BUDGET_CHECK = "budget_check"
    POLICY_VIOLATION = "policy_violation"
    POLICY_COMPLIANCE = "policy_compliance"
    POLICY_CREATED = "policy_created"
    POLICY_UPDATED = "policy_updated"
    POLICY_ENABLED = "policy_enabled"
    POLICY_DISABLED = "policy_disabled"


@dataclass
class AuditEntry:
    """Represents an audit log entry."""

    event_type: AuditEventType
    timestamp: str
    policy_id: str
    budget_status: Dict
    violations: List[str]
    actions_taken: List[str]
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Serialize audit entry to dictionary."""
        return {
            "event_type": self.event_type.value,
            "timestamp": self.timestamp,
            "policy_id": self.policy_id,
            "budget_status": self.budget_status,
            "violations": self.violations,
            "actions_taken": self.actions_taken,
            "metadata": self.metadata,
        }

    @staticmethod
    def from_dict(data: dict) -> "AuditEntry":
        """Deserialize audit entry from dictionary."""
        return AuditEntry(
            event_type=AuditEventType(data["event_type"]),
            timestamp=data["timestamp"],
            policy_id=data["policy_id"],
            budget_status=data["budget_status"],
            violations=data["violations"],
            actions_taken=data["actions_taken"],
            metadata=data.get("metadata", {}),
        )


class PolicyManager:
    """
    Manages governance policies with persistence.

    Provides policy storage, retrieval, and management capabilities.
    """

    def __init__(self, project_root: Path):
        """
        Initialize policy manager.

        Args:
            project_root: Project root directory
        """
        self.project_root = Path(project_root)
        self.policies_dir = self.project_root / ".cdg" / "policies"
        self.policies_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.project_root / ".cdg" / "config.json"

    def save_policy(self, policy: GovernancePolicy) -> None:
        """
        Save a governance policy.

        Args:
            policy: GovernancePolicy to save
        """
        policy_file = self.policies_dir / f"{policy.policy_id}.json"

        with open(policy_file, "w") as f:
            json.dump(policy.to_dict(), f, indent=2)

    def load_policy(self, policy_id: str) -> Optional[GovernancePolicy]:
        """
        Load a governance policy.

        Args:
            policy_id: Policy ID to load

        Returns:
            GovernancePolicy or None if not found
        """
        policy_file = self.policies_dir / f"{policy_id}.json"

        if not policy_file.exists():
            return None

        try:
            with open(policy_file, "r") as f:
                data = json.load(f)
            return GovernancePolicy.from_dict(data)
        except Exception:
            return None

    def list_policies(self) -> List[GovernancePolicy]:
        """
        List all saved policies.

        Returns:
            List of GovernancePolicy objects
        """
        policies = []

        for policy_file in self.policies_dir.glob("*.json"):
            try:
                with open(policy_file, "r") as f:
                    data = json.load(f)
                policies.append(GovernancePolicy.from_dict(data))
            except Exception:
                continue

        return policies

    def delete_policy(self, policy_id: str) -> bool:
        """
        Delete a policy.

        Args:
            policy_id: Policy ID to delete

        Returns:
            True if deleted, False if not found
        """
        policy_file = self.policies_dir / f"{policy_id}.json"

        if not policy_file.exists():
            return False

        try:
            policy_file.unlink()
            return True
        except Exception:
            return False

    def get_active_policy(self) -> GovernancePolicy:
        """
        Get the currently active governance policy.

        Returns:
            Active GovernancePolicy (defaults to default policy if none set)
        """
        # Load config
        config = {}
        if self.config_file.exists():
            try:
                with open(self.config_file, "r") as f:
                    config = json.load(f)
            except Exception:
                pass

        # Get active policy ID from config
        active_policy_id = config.get("governance", {}).get("active_policy")

        # Load active policy if set
        if active_policy_id:
            policy = self.load_policy(active_policy_id)
            if policy:
                return policy

        # Return default policy
        return GovernancePolicy(
            policy_id="default",
            name="Default Budget Policy",
            enabled=True,
            enforcement_mode=EnforcementMode.WARNING,
            max_files=15,
            max_lines=3000,
            alert_thresholds=[0.8, 0.9],
            violation_actions=[ViolationAction.LOG, ViolationAction.NOTIFY],
            description="Default governance policy for attention budgets",
        )

    def set_active_policy(self, policy_id: str) -> bool:
        """
        Set the active governance policy.

        Args:
            policy_id: Policy ID to set as active

        Returns:
            True if set successfully, False otherwise
        """
        # Verify policy exists
        policy = self.load_policy(policy_id)
        if not policy:
            return False

        # Load config
        config = {}
        if self.config_file.exists():
            try:
                with open(self.config_file, "r") as f:
                    config = json.load(f)
            except Exception:
                pass

        # Update config
        if "governance" not in config:
            config["governance"] = {}
        config["governance"]["active_policy"] = policy_id

        # Save config
        try:
            with open(self.config_file, "w") as f:
                json.dump(config, f, indent=2)
            return True
        except Exception:
            return False


class AuditLog:
    """
    Tracks budget violations and policy compliance over time.

    Provides audit logging for governance activities.
    """

    def __init__(self, project_root: Path):
        """
        Initialize audit log.

        Args:
            project_root: Project root directory
        """
        self.project_root = Path(project_root)
        self.audit_dir = self.project_root / ".cdg" / "audit"
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.audit_dir / "audit.jsonl"

    def log_event(
        self,
        event_type: AuditEventType,
        policy_id: str,
        budget_status: BudgetStatus,
        violations: List[str],
        actions_taken: List[str],
        metadata: Optional[Dict] = None,
    ) -> AuditEntry:
        """
        Log an audit event.

        Args:
            event_type: Type of event
            policy_id: Policy ID
            budget_status: Current budget status
            violations: List of violations (if any)
            actions_taken: Actions taken
            metadata: Additional metadata

        Returns:
            AuditEntry created
        """
        entry = AuditEntry(
            event_type=event_type,
            timestamp=datetime.now().isoformat(),
            policy_id=policy_id,
            budget_status={
                "files_used": budget_status.files_used,
                "files_max": budget_status.files_max,
                "lines_used": budget_status.lines_used,
                "lines_max": budget_status.lines_max,
            },
            violations=violations,
            actions_taken=actions_taken,
            metadata=metadata or {},
        )

        # Append to log file
        with open(self.log_file, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

        return entry

    def log_violation(
        self,
        policy: GovernancePolicy,
        budget: BudgetStatus,
        violations: List[str],
        actions_taken: List[str],
        metadata: Optional[Dict] = None,
    ) -> AuditEntry:
        """
        Log a policy violation.

        Args:
            policy: Governance policy
            budget: Current budget status
            violations: List of violations
            actions_taken: Actions taken
            metadata: Additional metadata

        Returns:
            AuditEntry created
        """
        return self.log_event(
            event_type=AuditEventType.POLICY_VIOLATION,
            policy_id=policy.policy_id,
            budget_status=budget,
            violations=violations,
            actions_taken=actions_taken,
            metadata=metadata,
        )

    def log_compliance(
        self,
        policy: GovernancePolicy,
        budget: BudgetStatus,
        metadata: Optional[Dict] = None,
    ) -> AuditEntry:
        """
        Log policy compliance.

        Args:
            policy: Governance policy
            budget: Current budget status
            metadata: Additional metadata

        Returns:
            AuditEntry created
        """
        return self.log_event(
            event_type=AuditEventType.POLICY_COMPLIANCE,
            policy_id=policy.policy_id,
            budget_status=budget,
            violations=[],
            actions_taken=[],
            metadata=metadata,
        )

    def get_entries(
        self,
        event_type: Optional[AuditEventType] = None,
        policy_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[AuditEntry]:
        """
        Get audit entries with optional filtering.

        Args:
            event_type: Filter by event type
            policy_id: Filter by policy ID
            limit: Maximum number of entries to return

        Returns:
            List of AuditEntry objects
        """
        if not self.log_file.exists():
            return []

        entries = []

        with open(self.log_file, "r") as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    entry = AuditEntry.from_dict(data)

                    # Apply filters
                    if event_type and entry.event_type != event_type:
                        continue
                    if policy_id and entry.policy_id != policy_id:
                        continue

                    entries.append(entry)
                except Exception:
                    continue

        # Apply limit
        if limit:
            entries = entries[-limit:]

        return entries

    def get_recent_violations(self, limit: int = 10) -> List[AuditEntry]:
        """
        Get recent policy violations.

        Args:
            limit: Maximum number of violations to return

        Returns:
            List of AuditEntry objects for violations
        """
        return self.get_entries(
            event_type=AuditEventType.POLICY_VIOLATION, limit=limit
        )

    def get_statistics(self) -> Dict:
        """
        Get audit statistics.

        Returns:
            Dictionary with audit statistics
        """
        entries = self.get_entries()

        total_events = len(entries)
        total_violations = sum(
            1 for e in entries if e.event_type == AuditEventType.POLICY_VIOLATION
        )
        total_compliance = sum(
            1 for e in entries if e.event_type == AuditEventType.POLICY_COMPLIANCE
        )

        compliance_rate = 0.0
        if total_violations + total_compliance > 0:
            compliance_rate = total_compliance / (total_violations + total_compliance)

        return {
            "total_events": total_events,
            "total_violations": total_violations,
            "total_compliance": total_compliance,
            "compliance_rate": compliance_rate,
        }
