"""
Command-line interface for contextdigger.

Provides all ContextDigger functionality via simple CLI commands.
This eliminates approval prompts when used from Claude Code skills.
"""

import sys
import json
from pathlib import Path
from typing import Optional, List
from dataclasses import asdict
from .manager import FocusManager, FocusArea, Bookmark, ContextSnapshot
from .discover import FocusAreaDiscovery
from .budget import BudgetTracker, create_budget_tracker_from_config
from .refusal import RefusalHandler, should_refuse
from .export import ContextExporter
from . import completions


def main():
    """Main CLI entry point."""
    if len(sys.argv) < 2:
        print_usage()
        return

    command = sys.argv[1]
    args = sys.argv[2:]

    # Handle completion commands (for shell autocomplete)
    if command == "completion":
        if len(args) == 0:
            print("Usage: contextdigger completion [bash|zsh|install|uninstall]")
            return
        shell = args[0]
        if shell == "bash":
            print(completions.generate_bash_completion())
        elif shell == "zsh":
            print(completions.generate_zsh_completion())
        elif shell == "install":
            completions.install_completion()
        elif shell == "uninstall":
            completions.uninstall_completion()
        else:
            print(f"Unknown option: {shell}")
            print("Supported: bash, zsh, install, uninstall")
        return

    # Handle internal completion helpers (called by shell scripts)
    if command == "--complete-commands":
        completions.print_commands()
        return
    elif command == "--complete-commands-with-desc":
        completions.print_commands_with_desc()
        return
    elif command == "--complete-areas":
        completions.print_areas()
        return
    elif command == "--complete-bookmarks":
        completions.print_bookmarks()
        return
    elif command == "--complete-contexts":
        completions.print_contexts()
        return

    # Map commands to functions
    commands = {
        # Help & Info
        "--help": print_usage,
        "-h": print_usage,
        "help": print_usage,
        "--version": cmd_version,

        # Core Navigation
        "init": cmd_init,
        "dig": cmd_dig,
        "redig": cmd_redig,
        "status": cmd_status,
        "back": cmd_back,
        "forward": cmd_forward,
        "history": cmd_history,

        # Bookmarks
        "mark-spot": cmd_mark_spot,
        "goto-spot": cmd_goto_spot,
        "list-spots": cmd_list_spots,
        "delete-spot": cmd_delete_spot,

        # Context Snapshots
        "save-context": cmd_save_context,
        "load-context": cmd_load_context,
        "list-contexts": cmd_list_contexts,
        "delete-context": cmd_delete_context,

        # Notes & Documentation
        "note": cmd_note,
        "notes": cmd_notes,
        "wiki": cmd_wiki,

        # Analysis & Intelligence
        "suggest": cmd_suggest,
        "deps": cmd_deps,
        "impact": cmd_impact,
        "map": cmd_map,
        "hotspots": cmd_hotspots,
        "gaps": cmd_gaps,
        "perf": cmd_perf,
        "benchmark": cmd_benchmark,

        # Search & Query
        "search": cmd_search,
        "query": cmd_query,

        # Automation
        "auto": cmd_auto,
        "rules": cmd_rules,

        # Reports & Export
        "analytics": cmd_analytics,
        "report": cmd_report,
        "export": cmd_export,
        "backup": cmd_backup,
        "provenance": cmd_provenance,

        # Dashboard & Monitoring
        "dashboard": cmd_dashboard,
        "health": cmd_health,
        "stats": cmd_stats,

        # Team
        "team": cmd_team,
        "tests": cmd_tests,

        # Sub-Area Management (NEW in v1.3.0)
        "split": cmd_split,
        "create-subarea": cmd_create_subarea,

        # Continuation Contracts (NEW in v1.4.0)
        "continue": cmd_continue,
        "pause": cmd_pause,
        "contracts": cmd_contracts,

        # Budget Governance (NEW in v1.4.0)
        "policy": cmd_policy,
        "audit": cmd_audit,

        # Intelligence & Insights (NEW in v2.0)
        "insights": cmd_insights,

        # Intelligence Expansion (NEW in v2.2.0)
        "trends": cmd_trends,
        "predictions": cmd_predictions,
        "remediate": cmd_remediate,
        "llm": cmd_llm,

        # Aliases
        "list": cmd_list,
        "dig-status": cmd_status,
    }

    if command in commands:
        try:
            commands[command](*args)
        except Exception as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            sys.exit(1)
    else:
        print(f"Unknown command: {command}")
        print_usage()
        sys.exit(1)


def print_usage():
    """Print usage information."""
    print("""
ContextDigger - Dig Deep Into Your Codebase

Usage:
  contextdigger <command> [arguments]

Core Navigation:
  init [-f|--force]     Initialize ContextDigger in current directory
  dig <area> [-v|-vv]   Dig into a code area (with verbosity)
  redig                 Interactive area selector
  status                Show current dig status
  back                  Navigate back in history
  forward               Navigate forward in history
  list                  List all discovered areas

Sub-Area Management (NEW in v1.3.0):
  split <area> [-v|-vv]          Split oversized area into sub-areas
  create-subarea <parent> <name> <pattern>  Create sub-area with pattern

Bookmarks:
  mark-spot [name]      Save current location as bookmark
  goto-spot <name>      Jump to bookmark
  list-spots            List all bookmarks
  delete-spot <name>    Delete a bookmark

Context Snapshots:
  save-context <name>   Save current context snapshot
  load-context <name>   Load context snapshot
  list-contexts         List all saved contexts
  delete-context <name> Delete context snapshot

Notes & Documentation:
  note <text>           Add note to current area
  notes [area]          View notes for area
  wiki                  Generate wiki documentation

Analysis & Intelligence:
  suggest               Get area suggestions
  deps [area]           Show dependencies
  impact <area>         Show impact analysis
  map                   Show codebase map
  hotspots              Find code hotspots
  gaps                  Find coverage gaps
  perf [area]           Performance analysis
  benchmark             Run benchmarks

Search & Query:
  search <query>        Search all data
  query <sql>           Run custom query

Automation:
  auto                  Show automation suggestions
  rules                 List automation rules

Reports & Export:
  analytics             Work analytics
  report [file]         Generate report
  export <format>       Export data
  backup                Create backup
  provenance [session]  Show file provenance (why files were loaded)

Dashboard & Monitoring:
  dashboard             Show dashboard
  health                Health check
  stats                 Statistics

Team:
  team                  Team activity
  tests                 Test coverage

Continuation Contracts (NEW in v1.4.0):
  continue              Resume last work session
  pause                 Pause current work and save state
  contracts [limit]     List all contracts (completed and paused)

Options:
  --version             Show version
  --help, -h            Show this help

Claude Code Skills (recommended):
  /init-dig             Initialize context discovery
  /dig <area>           Dig into a code area
  /dig-dashboard        Show dashboard

For full documentation:
  https://contextdigger.com
  https://github.com/ialameh/contextdigger#readme
    """)


def cmd_version():
    """Show version."""
    from . import __version__
    print(f"contextdigger {__version__}")


def get_manager() -> FocusManager:
    """Get manager instance and check if initialized."""
    manager = FocusManager(Path.cwd())
    if not manager.is_initialized():
        print("❌ ContextDigger not initialized")
        print("Run: contextdigger init")
        sys.exit(1)
    return manager


# =============================================================================
# Core Navigation
# =============================================================================

def cmd_init(*args):
    """Initialize context discovery system."""
    manager = FocusManager(Path.cwd())

    # Check for force flag
    force = '--force' in args or '-f' in args

    if manager.is_initialized() and not force:
        print("✓ ContextDigger already initialized")
        print()
        print("Use one of these commands:")
        print("  contextdigger dashboard  - View current status")
        print("  contextdigger list       - See all areas")
        print("  contextdigger init -f    - Force re-initialization")
        return

    manager.initialize()
    print("✓ Initialized .cdg/ directory")

    # Run discovery
    print("\n⛏️  Digging through codebase...")
    discovery = FocusAreaDiscovery(Path.cwd())
    areas = discovery.discover()

    # Save areas
    for area in areas:
        manager.save_area(area)

    print(f"\n✓ Discovered {len(areas)} code areas")
    print("\nUse 'contextdigger list' to see all areas")
    print("Use '/dig <area>' in Claude Code to start digging")


def _interactive_area_picker(manager: FocusManager) -> Optional[FocusArea]:
    """Launch interactive fuzzy picker for area selection.

    Returns:
        Selected FocusArea or None if cancelled/unavailable
    """
    try:
        import inquirer
    except ImportError:
        print("❌ Interactive picker not available")
        print("Install with: pip install 'contextdigger[interactive]'")
        print("\nOr use: cdg dig <area-name> for direct access")
        print("Or use: cdg dig --list for plain list")
        return None

    # Check if running in TTY (interactive terminal)
    if not sys.stdin.isatty():
        print("Not in interactive mode. Use: cdg dig --list")
        return None

    areas = manager.list_areas()

    if len(areas) == 0:
        print("No areas found. Run 'cdg init' first.")
        return None

    # If only 1-3 areas, just show them (no picker needed)
    if len(areas) <= 3:
        cmd_list()
        print("\nOnly a few areas. Use: cdg dig <area-name>")
        return None

    # Prepare choices for inquirer
    choices = []
    for area in areas:
        # Format: "area-name - Description here"
        label = f"{area.name}"
        if area.description:
            # Truncate description to 70 chars
            desc = area.description[:70]
            if len(area.description) > 70:
                desc += "..."
            label += f" - {desc}"
        choices.append((label, area))

    # Launch interactive picker with fuzzy search
    questions = [
        inquirer.List(
            'area',
            message="Select a code area to dig into (type to filter)",
            choices=choices,
            carousel=True,  # Wrap around at edges
        ),
    ]

    try:
        answers = inquirer.prompt(questions)
        if answers is None:  # User pressed Ctrl+C
            print("\nCancelled")
            return None

        selected_area = answers['area']
        print(f"\n✓ Selected: {selected_area.name}")
        return selected_area
    except KeyboardInterrupt:
        print("\nCancelled")
        return None


def cmd_dig(*args):
    """Dig into a code area."""
    manager = get_manager()

    # Parse verbosity flags
    verbosity = 0
    clean_args = []
    for arg in args:
        if arg == '-vv':
            verbosity = 2
        elif arg == '-v':
            verbosity = 1
        else:
            clean_args.append(arg)
    args = tuple(clean_args)

    # NEW: If no arguments, launch interactive picker
    if len(args) == 0:
        area = _interactive_area_picker(manager)
        if area is None:
            return  # User cancelled or picker unavailable
        args = (area.id,)  # Continue with selected area

    # Check for --list flag
    if len(args) == 1 and args[0] == "--list":
        cmd_list()
        return

    area_id = args[0]
    area = manager.get_area(area_id)

    if not area:
        # Try fuzzy match
        matches = manager.find_areas(area_id)
        if not matches:
            print(f"❌ No area found matching '{area_id}'")
            print("\nAvailable areas:")
            for a in manager.list_areas():
                print(f"  - {a.id}: {a.name}")
            sys.exit(1)
        elif len(matches) == 1:
            area = matches[0]
            print(f"Matched '{area_id}' to: {area.id}")
        else:
            print(f"Multiple areas match '{area_id}':")
            for i, match in enumerate(matches[:5], 1):
                print(f"  {i}. {match.id} - {match.name}")
            sys.exit(1)

    # Calculate budget and check for refusal
    try:
        config = manager.load_config()
        budget_tracker = create_budget_tracker_from_config(config)
        files = manager.get_files_in_area(area)
        budget_status = budget_tracker.calculate_budget(files)

        # CONTEXT APERTURE: Check if area exceeds attention budget
        if budget_status.exceeds:
            refusal_handler = RefusalHandler(
                max_files=budget_tracker.max_files,
                max_lines=budget_tracker.max_lines
            )

            # NEW: Interactive refusal with verbosity
            selected_area = refusal_handler.display_refusal_interactive(
                area_name=area.name,
                files=files,
                files_used=budget_status.files_used,
                lines_used=budget_status.lines_used,
                project_root=manager.project_root,
                verbosity=verbosity,
                manager=manager
            )

            if selected_area:
                # User selected a sub-area - it's already created and saved
                # Import here to avoid circular dependency
                from .manager import FocusArea

                if isinstance(selected_area, FocusArea):
                    print(f"\nDigging into {selected_area.id}...")
                    print("━" * 60)

                    # Recursively call cmd_dig with the new sub-area
                    cmd_dig(selected_area.id)

                    # After successful dig, show helpful next steps
                    print("\n" + "="*60)
                    print("✅ Sub-area ready for AI use!")
                    print("="*60)
                    print(f"\n📋 Area: {selected_area.id}")
                    print(f"📄 Context file: .cdg/context/{selected_area.id}.txt")
                    print(f"\n💡 Next steps:")
                    print(f"   1. View all areas: cdg list")
                    print(f"   2. Export for AI: cdg export txt")
                    print(f"   3. See this area: cdg dig {selected_area.id}")
                    print(f"   4. Add notes: cdg note \"your note here\"")
                    print(f"\n🤖 For Claude Code, Cursor, or ChatGPT:")
                    print(f"   Copy .cdg/context/{selected_area.id}.txt content")
                    print("="*60 + "\n")
                return

            # Exit without loading the area
            print("\n💡 Tip: Use 'contextdigger list' to see all areas")
            sys.exit(1)

    except Exception as e:
        # If budget calculation fails, don't block the dig command
        pass

    # Start session (only if budget check passed)
    manager.start_session(area.id)
    manager.add_to_history(area.id)

    # Auto-create continuation contract
    try:
        from .continuation import ContractManager
        contract_mgr = ContractManager(manager.project_root)

        # Check if there's already an active contract
        active = contract_mgr.get_active_contract()

        # Create new contract if none exists or if switching areas
        if not active or active.area_id != area.id:
            # Pause existing contract if switching areas
            if active and active.area_id != area.id:
                contract_mgr.pause_contract()

            # Create new contract for this area
            contract = contract_mgr.create_contract(
                area_id=area.id,
                area_name=area.name,
                intent=f"Working on {area.name}",
                problem=f"Exploring and understanding the {area.name} codebase",
                goal=f"Complete work in {area.name} area",
                tags=[area.metadata.get('language', 'unknown')],
            )
            contract_mgr.save_active_contract(contract)
    except Exception:
        # If contract creation fails, don't block the dig command
        pass

    print(f"\n⛏️  Digging into: {area.name}")
    print(f"   {area.description}")
    print(f"\n   Language: {area.metadata.get('language', 'unknown')}")
    print(f"   Files: ~{area.metadata.get('fileCount', '?')}")

    if area.metadata.get('primaryFiles'):
        print(f"\n   Key Files:")
        for pf in area.metadata['primaryFiles'][:5]:
            print(f"     - {pf}")

    if area.dependencies:
        print(f"\n   Depends on: {', '.join(area.dependencies)}")

    print(f"\n   Focus count: {area.focusCount} times")

    # Display budget (already calculated above)
    try:
        print(f"\n   {budget_tracker.format_budget_display(budget_status)}")

        # Generate and display budget alerts (Phase 1.3)
        from .budget import AlertLevel
        alerts = budget_tracker.generate_alerts(budget_status)

        if alerts:
            # Group alerts by level for better display
            for alert in sorted(alerts, key=lambda a: ["info", "warning", "critical", "exceeded"].index(a.level.value)):
                print(f"   {alert.format_message()}")

        # Show budget health status
        health = budget_tracker.get_budget_health(budget_status)
        if health == "exceeded":
            print(f"   💥 Budget exceeded - consider narrowing focus area")
        elif health == "critical":
            print(f"   🔴 Critical: Budget usage very high")
        elif health == "warning":
            print(f"   ⚠️  Warning: Approaching budget limit")

    except Exception as e:
        # If budget display fails, don't block the dig command
        pass

    # Export context file for AI tools
    try:
        # Get bookmarks for this area
        bookmarks = manager.list_bookmarks()
        area_bookmarks = [b for b in bookmarks if b.focusArea == area.id]

        # Track provenance for files being loaded
        from .provenance import ProvenanceTracker
        provenance_tracker = ProvenanceTracker(manager.project_root)
        session = manager.get_current_session()
        session_id = session.id if session else "unknown"

        # Track provenance for each file
        for file_path in files:
            # Get relative path
            try:
                rel_path = file_path.relative_to(manager.project_root)
            except ValueError:
                rel_path = file_path

            # Determine primary reason for inclusion
            is_bookmark = any(str(rel_path) in b.path for b in area_bookmarks) if area_bookmarks else False
            is_primary = str(rel_path) in area.metadata.get('primaryFiles', [])

            if is_bookmark:
                provenance_tracker.track_file_load(
                    file_path=str(rel_path),
                    reason_type="bookmark",
                    description=f"User bookmarked this file in {area.name}",
                    loaded_by="dig",
                    session_id=session_id,
                    area_id=area.id,
                    source="bookmarks",
                    confidence=1.0,
                )

            if is_primary:
                provenance_tracker.track_file_load(
                    file_path=str(rel_path),
                    reason_type="entry_point",
                    description=f"Primary file for {area.name} area",
                    loaded_by="dig",
                    session_id=session_id,
                    area_id=area.id,
                    confidence=1.0,
                )
            else:
                # General pattern match from area definition
                provenance_tracker.track_file_load(
                    file_path=str(rel_path),
                    reason_type="pattern_match",
                    description=f"Matched pattern in {area.name} area definition",
                    loaded_by="dig",
                    session_id=session_id,
                    area_id=area.id,
                    confidence=0.9,
                )

        # Save provenance to disk
        provenance_tracker.save_session_provenance(session_id)

        # Update continuation contract with context
        try:
            from .continuation import ContractManager
            contract_mgr = ContractManager(manager.project_root)
            active_contract = contract_mgr.get_active_contract()

            if active_contract and active_contract.area_id == area.id:
                # Capture file paths
                file_paths = [str(f.relative_to(manager.project_root)) if manager.project_root in f.parents else str(f) for f in files]
                bookmark_ids = [b.id for b in area_bookmarks] if area_bookmarks else []

                # Update contract context
                context = contract_mgr.capture_current_context(
                    open_files=file_paths[:10],  # Limit to top 10 files
                    bookmarks=bookmark_ids,
                    notes=f"Currently exploring {area.name}",
                )
                contract_mgr.update_contract(
                    active_contract.id,
                    context=context,
                )
        except Exception:
            # If contract update fails, don't block the dig command
            pass

        # Create exporter and export
        exporter = ContextExporter(
            project_root=manager.project_root,
            cdg_root=manager.cdg_dir
        )

        context_file = exporter.export_for_ai(
            area_name=area.id,
            area_description=area.description,
            files=files,
            budget_status=budget_status,
            bookmarks=area_bookmarks if area_bookmarks else None,
            provenance_tracker=provenance_tracker,
            session_id=session_id,
        )

        print(f"\n   📄 Context file: {context_file.relative_to(manager.project_root)}")
    except Exception as e:
        # If context export fails, don't block the dig command
        pass


def cmd_redig(*args):
    """Interactive area selector."""
    manager = get_manager()
    areas = manager.list_areas()

    if not areas:
        print("No areas discovered. Run: contextdigger init")
        return

    current = manager.get_current_focus()

    print("Available areas:\n")
    for i, area in enumerate(areas, 1):
        marker = "⛏️ " if area.id == current else "  "
        print(f"{marker}{i}. {area.id}")
        print(f"   {area.name}")
        print()

    print("Run: contextdigger dig <area-id>")


def cmd_status(*args):
    """Show current dig status."""
    manager = get_manager()
    current_focus = manager.get_current_focus()

    if not current_focus:
        print("Not currently digging")
        print("Use /dig or /redig to start digging into an area")
        return

    area = manager.get_area(current_focus)
    session = manager.get_current_session()

    print(f"⛏️  Current Focus: {area.name}")
    print(f"   Area ID: {area.id}")

    if session:
        from datetime import datetime, timezone
        start = datetime.fromisoformat(session.startedAt.replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        duration = now - start
        hours = int(duration.total_seconds() // 3600)
        minutes = int((duration.total_seconds() % 3600) // 60)
        print(f"   Session: {hours}h {minutes}m")

    files_modified = len(session.activity.get('filesModified', [])) if session else 0
    print(f"   Files modified: {files_modified}")


def cmd_back(*args):
    """Navigate back in history."""
    manager = get_manager()
    success = manager.navigate_backward()

    if success:
        current = manager.get_current_focus()
        if current:
            area = manager.get_area(current)
            print(f"⛏️  Back to: {area.name}")
    else:
        print("Already at oldest history item")


def cmd_forward(*args):
    """Navigate forward in history."""
    manager = get_manager()
    success = manager.navigate_forward()

    if success:
        current = manager.get_current_focus()
        if current:
            area = manager.get_area(current)
            print(f"⛏️  Forward to: {area.name}")
    else:
        print("Already at newest history item")


def cmd_history(*args):
    """Show navigation history."""
    manager = get_manager()
    history = manager.get_history()

    if not history:
        print("No navigation history")
        print("Use: contextdigger dig <area>")
        return

    print(f"📜 Navigation History ({len(history)} entries):\n")

    for entry in history[-10:]:  # Show last 10 entries
        marker = "→" if entry == history[-1] else " "
        print(f"{marker} {entry.areaName}")
        print(f"   Entered: {entry.enteredAt}")
        if entry.exitedAt:
            print(f"   Exited: {entry.exitedAt}")
        if entry.duration:
            minutes = entry.duration // 60
            print(f"   Duration: {minutes}m")
        if entry.actions:
            print(f"   Actions: {', '.join(entry.actions)}")
        print()


def cmd_list(*args):
    """List all discovered code areas."""
    manager = get_manager()
    areas = manager.list_areas()

    # Check for JSON output
    json_output = '--json' in args

    if not areas:
        if json_output:
            print(json.dumps({"areas": [], "total": 0}))
        else:
            print("No code areas discovered")
            print("Run: contextdigger init")
        return

    current_focus = manager.get_current_focus()

    if json_output:
        # Build JSON response
        areas_data = []
        for area in areas:
            lang = area.metadata.get('language', 'unknown')

            # Calculate file count dynamically
            try:
                files = manager.get_files_in_area(area)
                file_count = len(files)

                # Calculate budget status
                try:
                    config = manager.load_config()
                    budget_tracker = create_budget_tracker_from_config(config)
                    budget_status = budget_tracker.calculate_budget(files)
                    budget_info = {
                        "files_used": budget_status.files_used,
                        "files_max": budget_tracker.max_files,
                        "lines_used": budget_status.lines_used,
                        "lines_max": budget_tracker.max_lines,
                        "health": budget_status.health
                    }
                except Exception:
                    budget_info = None
            except Exception:
                file_count = 0
                budget_info = None

            areas_data.append({
                "id": area.id,
                "name": area.name,
                "description": area.description,
                "language": lang,
                "file_count": file_count,
                "is_current": area.id == current_focus,
                "budget": budget_info
            })

        print(json.dumps({"areas": areas_data, "total": len(areas)}, indent=2))
    else:
        # Original formatted output
        print(f"Discovered Code Areas ({len(areas)} total):\n")

        for area in areas:
            marker = "⛏️ " if area.id == current_focus else "  "
            lang = area.metadata.get('language', 'unknown')

            # Calculate file count dynamically
            try:
                files = manager.get_files_in_area(area)
                file_count = len(files)
            except Exception:
                file_count = '?'

            print(f"{marker}{area.id}")
            print(f"   {area.name} ({lang}, ~{file_count} files)")
            print(f"   {area.description}")
            print()


def cmd_split(*args):
    """Split an area into sub-areas.

    Usage:
        cdg split <area>        # Compact view
        cdg split <area> -v     # Horizontal verbose
        cdg split <area> -vv    # Vertical tree view
    """
    manager = get_manager()

    if not args:
        print("Usage: contextdigger split <area> [-v|-vv]")
        print("\nExamples:")
        print("  contextdigger split apex-tests         # Compact view")
        print("  contextdigger split apex-tests -v      # Horizontal verbose")
        print("  contextdigger split apex-tests -vv     # Vertical tree view")
        return

    # Parse verbosity
    verbosity = 0
    area_args = []
    for arg in args:
        if arg == '-vv':
            verbosity = 2
        elif arg == '-v':
            verbosity = 1
        else:
            area_args.append(arg)

    if not area_args:
        print("❌ Area name required")
        return

    area_id = area_args[0]

    # Load area
    area = manager.get_area(area_id)
    if not area:
        print(f"❌ Area not found: {area_id}")
        print("\nAvailable areas:")
        for a in manager.list_areas()[:10]:
            print(f"  - {a.id}")
        sys.exit(1)

    # Get files
    files = manager.get_files_in_area(area)

    if len(files) < 10:
        print(f"Area '{area.name}' is too small to split (only {len(files)} files)")
        print("Consider using the area as-is or creating manual sub-areas")
        return

    # Load config and create budget tracker
    config = manager.load_config()
    budget_tracker = create_budget_tracker_from_config(config)

    # Create analyzer and run analysis
    from contextdigger.subarea_analyzer import SubAreaAnalyzer, VerbosityRenderer

    analyzer = SubAreaAnalyzer(manager.project_root, budget_tracker)
    analysis = analyzer.analyze_area(files, area.name, max_depth=2)

    # Render based on verbosity
    renderer = VerbosityRenderer(budget_tracker)
    if verbosity == 0:
        print(renderer.render_compact(analysis))
    elif verbosity == 1:
        print(renderer.render_horizontal_verbose(analysis))
    else:
        print(renderer.render_vertical_verbose(analysis))

    # Interactive multi-select
    if not analysis.suggestions:
        print("\n❌ No sub-area suggestions found")
        print("Try creating sub-areas manually with: contextdigger create-subarea")
        return

    print("\n? Select sub-areas to create (or 'q' to quit)")
    print("  Enter numbers separated by commas (e.g., 1,3,4)")
    print("  Or 'all' to create all suggestions\n")

    for i, suggestion in enumerate(analysis.suggestions, 1):
        status = "✓" if suggestion.file_count <= budget_tracker.max_files else "⚠️"
        print(f"{i}. {status} {suggestion.name} ({suggestion.file_count} files)")

    try:
        choice = input("\nYour choice: ").strip().lower()

        if choice == 'q' or choice == '':
            print("Cancelled")
            return

        # Parse selection
        selected_indices = []
        if choice == 'all':
            selected_indices = list(range(len(analysis.suggestions)))
        else:
            try:
                parts = choice.split(',')
                for part in parts:
                    idx = int(part.strip()) - 1
                    if 0 <= idx < len(analysis.suggestions):
                        selected_indices.append(idx)
                    else:
                        print(f"Warning: Ignoring invalid selection: {part}")
            except ValueError:
                print("❌ Invalid input. Please enter numbers separated by commas")
                return

        if not selected_indices:
            print("No valid selections")
            return

        # Create selected sub-areas
        created_areas = []
        for idx in selected_indices:
            suggestion = analysis.suggestions[idx]

            # Create FocusArea
            from contextdigger.manager import FocusArea

            subarea_id = suggestion.name.lower().replace(" ", "-")
            focus_area = FocusArea(
                id=subarea_id,
                name=suggestion.name,
                description=suggestion.description,
                type="manual",
                patterns=suggestion.patterns if suggestion.patterns else {
                    "include": ["**/*"],
                    "exclude": []
                },
                metadata={
                    **suggestion.metadata,
                    "parent_area": area.id,
                    "strategy": suggestion.strategy,
                    "confidence": suggestion.confidence
                }
            )

            # Save area
            manager.save_area(focus_area)
            created_areas.append(subarea_id)
            print(f"  ✓ Created: {subarea_id}")

        print(f"\n✅ Successfully created {len(created_areas)} sub-areas")
        print("\nUse 'cdg dig <area-id>' to explore them:")
        for area_id in created_areas:
            print(f"  cdg dig {area_id}")

    except (KeyboardInterrupt, EOFError):
        print("\n\nCancelled")
        return


def cmd_create_subarea(*args):
    """Quickly create a sub-area with a pattern.

    Usage:
        cdg create-subarea <parent> <name> <pattern>

    Example:
        cdg create-subarea apex-tests account "**/*Account*Test.cls"
    """
    if len(args) < 3:
        print("Usage: contextdigger create-subarea <parent> <name> <pattern>")
        print("\nCreate a focused sub-area using a glob pattern")
        print("\nExamples:")
        print("  cdg create-subarea apex-tests account '**/*Account*Test.cls'")
        print("  cdg create-subarea backend auth 'src/auth/**/*.py'")
        print("  cdg create-subarea frontend components 'src/components/**/*.tsx'")
        return

    parent_id = args[0]
    name = args[1]
    pattern = args[2]

    manager = get_manager()

    # Load parent area
    parent = manager.get_area(parent_id)
    if not parent:
        print(f"❌ Parent area not found: {parent_id}")
        print("\nAvailable areas:")
        for a in manager.list_areas()[:10]:
            print(f"  - {a.id}")
        sys.exit(1)

    # Match pattern against parent files
    parent_files = manager.get_files_in_area(parent)

    # Use fnmatch for pattern matching
    import fnmatch
    matched_files = []
    for file_path in parent_files:
        # Try matching against the full path and relative path
        if fnmatch.fnmatch(str(file_path), pattern):
            matched_files.append(file_path)
        else:
            try:
                rel_path = file_path.relative_to(manager.project_root)
                if fnmatch.fnmatch(str(rel_path), pattern):
                    matched_files.append(file_path)
            except ValueError:
                pass

    if not matched_files:
        print(f"❌ Pattern '{pattern}' matches 0 files in '{parent.name}'")
        print(f"\nParent area has {len(parent_files)} files")
        print("\nTry patterns like:")
        print("  '**/*Account*'  - All files with 'Account' in name")
        print("  'src/auth/**/*' - All files in src/auth directory")
        sys.exit(1)

    # Calculate budget
    config = manager.load_config()
    budget_tracker = create_budget_tracker_from_config(config)
    budget_status = budget_tracker.calculate_budget(matched_files)

    # Show preview
    print(f"\n📊 Sub-Area Preview:")
    print(f"   Parent: {parent.name}")
    print(f"   Name: {name.title()}")
    print(f"   Pattern: {pattern}")
    print(f"   Matched Files: {budget_status.files_used}")
    print(f"   Total Lines: {budget_status.lines_used:,}")

    # Check budget
    if budget_status.exceeds:
        print(f"\n⚠️  Warning: This sub-area exceeds budget limits")
        print(f"   Files: {budget_status.files_used} (limit: {budget_tracker.max_files})")
        print(f"   Lines: {budget_status.lines_used:,} (limit: {budget_tracker.max_lines:,})")
        print("\nConsider:")
        print("  - Using a more specific pattern")
        print("  - Creating multiple smaller sub-areas")
        print("  - Using 'cdg split' for multi-strategy analysis")

        try:
            confirm = input("\nCreate anyway? (y/N): ").strip().lower()
            if confirm != 'y':
                print("Cancelled")
                return
        except (KeyboardInterrupt, EOFError):
            print("\nCancelled")
            return

    # Create sub-area
    from contextdigger.manager import FocusArea

    subarea_id = f"{parent_id}-{name.lower().replace(' ', '-')}"

    # Detect language from parent
    language = parent.metadata.get('language', 'unknown')

    focus_area = FocusArea(
        id=subarea_id,
        name=f"{parent.name} - {name.title()}",
        description=f"{name.title()}-related files from {parent.name}",
        type="manual",
        patterns={
            "include": [pattern],
            "exclude": parent.patterns.get("exclude", [])
        },
        metadata={
            "language": language,
            "parent_area": parent_id,
            "pattern": pattern
        }
    )

    # Save
    manager.save_area(focus_area)

    print(f"\n✅ Created sub-area: {subarea_id}")
    print(f"   Budget: {budget_status.files_used}/{budget_tracker.max_files} files, {budget_status.lines_used:,}/{budget_tracker.max_lines:,} lines")
    print(f"\nNext steps:")
    print(f"  cdg dig {subarea_id}")


# =============================================================================
# Bookmarks
# =============================================================================

def cmd_mark_spot(*args):
    """Save current location as bookmark."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger mark-spot <name> [path] [line]")
        return

    name = args[0]
    path = args[1] if len(args) > 1 else None
    line = int(args[2]) if len(args) > 2 else None

    if not path:
        print("Error: path required")
        print("Usage: contextdigger mark-spot <name> <path> [line]")
        sys.exit(1)

    # Create bookmark
    file_path = Path(path)
    if not file_path.is_absolute():
        file_path = Path.cwd() / file_path

    try:
        rel_path = file_path.relative_to(Path.cwd())
    except ValueError:
        rel_path = file_path

    current_focus = manager.get_current_focus()

    bookmark = Bookmark(
        id=name,
        name=name,
        path=str(rel_path),
        line=line,
        column=1,
        context="",
        focusArea=current_focus,
        tags=[],
        notes=""
    )

    manager.add_bookmark(bookmark)
    print(f"✓ Bookmark created: {bookmark.id}")
    print(f"   File: {bookmark.path}")
    if bookmark.line:
        print(f"   Line: {bookmark.line}")


def cmd_goto_spot(*args):
    """Jump to bookmark."""
    manager = get_manager()

    if not args:
        cmd_list_spots()
        return

    bookmark_id = args[0]
    bookmark = manager.get_bookmark(bookmark_id)

    if not bookmark:
        matches = manager.find_bookmarks(bookmark_id)
        if not matches:
            print(f"❌ No bookmark found: {bookmark_id}")
            sys.exit(1)
        bookmark = matches[0]

    manager.update_bookmark_access(bookmark.id)

    print(f"📍 {bookmark.name}")
    print(f"   File: {bookmark.path}")
    if bookmark.line:
        print(f"   Line: {bookmark.line}")

    # Show file context if it exists
    file_path = Path.cwd() / bookmark.path
    if file_path.exists():
        with open(file_path, 'r') as f:
            lines = f.readlines()

        line_num = bookmark.line or 1
        start = max(0, line_num - 10)
        end = min(len(lines), line_num + 10)

        print(f"\n📄 {bookmark.path}\n")
        for i in range(start, end):
            marker = ">>>" if i + 1 == line_num else "   "
            print(f"{marker} {i+1:4d} │ {lines[i].rstrip()}")


def cmd_list_spots(*args):
    """List all bookmarks."""
    manager = get_manager()
    bookmarks = manager.list_bookmarks()

    if not bookmarks:
        print("No bookmarks found")
        print("Use: contextdigger mark-spot <name> <path>")
        return

    print(f"📑 Bookmarks ({len(bookmarks)} total):\n")
    for bm in bookmarks:
        print(f"  {bm.id}: {bm.path}")
        if bm.line:
            print(f"    Line {bm.line}")
        if bm.context:
            print(f"    {bm.context}")
        print()


def cmd_delete_spot(*args):
    """Delete a bookmark."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger delete-spot <name>")
        return

    bookmark_id = args[0]
    if manager.delete_bookmark(bookmark_id):
        print(f"✓ Deleted bookmark: {bookmark_id}")
    else:
        print(f"❌ Bookmark not found: {bookmark_id}")


# =============================================================================
# Context Snapshots
# =============================================================================

def cmd_save_context(*args):
    """Save current context snapshot."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger save-context <name> [description]")
        return

    name = args[0]
    description = " ".join(args[1:]) if len(args) > 1 else ""

    snapshot = manager.save_context(name, description)
    print(f"✓ Context saved: {snapshot.name}")
    print(f"   Areas: {len(snapshot.markedSpots)}")
    print(f"   Saved at: {snapshot.savedAt}")


def cmd_load_context(*args):
    """Load context snapshot."""
    manager = get_manager()

    if not args:
        cmd_list_contexts()
        return

    name = args[0]
    snapshot = manager.load_context(name)

    if not snapshot:
        print(f"❌ Context not found: {name}")
        sys.exit(1)

    print(f"✓ Context loaded: {snapshot.name}")
    print(f"   {snapshot.description}")
    if snapshot.currentAreaName:
        print(f"   Current area: {snapshot.currentAreaName}")


def cmd_list_contexts(*args):
    """List all saved contexts."""
    manager = get_manager()
    contexts = manager.list_contexts()

    if not contexts:
        print("No saved contexts")
        print("Use: contextdigger save-context <name>")
        return

    print(f"Saved Contexts ({len(contexts)} total):\n")
    for ctx in contexts:
        print(f"  {ctx.name}")
        print(f"    {ctx.description}")
        print(f"    Saved: {ctx.savedAt}")
        print()


def cmd_delete_context(*args):
    """Delete context snapshot."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger delete-context <name>")
        return

    name = args[0]
    if manager.delete_context(name):
        print(f"✓ Deleted context: {name}")
    else:
        print(f"❌ Context not found: {name}")


# =============================================================================
# Notes & Documentation
# =============================================================================

def cmd_note(*args):
    """Add note to current area."""
    manager = get_manager()
    current = manager.get_current_focus()

    if not current:
        print("❌ Not in any area. Use: contextdigger dig <area>")
        sys.exit(1)

    if not args:
        print("Usage: contextdigger note <text>")
        return

    note_text = " ".join(args)
    note = manager.add_note(current, note_text)
    print(f"✓ Note added to {note.areaId}")


def cmd_notes(*args):
    """View notes for area."""
    manager = get_manager()

    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("❌ Not in any area. Use: contextdigger dig <area>")
        sys.exit(1)

    notes = manager.get_notes(area_id)

    if not notes:
        print(f"No notes for area: {area_id}")
        return

    area = manager.get_area(area_id)
    print(f"📝 Notes for {area.name}:\n")
    for note in notes:
        print(f"  • {note.content}")
        print(f"    {note.createdAt}")
        print()


def cmd_wiki(*args):
    """Generate wiki documentation."""
    manager = get_manager()

    print("📚 Wiki Documentation")
    print("="*60)

    areas = manager.list_areas()
    for area in areas:
        print(f"\n## {area.name}\n")
        print(f"{area.description}\n")

        notes = manager.get_notes(area.id)
        if notes:
            print("**Notes:**")
            for note in notes[:3]:
                print(f"- {note.content}")
            print()


# =============================================================================
# Analysis & Intelligence
# =============================================================================

def cmd_suggest(*args):
    """Get area suggestions."""
    manager = get_manager()
    current = manager.get_current_focus()

    suggestions = manager.get_area_suggestions(current)

    if not suggestions:
        print("No suggestions at this time")
        return

    print("💡 Suggestions:\n")
    for sug in suggestions:
        print(f"  • {sug.reason}")
        print(f"    /dig {sug.targetAreaId}")
        print()


def cmd_deps(*args):
    """Show dependencies."""
    manager = get_manager()
    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("Usage: contextdigger deps <area>")
        return

    area = manager.get_area(area_id)
    deps = manager.get_dependencies(area_id)

    print(f"📦 Dependencies for {area.name}:\n")
    for dep in deps:
        print(f"  • {dep.targetArea}")
        print(f"    {dep.relationshipType}: {dep.strength}")
        print()


def cmd_impact(*args):
    """Show impact analysis."""
    manager = get_manager()

    if not args:
        print("Usage: contextdigger impact <area>")
        return

    area_id = args[0]
    area = manager.get_area(area_id)
    dependents = manager.get_dependents(area_id)

    print(f"💥 Impact Analysis: {area.name}\n")
    print(f"Areas affected by changes: {len(dependents)}\n")

    for dep in dependents[:10]:
        print(f"  • {dep.targetArea}")
        print(f"    {dep.relationshipType}")
        print()


def cmd_map(*args):
    """Show codebase map."""
    manager = get_manager()
    areas = manager.list_areas()

    print("🗺️  Codebase Map\n")
    for area in areas:
        deps = len(area.dependencies)
        print(f"  {area.id}")
        print(f"    {area.name}")
        if deps > 0:
            print(f"    → Depends on {deps} area(s)")
        print()


def cmd_hotspots(*args):
    """Find code hotspots."""
    manager = get_manager()
    days = int(args[0]) if args else 30

    hotspots = manager.get_hotspots(days=days)

    print(f"🔥 Code Hotspots (last {days} days):\n")
    for hs in hotspots[:10]:
        print(f"  {hs.path}")
        print(f"    Commits: {hs.commitCount}, Complexity: {hs.complexity:.1f}")
        print(f"    Authors: {len(hs.authors)}")
        print()


def cmd_gaps(*args):
    """Find coverage gaps."""
    manager = get_manager()

    gaps = manager.find_coverage_gaps()

    print(f"🔍 Coverage Gaps:\n")
    for gap in gaps:
        print(f"  {gap.areaId}")
        print(f"    Coverage: {gap.lineCoverage:.1f}%")
        print()


def cmd_perf(*args):
    """Performance analysis."""
    manager = get_manager()
    area_id = args[0] if args else manager.get_current_focus()

    if not area_id:
        print("Usage: contextdigger perf [area]")
        return

    complexity = manager.get_area_complexity(area_id)
    area = manager.get_area(area_id)

    print(f"⚡ Performance Analysis: {area.name}\n")
    print(f"  Complexity: {complexity:.1f}")


def cmd_benchmark(*args):
    """Run benchmarks."""
    manager = get_manager()
    stats = manager.get_statistics()

    print("📊 Benchmarks:\n")
    print(f"  Total areas: {stats.get('total_areas', 0)}")
    print(f"  Total notes: {stats.get('total_notes', 0)}")
    print(f"  Total bookmarks: {stats.get('total_bookmarks', 0)}")
    print(f"  Total visits: {stats.get('total_visits', 0)}")


# =============================================================================
# Search & Query
# =============================================================================

def cmd_search(*args):
    """Search all data."""
    if not args:
        print("Usage: contextdigger search <query>")
        return

    manager = get_manager()
    query = " ".join(args)

    # Search areas
    areas = manager.find_areas(query)
    print(f"Areas matching '{query}':\n")
    for area in areas[:5]:
        print(f"  • {area.id}: {area.name}")

    # Search bookmarks
    bookmarks = manager.find_bookmarks(query)
    if bookmarks:
        print(f"\nBookmarks matching '{query}':\n")
        for bm in bookmarks[:5]:
            print(f"  • {bm.id}: {bm.path}")


def cmd_query(*args):
    """Run custom query."""
    print("Custom queries not yet implemented")


# =============================================================================
# Automation
# =============================================================================

def cmd_auto(*args):
    """Show automation suggestions."""
    print("💡 Automation Suggestions:\n")
    print("  • Set up area-based test automation")
    print("  • Configure auto-bookmarking on file edit")
    print("  • Enable team activity notifications")


def cmd_rules(*args):
    """List automation rules."""
    manager = get_manager()
    rules = manager.get_automation_rules()

    if not rules:
        print("No automation rules configured")
        return

    print(f"⚙️  Automation Rules ({len(rules)} total):\n")
    for rule in rules:
        print(f"  • {rule.name}")
        print(f"    Trigger: {rule.trigger}")
        print()


# =============================================================================
# Reports & Export
# =============================================================================

def cmd_analytics(*args):
    """Work analytics."""
    manager = get_manager()
    days = int(args[0]) if args else 30

    analytics = manager.get_work_analytics(days=days)

    print(f"📈 Work Analytics (last {days} days):\n")
    print(f"  Total sessions: {analytics.totalSessions}")
    print(f"  Total time: {analytics.totalTime // 3600}h")
    print(f"  Areas worked: {len(analytics.topAreas)}")
    print()

    print("  Top areas:")
    for area_stat in analytics.topAreas[:5]:
        print(f"    • {area_stat['areaName']}: {area_stat['sessionCount']} sessions")


def cmd_report(*args):
    """Generate report."""
    manager = get_manager()
    output_file = args[0] if args else None

    stats = manager.get_statistics()

    report = f"""# ContextDigger Report

## Overview
- Total Areas: {stats.get('total_areas', 0)}
- Total Notes: {stats.get('total_notes', 0)}
- Total Bookmarks: {stats.get('total_bookmarks', 0)}
- Total Snapshots: {stats.get('total_snapshots', 0)}
- Total Visits: {stats.get('total_visits', 0)}

## Areas
"""

    areas = manager.list_areas()
    for area in areas:
        report += f"\n### {area.name}\n"
        report += f"{area.description}\n"

    if output_file:
        Path(output_file).write_text(report)
        print(f"✓ Report saved to: {output_file}")
    else:
        print(report)


def cmd_export(*args):
    """Export data."""
    if not args:
        print("Usage: contextdigger export <format>")
        print("Formats: json, markdown")
        return

    manager = get_manager()
    format_type = args[0]

    if format_type == "json":
        data = {
            "areas": [asdict(a) for a in manager.list_areas()],
            "bookmarks": [asdict(b) for b in manager.list_bookmarks()],
            "contexts": [asdict(c) for c in manager.list_contexts()]
        }
        print(json.dumps(data, indent=2))
    else:
        print(f"Unsupported format: {format_type}")


def cmd_backup(*args):
    """Create backup."""
    import shutil
    from datetime import datetime

    backup_name = datetime.now().strftime("cdg-backup-%Y%m%d-%H%M%S.tar.gz")

    # Create tar.gz of .cdg directory
    import tarfile
    with tarfile.open(backup_name, "w:gz") as tar:
        tar.add(".cdg", arcname="cdg")

    print(f"✓ Backup created: {backup_name}")


def cmd_provenance(*args):
    """Show file provenance - why files were loaded into context."""
    from .provenance import ProvenanceTracker

    manager = get_manager()
    tracker = ProvenanceTracker(Path.cwd())

    # Get session ID from args or use current session
    if args:
        session_id = args[0]
    else:
        # Use current session
        current_session = manager.get_current_session()
        if not current_session:
            print("❌ No active session")
            print("Start a session with: contextdigger dig <area>")
            return
        session_id = current_session.id

    # Load provenance for this session
    tracker.load_session_provenance(session_id)
    provenance_records = tracker.get_session_provenance(session_id)

    if not provenance_records:
        print(f"📋 No provenance data for session: {session_id}")
        print()
        print("Provenance tracks why files are loaded into context.")
        print("It will be populated automatically when:")
        print("  - Exporting context with provenance tracking")
        print("  - Digging into areas (with provenance enabled)")
        return

    # Display provenance
    print(f"📋 File Provenance - Session {session_id}")
    print("="*70)
    print(f"Total files tracked: {len(provenance_records)}")
    print()

    # Group by reason type
    reason_counts = {}
    for prov in provenance_records:
        for reason in prov.reasons:
            reason_counts[reason.type] = reason_counts.get(reason.type, 0) + 1

    print("Reason Types:")
    for reason_type, count in sorted(reason_counts.items(), key=lambda x: -x[1]):
        print(f"  • {reason_type}: {count} files")
    print()

    # Show detailed provenance for each file
    print("File Details:")
    print("-"*70)
    for prov in sorted(provenance_records, key=lambda p: p.file_path):
        print(f"\n📄 {prov.file_path}")
        print(f"   Loaded by: {prov.loaded_by}")
        if prov.area_id:
            print(f"   Area: {prov.area_id}")
        print(f"   Reasons ({len(prov.reasons)}):")
        for reason in prov.reasons:
            print(f"     • {reason.type}: {reason.description}")
            if reason.source:
                print(f"       → Source: {reason.source}")
            if reason.confidence < 1.0:
                print(f"       → Confidence: {reason.confidence:.0%}")

    print()
    print("-"*70)
    print(f"✓ Provenance completeness: {len(provenance_records)} files documented")


# =============================================================================
# Continuation Contracts
# =============================================================================

def cmd_continue(*args):
    """Resume last work session."""
    from .continuation import ContractManager

    manager = get_manager()
    contract_mgr = ContractManager(manager.project_root)

    # Check for active contract first
    active = contract_mgr.get_active_contract()
    if active:
        print(f"📋 Resuming active contract: {active.intent}")
        print("="*70)
        print(f"   Area: {active.area_name}")
        print(f"   Status: {active.status}")
        print(f"   Progress: {active.progress:.0%}")
        print()
        print(f"   Problem: {active.problem}")
        print(f"   Goal: {active.goal}")
        print()

        if active.context.notes:
            print(f"   Notes: {active.context.notes}")
            print()

        if active.context.next_actions:
            print("   Next Actions:")
            for action in active.context.next_actions:
                print(f"     • {action}")
            print()

        if active.context.open_files:
            print(f"   Open Files ({len(active.context.open_files)}):")
            for file in active.context.open_files[:5]:
                print(f"     • {file}")
            if len(active.context.open_files) > 5:
                print(f"     ... and {len(active.context.open_files) - 5} more")
            print()

        # Auto-dig into the area
        print(f"⛏️  Digging into {active.area_id}...")
        cmd_dig(active.area_id)
        return

    # No active contract - check history
    history = contract_mgr.get_contract_history(limit=10)
    if not history:
        print("📋 No contracts found")
        print()
        print("Start a new work session:")
        print("  1. Dig into an area: contextdigger dig <area>")
        print("  2. A contract will be created automatically")
        return

    # Show recent contracts
    print("📋 Recent Contracts (select one to resume):")
    print("="*70)
    print()

    for i, contract in enumerate(history[:5], 1):
        status_icon = {
            "completed": "✓",
            "blocked": "⚠️ ",
            "investigating": "🔍",
            "implementing": "🔨",
            "testing": "🧪",
        }.get(contract.status, "•")

        print(f"{i}. {status_icon} {contract.intent}")
        print(f"   Area: {contract.area_name} | Status: {contract.status} | Progress: {contract.progress:.0%}")
        if contract.status == "completed":
            print(f"   Completed: {contract.completed_at[:16].replace('T', ' ')}")
        else:
            print(f"   Last updated: {contract.updated_at[:16].replace('T', ' ')}")
        print()

    print("Use 'contextdigger dig <area>' to start a new session")
    print("Or create a new contract with 'contextdigger start <area>'")


def cmd_pause(*args):
    """Pause current work and save state."""
    from .continuation import ContractManager

    manager = get_manager()
    contract_mgr = ContractManager(manager.project_root)

    active = contract_mgr.get_active_contract()
    if not active:
        print("📋 No active contract to pause")
        print()
        print("You're not currently working on anything.")
        print("Use 'contextdigger dig <area>' to start")
        return

    # Pause the contract
    contract_mgr.pause_contract()

    print(f"⏸️  Paused: {active.intent}")
    print("="*70)
    print(f"   Area: {active.area_name}")
    print(f"   Status: {active.status}")
    print(f"   Progress: {active.progress:.0%}")
    print()
    print("   Contract saved to history")
    print()
    print("Resume later with:")
    print("  contextdigger continue")
    print(f"  contextdigger dig {active.area_id}")


def cmd_contracts(*args):
    """List all contracts (completed and paused)."""
    from .continuation import ContractManager

    manager = get_manager()
    contract_mgr = ContractManager(manager.project_root)

    # Check for JSON output
    json_output = '--json' in args
    # Filter out --json flag
    filter_args = [arg for arg in args if arg != '--json']

    limit = int(filter_args[0]) if filter_args and filter_args[0].isdigit() else 20
    history = contract_mgr.get_contract_history(limit=limit)

    if not history:
        if json_output:
            print(json.dumps({"contracts": [], "total": 0}))
        else:
            print("📋 No contracts found")
            print()
            print("Contracts track your work sessions.")
            print("Start working with: contextdigger dig <area>")
        return

    # Group by status
    completed = [c for c in history if c.status == "completed"]
    in_progress = [c for c in history if c.status != "completed"]

    if json_output:
        # Build JSON response
        contracts_data = {
            "in_progress": [{
                "intent": c.intent,
                "area_name": c.area_name,
                "status": c.status,
                "progress": c.progress,
                "updated_at": c.updated_at,
                "tags": c.tags if c.tags else []
            } for c in in_progress],
            "completed": [{
                "intent": c.intent,
                "area_name": c.area_name,
                "completed_at": c.completed_at,
                "tags": c.tags if c.tags else []
            } for c in completed],
            "total": len(history)
        }
        print(json.dumps(contracts_data, indent=2))
        return

    if in_progress:
        print("## In Progress")
        print("-"*70)
        for contract in in_progress:
            status_icon = {
                "blocked": "⚠️ ",
                "investigating": "🔍",
                "implementing": "🔨",
                "testing": "🧪",
            }.get(contract.status, "•")

            print(f"\n{status_icon} {contract.intent}")
            print(f"   Area: {contract.area_name}")
            print(f"   Status: {contract.status} | Progress: {contract.progress:.0%}")
            print(f"   Updated: {contract.updated_at[:16].replace('T', ' ')}")
            if contract.tags:
                print(f"   Tags: {', '.join(contract.tags)}")
        print()
        print()

    if completed:
        print("## Completed")
        print("-"*70)
        for contract in completed[:10]:
            print(f"\n✓ {contract.intent}")
            print(f"   Area: {contract.area_name}")
            print(f"   Completed: {contract.completed_at[:16].replace('T', ' ')}")
            if contract.tags:
                print(f"   Tags: {', '.join(contract.tags)}")
        print()

    print("-"*70)
    print(f"Total contracts: {len(history)}")
    print()
    print("Resume work with: contextdigger continue")


def cmd_policy(*args):
    """
    Manage budget governance policies.

    Usage:
        contextdigger policy             Show current policy
        contextdigger policy check       Check compliance with policy
        contextdigger policy strict      Enable strict enforcement
        contextdigger policy warning     Enable warning mode (default)
        contextdigger policy advisory    Enable advisory mode
    """
    from .budget import (
        BudgetTracker,
        GovernancePolicy,
        EnforcementMode,
        ViolationAction,
        PolicyManager,
        AuditLog,
    )

    manager = get_manager()
    policy_manager = PolicyManager(manager.project_root)
    audit_log = AuditLog(manager.project_root)

    # Get current focus area for budget checking
    current_focus = manager.get_current_focus()

    # Parse command
    if not args:
        # Show current policy
        policy = policy_manager.get_active_policy()

        print("📋 Current Budget Governance Policy")
        print("="*70)
        print()
        print(f"  Policy: {policy.name}")
        print(f"  ID: {policy.policy_id}")
        print(f"  Status: {'Enabled' if policy.enabled else 'Disabled'}")
        print(f"  Enforcement: {policy.enforcement_mode.value.capitalize()}")
        print()
        print(f"  Budget Limits:")
        print(f"    Max Files: {policy.max_files}")
        print(f"    Max Lines: {policy.max_lines:,}")
        print()
        print(f"  Alert Thresholds:")
        for threshold in policy.alert_thresholds:
            level = "CRITICAL" if threshold >= 0.9 else "WARNING" if threshold >= 0.8 else "INFO"
            print(f"    {threshold:.0%} - {level}")
        print()
        print(f"  Violation Actions:")
        for action in policy.violation_actions:
            print(f"    • {action.value.capitalize()}")
        print()
        print(f"  Description:")
        print(f"    {policy.description}")
        print()

        # Show current budget status if in an area
        if current_focus:
            area = manager.get_area(current_focus)
            if area:
                print("="*70)
                print("Current Budget Status")
                print("-"*70)
                budget_tracker = BudgetTracker(
                    max_files=policy.max_files,
                    max_lines=policy.max_lines,
                    alert_thresholds=policy.alert_thresholds,
                )
                files = manager.get_files_in_area(area)
                budget_status = budget_tracker.calculate_budget(files)

                health = budget_tracker.get_budget_health(budget_status)
                health_icon = {
                    "healthy": "✅",
                    "warning": "⚠️ ",
                    "critical": "🔴",
                    "exceeded": "💥",
                }.get(health, "ℹ️ ")

                print(f"  Health: {health_icon} {health.capitalize()}")
                print(f"  Files: {budget_status.files_used}/{budget_status.files_max} ({budget_status.percentage_files:.0%})")
                print(f"  Lines: {budget_status.lines_used:,}/{budget_status.lines_max:,} ({budget_status.percentage_lines:.0%})")

                # Check compliance
                compliant, violations = budget_tracker.check_policy_compliance(
                    budget_status, policy
                )

                if compliant:
                    print(f"\n  ✅ In compliance with policy")
                else:
                    print(f"\n  ❌ Policy violations:")
                    for violation in violations:
                        print(f"     • {violation}")
                print()

    elif args[0] == "check":
        # Check compliance with policy
        if not current_focus:
            print("❌ No active focus area")
            print("   Use 'contextdigger dig <area>' to focus on an area")
            return

        area = manager.get_area(current_focus)
        if not area:
            print("❌ Area not found")
            return

        # Get active policy from PolicyManager
        policy = policy_manager.get_active_policy()

        budget_tracker = BudgetTracker(
            max_files=policy.max_files,
            max_lines=policy.max_lines,
            alert_thresholds=policy.alert_thresholds,
        )
        files = manager.get_files_in_area(area)
        budget_status = budget_tracker.calculate_budget(files)

        print("🔍 Policy Compliance Check")
        print("="*70)
        print(f"  Area: {area.name}")
        print()

        # Generate violation result
        result = budget_tracker.handle_violation(budget_status, policy)

        # Log audit event
        if result.has_violations:
            audit_log.log_violation(
                policy=policy,
                budget=budget_status,
                violations=[a.message for a in result.alerts],
                actions_taken=result.actions_taken,
                metadata={"area": area.name},
            )
        else:
            audit_log.log_compliance(
                policy=policy,
                budget=budget_status,
                metadata={"area": area.name},
            )

        if result.has_violations:
            print(f"  ❌ Policy Violations Detected")
            print()
            for alert in result.alerts:
                print(f"  {alert.format_message()}")
            print()

            if result.blocked:
                print(f"  🚫 Operation would be BLOCKED (strict mode)")
            else:
                print(f"  ⚠️  Operation allowed with warnings")

            print()
            print(f"  Actions taken:")
            for action in result.actions_taken:
                print(f"    • {action}")
        else:
            print(f"  ✅ No violations - budget is compliant")
            health = budget_tracker.get_budget_health(budget_status)
            print(f"  Budget health: {health.capitalize()}")

        print()

    elif args[0] in ["strict", "warning", "advisory"]:
        mode = args[0]
        print(f"📋 Governance Policy Enforcement Mode")
        print("="*70)
        print()
        print(f"  Mode set to: {mode.upper()}")
        print()

        if mode == "strict":
            print("  🔴 STRICT MODE")
            print("     Operations that violate budget will be BLOCKED")
            print("     Use this for critical production environments")
        elif mode == "warning":
            print("  ⚠️  WARNING MODE (default)")
            print("     Operations that violate budget will show warnings")
            print("     But will still be allowed to proceed")
        elif mode == "advisory":
            print("  ℹ️  ADVISORY MODE")
            print("     Budget violations will show suggestions only")
            print("     No warnings or blocks")

        print()
        print("  Note: Policy enforcement configuration coming in future releases")
        print()

    else:
        print("Usage: contextdigger policy [check|strict|warning|advisory]")
        print()
        print("Commands:")
        print("  policy          Show current policy")
        print("  policy check    Check compliance with policy")
        print("  policy strict   Enable strict enforcement")
        print("  policy warning  Enable warning mode")
        print("  policy advisory Enable advisory mode")


def cmd_audit(*args):
    """
    View budget governance audit logs.

    Usage:
        contextdigger audit              Show recent audit events
        contextdigger audit violations   Show recent violations
        contextdigger audit stats        Show audit statistics
    """
    from .budget import AuditLog, AuditEventType

    manager = get_manager()
    audit_log = AuditLog(manager.project_root)

    if not args or args[0] == "recent":
        # Show recent audit events
        limit = 20
        entries = audit_log.get_entries(limit=limit)

        if not entries:
            print("📋 Audit Log")
            print("="*70)
            print()
            print("  No audit events recorded yet")
            print()
            print("  Audit events are logged when you:")
            print("    • Run 'contextdigger policy check'")
            print("    • Dig into areas with budget tracking")
            print()
            return

        print(f"📋 Audit Log (showing {len(entries)} most recent)")
        print("="*70)
        print()

        for entry in reversed(entries):  # Show most recent first
            timestamp = entry.timestamp[:16].replace('T', ' ')
            event_icon = {
                AuditEventType.BUDGET_CHECK: "📊",
                AuditEventType.POLICY_VIOLATION: "❌",
                AuditEventType.POLICY_COMPLIANCE: "✅",
                AuditEventType.POLICY_CREATED: "🆕",
                AuditEventType.POLICY_UPDATED: "📝",
                AuditEventType.POLICY_ENABLED: "🟢",
                AuditEventType.POLICY_DISABLED: "🔴",
            }.get(entry.event_type, "ℹ️ ")

            print(f"{event_icon} {timestamp} - {entry.event_type.value}")
            print(f"   Policy: {entry.policy_id}")

            if entry.budget_status:
                files = entry.budget_status.get("files_used", 0)
                lines = entry.budget_status.get("lines_used", 0)
                print(f"   Budget: {files} files, {lines:,} lines")

            if entry.violations:
                print(f"   Violations:")
                for v in entry.violations[:3]:  # Show first 3
                    print(f"     • {v}")

            if entry.metadata.get("area"):
                print(f"   Area: {entry.metadata['area']}")

            print()

        print("-"*70)
        print(f"Run 'contextdigger audit violations' to see only violations")
        print(f"Run 'contextdigger audit stats' for statistics")
        print()

    elif args[0] == "violations":
        # Show recent violations
        limit = 20
        violations = audit_log.get_recent_violations(limit=limit)

        if not violations:
            print("📋 Budget Violations")
            print("="*70)
            print()
            print("  ✅ No budget violations recorded")
            print("     Your codebase is in excellent compliance!")
            print()
            return

        print(f"📋 Budget Violations (showing {len(violations)} most recent)")
        print("="*70)
        print()

        for entry in reversed(violations):
            timestamp = entry.timestamp[:16].replace('T', ' ')
            print(f"❌ {timestamp}")
            print(f"   Policy: {entry.policy_id}")

            if entry.budget_status:
                files = entry.budget_status.get("files_used", 0)
                files_max = entry.budget_status.get("files_max", 0)
                lines = entry.budget_status.get("lines_used", 0)
                lines_max = entry.budget_status.get("lines_max", 0)
                print(f"   Budget: {files}/{files_max} files, {lines:,}/{lines_max:,} lines")

            if entry.violations:
                print(f"   Violations:")
                for v in entry.violations:
                    print(f"     • {v}")

            if entry.actions_taken:
                print(f"   Actions:")
                for a in entry.actions_taken:
                    print(f"     • {a}")

            if entry.metadata.get("area"):
                print(f"   Area: {entry.metadata['area']}")

            print()

        print("-"*70)
        print(f"Total violations: {len(violations)}")
        print()

    elif args[0] == "stats":
        # Show statistics
        stats = audit_log.get_statistics()

        print("📊 Audit Statistics")
        print("="*70)
        print()
        print(f"  Total Events: {stats['total_events']}")
        print(f"  Violations: {stats['total_violations']}")
        print(f"  Compliance: {stats['total_compliance']}")

        if stats['total_violations'] + stats['total_compliance'] > 0:
            compliance_pct = stats['compliance_rate'] * 100
            print()
            print(f"  Compliance Rate: {compliance_pct:.1f}%")

            # Show status icon
            if compliance_pct >= 90:
                print(f"  Status: ✅ Excellent")
            elif compliance_pct >= 75:
                print(f"  Status: ⚠️  Good")
            elif compliance_pct >= 50:
                print(f"  Status: 🟡 Fair")
            else:
                print(f"  Status: 🔴 Needs Attention")

        print()
        print("-"*70)
        print()

    else:
        print("Usage: contextdigger audit [violations|stats]")
        print()
        print("Commands:")
        print("  audit              Show recent audit events")
        print("  audit violations   Show recent violations")
        print("  audit stats        Show audit statistics")


def cmd_insights(*args):
    """
    Generate and view intelligent insights about codebase health.

    Usage:
        contextdigger insights           Generate and show insights
        contextdigger insights critical  Show only critical insights
        contextdigger insights warnings  Show only warnings
        contextdigger insights area <name>  Show insights for specific area
    """
    from .insights import InsightEngine, InsightLevel

    manager = get_manager()
    engine = InsightEngine(manager.project_root)

    # Check for JSON output
    json_output = '--json' in args
    # Remove --json from args for filtering
    filter_args = [arg for arg in args if arg != '--json']

    # Generate insights
    insights = engine.generate_insights()

    if not insights:
        if json_output:
            print(json.dumps({"insights": [], "total": 0}))
        else:
            print("💡 Insights")
            print("="*70)
            print()
            print("  No insights available yet")
            print()
            print("  Insights are generated from:")
            print("    • Audit logs (policy checks and violations)")
            print("    • Usage patterns (frequent areas)")
            print("    • Budget data (hotspots and trends)")
            print()
            print("  Work with ContextDigger more to generate insights!")
            print()
        return

    # Filter insights based on args
    title = "All Insights"
    if filter_args:
        if filter_args[0] == "critical":
            insights = engine.get_insights_by_level(insights, InsightLevel.CRITICAL)
            title = "Critical Insights"
        elif filter_args[0] == "warnings":
            insights = engine.get_insights_by_level(insights, InsightLevel.WARNING)
            title = "Warning Insights"
        elif filter_args[0] == "area" and len(filter_args) > 1:
            area_name = filter_args[1]
            insights = engine.get_insights_by_area(insights, area_name)
            title = f"Insights for '{area_name}'"

    if json_output:
        # Build JSON response
        summary = engine.get_summary(insights)
        insights_data = []
        for insight in insights:
            insights_data.append({
                "title": insight.title,
                "description": insight.description,
                "level": insight.level.value,
                "impact": insight.impact_score,
                "pattern": {
                    "type": insight.pattern.pattern_type.value,
                    "occurrences": insight.pattern.occurrences,
                    "confidence": insight.pattern.confidence,
                    "areas": insight.pattern.affected_areas if insight.pattern.affected_areas else []
                },
                "recommendations": insight.recommendations if insight.recommendations else []
            })

        print(json.dumps({
            "insights": insights_data,
            "total": summary['total_insights'],
            "summary": summary
        }, indent=2))
        return

    # Show insights
    print(f"💡 {title}")
    print("="*70)
    print()

    if not insights:
        print(f"  No insights found for the selected filter")
        print()
        return

    # Get summary
    summary = engine.get_summary(insights)
    print(f"  Total Insights: {summary['total_insights']}")
    if summary.get('by_level'):
        by_level = summary['by_level']
        print(f"  By Level:")
        if by_level.get('critical'):
            print(f"    🔴 Critical: {by_level['critical']}")
        if by_level.get('warning'):
            print(f"    ⚠️  Warning: {by_level['warning']}")
        if by_level.get('info'):
            print(f"    ℹ️  Info: {by_level['info']}")
    print()
    print("-"*70)
    print()

    # Show top insights by impact
    top_insights = engine.get_top_insights(insights, limit=10)

    for insight in top_insights:
        # Icon by level
        level_icon = {
            InsightLevel.CRITICAL: "🔴",
            InsightLevel.WARNING: "⚠️ ",
            InsightLevel.INFO: "ℹ️ ",
        }.get(insight.level, "•")

        print(f"{level_icon} {insight.title}")
        print(f"   {insight.description}")
        print(f"   Impact: {insight.impact_score:.0%} | Confidence: {insight.pattern.confidence:.0%}")
        print()

        # Show pattern details
        print(f"   Pattern:")
        print(f"     Type: {insight.pattern.pattern_type.value}")
        print(f"     Occurrences: {insight.pattern.occurrences}")
        if insight.pattern.affected_areas:
            print(f"     Areas: {', '.join(insight.pattern.affected_areas[:3])}")
        print()

        # Show recommendations
        if insight.recommendations:
            print(f"   Recommendations:")
            for i, rec in enumerate(insight.recommendations[:3], 1):
                print(f"     {i}. {rec}")
        print()
        print("-"*70)
        print()

    # Show usage hints
    if len(insights) > len(top_insights):
        print(f"Showing top {len(top_insights)} of {len(insights)} insights")
        print()

    print("Filter insights:")
    print("  contextdigger insights critical  # Critical issues only")
    print("  contextdigger insights warnings  # Warnings only")
    print("  contextdigger insights area <name>  # Area-specific insights")
    print()


def cmd_trends(*args):
    """
    Analyze historical trends in patterns and usage.

    Usage:
        contextdigger trends           Show all trends
        contextdigger trends <area>    Show trends for specific area
        contextdigger trends --days 60 Show trends over 60 days
    """
    from .trends import PatternHistory, TrendAnalyzer
    from .insights import InsightEngine

    manager = get_manager()

    # Check for JSON output
    json_output = '--json' in args

    # Parse arguments
    area_id = None
    days = 30

    i = 0
    while i < len(args):
        if args[i] == "--json":
            i += 1
        elif args[i] == "--days" and i + 1 < len(args):
            days = int(args[i + 1])
            i += 2
        else:
            area_id = args[i]
            i += 1

    # Get current patterns and create snapshot
    engine = InsightEngine(manager.project_root)
    insights = engine.generate_insights()

    if insights:
        # Extract patterns from insights
        patterns = [insight.pattern for insight in insights]

        # Save snapshot
        from .trends import PatternSnapshot
        from datetime import datetime

        snapshot = PatternSnapshot(
            timestamp=datetime.now(),
            patterns=patterns,
            area_id=area_id,
        )

        history = PatternHistory(manager.project_root / ".cdg")
        history.save_snapshot(snapshot)

    # Analyze trends
    analyzer = TrendAnalyzer(history)
    trends = analyzer.analyze_trends(area_id=area_id, days=days)

    if not trends:
        if json_output:
            print(json.dumps({"trends": [], "total": 0, "period_days": days}))
        else:
            print("📈 Trend Analysis")
            print("="*70)
            print()
            print(f"  No trend data available for the last {days} days")
            print()
            print("  Trends are generated from historical pattern snapshots.")
            print("  Run the insights command regularly to build historical data.")
            print()
        return

    if json_output:
        # Build JSON response
        trends_data = [{
            "description": t.description,
            "direction": t.direction.value,
            "confidence": t.confidence,
            "data_points": t.data_points,
            "change_rate": t.change_rate,
            "affected_areas": t.affected_areas if t.affected_areas else [],
            "pattern_type": t.pattern_type.value if hasattr(t, 'pattern_type') else None
        } for t in trends]

        print(json.dumps({
            "trends": trends_data,
            "total": len(trends),
            "period_days": days,
            "area_id": area_id
        }, indent=2))
        return

    print("📈 Trend Analysis")
    print("="*70)
    print()
    print(f"  Period: Last {days} days")
    print(f"  Total Trends: {len(trends)}")
    print()
    print("-"*70)
    print()

    for trend in trends:
        # Icon by direction
        direction_icon = {
            "improving": "📉",
            "degrading": "📈",
            "stable": "➡️ ",
            "insufficient_data": "❓",
        }.get(trend.direction.value, "•")

        print(f"{direction_icon} {trend.description}")
        print(f"   Direction: {trend.direction.value.upper()}")
        print(f"   Confidence: {trend.confidence:.0%}")
        print(f"   Data Points: {trend.data_points}")
        print(f"   Change Rate: {trend.change_rate:+.2f} per snapshot")
        if trend.affected_areas:
            print(f"   Areas: {', '.join(trend.affected_areas[:3])}")
        print()
        print("-"*70)
        print()

    print("Tip: Use predictions to see forecasted issues based on these trends")
    print("     contextdigger predictions")
    print()


def cmd_predictions(*args):
    """
    Generate predictive insights based on historical trends.

    Usage:
        contextdigger predictions            Show all predictions
        contextdigger predictions <area>     Show predictions for area
        contextdigger predictions --days 60  Analyze over 60 days
    """
    from .trends import PatternHistory, TrendAnalyzer, PredictiveEngine

    manager = get_manager()

    # Check for JSON output
    json_output = '--json' in args

    # Parse arguments
    area_id = None
    days = 30

    i = 0
    while i < len(args):
        if args[i] == "--json":
            i += 1
        elif args[i] == "--days" and i + 1 < len(args):
            days = int(args[i + 1])
            i += 2
        else:
            area_id = args[i]
            i += 1

    # Generate predictions
    history = PatternHistory(manager.project_root / ".cdg")
    analyzer = TrendAnalyzer(history)
    engine = PredictiveEngine(analyzer)

    predictions = engine.generate_predictions(area_id=area_id, days=days)

    if not predictions:
        if json_output:
            print(json.dumps({"predictions": [], "total": 0}))
        else:
            print("🔮 Predictive Insights")
            print("="*70)
            print()
            print("  No predictions available")
            print()
            print("  Predictions require sufficient historical trend data.")
            print("  Run insights regularly and try again later.")
            print()
        return

    if json_output:
        # Sort by risk score (highest first)
        predictions.sort(key=lambda p: p.risk_score, reverse=True)

        # Build JSON response
        predictions_data = [{
            "description": p.description,
            "probability": p.probability,
            "timeframe": p.timeframe,
            "risk_score": p.risk_score,
            "affected_areas": p.affected_areas if p.affected_areas else [],
            "recommendations": p.recommendations if p.recommendations else []
        } for p in predictions]

        print(json.dumps({
            "predictions": predictions_data,
            "total": len(predictions)
        }, indent=2))
        return

    print("🔮 Predictive Insights")
    print("="*70)
    print()
    print(f"  Total Predictions: {len(predictions)}")
    print()
    print("-"*70)
    print()

    # Sort by risk score (highest first)
    predictions.sort(key=lambda p: p.risk_score, reverse=True)

    for prediction in predictions:
        # Icon by risk score
        if prediction.risk_score > 0.7:
            risk_icon = "🔴"
        elif prediction.risk_score > 0.4:
            risk_icon = "⚠️ "
        else:
            risk_icon = "ℹ️ "

        print(f"{risk_icon} {prediction.description}")
        print(f"   Probability: {prediction.probability:.0%}")
        print(f"   Timeframe: {prediction.timeframe}")
        print(f"   Risk Score: {prediction.risk_score:.0%}")
        if prediction.affected_areas:
            print(f"   Areas: {', '.join(prediction.affected_areas[:3])}")
        print()

        if prediction.recommendations:
            print("   Recommendations:")
            for i, rec in enumerate(prediction.recommendations[:3], 1):
                print(f"     {i}. {rec}")
        print()
        print("-"*70)
        print()

    print("Tip: Use remediate to get detailed fix suggestions")
    print("     contextdigger remediate")
    print()


def cmd_remediate(*args):
    """
    Get automated remediation suggestions for issues.

    Usage:
        contextdigger remediate            Show all suggestions
        contextdigger remediate --enhance  Use AI for enhanced suggestions (requires Ollama)
    """
    from .trends import RemediationSuggester, PatternHistory, TrendAnalyzer, PredictiveEngine
    from .insights import InsightEngine

    manager = get_manager()

    # Parse arguments
    use_ai = "--enhance" in args or "--ai" in args

    # Generate insights, trends, predictions
    engine = InsightEngine(manager.project_root)
    insights = engine.generate_insights()

    history = PatternHistory(manager.project_root / ".cdg")
    analyzer = TrendAnalyzer(history)
    trends = analyzer.analyze_trends(days=30)

    pred_engine = PredictiveEngine(analyzer)
    predictions = pred_engine.generate_predictions(days=30)

    # Generate suggestions
    suggester = RemediationSuggester()
    suggestions = suggester.suggest_remediations(insights, trends, predictions)

    # Enhance with AI if requested
    if use_ai:
        from .llm_integration import AIEnhancedSuggester, get_llm_status

        status = get_llm_status(manager.project_root / ".cdg")

        if status["status"] != "available":
            print(f"⚠️  {status['message']}")
            if "help" in status:
                print(f"   {status['help']}")
            print()
            print("Showing suggestions without AI enhancement...")
            print()
        else:
            ai_suggester = AIEnhancedSuggester(manager.project_root / ".cdg")

            # Get context
            context = {
                "total_areas": len(manager.areas.list_areas()),
                "insights_count": len(insights),
                "trends_count": len(trends),
            }

            # Enhance suggestions
            enhanced_suggestions = []
            for suggestion in suggestions:
                enhanced = ai_suggester.enhance_remediation(suggestion, context)
                enhanced_suggestions.append(enhanced)
            suggestions = enhanced_suggestions

            print(f"✨ AI-Enhanced Suggestions (using {status['model']})")
            print()

    if not suggestions:
        print("🔧 Remediation Suggestions")
        print("="*70)
        print()
        print("  No remediation suggestions at this time")
        print()
        print("  Suggestions are generated when:")
        print("    • Critical insights are detected")
        print("    • Trends show degradation")
        print("    • High-risk predictions are made")
        print()
        return

    print("🔧 Remediation Suggestions")
    print("="*70)
    print()
    print(f"  Total Suggestions: {len(suggestions)}")
    print()
    print("-"*70)
    print()

    for i, suggestion in enumerate(suggestions, 1):
        # Icon by priority
        priority_icon = {
            "critical": "🔴",
            "warning": "⚠️ ",
            "info": "ℹ️ ",
        }.get(suggestion.priority.value, "•")

        print(f"{priority_icon} Suggestion {i}: {suggestion.title}")
        print(f"   Type: {suggestion.remediation_type.value.replace('_', ' ').title()}")
        print(f"   Priority: {suggestion.priority.value.upper()}")
        print(f"   Effort: {suggestion.estimated_effort.upper()}")
        if suggestion.applicable_to:
            print(f"   Applicable to: {', '.join(suggestion.applicable_to[:3])}")
        print()

        print(f"   Description:")
        print(f"     {suggestion.description}")
        print()

        print(f"   Steps:")
        for step in suggestion.steps:
            print(f"     {step}")
        print()

        if suggestion.code_examples:
            print(f"   Code Examples:")
            for line in suggestion.code_examples:
                print(f"     {line}")
            print()

        if suggestion.metadata.get("ai_enhanced"):
            print(f"     ✨ Enhanced with AI ({suggestion.metadata.get('ai_model', 'unknown')})")
            print()

        print("-"*70)
        print()

    print("Tip: Use --enhance to get AI-enhanced suggestions")
    print("     contextdigger remediate --enhance")
    print()


def cmd_llm(*args):
    """
    Manage local LLM integration for AI-enhanced suggestions.

    Usage:
        contextdigger llm status              Show LLM status
        contextdigger llm enable              Enable LLM integration
        contextdigger llm enable --model qwen:7b  Enable with specific model
        contextdigger llm disable             Disable LLM integration
    """
    from .llm_integration import enable_llm, disable_llm, get_llm_status

    manager = get_manager()
    cdg_dir = manager.project_root / ".cdg"

    if not args or args[0] == "status":
        # Show status
        status = get_llm_status(cdg_dir)

        print("🤖 Local LLM Integration")
        print("="*70)
        print()

        if status["status"] == "disabled":
            print("  Status: DISABLED")
            print()
            print("  Local LLM integration is currently disabled.")
            print()
            print("  Enable it to get AI-enhanced suggestions:")
            print("    contextdigger llm enable")
            print()
        elif status["status"] == "unavailable":
            print(f"  Status: UNAVAILABLE")
            print(f"  Model: {status['model']}")
            print()
            print(f"  ⚠️  {status['message']}")
            if "help" in status:
                print(f"     {status['help']}")
            print()
        else:
            print(f"  Status: AVAILABLE ✓")
            print(f"  Model: {status['model']}")
            print(f"  Temperature: {status['temperature']}")
            print()
            print(f"  ✨ {status['message']}")
            print()
            print("  Use AI-enhanced suggestions:")
            print("    contextdigger remediate --enhance")
            print()

    elif args[0] == "enable":
        # Parse model
        model = "qwen:3b"  # Default
        if "--model" in args:
            idx = args.index("--model")
            if idx + 1 < len(args):
                model = args[idx + 1]

        print("🤖 Enabling Local LLM Integration...")
        print()

        success = enable_llm(cdg_dir, model=model)

        if success:
            print(f"  ✓ LLM integration enabled successfully!")
            print(f"  Model: {model}")
            print()
            print("  Try it out:")
            print("    contextdigger remediate --enhance")
            print()
        else:
            print("  ✗ Failed to enable LLM integration")
            print()
            print("  Ollama is not installed or not running.")
            print()
            print("  Install Ollama:")
            print("    https://ollama.ai/")
            print()
            print("  Then pull a model:")
            print(f"    ollama pull {model}")
            print()

    elif args[0] == "disable":
        disable_llm(cdg_dir)

        print("🤖 Local LLM Integration")
        print("="*70)
        print()
        print("  ✓ LLM integration disabled")
        print()

    else:
        print("Unknown command. Usage:")
        print("  contextdigger llm status")
        print("  contextdigger llm enable")
        print("  contextdigger llm disable")
        print()


# =============================================================================
# Dashboard & Monitoring
# =============================================================================

def cmd_dashboard(*args):
    """Show dashboard."""
    manager = get_manager()
    dashboard = manager.get_dashboard()

    # Check for JSON output
    json_output = '--json' in args

    if json_output:
        # Build comprehensive JSON dashboard
        dashboard_data = {
            "overview": dashboard.get("overview", {}),
            "provenance": None,
            "contracts": None,
            "budget": None,
            "insights": None
        }

        # Add provenance summary
        try:
            from .provenance import ProvenanceTracker
            tracker = ProvenanceTracker(manager.project_root)
            current_session = manager.get_current_session()
            if current_session:
                session_id = current_session.id
                tracker.load_session_provenance(session_id)
                provenance_records = tracker.get_session_provenance(session_id)
                if provenance_records:
                    reason_counts = {}
                    for prov in provenance_records:
                        for reason in prov.reasons:
                            reason_counts[reason.type] = reason_counts.get(reason.type, 0) + 1

                    dashboard_data["provenance"] = {
                        "files_tracked": len(provenance_records),
                        "reason_types": reason_counts
                    }
        except Exception:
            pass

        # Add contracts summary
        try:
            from .continuation import ContractManager
            contract_mgr = ContractManager(manager.project_root)
            active_contract = contract_mgr.get_active_contract()
            if active_contract:
                dashboard_data["contracts"] = {
                    "active": {
                        "intent": active_contract.intent,
                        "area_name": active_contract.area_name,
                        "status": active_contract.status,
                        "progress": active_contract.progress,
                        "notes": active_contract.context.notes if active_contract.context.notes else None
                    },
                    "paused": []
                }
            else:
                history = contract_mgr.get_contract_history(limit=10)
                paused = [c for c in history if c.status != "completed"]
                dashboard_data["contracts"] = {
                    "active": None,
                    "paused": [{"intent": c.intent, "area_name": c.area_name, "status": c.status, "progress": c.progress} for c in paused[:3]]
                }
        except Exception:
            pass

        # Add budget health
        try:
            current_focus = manager.get_current_focus()
            if current_focus:
                area = manager.get_area(current_focus)
                if area:
                    from .budget import BudgetTracker
                    budget_tracker = BudgetTracker()
                    files = manager.get_files_in_area(area)
                    budget_status = budget_tracker.calculate_budget(files)
                    health = budget_tracker.get_budget_health(budget_status)

                    dashboard_data["budget"] = {
                        "health": health,
                        "files_used": budget_status.files_used,
                        "files_max": budget_status.files_max,
                        "lines_used": budget_status.lines_used,
                        "lines_max": budget_status.lines_max,
                        "percentage_files": budget_status.percentage_files,
                        "percentage_lines": budget_status.percentage_lines
                    }
        except Exception:
            pass

        # Add insights summary
        try:
            from .insights import InsightEngine, InsightLevel
            engine = InsightEngine(manager.project_root)
            insights = engine.generate_insights()
            if insights:
                critical = engine.get_insights_by_level(insights, InsightLevel.CRITICAL)
                warnings = engine.get_insights_by_level(insights, InsightLevel.WARNING)
                dashboard_data["insights"] = {
                    "total": len(insights),
                    "critical": len(critical),
                    "warnings": len(warnings),
                    "top": [{"title": i.title, "message": i.message, "level": i.level.value, "impact": i.impact} for i in (critical[:2] + warnings[:1])]
                }
        except Exception:
            pass

        print(json.dumps(dashboard_data, indent=2))
        return

    print("📊 ContextDigger Dashboard")
    print("="*60)
    print()

    # Overview
    overview = dashboard["overview"]
    print("## Overview")
    print("-"*60)
    print(f"  Areas: {overview.get('areas', 0)}")
    print(f"  Notes: {overview.get('notes', 0)}")
    print(f"  Bookmarks: {overview.get('bookmarks', 0)}")
    print(f"  Snapshots: {overview.get('snapshots', 0)}")

    if "currentFocus" in overview:
        focus = overview["currentFocus"]
        print()
        print(f"  Currently in: {focus['name']}")
        print(f"  Path: {focus['path']}")
    print()
    print()

    # Provenance Summary
    try:
        from .provenance import ProvenanceTracker
        tracker = ProvenanceTracker(manager.project_root)

        # Get current session
        current_session = manager.get_current_session()
        if current_session:
            session_id = current_session.id
            tracker.load_session_provenance(session_id)
            provenance_records = tracker.get_session_provenance(session_id)

            if provenance_records:
                print("## 📋 Provenance Summary (Current Session)")
                print("-"*60)
                print(f"  Files tracked: {len(provenance_records)}")

                # Calculate provenance completeness
                # Assume current area files are what we're tracking
                current_focus = manager.get_current_focus()
                if current_focus:
                    area = manager.get_area(current_focus)
                    if area:
                        files = manager.get_files_in_area(area)
                        completeness = tracker.get_provenance_completeness(
                            session_id,
                            len(files)
                        )
                        print(f"  Completeness: {completeness:.0%}")

                # Group by reason type
                reason_counts = {}
                for prov in provenance_records:
                    for reason in prov.reasons:
                        reason_counts[reason.type] = reason_counts.get(reason.type, 0) + 1

                print(f"  Reason types: {len(reason_counts)}")
                # Show top 3 reason types
                top_reasons = sorted(reason_counts.items(), key=lambda x: -x[1])[:3]
                for reason_type, count in top_reasons:
                    print(f"    • {reason_type}: {count}")

                print()
                print(f"  💡 Run 'contextdigger provenance' for details")
                print()
                print()
    except Exception:
        # If provenance summary fails, don't block dashboard
        pass

    # Continuation Contracts Summary
    try:
        from .continuation import ContractManager
        contract_mgr = ContractManager(manager.project_root)

        # Get active contract
        active_contract = contract_mgr.get_active_contract()
        if active_contract:
            print("## 📋 Active Contract")
            print("-"*60)
            print(f"  Intent: {active_contract.intent}")
            print(f"  Area: {active_contract.area_name}")
            print(f"  Status: {active_contract.status} | Progress: {active_contract.progress:.0%}")
            if active_contract.context.notes:
                print(f"  Notes: {active_contract.context.notes}")
            print()
            print(f"  💡 Run 'contextdigger pause' to pause and save")
            print()
            print()

        # Check for paused contracts
        history = contract_mgr.get_contract_history(limit=10)
        paused = [c for c in history if c.status != "completed"]

        if paused and not active_contract:
            print("## 💡 Resume Work")
            print("-"*60)
            print(f"  You have {len(paused)} paused contract(s)")
            print()
            # Show most recent paused contract
            most_recent = paused[0]
            status_icon = {
                "blocked": "⚠️ ",
                "investigating": "🔍",
                "implementing": "🔨",
                "testing": "🧪",
            }.get(most_recent.status, "•")

            print(f"  {status_icon} {most_recent.intent}")
            print(f"     Area: {most_recent.area_name}")
            print(f"     Status: {most_recent.status} | Progress: {most_recent.progress:.0%}")
            print(f"     Paused: {most_recent.updated_at[:16].replace('T', ' ')}")
            print()
            print(f"  💡 Run 'contextdigger continue' to resume")
            print()
            print()
    except Exception:
        # If contracts summary fails, don't block dashboard
        pass

    # Budget Health Summary (Phase 1.3)
    try:
        current_focus = manager.get_current_focus()
        if current_focus:
            area = manager.get_area(current_focus)
            if area:
                from .budget import BudgetTracker
                budget_tracker = BudgetTracker()
                files = manager.get_files_in_area(area)
                budget_status = budget_tracker.calculate_budget(files)

                # Generate alerts
                alerts = budget_tracker.generate_alerts(budget_status)
                health = budget_tracker.get_budget_health(budget_status)

                # Show budget health section
                health_icon = {
                    "healthy": "✅",
                    "warning": "⚠️ ",
                    "critical": "🔴",
                    "exceeded": "💥",
                }.get(health, "ℹ️ ")

                print(f"## {health_icon} Budget Health")
                print("-"*60)
                print(f"  Status: {health.capitalize()}")
                print(f"  Files: {budget_status.files_used}/{budget_status.files_max} ({budget_status.percentage_files:.0%})")
                print(f"  Lines: {budget_status.lines_used:,}/{budget_status.lines_max:,} ({budget_status.percentage_lines:.0%})")

                # Show any alerts
                if alerts:
                    print()
                    print("  Active Alerts:")
                    for alert in alerts:
                        print(f"    {alert.icon} {alert.message}")

                # Show guidance based on health
                if health == "exceeded":
                    print()
                    print("  💡 Budget exceeded - consider narrowing focus area")
                elif health == "critical":
                    print()
                    print("  💡 Critical usage - budget almost exhausted")
                elif health == "warning":
                    print()
                    print("  💡 Approaching budget limit")

                print()
                print()
    except Exception:
        # If budget health fails, don't block dashboard
        pass

    # Insights Summary (Phase 2.1)
    try:
        from .insights import InsightEngine, InsightLevel

        engine = InsightEngine(manager.project_root)
        insights = engine.generate_insights()

        if insights:
            # Get top 3 critical/warning insights
            critical = engine.get_insights_by_level(insights, InsightLevel.CRITICAL)
            warnings = engine.get_insights_by_level(insights, InsightLevel.WARNING)
            top_insights = critical[:2] + warnings[:1] if len(critical) < 2 else critical[:3]

            if top_insights:
                print("## 💡 Top Insights")
                print("-"*60)

                for insight in top_insights:
                    level_icon = {
                        InsightLevel.CRITICAL: "🔴",
                        InsightLevel.WARNING: "⚠️ ",
                        InsightLevel.INFO: "ℹ️ ",
                    }.get(insight.level, "•")

                    print(f"  {level_icon} {insight.title}")
                    print(f"     {insight.description}")
                    if insight.recommendations:
                        print(f"     → {insight.recommendations[0]}")
                    print()

                print(f"  💡 Run 'contextdigger insights' for all {len(insights)} insights")
                print()
                print()
    except Exception:
        # If insights fail, don't block dashboard
        pass

    # Alerts
    alerts = dashboard.get("alerts", [])
    if alerts:
        print("## ⚠️  Alerts")
        print("-"*60)
        for alert in alerts:
            severity_icon = {
                "high": "🔴",
                "medium": "🟡",
                "low": "🟢",
            }.get(alert["severity"], "⚪")

            print(f"  {severity_icon} {alert['message']}")
            print(f"     Action: {alert['action']}")
            print()
        print()

    # Recent Activity
    recent = dashboard.get("recent", {}).get("areas", [])
    if recent:
        print("## Recent Activity")
        print("-"*60)
        for area in recent:
            timestamp = area.get("timestamp", "")[:16].replace("T", " ")
            print(f"  • {area['name']} ({timestamp})")
        print()
        print()

    # Suggestions
    suggestions = dashboard.get("suggestions", [])
    if suggestions:
        print("## 💡 Suggestions")
        print("-"*60)
        for suggestion in suggestions:
            print(f"  • {suggestion}")
        print()
        print()


def cmd_health(*args):
    """Health check."""
    manager = get_manager()
    health = manager.get_health_check()

    print("🏥 Health Check")
    print("="*60)
    print()

    status = health.get("status", "unknown")
    print(f"Status: {status.upper()}")
    print()

    issues = health.get("issues", [])
    if issues:
        print("Issues:")
        for issue in issues:
            print(f"  ⚠️  {issue}")
    else:
        print("✓ No issues found")


def cmd_stats(*args):
    """Statistics."""
    manager = get_manager()
    stats = manager.get_statistics()

    print("📊 Statistics")
    print("="*60)
    print()
    print(f"Total Areas: {stats.get('total_areas', 0)}")
    print(f"Total Notes: {stats.get('total_notes', 0)}")
    print(f"Total Bookmarks: {stats.get('total_bookmarks', 0)}")
    print(f"Total Snapshots: {stats.get('total_snapshots', 0)}")
    print(f"Total Visits: {stats.get('total_visits', 0)}")
    print()

    if stats.get('most_common_tags'):
        print("Most Common Tags:")
        for tag_data in stats['most_common_tags']:
            print(f"  • {tag_data['tag']}: {tag_data['count']} times")

    print()
    enabled = stats.get('enabled_rules', 0)
    total_rules = stats.get('automation_rules', 0)
    print(f"Automation Rules: {total_rules} ({enabled} enabled)")


# =============================================================================
# Team
# =============================================================================

def cmd_team(*args):
    """Team activity."""
    manager = get_manager()
    activity = manager.get_team_activity(max_age_hours=24)

    if not activity:
        print("No recent team activity")
        return

    print("👥 Team Activity (last 24h):\n")
    for act in activity[:10]:
        print(f"  • {act.author}")
        print(f"    {act.areaName} - {act.action}")
        print(f"    {act.timestamp}")
        print()


def cmd_tests(*args):
    """Test coverage."""
    manager = get_manager()
    current = args[0] if args else manager.get_current_focus()

    if not current:
        print("Usage: contextdigger tests [area]")
        return

    coverage = manager.get_area_coverage(current)
    area = manager.get_area(current)

    print(f"🧪 Test Coverage: {area.name}\n")
    print(f"  Line coverage: {coverage.lineCoverage:.1f}%")
    print(f"  Branch coverage: {coverage.branchCoverage:.1f}%")
    print(f"  Files: {coverage.totalFiles}")


if __name__ == "__main__":
    main()
