# Continuation Contract Templates

Pre-built templates for common development workflows. These templates help you start work with a clear structure and checklist.

## Available Templates

### 1. `bug-fix.yaml` - Fixing Bugs
Use when fixing bugs or defects.

**Workflow**: investigating → implementing → testing

**Includes**:
- Root cause analysis checklist
- Fix strategy template
- Testing plan
- Tags: bug, [area], [severity]

**Example Intent**: "Fix authentication timeout bug"

### 2. `feature.yaml` - Building Features
Use when implementing new features or enhancements.

**Workflow**: investigating → implementing → testing

**Includes**:
- Requirements checklist
- Design approach template
- Implementation plan
- Testing strategy
- Tags: feature, [area], [type]

**Example Intent**: "Implement user profile page"

### 3. `refactor.yaml` - Code Refactoring
Use when improving code quality without changing behavior.

**Workflow**: investigating → implementing → testing

**Includes**:
- Code smell identification
- Refactoring plan with safety checks
- Performance verification
- Tags: refactor, [type], [area]

**Example Intent**: "Refactor authentication module"

## How to Use Templates

### Option 1: Manual (Current)
1. Choose the appropriate template
2. Copy the structure when creating notes
3. Fill in the specifics for your work

### Option 2: Future CLI Integration (Planned)
```bash
# Create contract from template
contextdigger start --template bug-fix backend-api

# Interactive prompts
Intent: Fix login timeout bug
Problem: Users are logged out after 5 minutes of inactivity
Goal: Users stay logged in for 30 minutes
Tags: bug, auth, high

# Contract created with template structure
```

## Template Structure

Each template includes:

- **intent**: What you're trying to accomplish
- **problem**: The problem you're solving (with prompts)
- **goal**: What success looks like (with checklist)
- **workflow**: Status progression with tasks for each stage
- **tags**: Recommended tags for organization
- **context_checklist**: What context to gather
- **notes_template**: Structured format for your notes

## Workflow Stages

All templates use a three-stage workflow:

1. **investigating** (🔍)
   - Understand the problem
   - Gather context
   - Plan approach

2. **implementing** (🔨)
   - Write code
   - Make changes
   - Build solution

3. **testing** (🧪)
   - Verify it works
   - Run tests
   - Review and polish

## Customization

Feel free to:
- Copy and modify templates for your team
- Create new templates for your workflows
- Add team-specific checklists
- Adjust tags and categories

## Best Practices

1. **Start with intent** - Clear, specific goal
2. **Define success** - Checkboxes for "done"
3. **Track progress** - Update status as you work
4. **Capture notes** - Document as you learn
5. **Use tags** - Organize and find work later

## Examples

### Bug Fix Example
```yaml
intent: "Fix password reset email not sending"
problem: |
  Users report not receiving password reset emails.
  - Emails worked last week
  - Only affecting Gmail users
  - No errors in logs
goal: |
  Password reset emails send successfully:
  - [x] Root cause identified - SMTP timeout
  - [x] Fix implemented - increased timeout
  - [x] Tests added for email sending
  - [ ] Verified with Gmail test account
```

### Feature Example
```yaml
intent: "Implement dark mode toggle"
problem: |
  Users want dark mode for better readability at night.
  - 50+ user requests
  - Competitive feature
  - Accessibility improvement
goal: |
  Dark mode fully implemented:
  - [x] Design reviewed
  - [x] Theme system created
  - [ ] All components support dark mode
  - [ ] User preference persisted
  - [ ] Tests passing
```

## Future Enhancements

Planned template features:
- CLI integration for template-based contract creation
- Team-shared templates in version control
- Custom template creation wizard
- Template marketplace/library
- AI-suggested templates based on work type

## Contributing

To add a new template:
1. Create `[name].yaml` in this directory
2. Follow the existing template structure
3. Include clear comments and examples
4. Update this README with template details
