"""
ContextDigger Context Aperture Management

Implements attention budget enforcement through context aperture control.
When an area exceeds the attention budget, ContextDigger guides the user
toward better context scoping with narrower aperture settings.

Terminology:
- Context Aperture: The constraint on files (e.g., f/15 = 15 files)
- Attention Budget: Maximum context AI can process effectively
- Focus Discipline: The practice of deliberately constraining context
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Optional, Any
from collections import defaultdict


@dataclass
class SubArea:
    """Represents a suggested sub-area when an area is too large."""

    name: str
    path: str
    file_count: int
    line_count: int
    description: str
    files: List[Path]
    strategy: str = "directory"
    confidence: float = 1.0
    sample_files: List[str] = field(default_factory=list)
    patterns: Dict[str, List[str]] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    related_areas: List[str] = field(default_factory=list)


class RefusalHandler:
    """
    Manages context aperture constraints and attention budget enforcement.

    Core governance mechanism: ContextDigger enforces attention budget limits
    through context aperture control, guiding users toward optimal focus.

    Think of it like a camera aperture: f/15 means 15 files maximum.
    Narrower aperture (fewer files) = sharper AI focus.
    """

    def __init__(self, max_files: int = 15, max_lines: int = 3000):
        """
        Initialize refusal handler.

        Args:
            max_files: Maximum files allowed
            max_lines: Maximum lines allowed
        """
        self.max_files = max_files
        self.max_lines = max_lines

    def format_refusal_message(
        self,
        area_name: str,
        files_used: int,
        lines_used: int,
        reason: str = "attention budget"
    ) -> str:
        """
        Format context aperture constraint message.

        Explains why the area exceeds the attention budget and guides
        the user toward narrower aperture settings.

        Args:
            area_name: Name of the area
            files_used: Number of files in area
            lines_used: Number of lines in area
            reason: Why aperture was constrained

        Returns:
            Formatted constraint message with new terminology
        """
        limit_type = "files" if files_used > self.max_files else "lines"
        limit_value = self.max_files if files_used > self.max_files else self.max_lines
        actual_value = files_used if files_used > self.max_files else lines_used

        message = f"\n⚠️  Context Aperture Exceeded\n"
        message += f"\nThe '{area_name}' area has too many {limit_type} for effective AI attention.\n\n"
        message += f"  📸 Context Aperture: f/{self.max_files} ({self.max_files} files maximum)\n"
        message += f"     Actual: {files_used} files\n\n"
        message += f"  🧠 Attention Budget: {self.max_lines:,} lines maximum\n"
        message += f"     Actual: {lines_used:,} lines\n\n"
        message += f"💡 Narrower aperture (fewer files) = sharper AI focus\n"

        return message

    def suggest_sub_areas(
        self,
        files: List[Path],
        area_name: str,
        project_root: Path
    ) -> List[SubArea]:
        """
        Break large area into smaller sub-areas by directory.

        Strategy:
        1. Group files by parent directory
        2. Calculate file/line counts per directory
        3. Suggest directories that fit within budget
        4. Return top 4 suggestions

        Args:
            files: List of files in the oversized area
            area_name: Name of the parent area
            project_root: Project root path for relative path calculation

        Returns:
            List of SubArea suggestions
        """
        # Group files by parent directory
        files_by_dir: Dict[Path, List[Path]] = defaultdict(list)

        for file_path in files:
            # Get parent directory relative to project root
            try:
                rel_path = file_path.relative_to(project_root)
                parent = rel_path.parent
            except ValueError:
                parent = file_path.parent

            files_by_dir[parent].append(file_path)

        # Create sub-area suggestions
        sub_areas = []

        for dir_path, dir_files in files_by_dir.items():
            file_count = len(dir_files)

            # Only suggest directories that fit within budget
            if file_count <= self.max_files:
                # Calculate line count
                line_count = sum(self._count_lines(f) for f in dir_files)

                # Create sub-area
                sub_area = SubArea(
                    name=f"{area_name}-{dir_path.name}",
                    path=str(dir_path),
                    file_count=file_count,
                    line_count=line_count,
                    description=f"{dir_path.name} module",
                    files=dir_files
                )
                sub_areas.append(sub_area)

        # Sort by file count (prefer smaller, more focused areas)
        sub_areas.sort(key=lambda x: x.file_count)

        return sub_areas[:4]  # Return top 4 suggestions

    def format_sub_area_suggestions(self, sub_areas: List[SubArea]) -> str:
        """
        Format sub-area suggestions for display.

        Args:
            sub_areas: List of suggested sub-areas

        Returns:
            Formatted suggestion text
        """
        if not sub_areas:
            return "\nNo suitable sub-areas found. Consider creating a custom area."

        message = "\nSuggested sub-areas:\n"

        for i, sub in enumerate(sub_areas, 1):
            within_budget = "✓" if sub.line_count <= self.max_lines else "⚠️"
            message += f"\n{i}. {sub.name}\n"
            message += f"   Path: {sub.path}\n"
            message += f"   Size: {sub.file_count} files, {sub.line_count:,} lines {within_budget}\n"
            message += f"   {sub.description}\n"

        return message

    def format_options(self, files_used: int, lines_used: int) -> str:
        """
        Format available options when refusal occurs.

        Args:
            files_used: Number of files in oversized area
            lines_used: Number of lines in oversized area

        Returns:
            Formatted options text
        """
        message = "\nOptions:\n"
        message += "1. Focus on a sub-area (recommended)\n"
        message += f"2. Increase budget to {files_used} files / {lines_used:,} lines (requires explicit confirmation)\n"
        message += "3. Exit and refine your area definition\n"
        message += f"\n⚠️  ContextDigger will not load all {files_used} files without a decision.\n"

        return message

    def display_refusal(
        self,
        area_name: str,
        files: List[Path],
        files_used: int,
        lines_used: int,
        project_root: Path
    ) -> None:
        """
        Display complete refusal message with suggestions and options.

        Args:
            area_name: Name of the area
            files: Files in the area
            files_used: Number of files
            lines_used: Number of lines
            project_root: Project root path
        """
        # Display refusal message
        print(self.format_refusal_message(area_name, files_used, lines_used))

        # Suggest sub-areas
        sub_areas = self.suggest_sub_areas(files, area_name, project_root)
        print(self.format_sub_area_suggestions(sub_areas))

        # Display options
        print(self.format_options(files_used, lines_used))

    def _count_lines(self, file_path: Path) -> int:
        """
        Count lines in a file.

        Args:
            file_path: Path to file

        Returns:
            Number of lines in file
        """
        try:
            if not file_path.exists():
                return 0

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for _ in f)
        except Exception:
            return 0

    def suggest_sub_areas_interactive(
        self,
        files: List[Path],
        area_name: str,
        project_root: Path,
        verbosity: int = 0,
        manager=None
    ) -> Optional[Any]:
        """
        Interactive sub-area suggestion with selection.

        Args:
            files: Files in the oversized area
            area_name: Name of the area
            project_root: Project root path
            verbosity: 0=compact, 1=horizontal, 2=vertical tree
            manager: FocusManager instance for saving areas

        Returns:
            Selected FocusArea if user chooses, None if cancelled
        """
        # Import here to avoid circular dependency
        from .subarea_analyzer import SubAreaAnalyzer, VerbosityRenderer
        from .budget import BudgetTracker

        # Create budget tracker instance
        budget_tracker = BudgetTracker(
            max_files=self.max_files,
            max_lines=self.max_lines
        )
        # Store project_root as attribute for rendering
        budget_tracker.project_root = project_root

        # Create analyzer
        analyzer = SubAreaAnalyzer(project_root, budget_tracker)

        # Run analysis
        analysis = analyzer.analyze_area(files, area_name, max_depth=2)

        # Render based on verbosity
        renderer = VerbosityRenderer(budget_tracker)
        current_verbosity = verbosity

        # Interactive loop - allow switching between views
        while True:
            # Render current view
            if current_verbosity == 0:
                print(renderer.render_compact(analysis))
            elif current_verbosity == 1:
                print(renderer.render_horizontal_verbose(analysis))
            else:
                print(renderer.render_vertical_verbose(analysis))

            # Interactive prompt
            print("\nOptions:")
            print("1. Select sub-area to create and dig")
            print("2. Show more details (horizontal)")
            print("3. Show tree view (vertical)")
            print("4. Override budget (dangerous)")
            print("5. Exit")

            try:
                choice = input("\nYour choice (1-5): ").strip()

                if choice == "1":
                    return self._interactive_select(analysis.suggestions, project_root, area_name, manager)
                elif choice == "2":
                    current_verbosity = 1  # Switch to horizontal view and loop
                    continue
                elif choice == "3":
                    current_verbosity = 2  # Switch to tree view and loop
                    continue
                elif choice == "4":
                    print("\n⚠️  Override not implemented in interactive mode")
                    return None
                else:
                    print("\nExiting...")
                    return None

            except (KeyboardInterrupt, EOFError):
                print("\n\nCancelled by user")
                return None

    def _create_focus_area(self, suggestion, parent_area_name: str, manager=None):
        """
        Create a FocusArea from a suggestion.

        Args:
            suggestion: SubAreaSuggestion to create from
            parent_area_name: Name of parent area
            manager: FocusManager for saving

        Returns:
            Created FocusArea object
        """
        from .manager import FocusArea

        # Add comprehensive exclusions for hidden folders and artifacts
        standard_exclusions = [
            "**/.*",  # Hidden files/folders (.git, .sfdx, .astro, etc.)
            "**/node_modules",
            "**/dist",
            "**/build",
            "**/__pycache__",
            "**/coverage",
            "**/.next",
            "**/.venv",
            "**/venv"
        ]

        # Combine with any existing excludes
        all_excludes = suggestion.patterns.get("exclude", []) + standard_exclusions if suggestion.patterns else standard_exclusions

        focus_area = FocusArea(
            id=suggestion.name.lower().replace(" ", "-"),
            name=suggestion.name,
            description=suggestion.description,
            type="manual",
            patterns={
                "include": suggestion.patterns.get("include", []) if suggestion.patterns else [],
                "exclude": all_excludes
            },
            metadata={
                **suggestion.metadata,
                "parent_area": parent_area_name,
                "strategy": suggestion.strategy,
                "confidence": suggestion.confidence,
                "file_list": [str(f) for f in suggestion.files[:100]]  # Store actual matched files (limited to 100)
            }
        )

        # Save area if manager provided
        if manager:
            manager.save_area(focus_area)
            print(f"✓ Created sub-area: {focus_area.id}")

        return focus_area

    def _interactive_select(self, suggestions, project_root: Path, parent_area_name: str, manager=None) -> Optional[Any]:
        """
        Interactive selection of a sub-area.

        Args:
            manager: FocusManager instance for saving the area

        Returns:
            FocusArea object if selected and saved, None otherwise
        """
        from .manager import FocusArea

        # Try using inquirer for better UX
        try:
            import inquirer

            if not suggestions:
                print("No suggestions available")
                return None

            # Create choices for inquirer
            choices = []
            for i, suggestion in enumerate(suggestions, 1):
                status = "✓" if suggestion.file_count <= self.max_files else "⚠️"
                label = f"{status} {suggestion.name} ({suggestion.file_count} files) - {suggestion.description[:50]}"
                choices.append((label, suggestion))

            # Ask user if they want single or multi-select
            print("\nSelection mode:")
            print("1. Create one sub-area and dig into it")
            print("2. Create multiple sub-areas (batch mode)")
            print("3. Cancel")

            mode_choice = input("\nYour choice (1-3): ").strip()

            if mode_choice == "3":
                print("Cancelled")
                return None

            multi_select = (mode_choice == "2")

            if multi_select:
                # Multi-select with checkboxes
                questions = [
                    inquirer.Checkbox(
                        'subareas',
                        message="Select sub-areas to create (space to select, enter to confirm)",
                        choices=choices,
                    )
                ]

                answers = inquirer.prompt(questions)

                if not answers or not answers.get('subareas'):
                    print("Cancelled")
                    return None

                selected_list = answers['subareas']

                if not selected_list:
                    print("No sub-areas selected")
                    return None

                # Create all selected sub-areas
                created_areas = []
                for suggestion in selected_list:
                    focus_area = self._create_focus_area(suggestion, parent_area_name, manager)
                    if focus_area:
                        created_areas.append(focus_area)

                print(f"\n✅ Created {len(created_areas)} sub-areas:")
                for area in created_areas:
                    print(f"   • {area.id}")

                print(f"\n💡 Next steps:")
                print(f"   1. View all areas: cdg list")
                print(f"   2. Dig into an area: cdg dig <area-id>")
                print(f"   3. Export for AI: cdg export txt")

                return None  # Don't auto-dig when creating multiple

            else:
                # Single select with list
                # Add cancel option
                choices.append(("❌ Cancel", None))

                questions = [
                    inquirer.List(
                        'subarea',
                        message="Select a sub-area to create and dig into",
                        choices=choices,
                    )
                ]

                answers = inquirer.prompt(questions)

                if not answers or not answers.get('subarea'):
                    print("Cancelled")
                    return None

                selected = answers['subarea']

                # Check if user selected cancel
                if selected is None:
                    print("Cancelled")
                    return None

            # Single selection - create and return the area
            focus_area = self._create_focus_area(selected, parent_area_name, manager)
            return focus_area

        except ImportError:
            # Fallback to simple number selection
            print("\n💡 Install inquirer for better selection: pip install 'contextdigger[interactive]'")
            print("\nAvailable sub-areas:")

            for i, suggestion in enumerate(suggestions, 1):
                status = "✓" if suggestion.file_count <= self.max_files else "⚠️"
                print(f"{i}. {status} {suggestion.name} ({suggestion.file_count} files)")
                print(f"   {suggestion.description}")

            try:
                choice = input(f"\nSelect sub-area (1-{len(suggestions)}) or 'q' to quit: ").strip()

                if choice.lower() == 'q':
                    return None

                idx = int(choice) - 1
                if 0 <= idx < len(suggestions):
                    selected = suggestions[idx]
                    focus_area = self._create_focus_area(selected, parent_area_name, manager)
                    return focus_area
                else:
                    print("Invalid selection")
                    return None

            except (ValueError, KeyboardInterrupt, EOFError):
                print("\nCancelled")
                return None

    def display_refusal_interactive(
        self,
        area_name: str,
        files: List[Path],
        files_used: int,
        lines_used: int,
        project_root: Path,
        verbosity: int = 0,
        manager=None
    ) -> Optional[Any]:
        """
        Display refusal with interactive options.

        Args:
            area_name: Name of the area
            files: Files in the area
            files_used: Number of files
            lines_used: Number of lines
            project_root: Project root path
            verbosity: Verbosity level (0=compact, 1=horizontal, 2=vertical)
            manager: FocusManager instance for saving areas

        Returns:
            Selected FocusArea object or None (exit)
        """
        # Show refusal message
        print(self.format_refusal_message(area_name, files_used, lines_used))

        # Get and display suggestions interactively
        selected_area = self.suggest_sub_areas_interactive(
            files, area_name, project_root, verbosity, manager
        )

        # Return the FocusArea directly (not a string)
        return selected_area


def should_refuse(files_used: int, lines_used: int, max_files: int, max_lines: int) -> bool:
    """
    Check if area should be refused based on budget.

    Args:
        files_used: Number of files in area
        lines_used: Number of lines in area
        max_files: Maximum files allowed
        max_lines: Maximum lines allowed

    Returns:
        True if area exceeds budget and should be refused
    """
    return files_used > max_files or lines_used > max_lines
