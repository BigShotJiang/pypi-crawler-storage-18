# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateSimAlgorithmImagesRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'int',
        'body': 'PatchedAlgImageUpdateSrlz'
    }

    attribute_map = {
        'id': 'id',
        'body': 'body'
    }

    def __init__(self, id=None, body=None):
        r"""UpdateSimAlgorithmImagesRequest

        The model defined in huaweicloud sdk

        :param id: A unique integer value identifying this alg image.
        :type id: int
        :param body: Body of the UpdateSimAlgorithmImagesRequest
        :type body: :class:`huaweicloudsdkoctopus.v2.PatchedAlgImageUpdateSrlz`
        """
        
        

        self._id = None
        self._body = None
        self.discriminator = None

        self.id = id
        if body is not None:
            self.body = body

    @property
    def id(self):
        r"""Gets the id of this UpdateSimAlgorithmImagesRequest.

        A unique integer value identifying this alg image.

        :return: The id of this UpdateSimAlgorithmImagesRequest.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this UpdateSimAlgorithmImagesRequest.

        A unique integer value identifying this alg image.

        :param id: The id of this UpdateSimAlgorithmImagesRequest.
        :type id: int
        """
        self._id = id

    @property
    def body(self):
        r"""Gets the body of this UpdateSimAlgorithmImagesRequest.

        :return: The body of this UpdateSimAlgorithmImagesRequest.
        :rtype: :class:`huaweicloudsdkoctopus.v2.PatchedAlgImageUpdateSrlz`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateSimAlgorithmImagesRequest.

        :param body: The body of this UpdateSimAlgorithmImagesRequest.
        :type body: :class:`huaweicloudsdkoctopus.v2.PatchedAlgImageUpdateSrlz`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateSimAlgorithmImagesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
