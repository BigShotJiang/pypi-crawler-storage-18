# Accessiqlue
[![PyPI version](https://badge.fury.io/py/accessiqlue.svg)](https://badge.fury.io/py/accessiqlue)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/accessiqlue)](https://pepy.tech/project/accessiqlue)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


Accessiqlue is a Python package designed to take user input about accessibility challenges and generate structured summaries or actionable recommendations. It leverages advanced pattern matching with language model interactions to extract key points, identify accessibility needs, and produce clear, organized responses. This helps organizations better understand accessibility issues from user reports or feedback, enabling targeted improvements without processing raw multimedia data.

## Installation

```bash
pip install accessiqlue
```

## Usage

### Basic Usage

```python
from accessiqlue import accessiqlue

user_input = "The website is not accessible because the contrast is too low."
response = accessiqlue(user_input)
print(response)
```

### Using a Custom LLM

You can use your own LLM instance by passing it to the `accessiqlue` function. Here are examples using different LLMs:

#### Using OpenAI

```python
from langchain_openai import ChatOpenAI
from accessiqlue import accessiqlue

llm = ChatOpenAI()
response = accessiqlue(user_input, llm=llm)
print(response)
```

#### Using Anthropic

```python
from langchain_anthropic import ChatAnthropic
from accessiqlue import accessiqlue

llm = ChatAnthropic()
response = accessiqlue(user_input, llm=llm)
print(response)
```

#### Using Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from accessiqlue import accessiqlue

llm = ChatGoogleGenerativeAI()
response = accessiqlue(user_input, llm=llm)
print(response)
```

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Default LLM

By default, Accessiqlue uses `ChatLLM7` from `langchain_llm7`. You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Rate Limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits, you can pass your own API key via the environment variable `LLM7_API_KEY` or directly to the `accessiqlue` function.

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/accessiqlue/issues).

## Author

- **Eugene Evstafev**
- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)