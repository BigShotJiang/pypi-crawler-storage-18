# AxiomX 0.0.83462: the Gauss Edition

AxiomX is proud to release the 3rd special edition - the Gauss Edition. This edition is specific to the works of Carl Friedrich Gauss. The version number 0.0.83462 represents the Gauss Constant, which is the reciprocal of the Arithmetic-Geometric mean of 1 and √2. Here are some methods we have added and changed:

1. agm(a, b) - returns the arithmetic-geometric mean of a and b.
2. sqrt(n) - using Halley's method, which is faster that the Newton-Raphson Method.
3. gauss_legendre(step) - This calculates the value of &#960; to *step* steps. 3 returns an accurate value of &#960;.

## Note:
We have added a website for our project. Go to https://bit.ly/AxiomX-py to see our project. This library has been licensed under MIT and no one is supposed to copy code from AxiomX. Hope you all enjoy and please patronize.