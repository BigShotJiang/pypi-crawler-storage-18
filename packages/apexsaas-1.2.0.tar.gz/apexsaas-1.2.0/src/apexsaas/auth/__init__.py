"""
Auth functions - standalone, no database required.

All auth functions are async by default. Use sync wrappers for non-async contexts.
"""

# Async functions (standard)
from apexsaas.auth.signup import signup
from apexsaas.auth.login import login
from apexsaas.auth.logout import logout
from apexsaas.auth.forgot_password import forgot_password
from apexsaas.auth.reset_password import reset_password
from apexsaas.auth.verify_email import verify_email
from apexsaas.auth.verify_token import verify_token
from apexsaas.auth.refresh_token import refresh_access_token

# Sync wrappers
from apexsaas.auth.signup import signup_sync
from apexsaas.auth.login import login_sync
from apexsaas.auth.logout import logout_sync
from apexsaas.auth.forgot_password import forgot_password_sync
from apexsaas.auth.reset_password import reset_password_sync
from apexsaas.auth.verify_email import verify_email_sync
from apexsaas.auth.verify_token import verify_token_sync
from apexsaas.auth.refresh_token import refresh_access_token_sync

__all__ = [
    # Async functions (standard)
    'signup',
    'login',
    'logout',
    'forgot_password',
    'reset_password',
    'verify_email',
    'verify_token',
    'refresh_access_token',
    # Sync wrappers
    'signup_sync',
    'login_sync',
    'logout_sync',
    'forgot_password_sync',
    'reset_password_sync',
    'verify_email_sync',
    'verify_token_sync',
    'refresh_access_token_sync',
]


