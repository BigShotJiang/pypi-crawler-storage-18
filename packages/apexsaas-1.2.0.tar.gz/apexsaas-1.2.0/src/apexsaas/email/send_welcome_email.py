"""
Send welcome email function.
"""

import asyncio
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To

from apexsaas.exceptions import ApexEmailError, ApexValidationError
from apexsaas.email._templates import get_welcome_template


async def send_welcome_email(
    to_email: str,
    to_name: str,
    sendgrid_api_key: str,
    from_email: str,
    from_name: str = "Apex",
    app_url: str = None
) -> dict:
    """
    Send welcome email to new users (async).
    
    Args:
        to_email: Recipient email address
        to_name: Recipient name
        sendgrid_api_key: SendGrid API key
        from_email: Sender email address
        from_name: Sender name (default: "Apex")
        app_url: Optional application URL
    
    Returns:
        dict with success status and message details
    
    Raises:
        ApexValidationError: If required parameters are missing
        ApexEmailError: If SendGrid API call fails
    """
    if not to_email or not to_name:
        raise ApexValidationError("to_email and to_name are required")
    if not sendgrid_api_key:
        raise ApexValidationError("sendgrid_api_key is required")
    if not from_email:
        raise ApexValidationError("from_email is required")
    
    try:
        # Get HTML template
        html_content = get_welcome_template(to_name, app_url)
        
        # Create message
        message = Mail(
            from_email=(from_email, from_name),
            to_emails=To(to_email),
            subject="Welcome!",
            html_content=html_content,
            plain_text_content=f"Welcome {to_name}! Thank you for joining us."
        )
        
        # Send email (run in thread to avoid blocking)
        def _send():
            client = SendGridAPIClient(api_key=sendgrid_api_key)
            return client.send(message)
        
        response = await asyncio.to_thread(_send)
        
        # Check response
        if response.status_code not in [200, 201, 202]:
            raise ApexEmailError(
                f"SendGrid API error: {response.status_code}"
            )
        
        return {
            'success': True,
            'email_sent': True,
            'message_id': response.headers.get('X-Message-Id', 'unknown'),
            'message': f'Welcome email sent to {to_email}'
        }
    
    except Exception as e:
        if isinstance(e, (ApexValidationError, ApexEmailError)):
            raise
        raise ApexEmailError(
            f"Failed to send welcome email: {str(e)}"
        )


def send_welcome_email_sync(
    to_email: str,
    to_name: str,
    sendgrid_api_key: str,
    from_email: str,
    from_name: str = "Apex",
    app_url: str = None
) -> dict:
    """Sync wrapper for send_welcome_email."""
    from apexsaas.core.utils.async_runner import run_async
    try:
        return run_async(send_welcome_email(
            to_email=to_email,
            to_name=to_name,
            sendgrid_api_key=sendgrid_api_key,
            from_email=from_email,
            from_name=from_name,
            app_url=app_url
        ))
    except Exception as e:
        raise ApexEmailError(f"Failed to send welcome email: {str(e)}")
