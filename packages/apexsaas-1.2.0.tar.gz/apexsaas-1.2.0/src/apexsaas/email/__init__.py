"""
Email functions - SendGrid integration.

All email functions are async by default. Use sync wrappers for non-async contexts.
"""

# Async functions (standard)
from apexsaas.email.send_verification_email import send_verification_email
from apexsaas.email.send_reset_email import send_reset_email
from apexsaas.email.send_welcome_email import send_welcome_email
from apexsaas.email.send_payment_confirmation import send_payment_confirmation
from apexsaas.email.send_email import send_email

# Sync wrappers
from apexsaas.email.send_verification_email import send_verification_email_sync
from apexsaas.email.send_reset_email import send_reset_email_sync
from apexsaas.email.send_welcome_email import send_welcome_email_sync
from apexsaas.email.send_payment_confirmation import send_payment_confirmation_sync
from apexsaas.email.send_email import send_email_sync

__all__ = [
    # Async functions (standard)
    'send_verification_email',
    'send_reset_email',
    'send_welcome_email',
    'send_payment_confirmation',
    'send_email',
    # Sync wrappers
    'send_verification_email_sync',
    'send_reset_email_sync',
    'send_welcome_email_sync',
    'send_payment_confirmation_sync',
    'send_email_sync',
]


