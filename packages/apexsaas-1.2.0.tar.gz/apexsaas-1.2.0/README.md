# ApexSaaS

Complete authentication, payments, and email solution for Python. Database-agnostic, framework-agnostic, and production-ready.

## Features

- 🔐 **Authentication**: User signup, login, password reset, JWT tokens
- 💳 **Payments**: PayPal integration for orders and subscriptions
- 📧 **Email**: SendGrid integration for transactional emails
- 🚀 **Database-agnostic**: Works with any database or storage
- ⚡ **Framework-agnostic**: Use with FastAPI, Flask, Django, or any Python app
- 🎯 **Production-ready**: Battle-tested and ready for production use

## Quick Start

### Installation

```bash
pip install apexsaas
```

### Example: User Signup

```python
from apexsaas.auth import signup

result = signup(
    email="user@example.com",
    password="SecurePass123!",
    name="John Doe",
    sendgrid_api_key="SG.your_sendgrid_api_key",
    from_email="noreply@yourdomain.com",
    jwt_secret="your-secret-key"
)

# Store in your database
user_data = result['user']
access_token = result['access_token']
refresh_token = result['refresh_token']
```

### Example: Create Payment Order

```python
from apexsaas.payments import create_order

order = create_order(
    amount="99.99",
    currency="USD",
    client_id="your_paypal_client_id",
    client_secret="your_paypal_client_secret",
    return_url="https://yourdomain.com/success",
    cancel_url="https://yourdomain.com/cancel",
    sandbox=True
)

# Redirect user to PayPal
redirect(order['approval_url'])
```

### Example: Send Custom Email

```python
from apexsaas.email import send_email

result = send_email(
    to_email="user@example.com",
    to_name="John Doe",  # Optional
    subject="Welcome!",
    html_content="<h1>Your custom HTML email</h1>",
    sendgrid_api_key="SG.your_key",
    from_email="noreply@yourdomain.com"
)
```

## Documentation

- **User Guide**: Complete documentation with examples
- **Quick Start**: Get started in 5 minutes

## Requirements

- Python 3.8+
- SendGrid API key (for emails)
- PayPal Client ID & Secret (for payments)
- JWT Secret (for authentication)

## License

MIT License

## Support

- **GitHub**: https://github.com/apexneural/apexsaas
- **Issues**: https://github.com/apexneural/apexsaas/issues

---

**Version:** 1.0.2

