"""
Command Manifest Validator

Validates the command manifest for:
- JSON schema compliance
- Required fields presence
- Naming pattern consistency
- Cross-reference integrity
- Category validity

Exit codes:
- 0: All validations pass
- 1: Schema violations
- 2: Cross-reference violations
- 3: Both schema and cross-reference violations
"""

import sys
import json
import re
import ast
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ValidationError:
    """Represents a validation error."""
    severity: str  # 'error' or 'warning'
    category: str  # 'schema', 'cross-reference', 'naming', etc.
    message: str
    command_id: Optional[str] = None
    field: Optional[str] = None


class ManifestValidator:
    """Validates command manifest integrity."""

    def __init__(self, manifest_path: Path, contextdigger_root: Path):
        """Initialize validator."""
        self.manifest_path = manifest_path
        self.root = contextdigger_root
        self.errors: List[ValidationError] = []
        self.warnings: List[ValidationError] = []

    def validate(self) -> Tuple[bool, List[ValidationError], List[ValidationError]]:
        """
        Run all validations.

        Returns:
            (success, errors, warnings)
        """
        # Load manifest
        try:
            with open(self.manifest_path, 'r') as f:
                self.manifest = json.load(f)
        except json.JSONDecodeError as e:
            self.errors.append(ValidationError(
                severity='error',
                category='schema',
                message=f"Invalid JSON: {e}"
            ))
            return False, self.errors, self.warnings

        # Run validations
        print("🔍 Validating manifest schema...")
        self.validate_schema()

        print("🔍 Validating naming patterns...")
        self.validate_naming_patterns()

        print("🔍 Validating category references...")
        self.validate_categories()

        print("🔍 Validating cross-references...")
        self.validate_cross_references()

        print("🔍 Checking for orphaned commands...")
        self.check_orphaned_commands()

        # Summary
        success = len(self.errors) == 0
        return success, self.errors, self.warnings

    def validate_schema(self):
        """Validate manifest schema structure."""
        # Check top-level fields
        required_fields = ['version', 'metadata', 'categories', 'commands']
        for field in required_fields:
            if field not in self.manifest:
                self.errors.append(ValidationError(
                    severity='error',
                    category='schema',
                    message=f"Missing required field: {field}"
                ))

        # Validate metadata
        if 'metadata' in self.manifest:
            meta = self.manifest['metadata']
            if 'generated_at' not in meta:
                self.warnings.append(ValidationError(
                    severity='warning',
                    category='schema',
                    message="Missing metadata.generated_at"
                ))
            if 'total_commands' not in meta:
                self.warnings.append(ValidationError(
                    severity='warning',
                    category='schema',
                    message="Missing metadata.total_commands"
                ))

        # Validate each command
        if 'commands' in self.manifest:
            for cmd in self.manifest['commands']:
                self.validate_command_schema(cmd)

    def validate_command_schema(self, cmd: Dict):
        """Validate a single command entry."""
        cmd_id = cmd.get('id', '<unknown>')

        # Required fields
        required_fields = ['id', 'canonical_name', 'category', 'description']
        for field in required_fields:
            if field not in cmd:
                self.errors.append(ValidationError(
                    severity='error',
                    category='schema',
                    message=f"Missing required field: {field}",
                    command_id=cmd_id,
                    field=field
                ))

        # Check CLI section
        if 'cli' not in cmd:
            self.warnings.append(ValidationError(
                severity='warning',
                category='schema',
                message="Missing CLI section",
                command_id=cmd_id
            ))
        else:
            cli = cmd['cli']
            if 'name' not in cli or 'function' not in cli or 'implemented' not in cli:
                self.errors.append(ValidationError(
                    severity='error',
                    category='schema',
                    message="CLI section missing required fields (name, function, implemented)",
                    command_id=cmd_id
                ))

        # Check at least one implementation exists
        has_impl = False
        if cmd.get('cli', {}).get('implemented'):
            has_impl = True
        mcp = cmd.get('mcp')
        if mcp and mcp.get('implemented'):
            has_impl = True
        skill = cmd.get('skill')
        if skill and skill.get('exists'):
            has_impl = True

        if not has_impl:
            self.warnings.append(ValidationError(
                severity='warning',
                category='schema',
                message="Command has no implementations (cli, mcp, or skill)",
                command_id=cmd_id
            ))

    def validate_naming_patterns(self):
        """Validate naming pattern compliance."""
        if 'commands' not in self.manifest:
            return

        for cmd in self.manifest['commands']:
            cmd_id = cmd.get('id', '<unknown>')

            # CLI function pattern: cmd_[a-z_]+
            if 'cli' in cmd and 'function' in cmd['cli']:
                func = cmd['cli']['function']
                if func and not re.match(r'^cmd_[a-z_]+$', func):
                    self.warnings.append(ValidationError(
                        severity='warning',
                        category='naming',
                        message=f"CLI function '{func}' doesn't match pattern 'cmd_[a-z_]+'",
                        command_id=cmd_id
                    ))

            # MCP tool pattern: [a-z_]+
            if 'mcp' in cmd and cmd['mcp'] and 'tool_name' in cmd['mcp']:
                tool = cmd['mcp']['tool_name']
                if tool and not re.match(r'^[a-z_]+$', tool):
                    self.errors.append(ValidationError(
                        severity='error',
                        category='naming',
                        message=f"MCP tool '{tool}' doesn't match pattern '[a-z_]+'",
                        command_id=cmd_id
                    ))

            # Slash command pattern: /[a-z-]+
            if 'slash' in cmd and cmd['slash'] and 'primary' in cmd['slash']:
                slash = cmd['slash']['primary']
                if slash and not re.match(r'^/[a-z-]+$', slash):
                    self.errors.append(ValidationError(
                        severity='error',
                        category='naming',
                        message=f"Slash command '{slash}' doesn't match pattern '/[a-z-]+'",
                        command_id=cmd_id
                    ))

    def validate_categories(self):
        """Validate category references."""
        if 'categories' not in self.manifest or 'commands' not in self.manifest:
            return

        # Build valid category IDs
        valid_categories = {cat['id'] for cat in self.manifest['categories']}

        # Check each command's category
        for cmd in self.manifest['commands']:
            cmd_id = cmd.get('id', '<unknown>')
            category = cmd.get('category')

            if not category:
                self.errors.append(ValidationError(
                    severity='error',
                    category='schema',
                    message="Command missing category",
                    command_id=cmd_id
                ))
            elif category not in valid_categories:
                self.errors.append(ValidationError(
                    severity='error',
                    category='schema',
                    message=f"Invalid category '{category}' (not in categories list)",
                    command_id=cmd_id
                ))

    def validate_cross_references(self):
        """Validate cross-references to code."""
        # Parse CLI functions
        cli_functions = self.parse_cli_functions()

        # Parse MCP tools
        mcp_tools = self.parse_mcp_tools()

        # Scan skills
        skill_files = self.scan_skill_files()

        # Validate each command
        for cmd in self.manifest['commands']:
            cmd_id = cmd.get('id', '<unknown>')

            # Check CLI function exists
            if 'cli' in cmd and cmd['cli'].get('implemented'):
                func = cmd['cli'].get('function')
                if func and func not in cli_functions:
                    self.errors.append(ValidationError(
                        severity='error',
                        category='cross-reference',
                        message=f"CLI function '{func}' not found in cli.py",
                        command_id=cmd_id
                    ))

            # Check MCP tool exists
            if 'mcp' in cmd and cmd['mcp'] and cmd['mcp'].get('implemented'):
                tool = cmd['mcp'].get('tool_name')
                if tool and tool not in mcp_tools:
                    self.errors.append(ValidationError(
                        severity='error',
                        category='cross-reference',
                        message=f"MCP tool '{tool}' not found in mcp_server.py or not implemented",
                        command_id=cmd_id
                    ))

            # Check skill file exists
            if 'skill' in cmd and cmd['skill'].get('exists'):
                skill_file = cmd['skill'].get('file')
                if skill_file and skill_file not in skill_files:
                    self.warnings.append(ValidationError(
                        severity='warning',
                        category='cross-reference',
                        message=f"Skill file '{skill_file}' not found in claude-skills/",
                        command_id=cmd_id
                    ))

    def check_orphaned_commands(self):
        """Check for commands with no reachable interface."""
        for cmd in self.manifest['commands']:
            cmd_id = cmd.get('id', '<unknown>')

            # Check if command is reachable from any interface
            cli_impl = cmd.get('cli', {}).get('implemented', False)
            mcp_impl = cmd.get('mcp', {}).get('implemented', False) if cmd.get('mcp') else False
            skill_exists = cmd.get('skill', {}).get('exists', False)

            if not (cli_impl or mcp_impl or skill_exists):
                self.warnings.append(ValidationError(
                    severity='warning',
                    category='orphan',
                    message="Command has no implemented interface (unreachable)",
                    command_id=cmd_id
                ))

    def parse_cli_functions(self) -> Set[str]:
        """Parse CLI functions from cli.py."""
        cli_path = self.root / "contextdigger" / "cli.py"
        functions = set()

        try:
            with open(cli_path, 'r') as f:
                tree = ast.parse(f.read())

            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if node.name.startswith('cmd_'):
                        functions.add(node.name)
        except Exception as e:
            self.warnings.append(ValidationError(
                severity='warning',
                category='cross-reference',
                message=f"Could not parse cli.py: {e}"
            ))

        return functions

    def parse_mcp_tools(self) -> Set[str]:
        """Parse implemented MCP tools from mcp_server.py."""
        mcp_path = self.root / "contextdigger" / "mcp_server.py"
        tools = set()

        try:
            with open(mcp_path, 'r') as f:
                content = f.read()

            # Find implemented tools in execute_tool method
            # Match both 'if' and 'elif' statements
            impl_pattern = r'(?:if|elif)\s+tool_name\s*==\s*["\']([^"\']+)["\']'
            for match in re.finditer(impl_pattern, content):
                tools.add(match.group(1))

        except Exception as e:
            self.warnings.append(ValidationError(
                severity='warning',
                category='cross-reference',
                message=f"Could not parse mcp_server.py: {e}"
            ))

        return tools

    def scan_skill_files(self) -> Set[str]:
        """Scan for skill files in claude-skills/."""
        skills_path = self.root / "claude-skills"
        files = set()

        if skills_path.exists():
            for skill_file in skills_path.glob("*.md"):
                files.add(skill_file.name)

        return files


def main():
    """Main entry point."""
    # Find paths
    script_path = Path(__file__).resolve()
    contextdigger_root = script_path.parent.parent
    manifest_path = contextdigger_root / "contextdigger" / "commands_manifest.json"

    if not manifest_path.exists():
        print(f"❌ Manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    # Validate
    print(f"📋 Validating manifest: {manifest_path}")
    print()

    validator = ManifestValidator(manifest_path, contextdigger_root)
    success, errors, warnings = validator.validate()

    # Print results
    print()
    print("=" * 70)
    print("VALIDATION RESULTS")
    print("=" * 70)

    if errors:
        print(f"\n❌ ERRORS ({len(errors)}):")
        for err in errors:
            cmd_info = f" [{err.command_id}]" if err.command_id else ""
            print(f"  • {err.category.upper()}{cmd_info}: {err.message}")

    if warnings:
        print(f"\n⚠️  WARNINGS ({len(warnings)}):")
        for warn in warnings:
            cmd_info = f" [{warn.command_id}]" if warn.command_id else ""
            print(f"  • {warn.category.upper()}{cmd_info}: {warn.message}")

    if not errors and not warnings:
        print("\n✅ All validations passed!")

    print()
    print("=" * 70)
    print(f"Summary: {len(errors)} errors, {len(warnings)} warnings")
    print("=" * 70)

    # Exit code
    if errors and warnings:
        sys.exit(3)
    elif errors:
        sys.exit(1)
    elif warnings:
        sys.exit(2)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
