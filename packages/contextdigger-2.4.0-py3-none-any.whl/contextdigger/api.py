"""
ContextDigger Unified API Layer

Provides a clean, token-aware Python API that wraps FocusManager and services.
All operations accept a workspace path and optional token for authorization.

This layer:
- Enforces permissions via AuthzBackend
- Returns DTOs (Data Transfer Objects) instead of internal models
- Provides structured refusals aligned with refusal.py
- Can be called by CLI, MCP, VS Code, or future integrations

Design goals:
- Provider-agnostic (works with any AuthzBackend)
- Testable (can mock tokens and workspace state)
- Type-safe (explicit DTOs with dataclasses)
- Governance-first (enforces budgets and policies)
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

from .manager import FocusManager, FocusArea, Bookmark, ContextSnapshot
from .authz import (
    Permission,
    Tier,
    TokenInfo,
    AuthzBackend,
    AuthzError,
    get_authz_backend
)
from .budget import BudgetTracker, BudgetStatus, create_budget_tracker_from_config


# ============================================================================
# DTOs (Data Transfer Objects)
# ============================================================================


@dataclass
class AreaDto:
    """Code area summary."""
    id: str
    name: str
    description: str
    type: str  # "auto-detected" or "manual"
    file_count: int
    is_current: bool


@dataclass
class FocusedFile:
    """A file in the current focus."""
    path: str
    reason: str                 # Provenance: why this file was included
    lines: int
    size_bytes: int


@dataclass
class BudgetStatusDto:
    """Budget usage status."""
    files_used: int
    files_max: int
    lines_used: int
    lines_max: int
    health: str                 # "healthy", "warning", "exceeded"
    percentage: float
    policy_mode: str            # "strict", "warning", "advisory"


@dataclass
class FocusBundle:
    """Current focus with files, provenance, and budget."""
    area_id: Optional[str]
    area_name: Optional[str]
    files: List[FocusedFile]
    budget: BudgetStatusDto
    session_id: Optional[str]


@dataclass
class ContractSummary:
    """Continuation contract summary."""
    id: str
    state: str                  # "active", "paused", "completed", "expired"
    area_id: Optional[str]
    description: str
    created_at: datetime
    updated_at: datetime


@dataclass
class InsightDto:
    """An insight or recommendation."""
    level: str                  # "critical", "warning", "info"
    title: str
    description: str
    impact: str
    confidence: float
    related_areas: List[str]


@dataclass
class ProvenanceRecordDto:
    """File provenance record."""
    path: str
    area_id: str
    reason: str                 # Why this file was included
    source: str                 # "discovery", "manual", "continuation"
    score: Optional[float] = None


@dataclass
class ApiRefusal(Exception):
    """
    Structured refusal response.

    Raised when an operation cannot be performed due to:
    - Missing/invalid token
    - Insufficient permissions
    - Budget exceeded
    - Policy violation
    """
    code: str                   # Machine-readable code
    message: str                # Human-readable message
    details: Optional[str] = None
    required_permission: Optional[Permission] = None

    def __str__(self) -> str:
        """String representation."""
        return self.message

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
            "required_permission": self.required_permission.value if self.required_permission else None
        }


# ============================================================================
# API Functions
# ============================================================================


class ContextDiggerApi:
    """
    Main API class for ContextDigger operations.

    All methods accept workspace and optional token.
    Operations are permission-checked and return DTOs.
    """

    def __init__(self, workspace: Path, backend_type: str = "local"):
        """
        Initialize API for a workspace.

        Args:
            workspace: Path to workspace root (must contain .cdg/)
            backend_type: Authorization backend type ("local", "okta", "chargebee")
        """
        self.workspace = workspace
        self.authz_backend = get_authz_backend(workspace, backend_type)

    def _check_permission(
        self,
        token: Optional[str],
        permission: Permission
    ) -> TokenInfo:
        """
        Validate token and check permission.

        Args:
            token: Optional token string
            permission: Required permission

        Returns:
            TokenInfo if authorized

        Raises:
            ApiRefusal: If token invalid or permission denied
        """
        # If no token provided, use default local token for backward compat
        if token is None:
            token = self.authz_backend.DEFAULT_TOKEN if hasattr(self.authz_backend, 'DEFAULT_TOKEN') else None

        if token is None:
            raise ApiRefusal(
                code="missing_token",
                message="No token provided and no default available",
                required_permission=permission
            )

        # Validate token
        try:
            token_info = self.authz_backend.validate_token(token)
        except AuthzError as e:
            raise ApiRefusal(
                code=e.code,
                message=e.message,
                details=e.details
            )

        # Check permission
        if not token_info.has_permission(permission):
            raise ApiRefusal(
                code="insufficient_permissions",
                message=f"Token lacks required permission: {permission.value}",
                required_permission=permission,
                details=f"Current permissions: {[p.value for p in token_info.permissions]}"
            )

        return token_info

    def _get_manager(self) -> FocusManager:
        """Get FocusManager instance for workspace."""
        return FocusManager(self.workspace)

    def list_areas(self, token: Optional[str] = None) -> List[AreaDto]:
        """
        List all discovered code areas.

        Args:
            token: Optional authorization token

        Returns:
            List of AreaDto objects

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.READ_AREAS)

        manager = self._get_manager()
        areas = manager.list_areas()
        current_focus_id = manager.get_current_focus()

        return [
            AreaDto(
                id=area.id,
                name=area.name,
                description=area.description,
                type=area.type,
                file_count=len(manager.get_files_in_area(area)),
                is_current=(current_focus_id == area.id)
            )
            for area in areas
        ]

    def dig_area(
        self,
        area_id: str,
        token: Optional[str] = None
    ) -> FocusBundle:
        """
        Navigate to and load a code area.

        Args:
            area_id: Area identifier
            token: Optional authorization token

        Returns:
            FocusBundle with focused files and budget

        Raises:
            ApiRefusal: If not authorized or budget exceeded
            ValueError: If area_id does not exist
        """
        self._check_permission(token, Permission.DIG)

        manager = self._get_manager()

        # Validate area exists
        area = manager.get_area(area_id)
        if not area:
            raise ValueError(f"Area '{area_id}' not found")

        # Set focus (equivalent to "dig")
        try:
            manager.set_current_focus(area_id)
        except Exception as e:
            # Check if this was a governance refusal
            if "exceeded" in str(e).lower() or "budget" in str(e).lower():
                raise ApiRefusal(
                    code="budget_exceeded",
                    message=str(e),
                    details=f"Area '{area_id}' exceeds attention budget"
                )
            raise

        # Get current focus
        return self.get_focus(token)

    def get_focus(self, token: Optional[str] = None) -> FocusBundle:
        """
        Get current focus state.

        Args:
            token: Optional authorization token

        Returns:
            FocusBundle with current focused files and budget

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.FOCUS)

        manager = self._get_manager()
        current_focus_id = manager.get_current_focus()

        if not current_focus_id:
            return FocusBundle(
                area_id=None,
                area_name=None,
                files=[],
                budget=BudgetStatusDto(
                    files_used=0,
                    files_max=15,
                    lines_used=0,
                    lines_max=3000,
                    health="healthy",
                    percentage=0.0,
                    policy_mode="advisory"
                ),
                session_id=None
            )

        # Get the actual area
        current_area = manager.get_area(current_focus_id)
        if not current_area:
            # Focus ID exists but area doesn't - clear focus and return empty
            manager.clear_current_focus()
            return FocusBundle(
                area_id=None,
                area_name=None,
                files=[],
                budget=BudgetStatusDto(
                    files_used=0,
                    files_max=15,
                    lines_used=0,
                    lines_max=3000,
                    health="healthy",
                    percentage=0.0,
                    policy_mode="advisory"
                ),
                session_id=None
            )

        # Get files in area
        area_files = manager.get_files_in_area(current_area)

        # Get budget status
        config = manager.load_config()
        budget_tracker = create_budget_tracker_from_config(config)
        budget_status = budget_tracker.calculate_budget(area_files)

        # Convert files with provenance
        files = [
            FocusedFile(
                path=str(file_path),
                reason="area_member",  # TODO: Get actual provenance
                lines=self._count_lines(file_path),
                size_bytes=file_path.stat().st_size if file_path.exists() else 0
            )
            for file_path in area_files
        ]

        return FocusBundle(
            area_id=current_area.id,
            area_name=current_area.name,
            files=files,
            budget=BudgetStatusDto(
                files_used=budget_status.files_used,
                files_max=budget_status.files_max,
                lines_used=budget_status.lines_used,
                lines_max=budget_status.lines_max,
                health=budget_tracker.get_budget_health(budget_status),
                percentage=max(budget_status.percentage_files, budget_status.percentage_lines),
                policy_mode="advisory"  # TODO: Get from config
            ),
            session_id=None  # TODO: Get from session
        )

    def get_budget_status(self, token: Optional[str] = None) -> BudgetStatusDto:
        """
        Get current budget status.

        Args:
            token: Optional authorization token

        Returns:
            BudgetStatusDto

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.READ_CONFIG)

        manager = self._get_manager()
        current_focus_id = manager.get_current_focus()

        if not current_focus_id:
            return BudgetStatusDto(
                files_used=0,
                files_max=15,
                lines_used=0,
                lines_max=3000,
                health="healthy",
                percentage=0.0,
                policy_mode="advisory"
            )

        current_area = manager.get_area(current_focus_id)
        if not current_area:
            return BudgetStatusDto(
                files_used=0,
                files_max=15,
                lines_used=0,
                lines_max=3000,
                health="healthy",
                percentage=0.0,
                policy_mode="advisory"
            )

        area_files = manager.get_files_in_area(current_area)
        config = manager.load_config()
        budget_tracker = create_budget_tracker_from_config(config)
        budget_status = budget_tracker.calculate_budget(area_files)

        return BudgetStatusDto(
            files_used=budget_status.files_used,
            files_max=budget_status.files_max,
            lines_used=budget_status.lines_used,
            lines_max=budget_status.lines_max,
            health=budget_tracker.get_budget_health(budget_status),
            percentage=max(budget_status.percentage_files, budget_status.percentage_lines),
            policy_mode="advisory"  # TODO: Get from config
        )

    def get_contracts(self, token: Optional[str] = None) -> List[ContractSummary]:
        """
        List continuation contracts.

        Args:
            token: Optional authorization token

        Returns:
            List of ContractSummary objects

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.CONTINUATION)

        manager = self._get_manager()
        contracts = manager.list_contracts()

        return [
            ContractSummary(
                id=contract.id,
                state=contract.state,
                area_id=contract.area_id,
                description=contract.description or "",
                created_at=contract.created_at,
                updated_at=contract.updated_at
            )
            for contract in contracts
        ]

    def continue_work(self, token: Optional[str] = None) -> FocusBundle:
        """
        Resume the active continuation contract.

        Args:
            token: Optional authorization token

        Returns:
            FocusBundle with resumed focus

        Raises:
            ApiRefusal: If not authorized or no active contract
        """
        self._check_permission(token, Permission.CONTINUATION)

        manager = self._get_manager()

        try:
            manager.continue_work()
        except Exception as e:
            raise ApiRefusal(
                code="continuation_error",
                message=str(e),
                details="Failed to resume continuation contract"
            )

        return self.get_focus(token)

    def pause_work(self, token: Optional[str] = None) -> ContractSummary:
        """
        Pause current work and save continuation contract.

        Args:
            token: Optional authorization token

        Returns:
            ContractSummary for the paused contract

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.CONTINUATION)

        manager = self._get_manager()

        try:
            contract = manager.pause_work()
        except Exception as e:
            raise ApiRefusal(
                code="continuation_error",
                message=str(e),
                details="Failed to pause work"
            )

        return ContractSummary(
            id=contract.id,
            state=contract.state,
            area_id=contract.area_id,
            description=contract.description or "",
            created_at=contract.created_at,
            updated_at=contract.updated_at
        )

    def get_insights(self, token: Optional[str] = None) -> List[InsightDto]:
        """
        Get intelligent insights and recommendations.

        Args:
            token: Optional authorization token

        Returns:
            List of InsightDto objects

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.INSIGHTS)

        manager = self._get_manager()

        try:
            insights = manager.get_insights()
        except Exception as e:
            # If insights not available, return empty list
            return []

        return [
            InsightDto(
                level=insight.get("level", "info"),
                title=insight.get("title", ""),
                description=insight.get("description", ""),
                impact=insight.get("impact", ""),
                confidence=insight.get("confidence", 0.0),
                related_areas=insight.get("related_areas", [])
            )
            for insight in insights
        ]

    def get_provenance(
        self,
        file_path: Path,
        token: Optional[str] = None
    ) -> List[ProvenanceRecordDto]:
        """
        Get provenance records for a file.

        Args:
            file_path: Path to file
            token: Optional authorization token

        Returns:
            List of ProvenanceRecordDto objects

        Raises:
            ApiRefusal: If not authorized
        """
        self._check_permission(token, Permission.PROVENANCE)

        manager = self._get_manager()

        try:
            records = manager.get_provenance(file_path)
        except Exception:
            # If provenance not available, return empty
            return []

        return [
            ProvenanceRecordDto(
                path=str(record.get("path", file_path)),
                area_id=record.get("area_id", ""),
                reason=record.get("reason", ""),
                source=record.get("source", ""),
                score=record.get("score")
            )
            for record in records
        ]

    # Helper methods

    def _count_lines(self, file_path: Path) -> int:
        """Count lines in a file."""
        try:
            if not file_path.exists():
                return 0
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for _ in f)
        except Exception:
            return 0


# ============================================================================
# Convenience Functions (for backward compatibility)
# ============================================================================


def list_areas(
    workspace: Path,
    token: Optional[str] = None
) -> List[AreaDto]:
    """Convenience wrapper for ContextDiggerApi.list_areas()."""
    api = ContextDiggerApi(workspace)
    return api.list_areas(token)


def dig_area(
    workspace: Path,
    area_id: str,
    token: Optional[str] = None
) -> FocusBundle:
    """Convenience wrapper for ContextDiggerApi.dig_area()."""
    api = ContextDiggerApi(workspace)
    return api.dig_area(area_id, token)


def get_focus(
    workspace: Path,
    token: Optional[str] = None
) -> FocusBundle:
    """Convenience wrapper for ContextDiggerApi.get_focus()."""
    api = ContextDiggerApi(workspace)
    return api.get_focus(token)


def get_budget_status(
    workspace: Path,
    token: Optional[str] = None
) -> BudgetStatusDto:
    """Convenience wrapper for ContextDiggerApi.get_budget_status()."""
    api = ContextDiggerApi(workspace)
    return api.get_budget_status(token)


def get_contracts(
    workspace: Path,
    token: Optional[str] = None
) -> List[ContractSummary]:
    """Convenience wrapper for ContextDiggerApi.get_contracts()."""
    api = ContextDiggerApi(workspace)
    return api.get_contracts(token)


def continue_work(
    workspace: Path,
    token: Optional[str] = None
) -> FocusBundle:
    """Convenience wrapper for ContextDiggerApi.continue_work()."""
    api = ContextDiggerApi(workspace)
    return api.continue_work(token)


def pause_work(
    workspace: Path,
    token: Optional[str] = None
) -> ContractSummary:
    """Convenience wrapper for ContextDiggerApi.pause_work()."""
    api = ContextDiggerApi(workspace)
    return api.pause_work(token)


def get_insights(
    workspace: Path,
    token: Optional[str] = None
) -> List[InsightDto]:
    """Convenience wrapper for ContextDiggerApi.get_insights()."""
    api = ContextDiggerApi(workspace)
    return api.get_insights(token)


def get_provenance(
    workspace: Path,
    file_path: Path,
    token: Optional[str] = None
) -> List[ProvenanceRecordDto]:
    """Convenience wrapper for ContextDiggerApi.get_provenance()."""
    api = ContextDiggerApi(workspace)
    return api.get_provenance(file_path, token)
