"""
Unit tests for continuation.py - Continuation contracts for preserving developer intent.

Tests cover:
- ContractState and WorkflowStatus enums
- ContractContext dataclass
- ContinuationContract dataclass
- ContractManager functionality
- Contract persistence and retrieval
"""

import pytest
import tempfile
import json
from pathlib import Path
from datetime import datetime
from contextdigger.continuation import (
    ContractState,
    WorkflowStatus,
    ContractContext,
    ContinuationContract,
    ContractManager,
    # Legacy constants
    STATUS_INVESTIGATING,
    STATUS_IMPLEMENTING,
    STATUS_TESTING,
    STATUS_BLOCKED,
    STATUS_COMPLETED,
)


# ============================================================================
# Test Enums
# ============================================================================


class TestContractState:
    """Test ContractState enum."""

    def test_contract_state_values(self):
        """Test ContractState enum values."""
        assert ContractState.ACTIVE.value == "active"
        assert ContractState.PAUSED.value == "paused"
        assert ContractState.COMPLETED.value == "completed"
        assert ContractState.EXPIRED.value == "expired"
        assert ContractState.CANCELLED.value == "cancelled"


class TestWorkflowStatus:
    """Test WorkflowStatus enum."""

    def test_workflow_status_values(self):
        """Test WorkflowStatus enum values."""
        assert WorkflowStatus.INVESTIGATING.value == "investigating"
        assert WorkflowStatus.IMPLEMENTING.value == "implementing"
        assert WorkflowStatus.TESTING.value == "testing"
        assert WorkflowStatus.BLOCKED.value == "blocked"
        assert WorkflowStatus.COMPLETED.value == "completed"

    def test_legacy_constants(self):
        """Test backward-compatible legacy constants."""
        assert STATUS_INVESTIGATING == "investigating"
        assert STATUS_IMPLEMENTING == "implementing"
        assert STATUS_TESTING == "testing"
        assert STATUS_BLOCKED == "blocked"
        assert STATUS_COMPLETED == "completed"


# ============================================================================
# Test ContractContext
# ============================================================================


class TestContractContext:
    """Test ContractContext dataclass."""

    def test_basic_context(self):
        """Test creating basic ContractContext."""
        context = ContractContext(
            open_files=["src/api.py", "src/models.py"],
            bookmarks=["api-endpoint", "model-schema"],
            search_queries=["TODO", "FIXME"],
            last_commands=["dig backend-api", "mark-spot api-endpoint"],
            notes="Working on API refactoring",
            next_actions=["Add tests", "Update docs"]
        )

        assert len(context.open_files) == 2
        assert len(context.bookmarks) == 2
        assert len(context.search_queries) == 2
        assert len(context.last_commands) == 2
        assert context.notes == "Working on API refactoring"
        assert len(context.next_actions) == 2

    def test_empty_context(self):
        """Test creating empty ContractContext."""
        context = ContractContext(
            open_files=[],
            bookmarks=[],
            search_queries=[],
            last_commands=[],
            notes="",
            next_actions=[]
        )

        assert context.open_files == []
        assert context.notes == ""

    def test_to_dict(self):
        """Test converting ContractContext to dict."""
        context = ContractContext(
            open_files=["file1.py"],
            bookmarks=["bookmark1"],
            search_queries=["query1"],
            last_commands=["cmd1"],
            notes="Test notes",
            next_actions=["action1"]
        )

        data = context.to_dict()

        assert data["open_files"] == ["file1.py"]
        assert data["bookmarks"] == ["bookmark1"]
        assert data["notes"] == "Test notes"

    def test_from_dict(self):
        """Test creating ContractContext from dict."""
        data = {
            "open_files": ["src/test.py"],
            "bookmarks": ["test-spot"],
            "search_queries": ["test"],
            "last_commands": ["dig tests"],
            "notes": "Testing",
            "next_actions": ["Run tests"]
        }

        context = ContractContext.from_dict(data)

        assert context.open_files == ["src/test.py"]
        assert context.bookmarks == ["test-spot"]
        assert context.notes == "Testing"

    def test_from_dict_with_defaults(self):
        """Test creating ContractContext from dict with missing fields."""
        data = {}

        context = ContractContext.from_dict(data)

        assert context.open_files == []
        assert context.bookmarks == []
        assert context.notes == ""

    def test_roundtrip_serialization(self):
        """Test ContractContext roundtrip serialization."""
        original = ContractContext(
            open_files=["a.py", "b.py"],
            bookmarks=["spot1", "spot2"],
            search_queries=["TODO"],
            last_commands=["dig area1"],
            notes="Notes here",
            next_actions=["Fix bug"]
        )

        data = original.to_dict()
        restored = ContractContext.from_dict(data)

        assert restored.open_files == original.open_files
        assert restored.bookmarks == original.bookmarks
        assert restored.notes == original.notes


# ============================================================================
# Test ContinuationContract
# ============================================================================


class TestContinuationContract:
    """Test ContinuationContract dataclass."""

    def test_basic_contract(self):
        """Test creating basic ContinuationContract."""
        context = ContractContext(
            open_files=[],
            bookmarks=[],
            search_queries=[],
            last_commands=[],
            notes="",
            next_actions=[]
        )

        contract = ContinuationContract(
            id="contract-001",
            area_id="backend-api",
            area_name="Backend API",
            intent="Fix authentication bug",
            problem="Users can't log in",
            goal="Users can log in successfully",
            state=ContractState.ACTIVE.value,
            status=WorkflowStatus.INVESTIGATING.value,
            progress=0.0,
            context=context,
            created_at="2025-01-15T10:00:00Z",
            updated_at="2025-01-15T10:00:00Z",
            completed_at=None,
            tags=["bug", "auth"]
        )

        assert contract.id == "contract-001"
        assert contract.area_id == "backend-api"
        assert contract.intent == "Fix authentication bug"
        assert contract.state == ContractState.ACTIVE.value
        assert contract.status == WorkflowStatus.INVESTIGATING.value
        assert contract.progress == 0.0
        assert len(contract.tags) == 2

    def test_contract_with_description(self):
        """Test ContinuationContract with optional description."""
        context = ContractContext(
            open_files=[],
            bookmarks=[],
            search_queries=[],
            last_commands=[],
            notes="",
            next_actions=[]
        )

        contract = ContinuationContract(
            id="contract-002",
            area_id="frontend",
            area_name="Frontend",
            intent="Add dark mode",
            problem="No dark mode support",
            goal="Dark mode toggle works",
            state=ContractState.ACTIVE.value,
            status=WorkflowStatus.IMPLEMENTING.value,
            progress=0.5,
            context=context,
            created_at="2025-01-15T11:00:00Z",
            updated_at="2025-01-15T12:00:00Z",
            completed_at=None,
            tags=[],
            description="Adding dark mode feature to UI"
        )

        assert contract.description == "Adding dark mode feature to UI"

    def test_to_dict(self):
        """Test converting ContinuationContract to dict."""
        context = ContractContext(
            open_files=["api.py"],
            bookmarks=[],
            search_queries=[],
            last_commands=[],
            notes="Working",
            next_actions=[]
        )

        contract = ContinuationContract(
            id="contract-003",
            area_id="backend",
            area_name="Backend",
            intent="Optimize queries",
            problem="Slow performance",
            goal="Faster queries",
            state=ContractState.ACTIVE.value,
            status=WorkflowStatus.TESTING.value,
            progress=0.8,
            context=context,
            created_at="2025-01-15T13:00:00Z",
            updated_at="2025-01-15T14:00:00Z",
            completed_at=None,
            tags=["performance"]
        )

        data = contract.to_dict()

        assert data["id"] == "contract-003"
        assert data["intent"] == "Optimize queries"
        assert data["state"] == "active"
        assert data["status"] == "testing"
        assert data["progress"] == 0.8
        assert "context" in data
        assert data["context"]["notes"] == "Working"

    def test_from_dict(self):
        """Test creating ContinuationContract from dict."""
        data = {
            "id": "contract-004",
            "area_id": "tests",
            "area_name": "Tests",
            "intent": "Add unit tests",
            "problem": "No test coverage",
            "goal": "80% coverage",
            "state": "active",
            "status": "implementing",
            "progress": 0.3,
            "context": {
                "open_files": ["test_api.py"],
                "bookmarks": [],
                "search_queries": [],
                "last_commands": [],
                "notes": "Writing tests",
                "next_actions": []
            },
            "created_at": "2025-01-15T15:00:00Z",
            "updated_at": "2025-01-15T16:00:00Z",
            "completed_at": None,
            "tags": ["testing"],
            "description": "Adding comprehensive test suite"
        }

        contract = ContinuationContract.from_dict(data)

        assert contract.id == "contract-004"
        assert contract.intent == "Add unit tests"
        assert contract.state == "active"
        assert contract.status == "implementing"
        assert contract.progress == 0.3
        assert contract.context.notes == "Writing tests"
        assert contract.description == "Adding comprehensive test suite"

    def test_from_dict_backward_compatibility(self):
        """Test from_dict with missing state field (backward compatibility)."""
        data = {
            "id": "contract-old",
            "area_id": "backend",
            "area_name": "Backend",
            "intent": "Fix bug",
            "problem": "Bug exists",
            "goal": "Bug fixed",
            # state field missing - should default to ACTIVE
            "status": "investigating",
            "progress": 0.0,
            "context": {
                "open_files": [],
                "bookmarks": [],
                "search_queries": [],
                "last_commands": [],
                "notes": "",
                "next_actions": []
            },
            "created_at": "2025-01-15T17:00:00Z",
            "updated_at": "2025-01-15T17:00:00Z",
            "completed_at": None,
            "tags": []
        }

        contract = ContinuationContract.from_dict(data)

        assert contract.state == ContractState.ACTIVE.value

    def test_roundtrip_serialization(self):
        """Test ContinuationContract roundtrip serialization."""
        context = ContractContext(
            open_files=["main.py"],
            bookmarks=["spot1"],
            search_queries=["TODO"],
            last_commands=["dig area"],
            notes="Progress notes",
            next_actions=["Complete feature"]
        )

        original = ContinuationContract(
            id="contract-round",
            area_id="feature",
            area_name="Feature Area",
            intent="Build feature",
            problem="Feature missing",
            goal="Feature complete",
            state=ContractState.PAUSED.value,
            status=WorkflowStatus.BLOCKED.value,
            progress=0.6,
            context=context,
            created_at="2025-01-15T18:00:00Z",
            updated_at="2025-01-15T19:00:00Z",
            completed_at=None,
            tags=["feature", "blocked"],
            description="New feature implementation"
        )

        data = original.to_dict()
        restored = ContinuationContract.from_dict(data)

        assert restored.id == original.id
        assert restored.intent == original.intent
        assert restored.state == original.state
        assert restored.status == original.status
        assert restored.progress == original.progress
        assert restored.context.notes == original.context.notes


# ============================================================================
# Test ContractManager
# ============================================================================


class TestContractManager:
    """Test ContractManager functionality."""

    @pytest.fixture
    def temp_focus_root(self):
        """Create temporary focus root directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_init(self, temp_focus_root):
        """Test ContractManager initialization."""
        manager = ContractManager(temp_focus_root)

        assert manager.focus_root == temp_focus_root
        assert manager.contracts_dir == temp_focus_root / ".cdg" / "contracts"
        assert manager._active_contract is None

    def test_create_contract(self, temp_focus_root):
        """Test creating a new contract."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="backend-api",
            area_name="Backend API",
            intent="Add new endpoint",
            problem="Missing /users endpoint",
            goal="/users endpoint working",
            tags=["api", "feature"]
        )

        assert contract.id is not None
        assert contract.area_id == "backend-api"
        assert contract.intent == "Add new endpoint"
        assert contract.status == "investigating"
        assert contract.progress == 0.0
        assert len(contract.tags) == 2

    def test_create_contract_with_context(self, temp_focus_root):
        """Test creating contract with custom context."""
        manager = ContractManager(temp_focus_root)

        custom_context = ContractContext(
            open_files=["api.py"],
            bookmarks=["endpoint"],
            search_queries=[],
            last_commands=[],
            notes="Starting point",
            next_actions=["Define schema"]
        )

        contract = manager.create_contract(
            area_id="api",
            area_name="API",
            intent="Build API",
            problem="No API",
            goal="API exists",
            context=custom_context
        )

        assert contract.context.notes == "Starting point"
        assert len(contract.context.open_files) == 1

    def test_save_and_get_active_contract(self, temp_focus_root):
        """Test saving and retrieving active contract."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="frontend",
            area_name="Frontend",
            intent="Fix UI bug",
            problem="Button doesn't work",
            goal="Button works",
            tags=["bug"]
        )

        manager.save_active_contract(contract)

        # Check in-memory cache
        assert manager._active_contract == contract

        # Check file was created
        active_file = temp_focus_root / ".cdg" / "contracts" / "active.json"
        assert active_file.exists()

        # Retrieve contract
        retrieved = manager.get_active_contract()
        assert retrieved.id == contract.id
        assert retrieved.intent == contract.intent

    def test_get_active_contract_from_disk(self, temp_focus_root):
        """Test loading active contract from disk."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="tests",
            area_name="Tests",
            intent="Add tests",
            problem="No tests",
            goal="Tests exist"
        )

        manager.save_active_contract(contract)

        # Clear cache
        manager._active_contract = None

        # Should load from disk
        retrieved = manager.get_active_contract()
        assert retrieved is not None
        assert retrieved.id == contract.id

    def test_get_active_contract_none(self, temp_focus_root):
        """Test getting active contract when none exists."""
        manager = ContractManager(temp_focus_root)

        active = manager.get_active_contract()

        assert active is None

    def test_update_contract_status(self, temp_focus_root):
        """Test updating contract status."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="feature",
            area_name="Feature",
            intent="Build feature",
            problem="Missing",
            goal="Complete"
        )

        manager.save_active_contract(contract)

        # Update status
        manager.update_contract(
            contract.id,
            status="implementing",
            progress=0.5
        )

        updated = manager.get_active_contract()
        assert updated.status == "implementing"
        assert updated.progress == 0.5

    def test_update_contract_context(self, temp_focus_root):
        """Test updating contract context."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="docs",
            area_name="Documentation",
            intent="Write docs",
            problem="No docs",
            goal="Docs complete"
        )

        manager.save_active_contract(contract)

        new_context = ContractContext(
            open_files=["README.md"],
            bookmarks=[],
            search_queries=[],
            last_commands=[],
            notes="Updated context",
            next_actions=[]
        )

        manager.update_contract(contract.id, context=new_context)

        updated = manager.get_active_contract()
        assert updated.context.notes == "Updated context"

    def test_update_contract_notes(self, temp_focus_root):
        """Test updating contract notes."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="refactor",
            area_name="Refactoring",
            intent="Refactor code",
            problem="Messy code",
            goal="Clean code"
        )

        manager.save_active_contract(contract)

        manager.update_contract(contract.id, notes="Added new notes")

        updated = manager.get_active_contract()
        assert updated.context.notes == "Added new notes"

    def test_complete_contract(self, temp_focus_root):
        """Test completing a contract."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="bugfix",
            area_name="Bug Fix",
            intent="Fix crash",
            problem="App crashes",
            goal="No crashes"
        )

        manager.save_active_contract(contract)

        manager.complete_contract(contract.id)

        # Active contract should be cleared
        active = manager.get_active_contract()
        assert active is None

        # Contract should be in history
        history_file = temp_focus_root / ".cdg" / "contracts" / "history" / f"{contract.id}.json"
        assert history_file.exists()

        # Check contract was marked complete
        with open(history_file) as f:
            data = json.load(f)

        assert data["status"] == "completed"
        assert data["progress"] == 1.0
        assert data["completed_at"] is not None

    def test_pause_contract(self, temp_focus_root):
        """Test pausing a contract."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="feature",
            area_name="Feature",
            intent="Build feature",
            problem="Missing",
            goal="Complete"
        )

        manager.save_active_contract(contract)

        # Update to implementing state
        manager.update_contract(contract.id, status="implementing", progress=0.4)

        manager.pause_contract()

        # Active should be cleared
        active = manager.get_active_contract()
        assert active is None

        # Contract should be in history with current status
        history_file = temp_focus_root / ".cdg" / "contracts" / "history" / f"{contract.id}.json"
        assert history_file.exists()

        with open(history_file) as f:
            data = json.load(f)

        assert data["status"] == "implementing"
        assert data["progress"] == 0.4

    def test_get_contract_history(self, temp_focus_root):
        """Test getting contract history."""
        manager = ContractManager(temp_focus_root)

        # Create and complete multiple contracts
        for i in range(3):
            contract = manager.create_contract(
                area_id=f"area-{i}",
                area_name=f"Area {i}",
                intent=f"Intent {i}",
                problem=f"Problem {i}",
                goal=f"Goal {i}"
            )

            manager.save_active_contract(contract)
            manager.complete_contract(contract.id)

        history = manager.get_contract_history()

        assert len(history) == 3

    def test_get_contract_history_with_limit(self, temp_focus_root):
        """Test getting limited contract history."""
        manager = ContractManager(temp_focus_root)

        # Create 5 contracts
        for i in range(5):
            contract = manager.create_contract(
                area_id=f"area-{i}",
                area_name=f"Area {i}",
                intent=f"Intent {i}",
                problem=f"Problem {i}",
                goal=f"Goal {i}"
            )

            manager.save_active_contract(contract)
            manager.complete_contract(contract.id)

        history = manager.get_contract_history(limit=2)

        assert len(history) == 2

    def test_get_contract_by_id(self, temp_focus_root):
        """Test getting contract by ID."""
        manager = ContractManager(temp_focus_root)

        contract = manager.create_contract(
            area_id="lookup",
            area_name="Lookup Test",
            intent="Test lookup",
            problem="Need lookup",
            goal="Lookup works"
        )

        manager.save_active_contract(contract)
        manager.complete_contract(contract.id)

        # Retrieve from history
        retrieved = manager.get_contract(contract.id)

        assert retrieved is not None
        assert retrieved.id == contract.id
        assert retrieved.intent == "Test lookup"

    def test_get_contract_not_found(self, temp_focus_root):
        """Test getting non-existent contract."""
        manager = ContractManager(temp_focus_root)

        contract = manager.get_contract("nonexistent-id")

        assert contract is None

    def test_capture_current_context(self, temp_focus_root):
        """Test capturing current context."""
        manager = ContractManager(temp_focus_root)

        context = manager.capture_current_context(
            open_files=["file1.py", "file2.py"],
            bookmarks=["spot1"],
            search_queries=["TODO"],
            last_commands=["dig area"],
            notes="Current work",
            next_actions=["Finish task"]
        )

        assert len(context.open_files) == 2
        assert context.notes == "Current work"
        assert len(context.next_actions) == 1


# ============================================================================
# Integration Tests
# ============================================================================


class TestContractIntegration:
    """Integration tests for contract workflow."""

    @pytest.fixture
    def temp_focus_root(self):
        """Create temporary focus root directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_full_contract_lifecycle(self, temp_focus_root):
        """Test complete contract lifecycle."""
        manager = ContractManager(temp_focus_root)

        # 1. Create contract
        contract = manager.create_contract(
            area_id="feature-auth",
            area_name="Authentication Feature",
            intent="Implement OAuth",
            problem="No OAuth support",
            goal="OAuth login works",
            tags=["auth", "feature"]
        )

        # 2. Save as active
        manager.save_active_contract(contract)

        # 3. Update through workflow stages
        manager.update_contract(contract.id, status="investigating", progress=0.2)
        manager.update_contract(contract.id, status="implementing", progress=0.6)
        manager.update_contract(contract.id, status="testing", progress=0.9)

        # 4. Complete
        manager.complete_contract(contract.id)

        # 5. Verify no active contract
        assert manager.get_active_contract() is None

        # 6. Verify in history
        history = manager.get_contract_history()
        assert len(history) == 1
        assert history[0].status == "completed"
        assert history[0].progress == 1.0

    def test_pause_and_resume_workflow(self, temp_focus_root):
        """Test pausing and resuming contracts."""
        manager = ContractManager(temp_focus_root)

        # Create and start contract
        contract = manager.create_contract(
            area_id="refactor",
            area_name="Code Refactoring",
            intent="Refactor API",
            problem="API is messy",
            goal="Clean API"
        )

        manager.save_active_contract(contract)
        manager.update_contract(contract.id, status="implementing", progress=0.5)

        # Pause
        manager.pause_contract()

        assert manager.get_active_contract() is None

        # Resume by loading from history and making active again
        paused_contract = manager.get_contract(contract.id)
        assert paused_contract.progress == 0.5
        assert paused_contract.status == "implementing"
