"""
Unit tests for budget.py - Budget governance and policy enforcement.

Tests cover:
- BudgetConfig and PolicyConfig dataclasses
- BudgetAlert and BudgetStatus
- GovernancePolicy
- BudgetTracker core functionality
- Budget enforcement and violation handling
"""

import pytest
import tempfile
from pathlib import Path
from datetime import datetime

from contextdigger.budget import (
    # Enums
    AlertLevel,
    EnforcementMode,
    ViolationAction,
    # Configuration
    BudgetConfig,
    PolicyConfig,
    # Budget Status
    BudgetAlert,
    BudgetStatus,
    # Governance
    GovernancePolicy,
    ViolationResult,
    PolicyManager,
    # Budget Tracker
    BudgetTracker,
    create_budget_tracker_from_config,
)


# ============================================================================
# Test BudgetConfig
# ============================================================================


class TestBudgetConfig:
    """Test BudgetConfig dataclass."""

    def test_defaults(self):
        """Test default configuration values."""
        config = BudgetConfig()

        assert config.max_files == 15
        assert config.max_lines == 3000
        assert config.alert_thresholds == [0.5, 0.8, 0.9]
        assert config.allow_override is False
        assert "f/15" in config.description

    def test_context_aperture_property(self):
        """Test context_aperture property returns correct notation."""
        config = BudgetConfig(max_files=15)
        assert config.context_aperture == "f/15"

        config = BudgetConfig(max_files=30)
        assert config.context_aperture == "f/30"

    def test_to_dict(self):
        """Test serialization to dictionary."""
        config = BudgetConfig(
            max_files=20,
            max_lines=5000,
            alert_thresholds=[0.6, 0.85],
            allow_override=True,
            description="Custom config"
        )

        data = config.to_dict()

        assert data["max_files"] == 20
        assert data["max_lines"] == 5000
        assert data["alert_thresholds"] == [0.6, 0.85]
        assert data["allow_override"] is True
        assert data["description"] == "Custom config"

    def test_from_dict(self):
        """Test deserialization from dictionary."""
        data = {
            "max_files": 25,
            "max_lines": 4000,
            "alert_thresholds": [0.7],
            "allow_override": True,
            "description": "Test config"
        }

        config = BudgetConfig.from_dict(data)

        assert config.max_files == 25
        assert config.max_lines == 4000
        assert config.alert_thresholds == [0.7]
        assert config.allow_override is True
        assert config.description == "Test config"

    def test_from_dict_with_defaults(self):
        """Test deserialization with missing fields uses defaults."""
        data = {}
        config = BudgetConfig.from_dict(data)

        assert config.max_files == 15
        assert config.max_lines == 3000
        assert config.alert_thresholds == [0.5, 0.8, 0.9]
        assert config.allow_override is False

    def test_roundtrip_serialization(self):
        """Test to_dict() and from_dict() roundtrip."""
        original = BudgetConfig(max_files=12, max_lines=2500)
        data = original.to_dict()
        restored = BudgetConfig.from_dict(data)

        assert restored.max_files == original.max_files
        assert restored.max_lines == original.max_lines
        assert restored.alert_thresholds == original.alert_thresholds


# ============================================================================
# Test PolicyConfig
# ============================================================================


class TestPolicyConfig:
    """Test PolicyConfig dataclass."""

    def test_defaults(self):
        """Test default policy configuration."""
        config = PolicyConfig()

        assert config.enforcement_mode == EnforcementMode.STRICT
        assert ViolationAction.BLOCK in config.violation_actions
        assert ViolationAction.LOG in config.violation_actions
        assert config.enabled is True
        assert config.policy_name == "default"

    def test_is_strict_property(self):
        """Test is_strict property."""
        strict = PolicyConfig(enforcement_mode=EnforcementMode.STRICT)
        assert strict.is_strict is True

        warning = PolicyConfig(enforcement_mode=EnforcementMode.WARNING)
        assert warning.is_strict is False

        advisory = PolicyConfig(enforcement_mode=EnforcementMode.ADVISORY)
        assert advisory.is_strict is False

    def test_will_block_property(self):
        """Test will_block property."""
        blocking = PolicyConfig(violation_actions=[ViolationAction.BLOCK])
        assert blocking.will_block is True

        non_blocking = PolicyConfig(violation_actions=[ViolationAction.LOG])
        assert non_blocking.will_block is False

    def test_to_dict(self):
        """Test serialization to dictionary."""
        config = PolicyConfig(
            enforcement_mode=EnforcementMode.WARNING,
            violation_actions=[ViolationAction.NOTIFY, ViolationAction.SUGGEST],
            enabled=False,
            policy_name="custom",
            description="Test policy"
        )

        data = config.to_dict()

        assert data["enforcement_mode"] == "warning"
        assert "notify" in data["violation_actions"]
        assert "suggest" in data["violation_actions"]
        assert data["enabled"] is False
        assert data["policy_name"] == "custom"

    def test_from_dict(self):
        """Test deserialization from dictionary."""
        data = {
            "enforcement_mode": "advisory",
            "violation_actions": ["log", "notify"],
            "enabled": True,
            "policy_name": "test",
            "description": "Test"
        }

        config = PolicyConfig.from_dict(data)

        assert config.enforcement_mode == EnforcementMode.ADVISORY
        assert ViolationAction.LOG in config.violation_actions
        assert ViolationAction.NOTIFY in config.violation_actions
        assert config.enabled is True

    def test_roundtrip_serialization(self):
        """Test to_dict() and from_dict() roundtrip."""
        original = PolicyConfig(
            enforcement_mode=EnforcementMode.WARNING,
            policy_name="test"
        )
        data = original.to_dict()
        restored = PolicyConfig.from_dict(data)

        assert restored.enforcement_mode == original.enforcement_mode
        assert restored.policy_name == original.policy_name


# ============================================================================
# Test BudgetAlert
# ============================================================================


class TestBudgetAlert:
    """Test BudgetAlert functionality."""

    def test_percentage_property(self):
        """Test percentage calculation."""
        alert = BudgetAlert(
            level=AlertLevel.WARNING,
            metric="files",
            current_value=12,
            max_value=15,
            threshold=0.8,
            message="Warning"
        )

        assert alert.percentage == 0.8

    def test_percentage_with_zero_max(self):
        """Test percentage when max_value is zero."""
        alert = BudgetAlert(
            level=AlertLevel.INFO,
            metric="files",
            current_value=5,
            max_value=0,
            threshold=0.5,
            message="Info"
        )

        assert alert.percentage == 0.0

    def test_icon_property(self):
        """Test icon selection for each alert level."""
        levels_and_icons = [
            (AlertLevel.INFO, "ℹ️"),
            (AlertLevel.WARNING, "⚠️"),
            (AlertLevel.CRITICAL, "🔴"),
            (AlertLevel.EXCEEDED, "❌"),
        ]

        for level, expected_icon in levels_and_icons:
            alert = BudgetAlert(
                level=level,
                metric="files",
                current_value=10,
                max_value=15,
                threshold=0.5,
                message="Test"
            )
            assert alert.icon == expected_icon

    def test_format_message(self):
        """Test formatted alert message."""
        alert = BudgetAlert(
            level=AlertLevel.WARNING,
            metric="files",
            current_value=12,
            max_value=15,
            threshold=0.8,
            message="Approaching limit"
        )

        formatted = alert.format_message()

        assert "⚠️" in formatted
        assert "Approaching limit" in formatted
        assert "12" in formatted
        assert "15" in formatted
        assert "80%" in formatted


# ============================================================================
# Test BudgetStatus
# ============================================================================


class TestBudgetStatus:
    """Test BudgetStatus calculations."""

    def test_percentage_files(self):
        """Test file percentage calculation."""
        status = BudgetStatus(
            files_used=10,
            files_max=15,
            lines_used=2000,
            lines_max=3000
        )

        assert status.percentage_files == pytest.approx(0.6667, rel=0.01)

    def test_percentage_lines(self):
        """Test line percentage calculation."""
        status = BudgetStatus(
            files_used=10,
            files_max=15,
            lines_used=2400,
            lines_max=3000
        )

        assert status.percentage_lines == 0.8

    def test_percentage_with_zero_max(self):
        """Test percentage when max is zero."""
        status = BudgetStatus(
            files_used=5,
            files_max=0,
            lines_used=1000,
            lines_max=0
        )

        assert status.percentage_files == 0.0
        assert status.percentage_lines == 0.0

    def test_exceeds_files(self):
        """Test exceeds when files over budget."""
        status = BudgetStatus(
            files_used=20,
            files_max=15,
            lines_used=2000,
            lines_max=3000
        )

        assert status.exceeds is True
        assert status.within_budget is False

    def test_exceeds_lines(self):
        """Test exceeds when lines over budget."""
        status = BudgetStatus(
            files_used=10,
            files_max=15,
            lines_used=3500,
            lines_max=3000
        )

        assert status.exceeds is True
        assert status.within_budget is False

    def test_within_budget(self):
        """Test within_budget when both metrics are under."""
        status = BudgetStatus(
            files_used=10,
            files_max=15,
            lines_used=2000,
            lines_max=3000
        )

        assert status.exceeds is False
        assert status.within_budget is True

    def test_at_warning_threshold(self):
        """Test at_warning_threshold property."""
        # Below threshold
        below = BudgetStatus(files_used=10, files_max=15, lines_used=2000, lines_max=3000)
        assert below.at_warning_threshold is False

        # At threshold (80%)
        at_threshold = BudgetStatus(files_used=12, files_max=15, lines_used=2000, lines_max=3000)
        assert at_threshold.at_warning_threshold is True

        # Over threshold
        over = BudgetStatus(files_used=14, files_max=15, lines_used=2000, lines_max=3000)
        assert over.at_warning_threshold is True


# ============================================================================
# Test GovernancePolicy
# ============================================================================


class TestGovernancePolicy:
    """Test GovernancePolicy functionality."""

    def test_is_strict_property(self):
        """Test is_strict property."""
        strict = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )
        assert strict.is_strict is True

        warning = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.WARNING,
            max_files=15,
            max_lines=3000
        )
        assert warning.is_strict is False

    def test_allows_blocking_property(self):
        """Test allows_blocking property."""
        blocking = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.BLOCK]
        )
        assert blocking.allows_blocking is True

        non_blocking = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.ADVISORY,
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.LOG]
        )
        assert non_blocking.allows_blocking is False

    def test_to_dict(self):
        """Test serialization."""
        policy = GovernancePolicy(
            policy_id="test-123",
            name="Test Policy",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=20,
            max_lines=4000,
            alert_thresholds=[0.7, 0.85],
            violation_actions=[ViolationAction.BLOCK, ViolationAction.LOG],
            description="Test"
        )

        data = policy.to_dict()

        assert data["policy_id"] == "test-123"
        assert data["name"] == "Test Policy"
        assert data["enforcement_mode"] == "strict"
        assert data["max_files"] == 20
        assert data["max_lines"] == 4000

    def test_from_dict(self):
        """Test deserialization."""
        data = {
            "policy_id": "test-456",
            "name": "Test",
            "enabled": False,
            "enforcement_mode": "warning",
            "max_files": 25,
            "max_lines": 5000,
            "alert_thresholds": [0.6],
            "violation_actions": ["notify"],
            "description": "Test policy"
        }

        policy = GovernancePolicy.from_dict(data)

        assert policy.policy_id == "test-456"
        assert policy.enabled is False
        assert policy.enforcement_mode == EnforcementMode.WARNING


# ============================================================================
# Test BudgetTracker
# ============================================================================


class TestBudgetTracker:
    """Test BudgetTracker core functionality."""

    @pytest.fixture
    def temp_files(self):
        """Create temporary test files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create test files with known line counts
            file1 = tmpdir / "file1.py"
            file1.write_text("line1\nline2\nline3\n")  # 3 lines

            file2 = tmpdir / "file2.py"
            file2.write_text("line1\nline2\nline3\nline4\nline5\n")  # 5 lines

            file3 = tmpdir / "file3.py"
            file3.write_text("line1\nline2\n")  # 2 lines

            yield [file1, file2, file3]

    def test_init_defaults(self):
        """Test initialization with default values."""
        tracker = BudgetTracker()

        assert tracker.max_files == 15
        assert tracker.max_lines == 3000

    def test_init_custom_values(self):
        """Test initialization with custom values."""
        tracker = BudgetTracker(max_files=20, max_lines=5000)

        assert tracker.max_files == 20
        assert tracker.max_lines == 5000

    def test_calculate_budget(self, temp_files):
        """Test calculate_budget with real files."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget(temp_files)

        assert status.files_used == 3
        assert status.files_max == 15
        assert status.lines_used == 10  # 3 + 5 + 2
        assert status.lines_max == 3000

    def test_calculate_budget_empty_list(self):
        """Test calculate_budget with empty file list."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget([])

        assert status.files_used == 0
        assert status.lines_used == 0

    def test_get_budget_health_healthy(self, temp_files):
        """Test get_budget_health returns 'healthy'."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget(temp_files)
        health = tracker.get_budget_health(status)

        assert health == "healthy"

    def test_get_budget_health_warning(self):
        """Test get_budget_health returns 'warning'."""
        tracker = BudgetTracker(max_files=15, max_lines=3000)
        # 80% usage triggers warning
        status = BudgetStatus(files_used=12, files_max=15, lines_used=2000, lines_max=3000)
        health = tracker.get_budget_health(status)

        assert health == "warning"

    def test_get_budget_health_exceeded(self):
        """Test get_budget_health returns 'exceeded'."""
        tracker = BudgetTracker(max_files=15, max_lines=3000)
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)
        health = tracker.get_budget_health(status)

        assert health == "exceeded"

    def test_generate_alerts_no_alerts(self, temp_files):
        """Test generate_alerts with no alerts."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget(temp_files)
        alerts = tracker.generate_alerts(status)

        assert len(alerts) == 0

    def test_generate_alerts_with_warning(self):
        """Test generate_alerts generates warning alert."""
        tracker = BudgetTracker(max_files=15, max_lines=3000)
        # 85% usage
        status = BudgetStatus(files_used=13, files_max=15, lines_used=2550, lines_max=3000)
        alerts = tracker.generate_alerts(status)

        # Should have warning alert
        assert len(alerts) > 0
        assert any(a.level == AlertLevel.WARNING for a in alerts)

    def test_generate_alerts_exceeded(self):
        """Test generate_alerts when budget exceeded."""
        tracker = BudgetTracker(max_files=15, max_lines=3000)
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)
        alerts = tracker.generate_alerts(status)

        # Should have exceeded alert
        assert len(alerts) > 0
        assert any(a.level == AlertLevel.EXCEEDED for a in alerts)

    def test_is_within_budget_true(self, temp_files):
        """Test is_within_budget returns True."""
        tracker = BudgetTracker()
        assert tracker.is_within_budget(temp_files) is True

    def test_is_within_budget_false(self):
        """Test is_within_budget returns False when exceeded."""
        tracker = BudgetTracker(max_files=2, max_lines=100)

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            files = []
            for i in range(5):
                f = tmpdir / f"file{i}.py"
                f.write_text("line\n" * 50)
                files.append(f)

            assert tracker.is_within_budget(files) is False

    def test_format_budget_display(self, temp_files):
        """Test format_budget_display output."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget(temp_files)
        display = tracker.format_budget_display(status)

        assert "files" in display.lower()
        assert "lines" in display.lower()
        assert "3" in display  # 3 files
        assert "10" in display  # 10 lines

    def test_get_budget_breakdown(self, temp_files):
        """Test get_budget_breakdown returns detailed breakdown."""
        tracker = BudgetTracker()
        breakdown = tracker.get_budget_breakdown(temp_files)

        assert "total_files" in breakdown
        assert "total_lines" in breakdown
        assert "files" in breakdown
        assert breakdown["total_files"] == 3
        assert breakdown["total_lines"] == 10
        assert len(breakdown["files"]) == 3

    def test_check_policy_compliance_compliant(self, temp_files):
        """Test check_policy_compliance when compliant."""
        tracker = BudgetTracker()
        status = tracker.calculate_budget(temp_files)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )

        compliant, violations = tracker.check_policy_compliance(status, policy)

        assert compliant is True
        assert len(violations) == 0

    def test_check_policy_compliance_not_compliant(self):
        """Test check_policy_compliance when not compliant."""
        tracker = BudgetTracker(max_files=15, max_lines=3000)
        status = BudgetStatus(files_used=20, files_max=15, lines_used=4000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )

        compliant, violations = tracker.check_policy_compliance(status, policy)

        assert compliant is False
        assert len(violations) > 0

    def test_check_policy_compliance_disabled_policy(self):
        """Test check_policy_compliance with disabled policy."""
        tracker = BudgetTracker()
        status = BudgetStatus(files_used=20, files_max=15, lines_used=4000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=False,  # Disabled
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )

        compliant, violations = tracker.check_policy_compliance(status, policy)

        assert compliant is True  # Disabled policies always pass
        assert len(violations) == 0

    def test_handle_violation(self):
        """Test handle_violation returns ViolationResult."""
        tracker = BudgetTracker()
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.BLOCK]
        )

        result = tracker.handle_violation(status, policy)

        assert isinstance(result, ViolationResult)
        assert result.blocked is True  # Strict mode blocks
        assert result.has_violations is True

    def test_handle_violation_warning_mode(self):
        """Test handle_violation in WARNING mode doesn't block."""
        tracker = BudgetTracker()
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.WARNING,  # Warning mode
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.LOG]
        )

        result = tracker.handle_violation(status, policy)

        assert result.blocked is False  # Warning mode doesn't block
        assert result.has_violations is True

    def test_enforce_governance(self, temp_files):
        """Test enforce_governance method."""
        tracker = BudgetTracker()

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )

        result = tracker.enforce_governance(temp_files, policy)

        assert isinstance(result, ViolationResult)
        assert result.blocked is False  # Within budget
        assert result.has_violations is False


# ============================================================================
# Test create_budget_tracker_from_config
# ============================================================================


class TestCreateBudgetTrackerFromConfig:
    """Test budget tracker creation from config."""

    def test_create_from_dict_config(self):
        """Test creating tracker from dict configuration."""
        config = {
            "budgets": {
                "max_files": 20,
                "max_lines": 5000
            }
        }

        tracker = create_budget_tracker_from_config(config)

        assert tracker.max_files == 20
        assert tracker.max_lines == 5000

    def test_create_with_defaults(self):
        """Test creating tracker with default values."""
        config = {}
        tracker = create_budget_tracker_from_config(config)

        assert tracker.max_files == 15
        assert tracker.max_lines == 3000

    def test_create_with_partial_config(self):
        """Test creating tracker with partial configuration."""
        config = {
            "budgets": {
                "max_files": 25
            }
        }

        tracker = create_budget_tracker_from_config(config)

        assert tracker.max_files == 25
        assert tracker.max_lines == 3000  # Default


# ============================================================================
# Integration Tests
# ============================================================================


class TestBudgetIntegration:
    """Integration tests for budget system."""

    def test_full_budget_workflow(self):
        """Test complete budget checking workflow."""
        # 1. Create configuration
        budget_config = BudgetConfig(max_files=10, max_lines=1000)
        policy_config = PolicyConfig(enforcement_mode=EnforcementMode.STRICT)

        # 2. Create tracker
        tracker = BudgetTracker(
            max_files=budget_config.max_files,
            max_lines=budget_config.max_lines
        )

        # 3. Create test files
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            files = []
            for i in range(8):
                f = tmpdir / f"file{i}.py"
                f.write_text("line\n" * 100)  # 100 lines each
                files.append(f)

            # 4. Calculate budget
            status = tracker.calculate_budget(files)

            # 5. Check health
            health = tracker.get_budget_health(status)

            # 6. Get alerts
            alerts = tracker.generate_alerts(status)

            # Assertions
            assert status.files_used == 8
            assert status.lines_used == 800
            assert health == "warning"  # 80% usage
            assert len(alerts) > 0

    def test_config_serialization_roundtrip(self):
        """Test full config serialization roundtrip."""
        # Create configs
        budget = BudgetConfig(max_files=12, max_lines=2500)
        policy = PolicyConfig(enforcement_mode=EnforcementMode.WARNING)

        # Serialize
        budget_data = budget.to_dict()
        policy_data = policy.to_dict()

        # Deserialize
        budget_restored = BudgetConfig.from_dict(budget_data)
        policy_restored = PolicyConfig.from_dict(policy_data)

        # Verify
        assert budget_restored.max_files == 12
        assert budget_restored.max_lines == 2500
        assert policy_restored.enforcement_mode == EnforcementMode.WARNING


# ============================================================================
# Additional Tests for Coverage
# ============================================================================


class TestAlertLevels:
    """Test different alert levels (CRITICAL, WARNING, INFO)."""

    def test_critical_alert_level(self):
        """Test that 90%+ usage generates CRITICAL alerts."""
        tracker = BudgetTracker(max_files=10, max_lines=1000, alert_thresholds=[0.9])
        status = BudgetStatus(files_used=9, files_max=10, lines_used=950, lines_max=1000)

        alerts = tracker.generate_alerts(status)

        # Should have critical alerts
        critical_alerts = [a for a in alerts if a.level == AlertLevel.CRITICAL]
        assert len(critical_alerts) > 0

    def test_info_alert_level(self):
        """Test that lower thresholds generate INFO alerts."""
        tracker = BudgetTracker(max_files=10, max_lines=1000, alert_thresholds=[0.5])
        status = BudgetStatus(files_used=6, files_max=10, lines_used=600, lines_max=1000)

        alerts = tracker.generate_alerts(status)

        # Should have info alerts
        info_alerts = [a for a in alerts if a.level == AlertLevel.INFO]
        assert len(info_alerts) > 0


class TestViolationActions:
    """Test different violation actions (NOTIFY, SUGGEST)."""

    def test_notify_violation_action(self):
        """Test that NOTIFY action is included in result."""
        tracker = BudgetTracker()
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.NOTIFY]
        )

        result = tracker.handle_violation(status, policy)

        # Should include NOTIFY action
        notify_actions = [a for a in result.actions_taken if "Notify" in a]
        assert len(notify_actions) > 0

    def test_suggest_violation_action(self):
        """Test that SUGGEST action is included in result."""
        tracker = BudgetTracker()
        status = BudgetStatus(files_used=20, files_max=15, lines_used=2000, lines_max=3000)

        policy = GovernancePolicy(
            policy_id="test",
            name="Test",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000,
            violation_actions=[ViolationAction.SUGGEST]
        )

        result = tracker.handle_violation(status, policy)

        # Should include SUGGEST action
        suggest_actions = [a for a in result.actions_taken if "Suggest" in a]
        assert len(suggest_actions) > 0


class TestPolicyManager:
    """Test PolicyManager for saving/loading governance policies."""

    @pytest.fixture
    def temp_project_root(self):
        """Create temporary project root."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_init_creates_directories(self, temp_project_root):
        """Test that PolicyManager creates necessary directories."""
        manager = PolicyManager(temp_project_root)

        assert manager.policies_dir.exists()
        assert manager.policies_dir == temp_project_root / ".cdg" / "policies"

    def test_save_and_load_policy(self, temp_project_root):
        """Test saving and loading a policy."""
        manager = PolicyManager(temp_project_root)

        policy = GovernancePolicy(
            policy_id="test-policy",
            name="Test Policy",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=20,
            max_lines=5000
        )

        manager.save_policy(policy)

        loaded = manager.load_policy("test-policy")

        assert loaded is not None
        assert loaded.policy_id == "test-policy"
        assert loaded.name == "Test Policy"
        assert loaded.max_files == 20
        assert loaded.max_lines == 5000

    def test_load_nonexistent_policy(self, temp_project_root):
        """Test loading a policy that doesn't exist."""
        manager = PolicyManager(temp_project_root)

        loaded = manager.load_policy("nonexistent")

        assert loaded is None

    def test_list_policies(self, temp_project_root):
        """Test listing all policies."""
        manager = PolicyManager(temp_project_root)

        # Save multiple policies
        policy1 = GovernancePolicy(
            policy_id="policy1",
            name="Policy 1",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=15,
            max_lines=3000
        )

        policy2 = GovernancePolicy(
            policy_id="policy2",
            name="Policy 2",
            enabled=True,
            enforcement_mode=EnforcementMode.WARNING,
            max_files=20,
            max_lines=5000
        )

        manager.save_policy(policy1)
        manager.save_policy(policy2)

        policies = manager.list_policies()

        assert len(policies) == 2
        policy_ids = [p.policy_id for p in policies]
        assert "policy1" in policy_ids
        assert "policy2" in policy_ids

    def test_get_active_policy_default(self, temp_project_root):
        """Test getting active policy returns default when none set."""
        manager = PolicyManager(temp_project_root)

        policy = manager.get_active_policy()

        assert policy is not None
        assert policy.policy_id == "default"
        assert policy.enforcement_mode == EnforcementMode.WARNING

    def test_set_and_get_active_policy(self, temp_project_root):
        """Test setting and getting active policy."""
        manager = PolicyManager(temp_project_root)

        # Create and save a policy
        policy = GovernancePolicy(
            policy_id="custom-policy",
            name="Custom Policy",
            enabled=True,
            enforcement_mode=EnforcementMode.STRICT,
            max_files=10,
            max_lines=2000
        )

        manager.save_policy(policy)

        # Set as active
        success = manager.set_active_policy("custom-policy")
        assert success is True

        # Get active policy
        active = manager.get_active_policy()
        assert active is not None
        assert active.policy_id == "custom-policy"
        assert active.max_files == 10

    def test_set_nonexistent_policy_as_active(self, temp_project_root):
        """Test that setting nonexistent policy as active fails."""
        manager = PolicyManager(temp_project_root)

        success = manager.set_active_policy("nonexistent")

        assert success is False
