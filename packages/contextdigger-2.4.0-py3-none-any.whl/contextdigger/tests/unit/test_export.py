"""Tests for export module - Context export for AI tools.

Verifies that ContextExporter correctly:
- Generates AI-readable context files
- Includes budget information
- Handles provenance tracking
- Handles bookmarks
- Formats output correctly
- Handles edge cases (missing files, custom paths, etc.)
"""

import pytest
from pathlib import Path
from datetime import datetime
from contextdigger.export import ContextExporter, export_context_for_area
from contextdigger.provenance import ProvenanceTracker
from contextdigger.budget import BudgetStatus


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def temp_workspace(tmp_path):
    """Create temporary workspace with .cdg directory."""
    workspace = tmp_path / "test_project"
    workspace.mkdir()
    cdg_dir = workspace / ".cdg"
    cdg_dir.mkdir()
    return workspace


@pytest.fixture
def sample_files(temp_workspace):
    """Create sample files for testing."""
    # Create test files with content
    file1 = temp_workspace / "src" / "api.py"
    file1.parent.mkdir(parents=True, exist_ok=True)
    file1.write_text("def main():\n    pass\n")

    file2 = temp_workspace / "src" / "models.py"
    file2.write_text("class Model:\n    def __init__(self):\n        pass\n")

    file3 = temp_workspace / "tests" / "test_api.py"
    file3.parent.mkdir(parents=True, exist_ok=True)
    file3.write_text("def test_main():\n    assert True\n")

    return [file1, file2, file3]


@pytest.fixture
def budget_status_within():
    """Create BudgetStatus within budget."""
    return BudgetStatus(
        files_used=3,
        files_max=15,
        lines_used=100,
        lines_max=3000,
    )


@pytest.fixture
def budget_status_exceeded():
    """Create BudgetStatus exceeding budget."""
    return BudgetStatus(
        files_used=20,
        files_max=15,
        lines_used=3500,
        lines_max=3000,
    )


@pytest.fixture
def exporter(temp_workspace):
    """Create ContextExporter instance."""
    cdg_dir = temp_workspace / ".cdg"
    return ContextExporter(temp_workspace, cdg_dir)


# ============================================================================
# ContextExporter Initialization Tests
# ============================================================================


class TestContextExporterInit:
    """Test ContextExporter initialization."""

    def test_init_with_paths(self, temp_workspace):
        """Test initialization with project and cdg paths."""
        cdg_dir = temp_workspace / ".cdg"
        exporter = ContextExporter(temp_workspace, cdg_dir)

        assert exporter.project_root == temp_workspace
        assert exporter.cdg_root == cdg_dir
        assert exporter.context_dir == cdg_dir / "context"

    def test_init_converts_to_path(self, temp_workspace):
        """Test that string paths are converted to Path objects."""
        cdg_dir = temp_workspace / ".cdg"
        exporter = ContextExporter(str(temp_workspace), str(cdg_dir))

        assert isinstance(exporter.project_root, Path)
        assert isinstance(exporter.cdg_root, Path)
        assert isinstance(exporter.context_dir, Path)


# ============================================================================
# Line Counting Tests
# ============================================================================


class TestCountLines:
    """Test _count_lines method."""

    def test_count_lines_regular_file(self, exporter, temp_workspace):
        """Test counting lines in regular file."""
        test_file = temp_workspace / "test.py"
        test_file.write_text("line 1\nline 2\nline 3\n")

        count = exporter._count_lines(test_file)

        assert count == 3

    def test_count_lines_empty_file(self, exporter, temp_workspace):
        """Test counting lines in empty file."""
        test_file = temp_workspace / "empty.py"
        test_file.write_text("")

        count = exporter._count_lines(test_file)

        assert count == 0

    def test_count_lines_single_line_no_newline(self, exporter, temp_workspace):
        """Test counting lines in file without trailing newline."""
        test_file = temp_workspace / "single.py"
        test_file.write_text("single line")

        count = exporter._count_lines(test_file)

        assert count == 1

    def test_count_lines_nonexistent_file(self, exporter, temp_workspace):
        """Test counting lines in non-existent file."""
        test_file = temp_workspace / "nonexistent.py"

        count = exporter._count_lines(test_file)

        assert count == 0

    def test_count_lines_with_unicode(self, exporter, temp_workspace):
        """Test counting lines in file with unicode characters."""
        test_file = temp_workspace / "unicode.py"
        test_file.write_text("# -*- coding: utf-8 -*-\n# 日本語\nprint('hello')\n")

        count = exporter._count_lines(test_file)

        assert count == 3


# ============================================================================
# Basic Export Tests
# ============================================================================


class TestBasicExport:
    """Test basic export functionality."""

    def test_export_creates_file(self, exporter, sample_files, budget_status_within):
        """Test that export creates output file."""
        output = exporter.export_for_ai(
            area_name="backend-api",
            area_description="Backend API implementation",
            files=sample_files,
            budget_status=budget_status_within,
        )

        assert output.exists()
        assert output.name == "backend-api.txt"
        assert output.parent == exporter.context_dir

    def test_export_content_structure(self, exporter, sample_files, budget_status_within):
        """Test that exported file has correct structure."""
        output = exporter.export_for_ai(
            area_name="backend-api",
            area_description="Backend API implementation",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Check sections exist
        assert "# ContextDigger Context: backend-api" in content
        assert "## Instructions" in content
        assert "## Files to Load" in content
        assert "## Attention Budget Used" in content
        assert "## How to Use" in content

    def test_export_includes_all_files(self, exporter, sample_files, budget_status_within):
        """Test that all files are listed in export."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Check all files are mentioned
        assert "src/api.py" in content
        assert "src/models.py" in content
        assert "tests/test_api.py" in content

    def test_export_includes_line_counts(self, exporter, sample_files, budget_status_within):
        """Test that line counts are included."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Check line counts are present
        assert "Lines:" in content
        assert "lines" in content

    def test_export_custom_output_path(self, exporter, sample_files, budget_status_within, temp_workspace):
        """Test export to custom output path."""
        custom_path = temp_workspace / "custom" / "export.txt"

        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
            output_path=custom_path,
        )

        assert output == custom_path
        assert output.exists()
        assert output.parent.name == "custom"


# ============================================================================
# Budget Status Tests
# ============================================================================


class TestBudgetStatusInExport:
    """Test budget status display in exports."""

    def test_export_within_budget(self, exporter, sample_files, budget_status_within):
        """Test export with budget status within limits."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        assert "3/15" in content  # files_used/files_max
        assert "100" in content and "3,000" in content  # lines
        assert "Within budget" in content
        assert "✓" in content

    def test_export_exceeds_budget(self, exporter, sample_files, budget_status_exceeded):
        """Test export with budget exceeded."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_exceeded,
        )

        content = output.read_text()

        assert "20/15" in content  # files exceeded
        assert "3,500" in content and "3,000" in content  # lines exceeded
        assert "Exceeds budget" in content
        assert "⚠️" in content

    def test_export_includes_percentages(self, exporter, sample_files, budget_status_within):
        """Test that budget percentages are included."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        assert "20%" in content or "3%" in content  # Should have percentages


# ============================================================================
# Provenance Tracking Tests
# ============================================================================


class TestProvenanceTracking:
    """Test provenance tracking in exports."""

    def test_export_with_provenance_tracking(self, exporter, sample_files, budget_status_within, temp_workspace):
        """Test export with provenance tracking enabled."""
        tracker = ProvenanceTracker(temp_workspace)
        session_id = "test-session-001"

        output = exporter.export_for_ai(
            area_name="backend-api",
            area_description="Backend API",
            files=sample_files,
            budget_status=budget_status_within,
            provenance_tracker=tracker,
            session_id=session_id,
        )

        content = output.read_text()

        # Check provenance section exists
        assert "## File Provenance" in content
        assert "Why each file was included" in content

        # Verify provenance was tracked
        prov1 = tracker.get_file_provenance("src/api.py", session_id)
        assert prov1 is not None
        assert prov1.loaded_by == "export"
        assert prov1.area_id == "backend-api"

    def test_export_provenance_includes_reasons(self, exporter, sample_files, budget_status_within, temp_workspace):
        """Test that provenance reasons are displayed."""
        tracker = ProvenanceTracker(temp_workspace)
        session_id = "test-session-002"

        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
            provenance_tracker=tracker,
            session_id=session_id,
        )

        content = output.read_text()

        # Check that file paths and reasons are shown
        assert "export:" in content
        assert "Exported as part of" in content

    def test_export_without_provenance(self, exporter, sample_files, budget_status_within):
        """Test export without provenance tracking."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Provenance section should not exist
        assert "## File Provenance" not in content


# ============================================================================
# Bookmarks Tests
# ============================================================================


class TestBookmarks:
    """Test bookmark handling in exports."""

    def test_export_with_bookmarks(self, exporter, sample_files, budget_status_within):
        """Test export with bookmarks."""
        from contextdigger.manager import Bookmark

        bookmarks = [
            Bookmark(
                id="bookmark-1",
                name="Main function",
                path="src/api.py",
                line=10,
                notes="Entry point",
            )
        ]

        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
            bookmarks=bookmarks,
        )

        content = output.read_text()

        assert "## Bookmarks" in content
        assert "src/api.py:10" in content
        assert "Main function" in content

    def test_export_without_bookmarks(self, exporter, sample_files, budget_status_within):
        """Test export without bookmarks."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Bookmarks section should not exist
        assert "## Bookmarks" not in content


# ============================================================================
# Path Handling Tests
# ============================================================================


class TestPathHandling:
    """Test file path handling."""

    def test_export_handles_relative_paths(self, exporter, sample_files, budget_status_within):
        """Test that file paths are shown as relative."""
        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=sample_files,
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Should show relative paths, not absolute
        assert "src/api.py" in content
        assert str(exporter.project_root) not in content

    def test_export_handles_absolute_paths_outside_project(self, exporter, budget_status_within, tmp_path):
        """Test handling of absolute paths outside project root."""
        external_file = tmp_path / "external.py"
        external_file.write_text("# External file\n")

        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test area",
            files=[external_file],
            budget_status=budget_status_within,
        )

        content = output.read_text()

        # Should handle files outside project root gracefully
        assert "external.py" in content


# ============================================================================
# Convenience Function Tests
# ============================================================================


class TestConvenienceFunction:
    """Test export_context_for_area convenience function."""

    def test_convenience_function(self, temp_workspace, sample_files, budget_status_within):
        """Test convenience function works."""
        cdg_dir = temp_workspace / ".cdg"

        output = export_context_for_area(
            project_root=temp_workspace,
            cdg_root=cdg_dir,
            area_name="test-area",
            area_description="Test description",
            files=sample_files,
            budget_status=budget_status_within,
        )

        assert output.exists()
        assert output.parent == cdg_dir / "context"

    def test_convenience_function_with_bookmarks(self, temp_workspace, sample_files, budget_status_within):
        """Test convenience function with bookmarks."""
        from contextdigger.manager import Bookmark

        cdg_dir = temp_workspace / ".cdg"
        bookmarks = [
            Bookmark(
                id="bm-1",
                name="Test",
                path="src/api.py",
                line=1,
                notes="Test",
            )
        ]

        output = export_context_for_area(
            project_root=temp_workspace,
            cdg_root=cdg_dir,
            area_name="test-area",
            area_description="Test description",
            files=sample_files,
            budget_status=budget_status_within,
            bookmarks=bookmarks,
        )

        content = output.read_text()
        assert "## Bookmarks" in content


# ============================================================================
# Integration Tests
# ============================================================================


class TestExportIntegration:
    """Integration tests for complete export workflow."""

    def test_full_export_workflow(self, exporter, sample_files, budget_status_within, temp_workspace):
        """Test complete export workflow with all features."""
        tracker = ProvenanceTracker(temp_workspace)
        session_id = "integration-session"

        from contextdigger.manager import Bookmark

        bookmarks = [
            Bookmark(
                id="bm-integration",
                name="Integration bookmark",
                path="src/api.py",
                line=5,
                notes="Test bookmark",
            )
        ]

        # Export with all features
        output = exporter.export_for_ai(
            area_name="integration-test",
            area_description="Full integration test area",
            files=sample_files,
            budget_status=budget_status_within,
            bookmarks=bookmarks,
            provenance_tracker=tracker,
            session_id=session_id,
        )

        # Verify file created
        assert output.exists()

        # Verify content
        content = output.read_text()
        assert "# ContextDigger Context: integration-test" in content
        assert "## Files to Load" in content
        assert "## Bookmarks" in content
        assert "## File Provenance" in content
        assert "## Attention Budget Used" in content

        # Verify provenance tracked
        for file in sample_files:
            rel_path = file.relative_to(temp_workspace)
            prov = tracker.get_file_provenance(str(rel_path), session_id)
            assert prov is not None
            assert prov.loaded_by == "export"

    def test_export_creates_context_directory(self, temp_workspace, sample_files, budget_status_within):
        """Test that export creates context directory if it doesn't exist."""
        cdg_dir = temp_workspace / ".cdg"
        exporter = ContextExporter(temp_workspace, cdg_dir)

        # Ensure context dir doesn't exist
        context_dir = cdg_dir / "context"
        if context_dir.exists():
            import shutil
            shutil.rmtree(context_dir)

        output = exporter.export_for_ai(
            area_name="test-area",
            area_description="Test",
            files=sample_files,
            budget_status=budget_status_within,
        )

        assert context_dir.exists()
        assert output.exists()
