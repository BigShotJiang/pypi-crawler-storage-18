"""
Tests for contextdigger.api module.

Tests cover:
- DTO dataclasses
- ContextDiggerApi class with token validation
- Permission checking for all operations
- Refusal behavior for invalid/missing tokens
- Integration with FocusManager and services
- Convenience wrapper functions
"""

import pytest
import json
import tempfile
from pathlib import Path
from datetime import datetime

from contextdigger.api import (
    AreaDto,
    FocusedFile,
    BudgetStatusDto,
    FocusBundle,
    ContractSummary,
    InsightDto,
    ProvenanceRecordDto,
    ApiRefusal,
    ContextDiggerApi,
    list_areas,
    dig_area,
    get_focus,
    get_budget_status,
    get_contracts,
    continue_work,
    pause_work,
    get_insights,
    get_provenance,
)
from contextdigger.authz import (
    Permission,
    Tier,
    LocalFileAuthz,
)
from contextdigger.manager import FocusManager


class TestDTOs:
    """Test DTO dataclasses."""

    def test_area_dto(self):
        """Test AreaDto creation."""
        dto = AreaDto(
            id="backend-api",
            name="Backend API",
            description="REST API endpoints",
            type="auto-detected",
            file_count=15,
            is_current=True
        )

        assert dto.id == "backend-api"
        assert dto.name == "Backend API"
        assert dto.type == "auto-detected"
        assert dto.file_count == 15
        assert dto.is_current is True

    def test_focused_file(self):
        """Test FocusedFile creation."""
        file = FocusedFile(
            path="/path/to/file.py",
            reason="area_member",
            lines=100,
            size_bytes=5000
        )

        assert file.path == "/path/to/file.py"
        assert file.reason == "area_member"
        assert file.lines == 100

    def test_budget_status_dto(self):
        """Test BudgetStatusDto creation."""
        budget = BudgetStatusDto(
            files_used=10,
            files_max=15,
            lines_used=2000,
            lines_max=3000,
            health="healthy",
            percentage=66.7,
            policy_mode="advisory"
        )

        assert budget.files_used == 10
        assert budget.files_max == 15
        assert budget.health == "healthy"

    def test_focus_bundle(self):
        """Test FocusBundle creation."""
        files = [
            FocusedFile(path="/file1.py", reason="area", lines=50, size_bytes=1000),
            FocusedFile(path="/file2.py", reason="area", lines=75, size_bytes=1500)
        ]
        budget = BudgetStatusDto(
            files_used=2, files_max=15,
            lines_used=125, lines_max=3000,
            health="healthy", percentage=4.2,
            policy_mode="advisory"
        )

        bundle = FocusBundle(
            area_id="test-area",
            area_name="Test Area",
            files=files,
            budget=budget,
            session_id="session-123"
        )

        assert bundle.area_id == "test-area"
        assert len(bundle.files) == 2
        assert bundle.budget.health == "healthy"

    def test_api_refusal(self):
        """Test ApiRefusal creation and to_dict."""
        refusal = ApiRefusal(
            code="insufficient_permissions",
            message="Missing required permission",
            details="Token lacks DIG permission",
            required_permission=Permission.DIG
        )

        assert refusal.code == "insufficient_permissions"
        assert refusal.required_permission == Permission.DIG

        # Test to_dict
        data = refusal.to_dict()
        assert data["code"] == "insufficient_permissions"
        assert data["required_permission"] == "dig"


class TestContextDiggerApi:
    """Test ContextDiggerApi class."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace with .cdg directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            # Get the areas directory that was created
            areas_dir = workspace / ".cdg" / "areas"

            # Create a simple test area (matches FocusArea structure)
            test_area = {
                "id": "test-area",
                "name": "Test Area",
                "description": "Test area for unit tests",
                "type": "manual",
                "patterns": {
                    "include": ["*.py"]
                },
                "metadata": {},
                "dependencies": [],
                "quickAccess": {},
                "created": datetime.now().isoformat() + "Z",
                "lastFocused": None,
                "focusCount": 0
            }

            with open(areas_dir / "test-area.json", 'w') as f:
                json.dump(test_area, f)

            # Create actual test files
            (workspace / "test1.py").write_text("# Test file 1\nprint('hello')\n")
            (workspace / "test2.py").write_text("# Test file 2\nprint('world')\n")

            yield workspace

    @pytest.fixture
    def api(self, workspace):
        """Create ContextDiggerApi instance."""
        return ContextDiggerApi(workspace, backend_type="local")

    @pytest.fixture
    def setup_tokens(self, workspace):
        """Set up various test tokens."""
        backend = LocalFileAuthz(workspace)

        # Full permissions token (enterprise)
        backend.create_token(
            token="full-access",
            tier=Tier.ENTERPRISE,
            subject="admin-user"
        )

        # Restricted token (can only read, not dig)
        backend.create_token(
            token="read-only",
            tier=Tier.FREE,
            subject="read-user",
            permissions={Permission.READ_AREAS, Permission.READ_CONFIG}
        )

        # Team token (no admin)
        backend.create_token(
            token="team-user",
            tier=Tier.TEAM,
            subject="team-member"
        )

    def test_api_initialization(self, workspace):
        """Test API initialization."""
        api = ContextDiggerApi(workspace, backend_type="local")

        assert api.workspace == workspace
        assert api.authz_backend is not None

    def test_list_areas_with_full_permissions(self, api, setup_tokens):
        """Test list_areas with full permissions."""
        areas = api.list_areas(token="full-access")

        assert isinstance(areas, list)
        assert len(areas) >= 1  # At least our test area

        # Find our test area
        test_area = next((a for a in areas if a.id == "test-area"), None)
        assert test_area is not None
        assert test_area.name == "Test Area"
        assert test_area.file_count == 2

    def test_list_areas_without_token_uses_default(self, api):
        """Test that list_areas without token uses default token."""
        # Should not raise - uses default local-dev-full-access
        areas = api.list_areas()
        assert isinstance(areas, list)

    def test_list_areas_with_restricted_permissions(self, api, setup_tokens):
        """Test list_areas with read-only token."""
        # read-only token has READ_AREAS permission
        areas = api.list_areas(token="read-only")
        assert isinstance(areas, list)

    def test_list_areas_with_invalid_token_raises_refusal(self, api):
        """Test list_areas with invalid token raises ApiRefusal."""
        with pytest.raises(ApiRefusal) as exc_info:
            api.list_areas(token="nonexistent-token")

        assert exc_info.value.code == "invalid_token"

    def test_dig_area_with_full_permissions(self, api, setup_tokens):
        """Test dig_area with full permissions."""
        bundle = api.dig_area("test-area", token="full-access")

        assert isinstance(bundle, FocusBundle)
        assert bundle.area_id == "test-area"
        assert bundle.area_name == "Test Area"
        assert len(bundle.files) == 2
        assert isinstance(bundle.budget, BudgetStatusDto)

    def test_dig_area_without_dig_permission_raises_refusal(self, api, setup_tokens):
        """Test dig_area without DIG permission raises ApiRefusal."""
        with pytest.raises(ApiRefusal) as exc_info:
            api.dig_area("test-area", token="read-only")

        assert exc_info.value.code == "insufficient_permissions"
        assert exc_info.value.required_permission == Permission.DIG

    def test_get_focus_with_permissions(self, api, setup_tokens):
        """Test get_focus with FOCUS permission."""
        # First dig to set focus
        api.dig_area("test-area", token="full-access")

        # Then get focus
        bundle = api.get_focus(token="full-access")

        assert isinstance(bundle, FocusBundle)
        assert bundle.area_id == "test-area"

    def test_get_focus_no_current_area(self, api, setup_tokens):
        """Test get_focus when no area is current."""
        bundle = api.get_focus(token="full-access")

        assert bundle.area_id is None
        assert bundle.area_name is None
        assert len(bundle.files) == 0

    def test_get_budget_status(self, api, setup_tokens):
        """Test get_budget_status."""
        budget = api.get_budget_status(token="full-access")

        assert isinstance(budget, BudgetStatusDto)
        assert budget.files_max > 0
        assert budget.lines_max > 0

    def test_permission_enforcement_across_methods(self, api, setup_tokens):
        """Test that all methods enforce permissions correctly."""
        # read-only token should work for READ operations
        api.list_areas(token="read-only")  # Has READ_AREAS
        api.get_budget_status(token="read-only")  # Has READ_CONFIG

        # But should fail for operations requiring other permissions
        with pytest.raises(ApiRefusal):
            api.dig_area("test-area", token="read-only")  # Needs DIG

        with pytest.raises(ApiRefusal):
            api.get_insights(token="read-only")  # Needs INSIGHTS

    def test_api_refusal_structure(self, api):
        """Test that ApiRefusal has correct structure."""
        with pytest.raises(ApiRefusal) as exc_info:
            api.list_areas(token="bad-token")

        refusal = exc_info.value
        assert hasattr(refusal, 'code')
        assert hasattr(refusal, 'message')
        assert hasattr(refusal, 'details')
        assert isinstance(refusal.to_dict(), dict)

    def test_focus_bundle_includes_budget(self, api, setup_tokens):
        """Test that FocusBundle includes budget information."""
        api.dig_area("test-area", token="full-access")
        bundle = api.get_focus(token="full-access")

        assert bundle.budget is not None
        assert bundle.budget.files_used >= 0
        assert bundle.budget.lines_used >= 0
        assert bundle.budget.health in ["healthy", "warning", "exceeded"]

    def test_focused_files_have_provenance(self, api, setup_tokens):
        """Test that focused files include provenance reason."""
        api.dig_area("test-area", token="full-access")
        bundle = api.get_focus(token="full-access")

        for file in bundle.files:
            assert isinstance(file, FocusedFile)
            assert file.reason is not None
            assert file.path is not None
            assert file.lines >= 0
            assert file.size_bytes >= 0


class TestConvenienceWrappers:
    """Test convenience wrapper functions."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            areas_dir = workspace / ".cdg" / "areas"

            # Create test area
            test_area = {
                "id": "wrapper-test",
                "name": "Wrapper Test",
                "description": "Test for wrappers",
                "type": "manual",
                "patterns": {"include": ["*.py"]},
                "metadata": {},
                "dependencies": [],
                "quickAccess": {},
                "created": datetime.now().isoformat() + "Z",
                "lastFocused": None,
                "focusCount": 0
            }

            with open(areas_dir / "wrapper-test.json", 'w') as f:
                json.dump(test_area, f)

            yield workspace

    def test_list_areas_wrapper(self, workspace):
        """Test list_areas convenience wrapper."""
        areas = list_areas(workspace)

        assert isinstance(areas, list)
        assert any(a.id == "wrapper-test" for a in areas)

    def test_list_areas_wrapper_with_token(self, workspace):
        """Test list_areas wrapper with token."""
        # Set up token
        backend = LocalFileAuthz(workspace)
        backend.create_token("test-token", Tier.FREE, "test-user")

        areas = list_areas(workspace, token="test-token")
        assert isinstance(areas, list)

    def test_get_focus_wrapper(self, workspace):
        """Test get_focus convenience wrapper."""
        bundle = get_focus(workspace)

        assert isinstance(bundle, FocusBundle)

    def test_get_budget_status_wrapper(self, workspace):
        """Test get_budget_status convenience wrapper."""
        budget = get_budget_status(workspace)

        assert isinstance(budget, BudgetStatusDto)


class TestApiIntegration:
    """Integration tests for API layer."""

    @pytest.fixture
    def full_workspace(self):
        """Create workspace with multiple areas and tokens."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            areas_dir = workspace / ".cdg" / "areas"

            # Create multiple test areas
            for i in range(3):
                area = {
                    "id": f"area-{i}",
                    "name": f"Area {i}",
                    "description": f"Test area {i}",
                    "type": "manual",
                    "patterns": {
                        "include": [f"file{i}.py"]
                    },
                    "metadata": {},
                    "dependencies": [],
                    "quickAccess": {},
                    "created": datetime.now().isoformat() + "Z",
                    "lastFocused": None,
                    "focusCount": 0
                }

                with open(areas_dir / f"area-{i}.json", 'w') as f:
                    json.dump(area, f)

                # Create actual file
                (workspace / f"file{i}.py").write_text(f"# File {i}\n")

            # Set up tokens
            backend = LocalFileAuthz(workspace)
            backend.create_token("integration-token", Tier.ENTERPRISE, "integration-user")

            yield workspace

    def test_full_workflow_with_token(self, full_workspace):
        """Test complete workflow: list → dig → get focus."""
        api = ContextDiggerApi(full_workspace)
        token = "integration-token"

        # 1. List areas
        areas = api.list_areas(token=token)
        assert len(areas) >= 3

        # 2. Dig into area
        bundle = api.dig_area("area-0", token=token)
        assert bundle.area_id == "area-0"
        assert len(bundle.files) >= 1

        # 3. Get current focus
        focus = api.get_focus(token=token)
        assert focus.area_id == "area-0"
        assert focus.area_name == "Area 0"

        # 4. Check budget
        budget = api.get_budget_status(token=token)
        assert budget.files_used >= 1
        assert budget.health in ["healthy", "warning", "exceeded"]

    def test_switching_areas_updates_focus(self, full_workspace):
        """Test that digging different areas updates focus."""
        api = ContextDiggerApi(full_workspace)
        token = "integration-token"

        # Dig area-0
        bundle1 = api.dig_area("area-0", token=token)
        assert bundle1.area_id == "area-0"

        # Dig area-1
        bundle2 = api.dig_area("area-1", token=token)
        assert bundle2.area_id == "area-1"

        # Focus should be on area-1
        focus = api.get_focus(token=token)
        assert focus.area_id == "area-1"

    def test_tier_based_access_control(self, full_workspace):
        """Test that different tiers have different access."""
        backend = LocalFileAuthz(full_workspace)

        # Create tokens with different tiers
        backend.create_token("free-user", Tier.FREE, "free")
        backend.create_token("team-user", Tier.TEAM, "team")
        backend.create_token("enterprise-user", Tier.ENTERPRISE, "enterprise")

        api = ContextDiggerApi(full_workspace)

        # All can list areas
        api.list_areas(token="free-user")
        api.list_areas(token="team-user")
        api.list_areas(token="enterprise-user")

        # All can dig (DIG is in FREE tier)
        api.dig_area("area-0", token="free-user")
        api.dig_area("area-0", token="team-user")
        api.dig_area("area-0", token="enterprise-user")

        # Check insights (INSIGHTS is in FREE, but let's verify)
        api.get_insights(token="free-user")  # Should work
        api.get_insights(token="team-user")  # Should work
        api.get_insights(token="enterprise-user")  # Should work


class TestErrorHandling:
    """Test error handling and edge cases."""

    @pytest.fixture
    def workspace(self):
        """Create minimal workspace."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            yield workspace

    def test_missing_token_with_no_default(self, workspace):
        """Test behavior when no token and no default."""
        # Delete default token file to simulate no defaults
        tokens_file = workspace / ".cdg" / "tokens.json"
        if tokens_file.exists():
            tokens_file.unlink()

        api = ContextDiggerApi(workspace)

        # Should create default token on backend init
        # So this should actually work
        areas = api.list_areas()
        assert isinstance(areas, list)

    def test_invalid_area_id(self, workspace):
        """Test digging into nonexistent area."""
        api = ContextDiggerApi(workspace)

        # This should raise ValueError when area doesn't exist
        # (not ApiRefusal, since permission check passed)
        with pytest.raises(ValueError) as exc_info:
            api.dig_area("nonexistent-area", token=None)

        assert "not found" in str(exc_info.value).lower()

    def test_api_refusal_to_dict_serialization(self):
        """Test that ApiRefusal can be serialized to dict."""
        refusal = ApiRefusal(
            code="test_code",
            message="Test message",
            details="Test details",
            required_permission=Permission.ADMIN
        )

        data = refusal.to_dict()

        assert data["code"] == "test_code"
        assert data["message"] == "Test message"
        assert data["details"] == "Test details"
        assert data["required_permission"] == "admin"

    def test_api_refusal_without_permission(self):
        """Test ApiRefusal without required_permission."""
        refusal = ApiRefusal(
            code="general_error",
            message="General error"
        )

        data = refusal.to_dict()
        assert data["required_permission"] is None

    def test_api_refusal_str_representation(self):
        """Test ApiRefusal __str__ method."""
        refusal = ApiRefusal(
            code="test_error",
            message="This is the error message"
        )

        assert str(refusal) == "This is the error message"

    def test_missing_token_with_no_backend_default(self, workspace):
        """Test behavior when backend has no DEFAULT_TOKEN attribute."""
        from unittest.mock import Mock

        api = ContextDiggerApi(workspace)

        # Mock a backend without DEFAULT_TOKEN
        mock_backend = Mock(spec=[])  # No DEFAULT_TOKEN attribute
        api.authz_backend = mock_backend

        # Should raise ApiRefusal for missing token
        with pytest.raises(ApiRefusal) as exc_info:
            api._check_permission(None, Permission.READ_AREAS)

        assert exc_info.value.code == "missing_token"
        assert "no token provided" in exc_info.value.message.lower()

    def test_dig_area_budget_exceeded_exception(self, workspace):
        """Test dig_area when budget is exceeded."""
        from unittest.mock import patch, MagicMock

        # Mock FocusManager
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            # First call: validate area exists
            mock_manager_check = MagicMock()
            mock_area = MagicMock()
            mock_area.id = "test-area"
            mock_manager_check.get_area.return_value = mock_area

            # Second call: set_current_focus raises budget error
            mock_manager_check.set_current_focus.side_effect = Exception("Budget exceeded: too many files")

            MockFocusManager.return_value = mock_manager_check

            api = ContextDiggerApi(workspace)

            with pytest.raises(ApiRefusal) as exc_info:
                api.dig_area("test-area", token=None)

            assert exc_info.value.code == "budget_exceeded"
            assert "exceeded" in exc_info.value.message.lower()

    def test_dig_area_non_budget_exception(self, workspace):
        """Test dig_area with non-budget exception."""
        from unittest.mock import patch, MagicMock

        # Mock FocusManager
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager_check = MagicMock()
            mock_area = MagicMock()
            mock_area.id = "test-area"
            mock_manager_check.get_area.return_value = mock_area

            # set_current_focus raises non-budget error
            mock_manager_check.set_current_focus.side_effect = RuntimeError("Database connection failed")

            MockFocusManager.return_value = mock_manager_check

            api = ContextDiggerApi(workspace)

            # Should re-raise the original exception
            with pytest.raises(RuntimeError) as exc_info:
                api.dig_area("test-area", token=None)

            assert "database" in str(exc_info.value).lower()

    def test_get_focus_nonexistent_current_area(self, workspace):
        """Test get_focus when current focus ID doesn't exist."""
        from unittest.mock import patch
        from contextdigger.manager import FocusManager

        api = ContextDiggerApi(workspace)

        # Mock get_current_focus to return an ID that doesn't exist
        with patch.object(FocusManager, 'get_current_focus', return_value="nonexistent-area"):
            with patch.object(FocusManager, 'get_area', return_value=None):
                focus = api.get_focus(token=None)

                # Should return empty FocusBundle
                assert focus.area_id is None
                assert focus.area_name is None
                assert len(focus.files) == 0

    def test_get_budget_status_nonexistent_current_area(self, workspace):
        """Test get_budget_status when current area doesn't exist."""
        from unittest.mock import patch
        from contextdigger.manager import FocusManager

        api = ContextDiggerApi(workspace)

        # Mock get_current_focus to return an ID that doesn't exist
        with patch.object(FocusManager, 'get_current_focus', return_value="nonexistent-area"):
            with patch.object(FocusManager, 'get_area', return_value=None):
                budget = api.get_budget_status(token=None)

                # Should return empty budget
                assert budget.files_used == 0
                assert budget.lines_used == 0


class TestContractsAndContinuation:
    """Test continuation contract methods."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace with .cdg directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            yield workspace

    def test_get_contracts(self, workspace):
        """Test getting contracts list."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)

        # Mock FocusManager.list_contracts since it's not implemented yet
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.list_contracts.return_value = []
            MockFocusManager.return_value = mock_manager

            # Create new API with mocked manager
            api2 = ContextDiggerApi(workspace)
            contracts = api2.get_contracts(token=None)

            # Should return empty list when no contracts
            assert isinstance(contracts, list)
            assert len(contracts) == 0

    def test_get_contracts_requires_permission(self, workspace):
        """Test that get_contracts requires CONTINUATION permission."""
        # Create token without CONTINUATION permission
        backend = LocalFileAuthz(workspace)
        backend.create_token(
            token="no-continuation",
            tier=Tier.FREE,
            subject="test",
            permissions={Permission.READ_AREAS}  # Missing CONTINUATION
        )

        api = ContextDiggerApi(workspace)

        with pytest.raises(ApiRefusal) as exc_info:
            api.get_contracts(token="no-continuation")

        assert exc_info.value.code == "insufficient_permissions"

    def test_continue_work_exception(self, workspace):
        """Test continue_work when exception occurs."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)

        # Mock FocusManager.continue_work to raise exception
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.continue_work.side_effect = RuntimeError("No active contract")
            MockFocusManager.return_value = mock_manager

            api2 = ContextDiggerApi(workspace)

            with pytest.raises(ApiRefusal) as exc_info:
                api2.continue_work(token=None)

            assert exc_info.value.code == "continuation_error"
            # The exception message is used directly as the ApiRefusal message
            assert "no active contract" in exc_info.value.message.lower()
            assert exc_info.value.details == "Failed to resume continuation contract"

    def test_pause_work_exception(self, workspace):
        """Test pause_work when exception occurs."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)

        # Mock FocusManager.pause_work to raise exception
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.pause_work.side_effect = RuntimeError("Nothing to pause")
            MockFocusManager.return_value = mock_manager

            api2 = ContextDiggerApi(workspace)

            with pytest.raises(ApiRefusal) as exc_info:
                api2.pause_work(token=None)

            assert exc_info.value.code == "continuation_error"
            # The exception message is used directly as the ApiRefusal message
            assert "nothing to pause" in exc_info.value.message.lower()
            assert exc_info.value.details == "Failed to pause work"


class TestInsightsAndProvenance:
    """Test insights and provenance methods."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace with .cdg directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            yield workspace

    def test_get_insights(self, workspace):
        """Test getting insights."""
        api = ContextDiggerApi(workspace)

        insights = api.get_insights(token=None)

        # Should return empty list when no insights available
        assert isinstance(insights, list)

    def test_get_insights_requires_permission(self, workspace):
        """Test that get_insights requires INSIGHTS permission."""
        # Create token without INSIGHTS permission
        backend = LocalFileAuthz(workspace)
        backend.create_token(
            token="no-insights",
            tier=Tier.FREE,
            subject="test",
            permissions={Permission.READ_AREAS}  # Missing INSIGHTS
        )

        api = ContextDiggerApi(workspace)

        with pytest.raises(ApiRefusal) as exc_info:
            api.get_insights(token="no-insights")

        assert exc_info.value.code == "insufficient_permissions"

    def test_get_provenance(self, workspace):
        """Test getting file provenance."""
        api = ContextDiggerApi(workspace)
        test_file = workspace / "test.py"
        test_file.write_text("# test")

        provenance = api.get_provenance(test_file, token=None)

        # Should return empty list when no provenance available
        assert isinstance(provenance, list)

    def test_get_provenance_requires_permission(self, workspace):
        """Test that get_provenance requires PROVENANCE permission."""
        # Create token without PROVENANCE permission
        backend = LocalFileAuthz(workspace)
        backend.create_token(
            token="no-provenance",
            tier=Tier.FREE,
            subject="test",
            permissions={Permission.READ_AREAS}  # Missing PROVENANCE
        )

        api = ContextDiggerApi(workspace)
        test_file = workspace / "test.py"

        with pytest.raises(ApiRefusal) as exc_info:
            api.get_provenance(test_file, token="no-provenance")

        assert exc_info.value.code == "insufficient_permissions"

    def test_get_insights_with_data(self, workspace):
        """Test get_insights when insights are available (covers list comprehension)."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)

        # Mock get_insights to return data
        mock_insights = [
            {
                "level": "warning",
                "title": "High coupling detected",
                "description": "Module X has too many dependencies",
                "impact": "Maintainability",
                "confidence": 0.85,
                "related_areas": ["backend-api", "database"]
            },
            {
                "level": "info",
                "title": "Test coverage good",
                "description": "Coverage at 85%",
                "impact": "Quality",
                "confidence": 0.95,
                "related_areas": ["tests"]
            }
        ]

        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.get_insights.return_value = mock_insights
            MockFocusManager.return_value = mock_manager

            api2 = ContextDiggerApi(workspace)
            insights = api2.get_insights(token=None)

            # Verify list comprehension executed
            assert len(insights) == 2
            assert insights[0].level == "warning"
            assert insights[0].title == "High coupling detected"
            assert insights[1].level == "info"
            assert insights[1].confidence == 0.95

    def test_get_provenance_with_data(self, workspace):
        """Test get_provenance when records are available (covers list comprehension)."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)
        test_file = workspace / "test.py"
        test_file.write_text("# test")

        # Mock get_provenance to return data
        mock_provenance = [
            {
                "path": str(test_file),
                "area_id": "backend-api",
                "reason": "direct_member",
                "source": "discovery",
                "score": 1.0
            },
            {
                "path": str(test_file),
                "area_id": "tests",
                "reason": "test_file",
                "source": "analysis",
                "score": 0.8
            }
        ]

        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.get_provenance.return_value = mock_provenance
            MockFocusManager.return_value = mock_manager

            api2 = ContextDiggerApi(workspace)
            records = api2.get_provenance(test_file, token=None)

            # Verify list comprehension executed
            assert len(records) == 2
            assert records[0].area_id == "backend-api"
            assert records[0].reason == "direct_member"
            assert records[1].area_id == "tests"
            assert records[1].score == 0.8


class TestConvenienceWrappersExtended:
    """Test additional convenience wrapper functions."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace with .cdg directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            yield workspace

    def test_get_contracts_wrapper(self, workspace):
        """Test get_contracts convenience wrapper."""
        from unittest.mock import patch, MagicMock

        # Mock FocusManager.list_contracts since it's not implemented yet
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            mock_manager.list_contracts.return_value = []
            MockFocusManager.return_value = mock_manager

            contracts = get_contracts(workspace, token=None)

            assert isinstance(contracts, list)

    def test_get_insights_wrapper(self, workspace):
        """Test get_insights convenience wrapper."""
        insights = get_insights(workspace, token=None)

        assert isinstance(insights, list)

    def test_get_provenance_wrapper(self, workspace):
        """Test get_provenance convenience wrapper."""
        test_file = workspace / "test.py"
        test_file.write_text("# test")

        provenance = get_provenance(workspace, test_file, token=None)

        assert isinstance(provenance, list)

    def test_continue_work_wrapper(self, workspace):
        """Test continue_work convenience wrapper."""
        from unittest.mock import patch, MagicMock
        from contextdigger.api import continue_work

        # Mock FocusManager
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()
            # continue_work calls get_focus internally
            mock_manager.get_current_focus.return_value = None
            MockFocusManager.return_value = mock_manager

            focus = continue_work(workspace, token=None)

            assert isinstance(focus, FocusBundle)

    def test_pause_work_wrapper(self, workspace):
        """Test pause_work convenience wrapper."""
        from unittest.mock import patch, MagicMock
        from contextdigger.api import pause_work

        # Mock FocusManager
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()

            # Create a mock contract
            mock_contract = MagicMock()
            mock_contract.id = "contract-123"
            mock_contract.state = "paused"
            mock_contract.area_id = "test-area"
            mock_contract.description = "Test contract"
            mock_contract.created_at = "2025-01-01T00:00:00"
            mock_contract.updated_at = "2025-01-01T00:01:00"

            mock_manager.pause_work.return_value = mock_contract
            MockFocusManager.return_value = mock_manager

            contract = pause_work(workspace, token=None)

            assert isinstance(contract, ContractSummary)
            assert contract.id == "contract-123"
            assert contract.state == "paused"

    def test_dig_area_wrapper(self, workspace):
        """Test dig_area convenience wrapper."""
        from unittest.mock import patch, MagicMock

        # Create a test file
        test_file = workspace / "test.py"
        test_file.write_text("# test file\nprint('hello')\n")

        # Mock FocusManager
        with patch('contextdigger.api.FocusManager') as MockFocusManager:
            mock_manager = MagicMock()

            # Mock area exists
            mock_area = MagicMock()
            mock_area.id = "test-area"
            mock_area.name = "Test Area"
            mock_manager.get_area.return_value = mock_area

            # Mock current focus
            mock_manager.get_current_focus.return_value = "test-area"
            mock_manager.get_files_in_area.return_value = [test_file]
            mock_manager.load_config.return_value = {"budgets": {"max_files": 15, "max_lines": 3000}}

            MockFocusManager.return_value = mock_manager

            focus = dig_area(workspace, "test-area", token=None)

            assert isinstance(focus, FocusBundle)
            assert focus.area_id == "test-area"


class TestHelperMethods:
    """Test helper methods for 100% coverage."""

    @pytest.fixture
    def workspace(self):
        """Create temporary workspace."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)

            # Use FocusManager to properly initialize the workspace
            from contextdigger.manager import FocusManager
            manager = FocusManager(workspace)
            manager.initialize()

            yield workspace

    def test_count_lines_existing_file(self, workspace):
        """Test _count_lines with existing file."""
        api = ContextDiggerApi(workspace)

        # Create a test file with known line count
        test_file = workspace / "test.py"
        test_file.write_text("line1\nline2\nline3\n")

        line_count = api._count_lines(test_file)

        assert line_count == 3

    def test_count_lines_nonexistent_file(self, workspace):
        """Test _count_lines with nonexistent file."""
        api = ContextDiggerApi(workspace)

        nonexistent_file = workspace / "does_not_exist.py"

        line_count = api._count_lines(nonexistent_file)

        assert line_count == 0

    def test_count_lines_exception_handling(self, workspace):
        """Test _count_lines exception handling."""
        from unittest.mock import patch, MagicMock

        api = ContextDiggerApi(workspace)

        # Create a file
        test_file = workspace / "test.py"
        test_file.write_text("test")

        # Mock open to raise exception
        with patch('builtins.open') as mock_open:
            mock_open.side_effect = PermissionError("Access denied")

            line_count = api._count_lines(test_file)

            # Should return 0 on exception
            assert line_count == 0
