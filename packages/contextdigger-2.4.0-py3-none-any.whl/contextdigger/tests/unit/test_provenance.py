"""
Unit tests for provenance.py - File provenance tracking system.

Tests cover:
- ProvenanceReason dataclass
- FileProvenance dataclass
- ProvenanceTracker functionality
- Provenance persistence and querying
- Completeness calculations
"""

import pytest
import tempfile
import json
from pathlib import Path
from contextdigger.provenance import (
    ProvenanceReason,
    FileProvenance,
    ProvenanceTracker,
    REASON_ENTRY_POINT,
    REASON_DEPENDENCY,
    REASON_BOOKMARK,
    REASON_HISTORY,
    REASON_PATTERN_MATCH,
    REASON_USER_REQUEST,
)


# ============================================================================
# Test ProvenanceReason Dataclass
# ============================================================================


class TestProvenanceReason:
    """Test ProvenanceReason dataclass."""

    def test_basic_reason(self):
        """Test creating basic ProvenanceReason."""
        reason = ProvenanceReason(
            type="entry_point",
            description="Main API module"
        )

        assert reason.type == "entry_point"
        assert reason.description == "Main API module"
        assert reason.source is None
        assert reason.confidence == 1.0

    def test_full_reason(self):
        """Test ProvenanceReason with all fields."""
        reason = ProvenanceReason(
            type="dependency",
            description="Required by api.py",
            source="src/api.py",
            confidence=0.85
        )

        assert reason.type == "dependency"
        assert reason.description == "Required by api.py"
        assert reason.source == "src/api.py"
        assert reason.confidence == 0.85

    def test_to_dict(self):
        """Test converting ProvenanceReason to dict."""
        reason = ProvenanceReason(
            type="bookmark",
            description="User bookmarked",
            source="user",
            confidence=1.0
        )

        data = reason.to_dict()

        assert data["type"] == "bookmark"
        assert data["description"] == "User bookmarked"
        assert data["source"] == "user"
        assert data["confidence"] == 1.0

    def test_from_dict(self):
        """Test creating ProvenanceReason from dict."""
        data = {
            "type": "pattern_match",
            "description": "Matches test_*.py pattern",
            "source": "auto-discovery",
            "confidence": 0.9
        }

        reason = ProvenanceReason.from_dict(data)

        assert reason.type == "pattern_match"
        assert reason.description == "Matches test_*.py pattern"
        assert reason.source == "auto-discovery"
        assert reason.confidence == 0.9

    def test_from_dict_with_defaults(self):
        """Test creating ProvenanceReason from dict with missing optional fields."""
        data = {
            "type": "user_request",
            "description": "User requested this file"
        }

        reason = ProvenanceReason.from_dict(data)

        assert reason.type == "user_request"
        assert reason.description == "User requested this file"
        assert reason.source is None
        assert reason.confidence == 1.0

    def test_roundtrip_serialization(self):
        """Test ProvenanceReason can be serialized and deserialized."""
        original = ProvenanceReason(
            type="history",
            description="Previously loaded in session",
            source="session-123",
            confidence=0.75
        )

        data = original.to_dict()
        restored = ProvenanceReason.from_dict(data)

        assert restored.type == original.type
        assert restored.description == original.description
        assert restored.source == original.source
        assert restored.confidence == original.confidence


# ============================================================================
# Test FileProvenance Dataclass
# ============================================================================


class TestFileProvenance:
    """Test FileProvenance dataclass."""

    def test_basic_file_provenance(self):
        """Test creating basic FileProvenance."""
        reasons = [
            ProvenanceReason(type="entry_point", description="Main module")
        ]

        provenance = FileProvenance(
            file_path="src/api.py",
            reasons=reasons,
            loaded_by="dig",
            loaded_at="2025-01-15T10:00:00Z",
            session_id="session-001"
        )

        assert provenance.file_path == "src/api.py"
        assert len(provenance.reasons) == 1
        assert provenance.loaded_by == "dig"
        assert provenance.session_id == "session-001"
        assert provenance.area_id is None

    def test_file_provenance_with_area(self):
        """Test FileProvenance with area_id."""
        reasons = [
            ProvenanceReason(type="bookmark", description="User bookmark")
        ]

        provenance = FileProvenance(
            file_path="tests/test_api.py",
            reasons=reasons,
            loaded_by="export",
            loaded_at="2025-01-15T11:00:00Z",
            session_id="session-002",
            area_id="backend-api"
        )

        assert provenance.area_id == "backend-api"

    def test_file_provenance_multiple_reasons(self):
        """Test FileProvenance with multiple reasons."""
        reasons = [
            ProvenanceReason(type="entry_point", description="Main file"),
            ProvenanceReason(type="bookmark", description="User marked"),
            ProvenanceReason(type="dependency", description="Required by X")
        ]

        provenance = FileProvenance(
            file_path="src/models.py",
            reasons=reasons,
            loaded_by="dig",
            loaded_at="2025-01-15T12:00:00Z",
            session_id="session-003"
        )

        assert len(provenance.reasons) == 3
        assert provenance.reasons[0].type == "entry_point"
        assert provenance.reasons[1].type == "bookmark"
        assert provenance.reasons[2].type == "dependency"

    def test_to_dict(self):
        """Test converting FileProvenance to dict."""
        reasons = [
            ProvenanceReason(type="entry_point", description="Main")
        ]

        provenance = FileProvenance(
            file_path="src/app.py",
            reasons=reasons,
            loaded_by="dig",
            loaded_at="2025-01-15T13:00:00Z",
            session_id="session-004",
            area_id="frontend"
        )

        data = provenance.to_dict()

        assert data["file_path"] == "src/app.py"
        assert len(data["reasons"]) == 1
        assert data["reasons"][0]["type"] == "entry_point"
        assert data["loaded_by"] == "dig"
        assert data["session_id"] == "session-004"
        assert data["area_id"] == "frontend"

    def test_from_dict(self):
        """Test creating FileProvenance from dict."""
        data = {
            "file_path": "src/utils.py",
            "reasons": [
                {
                    "type": "dependency",
                    "description": "Used by app.py",
                    "source": "src/app.py",
                    "confidence": 0.9
                }
            ],
            "loaded_by": "export",
            "loaded_at": "2025-01-15T14:00:00Z",
            "session_id": "session-005",
            "area_id": "utils"
        }

        provenance = FileProvenance.from_dict(data)

        assert provenance.file_path == "src/utils.py"
        assert len(provenance.reasons) == 1
        assert provenance.reasons[0].type == "dependency"
        assert provenance.loaded_by == "export"
        assert provenance.session_id == "session-005"
        assert provenance.area_id == "utils"

    def test_roundtrip_serialization(self):
        """Test FileProvenance can be serialized and deserialized."""
        reasons = [
            ProvenanceReason(type="bookmark", description="Bookmarked", confidence=1.0),
            ProvenanceReason(type="history", description="Previous session", source="session-001")
        ]

        original = FileProvenance(
            file_path="tests/test_models.py",
            reasons=reasons,
            loaded_by="dig",
            loaded_at="2025-01-15T15:00:00Z",
            session_id="session-006",
            area_id="tests"
        )

        data = original.to_dict()
        restored = FileProvenance.from_dict(data)

        assert restored.file_path == original.file_path
        assert len(restored.reasons) == len(original.reasons)
        assert restored.loaded_by == original.loaded_by
        assert restored.session_id == original.session_id
        assert restored.area_id == original.area_id


# ============================================================================
# Test ProvenanceTracker
# ============================================================================


class TestProvenanceTracker:
    """Test ProvenanceTracker core functionality."""

    @pytest.fixture
    def temp_project_root(self):
        """Create temporary project root."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_init(self, temp_project_root):
        """Test ProvenanceTracker initialization."""
        tracker = ProvenanceTracker(temp_project_root)

        assert tracker.focus_root == temp_project_root
        assert tracker.provenance_dir == temp_project_root / ".cdg" / "provenance"
        assert tracker._provenance_cache == {}

    def test_ensure_provenance_dir(self, temp_project_root):
        """Test that provenance directory is created."""
        tracker = ProvenanceTracker(temp_project_root)

        tracker._ensure_provenance_dir()

        assert tracker.provenance_dir.exists()
        assert tracker.provenance_dir.is_dir()

    def test_track_file_load_new_file(self, temp_project_root):
        """Test tracking a new file load."""
        tracker = ProvenanceTracker(temp_project_root)

        tracker.track_file_load(
            file_path="src/api.py",
            reason_type="entry_point",
            description="Main API module",
            loaded_by="dig",
            session_id="session-001",
            area_id="backend-api"
        )

        # Check cache
        assert "session-001" in tracker._provenance_cache
        assert "src/api.py" in tracker._provenance_cache["session-001"]

        provenance = tracker._provenance_cache["session-001"]["src/api.py"]
        assert provenance.file_path == "src/api.py"
        assert len(provenance.reasons) == 1
        assert provenance.reasons[0].type == "entry_point"
        assert provenance.loaded_by == "dig"
        assert provenance.session_id == "session-001"
        assert provenance.area_id == "backend-api"

    def test_track_file_load_multiple_reasons(self, temp_project_root):
        """Test tracking multiple reasons for same file."""
        tracker = ProvenanceTracker(temp_project_root)

        # First reason
        tracker.track_file_load(
            file_path="src/models.py",
            reason_type="entry_point",
            description="Main module",
            loaded_by="dig",
            session_id="session-001"
        )

        # Second reason for same file
        tracker.track_file_load(
            file_path="src/models.py",
            reason_type="bookmark",
            description="User bookmarked",
            loaded_by="dig",
            session_id="session-001",
            source="user"
        )

        provenance = tracker._provenance_cache["session-001"]["src/models.py"]
        assert len(provenance.reasons) == 2
        assert provenance.reasons[0].type == "entry_point"
        assert provenance.reasons[1].type == "bookmark"
        assert provenance.reasons[1].source == "user"

    def test_track_file_load_with_confidence(self, temp_project_root):
        """Test tracking file load with confidence score."""
        tracker = ProvenanceTracker(temp_project_root)

        tracker.track_file_load(
            file_path="src/utils.py",
            reason_type="dependency",
            description="Inferred dependency",
            loaded_by="export",
            session_id="session-002",
            confidence=0.75
        )

        provenance = tracker._provenance_cache["session-002"]["src/utils.py"]
        assert provenance.reasons[0].confidence == 0.75

    def test_get_file_provenance_exists(self, temp_project_root):
        """Test getting provenance for existing file."""
        tracker = ProvenanceTracker(temp_project_root)

        tracker.track_file_load(
            file_path="src/api.py",
            reason_type="entry_point",
            description="Main",
            loaded_by="dig",
            session_id="session-003"
        )

        provenance = tracker.get_file_provenance("src/api.py", "session-003")

        assert provenance is not None
        assert provenance.file_path == "src/api.py"

    def test_get_file_provenance_not_exists(self, temp_project_root):
        """Test getting provenance for non-existent file."""
        tracker = ProvenanceTracker(temp_project_root)

        provenance = tracker.get_file_provenance("nonexistent.py", "session-999")

        assert provenance is None

    def test_get_session_provenance_with_files(self, temp_project_root):
        """Test getting all provenance for a session."""
        tracker = ProvenanceTracker(temp_project_root)

        # Track multiple files
        tracker.track_file_load(
            file_path="src/a.py",
            reason_type="entry_point",
            description="File A",
            loaded_by="dig",
            session_id="session-004"
        )

        tracker.track_file_load(
            file_path="src/b.py",
            reason_type="dependency",
            description="File B",
            loaded_by="dig",
            session_id="session-004"
        )

        tracker.track_file_load(
            file_path="src/c.py",
            reason_type="bookmark",
            description="File C",
            loaded_by="dig",
            session_id="session-004"
        )

        provenance_list = tracker.get_session_provenance("session-004")

        assert len(provenance_list) == 3
        file_paths = [p.file_path for p in provenance_list]
        assert "src/a.py" in file_paths
        assert "src/b.py" in file_paths
        assert "src/c.py" in file_paths

    def test_get_session_provenance_empty(self, temp_project_root):
        """Test getting provenance for non-existent session."""
        tracker = ProvenanceTracker(temp_project_root)

        provenance_list = tracker.get_session_provenance("session-999")

        assert provenance_list == []

    def test_save_session_provenance(self, temp_project_root):
        """Test saving session provenance to disk."""
        tracker = ProvenanceTracker(temp_project_root)

        tracker.track_file_load(
            file_path="src/api.py",
            reason_type="entry_point",
            description="API",
            loaded_by="dig",
            session_id="session-save"
        )

        tracker.save_session_provenance("session-save")

        # Check file was created
        provenance_file = tracker.provenance_dir / "session-session-save.json"
        assert provenance_file.exists()

        # Check contents
        with open(provenance_file) as f:
            data = json.load(f)

        assert data["session_id"] == "session-save"
        assert len(data["files"]) == 1
        assert data["files"][0]["file_path"] == "src/api.py"

    def test_save_session_provenance_nonexistent_session(self, temp_project_root):
        """Test saving provenance for non-existent session (should not crash)."""
        tracker = ProvenanceTracker(temp_project_root)

        # Should not crash
        tracker.save_session_provenance("nonexistent-session")

    def test_load_session_provenance(self, temp_project_root):
        """Test loading session provenance from disk."""
        tracker = ProvenanceTracker(temp_project_root)

        # Track and save
        tracker.track_file_load(
            file_path="src/models.py",
            reason_type="bookmark",
            description="Models",
            loaded_by="export",
            session_id="session-load",
            area_id="backend"
        )

        tracker.save_session_provenance("session-load")

        # Clear cache
        tracker._provenance_cache = {}

        # Load from disk
        tracker.load_session_provenance("session-load")

        # Verify loaded correctly
        assert "session-load" in tracker._provenance_cache
        assert "src/models.py" in tracker._provenance_cache["session-load"]

        provenance = tracker._provenance_cache["session-load"]["src/models.py"]
        assert provenance.file_path == "src/models.py"
        assert provenance.reasons[0].type == "bookmark"
        assert provenance.area_id == "backend"

    def test_load_session_provenance_nonexistent(self, temp_project_root):
        """Test loading non-existent session (should not crash)."""
        tracker = ProvenanceTracker(temp_project_root)

        # Should not crash
        tracker.load_session_provenance("nonexistent")

        assert "nonexistent" not in tracker._provenance_cache

    def test_get_provenance_completeness_full(self, temp_project_root):
        """Test provenance completeness with 100% coverage."""
        tracker = ProvenanceTracker(temp_project_root)

        # Track 3 files
        for i in range(3):
            tracker.track_file_load(
                file_path=f"src/file{i}.py",
                reason_type="entry_point",
                description=f"File {i}",
                loaded_by="dig",
                session_id="session-comp"
            )

        completeness = tracker.get_provenance_completeness("session-comp", total_files=3)

        assert completeness == 1.0

    def test_get_provenance_completeness_partial(self, temp_project_root):
        """Test provenance completeness with partial coverage."""
        tracker = ProvenanceTracker(temp_project_root)

        # Track 2 out of 5 files
        tracker.track_file_load(
            file_path="src/a.py",
            reason_type="entry_point",
            description="A",
            loaded_by="dig",
            session_id="session-partial"
        )

        tracker.track_file_load(
            file_path="src/b.py",
            reason_type="entry_point",
            description="B",
            loaded_by="dig",
            session_id="session-partial"
        )

        completeness = tracker.get_provenance_completeness("session-partial", total_files=5)

        assert completeness == 0.4  # 2/5

    def test_get_provenance_completeness_zero_files(self, temp_project_root):
        """Test provenance completeness with zero total files."""
        tracker = ProvenanceTracker(temp_project_root)

        completeness = tracker.get_provenance_completeness("session-empty", total_files=0)

        assert completeness == 1.0  # 100% of nothing is complete


# ============================================================================
# Test Provenance Constants
# ============================================================================


class TestProvenanceConstants:
    """Test provenance reason type constants."""

    def test_reason_constants(self):
        """Test that reason type constants are defined."""
        assert REASON_ENTRY_POINT == "entry_point"
        assert REASON_DEPENDENCY == "dependency"
        assert REASON_BOOKMARK == "bookmark"
        assert REASON_HISTORY == "history"
        assert REASON_PATTERN_MATCH == "pattern_match"
        assert REASON_USER_REQUEST == "user_request"


# ============================================================================
# Integration Tests
# ============================================================================


class TestProvenanceIntegration:
    """Integration tests for provenance tracking workflow."""

    @pytest.fixture
    def temp_project_root(self):
        """Create temporary project root."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_full_provenance_workflow(self, temp_project_root):
        """Test complete provenance tracking workflow."""
        tracker = ProvenanceTracker(temp_project_root)

        # 1. Track initial file load
        tracker.track_file_load(
            file_path="src/api.py",
            reason_type=REASON_ENTRY_POINT,
            description="Main API module",
            loaded_by="dig",
            session_id="workflow-session",
            area_id="backend-api"
        )

        # 2. Track dependency
        tracker.track_file_load(
            file_path="src/models.py",
            reason_type=REASON_DEPENDENCY,
            description="Required by api.py",
            loaded_by="dig",
            session_id="workflow-session",
            source="src/api.py",
            confidence=0.9
        )

        # 3. Track bookmark
        tracker.track_file_load(
            file_path="src/models.py",
            reason_type=REASON_BOOKMARK,
            description="User bookmarked",
            loaded_by="dig",
            session_id="workflow-session"
        )

        # 4. Get session provenance
        all_provenance = tracker.get_session_provenance("workflow-session")
        assert len(all_provenance) == 2  # 2 unique files

        # 5. Check models.py has 2 reasons
        models_prov = tracker.get_file_provenance("src/models.py", "workflow-session")
        assert len(models_prov.reasons) == 2

        # 6. Calculate completeness
        completeness = tracker.get_provenance_completeness("workflow-session", total_files=2)
        assert completeness == 1.0

        # 7. Save to disk
        tracker.save_session_provenance("workflow-session")

        # 8. Clear cache and reload
        tracker._provenance_cache = {}
        tracker.load_session_provenance("workflow-session")

        # 9. Verify loaded data
        loaded_prov = tracker.get_file_provenance("src/api.py", "workflow-session")
        assert loaded_prov is not None
        assert loaded_prov.area_id == "backend-api"

        loaded_models = tracker.get_file_provenance("src/models.py", "workflow-session")
        assert len(loaded_models.reasons) == 2
