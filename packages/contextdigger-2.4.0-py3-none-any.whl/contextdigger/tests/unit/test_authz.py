"""
Tests for contextdigger.authz module.

Tests cover:
- Permission and Tier enum behavior
- TokenInfo dataclass
- LocalFileAuthz token validation
- Default token creation
- Permission checking
- Token expiration
- Error handling
"""

import pytest
import json
import tempfile
from pathlib import Path
from datetime import datetime, timedelta

from contextdigger.authz import (
    Permission,
    Tier,
    TokenInfo,
    AuthzBackend,
    AuthzError,
    LocalFileAuthz,
    get_authz_backend
)


class TestPermissionEnum:
    """Test Permission enum."""

    def test_all_permissions_exist(self):
        """Test that all expected permissions are defined."""
        expected = {
            "read_areas", "read_config", "dig", "focus",
            "continuation", "bookmarks", "snapshots",
            "insights", "trends", "provenance",
            "reports", "export", "policy", "audit", "admin"
        }
        actual = {p.value for p in Permission}
        assert actual == expected

    def test_permission_values(self):
        """Test that permission values are correct."""
        assert Permission.READ_AREAS.value == "read_areas"
        assert Permission.DIG.value == "dig"
        assert Permission.ADMIN.value == "admin"


class TestTierEnum:
    """Test Tier enum and default permissions."""

    def test_all_tiers_exist(self):
        """Test that all tiers are defined."""
        expected = {"free", "team", "enterprise"}
        actual = {t.value for t in Tier}
        assert actual == expected

    def test_free_tier_permissions(self):
        """Test FREE tier has basic permissions."""
        perms = Tier.FREE.get_default_permissions()

        # Should have basic permissions
        assert Permission.READ_AREAS in perms
        assert Permission.DIG in perms
        assert Permission.FOCUS in perms
        assert Permission.CONTINUATION in perms
        assert Permission.INSIGHTS in perms

        # Should NOT have premium permissions
        assert Permission.TRENDS not in perms
        assert Permission.REPORTS not in perms
        assert Permission.POLICY not in perms
        assert Permission.ADMIN not in perms

    def test_team_tier_permissions(self):
        """Test TEAM tier has FREE + additional permissions."""
        free_perms = Tier.FREE.get_default_permissions()
        team_perms = Tier.TEAM.get_default_permissions()

        # Should include all FREE permissions
        assert free_perms.issubset(team_perms)

        # Should have additional permissions
        assert Permission.TRENDS in team_perms
        assert Permission.REPORTS in team_perms
        assert Permission.POLICY in team_perms
        assert Permission.AUDIT in team_perms

        # Should NOT have admin
        assert Permission.ADMIN not in team_perms

    def test_enterprise_tier_permissions(self):
        """Test ENTERPRISE tier has all permissions."""
        enterprise_perms = Tier.ENTERPRISE.get_default_permissions()
        all_perms = set(Permission)

        assert enterprise_perms == all_perms
        assert Permission.ADMIN in enterprise_perms

    def test_budget_multipliers(self):
        """Test tier budget multipliers."""
        assert Tier.FREE.get_budget_multiplier() == 1.0
        assert Tier.TEAM.get_budget_multiplier() == 2.0
        assert Tier.ENTERPRISE.get_budget_multiplier() == 5.0


class TestTokenInfo:
    """Test TokenInfo dataclass."""

    def test_token_info_creation(self):
        """Test creating TokenInfo."""
        token_info = TokenInfo(
            token="test-token",
            tier=Tier.FREE,
            permissions={Permission.READ_AREAS, Permission.DIG},
            subject="test-user"
        )

        assert token_info.token == "test-token"
        assert token_info.tier == Tier.FREE
        assert token_info.subject == "test-user"
        assert token_info.expires_at is None

    def test_token_info_with_expiration(self):
        """Test TokenInfo with expiration."""
        expires = datetime.now() + timedelta(days=30)
        token_info = TokenInfo(
            token="test-token",
            tier=Tier.TEAM,
            permissions=Tier.TEAM.get_default_permissions(),
            subject="test-user",
            expires_at=expires
        )

        assert token_info.expires_at == expires

    def test_has_permission(self):
        """Test has_permission method."""
        token_info = TokenInfo(
            token="test-token",
            tier=Tier.FREE,
            permissions={Permission.READ_AREAS, Permission.DIG},
            subject="test-user"
        )

        assert token_info.has_permission(Permission.READ_AREAS)
        assert token_info.has_permission(Permission.DIG)
        assert not token_info.has_permission(Permission.ADMIN)
        assert not token_info.has_permission(Permission.REPORTS)

    def test_token_info_is_frozen(self):
        """Test that TokenInfo is immutable."""
        token_info = TokenInfo(
            token="test-token",
            tier=Tier.FREE,
            permissions={Permission.READ_AREAS},
            subject="test-user"
        )

        with pytest.raises(AttributeError):
            token_info.token = "new-token"


class TestLocalFileAuthz:
    """Test LocalFileAuthz backend."""

    @pytest.fixture
    def temp_workspace(self):
        """Create temporary workspace with .cdg directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)
            cdg_dir = workspace / ".cdg"
            cdg_dir.mkdir()
            yield workspace

    @pytest.fixture
    def authz_backend(self, temp_workspace):
        """Create LocalFileAuthz backend."""
        return LocalFileAuthz(temp_workspace)

    def test_default_token_created(self, temp_workspace):
        """Test that default token is created on init."""
        backend = LocalFileAuthz(temp_workspace)
        tokens_file = temp_workspace / ".cdg" / "tokens.json"

        assert tokens_file.exists()

        with open(tokens_file, 'r') as f:
            data = json.load(f)

        assert "tokens" in data
        assert LocalFileAuthz.DEFAULT_TOKEN in data["tokens"]

        default_token_data = data["tokens"][LocalFileAuthz.DEFAULT_TOKEN]
        assert default_token_data["tier"] == "enterprise"
        assert default_token_data["subject"] == "local-dev"

    def test_validate_default_token(self, authz_backend):
        """Test validating the default token."""
        token_info = authz_backend.validate_token(LocalFileAuthz.DEFAULT_TOKEN)

        assert token_info.token == LocalFileAuthz.DEFAULT_TOKEN
        assert token_info.tier == Tier.ENTERPRISE
        assert token_info.subject == "local-dev"
        assert token_info.permissions == Tier.ENTERPRISE.get_default_permissions()

    def test_validate_custom_token(self, temp_workspace):
        """Test validating a custom token."""
        backend = LocalFileAuthz(temp_workspace)

        # Create custom token
        backend.create_token(
            token="custom-token-123",
            tier=Tier.TEAM,
            subject="team-user",
            description="Team user token"
        )

        # Validate it
        token_info = backend.validate_token("custom-token-123")

        assert token_info.token == "custom-token-123"
        assert token_info.tier == Tier.TEAM
        assert token_info.subject == "team-user"
        assert token_info.permissions == Tier.TEAM.get_default_permissions()

    def test_validate_token_with_explicit_permissions(self, temp_workspace):
        """Test token with explicit permission overrides."""
        backend = LocalFileAuthz(temp_workspace)

        # Create token with explicit permissions (subset of TEAM)
        custom_perms = {Permission.READ_AREAS, Permission.DIG}
        backend.create_token(
            token="restricted-token",
            tier=Tier.TEAM,
            subject="restricted-user",
            permissions=custom_perms
        )

        # Validate it
        token_info = backend.validate_token("restricted-token")

        assert token_info.permissions == custom_perms
        assert Permission.READ_AREAS in token_info.permissions
        assert Permission.DIG in token_info.permissions
        assert Permission.REPORTS not in token_info.permissions  # TEAM default, but not in explicit

    def test_invalid_token_raises_error(self, authz_backend):
        """Test that invalid token raises AuthzError."""
        with pytest.raises(AuthzError) as exc_info:
            authz_backend.validate_token("nonexistent-token")

        assert exc_info.value.code == "invalid_token"
        assert "not found" in exc_info.value.message.lower()

    def test_expired_token_raises_error(self, temp_workspace):
        """Test that expired token raises AuthzError."""
        backend = LocalFileAuthz(temp_workspace)
        tokens_file = temp_workspace / ".cdg" / "tokens.json"

        # Manually create expired token
        with open(tokens_file, 'r') as f:
            data = json.load(f)

        expired_time = datetime.now() - timedelta(days=1)
        data["tokens"]["expired-token"] = {
            "tier": "team",
            "subject": "expired-user",
            "expires_at": expired_time.isoformat()
        }

        with open(tokens_file, 'w') as f:
            json.dump(data, f)

        # Validate should raise error
        with pytest.raises(AuthzError) as exc_info:
            backend.validate_token("expired-token")

        assert exc_info.value.code == "expired_token"
        assert "expired" in exc_info.value.message.lower()

    def test_invalid_tier_raises_error(self, temp_workspace):
        """Test that invalid tier raises AuthzError."""
        backend = LocalFileAuthz(temp_workspace)
        tokens_file = temp_workspace / ".cdg" / "tokens.json"

        # Manually create token with invalid tier
        with open(tokens_file, 'r') as f:
            data = json.load(f)

        data["tokens"]["bad-tier-token"] = {
            "tier": "super-ultra-mega",  # Invalid tier
            "subject": "bad-user"
        }

        with open(tokens_file, 'w') as f:
            json.dump(data, f)

        # Validate should raise error
        with pytest.raises(AuthzError) as exc_info:
            backend.validate_token("bad-tier-token")

        assert exc_info.value.code == "configuration_error"
        assert "tier" in exc_info.value.message.lower()

    def test_invalid_permission_raises_error(self, temp_workspace):
        """Test that invalid permission raises AuthzError."""
        backend = LocalFileAuthz(temp_workspace)
        tokens_file = temp_workspace / ".cdg" / "tokens.json"

        # Manually create token with invalid permission
        with open(tokens_file, 'r') as f:
            data = json.load(f)

        data["tokens"]["bad-perm-token"] = {
            "tier": "team",
            "subject": "bad-user",
            "permissions": ["read_areas", "super_secret_permission"]
        }

        with open(tokens_file, 'w') as f:
            json.dump(data, f)

        # Validate should raise error
        with pytest.raises(AuthzError) as exc_info:
            backend.validate_token("bad-perm-token")

        assert exc_info.value.code == "configuration_error"
        assert "permission" in exc_info.value.message.lower()

    def test_missing_tokens_file_raises_error(self, temp_workspace):
        """Test that missing tokens.json (after delete) raises error."""
        backend = LocalFileAuthz(temp_workspace)
        tokens_file = temp_workspace / ".cdg" / "tokens.json"

        # Delete tokens file
        tokens_file.unlink()

        # Validate should raise error
        with pytest.raises(AuthzError) as exc_info:
            backend.validate_token("any-token")

        assert exc_info.value.code == "configuration_error"
        assert "failed to read" in exc_info.value.message.lower()

    def test_create_token_helper(self, temp_workspace):
        """Test create_token helper method."""
        backend = LocalFileAuthz(temp_workspace)

        # Create token
        backend.create_token(
            token="helper-test-token",
            tier=Tier.FREE,
            subject="helper-user",
            permissions={Permission.READ_AREAS, Permission.DIG},
            description="Test token created via helper"
        )

        # Verify it was created
        tokens_file = temp_workspace / ".cdg" / "tokens.json"
        with open(tokens_file, 'r') as f:
            data = json.load(f)

        assert "helper-test-token" in data["tokens"]
        token_data = data["tokens"]["helper-test-token"]
        assert token_data["tier"] == "free"
        assert token_data["subject"] == "helper-user"
        assert set(token_data["permissions"]) == {"read_areas", "dig"}
        assert token_data["description"] == "Test token created via helper"


class TestAuthzError:
    """Test AuthzError exception."""

    def test_authz_error_creation(self):
        """Test creating AuthzError."""
        error = AuthzError(
            code="test_error",
            message="Test error message",
            details="Additional details"
        )

        assert error.code == "test_error"
        assert error.message == "Test error message"
        assert error.details == "Additional details"
        assert str(error) == "Test error message"

    def test_authz_error_without_details(self):
        """Test AuthzError without details."""
        error = AuthzError(
            code="simple_error",
            message="Simple error"
        )

        assert error.code == "simple_error"
        assert error.message == "Simple error"
        assert error.details is None


class TestGetAuthzBackend:
    """Test get_authz_backend factory function."""

    def test_get_local_backend(self, tmp_path):
        """Test getting local file backend."""
        cdg_dir = tmp_path / ".cdg"
        cdg_dir.mkdir()

        backend = get_authz_backend(tmp_path, "local")

        assert isinstance(backend, LocalFileAuthz)
        assert backend.workspace == tmp_path

    def test_get_okta_backend_not_implemented(self, tmp_path):
        """Test that Okta backend raises NotImplementedError."""
        with pytest.raises(NotImplementedError):
            get_authz_backend(tmp_path, "okta")

    def test_get_chargebee_backend_not_implemented(self, tmp_path):
        """Test that Chargebee backend raises NotImplementedError."""
        with pytest.raises(NotImplementedError):
            get_authz_backend(tmp_path, "chargebee")

    def test_unknown_backend_type_raises_error(self, tmp_path):
        """Test that unknown backend type raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            get_authz_backend(tmp_path, "unknown-backend")

        assert "unknown backend type" in str(exc_info.value).lower()


class TestEdgeCases:
    """Test edge cases for improved coverage."""

    def test_invalid_expires_at_format(self, tmp_path):
        """Test that invalid expires_at format raises AuthzError."""
        cdg_dir = tmp_path / ".cdg"
        cdg_dir.mkdir()

        backend = LocalFileAuthz(tmp_path)
        tokens_file = tmp_path / ".cdg" / "tokens.json"

        # Manually create token with invalid expires_at format
        with open(tokens_file, 'r') as f:
            data = json.load(f)

        data["tokens"]["bad-expiry-token"] = {
            "tier": "free",
            "subject": "test-user",
            "expires_at": "not-a-valid-iso-date"  # Invalid format
        }

        with open(tokens_file, 'w') as f:
            json.dump(data, f)

        # Should raise AuthzError with configuration_error code
        with pytest.raises(AuthzError) as exc_info:
            backend.validate_token("bad-expiry-token")

        assert exc_info.value.code == "configuration_error"
        assert "iso 8601" in exc_info.value.message.lower()

    def test_okta_jwt_authz_not_implemented(self):
        """Test that OktaJwtAuthz raises NotImplementedError on instantiation."""
        from contextdigger.authz import OktaJwtAuthz

        with pytest.raises(NotImplementedError) as exc_info:
            OktaJwtAuthz(okta_domain="example.okta.com", client_id="test-client")

        assert "not yet implemented" in str(exc_info.value).lower()

    def test_chargebee_authz_not_implemented(self):
        """Test that ChargebeeAuthz raises NotImplementedError on instantiation."""
        from contextdigger.authz import ChargebeeAuthz

        with pytest.raises(NotImplementedError) as exc_info:
            ChargebeeAuthz(api_key="test-key", site="test-site")

        assert "not yet implemented" in str(exc_info.value).lower()


class TestAuthzIntegration:
    """Integration tests for authz flow."""

    @pytest.fixture
    def workspace_with_tokens(self, tmp_path):
        """Create workspace with multiple test tokens."""
        cdg_dir = tmp_path / ".cdg"
        cdg_dir.mkdir()

        backend = LocalFileAuthz(tmp_path)

        # Create various tokens
        backend.create_token(
            token="free-user",
            tier=Tier.FREE,
            subject="free-user-id",
            description="Free tier user"
        )

        backend.create_token(
            token="team-user",
            tier=Tier.TEAM,
            subject="team-user-id",
            description="Team tier user"
        )

        backend.create_token(
            token="enterprise-user",
            tier=Tier.ENTERPRISE,
            subject="enterprise-user-id",
            description="Enterprise tier user"
        )

        backend.create_token(
            token="restricted-user",
            tier=Tier.TEAM,
            subject="restricted-user-id",
            permissions={Permission.READ_AREAS, Permission.DIG},
            description="Restricted team user"
        )

        return tmp_path

    def test_permission_hierarchy(self, workspace_with_tokens):
        """Test that permission hierarchy works correctly."""
        backend = LocalFileAuthz(workspace_with_tokens)

        # FREE user
        free_info = backend.validate_token("free-user")
        assert free_info.has_permission(Permission.DIG)
        assert not free_info.has_permission(Permission.REPORTS)
        assert not free_info.has_permission(Permission.ADMIN)

        # TEAM user
        team_info = backend.validate_token("team-user")
        assert team_info.has_permission(Permission.DIG)
        assert team_info.has_permission(Permission.REPORTS)
        assert not team_info.has_permission(Permission.ADMIN)

        # ENTERPRISE user
        enterprise_info = backend.validate_token("enterprise-user")
        assert enterprise_info.has_permission(Permission.DIG)
        assert enterprise_info.has_permission(Permission.REPORTS)
        assert enterprise_info.has_permission(Permission.ADMIN)

    def test_explicit_permissions_override_tier(self, workspace_with_tokens):
        """Test that explicit permissions override tier defaults."""
        backend = LocalFileAuthz(workspace_with_tokens)

        restricted_info = backend.validate_token("restricted-user")

        # Should have explicitly granted permissions
        assert restricted_info.has_permission(Permission.READ_AREAS)
        assert restricted_info.has_permission(Permission.DIG)

        # Should NOT have other TEAM permissions
        assert not restricted_info.has_permission(Permission.REPORTS)
        assert not restricted_info.has_permission(Permission.TRENDS)
        assert not restricted_info.has_permission(Permission.ADMIN)
