"""
Unit tests for refusal.py - Context aperture management and budget enforcement.

Tests cover:
- RefusalReason enum
- RefusalResult dataclass (structured refusal responses)
- SubArea dataclass
- RefusalHandler core functionality
- Budget enforcement and sub-area suggestions
"""

import pytest
import tempfile
from pathlib import Path
from contextdigger.refusal import (
    RefusalReason,
    RefusalResult,
    SubArea,
    RefusalHandler,
)


# ============================================================================
# Test RefusalReason Enum
# ============================================================================


class TestRefusalReason:
    """Test RefusalReason enum values."""

    def test_budget_violation_codes(self):
        """Test budget violation reason codes."""
        assert RefusalReason.BUDGET_EXCEEDED.value == "budget_exceeded"
        assert RefusalReason.FILES_EXCEEDED.value == "files_exceeded"
        assert RefusalReason.LINES_EXCEEDED.value == "lines_exceeded"

    def test_policy_violation_codes(self):
        """Test policy violation reason codes."""
        assert RefusalReason.POLICY_VIOLATION.value == "policy_violation"
        assert RefusalReason.STRICT_MODE_VIOLATION.value == "strict_mode_violation"

    def test_configuration_error_codes(self):
        """Test configuration error reason codes."""
        assert RefusalReason.CONFIGURATION_ERROR.value == "configuration_error"
        assert RefusalReason.INVALID_BUDGET.value == "invalid_budget"
        assert RefusalReason.MISSING_POLICY.value == "missing_policy"

    def test_operation_error_codes(self):
        """Test operation error reason codes."""
        assert RefusalReason.AREA_NOT_FOUND.value == "area_not_found"
        assert RefusalReason.OPERATION_BLOCKED.value == "operation_blocked"
        assert RefusalReason.INVALID_STATE.value == "invalid_state"

    def test_permission_error_codes(self):
        """Test permission error reason codes."""
        assert RefusalReason.PERMISSION_DENIED.value == "permission_denied"
        assert RefusalReason.TOKEN_INVALID.value == "token_invalid"


# ============================================================================
# Test RefusalResult Dataclass
# ============================================================================


class TestRefusalResult:
    """Test RefusalResult structured response."""

    def test_basic_refusal_result(self):
        """Test creating basic RefusalResult."""
        result = RefusalResult(
            code=RefusalReason.BUDGET_EXCEEDED,
            message="Area exceeds budget"
        )

        assert result.code == RefusalReason.BUDGET_EXCEEDED
        assert result.message == "Area exceeds budget"
        assert result.details is None
        assert result.hint is None
        assert result.metadata is None

    def test_full_refusal_result(self):
        """Test RefusalResult with all fields."""
        result = RefusalResult(
            code=RefusalReason.FILES_EXCEEDED,
            message="Too many files",
            details="Found 25 files, limit is 15",
            hint="Try splitting into sub-areas",
            metadata={"files_count": 25, "limit": 15}
        )

        assert result.code == RefusalReason.FILES_EXCEEDED
        assert result.message == "Too many files"
        assert result.details == "Found 25 files, limit is 15"
        assert result.hint == "Try splitting into sub-areas"
        assert result.metadata["files_count"] == 25

    def test_str_representation(self):
        """Test string representation of RefusalResult."""
        result = RefusalResult(
            code=RefusalReason.BUDGET_EXCEEDED,
            message="Budget exceeded",
            details="20 files found",
            hint="Split into smaller areas"
        )

        str_repr = str(result)
        assert "Budget exceeded" in str_repr
        assert "Details: 20 files found" in str_repr
        assert "Hint: Split into smaller areas" in str_repr

    def test_to_dict(self):
        """Test converting RefusalResult to dict."""
        result = RefusalResult(
            code=RefusalReason.LINES_EXCEEDED,
            message="Too many lines",
            details="5000 lines",
            hint="Focus on specific module"
        )

        data = result.to_dict()

        assert data["code"] == "lines_exceeded"
        assert data["message"] == "Too many lines"
        assert data["details"] == "5000 lines"
        assert data["hint"] == "Focus on specific module"

    def test_from_dict(self):
        """Test creating RefusalResult from dict."""
        data = {
            "code": "policy_violation",
            "message": "Policy violated",
            "details": "Strict mode active",
            "hint": "Review policy settings",
            "metadata": {"policy_id": "test"}
        }

        result = RefusalResult.from_dict(data)

        assert result.code == RefusalReason.POLICY_VIOLATION
        assert result.message == "Policy violated"
        assert result.details == "Strict mode active"
        assert result.hint == "Review policy settings"
        assert result.metadata["policy_id"] == "test"

    def test_roundtrip_serialization(self):
        """Test RefusalResult can be serialized and deserialized."""
        original = RefusalResult(
            code=RefusalReason.CONFIGURATION_ERROR,
            message="Config error",
            details="Missing key",
            hint="Check config file"
        )

        data = original.to_dict()
        restored = RefusalResult.from_dict(data)

        assert restored.code == original.code
        assert restored.message == original.message
        assert restored.details == original.details
        assert restored.hint == original.hint


# ============================================================================
# Test SubArea Dataclass
# ============================================================================


class TestSubArea:
    """Test SubArea dataclass for split suggestions."""

    def test_basic_sub_area(self):
        """Test creating basic SubArea."""
        files = [Path("/project/src/module/file1.py")]

        sub_area = SubArea(
            name="backend-api",
            path="src/api",
            file_count=5,
            line_count=500,
            description="API module",
            files=files
        )

        assert sub_area.name == "backend-api"
        assert sub_area.path == "src/api"
        assert sub_area.file_count == 5
        assert sub_area.line_count == 500
        assert sub_area.description == "API module"
        assert len(sub_area.files) == 1

    def test_sub_area_with_defaults(self):
        """Test SubArea with default values."""
        sub_area = SubArea(
            name="test",
            path="tests/",
            file_count=3,
            line_count=300,
            description="Test files",
            files=[]
        )

        assert sub_area.strategy == "directory"
        assert sub_area.confidence == 1.0
        assert sub_area.sample_files == []
        assert sub_area.patterns == {}
        assert sub_area.metadata == {}
        assert sub_area.related_areas == []

    def test_sub_area_with_custom_fields(self):
        """Test SubArea with custom strategy and metadata."""
        sub_area = SubArea(
            name="utils",
            path="src/utils",
            file_count=8,
            line_count=800,
            description="Utility functions",
            files=[],
            strategy="pattern",
            confidence=0.85,
            sample_files=["utils.py", "helpers.py"],
            patterns={"naming": ["util_*", "helper_*"]},
            metadata={"primary_function": "utilities"},
            related_areas=["core", "services"]
        )

        assert sub_area.strategy == "pattern"
        assert sub_area.confidence == 0.85
        assert len(sub_area.sample_files) == 2
        assert "naming" in sub_area.patterns
        assert sub_area.metadata["primary_function"] == "utilities"
        assert "core" in sub_area.related_areas


# ============================================================================
# Test RefusalHandler
# ============================================================================


class TestRefusalHandler:
    """Test RefusalHandler core functionality."""

    def test_init_defaults(self):
        """Test RefusalHandler with default values."""
        handler = RefusalHandler()

        assert handler.max_files == 15
        assert handler.max_lines == 3000

    def test_init_custom_values(self):
        """Test RefusalHandler with custom budget."""
        handler = RefusalHandler(max_files=20, max_lines=5000)

        assert handler.max_files == 20
        assert handler.max_lines == 5000

    def test_format_refusal_message_files_exceeded(self):
        """Test formatting refusal message for files exceeded."""
        handler = RefusalHandler(max_files=15, max_lines=3000)

        message = handler.format_refusal_message(
            area_name="backend-api",
            files_used=25,
            lines_used=2000
        )

        assert "Context Aperture Exceeded" in message
        assert "backend-api" in message
        assert "25 files" in message
        assert "f/15" in message

    def test_format_refusal_message_lines_exceeded(self):
        """Test formatting refusal message for lines exceeded."""
        handler = RefusalHandler(max_files=15, max_lines=3000)

        message = handler.format_refusal_message(
            area_name="frontend-components",
            files_used=10,
            lines_used=5000
        )

        assert "Context Aperture Exceeded" in message
        assert "frontend-components" in message
        assert "5,000 lines" in message
        assert "3,000 lines maximum" in message

    def test_count_lines(self):
        """Test _count_lines helper method."""
        handler = RefusalHandler()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test.py"
            test_file.write_text("line1\nline2\nline3\nline4\nline5\n")

            line_count = handler._count_lines(test_file)

            assert line_count == 5

    def test_count_lines_empty_file(self):
        """Test _count_lines with empty file."""
        handler = RefusalHandler()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            empty_file = tmpdir / "empty.py"
            empty_file.write_text("")

            line_count = handler._count_lines(empty_file)

            assert line_count == 0

    def test_count_lines_nonexistent_file(self):
        """Test _count_lines with nonexistent file."""
        handler = RefusalHandler()

        line_count = handler._count_lines(Path("/nonexistent/file.py"))

        assert line_count == 0

    def test_suggest_sub_areas(self):
        """Test suggesting sub-areas by directory."""
        handler = RefusalHandler(max_files=5, max_lines=500)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create directory structure
            (project_root / "src" / "api").mkdir(parents=True)
            (project_root / "src" / "models").mkdir(parents=True)

            # Create files in different directories
            api_files = []
            for i in range(3):
                f = project_root / "src" / "api" / f"file{i}.py"
                f.write_text("line\n" * 10)
                api_files.append(f)

            model_files = []
            for i in range(4):
                f = project_root / "src" / "models" / f"model{i}.py"
                f.write_text("line\n" * 20)
                model_files.append(f)

            all_files = api_files + model_files

            sub_areas = handler.suggest_sub_areas(
                files=all_files,
                area_name="backend",
                project_root=project_root
            )

            # Should have 2 sub-areas (api and models)
            assert len(sub_areas) > 0

            # Check that sub-areas fit within budget
            for sub_area in sub_areas:
                assert sub_area.file_count <= handler.max_files

    def test_format_sub_area_suggestions(self):
        """Test formatting sub-area suggestions."""
        handler = RefusalHandler()

        sub_areas = [
            SubArea(
                name="backend-api",
                path="src/api",
                file_count=5,
                line_count=500,
                description="API endpoints",
                files=[]
            ),
            SubArea(
                name="backend-models",
                path="src/models",
                file_count=8,
                line_count=800,
                description="Data models",
                files=[]
            )
        ]

        formatted = handler.format_sub_area_suggestions(sub_areas)

        assert "backend-api" in formatted
        assert "backend-models" in formatted
        assert "5 files" in formatted
        assert "8 files" in formatted

    def test_format_options(self):
        """Test formatting refusal options."""
        handler = RefusalHandler()

        options = handler.format_options(files_used=25, lines_used=5000)

        assert "Options" in options or "options" in options.lower()

    def test_create_refusal_result_files_exceeded(self):
        """Test creating RefusalResult for files exceeded."""
        handler = RefusalHandler(max_files=15, max_lines=3000)

        result = handler.create_refusal_result(
            area_name="backend-api",
            files_used=25,
            lines_used=2000,
            sub_areas=[]
        )

        assert isinstance(result, RefusalResult)
        assert result.code == RefusalReason.FILES_EXCEEDED
        assert "25" in result.message or "25" in str(result.details or "")

    def test_create_refusal_result_lines_exceeded(self):
        """Test creating RefusalResult for lines exceeded."""
        handler = RefusalHandler(max_files=15, max_lines=3000)

        result = handler.create_refusal_result(
            area_name="frontend",
            files_used=10,
            lines_used=5000,
            sub_areas=[]
        )

        assert isinstance(result, RefusalResult)
        assert result.code == RefusalReason.LINES_EXCEEDED
        # Check details contains the line count (formatted with comma)
        assert result.details is not None
        assert "5,000" in result.details or "10" in result.details

    def test_create_refusal_result_both_exceeded(self):
        """Test creating RefusalResult when both files and lines exceeded."""
        handler = RefusalHandler(max_files=15, max_lines=3000)

        result = handler.create_refusal_result(
            area_name="large-area",
            files_used=25,
            lines_used=5000,
            sub_areas=[]
        )

        assert isinstance(result, RefusalResult)
        # When both are exceeded, uses BUDGET_EXCEEDED
        assert result.code == RefusalReason.BUDGET_EXCEEDED
        # Details should contain both file and line counts
        assert result.details is not None
        assert "25" in result.details
        assert "5,000" in result.details


# ============================================================================
# Integration Tests
# ============================================================================


class TestRefusalIntegration:
    """Integration tests for refusal handling workflow."""

    def test_full_refusal_workflow(self):
        """Test complete refusal workflow."""
        handler = RefusalHandler(max_files=5, max_lines=500)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create oversized area
            (project_root / "src" / "api").mkdir(parents=True)
            (project_root / "src" / "models").mkdir(parents=True)

            files = []
            for i in range(3):
                f = project_root / "src" / "api" / f"api{i}.py"
                f.write_text("line\n" * 50)
                files.append(f)

            for i in range(4):
                f = project_root / "src" / "models" / f"model{i}.py"
                f.write_text("line\n" * 50)
                files.append(f)

            # 1. Check if exceeds budget
            total_files = len(files)
            total_lines = sum(handler._count_lines(f) for f in files)

            assert total_files > handler.max_files

            # 2. Suggest sub-areas
            sub_areas = handler.suggest_sub_areas(
                files=files,
                area_name="backend",
                project_root=project_root
            )

            assert len(sub_areas) > 0

            # 3. Create refusal result
            result = handler.create_refusal_result(
                area_name="backend",
                files_used=total_files,
                lines_used=total_lines,
                sub_areas=sub_areas
            )

            assert isinstance(result, RefusalResult)
            assert result.code in [RefusalReason.FILES_EXCEEDED, RefusalReason.LINES_EXCEEDED]

            # 4. Format message
            message = handler.format_refusal_message(
                area_name="backend",
                files_used=total_files,
                lines_used=total_lines
            )

            assert "backend" in message
            assert "Context Aperture" in message


# ============================================================================
# Additional Tests for Coverage
# ============================================================================


class TestFormatMethods:
    """Test formatting methods edge cases."""

    def test_format_sub_area_suggestions_empty_list(self):
        """Test format_sub_area_suggestions with empty list."""
        handler = RefusalHandler()

        formatted = handler.format_sub_area_suggestions([])

        assert "No suitable sub-areas found" in formatted

    def test_display_refusal(self, capsys):
        """Test display_refusal prints all components."""
        handler = RefusalHandler(max_files=5, max_lines=500)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            (project_root / "src").mkdir()

            files = []
            for i in range(7):
                f = project_root / "src" / f"file{i}.py"
                f.write_text("line\n" * 50)
                files.append(f)

            handler.display_refusal(
                area_name="test-area",
                files=files,
                files_used=7,
                lines_used=350,
                project_root=project_root
            )

            captured = capsys.readouterr()
            assert "Context Aperture" in captured.out
            assert "test-area" in captured.out

    def test_count_lines_with_unicode(self):
        """Test _count_lines with unicode characters."""
        handler = RefusalHandler()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            unicode_file = tmpdir / "unicode.py"
            unicode_file.write_text("# -*- coding: utf-8 -*-\n# 日本語\nprint('hello')\n", encoding='utf-8')

            line_count = handler._count_lines(unicode_file)

            assert line_count == 3

    def test_count_lines_with_binary_file(self):
        """Test _count_lines with binary file (should handle gracefully)."""
        handler = RefusalHandler()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            binary_file = tmpdir / "image.png"
            binary_file.write_bytes(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR')

            # Should return 0 or handle gracefully
            line_count = handler._count_lines(binary_file)

            # Binary files might return a count, just verify no exception
            assert line_count >= 0


class TestSubAreaSuggestions:
    """Test sub-area suggestion edge cases."""

    def test_suggest_sub_areas_with_exception_in_count(self):
        """Test suggest_sub_areas handles file reading errors gracefully."""
        handler = RefusalHandler(max_files=10, max_lines=1000)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            (project_root / "src").mkdir()

            # Create a file that exists
            f1 = project_root / "src" / "valid.py"
            f1.write_text("line\n" * 10)

            # Reference a file that will be deleted (simulating read error)
            f2 = project_root / "src" / "deleted.py"
            f2.write_text("line\n" * 10)

            files = [f1, f2]

            # Delete f2 to cause read error
            f2.unlink()

            # Should handle gracefully and not crash
            sub_areas = handler.suggest_sub_areas(
                files=files,
                area_name="test",
                project_root=project_root
            )

            # Should still return sub-areas for valid files
            assert isinstance(sub_areas, list)

    def test_suggest_sub_areas_filters_oversized(self):
        """Test that suggest_sub_areas filters out directories exceeding budget."""
        handler = RefusalHandler(max_files=3, max_lines=300)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create small directory (should be included)
            (project_root / "small").mkdir()
            small_files = []
            for i in range(2):
                f = project_root / "small" / f"file{i}.py"
                f.write_text("line\n" * 10)
                small_files.append(f)

            # Create large directory (should be filtered out)
            (project_root / "large").mkdir()
            large_files = []
            for i in range(5):
                f = project_root / "large" / f"file{i}.py"
                f.write_text("line\n" * 10)
                large_files.append(f)

            all_files = small_files + large_files

            sub_areas = handler.suggest_sub_areas(
                files=all_files,
                area_name="test",
                project_root=project_root
            )

            # Should only have "small" sub-area
            sub_area_names = [sa.name for sa in sub_areas]
            assert any("small" in name for name in sub_area_names)
            # Large directory should be filtered out (more than 3 files)
            assert not any("large" in sa.name and len(sa.files) > 3 for sa in sub_areas)


class TestRefusalResultEdgeCases:
    """Test RefusalResult edge cases."""

    def test_refusal_result_with_none_metadata(self):
        """Test RefusalResult handles None metadata correctly."""
        result = RefusalResult(
            code=RefusalReason.AREA_NOT_FOUND,
            message="Area not found"
        )

        data = result.to_dict()

        assert data["metadata"] is None

    def test_refusal_result_from_dict_minimal(self):
        """Test creating RefusalResult from minimal dict."""
        data = {
            "code": "invalid_state",
            "message": "Invalid state"
        }

        result = RefusalResult.from_dict(data)

        assert result.code == RefusalReason.INVALID_STATE
        assert result.message == "Invalid state"
        assert result.details is None
        assert result.hint is None
        assert result.metadata is None

    def test_str_without_details_or_hint(self):
        """Test __str__ when details and hint are None."""
        result = RefusalResult(
            code=RefusalReason.OPERATION_BLOCKED,
            message="Operation blocked"
        )

        str_repr = str(result)

        assert str_repr == "Operation blocked"
        assert "Details:" not in str_repr
        assert "Hint:" not in str_repr


class TestUtilityFunctions:
    """Test utility functions."""

    def test_should_refuse_files_exceeded(self):
        """Test should_refuse when files exceeded."""
        from contextdigger.refusal import should_refuse

        result = should_refuse(
            files_used=20,
            lines_used=2000,
            max_files=15,
            max_lines=3000
        )

        assert result is True

    def test_should_refuse_lines_exceeded(self):
        """Test should_refuse when lines exceeded."""
        from contextdigger.refusal import should_refuse

        result = should_refuse(
            files_used=10,
            lines_used=5000,
            max_files=15,
            max_lines=3000
        )

        assert result is True

    def test_should_refuse_both_exceeded(self):
        """Test should_refuse when both limits exceeded."""
        from contextdigger.refusal import should_refuse

        result = should_refuse(
            files_used=20,
            lines_used=5000,
            max_files=15,
            max_lines=3000
        )

        assert result is True

    def test_should_refuse_within_budget(self):
        """Test should_refuse when within budget."""
        from contextdigger.refusal import should_refuse

        result = should_refuse(
            files_used=10,
            lines_used=2000,
            max_files=15,
            max_lines=3000
        )

        assert result is False


class TestEdgeCases:
    """Test edge cases and exception handling."""

    def test_suggest_sub_areas_with_file_outside_project_root(self):
        """Test suggest_sub_areas with file outside project root (ValueError path)."""
        handler = RefusalHandler(max_files=10, max_lines=1000)

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            # Create a file outside project root
            outside_file = Path(tmpdir) / "outside.py"
            outside_file.write_text("line\n" * 10)

            # Create a file inside project root
            inside_dir = project_root / "src"
            inside_dir.mkdir()
            inside_file = inside_dir / "inside.py"
            inside_file.write_text("line\n" * 10)

            files = [outside_file, inside_file]

            # Should handle ValueError gracefully
            sub_areas = handler.suggest_sub_areas(
                files=files,
                area_name="test",
                project_root=project_root
            )

            # Should still work despite ValueError for outside_file
            assert isinstance(sub_areas, list)

    def test_create_refusal_result_with_sub_areas(self):
        """Test create_refusal_result includes sub_areas in metadata."""
        handler = RefusalHandler()

        sub_areas = [
            SubArea(
                name="sub1",
                path="src/sub1",
                file_count=5,
                line_count=500,
                description="Sub area 1",
                files=[]
            ),
            SubArea(
                name="sub2",
                path="src/sub2",
                file_count=8,
                line_count=800,
                description="Sub area 2",
                files=[]
            )
        ]

        result = handler.create_refusal_result(
            area_name="main",
            files_used=20,
            lines_used=4000,
            sub_areas=sub_areas
        )

        assert result.metadata is not None
        assert "sub_areas" in result.metadata
        assert len(result.metadata["sub_areas"]) == 2
        assert result.metadata["sub_areas"][0]["name"] == "sub1"
        assert result.metadata["sub_areas"][1]["file_count"] == 8

    def test_count_lines_permission_error(self, monkeypatch):
        """Test _count_lines handles permission errors."""
        handler = RefusalHandler()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            protected_file = tmpdir / "protected.py"
            protected_file.write_text("line1\nline2\n")

            # Mock open to raise PermissionError
            import builtins
            original_open = builtins.open

            def mock_open(*args, **kwargs):
                if "protected.py" in str(args[0]):
                    raise PermissionError("Access denied")
                return original_open(*args, **kwargs)

            monkeypatch.setattr("builtins.open", mock_open)

            # Should return 0 on permission error
            line_count = handler._count_lines(protected_file)

            assert line_count == 0
