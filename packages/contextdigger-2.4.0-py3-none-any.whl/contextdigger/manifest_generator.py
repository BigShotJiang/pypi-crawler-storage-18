"""
Command Manifest Generator

Introspects codebase to generate a unified command manifest mapping:
- CLI commands (cli.py)
- MCP tools (mcp_server.py)
- Slash commands (website documentation)
- Skills (claude-skills/*.md)

This establishes the single source of truth for ContextDigger's command surface.
"""

import sys
import ast
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from datetime import datetime


# Category definitions (based on CLI structure)
CATEGORIES = [
    {"id": "core_navigation", "name": "Core Navigation", "description": "Primary navigation and discovery commands", "order": 1},
    {"id": "subarea_management", "name": "Sub-Area Management", "description": "Split and manage sub-areas", "order": 2},
    {"id": "bookmarks", "name": "Bookmarks", "description": "Save and navigate to bookmarks", "order": 3},
    {"id": "context_snapshots", "name": "Context Snapshots", "description": "Save and restore context snapshots", "order": 4},
    {"id": "notes_documentation", "name": "Notes & Documentation", "description": "Add notes and generate docs", "order": 5},
    {"id": "analysis_intelligence", "name": "Analysis & Intelligence", "description": "Code analysis and insights", "order": 6},
    {"id": "search_query", "name": "Search & Query", "description": "Search and query capabilities", "order": 7},
    {"id": "automation", "name": "Automation", "description": "Automation rules and suggestions", "order": 8},
    {"id": "reports_export", "name": "Reports & Export", "description": "Generate reports and export data", "order": 9},
    {"id": "dashboard_monitoring", "name": "Dashboard & Monitoring", "description": "Dashboards and health monitoring", "order": 10},
    {"id": "team", "name": "Team Collaboration", "description": "Team features and test coverage", "order": 11},
    {"id": "continuation_contracts", "name": "Continuation Contracts", "description": "Multi-session work contracts", "order": 12},
    {"id": "budget_governance", "name": "Budget & Governance", "description": "Budget policies and audit logs", "order": 13},
    {"id": "llm_integration", "name": "LLM Integration", "description": "Local LLM integration", "order": 14},
]

# Manual command categorization (based on CLI structure)
COMMAND_CATEGORIES = {
    # Core Navigation
    "init": "core_navigation",
    "dig": "core_navigation",
    "redig": "core_navigation",
    "status": "core_navigation",
    "back": "core_navigation",
    "forward": "core_navigation",
    "history": "core_navigation",
    "list": "core_navigation",

    # Sub-Area Management
    "split": "subarea_management",
    "create-subarea": "subarea_management",

    # Bookmarks
    "mark-spot": "bookmarks",
    "goto-spot": "bookmarks",
    "list-spots": "bookmarks",
    "delete-spot": "bookmarks",

    # Context Snapshots
    "save-context": "context_snapshots",
    "load-context": "context_snapshots",
    "list-contexts": "context_snapshots",
    "delete-context": "context_snapshots",

    # Notes & Documentation
    "note": "notes_documentation",
    "notes": "notes_documentation",
    "wiki": "notes_documentation",

    # Analysis & Intelligence
    "suggest": "analysis_intelligence",
    "deps": "analysis_intelligence",
    "impact": "analysis_intelligence",
    "map": "analysis_intelligence",
    "hotspots": "analysis_intelligence",
    "gaps": "analysis_intelligence",
    "perf": "analysis_intelligence",
    "benchmark": "analysis_intelligence",
    "insights": "analysis_intelligence",
    "trends": "analysis_intelligence",
    "predictions": "analysis_intelligence",
    "remediate": "analysis_intelligence",

    # Search & Query
    "search": "search_query",
    "query": "search_query",

    # Automation
    "auto": "automation",
    "rules": "automation",

    # Reports & Export
    "analytics": "reports_export",
    "report": "reports_export",
    "export": "reports_export",
    "backup": "reports_export",
    "provenance": "reports_export",

    # Dashboard & Monitoring
    "dashboard": "dashboard_monitoring",
    "health": "dashboard_monitoring",
    "stats": "dashboard_monitoring",

    # Team
    "team": "team",
    "tests": "team",

    # Continuation Contracts
    "continue": "continuation_contracts",
    "pause": "continuation_contracts",
    "contracts": "continuation_contracts",

    # Budget Governance
    "policy": "budget_governance",
    "audit": "budget_governance",

    # LLM Integration
    "llm": "llm_integration",
}

# CLI to MCP tool name mapping
CLI_TO_MCP = {
    "init": "init_project",
    "dig": "dig_area",
    "redig": None,  # No direct MCP equivalent (interactive)
    "status": "show_status",
    "back": "navigate_back",
    "forward": "navigate_forward",
    "history": "show_history",
    "list": "list_areas",

    "split": "split_area",
    "create-subarea": "create_subarea",

    "mark-spot": "create_bookmark",
    "goto-spot": "goto_bookmark",
    "list-spots": "list_bookmarks",
    "delete-spot": "delete_bookmark",

    "save-context": "save_context",
    "load-context": "load_context",
    "list-contexts": "list_contexts",
    "delete-context": "delete_context",

    "note": "add_note",
    "notes": "show_notes",
    "wiki": "generate_wiki",

    "suggest": "suggest_areas",
    "deps": "show_dependencies",
    "impact": "analyze_impact",
    "map": "show_map",
    "hotspots": "find_hotspots",
    "gaps": "find_gaps",
    "perf": "analyze_performance",
    "benchmark": "run_benchmark",
    "insights": "show_insights",
    "trends": "show_trends",
    "predictions": "show_predictions",
    "remediate": "get_remediation",

    "search": "search_all",
    "query": "run_query",

    "auto": "show_automation",
    "rules": "list_rules",

    "analytics": "show_analytics",
    "report": "generate_report",
    "export": "export_context",
    "backup": "create_backup",
    "provenance": "show_provenance",

    "dashboard": "show_dashboard",
    "health": "check_health",
    "stats": "show_stats",

    "team": "show_team_activity",
    "tests": "show_test_coverage",

    "continue": "continue_work",
    "pause": "pause_work",
    "contracts": "list_contracts",

    "policy": "manage_policy",
    "audit": "show_audit",

    "llm": "manage_llm",
}

# CLI to slash command mapping
CLI_TO_SLASH = {
    "init": "/init-dig",
    "dig": "/dig",
    "redig": "/redig",
    "status": "/dig-status",
    "back": "/dig-back",
    "forward": "/dig-forward",
    "history": "/dig-history",
    "list": "/dig-tree",

    "split": "/dig-split",
    "create-subarea": "/create-subarea",

    "mark-spot": "/mark-spot",
    "goto-spot": "/goto-spot",
    "list-spots": "/list-spots",
    "delete-spot": "/delete-spot",

    "save-context": "/dig-snapshot",
    "load-context": "/dig-load",
    "list-contexts": "/dig-recent",
    "delete-context": "/delete-context",

    "note": "/dig-note",
    "notes": "/dig-notes",
    "wiki": "/dig-wiki",

    "suggest": "/dig-suggest",
    "deps": "/dig-deps",
    "impact": "/dig-impact",
    "map": "/dig-map",
    "hotspots": "/dig-hotspots",
    "gaps": "/dig-gaps",
    "perf": "/dig-perf",
    "benchmark": "/dig-benchmark",
    "insights": "/dig-insights",
    "trends": "/dig-trends",
    "predictions": "/dig-predictions",
    "remediate": "/dig-remediate",

    "search": "/dig-search",
    "query": "/dig-query",

    "auto": "/dig-auto",
    "rules": "/dig-rules",

    "analytics": "/dig-analytics",
    "report": "/dig-report",
    "export": "/dig-export",
    "backup": "/dig-backup",
    "provenance": "/dig-provenance",

    "dashboard": "/dig-dashboard",
    "health": "/dig-health",
    "stats": "/dig-stats",

    "team": "/dig-team",
    "tests": "/dig-tests",

    "continue": "/dig-continue",
    "pause": "/dig-pause",
    "contracts": "/dig-contracts",

    "policy": "/dig-policy",
    "audit": "/dig-audit",

    "llm": "/dig-llm",
}


class ManifestGenerator:
    """Generates command manifest from codebase introspection."""

    def __init__(self, contextdigger_root: Path):
        """Initialize generator with ContextDigger root directory."""
        self.root = contextdigger_root
        self.cli_path = self.root / "contextdigger" / "cli.py"
        self.mcp_path = self.root / "contextdigger" / "mcp_server.py"
        self.skills_path = self.root / "claude-skills"

    def generate(self) -> Dict:
        """Generate complete command manifest."""
        print("🔍 Parsing CLI commands...", file=sys.stderr)
        cli_commands = self.parse_cli_commands()

        print("🔍 Parsing MCP tools...", file=sys.stderr)
        mcp_tools = self.parse_mcp_tools()

        print("🔍 Scanning skill files...", file=sys.stderr)
        skills = self.scan_skills()

        print("🔧 Building unified manifest...", file=sys.stderr)
        manifest = self.build_manifest(cli_commands, mcp_tools, skills)

        print(f"✅ Generated manifest with {len(manifest['commands'])} commands", file=sys.stderr)
        return manifest

    def parse_cli_commands(self) -> Dict[str, Dict]:
        """Parse CLI commands from cli.py."""
        commands = {}

        with open(self.cli_path, 'r') as f:
            content = f.read()

        # Find the commands dict
        tree = ast.parse(content)

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == 'commands':
                        if isinstance(node.value, ast.Dict):
                            for key, value in zip(node.value.keys, node.value.values):
                                if isinstance(key, ast.Constant):
                                    cmd_name = key.value
                                    func_name = None

                                    if isinstance(value, ast.Name):
                                        func_name = value.id
                                    elif isinstance(value, ast.Attribute):
                                        func_name = value.attr

                                    # Skip special commands
                                    if cmd_name in ['--help', '-h', 'help', '--version']:
                                        continue

                                    # Determine if it's an alias
                                    is_alias = cmd_name in ['dig-status', 'list']

                                    if not is_alias:
                                        commands[cmd_name] = {
                                            'name': cmd_name,
                                            'function': func_name,
                                            'aliases': [],
                                            'implemented': True
                                        }

        # Add aliases
        commands['status']['aliases'].append('dig-status')

        return commands

    def parse_mcp_tools(self) -> Dict[str, Dict]:
        """Parse MCP tool definitions from mcp_server.py."""
        tools = {}

        with open(self.mcp_path, 'r') as f:
            content = f.read()

        # Find tool definitions in list_tools() method
        # Look for patterns like: "tool_name": {"description": "...", ...}

        # For now, use the documented tool list from header
        # TODO: Parse actual tool definitions from list_tools() method
        documented_tools = [
            "init_project", "dig_area", "list_areas", "navigate_back", "navigate_forward",
            "show_history", "show_status",
            "create_bookmark", "goto_bookmark", "list_bookmarks", "delete_bookmark",
            "save_context", "load_context", "list_contexts", "delete_context",
            "add_note", "show_notes", "generate_wiki",
            "show_insights", "suggest_areas", "show_dependencies", "analyze_impact",
            "show_map", "find_hotspots", "find_gaps", "analyze_performance", "run_benchmark",
            "show_trends", "show_predictions", "get_remediation",
            "search_all", "run_query",
            "show_automation", "list_rules",
            "show_analytics", "generate_report", "export_context", "create_backup",
            "show_provenance", "show_dashboard", "check_health", "show_stats",
            "show_team_activity", "show_test_coverage",
            "split_area", "create_subarea",
            "check_budget", "manage_policy", "show_audit",
            "continue_work", "pause_work", "list_contracts",
            "manage_llm"
        ]

        # Check which are actually implemented (in execute_tool method)
        implemented = set()
        if "def execute_tool" in content:
            # Find implemented tools by looking for elif branches
            impl_pattern = r'elif\s+tool_name\s*==\s*["\']([^"\']+)["\']'
            for match in re.finditer(impl_pattern, content):
                implemented.add(match.group(1))

        for tool in documented_tools:
            tools[tool] = {
                'name': tool,
                'implemented': tool in implemented
            }

        return tools

    def scan_skills(self) -> Dict[str, Dict]:
        """Scan claude-skills directory for skill files."""
        skills = {}

        if not self.skills_path.exists():
            return skills

        for skill_file in self.skills_path.glob("*.md"):
            skill_name = skill_file.stem

            # Read first few lines to get title
            title = skill_name.replace('-', ' ').replace('_', ' ').title()
            with open(skill_file, 'r') as f:
                first_line = f.readline().strip()
                if first_line.startswith('#'):
                    title = first_line.lstrip('#').strip()

            skills[skill_name] = {
                'file': skill_file.name,
                'title': title,
                'exists': True
            }

        return skills

    def build_manifest(self, cli_commands: Dict, mcp_tools: Dict, skills: Dict) -> Dict:
        """Build unified manifest from parsed data."""
        commands = []

        for cmd_name, cmd_data in cli_commands.items():
            # Determine category
            category = COMMAND_CATEGORIES.get(cmd_name, "core_navigation")

            # Map to MCP tool
            mcp_tool_name = CLI_TO_MCP.get(cmd_name)
            mcp_data = None
            if mcp_tool_name and mcp_tool_name in mcp_tools:
                mcp_data = mcp_tools[mcp_tool_name]

            # Map to slash command
            slash_cmd = CLI_TO_SLASH.get(cmd_name)

            # Map to skill
            skill_name = cmd_name
            skill_data = skills.get(skill_name)

            # Build command entry
            command = {
                "id": cmd_name,
                "canonical_name": cmd_name,
                "category": category,
                "description": f"{cmd_name.replace('-', ' ').title()} command",  # Placeholder

                "cli": {
                    "name": cmd_name,
                    "aliases": cmd_data['aliases'],
                    "function": cmd_data['function'],
                    "args": "",  # TODO: Parse from function signature
                    "implemented": cmd_data['implemented']
                },

                "slash": {
                    "primary": slash_cmd,
                    "aliases": [],
                    "usage": f"{slash_cmd} <args>" if slash_cmd else "",
                    "documented_in_website": True  # Assume true for now
                } if slash_cmd else None,

                "mcp": {
                    "tool_name": mcp_tool_name,
                    "implemented": mcp_data['implemented'] if mcp_data else False,
                    "input_schema": {}  # TODO: Parse from tool definition
                } if mcp_tool_name else None,

                "skill": {
                    "file": skill_data['file'] if skill_data else f"{cmd_name}.md",
                    "title": skill_data['title'] if skill_data else cmd_name.replace('-', ' ').title(),
                    "exists": skill_data is not None
                },

                "metadata": {
                    "version_added": "1.0.0",  # Placeholder
                    "status": "stable",
                    "governance_enforced": cmd_name in ["dig", "split", "export"],
                    "budget_aware": cmd_name in ["dig", "export"]
                },

                "documentation": {
                    "short_description": f"{cmd_name.replace('-', ' ').title()} command",
                    "long_description": "",  # TODO: Extract from docstrings
                    "examples": [],
                    "related_commands": []
                }
            }

            commands.append(command)

        # Build manifest
        manifest = {
            "version": "1.0.0",
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "source": "code-based introspection",
                "total_commands": len(commands)
            },
            "categories": CATEGORIES,
            "commands": commands
        }

        return manifest


def main():
    """Main entry point."""
    import sys

    # Find contextdigger root
    script_path = Path(__file__).resolve()
    contextdigger_root = script_path.parent.parent

    # Generate manifest
    generator = ManifestGenerator(contextdigger_root)
    manifest = generator.generate()

    # Output as JSON
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
