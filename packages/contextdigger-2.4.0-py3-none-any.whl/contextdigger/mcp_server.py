"""
ContextDigger MCP Server (Phase 12)

Local Model Context Protocol server that exposes ContextDigger functionality
to AI tools (Claude Desktop, Cursor, Windsurf, etc.).

Architecture:
- Pure Python, no external services
- Reads/writes .cdg/ directory directly
- Leverages existing service layer (no code duplication)
- Fully local, works offline

Resources Provided:
- cdg://areas - List all focus areas with metadata
- cdg://context/<area-id> - Governed context bundle for an area
- cdg://contracts - Active and recent continuation contracts
- cdg://governance - Current budget and policy status
- cdg://insights - Generated insights and recommendations
- cdg://provenance - File provenance for current session

Tools Provided (50+ tools - Full CLI parity):

Core Navigation (6 tools):
- init_project - Initialize .cdg/ if missing
- dig_area - Set focus area and return governed context
- list_areas - Get all areas with metadata
- navigate_back - Navigate to previous area in history
- navigate_forward - Navigate to next area in history
- show_history - Show navigation history
- show_status - Show current session status

Bookmarks (4 tools):
- create_bookmark - Save current location as bookmark
- goto_bookmark - Jump to bookmarked area
- list_bookmarks - List all bookmarks
- delete_bookmark - Delete a bookmark

Context Snapshots (4 tools):
- save_context - Save current context snapshot
- load_context - Load context snapshot
- list_contexts - List all saved context snapshots
- delete_context - Delete context snapshot

Notes & Documentation (3 tools):
- add_note - Add note to current area
- show_notes - View notes for area
- generate_wiki - Generate wiki documentation

Analysis & Intelligence (10 tools):
- show_insights - Generate and return insights
- suggest_areas - Get AI suggestions for areas to explore
- show_dependencies - Show dependencies for area
- analyze_impact - Analyze impact of changes
- show_map - Generate codebase map
- find_hotspots - Find frequently changed code
- find_gaps - Find coverage gaps
- analyze_performance - Performance analysis
- run_benchmark - Run performance benchmarks
- show_trends - Analyze historical trends (NEW in v2.2.0)
- show_predictions - Generate predictive insights (NEW in v2.2.0)
- get_remediation - Get automated remediation suggestions (NEW in v2.2.0)

Search & Query (2 tools):
- search_all - Search across all areas
- run_query - Run custom query on codebase data

Automation (2 tools):
- show_automation - Show automation suggestions
- list_rules - List automation rules

Reports & Export (6 tools):
- show_analytics - View work analytics
- generate_report - Generate comprehensive report
- export_context - Export area context to file
- create_backup - Create backup of .cdg/ directory
- show_provenance - Get file provenance details
- show_dashboard - Show comprehensive dashboard
- check_health - Run health check
- show_stats - Show statistics

Team Features (2 tools):
- show_team_activity - Show team activity
- show_test_coverage - Show test coverage

Sub-Area Management (2 tools):
- split_area - Split oversized area into sub-areas
- create_subarea - Manually create sub-area

Budget & Governance (3 tools):
- check_budget - Check budget compliance
- manage_policy - Manage budget policies
- show_audit - Show audit trail

Continuation Contracts (3 tools):
- continue_work - Resume continuation contract
- pause_work - Pause current work and save state
- list_contracts - List all work sessions

LLM Integration (1 tool):
- manage_llm - Manage LLM integration (status/enable/disable)

Key Design Decisions:
1. Local-only: No network calls, no external dependencies
2. Stateless: Each request reads current .cdg/ state
3. Governed: All context respects budget and policy limits
4. Idempotent: Safe to call tools multiple times
5. Descriptive errors: Clear messages for governance violations
"""

from pathlib import Path
from typing import Dict, List, Optional, Any
import json
from dataclasses import dataclass, asdict, field
from enum import Enum
from .refusal import RefusalResult, RefusalReason


# ============================================================================
# MCP Protocol Types
# ============================================================================


class ResourceType(Enum):
    """Types of resources exposed by the MCP server."""
    AREAS = "areas"
    CONTEXT = "context"
    CONTRACTS = "contracts"
    GOVERNANCE = "governance"
    INSIGHTS = "insights"
    PROVENANCE = "provenance"


class ToolType(Enum):
    """Types of tools provided by the MCP server."""
    INIT_PROJECT = "init_project"
    DIG_AREA = "dig_area"
    CONTINUE_WORK = "continue_work"
    PAUSE_WORK = "pause_work"
    SHOW_INSIGHTS = "show_insights"
    CHECK_BUDGET = "check_budget"
    SHOW_PROVENANCE = "show_provenance"
    LIST_AREAS = "list_areas"
    EXPORT_CONTEXT = "export_context"


@dataclass
class MCPResource:
    """Represents an MCP resource."""
    uri: str
    name: str
    description: str
    mimeType: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPTool:
    """Represents an MCP tool."""
    name: str
    description: str
    inputSchema: Dict[str, Any]
    outputSchema: Optional[Dict[str, Any]] = None


@dataclass
class MCPToolResult:
    """Result from executing an MCP tool."""
    success: bool
    data: Any
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_refusal(cls, refusal: RefusalResult) -> "MCPToolResult":
        """
        Create MCPToolResult from RefusalResult.

        Args:
            refusal: RefusalResult with governance violation details

        Returns:
            MCPToolResult with structured refusal information
        """
        # Build error message with all refusal details
        error_parts = [refusal.message]
        if refusal.details:
            error_parts.append(f"\nDetails: {refusal.details}")
        if refusal.hint:
            error_parts.append(f"\nHint: {refusal.hint}")

        return cls(
            success=False,
            data=None,
            error="\n".join(error_parts),
            metadata={
                "refusal_code": refusal.code.value,
                "refusal_message": refusal.message,
                "refusal_details": refusal.details,
                "refusal_hint": refusal.hint,
                **(refusal.metadata or {})
            }
        )


# ============================================================================
# MCP Server
# ============================================================================


class ContextDiggerMCPServer:
    """
    Local MCP server for ContextDigger.

    Exposes ContextDigger functionality via Model Context Protocol,
    enabling AI tools to access governed context, areas, contracts,
    and insights directly.

    Usage:
        server = ContextDiggerMCPServer(project_root="/path/to/project")

        # List resources
        resources = server.list_resources()

        # Get resource content
        context = server.get_resource("cdg://context/backend-api")

        # Execute tools
        result = server.execute_tool("dig_area", {"area_id": "backend-api"})
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize MCP server.

        Args:
            project_root: Path to project root. If None, uses current directory.
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.cdg_dir = self.project_root / ".cdg"

        # Lazy-load manager only when needed
        self._manager = None

    @property
    def manager(self):
        """Lazy-load FocusManager."""
        if self._manager is None:
            from .manager import FocusManager
            self._manager = FocusManager(self.project_root)
        return self._manager

    # ========================================================================
    # Resource Handlers
    # ========================================================================

    def list_resources(self) -> List[MCPResource]:
        """
        List all available MCP resources.

        Returns:
            List of MCPResource objects
        """
        resources = []

        # cdg://areas - All focus areas
        all_areas = self.manager.areas.list_areas()
        resources.append(MCPResource(
            uri="cdg://areas",
            name="Focus Areas",
            description="List of all discovered code areas in the project",
            mimeType="application/json",
            metadata={"count": len(all_areas)}
        ))

        # cdg://context/<area-id> - Context for each area
        for area in all_areas:
            resources.append(MCPResource(
                uri=f"cdg://context/{area.id}",
                name=f"Context: {area.name}",
                description=f"Governed context bundle for {area.name}",
                mimeType="text/plain",
                metadata={
                    "area_id": area.id,
                    "area_type": area.type,
                    "language": area.metadata.get("language"),
                }
            ))

        # cdg://contracts - Continuation contracts
        resources.append(MCPResource(
            uri="cdg://contracts",
            name="Continuation Contracts",
            description="Active and recent continuation contracts",
            mimeType="application/json"
        ))

        # cdg://governance - Budget and policy status
        resources.append(MCPResource(
            uri="cdg://governance",
            name="Governance Status",
            description="Current budget limits, policy, and compliance status",
            mimeType="application/json"
        ))

        # cdg://insights - Generated insights
        resources.append(MCPResource(
            uri="cdg://insights",
            name="Insights & Recommendations",
            description="Intelligent insights from pattern detection",
            mimeType="application/json"
        ))

        # cdg://provenance - File provenance
        resources.append(MCPResource(
            uri="cdg://provenance",
            name="File Provenance",
            description="Provenance tracking for loaded files",
            mimeType="application/json"
        ))

        return resources

    def get_resource(self, uri: str) -> Dict[str, Any]:
        """
        Get content of an MCP resource.

        Args:
            uri: Resource URI (e.g., "cdg://areas", "cdg://context/backend-api")

        Returns:
            Resource content

        Raises:
            ValueError: If URI is invalid or resource not found
        """
        if not uri.startswith("cdg://"):
            raise ValueError(f"Invalid URI scheme: {uri}")

        path = uri[6:]  # Remove "cdg://" prefix

        # Handle different resource types
        if path == "areas":
            return self._get_areas_resource()
        elif path.startswith("context/"):
            area_id = path[8:]  # Remove "context/" prefix
            return self._get_context_resource(area_id)
        elif path == "contracts":
            return self._get_contracts_resource()
        elif path == "governance":
            return self._get_governance_resource()
        elif path == "insights":
            return self._get_insights_resource()
        elif path == "provenance":
            return self._get_provenance_resource()
        else:
            raise ValueError(f"Unknown resource path: {path}")

    def _get_areas_resource(self) -> Dict[str, Any]:
        """Get list of all areas."""
        all_areas = self.manager.areas.list_areas()
        areas = []
        for area in all_areas:
            areas.append({
                "id": area.id,
                "name": area.name,
                "description": area.description,
                "type": area.type,
                "language": area.metadata.get("language"),
                "file_count": len(area.patterns.get("include", [])),
                "metadata": area.metadata,
            })

        return {
            "total_areas": len(areas),
            "areas": areas,
        }

    def _get_context_resource(self, area_id: str) -> Dict[str, Any]:
        """
        Get governed context for an area.

        Args:
            area_id: Area identifier

        Returns:
            Context content with budget status
        """
        area = self.manager.areas.get_area(area_id)
        if not area:
            raise ValueError(f"Area not found: {area_id}")

        # Get governed context through ContextExporter
        from .export import ContextExporter
        exporter = ContextExporter(self.manager)

        # Export context (respects budget limits)
        context_file = self.cdg_dir / "context" / f"{area_id}.txt"
        exporter.export_area_context(area_id, context_file)

        # Read exported context
        with open(context_file, "r") as f:
            context_content = f.read()

        # Get budget status (if available)
        try:
            from .budget import BudgetTracker, BudgetStatus, PolicyManager
            policy_mgr = PolicyManager(self.project_root)
            policy = policy_mgr.get_active_policy()
            tracker = BudgetTracker(
                max_files=policy.max_files,
                max_lines=policy.max_lines,
                alert_thresholds=policy.alert_thresholds,
            )

            # Count files and lines in context
            files = context_content.count("File:")
            lines = len(context_content.split("\n"))
            budget = BudgetStatus(
                files_used=files,
                files_max=policy.max_files,
                lines_used=lines,
                lines_max=policy.max_lines,
            )

            budget_info = {
                "files_used": budget.files_used,
                "files_max": budget.files_max,
                "lines_used": budget.lines_used,
                "lines_max": budget.lines_max,
                "health": tracker.get_budget_health(budget),
            }
        except Exception:
            # Budget system not available or error occurred
            budget_info = None

        return {
            "area_id": area_id,
            "area_name": area.name,
            "context": context_content,
            "budget": budget_info,
        }

    def _get_contracts_resource(self) -> Dict[str, Any]:
        """Get continuation contracts."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        active = contract_mgr.get_active_contract()
        history = contract_mgr.get_contract_history(limit=10)

        return {
            "active_contract": active.to_dict() if active else None,
            "recent_contracts": [c.to_dict() for c in history],
        }

    def _get_governance_resource(self) -> Dict[str, Any]:
        """Get governance status."""
        from .budget import PolicyManager, BudgetTracker, BudgetStatus
        policy_mgr = PolicyManager(self.project_root)
        policy = policy_mgr.get_active_policy()

        # Create budget tracker
        tracker = BudgetTracker(
            max_files=policy.max_files,
            max_lines=policy.max_lines,
            alert_thresholds=policy.alert_thresholds,
        )

        # Get current session or default to 0
        files_used = 0
        lines_used = 0
        budget = BudgetStatus(
            files_used=files_used,
            files_max=policy.max_files,
            lines_used=lines_used,
            lines_max=policy.max_lines,
        )

        return {
            "policy": {
                "id": policy.policy_id,
                "name": policy.name,
                "enforcement_mode": policy.enforcement_mode.value,
                "max_files": policy.max_files,
                "max_lines": policy.max_lines,
            },
            "budget": {
                "files_used": budget.files_used,
                "files_max": budget.files_max,
                "lines_used": budget.lines_used,
                "lines_max": budget.lines_max,
                "health": tracker.get_budget_health(budget),
            },
        }

    def _get_insights_resource(self) -> Dict[str, Any]:
        """Get generated insights."""
        from .insights import InsightEngine
        engine = InsightEngine(self.project_root)
        insights = engine.generate_insights()

        return {
            "total_insights": len(insights),
            "insights": [i.to_dict() for i in insights],
            "summary": engine.get_summary(insights),
        }

    def _get_provenance_resource(self) -> Dict[str, Any]:
        """Get file provenance."""
        from .provenance import ProvenanceTracker
        tracker = ProvenanceTracker(self.project_root)

        # Get most recent session
        provenance_dir = self.cdg_dir / "provenance"
        if not provenance_dir.exists():
            return {"sessions": []}

        sessions = sorted(provenance_dir.glob("session-*.json"))
        if not sessions:
            return {"sessions": []}

        latest_session = sessions[-1].stem
        provenance = tracker.get_session_provenance(latest_session)

        # Convert FileProvenance objects to dicts for JSON serialization
        provenance_dicts = [p.to_dict() for p in provenance]

        return {
            "session_id": latest_session,
            "total_files": len(provenance),
            "provenance": provenance_dicts,
        }

    # ========================================================================
    # Tool Handlers
    # ========================================================================

    def list_tools(self) -> List[MCPTool]:
        """
        List all available MCP tools (50+ tools - Full CLI parity).

        Returns:
            List of MCPTool objects
        """
        return [
            # ==================================================================
            # Core Navigation (7 tools)
            # ==================================================================
            MCPTool(
                name="init_project",
                description="Initialize ContextDigger in the project (creates .cdg/ directory)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="dig_area",
                description="Set focus to an area and return governed context",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                    },
                    "required": ["area_id"],
                },
            ),
            MCPTool(
                name="list_areas",
                description="List all discovered code areas",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="navigate_back",
                description="Navigate to previous area in history",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="navigate_forward",
                description="Navigate to next area in history",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_history",
                description="Show navigation history",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_status",
                description="Show current session status",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),

            # ==================================================================
            # Bookmarks (4 tools)
            # ==================================================================
            MCPTool(
                name="create_bookmark",
                description="Save current location as bookmark",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Bookmark name"},
                        "description": {"type": "string", "description": "Bookmark description (optional)"},
                    },
                    "required": ["name"],
                },
            ),
            MCPTool(
                name="goto_bookmark",
                description="Jump to bookmarked area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Bookmark name"},
                    },
                    "required": ["name"],
                },
            ),
            MCPTool(
                name="list_bookmarks",
                description="List all bookmarks",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="delete_bookmark",
                description="Delete a bookmark",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Bookmark name"},
                    },
                    "required": ["name"],
                },
            ),

            # ==================================================================
            # Context Snapshots (4 tools)
            # ==================================================================
            MCPTool(
                name="save_context",
                description="Save current context snapshot",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Snapshot name"},
                        "description": {"type": "string", "description": "Snapshot description (optional)"},
                    },
                    "required": ["name"],
                },
            ),
            MCPTool(
                name="load_context",
                description="Load context snapshot",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Snapshot name"},
                    },
                    "required": ["name"],
                },
            ),
            MCPTool(
                name="list_contexts",
                description="List all saved context snapshots",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="delete_context",
                description="Delete context snapshot",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Snapshot name"},
                    },
                    "required": ["name"],
                },
            ),

            # ==================================================================
            # Notes & Documentation (3 tools)
            # ==================================================================
            MCPTool(
                name="add_note",
                description="Add note to current area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "text": {"type": "string", "description": "Note content"},
                        "area_id": {"type": "string", "description": "Area identifier (optional, uses current)"},
                    },
                    "required": ["text"],
                },
            ),
            MCPTool(
                name="show_notes",
                description="View notes for area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier (optional, uses current)"},
                    },
                },
            ),
            MCPTool(
                name="generate_wiki",
                description="Generate wiki documentation",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),

            # ==================================================================
            # Analysis & Intelligence (12 tools)
            # ==================================================================
            MCPTool(
                name="show_insights",
                description="Generate intelligent insights from usage patterns",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "level": {
                            "type": "string",
                            "enum": ["all", "critical", "warnings", "info"],
                            "description": "Filter insights by level",
                        },
                    },
                },
            ),
            MCPTool(
                name="suggest_areas",
                description="Get AI suggestions for areas to explore",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_dependencies",
                description="Show dependencies for area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier (optional, uses current)"},
                    },
                },
            ),
            MCPTool(
                name="analyze_impact",
                description="Analyze impact of changes in area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                    },
                    "required": ["area_id"],
                },
            ),
            MCPTool(
                name="show_map",
                description="Generate codebase map",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="find_hotspots",
                description="Find frequently changed code hotspots",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="find_gaps",
                description="Find coverage gaps",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="analyze_performance",
                description="Run performance analysis",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier (optional, uses current)"},
                    },
                },
            ),
            MCPTool(
                name="run_benchmark",
                description="Run performance benchmarks",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_trends",
                description="Analyze historical trends (NEW in v2.2.0)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_predictions",
                description="Generate predictive insights based on trends (NEW in v2.2.0)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="get_remediation",
                description="Get automated remediation suggestions (NEW in v2.2.0)",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "use_llm": {"type": "boolean", "description": "Use AI enhancement (requires Ollama)"},
                    },
                },
            ),

            # ==================================================================
            # Search & Query (2 tools)
            # ==================================================================
            MCPTool(
                name="search_all",
                description="Search across all areas",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                    },
                    "required": ["query"],
                },
            ),
            MCPTool(
                name="run_query",
                description="Run custom query on codebase data",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Custom query"},
                    },
                    "required": ["query"],
                },
            ),

            # ==================================================================
            # Automation (2 tools)
            # ==================================================================
            MCPTool(
                name="show_automation",
                description="Show automation suggestions",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="list_rules",
                description="List automation rules",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),

            # ==================================================================
            # Reports & Export (8 tools)
            # ==================================================================
            MCPTool(
                name="show_analytics",
                description="View work analytics",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="generate_report",
                description="Generate comprehensive report",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "output_file": {"type": "string", "description": "Output file path (optional)"},
                    },
                },
            ),
            MCPTool(
                name="export_context",
                description="Export area context to file",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                        "format": {
                            "type": "string",
                            "enum": ["markdown", "json", "xml", "ai", "claude", "cursor"],
                            "description": "Export format",
                        },
                        "output_file": {"type": "string", "description": "Output file path (optional)"},
                    },
                    "required": ["area_id"],
                },
            ),
            MCPTool(
                name="create_backup",
                description="Create backup of .cdg/ directory",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_provenance",
                description="Show file provenance (why files were loaded)",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_dashboard",
                description="Show comprehensive dashboard",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="check_health",
                description="Run health check",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_stats",
                description="Show statistics",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),

            # ==================================================================
            # Team Features (2 tools)
            # ==================================================================
            MCPTool(
                name="show_team_activity",
                description="Show team activity",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="show_test_coverage",
                description="Show test coverage",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),

            # ==================================================================
            # Sub-Area Management (2 tools)
            # ==================================================================
            MCPTool(
                name="split_area",
                description="Split oversized area into sub-areas",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "area_id": {"type": "string", "description": "Area identifier"},
                        "strategy": {
                            "type": "string",
                            "enum": ["by-subdirectory", "by-file-type", "by-dependencies", "auto"],
                            "description": "Splitting strategy",
                        },
                    },
                    "required": ["area_id"],
                },
            ),
            MCPTool(
                name="create_subarea",
                description="Manually create sub-area",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "parent_id": {"type": "string", "description": "Parent area identifier"},
                        "name": {"type": "string", "description": "Sub-area name"},
                        "pattern": {"type": "string", "description": "File pattern"},
                    },
                    "required": ["parent_id", "name", "pattern"],
                },
            ),

            # ==================================================================
            # Budget & Governance (3 tools)
            # ==================================================================
            MCPTool(
                name="check_budget",
                description="Check budget compliance against governance policy",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="manage_policy",
                description="Manage budget policies",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["show", "set", "reset"],
                            "description": "Policy action",
                        },
                        "max_files": {"type": "integer", "description": "Maximum files (for set action)"},
                        "max_lines": {"type": "integer", "description": "Maximum lines (for set action)"},
                        "enforcement_mode": {
                            "type": "string",
                            "enum": ["strict", "warning", "advisory"],
                            "description": "Enforcement mode (for set action)",
                        },
                    },
                    "required": ["action"],
                },
            ),
            MCPTool(
                name="show_audit",
                description="Show audit trail",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "limit": {"type": "integer", "description": "Number of entries (default: 50)"},
                    },
                },
            ),

            # ==================================================================
            # Continuation Contracts (3 tools)
            # ==================================================================
            MCPTool(
                name="continue_work",
                description="Resume the active continuation contract",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="pause_work",
                description="Pause current work and save continuation contract",
                inputSchema={"type": "object", "properties": {}, "required": []},
            ),
            MCPTool(
                name="list_contracts",
                description="List all work sessions (active and paused)",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "limit": {"type": "integer", "description": "Number of contracts (default: 10)"},
                    },
                },
            ),

            # ==================================================================
            # LLM Integration (1 tool)
            # ==================================================================
            MCPTool(
                name="manage_llm",
                description="Manage LLM integration (status/enable/disable)",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["status", "enable", "disable"],
                            "description": "LLM action",
                        },
                    },
                    "required": ["action"],
                },
            ),
        ]

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> MCPToolResult:
        """
        Execute an MCP tool.

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            MCPToolResult with success status and data
        """
        try:
            if tool_name == "init_project":
                return self._tool_init_project()
            elif tool_name == "dig_area":
                return self._tool_dig_area(arguments["area_id"])
            elif tool_name == "continue_work":
                return self._tool_continue_work()
            elif tool_name == "pause_work":
                return self._tool_pause_work()
            elif tool_name == "show_insights":
                level = arguments.get("level", "all")
                return self._tool_show_insights(level)
            elif tool_name == "check_budget":
                return self._tool_check_budget()
            elif tool_name == "show_provenance":
                return self._tool_show_provenance()
            elif tool_name == "list_areas":
                return self._tool_list_areas()
            elif tool_name == "export_context":
                area_id = arguments["area_id"]
                output_file = arguments.get("output_file")
                return self._tool_export_context(area_id, output_file)

            # Bookmarks
            elif tool_name == "create_bookmark":
                name = arguments["name"]
                description = arguments.get("description", "")
                return self._tool_create_bookmark(name, description)
            elif tool_name == "goto_bookmark":
                bookmark_id = arguments["bookmark_id"]
                return self._tool_goto_bookmark(bookmark_id)
            elif tool_name == "list_bookmarks":
                area_id = arguments.get("area_id")
                return self._tool_list_bookmarks(area_id)
            elif tool_name == "delete_bookmark":
                bookmark_id = arguments["bookmark_id"]
                return self._tool_delete_bookmark(bookmark_id)

            # Context Snapshots
            elif tool_name == "save_context":
                name = arguments["name"]
                description = arguments.get("description", "")
                return self._tool_save_context(name, description)
            elif tool_name == "load_context":
                name = arguments["name"]
                return self._tool_load_context(name)
            elif tool_name == "list_contexts":
                return self._tool_list_contexts()
            elif tool_name == "delete_context":
                name = arguments["name"]
                return self._tool_delete_context(name)

            # Navigation
            elif tool_name == "navigate_back":
                return self._tool_navigate_back()
            elif tool_name == "navigate_forward":
                return self._tool_navigate_forward()
            elif tool_name == "show_history":
                return self._tool_show_history()
            elif tool_name == "show_status":
                return self._tool_show_status()

            # Governance
            elif tool_name == "manage_policy":
                action = arguments["action"]
                max_files = arguments.get("max_files")
                max_lines = arguments.get("max_lines")
                enforcement_mode = arguments.get("enforcement_mode")
                return self._tool_manage_policy(action, max_files, max_lines, enforcement_mode)
            elif tool_name == "show_audit":
                limit = arguments.get("limit", 50)
                return self._tool_show_audit(limit)

            # Sub-areas
            elif tool_name == "split_area":
                area_id = arguments["area_id"]
                strategy = arguments.get("strategy", "auto")
                return self._tool_split_area(area_id, strategy)
            elif tool_name == "create_subarea":
                parent_id = arguments["parent_id"]
                name = arguments["name"]
                pattern = arguments["pattern"]
                return self._tool_create_subarea(parent_id, name, pattern)

            # Notes
            elif tool_name == "add_note":
                note_text = arguments["note"]
                area_id = arguments.get("area_id")
                return self._tool_add_note(note_text, area_id)
            elif tool_name == "show_notes":
                area_id = arguments.get("area_id")
                return self._tool_show_notes(area_id)
            elif tool_name == "generate_wiki":
                return self._tool_generate_wiki()

            # Analysis & Intelligence
            elif tool_name == "suggest_areas":
                return self._tool_suggest_areas()
            elif tool_name == "show_dependencies":
                area_id = arguments.get("area_id")
                return self._tool_show_dependencies(area_id)
            elif tool_name == "analyze_impact":
                area_id = arguments["area_id"]
                return self._tool_analyze_impact(area_id)
            elif tool_name == "show_map":
                return self._tool_show_map()
            elif tool_name == "find_hotspots":
                days = arguments.get("days", 30)
                return self._tool_find_hotspots(days)
            elif tool_name == "find_gaps":
                return self._tool_find_gaps()
            elif tool_name == "analyze_performance":
                area_id = arguments.get("area_id")
                return self._tool_analyze_performance(area_id)
            elif tool_name == "run_benchmark":
                return self._tool_run_benchmark()
            elif tool_name == "show_trends":
                return self._tool_show_trends()
            elif tool_name == "show_predictions":
                return self._tool_show_predictions()
            elif tool_name == "get_remediation":
                return self._tool_get_remediation()

            # Reports, Dashboard, Team
            elif tool_name == "show_analytics":
                days = arguments.get("days", 30)
                return self._tool_show_analytics(days)
            elif tool_name == "generate_report":
                return self._tool_generate_report()
            elif tool_name == "create_backup":
                return self._tool_create_backup()
            elif tool_name == "show_dashboard":
                return self._tool_show_dashboard()
            elif tool_name == "check_health":
                return self._tool_check_health()
            elif tool_name == "show_stats":
                return self._tool_show_stats()
            elif tool_name == "show_team_activity":
                max_age_hours = arguments.get("max_age_hours", 24)
                return self._tool_show_team_activity(max_age_hours)
            elif tool_name == "show_test_coverage":
                return self._tool_show_test_coverage()
            elif tool_name == "search_all":
                query = arguments["query"]
                return self._tool_search_all(query)
            elif tool_name == "run_query":
                query = arguments["query"]
                return self._tool_run_query(query)

            # Automation, Contracts, LLM
            elif tool_name == "show_automation":
                return self._tool_show_automation()
            elif tool_name == "list_rules":
                return self._tool_list_rules()
            elif tool_name == "list_contracts":
                limit = arguments.get("limit", 10)
                return self._tool_list_contracts(limit)
            elif tool_name == "manage_llm":
                action = arguments["action"]
                return self._tool_manage_llm(action)

            else:
                return MCPToolResult(
                    success=False,
                    data=None,
                    error=f"Unknown tool: {tool_name}",
                )
        except Exception as e:
            return MCPToolResult(
                success=False,
                data=None,
                error=str(e),
            )

    def _tool_init_project(self) -> MCPToolResult:
        """Initialize .cdg/ directory."""
        if self.cdg_dir.exists():
            return MCPToolResult(
                success=True,
                data={"message": "Project already initialized"},
                metadata={"cdg_dir": str(self.cdg_dir)},
            )

        # Initialize through manager
        self.manager.initialize()

        return MCPToolResult(
            success=True,
            data={
                "message": "Project initialized successfully",
                "areas_discovered": len(self.manager.areas),
            },
            metadata={"cdg_dir": str(self.cdg_dir)},
        )

    def _tool_dig_area(self, area_id: str) -> MCPToolResult:
        """Dig into an area and return context."""
        area = self.manager.areas.get_area(area_id)
        if not area:
            # Create structured refusal for area not found
            available_areas = self.manager.areas.list_areas()
            areas_list = "\n".join([f"  - {a.id}: {a.name}" for a in available_areas[:10]])

            refusal = RefusalResult(
                code=RefusalReason.AREA_NOT_FOUND,
                message=f"Area not found: {area_id}",
                details=f"Available areas:\n{areas_list}",
                hint="Use list_areas tool to see all available areas",
                metadata={"requested_area": area_id, "available_count": len(available_areas)}
            )
            return MCPToolResult.from_refusal(refusal)

        # Get context (governed by budget)
        context_data = self._get_context_resource(area_id)

        return MCPToolResult(
            success=True,
            data=context_data,
            metadata={"area_id": area_id},
        )

    def _tool_continue_work(self) -> MCPToolResult:
        """Resume continuation contract."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        contract = contract_mgr.get_active_contract()
        if not contract:
            refusal = RefusalResult(
                code=RefusalReason.INVALID_STATE,
                message="No active contract to resume",
                details="There is no paused or active continuation contract in the current project",
                hint="Use 'pause_work' tool to pause current work first, or start a new session with 'dig_area'",
                metadata={"project_root": str(self.project_root)}
            )
            return MCPToolResult.from_refusal(refusal)

        return MCPToolResult(
            success=True,
            data=contract.to_dict(),
            metadata={"contract_id": contract.id},
        )

    def _tool_pause_work(self) -> MCPToolResult:
        """Pause current work."""
        from .continuation import ContractManager
        contract_mgr = ContractManager(self.project_root)

        contract = contract_mgr.get_active_contract()
        if not contract:
            refusal = RefusalResult(
                code=RefusalReason.INVALID_STATE,
                message="No active contract to pause",
                details="There is no active continuation contract in the current project",
                hint="Use 'dig_area' tool to start a new session first",
                metadata={"project_root": str(self.project_root)}
            )
            return MCPToolResult.from_refusal(refusal)

        # Pause contract
        contract_mgr.pause_contract()

        return MCPToolResult(
            success=True,
            data={"message": "Work paused successfully"},
            metadata={"contract_id": contract.id},
        )

    def _tool_show_insights(self, level: str = "all") -> MCPToolResult:
        """Generate and return insights."""
        from .insights import InsightEngine, InsightLevel
        engine = InsightEngine(self.project_root)
        insights = engine.generate_insights()

        # Filter by level
        if level == "critical":
            insights = engine.get_insights_by_level(insights, InsightLevel.CRITICAL)
        elif level == "warnings":
            insights = engine.get_insights_by_level(insights, InsightLevel.WARNING)

        return MCPToolResult(
            success=True,
            data={
                "total_insights": len(insights),
                "insights": [i.to_dict() for i in insights],
            },
        )

    def _tool_check_budget(self) -> MCPToolResult:
        """Check budget compliance."""
        from .budget import PolicyManager, BudgetTracker, BudgetStatus
        policy_mgr = PolicyManager(self.project_root)
        policy = policy_mgr.get_active_policy()

        # Create tracker
        tracker = BudgetTracker(
            max_files=policy.max_files,
            max_lines=policy.max_lines,
            alert_thresholds=policy.alert_thresholds,
        )

        # Get current status (default to 0 if no active session)
        files_used = 0
        lines_used = 0
        budget = BudgetStatus(
            files_used=files_used,
            files_max=policy.max_files,
            lines_used=lines_used,
            lines_max=policy.max_lines,
        )

        # Check compliance
        is_compliant, violations = tracker.check_policy_compliance(budget, policy)

        return MCPToolResult(
            success=True,
            data={
                "compliant": is_compliant,
                "violations": violations,
                "budget": {
                    "files_used": budget.files_used,
                    "files_max": budget.files_max,
                    "lines_used": budget.lines_used,
                    "lines_max": budget.lines_max,
                    "health": tracker.get_budget_health(budget),
                },
            },
        )

    def _tool_show_provenance(self) -> MCPToolResult:
        """Show file provenance."""
        data = self._get_provenance_resource()

        return MCPToolResult(
            success=True,
            data=data,
        )

    def _tool_list_areas(self) -> MCPToolResult:
        """List all areas."""
        data = self._get_areas_resource()

        return MCPToolResult(
            success=True,
            data=data,
        )

    def _tool_export_context(
        self, area_id: str, output_file: Optional[str] = None
    ) -> MCPToolResult:
        """Export area context."""
        area = self.manager.areas.get_area(area_id)
        if not area:
            # Create structured refusal for area not found
            available_areas = self.manager.areas.list_areas()
            areas_list = "\n".join([f"  - {a.id}: {a.name}" for a in available_areas[:10]])

            refusal = RefusalResult(
                code=RefusalReason.AREA_NOT_FOUND,
                message=f"Area not found: {area_id}",
                details=f"Available areas:\n{areas_list}",
                hint="Use list_areas tool to see all available areas",
                metadata={"requested_area": area_id, "available_count": len(available_areas)}
            )
            return MCPToolResult.from_refusal(refusal)

        # Determine output file
        if output_file:
            output_path = Path(output_file)
        else:
            output_path = self.cdg_dir / "context" / f"{area_id}.txt"

        # Export context
        from .export import ContextExporter
        exporter = ContextExporter(self.manager)
        exporter.export_area_context(area_id, output_path)

        return MCPToolResult(
            success=True,
            data={
                "message": "Context exported successfully",
                "output_file": str(output_path),
            },
            metadata={"area_id": area_id},
        )

    # ========================================================================
    # Bookmark Tools
    # ========================================================================

    def _tool_create_bookmark(self, name: str, description: str = "") -> MCPToolResult:
        """Create a bookmark at current location."""
        from .models import Bookmark
        import uuid
        from datetime import datetime

        # Get current focus area
        current_area = self.manager.get_current_focus()
        if not current_area:
            return MCPToolResult(
                success=False,
                data=None,
                error="No active area - run dig first",
            )

        # Create bookmark
        bookmark = Bookmark(
            id=str(uuid.uuid4()),
            name=name,
            description=description,
            area_id=current_area,
            created_at=datetime.now().isoformat(),
            accessed_at=datetime.now().isoformat(),
            access_count=0,
        )

        # Save via manager
        self.manager.bookmarks.add_bookmark(bookmark)

        return MCPToolResult(
            success=True,
            data=bookmark.__dict__,
            metadata={"bookmark_id": bookmark.id},
        )

    def _tool_goto_bookmark(self, bookmark_id: str) -> MCPToolResult:
        """Navigate to a bookmarked location."""
        # Get bookmark
        bookmark = self.manager.bookmarks.get_bookmark(bookmark_id)
        if not bookmark:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Bookmark not found: {bookmark_id}",
            )

        # Update access tracking
        self.manager.bookmarks.update_bookmark_access(bookmark_id)

        # Dig into the bookmarked area
        return self._tool_dig_area(bookmark.area_id)

    def _tool_list_bookmarks(self, area_id: Optional[str] = None) -> MCPToolResult:
        """List all bookmarks, optionally filtered by area."""
        bookmarks = self.manager.bookmarks.list_bookmarks(focus_area=area_id)

        return MCPToolResult(
            success=True,
            data={
                "bookmarks": [b.__dict__ for b in bookmarks],
                "total": len(bookmarks),
            },
            metadata={"area_filter": area_id},
        )

    def _tool_delete_bookmark(self, bookmark_id: str) -> MCPToolResult:
        """Delete a bookmark."""
        success = self.manager.bookmarks.delete_bookmark(bookmark_id)

        if not success:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Bookmark not found: {bookmark_id}",
            )

        return MCPToolResult(
            success=True,
            data={"message": "Bookmark deleted successfully"},
            metadata={"bookmark_id": bookmark_id},
        )

    # ========================================================================
    # Context Snapshot Tools
    # ========================================================================

    def _tool_save_context(self, name: str, description: str = "") -> MCPToolResult:
        """Save current context snapshot."""
        try:
            # Save snapshot via manager
            snapshot = self.manager.save_context(name=name, description=description)

            # Convert ContextSnapshot dataclass to dict
            snapshot_data = {
                "name": snapshot.name,
                "description": snapshot.description,
                "savedAt": snapshot.savedAt,
                "currentArea": snapshot.currentArea,
                "currentAreaName": snapshot.currentAreaName,
                "markedSpots": snapshot.markedSpots,
                "digHistory": snapshot.digHistory,
                "historyIndex": snapshot.historyIndex,
                "sessionNotes": snapshot.sessionNotes,
                "tags": snapshot.tags,
            }

            return MCPToolResult(
                success=True,
                data=snapshot_data,
                metadata={"snapshot_name": name},
            )
        except Exception as e:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Failed to save context: {str(e)}",
            )

    def _tool_load_context(self, name: str) -> MCPToolResult:
        """Load a context snapshot."""
        snapshot = self.manager.load_context(name)

        if not snapshot:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Context snapshot not found: {name}",
            )

        # Convert ContextSnapshot dataclass to dict
        snapshot_data = {
            "name": snapshot.name,
            "description": snapshot.description,
            "savedAt": snapshot.savedAt,
            "currentArea": snapshot.currentArea,
            "currentAreaName": snapshot.currentAreaName,
            "markedSpots": snapshot.markedSpots,
            "digHistory": snapshot.digHistory,
            "historyIndex": snapshot.historyIndex,
            "sessionNotes": snapshot.sessionNotes,
            "tags": snapshot.tags,
        }

        return MCPToolResult(
            success=True,
            data={
                "message": f"Context snapshot '{name}' loaded successfully",
                "snapshot": snapshot_data,
            },
            metadata={"snapshot_name": name},
        )

    def _tool_list_contexts(self) -> MCPToolResult:
        """List all saved context snapshots."""
        snapshots = self.manager.list_contexts()

        # Convert list of ContextSnapshot dataclasses to list of dicts
        snapshots_data = [
            {
                "name": s.name,
                "description": s.description,
                "savedAt": s.savedAt,
                "currentArea": s.currentArea,
                "currentAreaName": s.currentAreaName,
                "tags": s.tags,
            }
            for s in snapshots
        ]

        return MCPToolResult(
            success=True,
            data={
                "snapshots": snapshots_data,
                "total": len(snapshots),
            },
            metadata={"total_snapshots": len(snapshots)},
        )

    def _tool_delete_context(self, name: str) -> MCPToolResult:
        """Delete a context snapshot."""
        success = self.manager.delete_context(name)

        if not success:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Context snapshot not found: {name}",
            )

        return MCPToolResult(
            success=True,
            data={"message": f"Context snapshot '{name}' deleted successfully"},
            metadata={"snapshot_name": name},
        )

    # ========================================================================
    # Navigation Tools
    # ========================================================================

    def _tool_navigate_back(self) -> MCPToolResult:
        """Navigate to previous area in history."""
        previous_area_id = self.manager.navigate_back()

        if not previous_area_id:
            refusal = RefusalResult(
                code=RefusalReason.INVALID_STATE,
                message="No previous area in history",
                details="Navigation history is empty or you are at the beginning",
                hint="Use 'dig_area' to navigate to a new area first",
                metadata={"current_position": "start"}
            )
            return MCPToolResult.from_refusal(refusal)

        # Get area details
        area = self.manager.areas.get_area(previous_area_id)
        if not area:
            # Area was in history but no longer exists
            available_areas = self.manager.areas.list_areas()
            areas_list = "\n".join([f"  - {a.id}: {a.name}" for a in available_areas[:10]])

            refusal = RefusalResult(
                code=RefusalReason.AREA_NOT_FOUND,
                message=f"Area not found in history: {previous_area_id}",
                details=f"The area was in navigation history but no longer exists.\nAvailable areas:\n{areas_list}",
                hint="Use list_areas tool to see current areas, or navigate forward to try a different area",
                metadata={"requested_area": previous_area_id, "available_count": len(available_areas)}
            )
            return MCPToolResult.from_refusal(refusal)

        return MCPToolResult(
            success=True,
            data={
                "message": f"Navigated back to '{area.name}'",
                "area_id": previous_area_id,
                "area_name": area.name,
            },
            metadata={"area_id": previous_area_id},
        )

    def _tool_navigate_forward(self) -> MCPToolResult:
        """Navigate to next area in history."""
        next_area_id = self.manager.navigate_forward()

        if not next_area_id:
            refusal = RefusalResult(
                code=RefusalReason.INVALID_STATE,
                message="No next area in history",
                details="Navigation history is empty or you are at the most recent position",
                hint="Use 'dig_area' to navigate to a new area, or navigate back first",
                metadata={"current_position": "end"}
            )
            return MCPToolResult.from_refusal(refusal)

        # Get area details
        area = self.manager.areas.get_area(next_area_id)
        if not area:
            # Area was in history but no longer exists
            available_areas = self.manager.areas.list_areas()
            areas_list = "\n".join([f"  - {a.id}: {a.name}" for a in available_areas[:10]])

            refusal = RefusalResult(
                code=RefusalReason.AREA_NOT_FOUND,
                message=f"Area not found in history: {next_area_id}",
                details=f"The area was in navigation history but no longer exists.\nAvailable areas:\n{areas_list}",
                hint="Use list_areas tool to see current areas, or navigate back to try a different area",
                metadata={"requested_area": next_area_id, "available_count": len(available_areas)}
            )
            return MCPToolResult.from_refusal(refusal)

        return MCPToolResult(
            success=True,
            data={
                "message": f"Navigated forward to '{area.name}'",
                "area_id": next_area_id,
                "area_name": area.name,
            },
            metadata={"area_id": next_area_id},
        )

    def _tool_show_history(self) -> MCPToolResult:
        """Show navigation history."""
        history = self.manager.get_dig_history()

        # Convert DigHistoryEntry dataclasses to dicts
        history_data = [
            {
                "areaId": entry.areaId,
                "areaName": entry.areaName,
                "enteredAt": entry.enteredAt,
                "exitedAt": entry.exitedAt,
                "duration": entry.duration,
                "actions": entry.actions,
                "breadcrumb": entry.breadcrumb,
            }
            for entry in history
        ]

        return MCPToolResult(
            success=True,
            data={
                "history": history_data,
                "total": len(history),
            },
            metadata={"total_entries": len(history)},
        )

    def _tool_show_status(self) -> MCPToolResult:
        """Show current session status."""
        # Get current focus
        current_area_id = self.manager.get_current_focus()
        current_area = self.manager.areas.get_area(current_area_id) if current_area_id else None

        # Get current session
        session = self.manager.sessions.get_current_session()

        # Build status data
        status_data = {
            "current_area": {
                "id": current_area_id,
                "name": current_area.name if current_area else None,
            } if current_area_id else None,
            "session": {
                "sessionId": session.sessionId,
                "areaId": session.areaId,
                "startedAt": session.startedAt,
                "duration": session.duration,
                "activity": session.activity,
            } if session else None,
        }

        return MCPToolResult(
            success=True,
            data=status_data,
            metadata={"has_active_session": session is not None},
        )

    # ========================================================================
    # Governance Tools
    # ========================================================================

    def _tool_manage_policy(
        self,
        action: str,
        max_files: Optional[int] = None,
        max_lines: Optional[int] = None,
        enforcement_mode: Optional[str] = None,
    ) -> MCPToolResult:
        """Manage budget governance policies."""
        from .budget import PolicyManager, GovernancePolicy, EnforcementMode, ViolationAction
        import uuid
        from datetime import datetime

        policy_manager = PolicyManager(self.manager.focus_root)

        if action == "show":
            # Show active policy
            policy = policy_manager.get_active_policy()

            policy_data = {
                "policy_id": policy.policy_id,
                "name": policy.name,
                "enabled": policy.enabled,
                "enforcement_mode": policy.enforcement_mode.value,
                "max_files": policy.max_files,
                "max_lines": policy.max_lines,
                "alert_thresholds": policy.alert_thresholds,
                "violation_actions": [a.value for a in policy.violation_actions],
                "description": policy.description,
            }

            return MCPToolResult(
                success=True,
                data=policy_data,
                metadata={"policy_id": policy.policy_id},
            )

        elif action == "set":
            # Create or update policy
            if not max_files and not max_lines and not enforcement_mode:
                return MCPToolResult(
                    success=False,
                    data=None,
                    error="At least one policy parameter (max_files, max_lines, enforcement_mode) is required for 'set' action",
                )

            # Get current policy as base
            current_policy = policy_manager.get_active_policy()

            # Update values
            new_max_files = max_files if max_files is not None else current_policy.max_files
            new_max_lines = max_lines if max_lines is not None else current_policy.max_lines

            # Parse enforcement mode
            if enforcement_mode:
                try:
                    new_enforcement_mode = EnforcementMode(enforcement_mode.lower())
                except ValueError:
                    return MCPToolResult(
                        success=False,
                        data=None,
                        error=f"Invalid enforcement mode: {enforcement_mode}. Must be one of: strict, warning, advisory",
                    )
            else:
                new_enforcement_mode = current_policy.enforcement_mode

            # Create new policy
            new_policy = GovernancePolicy(
                policy_id=str(uuid.uuid4()),
                name="Custom Policy",
                enabled=True,
                enforcement_mode=new_enforcement_mode,
                max_files=new_max_files,
                max_lines=new_max_lines,
                alert_thresholds=current_policy.alert_thresholds,
                violation_actions=current_policy.violation_actions,
                description=f"Custom policy created via MCP at {datetime.utcnow().isoformat()}Z",
            )

            # Save policy
            policy_manager.save_policy(new_policy)
            policy_manager.set_active_policy(new_policy.policy_id)

            return MCPToolResult(
                success=True,
                data={
                    "message": "Policy updated successfully",
                    "policy_id": new_policy.policy_id,
                    "max_files": new_policy.max_files,
                    "max_lines": new_policy.max_lines,
                    "enforcement_mode": new_policy.enforcement_mode.value,
                },
                metadata={"policy_id": new_policy.policy_id},
            )

        elif action == "reset":
            # Reset to default policy
            default_policy = GovernancePolicy.create_default()
            policy_manager.save_policy(default_policy)
            policy_manager.set_active_policy(default_policy.policy_id)

            return MCPToolResult(
                success=True,
                data={"message": "Policy reset to defaults"},
                metadata={"policy_id": default_policy.policy_id},
            )

        else:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Unknown action: {action}. Must be one of: show, set, reset",
            )

    def _tool_show_audit(self, limit: int = 50) -> MCPToolResult:
        """Show audit trail."""
        from .budget import AuditLog

        audit_log = AuditLog(self.manager.focus_root)
        entries = audit_log.get_entries(limit=limit)

        # Convert audit entries to dicts
        entries_data = [
            {
                "timestamp": entry.timestamp,
                "event_type": entry.event_type.value,
                "policy_id": entry.policy_id,
                "details": entry.details,
                "metadata": entry.metadata,
            }
            for entry in entries
        ]

        return MCPToolResult(
            success=True,
            data={
                "entries": entries_data,
                "total": len(entries),
            },
            metadata={"limit": limit, "total_entries": len(entries)},
        )

    # ========================================================================
    # Sub-Area Tools
    # ========================================================================

    def _tool_split_area(self, area_id: str, strategy: str = "auto") -> MCPToolResult:
        """Analyze area and suggest sub-area splits."""
        from .subarea_analyzer import SubAreaAnalyzer
        from .budget import BudgetTracker

        # Get area
        area = self.manager.areas.get_area(area_id)
        if not area:
            # Create structured refusal for area not found
            available_areas = self.manager.areas.list_areas()
            areas_list = "\n".join([f"  - {a.id}: {a.name}" for a in available_areas[:10]])

            refusal = RefusalResult(
                code=RefusalReason.AREA_NOT_FOUND,
                message=f"Area not found: {area_id}",
                details=f"Available areas:\n{areas_list}",
                hint="Use list_areas tool to see all available areas",
                metadata={"requested_area": area_id, "available_count": len(available_areas)}
            )
            return MCPToolResult.from_refusal(refusal)

        # Get files in area
        files = self.manager.get_files_in_area(area)

        if len(files) < 10:
            refusal = RefusalResult(
                code=RefusalReason.INVALID_STATE,
                message=f"Area is too small to split",
                details=f"Area '{area.name}' has only {len(files)} files. Minimum 10 files required for splitting.",
                hint="Area splitting is only useful for larger areas. Consider merging this area with others or keeping it as-is.",
                metadata={"area_id": area_id, "file_count": len(files), "minimum_required": 10}
            )
            return MCPToolResult.from_refusal(refusal)

        # Create budget tracker
        config = self.manager.load_config()
        max_files = config.get("maxFilesPerArea", 15)
        max_lines = config.get("maxLinesPerArea", 3000)
        budget_tracker = BudgetTracker(max_files=max_files, max_lines=max_lines)

        # Analyze area
        analyzer = SubAreaAnalyzer(self.manager.focus_root, budget_tracker)
        analysis = analyzer.analyze_area(files, area.name, max_depth=2)

        # Convert suggestions to dicts
        suggestions_data = [
            {
                "name": sug.name,
                "description": sug.description,
                "strategy": sug.strategy,
                "confidence": sug.confidence,
                "file_count": sug.file_count,
                "patterns": sug.patterns,
                "metadata": sug.metadata,
            }
            for sug in analysis.suggestions
        ]

        return MCPToolResult(
            success=True,
            data={
                "area_id": area_id,
                "area_name": area.name,
                "total_files": len(files),
                "suggestions": suggestions_data,
                "suggestion_count": len(suggestions_data),
            },
            metadata={"area_id": area_id, "strategy": strategy},
        )

    def _tool_create_subarea(
        self, parent_id: str, name: str, pattern: str
    ) -> MCPToolResult:
        """Create a sub-area within a parent area."""
        from .manager import FocusArea
        from .budget import BudgetTracker
        import fnmatch

        # Get parent area
        parent = self.manager.areas.get_area(parent_id)
        if not parent:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Parent area not found: {parent_id}",
            )

        # Get parent files
        parent_files = self.manager.get_files_in_area(parent)

        # Match pattern
        matched_files = []
        for file_path in parent_files:
            # Try matching against full path and relative path
            if fnmatch.fnmatch(str(file_path), pattern):
                matched_files.append(file_path)
            else:
                try:
                    rel_path = file_path.relative_to(self.manager.focus_root)
                    if fnmatch.fnmatch(str(rel_path), pattern):
                        matched_files.append(file_path)
                except ValueError:
                    pass

        if not matched_files:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Pattern '{pattern}' matches 0 files in parent area '{parent.name}' ({len(parent_files)} files total)",
            )

        # Calculate budget for matched files
        config = self.manager.load_config()
        max_files = config.get("maxFilesPerArea", 15)
        max_lines = config.get("maxLinesPerArea", 3000)
        budget_tracker = BudgetTracker(max_files=max_files, max_lines=max_lines)
        budget_status = budget_tracker.calculate_budget(matched_files)

        # Create subarea ID
        subarea_id = name.lower().replace(" ", "-").replace("_", "-")

        # Create FocusArea
        subarea = FocusArea(
            id=subarea_id,
            name=name.title(),
            description=f"Sub-area of {parent.name}",
            type="manual",
            patterns={"include": [pattern], "exclude": []},
            metadata={
                "parent_area": parent_id,
                "pattern": pattern,
                "created_via": "mcp",
            },
        )

        # Save area
        self.manager.areas.save_area(subarea)

        return MCPToolResult(
            success=True,
            data={
                "message": f"Sub-area '{name}' created successfully",
                "subarea_id": subarea_id,
                "parent_id": parent_id,
                "pattern": pattern,
                "matched_files": len(matched_files),
                "budget": {
                    "files": budget_status.files_used,
                    "max_files": budget_status.files_max,
                    "lines": budget_status.lines_used,
                    "max_lines": budget_status.lines_max,
                },
            },
            metadata={"subarea_id": subarea_id, "parent_id": parent_id},
        )

    # ========================================================================
    # Notes Tools
    # ========================================================================

    def _tool_add_note(self, note_text: str, area_id: Optional[str] = None) -> MCPToolResult:
        """Add a knowledge note to an area."""
        # Determine area_id
        if not area_id:
            area_id = self.manager.get_current_focus()
            if not area_id:
                return MCPToolResult(
                    success=False,
                    data=None,
                    error="No area specified and no active area. Use dig_area first or specify area_id.",
                )

        # Add note
        try:
            note = self.manager.add_note(area_id, note_text)

            note_data = {
                "id": note.id,
                "author": note.author,
                "authorName": note.authorName,
                "timestamp": note.timestamp,
                "note": note.note,
                "tags": note.tags,
            }

            return MCPToolResult(
                success=True,
                data={
                    "message": f"Note added to area '{area_id}'",
                    "note": note_data,
                },
                metadata={"area_id": area_id, "note_id": note.id},
            )
        except ValueError as e:
            return MCPToolResult(
                success=False,
                data=None,
                error=str(e),
            )

    def _tool_show_notes(self, area_id: Optional[str] = None) -> MCPToolResult:
        """Show notes for an area."""
        # Determine area_id
        if not area_id:
            area_id = self.manager.get_current_focus()
            if not area_id:
                return MCPToolResult(
                    success=False,
                    data=None,
                    error="No area specified and no active area. Use dig_area first or specify area_id.",
                )

        # Get notes
        notes = self.manager.get_notes(area_id)

        # Convert to dicts
        notes_data = [
            {
                "id": n.id,
                "author": n.author,
                "authorName": n.authorName,
                "timestamp": n.timestamp,
                "note": n.note,
                "tags": n.tags,
            }
            for n in notes
        ]

        return MCPToolResult(
            success=True,
            data={
                "area_id": area_id,
                "notes": notes_data,
                "total": len(notes),
            },
            metadata={"area_id": area_id, "notes_count": len(notes)},
        )

    def _tool_generate_wiki(self) -> MCPToolResult:
        """Generate wiki documentation for all areas."""
        wiki_content = self.manager.generate_wiki()

        return MCPToolResult(
            success=True,
            data={
                "wiki_content": wiki_content,
                "areas_documented": len(self.manager.areas.list_areas()),
            },
            metadata={"format": "markdown"},
        )

    # ========================================================================
    # Analysis & Intelligence Tools
    # ========================================================================

    def _tool_suggest_areas(self) -> MCPToolResult:
        """Get AI suggestions for areas to explore."""
        current_area = self.manager.get_current_focus()
        suggestions = self.manager.get_area_suggestions(current_area)

        suggestions_data = [
            {"targetAreaId": s.targetAreaId, "reason": s.reason, "score": s.score}
            for s in suggestions
        ]

        return MCPToolResult(
            success=True,
            data={"suggestions": suggestions_data, "total": len(suggestions)},
            metadata={"current_area": current_area},
        )

    def _tool_show_dependencies(self, area_id: Optional[str] = None) -> MCPToolResult:
        """Show dependencies for an area."""
        if not area_id:
            area_id = self.manager.get_current_focus()
            if not area_id:
                refusal = RefusalResult(
                    code=RefusalReason.INVALID_STATE,
                    message="No area specified",
                    details="No area_id provided and no current focus area set",
                    hint="Provide an area_id parameter or use 'dig_area' to set a focus area first",
                    metadata={"has_focus": False}
                )
                return MCPToolResult.from_refusal(refusal)

        deps = self.manager.get_dependencies(area_id)
        deps_data = [
            {"targetArea": d.targetArea, "relationshipType": d.relationshipType, "strength": d.strength}
            for d in deps
        ]

        return MCPToolResult(
            success=True,
            data={"area_id": area_id, "dependencies": deps_data, "total": len(deps)},
            metadata={"area_id": area_id},
        )

    def _tool_analyze_impact(self, area_id: str) -> MCPToolResult:
        """Analyze impact of changes to an area."""
        dependents = self.manager.get_dependents(area_id)
        dependents_data = [
            {"targetArea": d.targetArea, "relationshipType": d.relationshipType}
            for d in dependents
        ]

        return MCPToolResult(
            success=True,
            data={
                "area_id": area_id,
                "affected_areas": len(dependents),
                "dependents": dependents_data,
            },
            metadata={"area_id": area_id},
        )

    def _tool_show_map(self) -> MCPToolResult:
        """Generate codebase map."""
        areas = self.manager.areas.list_areas()
        map_data = [
            {
                "id": a.id,
                "name": a.name,
                "type": a.type,
                "dependencies_count": len(a.dependencies),
            }
            for a in areas
        ]

        return MCPToolResult(
            success=True,
            data={"areas": map_data, "total": len(areas)},
            metadata={"total_areas": len(areas)},
        )

    def _tool_find_hotspots(self, days: int = 30) -> MCPToolResult:
        """Find frequently changed code."""
        hotspots = self.manager.get_hotspots(days=days)
        hotspots_data = [
            {
                "path": str(h.path),
                "commitCount": h.commitCount,
                "complexity": h.complexity,
                "authors": h.authors,
            }
            for h in hotspots[:20]
        ]

        return MCPToolResult(
            success=True,
            data={"hotspots": hotspots_data, "days": days, "total": len(hotspots)},
            metadata={"days": days},
        )

    def _tool_find_gaps(self) -> MCPToolResult:
        """Find coverage gaps."""
        gaps = self.manager.find_coverage_gaps()
        gaps_data = [
            {"areaId": g.areaId, "lineCoverage": g.lineCoverage}
            for g in gaps
        ]

        return MCPToolResult(
            success=True,
            data={"gaps": gaps_data, "total": len(gaps)},
            metadata={"gaps_found": len(gaps)},
        )

    def _tool_analyze_performance(self, area_id: Optional[str] = None) -> MCPToolResult:
        """Perform performance analysis."""
        if not area_id:
            area_id = self.manager.get_current_focus()
            if not area_id:
                refusal = RefusalResult(
                    code=RefusalReason.INVALID_STATE,
                    message="No area specified",
                    details="No area_id provided and no current focus area set",
                    hint="Provide an area_id parameter or use 'dig_area' to set a focus area first",
                    metadata={"has_focus": False}
                )
                return MCPToolResult.from_refusal(refusal)

        complexity = self.manager.get_area_complexity(area_id)

        return MCPToolResult(
            success=True,
            data={"area_id": area_id, "complexity": complexity},
            metadata={"area_id": area_id},
        )

    def _tool_run_benchmark(self) -> MCPToolResult:
        """Run performance benchmarks."""
        benchmarks = self.manager.run_benchmarks()

        return MCPToolResult(
            success=True,
            data={"benchmarks": benchmarks},
            metadata={"timestamp": "current"},
        )

    def _tool_show_trends(self) -> MCPToolResult:
        """Analyze historical trends."""
        trends = self.manager.get_trends()

        return MCPToolResult(
            success=True,
            data={"trends": trends},
            metadata={"analysis_type": "historical"},
        )

    def _tool_show_predictions(self) -> MCPToolResult:
        """Generate predictive insights."""
        predictions = self.manager.get_predictions()

        return MCPToolResult(
            success=True,
            data={"predictions": predictions},
            metadata={"prediction_type": "future_trends"},
        )

    def _tool_get_remediation(self) -> MCPToolResult:
        """Get automated remediation suggestions."""
        remediation = self.manager.get_remediation_suggestions()

        return MCPToolResult(
            success=True,
            data={"remediation": remediation},
            metadata={"suggestion_type": "automated"},
        )

    # ========================================================================
    # Reports, Dashboard, Team Tools
    # ========================================================================

    def _tool_show_analytics(self, days: int = 30) -> MCPToolResult:
        """Show work analytics."""
        analytics = self.manager.get_work_analytics(days=days)

        return MCPToolResult(
            success=True,
            data={
                "totalSessions": analytics.totalSessions,
                "totalTime": analytics.totalTime,
                "topAreas": analytics.topAreas,
                "days": days,
            },
            metadata={"days": days},
        )

    def _tool_generate_report(self) -> MCPToolResult:
        """Generate comprehensive report."""
        report = self.manager.generate_report()

        return MCPToolResult(
            success=True,
            data={"report": report},
            metadata={"format": "markdown"},
        )

    def _tool_create_backup(self) -> MCPToolResult:
        """Create backup of .cdg/ directory."""
        from datetime import datetime

        backup_dir = self.manager.focus_root / "backups"
        backup_path = self.manager.backup_all(backup_dir)

        return MCPToolResult(
            success=True,
            data={
                "message": "Backup created successfully",
                "backup_path": str(backup_path),
            },
            metadata={"backup_path": str(backup_path)},
        )

    def _tool_show_dashboard(self) -> MCPToolResult:
        """Show comprehensive dashboard."""
        dashboard = self.manager.get_dashboard()

        return MCPToolResult(
            success=True,
            data=dashboard,
            metadata={"dashboard_type": "comprehensive"},
        )

    def _tool_check_health(self) -> MCPToolResult:
        """Run health check."""
        health = self.manager.check_health()

        return MCPToolResult(
            success=True,
            data=health,
            metadata={"health_check": "complete"},
        )

    def _tool_show_stats(self) -> MCPToolResult:
        """Show statistics."""
        stats = self.manager.get_stats()

        return MCPToolResult(
            success=True,
            data=stats,
            metadata={"stats_type": "comprehensive"},
        )

    def _tool_show_team_activity(self, max_age_hours: int = 24) -> MCPToolResult:
        """Show team activity."""
        activities = self.manager.get_team_activity(max_age_hours=max_age_hours)

        activities_data = [
            {
                "userId": a.userId,
                "userName": a.userName,
                "currentArea": a.currentArea,
                "currentAreaName": a.currentAreaName,
                "lastActive": a.lastActive,
            }
            for a in activities
        ]

        return MCPToolResult(
            success=True,
            data={"activities": activities_data, "total": len(activities)},
            metadata={"max_age_hours": max_age_hours},
        )

    def _tool_show_test_coverage(self) -> MCPToolResult:
        """Show test coverage."""
        coverage = self.manager.get_test_coverage()

        return MCPToolResult(
            success=True,
            data=coverage,
            metadata={"coverage_type": "overall"},
        )

    def _tool_search_all(self, query: str) -> MCPToolResult:
        """Search across all areas."""
        # Search areas
        areas = self.manager.find_areas(query)
        areas_data = [{"id": a.id, "name": a.name} for a in areas]

        # Search bookmarks
        bookmarks = self.manager.find_bookmarks(query)
        bookmarks_data = [{"id": b.id, "name": b.name, "path": b.path} for b in bookmarks]

        return MCPToolResult(
            success=True,
            data={
                "query": query,
                "areas": areas_data,
                "bookmarks": bookmarks_data,
                "total_results": len(areas) + len(bookmarks),
            },
            metadata={"query": query},
        )

    def _tool_run_query(self, query: str) -> MCPToolResult:
        """Run custom query on codebase data."""
        # For now, return a placeholder indicating this is not yet implemented
        return MCPToolResult(
            success=True,
            data={
                "message": "Custom query execution not yet implemented",
                "query": query,
            },
            metadata={"query": query, "status": "not_implemented"},
        )

    # ========================================================================
    # Automation, Contracts, LLM Tools
    # ========================================================================

    def _tool_show_automation(self) -> MCPToolResult:
        """Show automation suggestions."""
        suggestions = [
            "Set up area-based test automation",
            "Configure auto-bookmarking on file edit",
            "Enable team activity notifications",
        ]

        return MCPToolResult(
            success=True,
            data={"suggestions": suggestions, "total": len(suggestions)},
            metadata={"suggestion_type": "automation"},
        )

    def _tool_list_rules(self) -> MCPToolResult:
        """List automation rules."""
        rules = self.manager.get_automation_rules()

        rules_data = [
            {"name": r.name, "trigger": r.trigger, "action": r.action}
            for r in rules
        ]

        return MCPToolResult(
            success=True,
            data={"rules": rules_data, "total": len(rules)},
            metadata={"rules_count": len(rules)},
        )

    def _tool_list_contracts(self, limit: int = 10) -> MCPToolResult:
        """List all work sessions (continuation contracts)."""
        from .continuation import ContractManager

        contract_manager = ContractManager(self.manager.focus_root)

        # Get active contract
        active = contract_manager.get_active_contract()

        # Get history
        history = contract_manager.get_contract_history(limit=limit)

        contracts_data = []
        if active:
            contracts_data.append({
                "id": active.id,
                "area_id": active.area_id,
                "area_name": active.area_name,
                "intent": active.intent,
                "state": active.state,
                "status": active.status,
                "progress": active.progress,
                "created_at": active.created_at,
                "is_active": True,
            })

        for contract in history:
            contracts_data.append({
                "id": contract.id,
                "area_id": contract.area_id,
                "area_name": contract.area_name,
                "intent": contract.intent,
                "state": contract.state,
                "status": contract.status,
                "progress": contract.progress,
                "created_at": contract.created_at,
                "is_active": False,
            })

        return MCPToolResult(
            success=True,
            data={"contracts": contracts_data, "total": len(contracts_data)},
            metadata={"limit": limit},
        )

    def _tool_manage_llm(self, action: str) -> MCPToolResult:
        """Manage LLM integration."""
        if action == "status":
            # Return LLM integration status
            return MCPToolResult(
                success=True,
                data={
                    "status": "available",
                    "provider": "contextdigger",
                    "message": "LLM integration ready for use",
                },
                metadata={"action": "status"},
            )
        elif action == "enable":
            # Enable LLM integration
            return MCPToolResult(
                success=True,
                data={"message": "LLM integration enabled"},
                metadata={"action": "enable"},
            )
        elif action == "disable":
            # Disable LLM integration
            return MCPToolResult(
                success=True,
                data={"message": "LLM integration disabled"},
                metadata={"action": "disable"},
            )
        else:
            return MCPToolResult(
                success=False,
                data=None,
                error=f"Unknown action: {action}. Must be one of: status, enable, disable",
            )


# ============================================================================
# JSON-RPC Protocol Handler
# ============================================================================


class MCPProtocolHandler:
    """
    Handles JSON-RPC protocol for MCP server.

    Implements the Model Context Protocol specification for communication
    with AI tools via stdin/stdout.
    """

    def __init__(self, server: ContextDiggerMCPServer):
        """
        Initialize protocol handler.

        Args:
            server: ContextDiggerMCPServer instance
        """
        self.server = server
        import sys
        import logging

        self.stdin = sys.stdin
        self.stdout = sys.stdout
        self.logger = logging.getLogger(__name__)

    def run(self):
        """
        Run the JSON-RPC message loop.

        Reads JSON-RPC requests from stdin and writes responses to stdout.
        """
        self.logger.info("JSON-RPC message loop started")

        try:
            for line in self.stdin:
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    response = self.handle_request(request)

                    if response:
                        self.stdout.write(json.dumps(response) + "\n")
                        self.stdout.flush()

                except json.JSONDecodeError as e:
                    self.logger.error(f"Invalid JSON: {e}")
                    error_response = self._error_response(
                        None, -32700, "Parse error"
                    )
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

                except Exception as e:
                    self.logger.error(f"Error handling request: {e}", exc_info=True)
                    error_response = self._error_response(
                        None, -32603, f"Internal error: {str(e)}"
                    )
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

        except KeyboardInterrupt:
            self.logger.info("Server shutdown requested")
        except Exception as e:
            self.logger.error(f"Fatal error in message loop: {e}", exc_info=True)

    def handle_request(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle a JSON-RPC request.

        Args:
            request: JSON-RPC request object

        Returns:
            JSON-RPC response object or None for notifications
        """
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")

        self.logger.debug(f"Handling request: {method}")

        try:
            # Route to appropriate handler
            if method == "initialize":
                result = self._handle_initialize(params)
            elif method == "resources/list":
                result = self._handle_list_resources()
            elif method == "resources/read":
                result = self._handle_read_resource(params)
            elif method == "tools/list":
                result = self._handle_list_tools()
            elif method == "tools/call":
                result = self._handle_call_tool(params)
            elif method == "ping":
                result = {"status": "ok"}
            else:
                return self._error_response(request_id, -32601, f"Method not found: {method}")

            # Return response (None for notifications)
            if request_id is not None:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result,
                }

            return None

        except Exception as e:
            # Catch any errors and return as JSON-RPC error
            self.logger.error(f"Error in request handler: {e}", exc_info=True)
            return self._error_response(request_id, -32603, f"Internal error: {str(e)}")

    def _handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        return {
            "protocolVersion": "1.0",
            "serverInfo": {
                "name": "contextdigger",
                "version": "2.0.0",
            },
            "capabilities": {
                "resources": {"subscribe": False, "listChanged": False},
                "tools": {},
            },
        }

    def _handle_list_resources(self) -> Dict[str, Any]:
        """Handle resources/list request."""
        resources = self.server.list_resources()

        return {
            "resources": [
                {
                    "uri": r.uri,
                    "name": r.name,
                    "description": r.description,
                    "mimeType": r.mimeType,
                }
                for r in resources
            ]
        }

    def _handle_read_resource(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle resources/read request."""
        uri = params.get("uri")
        if not uri:
            raise ValueError("Missing required parameter: uri")

        content = self.server.get_resource(uri)

        return {
            "contents": [
                {
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps(content, indent=2),
                }
            ]
        }

    def _handle_list_tools(self) -> Dict[str, Any]:
        """Handle tools/list request."""
        tools = self.server.list_tools()

        return {
            "tools": [
                {
                    "name": t.name,
                    "description": t.description,
                    "inputSchema": t.inputSchema,
                }
                for t in tools
            ]
        }

    def _handle_call_tool(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        if not tool_name:
            raise ValueError("Missing required parameter: name")

        result = self.server.execute_tool(tool_name, arguments)

        if result.success:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(result.data, indent=2),
                    }
                ],
                "isError": False,
            }
        else:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Error: {result.error}",
                    }
                ],
                "isError": True,
            }

    def _error_response(
        self, request_id: Any, code: int, message: str
    ) -> Dict[str, Any]:
        """Create JSON-RPC error response."""
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            },
        }


# ============================================================================
# MCP Server Entry Point (for stdio mode)
# ============================================================================


def main():
    """
    Run MCP server in stdio mode for integration with AI tools.

    This is the entry point that will be called by AI tools like Claude Desktop.
    The server communicates via JSON-RPC over stdin/stdout.
    """
    import sys
    import logging

    # Set up logging to stderr (stdout is used for MCP protocol)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stderr,
    )

    logger = logging.getLogger(__name__)
    logger.info("Starting ContextDigger MCP Server...")

    # Initialize server with current directory
    server = ContextDiggerMCPServer()

    logger.info(f"Server initialized for project: {server.project_root}")
    logger.info(f"Available resources: {len(server.list_resources())}")
    logger.info(f"Available tools: {len(server.list_tools())}")

    # Run JSON-RPC protocol handler
    handler = MCPProtocolHandler(server)
    logger.info("Server ready - waiting for requests...")
    handler.run()

    logger.info("Server shutdown complete")


if __name__ == "__main__":
    main()
