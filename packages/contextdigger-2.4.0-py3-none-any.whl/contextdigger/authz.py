"""
Authorization and Permission System

Provides token-based permissions for ContextDigger API operations.
Designed to be provider-agnostic - can validate tokens from:
- Local file storage (.cdg/tokens.json)
- JWT from Okta/Auth0 (future)
- Subscription tiers from Chargebee (future)

This enables:
1. Permission-based access control (READ_AREAS, DIG, INSIGHTS, etc.)
2. Tier-based limits (FREE, TEAM, ENTERPRISE)
3. External identity provider integration
"""

from enum import Enum
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Set, Protocol
from datetime import datetime
import json


class Permission(Enum):
    """Permissions for ContextDigger operations."""

    # Basic read operations
    READ_AREAS = "read_areas"           # List available code areas
    READ_CONFIG = "read_config"         # Read .cdg configuration

    # Core navigation
    DIG = "dig"                         # Navigate to and load code areas
    FOCUS = "focus"                     # Manipulate focus (add/remove files)

    # Session management
    CONTINUATION = "continuation"       # Create/resume/pause continuation contracts
    BOOKMARKS = "bookmarks"             # Create/use bookmarks
    SNAPSHOTS = "snapshots"             # Save/load context snapshots

    # Analytics & Intelligence
    INSIGHTS = "insights"               # View insights and recommendations
    TRENDS = "trends"                   # View trend analysis
    PROVENANCE = "provenance"           # View file provenance

    # Reporting & Export
    REPORTS = "reports"                 # Generate reports
    EXPORT = "export"                   # Export context/data

    # Governance
    POLICY = "policy"                   # Manage budget policies
    AUDIT = "audit"                     # View audit logs

    # Admin operations
    ADMIN = "admin"                     # Full administrative access


class Tier(Enum):
    """Subscription tiers with increasing capabilities."""

    FREE = "free"                       # Free tier with basic features
    TEAM = "team"                       # Team tier ($15/user/month)
    ENTERPRISE = "enterprise"           # Enterprise tier ($40/user/month)

    def get_default_permissions(self) -> Set[Permission]:
        """Get default permissions for this tier."""
        if self == Tier.FREE:
            return {
                Permission.READ_AREAS,
                Permission.READ_CONFIG,
                Permission.DIG,
                Permission.FOCUS,
                Permission.CONTINUATION,
                Permission.BOOKMARKS,
                Permission.SNAPSHOTS,
                Permission.INSIGHTS,
                Permission.PROVENANCE,
            }
        elif self == Tier.TEAM:
            # Team has everything in Free plus:
            return {
                *Tier.FREE.get_default_permissions(),
                Permission.TRENDS,
                Permission.REPORTS,
                Permission.EXPORT,
                Permission.POLICY,
                Permission.AUDIT,
            }
        elif self == Tier.ENTERPRISE:
            # Enterprise has all permissions
            return set(Permission)

        return set()

    def get_budget_multiplier(self) -> float:
        """Get budget multiplier for this tier."""
        if self == Tier.FREE:
            return 1.0
        elif self == Tier.TEAM:
            return 2.0
        elif self == Tier.ENTERPRISE:
            return 5.0
        return 1.0


@dataclass(frozen=True)
class TokenInfo:
    """
    Information about a validated token.

    This structure is provider-agnostic:
    - For LocalFileAuthz: token is the key from .cdg/tokens.json
    - For OktaJwtAuthz: token is the JWT, subject is from 'sub' claim
    - For ChargebeeAuthz: subject is subscription ID, tier from plan
    """

    token: str                          # Raw token value
    tier: Tier                          # Subscription tier
    permissions: Set[Permission]        # Explicit granted permissions
    subject: str                        # Subject ID (user, subscription, etc.)
    expires_at: Optional[datetime] = None  # Optional expiration

    def has_permission(self, permission: Permission) -> bool:
        """Check if token has specific permission."""
        return permission in self.permissions


class AuthzBackend(Protocol):
    """
    Authorization backend interface.

    Implementations validate tokens and return TokenInfo with permissions.
    This is provider-agnostic - can be implemented for:
    - Local file storage
    - JWT from Okta/Auth0
    - Subscription APIs like Chargebee
    """

    def validate_token(self, raw_token: str) -> TokenInfo:
        """
        Validate token and return TokenInfo with permissions.

        Args:
            raw_token: Raw token string

        Returns:
            TokenInfo with tier and permissions

        Raises:
            AuthzError: If token is invalid or expired
        """
        ...


class AuthzError(Exception):
    """Raised when token validation fails."""

    def __init__(self, code: str, message: str, details: Optional[str] = None):
        self.code = code
        self.message = message
        self.details = details
        super().__init__(message)


class LocalFileAuthz:
    """
    Local file-based authorization backend.

    Reads token mappings from .cdg/tokens.json:
    {
      "tokens": {
        "dev-token-123": {
          "tier": "team",
          "subject": "local-dev",
          "permissions": ["dig", "insights", "reports"]  # optional overrides
        }
      }
    }

    If no tokens.json exists, creates default with a single full-access token.
    """

    DEFAULT_TOKEN = "local-dev-full-access"

    def __init__(self, workspace: Path):
        """Initialize with workspace path."""
        self.workspace = workspace
        self.tokens_file = workspace / ".cdg" / "tokens.json"
        self._ensure_tokens_file()

    def _ensure_tokens_file(self):
        """Ensure tokens.json exists with default token."""
        if self.tokens_file.exists():
            return

        # Create default tokens file
        default_tokens = {
            "tokens": {
                self.DEFAULT_TOKEN: {
                    "tier": "enterprise",
                    "subject": "local-dev",
                    "description": "Default full-access token for local development"
                }
            }
        }

        self.tokens_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.tokens_file, 'w') as f:
            json.dump(default_tokens, f, indent=2)

    def validate_token(self, raw_token: str) -> TokenInfo:
        """
        Validate token against local file storage.

        Args:
            raw_token: Token string to validate

        Returns:
            TokenInfo with tier and permissions

        Raises:
            AuthzError: If token is invalid
        """
        try:
            with open(self.tokens_file, 'r') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            raise AuthzError(
                code="configuration_error",
                message="Failed to read tokens configuration",
                details=str(e)
            )

        tokens = data.get("tokens", {})
        token_data = tokens.get(raw_token)

        if not token_data:
            raise AuthzError(
                code="invalid_token",
                message=f"Token not found or invalid",
                details=f"Token '{raw_token}' not present in tokens.json"
            )

        # Parse tier
        tier_str = token_data.get("tier", "free")
        try:
            tier = Tier(tier_str)
        except ValueError:
            raise AuthzError(
                code="configuration_error",
                message=f"Invalid tier '{tier_str}' in token configuration"
            )

        # Get permissions
        # Use explicit permissions if provided, otherwise use tier defaults
        if "permissions" in token_data:
            perm_strings = token_data["permissions"]
            try:
                permissions = {Permission(p) for p in perm_strings}
            except ValueError as e:
                raise AuthzError(
                    code="configuration_error",
                    message=f"Invalid permission in token configuration: {e}"
                )
        else:
            permissions = tier.get_default_permissions()

        # Get subject
        subject = token_data.get("subject", "unknown")

        # Get expiration (if any)
        expires_at = None
        if "expires_at" in token_data:
            try:
                expires_at = datetime.fromisoformat(token_data["expires_at"])
                if expires_at < datetime.now():
                    raise AuthzError(
                        code="expired_token",
                        message="Token has expired",
                        details=f"Token expired at {expires_at}"
                    )
            except ValueError:
                raise AuthzError(
                    code="configuration_error",
                    message="Invalid expires_at format (use ISO 8601)"
                )

        return TokenInfo(
            token=raw_token,
            tier=tier,
            permissions=permissions,
            subject=subject,
            expires_at=expires_at
        )

    def create_token(
        self,
        token: str,
        tier: Tier,
        subject: str,
        permissions: Optional[Set[Permission]] = None,
        description: Optional[str] = None
    ) -> None:
        """
        Create a new token (helper for testing/setup).

        Args:
            token: Token string
            tier: Subscription tier
            subject: Subject identifier
            permissions: Optional explicit permissions (defaults to tier permissions)
            description: Optional description
        """
        with open(self.tokens_file, 'r') as f:
            data = json.load(f)

        token_data = {
            "tier": tier.value,
            "subject": subject,
        }

        if permissions:
            token_data["permissions"] = [p.value for p in permissions]

        if description:
            token_data["description"] = description

        data["tokens"][token] = token_data

        with open(self.tokens_file, 'w') as f:
            json.dump(data, f, indent=2)


# Future backends (stubs for now)

class OktaJwtAuthz:
    """
    Okta JWT authorization backend (future).

    Would validate JWT tokens from Okta:
    - Verify signature
    - Check expiration
    - Map claims to permissions (e.g., groups → permissions)
    - Map custom claims to tier
    """

    def __init__(self, okta_domain: str, client_id: str):
        self.okta_domain = okta_domain
        self.client_id = client_id
        raise NotImplementedError("OktaJwtAuthz not yet implemented")

    def validate_token(self, raw_token: str) -> TokenInfo:
        raise NotImplementedError()


class ChargebeeAuthz:
    """
    Chargebee subscription authorization backend (future).

    Would validate tokens by querying Chargebee API:
    - Verify subscription is active
    - Map plan_id to tier (FREE, TEAM, ENTERPRISE)
    - Set permissions based on tier
    """

    def __init__(self, api_key: str, site: str):
        self.api_key = api_key
        self.site = site
        raise NotImplementedError("ChargebeeAuthz not yet implemented")

    def validate_token(self, raw_token: str) -> TokenInfo:
        raise NotImplementedError()


def get_authz_backend(workspace: Path, backend_type: str = "local") -> AuthzBackend:
    """
    Factory function to get configured authz backend.

    Args:
        workspace: Workspace path
        backend_type: Backend type ("local", "okta", "chargebee")

    Returns:
        AuthzBackend instance
    """
    if backend_type == "local":
        return LocalFileAuthz(workspace)
    elif backend_type == "okta":
        raise NotImplementedError("Okta backend not yet implemented")
    elif backend_type == "chargebee":
        raise NotImplementedError("Chargebee backend not yet implemented")
    else:
        raise ValueError(f"Unknown backend type: {backend_type}")
