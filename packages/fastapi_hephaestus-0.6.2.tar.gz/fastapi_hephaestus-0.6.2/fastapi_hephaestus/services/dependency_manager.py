"""
Dependency manager for project dependencies.

This module provides the DependencyManager class that handles
resolving and installing project dependencies based on configuration.
"""

import subprocess
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Protocol

from fastapi_hephaestus.constants import (
    BASE_DEPENDENCIES,
    DATABASE_DRIVERS,
    ODM_DEPENDENCIES,
    ORM_DEPENDENCIES,
)
from fastapi_hephaestus.models.project_config import ProjectConfig


class CommandRunner(Protocol):
    """Protocol for running shell commands."""

    def run(
        self,
        command: list[str],
        cwd: Path | None = None,
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a shell command."""
        ...


class SubprocessRunner:
    """Default implementation using subprocess."""

    @staticmethod
    def run(
        command: list[str],
        cwd: Path | None = None,
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """
        Run a shell command using subprocess.

        Args:
            command: The command and arguments to run.
            cwd: The working directory for the command.
            quiet: Whether to suppress output.

        Returns:
            The completed process result.
        """
        kwargs = {"cwd": cwd}
        if quiet:
            kwargs["stdout"] = subprocess.DEVNULL
            kwargs["stderr"] = subprocess.DEVNULL
        return subprocess.run(command, **kwargs)


class DependencyResolver(ABC):
    """Abstract base class for dependency resolution."""

    @abstractmethod
    def resolve(self, config: ProjectConfig) -> list[str]:
        """
        Resolve dependencies based on configuration.

        Args:
            config: The project configuration.

        Returns:
            A list of dependency package names.
        """
        pass


class FastAPIDependencyResolver(DependencyResolver):
    """
    Resolves dependencies for FastAPI projects.

    This resolver determines which packages to install based on
    the project's database type, ORM/ODM selection, and database choice.
    """

    def resolve(self, config: ProjectConfig) -> list[str]:
        """
        Resolve dependencies for a FastAPI project.

        Args:
            config: The project configuration.

        Returns:
            A list of all required dependency package names.
        """
        dependencies = list(BASE_DEPENDENCIES)

        # Add ORM dependencies
        if config.orm and config.orm in ORM_DEPENDENCIES:
            dependencies.extend(ORM_DEPENDENCIES[config.orm])

        # Add ODM dependencies
        if config.odm and config.odm in ODM_DEPENDENCIES:
            dependencies.extend(ODM_DEPENDENCIES[config.odm])

        # Add database driver
        if config.database in DATABASE_DRIVERS:
            dependencies.append(DATABASE_DRIVERS[config.database])

        return dependencies


class DependencyManager:
    """
    Manages project dependencies.

    This class follows the Single Responsibility Principle by handling
    only dependency-related operations. It uses dependency injection
    for the command runner and dependency resolver.

    Attributes:
        runner: The command runner for executing shell commands.
        resolver: The dependency resolver for determining packages.
    """

    def __init__(
        self,
        runner: CommandRunner | None = None,
        resolver: DependencyResolver | None = None,
    ) -> None:
        """
        Initialize the DependencyManager.

        Args:
            runner: Optional command runner. Uses SubprocessRunner if not provided.
            resolver: Optional dependency resolver. Uses FastAPIDependencyResolver
                     if not provided.
        """
        self.runner = runner or SubprocessRunner()
        self.resolver = resolver or FastAPIDependencyResolver()

    def init_project(
        self,
        project_path: Path,
        project_name: str,
        description: str,
    ) -> None:
        """
        Initialize a new uv project.

        Args:
            project_path: The path where the project will be created.
            project_name: The name of the project.
            description: The project description.
        """
        self.runner.run(
            [
                "uv",
                "init",
                ".",
                "--name",
                project_name,
                "--description",
                description,
                "--quiet",
            ],
            cwd=project_path,
        )

    def install_dependencies(self, config: ProjectConfig) -> None:
        """
        Install project dependencies based on configuration.

        Args:
            config: The project configuration.
        """
        dependencies = self.resolver.resolve(config)
        self.runner.run(
            ["uv", "add", *dependencies, "--quiet"],
            cwd=config.path,
        )

    def init_alembic(self, project_path: Path) -> None:
        """
        Initialize Alembic for database migrations.

        Args:
            project_path: The path to the project.
        """
        self.runner.run(
            ["uv", "run", "alembic", "init", "migrations", "--template", "async"],
            cwd=project_path,
            quiet=True,
        )

