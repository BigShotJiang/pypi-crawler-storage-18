"""
Aria File Manager - Intelligent File Operations for ARIA CLI v0.2.2

Comprehensive file management system with environment awareness:
- Environment detection (Termux, Windows, macOS, Linux, WSL)
- Local and remote file browsing
- File CRUD operations (Create, Read, Update, Delete)
- Upload/Download/Sync between devices
- File verification and testing
- App/File opening with routing
- Smart organization and categorization
- HTML/Web file serving with local routing

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    Aria File Manager                            │
    ├─────────────────────────────────────────────────────────────────┤
    │  Environment Layer   │  Detects OS, capabilities, paths        │
    ├──────────────────────┼──────────────────────────────────────────┤
    │  File Browser        │  Local + Remote file listing            │
    ├──────────────────────┼──────────────────────────────────────────┤
    │  Operations Layer    │  CRUD, copy, move, organize             │
    ├──────────────────────┼──────────────────────────────────────────┤
    │  Transfer Layer      │  Upload, Download, Sync                 │
    ├──────────────────────┼──────────────────────────────────────────┤
    │  Routing Layer       │  Open files, serve HTML, route apps     │
    └─────────────────────────────────────────────────────────────────┘
"""

import os
import sys
import json
import hashlib
import shutil
import tempfile
import subprocess
import mimetypes
import threading
import http.server
import socketserver
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
import uuid
import fnmatch

# Optional imports
try:
    from .ssh_router import SSHRouter, get_router, CommandResult
    HAS_SSH = True
except ImportError:
    HAS_SSH = False

try:
    from .aria_space import AriaSpace, Workspace, SyncFile, FileStatus
    HAS_SPACE = True
except ImportError:
    HAS_SPACE = False


# =============================================================================
# Enums and Data Classes
# =============================================================================

class Platform(Enum):
    """Operating system/platform"""
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    TERMUX = "termux"
    WSL = "wsl"
    UNKNOWN = "unknown"


class FileType(Enum):
    """File type categories"""
    TEXT = "text"
    CODE = "code"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    DOCUMENT = "document"
    ARCHIVE = "archive"
    EXECUTABLE = "executable"
    WEB = "web"
    DATA = "data"
    CONFIG = "config"
    OTHER = "other"


class FileLocation(Enum):
    """Where the file is located"""
    LOCAL = "local"
    REMOTE = "remote"
    BOTH = "both"
    SYNCED = "synced"
    CONFLICT = "conflict"


class OperationType(Enum):
    """File operation type"""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    COPY = "copy"
    MOVE = "move"
    RENAME = "rename"
    UPLOAD = "upload"
    DOWNLOAD = "download"
    SYNC = "sync"
    OPEN = "open"
    SERVE = "serve"
    VERIFY = "verify"
    ORGANIZE = "organize"


@dataclass
class Environment:
    """Current system environment"""
    platform: Platform
    hostname: str
    user: str
    home_dir: Path
    temp_dir: Path
    current_dir: Path
    shell: str
    has_gui: bool = True
    has_termux_api: bool = False
    has_ssh: bool = False
    python_version: str = ""
    aria_version: str = "0.2.2"
    
    # Platform-specific paths
    downloads_dir: Optional[Path] = None
    documents_dir: Optional[Path] = None
    pictures_dir: Optional[Path] = None
    storage_root: Optional[Path] = None  # Android/Termux storage
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "platform": self.platform.value,
            "hostname": self.hostname,
            "user": self.user,
            "home_dir": str(self.home_dir),
            "temp_dir": str(self.temp_dir),
            "current_dir": str(self.current_dir),
            "shell": self.shell,
            "has_gui": self.has_gui,
            "has_termux_api": self.has_termux_api,
            "has_ssh": self.has_ssh,
            "python_version": self.python_version,
            "aria_version": self.aria_version,
            "downloads_dir": str(self.downloads_dir) if self.downloads_dir else None,
            "documents_dir": str(self.documents_dir) if self.documents_dir else None,
            "pictures_dir": str(self.pictures_dir) if self.pictures_dir else None,
            "storage_root": str(self.storage_root) if self.storage_root else None,
        }


@dataclass
class FileEntry:
    """File or directory entry with metadata"""
    name: str
    path: Path
    is_dir: bool = False
    size: int = 0
    modified: Optional[datetime] = None
    created: Optional[datetime] = None
    file_type: FileType = FileType.OTHER
    location: FileLocation = FileLocation.LOCAL
    mime_type: str = ""
    permissions: str = ""
    owner: str = ""
    hash: Optional[str] = None
    
    # Sync metadata
    remote_path: Optional[str] = None
    sync_status: Optional[str] = None
    
    def __post_init__(self):
        if not self.mime_type and not self.is_dir:
            mime, _ = mimetypes.guess_type(str(self.path))
            self.mime_type = mime or "application/octet-stream"
        if self.file_type == FileType.OTHER and not self.is_dir:
            self.file_type = self._detect_file_type()
    
    def _detect_file_type(self) -> FileType:
        """Detect file type from extension and mime"""
        ext = self.path.suffix.lower()
        
        # Code files
        code_exts = {'.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.c', '.cpp', 
                     '.h', '.cs', '.go', '.rs', '.rb', '.php', '.swift', '.kt'}
        if ext in code_exts:
            return FileType.CODE
        
        # Web files
        web_exts = {'.html', '.htm', '.css', '.scss', '.sass', '.less', '.vue', '.svelte'}
        if ext in web_exts:
            return FileType.WEB
        
        # Text files
        text_exts = {'.txt', '.md', '.rst', '.log', '.csv'}
        if ext in text_exts:
            return FileType.TEXT
        
        # Config files
        config_exts = {'.json', '.yaml', '.yml', '.toml', '.ini', '.cfg', '.conf', '.env'}
        if ext in config_exts:
            return FileType.CONFIG
        
        # Data files
        data_exts = {'.db', '.sqlite', '.sqlite3', '.sql', '.parquet', '.arrow'}
        if ext in data_exts:
            return FileType.DATA
        
        # Images
        image_exts = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.ico'}
        if ext in image_exts:
            return FileType.IMAGE
        
        # Video
        video_exts = {'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm'}
        if ext in video_exts:
            return FileType.VIDEO
        
        # Audio
        audio_exts = {'.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma'}
        if ext in audio_exts:
            return FileType.AUDIO
        
        # Documents
        doc_exts = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.odt'}
        if ext in doc_exts:
            return FileType.DOCUMENT
        
        # Archives
        archive_exts = {'.zip', '.tar', '.gz', '.bz2', '.xz', '.7z', '.rar'}
        if ext in archive_exts:
            return FileType.ARCHIVE
        
        # Executables
        exec_exts = {'.exe', '.msi', '.app', '.dmg', '.deb', '.rpm', '.sh', '.bat', '.ps1'}
        if ext in exec_exts:
            return FileType.EXECUTABLE
        
        return FileType.OTHER
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "path": str(self.path),
            "is_dir": self.is_dir,
            "size": self.size,
            "modified": self.modified.isoformat() if self.modified else None,
            "created": self.created.isoformat() if self.created else None,
            "file_type": self.file_type.value,
            "location": self.location.value,
            "mime_type": self.mime_type,
            "permissions": self.permissions,
            "hash": self.hash,
            "remote_path": self.remote_path,
            "sync_status": self.sync_status,
        }
    
    @property
    def size_human(self) -> str:
        """Human-readable size"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if self.size < 1024:
                return f"{self.size:.1f} {unit}"
            self.size /= 1024
        return f"{self.size:.1f} PB"


@dataclass
class OperationResult:
    """Result of a file operation"""
    success: bool
    operation: OperationType
    source: str
    destination: Optional[str] = None
    message: str = ""
    error: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    duration_ms: float = 0
    bytes_transferred: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "operation": self.operation.value,
            "source": self.source,
            "destination": self.destination,
            "message": self.message,
            "error": self.error,
            "timestamp": self.timestamp.isoformat(),
            "duration_ms": self.duration_ms,
            "bytes_transferred": self.bytes_transferred,
        }


# =============================================================================
# Environment Detection
# =============================================================================

class EnvironmentDetector:
    """Detects and provides information about the current environment"""
    
    @staticmethod
    def detect() -> Environment:
        """Detect current environment"""
        platform = EnvironmentDetector._detect_platform()
        
        env = Environment(
            platform=platform,
            hostname=EnvironmentDetector._get_hostname(),
            user=os.getenv("USER", os.getenv("USERNAME", "unknown")),
            home_dir=Path.home(),
            temp_dir=Path(tempfile.gettempdir()),
            current_dir=Path.cwd(),
            shell=EnvironmentDetector._detect_shell(),
            has_gui=EnvironmentDetector._has_gui(platform),
            has_termux_api=EnvironmentDetector._has_termux_api(),
            has_ssh=HAS_SSH,
            python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )
        
        # Set platform-specific paths
        EnvironmentDetector._set_platform_paths(env, platform)
        
        return env
    
    @staticmethod
    def _detect_platform() -> Platform:
        """Detect operating system/platform"""
        # Check for Termux first
        if os.path.exists("/data/data/com.termux"):
            return Platform.TERMUX
        
        # Check for WSL
        if sys.platform == "linux":
            try:
                with open("/proc/version", "r") as f:
                    if "microsoft" in f.read().lower():
                        return Platform.WSL
            except:
                pass
        
        # Standard platform detection
        if sys.platform == "win32":
            return Platform.WINDOWS
        elif sys.platform == "darwin":
            return Platform.MACOS
        elif sys.platform == "linux":
            return Platform.LINUX
        
        return Platform.UNKNOWN
    
    @staticmethod
    def _get_hostname() -> str:
        """Get system hostname"""
        import socket
        try:
            return socket.gethostname()
        except:
            return "unknown"
    
    @staticmethod
    def _detect_shell() -> str:
        """Detect current shell"""
        shell = os.getenv("SHELL", os.getenv("COMSPEC", ""))
        return Path(shell).name if shell else "unknown"
    
    @staticmethod
    def _has_gui(platform: Platform) -> bool:
        """Check if GUI is available"""
        if platform == Platform.TERMUX:
            return False
        if platform in (Platform.WINDOWS, Platform.MACOS):
            return True
        # Linux - check for display
        return bool(os.getenv("DISPLAY") or os.getenv("WAYLAND_DISPLAY"))
    
    @staticmethod
    def _has_termux_api() -> bool:
        """Check if Termux API is available"""
        try:
            result = subprocess.run(
                ["termux-info"],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    @staticmethod
    def _set_platform_paths(env: Environment, platform: Platform):
        """Set platform-specific directory paths"""
        if platform == Platform.TERMUX:
            env.storage_root = Path("/storage/emulated/0")
            env.downloads_dir = env.storage_root / "Download"
            env.documents_dir = env.storage_root / "Documents"
            env.pictures_dir = env.storage_root / "Pictures"
        elif platform == Platform.WINDOWS:
            user_profile = Path(os.getenv("USERPROFILE", str(env.home_dir)))
            env.downloads_dir = user_profile / "Downloads"
            env.documents_dir = user_profile / "Documents"
            env.pictures_dir = user_profile / "Pictures"
        elif platform == Platform.MACOS:
            env.downloads_dir = env.home_dir / "Downloads"
            env.documents_dir = env.home_dir / "Documents"
            env.pictures_dir = env.home_dir / "Pictures"
        elif platform in (Platform.LINUX, Platform.WSL):
            # Check XDG directories first
            xdg_download = os.getenv("XDG_DOWNLOAD_DIR")
            xdg_documents = os.getenv("XDG_DOCUMENTS_DIR")
            xdg_pictures = os.getenv("XDG_PICTURES_DIR")
            
            env.downloads_dir = Path(xdg_download) if xdg_download else env.home_dir / "Downloads"
            env.documents_dir = Path(xdg_documents) if xdg_documents else env.home_dir / "Documents"
            env.pictures_dir = Path(xdg_pictures) if xdg_pictures else env.home_dir / "Pictures"


# =============================================================================
# File Browser
# =============================================================================

class FileBrowser:
    """Browse local and remote files"""
    
    def __init__(self, environment: Environment):
        self.env = environment
        self.ssh_router: Optional['SSHRouter'] = None
        if HAS_SSH:
            try:
                self.ssh_router = get_router()
            except:
                pass
    
    def list_local(
        self,
        path: Optional[Path] = None,
        pattern: str = "*",
        recursive: bool = False,
        include_hidden: bool = False,
        file_types: Optional[List[FileType]] = None,
    ) -> List[FileEntry]:
        """
        List files in local directory
        
        Args:
            path: Directory path (default: current directory)
            pattern: Glob pattern for filtering
            recursive: Whether to list recursively
            include_hidden: Include hidden files (starting with .)
            file_types: Filter by file types
        
        Returns:
            List of FileEntry objects
        """
        path = path or self.env.current_dir
        path = Path(path).expanduser().resolve()
        
        if not path.exists():
            return []
        
        entries = []
        
        try:
            if recursive:
                items = path.rglob(pattern)
            else:
                items = path.glob(pattern)
            
            for item in items:
                # Skip hidden files if not requested
                if not include_hidden and item.name.startswith('.'):
                    continue
                
                entry = self._create_entry(item)
                
                # Filter by file type if specified
                if file_types and entry.file_type not in file_types:
                    continue
                
                entries.append(entry)
        except PermissionError:
            pass
        
        # Sort: directories first, then by name
        entries.sort(key=lambda e: (not e.is_dir, e.name.lower()))
        
        return entries
    
    def list_remote(
        self,
        host: str,
        path: str = "~",
        pattern: str = "*",
    ) -> List[FileEntry]:
        """
        List files on remote host via SSH
        
        Args:
            host: SSH host name (from ssh config)
            path: Remote directory path
            pattern: Glob pattern for filtering
        
        Returns:
            List of FileEntry objects
        """
        if not self.ssh_router:
            return []
        
        try:
            # Use ls with detailed output
            cmd = f"ls -la {path}"
            if pattern != "*":
                cmd = f"ls -la {path}/{pattern} 2>/dev/null || ls -la {path}"
            
            result = self.ssh_router.execute(host, cmd)
            if not result.success:
                return []
            
            entries = []
            for line in result.stdout.strip().split('\n')[1:]:  # Skip total line
                entry = self._parse_ls_line(line, path)
                if entry:
                    entry.location = FileLocation.REMOTE
                    entries.append(entry)
            
            return entries
        except Exception as e:
            return []
    
    def _create_entry(self, path: Path) -> FileEntry:
        """Create FileEntry from Path"""
        stat = path.stat()
        
        return FileEntry(
            name=path.name,
            path=path,
            is_dir=path.is_dir(),
            size=stat.st_size if not path.is_dir() else 0,
            modified=datetime.fromtimestamp(stat.st_mtime),
            created=datetime.fromtimestamp(stat.st_ctime),
            permissions=oct(stat.st_mode)[-3:],
            location=FileLocation.LOCAL,
        )
    
    def _parse_ls_line(self, line: str, base_path: str) -> Optional[FileEntry]:
        """Parse ls -la output line"""
        parts = line.split()
        if len(parts) < 9:
            return None
        
        # Format: permissions links owner group size month day time/year name
        perms = parts[0]
        size = int(parts[4]) if parts[4].isdigit() else 0
        name = ' '.join(parts[8:])  # Handle names with spaces
        
        if name in ('.', '..'):
            return None
        
        is_dir = perms.startswith('d')
        
        return FileEntry(
            name=name,
            path=Path(f"{base_path}/{name}"),
            is_dir=is_dir,
            size=size,
            permissions=perms,
            location=FileLocation.REMOTE,
            remote_path=f"{base_path}/{name}",
        )
    
    def search(
        self,
        query: str,
        path: Optional[Path] = None,
        recursive: bool = True,
        file_types: Optional[List[FileType]] = None,
    ) -> List[FileEntry]:
        """
        Search for files by name
        
        Args:
            query: Search query (supports wildcards)
            path: Starting path
            recursive: Search recursively
            file_types: Filter by file types
        
        Returns:
            List of matching FileEntry objects
        """
        path = path or self.env.current_dir
        pattern = f"*{query}*" if '*' not in query else query
        
        return self.list_local(
            path=path,
            pattern=pattern,
            recursive=recursive,
            include_hidden=True,
            file_types=file_types,
        )
    
    def get_tree(
        self,
        path: Optional[Path] = None,
        max_depth: int = 3,
        include_files: bool = True,
    ) -> Dict[str, Any]:
        """
        Get directory tree structure
        
        Args:
            path: Root path
            max_depth: Maximum depth to traverse
            include_files: Include files (not just directories)
        
        Returns:
            Tree structure as nested dict
        """
        path = path or self.env.current_dir
        path = Path(path).expanduser().resolve()
        
        return self._build_tree(path, max_depth, include_files, 0)
    
    def _build_tree(
        self,
        path: Path,
        max_depth: int,
        include_files: bool,
        current_depth: int,
    ) -> Dict[str, Any]:
        """Build tree recursively"""
        tree = {
            "name": path.name or str(path),
            "path": str(path),
            "is_dir": path.is_dir(),
        }
        
        if not path.is_dir() or current_depth >= max_depth:
            if not path.is_dir():
                tree["size"] = path.stat().st_size
            return tree
        
        tree["children"] = []
        
        try:
            for item in sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                if item.name.startswith('.'):
                    continue
                
                if item.is_dir():
                    tree["children"].append(
                        self._build_tree(item, max_depth, include_files, current_depth + 1)
                    )
                elif include_files:
                    tree["children"].append({
                        "name": item.name,
                        "path": str(item),
                        "is_dir": False,
                        "size": item.stat().st_size,
                    })
        except PermissionError:
            pass
        
        return tree


# =============================================================================
# File Operations
# =============================================================================

class FileOperations:
    """CRUD and other file operations"""
    
    def __init__(self, environment: Environment):
        self.env = environment
        self.operation_log: List[OperationResult] = []
    
    def create(
        self,
        path: Union[str, Path],
        content: str = "",
        is_dir: bool = False,
        parents: bool = True,
    ) -> OperationResult:
        """
        Create file or directory
        
        Args:
            path: Path to create
            content: File content (if creating file)
            is_dir: Create directory instead of file
            parents: Create parent directories
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        try:
            if is_dir:
                path.mkdir(parents=parents, exist_ok=True)
                result = OperationResult(
                    success=True,
                    operation=OperationType.CREATE,
                    source=str(path),
                    message=f"Created directory: {path.name}",
                )
            else:
                if parents:
                    path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding='utf-8')
                result = OperationResult(
                    success=True,
                    operation=OperationType.CREATE,
                    source=str(path),
                    message=f"Created file: {path.name}",
                    bytes_transferred=len(content.encode('utf-8')),
                )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.CREATE,
                source=str(path),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        self.operation_log.append(result)
        return result
    
    def read(self, path: Union[str, Path], binary: bool = False) -> Tuple[Optional[Union[str, bytes]], OperationResult]:
        """
        Read file content
        
        Args:
            path: File path
            binary: Read as binary
        
        Returns:
            Tuple of (content, OperationResult)
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        try:
            if binary:
                content = path.read_bytes()
            else:
                content = path.read_text(encoding='utf-8')
            
            result = OperationResult(
                success=True,
                operation=OperationType.READ,
                source=str(path),
                message=f"Read file: {path.name}",
                bytes_transferred=len(content) if isinstance(content, bytes) else len(content.encode('utf-8')),
            )
            result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
            self.operation_log.append(result)
            return content, result
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.READ,
                source=str(path),
                error=str(e),
            )
            result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
            self.operation_log.append(result)
            return None, result
    
    def update(
        self,
        path: Union[str, Path],
        content: str,
        append: bool = False,
    ) -> OperationResult:
        """
        Update file content
        
        Args:
            path: File path
            content: New content
            append: Append instead of overwrite
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        try:
            mode = 'a' if append else 'w'
            with open(path, mode, encoding='utf-8') as f:
                f.write(content)
            
            result = OperationResult(
                success=True,
                operation=OperationType.UPDATE,
                source=str(path),
                message=f"{'Appended to' if append else 'Updated'} file: {path.name}",
                bytes_transferred=len(content.encode('utf-8')),
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.UPDATE,
                source=str(path),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        self.operation_log.append(result)
        return result
    
    def delete(
        self,
        path: Union[str, Path],
        recursive: bool = False,
    ) -> OperationResult:
        """
        Delete file or directory
        
        Args:
            path: Path to delete
            recursive: Delete directory contents recursively
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        try:
            if path.is_dir():
                if recursive:
                    shutil.rmtree(path)
                else:
                    path.rmdir()
            else:
                path.unlink()
            
            result = OperationResult(
                success=True,
                operation=OperationType.DELETE,
                source=str(path),
                message=f"Deleted: {path.name}",
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.DELETE,
                source=str(path),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        self.operation_log.append(result)
        return result
    
    def copy(
        self,
        source: Union[str, Path],
        destination: Union[str, Path],
    ) -> OperationResult:
        """Copy file or directory"""
        start = datetime.utcnow()
        source = Path(source).expanduser()
        destination = Path(destination).expanduser()
        
        try:
            if source.is_dir():
                shutil.copytree(source, destination)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            
            result = OperationResult(
                success=True,
                operation=OperationType.COPY,
                source=str(source),
                destination=str(destination),
                message=f"Copied {source.name} to {destination}",
                bytes_transferred=source.stat().st_size if source.is_file() else 0,
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.COPY,
                source=str(source),
                destination=str(destination),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        self.operation_log.append(result)
        return result
    
    def move(
        self,
        source: Union[str, Path],
        destination: Union[str, Path],
    ) -> OperationResult:
        """Move file or directory"""
        start = datetime.utcnow()
        source = Path(source).expanduser()
        destination = Path(destination).expanduser()
        
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(destination))
            
            result = OperationResult(
                success=True,
                operation=OperationType.MOVE,
                source=str(source),
                destination=str(destination),
                message=f"Moved {source.name} to {destination}",
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.MOVE,
                source=str(source),
                destination=str(destination),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        self.operation_log.append(result)
        return result
    
    def rename(
        self,
        path: Union[str, Path],
        new_name: str,
    ) -> OperationResult:
        """Rename file or directory"""
        path = Path(path).expanduser()
        new_path = path.parent / new_name
        return self.move(path, new_path)
    
    def verify(self, path: Union[str, Path]) -> Tuple[bool, OperationResult]:
        """
        Verify file exists and is readable
        
        Returns:
            Tuple of (is_valid, OperationResult)
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        try:
            if not path.exists():
                result = OperationResult(
                    success=False,
                    operation=OperationType.VERIFY,
                    source=str(path),
                    error="File does not exist",
                )
                return False, result
            
            # Check readability
            if path.is_file():
                with open(path, 'rb') as f:
                    f.read(1024)  # Read first KB to verify
            
            # Calculate hash
            file_hash = self.calculate_hash(path) if path.is_file() else None
            
            result = OperationResult(
                success=True,
                operation=OperationType.VERIFY,
                source=str(path),
                message=f"File verified: {path.name}" + (f" (SHA256: {file_hash[:16]}...)" if file_hash else ""),
            )
            result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
            self.operation_log.append(result)
            return True, result
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.VERIFY,
                source=str(path),
                error=str(e),
            )
            result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
            self.operation_log.append(result)
            return False, result
    
    def calculate_hash(self, path: Union[str, Path], algorithm: str = "sha256") -> str:
        """Calculate file hash"""
        path = Path(path).expanduser()
        hasher = hashlib.new(algorithm)
        
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                hasher.update(chunk)
        
        return hasher.hexdigest()
    
    def organize(
        self,
        source_dir: Union[str, Path],
        target_dir: Optional[Union[str, Path]] = None,
        by: str = "type",  # type, date, extension
        dry_run: bool = False,
    ) -> List[OperationResult]:
        """
        Organize files into folders
        
        Args:
            source_dir: Directory to organize
            target_dir: Target directory (default: same as source)
            by: Organization method (type, date, extension)
            dry_run: Preview without moving
        
        Returns:
            List of OperationResult for each file moved
        """
        source_dir = Path(source_dir).expanduser()
        target_dir = Path(target_dir).expanduser() if target_dir else source_dir
        
        results = []
        
        for item in source_dir.iterdir():
            if item.is_dir() or item.name.startswith('.'):
                continue
            
            entry = FileEntry(
                name=item.name,
                path=item,
                modified=datetime.fromtimestamp(item.stat().st_mtime),
            )
            
            # Determine target folder
            if by == "type":
                folder = entry.file_type.value
            elif by == "date":
                folder = entry.modified.strftime("%Y-%m") if entry.modified else "unknown"
            elif by == "extension":
                folder = item.suffix.lower()[1:] if item.suffix else "no_extension"
            else:
                folder = "other"
            
            dest = target_dir / folder / item.name
            
            if dry_run:
                results.append(OperationResult(
                    success=True,
                    operation=OperationType.ORGANIZE,
                    source=str(item),
                    destination=str(dest),
                    message=f"[DRY RUN] Would move to {folder}/",
                ))
            else:
                result = self.move(item, dest)
                result.operation = OperationType.ORGANIZE
                results.append(result)
        
        return results


# =============================================================================
# File Transfer
# =============================================================================

class FileTransfer:
    """Upload, download, and sync files between local and remote"""
    
    def __init__(self, environment: Environment):
        self.env = environment
        self.ssh_router: Optional['SSHRouter'] = None
        if HAS_SSH:
            try:
                self.ssh_router = get_router()
            except:
                pass
    
    def upload(
        self,
        local_path: Union[str, Path],
        remote_host: str,
        remote_path: str,
    ) -> OperationResult:
        """
        Upload file to remote host
        
        Args:
            local_path: Local file path
            remote_host: SSH host name
            remote_path: Remote destination path
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        local_path = Path(local_path).expanduser()
        
        if not self.ssh_router:
            return OperationResult(
                success=False,
                operation=OperationType.UPLOAD,
                source=str(local_path),
                destination=f"{remote_host}:{remote_path}",
                error="SSH not available",
            )
        
        try:
            self.ssh_router.upload(remote_host, str(local_path), remote_path)
            
            result = OperationResult(
                success=True,
                operation=OperationType.UPLOAD,
                source=str(local_path),
                destination=f"{remote_host}:{remote_path}",
                message=f"Uploaded {local_path.name} to {remote_host}",
                bytes_transferred=local_path.stat().st_size,
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.UPLOAD,
                source=str(local_path),
                destination=f"{remote_host}:{remote_path}",
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        return result
    
    def download(
        self,
        remote_host: str,
        remote_path: str,
        local_path: Union[str, Path],
    ) -> OperationResult:
        """
        Download file from remote host
        
        Args:
            remote_host: SSH host name
            remote_path: Remote file path
            local_path: Local destination path
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        local_path = Path(local_path).expanduser()
        
        if not self.ssh_router:
            return OperationResult(
                success=False,
                operation=OperationType.DOWNLOAD,
                source=f"{remote_host}:{remote_path}",
                destination=str(local_path),
                error="SSH not available",
            )
        
        try:
            # Ensure parent directory exists
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            self.ssh_router.download(remote_host, remote_path, str(local_path))
            
            result = OperationResult(
                success=True,
                operation=OperationType.DOWNLOAD,
                source=f"{remote_host}:{remote_path}",
                destination=str(local_path),
                message=f"Downloaded {Path(remote_path).name} from {remote_host}",
                bytes_transferred=local_path.stat().st_size if local_path.exists() else 0,
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.DOWNLOAD,
                source=f"{remote_host}:{remote_path}",
                destination=str(local_path),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        return result
    
    def sync_folder(
        self,
        local_dir: Union[str, Path],
        remote_host: str,
        remote_dir: str,
        direction: str = "bidirectional",  # upload, download, bidirectional
        dry_run: bool = False,
    ) -> List[OperationResult]:
        """
        Sync folder between local and remote
        
        Args:
            local_dir: Local directory
            remote_host: SSH host name
            remote_dir: Remote directory
            direction: Sync direction
            dry_run: Preview without syncing
        
        Returns:
            List of OperationResult
        """
        results = []
        local_dir = Path(local_dir).expanduser()
        
        if not self.ssh_router:
            return [OperationResult(
                success=False,
                operation=OperationType.SYNC,
                source=str(local_dir),
                destination=f"{remote_host}:{remote_dir}",
                error="SSH not available",
            )]
        
        # Use rsync if available
        try:
            if direction in ("upload", "bidirectional"):
                cmd = f"rsync -avz {'--dry-run' if dry_run else ''} {local_dir}/ {remote_host}:{remote_dir}/"
                subprocess.run(cmd, shell=True, check=True)
                results.append(OperationResult(
                    success=True,
                    operation=OperationType.SYNC,
                    source=str(local_dir),
                    destination=f"{remote_host}:{remote_dir}",
                    message=f"{'[DRY RUN] ' if dry_run else ''}Synced to {remote_host}",
                ))
            
            if direction in ("download", "bidirectional"):
                cmd = f"rsync -avz {'--dry-run' if dry_run else ''} {remote_host}:{remote_dir}/ {local_dir}/"
                subprocess.run(cmd, shell=True, check=True)
                results.append(OperationResult(
                    success=True,
                    operation=OperationType.SYNC,
                    source=f"{remote_host}:{remote_dir}",
                    destination=str(local_dir),
                    message=f"{'[DRY RUN] ' if dry_run else ''}Synced from {remote_host}",
                ))
        except Exception as e:
            results.append(OperationResult(
                success=False,
                operation=OperationType.SYNC,
                source=str(local_dir),
                destination=f"{remote_host}:{remote_dir}",
                error=str(e),
            ))
        
        return results


# =============================================================================
# File/App Opener and Router
# =============================================================================

class FileRouter:
    """Open files, serve web content, and route to applications"""
    
    def __init__(self, environment: Environment):
        self.env = environment
        self.servers: Dict[int, threading.Thread] = {}
        self._server_instances: Dict[int, socketserver.TCPServer] = {}
    
    def open_file(self, path: Union[str, Path]) -> OperationResult:
        """
        Open file with default application
        
        Args:
            path: File path to open
        
        Returns:
            OperationResult
        """
        start = datetime.utcnow()
        path = Path(path).expanduser()
        
        if not path.exists():
            return OperationResult(
                success=False,
                operation=OperationType.OPEN,
                source=str(path),
                error="File does not exist",
            )
        
        try:
            if self.env.platform == Platform.WINDOWS:
                os.startfile(str(path))
            elif self.env.platform == Platform.MACOS:
                subprocess.run(['open', str(path)], check=True)
            elif self.env.platform == Platform.TERMUX:
                # Use Termux API to open
                subprocess.run(['termux-open', str(path)], check=True)
            else:
                # Linux/WSL
                subprocess.run(['xdg-open', str(path)], check=True)
            
            result = OperationResult(
                success=True,
                operation=OperationType.OPEN,
                source=str(path),
                message=f"Opened {path.name}",
            )
        except Exception as e:
            result = OperationResult(
                success=False,
                operation=OperationType.OPEN,
                source=str(path),
                error=str(e),
            )
        
        result.duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        return result
    
    def open_url(self, url: str) -> OperationResult:
        """
        Open URL in default browser
        
        Args:
            url: URL to open
        
        Returns:
            OperationResult
        """
        import webbrowser
        
        try:
            webbrowser.open(url)
            return OperationResult(
                success=True,
                operation=OperationType.OPEN,
                source=url,
                message=f"Opened URL in browser",
            )
        except Exception as e:
            return OperationResult(
                success=False,
                operation=OperationType.OPEN,
                source=url,
                error=str(e),
            )
    
    def serve_html(
        self,
        path: Union[str, Path],
        port: int = 8080,
        open_browser: bool = True,
    ) -> OperationResult:
        """
        Serve HTML file locally and optionally open in browser
        
        Args:
            path: HTML file or directory to serve
            port: Port to serve on
            open_browser: Open browser automatically
        
        Returns:
            OperationResult
        """
        path = Path(path).expanduser().resolve()
        
        if path.is_file():
            serve_dir = path.parent
            index_file = path.name
        else:
            serve_dir = path
            index_file = "index.html"
        
        if not serve_dir.exists():
            return OperationResult(
                success=False,
                operation=OperationType.SERVE,
                source=str(path),
                error="Path does not exist",
            )
        
        try:
            # Create custom handler
            class Handler(http.server.SimpleHTTPRequestHandler):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, directory=str(serve_dir), **kwargs)
                
                def log_message(self, format, *args):
                    pass  # Suppress logging
            
            # Find available port
            while port in self._server_instances:
                port += 1
            
            server = socketserver.TCPServer(("", port), Handler)
            
            # Start in background thread
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            
            self.servers[port] = thread
            self._server_instances[port] = server
            
            url = f"http://localhost:{port}/{index_file}" if path.is_file() else f"http://localhost:{port}/"
            
            if open_browser:
                self.open_url(url)
            
            return OperationResult(
                success=True,
                operation=OperationType.SERVE,
                source=str(path),
                message=f"Serving at {url}",
            )
        except Exception as e:
            return OperationResult(
                success=False,
                operation=OperationType.SERVE,
                source=str(path),
                error=str(e),
            )
    
    def stop_server(self, port: int) -> bool:
        """Stop a running server"""
        if port in self._server_instances:
            self._server_instances[port].shutdown()
            del self._server_instances[port]
            del self.servers[port]
            return True
        return False
    
    def list_servers(self) -> List[Dict[str, Any]]:
        """List running servers"""
        return [
            {"port": port, "url": f"http://localhost:{port}/"}
            for port in self._server_instances.keys()
        ]
    
    def route_to_remote(
        self,
        local_path: Union[str, Path],
        remote_host: str,
        remote_port: int = 8080,
    ) -> OperationResult:
        """
        Serve local file and create SSH tunnel for remote access
        
        Args:
            local_path: Local file to serve
            remote_host: Remote host to tunnel from
            remote_port: Remote port to use
        
        Returns:
            OperationResult
        """
        # First serve locally
        local_port = 8080
        serve_result = self.serve_html(local_path, local_port, open_browser=False)
        
        if not serve_result.success:
            return serve_result
        
        # Create reverse tunnel if SSH available
        if HAS_SSH:
            try:
                ssh_router = get_router()
                ssh_router.create_reverse_tunnel(
                    remote_host,
                    remote_port=remote_port,
                    local_port=local_port,
                )
                
                return OperationResult(
                    success=True,
                    operation=OperationType.SERVE,
                    source=str(local_path),
                    message=f"Routed to {remote_host}:{remote_port} (localhost:{local_port})",
                )
            except Exception as e:
                return OperationResult(
                    success=False,
                    operation=OperationType.SERVE,
                    source=str(local_path),
                    error=f"Tunnel failed: {e}",
                )
        
        return OperationResult(
            success=True,
            operation=OperationType.SERVE,
            source=str(local_path),
            message=f"Serving locally at localhost:{local_port} (SSH not available for tunneling)",
        )


# =============================================================================
# Main File Manager
# =============================================================================

class AriaFileManager:
    """
    Aria's Intelligent File Manager
    
    Provides comprehensive file management with:
    - Environment detection and awareness
    - Local and remote file browsing
    - CRUD operations
    - Transfer (upload/download/sync)
    - File/app opening and routing
    - Smart organization
    
    Usage:
        manager = AriaFileManager()
        
        # Check environment
        print(manager.environment.platform)
        
        # Browse files
        files = manager.list_files()
        
        # Create file
        manager.create("notes.txt", content="Hello!")
        
        # Download from phone
        manager.download("termux-phone", "/storage/emulated/0/Download/file.pdf", "~/Downloads/")
        
        # Serve HTML and route
        manager.serve("webpage.html", port=8080)
        manager.route_to_remote("webpage.html", "termux-phone", 8080)
    """
    
    def __init__(self):
        self.environment = EnvironmentDetector.detect()
        self.browser = FileBrowser(self.environment)
        self.operations = FileOperations(self.environment)
        self.transfer = FileTransfer(self.environment)
        self.router = FileRouter(self.environment)
    
    # =========================================================================
    # Environment
    # =========================================================================
    
    def get_environment(self) -> Dict[str, Any]:
        """Get current environment info"""
        return self.environment.to_dict()
    
    def is_termux(self) -> bool:
        """Check if running on Termux"""
        return self.environment.platform == Platform.TERMUX
    
    def is_windows(self) -> bool:
        """Check if running on Windows"""
        return self.environment.platform == Platform.WINDOWS
    
    # =========================================================================
    # Browsing
    # =========================================================================
    
    def list_files(
        self,
        path: Optional[str] = None,
        pattern: str = "*",
        recursive: bool = False,
        file_types: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """List files in directory"""
        types = [FileType(t) for t in file_types] if file_types else None
        entries = self.browser.list_local(
            Path(path) if path else None,
            pattern,
            recursive,
            file_types=types,
        )
        return [e.to_dict() for e in entries]
    
    def list_remote(self, host: str, path: str = "~") -> List[Dict[str, Any]]:
        """List files on remote host"""
        entries = self.browser.list_remote(host, path)
        return [e.to_dict() for e in entries]
    
    def search(self, query: str, path: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for files"""
        entries = self.browser.search(query, Path(path) if path else None)
        return [e.to_dict() for e in entries]
    
    def tree(self, path: Optional[str] = None, depth: int = 3) -> Dict[str, Any]:
        """Get directory tree"""
        return self.browser.get_tree(Path(path) if path else None, depth)
    
    # =========================================================================
    # CRUD Operations
    # =========================================================================
    
    def create(
        self,
        path: str,
        content: str = "",
        is_dir: bool = False,
    ) -> Dict[str, Any]:
        """Create file or directory"""
        return self.operations.create(path, content, is_dir).to_dict()
    
    def read(self, path: str) -> Tuple[Optional[str], Dict[str, Any]]:
        """Read file content"""
        content, result = self.operations.read(path)
        return content, result.to_dict()
    
    def update(self, path: str, content: str, append: bool = False) -> Dict[str, Any]:
        """Update file content"""
        return self.operations.update(path, content, append).to_dict()
    
    def delete(self, path: str, recursive: bool = False) -> Dict[str, Any]:
        """Delete file or directory"""
        return self.operations.delete(path, recursive).to_dict()
    
    def copy(self, source: str, destination: str) -> Dict[str, Any]:
        """Copy file or directory"""
        return self.operations.copy(source, destination).to_dict()
    
    def move(self, source: str, destination: str) -> Dict[str, Any]:
        """Move file or directory"""
        return self.operations.move(source, destination).to_dict()
    
    def rename(self, path: str, new_name: str) -> Dict[str, Any]:
        """Rename file or directory"""
        return self.operations.rename(path, new_name).to_dict()
    
    def verify(self, path: str) -> Tuple[bool, Dict[str, Any]]:
        """Verify file exists and is readable"""
        valid, result = self.operations.verify(path)
        return valid, result.to_dict()
    
    def organize(
        self,
        source_dir: str,
        target_dir: Optional[str] = None,
        by: str = "type",
        dry_run: bool = False,
    ) -> List[Dict[str, Any]]:
        """Organize files into folders"""
        results = self.operations.organize(source_dir, target_dir, by, dry_run)
        return [r.to_dict() for r in results]
    
    # =========================================================================
    # Transfer
    # =========================================================================
    
    def upload(self, local_path: str, remote_host: str, remote_path: str) -> Dict[str, Any]:
        """Upload file to remote host"""
        return self.transfer.upload(local_path, remote_host, remote_path).to_dict()
    
    def download(self, remote_host: str, remote_path: str, local_path: str) -> Dict[str, Any]:
        """Download file from remote host"""
        return self.transfer.download(remote_host, remote_path, local_path).to_dict()
    
    def sync(
        self,
        local_dir: str,
        remote_host: str,
        remote_dir: str,
        direction: str = "bidirectional",
        dry_run: bool = False,
    ) -> List[Dict[str, Any]]:
        """Sync folder with remote"""
        results = self.transfer.sync_folder(local_dir, remote_host, remote_dir, direction, dry_run)
        return [r.to_dict() for r in results]
    
    # =========================================================================
    # Open/Serve/Route
    # =========================================================================
    
    def open(self, path: str) -> Dict[str, Any]:
        """Open file with default application"""
        return self.router.open_file(path).to_dict()
    
    def open_url(self, url: str) -> Dict[str, Any]:
        """Open URL in browser"""
        return self.router.open_url(url).to_dict()
    
    def serve(self, path: str, port: int = 8080, open_browser: bool = True) -> Dict[str, Any]:
        """Serve HTML/directory locally"""
        return self.router.serve_html(path, port, open_browser).to_dict()
    
    def route(self, local_path: str, remote_host: str, remote_port: int = 8080) -> Dict[str, Any]:
        """Serve and route to remote host"""
        return self.router.route_to_remote(local_path, remote_host, remote_port).to_dict()
    
    def stop_server(self, port: int) -> bool:
        """Stop a running server"""
        return self.router.stop_server(port)
    
    def list_servers(self) -> List[Dict[str, Any]]:
        """List running servers"""
        return self.router.list_servers()
    
    # =========================================================================
    # Convenience Methods
    # =========================================================================
    
    def save(self, path: str, content: str) -> Dict[str, Any]:
        """Save content to file (create or update)"""
        path_obj = Path(path).expanduser()
        if path_obj.exists():
            return self.update(path, content)
        else:
            return self.create(path, content)
    
    def message(self, recipient: str, content: str, via: str = "file") -> Dict[str, Any]:
        """
        Send message to another device/user
        
        Args:
            recipient: Target device (SSH host) or "local"
            content: Message content
            via: Method - "file" (save to file) or "notification"
        
        Returns:
            OperationResult dict
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"aria_message_{timestamp}.txt"
        
        message_content = f"""ARIA Message
============
From: {self.environment.hostname}
To: {recipient}
Time: {datetime.utcnow().isoformat()}

{content}
"""
        
        if recipient == "local" or via == "file":
            # Save locally
            msg_dir = Path.home() / ".aria" / "messages"
            msg_dir.mkdir(parents=True, exist_ok=True)
            return self.create(str(msg_dir / filename), message_content)
        
        # Upload to remote
        msg_dir = "~/.aria/messages"
        self.create(f"/tmp/{filename}", message_content)
        
        if HAS_SSH:
            try:
                ssh = get_router()
                ssh.execute(recipient, f"mkdir -p {msg_dir}")
                return self.upload(f"/tmp/{filename}", recipient, f"{msg_dir}/{filename}")
            except Exception as e:
                return {"success": False, "error": str(e)}
        
        return {"success": False, "error": "SSH not available"}


# =============================================================================
# Singleton and Factory
# =============================================================================

_file_manager_instance: Optional[AriaFileManager] = None


def get_file_manager() -> AriaFileManager:
    """Get or create the singleton AriaFileManager instance"""
    global _file_manager_instance
    if _file_manager_instance is None:
        _file_manager_instance = AriaFileManager()
    return _file_manager_instance


# Convenience aliases
FileManager = AriaFileManager
get_manager = get_file_manager
