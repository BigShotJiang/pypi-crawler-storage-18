"""
Q-System Module for ARIA CLI v0.2.0

Full Q0-Q38 Cognitive Architecture - 39 Layers of Recursive Reasoning

Layer Groups:
- Q0-Q9:   FOUNDATION  - Perception, memory, attention, pattern recognition
- Q10-Q19: REASONING   - Logic, inference, hypothesis, abstraction
- Q20-Q29: ACTION      - Planning, execution, feedback, optimization
- Q30-Q38: META        - Self-reflection, adaptation, transcendence

Each layer can recursively invoke lower layers, creating depth-first
cognitive processing that mirrors human thought patterns.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable, Union
from datetime import datetime
import json
from pathlib import Path
import hashlib
import threading
from collections import defaultdict


class QOperator(Enum):
    """Q-System command operators - expanded for v0.2.0"""
    
    # Data Operations
    INGEST = auto()
    GENERATE = auto()
    VALIDATE = auto()
    PARSE = auto()
    SERIALIZE = auto()
    
    # Processing Operations
    TRANSFORM = auto()
    ANALYZE = auto()
    SEARCH = auto()
    FILTER = auto()
    AGGREGATE = auto()
    
    # AI/ML Operations
    TRAIN = auto()
    PREDICT = auto()
    EVALUATE = auto()
    OPTIMIZE = auto()
    EMBED = auto()
    CLUSTER = auto()
    
    # Communication Operations
    ASK = auto()
    RESPOND = auto()
    TRANSLATE = auto()
    SUMMARIZE = auto()
    EXPLAIN = auto()
    
    # Memory Operations
    SAVE = auto()
    LOAD = auto()
    CACHE = auto()
    REMEMBER = auto()
    RECALL = auto()
    FORGET = auto()
    
    # System Operations
    REPORT = auto()
    TRANSFER = auto()
    EXECUTE = auto()
    SCHEDULE = auto()
    MONITOR = auto()
    
    # Meta Operations (new in v0.2.0)
    REFLECT = auto()
    INTROSPECT = auto()
    ADAPT = auto()
    EVOLVE = auto()
    TRANSCEND = auto()

    @classmethod
    def from_string(cls, s: str) -> 'QOperator':
        """Parse operator from string with fuzzy matching"""
        s = s.upper().replace('-', '_').replace(' ', '_')
        try:
            return cls[s]
        except KeyError:
            # Fuzzy match
            for op in cls:
                if s in op.name or op.name in s:
                    return op
            # Semantic mapping
            semantic_map = {
                'QUESTION': cls.ASK,
                'QUERY': cls.SEARCH,
                'CREATE': cls.GENERATE,
                'MAKE': cls.GENERATE,
                'BUILD': cls.GENERATE,
                'FIND': cls.SEARCH,
                'LOOK': cls.SEARCH,
                'THINK': cls.REFLECT,
                'CONSIDER': cls.ANALYZE,
                'LEARN': cls.TRAIN,
                'UNDERSTAND': cls.ANALYZE,
            }
            if s in semantic_map:
                return semantic_map[s]
            raise ValueError(f"Unknown operator: {s}")


class QLayer(Enum):
    """
    Q-System's Full 39-Layer Cognitive Architecture (Q0-Q38)
    
    Each layer represents a distinct cognitive function that can
    recursively invoke other layers for deep processing.
    """
    
    # === FOUNDATION LAYERS (Q0-Q9) ===
    Q0_VOID = 0           # The null state - potential before manifestation
    Q1_PERCEPTION = 1     # Raw sensory input processing
    Q2_ATTENTION = 2      # Focus and salience detection
    Q3_PATTERN = 3        # Pattern recognition and matching
    Q4_MEMORY_SHORT = 4   # Short-term/working memory
    Q5_MEMORY_LONG = 5    # Long-term memory storage
    Q6_ASSOCIATION = 6    # Associative linking between concepts
    Q7_CONTEXT = 7        # Contextual understanding
    Q8_LANGUAGE = 8       # Linguistic processing
    Q9_EMOTION = 9        # Affective processing and valence
    
    # === REASONING LAYERS (Q10-Q19) ===
    Q10_LOGIC = 10        # Formal logical reasoning
    Q11_INFERENCE = 11    # Inferential reasoning
    Q12_HYPOTHESIS = 12   # Hypothesis generation
    Q13_ABSTRACTION = 13  # Abstract concept formation
    Q14_ANALOGY = 14      # Analogical reasoning
    Q15_CAUSATION = 15    # Causal reasoning
    Q16_PREDICTION = 16   # Predictive modeling
    Q17_EVALUATION = 17   # Value and quality assessment
    Q18_SYNTHESIS = 18    # Information synthesis
    Q19_CREATIVITY = 19   # Creative generation
    
    # === ACTION LAYERS (Q20-Q29) ===
    Q20_INTENTION = 20    # Goal and intention formation
    Q21_PLANNING = 21     # Plan construction
    Q22_DECISION = 22     # Decision making
    Q23_EXECUTION = 23    # Action execution
    Q24_MONITORING = 24   # Progress monitoring
    Q25_FEEDBACK = 25     # Feedback processing
    Q26_CORRECTION = 26   # Error correction
    Q27_OPTIMIZATION = 27 # Performance optimization
    Q28_LEARNING = 28     # Learning from experience
    Q29_ADAPTATION = 29   # Behavioral adaptation
    
    # === META-COGNITIVE LAYERS (Q30-Q38) ===
    Q30_AWARENESS = 30    # Self-awareness
    Q31_REFLECTION = 31   # Self-reflection
    Q32_METACOGNITION = 32  # Thinking about thinking
    Q33_IDENTITY = 33     # Self-identity modeling
    Q34_VALUES = 34       # Value system and ethics
    Q35_WISDOM = 35       # Wisdom and judgment
    Q36_INTEGRATION = 36  # Full system integration
    Q37_EMERGENCE = 37    # Emergent properties
    Q38_TRANSCENDENCE = 38  # Beyond individual layers
    
    @property
    def group(self) -> str:
        """Get the layer group name"""
        if self.value <= 9:
            return "FOUNDATION"
        elif self.value <= 19:
            return "REASONING"
        elif self.value <= 29:
            return "ACTION"
        else:
            return "META"
    
    @property
    def description(self) -> str:
        """Get layer description"""
        descriptions = {
            # Foundation
            QLayer.Q0_VOID: "The null state - pure potential before manifestation",
            QLayer.Q1_PERCEPTION: "Raw sensory input processing and encoding",
            QLayer.Q2_ATTENTION: "Focus allocation and salience detection",
            QLayer.Q3_PATTERN: "Pattern recognition and template matching",
            QLayer.Q4_MEMORY_SHORT: "Working memory - active information buffer",
            QLayer.Q5_MEMORY_LONG: "Long-term storage and retrieval",
            QLayer.Q6_ASSOCIATION: "Associative linking between concepts",
            QLayer.Q7_CONTEXT: "Contextual frame understanding",
            QLayer.Q8_LANGUAGE: "Linguistic processing and generation",
            QLayer.Q9_EMOTION: "Affective processing and emotional valence",
            # Reasoning
            QLayer.Q10_LOGIC: "Formal logical reasoning and deduction",
            QLayer.Q11_INFERENCE: "Inferential reasoning from evidence",
            QLayer.Q12_HYPOTHESIS: "Hypothesis generation and testing",
            QLayer.Q13_ABSTRACTION: "Abstract concept formation",
            QLayer.Q14_ANALOGY: "Analogical and metaphorical reasoning",
            QLayer.Q15_CAUSATION: "Causal reasoning and attribution",
            QLayer.Q16_PREDICTION: "Predictive modeling and forecasting",
            QLayer.Q17_EVALUATION: "Value and quality assessment",
            QLayer.Q18_SYNTHESIS: "Information synthesis and integration",
            QLayer.Q19_CREATIVITY: "Creative generation and innovation",
            # Action
            QLayer.Q20_INTENTION: "Goal and intention formation",
            QLayer.Q21_PLANNING: "Strategic plan construction",
            QLayer.Q22_DECISION: "Decision making under uncertainty",
            QLayer.Q23_EXECUTION: "Action execution and motor control",
            QLayer.Q24_MONITORING: "Progress monitoring and tracking",
            QLayer.Q25_FEEDBACK: "Feedback processing and integration",
            QLayer.Q26_CORRECTION: "Error detection and correction",
            QLayer.Q27_OPTIMIZATION: "Performance optimization",
            QLayer.Q28_LEARNING: "Learning from experience",
            QLayer.Q29_ADAPTATION: "Behavioral adaptation to environment",
            # Meta
            QLayer.Q30_AWARENESS: "Self-awareness and consciousness",
            QLayer.Q31_REFLECTION: "Self-reflection and introspection",
            QLayer.Q32_METACOGNITION: "Thinking about thinking",
            QLayer.Q33_IDENTITY: "Self-identity and agency modeling",
            QLayer.Q34_VALUES: "Value system and ethical reasoning",
            QLayer.Q35_WISDOM: "Wisdom, judgment, and perspective",
            QLayer.Q36_INTEGRATION: "Full system integration",
            QLayer.Q37_EMERGENCE: "Emergent properties and behaviors",
            QLayer.Q38_TRANSCENDENCE: "Beyond individual layers - unified field",
        }
        return descriptions.get(self, f"Layer {self.value}")
    
    @property
    def default_operators(self) -> List[QOperator]:
        """Get default operators for this layer"""
        layer_operators = {
            # Foundation layers
            QLayer.Q0_VOID: [QOperator.TRANSCEND],
            QLayer.Q1_PERCEPTION: [QOperator.INGEST, QOperator.PARSE],
            QLayer.Q2_ATTENTION: [QOperator.FILTER, QOperator.SEARCH],
            QLayer.Q3_PATTERN: [QOperator.SEARCH, QOperator.ANALYZE],
            QLayer.Q4_MEMORY_SHORT: [QOperator.CACHE, QOperator.RECALL],
            QLayer.Q5_MEMORY_LONG: [QOperator.SAVE, QOperator.LOAD, QOperator.REMEMBER],
            QLayer.Q6_ASSOCIATION: [QOperator.ANALYZE, QOperator.SEARCH],
            QLayer.Q7_CONTEXT: [QOperator.ANALYZE, QOperator.INGEST],
            QLayer.Q8_LANGUAGE: [QOperator.PARSE, QOperator.GENERATE, QOperator.TRANSLATE],
            QLayer.Q9_EMOTION: [QOperator.ANALYZE, QOperator.EVALUATE],
            # Reasoning layers
            QLayer.Q10_LOGIC: [QOperator.ANALYZE, QOperator.VALIDATE],
            QLayer.Q11_INFERENCE: [QOperator.ANALYZE, QOperator.PREDICT],
            QLayer.Q12_HYPOTHESIS: [QOperator.GENERATE, QOperator.VALIDATE],
            QLayer.Q13_ABSTRACTION: [QOperator.TRANSFORM, QOperator.ANALYZE],
            QLayer.Q14_ANALOGY: [QOperator.SEARCH, QOperator.ANALYZE],
            QLayer.Q15_CAUSATION: [QOperator.ANALYZE, QOperator.EXPLAIN],
            QLayer.Q16_PREDICTION: [QOperator.PREDICT, QOperator.EVALUATE],
            QLayer.Q17_EVALUATION: [QOperator.EVALUATE, QOperator.ANALYZE],
            QLayer.Q18_SYNTHESIS: [QOperator.AGGREGATE, QOperator.GENERATE],
            QLayer.Q19_CREATIVITY: [QOperator.GENERATE, QOperator.TRANSFORM],
            # Action layers
            QLayer.Q20_INTENTION: [QOperator.ANALYZE, QOperator.GENERATE],
            QLayer.Q21_PLANNING: [QOperator.GENERATE, QOperator.OPTIMIZE],
            QLayer.Q22_DECISION: [QOperator.EVALUATE, QOperator.EXECUTE],
            QLayer.Q23_EXECUTION: [QOperator.EXECUTE, QOperator.MONITOR],
            QLayer.Q24_MONITORING: [QOperator.MONITOR, QOperator.REPORT],
            QLayer.Q25_FEEDBACK: [QOperator.ANALYZE, QOperator.EVALUATE],
            QLayer.Q26_CORRECTION: [QOperator.TRANSFORM, QOperator.OPTIMIZE],
            QLayer.Q27_OPTIMIZATION: [QOperator.OPTIMIZE, QOperator.EVALUATE],
            QLayer.Q28_LEARNING: [QOperator.TRAIN, QOperator.ADAPT],
            QLayer.Q29_ADAPTATION: [QOperator.ADAPT, QOperator.EVOLVE],
            # Meta layers
            QLayer.Q30_AWARENESS: [QOperator.INTROSPECT, QOperator.MONITOR],
            QLayer.Q31_REFLECTION: [QOperator.REFLECT, QOperator.ANALYZE],
            QLayer.Q32_METACOGNITION: [QOperator.REFLECT, QOperator.ANALYZE],
            QLayer.Q33_IDENTITY: [QOperator.INTROSPECT, QOperator.REMEMBER],
            QLayer.Q34_VALUES: [QOperator.EVALUATE, QOperator.ANALYZE],
            QLayer.Q35_WISDOM: [QOperator.ANALYZE, QOperator.EVALUATE],
            QLayer.Q36_INTEGRATION: [QOperator.AGGREGATE, QOperator.SYNTHESIZE] if hasattr(QOperator, 'SYNTHESIZE') else [QOperator.AGGREGATE],
            QLayer.Q37_EMERGENCE: [QOperator.EVOLVE, QOperator.TRANSCEND],
            QLayer.Q38_TRANSCENDENCE: [QOperator.TRANSCEND],
        }
        return layer_operators.get(self, [QOperator.EXECUTE])


class QState(Enum):
    """Command execution states"""
    PENDING = auto()
    PROCESSING = auto()
    COMPLETED = auto()
    FAILED = auto()
    CACHED = auto()
    CANCELLED = auto()


@dataclass
class QCommand:
    """A command routed through the Q-System"""
    operator: QOperator
    layer: QLayer
    payload: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    command_id: str = field(default="")
    parent_id: Optional[str] = None  # For recursive calls
    depth: int = 0  # Recursion depth
    
    def __post_init__(self):
        if not self.command_id:
            # Generate unique ID from content hash
            content = f"{self.operator.name}:{self.layer.name}:{self.timestamp.isoformat()}"
            self.command_id = hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'command_id': self.command_id,
            'operator': self.operator.name,
            'layer': self.layer.name,
            'layer_value': self.layer.value,
            'layer_group': self.layer.group,
            'payload': self.payload,
            'metadata': self.metadata,
            'timestamp': self.timestamp.isoformat(),
            'parent_id': self.parent_id,
            'depth': self.depth,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'QCommand':
        return cls(
            operator=QOperator[data['operator']],
            layer=QLayer[data['layer']] if isinstance(data['layer'], str) else QLayer(data['layer_value']),
            payload=data.get('payload', {}),
            metadata=data.get('metadata', {}),
            timestamp=datetime.fromisoformat(data['timestamp']) if 'timestamp' in data else datetime.now(),
            command_id=data.get('command_id', ''),
            parent_id=data.get('parent_id'),
            depth=data.get('depth', 0),
        )


@dataclass
class QResult:
    """Result from Q-System command execution"""
    command: QCommand
    state: QState
    output: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    layer_trace: List[str] = field(default_factory=list)  # Layers visited
    child_results: List['QResult'] = field(default_factory=list)  # Recursive results
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'command': self.command.to_dict(),
            'state': self.state.name,
            'output': self.output,
            'error': self.error,
            'execution_time': self.execution_time,
            'layer_trace': self.layer_trace,
            'child_count': len(self.child_results),
        }
    
    @property
    def success(self) -> bool:
        return self.state == QState.COMPLETED


class QSystem:
    """
    Q-System: 39-Layer Recursive Cognitive Architecture
    
    The Q-System processes commands through multiple cognitive layers,
    each providing specialized processing. Layers can recursively invoke
    other layers, creating deep, context-aware processing.
    
    Usage:
        system = QSystem()
        result = system.execute(QOperator.ASK, "What is quantum computing?")
        print(result.output)
    """
    
    MAX_RECURSION_DEPTH = 10
    
    def __init__(self, memory_dir: Optional[Path] = None):
        self.memory_dir = memory_dir or Path.home() / ".aria-cli" / "q-memory"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        # Layer statistics
        self.layer_stats: Dict[QLayer, int] = defaultdict(int)
        self.command_history: List[QCommand] = []
        
        # Layer handlers
        self._handlers: Dict[QLayer, Callable] = {}
        self._register_default_handlers()
        
        # LLM connector (optional)
        self._llm = None
        
        # Thread lock for concurrent access
        self._lock = threading.Lock()
    
    def _register_default_handlers(self):
        """Register default handlers for each layer"""
        # Foundation handlers
        self._handlers[QLayer.Q1_PERCEPTION] = self._handle_perception
        self._handlers[QLayer.Q2_ATTENTION] = self._handle_attention
        self._handlers[QLayer.Q3_PATTERN] = self._handle_pattern
        self._handlers[QLayer.Q4_MEMORY_SHORT] = self._handle_short_memory
        self._handlers[QLayer.Q5_MEMORY_LONG] = self._handle_long_memory
        self._handlers[QLayer.Q8_LANGUAGE] = self._handle_language
        
        # Reasoning handlers
        self._handlers[QLayer.Q10_LOGIC] = self._handle_logic
        self._handlers[QLayer.Q11_INFERENCE] = self._handle_inference
        self._handlers[QLayer.Q12_HYPOTHESIS] = self._handle_hypothesis
        self._handlers[QLayer.Q16_PREDICTION] = self._handle_prediction
        self._handlers[QLayer.Q19_CREATIVITY] = self._handle_creativity
        
        # Action handlers
        self._handlers[QLayer.Q21_PLANNING] = self._handle_planning
        self._handlers[QLayer.Q22_DECISION] = self._handle_decision
        self._handlers[QLayer.Q23_EXECUTION] = self._handle_execution
        self._handlers[QLayer.Q25_FEEDBACK] = self._handle_feedback
        
        # Meta handlers
        self._handlers[QLayer.Q30_AWARENESS] = self._handle_awareness
        self._handlers[QLayer.Q31_REFLECTION] = self._handle_reflection
        self._handlers[QLayer.Q38_TRANSCENDENCE] = self._handle_transcendence
    
    def set_llm(self, llm_connector):
        """Set the LLM connector for enhanced processing"""
        self._llm = llm_connector
    
    def execute(
        self,
        operator: Union[QOperator, str],
        payload: Union[str, Dict[str, Any]] = "",
        layer: Optional[QLayer] = None,
        metadata: Optional[Dict[str, Any]] = None,
        parent_command: Optional[QCommand] = None,
    ) -> QResult:
        """
        Execute a command through the Q-System
        
        Args:
            operator: The operation to perform
            payload: Command payload (string or dict)
            layer: Specific layer to use (auto-detected if None)
            metadata: Additional metadata
            parent_command: Parent command for recursive calls
            
        Returns:
            QResult with execution results
        """
        import time
        start_time = time.time()
        
        # Parse operator
        if isinstance(operator, str):
            operator = QOperator.from_string(operator)
        
        # Parse payload
        if isinstance(payload, str):
            payload = {"input": payload}
        
        # Determine layer
        if layer is None:
            layer = self._route_to_layer(operator, payload)
        
        # Calculate depth
        depth = (parent_command.depth + 1) if parent_command else 0
        
        # Check recursion limit
        if depth > self.MAX_RECURSION_DEPTH:
            return QResult(
                command=QCommand(operator, layer, payload),
                state=QState.FAILED,
                error=f"Maximum recursion depth ({self.MAX_RECURSION_DEPTH}) exceeded"
            )
        
        # Create command
        command = QCommand(
            operator=operator,
            layer=layer,
            payload=payload,
            metadata=metadata or {},
            parent_id=parent_command.command_id if parent_command else None,
            depth=depth,
        )
        
        # Track command
        with self._lock:
            self.command_history.append(command)
            self.layer_stats[layer] += 1
        
        # Execute through layer
        layer_trace = [f"Q{layer.value}:{layer.name}"]
        
        try:
            handler = self._handlers.get(layer, self._default_handler)
            output = handler(command)
            
            execution_time = time.time() - start_time
            
            return QResult(
                command=command,
                state=QState.COMPLETED,
                output=output,
                execution_time=execution_time,
                layer_trace=layer_trace,
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            return QResult(
                command=command,
                state=QState.FAILED,
                error=str(e),
                execution_time=execution_time,
                layer_trace=layer_trace,
            )
    
    def _route_to_layer(self, operator: QOperator, payload: Dict[str, Any]) -> QLayer:
        """Route operator to appropriate layer"""
        # Operator -> Layer mapping
        routing = {
            # Foundation
            QOperator.INGEST: QLayer.Q1_PERCEPTION,
            QOperator.PARSE: QLayer.Q1_PERCEPTION,
            QOperator.FILTER: QLayer.Q2_ATTENTION,
            QOperator.SEARCH: QLayer.Q3_PATTERN,
            QOperator.CACHE: QLayer.Q4_MEMORY_SHORT,
            QOperator.RECALL: QLayer.Q4_MEMORY_SHORT,
            QOperator.SAVE: QLayer.Q5_MEMORY_LONG,
            QOperator.LOAD: QLayer.Q5_MEMORY_LONG,
            QOperator.REMEMBER: QLayer.Q5_MEMORY_LONG,
            QOperator.TRANSLATE: QLayer.Q8_LANGUAGE,
            
            # Reasoning
            QOperator.VALIDATE: QLayer.Q10_LOGIC,
            QOperator.ANALYZE: QLayer.Q11_INFERENCE,
            QOperator.GENERATE: QLayer.Q12_HYPOTHESIS,
            QOperator.PREDICT: QLayer.Q16_PREDICTION,
            QOperator.EVALUATE: QLayer.Q17_EVALUATION,
            QOperator.SUMMARIZE: QLayer.Q18_SYNTHESIS,
            
            # Action
            QOperator.EXECUTE: QLayer.Q23_EXECUTION,
            QOperator.MONITOR: QLayer.Q24_MONITORING,
            QOperator.OPTIMIZE: QLayer.Q27_OPTIMIZATION,
            QOperator.TRAIN: QLayer.Q28_LEARNING,
            QOperator.ADAPT: QLayer.Q29_ADAPTATION,
            
            # Meta
            QOperator.REFLECT: QLayer.Q31_REFLECTION,
            QOperator.INTROSPECT: QLayer.Q30_AWARENESS,
            QOperator.EVOLVE: QLayer.Q37_EMERGENCE,
            QOperator.TRANSCEND: QLayer.Q38_TRANSCENDENCE,
            
            # Communication -> Language by default
            QOperator.ASK: QLayer.Q8_LANGUAGE,
            QOperator.RESPOND: QLayer.Q8_LANGUAGE,
            QOperator.EXPLAIN: QLayer.Q15_CAUSATION,
        }
        
        return routing.get(operator, QLayer.Q23_EXECUTION)
    
    def _default_handler(self, command: QCommand) -> Dict[str, Any]:
        """Default handler for unregistered layers"""
        return {
            "status": "processed",
            "layer": command.layer.name,
            "operator": command.operator.name,
            "payload": command.payload,
            "note": "Processed by default handler",
        }
    
    # === Foundation Layer Handlers ===
    
    def _handle_perception(self, command: QCommand) -> Dict[str, Any]:
        """Q1: Handle perception/input processing"""
        input_data = command.payload.get("input", "")
        return {
            "perceived": input_data,
            "type": type(input_data).__name__,
            "length": len(str(input_data)),
            "encoding": "utf-8",
        }
    
    def _handle_attention(self, command: QCommand) -> Dict[str, Any]:
        """Q2: Handle attention/focus"""
        input_data = command.payload.get("input", "")
        # Extract key terms
        words = str(input_data).split()
        important = [w for w in words if len(w) > 4]
        return {
            "focus": important[:5],
            "salience_score": len(important) / max(len(words), 1),
        }
    
    def _handle_pattern(self, command: QCommand) -> Dict[str, Any]:
        """Q3: Handle pattern recognition"""
        input_data = command.payload.get("input", "")
        query = command.payload.get("query", input_data)
        # Simple pattern matching
        return {
            "patterns_found": [],
            "query": query,
            "method": "pattern_matching",
        }
    
    def _handle_short_memory(self, command: QCommand) -> Dict[str, Any]:
        """Q4: Handle short-term memory"""
        op = command.operator
        key = command.payload.get("key", "default")
        value = command.payload.get("value", command.payload.get("input"))
        
        cache_file = self.memory_dir / "short_term_cache.json"
        
        try:
            cache = json.loads(cache_file.read_text()) if cache_file.exists() else {}
        except:
            cache = {}
        
        if op == QOperator.CACHE:
            cache[key] = {"value": value, "timestamp": datetime.now().isoformat()}
            cache_file.write_text(json.dumps(cache, indent=2))
            return {"cached": True, "key": key}
        elif op == QOperator.RECALL:
            return cache.get(key, {"error": f"Key '{key}' not found"})
        
        return {"cache_size": len(cache)}
    
    def _handle_long_memory(self, command: QCommand) -> Dict[str, Any]:
        """Q5: Handle long-term memory"""
        op = command.operator
        content = command.payload.get("input", "")
        key = command.payload.get("key", hashlib.sha256(content.encode()).hexdigest()[:8])
        
        memory_file = self.memory_dir / f"memory_{key}.json"
        
        if op in [QOperator.SAVE, QOperator.REMEMBER]:
            memory_data = {
                "content": content,
                "timestamp": datetime.now().isoformat(),
                "metadata": command.metadata,
            }
            memory_file.write_text(json.dumps(memory_data, indent=2))
            return {"saved": True, "key": key, "path": str(memory_file)}
        elif op == QOperator.LOAD:
            if memory_file.exists():
                return json.loads(memory_file.read_text())
            return {"error": f"Memory '{key}' not found"}
        
        # List all memories
        memories = list(self.memory_dir.glob("memory_*.json"))
        return {"memory_count": len(memories), "keys": [m.stem for m in memories]}
    
    def _handle_language(self, command: QCommand) -> Dict[str, Any]:
        """Q8: Handle language processing"""
        input_text = command.payload.get("input", "")
        
        # If LLM is available, use it
        if self._llm:
            try:
                response = self._llm.generate(input_text, command.metadata)
                return {
                    "response": response,
                    "method": "llm",
                    "model": self._llm.model_name,
                }
            except Exception as e:
                pass  # Fall through to pattern matching
        
        # Pattern-based response
        return {
            "answer": f"Processing question: {input_text}",
            "method": "pattern_matching",
            "note": "Full LLM integration available with aria-cli[llm]",
        }
    
    # === Reasoning Layer Handlers ===
    
    def _handle_logic(self, command: QCommand) -> Dict[str, Any]:
        """Q10: Handle logical reasoning"""
        input_data = command.payload.get("input", "")
        return {
            "valid": True,
            "reasoning": "logical_analysis",
            "input": input_data,
        }
    
    def _handle_inference(self, command: QCommand) -> Dict[str, Any]:
        """Q11: Handle inferential reasoning"""
        input_data = command.payload.get("input", "")
        return {
            "inferences": [],
            "confidence": 0.5,
            "method": "rule_based",
        }
    
    def _handle_hypothesis(self, command: QCommand) -> Dict[str, Any]:
        """Q12: Handle hypothesis generation"""
        input_data = command.payload.get("input", "")
        return {
            "hypotheses": [
                {"content": f"Hypothesis based on: {input_data[:50]}...", "confidence": 0.7}
            ],
            "method": "generative",
        }
    
    def _handle_prediction(self, command: QCommand) -> Dict[str, Any]:
        """Q16: Handle prediction"""
        return {
            "prediction": "Prediction requires model training",
            "confidence": 0.0,
            "method": "placeholder",
        }
    
    def _handle_creativity(self, command: QCommand) -> Dict[str, Any]:
        """Q19: Handle creative generation"""
        input_data = command.payload.get("input", "")
        prompt = command.payload.get("prompt", input_data)
        
        if self._llm:
            try:
                response = self._llm.generate(
                    f"Create something creative based on: {prompt}",
                    {"temperature": 0.9}
                )
                return {"creative_output": response, "method": "llm"}
            except:
                pass
        
        return {
            "creative_output": f"Creative response to: {prompt}",
            "method": "template",
        }
    
    # === Action Layer Handlers ===
    
    def _handle_planning(self, command: QCommand) -> Dict[str, Any]:
        """Q21: Handle planning"""
        goal = command.payload.get("input", "")
        return {
            "plan": [
                {"step": 1, "action": "Analyze goal", "status": "pending"},
                {"step": 2, "action": "Identify resources", "status": "pending"},
                {"step": 3, "action": "Execute plan", "status": "pending"},
            ],
            "goal": goal,
        }
    
    def _handle_decision(self, command: QCommand) -> Dict[str, Any]:
        """Q22: Handle decision making"""
        options = command.payload.get("options", [])
        return {
            "decision": options[0] if options else "No options provided",
            "method": "first_available",
            "options_count": len(options),
        }
    
    def _handle_execution(self, command: QCommand) -> Dict[str, Any]:
        """Q23: Handle execution"""
        action = command.payload.get("input", "")
        return {
            "executed": True,
            "action": action,
            "result": "Action completed",
        }
    
    def _handle_feedback(self, command: QCommand) -> Dict[str, Any]:
        """Q25: Handle feedback processing"""
        return {
            "feedback_processed": True,
            "layer_stats": {k.name: v for k, v in self.layer_stats.items()},
            "command_count": len(self.command_history),
        }
    
    # === Meta Layer Handlers ===
    
    def _handle_awareness(self, command: QCommand) -> Dict[str, Any]:
        """Q30: Handle self-awareness"""
        return {
            "system": "ARIA Q-System v0.2.0",
            "layers": 39,
            "active_layers": len([l for l, c in self.layer_stats.items() if c > 0]),
            "total_operations": sum(self.layer_stats.values()),
            "memory_path": str(self.memory_dir),
            "llm_connected": self._llm is not None,
        }
    
    def _handle_reflection(self, command: QCommand) -> Dict[str, Any]:
        """Q31: Handle self-reflection"""
        # Analyze recent commands
        recent = self.command_history[-10:] if self.command_history else []
        
        layer_usage = defaultdict(int)
        operator_usage = defaultdict(int)
        for cmd in recent:
            layer_usage[cmd.layer.group] += 1
            operator_usage[cmd.operator.name] += 1
        
        return {
            "reflection": {
                "recent_commands": len(recent),
                "layer_distribution": dict(layer_usage),
                "operator_distribution": dict(operator_usage),
                "dominant_layer_group": max(layer_usage, key=layer_usage.get) if layer_usage else None,
            },
            "insight": "System is functioning within normal parameters",
        }
    
    def _handle_transcendence(self, command: QCommand) -> Dict[str, Any]:
        """Q38: Handle transcendence - unified field processing"""
        return {
            "state": "transcendent",
            "message": "All layers unified in coherent processing",
            "q_system_version": "0.2.0",
            "layer_count": 39,
            "description": "Q38 represents the unified field where all cognitive layers "
                          "operate as one integrated system",
        }
    
    # === Utility Methods ===
    
    def get_layer_info(self, layer: Union[QLayer, int, str]) -> Dict[str, Any]:
        """Get information about a specific layer"""
        if isinstance(layer, int):
            layer = QLayer(layer)
        elif isinstance(layer, str):
            layer = QLayer[layer.upper().replace(" ", "_")]
        
        return {
            "name": layer.name,
            "value": layer.value,
            "group": layer.group,
            "description": layer.description,
            "default_operators": [op.name for op in layer.default_operators],
            "usage_count": self.layer_stats.get(layer, 0),
        }
    
    def get_all_layers(self) -> List[Dict[str, Any]]:
        """Get information about all layers"""
        return [self.get_layer_info(layer) for layer in QLayer]
    
    def get_status(self) -> Dict[str, Any]:
        """Get system status"""
        return {
            "version": "0.2.0",
            "layers": 39,
            "layer_groups": ["FOUNDATION", "REASONING", "ACTION", "META"],
            "total_commands": len(self.command_history),
            "layer_stats": {k.name: v for k, v in self.layer_stats.items() if v > 0},
            "memory_dir": str(self.memory_dir),
            "llm_connected": self._llm is not None,
        }
    
    def clear_history(self):
        """Clear command history"""
        with self._lock:
            self.command_history.clear()
            self.layer_stats.clear()


# Convenience function
def create_q_system(memory_dir: Optional[Path] = None) -> QSystem:
    """Create a new Q-System instance"""
    return QSystem(memory_dir)
