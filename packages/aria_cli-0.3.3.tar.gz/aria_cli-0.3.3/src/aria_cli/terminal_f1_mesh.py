"""
ARIA Terminal-to-Terminal F1 Mesh System v0.3.0

Creates a self-improving network of terminals where each terminal
performs F1 cycles on other terminals in the mesh.

Architecture:
  Terminal A ──F1──► Terminal B
      ▲                  │
      │                  │
      └───────F1─────────┘

The F1 Terminal-to-Terminal Process:
  1. ANALYZE: Terminal A inspects Terminal B's state, commands, outputs
  2. IMPROVE: Terminal A suggests/executes improvements on Terminal B
  3. VALIDATE: Terminal A verifies Terminal B's improvements succeeded

Mesh Patterns:
  - Ring: A→B→C→D→A (circular improvement chain)
  - Star: Central terminal improves all others
  - Full Mesh: Every terminal improves every other terminal
  - Hierarchical: Parent terminals improve child terminals
"""

import asyncio
import subprocess
import json
import os
import time
import uuid
import socket
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any, Set, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from collections import defaultdict
import threading
import queue


# =============================================================================
# ENUMS AND TYPES
# =============================================================================

class TerminalState(Enum):
    """State of a terminal in the mesh"""
    IDLE = "idle"
    ANALYZING = "analyzing"
    IMPROVING = "improving"
    VALIDATING = "validating"
    WAITING = "waiting"
    ERROR = "error"
    OFFLINE = "offline"


class MeshTopology(Enum):
    """Network topology for terminal mesh"""
    RING = "ring"           # Circular: A→B→C→A
    STAR = "star"           # Central hub: Hub→All
    FULL_MESH = "full_mesh" # Everyone→Everyone
    HIERARCHICAL = "hierarchical"  # Tree structure
    ADAPTIVE = "adaptive"   # Dynamic based on performance


class F1Phase(Enum):
    """F1 Three-Phase Improvement Cycle"""
    ANALYZE = "analyze"
    IMPROVE = "improve"
    VALIDATE = "validate"


class ImprovementType(Enum):
    """Types of improvements a terminal can make"""
    COMMAND_OPTIMIZATION = "command_optimization"
    ERROR_CORRECTION = "error_correction"
    PERFORMANCE_TUNING = "performance_tuning"
    CLEANUP = "cleanup"
    CONFIGURATION = "configuration"
    WORKFLOW_ENHANCEMENT = "workflow_enhancement"
    DEPENDENCY_UPDATE = "dependency_update"
    SECURITY_HARDENING = "security_hardening"


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class TerminalIdentity:
    """Identity of a terminal in the mesh"""
    id: str
    name: str
    shell: str  # powershell, bash, zsh, cmd, etc.
    cwd: str
    pid: int
    host: str
    created_at: float
    capabilities: Set[str] = field(default_factory=set)
    
    @property
    def fingerprint(self) -> str:
        """Unique fingerprint for this terminal"""
        data = f"{self.id}:{self.host}:{self.pid}:{self.shell}"
        return hashlib.md5(data.encode()).hexdigest()[:12]


@dataclass
class TerminalSnapshot:
    """Snapshot of terminal state for analysis"""
    terminal_id: str
    timestamp: float
    cwd: str
    env_vars: Dict[str, str]
    command_history: List[str]
    last_command: Optional[str]
    last_output: Optional[str]
    last_exit_code: Optional[int]
    running_processes: List[Dict[str, Any]]
    resource_usage: Dict[str, float]  # cpu, memory, disk
    errors: List[str]
    warnings: List[str]


@dataclass
class F1Improvement:
    """An improvement suggestion or action"""
    id: str
    type: ImprovementType
    target_terminal: str
    description: str
    command: Optional[str]
    script: Optional[str]
    priority: int  # 1-10, higher = more important
    estimated_impact: float  # 0-1
    auto_apply: bool
    requires_confirmation: bool
    dependencies: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "target": self.target_terminal,
            "description": self.description,
            "command": self.command,
            "priority": self.priority,
            "impact": self.estimated_impact,
            "auto_apply": self.auto_apply
        }


@dataclass
class F1CycleResult:
    """Result of an F1 cycle between two terminals"""
    source_terminal: str
    target_terminal: str
    phase: F1Phase
    started_at: float
    completed_at: float
    success: bool
    improvements_found: List[F1Improvement]
    improvements_applied: List[str]  # IDs of applied improvements
    validation_passed: bool
    metrics: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    
    @property
    def duration(self) -> float:
        return self.completed_at - self.started_at


@dataclass 
class MeshConnection:
    """Connection between two terminals"""
    source_id: str
    target_id: str
    established_at: float
    last_f1_cycle: Optional[float] = None
    total_cycles: int = 0
    successful_cycles: int = 0
    total_improvements: int = 0
    latency_ms: float = 0.0
    
    @property
    def success_rate(self) -> float:
        if self.total_cycles == 0:
            return 0.0
        return self.successful_cycles / self.total_cycles


# =============================================================================
# TERMINAL NODE
# =============================================================================

class TerminalNode:
    """
    Represents a single terminal in the F1 mesh.
    Can analyze, improve, and validate other terminals.
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        shell: Optional[str] = None,
        cwd: Optional[Path] = None
    ):
        self.id = str(uuid.uuid4())[:8]
        self.name = name or f"terminal-{self.id}"
        self.shell = shell or self._detect_shell()
        self.cwd = cwd or Path.cwd()
        self.pid = os.getpid()
        self.host = socket.gethostname()
        self.created_at = time.time()
        
        self.state = TerminalState.IDLE
        self.capabilities = self._detect_capabilities()
        
        # Command history and output tracking
        self.command_history: List[Tuple[str, float, int]] = []  # (cmd, time, exit_code)
        self.output_buffer: List[str] = []
        self.error_buffer: List[str] = []
        
        # F1 cycle tracking
        self.cycles_performed: List[F1CycleResult] = []
        self.cycles_received: List[F1CycleResult] = []
        self.pending_improvements: List[F1Improvement] = []
        
        # Improvement history - tracks what has been applied
        self.applied_improvements: List[F1Improvement] = []
        self.improvement_history: Dict[str, List[str]] = {}  # type -> list of descriptions
        self.f1_level: int = 0  # Current F1 evolution level
        self.evolution_log: List[Dict[str, Any]] = []  # Log of all evolutions
        
        # Connections to other terminals
        self.connections: Dict[str, MeshConnection] = {}
        
        # Async event loop
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._command_queue: queue.Queue = queue.Queue()
        
    def _detect_shell(self) -> str:
        """Detect current shell type"""
        shell = os.environ.get("SHELL", "")
        if "powershell" in shell.lower() or os.name == "nt":
            return "powershell"
        elif "bash" in shell:
            return "bash"
        elif "zsh" in shell:
            return "zsh"
        elif "fish" in shell:
            return "fish"
        return "sh"
    
    def _detect_capabilities(self) -> Set[str]:
        """Detect terminal capabilities"""
        caps = {"execute", "read_output", "f1_analyze"}
        
        # Check for common tools
        tools = ["git", "python", "node", "npm", "pip", "gh", "docker", "kubectl"]
        for tool in tools:
            try:
                result = subprocess.run(
                    ["which", tool] if os.name != "nt" else ["where", tool],
                    capture_output=True,
                    timeout=2
                )
                if result.returncode == 0:
                    caps.add(f"tool:{tool}")
            except:
                pass
        
        return caps
    
    @property
    def identity(self) -> TerminalIdentity:
        """Get terminal identity"""
        return TerminalIdentity(
            id=self.id,
            name=self.name,
            shell=self.shell,
            cwd=str(self.cwd),
            pid=self.pid,
            host=self.host,
            created_at=self.created_at,
            capabilities=self.capabilities
        )
    
    def take_snapshot(self) -> TerminalSnapshot:
        """Take a snapshot of current terminal state"""
        # Get recent command history
        recent_commands = [cmd for cmd, _, _ in self.command_history[-20:]]
        
        # Get last command info
        last_cmd = None
        last_exit = None
        if self.command_history:
            last_cmd, _, last_exit = self.command_history[-1]
        
        # Get running processes (simplified)
        processes = []
        try:
            if os.name == "nt":
                result = subprocess.run(
                    ["tasklist", "/fo", "csv", "/nh"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                # Parse first few lines
                for line in result.stdout.split("\n")[:10]:
                    if line.strip():
                        parts = line.strip('"').split('","')
                        if len(parts) >= 2:
                            processes.append({"name": parts[0], "pid": parts[1]})
            else:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                for line in result.stdout.split("\n")[1:10]:
                    parts = line.split()
                    if len(parts) >= 11:
                        processes.append({"name": parts[10], "pid": parts[1]})
        except:
            pass
        
        return TerminalSnapshot(
            terminal_id=self.id,
            timestamp=time.time(),
            cwd=str(self.cwd),
            env_vars={k: v for k, v in os.environ.items() if not k.startswith("_")},
            command_history=recent_commands,
            last_command=last_cmd,
            last_output=self.output_buffer[-1] if self.output_buffer else None,
            last_exit_code=last_exit,
            running_processes=processes,
            resource_usage=self._get_resource_usage(),
            errors=self.error_buffer[-10:],
            warnings=[]
        )
    
    def _get_resource_usage(self) -> Dict[str, float]:
        """Get resource usage metrics"""
        try:
            import psutil
            return {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage("/").percent if os.name != "nt" else psutil.disk_usage("C:\\").percent
            }
        except ImportError:
            return {"cpu_percent": 0, "memory_percent": 0, "disk_percent": 0}
    
    async def execute_command(
        self,
        command: str,
        timeout: int = 60,
        capture: bool = True
    ) -> Tuple[int, str, str]:
        """Execute a command in this terminal"""
        self.state = TerminalState.IMPROVING
        start_time = time.time()
        
        try:
            # Build command for shell
            if self.shell == "powershell":
                cmd = ["powershell", "-NoProfile", "-Command", command]
            elif self.shell == "bash":
                cmd = ["bash", "-c", command]
            elif self.shell == "zsh":
                cmd = ["zsh", "-c", command]
            else:
                cmd = ["sh", "-c", command]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE if capture else None,
                stderr=asyncio.subprocess.PIPE if capture else None,
                cwd=self.cwd
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout
            )
            
            exit_code = process.returncode or 0
            stdout_str = stdout.decode("utf-8", errors="replace") if stdout else ""
            stderr_str = stderr.decode("utf-8", errors="replace") if stderr else ""
            
            # Record in history
            self.command_history.append((command, time.time(), exit_code))
            if stdout_str:
                self.output_buffer.append(stdout_str)
            if stderr_str:
                self.error_buffer.append(stderr_str)
            
            self.state = TerminalState.IDLE
            return exit_code, stdout_str, stderr_str
            
        except asyncio.TimeoutError:
            self.error_buffer.append(f"Command timed out: {command}")
            self.state = TerminalState.ERROR
            return -1, "", f"Timeout after {timeout}s"
        except Exception as e:
            self.error_buffer.append(str(e))
            self.state = TerminalState.ERROR
            return -1, "", str(e)
    
    def record_improvement(self, improvement: F1Improvement) -> None:
        """Record an applied improvement for history tracking"""
        self.applied_improvements.append(improvement)
        
        # Track by type
        type_key = improvement.type.value
        if type_key not in self.improvement_history:
            self.improvement_history[type_key] = []
        self.improvement_history[type_key].append(improvement.description)
        
        # Log evolution
        self.evolution_log.append({
            "timestamp": time.time(),
            "improvement_id": improvement.id,
            "type": type_key,
            "description": improvement.description,
            "f1_level": self.f1_level
        })
    
    def advance_f1_level(self) -> int:
        """Advance to next F1 evolution level"""
        self.f1_level += 1
        self.evolution_log.append({
            "timestamp": time.time(),
            "event": "level_up",
            "new_level": self.f1_level,
            "total_improvements": len(self.applied_improvements)
        })
        return self.f1_level
    
    def has_improvement_type(self, imp_type: ImprovementType) -> bool:
        """Check if terminal has already received this type of improvement"""
        return imp_type.value in self.improvement_history
    
    def get_improvement_count(self, imp_type: ImprovementType) -> int:
        """Get count of improvements of a specific type"""
        return len(self.improvement_history.get(imp_type.value, []))
    
    def get_evolution_summary(self) -> Dict[str, Any]:
        """Get summary of terminal's evolution through F1 cycles"""
        return {
            "terminal_id": self.id,
            "name": self.name,
            "f1_level": self.f1_level,
            "total_improvements": len(self.applied_improvements),
            "cycles_received": len(self.cycles_received),
            "improvement_breakdown": {
                k: len(v) for k, v in self.improvement_history.items()
            },
            "recent_evolutions": self.evolution_log[-10:]
        }


# =============================================================================
# F1 ANALYZER
# =============================================================================

class F1TerminalAnalyzer:
    """
    Analyzes a target terminal and identifies improvements.
    Phase 1 of the F1 cycle.
    """
    
    def __init__(self, source: TerminalNode):
        self.source = source
        self.analysis_patterns = self._load_analysis_patterns()
    
    def _load_analysis_patterns(self) -> Dict[str, Any]:
        """Load patterns for analysis"""
        return {
            "error_patterns": [
                r"error:",
                r"Error:",
                r"ERROR",
                r"failed",
                r"Failed",
                r"FAILED",
                r"exception",
                r"Exception",
                r"traceback",
                r"Traceback",
            ],
            "optimization_patterns": [
                # Commands that could be improved
                {"pattern": r"pip install (?!-r)", "suggestion": "Use requirements.txt for reproducibility"},
                {"pattern": r"npm install (?!--save)", "suggestion": "Use --save or package.json"},
                {"pattern": r"git add \.", "suggestion": "Use specific file patterns to avoid accidental commits"},
            ],
            "security_patterns": [
                {"pattern": r"password=", "severity": "high", "suggestion": "Use environment variables for secrets"},
                {"pattern": r"api_key=", "severity": "high", "suggestion": "Use environment variables for API keys"},
                {"pattern": r"chmod 777", "severity": "medium", "suggestion": "Use more restrictive permissions"},
            ],
            "performance_patterns": [
                {"pattern": r"sleep \d+", "suggestion": "Consider using event-based waiting"},
                {"pattern": r"while true", "suggestion": "Add exit condition to prevent infinite loops"},
            ]
        }
    
    async def analyze(self, target: TerminalNode) -> List[F1Improvement]:
        """
        Analyze target terminal and identify improvements.
        Builds upon previous F1 cycles - provides progressive improvements.
        
        F1 Level Progression:
        - Level 0: Basic configuration (env vars, shell settings)
        - Level 1: Workflow optimization (aliases, functions, paths)
        - Level 2: Performance tuning (caching, parallel execution)
        - Level 3: Security hardening (permissions, secrets management)
        - Level 4: Advanced automation (scripts, task scheduling)
        - Level 5+: Cross-system integration and optimization
        """
        self.source.state = TerminalState.ANALYZING
        improvements: List[F1Improvement] = []
        
        # Take snapshot of target
        snapshot = target.take_snapshot()
        f1_level = target.f1_level
        
        # Filter out already-applied improvement descriptions
        applied_descriptions = set()
        for imp in target.applied_improvements:
            applied_descriptions.add(imp.description)
        
        # Get improvements based on F1 level (progressive)
        if f1_level == 0:
            # Level 0: Basic configuration
            config_improvements = await self._analyze_configuration(snapshot, target.shell)
            improvements.extend(config_improvements)
            
            # Also check for errors at all levels
            error_improvements = await self._analyze_errors(snapshot)
            improvements.extend(error_improvements)
            
        elif f1_level == 1:
            # Level 1: Workflow optimization
            workflow_improvements = await self._analyze_workflow(snapshot, target)
            improvements.extend(workflow_improvements)
            
            optimization_improvements = await self._analyze_optimizations(snapshot)
            improvements.extend(optimization_improvements)
            
        elif f1_level == 2:
            # Level 2: Performance tuning
            resource_improvements = await self._analyze_resources(snapshot)
            improvements.extend(resource_improvements)
            
            perf_improvements = await self._analyze_performance(snapshot, target)
            improvements.extend(perf_improvements)
            
        elif f1_level == 3:
            # Level 3: Security hardening
            security_improvements = await self._analyze_security(snapshot)
            improvements.extend(security_improvements)
            
        elif f1_level == 4:
            # Level 4: Advanced automation
            automation_improvements = await self._analyze_automation(snapshot, target)
            improvements.extend(automation_improvements)
            
        else:
            # Level 5+: Cross-system integration
            cross_improvements = await self._analyze_cross_terminal(target)
            improvements.extend(cross_improvements)
            
            # Also do a comprehensive re-check
            all_improvements = await self._comprehensive_analysis(snapshot, target)
            improvements.extend(all_improvements)
        
        # Filter out already-applied improvements
        filtered_improvements = [
            imp for imp in improvements 
            if imp.description not in applied_descriptions
        ]
        
        # Sort by priority
        filtered_improvements.sort(key=lambda x: x.priority, reverse=True)
        
        self.source.state = TerminalState.IDLE
        return filtered_improvements
    
    async def _analyze_workflow(self, snapshot: TerminalSnapshot, target: TerminalNode) -> List[F1Improvement]:
        """Level 1: Analyze workflow and suggest optimizations"""
        improvements = []
        is_powershell = "powershell" in target.shell.lower()
        
        # Check for PATH optimization
        path_var = snapshot.env_vars.get("PATH", "") or snapshot.env_vars.get("Path", "")
        local_bin = os.path.expanduser("~/.local/bin") if not is_powershell else os.path.expanduser("~/bin")
        
        if local_bin not in path_var:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.WORKFLOW_ENHANCEMENT,
                target_terminal=target.id,
                description=f"Add {local_bin} to PATH for local scripts",
                command=f"$env:PATH += ';{local_bin}'" if is_powershell else f"export PATH=$PATH:{local_bin}",
                script=None,
                priority=5,
                estimated_impact=0.4,
                auto_apply=True,
                requires_confirmation=False
            ))
        
        # Suggest common aliases based on command history
        common_cmds = {}
        for cmd in snapshot.command_history:
            base_cmd = cmd.split()[0] if cmd else ""
            common_cmds[base_cmd] = common_cmds.get(base_cmd, 0) + 1
        
        # Most used commands could benefit from aliases
        for cmd, count in sorted(common_cmds.items(), key=lambda x: -x[1])[:3]:
            if count > 3 and len(cmd) > 3:
                alias_name = cmd[:2]
                improvements.append(F1Improvement(
                    id=str(uuid.uuid4())[:8],
                    type=ImprovementType.WORKFLOW_ENHANCEMENT,
                    target_terminal=target.id,
                    description=f"Create alias '{alias_name}' for frequently used '{cmd}'",
                    command=f"Set-Alias -Name {alias_name} -Value {cmd}" if is_powershell else f"alias {alias_name}='{cmd}'",
                    script=None,
                    priority=4,
                    estimated_impact=0.3,
                    auto_apply=True,
                    requires_confirmation=False
                ))
        
        return improvements
    
    async def _analyze_performance(self, snapshot: TerminalSnapshot, target: TerminalNode) -> List[F1Improvement]:
        """Level 2: Analyze performance and suggest optimizations"""
        improvements = []
        is_powershell = "powershell" in target.shell.lower()
        
        # Check for history optimization
        history_size = len(snapshot.command_history)
        if history_size > 100:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.PERFORMANCE_TUNING,
                target_terminal=target.id,
                description="Enable command history deduplication",
                command="Set-PSReadLineOption -HistoryNoDuplicates" if is_powershell else "export HISTCONTROL=ignoredups:erasedups",
                script=None,
                priority=4,
                estimated_impact=0.3,
                auto_apply=True,
                requires_confirmation=False
            ))
        
        # Suggest parallel execution if sequential patterns detected
        if any("&&" in cmd or ";" in cmd for cmd in snapshot.command_history):
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.PERFORMANCE_TUNING,
                target_terminal=target.id,
                description="Consider parallel job execution for independent commands",
                command="# Use Start-Job for parallel execution" if is_powershell else "# Use & for background jobs",
                script=None,
                priority=3,
                estimated_impact=0.4,
                auto_apply=False,
                requires_confirmation=False
            ))
        
        return improvements
    
    async def _analyze_automation(self, snapshot: TerminalSnapshot, target: TerminalNode) -> List[F1Improvement]:
        """Level 4: Suggest automation improvements"""
        improvements = []
        is_powershell = "powershell" in target.shell.lower()
        
        # Check for repetitive command patterns
        if len(snapshot.command_history) > 10:
            # Look for patterns that could be automated
            patterns = {}
            for i in range(len(snapshot.command_history) - 1):
                pair = (snapshot.command_history[i], snapshot.command_history[i+1])
                patterns[pair] = patterns.get(pair, 0) + 1
            
            for (cmd1, cmd2), count in patterns.items():
                if count >= 2:
                    improvements.append(F1Improvement(
                        id=str(uuid.uuid4())[:8],
                        type=ImprovementType.WORKFLOW_ENHANCEMENT,
                        target_terminal=target.id,
                        description=f"Create automation script for repeated sequence: {cmd1[:20]}... → {cmd2[:20]}...",
                        command=None,
                        script=f"# Auto-generated workflow\n{cmd1}\n{cmd2}",
                        priority=5,
                        estimated_impact=0.5,
                        auto_apply=False,
                        requires_confirmation=True
                    ))
                    break  # Only suggest one
        
        # Suggest task scheduler integration
        improvements.append(F1Improvement(
            id=str(uuid.uuid4())[:8],
            type=ImprovementType.WORKFLOW_ENHANCEMENT,
            target_terminal=target.id,
            description="Enable scheduled task capabilities",
            command="Get-ScheduledTask | Select-Object -First 1" if is_powershell else "crontab -l 2>/dev/null || echo 'No crontab'",
            script=None,
            priority=3,
            estimated_impact=0.2,
            auto_apply=True,
            requires_confirmation=False
        ))
        
        return improvements
    
    async def _comprehensive_analysis(self, snapshot: TerminalSnapshot, target: TerminalNode) -> List[F1Improvement]:
        """Level 5+: Comprehensive re-analysis for advanced terminals"""
        improvements = []
        is_powershell = "powershell" in target.shell.lower()
        
        # At high levels, suggest integration improvements
        improvements.append(F1Improvement(
            id=str(uuid.uuid4())[:8],
            type=ImprovementType.WORKFLOW_ENHANCEMENT,
            target_terminal=target.id,
            description=f"Terminal at F1 Level {target.f1_level} - Consider cross-mesh synchronization",
            command="# Advanced: Enable mesh sync protocols",
            script=None,
            priority=2,
            estimated_impact=0.6,
            auto_apply=False,
            requires_confirmation=True
        ))
        
        # Suggest profile optimization
        profile_path = "$PROFILE" if is_powershell else "~/.bashrc"
        improvements.append(F1Improvement(
            id=str(uuid.uuid4())[:8],
            type=ImprovementType.CONFIGURATION,
            target_terminal=target.id,
            description=f"Optimize shell profile ({profile_path}) with learned patterns",
            command=f"Test-Path {profile_path}" if is_powershell else f"test -f {profile_path} && echo 'Profile exists'",
            script=None,
            priority=4,
            estimated_impact=0.5,
            auto_apply=True,
            requires_confirmation=False
        ))
        
        return improvements
    
    async def _analyze_errors(self, snapshot: TerminalSnapshot) -> List[F1Improvement]:
        """Analyze for error patterns"""
        improvements = []
        
        # Check error buffer
        for error in snapshot.errors:
            improvement = F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.ERROR_CORRECTION,
                target_terminal=snapshot.terminal_id,
                description=f"Error detected: {error[:100]}...",
                command=None,
                script=None,
                priority=9,
                estimated_impact=0.8,
                auto_apply=False,
                requires_confirmation=True
            )
            improvements.append(improvement)
        
        # Check last exit code
        if snapshot.last_exit_code and snapshot.last_exit_code != 0:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.ERROR_CORRECTION,
                target_terminal=snapshot.terminal_id,
                description=f"Last command failed with exit code {snapshot.last_exit_code}",
                command=f"# Retry: {snapshot.last_command}" if snapshot.last_command else None,
                script=None,
                priority=8,
                estimated_impact=0.7,
                auto_apply=False,
                requires_confirmation=True
            ))
        
        return improvements
    
    async def _analyze_optimizations(self, snapshot: TerminalSnapshot) -> List[F1Improvement]:
        """Analyze for optimization opportunities"""
        improvements = []
        
        # Check command history for patterns
        for cmd in snapshot.command_history:
            for pattern in self.analysis_patterns["optimization_patterns"]:
                import re
                if re.search(pattern["pattern"], cmd):
                    improvements.append(F1Improvement(
                        id=str(uuid.uuid4())[:8],
                        type=ImprovementType.COMMAND_OPTIMIZATION,
                        target_terminal=snapshot.terminal_id,
                        description=pattern["suggestion"],
                        command=None,
                        script=None,
                        priority=5,
                        estimated_impact=0.4,
                        auto_apply=False,
                        requires_confirmation=False
                    ))
        
        return improvements
    
    async def _analyze_configuration(self, snapshot: TerminalSnapshot, shell: str = "sh") -> List[F1Improvement]:
        """Analyze environment and configuration"""
        improvements = []
        
        # Determine if PowerShell based on shell type
        is_powershell = "powershell" in shell.lower() or "pwsh" in shell.lower()
        
        # Check for missing common env vars
        recommended_vars = ["EDITOR", "PYTHONPATH", "NODE_ENV"]
        for var in recommended_vars:
            if var not in snapshot.env_vars:
                # Use correct syntax for the shell
                if is_powershell:
                    cmd = f"$env:{var} = 'value'"
                else:
                    cmd = f"export {var}=value"
                    
                improvements.append(F1Improvement(
                    id=str(uuid.uuid4())[:8],
                    type=ImprovementType.CONFIGURATION,
                    target_terminal=snapshot.terminal_id,
                    description=f"Consider setting {var} environment variable",
                    command=cmd,
                    script=None,
                    priority=3,
                    estimated_impact=0.2,
                    auto_apply=True,  # Safe to auto-apply
                    requires_confirmation=False
                ))
        
        return improvements
    
    async def _analyze_security(self, snapshot: TerminalSnapshot) -> List[F1Improvement]:
        """Analyze for security issues"""
        improvements = []
        
        # Check command history for security patterns
        for cmd in snapshot.command_history:
            for pattern in self.analysis_patterns["security_patterns"]:
                import re
                if re.search(pattern["pattern"], cmd, re.IGNORECASE):
                    improvements.append(F1Improvement(
                        id=str(uuid.uuid4())[:8],
                        type=ImprovementType.SECURITY_HARDENING,
                        target_terminal=snapshot.terminal_id,
                        description=f"Security issue: {pattern['suggestion']}",
                        command=None,
                        script=None,
                        priority=10 if pattern["severity"] == "high" else 7,
                        estimated_impact=0.9 if pattern["severity"] == "high" else 0.6,
                        auto_apply=False,
                        requires_confirmation=True
                    ))
        
        return improvements
    
    async def _analyze_resources(self, snapshot: TerminalSnapshot) -> List[F1Improvement]:
        """Analyze resource usage"""
        improvements = []
        usage = snapshot.resource_usage
        
        if usage.get("cpu_percent", 0) > 80:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.PERFORMANCE_TUNING,
                target_terminal=snapshot.terminal_id,
                description=f"High CPU usage: {usage['cpu_percent']}%",
                command=None,
                script=None,
                priority=7,
                estimated_impact=0.6,
                auto_apply=False,
                requires_confirmation=True
            ))
        
        if usage.get("memory_percent", 0) > 85:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.PERFORMANCE_TUNING,
                target_terminal=snapshot.terminal_id,
                description=f"High memory usage: {usage['memory_percent']}%",
                command=None,
                script=None,
                priority=8,
                estimated_impact=0.7,
                auto_apply=False,
                requires_confirmation=True
            ))
        
        if usage.get("disk_percent", 0) > 90:
            improvements.append(F1Improvement(
                id=str(uuid.uuid4())[:8],
                type=ImprovementType.CLEANUP,
                target_terminal=snapshot.terminal_id,
                description=f"Disk nearly full: {usage['disk_percent']}%",
                command="# Run disk cleanup",
                script=None,
                priority=9,
                estimated_impact=0.8,
                auto_apply=False,
                requires_confirmation=True
            ))
        
        return improvements
    
    async def _analyze_cross_terminal(self, target: TerminalNode) -> List[F1Improvement]:
        """Analyze improvements based on cross-terminal knowledge"""
        improvements = []
        
        # Compare capabilities
        source_caps = self.source.capabilities
        target_caps = target.capabilities
        
        missing_tools = source_caps - target_caps
        for cap in missing_tools:
            if cap.startswith("tool:"):
                tool = cap.replace("tool:", "")
                improvements.append(F1Improvement(
                    id=str(uuid.uuid4())[:8],
                    type=ImprovementType.DEPENDENCY_UPDATE,
                    target_terminal=target.id,
                    description=f"Install {tool} (available in source terminal)",
                    command=self._get_install_command(tool),
                    script=None,
                    priority=4,
                    estimated_impact=0.5,
                    auto_apply=False,
                    requires_confirmation=True
                ))
        
        return improvements
    
    def _get_install_command(self, tool: str) -> str:
        """Get install command for a tool"""
        install_commands = {
            "git": "winget install Git.Git" if os.name == "nt" else "apt install git",
            "python": "winget install Python.Python.3.12" if os.name == "nt" else "apt install python3",
            "node": "winget install OpenJS.NodeJS" if os.name == "nt" else "apt install nodejs",
            "npm": "# Installed with Node.js",
            "pip": "python -m ensurepip --upgrade",
            "gh": "winget install GitHub.cli" if os.name == "nt" else "apt install gh",
            "docker": "winget install Docker.DockerDesktop" if os.name == "nt" else "apt install docker.io",
        }
        return install_commands.get(tool, f"# Install {tool}")


# =============================================================================
# F1 IMPROVER
# =============================================================================

class F1TerminalImprover:
    """
    Applies improvements to a target terminal.
    Phase 2 of the F1 cycle.
    """
    
    def __init__(self, source: TerminalNode):
        self.source = source
    
    async def improve(
        self,
        target: TerminalNode,
        improvements: List[F1Improvement],
        auto_only: bool = True,
        force_apply: bool = False
    ) -> List[str]:
        """
        Apply improvements to target terminal.
        Returns list of applied improvement IDs.
        
        Args:
            target: The terminal to improve
            improvements: List of improvements to consider
            auto_only: If True, only apply improvements marked auto_apply=True
            force_apply: If True, apply ALL improvements (overrides auto_only)
        """
        self.source.state = TerminalState.IMPROVING
        applied_ids: List[str] = []
        
        for improvement in improvements:
            # If force_apply, apply everything that has a command
            if force_apply:
                if improvement.command or improvement.script:
                    success = await self._apply_improvement(target, improvement)
                    if success:
                        applied_ids.append(improvement.id)
                continue
            
            # Skip if not auto-applicable and auto_only is True
            if auto_only and not improvement.auto_apply:
                target.pending_improvements.append(improvement)
                continue
            
            # Skip if requires confirmation (unless explicitly allowed)
            if improvement.requires_confirmation and auto_only:
                target.pending_improvements.append(improvement)
                continue
            
            # Apply the improvement
            success = await self._apply_improvement(target, improvement)
            if success:
                applied_ids.append(improvement.id)
        
        self.source.state = TerminalState.IDLE
        return applied_ids
    
    async def _apply_improvement(
        self,
        target: TerminalNode,
        improvement: F1Improvement
    ) -> bool:
        """Apply a single improvement and record it in target's history"""
        try:
            success = False
            
            if improvement.command:
                exit_code, stdout, stderr = await target.execute_command(
                    improvement.command,
                    timeout=30
                )
                success = exit_code == 0
            
            elif improvement.script:
                # Write script to temp file and execute
                script_path = Path(target.cwd) / f".aria_temp_{improvement.id}.sh"
                script_path.write_text(improvement.script)
                try:
                    exit_code, stdout, stderr = await target.execute_command(
                        f"bash {script_path}" if os.name != "nt" else f"powershell {script_path}",
                        timeout=60
                    )
                    success = exit_code == 0
                finally:
                    if script_path.exists():
                        script_path.unlink()
            else:
                success = True  # No command/script = informational only
            
            # Record the improvement in target's history if successful
            if success:
                target.record_improvement(improvement)
            
            return success
            
        except Exception as e:
            target.error_buffer.append(f"Failed to apply improvement {improvement.id}: {e}")
            return False


# =============================================================================
# F1 VALIDATOR
# =============================================================================

class F1TerminalValidator:
    """
    Validates improvements were successfully applied.
    Phase 3 of the F1 cycle.
    """
    
    def __init__(self, source: TerminalNode):
        self.source = source
    
    async def validate(
        self,
        target: TerminalNode,
        improvements: List[F1Improvement],
        applied_ids: List[str]
    ) -> Tuple[bool, Dict[str, bool]]:
        """
        Validate improvements on target terminal.
        Returns (overall_success, per_improvement_results).
        """
        self.source.state = TerminalState.VALIDATING
        results: Dict[str, bool] = {}
        
        for improvement in improvements:
            if improvement.id in applied_ids:
                valid = await self._validate_improvement(target, improvement)
                results[improvement.id] = valid
        
        overall = all(results.values()) if results else True
        self.source.state = TerminalState.IDLE
        
        return overall, results
    
    async def _validate_improvement(
        self,
        target: TerminalNode,
        improvement: F1Improvement
    ) -> bool:
        """Validate a single improvement"""
        # Take new snapshot and compare
        snapshot = target.take_snapshot()
        
        # Check for new errors
        if snapshot.errors and len(snapshot.errors) > len(target.error_buffer):
            return False
        
        # Type-specific validation
        if improvement.type == ImprovementType.ERROR_CORRECTION:
            # Check if error is resolved
            return snapshot.last_exit_code == 0 or snapshot.last_exit_code is None
        
        elif improvement.type == ImprovementType.DEPENDENCY_UPDATE:
            # Check if tool is now available
            if improvement.command and "install" in improvement.command:
                tool = improvement.command.split()[-1]
                return f"tool:{tool}" in target.capabilities
        
        elif improvement.type == ImprovementType.PERFORMANCE_TUNING:
            # Check if resource usage improved
            usage = snapshot.resource_usage
            return usage.get("cpu_percent", 100) < 90 and usage.get("memory_percent", 100) < 90
        
        # Default: assume valid if no errors
        return True


# =============================================================================
# F1 MESH NETWORK
# =============================================================================

class F1TerminalMesh:
    """
    Network of terminals that perform F1 cycles on each other.
    Manages connections, routing, and coordination.
    """
    
    def __init__(
        self,
        topology: MeshTopology = MeshTopology.ADAPTIVE,
        name: str = "aria-f1-mesh"
    ):
        self.name = name
        self.topology = topology
        self.created_at = time.time()
        
        # Terminals in the mesh
        self.terminals: Dict[str, TerminalNode] = {}
        self.connections: Dict[str, MeshConnection] = {}
        
        # Cycle tracking
        self.active_cycles: Dict[str, F1CycleResult] = {}
        self.completed_cycles: List[F1CycleResult] = []
        
        # Statistics
        self.total_improvements = 0
        self.total_cycles = 0
        
        # Event callbacks
        self._on_cycle_complete: List[Callable] = []
        self._on_improvement_applied: List[Callable] = []
    
    def add_terminal(self, terminal: TerminalNode) -> None:
        """Add a terminal to the mesh"""
        self.terminals[terminal.id] = terminal
        
        # Create connections based on topology
        self._update_connections()
    
    def remove_terminal(self, terminal_id: str) -> None:
        """Remove a terminal from the mesh"""
        if terminal_id in self.terminals:
            del self.terminals[terminal_id]
            # Remove connections
            self.connections = {
                k: v for k, v in self.connections.items()
                if v.source_id != terminal_id and v.target_id != terminal_id
            }
    
    def _update_connections(self) -> None:
        """Update connections based on topology"""
        terminal_ids = list(self.terminals.keys())
        
        if self.topology == MeshTopology.RING:
            # Each terminal connects to the next
            for i, tid in enumerate(terminal_ids):
                next_id = terminal_ids[(i + 1) % len(terminal_ids)]
                if tid != next_id:
                    conn_id = f"{tid}->{next_id}"
                    if conn_id not in self.connections:
                        self.connections[conn_id] = MeshConnection(
                            source_id=tid,
                            target_id=next_id,
                            established_at=time.time()
                        )
        
        elif self.topology == MeshTopology.STAR:
            # First terminal is hub, connects to all others
            if terminal_ids:
                hub = terminal_ids[0]
                for tid in terminal_ids[1:]:
                    conn_id = f"{hub}->{tid}"
                    if conn_id not in self.connections:
                        self.connections[conn_id] = MeshConnection(
                            source_id=hub,
                            target_id=tid,
                            established_at=time.time()
                        )
        
        elif self.topology == MeshTopology.FULL_MESH:
            # Every terminal connects to every other
            for source in terminal_ids:
                for target in terminal_ids:
                    if source != target:
                        conn_id = f"{source}->{target}"
                        if conn_id not in self.connections:
                            self.connections[conn_id] = MeshConnection(
                                source_id=source,
                                target_id=target,
                                established_at=time.time()
                            )
        
        elif self.topology == MeshTopology.ADAPTIVE:
            # Start with ring, evolve based on performance
            self._adaptive_topology()
    
    def _adaptive_topology(self) -> None:
        """Adaptive topology that evolves based on performance"""
        terminal_ids = list(self.terminals.keys())
        
        # Start with ring pattern
        for i, tid in enumerate(terminal_ids):
            next_id = terminal_ids[(i + 1) % len(terminal_ids)]
            if tid != next_id:
                conn_id = f"{tid}->{next_id}"
                if conn_id not in self.connections:
                    self.connections[conn_id] = MeshConnection(
                        source_id=tid,
                        target_id=next_id,
                        established_at=time.time()
                    )
        
        # Add high-performing connections
        for conn in self.connections.values():
            if conn.success_rate > 0.9 and conn.total_improvements > 5:
                # Create reverse connection for bidirectional improvement
                reverse_id = f"{conn.target_id}->{conn.source_id}"
                if reverse_id not in self.connections:
                    self.connections[reverse_id] = MeshConnection(
                        source_id=conn.target_id,
                        target_id=conn.source_id,
                        established_at=time.time()
                    )
    
    async def run_f1_cycle(
        self,
        source_id: str,
        target_id: str,
        auto_apply: bool = False,
        force_apply: bool = False
    ) -> F1CycleResult:
        """
        Run a complete F1 cycle from source to target terminal.
        
        Args:
            source_id: ID of the source terminal (the analyzer)
            target_id: ID of the target terminal (being improved)
            auto_apply: If True, apply improvements marked as auto_apply
            force_apply: If True, apply ALL improvements with commands
        """
        source = self.terminals.get(source_id)
        target = self.terminals.get(target_id)
        
        if not source or not target:
            raise ValueError(f"Source or target terminal not found")
        
        cycle_id = f"{source_id}->{target_id}:{int(time.time())}"
        started_at = time.time()
        
        # Phase 1: ANALYZE
        analyzer = F1TerminalAnalyzer(source)
        improvements = await analyzer.analyze(target)
        
        # Phase 2: IMPROVE
        improver = F1TerminalImprover(source)
        applied_ids = await improver.improve(
            target, 
            improvements, 
            auto_only=not auto_apply,
            force_apply=force_apply
        )
        
        # Phase 3: VALIDATE
        validator = F1TerminalValidator(source)
        validation_passed, validation_results = await validator.validate(
            target, improvements, applied_ids
        )
        
        completed_at = time.time()
        
        # Create result
        result = F1CycleResult(
            source_terminal=source_id,
            target_terminal=target_id,
            phase=F1Phase.VALIDATE,  # Completed all phases
            started_at=started_at,
            completed_at=completed_at,
            success=validation_passed,
            improvements_found=improvements,
            improvements_applied=applied_ids,
            validation_passed=validation_passed,
            metrics={
                "duration": completed_at - started_at,
                "improvements_count": len(improvements),
                "applied_count": len(applied_ids),
                "validation_results": validation_results,
                "target_f1_level": target.f1_level
            }
        )
        
        # Track the cycle in target
        target.cycles_received.append(result)
        
        # Advance F1 level if improvements were applied
        if len(applied_ids) > 0 and validation_passed:
            old_level = target.f1_level
            new_level = target.advance_f1_level()
            result.metrics["level_advanced"] = True
            result.metrics["old_level"] = old_level
            result.metrics["new_level"] = new_level
        
        # Track in mesh
        self.completed_cycles.append(result)
        self.total_cycles += 1
        self.total_improvements += len(applied_ids)
        
        # Update connection
        conn_id = f"{source_id}->{target_id}"
        if conn_id in self.connections:
            conn = self.connections[conn_id]
            conn.last_f1_cycle = completed_at
            conn.total_cycles += 1
            if result.success:
                conn.successful_cycles += 1
            conn.total_improvements += len(applied_ids)
        
        # Callbacks
        for callback in self._on_cycle_complete:
            await callback(result) if asyncio.iscoroutinefunction(callback) else callback(result)
        
        return result
    
    async def run_mesh_cycle(self, max_concurrent: int = 3) -> List[F1CycleResult]:
        """
        Run F1 cycles across all connections in the mesh.
        """
        results: List[F1CycleResult] = []
        
        # Group connections for parallel execution
        connection_list = list(self.connections.values())
        
        for i in range(0, len(connection_list), max_concurrent):
            batch = connection_list[i:i + max_concurrent]
            tasks = [
                self.run_f1_cycle(conn.source_id, conn.target_id)
                for conn in batch
            ]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in batch_results:
                if isinstance(result, F1CycleResult):
                    results.append(result)
                elif isinstance(result, Exception):
                    print(f"Cycle failed: {result}")
        
        return results
    
    async def run_until_stable(
        self,
        max_iterations: int = 10,
        stability_threshold: int = 2
    ) -> Dict[str, Any]:
        """
        Run mesh cycles until no more improvements are found.
        """
        iteration = 0
        no_improvement_count = 0
        all_results: List[F1CycleResult] = []
        
        while iteration < max_iterations:
            iteration += 1
            results = await self.run_mesh_cycle()
            all_results.extend(results)
            
            # Count improvements this iteration
            improvements_this_round = sum(
                len(r.improvements_applied) for r in results
            )
            
            if improvements_this_round == 0:
                no_improvement_count += 1
                if no_improvement_count >= stability_threshold:
                    break
            else:
                no_improvement_count = 0
        
        return {
            "iterations": iteration,
            "total_cycles": len(all_results),
            "total_improvements": sum(len(r.improvements_applied) for r in all_results),
            "stable": no_improvement_count >= stability_threshold,
            "results": all_results
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get mesh status"""
        return {
            "name": self.name,
            "topology": self.topology.value,
            "terminals": len(self.terminals),
            "connections": len(self.connections),
            "total_cycles": self.total_cycles,
            "total_improvements": self.total_improvements,
            "terminals_list": [
                {
                    "id": t.id,
                    "name": t.name,
                    "shell": t.shell,
                    "state": t.state.value,
                    "cwd": str(t.cwd),
                    "f1_level": t.f1_level,
                    "improvements_applied": sum(
                        len(hist) for hist in t.improvement_history.values()
                    )
                }
                for t in self.terminals.values()
            ],
            "connections_list": [
                {
                    "source": c.source_id,
                    "target": c.target_id,
                    "cycles": c.total_cycles,
                    "success_rate": f"{c.success_rate:.1%}",
                    "improvements": c.total_improvements
                }
                for c in self.connections.values()
            ]
        }


# =============================================================================
# GLOBAL MESH INSTANCE
# =============================================================================

_global_mesh: Optional[F1TerminalMesh] = None


def get_mesh(topology: MeshTopology = MeshTopology.ADAPTIVE) -> F1TerminalMesh:
    """Get or create global mesh instance"""
    global _global_mesh
    if _global_mesh is None:
        _global_mesh = F1TerminalMesh(topology=topology)
    return _global_mesh


def create_terminal(name: Optional[str] = None) -> TerminalNode:
    """Create a new terminal and add to mesh"""
    terminal = TerminalNode(name=name)
    mesh = get_mesh()
    mesh.add_terminal(terminal)
    return terminal


async def run_f1_between(
    source_name: str,
    target_name: str,
    auto_apply: bool = True
) -> F1CycleResult:
    """Run F1 cycle between two terminals by name"""
    mesh = get_mesh()
    
    # Find terminals by name
    source = next((t for t in mesh.terminals.values() if t.name == source_name), None)
    target = next((t for t in mesh.terminals.values() if t.name == target_name), None)
    
    if not source:
        source = create_terminal(source_name)
    if not target:
        target = create_terminal(target_name)
    
    return await mesh.run_f1_cycle(source.id, target.id, auto_apply=auto_apply)


# =============================================================================
# CLI DEMO
# =============================================================================

async def demo():
    """Demo the terminal-to-terminal F1 system"""
    print("=" * 60)
    print("🔄 ARIA Terminal-to-Terminal F1 Mesh Demo")
    print("=" * 60)
    
    # Create mesh with ring topology
    mesh = F1TerminalMesh(topology=MeshTopology.RING, name="demo-mesh")
    
    # Create terminals
    print("\n📟 Creating terminals...")
    t1 = TerminalNode(name="terminal-alpha", shell="powershell")
    t2 = TerminalNode(name="terminal-beta", shell="powershell")
    t3 = TerminalNode(name="terminal-gamma", shell="powershell")
    
    mesh.add_terminal(t1)
    mesh.add_terminal(t2)
    mesh.add_terminal(t3)
    
    print(f"  ✓ Created {t1.name} ({t1.id})")
    print(f"  ✓ Created {t2.name} ({t2.id})")
    print(f"  ✓ Created {t3.name} ({t3.id})")
    
    # Show topology
    print(f"\n🔗 Mesh Topology: {mesh.topology.value}")
    for conn in mesh.connections.values():
        src = mesh.terminals[conn.source_id].name
        tgt = mesh.terminals[conn.target_id].name
        print(f"  {src} ──F1──► {tgt}")
    
    # Run single F1 cycle
    print("\n🔄 Running F1 cycle: alpha → beta")
    result = await mesh.run_f1_cycle(t1.id, t2.id)
    print(f"  ✓ Completed in {result.duration:.2f}s")
    print(f"  📊 Found {len(result.improvements_found)} improvements")
    print(f"  ✅ Applied {len(result.improvements_applied)} improvements")
    print(f"  {'✓' if result.validation_passed else '✗'} Validation: {'PASSED' if result.validation_passed else 'FAILED'}")
    
    # Run full mesh cycle
    print("\n🌐 Running full mesh cycle...")
    results = await mesh.run_mesh_cycle()
    print(f"  ✓ Completed {len(results)} cycles")
    
    # Get status
    print("\n📈 Mesh Status:")
    status = mesh.get_status()
    print(f"  Terminals: {status['terminals']}")
    print(f"  Connections: {status['connections']}")
    print(f"  Total Cycles: {status['total_cycles']}")
    print(f"  Total Improvements: {status['total_improvements']}")
    
    print("\n✨ Demo complete!")
    return mesh


if __name__ == "__main__":
    asyncio.run(demo())
