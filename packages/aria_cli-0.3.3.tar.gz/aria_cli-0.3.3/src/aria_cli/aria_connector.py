"""
ARIA Connector for CLI v0.2.0

Synchronization layer between CLI and GUI versions:
- State synchronization
- Event bridging
- Configuration sharing
- Plugin system
"""

import json
import time
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
import threading
import socket
import os


class SyncMode(Enum):
    """Synchronization modes"""
    NONE = auto()          # No sync
    FILE = auto()          # File-based sync
    SOCKET = auto()        # Socket-based sync
    MEMORY = auto()        # In-memory (same process)


class EventType(Enum):
    """Event types for CLI-GUI communication"""
    # State events
    STATE_CHANGE = "state_change"
    LAYER_SWITCH = "layer_switch"
    CONTEXT_UPDATE = "context_update"
    
    # Command events
    COMMAND_SENT = "command_sent"
    COMMAND_RESULT = "command_result"
    
    # System events
    LLM_CONNECTED = "llm_connected"
    LLM_DISCONNECTED = "llm_disconnected"
    ERROR = "error"
    
    # Sync events
    SYNC_REQUEST = "sync_request"
    SYNC_RESPONSE = "sync_response"


@dataclass
class AriaEvent:
    """Event for CLI-GUI communication"""
    type: EventType
    data: Dict[str, Any]
    source: str  # 'cli' or 'gui'
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.type.value,
            'data': self.data,
            'source': self.source,
            'timestamp': self.timestamp,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'AriaEvent':
        return cls(
            type=EventType(d['type']),
            data=d['data'],
            source=d['source'],
            timestamp=d.get('timestamp', time.time()),
        )
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_json(cls, s: str) -> 'AriaEvent':
        return cls.from_dict(json.loads(s))


@dataclass
class SyncState:
    """Synchronized state between CLI and GUI"""
    current_layer: int = 8
    context: Dict[str, Any] = field(default_factory=dict)
    history: List[Dict[str, Any]] = field(default_factory=list)
    llm_status: str = "disconnected"
    llm_backend: Optional[str] = None
    active_plugins: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'current_layer': self.current_layer,
            'context': self.context,
            'history': self.history[-10:],  # Last 10 entries
            'llm_status': self.llm_status,
            'llm_backend': self.llm_backend,
            'active_plugins': self.active_plugins,
            'timestamp': self.timestamp,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'SyncState':
        return cls(
            current_layer=d.get('current_layer', 8),
            context=d.get('context', {}),
            history=d.get('history', []),
            llm_status=d.get('llm_status', 'disconnected'),
            llm_backend=d.get('llm_backend'),
            active_plugins=d.get('active_plugins', []),
            timestamp=d.get('timestamp', time.time()),
        )


class AriaConnector:
    """
    Connector for CLI-GUI synchronization
    
    Supports multiple sync modes:
    - FILE: Uses a shared JSON file for state
    - SOCKET: Uses local socket for real-time sync
    - MEMORY: In-process sync for embedded use
    """
    
    DEFAULT_SYNC_DIR = Path.home() / '.aria'
    DEFAULT_SYNC_FILE = 'sync_state.json'
    DEFAULT_SOCKET_PORT = 51738  # ARIA in phone numbers
    
    def __init__(
        self,
        mode: SyncMode = SyncMode.FILE,
        source: str = 'cli',
        sync_dir: Optional[Path] = None,
        socket_port: Optional[int] = None,
    ):
        """
        Initialize ARIA Connector
        
        Args:
            mode: Synchronization mode
            source: Source identifier ('cli' or 'gui')
            sync_dir: Directory for file-based sync
            socket_port: Port for socket-based sync
        """
        self.mode = mode
        self.source = source
        self.sync_dir = sync_dir or self.DEFAULT_SYNC_DIR
        self.socket_port = socket_port or self.DEFAULT_SOCKET_PORT
        
        # State
        self._state = SyncState()
        self._event_handlers: Dict[EventType, List[Callable[[AriaEvent], None]]] = {}
        self._running = False
        self._lock = threading.Lock()
        
        # Socket (for SOCKET mode)
        self._socket: Optional[socket.socket] = None
        self._listener_thread: Optional[threading.Thread] = None
        
        # Ensure sync directory exists
        self.sync_dir.mkdir(parents=True, exist_ok=True)
    
    @property
    def state(self) -> SyncState:
        """Get current synchronized state"""
        with self._lock:
            return self._state
    
    def update_state(self, **kwargs) -> SyncState:
        """
        Update synchronized state
        
        Args:
            **kwargs: State fields to update
            
        Returns:
            Updated state
        """
        with self._lock:
            for key, value in kwargs.items():
                if hasattr(self._state, key):
                    setattr(self._state, key, value)
            self._state.timestamp = time.time()
        
        # Sync and notify
        self._sync_state()
        self.emit(EventType.STATE_CHANGE, {'updated': list(kwargs.keys())})
        
        return self._state
    
    def emit(self, event_type: EventType, data: Dict[str, Any]):
        """
        Emit an event
        
        Args:
            event_type: Type of event
            data: Event data
        """
        event = AriaEvent(
            type=event_type,
            data=data,
            source=self.source,
        )
        
        # Call local handlers
        handlers = self._event_handlers.get(event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception:
                pass
        
        # Send to other side based on mode
        if self.mode == SyncMode.FILE:
            self._emit_file(event)
        elif self.mode == SyncMode.SOCKET:
            self._emit_socket(event)
    
    def on(self, event_type: EventType, handler: Callable[[AriaEvent], None]):
        """
        Register an event handler
        
        Args:
            event_type: Type of event to handle
            handler: Handler function
        """
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)
    
    def off(self, event_type: EventType, handler: Callable[[AriaEvent], None]):
        """
        Remove an event handler
        
        Args:
            event_type: Type of event
            handler: Handler to remove
        """
        if event_type in self._event_handlers:
            try:
                self._event_handlers[event_type].remove(handler)
            except ValueError:
                pass
    
    def start(self):
        """Start the connector"""
        if self._running:
            return
        
        self._running = True
        
        if self.mode == SyncMode.FILE:
            self._start_file_watcher()
        elif self.mode == SyncMode.SOCKET:
            self._start_socket_listener()
        
        # Load existing state
        self._load_state()
    
    def stop(self):
        """Stop the connector"""
        self._running = False
        
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None
        
        if self._listener_thread:
            self._listener_thread.join(timeout=1.0)
            self._listener_thread = None
    
    def sync(self) -> SyncState:
        """
        Force synchronization
        
        Returns:
            Current synchronized state
        """
        self._load_state()
        self._sync_state()
        return self._state
    
    # File-based sync methods
    
    def _sync_state(self):
        """Sync state to file"""
        if self.mode == SyncMode.FILE:
            state_file = self.sync_dir / self.DEFAULT_SYNC_FILE
            with self._lock:
                data = self._state.to_dict()
            try:
                with open(state_file, 'w') as f:
                    json.dump(data, f, indent=2)
            except Exception:
                pass
    
    def _load_state(self):
        """Load state from file"""
        if self.mode == SyncMode.FILE:
            state_file = self.sync_dir / self.DEFAULT_SYNC_FILE
            if state_file.exists():
                try:
                    with open(state_file) as f:
                        data = json.load(f)
                    with self._lock:
                        self._state = SyncState.from_dict(data)
                except Exception:
                    pass
    
    def _emit_file(self, event: AriaEvent):
        """Emit event to file"""
        event_file = self.sync_dir / 'events' / f'{event.timestamp}_{event.type.value}.json'
        event_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(event_file, 'w') as f:
                json.dump(event.to_dict(), f)
        except Exception:
            pass
    
    def _start_file_watcher(self):
        """Start watching for file changes"""
        # Simple polling-based watcher
        def watch():
            last_mtime = 0
            while self._running:
                state_file = self.sync_dir / self.DEFAULT_SYNC_FILE
                try:
                    mtime = state_file.stat().st_mtime if state_file.exists() else 0
                    if mtime > last_mtime:
                        last_mtime = mtime
                        self._load_state()
                except Exception:
                    pass
                time.sleep(0.5)
        
        self._listener_thread = threading.Thread(target=watch, daemon=True)
        self._listener_thread.start()
    
    # Socket-based sync methods
    
    def _emit_socket(self, event: AriaEvent):
        """Emit event through socket"""
        if self._socket:
            try:
                self._socket.sendall(event.to_json().encode() + b'\n')
            except Exception:
                pass
    
    def _start_socket_listener(self):
        """Start socket listener"""
        def listen():
            try:
                self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self._socket.bind(('127.0.0.1', self.socket_port))
                self._socket.listen(1)
                self._socket.settimeout(1.0)
                
                while self._running:
                    try:
                        conn, addr = self._socket.accept()
                        self._handle_connection(conn)
                    except socket.timeout:
                        continue
                    except Exception:
                        break
            except Exception:
                pass
        
        self._listener_thread = threading.Thread(target=listen, daemon=True)
        self._listener_thread.start()
    
    def _handle_connection(self, conn: socket.socket):
        """Handle incoming socket connection"""
        buffer = ""
        try:
            while self._running:
                data = conn.recv(4096).decode()
                if not data:
                    break
                buffer += data
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    if line:
                        try:
                            event = AriaEvent.from_json(line)
                            # Call handlers
                            handlers = self._event_handlers.get(event.type, [])
                            for handler in handlers:
                                handler(event)
                        except Exception:
                            pass
        except Exception:
            pass
        finally:
            conn.close()
    
    # Convenience methods
    
    def switch_layer(self, layer: int):
        """Switch to a different Q-Layer"""
        self.update_state(current_layer=layer)
        self.emit(EventType.LAYER_SWITCH, {'layer': layer})
    
    def add_history(self, entry: Dict[str, Any]):
        """Add entry to synchronized history"""
        with self._lock:
            self._state.history.append(entry)
            if len(self._state.history) > 100:
                self._state.history = self._state.history[-100:]
        self._sync_state()
    
    def set_llm_status(self, connected: bool, backend: Optional[str] = None):
        """Update LLM connection status"""
        status = 'connected' if connected else 'disconnected'
        self.update_state(llm_status=status, llm_backend=backend)
        
        event_type = EventType.LLM_CONNECTED if connected else EventType.LLM_DISCONNECTED
        self.emit(event_type, {'backend': backend})


class PluginManager:
    """
    Plugin system for ARIA
    
    Allows extending both CLI and GUI with shared plugins.
    """
    
    def __init__(self, connector: Optional[AriaConnector] = None):
        """
        Initialize Plugin Manager
        
        Args:
            connector: Optional AriaConnector for sync
        """
        self.connector = connector
        self._plugins: Dict[str, 'AriaPlugin'] = {}
    
    def register(self, plugin: 'AriaPlugin'):
        """Register a plugin"""
        self._plugins[plugin.name] = plugin
        plugin.on_register(self)
        
        if self.connector:
            self.connector.update_state(
                active_plugins=list(self._plugins.keys())
            )
    
    def unregister(self, name: str):
        """Unregister a plugin"""
        if name in self._plugins:
            self._plugins[name].on_unregister()
            del self._plugins[name]
            
            if self.connector:
                self.connector.update_state(
                    active_plugins=list(self._plugins.keys())
                )
    
    def get(self, name: str) -> Optional['AriaPlugin']:
        """Get a plugin by name"""
        return self._plugins.get(name)
    
    def list(self) -> List[str]:
        """List all registered plugins"""
        return list(self._plugins.keys())
    
    def notify_all(self, event: str, data: Any):
        """Notify all plugins of an event"""
        for plugin in self._plugins.values():
            try:
                plugin.on_event(event, data)
            except Exception:
                pass


class AriaPlugin:
    """
    Base class for ARIA plugins
    
    Plugins can extend both CLI and GUI functionality.
    """
    
    name: str = "base_plugin"
    version: str = "1.0.0"
    description: str = "Base ARIA plugin"
    
    def __init__(self):
        self._manager: Optional[PluginManager] = None
    
    def on_register(self, manager: PluginManager):
        """Called when plugin is registered"""
        self._manager = manager
    
    def on_unregister(self):
        """Called when plugin is unregistered"""
        self._manager = None
    
    def on_event(self, event: str, data: Any):
        """Handle events from the system"""
        pass
    
    def execute(self, command: str, args: Dict[str, Any]) -> Any:
        """Execute a plugin command"""
        raise NotImplementedError


# Example plugins

class MemoryPlugin(AriaPlugin):
    """Plugin for persistent memory across sessions"""
    
    name = "memory"
    version = "1.0.0"
    description = "Persistent memory storage"
    
    def __init__(self, storage_path: Optional[Path] = None):
        super().__init__()
        self.storage_path = storage_path or Path.home() / '.aria' / 'memory.json'
        self._memory: Dict[str, Any] = {}
        self._load()
    
    def _load(self):
        """Load memory from disk"""
        if self.storage_path.exists():
            try:
                with open(self.storage_path) as f:
                    self._memory = json.load(f)
            except Exception:
                pass
    
    def _save(self):
        """Save memory to disk"""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.storage_path, 'w') as f:
                json.dump(self._memory, f, indent=2)
        except Exception:
            pass
    
    def execute(self, command: str, args: Dict[str, Any]) -> Any:
        if command == "remember":
            key = args.get('key', str(time.time()))
            value = args.get('value')
            self._memory[key] = value
            self._save()
            return {'stored': key}
        
        elif command == "recall":
            key = args.get('key')
            if key:
                return {'value': self._memory.get(key)}
            return {'all': self._memory}
        
        elif command == "forget":
            key = args.get('key')
            if key and key in self._memory:
                del self._memory[key]
                self._save()
                return {'forgotten': key}
            return {'error': 'key not found'}
        
        return {'error': 'unknown command'}


class ShellPlugin(AriaPlugin):
    """Plugin for shell command execution"""
    
    name = "shell"
    version = "1.0.0"
    description = "Execute shell commands"
    
    def execute(self, command: str, args: Dict[str, Any]) -> Any:
        import subprocess
        
        if command == "run":
            cmd = args.get('command', '')
            if not cmd:
                return {'error': 'no command specified'}
            
            try:
                result = subprocess.run(
                    cmd,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                return {
                    'stdout': result.stdout,
                    'stderr': result.stderr,
                    'returncode': result.returncode,
                }
            except subprocess.TimeoutExpired:
                return {'error': 'command timed out'}
            except Exception as e:
                return {'error': str(e)}
        
        return {'error': 'unknown command'}
