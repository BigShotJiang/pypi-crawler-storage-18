"""
Termux Setup Helper for ARIA CLI

Automated setup scripts and helpers for connecting ARIA CLI 
to Android devices running Termux.

Features:
- SSH server setup on Termux
- Key-based authentication setup
- Device discovery on local network
- Meta AI folder access configuration
- Storage permission helpers
"""

import os
import socket
import subprocess
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass


@dataclass
class TermuxDevice:
    """Discovered Termux device"""
    hostname: str
    ip_address: str
    port: int = 8022
    username: str = "u0_a"
    storage_path: str = "/storage/emulated/0"
    termux_home: str = "/data/data/com.termux/files/home"
    detected_at: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "port": self.port,
            "username": self.username,
            "storage_path": self.storage_path,
            "termux_home": self.termux_home,
        }


class TermuxSetup:
    """
    Termux Setup Helper
    
    Helps configure ARIA CLI connection to Android Termux.
    
    Usage:
        setup = TermuxSetup()
        
        # Discover devices on network
        devices = setup.discover_devices()
        
        # Generate setup script for Termux
        script = setup.generate_termux_script()
        
        # Generate SSH config entry
        config = setup.generate_ssh_config("my-phone", "192.168.1.100")
        
        # Full setup wizard
        setup.wizard()
    """
    
    # Common Termux SSH port
    DEFAULT_PORT = 8022
    
    # Termux setup script template
    TERMUX_SETUP_SCRIPT = '''#!/data/data/com.termux/files/usr/bin/bash
# ARIA CLI Termux Setup Script
# Run this script inside Termux on your Android device

echo "=================================="
echo "   ARIA CLI - Termux Setup"
echo "=================================="
echo ""

# Update packages
echo "[1/6] Updating packages..."
pkg update -y && pkg upgrade -y

# Install SSH server
echo "[2/6] Installing OpenSSH..."
pkg install openssh -y

# Install useful tools
echo "[3/6] Installing utilities..."
pkg install python git wget curl rsync termux-api -y

# Setup storage access
echo "[4/6] Setting up storage access..."
termux-setup-storage

# Generate SSH keys if not exist
if [ ! -f ~/.ssh/id_rsa ]; then
    echo "[5/6] Generating SSH keys..."
    ssh-keygen -t rsa -b 4096 -N "" -f ~/.ssh/id_rsa
fi

# Start SSH server
echo "[6/6] Starting SSH server..."
sshd

# Get device info
IP_ADDR=$(ifconfig wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}')
if [ -z "$IP_ADDR" ]; then
    IP_ADDR=$(ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
fi
USERNAME=$(whoami)
PORT=8022

echo ""
echo "=================================="
echo "   Setup Complete!"
echo "=================================="
echo ""
echo "Connection Details:"
echo "  IP Address: $IP_ADDR"
echo "  Port: $PORT"
echo "  Username: $USERNAME"
echo ""
echo "To connect from your computer, run:"
echo "  aria ssh add termux-phone $IP_ADDR --port $PORT --user $USERNAME"
echo ""
echo "Then create an AriaSpace workspace:"
echo "  aria space create meta-ai termux-phone '/storage/emulated/0/Meta AI'"
echo ""
echo "SSH Server Status:"
ps aux | grep sshd | grep -v grep
echo ""
echo "Your public key (copy this to your computer's ~/.ssh/authorized_keys):"
cat ~/.ssh/id_rsa.pub
echo ""
'''

    TERMUX_META_AI_SCRIPT = '''#!/data/data/com.termux/files/usr/bin/bash
# Find and list Meta AI folder contents

META_AI_PATH="/storage/emulated/0/Meta AI"

if [ -d "$META_AI_PATH" ]; then
    echo "Meta AI folder found!"
    echo "Location: $META_AI_PATH"
    echo ""
    echo "Contents:"
    ls -la "$META_AI_PATH"
    echo ""
    echo "Total size:"
    du -sh "$META_AI_PATH"
else
    echo "Meta AI folder not found at: $META_AI_PATH"
    echo ""
    echo "Searching for Meta AI folder..."
    find /storage/emulated/0 -type d -name "*Meta*AI*" 2>/dev/null
fi
'''

    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize Termux setup helper"""
        self.config_dir = config_dir or Path.home() / ".aria" / "termux"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.devices_file = self.config_dir / "devices.json"
    
    def discover_devices(
        self,
        network_prefix: str = "192.168.1",
        port: int = DEFAULT_PORT,
        timeout: float = 0.5,
        scan_range: Tuple[int, int] = (1, 255),
    ) -> List[TermuxDevice]:
        """
        Discover Termux devices on local network
        
        Args:
            network_prefix: Network prefix (e.g., "192.168.1")
            port: SSH port to check (default 8022)
            timeout: Connection timeout
            scan_range: IP range to scan (start, end)
            
        Returns:
            List of discovered devices
        """
        devices = []
        start, end = scan_range
        
        print(f"🔍 Scanning network {network_prefix}.{start}-{end} for Termux devices...")
        
        for i in range(start, end + 1):
            ip = f"{network_prefix}.{i}"
            
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                result = sock.connect_ex((ip, port))
                sock.close()
                
                if result == 0:
                    # Port is open, likely Termux SSH
                    print(f"  ✓ Found device at {ip}:{port}")
                    
                    device = TermuxDevice(
                        hostname=f"termux-{i}",
                        ip_address=ip,
                        port=port,
                    )
                    devices.append(device)
            
            except Exception:
                pass
        
        # Save discovered devices
        if devices:
            self._save_devices(devices)
        
        print(f"\n📱 Found {len(devices)} device(s)")
        return devices
    
    def _save_devices(self, devices: List[TermuxDevice]):
        """Save discovered devices"""
        data = {
            "devices": [d.to_dict() for d in devices],
        }
        self.devices_file.write_text(json.dumps(data, indent=2))
    
    def _load_devices(self) -> List[TermuxDevice]:
        """Load previously discovered devices"""
        if not self.devices_file.exists():
            return []
        
        try:
            data = json.loads(self.devices_file.read_text())
            return [TermuxDevice(**d) for d in data.get("devices", [])]
        except Exception:
            return []
    
    def generate_termux_script(self) -> str:
        """Generate the Termux setup script"""
        return self.TERMUX_SETUP_SCRIPT
    
    def generate_meta_ai_script(self) -> str:
        """Generate the Meta AI finder script"""
        return self.TERMUX_META_AI_SCRIPT
    
    def save_termux_script(self, output_path: Optional[Path] = None) -> Path:
        """
        Save the Termux setup script to a file
        
        Args:
            output_path: Output file path
            
        Returns:
            Path to the saved script
        """
        if output_path is None:
            output_path = self.config_dir / "aria_termux_setup.sh"
        
        output_path.write_text(self.TERMUX_SETUP_SCRIPT)
        print(f"📝 Saved Termux setup script to: {output_path}")
        return output_path
    
    def generate_ssh_config(
        self,
        hostname: str,
        ip_address: str,
        port: int = DEFAULT_PORT,
        username: str = "u0_a",
        identity_file: Optional[str] = None,
    ) -> str:
        """
        Generate SSH config entry for Termux device
        
        Args:
            hostname: Alias for the device
            ip_address: Device IP address
            port: SSH port
            username: Termux username
            identity_file: Path to SSH key
            
        Returns:
            SSH config block
        """
        config = f"""
# ARIA CLI - Termux Device
Host {hostname}
    HostName {ip_address}
    Port {port}
    User {username}
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    ServerAliveInterval 60
    ServerAliveCountMax 3
"""
        if identity_file:
            config += f"    IdentityFile {identity_file}\n"
        
        return config
    
    def append_ssh_config(
        self,
        hostname: str,
        ip_address: str,
        port: int = DEFAULT_PORT,
        username: str = "u0_a",
    ) -> bool:
        """
        Append Termux device to ~/.ssh/config
        
        Args:
            hostname: Alias for the device
            ip_address: Device IP address
            port: SSH port
            username: Termux username
            
        Returns:
            True if successful
        """
        ssh_config = Path.home() / ".ssh" / "config"
        ssh_config.parent.mkdir(exist_ok=True)
        
        # Check if host already exists
        if ssh_config.exists():
            existing = ssh_config.read_text()
            if f"Host {hostname}" in existing:
                print(f"⚠️ Host '{hostname}' already exists in SSH config")
                return False
        
        # Append new config
        config_block = self.generate_ssh_config(hostname, ip_address, port, username)
        
        with open(ssh_config, "a") as f:
            f.write(config_block)
        
        print(f"✅ Added '{hostname}' to SSH config")
        return True
    
    def setup_key_auth(
        self,
        hostname: str,
        password: Optional[str] = None,
    ) -> bool:
        """
        Setup SSH key authentication with Termux device
        
        Args:
            hostname: SSH host name
            password: Termux password (if needed)
            
        Returns:
            True if successful
        """
        # Check for local SSH key
        ssh_key = Path.home() / ".ssh" / "id_rsa.pub"
        if not ssh_key.exists():
            # Generate key
            print("🔑 Generating SSH key pair...")
            subprocess.run([
                "ssh-keygen", "-t", "rsa", "-b", "4096",
                "-N", "", "-f", str(ssh_key.parent / "id_rsa")
            ], check=True)
        
        # Copy key to device
        print(f"📤 Copying SSH key to {hostname}...")
        
        try:
            result = subprocess.run([
                "ssh-copy-id",
                "-i", str(ssh_key),
                hostname
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ SSH key authentication setup complete")
                return True
            else:
                print(f"❌ Failed to copy key: {result.stderr}")
                return False
        
        except FileNotFoundError:
            print("⚠️ ssh-copy-id not found. Manual key copy required.")
            print(f"\nCopy this to Termux ~/.ssh/authorized_keys:")
            print(ssh_key.read_text())
            return False
    
    def test_connection(self, hostname: str) -> Tuple[bool, str]:
        """
        Test SSH connection to Termux device
        
        Args:
            hostname: SSH host name
            
        Returns:
            (success, message) tuple
        """
        try:
            result = subprocess.run(
                ["ssh", "-o", "ConnectTimeout=5", hostname, "echo 'ARIA Connected!'"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                return True, "Connection successful"
            else:
                return False, result.stderr.strip()
        
        except subprocess.TimeoutExpired:
            return False, "Connection timeout"
        except Exception as e:
            return False, str(e)
    
    def get_device_info(self, hostname: str) -> Dict[str, Any]:
        """
        Get information about connected Termux device
        
        Args:
            hostname: SSH host name
            
        Returns:
            Device information dictionary
        """
        info = {}
        
        commands = {
            "android_version": "getprop ro.build.version.release",
            "device_model": "getprop ro.product.model",
            "device_brand": "getprop ro.product.brand",
            "storage_info": "df -h /storage/emulated/0 | tail -1",
            "termux_version": "pkg show termux-tools 2>/dev/null | grep Version || echo 'unknown'",
            "ip_address": "ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1",
            "hostname": "hostname",
            "username": "whoami",
        }
        
        for key, cmd in commands.items():
            try:
                result = subprocess.run(
                    ["ssh", "-o", "ConnectTimeout=5", hostname, cmd],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    info[key] = result.stdout.strip()
            except Exception:
                pass
        
        return info
    
    def find_meta_ai_folder(self, hostname: str) -> Optional[str]:
        """
        Find Meta AI folder on device
        
        Args:
            hostname: SSH host name
            
        Returns:
            Path to Meta AI folder or None
        """
        # Common locations
        paths = [
            "/storage/emulated/0/Meta AI",
            "/storage/emulated/0/MetaAI",
            "/storage/emulated/0/meta-ai",
            "/sdcard/Meta AI",
        ]
        
        for path in paths:
            try:
                result = subprocess.run(
                    ["ssh", hostname, f'test -d "{path}" && echo "found"'],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.stdout.strip() == "found":
                    return path
            except Exception:
                pass
        
        # Search for it
        try:
            result = subprocess.run(
                ["ssh", hostname, 'find /storage/emulated/0 -type d -name "*Meta*AI*" 2>/dev/null | head -1'],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.stdout.strip():
                return result.stdout.strip()
        except Exception:
            pass
        
        return None
    
    def list_android_folders(self, hostname: str) -> List[Dict[str, Any]]:
        """
        List common Android folders
        
        Args:
            hostname: SSH host name
            
        Returns:
            List of folder info
        """
        folders = []
        
        paths = {
            "Downloads": "/storage/emulated/0/Download",
            "Documents": "/storage/emulated/0/Documents",
            "Pictures": "/storage/emulated/0/Pictures",
            "DCIM": "/storage/emulated/0/DCIM",
            "Movies": "/storage/emulated/0/Movies",
            "Music": "/storage/emulated/0/Music",
            "Meta AI": "/storage/emulated/0/Meta AI",
            "WhatsApp": "/storage/emulated/0/WhatsApp",
            "Termux Home": "/data/data/com.termux/files/home",
        }
        
        for name, path in paths.items():
            try:
                result = subprocess.run(
                    ["ssh", hostname, f'test -d "{path}" && du -sh "{path}" 2>/dev/null | cut -f1'],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0 and result.stdout.strip():
                    folders.append({
                        "name": name,
                        "path": path,
                        "size": result.stdout.strip(),
                        "exists": True,
                    })
                else:
                    folders.append({
                        "name": name,
                        "path": path,
                        "size": None,
                        "exists": False,
                    })
            except Exception:
                folders.append({
                    "name": name,
                    "path": path,
                    "size": None,
                    "exists": False,
                })
        
        return folders
    
    def wizard(self) -> Optional[TermuxDevice]:
        """
        Interactive setup wizard
        
        Returns:
            Configured TermuxDevice or None
        """
        print("=" * 50)
        print("   ARIA CLI - Termux Setup Wizard")
        print("=" * 50)
        print()
        print("This wizard will help you connect ARIA CLI to your")
        print("Android device running Termux.")
        print()
        
        # Step 1: Get network info
        print("[Step 1/5] Network Configuration")
        print("-" * 40)
        
        # Try to detect network prefix
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            network_prefix = ".".join(local_ip.split(".")[:3])
            print(f"Detected network: {network_prefix}.x")
        except Exception:
            network_prefix = input("Enter network prefix (e.g., 192.168.1): ").strip()
        
        print()
        
        # Step 2: Scan for devices
        print("[Step 2/5] Device Discovery")
        print("-" * 40)
        
        devices = self.discover_devices(network_prefix)
        
        if not devices:
            print()
            print("No devices found automatically.")
            print("Please enter your device IP manually:")
            ip = input("Device IP: ").strip()
            port = input(f"SSH Port [{self.DEFAULT_PORT}]: ").strip()
            port = int(port) if port else self.DEFAULT_PORT
            
            devices = [TermuxDevice(
                hostname="termux-phone",
                ip_address=ip,
                port=port,
            )]
        
        print()
        
        # Step 3: Select device
        print("[Step 3/5] Device Selection")
        print("-" * 40)
        
        if len(devices) == 1:
            device = devices[0]
            print(f"Using device: {device.ip_address}:{device.port}")
        else:
            for i, d in enumerate(devices, 1):
                print(f"  {i}. {d.ip_address}:{d.port}")
            
            choice = input("Select device (1): ").strip()
            idx = int(choice) - 1 if choice else 0
            device = devices[idx]
        
        print()
        
        # Step 4: Configure hostname
        print("[Step 4/5] SSH Configuration")
        print("-" * 40)
        
        hostname = input("SSH alias name [termux-phone]: ").strip() or "termux-phone"
        device.hostname = hostname
        
        # Add to SSH config
        self.append_ssh_config(
            hostname=device.hostname,
            ip_address=device.ip_address,
            port=device.port,
        )
        
        print()
        
        # Step 5: Test connection
        print("[Step 5/5] Connection Test")
        print("-" * 40)
        
        success, message = self.test_connection(device.hostname)
        
        if success:
            print("✅ Connection successful!")
            
            # Get device info
            info = self.get_device_info(device.hostname)
            if info:
                print(f"\nDevice: {info.get('device_brand', '')} {info.get('device_model', '')}")
                print(f"Android: {info.get('android_version', 'unknown')}")
            
            # Find Meta AI folder
            meta_ai_path = self.find_meta_ai_folder(device.hostname)
            if meta_ai_path:
                print(f"\n📁 Found Meta AI folder: {meta_ai_path}")
                device.storage_path = meta_ai_path
        else:
            print(f"❌ Connection failed: {message}")
            print()
            print("Troubleshooting:")
            print("1. Make sure Termux SSH server is running: sshd")
            print("2. Check firewall settings")
            print("3. Verify IP address and port")
            print()
            print("Run this in Termux to start SSH:")
            print("  pkg install openssh && sshd")
        
        print()
        print("=" * 50)
        print("Setup Complete!")
        print("=" * 50)
        print()
        print("Next steps:")
        print(f"  1. aria space create meta-ai {device.hostname} '/storage/emulated/0/Meta AI'")
        print(f"  2. aria space list")
        print(f"  3. aria space sync meta-ai")
        
        return device


def get_termux_setup() -> TermuxSetup:
    """Get the default TermuxSetup instance"""
    return TermuxSetup()
