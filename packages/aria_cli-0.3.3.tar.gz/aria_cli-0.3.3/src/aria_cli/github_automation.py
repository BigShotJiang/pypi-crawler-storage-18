"""
ARIA GitHub Automation Module v0.3.0

Integrates GitHub CLI (gh) with ARIA's:
- F1 Three-Phase Improvement Cycle (Analyze → Optimize → Validate)
- M1 Master Cycle (orchestrates all systems to completion)
- SSH Storage for persistent state
- Terminal execution automation

The F1 Quantum Cycle:
  Phase 1: ANALYZE  - Scan, assess, identify improvements
  Phase 2: OPTIMIZE - Apply changes, execute commands
  Phase 3: VALIDATE - Verify, test, confirm success

The M1 Master Cycle:
  Iterates through ALL files/folders/systems
  Each system goes through F1 cycle
  Continues until all systems complete successfully
"""

import asyncio
import subprocess
import json
import os
import time
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import shutil


# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================

class F1Phase(Enum):
    """F1 Three-Phase Improvement Cycle"""
    ANALYZE = "analyze"      # Phase 1: Scan, assess, identify
    OPTIMIZE = "optimize"    # Phase 2: Apply changes, execute
    VALIDATE = "validate"    # Phase 3: Verify, test, confirm


class CycleStatus(Enum):
    """Status of a cycle"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"


class SystemType(Enum):
    """Types of systems that can be cycled"""
    FILE = "file"
    FOLDER = "folder"
    REPO = "repository"
    BRANCH = "branch"
    ISSUE = "issue"
    PR = "pull_request"
    WORKFLOW = "workflow"
    RELEASE = "release"
    SECRET = "secret"
    CODESPACE = "codespace"


@dataclass
class F1CycleResult:
    """Result of a single F1 cycle"""
    system_id: str
    system_type: SystemType
    phase: F1Phase
    status: CycleStatus
    start_time: float
    end_time: float
    duration: float
    improvements: List[str] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)
    commands_executed: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def success(self) -> bool:
        return self.status in (CycleStatus.SUCCESS, CycleStatus.PARTIAL)


@dataclass
class M1MasterCycle:
    """Master cycle tracking all systems"""
    cycle_id: str
    start_time: float
    end_time: Optional[float] = None
    status: CycleStatus = CycleStatus.PENDING
    total_systems: int = 0
    completed_systems: int = 0
    f1_cycles: List[F1CycleResult] = field(default_factory=list)
    current_iteration: int = 0
    max_iterations: int = 10
    
    @property
    def progress(self) -> float:
        if self.total_systems == 0:
            return 0.0
        return (self.completed_systems / self.total_systems) * 100
    
    @property
    def all_complete(self) -> bool:
        return self.completed_systems >= self.total_systems


@dataclass
class GitHubResult:
    """Result from a GitHub CLI command"""
    success: bool
    command: str
    stdout: str
    stderr: str
    exit_code: int
    duration: float
    parsed_data: Optional[Any] = None


# =============================================================================
# GITHUB CLI WRAPPER
# =============================================================================

class GitHubCLI:
    """
    Wrapper for GitHub CLI (gh) commands
    Provides Pythonic interface to all gh operations
    """
    
    def __init__(self, working_dir: Optional[Path] = None):
        self.working_dir = working_dir or Path.cwd()
        self.gh_path = self._find_gh()
        self._command_history: List[GitHubResult] = []
    
    def _find_gh(self) -> str:
        """Find gh executable"""
        gh = shutil.which("gh")
        if gh:
            return gh
        # Common locations
        common_paths = [
            "/usr/bin/gh",
            "/usr/local/bin/gh",
            "C:\\Program Files\\GitHub CLI\\gh.exe",
            "C:\\Program Files (x86)\\GitHub CLI\\gh.exe",
            os.path.expanduser("~/.local/bin/gh"),
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path
        return "gh"  # Hope it's in PATH
    
    async def execute(
        self, 
        *args: str,
        capture_json: bool = False,
        timeout: int = 60
    ) -> GitHubResult:
        """Execute a gh command"""
        cmd = [self.gh_path] + list(args)
        if capture_json and "--json" not in args:
            # Add JSON output for commands that support it
            pass  # Not all commands support --json
        
        start = time.time()
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.working_dir
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout
            )
            
            duration = time.time() - start
            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")
            
            # Try to parse JSON if present
            parsed = None
            if capture_json:
                try:
                    parsed = json.loads(stdout_str)
                except json.JSONDecodeError:
                    pass
            
            result = GitHubResult(
                success=process.returncode == 0,
                command=" ".join(cmd),
                stdout=stdout_str,
                stderr=stderr_str,
                exit_code=process.returncode or 0,
                duration=duration,
                parsed_data=parsed
            )
            self._command_history.append(result)
            return result
            
        except asyncio.TimeoutError:
            duration = time.time() - start
            return GitHubResult(
                success=False,
                command=" ".join(cmd),
                stdout="",
                stderr=f"Command timed out after {timeout}s",
                exit_code=-1,
                duration=duration
            )
        except Exception as e:
            duration = time.time() - start
            return GitHubResult(
                success=False,
                command=" ".join(cmd),
                stdout="",
                stderr=str(e),
                exit_code=-1,
                duration=duration
            )
    
    # =========================================================================
    # AUTH COMMANDS
    # =========================================================================
    
    async def auth_status(self) -> GitHubResult:
        """Check authentication status"""
        return await self.execute("auth", "status", "--json", "git_protocol,token_hosts", capture_json=True)
    
    async def auth_login(self, web: bool = True) -> GitHubResult:
        """Login to GitHub"""
        args = ["auth", "login"]
        if web:
            args.append("--web")
        return await self.execute(*args)
    
    async def auth_token(self) -> GitHubResult:
        """Get auth token"""
        return await self.execute("auth", "token")
    
    # =========================================================================
    # REPO COMMANDS
    # =========================================================================
    
    async def repo_list(self, owner: Optional[str] = None, limit: int = 30) -> GitHubResult:
        """List repositories"""
        args = ["repo", "list", "--json", "name,owner,visibility,updatedAt,description"]
        if owner:
            args.insert(2, owner)
        args.extend(["--limit", str(limit)])
        return await self.execute(*args, capture_json=True)
    
    async def repo_view(self, repo: Optional[str] = None) -> GitHubResult:
        """View repository details"""
        args = ["repo", "view", "--json", "name,owner,description,url,defaultBranchRef,isPrivate"]
        if repo:
            args.insert(2, repo)
        return await self.execute(*args, capture_json=True)
    
    async def repo_clone(self, repo: str, directory: Optional[str] = None) -> GitHubResult:
        """Clone a repository"""
        args = ["repo", "clone", repo]
        if directory:
            args.append(directory)
        return await self.execute(*args)
    
    async def repo_create(
        self,
        name: str,
        public: bool = False,
        description: Optional[str] = None,
        clone: bool = True
    ) -> GitHubResult:
        """Create a new repository"""
        args = ["repo", "create", name]
        args.append("--public" if public else "--private")
        if description:
            args.extend(["--description", description])
        if clone:
            args.append("--clone")
        return await self.execute(*args)
    
    async def repo_sync(self, source: Optional[str] = None) -> GitHubResult:
        """Sync repository with upstream"""
        args = ["repo", "sync"]
        if source:
            args.extend(["--source", source])
        return await self.execute(*args)
    
    # =========================================================================
    # ISSUE COMMANDS
    # =========================================================================
    
    async def issue_list(
        self,
        state: str = "open",
        limit: int = 30,
        labels: Optional[List[str]] = None
    ) -> GitHubResult:
        """List issues"""
        args = ["issue", "list", "--state", state, "--limit", str(limit)]
        args.extend(["--json", "number,title,state,author,labels,createdAt"])
        if labels:
            args.extend(["--label", ",".join(labels)])
        return await self.execute(*args, capture_json=True)
    
    async def issue_create(
        self,
        title: str,
        body: Optional[str] = None,
        labels: Optional[List[str]] = None,
        assignees: Optional[List[str]] = None
    ) -> GitHubResult:
        """Create an issue"""
        args = ["issue", "create", "--title", title]
        if body:
            args.extend(["--body", body])
        if labels:
            args.extend(["--label", ",".join(labels)])
        if assignees:
            args.extend(["--assignee", ",".join(assignees)])
        return await self.execute(*args)
    
    async def issue_close(self, number: int, reason: str = "completed") -> GitHubResult:
        """Close an issue"""
        return await self.execute("issue", "close", str(number), "--reason", reason)
    
    async def issue_view(self, number: int) -> GitHubResult:
        """View issue details"""
        return await self.execute(
            "issue", "view", str(number),
            "--json", "number,title,body,state,author,labels,comments"
        )
    
    # =========================================================================
    # PR COMMANDS
    # =========================================================================
    
    async def pr_list(self, state: str = "open", limit: int = 30) -> GitHubResult:
        """List pull requests"""
        args = ["pr", "list", "--state", state, "--limit", str(limit)]
        args.extend(["--json", "number,title,state,author,headRefName,baseRefName,createdAt"])
        return await self.execute(*args, capture_json=True)
    
    async def pr_create(
        self,
        title: str,
        body: Optional[str] = None,
        base: str = "main",
        draft: bool = False,
        fill: bool = False
    ) -> GitHubResult:
        """Create a pull request"""
        args = ["pr", "create", "--title", title, "--base", base]
        if body:
            args.extend(["--body", body])
        if draft:
            args.append("--draft")
        if fill:
            args.append("--fill")
        return await self.execute(*args)
    
    async def pr_merge(
        self,
        number: Optional[int] = None,
        squash: bool = True,
        delete_branch: bool = True
    ) -> GitHubResult:
        """Merge a pull request"""
        args = ["pr", "merge"]
        if number:
            args.append(str(number))
        if squash:
            args.append("--squash")
        if delete_branch:
            args.append("--delete-branch")
        args.append("--auto")
        return await self.execute(*args)
    
    async def pr_checkout(self, number: int) -> GitHubResult:
        """Checkout a pull request"""
        return await self.execute("pr", "checkout", str(number))
    
    async def pr_checks(self, number: Optional[int] = None) -> GitHubResult:
        """View PR checks status"""
        args = ["pr", "checks"]
        if number:
            args.append(str(number))
        return await self.execute(*args)
    
    # =========================================================================
    # WORKFLOW COMMANDS
    # =========================================================================
    
    async def workflow_list(self) -> GitHubResult:
        """List workflows"""
        return await self.execute(
            "workflow", "list",
            "--json", "name,id,state,path"
        )
    
    async def workflow_run(
        self,
        workflow: str,
        ref: Optional[str] = None,
        fields: Optional[Dict[str, str]] = None
    ) -> GitHubResult:
        """Run a workflow"""
        args = ["workflow", "run", workflow]
        if ref:
            args.extend(["--ref", ref])
        if fields:
            for key, value in fields.items():
                args.extend(["-f", f"{key}={value}"])
        return await self.execute(*args)
    
    async def run_list(self, workflow: Optional[str] = None, limit: int = 20) -> GitHubResult:
        """List workflow runs"""
        args = ["run", "list", "--limit", str(limit)]
        if workflow:
            args.extend(["--workflow", workflow])
        args.extend(["--json", "databaseId,status,conclusion,workflowName,createdAt"])
        return await self.execute(*args, capture_json=True)
    
    async def run_view(self, run_id: int) -> GitHubResult:
        """View a workflow run"""
        return await self.execute(
            "run", "view", str(run_id),
            "--json", "status,conclusion,jobs,createdAt,updatedAt"
        )
    
    async def run_watch(self, run_id: int) -> GitHubResult:
        """Watch a workflow run"""
        return await self.execute("run", "watch", str(run_id))
    
    # =========================================================================
    # RELEASE COMMANDS
    # =========================================================================
    
    async def release_list(self, limit: int = 10) -> GitHubResult:
        """List releases"""
        return await self.execute(
            "release", "list", "--limit", str(limit),
            "--json", "tagName,name,isDraft,isPrerelease,publishedAt"
        )
    
    async def release_create(
        self,
        tag: str,
        title: Optional[str] = None,
        notes: Optional[str] = None,
        draft: bool = False,
        prerelease: bool = False,
        generate_notes: bool = True
    ) -> GitHubResult:
        """Create a release"""
        args = ["release", "create", tag]
        if title:
            args.extend(["--title", title])
        if notes:
            args.extend(["--notes", notes])
        elif generate_notes:
            args.append("--generate-notes")
        if draft:
            args.append("--draft")
        if prerelease:
            args.append("--prerelease")
        return await self.execute(*args)
    
    # =========================================================================
    # AGENT TASK COMMANDS (Copilot)
    # =========================================================================
    
    async def agent_task_create(
        self,
        description: str,
        base: Optional[str] = None,
        follow: bool = False
    ) -> GitHubResult:
        """Create a Copilot agent task"""
        args = ["agent-task", "create", description]
        if base:
            args.extend(["--base", base])
        if follow:
            args.append("--follow")
        return await self.execute(*args)
    
    async def agent_task_list(self, limit: int = 30) -> GitHubResult:
        """List agent tasks"""
        return await self.execute("agent-task", "list", "--limit", str(limit))
    
    async def agent_task_view(self, session_id: str, log: bool = False) -> GitHubResult:
        """View an agent task"""
        args = ["agent-task", "view", session_id]
        if log:
            args.append("--log")
        return await self.execute(*args)
    
    # =========================================================================
    # CODESPACE COMMANDS
    # =========================================================================
    
    async def codespace_list(self) -> GitHubResult:
        """List codespaces"""
        return await self.execute(
            "codespace", "list",
            "--json", "name,state,repository,gitStatus"
        )
    
    async def codespace_create(
        self,
        repo: Optional[str] = None,
        branch: Optional[str] = None,
        machine: str = "basicLinux32gb"
    ) -> GitHubResult:
        """Create a codespace"""
        args = ["codespace", "create", "--machine", machine]
        if repo:
            args.extend(["--repo", repo])
        if branch:
            args.extend(["--branch", branch])
        return await self.execute(*args)
    
    async def codespace_ssh(self, codespace_name: str) -> GitHubResult:
        """SSH into a codespace"""
        return await self.execute("codespace", "ssh", "--codespace", codespace_name)
    
    # =========================================================================
    # SECRET COMMANDS
    # =========================================================================
    
    async def secret_list(self) -> GitHubResult:
        """List secrets"""
        return await self.execute("secret", "list")
    
    async def secret_set(self, name: str, body: str) -> GitHubResult:
        """Set a secret"""
        # Use stdin for security
        process = await asyncio.create_subprocess_exec(
            self.gh_path, "secret", "set", name,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.working_dir
        )
        stdout, stderr = await process.communicate(input=body.encode())
        return GitHubResult(
            success=process.returncode == 0,
            command=f"gh secret set {name}",
            stdout=stdout.decode(),
            stderr=stderr.decode(),
            exit_code=process.returncode or 0,
            duration=0
        )
    
    # =========================================================================
    # CACHE COMMANDS
    # =========================================================================
    
    async def cache_list(self, limit: int = 30) -> GitHubResult:
        """List GitHub Actions caches"""
        return await self.execute(
            "cache", "list", "--limit", str(limit),
            "--json", "id,key,size_in_bytes,created_at,last_accessed_at"
        )
    
    async def cache_delete(self, cache_id: Optional[str] = None, all_caches: bool = False) -> GitHubResult:
        """Delete caches"""
        args = ["cache", "delete"]
        if all_caches:
            args.append("--all")
        elif cache_id:
            args.append(cache_id)
        return await self.execute(*args)
    
    # =========================================================================
    # SEARCH COMMANDS
    # =========================================================================
    
    async def search_code(self, query: str, limit: int = 30) -> GitHubResult:
        """Search code"""
        return await self.execute(
            "search", "code", query,
            "--limit", str(limit),
            "--json", "path,repository,textMatches"
        )
    
    async def search_repos(self, query: str, limit: int = 30) -> GitHubResult:
        """Search repositories"""
        return await self.execute(
            "search", "repos", query,
            "--limit", str(limit),
            "--json", "fullName,description,url,stargazersCount"
        )
    
    async def search_issues(self, query: str, limit: int = 30) -> GitHubResult:
        """Search issues"""
        return await self.execute(
            "search", "issues", query,
            "--limit", str(limit),
            "--json", "number,title,repository,state,url"
        )
    
    async def search_prs(self, query: str, limit: int = 30) -> GitHubResult:
        """Search pull requests"""
        return await self.execute(
            "search", "prs", query,
            "--limit", str(limit),
            "--json", "number,title,repository,state,url"
        )


# =============================================================================
# F1 THREE-PHASE CYCLE ENGINE
# =============================================================================

class F1CycleEngine:
    """
    F1 Three-Phase Improvement Cycle Engine
    
    Phase 1: ANALYZE  - Scan and assess current state
    Phase 2: OPTIMIZE - Apply improvements
    Phase 3: VALIDATE - Verify changes succeeded
    """
    
    def __init__(
        self,
        gh: GitHubCLI,
        storage: Optional[Any] = None,  # InfiniteStorage instance
        on_phase_complete: Optional[Callable] = None
    ):
        self.gh = gh
        self.storage = storage
        self.on_phase_complete = on_phase_complete
        self._cycle_history: List[F1CycleResult] = []
    
    async def execute_f1_cycle(
        self,
        system_id: str,
        system_type: SystemType,
        analyze_fn: Callable,
        optimize_fn: Callable,
        validate_fn: Callable
    ) -> F1CycleResult:
        """Execute a complete F1 cycle on a system"""
        start_time = time.time()
        improvements = []
        issues = []
        commands = []
        
        # Phase 1: ANALYZE
        phase1_result = await self._execute_phase(
            F1Phase.ANALYZE,
            analyze_fn,
            system_id
        )
        improvements.extend(phase1_result.get("improvements", []))
        issues.extend(phase1_result.get("issues", []))
        commands.extend(phase1_result.get("commands", []))
        
        if self.on_phase_complete:
            await self.on_phase_complete(F1Phase.ANALYZE, phase1_result)
        
        # Phase 2: OPTIMIZE
        phase2_result = await self._execute_phase(
            F1Phase.OPTIMIZE,
            optimize_fn,
            system_id,
            phase1_result
        )
        improvements.extend(phase2_result.get("improvements", []))
        issues.extend(phase2_result.get("issues", []))
        commands.extend(phase2_result.get("commands", []))
        
        if self.on_phase_complete:
            await self.on_phase_complete(F1Phase.OPTIMIZE, phase2_result)
        
        # Phase 3: VALIDATE
        phase3_result = await self._execute_phase(
            F1Phase.VALIDATE,
            validate_fn,
            system_id,
            phase2_result
        )
        improvements.extend(phase3_result.get("improvements", []))
        issues.extend(phase3_result.get("issues", []))
        commands.extend(phase3_result.get("commands", []))
        
        if self.on_phase_complete:
            await self.on_phase_complete(F1Phase.VALIDATE, phase3_result)
        
        # Determine overall status
        end_time = time.time()
        status = CycleStatus.SUCCESS
        if issues:
            status = CycleStatus.PARTIAL if improvements else CycleStatus.FAILED
        
        result = F1CycleResult(
            system_id=system_id,
            system_type=system_type,
            phase=F1Phase.VALIDATE,  # Completed all phases
            status=status,
            start_time=start_time,
            end_time=end_time,
            duration=end_time - start_time,
            improvements=improvements,
            issues=issues,
            commands_executed=commands,
            metrics={
                "phase1": phase1_result,
                "phase2": phase2_result,
                "phase3": phase3_result
            }
        )
        
        self._cycle_history.append(result)
        
        # Store in infinite storage if available
        if self.storage:
            try:
                await self.storage.store(
                    f"f1:cycle:{system_id}:{int(start_time)}",
                    json.dumps({
                        "system_id": system_id,
                        "system_type": system_type.value,
                        "status": status.value,
                        "duration": result.duration,
                        "improvements": improvements,
                        "issues": issues
                    })
                )
            except Exception:
                pass  # Storage failure shouldn't fail the cycle
        
        return result
    
    async def _execute_phase(
        self,
        phase: F1Phase,
        phase_fn: Callable,
        system_id: str,
        previous_result: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Execute a single phase"""
        try:
            if asyncio.iscoroutinefunction(phase_fn):
                return await phase_fn(system_id, previous_result)
            else:
                return phase_fn(system_id, previous_result)
        except Exception as e:
            return {
                "success": False,
                "issues": [str(e)],
                "improvements": [],
                "commands": []
            }


# =============================================================================
# M1 MASTER CYCLE ORCHESTRATOR
# =============================================================================

class M1MasterOrchestrator:
    """
    M1 Master Cycle Orchestrator
    
    Iterates through ALL systems (files, folders, repos, etc.)
    Each system goes through F1 cycle
    Continues until all systems complete successfully
    """
    
    def __init__(
        self,
        gh: GitHubCLI,
        f1_engine: F1CycleEngine,
        storage: Optional[Any] = None,
        max_iterations: int = 10,
        on_cycle_complete: Optional[Callable] = None,
        on_system_complete: Optional[Callable] = None
    ):
        self.gh = gh
        self.f1_engine = f1_engine
        self.storage = storage
        self.max_iterations = max_iterations
        self.on_cycle_complete = on_cycle_complete
        self.on_system_complete = on_system_complete
        self._master_cycles: List[M1MasterCycle] = []
    
    async def run_master_cycle(
        self,
        systems: List[Tuple[str, SystemType]],
        cycle_handlers: Dict[SystemType, Dict[str, Callable]]
    ) -> M1MasterCycle:
        """
        Run a complete M1 master cycle
        
        Args:
            systems: List of (system_id, system_type) tuples
            cycle_handlers: Dict mapping SystemType to {analyze, optimize, validate} functions
        
        Returns:
            M1MasterCycle with results
        """
        master = M1MasterCycle(
            cycle_id=f"m1-{int(time.time())}",
            start_time=time.time(),
            status=CycleStatus.IN_PROGRESS,
            total_systems=len(systems),
            max_iterations=self.max_iterations
        )
        self._master_cycles.append(master)
        
        # Track which systems are complete
        completed = set()
        iteration = 0
        
        while not master.all_complete and iteration < self.max_iterations:
            iteration += 1
            master.current_iteration = iteration
            
            for system_id, system_type in systems:
                if system_id in completed:
                    continue
                
                # Get handlers for this system type
                handlers = cycle_handlers.get(system_type, {})
                if not all(k in handlers for k in ["analyze", "optimize", "validate"]):
                    # Skip systems without proper handlers
                    completed.add(system_id)
                    master.completed_systems += 1
                    continue
                
                # Execute F1 cycle
                result = await self.f1_engine.execute_f1_cycle(
                    system_id=system_id,
                    system_type=system_type,
                    analyze_fn=handlers["analyze"],
                    optimize_fn=handlers["optimize"],
                    validate_fn=handlers["validate"]
                )
                
                master.f1_cycles.append(result)
                
                if result.success:
                    completed.add(system_id)
                    master.completed_systems += 1
                    if self.on_system_complete:
                        await self.on_system_complete(system_id, result)
            
            if self.on_cycle_complete:
                await self.on_cycle_complete(master, iteration)
        
        # Finalize
        master.end_time = time.time()
        master.status = (
            CycleStatus.SUCCESS if master.all_complete
            else CycleStatus.PARTIAL if master.completed_systems > 0
            else CycleStatus.FAILED
        )
        
        # Store master cycle results
        if self.storage:
            try:
                await self.storage.store(
                    f"m1:master:{master.cycle_id}",
                    json.dumps({
                        "cycle_id": master.cycle_id,
                        "status": master.status.value,
                        "total_systems": master.total_systems,
                        "completed_systems": master.completed_systems,
                        "iterations": master.current_iteration,
                        "duration": master.end_time - master.start_time
                    })
                )
            except Exception:
                pass
        
        return master
    
    async def scan_workspace(
        self,
        workspace_path: Path,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None
    ) -> List[Tuple[str, SystemType]]:
        """Scan workspace and return list of systems to process"""
        systems = []
        exclude = exclude_patterns or [
            ".git", "__pycache__", "node_modules", ".venv",
            "venv", "dist", "build", ".eggs", "*.egg-info"
        ]
        include = include_patterns or ["*"]
        
        def should_exclude(path: Path) -> bool:
            for pattern in exclude:
                if path.match(pattern) or pattern in str(path):
                    return True
            return False
        
        # Scan directories
        for item in workspace_path.iterdir():
            if should_exclude(item):
                continue
            
            if item.is_dir():
                systems.append((str(item), SystemType.FOLDER))
                # Recursively scan subdirectories
                for subitem in item.rglob("*"):
                    if should_exclude(subitem):
                        continue
                    if subitem.is_file():
                        systems.append((str(subitem), SystemType.FILE))
                    elif subitem.is_dir():
                        systems.append((str(subitem), SystemType.FOLDER))
            else:
                systems.append((str(item), SystemType.FILE))
        
        return systems
    
    async def scan_github_systems(self, repo: Optional[str] = None) -> List[Tuple[str, SystemType]]:
        """Scan GitHub for systems to process"""
        systems = []
        
        # Get issues
        issues = await self.gh.issue_list(limit=100)
        if issues.success and issues.parsed_data:
            for issue in issues.parsed_data:
                systems.append((f"issue:{issue['number']}", SystemType.ISSUE))
        
        # Get PRs
        prs = await self.gh.pr_list(limit=100)
        if prs.success and prs.parsed_data:
            for pr in prs.parsed_data:
                systems.append((f"pr:{pr['number']}", SystemType.PR))
        
        # Get workflows
        workflows = await self.gh.workflow_list()
        if workflows.success and workflows.parsed_data:
            for wf in workflows.parsed_data:
                systems.append((f"workflow:{wf['id']}", SystemType.WORKFLOW))
        
        return systems


# =============================================================================
# GITHUB AUTOMATION MANAGER
# =============================================================================

class GitHubAutomation:
    """
    Main GitHub Automation Manager
    Combines F1 cycles, M1 master orchestration, and SSH storage
    """
    
    def __init__(
        self,
        working_dir: Optional[Path] = None,
        storage: Optional[Any] = None
    ):
        self.working_dir = working_dir or Path.cwd()
        self.storage = storage
        self.gh = GitHubCLI(working_dir=self.working_dir)
        self.f1_engine = F1CycleEngine(gh=self.gh, storage=storage)
        self.m1_orchestrator = M1MasterOrchestrator(
            gh=self.gh,
            f1_engine=self.f1_engine,
            storage=storage
        )
        
        # Default handlers for each system type
        self._handlers: Dict[SystemType, Dict[str, Callable]] = {
            SystemType.FILE: {
                "analyze": self._analyze_file,
                "optimize": self._optimize_file,
                "validate": self._validate_file
            },
            SystemType.FOLDER: {
                "analyze": self._analyze_folder,
                "optimize": self._optimize_folder,
                "validate": self._validate_folder
            },
            SystemType.ISSUE: {
                "analyze": self._analyze_issue,
                "optimize": self._optimize_issue,
                "validate": self._validate_issue
            },
            SystemType.PR: {
                "analyze": self._analyze_pr,
                "optimize": self._optimize_pr,
                "validate": self._validate_pr
            },
            SystemType.WORKFLOW: {
                "analyze": self._analyze_workflow,
                "optimize": self._optimize_workflow,
                "validate": self._validate_workflow
            }
        }
    
    # =========================================================================
    # FILE HANDLERS
    # =========================================================================
    
    async def _analyze_file(self, system_id: str, _prev: Optional[Dict]) -> Dict:
        """Analyze a file"""
        path = Path(system_id)
        improvements = []
        issues = []
        
        if not path.exists():
            issues.append(f"File not found: {system_id}")
            return {"success": False, "issues": issues, "improvements": [], "commands": []}
        
        # Get file stats
        stat = path.stat()
        size = stat.st_size
        
        # Check for improvements
        if size == 0:
            issues.append("Empty file")
        if size > 1_000_000:
            improvements.append("Consider splitting large file")
        
        # Check for common issues based on extension
        ext = path.suffix.lower()
        if ext == ".py":
            content = path.read_text(errors="replace")
            if "TODO" in content or "FIXME" in content:
                improvements.append("Has TODO/FIXME comments to address")
            if "print(" in content and "__name__" not in content:
                improvements.append("Consider using logging instead of print")
        
        return {
            "success": True,
            "improvements": improvements,
            "issues": issues,
            "commands": [],
            "size": size,
            "extension": ext
        }
    
    async def _optimize_file(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Optimize a file"""
        path = Path(system_id)
        improvements = []
        commands = []
        
        if not path.exists():
            return {"success": False, "issues": ["File not found"], "improvements": [], "commands": []}
        
        ext = path.suffix.lower()
        
        # Auto-format Python files
        if ext == ".py":
            try:
                result = subprocess.run(
                    ["python", "-m", "black", "--check", str(path)],
                    capture_output=True,
                    text=True
                )
                if result.returncode != 0:
                    # Would reformat - but just note it
                    improvements.append("File can be formatted with Black")
                    commands.append(f"black {path}")
            except Exception:
                pass
        
        return {
            "success": True,
            "improvements": improvements,
            "issues": [],
            "commands": commands
        }
    
    async def _validate_file(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Validate a file"""
        path = Path(system_id)
        issues = []
        
        if not path.exists():
            issues.append("File not found")
            return {"success": False, "issues": issues, "improvements": [], "commands": []}
        
        # Validate based on extension
        ext = path.suffix.lower()
        if ext == ".py":
            try:
                result = subprocess.run(
                    ["python", "-m", "py_compile", str(path)],
                    capture_output=True,
                    text=True
                )
                if result.returncode != 0:
                    issues.append(f"Syntax error: {result.stderr}")
            except Exception:
                pass
        elif ext == ".json":
            try:
                json.loads(path.read_text())
            except json.JSONDecodeError as e:
                issues.append(f"Invalid JSON: {e}")
        
        return {
            "success": len(issues) == 0,
            "improvements": [],
            "issues": issues,
            "commands": []
        }
    
    # =========================================================================
    # FOLDER HANDLERS
    # =========================================================================
    
    async def _analyze_folder(self, system_id: str, _prev: Optional[Dict]) -> Dict:
        """Analyze a folder"""
        path = Path(system_id)
        improvements = []
        issues = []
        
        if not path.exists():
            issues.append(f"Folder not found: {system_id}")
            return {"success": False, "issues": issues, "improvements": [], "commands": []}
        
        # Count contents
        files = list(path.glob("*"))
        file_count = len([f for f in files if f.is_file()])
        folder_count = len([f for f in files if f.is_dir()])
        
        if file_count > 50:
            improvements.append("Consider organizing into subfolders")
        
        # Check for README
        if not any(f.name.lower().startswith("readme") for f in files):
            improvements.append("Add a README file")
        
        return {
            "success": True,
            "improvements": improvements,
            "issues": issues,
            "commands": [],
            "file_count": file_count,
            "folder_count": folder_count
        }
    
    async def _optimize_folder(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Optimize a folder"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    async def _validate_folder(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Validate a folder"""
        path = Path(system_id)
        return {
            "success": path.exists() and path.is_dir(),
            "improvements": [],
            "issues": [] if path.exists() else ["Folder not found"],
            "commands": []
        }
    
    # =========================================================================
    # ISSUE HANDLERS
    # =========================================================================
    
    async def _analyze_issue(self, system_id: str, _prev: Optional[Dict]) -> Dict:
        """Analyze a GitHub issue"""
        issue_num = int(system_id.split(":")[1])
        result = await self.gh.issue_view(issue_num)
        
        if not result.success:
            return {"success": False, "issues": [result.stderr], "improvements": [], "commands": []}
        
        improvements = []
        data = result.parsed_data or {}
        
        # Check for labels
        if not data.get("labels"):
            improvements.append("Add labels for better organization")
        
        # Check for assignees
        if not data.get("assignees"):
            improvements.append("Assign to a team member")
        
        return {
            "success": True,
            "improvements": improvements,
            "issues": [],
            "commands": [],
            "data": data
        }
    
    async def _optimize_issue(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Optimize a GitHub issue (apply labels, etc.)"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    async def _validate_issue(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Validate an issue state"""
        issue_num = int(system_id.split(":")[1])
        result = await self.gh.issue_view(issue_num)
        return {
            "success": result.success,
            "improvements": [],
            "issues": [result.stderr] if not result.success else [],
            "commands": []
        }
    
    # =========================================================================
    # PR HANDLERS
    # =========================================================================
    
    async def _analyze_pr(self, system_id: str, _prev: Optional[Dict]) -> Dict:
        """Analyze a pull request"""
        pr_num = int(system_id.split(":")[1])
        checks = await self.gh.pr_checks(pr_num)
        
        improvements = []
        issues = []
        
        if "failing" in checks.stdout.lower():
            issues.append("PR has failing checks")
        
        if "pending" in checks.stdout.lower():
            improvements.append("Wait for pending checks to complete")
        
        return {
            "success": True,
            "improvements": improvements,
            "issues": issues,
            "commands": [],
            "checks": checks.stdout
        }
    
    async def _optimize_pr(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Optimize a PR (request reviews, etc.)"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    async def _validate_pr(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Validate a PR is ready to merge"""
        pr_num = int(system_id.split(":")[1])
        checks = await self.gh.pr_checks(pr_num)
        
        success = "pass" in checks.stdout.lower() or "success" in checks.stdout.lower()
        return {
            "success": success,
            "improvements": [],
            "issues": [] if success else ["PR checks not passing"],
            "commands": []
        }
    
    # =========================================================================
    # WORKFLOW HANDLERS
    # =========================================================================
    
    async def _analyze_workflow(self, system_id: str, _prev: Optional[Dict]) -> Dict:
        """Analyze a workflow"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    async def _optimize_workflow(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Optimize a workflow"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    async def _validate_workflow(self, system_id: str, prev: Optional[Dict]) -> Dict:
        """Validate a workflow"""
        return {"success": True, "improvements": [], "issues": [], "commands": []}
    
    # =========================================================================
    # PUBLIC API
    # =========================================================================
    
    async def run_full_cycle(
        self,
        include_workspace: bool = True,
        include_github: bool = True,
        workspace_path: Optional[Path] = None
    ) -> M1MasterCycle:
        """Run a complete M1 master cycle on all systems"""
        systems = []
        
        if include_workspace:
            ws_path = workspace_path or self.working_dir
            ws_systems = await self.m1_orchestrator.scan_workspace(ws_path)
            systems.extend(ws_systems)
        
        if include_github:
            gh_systems = await self.m1_orchestrator.scan_github_systems()
            systems.extend(gh_systems)
        
        return await self.m1_orchestrator.run_master_cycle(
            systems=systems,
            cycle_handlers=self._handlers
        )
    
    async def run_f1_on_file(self, file_path: str) -> F1CycleResult:
        """Run F1 cycle on a single file"""
        return await self.f1_engine.execute_f1_cycle(
            system_id=file_path,
            system_type=SystemType.FILE,
            analyze_fn=self._analyze_file,
            optimize_fn=self._optimize_file,
            validate_fn=self._validate_file
        )
    
    async def run_f1_on_issue(self, issue_number: int) -> F1CycleResult:
        """Run F1 cycle on a GitHub issue"""
        return await self.f1_engine.execute_f1_cycle(
            system_id=f"issue:{issue_number}",
            system_type=SystemType.ISSUE,
            analyze_fn=self._analyze_issue,
            optimize_fn=self._optimize_issue,
            validate_fn=self._validate_issue
        )
    
    async def run_f1_on_pr(self, pr_number: int) -> F1CycleResult:
        """Run F1 cycle on a pull request"""
        return await self.f1_engine.execute_f1_cycle(
            system_id=f"pr:{pr_number}",
            system_type=SystemType.PR,
            analyze_fn=self._analyze_pr,
            optimize_fn=self._optimize_pr,
            validate_fn=self._validate_pr
        )


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_github_cli(working_dir: Optional[Path] = None) -> GitHubCLI:
    """Get a GitHubCLI instance"""
    return GitHubCLI(working_dir=working_dir)


def get_github_automation(
    working_dir: Optional[Path] = None,
    storage: Optional[Any] = None
) -> GitHubAutomation:
    """Get a GitHubAutomation instance"""
    return GitHubAutomation(working_dir=working_dir, storage=storage)


async def quick_status() -> Dict[str, Any]:
    """Quick status check of GitHub authentication and current repo"""
    gh = GitHubCLI()
    
    auth = await gh.auth_status()
    repo = await gh.repo_view()
    
    return {
        "authenticated": auth.success,
        "repo": repo.parsed_data if repo.success else None,
        "gh_available": bool(gh.gh_path)
    }
