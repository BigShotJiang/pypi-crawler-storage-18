"""
LLM Connector Module for ARIA CLI v0.2.0

Provides unified interface to multiple LLM backends:
- OpenAI (GPT-4, GPT-3.5)
- Anthropic (Claude)
- Local models (llama.cpp, transformers)
- Custom API endpoints

Usage:
    from aria_cli import LLMConnector, LLMProvider
    
    # OpenAI
    llm = LLMConnector(LLMProvider.OPENAI, api_key="sk-...")
    
    # Anthropic
    llm = LLMConnector(LLMProvider.ANTHROPIC, api_key="sk-ant-...")
    
    # Local model
    llm = LLMConnector(LLMProvider.LOCAL, model_path="/path/to/model.gguf")
    
    response = llm.generate("What is quantum computing?")
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Union, Generator
from pathlib import Path
import json
import os


class LLMProvider(Enum):
    """Supported LLM providers"""
    OPENAI = auto()
    ANTHROPIC = auto()
    LOCAL = auto()           # Local llama.cpp or transformers
    OLLAMA = auto()          # Ollama local server
    AZURE_OPENAI = auto()
    CUSTOM = auto()          # Custom API endpoint


@dataclass
class LLMConfig:
    """Configuration for LLM connection"""
    provider: LLMProvider
    model: str = ""
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2048
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    system_prompt: str = "You are ARIA, a helpful AI assistant powered by the Q-System cognitive architecture."
    timeout: float = 60.0
    extra: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_env(cls, provider: LLMProvider) -> 'LLMConfig':
        """Create config from environment variables"""
        config = cls(provider=provider)
        
        if provider == LLMProvider.OPENAI:
            config.api_key = os.getenv("OPENAI_API_KEY")
            config.model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            config.api_base = os.getenv("OPENAI_API_BASE")
            
        elif provider == LLMProvider.ANTHROPIC:
            config.api_key = os.getenv("ANTHROPIC_API_KEY")
            config.model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
            
        elif provider == LLMProvider.AZURE_OPENAI:
            config.api_key = os.getenv("AZURE_OPENAI_API_KEY")
            config.api_base = os.getenv("AZURE_OPENAI_ENDPOINT")
            config.model = os.getenv("AZURE_OPENAI_DEPLOYMENT")
            
        elif provider == LLMProvider.OLLAMA:
            config.api_base = os.getenv("OLLAMA_HOST", "http://localhost:11434")
            config.model = os.getenv("OLLAMA_MODEL", "llama3.2")
            
        elif provider == LLMProvider.LOCAL:
            config.model = os.getenv("LOCAL_MODEL_PATH", "")
            
        return config
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider.name,
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "api_base": self.api_base,
            "has_api_key": self.api_key is not None,
        }


@dataclass
class LLMResponse:
    """Response from LLM"""
    content: str
    model: str
    provider: str
    usage: Dict[str, int] = field(default_factory=dict)
    finish_reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __str__(self) -> str:
        return self.content


class LLMConnector:
    """
    Unified LLM Connector for ARIA CLI
    
    Provides a consistent interface across multiple LLM providers,
    handling authentication, rate limiting, and response parsing.
    """
    
    def __init__(
        self,
        provider: Union[LLMProvider, str] = LLMProvider.OPENAI,
        config: Optional[LLMConfig] = None,
        **kwargs
    ):
        if isinstance(provider, str):
            provider = LLMProvider[provider.upper()]
        
        self.provider = provider
        self.config = config or LLMConfig.from_env(provider)
        
        # Override config with kwargs
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        
        # Initialize provider client
        self._client = None
        self._init_client()
    
    def _init_client(self):
        """Initialize the provider client"""
        try:
            if self.provider == LLMProvider.OPENAI:
                self._init_openai()
            elif self.provider == LLMProvider.ANTHROPIC:
                self._init_anthropic()
            elif self.provider == LLMProvider.OLLAMA:
                self._init_ollama()
            elif self.provider == LLMProvider.LOCAL:
                self._init_local()
            elif self.provider == LLMProvider.AZURE_OPENAI:
                self._init_azure()
        except ImportError as e:
            # Dependencies not installed
            self._client = None
            self._import_error = str(e)
    
    def _init_openai(self):
        """Initialize OpenAI client"""
        try:
            from openai import OpenAI
            self._client = OpenAI(
                api_key=self.config.api_key,
                base_url=self.config.api_base,
                timeout=self.config.timeout,
            )
        except ImportError:
            raise ImportError("OpenAI not installed. Run: pip install aria-cli[llm]")
    
    def _init_anthropic(self):
        """Initialize Anthropic client"""
        try:
            from anthropic import Anthropic
            self._client = Anthropic(
                api_key=self.config.api_key,
                timeout=self.config.timeout,
            )
        except ImportError:
            raise ImportError("Anthropic not installed. Run: pip install aria-cli[llm]")
    
    def _init_ollama(self):
        """Initialize Ollama client"""
        try:
            import httpx
            self._client = httpx.Client(
                base_url=self.config.api_base,
                timeout=self.config.timeout,
            )
        except ImportError:
            raise ImportError("httpx not installed. Run: pip install httpx")
    
    def _init_local(self):
        """Initialize local model"""
        model_path = self.config.model or self.config.extra.get("model_path")
        
        if not model_path:
            self._client = None
            return
        
        # Try llama-cpp-python first
        try:
            from llama_cpp import Llama
            self._client = Llama(
                model_path=str(model_path),
                n_ctx=self.config.max_tokens * 2,
                n_threads=os.cpu_count() or 4,
            )
            self._local_backend = "llama_cpp"
            return
        except ImportError:
            pass
        
        # Try transformers
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(model_path)
            self._client = AutoModelForCausalLM.from_pretrained(model_path)
            self._local_backend = "transformers"
            return
        except ImportError:
            pass
        
        raise ImportError("No local model backend available. Run: pip install aria-cli[local]")
    
    def _init_azure(self):
        """Initialize Azure OpenAI client"""
        try:
            from openai import AzureOpenAI
            self._client = AzureOpenAI(
                api_key=self.config.api_key,
                azure_endpoint=self.config.api_base,
                api_version=self.config.extra.get("api_version", "2024-02-15-preview"),
                timeout=self.config.timeout,
            )
        except ImportError:
            raise ImportError("OpenAI not installed. Run: pip install aria-cli[llm]")
    
    @property
    def is_available(self) -> bool:
        """Check if the LLM is available"""
        return self._client is not None
    
    @property
    def model_name(self) -> str:
        """Get the model name"""
        return self.config.model or self.provider.name
    
    def generate(
        self,
        prompt: str,
        options: Optional[Dict[str, Any]] = None,
        system: Optional[str] = None,
    ) -> str:
        """
        Generate a response from the LLM
        
        Args:
            prompt: The user prompt
            options: Override generation options
            system: Override system prompt
            
        Returns:
            Generated text response
        """
        response = self.generate_full(prompt, options, system)
        return response.content
    
    def generate_full(
        self,
        prompt: str,
        options: Optional[Dict[str, Any]] = None,
        system: Optional[str] = None,
    ) -> LLMResponse:
        """
        Generate a full response with metadata
        
        Args:
            prompt: The user prompt
            options: Override generation options
            system: Override system prompt
            
        Returns:
            LLMResponse with content and metadata
        """
        if not self.is_available:
            return LLMResponse(
                content=f"LLM not available. Error: {getattr(self, '_import_error', 'Client not initialized')}",
                model="none",
                provider=self.provider.name,
            )
        
        options = options or {}
        system = system or self.config.system_prompt
        
        if self.provider == LLMProvider.OPENAI or self.provider == LLMProvider.AZURE_OPENAI:
            return self._generate_openai(prompt, system, options)
        elif self.provider == LLMProvider.ANTHROPIC:
            return self._generate_anthropic(prompt, system, options)
        elif self.provider == LLMProvider.OLLAMA:
            return self._generate_ollama(prompt, system, options)
        elif self.provider == LLMProvider.LOCAL:
            return self._generate_local(prompt, system, options)
        else:
            return LLMResponse(
                content=f"Provider {self.provider.name} not implemented",
                model="none",
                provider=self.provider.name,
            )
    
    def _generate_openai(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> LLMResponse:
        """Generate using OpenAI API"""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        
        response = self._client.chat.completions.create(
            model=self.config.model or "gpt-4o-mini",
            messages=messages,
            temperature=options.get("temperature", self.config.temperature),
            max_tokens=options.get("max_tokens", self.config.max_tokens),
            top_p=options.get("top_p", self.config.top_p),
        )
        
        choice = response.choices[0]
        return LLMResponse(
            content=choice.message.content or "",
            model=response.model,
            provider="openai",
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            },
            finish_reason=choice.finish_reason or "",
        )
    
    def _generate_anthropic(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> LLMResponse:
        """Generate using Anthropic API"""
        response = self._client.messages.create(
            model=self.config.model or "claude-3-5-sonnet-20241022",
            system=system,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=options.get("max_tokens", self.config.max_tokens),
            temperature=options.get("temperature", self.config.temperature),
        )
        
        content = response.content[0].text if response.content else ""
        return LLMResponse(
            content=content,
            model=response.model,
            provider="anthropic",
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
            finish_reason=response.stop_reason or "",
        )
    
    def _generate_ollama(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> LLMResponse:
        """Generate using Ollama local server"""
        response = self._client.post(
            "/api/generate",
            json={
                "model": self.config.model or "llama3.2",
                "prompt": prompt,
                "system": system,
                "stream": False,
                "options": {
                    "temperature": options.get("temperature", self.config.temperature),
                    "num_predict": options.get("max_tokens", self.config.max_tokens),
                }
            }
        )
        
        data = response.json()
        return LLMResponse(
            content=data.get("response", ""),
            model=data.get("model", self.config.model),
            provider="ollama",
            metadata={
                "total_duration": data.get("total_duration"),
                "eval_count": data.get("eval_count"),
            }
        )
    
    def _generate_local(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> LLMResponse:
        """Generate using local model"""
        full_prompt = f"{system}\n\nUser: {prompt}\n\nAssistant:"
        
        if self._local_backend == "llama_cpp":
            output = self._client(
                full_prompt,
                max_tokens=options.get("max_tokens", self.config.max_tokens),
                temperature=options.get("temperature", self.config.temperature),
                stop=["User:", "\n\n"],
            )
            content = output["choices"][0]["text"]
            return LLMResponse(
                content=content.strip(),
                model=self.config.model,
                provider="llama_cpp",
                usage={"tokens": output.get("usage", {}).get("total_tokens", 0)},
            )
        
        elif self._local_backend == "transformers":
            inputs = self._tokenizer(full_prompt, return_tensors="pt")
            outputs = self._client.generate(
                **inputs,
                max_new_tokens=options.get("max_tokens", self.config.max_tokens),
                temperature=options.get("temperature", self.config.temperature),
                do_sample=True,
            )
            content = self._tokenizer.decode(outputs[0], skip_special_tokens=True)
            # Remove the prompt from the output
            content = content[len(full_prompt):].strip()
            return LLMResponse(
                content=content,
                model=self.config.model,
                provider="transformers",
            )
        
        return LLMResponse(
            content="Local backend not initialized",
            model="none",
            provider="local",
        )
    
    def stream(
        self,
        prompt: str,
        options: Optional[Dict[str, Any]] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """
        Stream responses from the LLM
        
        Args:
            prompt: The user prompt
            options: Override generation options
            system: Override system prompt
            
        Yields:
            Streamed text chunks
        """
        if not self.is_available:
            yield f"LLM not available"
            return
        
        options = options or {}
        system = system or self.config.system_prompt
        
        if self.provider == LLMProvider.OPENAI or self.provider == LLMProvider.AZURE_OPENAI:
            yield from self._stream_openai(prompt, system, options)
        elif self.provider == LLMProvider.ANTHROPIC:
            yield from self._stream_anthropic(prompt, system, options)
        else:
            # Fallback to non-streaming
            yield self.generate(prompt, options, system)
    
    def _stream_openai(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> Generator[str, None, None]:
        """Stream from OpenAI"""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        
        stream = self._client.chat.completions.create(
            model=self.config.model or "gpt-4o-mini",
            messages=messages,
            temperature=options.get("temperature", self.config.temperature),
            max_tokens=options.get("max_tokens", self.config.max_tokens),
            stream=True,
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    def _stream_anthropic(
        self,
        prompt: str,
        system: str,
        options: Dict[str, Any]
    ) -> Generator[str, None, None]:
        """Stream from Anthropic"""
        with self._client.messages.stream(
            model=self.config.model or "claude-3-5-sonnet-20241022",
            system=system,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=options.get("max_tokens", self.config.max_tokens),
        ) as stream:
            for text in stream.text_stream:
                yield text
    
    def embed(self, text: str) -> List[float]:
        """
        Generate embeddings for text
        
        Args:
            text: Text to embed
            
        Returns:
            List of floats representing the embedding
        """
        if self.provider == LLMProvider.OPENAI:
            response = self._client.embeddings.create(
                model="text-embedding-3-small",
                input=text,
            )
            return response.data[0].embedding
        
        # Try sentence-transformers for local embeddings
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer('all-MiniLM-L6-v2')
            embedding = model.encode(text)
            return embedding.tolist()
        except ImportError:
            raise ImportError("Embeddings require: pip install aria-cli[embeddings]")
    
    def chat(
        self,
        messages: List[Dict[str, str]],
        options: Optional[Dict[str, Any]] = None,
    ) -> LLMResponse:
        """
        Multi-turn chat with message history
        
        Args:
            messages: List of {"role": "user"|"assistant", "content": "..."}
            options: Override generation options
            
        Returns:
            LLMResponse
        """
        if not self.is_available:
            return LLMResponse(
                content="LLM not available",
                model="none",
                provider=self.provider.name,
            )
        
        options = options or {}
        
        if self.provider in [LLMProvider.OPENAI, LLMProvider.AZURE_OPENAI]:
            # Add system message
            full_messages = [
                {"role": "system", "content": self.config.system_prompt}
            ] + messages
            
            response = self._client.chat.completions.create(
                model=self.config.model,
                messages=full_messages,
                temperature=options.get("temperature", self.config.temperature),
                max_tokens=options.get("max_tokens", self.config.max_tokens),
            )
            
            choice = response.choices[0]
            return LLMResponse(
                content=choice.message.content or "",
                model=response.model,
                provider="openai",
                finish_reason=choice.finish_reason or "",
            )
        
        elif self.provider == LLMProvider.ANTHROPIC:
            response = self._client.messages.create(
                model=self.config.model,
                system=self.config.system_prompt,
                messages=messages,
                max_tokens=options.get("max_tokens", self.config.max_tokens),
            )
            
            return LLMResponse(
                content=response.content[0].text if response.content else "",
                model=response.model,
                provider="anthropic",
            )
        
        # Fallback: use last user message
        last_user = next((m for m in reversed(messages) if m["role"] == "user"), None)
        if last_user:
            return self.generate_full(last_user["content"], options)
        
        return LLMResponse(
            content="No user message found",
            model="none",
            provider=self.provider.name,
        )


def auto_detect_provider() -> Optional[LLMConnector]:
    """
    Auto-detect available LLM provider from environment
    
    Returns:
        LLMConnector if a provider is available, None otherwise
    """
    # Check for API keys in order of preference
    if os.getenv("ANTHROPIC_API_KEY"):
        return LLMConnector(LLMProvider.ANTHROPIC)
    
    if os.getenv("OPENAI_API_KEY"):
        return LLMConnector(LLMProvider.OPENAI)
    
    if os.getenv("AZURE_OPENAI_API_KEY"):
        return LLMConnector(LLMProvider.AZURE_OPENAI)
    
    # Check for Ollama
    try:
        import httpx
        response = httpx.get("http://localhost:11434/api/tags", timeout=2.0)
        if response.status_code == 200:
            return LLMConnector(LLMProvider.OLLAMA)
    except:
        pass
    
    return None
