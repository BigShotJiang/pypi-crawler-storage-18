"""
NLP Engine for ARIA CLI v0.2.0

Enhanced natural language processing with:
- Multi-pattern intent detection
- Named entity recognition
- Semantic similarity matching
- Q-System operator routing
- Context-aware parsing
"""

import re
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Set
from enum import Enum, auto
from pathlib import Path
import json


class Intent(Enum):
    """Detected user intents with Q-System mapping"""
    
    # Foundation intents
    QUESTION = auto()        # Asking for information
    COMMAND = auto()         # Direct command execution
    SEARCH = auto()          # Search for something
    
    # Action intents
    GENERATE = auto()        # Create/generate content
    ANALYZE = auto()         # Analyze something
    TRAIN = auto()           # Train a model
    PREDICT = auto()         # Make a prediction
    EVALUATE = auto()        # Evaluate/assess
    
    # Memory intents
    REMEMBER = auto()        # Store in memory
    RECALL = auto()          # Retrieve from memory
    FORGET = auto()          # Remove from memory
    
    # Communication intents
    EXPLAIN = auto()         # Request explanation
    SUMMARIZE = auto()       # Request summary
    TRANSLATE = auto()       # Translate content
    
    # Meta intents
    HELP = auto()            # Request help
    STATUS = auto()          # Check status
    CONFIGURE = auto()       # Configure settings
    REFLECT = auto()         # Self-reflection
    
    # Catch-all
    UNKNOWN = auto()

    @property
    def q_operator(self) -> str:
        """Map intent to Q-System operator"""
        mapping = {
            Intent.QUESTION: 'ASK',
            Intent.COMMAND: 'EXECUTE',
            Intent.SEARCH: 'SEARCH',
            Intent.GENERATE: 'GENERATE',
            Intent.ANALYZE: 'ANALYZE',
            Intent.TRAIN: 'TRAIN',
            Intent.PREDICT: 'PREDICT',
            Intent.EVALUATE: 'EVALUATE',
            Intent.REMEMBER: 'REMEMBER',
            Intent.RECALL: 'RECALL',
            Intent.FORGET: 'FORGET',
            Intent.EXPLAIN: 'EXPLAIN',
            Intent.SUMMARIZE: 'SUMMARIZE',
            Intent.TRANSLATE: 'TRANSLATE',
            Intent.HELP: 'REPORT',
            Intent.STATUS: 'REPORT',
            Intent.CONFIGURE: 'EXECUTE',
            Intent.REFLECT: 'REFLECT',
            Intent.UNKNOWN: 'ASK',
        }
        return mapping.get(self, 'ASK')
    
    @property
    def q_layer(self) -> int:
        """Map intent to primary Q-Layer"""
        mapping = {
            Intent.QUESTION: 8,      # Q8_LANGUAGE
            Intent.COMMAND: 23,      # Q23_EXECUTION
            Intent.SEARCH: 3,        # Q3_PATTERN
            Intent.GENERATE: 12,     # Q12_HYPOTHESIS
            Intent.ANALYZE: 11,      # Q11_INFERENCE
            Intent.TRAIN: 28,        # Q28_LEARNING
            Intent.PREDICT: 16,      # Q16_PREDICTION
            Intent.EVALUATE: 17,     # Q17_EVALUATION
            Intent.REMEMBER: 5,      # Q5_MEMORY_LONG
            Intent.RECALL: 4,        # Q4_MEMORY_SHORT
            Intent.FORGET: 5,        # Q5_MEMORY_LONG
            Intent.EXPLAIN: 15,      # Q15_CAUSATION
            Intent.SUMMARIZE: 18,    # Q18_SYNTHESIS
            Intent.TRANSLATE: 8,     # Q8_LANGUAGE
            Intent.HELP: 30,         # Q30_AWARENESS
            Intent.STATUS: 24,       # Q24_MONITORING
            Intent.CONFIGURE: 29,    # Q29_ADAPTATION
            Intent.REFLECT: 31,      # Q31_REFLECTION
            Intent.UNKNOWN: 8,       # Q8_LANGUAGE
        }
        return mapping.get(self, 8)


@dataclass
class Entity:
    """Extracted entity from text"""
    type: str           # Entity type
    value: str          # Entity value
    start: int          # Start position
    end: int            # End position
    confidence: float = 1.0
    normalized: Optional[str] = None  # Normalized form
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.type,
            'value': self.value,
            'start': self.start,
            'end': self.end,
            'confidence': self.confidence,
            'normalized': self.normalized,
        }


@dataclass
class ParsedInput:
    """Fully parsed user input"""
    raw_text: str
    intent: Intent
    entities: List[Entity] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    q_operator: str = "ASK"
    q_layer: int = 8
    payload: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    alternatives: List[Intent] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.q_operator = self.intent.q_operator
        self.q_layer = self.intent.q_layer

    def to_dict(self) -> Dict[str, Any]:
        return {
            'raw_text': self.raw_text,
            'intent': self.intent.name,
            'entities': [e.to_dict() for e in self.entities],
            'keywords': self.keywords,
            'q_operator': self.q_operator,
            'q_layer': self.q_layer,
            'payload': self.payload,
            'confidence': self.confidence,
            'alternatives': [a.name for a in self.alternatives],
        }


class NLPEngine:
    """
    Natural Language Processing Engine for ARIA CLI v0.2.0
    
    Provides comprehensive NLP capabilities:
    - Intent detection with confidence scoring
    - Named entity recognition
    - Keyword extraction
    - Q-System routing
    - Context management
    """
    
    # Intent detection patterns
    INTENT_PATTERNS: Dict[Intent, List[str]] = {
        Intent.QUESTION: [
            r'^(what|who|where|when|why|how|which|can|could|would|should|is|are|do|does|did|has|have|will)\b',
            r'\?$',
            r'^(tell me|explain|describe|show me|what\'s|who\'s)\b',
            r'\b(meaning of|definition of)\b',
        ],
        Intent.SEARCH: [
            r'^(search|find|look for|locate|show|list|get all|fetch)\b',
            r'(search for|looking for|find me|show me all|where is|where are)\b',
            r'\b(grep|query|lookup)\b',
        ],
        Intent.GENERATE: [
            r'^(generate|create|make|build|write|compose|draft|produce)\b',
            r'(generate me|create a|make a|write a|build me)\b',
            r'\b(new|fresh|original)\s+(code|text|file|document|image)\b',
        ],
        Intent.ANALYZE: [
            r'^(analyze|analyse|examine|inspect|review|assess|study|investigate)\b',
            r'(analyze this|analyze the|break down|look at)\b',
            r'\b(analysis|breakdown|examination)\b',
        ],
        Intent.TRAIN: [
            r'^(train|learn|fit|tune|fine-tune)\b',
            r'(train a|train the|train on|learn from)\b',
            r'\b(training|learning|model)\s+(data|set|process)\b',
        ],
        Intent.PREDICT: [
            r'^(predict|forecast|estimate|project|anticipate)\b',
            r'(what will|what would|future|next)\b',
            r'\b(prediction|forecast|projection)\b',
        ],
        Intent.EVALUATE: [
            r'^(evaluate|rate|score|grade|rank|compare)\b',
            r'(how good|how well|quality of|performance of)\b',
            r'\b(evaluation|assessment|benchmark)\b',
        ],
        Intent.REMEMBER: [
            r'^(remember|save|store|keep|note|record)\b',
            r'(remember that|don\'t forget|save this|note that)\b',
            r'\b(memo|reminder|bookmark)\b',
        ],
        Intent.RECALL: [
            r'^(recall|retrieve|get|fetch|load|restore)\b',
            r'(what did i|do you remember|what was|remind me)\b',
            r'\b(previously|earlier|before|last time)\b',
        ],
        Intent.FORGET: [
            r'^(forget|delete|remove|clear|erase)\b',
            r'(forget about|delete the|remove the|clear the)\b',
        ],
        Intent.EXPLAIN: [
            r'^(explain|clarify|elaborate|expound)\b',
            r'(explain to me|explain how|explain why|what does .* mean)\b',
            r'\b(explanation|clarification|in detail)\b',
        ],
        Intent.SUMMARIZE: [
            r'^(summarize|summarise|sum up|recap|brief)\b',
            r'(give me a summary|in short|in brief|tl;?dr)\b',
            r'\b(summary|overview|highlights)\b',
        ],
        Intent.TRANSLATE: [
            r'^(translate|convert|transform)\b',
            r'(translate .* to|in .* language|say .* in)\b',
            r'\b(translation|translated)\b',
        ],
        Intent.HELP: [
            r'^(help|assist|support)\b',
            r'(how do i|how can i|i need help|can you help)\b',
            r'\b(instructions|guide|tutorial|documentation)\b',
        ],
        Intent.STATUS: [
            r'^(status|state|check|info|information)\b',
            r'(what is the status|current state|system info)\b',
            r'\b(report|diagnostic|health)\b',
        ],
        Intent.CONFIGURE: [
            r'^(configure|config|setup|set|change|update|modify)\b',
            r'(change the|update the|set the|modify the)\b',
            r'\b(settings|configuration|preferences|options)\b',
        ],
        Intent.REFLECT: [
            r'^(reflect|think about|consider|ponder|contemplate)\b',
            r'(what do you think|your thoughts|self-reflect)\b',
            r'\b(reflection|introspection|meta)\b',
        ],
        Intent.COMMAND: [
            r'^(run|execute|do|perform|start|stop|restart)\b',
            r'(run the|execute the|start the|stop the)\b',
            r'^!',  # Shell-style command prefix
        ],
    }
    
    # Entity patterns
    ENTITY_PATTERNS: Dict[str, List[Tuple[str, str]]] = {
        'file': [
            (r'[\w\-./\\]+\.(py|js|ts|json|yaml|yml|md|txt|csv|xml|html|css)', 'FILE'),
            (r'["\']([^"\']+)["\']', 'QUOTED'),
        ],
        'url': [
            (r'https?://[^\s<>"]+', 'URL'),
        ],
        'number': [
            (r'\b\d+\.?\d*\b', 'NUMBER'),
        ],
        'date': [
            (r'\b\d{4}-\d{2}-\d{2}\b', 'DATE'),
            (r'\b(today|tomorrow|yesterday|next week|last week)\b', 'RELATIVE_DATE'),
        ],
        'time': [
            (r'\b\d{1,2}:\d{2}(:\d{2})?\s*(am|pm)?\b', 'TIME'),
        ],
        'email': [
            (r'\b[\w.+-]+@[\w.-]+\.\w+\b', 'EMAIL'),
        ],
        'model': [
            (r'\b(gpt-4|gpt-3\.5|claude|llama|mistral|gemini)\b', 'MODEL'),
        ],
        'language': [
            (r'\b(python|javascript|typescript|java|c\+\+|rust|go|ruby)\b', 'PROGRAMMING_LANG'),
            (r'\b(english|spanish|french|german|chinese|japanese|korean)\b', 'NATURAL_LANG'),
        ],
    }
    
    # Stopwords for keyword extraction
    STOPWORDS: Set[str] = {
        'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
        'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above',
        'below', 'between', 'under', 'again', 'further', 'then', 'once',
        'here', 'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few',
        'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only',
        'own', 'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but',
        'if', 'or', 'because', 'until', 'while', 'about', 'against', 'this',
        'that', 'these', 'those', 'am', 'it', 'its', 'i', 'me', 'my', 'we',
        'our', 'you', 'your', 'he', 'him', 'his', 'she', 'her', 'they', 'them',
        'their', 'what', 'which', 'who', 'whom', 'please', 'thanks', 'thank',
    }
    
    def __init__(self, use_embeddings: bool = False):
        """
        Initialize NLP Engine
        
        Args:
            use_embeddings: Whether to use semantic embeddings (requires aria-cli[embeddings])
        """
        self._use_embeddings = use_embeddings
        self._embedder = None
        self._context_history: List[ParsedInput] = []
        
        if use_embeddings:
            self._init_embeddings()
    
    def _init_embeddings(self):
        """Initialize semantic embeddings"""
        try:
            from sentence_transformers import SentenceTransformer
            self._embedder = SentenceTransformer('all-MiniLM-L6-v2')
        except ImportError:
            self._use_embeddings = False
    
    def parse(self, text: str, context: Optional[Dict[str, Any]] = None) -> ParsedInput:
        """
        Parse user input into structured format
        
        Args:
            text: Raw user input
            context: Optional context from previous interactions
            
        Returns:
            ParsedInput with detected intent, entities, and routing info
        """
        text = text.strip()
        context = context or {}
        
        # Detect intent
        intent, confidence, alternatives = self._detect_intent(text)
        
        # Extract entities
        entities = self._extract_entities(text)
        
        # Extract keywords
        keywords = self._extract_keywords(text)
        
        # Build payload
        payload = self._build_payload(text, intent, entities, keywords)
        
        # Create parsed input
        parsed = ParsedInput(
            raw_text=text,
            intent=intent,
            entities=entities,
            keywords=keywords,
            payload=payload,
            confidence=confidence,
            alternatives=alternatives,
            context=context,
        )
        
        # Update context history
        self._context_history.append(parsed)
        if len(self._context_history) > 10:
            self._context_history.pop(0)
        
        return parsed
    
    def _detect_intent(self, text: str) -> Tuple[Intent, float, List[Intent]]:
        """
        Detect intent from text with confidence scoring
        
        Returns:
            Tuple of (primary intent, confidence, alternative intents)
        """
        text_lower = text.lower()
        scores: Dict[Intent, float] = {}
        
        for intent, patterns in self.INTENT_PATTERNS.items():
            score = 0.0
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    # Weight early matches higher
                    match = re.search(pattern, text_lower, re.IGNORECASE)
                    if match:
                        position_weight = 1.0 - (match.start() / max(len(text), 1)) * 0.3
                        score += position_weight
            
            if score > 0:
                scores[intent] = score
        
        if not scores:
            return Intent.UNKNOWN, 0.3, []
        
        # Sort by score
        sorted_intents = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        
        primary = sorted_intents[0][0]
        confidence = min(sorted_intents[0][1], 1.0)
        alternatives = [i for i, s in sorted_intents[1:4] if s > 0.3]
        
        return primary, confidence, alternatives
    
    def _extract_entities(self, text: str) -> List[Entity]:
        """Extract named entities from text"""
        entities: List[Entity] = []
        
        for entity_type, patterns in self.ENTITY_PATTERNS.items():
            for pattern, subtype in patterns:
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    value = match.group(0)
                    # Check if this span overlaps with existing entity
                    overlaps = any(
                        e.start <= match.start() < e.end or
                        e.start < match.end() <= e.end
                        for e in entities
                    )
                    if not overlaps:
                        entities.append(Entity(
                            type=subtype,
                            value=value,
                            start=match.start(),
                            end=match.end(),
                            normalized=value.lower() if subtype in ['PROGRAMMING_LANG', 'MODEL'] else None,
                        ))
        
        # Sort by position
        entities.sort(key=lambda e: e.start)
        return entities
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords from text"""
        # Tokenize
        words = re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]*\b', text.lower())
        
        # Filter stopwords and short words
        keywords = [
            w for w in words
            if w not in self.STOPWORDS and len(w) > 2
        ]
        
        # Deduplicate while preserving order
        seen = set()
        unique = []
        for kw in keywords:
            if kw not in seen:
                seen.add(kw)
                unique.append(kw)
        
        return unique[:10]  # Top 10 keywords
    
    def _build_payload(
        self,
        text: str,
        intent: Intent,
        entities: List[Entity],
        keywords: List[str]
    ) -> Dict[str, Any]:
        """Build command payload from parsed components"""
        payload: Dict[str, Any] = {
            'input': text,
            'keywords': keywords,
        }
        
        # Add entities by type
        for entity in entities:
            key = entity.type.lower()
            if key not in payload:
                payload[key] = []
            if isinstance(payload[key], list):
                payload[key].append(entity.value)
        
        # Intent-specific extraction
        if intent == Intent.SEARCH:
            # Extract search query
            query_match = re.search(
                r'(?:search|find|look for|locate)\s+(?:for\s+)?(.+)',
                text, re.IGNORECASE
            )
            if query_match:
                payload['query'] = query_match.group(1).strip()
        
        elif intent == Intent.GENERATE:
            # Extract what to generate
            gen_match = re.search(
                r'(?:generate|create|make|write|build)\s+(?:a\s+)?(.+)',
                text, re.IGNORECASE
            )
            if gen_match:
                payload['target'] = gen_match.group(1).strip()
        
        elif intent == Intent.REMEMBER:
            # Extract what to remember
            mem_match = re.search(
                r'(?:remember|save|store|note)\s+(?:that\s+)?(.+)',
                text, re.IGNORECASE
            )
            if mem_match:
                payload['content'] = mem_match.group(1).strip()
        
        elif intent == Intent.TRANSLATE:
            # Extract source and target language
            trans_match = re.search(
                r'translate\s+(.+?)\s+(?:to|into)\s+(\w+)',
                text, re.IGNORECASE
            )
            if trans_match:
                payload['content'] = trans_match.group(1).strip()
                payload['target_language'] = trans_match.group(2).strip()
        
        return payload
    
    def get_context(self) -> List[Dict[str, Any]]:
        """Get recent context history"""
        return [p.to_dict() for p in self._context_history]
    
    def clear_context(self):
        """Clear context history"""
        self._context_history.clear()
    
    def semantic_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate semantic similarity between two texts
        
        Requires aria-cli[embeddings]
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score between 0 and 1
        """
        if not self._embedder:
            # Fall back to simple word overlap
            words1 = set(self._extract_keywords(text1))
            words2 = set(self._extract_keywords(text2))
            if not words1 or not words2:
                return 0.0
            overlap = len(words1 & words2)
            return overlap / max(len(words1), len(words2))
        
        embeddings = self._embedder.encode([text1, text2])
        # Cosine similarity
        from numpy import dot
        from numpy.linalg import norm
        return float(dot(embeddings[0], embeddings[1]) / (norm(embeddings[0]) * norm(embeddings[1])))
