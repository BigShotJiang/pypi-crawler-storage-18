"""
ARIA Infinite Storage Client - Cloud Storage Integration

Integrates with the Universal Crown Prime Infinite Storage System:
- Multi-backend storage (Redis, PostgreSQL, S3/MinIO, Local)
- Compression (zstd) for efficient transfer
- Encryption (AES-256-GCM) for security
- RAM caching with LRU eviction
- Cross-device file synchronization

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                   ARIA Infinite Storage                         │
    ├─────────────────────────────────────────────────────────────────┤
    │  ┌───────────┐    ┌────────────┐    ┌──────────────────────┐  │
    │  │ RAM Cache │───▶│ Storage API│───▶│ Multi-Backend Storage│  │
    │  │   (LRU)   │    │  (HTTP)    │    │ Redis/PG/S3/Local    │  │
    │  └───────────┘    └────────────┘    └──────────────────────┘  │
    └─────────────────────────────────────────────────────────────────┘

Usage:
    from aria_cli.infinite_storage import InfiniteStorage, StorageBackend
    
    # Initialize client
    storage = InfiniteStorage()
    
    # Store data
    await storage.store("mykey", {"data": "value"}, backend=StorageBackend.REDIS)
    
    # Retrieve data
    data = await storage.retrieve("mykey")
    
    # Store file
    await storage.store_file("/path/to/file.txt", "file:myfile")
    
    # Download file
    await storage.download_file("file:myfile", "/path/to/output.txt")
"""

import os
import sys
import json
import asyncio
import hashlib
import base64
import zlib
import gzip
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import OrderedDict
import threading
import time

# Optional imports
try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False
    httpx = None

try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False
    aiohttp = None

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    requests = None

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    HAS_RICH = True
    console = Console()
except ImportError:
    HAS_RICH = False
    console = None

# Compression support
try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False
    zstd = None

# Encryption support
try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False
    Fernet = None
    AESGCM = None


class StorageBackend(str, Enum):
    """Available storage backends"""
    REDIS = "REDIS"
    POSTGRESQL = "POSTGRESQL"
    S3 = "S3"
    LOCAL = "LOCAL"
    AUTO = "AUTO"  # Auto-select best backend


class CompressionLevel(str, Enum):
    """Compression level options"""
    NONE = "NONE"
    FAST = "FAST"
    BALANCED = "BALANCED"
    MAXIMUM = "MAXIMUM"


@dataclass
class StorageConfig:
    """Configuration for infinite storage"""
    api_url: str = "http://localhost:9000"
    default_backend: StorageBackend = StorageBackend.REDIS
    compression: CompressionLevel = CompressionLevel.BALANCED
    encryption_enabled: bool = True
    cache_enabled: bool = True
    cache_max_size: int = 500
    cache_ttl_seconds: int = 3600
    timeout_seconds: int = 30
    retry_count: int = 3
    retry_delay: float = 0.5
    
    @classmethod
    def from_env(cls) -> "StorageConfig":
        """Create config from environment variables"""
        return cls(
            api_url=os.environ.get("ARIA_STORAGE_API_URL", "http://localhost:9000"),
            default_backend=StorageBackend(
                os.environ.get("ARIA_STORAGE_BACKEND", "REDIS")
            ),
            compression=CompressionLevel(
                os.environ.get("ARIA_STORAGE_COMPRESSION", "BALANCED")
            ),
            encryption_enabled=os.environ.get(
                "ARIA_STORAGE_ENCRYPTION", "true"
            ).lower() == "true",
            cache_enabled=os.environ.get(
                "ARIA_STORAGE_CACHE", "true"
            ).lower() == "true",
            cache_max_size=int(os.environ.get("ARIA_CACHE_MAX_SIZE", "500")),
            timeout_seconds=int(os.environ.get("ARIA_STORAGE_TIMEOUT", "30")),
        )


@dataclass
class StorageResult:
    """Result of a storage operation"""
    success: bool
    key: str
    data: Optional[Any] = None
    size_bytes: int = 0
    compressed: bool = False
    encrypted: bool = False
    backend: str = ""
    from_cache: bool = False
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "key": self.key,
            "data": self.data,
            "size_bytes": self.size_bytes,
            "compressed": self.compressed,
            "encrypted": self.encrypted,
            "backend": self.backend,
            "from_cache": self.from_cache,
            "error": self.error,
            "metadata": self.metadata,
        }


class PersistentCache:
    """
    Disk-backed cache for CLI persistence
    Uses individual files per key for simplicity
    """
    
    CACHE_DIR = Path.home() / ".aria" / "storage_cache"
    
    def __init__(self, max_size: int = 500, ttl_seconds: int = 86400):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self.hits = 0
        self.misses = 0
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    
    def _key_to_filename(self, key: str) -> Path:
        """Convert key to safe filename"""
        safe_key = hashlib.sha256(key.encode()).hexdigest()[:32]
        return self.CACHE_DIR / f"{safe_key}.cache"
    
    def _key_to_meta(self, key: str) -> Path:
        """Get metadata file path"""
        safe_key = hashlib.sha256(key.encode()).hexdigest()[:32]
        return self.CACHE_DIR / f"{safe_key}.meta"
    
    def get(self, key: str) -> Optional[bytes]:
        """Get value from disk cache"""
        cache_file = self._key_to_filename(key)
        meta_file = self._key_to_meta(key)
        
        if not cache_file.exists():
            self.misses += 1
            return None
        
        # Check TTL
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
                stored_at = datetime.fromisoformat(meta.get('stored_at', ''))
                age = (datetime.now() - stored_at).total_seconds()
                if age > self.ttl_seconds:
                    # Expired
                    cache_file.unlink(missing_ok=True)
                    meta_file.unlink(missing_ok=True)
                    self.misses += 1
                    return None
            except Exception:
                pass
        
        try:
            self.hits += 1
            return cache_file.read_bytes()
        except Exception:
            self.misses += 1
            return None
    
    def set(self, key: str, value: bytes) -> None:
        """Set value in disk cache"""
        cache_file = self._key_to_filename(key)
        meta_file = self._key_to_meta(key)
        
        try:
            # Write data
            cache_file.write_bytes(value)
            
            # Write metadata
            meta = {
                'key': key,
                'stored_at': datetime.now().isoformat(),
                'size': len(value),
            }
            meta_file.write_text(json.dumps(meta))
            
            # Cleanup old entries if too many
            self._maybe_cleanup()
        except Exception:
            pass
    
    def delete(self, key: str) -> bool:
        """Delete from cache"""
        cache_file = self._key_to_filename(key)
        meta_file = self._key_to_meta(key)
        
        deleted = False
        if cache_file.exists():
            cache_file.unlink(missing_ok=True)
            deleted = True
        if meta_file.exists():
            meta_file.unlink(missing_ok=True)
            deleted = True
        return deleted
    
    def clear(self) -> None:
        """Clear all cache files"""
        for f in self.CACHE_DIR.glob("*.cache"):
            f.unlink(missing_ok=True)
        for f in self.CACHE_DIR.glob("*.meta"):
            f.unlink(missing_ok=True)
    
    def _maybe_cleanup(self) -> None:
        """Cleanup old entries if cache is too large"""
        cache_files = list(self.CACHE_DIR.glob("*.cache"))
        if len(cache_files) <= self.max_size:
            return
        
        # Sort by modification time and remove oldest
        cache_files.sort(key=lambda f: f.stat().st_mtime)
        remove_count = len(cache_files) - self.max_size + 10
        for f in cache_files[:remove_count]:
            f.unlink(missing_ok=True)
            meta = f.with_suffix('.meta')
            meta.unlink(missing_ok=True)
    
    def keys(self) -> List[str]:
        """List all cached keys"""
        result = []
        for meta_file in self.CACHE_DIR.glob("*.meta"):
            try:
                meta = json.loads(meta_file.read_text())
                if 'key' in meta:
                    result.append(meta['key'])
            except Exception:
                pass
        return result
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        cache_files = list(self.CACHE_DIR.glob("*.cache"))
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            "size": len(cache_files),
            "max_size": self.max_size,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": round(hit_rate, 2),
            "ttl_seconds": self.ttl_seconds,
            "cache_dir": str(self.CACHE_DIR),
        }


class LRUCache:
    """Thread-safe LRU cache with TTL support"""
    
    def __init__(self, max_size: int = 500, ttl_seconds: int = 3600):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self.cache: OrderedDict = OrderedDict()
        self.timestamps: Dict[str, datetime] = {}
        self.lock = threading.RLock()
        self.hits = 0
        self.misses = 0
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        with self.lock:
            if key not in self.cache:
                self.misses += 1
                return None
            
            # Check TTL
            if key in self.timestamps:
                age = (datetime.now() - self.timestamps[key]).total_seconds()
                if age > self.ttl_seconds:
                    # Expired
                    del self.cache[key]
                    del self.timestamps[key]
                    self.misses += 1
                    return None
            
            # Move to end (most recently used)
            self.cache.move_to_end(key)
            self.hits += 1
            return self.cache[key]
    
    def set(self, key: str, value: Any) -> None:
        """Set value in cache"""
        with self.lock:
            if key in self.cache:
                # Update existing
                self.cache.move_to_end(key)
                self.cache[key] = value
                self.timestamps[key] = datetime.now()
            else:
                # Add new
                if len(self.cache) >= self.max_size:
                    # Evict oldest
                    oldest_key = next(iter(self.cache))
                    del self.cache[oldest_key]
                    self.timestamps.pop(oldest_key, None)
                
                self.cache[key] = value
                self.timestamps[key] = datetime.now()
    
    def delete(self, key: str) -> bool:
        """Delete from cache"""
        with self.lock:
            if key in self.cache:
                del self.cache[key]
                self.timestamps.pop(key, None)
                return True
            return False
    
    def clear(self) -> None:
        """Clear all cache"""
        with self.lock:
            self.cache.clear()
            self.timestamps.clear()
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        return {
            "size": len(self.cache),
            "max_size": self.max_size,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": round(hit_rate, 2),
            "ttl_seconds": self.ttl_seconds,
        }


class LocalCompression:
    """Local compression utilities when API is unavailable"""
    
    @staticmethod
    def compress(data: bytes, level: CompressionLevel = CompressionLevel.BALANCED) -> bytes:
        """Compress data locally"""
        if HAS_ZSTD:
            # Use zstd
            zstd_level = {
                CompressionLevel.NONE: 0,
                CompressionLevel.FAST: 1,
                CompressionLevel.BALANCED: 6,
                CompressionLevel.MAXIMUM: 19,
            }.get(level, 6)
            
            if zstd_level == 0:
                return data
            
            compressor = zstd.ZstdCompressor(level=zstd_level)
            return compressor.compress(data)
        else:
            # Fallback to gzip
            gzip_level = {
                CompressionLevel.NONE: 0,
                CompressionLevel.FAST: 1,
                CompressionLevel.BALANCED: 6,
                CompressionLevel.MAXIMUM: 9,
            }.get(level, 6)
            
            if gzip_level == 0:
                return data
            
            return gzip.compress(data, compresslevel=gzip_level)
    
    @staticmethod
    def decompress(data: bytes) -> bytes:
        """Decompress data locally"""
        if len(data) < 4:
            return data
        
        # Try zstd first
        if HAS_ZSTD:
            try:
                decompressor = zstd.ZstdDecompressor()
                return decompressor.decompress(data)
            except Exception:
                pass
        
        # Try gzip
        try:
            return gzip.decompress(data)
        except Exception:
            pass
        
        # Try zlib
        try:
            return zlib.decompress(data)
        except Exception:
            pass
        
        # Return as-is
        return data


class LocalEncryption:
    """Local encryption utilities with persistent key"""
    
    _shared_key: Optional[bytes] = None
    _key_file: Path = Path.home() / ".aria" / ".storage_key"
    
    def __init__(self, key: Optional[bytes] = None):
        self.key = key or self._get_or_create_key()
        if HAS_CRYPTO:
            self.fernet = Fernet(self.key)
        else:
            self.fernet = None
    
    @classmethod
    def _get_or_create_key(cls) -> bytes:
        """Get existing key or create a new persistent one"""
        # Use shared key if already loaded
        if cls._shared_key is not None:
            return cls._shared_key
        
        # Try to load from file
        if cls._key_file.exists():
            try:
                cls._shared_key = cls._key_file.read_bytes()
                return cls._shared_key
            except Exception:
                pass
        
        # Generate new key and save
        if HAS_CRYPTO:
            cls._shared_key = Fernet.generate_key()
        else:
            cls._shared_key = base64.urlsafe_b64encode(os.urandom(32))
        
        # Save to file
        try:
            cls._key_file.parent.mkdir(parents=True, exist_ok=True)
            cls._key_file.write_bytes(cls._shared_key)
            # Restrict permissions (on Unix)
            if hasattr(os, 'chmod'):
                os.chmod(cls._key_file, 0o600)
        except Exception:
            pass
        
        return cls._shared_key
    
    @staticmethod
    def _generate_key() -> bytes:
        """Generate a Fernet key"""
        if HAS_CRYPTO:
            return Fernet.generate_key()
        else:
            # Simple base64 key
            return base64.urlsafe_b64encode(os.urandom(32))
    
    def encrypt(self, data: bytes) -> bytes:
        """Encrypt data"""
        if self.fernet:
            return self.fernet.encrypt(data)
        else:
            # XOR with key (very basic, not secure)
            key_bytes = self.key[:32] if len(self.key) >= 32 else self.key.ljust(32, b'\0')
            return bytes(d ^ key_bytes[i % 32] for i, d in enumerate(data))
    
    def decrypt(self, data: bytes) -> bytes:
        """Decrypt data"""
        if self.fernet:
            return self.fernet.decrypt(data)
        else:
            # XOR with key
            key_bytes = self.key[:32] if len(self.key) >= 32 else self.key.ljust(32, b'\0')
            return bytes(d ^ key_bytes[i % 32] for i, d in enumerate(data))


class InfiniteStorage:
    """
    ARIA Infinite Storage Client
    
    Provides seamless access to the Universal Crown Prime Infinite Storage System
    with local caching, compression, and encryption support.
    """
    
    VERSION = "1.0.0"
    
    def __init__(self, config: Optional[StorageConfig] = None):
        self.config = config or StorageConfig.from_env()
        
        # Use persistent disk cache for CLI mode (survives process restarts)
        self.cache = PersistentCache(
            max_size=self.config.cache_max_size,
            ttl_seconds=self.config.cache_ttl_seconds,
        ) if self.config.cache_enabled else None
        
        # In-memory cache for fast access during single session
        self._memory_cache = LRUCache(
            max_size=self.config.cache_max_size,
            ttl_seconds=self.config.cache_ttl_seconds,
        ) if self.config.cache_enabled else None
        
        self._compression = LocalCompression()
        self._encryption = LocalEncryption() if self.config.encryption_enabled else None
        self._connected = False
        self._api_available = False
        
        # HTTP client
        self._client = None
        self._async_client = None
    
    def _get_sync_client(self):
        """Get synchronous HTTP client"""
        if HAS_REQUESTS:
            return requests.Session()
        return None
    
    async def _get_async_client(self):
        """Get async HTTP client"""
        if HAS_HTTPX:
            if self._async_client is None:
                self._async_client = httpx.AsyncClient(
                    timeout=self.config.timeout_seconds
                )
            return self._async_client
        elif HAS_AIOHTTP:
            return aiohttp.ClientSession()
        return None
    
    async def connect(self) -> bool:
        """Connect to storage API"""
        try:
            client = await self._get_async_client()
            if client and HAS_HTTPX:
                response = await client.get(f"{self.config.api_url}/health")
                if response.status_code == 200:
                    self._connected = True
                    self._api_available = True
                    return True
        except Exception as e:
            pass
        
        # Try sync client
        try:
            client = self._get_sync_client()
            if client:
                response = client.get(
                    f"{self.config.api_url}/health",
                    timeout=5
                )
                if response.status_code == 200:
                    self._connected = True
                    self._api_available = True
                    return True
        except Exception:
            pass
        
        # API not available, use local mode
        self._connected = True
        self._api_available = False
        return True
    
    async def disconnect(self) -> None:
        """Disconnect from storage API"""
        if self._async_client and HAS_HTTPX:
            await self._async_client.aclose()
            self._async_client = None
        self._connected = False
    
    async def health_check(self) -> Dict[str, Any]:
        """Check storage API health"""
        result = {
            "status": "disconnected",
            "api_available": self._api_available,
            "cache_stats": self.cache.stats() if self.cache else None,
            "local_mode": not self._api_available,
            "timestamp": datetime.now().isoformat(),
        }
        
        if self._api_available:
            try:
                client = await self._get_async_client()
                if client and HAS_HTTPX:
                    response = await client.get(f"{self.config.api_url}/health")
                    if response.status_code == 200:
                        result["status"] = "connected"
                        result["api_health"] = response.json()
            except Exception as e:
                result["error"] = str(e)
        else:
            result["status"] = "local_mode"
        
        return result
    
    async def store(
        self,
        key: str,
        data: Union[str, bytes, Dict, List],
        backend: Optional[StorageBackend] = None,
        ttl_seconds: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        use_compression: bool = True,
        use_encryption: Optional[bool] = None,
    ) -> StorageResult:
        """
        Store data in infinite storage
        
        Args:
            key: Unique storage key
            data: Data to store (string, bytes, dict, or list)
            backend: Storage backend (default: from config)
            ttl_seconds: Time-to-live in seconds
            metadata: Optional metadata dict
            use_compression: Enable compression
            use_encryption: Enable encryption (default: from config)
        
        Returns:
            StorageResult with operation status
        """
        backend = backend or self.config.default_backend
        use_encryption = use_encryption if use_encryption is not None else self.config.encryption_enabled
        
        # Convert data to bytes
        if isinstance(data, dict) or isinstance(data, list):
            data_bytes = json.dumps(data).encode('utf-8')
        elif isinstance(data, str):
            data_bytes = data.encode('utf-8')
        else:
            data_bytes = data
        
        original_size = len(data_bytes)
        
        # Apply compression
        compressed = False
        if use_compression and self.config.compression != CompressionLevel.NONE:
            data_bytes = self._compression.compress(data_bytes, self.config.compression)
            compressed = len(data_bytes) < original_size
        
        # Apply encryption
        encrypted = False
        if use_encryption and self._encryption:
            data_bytes = self._encryption.encrypt(data_bytes)
            encrypted = True
        
        # Store in cache
        if self.cache:
            self.cache.set(key, data_bytes)
        
        # Try API storage
        if self._api_available:
            try:
                client = await self._get_async_client()
                if client and HAS_HTTPX:
                    payload = {
                        "key": key,
                        "data": base64.b64encode(data_bytes).decode('ascii'),
                        "backend": backend.value if isinstance(backend, StorageBackend) else backend,
                        "metadata": metadata,
                        "ttl_seconds": ttl_seconds,
                        "use_compression": False,  # Already compressed
                        "use_encryption": False,   # Already encrypted
                    }
                    response = await client.post(
                        f"{self.config.api_url}/storage/store",
                        json=payload,
                    )
                    if response.status_code == 200:
                        result = response.json()
                        return StorageResult(
                            success=True,
                            key=key,
                            size_bytes=len(data_bytes),
                            compressed=compressed,
                            encrypted=encrypted,
                            backend=result.get("backend", backend),
                            from_cache=False,
                            metadata=metadata,
                        )
            except Exception as e:
                pass  # Fall through to local storage
        
        # Local storage fallback
        return StorageResult(
            success=True,
            key=key,
            size_bytes=len(data_bytes),
            compressed=compressed,
            encrypted=encrypted,
            backend="LOCAL_CACHE",
            from_cache=True,
            metadata=metadata,
        )
    
    async def retrieve(
        self,
        key: str,
        parse_json: bool = True,
    ) -> StorageResult:
        """
        Retrieve data from infinite storage
        
        Args:
            key: Storage key
            parse_json: Attempt to parse as JSON
        
        Returns:
            StorageResult with data
        """
        # Check cache first
        if self.cache:
            cached = self.cache.get(key)
            if cached is not None:
                data = self._decode_data(cached, parse_json)
                return StorageResult(
                    success=True,
                    key=key,
                    data=data,
                    size_bytes=len(cached),
                    from_cache=True,
                )
        
        # Try API
        if self._api_available:
            try:
                client = await self._get_async_client()
                if client and HAS_HTTPX:
                    response = await client.get(
                        f"{self.config.api_url}/storage/retrieve/{key}"
                    )
                    if response.status_code == 200:
                        result = response.json()
                        if result.get("success"):
                            data_b64 = result.get("data", "")
                            data_bytes = base64.b64decode(data_b64)
                            data = self._decode_data(data_bytes, parse_json)
                            
                            # Cache it
                            if self.cache:
                                self.cache.set(key, data_bytes)
                            
                            return StorageResult(
                                success=True,
                                key=key,
                                data=data,
                                size_bytes=len(data_bytes),
                                from_cache=False,
                                metadata=result.get("metadata"),
                            )
            except Exception as e:
                pass
        
        # Not found
        return StorageResult(
            success=False,
            key=key,
            error="Key not found",
        )
    
    def _decode_data(self, data_bytes: bytes, parse_json: bool) -> Any:
        """Decode data bytes to original form"""
        # Decrypt if needed
        if self._encryption:
            try:
                data_bytes = self._encryption.decrypt(data_bytes)
            except Exception:
                pass
        
        # Decompress if needed
        data_bytes = self._compression.decompress(data_bytes)
        
        # Try to decode as string/JSON
        try:
            text = data_bytes.decode('utf-8')
            if parse_json:
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    return text
            return text
        except UnicodeDecodeError:
            return data_bytes
    
    async def delete(self, key: str) -> StorageResult:
        """Delete from storage"""
        # Remove from cache
        if self.cache:
            self.cache.delete(key)
        
        # Delete from API
        if self._api_available:
            try:
                client = await self._get_async_client()
                if client and HAS_HTTPX:
                    response = await client.delete(
                        f"{self.config.api_url}/storage/delete/{key}"
                    )
                    if response.status_code == 200:
                        return StorageResult(
                            success=True,
                            key=key,
                        )
            except Exception:
                pass
        
        return StorageResult(
            success=True,
            key=key,
            from_cache=True,
        )
    
    async def store_file(
        self,
        file_path: Union[str, Path],
        key: Optional[str] = None,
        backend: Optional[StorageBackend] = None,
        ttl_seconds: Optional[int] = None,
    ) -> StorageResult:
        """
        Store a file in infinite storage
        
        Args:
            file_path: Path to file
            key: Storage key (default: file:{filename})
            backend: Storage backend
            ttl_seconds: Time-to-live
        
        Returns:
            StorageResult with operation status
        """
        path = Path(file_path)
        if not path.exists():
            return StorageResult(
                success=False,
                key=key or "",
                error=f"File not found: {file_path}",
            )
        
        key = key or f"file:{path.name}"
        
        # Read file
        data = path.read_bytes()
        
        # Store with metadata
        metadata = {
            "filename": path.name,
            "original_path": str(path.absolute()),
            "size": len(data),
            "checksum": hashlib.sha256(data).hexdigest(),
            "stored_at": datetime.now().isoformat(),
        }
        
        return await self.store(
            key=key,
            data=data,
            backend=backend,
            ttl_seconds=ttl_seconds,
            metadata=metadata,
        )
    
    async def download_file(
        self,
        key: str,
        output_path: Union[str, Path],
    ) -> StorageResult:
        """
        Download a file from infinite storage
        
        Args:
            key: Storage key
            output_path: Where to save the file
        
        Returns:
            StorageResult with operation status
        """
        result = await self.retrieve(key, parse_json=False)
        
        if not result.success:
            return result
        
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        
        if isinstance(result.data, bytes):
            output.write_bytes(result.data)
        else:
            output.write_text(str(result.data))
        
        return StorageResult(
            success=True,
            key=key,
            data=str(output),
            metadata={"downloaded_to": str(output)},
        )
    
    async def list_keys(self, pattern: str = "*") -> List[str]:
        """List storage keys matching pattern"""
        keys = []
        
        # Get from API
        if self._api_available:
            try:
                client = await self._get_async_client()
                if client and HAS_HTTPX:
                    response = await client.get(
                        f"{self.config.api_url}/storage/keys",
                        params={"pattern": pattern}
                    )
                    if response.status_code == 200:
                        result = response.json()
                        keys = result.get("keys", [])
            except Exception:
                pass
        
        # Add cached keys
        if self.cache:
            import fnmatch
            cached_keys = [
                k for k in self.cache.keys()
                if fnmatch.fnmatch(k, pattern)
            ]
            keys = list(set(keys + cached_keys))
        
        return sorted(keys)
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return self.cache.stats() if self.cache else {}
    
    def clear_cache(self) -> None:
        """Clear local cache"""
        if self.cache:
            self.cache.clear()
    
    def print_stats(self) -> None:
        """Print storage statistics"""
        if not HAS_RICH:
            print(f"Cache stats: {self.get_cache_stats()}")
            return
        
        stats = self.get_cache_stats()
        
        table = Table(title="📦 Infinite Storage Statistics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("API URL", self.config.api_url)
        table.add_row("API Available", "✅ Yes" if self._api_available else "❌ No (Local Mode)")
        table.add_row("Default Backend", self.config.default_backend.value)
        table.add_row("Compression", self.config.compression.value)
        table.add_row("Encryption", "✅ Enabled" if self.config.encryption_enabled else "❌ Disabled")
        table.add_row("", "")
        table.add_row("Cache Size", f"{stats.get('size', 0)} / {stats.get('max_size', 0)}")
        table.add_row("Cache Hits", str(stats.get('hits', 0)))
        table.add_row("Cache Misses", str(stats.get('misses', 0)))
        table.add_row("Hit Rate", f"{stats.get('hit_rate', 0)}%")
        
        console.print(table)


# Convenience functions
_storage_instance: Optional[InfiniteStorage] = None


def get_storage(config: Optional[StorageConfig] = None) -> InfiniteStorage:
    """Get or create storage instance"""
    global _storage_instance
    if _storage_instance is None:
        _storage_instance = InfiniteStorage(config)
    return _storage_instance


async def store(key: str, data: Any, **kwargs) -> StorageResult:
    """Store data (convenience function)"""
    storage = get_storage()
    await storage.connect()
    return await storage.store(key, data, **kwargs)


async def retrieve(key: str, **kwargs) -> StorageResult:
    """Retrieve data (convenience function)"""
    storage = get_storage()
    await storage.connect()
    return await storage.retrieve(key, **kwargs)


async def delete(key: str) -> StorageResult:
    """Delete data (convenience function)"""
    storage = get_storage()
    await storage.connect()
    return await storage.delete(key)


if __name__ == "__main__":
    # Demo
    import asyncio
    
    async def demo():
        storage = InfiniteStorage()
        await storage.connect()
        
        print("Health check:")
        health = await storage.health_check()
        print(json.dumps(health, indent=2))
        
        print("\nStoring data...")
        result = await storage.store(
            "demo:test",
            {"message": "Hello from ARIA!", "timestamp": datetime.now().isoformat()}
        )
        print(f"Stored: {result.success}, backend: {result.backend}")
        
        print("\nRetrieving data...")
        result = await storage.retrieve("demo:test")
        print(f"Retrieved: {result.data}")
        
        storage.print_stats()
        
        await storage.disconnect()
    
    asyncio.run(demo())
