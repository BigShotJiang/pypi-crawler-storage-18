"""
SSH Router for ARIA CLI v0.2.0

Provides secure SSH connection management and command routing:
- Multi-host connection management
- SSH tunnel creation
- Remote command execution
- File transfer (SCP/SFTP)
- Connection pooling
- Host configuration management
"""

import os
import socket
import threading
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
import json
import shlex


class SSHAuthMethod(Enum):
    """SSH authentication methods"""
    PASSWORD = auto()
    KEY = auto()
    AGENT = auto()
    CERTIFICATE = auto()


class ConnectionStatus(Enum):
    """Connection status"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    TIMEOUT = "timeout"


@dataclass
class SSHHost:
    """SSH host configuration"""
    name: str
    hostname: str
    port: int = 22
    username: Optional[str] = None
    key_file: Optional[Path] = None
    password: Optional[str] = None
    auth_method: SSHAuthMethod = SSHAuthMethod.KEY
    jump_host: Optional[str] = None  # ProxyJump
    identity_file: Optional[Path] = None
    forward_agent: bool = False
    compression: bool = True
    keep_alive: int = 60
    connect_timeout: int = 30
    options: Dict[str, str] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    description: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "hostname": self.hostname,
            "port": self.port,
            "username": self.username,
            "key_file": str(self.key_file) if self.key_file else None,
            "auth_method": self.auth_method.name,
            "jump_host": self.jump_host,
            "identity_file": str(self.identity_file) if self.identity_file else None,
            "forward_agent": self.forward_agent,
            "compression": self.compression,
            "keep_alive": self.keep_alive,
            "connect_timeout": self.connect_timeout,
            "options": self.options,
            "tags": self.tags,
            "description": self.description,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'SSHHost':
        return cls(
            name=d["name"],
            hostname=d["hostname"],
            port=d.get("port", 22),
            username=d.get("username"),
            key_file=Path(d["key_file"]) if d.get("key_file") else None,
            auth_method=SSHAuthMethod[d.get("auth_method", "KEY")],
            jump_host=d.get("jump_host"),
            identity_file=Path(d["identity_file"]) if d.get("identity_file") else None,
            forward_agent=d.get("forward_agent", False),
            compression=d.get("compression", True),
            keep_alive=d.get("keep_alive", 60),
            connect_timeout=d.get("connect_timeout", 30),
            options=d.get("options", {}),
            tags=d.get("tags", []),
            description=d.get("description", ""),
        )
    
    def get_ssh_command(self) -> List[str]:
        """Generate SSH command arguments"""
        cmd = ["ssh"]
        
        if self.port != 22:
            cmd.extend(["-p", str(self.port)])
        
        if self.identity_file or self.key_file:
            key = self.identity_file or self.key_file
            cmd.extend(["-i", str(key)])
        
        if self.forward_agent:
            cmd.append("-A")
        
        if self.compression:
            cmd.append("-C")
        
        if self.keep_alive:
            cmd.extend(["-o", f"ServerAliveInterval={self.keep_alive}"])
        
        if self.connect_timeout:
            cmd.extend(["-o", f"ConnectTimeout={self.connect_timeout}"])
        
        if self.jump_host:
            cmd.extend(["-J", self.jump_host])
        
        for key, value in self.options.items():
            cmd.extend(["-o", f"{key}={value}"])
        
        # Add user@host
        if self.username:
            cmd.append(f"{self.username}@{self.hostname}")
        else:
            cmd.append(self.hostname)
        
        return cmd


@dataclass
class SSHConnection:
    """Active SSH connection"""
    host: SSHHost
    status: ConnectionStatus = ConnectionStatus.DISCONNECTED
    connected_at: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    process: Optional[subprocess.Popen] = None
    tunnel_ports: Dict[int, int] = field(default_factory=dict)
    
    @property
    def is_connected(self) -> bool:
        return self.status == ConnectionStatus.CONNECTED


@dataclass
class CommandResult:
    """Result of SSH command execution"""
    command: str
    host: str
    exit_code: int
    stdout: str
    stderr: str
    duration: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def success(self) -> bool:
        return self.exit_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "command": self.command,
            "host": self.host,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration": self.duration,
            "success": self.success,
            "timestamp": self.timestamp.isoformat(),
        }


class SSHRouter:
    """
    SSH Router for ARIA CLI
    
    Manages SSH connections, command routing, and tunnels.
    
    Usage:
        router = SSHRouter()
        
        # Add a host
        router.add_host(SSHHost(
            name="production",
            hostname="prod.example.com",
            username="deploy",
            key_file=Path("~/.ssh/id_rsa").expanduser()
        ))
        
        # Execute command
        result = router.execute("production", "ls -la")
        print(result.stdout)
        
        # Create tunnel
        router.create_tunnel("production", local_port=8080, remote_port=80)
        
        # Transfer file
        router.upload("production", "/local/file.txt", "/remote/path/")
    """
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path.home() / ".aria" / "ssh"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.hosts_file = self.config_dir / "hosts.json"
        self.history_file = self.config_dir / "history.json"
        
        self._hosts: Dict[str, SSHHost] = {}
        self._connections: Dict[str, SSHConnection] = {}
        self._tunnels: Dict[str, subprocess.Popen] = {}
        self._lock = threading.Lock()
        
        self._load_hosts()
    
    def _load_hosts(self):
        """Load hosts from configuration file"""
        if self.hosts_file.exists():
            try:
                data = json.loads(self.hosts_file.read_text())
                for host_data in data.get("hosts", []):
                    host = SSHHost.from_dict(host_data)
                    self._hosts[host.name] = host
            except Exception as e:
                print(f"Warning: Could not load SSH hosts: {e}")
        
        # Also try to load from ~/.ssh/config
        self._load_ssh_config()
    
    def _load_ssh_config(self):
        """Parse ~/.ssh/config for additional hosts"""
        ssh_config = Path.home() / ".ssh" / "config"
        if not ssh_config.exists():
            return
        
        try:
            current_host = None
            with open(ssh_config) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    
                    parts = line.split(None, 1)
                    if len(parts) != 2:
                        continue
                    
                    key, value = parts[0].lower(), parts[1]
                    
                    if key == "host":
                        # Skip wildcards
                        if "*" in value or "?" in value:
                            current_host = None
                            continue
                        
                        host_name = value
                        if host_name not in self._hosts:
                            current_host = SSHHost(name=host_name, hostname=host_name)
                            self._hosts[host_name] = current_host
                        else:
                            current_host = self._hosts[host_name]
                    
                    elif current_host:
                        if key == "hostname":
                            current_host.hostname = value
                        elif key == "port":
                            current_host.port = int(value)
                        elif key == "user":
                            current_host.username = value
                        elif key == "identityfile":
                            current_host.identity_file = Path(value).expanduser()
                        elif key == "proxyjump":
                            current_host.jump_host = value
                        elif key == "forwardagent" and value.lower() == "yes":
                            current_host.forward_agent = True
                        elif key == "compression" and value.lower() == "yes":
                            current_host.compression = True
                        elif key == "serveraliveinterval":
                            current_host.keep_alive = int(value)
                        elif key == "connecttimeout":
                            current_host.connect_timeout = int(value)
                        else:
                            current_host.options[key] = value
        except Exception as e:
            print(f"Warning: Could not parse SSH config: {e}")
    
    def _save_hosts(self):
        """Save hosts to configuration file"""
        data = {
            "hosts": [host.to_dict() for host in self._hosts.values()],
            "updated_at": datetime.utcnow().isoformat(),
        }
        self.hosts_file.write_text(json.dumps(data, indent=2))
    
    def add_host(self, host: SSHHost) -> SSHHost:
        """
        Add or update an SSH host
        
        Args:
            host: SSHHost configuration
            
        Returns:
            The added host
        """
        self._hosts[host.name] = host
        self._save_hosts()
        return host
    
    def remove_host(self, name: str) -> bool:
        """
        Remove an SSH host
        
        Args:
            name: Host name
            
        Returns:
            True if removed, False if not found
        """
        if name in self._hosts:
            # Disconnect if connected
            self.disconnect(name)
            del self._hosts[name]
            self._save_hosts()
            return True
        return False
    
    def get_host(self, name: str) -> Optional[SSHHost]:
        """Get host by name"""
        return self._hosts.get(name)
    
    def list_hosts(self, tag: Optional[str] = None) -> List[SSHHost]:
        """
        List all hosts, optionally filtered by tag
        
        Args:
            tag: Optional tag to filter by
            
        Returns:
            List of SSHHost objects
        """
        hosts = list(self._hosts.values())
        if tag:
            hosts = [h for h in hosts if tag in h.tags]
        return hosts
    
    def test_connection(self, name: str) -> Tuple[bool, str]:
        """
        Test SSH connection to a host
        
        Args:
            name: Host name
            
        Returns:
            Tuple of (success, message)
        """
        host = self.get_host(name)
        if not host:
            return False, f"Host '{name}' not found"
        
        try:
            cmd = host.get_ssh_command() + ["-o", "BatchMode=yes", "echo", "OK"]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=host.connect_timeout,
            )
            
            if result.returncode == 0:
                return True, "Connection successful"
            else:
                return False, result.stderr.strip() or "Connection failed"
        
        except subprocess.TimeoutExpired:
            return False, "Connection timeout"
        except Exception as e:
            return False, str(e)
    
    def execute(
        self,
        host_name: str,
        command: str,
        timeout: Optional[int] = None,
        capture: bool = True,
    ) -> CommandResult:
        """
        Execute a command on a remote host
        
        Args:
            host_name: Name of the host
            command: Command to execute
            timeout: Optional timeout in seconds
            capture: Whether to capture output
            
        Returns:
            CommandResult object
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        start_time = datetime.utcnow()
        
        try:
            ssh_cmd = host.get_ssh_command() + [command]
            
            result = subprocess.run(
                ssh_cmd,
                capture_output=capture,
                text=True,
                timeout=timeout or 300,
            )
            
            duration = (datetime.utcnow() - start_time).total_seconds()
            
            return CommandResult(
                command=command,
                host=host_name,
                exit_code=result.returncode,
                stdout=result.stdout if capture else "",
                stderr=result.stderr if capture else "",
                duration=duration,
            )
        
        except subprocess.TimeoutExpired:
            duration = (datetime.utcnow() - start_time).total_seconds()
            return CommandResult(
                command=command,
                host=host_name,
                exit_code=-1,
                stdout="",
                stderr="Command timed out",
                duration=duration,
            )
        except Exception as e:
            duration = (datetime.utcnow() - start_time).total_seconds()
            return CommandResult(
                command=command,
                host=host_name,
                exit_code=-1,
                stdout="",
                stderr=str(e),
                duration=duration,
            )
    
    def execute_multi(
        self,
        host_names: List[str],
        command: str,
        parallel: bool = True,
    ) -> Dict[str, CommandResult]:
        """
        Execute command on multiple hosts
        
        Args:
            host_names: List of host names
            command: Command to execute
            parallel: Execute in parallel (default True)
            
        Returns:
            Dict mapping host names to CommandResults
        """
        results = {}
        
        if parallel:
            threads = []
            results_lock = threading.Lock()
            
            def run_on_host(name):
                result = self.execute(name, command)
                with results_lock:
                    results[name] = result
            
            for name in host_names:
                t = threading.Thread(target=run_on_host, args=(name,))
                t.start()
                threads.append(t)
            
            for t in threads:
                t.join()
        else:
            for name in host_names:
                results[name] = self.execute(name, command)
        
        return results
    
    def create_tunnel(
        self,
        host_name: str,
        local_port: int,
        remote_port: int,
        remote_host: str = "localhost",
        bind_address: str = "127.0.0.1",
    ) -> bool:
        """
        Create an SSH tunnel (local port forwarding)
        
        Args:
            host_name: SSH host name
            local_port: Local port to bind
            remote_port: Remote port to forward to
            remote_host: Remote host (default localhost)
            bind_address: Local bind address
            
        Returns:
            True if tunnel created successfully
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        tunnel_key = f"{host_name}:{local_port}"
        
        # Close existing tunnel if any
        if tunnel_key in self._tunnels:
            self._tunnels[tunnel_key].terminate()
        
        ssh_cmd = host.get_ssh_command()
        ssh_cmd.extend([
            "-N",  # No remote command
            "-L", f"{bind_address}:{local_port}:{remote_host}:{remote_port}",
        ])
        
        try:
            process = subprocess.Popen(
                ssh_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            
            # Wait briefly to check if it started
            try:
                process.wait(timeout=1)
                # If we get here, process exited early (error)
                stderr = process.stderr.read().decode() if process.stderr else ""
                print(f"Tunnel failed: {stderr}")
                return False
            except subprocess.TimeoutExpired:
                # Process is still running - tunnel is active
                self._tunnels[tunnel_key] = process
                print(f"✅ Tunnel created: localhost:{local_port} → {host_name}:{remote_port}")
                return True
        
        except Exception as e:
            print(f"Failed to create tunnel: {e}")
            return False
    
    def create_reverse_tunnel(
        self,
        host_name: str,
        remote_port: int,
        local_port: int,
        local_host: str = "localhost",
        bind_address: str = "127.0.0.1",
    ) -> bool:
        """
        Create a reverse SSH tunnel (remote port forwarding)
        
        Args:
            host_name: SSH host name
            remote_port: Remote port to bind on server
            local_port: Local port to forward to
            local_host: Local host (default localhost)
            bind_address: Remote bind address
            
        Returns:
            True if tunnel created successfully
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        tunnel_key = f"{host_name}:R{remote_port}"
        
        if tunnel_key in self._tunnels:
            self._tunnels[tunnel_key].terminate()
        
        ssh_cmd = host.get_ssh_command()
        ssh_cmd.extend([
            "-N",
            "-R", f"{bind_address}:{remote_port}:{local_host}:{local_port}",
        ])
        
        try:
            process = subprocess.Popen(
                ssh_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            
            try:
                process.wait(timeout=1)
                return False
            except subprocess.TimeoutExpired:
                self._tunnels[tunnel_key] = process
                print(f"✅ Reverse tunnel: {host_name}:{remote_port} → localhost:{local_port}")
                return True
        
        except Exception as e:
            print(f"Failed to create reverse tunnel: {e}")
            return False
    
    def close_tunnel(self, host_name: str, port: int) -> bool:
        """Close an SSH tunnel"""
        tunnel_key = f"{host_name}:{port}"
        if tunnel_key in self._tunnels:
            self._tunnels[tunnel_key].terminate()
            del self._tunnels[tunnel_key]
            return True
        return False
    
    def list_tunnels(self) -> List[Dict[str, Any]]:
        """List active tunnels"""
        tunnels = []
        for key, process in self._tunnels.items():
            if process.poll() is None:  # Still running
                host, port = key.split(":", 1)
                tunnels.append({
                    "host": host,
                    "port": port,
                    "pid": process.pid,
                    "status": "active",
                })
            else:
                tunnels.append({
                    "host": key.split(":")[0],
                    "port": key.split(":")[1],
                    "status": "closed",
                })
        return tunnels
    
    def upload(
        self,
        host_name: str,
        local_path: Union[str, Path],
        remote_path: str,
        recursive: bool = False,
    ) -> bool:
        """
        Upload file(s) to remote host using SCP
        
        Args:
            host_name: SSH host name
            local_path: Local file or directory path
            remote_path: Remote destination path
            recursive: Upload directory recursively
            
        Returns:
            True if successful
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        local_path = Path(local_path)
        if not local_path.exists():
            raise FileNotFoundError(f"Local path not found: {local_path}")
        
        scp_cmd = ["scp"]
        
        if recursive or local_path.is_dir():
            scp_cmd.append("-r")
        
        if host.port != 22:
            scp_cmd.extend(["-P", str(host.port)])
        
        if host.identity_file or host.key_file:
            key = host.identity_file or host.key_file
            scp_cmd.extend(["-i", str(key)])
        
        if host.compression:
            scp_cmd.append("-C")
        
        # Source
        scp_cmd.append(str(local_path))
        
        # Destination
        if host.username:
            scp_cmd.append(f"{host.username}@{host.hostname}:{remote_path}")
        else:
            scp_cmd.append(f"{host.hostname}:{remote_path}")
        
        try:
            result = subprocess.run(scp_cmd, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Uploaded {local_path} to {host_name}:{remote_path}")
                return True
            else:
                print(f"❌ Upload failed: {result.stderr}")
                return False
        except Exception as e:
            print(f"❌ Upload error: {e}")
            return False
    
    def download(
        self,
        host_name: str,
        remote_path: str,
        local_path: Union[str, Path],
        recursive: bool = False,
    ) -> bool:
        """
        Download file(s) from remote host using SCP
        
        Args:
            host_name: SSH host name
            remote_path: Remote file or directory path
            local_path: Local destination path
            recursive: Download directory recursively
            
        Returns:
            True if successful
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        local_path = Path(local_path)
        
        scp_cmd = ["scp"]
        
        if recursive:
            scp_cmd.append("-r")
        
        if host.port != 22:
            scp_cmd.extend(["-P", str(host.port)])
        
        if host.identity_file or host.key_file:
            key = host.identity_file or host.key_file
            scp_cmd.extend(["-i", str(key)])
        
        if host.compression:
            scp_cmd.append("-C")
        
        # Source
        if host.username:
            scp_cmd.append(f"{host.username}@{host.hostname}:{remote_path}")
        else:
            scp_cmd.append(f"{host.hostname}:{remote_path}")
        
        # Destination
        scp_cmd.append(str(local_path))
        
        try:
            result = subprocess.run(scp_cmd, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Downloaded {host_name}:{remote_path} to {local_path}")
                return True
            else:
                print(f"❌ Download failed: {result.stderr}")
                return False
        except Exception as e:
            print(f"❌ Download error: {e}")
            return False
    
    def connect_interactive(self, host_name: str):
        """
        Open interactive SSH session
        
        Args:
            host_name: SSH host name
        """
        host = self.get_host(host_name)
        if not host:
            raise ValueError(f"Host '{host_name}' not found")
        
        ssh_cmd = host.get_ssh_command()
        print(f"🔗 Connecting to {host_name}...")
        
        try:
            subprocess.run(ssh_cmd)
        except KeyboardInterrupt:
            print("\n👋 Disconnected")
    
    def disconnect(self, host_name: str):
        """Close any active connections/tunnels to a host"""
        # Close tunnels
        to_close = [k for k in self._tunnels.keys() if k.startswith(f"{host_name}:")]
        for key in to_close:
            self._tunnels[key].terminate()
            del self._tunnels[key]
        
        # Remove from connections
        if host_name in self._connections:
            del self._connections[host_name]
    
    def disconnect_all(self):
        """Close all connections and tunnels"""
        for process in self._tunnels.values():
            try:
                process.terminate()
            except Exception:
                pass
        self._tunnels.clear()
        self._connections.clear()


# Convenience function
def get_router() -> SSHRouter:
    """Get the default SSH router instance"""
    return SSHRouter()
