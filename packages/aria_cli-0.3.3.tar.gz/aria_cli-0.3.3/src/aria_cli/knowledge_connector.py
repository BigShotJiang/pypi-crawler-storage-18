"""
Knowledge Connector for ARIA CLI v0.2.0

SQLite-based knowledge base integration from v0.1.0, enhanced for v0.2.0:
- ultra_knowledge.db (G10, Q38, concepts, patterns)
- Integration with Q38 cluster
- File exploration
- Chat processing

Ported from v0.1.0 ARIAConnector with Q38 integration.
"""

import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

from .q_system import QSystem, QOperator


@dataclass
class KnowledgeResult:
    """Result from knowledge base query"""
    concept: str
    type: str
    file: str
    path: str
    category: str = ""
    q_tier: Optional[int] = None
    layer: Optional[int] = None  # Q-layer (0-38)
    direction: Optional[str] = None  # Q38 direction
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'concept': self.concept,
            'type': self.type,
            'file': self.file,
            'path': self.path,
            'category': self.category,
            'q_tier': self.q_tier,
            'layer': self.layer,
            'direction': self.direction,
        }


class KnowledgeConnector:
    """
    Connector to ARIA's SQLite knowledge bases
    
    Provides access to:
    - ultra_knowledge.db (G10, Q38, concepts, patterns)
    - File exploration
    - Chat processing from aria_interface.py
    - Q38 cluster integration
    
    Usage:
        kb = KnowledgeConnector()
        
        # Query G10 concepts
        results = kb.query_g10("trading")
        
        # Query Q38/Quantum concepts
        results = kb.query_q38("compression")
        
        # Get stats
        stats = kb.get_stats()
        
        # Process chat message
        response = kb.process_chat("show me G10 systems")
    """
    
    # Default knowledge base paths
    DEFAULT_DB_PATHS = [
        Path.home() / 'ultra_knowledge.db',
        Path.home() / 'OneDrive' / 'ultra_knowledge.db',
        Path('ultra_knowledge.db'),
    ]
    
    def __init__(
        self,
        db_path: Optional[Path] = None,
        q_system: Optional[QSystem] = None,
        q38_connector: Optional[Any] = None,
    ):
        """
        Initialize Knowledge Connector
        
        Args:
            db_path: Path to ultra_knowledge.db (auto-detected if not provided)
            q_system: Q-System instance to integrate with
            q38_connector: Q38Connector for cluster integration
        """
        self.db_path = db_path or self._find_db()
        self.q_system = q_system
        self.q38_connector = q38_connector
        self.connection: Optional[sqlite3.Connection] = None
        
        # Try to connect
        if self.db_path and self.db_path.exists():
            self._connect()
            if self.q_system:
                self._setup_handlers()
    
    def _find_db(self) -> Optional[Path]:
        """Find knowledge database"""
        for path in self.DEFAULT_DB_PATHS:
            if path.exists():
                return path
        return None
    
    def _connect(self):
        """Connect to knowledge database"""
        try:
            self.connection = sqlite3.connect(str(self.db_path))
            self.connection.row_factory = sqlite3.Row
        except Exception as e:
            print(f"Warning: Could not connect to {self.db_path}: {e}")
    
    def _setup_handlers(self):
        """Setup Q-System handlers for knowledge queries"""
        if not self.q_system:
            return
        
        def search_handler(cmd):
            query = cmd.payload.get('query', cmd.payload.get('text', ''))
            category = cmd.payload.get('category', 'all')
            limit = cmd.payload.get('limit', 20)
            
            if category == 'g10':
                results = self.query_g10(query, limit)
            elif category == 'q38' or category == 'quantum':
                results = self.query_q38(query, limit)
            else:
                results = self.query_all(query, limit)
            
            return {
                'query': query,
                'category': category,
                'count': len(results),
                'results': [r.to_dict() for r in results]
            }
        
        self.q_system.register_handler(QOperator.SEARCH, search_handler)
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to database"""
        return self.connection is not None
    
    def query_g10(self, search: str = "", limit: int = 20) -> List[KnowledgeResult]:
        """
        Query G10 infrastructure concepts
        
        Args:
            search: Search term
            limit: Max results
            
        Returns:
            List of KnowledgeResult
        """
        if not self.is_connected:
            return []
        
        try:
            cursor = self.connection.cursor()
            
            if search:
                query = """
                SELECT concept, type, file, path 
                FROM u_concepts 
                WHERE category LIKE '%G10%' 
                AND (concept LIKE ? OR file LIKE ? OR type LIKE ?)
                LIMIT ?
                """
                cursor.execute(query, (f'%{search}%', f'%{search}%', f'%{search}%', limit))
            else:
                query = """
                SELECT concept, type, file, path 
                FROM u_concepts 
                WHERE category LIKE '%G10%'
                LIMIT ?
                """
                cursor.execute(query, (limit,))
            
            results = []
            for row in cursor.fetchall():
                results.append(KnowledgeResult(
                    concept=row['concept'],
                    type=row['type'],
                    file=row['file'],
                    path=row['path'],
                    category='G10'
                ))
            
            return results
            
        except Exception as e:
            print(f"G10 query error: {e}")
            return []
    
    def query_q38(self, search: str = "", limit: int = 20) -> List[KnowledgeResult]:
        """
        Query Q38/Quantum concepts
        
        Args:
            search: Search term
            limit: Max results
            
        Returns:
            List of KnowledgeResult with Q-tier info
        """
        if not self.is_connected:
            return []
        
        try:
            cursor = self.connection.cursor()
            
            if search:
                query = """
                SELECT concept, type, file, path, q_tier
                FROM u_concepts 
                WHERE (category LIKE '%Q38%' OR category LIKE '%quantum%' OR q_tier IS NOT NULL)
                AND (concept LIKE ? OR file LIKE ? OR type LIKE ?)
                LIMIT ?
                """
                cursor.execute(query, (f'%{search}%', f'%{search}%', f'%{search}%', limit))
            else:
                query = """
                SELECT concept, type, file, path, q_tier
                FROM u_concepts 
                WHERE category LIKE '%Q38%' OR category LIKE '%quantum%' OR q_tier IS NOT NULL
                LIMIT ?
                """
                cursor.execute(query, (limit,))
            
            results = []
            for row in cursor.fetchall():
                q_tier = row['q_tier'] if 'q_tier' in row.keys() else None
                results.append(KnowledgeResult(
                    concept=row['concept'],
                    type=row['type'],
                    file=row['file'],
                    path=row['path'],
                    category='Q38',
                    q_tier=q_tier,
                    layer=q_tier,  # Map q_tier to layer
                ))
            
            return results
            
        except Exception as e:
            print(f"Q38 query error: {e}")
            return []
    
    def query_all(self, search: str, limit: int = 20) -> List[KnowledgeResult]:
        """
        Query all concepts
        
        Args:
            search: Search term
            limit: Max results
            
        Returns:
            List of KnowledgeResult
        """
        if not self.is_connected:
            return []
        
        try:
            cursor = self.connection.cursor()
            
            query = """
            SELECT concept, type, file, path, category
            FROM u_concepts 
            WHERE concept LIKE ? OR file LIKE ? OR type LIKE ? OR category LIKE ?
            LIMIT ?
            """
            cursor.execute(query, (f'%{search}%', f'%{search}%', f'%{search}%', f'%{search}%', limit))
            
            results = []
            for row in cursor.fetchall():
                results.append(KnowledgeResult(
                    concept=row['concept'],
                    type=row['type'],
                    file=row['file'],
                    path=row['path'],
                    category=row['category']
                ))
            
            return results
            
        except Exception as e:
            print(f"Query error: {e}")
            return []
    
    def query_by_layer(self, layer: int, limit: int = 20) -> List[KnowledgeResult]:
        """
        Query concepts by Q-layer (0-38)
        
        Args:
            layer: Q-layer number
            limit: Max results
            
        Returns:
            List of KnowledgeResult at that layer
        """
        if not self.is_connected:
            return []
        
        try:
            cursor = self.connection.cursor()
            
            query = """
            SELECT concept, type, file, path, category, q_tier
            FROM u_concepts 
            WHERE q_tier = ?
            LIMIT ?
            """
            cursor.execute(query, (layer, limit))
            
            results = []
            for row in cursor.fetchall():
                results.append(KnowledgeResult(
                    concept=row['concept'],
                    type=row['type'],
                    file=row['file'],
                    path=row['path'],
                    category=row['category'],
                    q_tier=row['q_tier'],
                    layer=layer,
                ))
            
            return results
            
        except Exception as e:
            print(f"Layer query error: {e}")
            return []
    
    def get_stats(self) -> Dict[str, Any]:
        """Get knowledge base statistics"""
        if not self.is_connected:
            return {'connected': False, 'path': str(self.db_path) if self.db_path else None}
        
        try:
            cursor = self.connection.cursor()
            
            stats = {'connected': True, 'path': str(self.db_path)}
            
            # Count tables
            for table in ['u_files', 'u_concepts', 'u_patterns', 'aria_memories']:
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    stats[table] = cursor.fetchone()[0]
                except:
                    stats[table] = 0
            
            # G10 count
            try:
                cursor.execute("SELECT COUNT(*) FROM u_concepts WHERE category LIKE '%G10%'")
                stats['g10'] = cursor.fetchone()[0]
            except:
                stats['g10'] = 0
            
            # Q38 count
            try:
                cursor.execute("SELECT COUNT(*) FROM u_concepts WHERE category LIKE '%Q38%' OR q_tier IS NOT NULL")
                stats['q38'] = cursor.fetchone()[0]
            except:
                stats['q38'] = 0
            
            # Layer distribution
            try:
                cursor.execute("""
                    SELECT q_tier, COUNT(*) as count 
                    FROM u_concepts 
                    WHERE q_tier IS NOT NULL 
                    GROUP BY q_tier 
                    ORDER BY q_tier
                """)
                stats['layer_distribution'] = {row[0]: row[1] for row in cursor.fetchall()}
            except:
                stats['layer_distribution'] = {}
            
            # Q38 cluster status (if available)
            if self.q38_connector:
                stats['q38_cluster'] = {
                    'available': self.q38_connector.available,
                    'directions': len(self.q38_connector.directions) if hasattr(self.q38_connector, 'directions') else 0,
                }
            
            return stats
            
        except Exception as e:
            return {'connected': True, 'error': str(e)}
    
    def process_chat(self, message: str) -> str:
        """
        Process chat message (ported from aria_interface.py)
        
        This replicates the chat processing logic from the GUI version.
        
        Args:
            message: User message
            
        Returns:
            Response string
        """
        msg_lower = message.lower()
        
        # G10 queries
        if "g10" in msg_lower:
            search = message.replace("g10", "").replace("G10", "").strip()
            results = self.query_g10(search if search else "", limit=10)
            if results:
                response = f"Found {len(results)} G10 results:\n\n"
                for r in results:
                    response += f"• {r.concept}\n  File: {r.file}\n"
                return response
            return "No G10 results found for that query."
        
        # Q38/Quantum queries
        if "quantum" in msg_lower or "q38" in msg_lower:
            search = message.replace("quantum", "").replace("Q38", "").replace("q38", "").strip()
            results = self.query_q38(search if search else "", limit=10)
            if results:
                response = f"Found {len(results)} Q38/Quantum results:\n\n"
                for r in results:
                    tier = f"[Q{r.q_tier}]" if r.q_tier else ""
                    response += f"• {r.concept} {tier}\n  File: {r.file}\n"
                return response
            return "No Q38/Quantum results found."
        
        # Layer queries (Q0-Q38)
        import re
        layer_match = re.search(r'\bq(\d{1,2})\b', msg_lower)
        if layer_match:
            layer = int(layer_match.group(1))
            if 0 <= layer <= 38:
                results = self.query_by_layer(layer, limit=10)
                if results:
                    response = f"Found {len(results)} concepts at Q{layer}:\n\n"
                    for r in results:
                        response += f"• {r.concept}\n  File: {r.file}\n"
                    return response
                return f"No concepts found at layer Q{layer}."
        
        # Stats
        if "stats" in msg_lower or "status" in msg_lower:
            stats = self.get_stats()
            if stats.get('connected'):
                response = f"""Knowledge Base Stats:
📁 Files: {stats.get('u_files', 0):,}
💡 Concepts: {stats.get('u_concepts', 0):,}
🔄 Patterns: {stats.get('u_patterns', 0):,}
📡 G10 Concepts: {stats.get('g10', 0):,}
⚛️ Q38/Quantum: {stats.get('q38', 0):,}
"""
                if stats.get('q38_cluster'):
                    cluster = stats['q38_cluster']
                    response += f"""
🌐 Q38 Cluster: {'✅ Online' if cluster.get('available') else '⚠️ Offline'}
🧭 Directions: {cluster.get('directions', 0)}
"""
                response += "\nAll systems operational! 💜"
                return response
            else:
                return f"Knowledge base not connected: {stats.get('path')}"
        
        # Search anything
        if "find" in msg_lower or "search" in msg_lower:
            search = message.replace("find", "").replace("search", "").strip()
            results = self.query_all(search, limit=15)
            if results:
                response = f"Found {len(results)} results for '{search}':\n\n"
                for r in results:
                    response += f"• {r.concept} ({r.type})\n  {r.file} [{r.category}]\n"
                return response
            return f"No results found for '{search}'."
        
        # Q38 cluster commands (if connected)
        if self.q38_connector and self.q38_connector.available:
            if "directions" in msg_lower or "direction" in msg_lower:
                dirs = self.q38_connector.get_all_directions()
                return f"Q38 64-Direction System:\n" + "\n".join(f"  {i}: {d}" for i, d in enumerate(dirs[:16])) + "\n  ... and {len(dirs)-16} more"
        
        # Default response
        stats = self.get_stats()
        concept_count = stats.get('u_concepts', 0)
        return f"""I understand you said: "{message}"

Here are some things you can ask me:
• "Show me G10 trading systems"
• "Search quantum processors"
• "Find compression algorithms"
• "Show Q10 concepts" (any layer Q0-Q38)
• "Show stats"

I have access to {concept_count:,} concepts! 💜"""
    
    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            self.connection = None
    
    def __del__(self):
        """Cleanup on deletion"""
        self.close()


# Legacy alias for v0.1.0 compatibility
ARIAConnector = KnowledgeConnector


def create_connector(db_path: Path = None) -> KnowledgeConnector:
    """Factory function to create knowledge connector"""
    return KnowledgeConnector(db_path=db_path)
