"""
Q38 Connector for ARIA CLI v0.2.0

Native integration with the Q38 Database system - your own AI processing:
- Direction nodes (64 directions)
- QSAID framework
- Sync layer coordination
- Layer 1 Core / Layer 2 Ported databases

This is the PRIMARY backend for ARIA - connecting to your local Q38 cluster.
"""

import os
import json
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from pathlib import Path
import time


@dataclass
class Q38Config:
    """Configuration for Q38 Database connection"""
    # API settings
    api_url: str = "http://localhost:8080"
    sync_port: int = 9000
    api_key: Optional[str] = None
    
    # Cluster settings
    base_port: int = 8200
    node_count: int = 8
    
    # Processing settings
    default_layer: int = 8
    timeout: float = 30.0
    
    # Paths
    config_dir: Path = field(default_factory=lambda: Path("direction_configs"))
    db_path: Path = field(default_factory=lambda: Path("q38_database"))
    
    def __post_init__(self):
        # Load API key from file if exists
        api_key_file = Path(".q38_api_key")
        if api_key_file.exists() and not self.api_key:
            self.api_key = api_key_file.read_text().strip()
        
        # Check environment
        if os.environ.get("Q38_API_URL"):
            self.api_url = os.environ["Q38_API_URL"]
        if os.environ.get("Q38_SYNC_PORT"):
            self.sync_port = int(os.environ["Q38_SYNC_PORT"])
        if os.environ.get("Q38_BASE_PORT"):
            self.base_port = int(os.environ["Q38_BASE_PORT"])


@dataclass
class Q38Response:
    """Response from Q38 system processing"""
    direction: str
    value: Any
    layer: int
    sync_status: str
    timestamp: float = field(default_factory=time.time)
    trace: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_text(self) -> str:
        """Convert response to readable text"""
        if isinstance(self.value, str):
            return self.value
        elif isinstance(self.value, dict):
            if "text" in self.value:
                return self.value["text"]
            if "response" in self.value:
                return self.value["response"]
            if "result" in self.value:
                return str(self.value["result"])
        return json.dumps(self.value, indent=2, default=str)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "direction": self.direction,
            "value": self.value,
            "layer": self.layer,
            "sync_status": self.sync_status,
            "timestamp": self.timestamp,
            "trace": self.trace,
            "metadata": self.metadata,
        }


class Q38Connector:
    """
    Connector to the Q38 Database System
    
    Your native AI processing system using:
    - 64 direction nodes for distributed processing
    - QSAID framework for structured reasoning
    - Sync layer for coherence
    - Q0-Q38 cognitive layers
    
    Usage:
        q38 = Q38Connector()
        
        # Check if cluster is available
        if q38.available:
            response = q38.process("analyze this text")
            print(response.to_text())
        
        # Update a direction node
        q38.update_direction("a005625", {"value": 42})
        
        # Get cluster status
        status = q38.get_cluster_status()
    """
    
    def __init__(self, config: Optional[Q38Config] = None):
        """
        Initialize Q38 Connector
        
        Args:
            config: Q38 configuration (auto-detected if not provided)
        """
        self.config = config or Q38Config()
        self._available = False
        self._cluster_info: Dict[str, Any] = {}
        self._directions = self._init_directions()
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._check_availability()
    
    def _init_directions(self) -> List[str]:
        """Initialize the 64 direction names"""
        return [
            # Layer 1 Core (8 primary)
            "a000000", "a001125", "a002250", "a003375",
            "a004500", "a005625", "a006750", "a007875",
            # Layer 1 Core (8 secondary)
            "b000000", "b001125", "b002250", "b003375",
            "b004500", "b005625", "b006750", "b007875",
            # Layer 2 Ported (16 directions)
            "c000000", "c000563", "c001125", "c001688",
            "c002250", "c002813", "c003375", "c003938",
            "c004500", "c005063", "c005625", "c006188",
            "c006750", "c007313", "c007875", "c008438",
            # Ported extensions (32 directions)
            "d000000", "d000281", "d000563", "d000844",
            "d001125", "d001406", "d001688", "d001969",
            "d002250", "d002531", "d002813", "d003094",
            "d003375", "d003656", "d003938", "d004219",
            "d004500", "d004781", "d005063", "d005344",
            "d005625", "d005906", "d006188", "d006469",
            "d006750", "d007031", "d007313", "d007594",
            "d007875", "d008156", "d008438", "d008719",
        ]
    
    @property
    def directions(self) -> List[str]:
        """Get list of all 64 directions"""
        return self._directions
    
    @property
    def nodes(self) -> Dict[str, Dict[str, Any]]:
        """Get node information (lazy-loaded)"""
        if not self._nodes:
            for i, direction in enumerate(self._directions):
                self._nodes[direction] = {
                    "port": self.config.base_port + i,
                    "direction": direction,
                    "active": False,  # Will be updated by health check
                }
        return self._nodes
    
    def get_all_directions(self) -> List[str]:
        """Get all 64 direction names"""
        return self._directions
    
    def _check_availability(self):
        """Check if Q38 cluster is running"""
        try:
            import requests
            
            # Try main API
            resp = requests.get(
                f"{self.config.api_url}/cluster/status",
                headers=self._headers(),
                timeout=2
            )
            if resp.status_code == 200:
                self._available = True
                self._cluster_info = resp.json()
                return
        except Exception:
            pass
        
        # Try sync layer directly
        try:
            import requests
            resp = requests.get(
                f"http://localhost:{self.config.sync_port}/status",
                timeout=2
            )
            if resp.status_code == 200:
                self._available = True
                self._cluster_info = {"sync_layer": "active"}
                return
        except Exception:
            pass
        
        # Try first direction node
        try:
            import requests
            resp = requests.get(
                f"http://localhost:{self.config.base_port}/status",
                timeout=2
            )
            if resp.status_code == 200:
                self._available = True
                self._cluster_info = {"node_0": "active"}
                return
        except Exception:
            pass
        
        self._available = False
    
    def _headers(self) -> Dict[str, str]:
        """Get API headers"""
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers
    
    @property
    def available(self) -> bool:
        """Check if Q38 cluster is available"""
        return self._available
    
    @property
    def cluster_info(self) -> Dict[str, Any]:
        """Get cached cluster info"""
        return self._cluster_info
    
    def process(
        self,
        input_text: str,
        direction: Optional[str] = None,
        layer: Optional[int] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Q38Response:
        """
        Process input through Q38 system
        
        Args:
            input_text: Text to process
            direction: Specific direction to use (e.g., 'a005625')
            layer: Q-layer (0-38), defaults to config.default_layer
            context: Additional context dictionary
            
        Returns:
            Q38Response with processing results
        """
        layer = layer or self.config.default_layer
        context = context or {}
        
        payload = {
            "input": input_text,
            "layer": layer,
            "context": context,
        }
        if direction:
            payload["direction"] = direction
        
        # Try main API
        try:
            import requests
            resp = requests.post(
                f"{self.config.api_url}/process",
                json=payload,
                headers=self._headers(),
                timeout=self.config.timeout
            )
            
            if resp.status_code == 200:
                data = resp.json()
                return Q38Response(
                    direction=data.get("direction", direction or "auto"),
                    value=data.get("value", data.get("result", data)),
                    layer=data.get("layer", layer),
                    sync_status=data.get("sync_status", "ok"),
                    trace=data.get("trace", []),
                    metadata=data.get("metadata", {}),
                )
        except Exception as e:
            pass
        
        # Try sync layer
        try:
            import requests
            resp = requests.post(
                f"http://localhost:{self.config.sync_port}/sync",
                json=payload,
                timeout=self.config.timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                return Q38Response(
                    direction="sync",
                    value=data,
                    layer=layer,
                    sync_status="synced",
                )
        except Exception:
            pass
        
        # Local fallback using Q-System
        return self._local_process(input_text, layer, context)
    
    def _local_process(
        self,
        input_text: str,
        layer: int,
        context: Dict[str, Any]
    ) -> Q38Response:
        """Local processing when cluster is offline"""
        try:
            from .q_system import QSystem, QCommand, QOperator, QLayer
            
            q = QSystem()
            cmd = QCommand(
                operator=QOperator.ASK,
                payload={"input": input_text, "context": context},
                layer=QLayer(min(layer, 38)),
            )
            result = q.execute(cmd)
            
            return Q38Response(
                direction="local",
                value=result,
                layer=layer,
                sync_status="offline",
                trace=result.get("processing", {}).get("trace", []),
            )
        except Exception as e:
            return Q38Response(
                direction="error",
                value={"error": str(e), "input": input_text},
                layer=layer,
                sync_status="error",
            )
    
    def update_direction(
        self,
        direction: str,
        value: Any,
        port: Optional[int] = None
    ) -> bool:
        """
        Update a specific direction node
        
        Args:
            direction: Direction identifier (e.g., 'a005625')
            value: Value to update
            port: Specific port (auto-calculated if not provided)
            
        Returns:
            True if update succeeded
        """
        import requests
        
        port = port or self.config.base_port
        
        try:
            resp = requests.post(
                f"http://localhost:{port}/update",
                json={"value": value, "direction": direction},
                timeout=5
            )
            return resp.status_code == 200
        except Exception:
            return False
    
    def get_direction_status(self, port: int) -> Optional[Dict[str, Any]]:
        """Get status of a specific direction node"""
        import requests
        
        try:
            resp = requests.get(
                f"http://localhost:{port}/status",
                timeout=2
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None
    
    def get_cluster_status(self) -> Dict[str, Any]:
        """Get full cluster status"""
        self._check_availability()
        
        status = {
            "available": self._available,
            "api_url": self.config.api_url,
            "sync_port": self.config.sync_port,
            "base_port": self.config.base_port,
            "cluster_info": self._cluster_info,
        }
        
        # Check individual nodes
        nodes = []
        for i in range(self.config.node_count):
            port = self.config.base_port + i
            node_status = self.get_direction_status(port)
            nodes.append({
                "port": port,
                "status": "active" if node_status else "offline",
                "data": node_status,
            })
        status["nodes"] = nodes
        
        return status
    
    async def check_cluster_health(self) -> Dict[str, Any]:
        """Async wrapper for cluster health check"""
        return self.get_cluster_status()
    
    async def direction_query(self, direction: str, query: str) -> Dict[str, Any]:
        """
        Async query to a specific direction
        
        Args:
            direction: Direction identifier
            query: Query text
            
        Returns:
            Response dictionary
        """
        response = self.process(query, direction=direction)
        return response.to_dict()
    
    async def sync_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Async broadcast sync event to cluster
        
        Args:
            event: Event data to broadcast
            
        Returns:
            Sync result
        """
        import requests
        
        try:
            resp = requests.post(
                f"http://localhost:{self.config.sync_port}/sync",
                json=event,
                timeout=5
            )
            if resp.status_code == 200:
                return resp.json()
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def init_cluster(
        self,
        node_count: Optional[int] = None,
        base_port: Optional[int] = None,
        sync_port: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Initialize Q38 cluster
        
        Args:
            node_count: Number of direction nodes
            base_port: Starting port for nodes
            sync_port: Sync layer port
            
        Returns:
            Initialization result
        """
        import requests
        
        payload = {
            "node_count": node_count or self.config.node_count,
            "base_port": base_port or self.config.base_port,
            "sync_port": sync_port or self.config.sync_port,
        }
        
        try:
            resp = requests.post(
                f"{self.config.api_url}/cluster/init",
                json=payload,
                headers=self._headers(),
                timeout=30
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            return {"error": str(e)}
        
        return {"error": "Failed to initialize cluster"}
    
    def scale_cluster(self, increment: int) -> Dict[str, Any]:
        """
        Scale cluster by adding nodes
        
        Args:
            increment: Number of nodes to add
            
        Returns:
            Scaling result
        """
        import requests
        
        payload = {
            "increment": increment,
            "base_port": self.config.base_port,
            "sync_port": self.config.sync_port,
        }
        
        try:
            resp = requests.post(
                f"{self.config.api_url}/cluster/scale",
                json=payload,
                headers=self._headers(),
                timeout=30
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            return {"error": str(e)}
        
        return {"error": "Failed to scale cluster"}


class QSAIDProcessor:
    """
    QSAID Framework Processor
    
    Structured reasoning using QSAID methodology on top of Q38.
    """
    
    def __init__(self, q38: Optional[Q38Connector] = None):
        """
        Initialize QSAID Processor
        
        Args:
            q38: Q38 connector (creates new one if not provided)
        """
        self.q38 = q38 or Q38Connector()
    
    def query(
        self,
        question: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Q38Response:
        """
        Process a question through QSAID
        
        Args:
            question: Question to process
            context: Additional context
            
        Returns:
            Q38Response with answer
        """
        return self.q38.process(
            question,
            layer=10,  # Q10 LOGIC layer for questions
            context=context,
        )
    
    def analyze(
        self,
        data: Any,
        analysis_type: str = "general",
    ) -> Q38Response:
        """
        Analyze data through QSAID
        
        Args:
            data: Data to analyze
            analysis_type: Type of analysis
            
        Returns:
            Q38Response with analysis
        """
        context = {
            "analysis_type": analysis_type,
            "data_type": type(data).__name__,
        }
        
        input_text = json.dumps(data, default=str) if not isinstance(data, str) else data
        
        return self.q38.process(
            input_text,
            layer=17,  # Q17 EVALUATION layer
            context=context,
        )
    
    def synthesize(
        self,
        inputs: List[Any],
    ) -> Q38Response:
        """
        Synthesize multiple inputs into unified output
        
        Args:
            inputs: List of inputs to synthesize
            
        Returns:
            Q38Response with synthesis
        """
        context = {
            "input_count": len(inputs),
            "mode": "synthesis",
        }
        
        combined = "\n---\n".join(
            json.dumps(i, default=str) if not isinstance(i, str) else i
            for i in inputs
        )
        
        return self.q38.process(
            combined,
            layer=18,  # Q18 SYNTHESIS layer
            context=context,
        )


# Create singleton instance for easy access
_default_connector: Optional[Q38Connector] = None


def get_q38() -> Q38Connector:
    """Get the default Q38 connector (creates one if needed)"""
    global _default_connector
    if _default_connector is None:
        _default_connector = Q38Connector()
    return _default_connector


def process(input_text: str, layer: int = 8) -> Q38Response:
    """Convenience function to process through Q38"""
    return get_q38().process(input_text, layer=layer)
