"""
Authentication System for ARIA CLI v0.2.0

Provides secure login and session management:
- Local credential storage (encrypted)
- API key management
- Session tokens with expiry
- Multi-provider auth (GitHub, Google, API keys)
- Secure keyring integration
"""

import os
import json
import hashlib
import secrets
import base64
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
import getpass


class AuthProvider(Enum):
    """Supported authentication providers"""
    LOCAL = auto()       # Local username/password
    API_KEY = auto()     # API key authentication
    GITHUB = auto()      # GitHub OAuth
    GOOGLE = auto()      # Google OAuth
    SSH_KEY = auto()     # SSH key authentication
    TOKEN = auto()       # Bearer token


class AuthStatus(Enum):
    """Authentication status"""
    AUTHENTICATED = "authenticated"
    EXPIRED = "expired"
    INVALID = "invalid"
    NOT_AUTHENTICATED = "not_authenticated"
    MFA_REQUIRED = "mfa_required"


@dataclass
class User:
    """Authenticated user"""
    username: str
    provider: AuthProvider
    email: Optional[str] = None
    display_name: Optional[str] = None
    avatar_url: Optional[str] = None
    roles: List[str] = field(default_factory=lambda: ["user"])
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "username": self.username,
            "provider": self.provider.name,
            "email": self.email,
            "display_name": self.display_name,
            "avatar_url": self.avatar_url,
            "roles": self.roles,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'User':
        return cls(
            username=d["username"],
            provider=AuthProvider[d["provider"]],
            email=d.get("email"),
            display_name=d.get("display_name"),
            avatar_url=d.get("avatar_url"),
            roles=d.get("roles", ["user"]),
            metadata=d.get("metadata", {}),
            created_at=datetime.fromisoformat(d["created_at"]) if "created_at" in d else datetime.utcnow(),
        )
    
    def has_role(self, role: str) -> bool:
        return role in self.roles or "admin" in self.roles


@dataclass
class Session:
    """Authentication session"""
    token: str
    user: User
    expires_at: datetime
    created_at: datetime = field(default_factory=datetime.utcnow)
    refresh_token: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    
    @property
    def is_expired(self) -> bool:
        return datetime.utcnow() > self.expires_at
    
    @property
    def is_valid(self) -> bool:
        return not self.is_expired
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "token": self.token,
            "user": self.user.to_dict(),
            "expires_at": self.expires_at.isoformat(),
            "created_at": self.created_at.isoformat(),
            "refresh_token": self.refresh_token,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Session':
        return cls(
            token=d["token"],
            user=User.from_dict(d["user"]),
            expires_at=datetime.fromisoformat(d["expires_at"]),
            created_at=datetime.fromisoformat(d["created_at"]) if "created_at" in d else datetime.utcnow(),
            refresh_token=d.get("refresh_token"),
        )


class CredentialStore:
    """
    Secure credential storage
    
    Uses system keyring when available, falls back to encrypted file storage.
    """
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path.home() / ".aria"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.credentials_file = self.config_dir / ".credentials"
        self._keyring_available = self._check_keyring()
        self._encryption_key = self._get_or_create_key()
    
    def _check_keyring(self) -> bool:
        """Check if system keyring is available"""
        try:
            import keyring
            # Test if keyring works
            keyring.get_keyring()
            return True
        except Exception:
            return False
    
    def _get_or_create_key(self) -> bytes:
        """Get or create encryption key for file-based storage"""
        key_file = self.config_dir / ".key"
        if key_file.exists():
            return key_file.read_bytes()
        else:
            key = secrets.token_bytes(32)
            key_file.write_bytes(key)
            # Set restrictive permissions (Windows compatible)
            try:
                import stat
                key_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
            except Exception:
                pass
            return key
    
    def _encrypt(self, data: str) -> str:
        """Simple XOR encryption (for demo - use proper encryption in production)"""
        key = self._encryption_key
        encrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(data.encode())])
        return base64.b64encode(encrypted).decode()
    
    def _decrypt(self, data: str) -> str:
        """Decrypt data"""
        key = self._encryption_key
        encrypted = base64.b64decode(data.encode())
        decrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(encrypted)])
        return decrypted.decode()
    
    def store(self, service: str, username: str, credential: str):
        """Store a credential"""
        if self._keyring_available:
            try:
                import keyring
                keyring.set_password(f"aria-cli-{service}", username, credential)
                return
            except Exception:
                pass
        
        # Fall back to file storage
        creds = self._load_file_creds()
        if service not in creds:
            creds[service] = {}
        creds[service][username] = self._encrypt(credential)
        self._save_file_creds(creds)
    
    def get(self, service: str, username: str) -> Optional[str]:
        """Retrieve a credential"""
        if self._keyring_available:
            try:
                import keyring
                cred = keyring.get_password(f"aria-cli-{service}", username)
                if cred:
                    return cred
            except Exception:
                pass
        
        # Fall back to file storage
        creds = self._load_file_creds()
        if service in creds and username in creds[service]:
            return self._decrypt(creds[service][username])
        return None
    
    def delete(self, service: str, username: str):
        """Delete a credential"""
        if self._keyring_available:
            try:
                import keyring
                keyring.delete_password(f"aria-cli-{service}", username)
            except Exception:
                pass
        
        creds = self._load_file_creds()
        if service in creds and username in creds[service]:
            del creds[service][username]
            self._save_file_creds(creds)
    
    def list_services(self) -> List[str]:
        """List all stored services"""
        creds = self._load_file_creds()
        return list(creds.keys())
    
    def _load_file_creds(self) -> Dict[str, Dict[str, str]]:
        """Load credentials from file"""
        if self.credentials_file.exists():
            try:
                return json.loads(self.credentials_file.read_text())
            except Exception:
                return {}
        return {}
    
    def _save_file_creds(self, creds: Dict[str, Dict[str, str]]):
        """Save credentials to file"""
        self.credentials_file.write_text(json.dumps(creds, indent=2))
        try:
            import stat
            self.credentials_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass


class AuthManager:
    """
    Authentication Manager for ARIA CLI
    
    Handles login, logout, session management, and credential storage.
    
    Usage:
        auth = AuthManager()
        
        # Login with username/password
        session = auth.login("user", "password")
        
        # Login with API key
        session = auth.login_with_api_key("sk-...")
        
        # Check authentication
        if auth.is_authenticated:
            print(f"Logged in as {auth.current_user.username}")
        
        # Logout
        auth.logout()
    """
    
    SESSION_DURATION = timedelta(hours=24)
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path.home() / ".aria"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.credentials = CredentialStore(self.config_dir)
        self.session_file = self.config_dir / "session.json"
        
        self._session: Optional[Session] = None
        self._load_session()
    
    def _load_session(self):
        """Load existing session from file"""
        if self.session_file.exists():
            try:
                data = json.loads(self.session_file.read_text())
                self._session = Session.from_dict(data)
                if self._session.is_expired:
                    self._session = None
                    self.session_file.unlink()
            except Exception:
                self._session = None
    
    def _save_session(self):
        """Save session to file"""
        if self._session:
            self.session_file.write_text(json.dumps(self._session.to_dict(), indent=2))
        elif self.session_file.exists():
            self.session_file.unlink()
    
    def _hash_password(self, password: str, salt: Optional[str] = None) -> tuple:
        """Hash a password with salt"""
        if salt is None:
            salt = secrets.token_hex(16)
        hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return base64.b64encode(hashed).decode(), salt
    
    def _generate_token(self) -> str:
        """Generate a secure session token"""
        return secrets.token_urlsafe(32)
    
    @property
    def is_authenticated(self) -> bool:
        """Check if user is authenticated"""
        return self._session is not None and self._session.is_valid
    
    @property
    def current_user(self) -> Optional[User]:
        """Get current authenticated user"""
        return self._session.user if self._session else None
    
    @property
    def current_session(self) -> Optional[Session]:
        """Get current session"""
        return self._session
    
    def get_status(self) -> AuthStatus:
        """Get authentication status"""
        if self._session is None:
            return AuthStatus.NOT_AUTHENTICATED
        if self._session.is_expired:
            return AuthStatus.EXPIRED
        return AuthStatus.AUTHENTICATED
    
    def register(self, username: str, password: str, email: Optional[str] = None) -> User:
        """
        Register a new local user
        
        Args:
            username: Username
            password: Password
            email: Optional email
            
        Returns:
            Created User object
        """
        # Check if user exists
        existing = self.credentials.get("users", username)
        if existing:
            raise ValueError(f"User '{username}' already exists")
        
        # Hash password and store
        hashed, salt = self._hash_password(password)
        user_data = {
            "password_hash": hashed,
            "salt": salt,
            "email": email,
            "created_at": datetime.utcnow().isoformat(),
        }
        self.credentials.store("users", username, json.dumps(user_data))
        
        return User(
            username=username,
            provider=AuthProvider.LOCAL,
            email=email,
        )
    
    def login(self, username: str, password: str) -> Session:
        """
        Login with username and password
        
        Args:
            username: Username
            password: Password
            
        Returns:
            Session object
        """
        # Get stored user data
        stored = self.credentials.get("users", username)
        if not stored:
            raise ValueError("Invalid username or password")
        
        user_data = json.loads(stored)
        
        # Verify password
        hashed, _ = self._hash_password(password, user_data["salt"])
        if hashed != user_data["password_hash"]:
            raise ValueError("Invalid username or password")
        
        # Create session
        user = User(
            username=username,
            provider=AuthProvider.LOCAL,
            email=user_data.get("email"),
        )
        
        self._session = Session(
            token=self._generate_token(),
            user=user,
            expires_at=datetime.utcnow() + self.SESSION_DURATION,
            refresh_token=self._generate_token(),
        )
        self._save_session()
        
        return self._session
    
    def login_with_api_key(self, api_key: str, provider: str = "openai") -> Session:
        """
        Login with API key
        
        Args:
            api_key: The API key
            provider: API provider (openai, anthropic, etc.)
            
        Returns:
            Session object
        """
        # Store API key
        self.credentials.store("api_keys", provider, api_key)
        
        # Create session
        user = User(
            username=f"{provider}_user",
            provider=AuthProvider.API_KEY,
            metadata={"api_provider": provider},
        )
        
        self._session = Session(
            token=self._generate_token(),
            user=user,
            expires_at=datetime.utcnow() + self.SESSION_DURATION,
        )
        self._save_session()
        
        return self._session
    
    def login_with_ssh_key(self, key_path: Optional[Path] = None) -> Session:
        """
        Login with SSH key
        
        Args:
            key_path: Path to SSH private key (defaults to ~/.ssh/id_rsa)
            
        Returns:
            Session object
        """
        if key_path is None:
            key_path = Path.home() / ".ssh" / "id_rsa"
        
        if not key_path.exists():
            raise FileNotFoundError(f"SSH key not found: {key_path}")
        
        # Read public key to get username
        pub_key_path = key_path.with_suffix(".pub")
        username = "ssh_user"
        if pub_key_path.exists():
            pub_key = pub_key_path.read_text().strip()
            parts = pub_key.split()
            if len(parts) >= 3:
                username = parts[2].split("@")[0]
        
        user = User(
            username=username,
            provider=AuthProvider.SSH_KEY,
            metadata={"key_path": str(key_path)},
        )
        
        self._session = Session(
            token=self._generate_token(),
            user=user,
            expires_at=datetime.utcnow() + self.SESSION_DURATION,
        )
        self._save_session()
        
        return self._session
    
    def login_interactive(self) -> Session:
        """
        Interactive login prompt
        
        Returns:
            Session object
        """
        print("\n🔐 ARIA CLI Login\n")
        
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ")
        
        try:
            session = self.login(username, password)
            print(f"\n✅ Logged in as {username}\n")
            return session
        except ValueError as e:
            print(f"\n❌ Login failed: {e}\n")
            raise
    
    def logout(self):
        """Logout and clear session"""
        self._session = None
        if self.session_file.exists():
            self.session_file.unlink()
        print("👋 Logged out successfully")
    
    def refresh_session(self) -> Optional[Session]:
        """Refresh the current session"""
        if self._session and self._session.refresh_token:
            self._session.expires_at = datetime.utcnow() + self.SESSION_DURATION
            self._session.token = self._generate_token()
            self._save_session()
            return self._session
        return None
    
    def get_api_key(self, provider: str) -> Optional[str]:
        """Get stored API key for a provider"""
        return self.credentials.get("api_keys", provider)
    
    def set_api_key(self, provider: str, api_key: str):
        """Store API key for a provider"""
        self.credentials.store("api_keys", provider, api_key)
    
    def list_api_keys(self) -> List[str]:
        """List stored API key providers"""
        # This is a simplified implementation
        providers = []
        for provider in ["openai", "anthropic", "github", "google"]:
            if self.credentials.get("api_keys", provider):
                providers.append(provider)
        return providers
    
    def require_auth(self) -> User:
        """
        Require authentication, prompt if not logged in
        
        Returns:
            Current user
            
        Raises:
            PermissionError if not authenticated
        """
        if not self.is_authenticated:
            print("Authentication required.")
            try:
                self.login_interactive()
            except Exception:
                raise PermissionError("Authentication required")
        
        if not self.current_user:
            raise PermissionError("Authentication required")
        
        return self.current_user
    
    def whoami(self) -> Dict[str, Any]:
        """Get current user info"""
        if not self.is_authenticated or not self.current_user or not self._session:
            return {"status": "not_authenticated"}
        
        return {
            "status": "authenticated",
            "user": self.current_user.to_dict(),
            "session": {
                "expires_at": self._session.expires_at.isoformat(),
                "created_at": self._session.created_at.isoformat(),
            },
        }


# Convenience function
def get_auth() -> AuthManager:
    """Get the default auth manager instance"""
    return AuthManager()
