"""
ARIA Agent Channels Module v0.2.0

Advanced communication channels for agent-to-agent messaging.

This module provides:
- AgentChannel: Direct communication channel between two agents
- BroadcastChannel: One-to-many communication
- StreamChannel: Streaming data between agents
- PersistentChannel: Durable channels with message persistence

Channel Types:
    ┌──────────┐           ┌──────────┐
    │ Agent A  │◄─────────►│ Agent B  │  Direct Channel
    └──────────┘           └──────────┘

    ┌──────────┐    ┌─────────────────────────┐
    │ Agent A  │───►│    Broadcast Channel    │
    └──────────┘    └─────────────────────────┘
                          │    │    │
                    ┌─────┘    │    └─────┐
                    ▼          ▼          ▼
                ┌──────┐  ┌──────┐  ┌──────┐
                │  B   │  │  C   │  │  D   │
                └──────┘  └──────┘  └──────┘
"""

from __future__ import annotations
import asyncio
import uuid
import json
import time
import logging
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import (
    Dict, Any, List, Optional, Callable, Union,
    Awaitable, Set, AsyncIterator, Tuple
)
from datetime import datetime, timedelta
from pathlib import Path
from collections import deque
from abc import ABC, abstractmethod

from .agents import (
    AgentMessage, MessageType, MessagePriority,
    AriaAgent, AgentRegistry, get_registry,
)

logger = logging.getLogger(__name__)


# ============================================================================
# Channel Types and Status
# ============================================================================

class ChannelType(Enum):
    """Types of communication channels"""
    DIRECT = auto()      # Point-to-point
    BROADCAST = auto()   # One-to-many
    STREAM = auto()      # Continuous data flow
    PERSISTENT = auto()  # Durable with storage
    SECURE = auto()      # Encrypted channel


class ChannelState(Enum):
    """Channel lifecycle states"""
    CREATED = auto()
    CONNECTING = auto()
    OPEN = auto()
    PAUSED = auto()
    CLOSING = auto()
    CLOSED = auto()
    ERROR = auto()


@dataclass
class ChannelMetrics:
    """Channel performance metrics"""
    messages_sent: int = 0
    messages_received: int = 0
    bytes_transferred: int = 0
    errors: int = 0
    avg_latency_ms: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    last_activity: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages_sent": self.messages_sent,
            "messages_received": self.messages_received,
            "bytes_transferred": self.bytes_transferred,
            "errors": self.errors,
            "avg_latency_ms": self.avg_latency_ms,
            "created_at": self.created_at.isoformat(),
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
        }


# ============================================================================
# Base Channel Class
# ============================================================================

MessageHandler = Callable[[AgentMessage], Union[None, Awaitable[None]]]


class BaseChannel(ABC):
    """
    Base class for all agent communication channels.
    
    Channels provide a structured way for agents to communicate,
    with built-in support for async messaging, error handling,
    and metrics collection.
    """
    
    def __init__(
        self,
        name: str,
        channel_type: ChannelType = ChannelType.DIRECT,
        channel_id: Optional[str] = None,
    ):
        self.id = channel_id or f"ch-{name}-{uuid.uuid4().hex[:8]}"
        self.name = name
        self.type = channel_type
        
        # State
        self._state = ChannelState.CREATED
        self._error: Optional[str] = None
        
        # Message handling
        self._handlers: List[MessageHandler] = []
        self._message_queue: asyncio.Queue[AgentMessage] = asyncio.Queue()
        
        # Metrics
        self.metrics = ChannelMetrics()
        
        # Processing task
        self._process_task: Optional[asyncio.Task] = None
        self._running = False
        
        logger.debug(f"Channel created: {self.id}")
    
    @property
    def state(self) -> ChannelState:
        return self._state
    
    @state.setter
    def state(self, value: ChannelState):
        old_state = self._state
        self._state = value
        logger.debug(f"Channel {self.id}: {old_state.name} -> {value.name}")
    
    @property
    def is_open(self) -> bool:
        return self._state == ChannelState.OPEN
    
    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------
    
    async def open(self) -> None:
        """Open the channel"""
        if self._running:
            return
        
        self.state = ChannelState.CONNECTING
        self._running = True
        
        # Start processing task
        self._process_task = asyncio.create_task(self._process_messages())
        
        self.state = ChannelState.OPEN
        logger.info(f"Channel opened: {self.id}")
    
    async def close(self) -> None:
        """Close the channel"""
        if not self._running:
            return
        
        self.state = ChannelState.CLOSING
        self._running = False
        
        # Stop processing
        if self._process_task:
            self._process_task.cancel()
            try:
                await self._process_task
            except asyncio.CancelledError:
                pass
        
        self.state = ChannelState.CLOSED
        logger.info(f"Channel closed: {self.id}")
    
    async def pause(self) -> None:
        """Pause the channel"""
        self.state = ChannelState.PAUSED
    
    async def resume(self) -> None:
        """Resume the channel"""
        if self._running:
            self.state = ChannelState.OPEN
    
    # -------------------------------------------------------------------------
    # Messaging
    # -------------------------------------------------------------------------
    
    @abstractmethod
    async def send(self, message: AgentMessage) -> None:
        """Send a message through the channel"""
        pass
    
    async def receive(self, message: AgentMessage) -> None:
        """Receive a message into the channel"""
        await self._message_queue.put(message)
        self.metrics.messages_received += 1
        self.metrics.last_activity = datetime.now()
    
    def on_message(self, handler: MessageHandler) -> None:
        """Register a message handler"""
        self._handlers.append(handler)
    
    async def _process_messages(self) -> None:
        """Process incoming messages"""
        while self._running:
            try:
                if self._state == ChannelState.PAUSED:
                    await asyncio.sleep(0.1)
                    continue
                
                try:
                    message = await asyncio.wait_for(
                        self._message_queue.get(),
                        timeout=0.5
                    )
                except asyncio.TimeoutError:
                    continue
                
                # Call handlers
                for handler in self._handlers:
                    try:
                        result = handler(message)
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Handler error: {e}")
                        self.metrics.errors += 1
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Channel error: {e}")
                self._error = str(e)
                self.state = ChannelState.ERROR
    
    def get_status(self) -> Dict[str, Any]:
        """Get channel status"""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type.name,
            "state": self._state.name,
            "error": self._error,
            "metrics": self.metrics.to_dict(),
        }


# ============================================================================
# Direct Channel - Point-to-Point Communication
# ============================================================================

class DirectChannel(BaseChannel):
    """
    Direct point-to-point channel between two agents.
    
    Example:
        channel = DirectChannel("task-comm", agent_a, agent_b)
        await channel.open()
        
        # Send from A to B
        await channel.send(AgentMessage(
            type=MessageType.REQUEST,
            payload={"action": "process"}
        ))
    """
    
    def __init__(
        self,
        name: str,
        agent_a: Union[str, AriaAgent],
        agent_b: Union[str, AriaAgent],
        bidirectional: bool = True,
        registry: Optional[AgentRegistry] = None,
    ):
        super().__init__(name, ChannelType.DIRECT)
        
        self.agent_a_id = agent_a.id if isinstance(agent_a, AriaAgent) else agent_a
        self.agent_b_id = agent_b.id if isinstance(agent_b, AriaAgent) else agent_b
        self.bidirectional = bidirectional
        self.registry = registry or get_registry()
    
    async def send(self, message: AgentMessage) -> None:
        """Send message to the other endpoint"""
        if not self.is_open:
            raise RuntimeError(f"Channel {self.id} is not open")
        
        # Determine recipient
        if message.sender == self.agent_a_id:
            message.recipient = self.agent_b_id
        elif message.sender == self.agent_b_id:
            if not self.bidirectional:
                raise ValueError("Channel is not bidirectional")
            message.recipient = self.agent_a_id
        else:
            # Default to B
            message.sender = self.agent_a_id
            message.recipient = self.agent_b_id
        
        # Add channel metadata
        message.metadata["channel_id"] = self.id
        message.metadata["channel_type"] = self.type.name
        
        # Route through registry
        await self.registry.route_message(message)
        
        self.metrics.messages_sent += 1
        self.metrics.last_activity = datetime.now()
    
    async def request(
        self,
        payload: Dict[str, Any],
        from_agent: str,
        timeout: float = 30.0,
    ) -> AgentMessage:
        """Send request and wait for response"""
        message = AgentMessage(
            type=MessageType.REQUEST,
            sender=from_agent,
            payload=payload,
        )
        
        # Create response future
        response_event = asyncio.Event()
        response_holder: List[AgentMessage] = []
        
        def handle_response(msg: AgentMessage) -> None:
            if msg.reply_to == message.id:
                response_holder.append(msg)
                response_event.set()
        
        self.on_message(handle_response)
        
        await self.send(message)
        
        try:
            await asyncio.wait_for(response_event.wait(), timeout=timeout)
            return response_holder[0]
        except asyncio.TimeoutError:
            raise TimeoutError(f"No response within {timeout}s")


# ============================================================================
# Broadcast Channel - One-to-Many Communication
# ============================================================================

class BroadcastChannel(BaseChannel):
    """
    Broadcast channel for one-to-many communication.
    
    One publisher sends messages to multiple subscribers.
    Supports topic-based filtering.
    
    Example:
        channel = BroadcastChannel("events")
        await channel.open()
        
        # Subscribe agents
        channel.subscribe(agent_b.id)
        channel.subscribe(agent_c.id)
        
        # Broadcast
        await channel.publish({"event": "task_complete"})
    """
    
    def __init__(
        self,
        name: str,
        publisher: Optional[Union[str, AriaAgent]] = None,
        registry: Optional[AgentRegistry] = None,
    ):
        super().__init__(name, ChannelType.BROADCAST)
        
        self.publisher_id = publisher.id if isinstance(publisher, AriaAgent) else publisher
        self.registry = registry or get_registry()
        
        # Subscribers
        self._subscribers: Set[str] = set()
        self._topic_subscribers: Dict[str, Set[str]] = {}
    
    def subscribe(self, agent_id: str, topics: Optional[List[str]] = None) -> None:
        """Subscribe an agent to the channel"""
        self._subscribers.add(agent_id)
        
        if topics:
            for topic in topics:
                if topic not in self._topic_subscribers:
                    self._topic_subscribers[topic] = set()
                self._topic_subscribers[topic].add(agent_id)
        
        logger.debug(f"Agent {agent_id} subscribed to {self.id}")
    
    def unsubscribe(self, agent_id: str, topics: Optional[List[str]] = None) -> None:
        """Unsubscribe an agent from the channel"""
        if topics:
            for topic in topics:
                if topic in self._topic_subscribers:
                    self._topic_subscribers[topic].discard(agent_id)
        else:
            self._subscribers.discard(agent_id)
            for topic_subs in self._topic_subscribers.values():
                topic_subs.discard(agent_id)
        
        logger.debug(f"Agent {agent_id} unsubscribed from {self.id}")
    
    async def send(self, message: AgentMessage) -> None:
        """Send to all subscribers"""
        await self.publish(message.payload, topic=message.metadata.get("topic"))
    
    async def publish(
        self,
        payload: Dict[str, Any],
        topic: Optional[str] = None,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> None:
        """Publish a message to all subscribers"""
        if not self.is_open:
            raise RuntimeError(f"Channel {self.id} is not open")
        
        # Determine recipients
        if topic and topic in self._topic_subscribers:
            recipients = self._topic_subscribers[topic]
        else:
            recipients = self._subscribers
        
        message = AgentMessage(
            type=MessageType.EVENT,
            sender=self.publisher_id or "broadcast",
            payload=payload,
            priority=priority,
            metadata={
                "channel_id": self.id,
                "channel_type": self.type.name,
                "topic": topic,
            },
        )
        
        # Send to each subscriber
        for agent_id in recipients:
            msg_copy = AgentMessage(
                id=f"{message.id}-{agent_id[:8]}",
                type=message.type,
                sender=message.sender,
                recipient=agent_id,
                payload=message.payload,
                priority=message.priority,
                timestamp=message.timestamp,
                metadata=message.metadata,
            )
            await self.registry.route_message(msg_copy)
        
        self.metrics.messages_sent += len(recipients)
        self.metrics.last_activity = datetime.now()
    
    def get_subscribers(self, topic: Optional[str] = None) -> List[str]:
        """Get list of subscribers"""
        if topic and topic in self._topic_subscribers:
            return list(self._topic_subscribers[topic])
        return list(self._subscribers)


# ============================================================================
# Stream Channel - Continuous Data Flow
# ============================================================================

@dataclass
class StreamChunk:
    """A chunk of streaming data"""
    sequence: int
    data: Any
    is_final: bool = False
    timestamp: datetime = field(default_factory=datetime.now)


class StreamChannel(BaseChannel):
    """
    Streaming channel for continuous data flow.
    
    Supports ordered delivery with sequence numbers
    and flow control.
    
    Example:
        channel = StreamChannel("data-stream", producer, consumer)
        await channel.open()
        
        # Stream data
        async for chunk in data_generator():
            await channel.stream(chunk)
        
        await channel.end_stream()
    """
    
    def __init__(
        self,
        name: str,
        producer: Union[str, AriaAgent],
        consumer: Union[str, AriaAgent],
        buffer_size: int = 100,
        registry: Optional[AgentRegistry] = None,
    ):
        super().__init__(name, ChannelType.STREAM)
        
        self.producer_id = producer.id if isinstance(producer, AriaAgent) else producer
        self.consumer_id = consumer.id if isinstance(consumer, AriaAgent) else consumer
        self.buffer_size = buffer_size
        self.registry = registry or get_registry()
        
        # Stream state
        self._sequence = 0
        self._buffer: deque[StreamChunk] = deque(maxlen=buffer_size)
        self._stream_ended = False
        
        # Flow control
        self._backpressure = asyncio.Event()
        self._backpressure.set()  # Initially not blocked
    
    async def send(self, message: AgentMessage) -> None:
        """Send via stream"""
        await self.stream(message.payload)
    
    async def stream(self, data: Any) -> None:
        """Stream a chunk of data"""
        if not self.is_open:
            raise RuntimeError(f"Channel {self.id} is not open")
        
        if self._stream_ended:
            raise RuntimeError("Stream has ended")
        
        # Wait for backpressure to clear
        await self._backpressure.wait()
        
        # Create chunk
        chunk = StreamChunk(
            sequence=self._sequence,
            data=data,
        )
        self._sequence += 1
        self._buffer.append(chunk)
        
        # Create message
        message = AgentMessage(
            type=MessageType.STREAM,
            sender=self.producer_id,
            recipient=self.consumer_id,
            payload={
                "sequence": chunk.sequence,
                "data": data,
                "is_final": False,
            },
            metadata={
                "channel_id": self.id,
                "channel_type": self.type.name,
            },
        )
        
        await self.registry.route_message(message)
        
        self.metrics.messages_sent += 1
        self.metrics.last_activity = datetime.now()
        
        # Apply backpressure if buffer full
        if len(self._buffer) >= self.buffer_size:
            self._backpressure.clear()
    
    async def end_stream(self) -> None:
        """End the stream"""
        if self._stream_ended:
            return
        
        # Send final chunk
        message = AgentMessage(
            type=MessageType.STREAM,
            sender=self.producer_id,
            recipient=self.consumer_id,
            payload={
                "sequence": self._sequence,
                "data": None,
                "is_final": True,
            },
            metadata={
                "channel_id": self.id,
                "channel_type": self.type.name,
            },
        )
        
        await self.registry.route_message(message)
        self._stream_ended = True
        
        logger.info(f"Stream ended: {self.id} ({self._sequence} chunks)")
    
    async def acknowledge(self, sequence: int) -> None:
        """Acknowledge receipt of chunks up to sequence"""
        # Remove acknowledged chunks from buffer
        while self._buffer and self._buffer[0].sequence <= sequence:
            self._buffer.popleft()
        
        # Release backpressure
        if len(self._buffer) < self.buffer_size:
            self._backpressure.set()
    
    async def iter_stream(self) -> AsyncIterator[Any]:
        """Iterate over streamed data (consumer side)"""
        while not self._stream_ended or self._buffer:
            if self._buffer:
                chunk = self._buffer.popleft()
                yield chunk.data
                await self.acknowledge(chunk.sequence)
            else:
                await asyncio.sleep(0.01)


# ============================================================================
# Persistent Channel - Durable with Storage
# ============================================================================

class PersistentChannel(BaseChannel):
    """
    Persistent channel with message storage.
    
    Messages are stored to disk and survive restarts.
    Supports replay of historical messages.
    
    Example:
        channel = PersistentChannel("audit-log")
        await channel.open()
        
        # Messages are persisted
        await channel.send(message)
        
        # Replay from timestamp
        async for msg in channel.replay(since=yesterday):
            process(msg)
    """
    
    def __init__(
        self,
        name: str,
        storage_path: Optional[Path] = None,
        max_messages: int = 10000,
        retention_days: int = 7,
        registry: Optional[AgentRegistry] = None,
    ):
        super().__init__(name, ChannelType.PERSISTENT)
        
        self.storage_path = storage_path or (Path.home() / ".aria" / "channels" / name)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.max_messages = max_messages
        self.retention_days = retention_days
        self.registry = registry or get_registry()
        
        # Message log file
        self._log_file = self.storage_path / "messages.jsonl"
        self._index_file = self.storage_path / "index.json"
        
        # In-memory index
        self._message_index: Dict[str, int] = {}  # message_id -> file offset
        self._subscribers: Set[str] = set()
        
        # Load index
        self._load_index()
    
    def _load_index(self) -> None:
        """Load message index from disk"""
        if self._index_file.exists():
            try:
                with open(self._index_file, 'r') as f:
                    self._message_index = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load index: {e}")
                self._message_index = {}
    
    def _save_index(self) -> None:
        """Save message index to disk"""
        try:
            with open(self._index_file, 'w') as f:
                json.dump(self._message_index, f)
        except Exception as e:
            logger.error(f"Failed to save index: {e}")
    
    def subscribe(self, agent_id: str) -> None:
        """Subscribe an agent to the channel"""
        self._subscribers.add(agent_id)
    
    def unsubscribe(self, agent_id: str) -> None:
        """Unsubscribe an agent"""
        self._subscribers.discard(agent_id)
    
    async def send(self, message: AgentMessage) -> None:
        """Send and persist a message"""
        if not self.is_open:
            raise RuntimeError(f"Channel {self.id} is not open")
        
        # Add channel metadata
        message.metadata["channel_id"] = self.id
        message.metadata["channel_type"] = self.type.name
        message.metadata["persisted_at"] = datetime.now().isoformat()
        
        # Persist to disk
        try:
            with open(self._log_file, 'a') as f:
                offset = f.tell()
                f.write(json.dumps(message.to_dict()) + "\n")
                self._message_index[message.id] = offset
            
            self._save_index()
        except Exception as e:
            logger.error(f"Failed to persist message: {e}")
            self.metrics.errors += 1
        
        # Route to subscribers
        for agent_id in self._subscribers:
            msg_copy = AgentMessage(
                id=message.id,
                type=message.type,
                sender=message.sender,
                recipient=agent_id,
                payload=message.payload,
                priority=message.priority,
                timestamp=message.timestamp,
                metadata=message.metadata,
            )
            await self.registry.route_message(msg_copy)
        
        self.metrics.messages_sent += 1
        self.metrics.last_activity = datetime.now()
    
    async def get_message(self, message_id: str) -> Optional[AgentMessage]:
        """Get a message by ID"""
        offset = self._message_index.get(message_id)
        if offset is None:
            return None
        
        try:
            with open(self._log_file, 'r') as f:
                f.seek(offset)
                line = f.readline()
                return AgentMessage.from_dict(json.loads(line))
        except Exception as e:
            logger.error(f"Failed to read message: {e}")
            return None
    
    async def replay(
        self,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: Optional[int] = None,
    ) -> AsyncIterator[AgentMessage]:
        """Replay messages from the log"""
        count = 0
        
        try:
            with open(self._log_file, 'r') as f:
                for line in f:
                    if limit and count >= limit:
                        break
                    
                    try:
                        msg = AgentMessage.from_dict(json.loads(line))
                        
                        # Filter by time
                        if since and msg.timestamp < since:
                            continue
                        if until and msg.timestamp > until:
                            continue
                        
                        yield msg
                        count += 1
                    
                    except json.JSONDecodeError:
                        continue
        
        except FileNotFoundError:
            pass
    
    async def cleanup(self) -> int:
        """Remove old messages beyond retention period"""
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        removed = 0
        
        # Read all messages
        messages = []
        async for msg in self.replay():
            if msg.timestamp >= cutoff:
                messages.append(msg)
            else:
                removed += 1
        
        # Rewrite log
        if removed > 0:
            with open(self._log_file, 'w') as f:
                self._message_index.clear()
                for msg in messages:
                    offset = f.tell()
                    f.write(json.dumps(msg.to_dict()) + "\n")
                    self._message_index[msg.id] = offset
            
            self._save_index()
            logger.info(f"Cleaned up {removed} old messages from {self.id}")
        
        return removed


# ============================================================================
# Channel Manager
# ============================================================================

class ChannelManager:
    """
    Central manager for all agent channels.
    
    Provides channel creation, discovery, and lifecycle management.
    
    Example:
        manager = ChannelManager()
        
        # Create channels
        direct = manager.create_direct("task-comm", agent_a, agent_b)
        broadcast = manager.create_broadcast("events", agent_a)
        
        # Open all
        await manager.open_all()
        
        # Find channels
        channels = manager.find_by_agent(agent_a.id)
    """
    
    def __init__(self, registry: Optional[AgentRegistry] = None):
        self.registry = registry or get_registry()
        self._channels: Dict[str, BaseChannel] = {}
        self._by_agent: Dict[str, Set[str]] = {}  # agent_id -> channel_ids
        
        logger.info("ChannelManager initialized")
    
    def create_direct(
        self,
        name: str,
        agent_a: Union[str, AriaAgent],
        agent_b: Union[str, AriaAgent],
        bidirectional: bool = True,
    ) -> DirectChannel:
        """Create a direct channel between two agents"""
        channel = DirectChannel(
            name=name,
            agent_a=agent_a,
            agent_b=agent_b,
            bidirectional=bidirectional,
            registry=self.registry,
        )
        self._register_channel(channel, [
            agent_a.id if isinstance(agent_a, AriaAgent) else agent_a,
            agent_b.id if isinstance(agent_b, AriaAgent) else agent_b,
        ])
        return channel
    
    def create_broadcast(
        self,
        name: str,
        publisher: Optional[Union[str, AriaAgent]] = None,
    ) -> BroadcastChannel:
        """Create a broadcast channel"""
        channel = BroadcastChannel(
            name=name,
            publisher=publisher,
            registry=self.registry,
        )
        agents = []
        if publisher:
            agents.append(publisher.id if isinstance(publisher, AriaAgent) else publisher)
        self._register_channel(channel, agents)
        return channel
    
    def create_stream(
        self,
        name: str,
        producer: Union[str, AriaAgent],
        consumer: Union[str, AriaAgent],
        buffer_size: int = 100,
    ) -> StreamChannel:
        """Create a streaming channel"""
        channel = StreamChannel(
            name=name,
            producer=producer,
            consumer=consumer,
            buffer_size=buffer_size,
            registry=self.registry,
        )
        self._register_channel(channel, [
            producer.id if isinstance(producer, AriaAgent) else producer,
            consumer.id if isinstance(consumer, AriaAgent) else consumer,
        ])
        return channel
    
    def create_persistent(
        self,
        name: str,
        storage_path: Optional[Path] = None,
        max_messages: int = 10000,
        retention_days: int = 7,
    ) -> PersistentChannel:
        """Create a persistent channel"""
        channel = PersistentChannel(
            name=name,
            storage_path=storage_path,
            max_messages=max_messages,
            retention_days=retention_days,
            registry=self.registry,
        )
        self._register_channel(channel, [])
        return channel
    
    def _register_channel(self, channel: BaseChannel, agents: List[str]) -> None:
        """Register a channel"""
        self._channels[channel.id] = channel
        for agent_id in agents:
            if agent_id not in self._by_agent:
                self._by_agent[agent_id] = set()
            self._by_agent[agent_id].add(channel.id)
    
    def get(self, channel_id: str) -> Optional[BaseChannel]:
        """Get a channel by ID"""
        return self._channels.get(channel_id)
    
    def find_by_name(self, name: str) -> Optional[BaseChannel]:
        """Find a channel by name"""
        for channel in self._channels.values():
            if channel.name == name:
                return channel
        return None
    
    def find_by_agent(self, agent_id: str) -> List[BaseChannel]:
        """Find all channels involving an agent"""
        channel_ids = self._by_agent.get(agent_id, set())
        return [self._channels[cid] for cid in channel_ids if cid in self._channels]
    
    def find_by_type(self, channel_type: ChannelType) -> List[BaseChannel]:
        """Find all channels of a specific type"""
        return [ch for ch in self._channels.values() if ch.type == channel_type]
    
    def list_channels(self) -> List[Dict[str, Any]]:
        """List all channels with status"""
        return [ch.get_status() for ch in self._channels.values()]
    
    async def open_all(self) -> None:
        """Open all channels"""
        for channel in self._channels.values():
            await channel.open()
    
    async def close_all(self) -> None:
        """Close all channels"""
        for channel in self._channels.values():
            await channel.close()
    
    async def remove(self, channel_id: str) -> None:
        """Remove a channel"""
        channel = self._channels.pop(channel_id, None)
        if channel:
            await channel.close()
            # Remove from agent mappings
            for agent_channels in self._by_agent.values():
                agent_channels.discard(channel_id)


# ============================================================================
# Singleton Instance
# ============================================================================

_channel_manager: Optional[ChannelManager] = None


def get_channel_manager() -> ChannelManager:
    """Get or create the global channel manager"""
    global _channel_manager
    if _channel_manager is None:
        _channel_manager = ChannelManager()
    return _channel_manager


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Channel types
    "ChannelType",
    "ChannelState",
    "ChannelMetrics",
    
    # Base
    "BaseChannel",
    "MessageHandler",
    
    # Channel implementations
    "DirectChannel",
    "BroadcastChannel",
    "StreamChannel",
    "StreamChunk",
    "PersistentChannel",
    
    # Manager
    "ChannelManager",
    "get_channel_manager",
]
