"""
ARIA CLI v0.2.1 - Main Entry Point

This module allows running ARIA CLI as:
    python -m aria_cli
"""

from .cli import main

if __name__ == "__main__":
    main()
