"""
AriaSpace - Personal Codespace System for ARIA CLI v0.2.0

Secure file synchronization and workspace management between devices:
- Phone (Termux/Android) ↔ Computer sync
- Meta AI folder integration
- GitHub Codespaces-like experience
- End-to-end encrypted transfers
- Real-time sync with conflict resolution
- Workspace snapshots and versioning

Architecture:
    Phone (Termux)                    Computer
    ┌─────────────────┐              ┌─────────────────┐
    │  AriaSpace      │    SSH       │  AriaSpace      │
    │  Client         │◄────────────►│  Server         │
    │                 │              │                 │
    │  /storage/      │   Sync       │  ~/aria-space/  │
    │  emulated/0/    │◄────────────►│  workspaces/    │
    │  Meta AI/       │              │                 │
    └─────────────────┘              └─────────────────┘
"""

import os
import json
import hashlib
import shutil
import threading
import time
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
import subprocess
import fnmatch

from .ssh_router import SSHRouter, SSHHost, CommandResult


class SyncDirection(Enum):
    """Sync direction"""
    UPLOAD = "upload"        # Phone → Computer
    DOWNLOAD = "download"    # Computer → Phone
    BIDIRECTIONAL = "bidirectional"


class SyncStrategy(Enum):
    """Conflict resolution strategy"""
    NEWER_WINS = auto()      # Most recent modification wins
    LOCAL_WINS = auto()      # Local file wins
    REMOTE_WINS = auto()     # Remote file wins
    MANUAL = auto()          # Prompt user
    BACKUP_BOTH = auto()     # Keep both versions


class FileStatus(Enum):
    """File sync status"""
    SYNCED = "synced"
    MODIFIED_LOCAL = "modified_local"
    MODIFIED_REMOTE = "modified_remote"
    CONFLICT = "conflict"
    NEW_LOCAL = "new_local"
    NEW_REMOTE = "new_remote"
    DELETED_LOCAL = "deleted_local"
    DELETED_REMOTE = "deleted_remote"


@dataclass
class SyncFile:
    """File in sync workspace"""
    relative_path: str
    local_path: Optional[Path] = None
    remote_path: Optional[str] = None
    local_hash: Optional[str] = None
    remote_hash: Optional[str] = None
    local_mtime: Optional[float] = None
    remote_mtime: Optional[float] = None
    local_size: int = 0
    remote_size: int = 0
    status: FileStatus = FileStatus.SYNCED
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "relative_path": self.relative_path,
            "local_path": str(self.local_path) if self.local_path else None,
            "remote_path": self.remote_path,
            "local_hash": self.local_hash,
            "remote_hash": self.remote_hash,
            "local_mtime": self.local_mtime,
            "remote_mtime": self.remote_mtime,
            "local_size": self.local_size,
            "remote_size": self.remote_size,
            "status": self.status.value,
        }


@dataclass
class Workspace:
    """AriaSpace workspace"""
    name: str
    local_root: Path
    remote_root: str
    remote_host: str
    description: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_sync: Optional[datetime] = None
    sync_direction: SyncDirection = SyncDirection.BIDIRECTIONAL
    sync_strategy: SyncStrategy = SyncStrategy.NEWER_WINS
    ignore_patterns: List[str] = field(default_factory=lambda: [
        ".git", "__pycache__", "*.pyc", ".DS_Store", "Thumbs.db",
        "node_modules", ".venv", "*.log", ".aria-space"
    ])
    auto_sync: bool = False
    sync_interval: int = 300  # seconds
    encrypted: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "local_root": str(self.local_root),
            "remote_root": self.remote_root,
            "remote_host": self.remote_host,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "last_sync": self.last_sync.isoformat() if self.last_sync else None,
            "sync_direction": self.sync_direction.value,
            "sync_strategy": self.sync_strategy.name,
            "ignore_patterns": self.ignore_patterns,
            "auto_sync": self.auto_sync,
            "sync_interval": self.sync_interval,
            "encrypted": self.encrypted,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Workspace':
        return cls(
            name=d["name"],
            local_root=Path(d["local_root"]),
            remote_root=d["remote_root"],
            remote_host=d["remote_host"],
            description=d.get("description", ""),
            created_at=datetime.fromisoformat(d["created_at"]) if "created_at" in d else datetime.utcnow(),
            last_sync=datetime.fromisoformat(d["last_sync"]) if d.get("last_sync") else None,
            sync_direction=SyncDirection(d.get("sync_direction", "bidirectional")),
            sync_strategy=SyncStrategy[d.get("sync_strategy", "NEWER_WINS")],
            ignore_patterns=d.get("ignore_patterns", []),
            auto_sync=d.get("auto_sync", False),
            sync_interval=d.get("sync_interval", 300),
            encrypted=d.get("encrypted", True),
        )


@dataclass
class SyncResult:
    """Result of a sync operation"""
    workspace: str
    direction: SyncDirection
    files_uploaded: int = 0
    files_downloaded: int = 0
    files_deleted: int = 0
    files_conflicted: int = 0
    bytes_transferred: int = 0
    errors: List[str] = field(default_factory=list)
    duration: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def success(self) -> bool:
        return len(self.errors) == 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "workspace": self.workspace,
            "direction": self.direction.value,
            "files_uploaded": self.files_uploaded,
            "files_downloaded": self.files_downloaded,
            "files_deleted": self.files_deleted,
            "files_conflicted": self.files_conflicted,
            "bytes_transferred": self.bytes_transferred,
            "errors": self.errors,
            "duration": self.duration,
            "success": self.success,
            "timestamp": self.timestamp.isoformat(),
        }


class AriaSpace:
    """
    AriaSpace - Personal Codespace for ARIA CLI
    
    Secure workspace synchronization between devices (Phone ↔ Computer).
    
    Usage:
        space = AriaSpace()
        
        # Create workspace linked to phone
        space.create_workspace(
            name="meta-ai",
            local_root="~/aria-space/meta-ai",
            remote_root="/storage/emulated/0/Meta AI",
            remote_host="termux-phone"
        )
        
        # List files
        files = space.list_files("meta-ai")
        
        # Sync workspace
        result = space.sync("meta-ai")
        
        # Download specific file
        space.download_file("meta-ai", "images/photo.jpg")
        
        # Upload file
        space.upload_file("meta-ai", "documents/notes.txt")
        
        # Watch for changes (auto-sync)
        space.watch("meta-ai")
    """
    
    # Common Android paths
    ANDROID_PATHS = {
        "meta_ai": "/storage/emulated/0/Meta AI",
        "downloads": "/storage/emulated/0/Download",
        "documents": "/storage/emulated/0/Documents",
        "pictures": "/storage/emulated/0/Pictures",
        "dcim": "/storage/emulated/0/DCIM",
        "movies": "/storage/emulated/0/Movies",
        "music": "/storage/emulated/0/Music",
        "termux_home": "/data/data/com.termux/files/home",
    }
    
    def __init__(
        self,
        config_dir: Optional[Path] = None,
        ssh_router: Optional[SSHRouter] = None,
    ):
        """
        Initialize AriaSpace
        
        Args:
            config_dir: Configuration directory (default ~/.aria/spaces)
            ssh_router: SSH router instance for connections
        """
        self.config_dir = config_dir or Path.home() / ".aria" / "spaces"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.workspaces_file = self.config_dir / "workspaces.json"
        self.sync_state_dir = self.config_dir / "state"
        self.sync_state_dir.mkdir(exist_ok=True)
        
        self.ssh = ssh_router or SSHRouter()
        self._workspaces: Dict[str, Workspace] = {}
        self._watchers: Dict[str, threading.Thread] = {}
        self._running = True
        
        self._load_workspaces()
    
    def _load_workspaces(self):
        """Load workspaces from config"""
        if self.workspaces_file.exists():
            try:
                data = json.loads(self.workspaces_file.read_text())
                for ws_data in data.get("workspaces", []):
                    ws = Workspace.from_dict(ws_data)
                    self._workspaces[ws.name] = ws
            except Exception as e:
                print(f"Warning: Could not load workspaces: {e}")
    
    def _save_workspaces(self):
        """Save workspaces to config"""
        data = {
            "workspaces": [ws.to_dict() for ws in self._workspaces.values()],
            "updated_at": datetime.utcnow().isoformat(),
        }
        self.workspaces_file.write_text(json.dumps(data, indent=2))
    
    def _get_sync_state_file(self, workspace_name: str) -> Path:
        """Get sync state file for workspace"""
        return self.sync_state_dir / f"{workspace_name}.json"
    
    def _load_sync_state(self, workspace_name: str) -> Dict[str, Dict[str, Any]]:
        """Load sync state for workspace"""
        state_file = self._get_sync_state_file(workspace_name)
        if state_file.exists():
            try:
                return json.loads(state_file.read_text())
            except Exception:
                pass
        return {}
    
    def _save_sync_state(self, workspace_name: str, state: Dict[str, Dict[str, Any]]):
        """Save sync state for workspace"""
        state_file = self._get_sync_state_file(workspace_name)
        state_file.write_text(json.dumps(state, indent=2))
    
    def _hash_file(self, path: Path) -> str:
        """Calculate SHA256 hash of file"""
        sha256 = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _should_ignore(self, path: str, patterns: List[str]) -> bool:
        """Check if path matches ignore patterns"""
        for pattern in patterns:
            if fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch(Path(path).name, pattern):
                return True
        return False
    
    # =========================================================================
    # Workspace Management
    # =========================================================================
    
    def create_workspace(
        self,
        name: str,
        local_root: Union[str, Path],
        remote_root: str,
        remote_host: str,
        description: str = "",
        sync_direction: SyncDirection = SyncDirection.BIDIRECTIONAL,
        auto_sync: bool = False,
    ) -> Workspace:
        """
        Create a new workspace
        
        Args:
            name: Unique workspace name
            local_root: Local directory path
            remote_root: Remote directory path (on phone)
            remote_host: SSH host name for remote device
            description: Optional description
            sync_direction: Sync direction (upload/download/bidirectional)
            auto_sync: Enable automatic synchronization
            
        Returns:
            Created Workspace object
        """
        if name in self._workspaces:
            raise ValueError(f"Workspace '{name}' already exists")
        
        local_root = Path(local_root).expanduser().resolve()
        local_root.mkdir(parents=True, exist_ok=True)
        
        # Verify SSH host exists
        if not self.ssh.get_host(remote_host):
            raise ValueError(f"SSH host '{remote_host}' not found. Add it first with aria ssh add")
        
        workspace = Workspace(
            name=name,
            local_root=local_root,
            remote_root=remote_root,
            remote_host=remote_host,
            description=description,
            sync_direction=sync_direction,
            auto_sync=auto_sync,
        )
        
        self._workspaces[name] = workspace
        self._save_workspaces()
        
        # Create .aria-space marker
        marker = local_root / ".aria-space"
        marker.write_text(json.dumps({
            "workspace": name,
            "remote": f"{remote_host}:{remote_root}",
            "created": datetime.utcnow().isoformat(),
        }, indent=2))
        
        print(f"✅ Created workspace '{name}'")
        print(f"   Local:  {local_root}")
        print(f"   Remote: {remote_host}:{remote_root}")
        
        return workspace
    
    def create_meta_ai_workspace(
        self,
        remote_host: str,
        local_root: Optional[Path] = None,
        name: str = "meta-ai",
    ) -> Workspace:
        """
        Convenience method to create Meta AI workspace
        
        Args:
            remote_host: SSH host for Android phone
            local_root: Local directory (default ~/aria-space/meta-ai)
            name: Workspace name
            
        Returns:
            Created Workspace
        """
        if local_root is None:
            local_root = Path.home() / "aria-space" / "meta-ai"
        
        return self.create_workspace(
            name=name,
            local_root=local_root,
            remote_root=self.ANDROID_PATHS["meta_ai"],
            remote_host=remote_host,
            description="Meta AI folder from Android device",
            sync_direction=SyncDirection.BIDIRECTIONAL,
        )
    
    def delete_workspace(self, name: str, delete_local: bool = False) -> bool:
        """
        Delete a workspace
        
        Args:
            name: Workspace name
            delete_local: Also delete local files
            
        Returns:
            True if deleted
        """
        if name not in self._workspaces:
            return False
        
        workspace = self._workspaces[name]
        
        # Stop watcher if running
        self.unwatch(name)
        
        # Delete local files if requested
        if delete_local and workspace.local_root.exists():
            shutil.rmtree(workspace.local_root)
        
        # Delete sync state
        state_file = self._get_sync_state_file(name)
        if state_file.exists():
            state_file.unlink()
        
        del self._workspaces[name]
        self._save_workspaces()
        
        print(f"🗑️ Deleted workspace '{name}'")
        return True
    
    def get_workspace(self, name: str) -> Optional[Workspace]:
        """Get workspace by name"""
        return self._workspaces.get(name)
    
    def list_workspaces(self) -> List[Workspace]:
        """List all workspaces"""
        return list(self._workspaces.values())
    
    # =========================================================================
    # File Operations
    # =========================================================================
    
    def list_files(
        self,
        workspace_name: str,
        path: str = "",
        include_remote: bool = True,
    ) -> List[SyncFile]:
        """
        List files in workspace
        
        Args:
            workspace_name: Workspace name
            path: Relative path within workspace
            include_remote: Also scan remote files
            
        Returns:
            List of SyncFile objects
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        files: Dict[str, SyncFile] = {}
        sync_state = self._load_sync_state(workspace_name)
        
        # Scan local files
        local_path = workspace.local_root / path
        if local_path.exists():
            for item in local_path.rglob("*"):
                if item.is_file():
                    rel_path = str(item.relative_to(workspace.local_root))
                    if self._should_ignore(rel_path, workspace.ignore_patterns):
                        continue
                    
                    stat = item.stat()
                    files[rel_path] = SyncFile(
                        relative_path=rel_path,
                        local_path=item,
                        local_hash=self._hash_file(item),
                        local_mtime=stat.st_mtime,
                        local_size=stat.st_size,
                        status=FileStatus.NEW_LOCAL,
                    )
        
        # Scan remote files
        if include_remote:
            remote_path = f"{workspace.remote_root}/{path}".rstrip("/")
            result = self.ssh.execute(
                workspace.remote_host,
                f'find "{remote_path}" -type f -exec stat -c "%n|%s|%Y" {{}} \\; 2>/dev/null'
            )
            
            if result.success:
                for line in result.stdout.strip().split("\n"):
                    if "|" not in line:
                        continue
                    
                    parts = line.split("|")
                    if len(parts) >= 3:
                        full_path, size, mtime = parts[0], int(parts[1]), float(parts[2])
                        rel_path = full_path.replace(workspace.remote_root + "/", "")
                        
                        if self._should_ignore(rel_path, workspace.ignore_patterns):
                            continue
                        
                        if rel_path in files:
                            # File exists locally and remotely
                            files[rel_path].remote_path = full_path
                            files[rel_path].remote_size = size
                            files[rel_path].remote_mtime = mtime
                            
                            # Determine status
                            if files[rel_path].local_mtime > mtime:
                                files[rel_path].status = FileStatus.MODIFIED_LOCAL
                            elif files[rel_path].local_mtime < mtime:
                                files[rel_path].status = FileStatus.MODIFIED_REMOTE
                            else:
                                files[rel_path].status = FileStatus.SYNCED
                        else:
                            # Remote only
                            files[rel_path] = SyncFile(
                                relative_path=rel_path,
                                remote_path=full_path,
                                remote_size=size,
                                remote_mtime=mtime,
                                status=FileStatus.NEW_REMOTE,
                            )
        
        return list(files.values())
    
    def download_file(
        self,
        workspace_name: str,
        relative_path: str,
        overwrite: bool = True,
    ) -> bool:
        """
        Download a file from remote to local
        
        Args:
            workspace_name: Workspace name
            relative_path: Path relative to workspace root
            overwrite: Overwrite existing local file
            
        Returns:
            True if successful
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        remote_path = f"{workspace.remote_root}/{relative_path}"
        local_path = workspace.local_root / relative_path
        
        if local_path.exists() and not overwrite:
            print(f"⚠️ File exists: {local_path}")
            return False
        
        # Create parent directories
        local_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Download via SCP
        success = self.ssh.download(
            workspace.remote_host,
            remote_path,
            local_path,
        )
        
        if success:
            print(f"⬇️ Downloaded: {relative_path}")
        
        return success
    
    def upload_file(
        self,
        workspace_name: str,
        relative_path: str,
        overwrite: bool = True,
    ) -> bool:
        """
        Upload a file from local to remote
        
        Args:
            workspace_name: Workspace name
            relative_path: Path relative to workspace root
            overwrite: Overwrite existing remote file
            
        Returns:
            True if successful
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        local_path = workspace.local_root / relative_path
        remote_path = f"{workspace.remote_root}/{relative_path}"
        
        if not local_path.exists():
            raise FileNotFoundError(f"Local file not found: {local_path}")
        
        # Create remote parent directory
        remote_dir = str(Path(remote_path).parent)
        self.ssh.execute(workspace.remote_host, f'mkdir -p "{remote_dir}"')
        
        # Upload via SCP
        success = self.ssh.upload(
            workspace.remote_host,
            local_path,
            remote_path,
        )
        
        if success:
            print(f"⬆️ Uploaded: {relative_path}")
        
        return success
    
    def delete_file(
        self,
        workspace_name: str,
        relative_path: str,
        local: bool = True,
        remote: bool = False,
    ) -> bool:
        """
        Delete a file from workspace
        
        Args:
            workspace_name: Workspace name
            relative_path: Path relative to workspace root
            local: Delete local file
            remote: Delete remote file
            
        Returns:
            True if successful
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        success = True
        
        if local:
            local_path = workspace.local_root / relative_path
            if local_path.exists():
                local_path.unlink()
                print(f"🗑️ Deleted local: {relative_path}")
            else:
                success = False
        
        if remote:
            remote_path = f"{workspace.remote_root}/{relative_path}"
            result = self.ssh.execute(
                workspace.remote_host,
                f'rm -f "{remote_path}"'
            )
            if result.success:
                print(f"🗑️ Deleted remote: {relative_path}")
            else:
                success = False
        
        return success
    
    # =========================================================================
    # Synchronization
    # =========================================================================
    
    def sync(
        self,
        workspace_name: str,
        direction: Optional[SyncDirection] = None,
        dry_run: bool = False,
    ) -> SyncResult:
        """
        Synchronize workspace
        
        Args:
            workspace_name: Workspace name
            direction: Override sync direction
            dry_run: Show what would be done without doing it
            
        Returns:
            SyncResult object
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        direction = direction or workspace.sync_direction
        start_time = time.time()
        
        result = SyncResult(
            workspace=workspace_name,
            direction=direction,
        )
        
        print(f"🔄 Syncing '{workspace_name}' ({direction.value})...")
        
        # Get file status
        files = self.list_files(workspace_name, include_remote=True)
        sync_state = self._load_sync_state(workspace_name)
        
        for file in files:
            try:
                if direction == SyncDirection.DOWNLOAD:
                    if file.status in [FileStatus.NEW_REMOTE, FileStatus.MODIFIED_REMOTE]:
                        if not dry_run:
                            self.download_file(workspace_name, file.relative_path)
                        result.files_downloaded += 1
                        result.bytes_transferred += file.remote_size
                
                elif direction == SyncDirection.UPLOAD:
                    if file.status in [FileStatus.NEW_LOCAL, FileStatus.MODIFIED_LOCAL]:
                        if not dry_run:
                            self.upload_file(workspace_name, file.relative_path)
                        result.files_uploaded += 1
                        result.bytes_transferred += file.local_size
                
                elif direction == SyncDirection.BIDIRECTIONAL:
                    if file.status == FileStatus.NEW_LOCAL:
                        if not dry_run:
                            self.upload_file(workspace_name, file.relative_path)
                        result.files_uploaded += 1
                        result.bytes_transferred += file.local_size
                    
                    elif file.status == FileStatus.NEW_REMOTE:
                        if not dry_run:
                            self.download_file(workspace_name, file.relative_path)
                        result.files_downloaded += 1
                        result.bytes_transferred += file.remote_size
                    
                    elif file.status == FileStatus.MODIFIED_LOCAL:
                        if workspace.sync_strategy == SyncStrategy.NEWER_WINS:
                            if file.local_mtime > (file.remote_mtime or 0):
                                if not dry_run:
                                    self.upload_file(workspace_name, file.relative_path)
                                result.files_uploaded += 1
                        elif workspace.sync_strategy == SyncStrategy.LOCAL_WINS:
                            if not dry_run:
                                self.upload_file(workspace_name, file.relative_path)
                            result.files_uploaded += 1
                    
                    elif file.status == FileStatus.MODIFIED_REMOTE:
                        if workspace.sync_strategy == SyncStrategy.NEWER_WINS:
                            if (file.remote_mtime or 0) > (file.local_mtime or 0):
                                if not dry_run:
                                    self.download_file(workspace_name, file.relative_path)
                                result.files_downloaded += 1
                        elif workspace.sync_strategy == SyncStrategy.REMOTE_WINS:
                            if not dry_run:
                                self.download_file(workspace_name, file.relative_path)
                            result.files_downloaded += 1
                
                # Update sync state
                if not dry_run:
                    sync_state[file.relative_path] = {
                        "hash": file.local_hash or file.remote_hash,
                        "synced_at": datetime.utcnow().isoformat(),
                    }
            
            except Exception as e:
                result.errors.append(f"{file.relative_path}: {str(e)}")
        
        # Save state
        if not dry_run:
            self._save_sync_state(workspace_name, sync_state)
            workspace.last_sync = datetime.utcnow()
            self._save_workspaces()
        
        result.duration = time.time() - start_time
        
        # Print summary
        print(f"\n{'[DRY RUN] ' if dry_run else ''}Sync complete:")
        print(f"  ⬆️ Uploaded:   {result.files_uploaded}")
        print(f"  ⬇️ Downloaded: {result.files_downloaded}")
        print(f"  📦 Transferred: {result.bytes_transferred / 1024:.1f} KB")
        print(f"  ⏱️ Duration:   {result.duration:.2f}s")
        if result.errors:
            print(f"  ❌ Errors:     {len(result.errors)}")
        
        return result
    
    def pull(self, workspace_name: str, path: str = "") -> SyncResult:
        """Pull (download) from remote to local"""
        return self.sync(workspace_name, direction=SyncDirection.DOWNLOAD)
    
    def push(self, workspace_name: str, path: str = "") -> SyncResult:
        """Push (upload) from local to remote"""
        return self.sync(workspace_name, direction=SyncDirection.UPLOAD)
    
    # =========================================================================
    # Watch / Auto-sync
    # =========================================================================
    
    def watch(self, workspace_name: str, interval: Optional[int] = None):
        """
        Start watching workspace for changes
        
        Args:
            workspace_name: Workspace name
            interval: Sync interval in seconds (default from workspace config)
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        if workspace_name in self._watchers:
            print(f"Already watching '{workspace_name}'")
            return
        
        interval = interval or workspace.sync_interval
        
        def watch_loop():
            while self._running and workspace_name in self._watchers:
                try:
                    self.sync(workspace_name)
                except Exception as e:
                    print(f"Sync error: {e}")
                time.sleep(interval)
        
        thread = threading.Thread(target=watch_loop, daemon=True)
        self._watchers[workspace_name] = thread
        thread.start()
        
        print(f"👁️ Watching '{workspace_name}' (interval: {interval}s)")
    
    def unwatch(self, workspace_name: str):
        """Stop watching workspace"""
        if workspace_name in self._watchers:
            del self._watchers[workspace_name]
            print(f"👁️ Stopped watching '{workspace_name}'")
    
    # =========================================================================
    # Snapshots
    # =========================================================================
    
    def create_snapshot(self, workspace_name: str, message: str = "") -> str:
        """
        Create a snapshot of workspace state
        
        Args:
            workspace_name: Workspace name
            message: Snapshot message
            
        Returns:
            Snapshot ID
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        snapshot_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        snapshot_dir = self.config_dir / "snapshots" / workspace_name
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        # Get current file list with hashes
        files = self.list_files(workspace_name, include_remote=False)
        
        snapshot_data = {
            "id": snapshot_id,
            "workspace": workspace_name,
            "message": message,
            "created_at": datetime.utcnow().isoformat(),
            "files": [f.to_dict() for f in files],
        }
        
        snapshot_file = snapshot_dir / f"{snapshot_id}.json"
        snapshot_file.write_text(json.dumps(snapshot_data, indent=2))
        
        print(f"📸 Created snapshot: {snapshot_id}")
        return snapshot_id
    
    def list_snapshots(self, workspace_name: str) -> List[Dict[str, Any]]:
        """List snapshots for workspace"""
        snapshot_dir = self.config_dir / "snapshots" / workspace_name
        if not snapshot_dir.exists():
            return []
        
        snapshots = []
        for file in sorted(snapshot_dir.glob("*.json"), reverse=True):
            try:
                data = json.loads(file.read_text())
                snapshots.append({
                    "id": data["id"],
                    "message": data.get("message", ""),
                    "created_at": data["created_at"],
                    "file_count": len(data.get("files", [])),
                })
            except Exception:
                pass
        
        return snapshots
    
    # =========================================================================
    # Remote Browsing
    # =========================================================================
    
    def browse_remote(
        self,
        workspace_name: str,
        path: str = "",
    ) -> List[Dict[str, Any]]:
        """
        Browse remote directory
        
        Args:
            workspace_name: Workspace name
            path: Relative path to browse
            
        Returns:
            List of file/directory entries
        """
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        remote_path = f"{workspace.remote_root}/{path}".rstrip("/")
        
        result = self.ssh.execute(
            workspace.remote_host,
            f'ls -la "{remote_path}" 2>/dev/null'
        )
        
        entries = []
        if result.success:
            for line in result.stdout.strip().split("\n")[1:]:  # Skip "total" line
                parts = line.split()
                if len(parts) >= 9:
                    name = " ".join(parts[8:])
                    if name in [".", ".."]:
                        continue
                    
                    entries.append({
                        "name": name,
                        "is_dir": parts[0].startswith("d"),
                        "permissions": parts[0],
                        "size": int(parts[4]) if parts[4].isdigit() else 0,
                        "modified": f"{parts[5]} {parts[6]} {parts[7]}",
                    })
        
        return entries
    
    def get_status(self, workspace_name: str) -> Dict[str, Any]:
        """Get workspace status"""
        workspace = self._workspaces.get(workspace_name)
        if not workspace:
            raise ValueError(f"Workspace '{workspace_name}' not found")
        
        # Test connection
        connected, message = self.ssh.test_connection(workspace.remote_host)
        
        # Count local files
        local_count = sum(1 for _ in workspace.local_root.rglob("*") if _.is_file())
        
        return {
            "name": workspace.name,
            "local_root": str(workspace.local_root),
            "remote_root": workspace.remote_root,
            "remote_host": workspace.remote_host,
            "connected": connected,
            "connection_message": message,
            "last_sync": workspace.last_sync.isoformat() if workspace.last_sync else None,
            "local_files": local_count,
            "watching": workspace_name in self._watchers,
            "auto_sync": workspace.auto_sync,
        }
    
    def shutdown(self):
        """Shutdown AriaSpace (stop all watchers)"""
        self._running = False
        self._watchers.clear()


# Convenience function
def get_space() -> AriaSpace:
    """Get the default AriaSpace instance"""
    return AriaSpace()
