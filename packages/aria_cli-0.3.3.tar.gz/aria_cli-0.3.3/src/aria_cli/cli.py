"""
ARIA CLI v0.2.0 - Main Command Line Interface

Full Q0-Q38 cognitive architecture with:
- Interactive REPL mode
- Command chaining
- LLM integration
- GUI sync capabilities
- Rich terminal output
"""

import sys
from pathlib import Path
from typing import Optional, List, Any, Dict
from enum import Enum
import json
import os

try:
    import typer
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt, Confirm
    from rich import print as rprint
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    Console = None
    typer = None


from .q_system import QSystem, QLayer, QOperator, QCommand
from .nlp_engine import NLPEngine, Intent, ParsedInput
from .llm_connector import LLMConnector, LLMConfig
from .q38_connector import Q38Connector, Q38Config
from .aria_space import AriaSpace, SyncDirection
from .termux_setup import TermuxSetup


# Console for rich output
console = Console() if HAS_RICH else None


def version_callback(value: bool):
    """Print version and exit"""
    if value:
        print("ARIA CLI v0.3.0")
        raise typer.Exit()


# Main app
app = typer.Typer(
    name="aria",
    help="ARIA CLI v0.3.0 - Advanced Recursive Intelligence Architecture with F1/M1 Cycles",
    add_completion=False,
) if typer else None


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback,
        is_eager=True, help="Show version and exit"
    )
):
    """ARIA CLI - Advanced Recursive Intelligence Architecture"""
    pass


class OutputFormat(str, Enum):
    """Output format options"""
    PLAIN = "plain"
    JSON = "json"
    RICH = "rich"



class AriaCLI:
    """
    ARIA Command Line Interface
    
    Provides a unified interface to the Q0-Q38 cognitive system
    with LLM integration, GitHub automation, and F1/M1 cycle orchestration.
    """
    
    VERSION = "0.3.0"
    
    def __init__(
        self,
        config_path: Optional[Path] = None,
        output_format: OutputFormat = OutputFormat.RICH,
        use_llm: bool = True,
    ):
        """
        Initialize ARIA CLI
        
        Args:
            config_path: Path to configuration file
            output_format: Output format (plain, json, rich)
            use_llm: Whether to enable LLM integration
        """
        self.output_format = output_format
        self.use_llm = use_llm
        
        # Initialize subsystems
        self.q_system = QSystem()
        self.nlp = NLPEngine()
        self.llm: Optional[LLMConnector] = None
        self.q38: Optional[Q38Connector] = None
        
        # Configuration
        self.config = self._load_config(config_path)
        
        # Session state
        self.session_history: List[Dict[str, Any]] = []
        self.context: Dict[str, Any] = {}
        
        # Initialize LLM if requested
        if use_llm:
            self._init_llm()
        
        # Initialize Q38 cluster connector
        self._init_q38()
    
    def _load_config(self, config_path: Optional[Path] = None) -> Dict[str, Any]:
        """Load configuration from file or defaults"""
        default_config = {
            'llm': {
                'backend': 'auto',
                'model': None,
                'temperature': 0.7,
                'max_tokens': 2048,
            },
            'q_system': {
                'default_layer': 8,
                'trace_enabled': True,
            },
            'ui': {
                'theme': 'dark',
                'show_layer_info': True,
            },
        }
        
        if config_path and config_path.exists():
            try:
                with open(config_path) as f:
                    user_config = json.load(f)
                # Deep merge
                for key in user_config:
                    if isinstance(user_config[key], dict) and key in default_config:
                        default_config[key].update(user_config[key])
                    else:
                        default_config[key] = user_config[key]
            except Exception:
                pass
        
        return default_config
    
    def _init_llm(self):
        """Initialize LLM connector"""
        try:
            llm_config = LLMConfig(
                temperature=self.config['llm'].get('temperature', 0.7),
                max_tokens=self.config['llm'].get('max_tokens', 2048),
            )
            self.llm = LLMConnector(config=llm_config)
        except Exception:
            self.llm = None
    
    def _init_q38(self):
        """Initialize Q38 cluster connector"""
        try:
            q38_config = self.config.get('q38', {})
            cluster_config = Q38Config(
                base_port=q38_config.get('base_port', 8200),
                node_count=q38_config.get('node_count', 8),
                sync_port=q38_config.get('sync_port', 9000),
            )
            self.q38 = Q38Connector(config=cluster_config)
        except Exception as e:
            self.q38 = None
            # Q38 is optional - continue without it
    
    def output(self, content: Any, title: Optional[str] = None):
        """
        Output content in the configured format
        
        Args:
            content: Content to output
            title: Optional title for panels
        """
        if self.output_format == OutputFormat.JSON:
            if isinstance(content, (dict, list)):
                print(json.dumps(content, indent=2, default=str))
            else:
                print(json.dumps({'result': str(content)}, indent=2))
        
        elif self.output_format == OutputFormat.RICH and console:
            if isinstance(content, dict):
                table = Table(show_header=True)
                table.add_column("Key", style="cyan")
                table.add_column("Value", style="white")
                for k, v in content.items():
                    table.add_row(str(k), str(v))
                if title:
                    console.print(Panel(table, title=title))
                else:
                    console.print(table)
            elif isinstance(content, str):
                if title:
                    console.print(Panel(content, title=title))
                else:
                    console.print(content)
            else:
                console.print(content)
        
        else:
            print(content)
    
    def process(self, input_text: str) -> Dict[str, Any]:
        """
        Process user input through the full Q-System pipeline
        
        Args:
            input_text: User input text
            
        Returns:
            Processing result dictionary
        """
        # Parse input
        parsed = self.nlp.parse(input_text, context=self.context)
        
        # Create Q-Command
        command = QCommand(
            operator=QOperator[parsed.q_operator] if hasattr(QOperator, parsed.q_operator) else QOperator.ASK,
            payload=parsed.payload,
            layer=QLayer(parsed.q_layer) if parsed.q_layer <= 38 else QLayer.Q8_LANGUAGE,
            metadata={'context': self.context},
        )
        
        # Execute through Q-System
        result = self.q_system.execute(command)
        
        # Enhance with LLM if available
        if self.llm and self.llm.available:
            llm_response = self._enhance_with_llm(parsed, result)
            result['llm_response'] = llm_response
        
        # Update context
        self.context['last_intent'] = parsed.intent.name
        self.context['last_result'] = result
        
        # Store in history
        self.session_history.append({
            'input': input_text,
            'parsed': parsed.to_dict(),
            'result': result,
        })
        
        return result
    
    def _enhance_with_llm(self, parsed: ParsedInput, q_result: Dict[str, Any]) -> Optional[str]:
        """Enhance Q-System result with LLM generation"""
        if not self.llm:
            return None
        
        # Build prompt based on intent
        prompt = self._build_llm_prompt(parsed, q_result)
        
        try:
            response = self.llm.generate(
                prompt=prompt,
                context={
                    'q_layer': parsed.q_layer,
                    'intent': parsed.intent.name,
                    'keywords': parsed.keywords,
                },
            )
            return response
        except Exception as e:
            return f"LLM unavailable: {e}"
    
    def _build_llm_prompt(self, parsed: ParsedInput, q_result: Dict[str, Any]) -> str:
        """Build LLM prompt based on parsed input"""
        base = f"""You are ARIA, an Advanced Recursive Intelligence Architecture operating at Q-Layer {parsed.q_layer}.

User request: {parsed.raw_text}
Detected intent: {parsed.intent.name}
Keywords: {', '.join(parsed.keywords)}
Q-System processing complete. Provide a helpful response.

"""
        
        if parsed.intent == Intent.EXPLAIN:
            base += "Provide a clear, detailed explanation."
        elif parsed.intent == Intent.SUMMARIZE:
            base += "Provide a concise summary."
        elif parsed.intent == Intent.GENERATE:
            base += f"Generate the requested content: {parsed.payload.get('target', '')}"
        elif parsed.intent == Intent.ANALYZE:
            base += "Provide analytical insights."
        
        return base
    
    def interactive_mode(self):
        """Run interactive REPL mode"""
        if console:
            console.print(Panel.fit(
                f"[bold cyan]ARIA CLI v{self.VERSION}[/bold cyan]\n"
                f"[dim]Q0-Q38 Cognitive Architecture[/dim]\n\n"
                f"Type [bold green]help[/bold green] for commands, [bold red]exit[/bold red] to quit",
                title="Welcome",
                border_style="cyan",
            ))
        else:
            print(f"\nARIA CLI v{self.VERSION}")
            print("Type 'help' for commands, 'exit' to quit\n")
        
        while True:
            try:
                # Get input
                if console:
                    prompt_text = f"[bold cyan]ARIA[/bold cyan] [dim]Q{self.context.get('current_layer', 8)}[/dim] > "
                    user_input = Prompt.ask(prompt_text)
                else:
                    user_input = input(f"ARIA Q{self.context.get('current_layer', 8)} > ")
                
                user_input = user_input.strip()
                
                if not user_input:
                    continue
                
                # Handle special commands
                if user_input.lower() in ('exit', 'quit', 'q'):
                    if console:
                        console.print("[dim]Goodbye![/dim]")
                    else:
                        print("Goodbye!")
                    break
                
                if user_input.lower() == 'help':
                    self._show_help()
                    continue
                
                if user_input.lower() == 'status':
                    self._show_status()
                    continue
                
                if user_input.lower() == 'layers':
                    self._show_layers()
                    continue
                
                if user_input.lower().startswith('layer '):
                    layer_num = int(user_input.split()[1])
                    self._set_layer(layer_num)
                    continue
                
                if user_input.lower() == 'history':
                    self._show_history()
                    continue
                
                if user_input.lower() == 'clear':
                    self.session_history.clear()
                    self.nlp.clear_context()
                    if console:
                        console.print("[dim]History cleared[/dim]")
                    else:
                        print("History cleared")
                    continue
                
                # Q38 Commands
                if user_input.lower().startswith('q38 '):
                    self._handle_q38_command(user_input[4:].strip())
                    continue
                
                # Process through Q-System
                result = self.process(user_input)
                
                # Display result
                if self.output_format == OutputFormat.RICH and console:
                    self._display_result_rich(result)
                else:
                    self.output(result)
                
            except KeyboardInterrupt:
                if console:
                    console.print("\n[dim]Use 'exit' to quit[/dim]")
                else:
                    print("\nUse 'exit' to quit")
            except Exception as e:
                if console:
                    console.print(f"[red]Error: {e}[/red]")
                else:
                    print(f"Error: {e}")
    
    def _show_help(self):
        """Display help information"""
        if console:
            table = Table(title="ARIA CLI Commands", show_header=True)
            table.add_column("Command", style="cyan")
            table.add_column("Description", style="white")
            
            commands = [
                ("help", "Show this help message"),
                ("status", "Show system status"),
                ("layers", "List all Q-Layers"),
                ("layer <N>", "Switch to Q-Layer N"),
                ("history", "Show session history"),
                ("clear", "Clear session history"),
                ("q38 status", "Show Q38 cluster status"),
                ("q38 directions", "List all 64 directions"),
                ("q38 query <dir> <text>", "Query a specific direction"),
                ("exit", "Exit ARIA CLI"),
            ]
            
            for cmd, desc in commands:
                table.add_row(cmd, desc)
            
            console.print(table)
            console.print("\n[dim]Natural language queries are processed through the Q-System[/dim]")
        else:
            print("\nARIA CLI Commands:")
            print("  help     - Show this help message")
            print("  status   - Show system status")
            print("  layers   - List all Q-Layers")
            print("  layer N  - Switch to Q-Layer N")
            print("  history  - Show session history")
            print("  clear    - Clear session history")
            print("  q38 status     - Show Q38 cluster status")
            print("  q38 directions - List all 64 directions")
            print("  q38 query <dir> <text> - Query a direction")
            print("  exit     - Exit ARIA CLI")
            print("\nNatural language queries are processed through the Q-System\n")
    
    def _show_status(self):
        """Display system status"""
        status = {
            'Version': self.VERSION,
            'Q-System': 'Active',
            'Current Layer': self.context.get('current_layer', 8),
            'LLM': 'Connected' if self.llm and self.llm.available else 'Disconnected',
            'LLM Backend': getattr(self.llm, 'backend', 'N/A') if self.llm else 'N/A',
            'Q38 Cluster': 'Connected' if self.q38 else 'Disconnected',
            'Q38 Directions': len(self.q38.directions) if self.q38 else 0,
            'Session Commands': len(self.session_history),
            'NLP Context': len(self.nlp.get_context()),
        }
        self.output(status, title="System Status")
    
    def _handle_q38_command(self, cmd: str):
        """Handle Q38 cluster commands"""
        import asyncio
        
        parts = cmd.split(maxsplit=2)
        subcmd = parts[0].lower() if parts else ''
        
        if subcmd == 'status':
            self._show_q38_status()
        elif subcmd == 'directions':
            self._show_q38_directions()
        elif subcmd == 'query' and len(parts) >= 3:
            direction = parts[1]
            query_text = parts[2]
            asyncio.run(self._q38_query(direction, query_text))
        elif subcmd == 'init':
            asyncio.run(self._q38_init())
        elif subcmd == 'sync':
            event_data = parts[1] if len(parts) > 1 else 'ping'
            asyncio.run(self._q38_sync(event_data))
        else:
            if console:
                console.print("[yellow]Q38 Commands:[/yellow]")
                console.print("  q38 status     - Show cluster status")
                console.print("  q38 directions - List all directions")
                console.print("  q38 query <direction> <text> - Query a direction")
                console.print("  q38 init       - Initialize cluster")
                console.print("  q38 sync [event] - Broadcast sync event")
            else:
                print("Q38 Commands: status, directions, query <dir> <text>, init, sync")
    
    def _show_q38_status(self):
        """Display Q38 cluster status"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        status = {
            'API URL': self.q38.config.api_url,
            'Base Port': self.q38.config.base_port,
            'Node Count': self.q38.config.node_count,
            'Sync Port': self.q38.config.sync_port,
            'Active Nodes': len([d for d, n in self.q38.nodes.items() if n.get('active', False)]),
            'Total Directions': len(self.q38.directions),
        }
        self.output(status, title="Q38 Cluster Status")
    
    def _show_q38_directions(self):
        """Display all 64 directions"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        directions = self.q38.get_all_directions()
        
        if console:
            table = Table(title="Q38 64-Direction System", show_header=True)
            table.add_column("ID", style="cyan", width=3)
            table.add_column("Direction", style="white")
            table.add_column("Port", style="yellow")
            
            for i, direction in enumerate(directions):
                node = self.q38.nodes.get(direction)
                port = node.get('port', self.q38.config.base_port + i) if node else self.q38.config.base_port + i
                table.add_row(str(i), direction, str(port))
            
            console.print(table)
        else:
            print("\nQ38 64-Direction System:")
            for i, direction in enumerate(directions):
                print(f"  {i:2d}: {direction}")
    
    async def _q38_query(self, direction: str, query_text: str):
        """Query a specific Q38 direction"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        if console:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(f"Querying direction: {direction}", total=None)
                result = await self.q38.direction_query(direction, query_text)
        else:
            print(f"Querying direction: {direction}...")
            result = await self.q38.direction_query(direction, query_text)
        
        self.output(result, title=f"Q38 Response: {direction}")
    
    async def _q38_init(self):
        """Initialize Q38 cluster"""
        if not self.q38:
            if console:
                console.print("[red]Q38 connector not available[/red]")
            else:
                print("Q38 connector not available")
            return
        
        if console:
            console.print("[cyan]Initializing Q38 cluster...[/cyan]")
        else:
            print("Initializing Q38 cluster...")
        
        # Check cluster status
        status = await self.q38.check_cluster_health()
        self.output(status, title="Q38 Cluster Health")
    
    async def _q38_sync(self, event_data: str):
        """Broadcast sync event to all Q38 nodes"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        event = {
            'type': 'sync',
            'data': event_data,
            'source': 'aria-cli',
        }
        
        if console:
            console.print(f"[cyan]Broadcasting sync event: {event_data}[/cyan]")
        else:
            print(f"Broadcasting sync event: {event_data}")
        
        result = await self.q38.sync_event(event)
        self.output(result, title="Sync Result")
    
    def _show_layers(self):
        """Display all Q-Layers"""
        if console:
            table = Table(title="Q0-Q38 Cognitive Layers", show_header=True)
            table.add_column("Layer", style="cyan", width=5)
            table.add_column("Name", style="white")
            table.add_column("Domain", style="yellow")
            
            for layer in QLayer:
                domain = "FOUNDATION" if layer.value < 10 else \
                         "REASONING" if layer.value < 20 else \
                         "METACOGNITION" if layer.value < 30 else "TRANSCENDENCE"
                table.add_row(
                    str(layer.value),
                    layer.name.replace('_', ' '),
                    domain,
                )
            
            console.print(table)
        else:
            print("\nQ0-Q38 Cognitive Layers:")
            for layer in QLayer:
                print(f"  Q{layer.value:2d}: {layer.name}")
    
    def _set_layer(self, layer_num: int):
        """Set current working layer"""
        if 0 <= layer_num <= 38:
            self.context['current_layer'] = layer_num
            layer = QLayer(layer_num)
            if console:
                console.print(f"[green]Switched to {layer.name}[/green]")
            else:
                print(f"Switched to {layer.name}")
        else:
            if console:
                console.print("[red]Invalid layer. Use 0-38.[/red]")
            else:
                print("Invalid layer. Use 0-38.")
    
    def _show_history(self):
        """Display session history"""
        if not self.session_history:
            if console:
                console.print("[dim]No history yet[/dim]")
            else:
                print("No history yet")
            return
        
        if console:
            for i, entry in enumerate(self.session_history[-10:], 1):
                console.print(f"[dim]{i}.[/dim] [cyan]{entry['input']}[/cyan]")
                console.print(f"   [dim]Intent: {entry['parsed']['intent']}[/dim]")
        else:
            for i, entry in enumerate(self.session_history[-10:], 1):
                print(f"{i}. {entry['input']}")
                print(f"   Intent: {entry['parsed']['intent']}")
    
    def _display_result_rich(self, result: Dict[str, Any]):
        """Display result with rich formatting"""
        if not console:
            print(result)
            return
        
        # Main result panel
        if 'llm_response' in result and result['llm_response']:
            console.print(Panel(
                Markdown(result['llm_response']),
                title="ARIA Response",
                border_style="green",
            ))
        
        # Processing info
        if self.config['ui'].get('show_layer_info', True):
            info = result.get('processing', {})
            if info:
                console.print(f"[dim]Layer: Q{info.get('layer', '?')} | "
                            f"Operator: {info.get('operator', '?')} | "
                            f"Trace: {len(info.get('trace', []))} steps[/dim]")


# CLI Commands using Typer
if app:
    
    @app.command()
    def chat(
        llm: bool = typer.Option(True, "--llm/--no-llm", help="Enable LLM integration"),
        format: OutputFormat = typer.Option(OutputFormat.RICH, "--format", "-f", help="Output format"),
        config: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path"),
    ):
        """Start interactive ARIA session"""
        cli = AriaCLI(
            config_path=config,
            output_format=format,
            use_llm=llm,
        )
        cli.interactive_mode()
    
    @app.command()
    def ask(
        query: str = typer.Argument(..., help="Your question or command"),
        layer: int = typer.Option(8, "--layer", "-l", help="Q-Layer to use (0-38)"),
        format: OutputFormat = typer.Option(OutputFormat.RICH, "--format", "-f", help="Output format"),
    ):
        """Process a single query"""
        cli = AriaCLI(output_format=format)
        cli.context['current_layer'] = layer
        result = cli.process(query)
        cli.output(result)
    
    @app.command()
    def layers():
        """Show all Q0-Q38 layers"""
        cli = AriaCLI()
        cli._show_layers()
    
    @app.command()
    def status():
        """Show system status"""
        cli = AriaCLI()
        cli._show_status()
    
    @app.command()
    def version():
        """Show version information"""
        if console:
            console.print(f"[bold cyan]ARIA CLI[/bold cyan] v{AriaCLI.VERSION}")
            console.print(f"[dim]Q0-Q38 Cognitive Architecture[/dim]")
        else:
            print(f"ARIA CLI v{AriaCLI.VERSION}")
            print("Q0-Q38 Cognitive Architecture")


# =========================================================================
# Agent Commands - aria agent ...
# =========================================================================

# Import agents module
try:
    from .agents import (
        AriaAgent, AgentRegistry, AgentSwarm, AgentMessage,
        MessageType, MessagePriority, AgentCapability, AgentState,
        TaskAgent, ReasoningAgent, CoordinatorAgent, GeneratorAgent,
        create_agent, get_registry,
    )
    from .agent_channels import (
        ChannelManager, DirectChannel, BroadcastChannel,
        get_channel_manager,
    )
    HAS_AGENTS = True
except ImportError:
    HAS_AGENTS = False

agent_app = typer.Typer(
    name="agent",
    help="ARIA Agents - Autonomous AI agents with Q-System integration",
) if typer else None

if agent_app:
    app.add_typer(agent_app, name="agent")
    
    @agent_app.command("list")
    def agent_list():
        """List all registered agents"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        agents = registry.list_agents()
        
        if console:
            table = Table(title="Registered Agents")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="white")
            table.add_column("Q-Layer", style="magenta")
            table.add_column("State", style="green")
            table.add_column("Capabilities", style="dim")
            table.add_column("Messages", style="yellow")
            
            for a in agents:
                state_color = {
                    "IDLE": "green",
                    "BUSY": "yellow",
                    "ERROR": "red",
                    "STOPPED": "dim",
                }.get(a.state.name, "white")
                
                table.add_row(
                    a.agent_id[:16] + "...",
                    a.name,
                    f"Q{a.q_layer.value}",
                    f"[{state_color}]{a.state.name}[/{state_color}]",
                    ", ".join(c[:10] for c in [cap.name for cap in a.capabilities][:3]),
                    str(a.messages_processed),
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(agents)} agents[/dim]")
        else:
            for a in agents:
                print(f"{a.agent_id}: {a.name} (Q{a.q_layer.value}) - {a.state.name}")
    
    @agent_app.command("create")
    def agent_create(
        name: str = typer.Argument(..., help="Agent name"),
        agent_type: str = typer.Option("task", "--type", "-t", help="Agent type: task, reasoning, coordinator, generator"),
        layer: int = typer.Option(None, "--layer", "-l", help="Q-Layer (0-38)"),
        start: bool = typer.Option(False, "--start", "-s", help="Start agent after creation"),
    ):
        """Create a new agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        
        async def _create():
            # Create agent
            kwargs = {}
            if layer is not None:
                kwargs['q_layer'] = QLayer(layer)
            
            agent = create_agent(agent_type, name, **kwargs)
            
            # Register
            registry = get_registry()
            await registry.register(agent)
            
            if start:
                await agent.start()
            
            return agent
        
        try:
            agent = asyncio.run(_create())
            
            if console:
                console.print(Panel(
                    f"[bold green]Agent Created[/bold green]\n\n"
                    f"[cyan]ID:[/cyan] {agent.id}\n"
                    f"[cyan]Name:[/cyan] {agent.name}\n"
                    f"[cyan]Type:[/cyan] {agent_type}\n"
                    f"[cyan]Q-Layer:[/cyan] Q{agent.q_layer.value} ({agent.q_layer.name})\n"
                    f"[cyan]State:[/cyan] {agent.state.name}\n"
                    f"[cyan]Capabilities:[/cyan] {', '.join(c.name for c in agent.capabilities)}",
                    title="🤖 New Agent",
                    border_style="green",
                ))
            else:
                print(f"Created agent: {agent.id}")
        except Exception as e:
            rprint(f"[red]Error creating agent: {e}[/red]")
    
    @agent_app.command("start")
    def agent_start(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Start an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        asyncio.run(agent.start())
        rprint(f"[green]Started agent: {agent.id}[/green]")
    
    @agent_app.command("stop")
    def agent_stop(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Stop an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        asyncio.run(agent.stop())
        rprint(f"[yellow]Stopped agent: {agent.id}[/yellow]")
    
    @agent_app.command("status")
    def agent_status(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Get detailed agent status"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        registry = get_registry()
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        status = agent.status
        
        if console:
            console.print(Panel(
                f"[cyan]ID:[/cyan] {status.agent_id}\n"
                f"[cyan]Name:[/cyan] {status.name}\n"
                f"[cyan]State:[/cyan] {status.state.name}\n"
                f"[cyan]Q-Layer:[/cyan] Q{status.q_layer.value} ({status.q_layer.name})\n"
                f"[cyan]Capabilities:[/cyan] {', '.join(c.name for c in status.capabilities)}\n"
                f"[cyan]Current Task:[/cyan] {status.current_task or 'None'}\n"
                f"[cyan]Messages Processed:[/cyan] {status.messages_processed}\n"
                f"[cyan]Messages Pending:[/cyan] {status.messages_pending}\n"
                f"[cyan]Uptime:[/cyan] {status.uptime_seconds:.1f}s\n"
                f"[cyan]Last Activity:[/cyan] {status.last_activity or 'Never'}\n"
                f"[cyan]Error:[/cyan] {status.error or 'None'}",
                title=f"🤖 Agent Status: {status.name}",
                border_style="cyan",
            ))
        else:
            print(json.dumps(status.to_dict(), indent=2))
    
    @agent_app.command("send")
    def agent_send(
        recipient: str = typer.Argument(..., help="Recipient agent ID or name"),
        message: str = typer.Argument(..., help="Message content"),
        sender: str = typer.Option("cli", "--from", "-f", help="Sender ID"),
        priority: str = typer.Option("NORMAL", "--priority", "-p", help="Message priority"),
    ):
        """Send a message to an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(recipient) or registry.get_by_name(recipient)
        if not agent:
            rprint(f"[red]Agent not found: {recipient}[/red]")
            return
        
        try:
            priority_enum = MessagePriority[priority.upper()]
        except KeyError:
            priority_enum = MessagePriority.NORMAL
        
        msg = AgentMessage(
            type=MessageType.REQUEST,
            sender=sender,
            recipient=agent.id,
            payload={"message": message},
            priority=priority_enum,
        )
        
        asyncio.run(agent.receive(msg))
        rprint(f"[green]Message sent to {agent.name}[/green]")
        rprint(f"[dim]Message ID: {msg.id}[/dim]")
    
    @agent_app.command("types")
    def agent_types():
        """Show available agent types"""
        if console:
            table = Table(title="Agent Types")
            table.add_column("Type", style="cyan")
            table.add_column("Q-Layer", style="magenta")
            table.add_column("Description", style="white")
            table.add_column("Capabilities", style="dim")
            
            types = [
                ("task", "Q23", "Task execution agent", "SHELL_EXECUTION, FILE_OPERATIONS"),
                ("reasoning", "Q10", "Logical reasoning agent", "REASONING, ANALYSIS"),
                ("coordinator", "Q21", "Multi-agent coordinator", "AGENT_COORDINATION, TASK_DECOMPOSITION"),
                ("generator", "Q19", "Content generation agent", "TEXT_GENERATION, CODE_GENERATION"),
            ]
            
            for t in types:
                table.add_row(*t)
            
            console.print(table)
        else:
            print("Agent types: task, reasoning, coordinator, generator")
    
    @agent_app.command("capabilities")
    def agent_capabilities():
        """Show all agent capabilities"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        if console:
            table = Table(title="Agent Capabilities")
            table.add_column("Category", style="cyan")
            table.add_column("Capability", style="white")
            
            categories = {
                "Processing": ["TEXT_GENERATION", "CODE_GENERATION", "ANALYSIS", "SUMMARIZATION", "TRANSLATION"],
                "Data": ["FILE_OPERATIONS", "DATABASE_ACCESS", "WEB_SEARCH", "API_CALLS"],
                "System": ["SHELL_EXECUTION", "PROCESS_MANAGEMENT", "SCHEDULING"],
                "AI/ML": ["EMBEDDING", "CLASSIFICATION", "PREDICTION", "REASONING"],
                "Meta": ["AGENT_COORDINATION", "TASK_DECOMPOSITION", "SELF_IMPROVEMENT"],
            }
            
            for category, caps in categories.items():
                for cap in caps:
                    table.add_row(category, cap)
            
            console.print(table)


# Channel sub-commands
channel_app = typer.Typer(
    name="channel",
    help="Agent communication channels",
) if typer else None

if channel_app and agent_app:
    agent_app.add_typer(channel_app, name="channel")
    
    @channel_app.command("list")
    def channel_list():
        """List all channels"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        manager = get_channel_manager()
        channels = manager.list_channels()
        
        if console:
            table = Table(title="Agent Channels")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="white")
            table.add_column("Type", style="magenta")
            table.add_column("State", style="green")
            table.add_column("Messages", style="yellow")
            
            for ch in channels:
                state_color = {
                    "OPEN": "green",
                    "CLOSED": "dim",
                    "ERROR": "red",
                }.get(ch["state"], "white")
                
                table.add_row(
                    ch["id"][:20] + "...",
                    ch["name"],
                    ch["type"],
                    f"[{state_color}]{ch['state']}[/{state_color}]",
                    str(ch["metrics"]["messages_sent"]),
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(channels)} channels[/dim]")
        else:
            for ch in channels:
                print(f"{ch['id']}: {ch['name']} ({ch['type']}) - {ch['state']}")
    
    @channel_app.command("create")
    def channel_create(
        name: str = typer.Argument(..., help="Channel name"),
        channel_type: str = typer.Option("direct", "--type", "-t", help="Channel type: direct, broadcast, stream, persistent"),
        agent_a: str = typer.Option(None, "--agent-a", "-a", help="First agent (for direct/stream)"),
        agent_b: str = typer.Option(None, "--agent-b", "-b", help="Second agent (for direct/stream)"),
    ):
        """Create a new channel"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        manager = get_channel_manager()
        
        try:
            if channel_type == "direct":
                if not agent_a or not agent_b:
                    rprint("[red]Direct channel requires --agent-a and --agent-b[/red]")
                    return
                channel = manager.create_direct(name, agent_a, agent_b)
            elif channel_type == "broadcast":
                channel = manager.create_broadcast(name, agent_a)
            elif channel_type == "stream":
                if not agent_a or not agent_b:
                    rprint("[red]Stream channel requires --agent-a and --agent-b[/red]")
                    return
                channel = manager.create_stream(name, agent_a, agent_b)
            elif channel_type == "persistent":
                channel = manager.create_persistent(name)
            else:
                rprint(f"[red]Unknown channel type: {channel_type}[/red]")
                return
            
            asyncio.run(channel.open())
            
            rprint(f"[green]Created channel: {channel.id}[/green]")
            rprint(f"[dim]Type: {channel.type.name}, State: {channel.state.name}[/dim]")
        except Exception as e:
            rprint(f"[red]Error creating channel: {e}[/red]")


# Swarm sub-commands
swarm_app = typer.Typer(
    name="swarm",
    help="Agent swarm coordination",
) if typer else None

if swarm_app and agent_app:
    agent_app.add_typer(swarm_app, name="swarm")
    
    @swarm_app.command("create")
    def swarm_create(
        name: str = typer.Argument(..., help="Swarm name"),
    ):
        """Create a new agent swarm"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        
        swarm = AgentSwarm(name)
        asyncio.run(swarm.initialize())
        
        if console:
            console.print(Panel(
                f"[bold green]Swarm Created[/bold green]\n\n"
                f"[cyan]ID:[/cyan] {swarm.id}\n"
                f"[cyan]Name:[/cyan] {swarm.name}\n"
                f"[cyan]Coordinator:[/cyan] {swarm.coordinator.id}\n"
                f"[cyan]Members:[/cyan] 0",
                title="🐝 New Swarm",
                border_style="green",
            ))
        else:
            print(f"Created swarm: {swarm.id}")
    
    @swarm_app.command("status")
    def swarm_status(
        swarm_id: str = typer.Argument(..., help="Swarm ID"),
    ):
        """Get swarm status"""
        rprint("[yellow]Swarm status lookup not yet implemented[/yellow]")
        rprint("[dim]Use: aria agent swarm create <name> to create a swarm[/dim]")


# =========================================================================
# AriaSpace Commands - aria space ...
# =========================================================================

space_app = typer.Typer(
    name="space",
    help="AriaSpace - Personal codespace for phone ↔ computer sync",
) if typer else None

if space_app:
    app.add_typer(space_app, name="space")
    
    @space_app.command("create")
    def space_create(
        name: str = typer.Argument(..., help="Workspace name"),
        remote_host: str = typer.Argument(..., help="SSH host for remote device"),
        remote_path: str = typer.Argument(..., help="Remote directory path"),
        local_path: Optional[str] = typer.Option(None, "--local", "-l", help="Local directory path"),
        description: str = typer.Option("", "--desc", "-d", help="Workspace description"),
    ):
        """Create a new AriaSpace workspace"""
        space = AriaSpace()
        local = local_path or str(Path.home() / "aria-space" / name)
        
        try:
            ws = space.create_workspace(
                name=name,
                local_root=local,
                remote_root=remote_path,
                remote_host=remote_host,
                description=description,
            )
            if console:
                console.print(f"[green]✅ Created workspace '{name}'[/green]")
                console.print(f"   Local:  {ws.local_root}")
                console.print(f"   Remote: {remote_host}:{remote_path}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
            else:
                print(f"Error: {e}")
    
    @space_app.command("create-meta-ai")
    def space_create_meta_ai(
        remote_host: str = typer.Argument(..., help="SSH host for Android device"),
        name: str = typer.Option("meta-ai", "--name", "-n", help="Workspace name"),
    ):
        """Quick setup for Meta AI folder sync"""
        space = AriaSpace()
        try:
            ws = space.create_meta_ai_workspace(remote_host, name=name)
            if console:
                console.print(f"[green]✅ Created Meta AI workspace '{name}'[/green]")
                console.print(f"   Local:  {ws.local_root}")
                console.print(f"   Remote: {remote_host}:/storage/emulated/0/Meta AI")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("list")
    def space_list():
        """List all AriaSpace workspaces"""
        space = AriaSpace()
        workspaces = space.list_workspaces()
        
        if not workspaces:
            if console:
                console.print("[dim]No workspaces configured[/dim]")
            else:
                print("No workspaces configured")
            return
        
        if console:
            table = Table(title="AriaSpace Workspaces")
            table.add_column("Name", style="cyan")
            table.add_column("Local", style="white")
            table.add_column("Remote", style="green")
            table.add_column("Last Sync", style="dim")
            
            for ws in workspaces:
                last_sync = ws.last_sync.strftime("%Y-%m-%d %H:%M") if ws.last_sync else "Never"
                table.add_row(
                    ws.name,
                    str(ws.local_root),
                    f"{ws.remote_host}:{ws.remote_root}",
                    last_sync,
                )
            
            console.print(table)
        else:
            for ws in workspaces:
                print(f"{ws.name}: {ws.local_root} <-> {ws.remote_host}:{ws.remote_root}")
    
    @space_app.command("sync")
    def space_sync(
        name: str = typer.Argument(..., help="Workspace name"),
        direction: str = typer.Option("bidirectional", "--direction", "-d", help="Sync direction: upload, download, bidirectional"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be done"),
    ):
        """Synchronize a workspace"""
        space = AriaSpace()
        
        dir_map = {
            "upload": SyncDirection.UPLOAD,
            "download": SyncDirection.DOWNLOAD,
            "bidirectional": SyncDirection.BIDIRECTIONAL,
            "up": SyncDirection.UPLOAD,
            "down": SyncDirection.DOWNLOAD,
            "both": SyncDirection.BIDIRECTIONAL,
        }
        
        try:
            result = space.sync(name, direction=dir_map.get(direction, SyncDirection.BIDIRECTIONAL), dry_run=dry_run)
            if console and result.success:
                console.print(f"[green]✅ Sync complete[/green]")
            elif not result.success:
                console.print(f"[yellow]⚠️ Sync completed with errors[/yellow]")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("pull")
    def space_pull(name: str = typer.Argument(..., help="Workspace name")):
        """Download from remote to local"""
        space = AriaSpace()
        space.pull(name)
    
    @space_app.command("push")
    def space_push(name: str = typer.Argument(..., help="Workspace name")):
        """Upload from local to remote"""
        space = AriaSpace()
        space.push(name)
    
    @space_app.command("files")
    def space_files(
        name: str = typer.Argument(..., help="Workspace name"),
        path: str = typer.Option("", "--path", "-p", help="Relative path"),
    ):
        """List files in workspace"""
        space = AriaSpace()
        
        try:
            files = space.list_files(name, path)
            
            if console:
                table = Table(title=f"Files in '{name}'")
                table.add_column("Status", style="white", width=10)
                table.add_column("Path", style="cyan")
                table.add_column("Local Size", style="dim", justify="right")
                table.add_column("Remote Size", style="dim", justify="right")
                
                status_icons = {
                    "synced": "[green]✓[/green]",
                    "modified_local": "[yellow]↑[/yellow]",
                    "modified_remote": "[blue]↓[/blue]",
                    "new_local": "[green]+L[/green]",
                    "new_remote": "[blue]+R[/blue]",
                    "conflict": "[red]!![/red]",
                }
                
                for f in files:
                    icon = status_icons.get(f.status.value, "?")
                    table.add_row(
                        icon,
                        f.relative_path,
                        f"{f.local_size:,}" if f.local_size else "-",
                        f"{f.remote_size:,}" if f.remote_size else "-",
                    )
                
                console.print(table)
                console.print(f"\n[dim]Total: {len(files)} files[/dim]")
            else:
                for f in files:
                    print(f"{f.status.value:15} {f.relative_path}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("browse")
    def space_browse(
        name: str = typer.Argument(..., help="Workspace name"),
        path: str = typer.Option("", "--path", "-p", help="Relative path"),
    ):
        """Browse remote directory"""
        space = AriaSpace()
        
        try:
            entries = space.browse_remote(name, path)
            
            if console:
                table = Table(title=f"Remote: {path or '/'}")
                table.add_column("Type", style="dim", width=4)
                table.add_column("Name", style="cyan")
                table.add_column("Size", style="dim", justify="right")
                table.add_column("Modified", style="dim")
                
                for entry in entries:
                    icon = "📁" if entry["is_dir"] else "📄"
                    size = "-" if entry["is_dir"] else f"{entry['size']:,}"
                    table.add_row(icon, entry["name"], size, entry.get("modified", ""))
                
                console.print(table)
            else:
                for entry in entries:
                    print(f"{'d' if entry['is_dir'] else '-'} {entry['name']}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("status")
    def space_status(name: str = typer.Argument(..., help="Workspace name")):
        """Show workspace status"""
        space = AriaSpace()
        
        try:
            status = space.get_status(name)
            
            if console:
                panel_content = (
                    f"[cyan]Workspace:[/cyan] {status['name']}\n"
                    f"[cyan]Local:[/cyan] {status['local_root']}\n"
                    f"[cyan]Remote:[/cyan] {status['remote_root']}\n"
                    f"[cyan]Host:[/cyan] {status['remote_host']}\n"
                    f"[cyan]Connected:[/cyan] {'[green]Yes[/green]' if status['connected'] else '[red]No[/red]'}\n"
                    f"[cyan]Local Files:[/cyan] {status['local_files']}\n"
                    f"[cyan]Last Sync:[/cyan] {status['last_sync'] or 'Never'}\n"
                    f"[cyan]Watching:[/cyan] {'Yes' if status['watching'] else 'No'}"
                )
                console.print(Panel(panel_content, title="Workspace Status"))
            else:
                for k, v in status.items():
                    print(f"{k}: {v}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("delete")
    def space_delete(
        name: str = typer.Argument(..., help="Workspace name"),
        delete_local: bool = typer.Option(False, "--delete-local", help="Also delete local files"),
    ):
        """Delete a workspace"""
        space = AriaSpace()
        
        if console and not delete_local:
            if not Confirm.ask(f"Delete workspace '{name}'?"):
                return
        
        space.delete_workspace(name, delete_local=delete_local)


# =========================================================================
# Termux Setup Commands - aria termux ...
# =========================================================================

termux_app = typer.Typer(
    name="termux",
    help="Termux device setup and configuration",
) if typer else None

if termux_app:
    app.add_typer(termux_app, name="termux")
    
    @termux_app.command("wizard")
    def termux_wizard():
        """Interactive setup wizard for Termux connection"""
        setup = TermuxSetup()
        setup.wizard()
    
    @termux_app.command("discover")
    def termux_discover(
        network: str = typer.Option("192.168.1", "--network", "-n", help="Network prefix"),
        port: int = typer.Option(8022, "--port", "-p", help="SSH port to scan"),
    ):
        """Discover Termux devices on local network"""
        setup = TermuxSetup()
        devices = setup.discover_devices(network, port)
        
        if console:
            if devices:
                table = Table(title="Discovered Devices")
                table.add_column("IP", style="cyan")
                table.add_column("Port", style="white")
                table.add_column("Hostname", style="green")
                
                for d in devices:
                    table.add_row(d.ip_address, str(d.port), d.hostname)
                
                console.print(table)
            else:
                console.print("[yellow]No devices found[/yellow]")
    
    @termux_app.command("setup-script")
    def termux_script(
        output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    ):
        """Generate Termux setup script"""
        setup = TermuxSetup()
        
        if output:
            path = setup.save_termux_script(output)
            if console:
                console.print(f"[green]Saved to: {path}[/green]")
        else:
            if console:
                console.print(Panel(setup.generate_termux_script(), title="Termux Setup Script"))
            else:
                print(setup.generate_termux_script())
    
    @termux_app.command("add-host")
    def termux_add_host(
        name: str = typer.Argument(..., help="Host alias (e.g., termux-phone)"),
        ip: str = typer.Argument(..., help="IP address"),
        port: int = typer.Option(8022, "--port", "-p", help="SSH port"),
        user: str = typer.Option("u0_a", "--user", "-u", help="Username"),
    ):
        """Add Termux device to SSH config"""
        setup = TermuxSetup()
        setup.append_ssh_config(name, ip, port, user)
        
        if console:
            console.print(f"[green]✅ Added '{name}' to SSH config[/green]")
            console.print(f"[dim]Connect with: ssh {name}[/dim]")
    
    @termux_app.command("test")
    def termux_test(host: str = typer.Argument(..., help="SSH host to test")):
        """Test connection to Termux device"""
        setup = TermuxSetup()
        success, message = setup.test_connection(host)
        
        if console:
            if success:
                console.print(f"[green]✅ {message}[/green]")
                
                # Get device info
                info = setup.get_device_info(host)
                if info:
                    table = Table(title="Device Info")
                    table.add_column("Property", style="cyan")
                    table.add_column("Value", style="white")
                    
                    for k, v in info.items():
                        if v:
                            table.add_row(k.replace("_", " ").title(), v)
                    
                    console.print(table)
            else:
                console.print(f"[red]❌ {message}[/red]")
    
    @termux_app.command("find-meta-ai")
    def termux_find_meta_ai(host: str = typer.Argument(..., help="SSH host")):
        """Find Meta AI folder on device"""
        setup = TermuxSetup()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task("Searching for Meta AI folder...", total=None)
                path = setup.find_meta_ai_folder(host)
        else:
            path = setup.find_meta_ai_folder(host)
        
        if path:
            if console:
                console.print(f"[green]✅ Found: {path}[/green]")
            else:
                print(f"Found: {path}")
        else:
            if console:
                console.print("[yellow]Meta AI folder not found[/yellow]")
    
    @termux_app.command("folders")
    def termux_folders(host: str = typer.Argument(..., help="SSH host")):
        """List common Android folders on device"""
        setup = TermuxSetup()
        folders = setup.list_android_folders(host)
        
        if console:
            table = Table(title="Android Folders")
            table.add_column("Name", style="cyan")
            table.add_column("Path", style="white")
            table.add_column("Size", style="dim")
            table.add_column("Status", style="green")
            
            for f in folders:
                status = "✓" if f["exists"] else "✗"
                color = "green" if f["exists"] else "red"
                table.add_row(
                    f["name"],
                    f["path"],
                    f.get("size") or "-",
                    f"[{color}]{status}[/{color}]",
                )
            
            console.print(table)


# =========================================================================
# Files Commands - aria files ...
# =========================================================================

# Import file manager
try:
    from .file_manager import (
        AriaFileManager, get_file_manager,
        FileType, Platform, FileLocation,
    )
    HAS_FILES = True
except ImportError:
    HAS_FILES = False

files_app = typer.Typer(
    name="files",
    help="Aria File Manager - View, update, sync, and organize files",
) if typer else None

if files_app:
    app.add_typer(files_app, name="files")
    
    @files_app.command("env")
    def files_env():
        """Show current environment"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        env = manager.get_environment()
        
        if console:
            console.print(Panel(
                f"[cyan]Platform:[/cyan] {env['platform']}\n"
                f"[cyan]Hostname:[/cyan] {env['hostname']}\n"
                f"[cyan]User:[/cyan] {env['user']}\n"
                f"[cyan]Home:[/cyan] {env['home_dir']}\n"
                f"[cyan]Current:[/cyan] {env['current_dir']}\n"
                f"[cyan]Shell:[/cyan] {env['shell']}\n"
                f"[cyan]Python:[/cyan] {env['python_version']}\n"
                f"[cyan]ARIA:[/cyan] v{env['aria_version']}\n"
                f"[cyan]GUI:[/cyan] {'Yes' if env['has_gui'] else 'No'}\n"
                f"[cyan]SSH:[/cyan] {'Yes' if env['has_ssh'] else 'No'}",
                title="🌍 Environment",
                border_style="cyan",
            ))
        else:
            for k, v in env.items():
                print(f"{k}: {v}")
    
    @files_app.command("list")
    def files_list(
        path: Optional[str] = typer.Argument(None, help="Directory path"),
        pattern: str = typer.Option("*", "--pattern", "-p", help="Glob pattern"),
        recursive: bool = typer.Option(False, "--recursive", "-r", help="List recursively"),
        type_filter: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type: code, text, image, etc."),
    ):
        """List files in directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        types = [type_filter] if type_filter else None
        files = manager.list_files(path, pattern, recursive, types)
        
        if console:
            table = Table(title=f"Files in {path or '.'}")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="magenta")
            table.add_column("Size", style="dim")
            table.add_column("Modified", style="dim")
            
            for f in files:
                icon = "📁" if f['is_dir'] else "📄"
                size = "-" if f['is_dir'] else f"{f['size']:,} B"
                mtime = f['modified'][:10] if f['modified'] else "-"
                table.add_row(
                    f"{icon} {f['name']}",
                    f['file_type'],
                    size,
                    mtime,
                )
            
            console.print(table)
            console.print(f"[dim]Total: {len(files)} items[/dim]")
        else:
            for f in files:
                print(f"{'[D]' if f['is_dir'] else '[F]'} {f['name']}")
    
    @files_app.command("remote")
    def files_remote(
        host: str = typer.Argument(..., help="SSH host"),
        path: str = typer.Option("~", "--path", "-p", help="Remote path"),
    ):
        """List files on remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        files = manager.list_remote(host, path)
        
        if not files:
            rprint(f"[yellow]No files found or unable to connect to {host}[/yellow]")
            return
        
        if console:
            table = Table(title=f"Remote: {host}:{path}")
            table.add_column("Name", style="cyan")
            table.add_column("Size", style="dim")
            table.add_column("Permissions", style="dim")
            
            for f in files:
                icon = "📁" if f['is_dir'] else "📄"
                table.add_row(
                    f"{icon} {f['name']}",
                    str(f['size']),
                    f['permissions'],
                )
            
            console.print(table)
    
    @files_app.command("search")
    def files_search(
        query: str = typer.Argument(..., help="Search query"),
        path: Optional[str] = typer.Option(None, "--path", "-p", help="Starting path"),
    ):
        """Search for files"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        files = manager.search(query, path)
        
        if console:
            table = Table(title=f"Search: '{query}'")
            table.add_column("Name", style="cyan")
            table.add_column("Path", style="dim")
            table.add_column("Type", style="magenta")
            
            for f in files[:50]:  # Limit results
                table.add_row(f['name'], f['path'], f['file_type'])
            
            console.print(table)
            console.print(f"[dim]Found: {len(files)} matches[/dim]")
    
    @files_app.command("tree")
    def files_tree(
        path: Optional[str] = typer.Argument(None, help="Root path"),
        depth: int = typer.Option(3, "--depth", "-d", help="Max depth"),
    ):
        """Show directory tree"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        tree = manager.tree(path, depth)
        
        def print_tree(node, prefix="", is_last=True):
            connector = "└── " if is_last else "├── "
            icon = "📁" if node.get('is_dir', True) else "📄"
            console.print(f"{prefix}{connector}{icon} {node['name']}")
            
            children = node.get('children', [])
            for i, child in enumerate(children):
                is_last_child = i == len(children) - 1
                new_prefix = prefix + ("    " if is_last else "│   ")
                print_tree(child, new_prefix, is_last_child)
        
        if console:
            console.print(f"[bold]{tree['name']}[/bold]")
            for i, child in enumerate(tree.get('children', [])):
                print_tree(child, "", i == len(tree.get('children', [])) - 1)
    
    @files_app.command("create")
    def files_create(
        path: str = typer.Argument(..., help="File/directory path"),
        content: str = typer.Option("", "--content", "-c", help="File content"),
        directory: bool = typer.Option(False, "--dir", "-d", help="Create directory"),
    ):
        """Create file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.create(path, content, directory)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("read")
    def files_read(
        path: str = typer.Argument(..., help="File path"),
        lines: int = typer.Option(0, "--lines", "-n", help="Number of lines (0=all)"),
    ):
        """Read file content"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        content, result = manager.read(path)
        
        if result['success']:
            if lines > 0:
                content = '\n'.join(content.split('\n')[:lines])
            
            if console:
                from rich.syntax import Syntax
                ext = Path(path).suffix.lstrip('.')
                lang = ext if ext in ('py', 'js', 'ts', 'json', 'html', 'css', 'md') else 'text'
                syntax = Syntax(content, lang, theme="monokai", line_numbers=True)
                console.print(syntax)
            else:
                print(content)
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("save")
    def files_save(
        path: str = typer.Argument(..., help="File path"),
        content: str = typer.Argument(..., help="Content to save"),
    ):
        """Save content to file"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.save(path, content)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("delete")
    def files_delete(
        path: str = typer.Argument(..., help="File/directory path"),
        recursive: bool = typer.Option(False, "--recursive", "-r", help="Delete recursively"),
        force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    ):
        """Delete file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        if not force:
            confirm = typer.confirm(f"Delete {path}?")
            if not confirm:
                rprint("[yellow]Cancelled[/yellow]")
                return
        
        manager = get_file_manager()
        result = manager.delete(path, recursive)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("copy")
    def files_copy(
        source: str = typer.Argument(..., help="Source path"),
        destination: str = typer.Argument(..., help="Destination path"),
    ):
        """Copy file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.copy(source, destination)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("move")
    def files_move(
        source: str = typer.Argument(..., help="Source path"),
        destination: str = typer.Argument(..., help="Destination path"),
    ):
        """Move file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.move(source, destination)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("upload")
    def files_upload(
        local_path: str = typer.Argument(..., help="Local file path"),
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_path: str = typer.Argument(..., help="Remote destination path"),
    ):
        """Upload file to remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task(f"Uploading to {host}...", total=None)
                result = manager.upload(local_path, host, remote_path)
        else:
            result = manager.upload(local_path, host, remote_path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[dim]Transferred: {result['bytes_transferred']:,} bytes[/dim]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("download")
    def files_download(
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_path: str = typer.Argument(..., help="Remote file path"),
        local_path: str = typer.Argument(..., help="Local destination path"),
    ):
        """Download file from remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task(f"Downloading from {host}...", total=None)
                result = manager.download(host, remote_path, local_path)
        else:
            result = manager.download(host, remote_path, local_path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[dim]Transferred: {result['bytes_transferred']:,} bytes[/dim]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("sync")
    def files_sync(
        local_dir: str = typer.Argument(..., help="Local directory"),
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_dir: str = typer.Argument(..., help="Remote directory"),
        direction: str = typer.Option("bidirectional", "--direction", "-d", help="upload, download, or bidirectional"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview without syncing"),
    ):
        """Sync folder with remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        results = manager.sync(local_dir, host, remote_dir, direction, dry_run)
        
        for result in results:
            if result['success']:
                rprint(f"[green]✅ {result['message']}[/green]")
            else:
                rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("open")
    def files_open(
        path: str = typer.Argument(..., help="File path to open"),
    ):
        """Open file with default application"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.open(path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("serve")
    def files_serve(
        path: str = typer.Argument(..., help="HTML file or directory to serve"),
        port: int = typer.Option(8080, "--port", "-p", help="Port to serve on"),
        no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser"),
    ):
        """Serve HTML file locally"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.serve(path, port, not no_browser)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint("[dim]Press Ctrl+C to stop[/dim]")
            try:
                while True:
                    import time
                    time.sleep(1)
            except KeyboardInterrupt:
                manager.stop_server(port)
                rprint("\n[yellow]Server stopped[/yellow]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("route")
    def files_route(
        path: str = typer.Argument(..., help="Local file to serve and route"),
        host: str = typer.Argument(..., help="Remote host to route to"),
        port: int = typer.Option(8080, "--port", "-p", help="Remote port"),
    ):
        """Serve file and route to remote host via SSH tunnel"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.route(path, host, port)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[cyan]Access from {host} at: http://localhost:{port}/[/cyan]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("organize")
    def files_organize(
        source_dir: str = typer.Argument(..., help="Directory to organize"),
        target_dir: Optional[str] = typer.Option(None, "--target", "-t", help="Target directory"),
        by: str = typer.Option("type", "--by", "-b", help="Organize by: type, date, extension"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview without moving"),
    ):
        """Organize files into folders"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        results = manager.organize(source_dir, target_dir, by, dry_run)
        
        if console:
            table = Table(title="Organization Results")
            table.add_column("File", style="cyan")
            table.add_column("Destination", style="white")
            table.add_column("Status", style="green")
            
            for result in results:
                status = "✅" if result['success'] else "❌"
                table.add_row(
                    Path(result['source']).name,
                    result['destination'] or "-",
                    status,
                )
            
            console.print(table)
            console.print(f"[dim]{'[DRY RUN] ' if dry_run else ''}Organized {len(results)} files[/dim]")
    
    @files_app.command("verify")
    def files_verify(
        path: str = typer.Argument(..., help="File path to verify"),
    ):
        """Verify file exists and is readable"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        valid, result = manager.verify(path)
        
        if valid:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("message")
    def files_message(
        recipient: str = typer.Argument(..., help="Target device (SSH host) or 'local'"),
        message: str = typer.Argument(..., help="Message content"),
    ):
        """Send message to another device"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.message(recipient, message)
        
        if result.get('success'):
            rprint(f"[green]✅ Message sent to {recipient}[/green]")
        else:
            rprint(f"[red]❌ {result.get('error', 'Failed to send message')}[/red]")


# =============================================================================
# Infinite Storage Commands
# =============================================================================

# Try to import infinite storage
try:
    from .infinite_storage import (
        InfiniteStorage,
        StorageConfig,
        StorageBackend,
        CompressionLevel,
        get_storage,
    )
    HAS_INFINITE_STORAGE = True
except ImportError:
    HAS_INFINITE_STORAGE = False
    InfiniteStorage = None

# Create storage app
storage_app = typer.Typer(
    name="storage",
    help="Infinite Storage - Multi-backend cloud storage with compression & encryption",
) if typer else None

if storage_app:
    app.add_typer(storage_app, name="storage")
    
    @storage_app.command("status")
    def storage_status():
        """Show storage status and statistics"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def check():
            await storage.connect()
            health = await storage.health_check()
            return health
        
        health = asyncio.run(check())
        
        table = Table(title="📦 Infinite Storage Status")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Status", health.get('status', 'unknown'))
        table.add_row("API Available", "✅ Yes" if health.get('api_available') else "❌ No")
        table.add_row("Mode", "API" if health.get('api_available') else "Local Cache")
        
        if health.get('cache_stats'):
            stats = health['cache_stats']
            table.add_row("Cache Size", f"{stats.get('size', 0)} / {stats.get('max_size', 0)}")
            table.add_row("Cache Hit Rate", f"{stats.get('hit_rate', 0)}%")
        
        console.print(table)
    
    @storage_app.command("store")
    def storage_store(
        key: str = typer.Argument(..., help="Storage key"),
        value: str = typer.Argument(..., help="Value to store (or @filename for file)"),
        backend: str = typer.Option("REDIS", "-b", "--backend", help="Backend: REDIS, POSTGRESQL, S3, LOCAL"),
        ttl: int = typer.Option(None, "-t", "--ttl", help="Time-to-live in seconds"),
        no_compress: bool = typer.Option(False, "--no-compress", help="Disable compression"),
        no_encrypt: bool = typer.Option(False, "--no-encrypt", help="Disable encryption"),
    ):
        """Store data in infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        # Check if value is a file reference
        if value.startswith("@"):
            file_path = Path(value[1:])
            if file_path.exists():
                value = file_path.read_text()
            else:
                rprint(f"[red]File not found: {file_path}[/red]")
                return
        
        async def do_store():
            await storage.connect()
            return await storage.store(
                key=key,
                data=value,
                backend=StorageBackend(backend),
                ttl_seconds=ttl,
                use_compression=not no_compress,
                use_encryption=not no_encrypt,
            )
        
        result = asyncio.run(do_store())
        
        if result.success:
            rprint(f"[green]✅ Stored: {key}[/green]")
            rprint(f"   Size: {result.size_bytes} bytes")
            rprint(f"   Backend: {result.backend}")
            rprint(f"   Compressed: {'Yes' if result.compressed else 'No'}")
            rprint(f"   Encrypted: {'Yes' if result.encrypted else 'No'}")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("get")
    def storage_get(
        key: str = typer.Argument(..., help="Storage key"),
        output: str = typer.Option(None, "-o", "--output", help="Output file (optional)"),
        raw: bool = typer.Option(False, "--raw", help="Output raw value without formatting"),
    ):
        """Retrieve data from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_get():
            await storage.connect()
            return await storage.retrieve(key)
        
        result = asyncio.run(do_get())
        
        if result.success:
            if output:
                # Save to file
                Path(output).write_text(str(result.data))
                rprint(f"[green]✅ Saved to: {output}[/green]")
            elif raw:
                print(result.data)
            else:
                rprint(f"[green]✅ Retrieved: {key}[/green]")
                rprint(f"   From Cache: {'Yes' if result.from_cache else 'No'}")
                console.print(Panel(str(result.data), title=key))
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("delete")
    def storage_delete(
        key: str = typer.Argument(..., help="Storage key to delete"),
        force: bool = typer.Option(False, "-f", "--force", help="Skip confirmation"),
    ):
        """Delete data from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        if not force:
            confirm = Confirm.ask(f"Delete {key}?")
            if not confirm:
                rprint("Cancelled")
                return
        
        import asyncio
        storage = get_storage()
        
        async def do_delete():
            await storage.connect()
            return await storage.delete(key)
        
        result = asyncio.run(do_delete())
        
        if result.success:
            rprint(f"[green]✅ Deleted: {key}[/green]")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("upload")
    def storage_upload(
        file_path: str = typer.Argument(..., help="File to upload"),
        key: str = typer.Option(None, "-k", "--key", help="Custom storage key"),
        backend: str = typer.Option("S3", "-b", "--backend", help="Backend: REDIS, POSTGRESQL, S3, LOCAL"),
        ttl: int = typer.Option(None, "-t", "--ttl", help="Time-to-live in seconds"),
    ):
        """Upload file to infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_upload():
            await storage.connect()
            return await storage.store_file(
                file_path=file_path,
                key=key,
                backend=StorageBackend(backend),
                ttl_seconds=ttl,
            )
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Uploading...", total=None)
            result = asyncio.run(do_upload())
        
        if result.success:
            rprint(f"[green]✅ Uploaded: {file_path}[/green]")
            rprint(f"   Key: {result.key}")
            rprint(f"   Size: {result.size_bytes} bytes")
            rprint(f"   Backend: {result.backend}")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("download")
    def storage_download(
        key: str = typer.Argument(..., help="Storage key"),
        output: str = typer.Argument(..., help="Output file path"),
    ):
        """Download file from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_download():
            await storage.connect()
            return await storage.download_file(key, output)
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Downloading...", total=None)
            result = asyncio.run(do_download())
        
        if result.success:
            rprint(f"[green]✅ Downloaded: {key} → {output}[/green]")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("list")
    def storage_list(
        pattern: str = typer.Argument("*", help="Key pattern (e.g., 'file:*')"),
    ):
        """List stored keys"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_list():
            await storage.connect()
            return await storage.list_keys(pattern)
        
        keys = asyncio.run(do_list())
        
        if keys:
            table = Table(title=f"🔑 Keys matching '{pattern}'")
            table.add_column("#", style="dim")
            table.add_column("Key", style="cyan")
            
            for i, key in enumerate(keys, 1):
                table.add_row(str(i), key)
            
            console.print(table)
            rprint(f"[dim]Total: {len(keys)} keys[/dim]")
        else:
            rprint("[yellow]No keys found[/yellow]")
    
    @storage_app.command("cache")
    def storage_cache(
        action: str = typer.Argument("stats", help="Action: stats, clear"),
    ):
        """Manage local cache"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        storage = get_storage()
        
        if action == "clear":
            storage.clear_cache()
            rprint("[green]✅ Cache cleared[/green]")
        else:
            # Stats
            storage.print_stats()
    
    @storage_app.command("config")
    def storage_config(
        api_url: str = typer.Option(None, "--api-url", help="Storage API URL"),
        backend: str = typer.Option(None, "--backend", help="Default backend"),
        compression: str = typer.Option(None, "--compression", help="Compression: NONE, FAST, BALANCED, MAXIMUM"),
        encryption: bool = typer.Option(None, "--encryption", help="Enable encryption"),
    ):
        """View or update storage configuration"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        # Show current config
        storage = get_storage()
        config = storage.config
        
        table = Table(title="⚙️ Storage Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("API URL", config.api_url)
        table.add_row("Default Backend", config.default_backend.value)
        table.add_row("Compression", config.compression.value)
        table.add_row("Encryption", "Enabled" if config.encryption_enabled else "Disabled")
        table.add_row("Cache Enabled", "Yes" if config.cache_enabled else "No")
        table.add_row("Cache Max Size", str(config.cache_max_size))
        table.add_row("Cache TTL", f"{config.cache_ttl_seconds}s")
        table.add_row("Timeout", f"{config.timeout_seconds}s")
        
        console.print(table)
        
        rprint("\n[dim]Set via environment variables:[/dim]")
        rprint("  ARIA_STORAGE_API_URL, ARIA_STORAGE_BACKEND")
        rprint("  ARIA_STORAGE_COMPRESSION, ARIA_STORAGE_ENCRYPTION")


# =============================================================================
# GitHub Automation Commands (F1/M1 Cycle Integration)
# =============================================================================

# Try to import github automation
try:
    from .github_automation import (
        GitHubCLI,
        GitHubAutomation,
        F1CycleEngine,
        M1MasterOrchestrator,
        F1Phase,
        CycleStatus,
        SystemType,
        get_github_cli,
        get_github_automation,
        quick_status,
    )
    HAS_GITHUB_AUTOMATION = True
except ImportError:
    HAS_GITHUB_AUTOMATION = False
    GitHubCLI = None

# Create github app
github_app = typer.Typer(
    name="github",
    help="GitHub Automation with F1/M1 Cycle Integration",
) if typer else None

if github_app:
    app.add_typer(github_app, name="github")
    
    @github_app.command("status")
    def github_status():
        """Show GitHub authentication and repo status"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        
        async def check():
            return await quick_status()
        
        status = asyncio.run(check())
        
        table = Table(title="🐙 GitHub Status")
        table.add_column("Item", style="cyan")
        table.add_column("Status", style="green")
        
        auth_status = "✅ Authenticated" if status.get("authenticated") else "❌ Not authenticated"
        table.add_row("Authentication", auth_status)
        table.add_row("gh CLI", "✅ Available" if status.get("gh_available") else "❌ Not found")
        
        if status.get("repo"):
            repo = status["repo"]
            table.add_row("Repository", repo.get("name", "Unknown"))
            table.add_row("Owner", str(repo.get("owner", {}).get("login", "Unknown")))
            table.add_row("Default Branch", repo.get("defaultBranchRef", {}).get("name", "main"))
        
        console.print(table)
    
    @github_app.command("auth")
    def github_auth(
        web: bool = typer.Option(True, "--web", help="Open browser for authentication"),
        status_only: bool = typer.Option(False, "--status", help="Just show auth status"),
    ):
        """Authenticate with GitHub"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        if status_only:
            result = asyncio.run(gh.auth_status())
            if result.success:
                rprint("[green]✅ Authenticated with GitHub[/green]")
                rprint(f"[dim]{result.stdout}[/dim]")
            else:
                rprint("[red]❌ Not authenticated[/red]")
            return
        
        rprint("[cyan]🔐 Opening browser for GitHub authentication...[/cyan]")
        result = asyncio.run(gh.auth_login(web=web))
        if result.success:
            rprint("[green]✅ Successfully authenticated![/green]")
        else:
            rprint(f"[red]❌ Authentication failed: {result.stderr}[/red]")
    
    @github_app.command("repos")
    def github_repos(
        owner: str = typer.Option(None, "--owner", "-o", help="Repository owner"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max repos to show"),
    ):
        """List GitHub repositories"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching repositories...[/cyan]"):
            result = asyncio.run(gh.repo_list(owner=owner, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        repos = result.parsed_data or []
        
        table = Table(title=f"📁 Repositories ({len(repos)})")
        table.add_column("Name", style="cyan")
        table.add_column("Owner", style="blue")
        table.add_column("Visibility", style="green")
        table.add_column("Updated", style="dim")
        
        for repo in repos:
            table.add_row(
                repo.get("name", ""),
                str(repo.get("owner", {}).get("login", "")),
                repo.get("visibility", ""),
                repo.get("updatedAt", "")[:10] if repo.get("updatedAt") else ""
            )
        
        console.print(table)
    
    @github_app.command("issues")
    def github_issues(
        state: str = typer.Option("open", "--state", "-s", help="Issue state: open, closed, all"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max issues to show"),
    ):
        """List GitHub issues"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching issues...[/cyan]"):
            result = asyncio.run(gh.issue_list(state=state, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        issues = result.parsed_data or []
        
        table = Table(title=f"🔖 Issues ({len(issues)})")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("State", style="green")
        table.add_column("Author", style="blue")
        
        for issue in issues:
            table.add_row(
                str(issue.get("number", "")),
                issue.get("title", "")[:50],
                issue.get("state", ""),
                str(issue.get("author", {}).get("login", ""))
            )
        
        console.print(table)
    
    @github_app.command("prs")
    def github_prs(
        state: str = typer.Option("open", "--state", "-s", help="PR state: open, closed, merged, all"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max PRs to show"),
    ):
        """List pull requests"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching pull requests...[/cyan]"):
            result = asyncio.run(gh.pr_list(state=state, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        prs = result.parsed_data or []
        
        table = Table(title=f"🔀 Pull Requests ({len(prs)})")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("State", style="green")
        table.add_column("Branch", style="yellow")
        table.add_column("Author", style="blue")
        
        for pr in prs:
            table.add_row(
                str(pr.get("number", "")),
                pr.get("title", "")[:40],
                pr.get("state", ""),
                pr.get("headRefName", "")[:20],
                str(pr.get("author", {}).get("login", ""))
            )
        
        console.print(table)
    
    @github_app.command("workflows")
    def github_workflows():
        """List GitHub Actions workflows"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching workflows...[/cyan]"):
            result = asyncio.run(gh.workflow_list())
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        workflows = result.parsed_data or []
        
        table = Table(title="⚡ GitHub Workflows")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("State", style="green")
        table.add_column("Path", style="dim")
        
        for wf in workflows:
            table.add_row(
                str(wf.get("id", "")),
                wf.get("name", ""),
                wf.get("state", ""),
                wf.get("path", "")
            )
        
        console.print(table)
    
    @github_app.command("runs")
    def github_runs(
        workflow: str = typer.Option(None, "--workflow", "-w", help="Filter by workflow"),
        limit: int = typer.Option(10, "--limit", "-l", help="Max runs to show"),
    ):
        """List recent workflow runs"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching workflow runs...[/cyan]"):
            result = asyncio.run(gh.run_list(workflow=workflow, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        runs = result.parsed_data or []
        
        table = Table(title="🏃 Workflow Runs")
        table.add_column("ID", style="cyan")
        table.add_column("Workflow", style="white")
        table.add_column("Status", style="yellow")
        table.add_column("Conclusion", style="green")
        
        for run in runs:
            conclusion = run.get("conclusion", "")
            if conclusion == "success":
                conclusion_style = "[green]✅ success[/green]"
            elif conclusion == "failure":
                conclusion_style = "[red]❌ failure[/red]"
            elif conclusion:
                conclusion_style = f"[yellow]{conclusion}[/yellow]"
            else:
                conclusion_style = "[dim]pending[/dim]"
            
            table.add_row(
                str(run.get("databaseId", "")),
                run.get("workflowName", "")[:30],
                run.get("status", ""),
                conclusion_style
            )
        
        console.print(table)
    
    @github_app.command("agent")
    def github_agent(
        description: str = typer.Argument(..., help="Task description for Copilot"),
        base: str = typer.Option(None, "--base", "-b", help="Base branch"),
        follow: bool = typer.Option(False, "--follow", "-f", help="Follow agent logs"),
    ):
        """Create a GitHub Copilot agent task"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint(f"[cyan]🤖 Creating Copilot agent task...[/cyan]")
        result = asyncio.run(gh.agent_task_create(description, base=base, follow=follow))
        
        if result.success:
            rprint("[green]✅ Agent task created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    # =========================================================================
    # F1 CYCLE COMMANDS
    # =========================================================================
    
    @github_app.command("f1")
    def github_f1(
        target: str = typer.Argument(..., help="Target: file path, issue:N, pr:N"),
        verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
    ):
        """Run F1 Three-Phase Cycle (Analyze → Optimize → Validate)"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        
        automation = get_github_automation()
        
        # Determine target type
        if target.startswith("issue:"):
            rprint(f"[cyan]🔄 Running F1 cycle on issue #{target.split(':')[1]}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_issue(int(target.split(':')[1])))
        elif target.startswith("pr:"):
            rprint(f"[cyan]🔄 Running F1 cycle on PR #{target.split(':')[1]}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_pr(int(target.split(':')[1])))
        else:
            rprint(f"[cyan]🔄 Running F1 cycle on file: {target}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_file(target))
        
        # Display results
        table = Table(title="🔄 F1 Cycle Results")
        table.add_column("Phase", style="cyan")
        table.add_column("Details", style="white")
        
        table.add_row("System", result.system_id)
        table.add_row("Type", result.system_type.value)
        table.add_row("Status", 
            "[green]✅ Success[/green]" if result.success 
            else "[red]❌ Failed[/red]")
        table.add_row("Duration", f"{result.duration:.2f}s")
        
        if result.improvements:
            table.add_row("Improvements", "\n".join(f"• {i}" for i in result.improvements))
        if result.issues:
            table.add_row("Issues", "\n".join(f"• {i}" for i in result.issues))
        if result.commands_executed:
            table.add_row("Commands", "\n".join(f"$ {c}" for c in result.commands_executed))
        
        console.print(table)
        
        rprint("\n[dim]F1 Phases: ANALYZE → OPTIMIZE → VALIDATE[/dim]")
    
    @github_app.command("m1")
    def github_m1(
        workspace: bool = typer.Option(True, "--workspace/--no-workspace", help="Include workspace files"),
        gh_systems: bool = typer.Option(True, "--github/--no-github", help="Include GitHub systems"),
        max_iter: int = typer.Option(3, "--max-iter", "-i", help="Max iterations"),
    ):
        """Run M1 Master Cycle on all systems"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        from pathlib import Path
        
        automation = get_github_automation()
        automation.m1_orchestrator.max_iterations = max_iter
        
        rprint("[cyan]🌟 Starting M1 Master Cycle...[/cyan]")
        rprint(f"[dim]Include workspace: {workspace}, Include GitHub: {gh_systems}[/dim]")
        rprint(f"[dim]Max iterations: {max_iter}[/dim]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Running M1 cycle...", total=None)
            
            async def run_with_progress():
                return await automation.run_full_cycle(
                    include_workspace=workspace,
                    include_github=gh_systems
                )
            
            result = asyncio.run(run_with_progress())
        
        # Display results
        table = Table(title="🌟 M1 Master Cycle Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        status_text = {
            CycleStatus.SUCCESS: "[green]✅ All Complete[/green]",
            CycleStatus.PARTIAL: "[yellow]⚠️ Partial Success[/yellow]",
            CycleStatus.FAILED: "[red]❌ Failed[/red]",
        }.get(result.status, str(result.status))
        
        table.add_row("Status", status_text)
        table.add_row("Total Systems", str(result.total_systems))
        table.add_row("Completed", str(result.completed_systems))
        table.add_row("Progress", f"{result.progress:.1f}%")
        table.add_row("Iterations", str(result.current_iteration))
        table.add_row("F1 Cycles Run", str(len(result.f1_cycles)))
        
        if result.end_time:
            duration = result.end_time - result.start_time
            table.add_row("Duration", f"{duration:.2f}s")
        
        console.print(table)
        
        # Summary of cycle outcomes
        success_count = sum(1 for c in result.f1_cycles if c.success)
        fail_count = len(result.f1_cycles) - success_count
        
        rprint(f"\n[dim]F1 Cycles: {success_count} succeeded, {fail_count} failed[/dim]")
        rprint("[dim]M1 Master Cycle: Iterates all systems through F1 until complete[/dim]")
    
    @github_app.command("sync")
    def github_sync(
        source: str = typer.Option(None, "--source", "-s", help="Source repository"),
    ):
        """Sync repository with upstream"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint("[cyan]🔄 Syncing repository...[/cyan]")
        result = asyncio.run(gh.repo_sync(source=source))
        
        if result.success:
            rprint("[green]✅ Repository synced successfully![/green]")
            if result.stdout:
                rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Sync failed: {result.stderr}[/red]")
    
    @github_app.command("create-pr")
    def github_create_pr(
        title: str = typer.Argument(..., help="PR title"),
        body: str = typer.Option(None, "--body", "-b", help="PR body"),
        base: str = typer.Option("main", "--base", help="Base branch"),
        draft: bool = typer.Option(False, "--draft", "-d", help="Create as draft"),
        fill: bool = typer.Option(False, "--fill", "-f", help="Fill from commits"),
    ):
        """Create a pull request"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint("[cyan]📝 Creating pull request...[/cyan]")
        result = asyncio.run(gh.pr_create(title=title, body=body, base=base, draft=draft, fill=fill))
        
        if result.success:
            rprint("[green]✅ Pull request created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    @github_app.command("create-issue")
    def github_create_issue(
        title: str = typer.Argument(..., help="Issue title"),
        body: str = typer.Option(None, "--body", "-b", help="Issue body"),
        labels: str = typer.Option(None, "--labels", "-l", help="Comma-separated labels"),
        assignees: str = typer.Option(None, "--assignees", "-a", help="Comma-separated assignees"),
    ):
        """Create a GitHub issue"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        label_list = labels.split(",") if labels else None
        assignee_list = assignees.split(",") if assignees else None
        
        rprint("[cyan]📝 Creating issue...[/cyan]")
        result = asyncio.run(gh.issue_create(title=title, body=body, labels=label_list, assignees=assignee_list))
        
        if result.success:
            rprint("[green]✅ Issue created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    @github_app.command("release")
    def github_release(
        tag: str = typer.Argument(..., help="Release tag (e.g., v1.0.0)"),
        title: str = typer.Option(None, "--title", "-t", help="Release title"),
        notes: str = typer.Option(None, "--notes", "-n", help="Release notes"),
        draft: bool = typer.Option(False, "--draft", help="Create as draft"),
        prerelease: bool = typer.Option(False, "--prerelease", help="Mark as prerelease"),
    ):
        """Create a GitHub release"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint(f"[cyan]🚀 Creating release {tag}...[/cyan]")
        result = asyncio.run(gh.release_create(
            tag=tag, title=title, notes=notes,
            draft=draft, prerelease=prerelease,
            generate_notes=notes is None
        ))
        
        if result.success:
            rprint("[green]✅ Release created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")


# =============================================================================
# TERMINAL F1 MESH COMMANDS
# =============================================================================

try:
    from .terminal_f1_mesh import (
        F1TerminalMesh, TerminalNode, MeshTopology,
        get_mesh, create_terminal, run_f1_between,
        F1TerminalAnalyzer, F1TerminalImprover, F1TerminalValidator
    )
    HAS_TERMINAL_MESH = True
except ImportError:
    HAS_TERMINAL_MESH = False

# Create mesh app
mesh_app = typer.Typer(
    name="mesh",
    help="Terminal-to-Terminal F1 Mesh Network - Self-improving terminal network",
) if typer else None

if mesh_app:
    app.add_typer(mesh_app, name="mesh")
    
    @mesh_app.command("status")
    def mesh_status():
        """Show F1 mesh network status"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        mesh = get_mesh()
        status = mesh.get_status()
        
        # Main status table
        table = Table(title="🔗 F1 Terminal Mesh Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Mesh Name", status["name"])
        table.add_row("Topology", status["topology"])
        table.add_row("Terminals", str(status["terminals"]))
        table.add_row("Connections", str(status["connections"]))
        table.add_row("Total Cycles", str(status["total_cycles"]))
        table.add_row("Total Improvements", str(status["total_improvements"]))
        
        console.print(table)
        
        # Terminals table
        if status["terminals_list"]:
            term_table = Table(title="📟 Terminals")
            term_table.add_column("ID", style="dim")
            term_table.add_column("Name", style="cyan")
            term_table.add_column("Shell", style="blue")
            term_table.add_column("F1 Level", style="magenta")
            term_table.add_column("State", style="green")
            term_table.add_column("CWD", style="dim")
            
            # F1 Level names
            f1_level_names = ["BASIC", "CONFIGURED", "OPTIMIZED", "HARDENED", "ADVANCED", "MASTERY"]
            
            for t in status["terminals_list"]:
                state_icon = {
                    "idle": "⏸️",
                    "analyzing": "🔍",
                    "improving": "🔧",
                    "validating": "✅",
                    "error": "❌",
                }.get(t["state"], "❓")
                
                # F1 level display
                level = t.get("f1_level", 0)
                level_name = f1_level_names[min(level, 5)]
                level_display = f"L{level} {level_name}"
                
                term_table.add_row(
                    t["id"],
                    t["name"],
                    t["shell"],
                    level_display,
                    f"{state_icon} {t['state']}",
                    t["cwd"][:35] + "..." if len(t["cwd"]) > 35 else t["cwd"]
                )
            
            console.print(term_table)
        
        # Connections table
        if status["connections_list"]:
            conn_table = Table(title="🔗 Connections")
            conn_table.add_column("Source", style="cyan")
            conn_table.add_column("→", style="dim")
            conn_table.add_column("Target", style="blue")
            conn_table.add_column("Cycles", style="green")
            conn_table.add_column("Success", style="yellow")
            conn_table.add_column("Improvements", style="magenta")
            
            for c in status["connections_list"]:
                conn_table.add_row(
                    c["source"][:8],
                    "F1",
                    c["target"][:8],
                    str(c["cycles"]),
                    c["success_rate"],
                    str(c["improvements"])
                )
            
            console.print(conn_table)
    
    @mesh_app.command("create")
    def mesh_create_terminal(
        name: str = typer.Argument(..., help="Terminal name"),
        shell: str = typer.Option(None, "--shell", "-s", help="Shell type (powershell, bash, zsh)"),
    ):
        """Create a new terminal in the mesh"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        terminal = TerminalNode(name=name, shell=shell)
        mesh = get_mesh()
        mesh.add_terminal(terminal)
        
        rprint(f"[green]✅ Created terminal '{name}' (ID: {terminal.id})[/green]")
        rprint(f"[dim]Shell: {terminal.shell}[/dim]")
        rprint(f"[dim]Capabilities: {len(terminal.capabilities)} detected[/dim]")
        
        # Show connections
        if mesh.connections:
            rprint("\n[cyan]Mesh connections:[/cyan]")
            for conn in mesh.connections.values():
                src = mesh.terminals.get(conn.source_id)
                tgt = mesh.terminals.get(conn.target_id)
                if src and tgt:
                    rprint(f"  {src.name} ──F1──► {tgt.name}")
    
    @mesh_app.command("f1")
    def mesh_f1_cycle(
        source: str = typer.Argument(..., help="Source terminal name or ID"),
        target: str = typer.Argument(..., help="Target terminal name or ID"),
        auto_apply: bool = typer.Option(False, "--auto", "-a", help="Auto-apply safe improvements"),
        force: bool = typer.Option(False, "--force", "-f", help="Force apply ALL improvements"),
    ):
        """Run F1 cycle from source to target terminal"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        
        mesh = get_mesh()
        
        # Find terminals
        source_term = next(
            (t for t in mesh.terminals.values() if t.name == source or t.id == source),
            None
        )
        target_term = next(
            (t for t in mesh.terminals.values() if t.name == target or t.id == target),
            None
        )
        
        if not source_term:
            rprint(f"[yellow]Creating source terminal '{source}'...[/yellow]")
            source_term = create_terminal(source)
        
        if not target_term:
            rprint(f"[yellow]Creating target terminal '{target}'...[/yellow]")
            target_term = create_terminal(target)
        
        rprint(f"\n[cyan]🔄 Running F1 cycle: {source_term.name} → {target_term.name}[/cyan]")
        if force:
            rprint("[yellow]⚠️  Force mode: ALL improvements with commands will be applied[/yellow]")
        elif auto_apply:
            rprint("[dim]Auto-apply mode: Safe improvements will be applied[/dim]")
        
        with console.status("[cyan]Phase 1: ANALYZE...[/cyan]"):
            result = asyncio.run(mesh.run_f1_cycle(
                source_term.id, target_term.id, 
                auto_apply=auto_apply,
                force_apply=force
            ))
        
        # Results
        status_icon = "✅" if result.success else "❌"
        rprint(f"\n{status_icon} F1 Cycle Complete")
        
        table = Table(title="📊 F1 Cycle Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Duration", f"{result.duration:.2f}s")
        table.add_row("Improvements Found", str(len(result.improvements_found)))
        table.add_row("Improvements Applied", str(len(result.improvements_applied)))
        table.add_row("Validation", "✅ PASSED" if result.validation_passed else "❌ FAILED")
        
        console.print(table)
        
        # Show improvements
        if result.improvements_found:
            imp_table = Table(title="💡 Improvements Found")
            imp_table.add_column("Type", style="blue")
            imp_table.add_column("Description", style="white")
            imp_table.add_column("Priority", style="yellow")
            imp_table.add_column("Applied", style="green")
            
            for imp in result.improvements_found[:10]:
                applied = "✅" if imp.id in result.improvements_applied else "⏸️"
                imp_table.add_row(
                    imp.type.value,
                    imp.description[:50] + "..." if len(imp.description) > 50 else imp.description,
                    str(imp.priority),
                    applied
                )
            
            console.print(imp_table)
        
        # Show F1 level status
        f1_level_names = ["BASIC", "CONFIGURED", "OPTIMIZED", "HARDENED", "ADVANCED", "MASTERY"]
        level = target_term.f1_level
        level_name = f1_level_names[min(level, 5)]
        total_improvements = sum(len(h) for h in target_term.improvement_history.values())
        
        rprint(f"\n📈 [cyan]Target F1 Level:[/cyan] [magenta]L{level} {level_name}[/magenta] ({total_improvements} total improvements)")
        
        if level < 5:
            next_level_name = f1_level_names[level + 1]
            rprint(f"[dim]Next level: L{level + 1} {next_level_name}[/dim]")
    
    @mesh_app.command("run")
    def mesh_run_all(
        iterations: int = typer.Option(5, "--iterations", "-i", help="Max iterations"),
        concurrent: int = typer.Option(3, "--concurrent", "-c", help="Max concurrent cycles"),
    ):
        """Run F1 cycles across entire mesh until stable"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        
        mesh = get_mesh()
        
        if len(mesh.terminals) < 2:
            rprint("[yellow]Need at least 2 terminals in mesh[/yellow]")
            rprint("Create terminals with: aria mesh create <name>")
            return
        
        rprint(f"\n[cyan]🌐 Running F1 mesh cycle ({len(mesh.terminals)} terminals, {len(mesh.connections)} connections)[/cyan]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Running mesh cycles...", total=None)
            
            result = asyncio.run(mesh.run_until_stable(
                max_iterations=iterations,
                stability_threshold=2
            ))
        
        # Summary
        rprint(f"\n✨ [green]Mesh cycle complete![/green]")
        
        table = Table(title="📊 Mesh Cycle Summary")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Iterations", str(result["iterations"]))
        table.add_row("Total Cycles", str(result["total_cycles"]))
        table.add_row("Total Improvements", str(result["total_improvements"]))
        table.add_row("Stable", "✅ Yes" if result["stable"] else "🔄 Continuing")
        
        console.print(table)
    
    @mesh_app.command("topology")
    def mesh_set_topology(
        topology: str = typer.Argument(
            "adaptive",
            help="Topology type: ring, star, full_mesh, adaptive"
        ),
    ):
        """Set mesh topology"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        topology_map = {
            "ring": MeshTopology.RING,
            "star": MeshTopology.STAR,
            "full_mesh": MeshTopology.FULL_MESH,
            "full": MeshTopology.FULL_MESH,
            "adaptive": MeshTopology.ADAPTIVE,
        }
        
        if topology.lower() not in topology_map:
            rprint(f"[red]Unknown topology: {topology}[/red]")
            rprint("Options: ring, star, full_mesh, adaptive")
            return
        
        mesh = get_mesh()
        mesh.topology = topology_map[topology.lower()]
        mesh._update_connections()
        
        rprint(f"[green]✅ Topology set to: {mesh.topology.value}[/green]")
        rprint(f"[dim]Connections: {len(mesh.connections)}[/dim]")
    
    @mesh_app.command("demo")
    def mesh_demo():
        """Run a demo of the F1 terminal mesh"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        from .terminal_f1_mesh import demo
        
        asyncio.run(demo())


def main():
    """Main entry point"""
    # Ensure UTF-8 output
    if sys.platform == 'win32':
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    
    if app:
        app()
    else:
        # Fallback for minimal install
        print("ARIA CLI v0.3.0")
        print("Install with: pip install aria-cli[full]")
        print("\nRunning minimal mode...")
        cli = AriaCLI(output_format=OutputFormat.PLAIN, use_llm=False)
        cli.interactive_mode()


if __name__ == "__main__":
    main()
