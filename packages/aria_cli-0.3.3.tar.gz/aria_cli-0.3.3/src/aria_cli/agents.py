"""
ARIA Agents Module v0.2.0

Agent-based architecture for distributed AI processing and communication.

This module provides:
- AriaAgent: Base class for all ARIA agents
- AgentMessage: Typed message protocol for agent communication
- AgentRegistry: Discovery and routing for agents
- AgentChannel: Communication channels between agents
- AgentSwarm: Coordinated multi-agent processing

Architecture:
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │   Agent A   │────►│   Channel   │────►│   Agent B   │
    │  (Q-Layer)  │◄────│  (Message)  │◄────│  (Q-Layer)  │
    └─────────────┘     └─────────────┘     └─────────────┘
           │                                        │
           └────────────────────────────────────────┘
                      Agent Registry
"""

from __future__ import annotations
import asyncio
import uuid
import json
import time
import threading
import logging
from enum import Enum, auto
from dataclasses import dataclass, field, asdict
from typing import (
    Dict, Any, List, Optional, Callable, Union, 
    Awaitable, Set, Tuple, Type, TypeVar
)
from datetime import datetime
from pathlib import Path
from collections import defaultdict
from abc import ABC, abstractmethod
import hashlib
import queue

from .q_system import QSystem, QLayer, QOperator, QCommand

logger = logging.getLogger(__name__)


# ============================================================================
# Message Types and Protocol
# ============================================================================

class MessageType(Enum):
    """Types of messages agents can exchange"""
    # Request/Response
    REQUEST = auto()      # Request action from another agent
    RESPONSE = auto()     # Response to a request
    
    # Events
    EVENT = auto()        # Broadcast event notification
    SUBSCRIBE = auto()    # Subscribe to events
    UNSUBSCRIBE = auto()  # Unsubscribe from events
    
    # Control
    PING = auto()         # Health check
    PONG = auto()         # Health check response
    HANDSHAKE = auto()    # Agent introduction
    GOODBYE = auto()      # Agent departure
    
    # Data
    STREAM = auto()       # Streaming data chunk
    SYNC = auto()         # State synchronization
    
    # System
    ERROR = auto()        # Error notification
    ACK = auto()          # Acknowledgment
    NACK = auto()         # Negative acknowledgment


class MessagePriority(Enum):
    """Message priority levels"""
    CRITICAL = 0   # System-critical, immediate processing
    HIGH = 1       # High priority, process before normal
    NORMAL = 2     # Standard priority
    LOW = 3        # Low priority, process when idle
    BACKGROUND = 4 # Background processing


class AgentCapability(Enum):
    """Standard agent capabilities"""
    # Processing
    TEXT_GENERATION = auto()
    CODE_GENERATION = auto()
    ANALYSIS = auto()
    SUMMARIZATION = auto()
    TRANSLATION = auto()
    
    # Data
    FILE_OPERATIONS = auto()
    DATABASE_ACCESS = auto()
    WEB_SEARCH = auto()
    API_CALLS = auto()
    
    # System
    SHELL_EXECUTION = auto()
    PROCESS_MANAGEMENT = auto()
    SCHEDULING = auto()
    
    # AI/ML
    EMBEDDING = auto()
    CLASSIFICATION = auto()
    PREDICTION = auto()
    REASONING = auto()
    
    # Meta
    AGENT_COORDINATION = auto()
    TASK_DECOMPOSITION = auto()
    SELF_IMPROVEMENT = auto()


@dataclass
class AgentMessage:
    """
    Message exchanged between agents.
    
    Attributes:
        id: Unique message identifier
        type: Message type
        sender: Sender agent ID
        recipient: Recipient agent ID (None for broadcast)
        payload: Message data
        priority: Message priority
        timestamp: Creation timestamp
        reply_to: ID of message this replies to
        expires: Expiration timestamp
        trace: Q-System trace path
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: MessageType = MessageType.REQUEST
    sender: str = ""
    recipient: Optional[str] = None  # None = broadcast
    payload: Dict[str, Any] = field(default_factory=dict)
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: datetime = field(default_factory=datetime.now)
    reply_to: Optional[str] = None
    expires: Optional[datetime] = None
    trace: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "type": self.type.name,
            "sender": self.sender,
            "recipient": self.recipient,
            "payload": self.payload,
            "priority": self.priority.name,
            "timestamp": self.timestamp.isoformat(),
            "reply_to": self.reply_to,
            "expires": self.expires.isoformat() if self.expires else None,
            "trace": self.trace,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentMessage':
        """Create from dictionary"""
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            type=MessageType[data.get("type", "REQUEST")],
            sender=data.get("sender", ""),
            recipient=data.get("recipient"),
            payload=data.get("payload", {}),
            priority=MessagePriority[data.get("priority", "NORMAL")],
            timestamp=datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else datetime.now(),
            reply_to=data.get("reply_to"),
            expires=datetime.fromisoformat(data["expires"]) if data.get("expires") else None,
            trace=data.get("trace", []),
            metadata=data.get("metadata", {}),
        )
    
    def reply(self, payload: Dict[str, Any], type: MessageType = MessageType.RESPONSE) -> 'AgentMessage':
        """Create a reply to this message"""
        return AgentMessage(
            type=type,
            sender=self.recipient or "",
            recipient=self.sender,
            payload=payload,
            reply_to=self.id,
            trace=self.trace + [self.id],
        )
    
    def is_expired(self) -> bool:
        """Check if message has expired"""
        if self.expires is None:
            return False
        return datetime.now() > self.expires


# ============================================================================
# Agent State and Status
# ============================================================================

class AgentState(Enum):
    """Agent lifecycle states"""
    INITIALIZING = auto()
    IDLE = auto()
    BUSY = auto()
    WAITING = auto()
    PAUSED = auto()
    STOPPING = auto()
    STOPPED = auto()
    ERROR = auto()


@dataclass
class AgentStatus:
    """Current status of an agent"""
    agent_id: str
    name: str
    state: AgentState
    q_layer: QLayer
    capabilities: List[AgentCapability]
    current_task: Optional[str] = None
    messages_processed: int = 0
    messages_pending: int = 0
    uptime_seconds: float = 0.0
    last_activity: Optional[datetime] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "state": self.state.name,
            "q_layer": self.q_layer.name,
            "capabilities": [c.name for c in self.capabilities],
            "current_task": self.current_task,
            "messages_processed": self.messages_processed,
            "messages_pending": self.messages_pending,
            "uptime_seconds": self.uptime_seconds,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "error": self.error,
        }


# ============================================================================
# Base Agent Class
# ============================================================================

AgentHandler = Callable[[AgentMessage], Union[AgentMessage, Awaitable[AgentMessage], None]]


class AriaAgent(ABC):
    """
    Base class for all ARIA agents.
    
    An agent is an autonomous unit that:
    - Operates at a specific Q-Layer
    - Has defined capabilities
    - Can send/receive messages to/from other agents
    - Processes tasks asynchronously
    
    Example:
        class MyAgent(AriaAgent):
            def __init__(self):
                super().__init__(
                    name="my-agent",
                    q_layer=QLayer.Q10_LOGIC,
                    capabilities=[AgentCapability.ANALYSIS]
                )
            
            async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
                # Handle incoming message
                result = self.analyze(message.payload)
                return message.reply({"result": result})
    """
    
    def __init__(
        self,
        name: str,
        q_layer: QLayer = QLayer.Q8_LANGUAGE,
        capabilities: Optional[List[AgentCapability]] = None,
        agent_id: Optional[str] = None,
    ):
        self.id = agent_id or f"{name}-{uuid.uuid4().hex[:8]}"
        self.name = name
        self.q_layer = q_layer
        self.capabilities = capabilities or []
        
        # State
        self._state = AgentState.INITIALIZING
        self._start_time: Optional[float] = None
        self._last_activity: Optional[datetime] = None
        self._current_task: Optional[str] = None
        self._error: Optional[str] = None
        
        # Message handling
        self._inbox: asyncio.Queue[AgentMessage] = asyncio.Queue()
        self._outbox: asyncio.Queue[AgentMessage] = asyncio.Queue()
        self._handlers: Dict[MessageType, List[AgentHandler]] = defaultdict(list)
        self._pending_replies: Dict[str, asyncio.Future] = {}
        
        # Stats
        self._messages_processed = 0
        
        # Q-System integration
        self._q_system = QSystem()
        
        # Registry reference (set when registered)
        self._registry: Optional['AgentRegistry'] = None
        
        # Running task
        self._run_task: Optional[asyncio.Task] = None
        self._running = False
        
        # Event subscriptions
        self._subscriptions: Set[str] = set()
        
        logger.info(f"Agent created: {self.id} (Q{self.q_layer.value})")
    
    @property
    def state(self) -> AgentState:
        """Get current agent state"""
        return self._state
    
    @state.setter
    def state(self, value: AgentState):
        """Set agent state"""
        old_state = self._state
        self._state = value
        logger.debug(f"Agent {self.id}: {old_state.name} -> {value.name}")
    
    @property
    def status(self) -> AgentStatus:
        """Get current agent status"""
        uptime = time.time() - self._start_time if self._start_time else 0.0
        return AgentStatus(
            agent_id=self.id,
            name=self.name,
            state=self._state,
            q_layer=self.q_layer,
            capabilities=self.capabilities,
            current_task=self._current_task,
            messages_processed=self._messages_processed,
            messages_pending=self._inbox.qsize(),
            uptime_seconds=uptime,
            last_activity=self._last_activity,
            error=self._error,
        )
    
    def has_capability(self, capability: AgentCapability) -> bool:
        """Check if agent has a capability"""
        return capability in self.capabilities
    
    # -------------------------------------------------------------------------
    # Lifecycle Methods
    # -------------------------------------------------------------------------
    
    async def start(self) -> None:
        """Start the agent"""
        if self._running:
            return
        
        self._running = True
        self._start_time = time.time()
        self.state = AgentState.IDLE
        
        # Initialize
        await self.on_start()
        
        # Start message processing loop
        self._run_task = asyncio.create_task(self._message_loop())
        
        logger.info(f"Agent started: {self.id}")
    
    async def stop(self) -> None:
        """Stop the agent"""
        if not self._running:
            return
        
        self.state = AgentState.STOPPING
        self._running = False
        
        # Stop message loop
        if self._run_task:
            self._run_task.cancel()
            try:
                await self._run_task
            except asyncio.CancelledError:
                pass
        
        # Cleanup
        await self.on_stop()
        
        self.state = AgentState.STOPPED
        logger.info(f"Agent stopped: {self.id}")
    
    async def on_start(self) -> None:
        """Called when agent starts. Override for custom initialization."""
        pass
    
    async def on_stop(self) -> None:
        """Called when agent stops. Override for custom cleanup."""
        pass
    
    # -------------------------------------------------------------------------
    # Message Handling
    # -------------------------------------------------------------------------
    
    async def _message_loop(self) -> None:
        """Main message processing loop"""
        while self._running:
            try:
                # Get next message with timeout
                try:
                    message = await asyncio.wait_for(
                        self._inbox.get(),
                        timeout=0.5
                    )
                except asyncio.TimeoutError:
                    continue
                
                # Skip expired messages
                if message.is_expired():
                    logger.debug(f"Message expired: {message.id}")
                    continue
                
                # Update state
                self.state = AgentState.BUSY
                self._current_task = f"Processing {message.type.name}"
                self._last_activity = datetime.now()
                
                # Process message
                try:
                    response = await self._handle_message(message)
                    
                    # Send response if any
                    if response:
                        await self.send(response)
                    
                    self._messages_processed += 1
                    
                except Exception as e:
                    logger.error(f"Error processing message {message.id}: {e}")
                    self._error = str(e)
                    
                    # Send error response
                    error_response = message.reply(
                        {"error": str(e)},
                        type=MessageType.ERROR
                    )
                    await self.send(error_response)
                
                finally:
                    self.state = AgentState.IDLE
                    self._current_task = None
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in message loop: {e}")
                self._error = str(e)
                self.state = AgentState.ERROR
    
    async def _handle_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Handle an incoming message"""
        # Check for reply handlers
        if message.reply_to and message.reply_to in self._pending_replies:
            future = self._pending_replies.pop(message.reply_to)
            future.set_result(message)
            return None
        
        # Check for registered handlers
        handlers = self._handlers.get(message.type, [])
        for handler in handlers:
            try:
                result = handler(message)
                if asyncio.iscoroutine(result):
                    result = await result
                if result:
                    return result
            except Exception as e:
                logger.error(f"Handler error: {e}")
        
        # Default handling
        return await self.process_message(message)
    
    @abstractmethod
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """
        Process an incoming message.
        
        Override this method to define agent behavior.
        
        Args:
            message: Incoming message to process
            
        Returns:
            Optional response message
        """
        pass
    
    def on(self, message_type: MessageType, handler: AgentHandler) -> None:
        """Register a handler for a message type"""
        self._handlers[message_type].append(handler)
    
    # -------------------------------------------------------------------------
    # Sending Messages
    # -------------------------------------------------------------------------
    
    async def send(self, message: AgentMessage) -> None:
        """Send a message to another agent"""
        message.sender = self.id
        message.trace.append(self.id)
        
        if self._registry:
            await self._registry.route_message(message)
        else:
            await self._outbox.put(message)
    
    async def request(
        self,
        recipient: str,
        payload: Dict[str, Any],
        timeout: float = 30.0,
        priority: MessagePriority = MessagePriority.NORMAL,
    ) -> AgentMessage:
        """
        Send a request and wait for response.
        
        Args:
            recipient: Target agent ID
            payload: Request payload
            timeout: Response timeout in seconds
            priority: Message priority
            
        Returns:
            Response message
            
        Raises:
            TimeoutError: If no response within timeout
        """
        message = AgentMessage(
            type=MessageType.REQUEST,
            sender=self.id,
            recipient=recipient,
            payload=payload,
            priority=priority,
        )
        
        # Create future for response
        future: asyncio.Future[AgentMessage] = asyncio.get_event_loop().create_future()
        self._pending_replies[message.id] = future
        
        # Send request
        await self.send(message)
        
        try:
            response = await asyncio.wait_for(future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            self._pending_replies.pop(message.id, None)
            raise TimeoutError(f"No response from {recipient} within {timeout}s")
    
    async def broadcast(
        self,
        payload: Dict[str, Any],
        event_type: str = "event",
    ) -> None:
        """Broadcast a message to all subscribed agents"""
        message = AgentMessage(
            type=MessageType.EVENT,
            sender=self.id,
            recipient=None,  # Broadcast
            payload={"event_type": event_type, **payload},
        )
        await self.send(message)
    
    async def receive(self, message: AgentMessage) -> None:
        """Receive a message into inbox"""
        await self._inbox.put(message)
    
    # -------------------------------------------------------------------------
    # Q-System Integration
    # -------------------------------------------------------------------------
    
    async def execute_q_command(
        self,
        operator: QOperator,
        payload: Dict[str, Any],
        layer: Optional[QLayer] = None,
    ) -> Any:
        """Execute a Q-System command at this agent's layer"""
        cmd = QCommand(
            operator=operator,
            payload=payload,
            layer=layer or self.q_layer,
        )
        return self._q_system.execute(cmd)
    
    def get_q_context(self) -> Dict[str, Any]:
        """Get Q-System context for this agent"""
        return {
            "agent_id": self.id,
            "agent_name": self.name,
            "q_layer": self.q_layer.value,
            "q_layer_name": self.q_layer.name,
            "q_layer_group": self.q_layer.group,
            "capabilities": [c.name for c in self.capabilities],
        }


# ============================================================================
# Specialized Agent Types
# ============================================================================

class TaskAgent(AriaAgent):
    """Agent specialized for task execution"""
    
    def __init__(self, name: str, **kwargs):
        super().__init__(
            name=name,
            q_layer=QLayer.Q23_EXECUTION,
            capabilities=[
                AgentCapability.SHELL_EXECUTION,
                AgentCapability.FILE_OPERATIONS,
            ],
            **kwargs
        )
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process task execution messages"""
        action = message.payload.get("action", "execute")
        
        if action == "execute":
            command = message.payload.get("command", "")
            result = await self.execute_command(command)
            return message.reply({"result": result})
        
        return message.reply({"error": f"Unknown action: {action}"})
    
    async def execute_command(self, command: str) -> Dict[str, Any]:
        """Execute a shell command (stub - override for real implementation)"""
        return {"status": "simulated", "command": command}


class ReasoningAgent(AriaAgent):
    """Agent specialized for logical reasoning"""
    
    def __init__(self, name: str, **kwargs):
        super().__init__(
            name=name,
            q_layer=QLayer.Q10_LOGIC,
            capabilities=[
                AgentCapability.REASONING,
                AgentCapability.ANALYSIS,
            ],
            **kwargs
        )
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process reasoning requests"""
        action = message.payload.get("action", "analyze")
        
        if action == "analyze":
            data = message.payload.get("data", {})
            result = await self.analyze(data)
            return message.reply({"analysis": result})
        
        elif action == "infer":
            premises = message.payload.get("premises", [])
            result = await self.infer(premises)
            return message.reply({"inference": result})
        
        return message.reply({"error": f"Unknown action: {action}"})
    
    async def analyze(self, data: Any) -> Dict[str, Any]:
        """Analyze data (stub - override for real implementation)"""
        return {"analyzed": True, "data_type": type(data).__name__}
    
    async def infer(self, premises: List[str]) -> Dict[str, Any]:
        """Make inference from premises"""
        return {"premises_count": len(premises), "inference": "placeholder"}


class CoordinatorAgent(AriaAgent):
    """Agent specialized for coordinating other agents"""
    
    def __init__(self, name: str, **kwargs):
        super().__init__(
            name=name,
            q_layer=QLayer.Q21_PLANNING,
            capabilities=[
                AgentCapability.AGENT_COORDINATION,
                AgentCapability.TASK_DECOMPOSITION,
            ],
            **kwargs
        )
        self._managed_agents: List[str] = []
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process coordination requests"""
        action = message.payload.get("action", "coordinate")
        
        if action == "coordinate":
            task = message.payload.get("task", {})
            result = await self.coordinate_task(task)
            return message.reply({"coordination": result})
        
        elif action == "decompose":
            task = message.payload.get("task", "")
            subtasks = await self.decompose_task(task)
            return message.reply({"subtasks": subtasks})
        
        elif action == "status":
            status = await self.get_managed_status()
            return message.reply({"agents_status": status})
        
        return message.reply({"error": f"Unknown action: {action}"})
    
    async def coordinate_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Coordinate task across agents"""
        return {"coordinated": True, "task_id": str(uuid.uuid4())}
    
    async def decompose_task(self, task: str) -> List[Dict[str, Any]]:
        """Decompose task into subtasks"""
        return [{"subtask": task, "assigned_to": None}]
    
    async def get_managed_status(self) -> List[Dict[str, Any]]:
        """Get status of managed agents"""
        return [{"agent_id": aid, "status": "unknown"} for aid in self._managed_agents]


class GeneratorAgent(AriaAgent):
    """Agent specialized for content generation"""
    
    def __init__(self, name: str, **kwargs):
        super().__init__(
            name=name,
            q_layer=QLayer.Q19_CREATIVITY,
            capabilities=[
                AgentCapability.TEXT_GENERATION,
                AgentCapability.CODE_GENERATION,
            ],
            **kwargs
        )
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process generation requests"""
        action = message.payload.get("action", "generate")
        
        if action == "generate":
            prompt = message.payload.get("prompt", "")
            gen_type = message.payload.get("type", "text")
            result = await self.generate(prompt, gen_type)
            return message.reply({"generated": result})
        
        return message.reply({"error": f"Unknown action: {action}"})
    
    async def generate(self, prompt: str, gen_type: str = "text") -> str:
        """Generate content (stub - connect to LLM for real implementation)"""
        return f"[Generated {gen_type}] Response to: {prompt[:50]}..."


# ============================================================================
# Agent Registry and Discovery
# ============================================================================

class AgentRegistry:
    """
    Central registry for agent discovery and message routing.
    
    The registry maintains a directory of all registered agents and
    routes messages between them based on capabilities and Q-layers.
    
    Example:
        registry = AgentRegistry()
        
        agent1 = MyAgent()
        agent2 = OtherAgent()
        
        await registry.register(agent1)
        await registry.register(agent2)
        
        # Find agents by capability
        analyzers = registry.find_by_capability(AgentCapability.ANALYSIS)
        
        # Route a message
        await registry.route_message(message)
    """
    
    def __init__(self, storage_path: Optional[Path] = None):
        self._agents: Dict[str, AriaAgent] = {}
        self._by_capability: Dict[AgentCapability, Set[str]] = defaultdict(set)
        self._by_layer: Dict[QLayer, Set[str]] = defaultdict(set)
        self._by_name: Dict[str, str] = {}  # name -> id
        
        # Event subscribers
        self._subscribers: Dict[str, Set[str]] = defaultdict(set)
        
        # Storage
        self.storage_path = storage_path or Path.home() / ".aria" / "agents"
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Lock for thread safety
        self._lock = asyncio.Lock()
        
        logger.info("AgentRegistry initialized")
    
    async def register(self, agent: AriaAgent) -> None:
        """Register an agent with the registry"""
        async with self._lock:
            self._agents[agent.id] = agent
            self._by_name[agent.name] = agent.id
            
            for cap in agent.capabilities:
                self._by_capability[cap].add(agent.id)
            
            self._by_layer[agent.q_layer].add(agent.id)
            
            # Set registry reference
            agent._registry = self
        
        logger.info(f"Registered agent: {agent.id} ({agent.name})")
    
    async def unregister(self, agent_id: str) -> None:
        """Unregister an agent"""
        async with self._lock:
            if agent_id not in self._agents:
                return
            
            agent = self._agents[agent_id]
            
            # Remove from indices
            self._by_name.pop(agent.name, None)
            
            for cap in agent.capabilities:
                self._by_capability[cap].discard(agent_id)
            
            self._by_layer[agent.q_layer].discard(agent_id)
            
            # Remove from subscribers
            for event_type in list(self._subscribers.keys()):
                self._subscribers[event_type].discard(agent_id)
            
            # Clear registry reference
            agent._registry = None
            
            del self._agents[agent_id]
        
        logger.info(f"Unregistered agent: {agent_id}")
    
    def get(self, agent_id: str) -> Optional[AriaAgent]:
        """Get an agent by ID"""
        return self._agents.get(agent_id)
    
    def get_by_name(self, name: str) -> Optional[AriaAgent]:
        """Get an agent by name"""
        agent_id = self._by_name.get(name)
        if agent_id:
            return self._agents.get(agent_id)
        return None
    
    def find_by_capability(self, capability: AgentCapability) -> List[AriaAgent]:
        """Find agents with a specific capability"""
        agent_ids = self._by_capability.get(capability, set())
        return [self._agents[aid] for aid in agent_ids if aid in self._agents]
    
    def find_by_layer(self, layer: QLayer) -> List[AriaAgent]:
        """Find agents operating at a specific Q-layer"""
        agent_ids = self._by_layer.get(layer, set())
        return [self._agents[aid] for aid in agent_ids if aid in self._agents]
    
    def find_by_layer_range(self, min_layer: QLayer, max_layer: QLayer) -> List[AriaAgent]:
        """Find agents within a Q-layer range"""
        result = []
        for layer in QLayer:
            if min_layer.value <= layer.value <= max_layer.value:
                result.extend(self.find_by_layer(layer))
        return result
    
    def list_agents(self) -> List[AgentStatus]:
        """List all registered agents with their status"""
        return [agent.status for agent in self._agents.values()]
    
    async def route_message(self, message: AgentMessage) -> None:
        """Route a message to its destination"""
        if message.recipient:
            # Direct message
            agent = self._agents.get(message.recipient)
            if agent:
                await agent.receive(message)
            else:
                # Try by name
                agent = self.get_by_name(message.recipient)
                if agent:
                    await agent.receive(message)
                else:
                    logger.warning(f"Unknown recipient: {message.recipient}")
        else:
            # Broadcast to subscribers
            event_type = message.payload.get("event_type", "all")
            subscribers = self._subscribers.get(event_type, set()) | self._subscribers.get("all", set())
            
            for agent_id in subscribers:
                if agent_id != message.sender and agent_id in self._agents:
                    await self._agents[agent_id].receive(message)
    
    async def subscribe(self, agent_id: str, event_type: str = "all") -> None:
        """Subscribe an agent to events"""
        self._subscribers[event_type].add(agent_id)
    
    async def unsubscribe(self, agent_id: str, event_type: str = "all") -> None:
        """Unsubscribe an agent from events"""
        self._subscribers[event_type].discard(agent_id)
    
    async def start_all(self) -> None:
        """Start all registered agents"""
        for agent in self._agents.values():
            await agent.start()
    
    async def stop_all(self) -> None:
        """Stop all registered agents"""
        for agent in self._agents.values():
            await agent.stop()


# ============================================================================
# Agent Swarm - Multi-Agent Coordination
# ============================================================================

@dataclass
class SwarmTask:
    """A task to be executed by the swarm"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    description: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    required_capabilities: List[AgentCapability] = field(default_factory=list)
    assigned_to: Optional[str] = None
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None


class AgentSwarm:
    """
    Coordinated multi-agent system for complex task execution.
    
    A swarm manages multiple agents working together on a shared goal.
    Tasks are decomposed and distributed based on agent capabilities.
    
    Example:
        swarm = AgentSwarm("my-swarm", registry)
        
        # Add agents
        swarm.add_agent(task_agent)
        swarm.add_agent(reasoning_agent)
        
        # Execute complex task
        result = await swarm.execute({
            "goal": "Analyze and process data",
            "data": {...}
        })
    """
    
    def __init__(
        self,
        name: str,
        registry: Optional[AgentRegistry] = None,
        coordinator: Optional[CoordinatorAgent] = None,
    ):
        self.id = f"swarm-{name}-{uuid.uuid4().hex[:8]}"
        self.name = name
        self.registry = registry or AgentRegistry()
        
        # Create or use coordinator
        self.coordinator = coordinator or CoordinatorAgent(f"{name}-coordinator")
        
        # Swarm members
        self._members: Dict[str, AriaAgent] = {}
        
        # Task tracking
        self._tasks: Dict[str, SwarmTask] = {}
        self._task_queue: asyncio.Queue[SwarmTask] = asyncio.Queue()
        
        # Stats
        self.tasks_completed = 0
        self.tasks_failed = 0
        
        logger.info(f"Swarm created: {self.id}")
    
    async def initialize(self) -> None:
        """Initialize the swarm"""
        # Register coordinator
        await self.registry.register(self.coordinator)
        await self.coordinator.start()
        
        # Register members
        for agent in self._members.values():
            await self.registry.register(agent)
            await agent.start()
    
    async def shutdown(self) -> None:
        """Shutdown the swarm"""
        await self.coordinator.stop()
        for agent in self._members.values():
            await agent.stop()
    
    def add_agent(self, agent: AriaAgent) -> None:
        """Add an agent to the swarm"""
        self._members[agent.id] = agent
        logger.info(f"Added agent {agent.id} to swarm {self.id}")
    
    def remove_agent(self, agent_id: str) -> None:
        """Remove an agent from the swarm"""
        self._members.pop(agent_id, None)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a complex task using the swarm.
        
        Args:
            task: Task definition with goal and data
            
        Returns:
            Combined results from all subtasks
        """
        # Create swarm task
        swarm_task = SwarmTask(
            description=task.get("goal", "Execute task"),
            payload=task,
        )
        self._tasks[swarm_task.id] = swarm_task
        
        # Decompose into subtasks
        decompose_result = await self.coordinator.request(
            self.coordinator.id,
            {"action": "decompose", "task": task.get("goal", "")},
            timeout=30.0
        )
        
        subtasks = decompose_result.payload.get("subtasks", [])
        
        # Assign and execute subtasks
        results = []
        for subtask in subtasks:
            # Find suitable agent
            agent = self._find_agent_for_task(subtask)
            if agent:
                result = await self._execute_subtask(agent, subtask)
                results.append(result)
        
        # Update task
        swarm_task.status = "completed"
        swarm_task.completed_at = datetime.now()
        swarm_task.result = {"subtask_results": results}
        self.tasks_completed += 1
        
        return swarm_task.result
    
    def _find_agent_for_task(self, subtask: Dict[str, Any]) -> Optional[AriaAgent]:
        """Find a suitable agent for a subtask"""
        # First, check if specific agent assigned
        assigned = subtask.get("assigned_to")
        if assigned:
            agent = self._members.get(assigned)
            if agent:
                return agent
        
        # Find by capability
        required_caps = subtask.get("required_capabilities", [])
        for cap_name in required_caps:
            try:
                cap = AgentCapability[cap_name]
                agents = self.registry.find_by_capability(cap)
                # Prefer swarm members
                for agent in agents:
                    if agent.id in self._members:
                        return agent
                if agents:
                    return agents[0]
            except KeyError:
                pass
        
        # Return first available member
        if self._members:
            return next(iter(self._members.values()))
        
        return None
    
    async def _execute_subtask(
        self,
        agent: AriaAgent,
        subtask: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a subtask on an agent"""
        try:
            response = await agent.request(
                agent.id,
                subtask,
                timeout=60.0
            )
            return {
                "agent": agent.id,
                "subtask": subtask,
                "result": response.payload,
                "success": True,
            }
        except Exception as e:
            return {
                "agent": agent.id,
                "subtask": subtask,
                "error": str(e),
                "success": False,
            }
    
    def get_status(self) -> Dict[str, Any]:
        """Get swarm status"""
        return {
            "id": self.id,
            "name": self.name,
            "members": len(self._members),
            "agents": [a.status.to_dict() for a in self._members.values()],
            "coordinator": self.coordinator.status.to_dict(),
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "pending_tasks": len([t for t in self._tasks.values() if t.status == "pending"]),
        }


# ============================================================================
# Singleton Instances
# ============================================================================

_registry: Optional[AgentRegistry] = None


def get_registry() -> AgentRegistry:
    """Get or create the global agent registry"""
    global _registry
    if _registry is None:
        _registry = AgentRegistry()
    return _registry


def create_agent(
    agent_type: str,
    name: str,
    **kwargs
) -> AriaAgent:
    """
    Factory function to create agents by type.
    
    Args:
        agent_type: Type of agent (task, reasoning, coordinator, generator)
        name: Agent name
        **kwargs: Additional agent parameters
        
    Returns:
        Created agent instance
    """
    agent_types = {
        "task": TaskAgent,
        "reasoning": ReasoningAgent,
        "coordinator": CoordinatorAgent,
        "generator": GeneratorAgent,
    }
    
    agent_class = agent_types.get(agent_type.lower())
    if not agent_class:
        raise ValueError(f"Unknown agent type: {agent_type}. Available: {list(agent_types.keys())}")
    
    return agent_class(name, **kwargs)


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    # Message types
    "MessageType",
    "MessagePriority",
    "AgentMessage",
    
    # Agent state
    "AgentState",
    "AgentStatus",
    "AgentCapability",
    
    # Base agent
    "AriaAgent",
    "AgentHandler",
    
    # Specialized agents
    "TaskAgent",
    "ReasoningAgent",
    "CoordinatorAgent",
    "GeneratorAgent",
    
    # Registry
    "AgentRegistry",
    "get_registry",
    
    # Swarm
    "AgentSwarm",
    "SwarmTask",
    
    # Factory
    "create_agent",
]
