# ARIA CLI Migration Guide

## Migrating from v0.1.x to v0.2.0

This guide covers upgrading from aria-cli v0.1.0/v0.1.1 to v0.2.0.

---

## Overview

| Feature | v0.1.x | v0.2.0 |
|---------|--------|--------|
| Q-System Layers | 8 (QUANTUM→MEMORY) | **39 (Q0-Q38)** |
| Q38 Cluster | ❌ | ✅ 64-direction support |
| LLM Integration | Optional embeddings | Multi-backend (OpenAI, Anthropic, Ollama, local) |
| Package Structure | Flat `aria_cli/` | `src/aria_cli/` (PEP 517) |
| SQLite Knowledge | `ARIAConnector` | `KnowledgeConnector` + legacy alias |
| CLI Framework | argparse | typer + rich |
| Async Support | ❌ | ✅ |
| GUI Sync | ❌ | ✅ Plugin system |

---

## Installation

### v0.1.x
```bash
pip install aria-cli
```

### v0.2.0
```bash
pip install aria-cli>=0.2.0

# Or with extras
pip install aria-cli[full]     # All features
pip install aria-cli[llm]      # LLM support
pip install aria-cli[rich]     # Rich terminal
```

---

## Code Migration

### 1. Imports

**v0.1.x:**
```python
from aria_cli import AriaCLI, QSystem, QOperator, NLPEngine
from aria_cli import ARIAConnector
```

**v0.2.0:**
```python
from aria_cli import AriaCLI, QSystem, QOperator, NLPEngine
from aria_cli import KnowledgeConnector  # New name
from aria_cli import ARIAConnector       # Legacy alias still works!

# New v0.2.0 imports
from aria_cli import Q38Connector, Q38Config, Q38Response
from aria_cli import AriaConnector, SyncMode  # GUI sync
```

### 2. Q-System Layers

**v0.1.x (8 layers):**
```python
from aria_cli import QLayer

# v0.1.x layers
QLayer.QUANTUM      # 1
QLayer.OBSERVATION  # 2
QLayer.REASONING    # 3
QLayer.HYPOTHESIS   # 4
QLayer.ACTION       # 5
QLayer.FEEDBACK     # 6
QLayer.EVOLUTION    # 7
QLayer.MEMORY       # 8
```

**v0.2.0 (39 layers - Q0-Q38):**
```python
from aria_cli import QLayer

# v0.2.0 layers (examples)
QLayer.Q0_VOID          # 0 - Foundation
QLayer.Q8_LANGUAGE      # 8 - Language processing
QLayer.Q10_LOGIC        # 10 - Logic/reasoning
QLayer.Q17_EVALUATION   # 17 - Evaluation
QLayer.Q38_TRANSCENDENCE # 38 - Highest layer

# Layer mapping from v0.1.x:
# QUANTUM     → Q0_VOID
# OBSERVATION → Q1_INPUT
# REASONING   → Q10_LOGIC
# HYPOTHESIS  → Q13_HYPOTHESIS
# ACTION      → Q20_PLANNING
# FEEDBACK    → Q17_EVALUATION
# EVOLUTION   → Q35_ADAPTATION
# MEMORY      → Q6_MEMORY
```

### 3. Knowledge Base Queries

**v0.1.x:**
```python
from aria_cli import ARIAConnector

kb = ARIAConnector()
results = kb.query_g10("trading")
results = kb.query_q38("compression")
stats = kb.get_stats()
```

**v0.2.0 (fully compatible):**
```python
from aria_cli import KnowledgeConnector  # New name

kb = KnowledgeConnector()
results = kb.query_g10("trading")
results = kb.query_q38("compression")
stats = kb.get_stats()

# New features in v0.2.0:
results = kb.query_by_layer(10)  # Query by Q-layer
kb.q38_connector = Q38Connector()  # Attach cluster
```

### 4. Q38 Cluster Integration (New in v0.2.0)

```python
from aria_cli import Q38Connector, Q38Config

# Connect to your Q38 cluster
q38 = Q38Connector()

# Check availability
if q38.available:
    # Process through cluster
    response = q38.process("analyze this text", layer=10)
    print(response.to_text())
    
    # Query specific direction
    result = q38.process("data", direction="a005625")
    
    # Get cluster status
    status = q38.get_cluster_status()
```

### 5. CLI Commands

**v0.1.x:**
```bash
aria ask "question"
aria search "query"
aria q-command TRAIN
aria --interactive
aria status
```

**v0.2.0 (all still work + new commands):**
```bash
# Existing commands (compatible)
aria ask "question"
aria search "query"
aria status

# New in v0.2.0
aria chat              # Interactive mode with rich UI
aria layers            # Show all 39 Q-layers
aria q38 status        # Q38 cluster status
aria q38 directions    # List 64 directions
aria q38 query a005625 "text"  # Query direction
```

---

## Breaking Changes

### None for Basic Usage

v0.2.0 maintains full backward compatibility with v0.1.x. Your existing code will work.

### Optional Migration

| v0.1.x | v0.2.0 | Notes |
|--------|--------|-------|
| `ARIAConnector` | `KnowledgeConnector` | Alias available |
| `QLayer.MEMORY` | `QLayer.Q6_MEMORY` | 8-layer mapping provided |
| `--interactive` | `chat` command | Both work |

---

## New Features in v0.2.0

### 1. Q38 Cluster Support

Connect to your local Q38 distributed processing cluster:

```python
from aria_cli import Q38Connector

q38 = Q38Connector()

# 64 directions
print(q38.directions)  # ['a000000', 'a001125', ...]

# Process with cluster fallback to local
response = q38.process("input text")
```

### 2. QSAID Framework

Structured reasoning on top of Q38:

```python
from aria_cli.q38_connector import QSAIDProcessor

qsaid = QSAIDProcessor()

# Query
answer = qsaid.query("What is quantum computing?")

# Analyze
analysis = qsaid.analyze(data, analysis_type="deep")

# Synthesize
synthesis = qsaid.synthesize([input1, input2, input3])
```

### 3. GUI Sync

Sync CLI state with aria_interface.py:

```python
from aria_cli import AriaConnector, SyncMode

sync = AriaConnector()
sync.connect("aria_interface.py")
sync.set_mode(SyncMode.BIDIRECTIONAL)

# State syncs automatically
```

### 4. Plugin System

Extend CLI with plugins:

```python
from aria_cli import AriaPlugin, PluginManager

class MyPlugin(AriaPlugin):
    name = "my-plugin"
    
    async def on_command(self, cmd):
        # Process command
        pass

manager = PluginManager()
manager.register(MyPlugin())
```

### 5. Rich Terminal Output

Beautiful terminal output with progress bars, tables, panels:

```bash
pip install aria-cli[rich]
aria chat  # Now with colors and formatting!
```

---

## Configuration

### v0.1.x Config Location
```
~/.aria-cli/config.json
```

### v0.2.0 Config (compatible)
```
~/.aria-cli/config.json  # Still works
~/.config/aria-cli/config.yaml  # New option
```

### New Config Options in v0.2.0

```json
{
  "q38": {
    "api_url": "http://localhost:8080",
    "base_port": 8200,
    "sync_port": 9000,
    "node_count": 8
  },
  "llm": {
    "backend": "auto",
    "temperature": 0.7
  },
  "ui": {
    "theme": "dark",
    "show_layer_info": true
  }
}
```

---

## Testing Your Migration

```python
# Verify import compatibility
from aria_cli import __version__
print(f"Version: {__version__}")  # Should be 0.2.0

# Test basic functionality
from aria_cli import AriaCLI, NLPEngine, QSystem

cli = AriaCLI()
nlp = NLPEngine()
q = QSystem()

# Test knowledge base
from aria_cli import KnowledgeConnector, ARIAConnector
kb1 = KnowledgeConnector()
kb2 = ARIAConnector()  # Legacy alias works

# Test new features
from aria_cli import Q38Connector
q38 = Q38Connector()
print(f"Q38 available: {q38.available}")
print(f"Directions: {len(q38.directions)}")
```

---

## Getting Help

- **Issues**: https://github.com/AlphaMythicDot/universal-monorepo/issues
- **Docs**: See `packages/aria-cli-v2/README.md`
- **CLI Help**: `aria --help`

---

## Version Compatibility Matrix

| aria-cli | Python | Q-Layers | Q38 Cluster | SQLite KB |
|----------|--------|----------|-------------|-----------|
| 0.1.0 | 3.8+ | 8 | ❌ | ✅ |
| 0.1.1 | 3.8+ | 8 | ❌ | ✅ |
| 0.2.0 | 3.10+ | 39 | ✅ | ✅ |

---

*Last Updated: December 22, 2025*
