
import sys
import inspect
import importlib


def calculation2(x, y, z=None):
    """替换后的计算方法 - 乘法实现"""
    if z is not None:
        result = x * y * z
        return result
    else:
        result = x * y
        return result

def process_real_pred_lists(real_lst, pred_lst, c_scaler):
    real_lst = [1, 2, 3, 4, 5]
    pred_lst = [1, 2, 3, 4, 5]
    return real_lst,pred_lst

def create_smart_wrapper():
    """创建智能包装器 - 自动参数嗅探"""
    def smart_calculation_wrapper(*args, **kwargs):
        """智能包装器 - 拦截函数调用并自动嗅探参数"""
        # 获取调用者的局部变量
        frame = inspect.currentframe().f_back
        caller_locals = frame.f_locals
        
        # 解析传入的参数
        if len(args) >= 2:
            x, y = args[0], args[1]
            z = args[2] if len(args) > 2 else kwargs.get('z')
        else:
            x = args[0] if len(args) > 0 else kwargs.get('x')
            y = kwargs.get('y')
            z = kwargs.get('z')
        
        # 参数嗅探：检查调用者作用域中是否有 z 变量
        if z is None and 'z' in caller_locals:
            z = caller_locals['z']
        
        # 调用替换后的方法
        return calculation2(x, y, z)
    
    return smart_calculation_wrapper


def apply_patch():
    """应用猴子补丁 - 自动替换已导入或未导入的模块"""
    try:
        # 尝试从 sys.modules 获取已导入的模块
        if 'Cus_MinMaxScaler' in sys.modules:
            Cus_MinMaxScaler = sys.modules['Cus_MinMaxScaler']
            if hasattr(Cus_MinMaxScaler, 'process_real_pred_lists') and not hasattr(Cus_MinMaxScaler, '_original_process_real_pred_lists'):
                # 保存原始方法
                Cus_MinMaxScaler._original_process_real_pred_lists = Cus_MinMaxScaler.process_real_pred_lists
                # 替换为智能包装器
                Cus_MinMaxScaler.process_real_pred_lists = create_smart_wrapper()
        
        # 无论模块是否已导入，都安装延迟补丁（以防其他导入）
        _install_deferred_patch()
    except Exception as e:
        pass  # 忽略错误，静默失败


def _install_deferred_patch():
    """安装延迟补丁 - 模块导入后自动应用"""
    
    class DeferredPatcher:
        """延迟补丁器 - 在模块导入后自动打补丁"""
        
        def find_module(self, fullname, path=None):
            if fullname == 'Cus_MinMaxScaler':
                return self
            return None
        
        def load_module(self, fullname):
            # 先让 Python 正常加载模块
            if fullname in sys.modules:
                return sys.modules[fullname]
            
            # 临时移除自己，避免递归
            sys.meta_path = [hook for hook in sys.meta_path if not isinstance(hook, DeferredPatcher)]
            
            try:
                # 找到并加载原始模块
                module = importlib.import_module(fullname)
                
                if hasattr(module, 'process_real_pred_lists') and not hasattr(module, 'p'):
                    module._original_calculation = module.calculation
                    module.calculation = create_smart_wrapper()
                
                return module
            finally:
                if not any(isinstance(hook, DeferredPatcher) for hook in sys.meta_path):
                    sys.meta_path.insert(0, DeferredPatcher())
    
    # 安装到 sys.meta_path
    sys.meta_path.insert(0, DeferredPatcher())


# 自动应用补丁
apply_patch()
