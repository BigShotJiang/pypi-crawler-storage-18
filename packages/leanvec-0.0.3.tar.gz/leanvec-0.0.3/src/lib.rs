use parking_lot::RwLock;
use pyo3::prelude::*;
use roaring::RoaringBitmap;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap};
use std::fs::{File, OpenOptions};
use std::io::{BufReader, BufWriter, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::sync::Arc;

const M: usize = 12;
const EF_CONSTRUCTION: usize = 100;

#[inline(always)]
fn quantize(val: f32) -> u8 {
    let clamped = val.clamp(-1.0, 1.0);
    ((clamped + 1.0) * 127.5) as u8
}

#[inline(always)]
fn dist_sq_u8(a: &[u8], b: &[u8]) -> u32 {
    let mut d: u32 = 0;
    // Auto-vectorization friendly loop
    for i in 0..a.len() {
        let diff = (a[i] as i32) - (b[i] as i32);
        d += (diff * diff) as u32;
    }
    d
}

// --- Persistence ---
#[derive(Serialize, Deserialize)]
enum WalEntry {
    Insert { id: String, vec: Vec<f32>, meta: Map<String, Value> },
    Delete { id: String },
}

#[derive(Serialize, Deserialize)]
struct CoreIndex {
    vectors: Vec<Vec<u8>>,
    graph: Vec<Vec<usize>>,
    enter_point: Option<usize>,
    
    // Inverted Index for STRINGS (Equality lookups)
    // Field -> Value -> Bitmap
    str_index: HashMap<String, HashMap<String, RoaringBitmap>>,
    
    // Columnar Store for NUMBERS (Range lookups)
    // Field -> Dense Vector of values (Index = Internal ID)
    // f32::NAN to represent "missing" values
    num_store: HashMap<String, Vec<f32>>,
    
    valid_ids: RoaringBitmap,
    deleted: RoaringBitmap,
    ext_to_int: HashMap<String, usize>,
    int_to_ext: Vec<String>,
}

impl CoreIndex {
    fn new() -> Self {
        Self {
            vectors: Vec::with_capacity(500_000),
            graph: Vec::with_capacity(500_000),
            enter_point: None,
            str_index: HashMap::new(),
            num_store: HashMap::new(),
            valid_ids: RoaringBitmap::new(),
            deleted: RoaringBitmap::new(),
            ext_to_int: HashMap::new(),
            int_to_ext: Vec::with_capacity(500_000),
        }
    }

    fn insert_in_mem(&mut self, ext_id: String, vector: Vec<f32>, metadata: Map<String, Value>) {
        if self.ext_to_int.contains_key(&ext_id) { return; }

        let new_id = self.vectors.len();
        let q_vec: Vec<u8> = vector.iter().map(|&x| quantize(x)).collect();
        
        self.vectors.push(q_vec);
        self.int_to_ext.push(ext_id.clone());
        self.ext_to_int.insert(ext_id, new_id);
        self.valid_ids.insert(new_id as u32);
        
        // 1. Process Metadata
        for (key, val) in metadata {
            match val {
                Value::String(s) => {
                    self.str_index.entry(key).or_default()
                        .entry(s).or_default()
                        .insert(new_id as u32);
                },
                Value::Number(n) => {
                    if let Some(f) = n.as_f64() {
                        let f_val = f as f32;
                        // Ensure column exists and is padded to current length
                        let col = self.num_store.entry(key).or_insert_with(|| vec![f32::NAN; new_id]);
                        // Pad if new field introduced late
                        if col.len() < new_id {
                            col.resize(new_id, f32::NAN);
                        }
                        col.push(f_val);
                    }
                },
                Value::Bool(b) => {
                    let s = if b { "true".to_string() } else { "false".to_string() };
                    self.str_index.entry(key).or_default()
                        .entry(s).or_default()
                        .insert(new_id as u32);
                },
                _ => {} 
            }
        }

        // 2. Pad any numeric columns that weren't in this metadata but exist in DB
        // This ensures col.len() == new_id + 1
        for col in self.num_store.values_mut() {
            if col.len() == new_id {
                col.push(f32::NAN);
            }
        }

        // 3. HNSW Graph Insert
        self.graph.push(Vec::with_capacity(M + 1));
        if self.enter_point.is_none() {
            self.enter_point = Some(new_id);
            return;
        }

        let neighbors = self._search_core(&self.vectors[new_id], EF_CONSTRUCTION, None);
        let mut connections = Vec::new();
        for (_dist, neighbor_id) in neighbors.iter().take(M) {
            connections.push(*neighbor_id);
            if self.graph[*neighbor_id].len() < M {
                self.graph[*neighbor_id].push(new_id);
            }
        }
        self.graph[new_id] = connections;
    }

    fn delete_in_mem(&mut self, ext_id: String) {
        if let Some(&int_id) = self.ext_to_int.get(&ext_id) {
            self.deleted.insert(int_id as u32);
            self.valid_ids.remove(int_id as u32);
            self.ext_to_int.remove(&ext_id);

            // If the Entry Point is deleted, move it to a valid node.
            if Some(int_id) == self.enter_point {
                // We pick the maximum valid ID (newest node). 
                // In an Append-Only graph, newer nodes usually have better connectivity.
                self.enter_point = self.valid_ids.max().map(|x| x as usize);
            }
        }
    }

    // --- Filter Logic ---
    fn is_expensive_filter(&self, filter: &Value) -> bool {
        match filter {
            Value::Object(map) => {
                // Recursive logic: if it contains $and/$or/$not with expensive children
                if let Some(clauses) = map.get("$and").or(map.get("$or")) {
                    if let Value::Array(arr) = clauses {
                        return arr.iter().any(|f| self.is_expensive_filter(f));
                    }
                }
                
                // Check fields
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    
                    // If field is numeric, it's expensive
                    if self.num_store.contains_key(key) {
                        return true;
                    }
                    
                    // Check for nested operators on potentially numeric fields
                    if let Value::Object(ops) = val {
                        for (op, _) in ops {
                            if ["$gt", "$gte", "$lt", "$lte"].contains(&op.as_str()) {
                                return true;
                            }
                        }
                    }
                }
                false
            },
            _ => false
        }
    }

    fn evaluate_filter(&self, filter: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        match filter {
            Value::Object(map) => {
                // --- AND Optimization: Reordering ---
                if let Some(clauses) = map.get("$and") {
                    if let Value::Array(arr) = clauses {
                        // 1. Separate Cheap vs Expensive
                        let (cheap, expensive): (Vec<&Value>, Vec<&Value>) = arr.iter()
                            .partition(|f| !self.is_expensive_filter(f));

                        // 2. Execute Cheap First (narrow down the universe)
                        // Start with the provided mask or the full valid set
                        let mut current_res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());

                        for f in cheap {
                            // Cheap filters don't need a mask (usually hash lookups), 
                            // but we intersect immediately
                            current_res &= self.evaluate_filter(f, None);
                            if current_res.is_empty() { return current_res; }
                        }

                        // 3. Execute Expensive using the narrowed result as a Mask
                        for f in expensive {
                            // Pass current_res as the mask!
                            current_res &= self.evaluate_filter(f, Some(&current_res));
                            if current_res.is_empty() { return current_res; }
                        }
                        return current_res;
                    }
                }
                
                // --- OR Logic (Harder to optimize with masks, standard union) ---
                if let Some(clauses) = map.get("$or") {
                    if let Value::Array(arr) = clauses {
                        let mut res = RoaringBitmap::new();
                        for sub in arr {
                            // Mask doesn't help much in OR, usually need to evaluate fully
                            res |= self.evaluate_filter(sub, None);
                        }
                        // If we had an incoming mask (from a parent AND), strictly enforce it at the end
                        if let Some(m) = mask {
                            res &= m;
                        }
                        return res;
                    }
                }
                
                if let Some(clause) = map.get("$not") {
                    let sub = self.evaluate_filter(clause, None);
                    let mut res = &self.valid_ids - &sub;
                    if let Some(m) = mask { res &= m; }
                    return res;
                }

                // --- Field Evaluation ---
                let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
                
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    // Pass the mask down to the field evaluator
                    res &= self.evaluate_field_condition(key, val, Some(&res));
                    if res.is_empty() { return res; }
                }
                res
            },
            _ => RoaringBitmap::new(),
        }
    }

    fn evaluate_field_condition(&self, field: &str, condition: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if condition.is_string() || condition.is_boolean() {
            return self.get_bitmap_str_eq(field, condition);
        }
        
        if condition.is_number() {
            return self.evaluate_numeric_op(field, "$eq", condition.as_f64().unwrap() as f32, mask);
        }

        if let Value::Object(op_map) = condition {
            let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
            
            for (op, val) in op_map {
                let op_res = match op.as_str() {
                    "$eq" => {
                        if val.is_number() {
                            self.evaluate_numeric_op(field, "$eq", val.as_f64().unwrap() as f32, mask)
                        } else {
                            self.get_bitmap_str_eq(field, val)
                        }
                    },
                    "$ne" => {
                         if val.is_number() {
                            self.evaluate_numeric_op(field, "$ne", val.as_f64().unwrap() as f32, mask)
                        } else {
                            &self.valid_ids - &self.get_bitmap_str_eq(field, val)
                        }
                    },
                    "$in" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr {
                                // No mask recursion for simple $in, usually string lookups
                                u |= self.evaluate_field_condition(field, item, None);
                            }
                        }
                        u
                    },
                    "$nin" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr { u |= self.evaluate_field_condition(field, item, None); }
                        }
                        &self.valid_ids - &u
                    },
                    "$gt" | "$gte" | "$lt" | "$lte" => {
                        if let Some(f) = val.as_f64() {
                            self.evaluate_numeric_op(field, op, f as f32, mask)
                        } else {
                            RoaringBitmap::new()
                        }
                    },
                    _ => RoaringBitmap::new()
                };
                res &= op_res;
            }
            return res;
        }
        RoaringBitmap::new()
    }

    fn get_bitmap_str_eq(&self, field: &str, val: &Value) -> RoaringBitmap {
        let key_str = match val {
            Value::String(s) => s.clone(),
            Value::Bool(b) => if *b { "true".to_string() } else { "false".to_string() },
            _ => return RoaringBitmap::new(),
        };
        self.str_index.get(field)
            .and_then(|m| m.get(&key_str))
            .cloned().unwrap_or_default()
    }

    // Hybrid Scan Strategy
    // If mask is small (< 10% of DB), iterate the mask (sparse).
    // If mask is large or None, iterate the array (dense/SIMD).
    fn evaluate_numeric_op(&self, field: &str, op: &str, target: f32, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if let Some(column) = self.num_store.get(field) {
            
            // 1. Collect results in a plain vector first. 
            // Direct insertion into RoaringBitmap in a tight loop is slow.
            let mut matches: Vec<u32> = Vec::with_capacity(1024); 

            // 2. Heuristic: Use Sparse Scan if mask density < 50%
            let use_sparse = if let Some(m) = mask {
                (m.len() as usize) < (self.vectors.len() / 2)
            } else {
                false
            };

            if use_sparse {
                // --- SPARSE PATH ---
                // Iterate only the indices present in the mask.
                if let Some(m) = mask {
                    for id in m.iter() {
                        let idx = id as usize;
                        // Unchecked access is safe here if we trust ext_to_int logic, 
                        // but we stick to safe indexing for stability.
                        if let Some(&val) = column.get(idx) {
                            if val.is_nan() { continue; }
                            
                            let is_match = match op {
                                "$gt" => val > target,
                                "$gte" => val >= target,
                                "$lt" => val < target,
                                "$lte" => val <= target,
                                "$eq" => (val - target).abs() < f32::EPSILON,
                                "$ne" => (val - target).abs() > f32::EPSILON,
                                _ => false
                            };
                            
                            if is_match { matches.push(id); }
                        }
                    }
                    // Bulk creation is O(N) but very fast for sorted inputs
                    return RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap(); 
                }
            }

            // --- DENSE PATH (SIMD Friendly) ---
            // Iterates contiguous memory.
            for (i, &val) in column.iter().enumerate() {
                 let is_match = match op {
                    "$gt" => val > target,
                    "$gte" => val >= target,
                    "$lt" => val < target,
                    "$lte" => val <= target,
                    "$eq" => (val - target).abs() < f32::EPSILON,
                    "$ne" => (val - target).abs() > f32::EPSILON,
                    _ => false
                };
                if is_match { matches.push(i as u32); }
            }
            
            let mut bm = RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap();
            
            // Intersect at the end if we took the dense path
            if let Some(m) = mask {
                bm &= m;
            } else {
                bm &= &self.valid_ids;
            }
            return bm;
        }
        RoaringBitmap::new()
    }

    fn _search_core(&self, target_vec: &[u8], ef: usize, filter: Option<&RoaringBitmap>) -> Vec<(u32, usize)> {
        if self.enter_point.is_none() { return vec![]; }

        let mut visited = RoaringBitmap::new();
        let mut candidates = BinaryHeap::new(); // MinHeap (via Reverse) to explore closest nodes
        let mut results = BinaryHeap::new();    // MaxHeap to keep track of top-k VALID nodes

        let ep = self.enter_point.unwrap();
        let d_ep = dist_sq_u8(target_vec, &self.vectors[ep]);
        
        candidates.push(Reverse((d_ep, ep)));
        visited.insert(ep as u32);
        
        // Check validity of Entry Point
        let ep_valid = !self.deleted.contains(ep as u32) && 
                       filter.map_or(true, |bm| bm.contains(ep as u32));
        
        if ep_valid {
            results.push((d_ep, ep));
        }

        while let Some(Reverse((d_curr, curr_id))) = candidates.pop() {
            // Stopping Logic:
            // If we have filled the result buffer with valid nodes, 
            // and the current candidate is worse than the worst valid node found so far -> stop.
            if results.len() >= ef {
                if let Some(&(d_worst, _)) = results.peek() {
                    if d_curr > d_worst {
                        break;
                    }
                }
            }

            for &neighbor in &self.graph[curr_id] {
                if !visited.contains(neighbor as u32) {
                    visited.insert(neighbor as u32);
                    let dist = dist_sq_u8(target_vec, &self.vectors[neighbor]);
                    
                    // Dynamic Pruning:
                    // We traverse if we are better than the worst VALID result found so far.
                    // If we haven't found 'ef' valid results yet, the threshold is infinity (u32::MAX).
                    let threshold = if results.len() >= ef {
                        results.peek().unwrap().0
                    } else {
                        u32::MAX
                    };

                    if dist <= threshold {
                        candidates.push(Reverse((dist, neighbor)));
                        
                        // Check Validity
                        let is_valid = !self.deleted.contains(neighbor as u32) && 
                                       filter.map_or(true, |bm| bm.contains(neighbor as u32));
                        
                        if is_valid {
                            results.push((dist, neighbor));
                            if results.len() > ef {
                                results.pop(); // Keep only top 'ef' valid results
                            }
                        }
                    }
                }
            }
        }

        // Convert heap to sorted vector
        let final_results = results.into_sorted_vec();
        final_results
    }

    /// Release unused memory back to the OS.
    /// Crucial for low-RAM environments after heavy inserts.
    fn compact_memory(&mut self) {
        // 1. Shrink main vectors
        self.vectors.shrink_to_fit();
        // Inner vectors (u8) usually fit exactly, but good to ensure
        for v in &mut self.vectors { v.shrink_to_fit(); }

        // 2. Shrink Graph (High fragmentation area)
        self.graph.shrink_to_fit();
        for adj in &mut self.graph { adj.shrink_to_fit(); }

        // 3. Shrink Auxiliary structures
        self.int_to_ext.shrink_to_fit();
        self.ext_to_int.shrink_to_fit();
        
        // 4. Shrink Columnar Store
        self.num_store.shrink_to_fit();
        for col in self.num_store.values_mut() {
            col.shrink_to_fit();
        }
    }
}

// --- Python Class ---

#[pyclass]
struct LeanDB {
    inner: Arc<RwLock<CoreIndex>>,
    base_path: PathBuf,
    wal_writer: Arc<RwLock<BufWriter<File>>>,
}

#[pymethods]
impl LeanDB {
    #[new]
    fn new(storage_path: String) -> PyResult<Self> {
        let path = PathBuf::from(storage_path);
        std::fs::create_dir_all(&path)?;
        let snapshot_path = path.join("snapshot.bin");
        let wal_path = path.join("wal.bin");

        let mut index = CoreIndex::new();
        
        if snapshot_path.exists() {
            let f = File::open(&snapshot_path)?;
            let reader = BufReader::new(f);
            if let Ok(idx) = bincode::deserialize_from(reader) {
                index = idx;
            }
        }

        if wal_path.exists() {
            let f = File::open(&wal_path)?;
            if f.metadata()?.len() > 0 {
                let mut reader = BufReader::new(f);
                loop {
                    match bincode::deserialize_from::<&mut BufReader<File>, WalEntry>(&mut reader) {
                        Ok(entry) => match entry {
                            WalEntry::Insert { id, vec, meta } => index.insert_in_mem(id, vec, meta),
                            WalEntry::Delete { id } => index.delete_in_mem(id),
                        },
                        Err(_) => break,
                    }
                }
            }
        }

        let wal_file = OpenOptions::new().create(true).append(true).open(&wal_path)?;

        Ok(LeanDB {
            inner: Arc::new(RwLock::new(index)),
            base_path: path,
            wal_writer: Arc::new(RwLock::new(BufWriter::new(wal_file))),
        })
    }

    fn add(&self, id: String, vector: Vec<f32>, metadata: String) -> PyResult<()> {
        let meta_map: Map<String, Value> = serde_json::from_str(&metadata)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON: {}", e)))?;

        {
            let mut writer = self.wal_writer.write();
            let entry = WalEntry::Insert { id: id.clone(), vec: vector.clone(), meta: meta_map.clone() };
            bincode::serialize_into(&mut *writer, &entry).unwrap();
        }

        let mut guard = self.inner.write();
        guard.insert_in_mem(id, vector, meta_map);
        Ok(())
    }

    fn delete(&self, id: String) {
        {
            let mut writer = self.wal_writer.write();
            let entry = WalEntry::Delete { id: id.clone() };
            bincode::serialize_into(&mut *writer, &entry).unwrap();
        }
        let mut guard = self.inner.write();
        guard.delete_in_mem(id);
    }

    fn delete_by_filter(&self, filter_json: String) -> PyResult<usize> {
        // 1. Parse Filter
        let filter_val: Value = serde_json::from_str(&filter_json)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid Filter: {}", e)))?;

        // 2. Acquire Write Locks (we will be modifying data)
        let mut guard = self.inner.write();
        let mut writer = self.wal_writer.write();

        // 3. Find ALL matches using the index
        // This returns a Bitmap of internal IDs. It is Exact and Exhaustive.
        let matches = guard.evaluate_filter(&filter_val, None);
        
        // Collect into a Vec so we don't iterate while modifying (though Bitmap is separate, this is safer)
        let ids_to_delete: Vec<u32> = matches.iter().collect();
        let mut count = 0;

        for int_id in ids_to_delete {
            let idx = int_id as usize;
            
            // Check if already deleted (evaluate_filter usually checks valid_ids, but safety first)
            if guard.deleted.contains(int_id) { continue; }

            // Retrieve External ID (needed for WAL and Map removal)
            if idx < guard.int_to_ext.len() {
                let ext_id = guard.int_to_ext[idx].clone();

                // A. Write to WAL
                let entry = WalEntry::Delete { id: ext_id.clone() };
                // We unwrap here for prototype simplicity; in prod, handle IO errors
                if let Err(_) = bincode::serialize_into(&mut *writer, &entry) {
                    continue; 
                }

                // B. Delete from Memory
                guard.delete_in_mem(ext_id);
                count += 1;
            }
        }
        
        Ok(count)
    }

    fn persist(&self) -> PyResult<()> {
        let snapshot_path = self.base_path.join("snapshot.bin");
        let tmp_path = self.base_path.join("snapshot.bin.tmp");

        println!("Starting persistence routine...");

        // STEP 1: Compact Memory (Requires Write Lock)
        {
            println!("Compacting memory...");
            let mut guard = self.inner.write();
            guard.compact_memory();
        } 
        
        // STEP 2: Serialize to Disk (Read Lock)
        {
            println!("Writing to disk...");
            let guard = self.inner.read();
            let f = File::create(&tmp_path)?;
            
            // INCREASE BUFFER SIZE: 
            let mut writer = BufWriter::with_capacity(1024 * 1024, f);
            
            bincode::serialize_into(&mut writer, &*guard).unwrap();
            writer.flush()?;
            // Fix E0382: access file via the writer reference
            writer.get_ref().sync_all()?;
        }

        // STEP 3: Atomic Rename & Clean WAL
        std::fs::rename(&tmp_path, &snapshot_path)?;
        
        {
            let mut wal_guard = self.wal_writer.write();
            wal_guard.flush()?;
            let file = wal_guard.get_mut();
            file.set_len(0)?;
            file.seek(SeekFrom::Start(0))?;
        }
        
        println!("Persistence complete.");
        Ok(())
    }

    fn search(&self, vector: Vec<f32>, k: usize, filter_json: Option<String>) -> PyResult<Vec<(String, f32)>> {
        let guard = self.inner.read();
        let q_vec: Vec<u8> = vector.iter().map(|&x| quantize(x)).collect();

        let mut final_mask: Option<RoaringBitmap> = None;
        if let Some(json_str) = filter_json {
             let filter_val: Value = serde_json::from_str(&json_str)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid Filter: {}", e)))?;
             
             final_mask = Some(guard.evaluate_filter(&filter_val, None));
        }

        let raw_results = guard._search_core(&q_vec, k * 5, final_mask.as_ref());

        Ok(raw_results.iter()
            .take(k)
            .map(|(_d, idx)| {
                (guard.int_to_ext[*idx].clone(), *_d as f32) 
            })
            .collect())
    }
    
    fn count(&self) -> usize {
        let guard = self.inner.read();
        guard.vectors.len() - guard.deleted.len() as usize
    }
}

#[pymodule]
fn leanvec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<LeanDB>()?;
    Ok(())
}