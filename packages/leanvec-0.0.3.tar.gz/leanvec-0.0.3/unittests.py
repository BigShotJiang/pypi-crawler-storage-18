import unittest
import shutil
import tempfile
import time
import os
import numpy as np

from leanvecdb import LeanVecDB

class BaseVectorDBTest(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        # FIX: Set auto_persist=False. 
        # We delete the directory in tearDown, so we don't want atexit trying to save there later.
        self.db = LeanVecDB(self.test_dir, auto_persist=False)
        
    def tearDown(self):
        # Explicitly release the rust object
        if hasattr(self, 'db'): 
            del self.db
            
        # Clean up disk
        if os.path.exists(self.test_dir):
            try:
                shutil.rmtree(self.test_dir)
            except OSError:
                pass 

    def _store_batch(self, vectors, metas, ids=None):
        """Helper that adapts to the Wrapper's batch input format"""
        if ids:
            for i, meta in enumerate(metas):
                meta["id"] = str(ids[i])
        
        self.db.store_embeddings_batch(vectors, metas)

    def _ids(self, results):
        """Helper to extract IDs from wrapper results"""
        return sorted([r["id"] for r in results])

class TestAdvancedFilters(BaseVectorDBTest):
    def setUp(self):
        super().setUp()
        vec = [0.1, 0.1]
        self._store_batch(
            [vec]*6, 
            [
                {"id": "1", "tag": "A", "score": 10, "active": True},
                {"id": "2", "tag": "B", "score": 20, "active": True},
                {"id": "3", "tag": "A", "score": 30, "active": False},
                {"id": "4", "tag": "C", "score": 40, "active": True},
                {"id": "5", "tag": "B", "score": 50, "active": False},
                {"id": "6", "tag": "A", "score": 60, "active": True},
            ]
        )
        self.vec = vec

    def test_gt_lt(self):
        res = self.db.search(self.vec, filters={"score": {"$gt": 35}}, k=10)
        self.assertEqual(self._ids(res), ["4", "5", "6"])

        res = self.db.search(self.vec, filters={"score": {"$lt": 25}}, k=10)
        self.assertEqual(self._ids(res), ["1", "2"])

    def test_and_logic(self):
        query = {"$and": [
            {"tag": "A"},
            {"score": {"$gt": 20}}
        ]}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["3", "6"])

    def test_or_logic(self):
        query = {"$or": [
            {"tag": "C"},
            {"score": {"$lt": 15}}
        ]}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["1", "4"])

    def test_in_nin(self):
        res = self.db.search(self.vec, filters={"tag": {"$in": ["B", "C"]}}, k=10)
        self.assertEqual(self._ids(res), ["2", "4", "5"])

        res = self.db.search(self.vec, filters={"tag": {"$nin": ["A", "B"]}}, k=10)
        self.assertEqual(self._ids(res), ["4"])

    def test_not_complex(self):
        query = {"$not": {"$or": [{"tag": "A"}, {"score": {"$lt": 20}}]}}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["2", "4", "5"])

class TestBulkDelete(BaseVectorDBTest):
    def test_large_scale_delete(self):
        count = 15_000
        vecs = [[0.1, 0.1]] * count
        
        metas = []
        for i in range(count):
            group = "A" if i < 10000 else "B"
            metas.append({"id": str(i), "group": group})
            
        print(f"Inserting {count} vectors for delete test...")
        self.db.store_embeddings_batch(vecs, metas)
        
        self.assertEqual(self.db.count(), 15000)
        
        print("Deleting group 'A' (10,000 items)...")
        start = time.time()
        deleted_count = self.db.delete({"group": "A"})
        dur = time.time() - start
        
        print(f"Deleted {deleted_count} items in {dur:.4f}s")
        
        self.assertEqual(deleted_count, 10000)
        self.assertEqual(self.db.count(), 5000)
        
        res = self.db.search([0.1, 0.1], filters={"group": "B"}, k=1)
        self.assertTrue(len(res) > 0)
        
        res_gone = self.db.search([0.1, 0.1], filters={"group": "A"}, k=1)
        self.assertEqual(len(res_gone), 0)

class TestWrapperFeatures(BaseVectorDBTest):
    def test_autocut(self):
        scores = [0.1, 0.12, 0.13, 0.50, 0.51]
        indices = self.db.autocut_scores(scores)
        self.assertEqual(indices, [3, 4])

    def test_dimension_enforcement(self):
        self.db.store_embedding([0.1, 0.1], {"id": "1"})
        
        with self.assertRaises(ValueError):
            self.db.store_embedding([0.1, 0.1, 0.1], {"id": "2"})
            
        del self.db
        new_db = LeanVecDB(self.test_dir, auto_persist=False)
        with self.assertRaises(ValueError):
            new_db.store_embedding([0.1, 0.1, 0.1], {"id": "3"})

class TestPerformance(BaseVectorDBTest):
    def test_filter_speed_large(self):
        count = 10000
        vecs = np.random.rand(count, 768).astype(np.float32).tolist()
        metas = []
        for i in range(count):
            metas.append({
                "id": str(i),
                "val": i,
                "group": "A"
            })
        
        start = time.time()
        self.db.store_embeddings_batch(vecs, metas)
        print(f"\n[Perf] Inserted {count} in {time.time()-start:.2f}s")
        
        start = time.time()
        res = self.db.search(vecs[0], k=10, filters={"val": {"$gt": count/2}})
        dur = time.time() - start
        
        print(f"[Perf] Range Search via Wrapper: {dur*1000:.2f}ms")
        self.assertTrue(dur < 0.1) 

if __name__ == "__main__":
    unittest.main()