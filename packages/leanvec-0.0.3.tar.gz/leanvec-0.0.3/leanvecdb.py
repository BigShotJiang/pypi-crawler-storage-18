from typing import List, Dict, Any, Optional
import json, uuid, os, leanvec, atexit, gc

class LeanVecDB:
    """
    A Pythonic wrapper for the high-performance Rust LeanVec database.
    
    Features:
    - Auto-detection and enforcement of vector dimension.
    - Automatic JSON serialization.
    - ID generation.
    - Batch processing.
    - Autocut post-processing.
    """

    def __init__(self, storage_folder: str = 'leanvec_db', auto_persist: bool = True):
        """
        Initialize the vector database.

        Args:
            storage_folder (str): Path to the directory where data will be persisted.
            auto_persist (bool): If True, automatically saves snapshot on program exit.
        """
        self.storage_folder = storage_folder
        self.config_path = os.path.join(storage_folder, 'config.json')
        
        if not os.path.exists(storage_folder):
            os.makedirs(storage_folder)

        # Initialize Rust backend
        self.db = leanvec.LeanDB(storage_folder)
        
        # Load dimension state
        self.dimension = self._load_dimension()

        # Register auto-persist hook
        if auto_persist:
            atexit.register(self.persist)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures persist is called."""
        self.persist()

    def _load_dimension(self) -> Optional[int]:
        """Load the fixed dimension from config if it exists."""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    return config.get('dimension')
            except Exception:
                return None
        return None

    def _set_dimension(self, dim: int):
        """Set the dimension on first insert and persist it."""
        self.dimension = dim
        with open(self.config_path, 'w') as f:
            json.dump({'dimension': dim}, f)

    def store_embedding(self, embedding: List[float], metadata_dict: Dict[str, Any] = {}) -> str:
        """Store a single embedding."""
        return self.store_embeddings_batch([embedding], [metadata_dict])[0]

    def store_embeddings_batch(self, embeddings: List[List[float]], metadatas: Optional[List[Dict[str, Any]]] = None) -> List[str]:
        """
        Store multiple embeddings in batch.
        Enforces dimension consistency.
        """
        if not embeddings:
            return []

        # 1. Dimension Check / Auto-detection
        input_dim = len(embeddings[0])

        if self.dimension is None:
            # First time usage: Lock the dimension
            self._set_dimension(input_dim)
        elif input_dim != self.dimension:
            raise ValueError(f"Dimension Mismatch: DB is configured for {self.dimension}, "
                             f"but received vector of size {input_dim}.")

        # 2. Metadata Handling
        if metadatas is None:
            metadatas = [{} for _ in range(len(embeddings))]
        
        if len(embeddings) != len(metadatas):
            raise ValueError("Length of embeddings and metadatas must match.")

        ids = []
        for vec, meta in zip(embeddings, metadatas):
            # Sanity check every vector in batch (or trust input for speed)
            if len(vec) != self.dimension:
                 raise ValueError(f"Batch contains inconsistent dimensions. Expected {self.dimension}, got {len(vec)}")

            if "id" in meta:
                doc_id = str(meta["id"])
            else:
                doc_id = str(uuid.uuid4())
                meta["id"] = doc_id
            
            ids.append(doc_id)
            
            # Serialize metadata
            meta_json = json.dumps(meta)
            
            # Call Rust
            self.db.add(doc_id, vec, meta_json)
        
        return ids
    
    def delete(self, metadata_filter: Dict[str, Any]) -> int:
        """
        Delete entries in the database that match the metadata_filter.
        
        Args:
            metadata_filter (Dict): The filter criteria (e.g. {"category": "books"}).
            
        Returns:
            int: The number of items deleted.
        """
        if self.dimension is None:
            return 0

        # Serialize the filter and call the optimized Rust implementation
        filter_str = json.dumps(metadata_filter)
        
        # This now performs an exact, exhaustive delete of all matches
        return self.db.delete_by_filter(filter_str)
    
    def autocut_scores(self, score_list: List[float]) -> List[int]:
        """
        Detects significant drop-offs in relevance scores.
        """
        if len(score_list) < 2:
            return []

        score_changes = []
        for i in range(1, len(score_list)):
            prev = score_list[i-1]
            curr = score_list[i]
            if prev == 0: 
                change = 0 
            else:
                # Relative increase in L2 distance (smaller is better)
                change = (curr - prev) / prev
            score_changes.append(change)
        
        if not score_changes:
            return []

        max_change = max(score_changes)

        # 20% threshold
        if max_change > 0.2:
            cut_index = score_changes.index(max_change) + 1
            return list(range(cut_index, len(score_list)))
        
        return []

    def search(self, 
               query_embedding: List[float], 
               filters: Optional[Dict[str, Any]] = None, 
               k: int = 5, 
               autocut: bool = False, 
               return_vectors: bool = False) -> List[Dict[str, Any]]:
        """
        Search for nearest neighbors.
        """
        if self.dimension is None:
            return [] # DB empty
            
        if len(query_embedding) != self.dimension:
            raise ValueError(f"Query dimension mismatch. Expected {self.dimension}, got {len(query_embedding)}")

        filter_str = json.dumps(filters) if filters else None
        
        # Rust returns: List[(id, score)]
        raw_results = self.db.search(query_embedding, k, filter_str)
        
        formatted_results = []
        scores = []
        
        for doc_id, score in raw_results:
            result = {
                "id": doc_id,
                "score": score
            }
            formatted_results.append(result)
            scores.append(score)

        if autocut and len(scores) > 1:
            indices_to_remove = self.autocut_scores(scores)
            if indices_to_remove:
                formatted_results = formatted_results[:indices_to_remove[0]]

        return formatted_results

    def persist(self):
        """Force save to disk (Snapshots RAM to File)."""
        try:
            # Force Python to release all unused objects (lists, dicts from inserts)
            # BEFORE we ask Rust to serialize.
            gc.collect() 
            self.db.persist()
        except Exception as e:
            print(f"Persist failed: {e}")

    def count(self) -> int:
        """Total vectors."""
        return self.db.count()
