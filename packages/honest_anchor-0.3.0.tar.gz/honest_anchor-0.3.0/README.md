# Honest Anchor

> **DEPRECATED**
>
> **This package is deprecated. Use [proofnest-anchor](https://pypi.org/project/proofnest-anchor/) instead.**
>
> ```bash
> pip install proofnest-anchor
> ```
>
> PROOFNEST ANCHOR is the new name for honest-anchor. Same functionality, new identity.

---

## Git commit for your IP

Timestamp your files to Bitcoin in seconds. Prove prior art. Forever.

```bash
# Use the new package
pip install proofnest-anchor

# Commands remain the same
anchor init
anchor commit <file>
anchor verify <file>
```

## License

Apache-2.0. Copyright (c) 2025 Stellanium Ltd.
