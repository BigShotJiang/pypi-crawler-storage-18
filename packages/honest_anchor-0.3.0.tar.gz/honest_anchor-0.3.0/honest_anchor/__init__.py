"""
Honest Anchor - git commit for your IP

Timestamp your files to Bitcoin in seconds.
Prove prior art. Forever.

DEPRECATED: Use proofnest-anchor instead.
  pip install proofnest-anchor

(c) 2025 Stellanium Ltd. All rights reserved.
"""

__version__ = "0.3.0"
__author__ = "Stellanium Ltd"

# ============================================================================
# DEPRECATION NOTICE
# ============================================================================
import warnings as _warnings

_warnings.warn(
    "honest-anchor is deprecated. Use 'proofnest-anchor' instead:\n"
    "  pip install proofnest-anchor\n"
    "See: https://pypi.org/project/proofnest-anchor/",
    DeprecationWarning,
    stacklevel=2
)
