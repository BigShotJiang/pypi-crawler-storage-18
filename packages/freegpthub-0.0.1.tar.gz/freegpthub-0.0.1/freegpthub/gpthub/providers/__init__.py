'''initialize'''
from .oai import OpenAIChatGPTEndpoints
from .baidu import BaiduQianfanEndpoints
from .iflytek import IFLYTEKSparkEndpoints
from .base import BaseEndpoint, EndpointRegistry