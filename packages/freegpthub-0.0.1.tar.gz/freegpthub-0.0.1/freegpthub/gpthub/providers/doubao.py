'''
Function:
    Implementation of DoubaoEndpoints
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
from .base import BaseEndpoint
from ..utils import resp2json, ChatRequest, ChatResponse


