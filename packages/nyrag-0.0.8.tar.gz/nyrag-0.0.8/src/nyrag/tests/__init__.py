"""Test suite for nyrag."""
