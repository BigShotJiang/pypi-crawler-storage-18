from setuptools import setup, find_packages

setup(
    name="CConsole",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.7",
)
