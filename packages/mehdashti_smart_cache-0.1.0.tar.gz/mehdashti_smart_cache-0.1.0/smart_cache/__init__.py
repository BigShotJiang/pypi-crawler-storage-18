"""
Smart Cache

Caching utilities with Redis and Memory providers for Smart Platform.
"""

from smart_cache.base import CacheProvider
from smart_cache.memory import MemoryCache
from smart_cache.redis import RedisCache
from smart_cache.decorators import cached, cache_key

__version__ = "0.1.0"

__all__ = [
    "CacheProvider",
    "MemoryCache",
    "RedisCache",
    "cached",
    "cache_key",
]
