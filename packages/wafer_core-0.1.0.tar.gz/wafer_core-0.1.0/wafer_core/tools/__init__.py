"""Tools module for wafer-core.

Provides CUDA tool finding and compilation utilities.
"""

from wafer_core.tools.tool_finder import (
    find_nvcc,
    find_nvdisasm,
    get_nvcc_version,
    get_platform,
)
from wafer_core.tools.compiler import (
    compile_cuda,
    detect_arch,
    CompileResult,
    ArchDetectResult,
)

__all__ = [
    # Tool finder
    "find_nvcc",
    "find_nvdisasm",
    "get_nvcc_version",
    "get_platform",
    # Compiler
    "compile_cuda",
    "detect_arch",
    "CompileResult",
    "ArchDetectResult",
]

