"""Wafer Core - utilities and environments for GPU kernel optimization.

Main exports:
- CodingEnvironment: Pi-coding-agent style environment with read/write/edit/bash/wafer tools
- GPUModeSimpleEnvironment: Environment for GPU kernel optimization
- Target configs: ModalTarget, BaremetalTarget, VMTarget
- Sessions: AgentSession, SessionStore, FileSessionStore
- Logging: setup_logging, ColorFormatter, JSONFormatter
- Retry: retry, async_retry, RetryState
- SSH: SSHClient
- Utils: Remote execution, kernel utilities, etc.
- Tools: CUDA compilation (compile_cuda, detect_arch), tool finding (find_nvcc, find_nvdisasm)
- Telemetry: with_telemetry decorator, telemetry hooks

Note: Imports are lazy to avoid pulling in rollouts for code that only
needs utility modules (e.g., evaluate.py only needs wafer_core.utils.*).
"""

__all__ = [
    "CodingEnvironment",
    "GPUModeSimpleEnvironment",
    "ModalTarget",
    "BaremetalTarget",
    "VMTarget",
    "TargetConfig",
    # Sessions
    "AgentHooks",
    "AgentSession",
    "EndpointConfig",
    "EnvironmentConfig",
    "FileSessionStore",
    "Message",
    "SessionStore",
    "Status",
    "run_agent_with_session",
    # Logging
    "setup_logging",
    "ColorFormatter",
    "JSONFormatter",
    # Retry
    "retry",
    "retry_v2",
    "async_retry",
    "RetryState",
    # Tools
    "compile_cuda",
    "detect_arch",
    "find_nvcc",
    "find_nvdisasm",
    "get_nvcc_version",
    "CompileResult",
    "ArchDetectResult",
    # Telemetry
    "with_telemetry",
    "set_telemetry_hook",
    "clear_telemetry_hook",
    "track_event",
]


def __getattr__(name: str):
    """Lazy import to avoid loading rollouts for utility-only usage."""
    if name == "CodingEnvironment":
        from wafer_core.environments.coding import CodingEnvironment

        return CodingEnvironment

    if name == "GPUModeSimpleEnvironment":
        from wafer_core.environments.gpumode import GPUModeSimpleEnvironment

        return GPUModeSimpleEnvironment

    if name in (
        "AgentHooks",
        "AgentSession",
        "EndpointConfig",
        "EnvironmentConfig",
        "FileSessionStore",
        "Message",
        "SessionStore",
        "Status",
        "run_agent_with_session",
    ):
        from wafer_core import sessions

        return getattr(sessions, name)

    if name in ("BaremetalTarget", "ModalTarget", "TargetConfig", "VMTarget"):
        from wafer_core.utils.kernel_utils import targets

        return getattr(targets, name)

    if name in ("setup_logging", "ColorFormatter", "JSONFormatter"):
        from wafer_core import logging

        return getattr(logging, name)

    if name in ("retry", "retry_v2", "async_retry", "RetryState"):
        from wafer_core import retry

        return getattr(retry, name)

    # Tools
    if name in (
        "compile_cuda",
        "detect_arch",
        "find_nvcc",
        "find_nvdisasm",
        "get_nvcc_version",
        "CompileResult",
        "ArchDetectResult",
    ):
        from wafer_core import tools

        return getattr(tools, name)

    # Telemetry
    if name in ("with_telemetry", "set_telemetry_hook", "clear_telemetry_hook", "track_event"):
        from wafer_core import telemetry

        return getattr(telemetry, name)

    raise AttributeError(f"module 'wafer_core' has no attribute {name!r}")
