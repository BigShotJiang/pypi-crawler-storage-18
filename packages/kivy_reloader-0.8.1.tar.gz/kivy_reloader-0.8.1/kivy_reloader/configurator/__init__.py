from .app import ConfiguratorUI
