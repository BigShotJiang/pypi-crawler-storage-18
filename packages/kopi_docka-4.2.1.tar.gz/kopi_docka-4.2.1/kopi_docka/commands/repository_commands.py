################################################################################
# KOPI-DOCKA
#
# @file:        repository_commands.py
# @module:      kopi_docka.commands
# @description: Repository management commands
# @author:      Markus F. (TZERO78) & KI-Assistenten
# @repository:  https://github.com/TZERO78/kopi-docka
# @version:     2.0.0
#
# ------------------------------------------------------------------------------
# Copyright (c) 2025 Markus F. (TZERO78)
# MIT-Lizenz: siehe LICENSE oder https://opensource.org/licenses/MIT
################################################################################

"""Repository management commands."""

import json
import subprocess
import shutil
import time
import secrets
import string
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import box

from ..helpers import Config, get_logger, generate_secure_password
from ..helpers.ui_utils import (
    print_success,
    print_error,
    print_warning,
    print_error_panel,
    print_success_panel,
    print_next_steps,
)
import getpass
from ..cores import KopiaRepository

logger = get_logger(__name__)
console = Console()


def get_config(ctx: typer.Context) -> Optional[Config]:
    """Get config from context."""
    return ctx.obj.get("config")


def ensure_config(ctx: typer.Context) -> Config:
    """Ensure config exists or exit."""
    cfg = get_config(ctx)
    if not cfg:
        print_error_panel(
            "No configuration found\n\n"
            "[dim]Run:[/dim] [cyan]kopi-docka admin config new[/cyan]"
        )
        raise typer.Exit(code=1)
    return cfg


def get_repository(ctx: typer.Context) -> Optional[KopiaRepository]:
    """Get or create repository from context."""
    if "repository" not in ctx.obj:
        cfg = get_config(ctx)
        if cfg:
            ctx.obj["repository"] = KopiaRepository(cfg)
    return ctx.obj.get("repository")


def ensure_repository(ctx: typer.Context) -> KopiaRepository:
    """Ensure repository is connected."""
    repo = get_repository(ctx)
    if not repo:
        print_error_panel("Repository not available")
        raise typer.Exit(code=1)

    # Already connected?
    try:
        if repo.is_connected():
            return repo
    except Exception:
        pass

    # Auto connect
    console.print("[cyan]Connecting to Kopia repository...[/cyan]")
    try:
        repo.connect()
    except Exception as e:
        print_error_panel(
            f"Connect failed: {e}\n\n"
            "[dim]Check:[/dim] kopia_params, password, permissions, mounts."
        )
        raise typer.Exit(code=1)

    if not repo.is_connected():
        print_error("Still not connected after connect().")
        raise typer.Exit(code=1)

    return repo


def _print_kopia_native_status(repo: KopiaRepository) -> None:
    """Print Kopia native status with raw output."""
    console.print()
    console.print(Panel.fit(
        "[bold]Kopia Native Status - Debug Output[/bold]",
        border_style="dim"
    ))

    cfg_file = repo._get_config_file()
    env = repo._get_env()

    cmd_json_verbose = ["kopia", "repository", "status", "--json-verbose", "--config-file", cfg_file]
    cmd_json = ["kopia", "repository", "status", "--json", "--config-file", cfg_file]
    cmd_plain = ["kopia", "repository", "status", "--config-file", cfg_file]

    used_cmd = None
    rc_connected = False
    raw_out = raw_err = ""

    for cmd in (cmd_json_verbose, cmd_json, cmd_plain):
        p = subprocess.run(cmd, env=env, text=True, capture_output=True)
        used_cmd = cmd
        raw_out, raw_err = p.stdout or "", p.stderr or ""
        if p.returncode == 0:
            rc_connected = True
            break

    # Debug info table
    debug_table = Table(box=box.SIMPLE, show_header=False)
    debug_table.add_column("Property", style="dim")
    debug_table.add_column("Value")

    debug_table.add_row("Command used", " ".join(used_cmd))
    debug_table.add_row("Config file", cfg_file)
    debug_table.add_row("KOPIA_PASSWORD", "[green]set[/green]" if env.get("KOPIA_PASSWORD") else "[red]unset[/red]")
    debug_table.add_row("KOPIA_CACHE", env.get("KOPIA_CACHE_DIRECTORY") or "-")
    debug_table.add_row("Connected (by RC)", "[green]Yes[/green]" if rc_connected else "[red]No[/red]")

    console.print(debug_table)

    # Output panel
    console.print()
    console.print("[dim]--- kopia stdout ---[/dim]")
    console.print(raw_out.strip() or "[dim]<empty>[/dim]")
    if raw_err.strip():
        console.print()
        console.print("[dim]--- kopia stderr ---[/dim]")
        console.print(f"[yellow]{raw_err.strip()}[/yellow]")

    # Pretty-print JSON if possible
    try:
        parsed = json.loads(raw_out) if raw_out else None
        if parsed is not None:
            console.print()
            console.print("[dim]--- parsed JSON (pretty) ---[/dim]")
            console.print(json.dumps(parsed, indent=2, ensure_ascii=False))
    except Exception:
        pass


# -------------------------
# Commands
# -------------------------

def cmd_init(ctx: typer.Context):
    """Initialize (or connect to) the Kopia repository."""
    import getpass

    if not shutil.which("kopia"):
        print_error_panel(
            "Kopia is not installed!\n\n"
            "[dim]Install with:[/dim] [cyan]kopi-docka install-deps[/cyan]"
        )
        raise typer.Exit(code=1)

    cfg = ensure_config(ctx)

    # ═══════════════════════════════════════════
    # Phase 1: Password Check & Setup (if needed)
    # ═══════════════════════════════════════════
    try:
        current_password = cfg.get_password()
    except ValueError as e:
        print_warning(f"Password issue: {e}")
        current_password = ''

    # Check for default/placeholder passwords
    if current_password in ('kopia-docka', 'CHANGE_ME_TO_A_SECURE_PASSWORD', ''):
        console.print()
        console.print(Panel.fit(
            "[bold yellow]Default or missing password detected![/bold yellow]\n\n"
            "You need to set a secure password before initialization.\n\n"
            "[bold]This password will:[/bold]\n"
            "  [dim]•[/dim] Encrypt your backups\n"
            "  [dim]•[/dim] Be required for ALL future operations\n"
            "  [dim]•[/dim] Be UNRECOVERABLE if lost!",
            title="[bold]Repository Password Setup[/bold]",
            border_style="yellow"
        ))
        console.print()

        use_generated = typer.confirm("Generate secure random password?", default=True)
        console.print()

        if use_generated:
            new_password = generate_secure_password()
            console.print(Panel.fit(
                f"[bold]GENERATED PASSWORD (save this NOW!):[/bold]\n\n"
                f"   [bold cyan]{new_password}[/bold cyan]\n\n"
                "[yellow]Copy this to:[/yellow]\n"
                "  [dim]•[/dim] Password manager (recommended)\n"
                "  [dim]•[/dim] Encrypted USB drive\n"
                "  [dim]•[/dim] Secure physical location",
                title="[bold yellow]Important[/bold yellow]",
                border_style="yellow"
            ))
            console.print()
            input("Press Enter to continue...")
        else:
            new_password = getpass.getpass("Enter password: ")
            password_confirm = getpass.getpass("Confirm password: ")

            if new_password != password_confirm:
                print_error("Passwords don't match!")
                raise typer.Exit(1)

            if len(new_password) < 12:
                print_warning(f"Password is short ({len(new_password)} chars). Recommended: 12+ characters")
                if not typer.confirm("Continue with this password?", default=False):
                    console.print("[dim]Aborted.[/dim]")
                    raise typer.Exit(0)

        # Save password to config
        console.print("[cyan]Saving password to config...[/cyan]")
        cfg.set_password(new_password, use_file=True)
        password_file = cfg.config_file.parent / f".{cfg.config_file.stem}.password"
        print_success(f"Password saved: {password_file}")
        console.print()

        # IMPORTANT: Reload config to get new password
        cfg = Config(cfg.config_file)

    # ═══════════════════════════════════════════
    # Phase 2: Repository Initialization
    # ═══════════════════════════════════════════
    repo = KopiaRepository(cfg)

    console.print(Panel.fit(
        f"[bold]Profile:[/bold]      {repo.profile_name}\n"
        f"[bold]Kopia Params:[/bold] {repo.kopia_params}",
        title="[bold cyan]Repository Initialization[/bold cyan]",
        border_style="cyan"
    ))
    console.print()

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Initializing repository...", total=None)
            repo.initialize()
            progress.update(task, completed=True)

        console.print()
        print_success_panel("Repository initialized successfully!")

        print_next_steps([
            "List Docker containers: [cyan]kopi-docka list --units[/cyan]",
            "Test backup: [cyan]kopi-docka dry-run[/cyan]",
            "Create first backup: [cyan]kopi-docka backup[/cyan]",
        ])

    except Exception as e:
        print_error_panel(
            f"Initialization failed: {e}\n\n"
            "[bold]Common issues:[/bold]\n"
            "  [dim]•[/dim] Repository path not accessible\n"
            "  [dim]•[/dim] Insufficient permissions\n"
            "  [dim]•[/dim] Cloud credentials not configured\n"
            "  [dim]•[/dim] Network connectivity issues\n\n"
            "[bold]For cloud storage (B2/S3/Azure/GCS):[/bold]\n"
            "  [dim]•[/dim] Check environment variables (AWS_*, B2_*, etc.)\n"
            "  [dim]•[/dim] Verify bucket/container exists\n"
            "  [dim]•[/dim] Test credentials separately"
        )
        raise typer.Exit(code=1)


def cmd_repo_status(ctx: typer.Context):
    """Show Kopia repository status and statistics."""
    ensure_config(ctx)
    repo = ensure_repository(ctx)

    try:
        # Check connection status
        is_conn = False
        try:
            is_conn = repo.is_connected()
        except Exception:
            is_conn = False

        # Get statistics
        snapshots = repo.list_snapshots()
        units = repo.list_backup_units()

        # Build status table
        table = Table(
            title="Repository Status",
            show_header=True,
            header_style="bold cyan",
            box=box.ROUNDED,
            border_style="cyan"
        )
        table.add_column("Property", style="cyan")
        table.add_column("Value")

        table.add_row("Profile", repo.profile_name)
        table.add_row("Kopia Params", repo.kopia_params)
        table.add_row("Connected", "[green]Yes[/green]" if is_conn else "[red]No[/red]")
        table.add_row("Total Snapshots", str(len(snapshots)))
        table.add_row("Backup Units", str(len(units)))

        console.print()
        console.print(table)
        console.print()

        # Show detailed Kopia status if requested (debug)
        if ctx.obj.get('verbose'):
            _print_kopia_native_status(repo)

    except Exception as e:
        print_error_panel(f"Failed to get repository status: {e}")
        raise typer.Exit(code=1)


def cmd_repo_which_config(ctx: typer.Context):
    """Show which Kopia config file is used."""
    repo = get_repository(ctx) or KopiaRepository(ensure_config(ctx))

    table = Table(box=box.SIMPLE, show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value")

    table.add_row("Profile", repo.profile_name)
    table.add_row("Profile config", repo._get_config_file())
    table.add_row("Default config", str(Path.home() / '.config' / 'kopia' / 'repository.config'))

    console.print()
    console.print(table)
    console.print()


def cmd_repo_set_default(ctx: typer.Context):
    """Point default Kopia config at current profile."""
    repo = ensure_repository(ctx)

    src = Path(repo._get_config_file())
    dst = Path.home() / ".config" / "kopia" / "repository.config"
    dst.parent.mkdir(parents=True, exist_ok=True)

    try:
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        try:
            dst.symlink_to(src)
        except Exception:
            from shutil import copy2
            copy2(src, dst)
        print_success("Default kopia config set.")
        console.print("[dim]Test:[/dim]  [cyan]kopia repository status[/cyan]")
    except Exception as e:
        print_error_panel(f"Could not set default: {e}")
        raise typer.Exit(code=1)


def cmd_repo_init_path(
    ctx: typer.Context,
    path: Path,
    profile: Optional[str] = None,
    set_default: bool = False,
    password: Optional[str] = None,
):
    """Create a Kopia filesystem repository at PATH."""
    cfg = ensure_config(ctx)
    repo = KopiaRepository(cfg)

    env = repo._get_env()
    if password:
        env["KOPIA_PASSWORD"] = password

    cfg_file = repo._get_config_file() if not profile else str(
        Path.home() / ".config" / "kopia" / f"repository-{profile}.config"
    )
    Path(cfg_file).parent.mkdir(parents=True, exist_ok=True)

    path = path.expanduser().resolve()
    path.mkdir(parents=True, exist_ok=True)

    # Create
    cmd_create = [
        "kopia", "repository", "create", "filesystem",
        "--path", str(path),
        "--description", f"Kopi-Docka Backup Repository ({profile or repo.profile_name})",
        "--config-file", cfg_file,
    ]
    p = subprocess.run(cmd_create, env=env, text=True, capture_output=True)
    if p.returncode != 0 and "existing data in storage location" not in (p.stderr or ""):
        print_error("Create failed:")
        console.print(f"[dim]{p.stderr.strip() or p.stdout.strip()}[/dim]")
        raise typer.Exit(code=1)

    # Connect
    cmd_connect = [
        "kopia", "repository", "connect", "filesystem",
        "--path", str(path),
        "--config-file", cfg_file,
    ]
    pc = subprocess.run(cmd_connect, env=env, text=True, capture_output=True)
    if pc.returncode != 0:
        ps = subprocess.run(["kopia", "repository", "status", "--config-file", cfg_file], env=env, text=True, capture_output=True)
        print_error("Connect failed:")
        console.print(f"[dim]{pc.stderr.strip() or pc.stdout.strip() or ps.stderr.strip() or ps.stdout.strip()}[/dim]")
        raise typer.Exit(code=1)

    # Verify
    ps = subprocess.run(["kopia", "repository", "status", "--json", "--config-file", cfg_file], env=env, text=True, capture_output=True)
    if ps.returncode != 0:
        print_error("Status failed after connect:")
        console.print(f"[dim]{ps.stderr.strip() or ps.stdout.strip()}[/dim]")
        raise typer.Exit(code=1)

    print_success("Repository created & connected")
    console.print(f"  [cyan]Path:[/cyan]    {path}")
    console.print(f"  [cyan]Profile:[/cyan] {profile or repo.profile_name}")
    console.print(f"  [cyan]Config:[/cyan]  {cfg_file}")

    if set_default:
        src = Path(cfg_file)
        dst = Path.home() / ".config" / "kopia" / "repository.config"
        try:
            if dst.exists() or dst.is_symlink():
                dst.unlink()
            try:
                dst.symlink_to(src)
            except Exception:
                from shutil import copy2
                copy2(src, dst)
            print_success("Set as default Kopia config.")
        except Exception as e:
            print_warning(f"Could not set default: {e}")

    console.print()
    console.print("[dim]Use raw Kopia with this repo:[/dim]")
    console.print(f"  [cyan]kopia repository status --config-file {cfg_file}[/cyan]")


def cmd_repo_selftest(
    tmpdir: Path = Path("/tmp"),
    keep: bool = False,
    password: Optional[str] = None,
):
    """Create ephemeral test repository."""
    stamp = str(int(time.time()))
    test_profile = f"kopi-docka-selftest-{stamp}"
    repo_dir = Path(tmpdir) / f"kopia-selftest-{stamp}"
    repo_dir.mkdir(parents=True, exist_ok=True)

    if not password:
        alphabet = string.ascii_letters + string.digits
        password = "".join(secrets.choice(alphabet) for _ in range(24))

    conf_dir = Path.home() / ".config" / "kopi-docka"
    conf_dir.mkdir(parents=True, exist_ok=True)
    conf_path = conf_dir / f"selftest-{stamp}.conf"

    conf_path.write_text(
        f"""{{
  "kopia": {{
    "kopia_params": "filesystem --path {repo_dir}",
    "password": "{password}",
    "profile": "{test_profile}"
  }},
  "retention": {{
    "daily": 7,
    "weekly": 4,
    "monthly": 12,
    "yearly": 3
  }}
}}""",
        encoding="utf-8",
    )

    # Display selftest info
    table = Table(box=box.SIMPLE, show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value")
    table.add_row("Selftest profile", test_profile)
    table.add_row("Selftest repo path", str(repo_dir))
    table.add_row("Selftest config", str(conf_path))
    console.print(table)

    cfg = Config(conf_path)
    test_repo = KopiaRepository(cfg)

    console.print("[cyan]Connecting/creating test repository...[/cyan]")
    try:
        test_repo.initialize()
    except Exception as e:
        print_error_panel(f"Could not initialize selftest repo: {e}")
        raise typer.Exit(code=1)

    if not test_repo.is_connected():
        print_error("Not connected after initialize().")
        raise typer.Exit(code=1)

    _print_kopia_native_status(test_repo)

    workdir = repo_dir / "data"
    workdir.mkdir(parents=True, exist_ok=True)
    (workdir / "hello.txt").write_text("Hello Kopia!\n", encoding="utf-8")

    console.print("[cyan]Creating snapshot of selftest data...[/cyan]")
    snap_id = test_repo.create_snapshot(str(workdir), tags={"type": "selftest"})
    console.print(f"[dim]Snapshot ID:[/dim] {snap_id}")

    snaps = test_repo.list_snapshots(tag_filter={"type": "selftest"})
    console.print(f"[dim]Selftest snapshots:[/dim] {len(snaps)}")

    try:
        test_repo.maintenance_run(full=False)
    except Exception:
        pass

    if not keep:
        console.print("[cyan]Cleaning up selftest repo & config...[/cyan]")
        try:
            test_repo.disconnect()
        except Exception:
            pass
        try:
            import shutil as _shutil
            _shutil.rmtree(repo_dir, ignore_errors=True)
        except Exception:
            pass
        try:
            conf_path.unlink(missing_ok=True)
        except Exception:
            pass
        print_success("Cleanup done")
    else:
        console.print("[dim](kept) Inspect manually[/dim]")


def cmd_repo_maintenance(ctx: typer.Context):
    """Run Kopia repository maintenance."""
    ensure_config(ctx)
    repo = ensure_repository(ctx)

    console.print("[cyan]Running repository maintenance...[/cyan]")
    try:
        repo.maintenance_run()
        print_success("Maintenance completed")
    except Exception as e:
        print_error_panel(f"Maintenance failed: {e}")
        raise typer.Exit(code=1)


def cmd_change_password(
    ctx: typer.Context,
    new_password: Optional[str] = None,
    use_file: bool = True,
):
    """Change Kopia repository password and store securely."""
    cfg = ensure_config(ctx)
    repo = KopiaRepository(cfg)

    try:
        if not repo.is_connected():
            console.print("[cyan]Connecting to repository...[/cyan]")
            repo.connect()
    except Exception as e:
        print_error_panel(
            f"Failed to connect: {e}\n\n"
            "[bold]Make sure:[/bold]\n"
            "  [dim]•[/dim] Repository exists and is initialized\n"
            "  [dim]•[/dim] Current password in config is correct"
        )
        raise typer.Exit(code=1)

    console.print()
    console.print(Panel.fit(
        f"[bold]Repository:[/bold] {repo.repo_path}\n"
        f"[bold]Profile:[/bold]    {repo.profile_name}",
        title="[bold cyan]Change Repository Password[/bold cyan]",
        border_style="cyan"
    ))
    console.print()

    # Verify current password first
    console.print("[bold]Verify current password:[/bold]")
    current_password = getpass.getpass("Current password: ")

    console.print("[cyan]Verifying current password...[/cyan]")
    if not repo.verify_password(current_password):
        print_error_panel(
            "Current password is incorrect!\n\n"
            "[bold]If you've forgotten the password:[/bold]\n"
            "  [dim]•[/dim] Check /etc/.kopi-docka.password\n"
            "  [dim]•[/dim] Check password_file setting in config\n"
            "  [dim]•[/dim] As last resort: reset repository (lose all backups)"
        )
        raise typer.Exit(code=1)

    print_success("Current password verified")
    console.print()

    # Get new password
    if not new_password:
        console.print("[bold]Enter new password[/bold] [dim](empty = auto-generate):[/dim]")
        new_password = getpass.getpass("New password: ")

        if not new_password:
            new_password = generate_secure_password()
            console.print()
            console.print(Panel.fit(
                f"[bold]GENERATED PASSWORD:[/bold]\n\n"
                f"   [bold cyan]{new_password}[/bold cyan]",
                title="[bold yellow]Save This Password[/bold yellow]",
                border_style="yellow"
            ))
            console.print()
            if not typer.confirm("Use this password?"):
                console.print("[dim]Aborted.[/dim]")
                raise typer.Exit(code=0)
        else:
            new_password_confirm = getpass.getpass("Confirm new password: ")
            if new_password != new_password_confirm:
                print_error("Passwords don't match!")
                raise typer.Exit(code=1)

    if len(new_password) < 12:
        print_warning(f"Password is short ({len(new_password)} chars)")
        if not typer.confirm("Continue?"):
            raise typer.Exit(code=0)

    # Change in Kopia repository
    console.print()
    console.print("[cyan]Changing repository password...[/cyan]")
    try:
        repo.set_repo_password(new_password)
        print_success("Repository password changed")
    except Exception as e:
        print_error_panel(f"Error: {e}")
        raise typer.Exit(code=1)

    # Store password using Config class
    console.print("[cyan]Storing new password...[/cyan]")
    try:
        cfg.set_password(new_password, use_file=use_file)

        if use_file:
            password_file = cfg.config_file.parent / f".{cfg.config_file.stem}.password"
            print_success(f"Password stored in: {password_file} (chmod 600)")
        else:
            print_success(f"Password stored in: {cfg.config_file} (chmod 600)")
    except Exception as e:
        print_error_panel(
            f"Failed to store password: {e}\n\n"
            "[bold yellow]IMPORTANT: Write down this password manually![/bold yellow]\n"
            f"Password: {new_password}"
        )
        raise typer.Exit(code=1)

    console.print()
    print_success_panel("Password changed successfully!")


# -------------------------
# Registration
# -------------------------

def register(app: typer.Typer):
    """Register all repository commands."""
    
    # Simple commands without parameters
    app.command("init")(cmd_init)
    app.command("repo-status")(cmd_repo_status)
    app.command("repo-which-config")(cmd_repo_which_config)
    app.command("repo-set-default")(cmd_repo_set_default)
    app.command("repo-maintenance")(cmd_repo_maintenance)
    
    @app.command("repo-init-path")
    def _repo_init_path_cmd(
        ctx: typer.Context,
        path: Path = typer.Argument(..., help="Repository path"),
        profile: Optional[str] = typer.Option(None, "--profile", help="Profile name"),
        set_default: bool = typer.Option(False, "--set-default/--no-set-default"),
        password: Optional[str] = typer.Option(None, "--password"),
    ):
        """Create a Kopia filesystem repository at PATH."""
        cmd_repo_init_path(ctx, path, profile, set_default, password)
    
    @app.command("repo-selftest")
    def _repo_selftest_cmd(
        tmpdir: Path = typer.Option(Path("/tmp"), "--tmpdir"),
        keep: bool = typer.Option(False, "--keep/--no-keep"),
        password: Optional[str] = typer.Option(None, "--password"),
    ):
        """Create ephemeral test repository."""
        cmd_repo_selftest(tmpdir, keep, password)

    @app.command("change-password")
    def _change_password_cmd(
        ctx: typer.Context,
        new_password: Optional[str] = typer.Option(None, "--new-password", help="New password (will prompt if not provided)"),
        use_file: bool = typer.Option(True, "--file/--inline", help="Store in external file (default) or inline in config"),
    ):
        """Change Kopia repository password."""
        cmd_change_password(ctx, new_password, use_file)
