"""
nanocoder - A multi-provider coding agent with Textual TUI

Supports OpenAI, Anthropic, and Google Gemini via provider-native APIs.
"""

__version__ = "0.2.0"

