"""
Trace event schema and types for trajectory logging.

Defines the consistent event schema used across all providers for
debugging, reproducibility, and regression analysis.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
import hashlib
import json
import os
import platform
import socket


class TraceMode(Enum):
    """Trace logging modes with different verbosity levels."""
    
    META = "meta"        # No content, only sizes/hashes, names, timings
    CONTENT = "content"  # User+assistant text, tool calls, truncated results
    RAW = "raw"          # Full provider-native request/response objects


class TraceEventType(Enum):
    """Types of trace events."""
    
    RUN_START = "run.start"
    RUN_END = "run.end"
    TURN_START = "turn.start"
    TURN_END = "turn.end"
    MODEL_REQUEST = "model.request"
    MODEL_RESPONSE = "model.response"
    TOOL_START = "tool.start"
    TOOL_END = "tool.end"
    ERROR = "error"


@dataclass
class TraceEvent:
    """A single trace event for JSONL logging.
    
    All events share these required fields for consistency and self-containment.
    Each line can be processed independently.
    """
    
    trace_id: str                    # Stable per app session
    seq: int                         # Monotonically increasing
    ts: str                          # UTC ISO timestamp
    type: str                        # Event type string
    provider: str                    # gemini|openai|anthropic
    model: str                       # Model string
    data: dict = field(default_factory=dict)  # Event payload
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "trace_id": self.trace_id,
            "seq": self.seq,
            "ts": self.ts,
            "type": self.type,
            "provider": self.provider,
            "model": self.model,
            "data": self.data,
        }
    
    def to_json(self) -> str:
        """Convert to JSON string for JSONL output."""
        return json.dumps(self.to_dict(), ensure_ascii=False)
    
    @classmethod
    def now(cls) -> str:
        """Get current UTC ISO timestamp."""
        return datetime.now(timezone.utc).isoformat()


def content_hash(content: str) -> str:
    """Compute a short hash of content for meta mode."""
    return hashlib.sha256(content.encode()).hexdigest()[:12]


def truncate_content(content: str, max_len: int = 1000) -> str:
    """Truncate content for content mode."""
    if len(content) <= max_len:
        return content
    return content[:max_len] + f"... [truncated, {len(content)} total chars]"


def sanitize_for_mode(data: dict, mode: TraceMode) -> dict:
    """Sanitize data based on trace mode.
    
    Args:
        data: The data to sanitize
        mode: The trace mode (meta, content, raw)
        
    Returns:
        Sanitized data dictionary
    """
    if mode == TraceMode.RAW:
        return data
    
    result = {}
    for key, value in data.items():
        if mode == TraceMode.META:
            # For meta mode, replace content with sizes/hashes
            if key in ("content", "text", "stdout", "stderr", "result"):
                if isinstance(value, str):
                    result[key] = {
                        "length": len(value),
                        "hash": content_hash(value),
                    }
                elif isinstance(value, dict):
                    result[key] = {"type": "dict", "keys": list(value.keys())}
                else:
                    result[key] = {"type": type(value).__name__}
            elif key in ("args", "arguments"):
                # Keep argument keys but hash values
                if isinstance(value, dict):
                    result[key] = {
                        k: {"type": type(v).__name__, "length": len(str(v))}
                        for k, v in value.items()
                    }
                else:
                    result[key] = value
            else:
                result[key] = value
        else:  # CONTENT mode
            # Truncate long content
            if key in ("content", "text", "stdout", "stderr"):
                if isinstance(value, str):
                    result[key] = truncate_content(value)
                else:
                    result[key] = value
            elif key == "result":
                if isinstance(value, dict):
                    # Truncate string values in result dict
                    result[key] = {
                        k: truncate_content(v) if isinstance(v, str) else v
                        for k, v in value.items()
                    }
                else:
                    result[key] = value
            else:
                result[key] = value
    
    return result


# =============================================================================
# Event Factory Functions
# =============================================================================

def get_machine_info() -> dict:
    """Get machine/host information for logging."""
    from nanocoder import __version__
    return {
        "nanocoder_version": __version__,
        "hostname": socket.gethostname(),
        "platform": platform.system(),
        "platform_version": platform.version(),
        "python_version": platform.python_version(),
        "pid": os.getpid(),
    }


def make_run_start_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    cwd: str,
) -> TraceEvent:
    """Create a run.start event with machine metadata."""
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.RUN_START.value,
        provider=provider,
        model=model,
        data={
            "cwd": cwd,
            "machine": get_machine_info(),
        },
    )


def make_run_end_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    turns: int,
    total_tool_calls: int,
) -> TraceEvent:
    """Create a run.end event."""
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.RUN_END.value,
        provider=provider,
        model=model,
        data={"turns": turns, "total_tool_calls": total_tool_calls},
    )


def make_turn_start_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    turn: int,
    user_message: str | None = None,
) -> TraceEvent:
    """Create a turn.start event."""
    data: dict[str, Any] = {"turn": turn}
    if user_message is not None:
        # Always store full user message for training data
        data["user_message"] = user_message
    
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.TURN_START.value,
        provider=provider,
        model=model,
        data=data,
    )


def make_model_request_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    turn: int,
    tool_names: list[str],
    stream: bool = True,
) -> TraceEvent:
    """Create a model.request event."""
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.MODEL_REQUEST.value,
        provider=provider,
        model=model,
        data={
            "turn": turn,
            "tool_names": tool_names,
            "stream": stream,
        },
    )


def make_model_response_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    turn: int,
    text: str,
    reasoning: str | None = None,
    tool_calls: list[dict] | None = None,
    usage: dict | None = None,
    start_ts: str | None = None,
    end_ts: str | None = None,
) -> TraceEvent:
    """Create a model.response event with full content and timing.
    
    Always logs full raw content for training data reproducibility.
    Includes start/end timestamps for replay capability.
    
    Args:
        trace_id: Trace identifier
        seq: Sequence number
        provider: Provider name
        model: Model name
        turn: Turn number
        text: Accumulated response text (full, not truncated)
        reasoning: Accumulated reasoning/thinking content (full)
        tool_calls: List of tool calls with args
        usage: Token usage statistics
        start_ts: ISO timestamp when generation started
        end_ts: ISO timestamp when generation ended
    """
    data: dict[str, Any] = {
        "turn": turn,
        "text": text,  # Always full content
        "tool_calls": tool_calls or [],
    }
    
    # Add reasoning if present (always full)
    if reasoning:
        data["reasoning"] = reasoning
    
    # Add timing for replay
    if start_ts:
        data["start_ts"] = start_ts
    if end_ts:
        data["end_ts"] = end_ts
    
    # Add usage if available
    if usage:
        data["usage"] = usage
    
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.MODEL_RESPONSE.value,
        provider=provider,
        model=model,
        data=data,
    )


def make_tool_start_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    call_id: str,
    name: str,
    args: dict,
    mode: TraceMode = TraceMode.CONTENT,
) -> TraceEvent:
    """Create a tool.start event."""
    data = {
        "call_id": call_id,
        "name": name,
        "args": sanitize_for_mode({"args": args}, mode)["args"],
    }
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.TOOL_START.value,
        provider=provider,
        model=model,
        data=data,
    )


def make_tool_end_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    call_id: str,
    name: str,
    success: bool,
    result: dict,
    elapsed_ms: float,
    mode: TraceMode = TraceMode.CONTENT,
) -> TraceEvent:
    """Create a tool.end event."""
    data = {
        "call_id": call_id,
        "name": name,
        "success": success,
        "elapsed_ms": round(elapsed_ms, 2),
    }
    
    # Add result summary based on mode
    if mode == TraceMode.META:
        data["result_summary"] = {
            "keys": list(result.keys()),
            "error": "error" in result,
        }
    else:
        data["result"] = sanitize_for_mode({"result": result}, mode)["result"]
    
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.TOOL_END.value,
        provider=provider,
        model=model,
        data=data,
    )


def make_error_event(
    trace_id: str,
    seq: int,
    provider: str,
    model: str,
    error: str,
    error_type: str | None = None,
    recoverable: bool = False,
) -> TraceEvent:
    """Create an error event."""
    data: dict[str, Any] = {
        "error": error,
        "recoverable": recoverable,
    }
    if error_type:
        data["error_type"] = error_type
    
    return TraceEvent(
        trace_id=trace_id,
        seq=seq,
        ts=TraceEvent.now(),
        type=TraceEventType.ERROR.value,
        provider=provider,
        model=model,
        data=data,
    )

