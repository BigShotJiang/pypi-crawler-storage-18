"""
Trajectory logger for JSONL event logging.

Provides consistent logging across all providers for debugging,
reproducibility, and regression analysis.
"""

import os
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from .schema import (
    TraceEvent,
    TraceMode,
    make_run_start_event,
    make_run_end_event,
    make_turn_start_event,
    make_model_request_event,
    make_model_response_event,
    make_tool_start_event,
    make_tool_end_event,
    make_error_event,
)


class TrajectoryLogger:
    """JSONL trajectory logger for agent runs.
    
    Thread-safe logger that writes events to a JSONL file for each run.
    Supports different trace modes for privacy/verbosity control.
    """
    
    def __init__(
        self,
        trace_dir: str | Path = ".nanocoder_traces",
        mode: TraceMode = TraceMode.CONTENT,
        provider: str = "unknown",
        model: str = "unknown",
    ):
        """Initialize the trajectory logger.
        
        Args:
            trace_dir: Directory for trace files
            mode: Trace mode (meta, content, raw)
            provider: Provider name for events
            model: Model name for events
        """
        self.trace_dir = Path(trace_dir)
        self.mode = mode
        self.provider = provider
        self.model = model
        
        # Thread safety
        self._lock = threading.Lock()
        self._seq = 0
        
        # Generate trace ID and file path
        self._trace_id = self._generate_trace_id()
        self._file_path: Path | None = None
        self._file_handle: Any = None
        
        # Stats
        self._turn_count = 0
        self._tool_call_count = 0
    
    def _generate_trace_id(self) -> str:
        """Generate a unique trace ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique = uuid.uuid4().hex[:8]
        return f"{timestamp}_{unique}"
    
    def _get_file_path(self) -> Path:
        """Get the trace file path (creates dir if needed)."""
        if self._file_path is None:
            self.trace_dir.mkdir(parents=True, exist_ok=True)
            filename = f"{self._trace_id}_{self.provider}.jsonl"
            self._file_path = self.trace_dir / filename
        return self._file_path
    
    def _next_seq(self) -> int:
        """Get next sequence number (thread-safe)."""
        with self._lock:
            self._seq += 1
            return self._seq
    
    def _write_event(self, event: TraceEvent) -> None:
        """Write an event to the trace file (thread-safe)."""
        with self._lock:
            file_path = self._get_file_path()
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(event.to_json() + "\n")
    
    @property
    def trace_id(self) -> str:
        """Get the current trace ID."""
        return self._trace_id
    
    @property
    def trace_path(self) -> Path:
        """Get the trace file path."""
        return self._get_file_path()
    
    def set_provider_model(self, provider: str, model: str) -> None:
        """Update provider and model (for dynamic configuration)."""
        self.provider = provider
        self.model = model
    
    # =========================================================================
    # High-level logging methods
    # =========================================================================
    
    def log_run_start(self, cwd: str | None = None) -> None:
        """Log the start of an agent run."""
        cwd = cwd or os.getcwd()
        event = make_run_start_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            cwd=cwd,
        )
        self._write_event(event)
    
    def log_run_end(self) -> None:
        """Log the end of an agent run."""
        event = make_run_end_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            turns=self._turn_count,
            total_tool_calls=self._tool_call_count,
        )
        self._write_event(event)
    
    def log_turn_start(self, turn: int, user_message: str | None = None) -> None:
        """Log the start of a conversation turn."""
        self._turn_count = turn
        event = make_turn_start_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            turn=turn,
            user_message=user_message,
        )
        self._write_event(event)
    
    def log_model_request(
        self,
        turn: int,
        tool_names: list[str],
        stream: bool = True,
    ) -> None:
        """Log a model request."""
        event = make_model_request_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            turn=turn,
            tool_names=tool_names,
            stream=stream,
        )
        self._write_event(event)
    
    def log_model_response(
        self,
        turn: int,
        text: str,
        reasoning: str | None = None,
        tool_calls: list[dict] | None = None,
        usage: dict | None = None,
        start_ts: str | None = None,
        end_ts: str | None = None,
    ) -> None:
        """Log a model response with full content and timing.
        
        Always logs full raw content for training data reproducibility.
        
        Args:
            turn: Turn number
            text: Accumulated response text (full, not truncated)
            reasoning: Accumulated reasoning/thinking content (full)
            tool_calls: List of tool calls
            usage: Token usage statistics
            start_ts: ISO timestamp when generation started
            end_ts: ISO timestamp when generation ended
        """
        event = make_model_response_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            turn=turn,
            text=text,
            reasoning=reasoning,
            tool_calls=tool_calls,
            usage=usage,
            start_ts=start_ts,
            end_ts=end_ts,
        )
        self._write_event(event)
    
    def log_tool_start(
        self,
        call_id: str,
        name: str,
        args: dict,
    ) -> None:
        """Log the start of a tool execution."""
        event = make_tool_start_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            call_id=call_id,
            name=name,
            args=args,
            mode=self.mode,
        )
        self._write_event(event)
    
    def log_tool_end(
        self,
        call_id: str,
        name: str,
        success: bool,
        result: dict,
        elapsed_ms: float,
    ) -> None:
        """Log the end of a tool execution."""
        self._tool_call_count += 1
        event = make_tool_end_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            call_id=call_id,
            name=name,
            success=success,
            result=result,
            elapsed_ms=elapsed_ms,
            mode=self.mode,
        )
        self._write_event(event)
    
    def log_error(
        self,
        error: str,
        error_type: str | None = None,
        recoverable: bool = False,
    ) -> None:
        """Log an error event."""
        event = make_error_event(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            provider=self.provider,
            model=self.model,
            error=error,
            error_type=error_type,
            recoverable=recoverable,
        )
        self._write_event(event)
    
    def log_raw_event(self, event_type: str, data: dict) -> None:
        """Log a raw event (for provider-specific data in raw mode)."""
        if self.mode != TraceMode.RAW:
            return
        
        event = TraceEvent(
            trace_id=self._trace_id,
            seq=self._next_seq(),
            ts=TraceEvent.now(),
            type=event_type,
            provider=self.provider,
            model=self.model,
            data=data,
        )
        self._write_event(event)

