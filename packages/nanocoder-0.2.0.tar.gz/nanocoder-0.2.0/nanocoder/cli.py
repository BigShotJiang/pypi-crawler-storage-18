"""
CLI entry point for nanocoder.

Provides the main() function that runs the Textual TUI application.
"""

import os


def main():
    """Run the nanocoder application."""
    # Import here to avoid loading everything at startup
    from .app_tui import CodingAgentApp
    
    # Provide helpful error message for missing API keys
    provider = os.environ.get("NANOCODER_PROVIDER", "gemini").lower()
    
    key_map = {
        "gemini": "GEMINI_API_KEY",
        "openai": "OPENAI_API_KEY", 
        "anthropic": "ANTHROPIC_API_KEY",
    }
    
    required_key = key_map.get(provider)
    if required_key and not os.environ.get(required_key):
        print(f"Warning: {required_key} not set for provider '{provider}'")
        print(f"Set the environment variable or switch providers:")
        print(f"  export {required_key}='your-api-key'")
        print(f"  # or")
        print(f"  export NANOCODER_PROVIDER=gemini|openai|anthropic")
        print()
    
    app = CodingAgentApp()
    app.run()


if __name__ == "__main__":
    main()

