"""
Anthropic adapter using the Messages API.

Implements the LLMSession protocol for Claude models,
using content blocks for tool calling and streaming.
"""

import os
import json
from typing import Iterator, Any

import anthropic

from .base import (
    LLMSession,
    LLMEvent,
    TextDeltaEvent,
    ThoughtDeltaEvent,
    ToolCallEvent,
    FinalEvent,
    ErrorEvent,
    ToolOutput,
)
from ..agent.tools import ToolSpec, get_current_working_dir


# Default system instruction template
SYSTEM_INSTRUCTION_TEMPLATE = """You are an expert coding assistant with filesystem and shell access.

WORKFLOW:
- Read files before editing to understand context
- For complex logic, write a Python script instead of chaining bash commands

RESPONSES:
- Always provide a brief summary after completing tasks
- Explain what you did and the outcome

Current directory: {cwd}"""


class AnthropicSession(LLMSession):
    """LLMSession implementation for Anthropic Claude.
    
    Maintains native Anthropic conversation state (list of messages)
    and converts streaming content blocks to unified events.
    
    Tool use pattern: tool_use blocks -> execute -> tool_result with tool_use_id
    
    Extended thinking: Enabled by default with configurable budget to show
    Claude's internal reasoning process.
    """
    
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-opus-4-5-20251101",
        max_tokens: int = 16000,
        thinking_budget: int = 10000,
    ):
        """Initialize Anthropic session.
        
        Args:
            api_key: Anthropic API key (or from ANTHROPIC_API_KEY env var)
            model: Model identifier
            max_tokens: Maximum output tokens (must be > thinking_budget when thinking enabled)
            thinking_budget: Token budget for extended thinking (0 to disable)
        """
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY environment variable not set")
        
        self.client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens
        self._thinking_budget = thinking_budget
        
        # Native conversation state
        self._messages: list[dict] = []
        
        # Tool configuration
        self._tools: list[ToolSpec] = []
        self._anthropic_tools: list[dict] = []
    
    @property
    def provider(self) -> str:
        return "anthropic"
    
    @property
    def model(self) -> str:
        return self._model
    
    def set_tools(self, tools: list[ToolSpec]) -> None:
        """Configure tools for the session."""
        self._tools = tools
        self._anthropic_tools = [t.to_anthropic_tool() for t in tools]
    
    def _get_system_instruction(self) -> str:
        """Get the system instruction with current working directory."""
        cwd = get_current_working_dir()
        return SYSTEM_INSTRUCTION_TEMPLATE.format(cwd=cwd)
    
    def _stream_response(self) -> Iterator[LLMEvent]:
        """Stream from model and process events."""
        # Build request kwargs
        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "system": self._get_system_instruction(),
            "messages": self._messages,
        }
        
        # Add tools if configured
        if self._anthropic_tools:
            kwargs["tools"] = self._anthropic_tools
        
        # Enable extended thinking if budget is set
        # Extended thinking shows Claude's internal reasoning process
        if self._thinking_budget > 0:
            kwargs["thinking"] = {
                "type": "enabled",
                "budget_tokens": self._thinking_budget,
            }
        
        try:
            stream = self.client.messages.stream(**kwargs)
        except Exception as e:
            yield ErrorEvent(error=str(e), recoverable=False, raw_error=e)
            return
        
        # Accumulate response content
        accumulated_text = ""
        accumulated_thinking = ""
        tool_calls: list[ToolCallEvent] = []
        response_content: list[dict] = []
        usage = None
        
        # Track current content block being streamed
        current_block_type = None
        current_block_id = None
        current_block_index = None
        current_tool_name = None
        current_tool_input = ""
        current_thinking_signature = None  # Signature for thinking blocks (required for tool use)
        
        try:
            with stream as response_stream:
                for event in response_stream:
                    event_type = event.type
                    
                    if event_type == "content_block_start":
                        # New content block starting
                        block = event.content_block
                        current_block_type = block.type
                        current_block_index = event.index
                        
                        if block.type == "tool_use":
                            current_block_id = block.id
                            current_tool_name = block.name
                            current_tool_input = ""
                        elif block.type == "thinking":
                            # Extended thinking block starting
                            current_block_id = getattr(block, "id", None)
                    
                    elif event_type == "content_block_delta":
                        delta = event.delta
                        delta_type = delta.type
                        
                        if delta_type == "text_delta":
                            # Text chunk
                            text = delta.text
                            accumulated_text += text
                            yield TextDeltaEvent(text=text)
                        
                        elif delta_type == "input_json_delta":
                            # Tool input chunk
                            current_tool_input += delta.partial_json
                        
                        elif delta_type == "thinking_delta":
                            # Extended thinking chunk - show Claude's reasoning
                            thinking_text = delta.thinking
                            accumulated_thinking += thinking_text
                            yield ThoughtDeltaEvent(text=thinking_text)
                        
                        elif delta_type == "signature_delta":
                            # Signature for thinking blocks (required for tool use in multi-turn)
                            current_thinking_signature = delta.signature
                    
                    elif event_type == "content_block_stop":
                        # Content block completed
                        if current_block_type == "text":
                            if accumulated_text:
                                response_content.append({
                                    "type": "text",
                                    "text": accumulated_text,
                                })
                        
                        elif current_block_type == "thinking":
                            # Thinking block completed - store for history with signature
                            # The signature is required when using tool use with extended thinking
                            if accumulated_thinking:
                                thinking_block = {
                                    "type": "thinking",
                                    "thinking": accumulated_thinking,
                                }
                                # Include signature if available (required for tool use)
                                if current_thinking_signature:
                                    thinking_block["signature"] = current_thinking_signature
                                response_content.append(thinking_block)
                                # Reset for potential next thinking block
                                accumulated_thinking = ""
                                current_thinking_signature = None
                        
                        elif current_block_type == "tool_use":
                            # Parse tool input
                            try:
                                args = json.loads(current_tool_input) if current_tool_input else {}
                            except json.JSONDecodeError:
                                args = {}
                            
                            # Create tool call event
                            event_obj = ToolCallEvent(
                                call_id=current_block_id or "",
                                name=current_tool_name or "",
                                args=args,
                            )
                            tool_calls.append(event_obj)
                            yield event_obj
                            
                            # Add to response content
                            response_content.append({
                                "type": "tool_use",
                                "id": current_block_id,
                                "name": current_tool_name,
                                "input": args,
                            })
                        
                        # Reset current block tracking
                        current_block_type = None
                        current_block_id = None
                        current_tool_name = None
                        current_tool_input = ""
                    
                    elif event_type == "message_delta":
                        # Message metadata update
                        if hasattr(event, "usage") and event.usage:
                            usage = {
                                "output_tokens": event.usage.output_tokens,
                            }
                    
                    elif event_type == "message_start":
                        # Message starting - can get input token usage
                        if hasattr(event, "message") and hasattr(event.message, "usage"):
                            msg_usage = event.message.usage
                            usage = {
                                "input_tokens": getattr(msg_usage, "input_tokens", 0),
                                "output_tokens": 0,
                            }
                    
                    elif event_type == "message_stop":
                        # Message completed
                        pass
        
        except Exception as e:
            yield ErrorEvent(error=str(e), recoverable=False, raw_error=e)
            return
        
        # Add assistant message to conversation state
        if response_content:
            self._messages.append({
                "role": "assistant",
                "content": response_content,
            })
        
        # Yield final event if no tool calls
        if not tool_calls:
            yield FinalEvent(
                text=accumulated_text if accumulated_text.strip() else None,
                usage=usage,
            )
    
    def stream_user_turn(self, user_message: str) -> Iterator[LLMEvent]:
        """Send a user message and stream events."""
        # Add user message
        self._messages.append({
            "role": "user",
            "content": user_message,
        })
        
        yield from self._stream_response()
    
    def stream_tool_results(self, tool_outputs: list[ToolOutput]) -> Iterator[LLMEvent]:
        """Send tool results and stream the model's response."""
        # Build tool result content blocks
        tool_results = []
        for output in tool_outputs:
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": output.call_id,
                "content": json.dumps(output.result),
            })
        
        # Add as user message with tool results
        self._messages.append({
            "role": "user",
            "content": tool_results,
        })
        
        yield from self._stream_response()
    
    def reset(self) -> None:
        """Clear conversation history."""
        self._messages = []
