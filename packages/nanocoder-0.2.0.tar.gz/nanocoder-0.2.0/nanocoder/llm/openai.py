"""
OpenAI adapter using the Responses API.

Implements the LLMSession protocol for OpenAI models,
using the items-based Responses API for tool calling and streaming.
"""

import os
import json
from typing import Iterator, Any

from openai import OpenAI

from .base import (
    LLMSession,
    LLMEvent,
    TextDeltaEvent,
    ThoughtDeltaEvent,
    ToolCallEvent,
    FinalEvent,
    ErrorEvent,
    ToolOutput,
)
from ..agent.tools import ToolSpec, get_current_working_dir


# Default system instruction template
SYSTEM_INSTRUCTION_TEMPLATE = """You are an expert coding assistant with filesystem and shell access.

WORKFLOW:
- Read files before editing to understand context
- For complex logic, write a Python script instead of chaining bash commands

RESPONSES:
- Always provide a brief summary after completing tasks
- Explain what you did and the outcome

Current directory: {cwd}"""


class OpenAISession(LLMSession):
    """LLMSession implementation for OpenAI using Responses API.
    
    Maintains native OpenAI conversation state (list of items) and
    converts streaming SSE events to unified events.
    
    Supports reasoning/thinking features for compatible models via
    the reasoning parameter with effort and summary settings.
    """
    
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gpt-5.1-codex",
        reasoning_effort: str = "high",
        reasoning_summary: str = "detailed",
    ):
        """Initialize OpenAI session.
        
        Args:
            api_key: OpenAI API key (or from OPENAI_API_KEY env var)
            model: Model identifier
            reasoning_effort: Reasoning effort level (low, medium, high)
            reasoning_summary: Reasoning summary mode (auto, detailed)
        """
        api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable not set")
        
        self.client = OpenAI(api_key=api_key)
        self._model = model
        self._reasoning_effort = reasoning_effort
        self._reasoning_summary = reasoning_summary
        
        # Native conversation state (items for Responses API)
        self._items: list[dict] = []
        
        # Tool configuration
        self._tools: list[ToolSpec] = []
        self._openai_tools: list[dict] = []
        
        # Pending function calls (for matching results)
        self._pending_calls: dict[str, dict] = {}  # call_id -> {name, args}
    
    @property
    def provider(self) -> str:
        return "openai"
    
    @property
    def model(self) -> str:
        return self._model
    
    def set_tools(self, tools: list[ToolSpec]) -> None:
        """Configure tools for the session."""
        self._tools = tools
        self._openai_tools = [t.to_openai_tool() for t in tools]
    
    def _get_system_instruction(self) -> str:
        """Get the system instruction with current working directory."""
        cwd = get_current_working_dir()
        return SYSTEM_INSTRUCTION_TEMPLATE.format(cwd=cwd)
    
    def _build_input(self) -> list[dict]:
        """Build the input list for the Responses API."""
        input_list = []
        
        # Add system instruction as first message
        input_list.append({
            "type": "message",
            "role": "system",
            "content": self._get_system_instruction(),
        })
        
        # Add conversation items
        input_list.extend(self._items)
        
        return input_list
    
    def _stream_response(self) -> Iterator[LLMEvent]:
        """Stream from model and process events."""
        input_list = self._build_input()
        
        # Build request kwargs
        kwargs: dict[str, Any] = {
            "model": self._model,
            "input": input_list,
            "stream": True,
        }
        
        # Add tools if configured
        if self._openai_tools:
            kwargs["tools"] = self._openai_tools
        
        # Always add reasoning configuration for detailed thought summaries
        # This enables reasoning summaries on compatible models (o-series, GPT-5, etc.)
        kwargs["reasoning"] = {
            "effort": self._reasoning_effort,
            "summary": self._reasoning_summary,
        }
        
        try:
            stream = self.client.responses.create(**kwargs)
        except Exception as e:
            yield ErrorEvent(error=str(e), recoverable=False, raw_error=e)
            return
        
        # Accumulate text and track tool calls
        accumulated_text = ""
        accumulated_reasoning = ""
        tool_calls: list[ToolCallEvent] = []
        response_items: list[dict] = []
        usage = None
        
        # Track partial function calls being built
        partial_function_calls: dict[str, dict] = {}  # item_id -> partial data
        
        try:
            for event in stream:
                event_type = event.type
                
                # Handle different event types
                if event_type == "response.output_text.delta":
                    # Text chunk
                    delta_text = event.delta
                    accumulated_text += delta_text
                    yield TextDeltaEvent(text=delta_text)
                
                elif event_type == "response.reasoning_text.delta":
                    # Full reasoning text - the actual detailed chain of thought
                    # This is the detailed reasoning content (when available)
                    delta_text = event.delta
                    accumulated_reasoning += delta_text
                    yield ThoughtDeltaEvent(text=delta_text)
                
                elif event_type == "response.reasoning_text.done":
                    # Full reasoning text complete
                    pass
                
                elif event_type == "response.reasoning_summary_text.delta":
                    # Reasoning summary - condensed version of reasoning
                    delta_text = event.delta
                    accumulated_reasoning += delta_text
                    yield ThoughtDeltaEvent(text=delta_text)
                
                elif event_type == "response.reasoning_summary_text.done":
                    # Reasoning summary complete
                    pass
                
                elif event_type == "response.reasoning_summary_part.added":
                    # Structured reasoning summary part (non-streaming)
                    # Add newline before new parts for visual separation
                    part = getattr(event, "part", None)
                    if part:
                        part_type = getattr(part, "type", None)
                        if part_type == "summary_text":
                            text = getattr(part, "text", "")
                            if text:
                                # Add newline before new summary parts for readability
                                if accumulated_reasoning:
                                    accumulated_reasoning += "\n"
                                    yield ThoughtDeltaEvent(text="\n")
                                accumulated_reasoning += text
                                yield ThoughtDeltaEvent(text=text)
                
                elif event_type == "response.reasoning_summary_part.done":
                    # Structured reasoning summary part complete
                    pass
                
                elif event_type == "response.function_call_arguments.delta":
                    # Partial function call arguments
                    item_id = event.item_id
                    if item_id not in partial_function_calls:
                        partial_function_calls[item_id] = {"arguments": ""}
                    partial_function_calls[item_id]["arguments"] += event.delta
                
                elif event_type == "response.output_item.added":
                    # New output item added - item is an SDK object, use getattr
                    item = event.item
                    item_type = getattr(item, "type", None)
                    
                    if item_type == "function_call":
                        item_id = getattr(item, "id", "")
                        partial_function_calls[item_id] = {
                            "call_id": getattr(item, "call_id", item_id),
                            "name": getattr(item, "name", ""),
                            "arguments": "",
                        }
                
                elif event_type == "response.output_item.done":
                    # Output item completed - item is an SDK object
                    item = event.item
                    item_type = getattr(item, "type", None)
                    
                    if item_type == "function_call":
                        call_id = getattr(item, "call_id", None) or getattr(item, "id", "")
                        name = getattr(item, "name", "")
                        args_str = getattr(item, "arguments", "{}")
                        
                        try:
                            args = json.loads(args_str) if args_str else {}
                        except json.JSONDecodeError:
                            args = {}
                        
                        # Create tool call event
                        event_obj = ToolCallEvent(
                            call_id=call_id,
                            name=name,
                            args=args,
                        )
                        tool_calls.append(event_obj)
                        yield event_obj
                        
                        # Track for result matching
                        self._pending_calls[call_id] = {"name": name, "args": args}
                        
                        # Add to response items
                        response_items.append({
                            "type": "function_call",
                            "id": getattr(item, "id", ""),
                            "call_id": call_id,
                            "name": name,
                            "arguments": args_str,
                        })
                    
                    elif item_type == "message":
                        # Message item completed
                        content = getattr(item, "content", [])
                        text_content = ""
                        for block in content:
                            block_type = getattr(block, "type", None)
                            if block_type == "output_text":
                                text_content += getattr(block, "text", "")
                        
                        if text_content:
                            response_items.append({
                                "type": "message",
                                "role": "assistant",
                                "content": text_content,
                            })
                
                elif event_type == "response.done":
                    # Response completed
                    response = event.response
                    if hasattr(response, "usage") and response.usage:
                        usage = {
                            "input_tokens": response.usage.input_tokens,
                            "output_tokens": response.usage.output_tokens,
                        }
                        # Include reasoning tokens if available
                        if hasattr(response.usage, "reasoning_tokens"):
                            usage["reasoning_tokens"] = response.usage.reasoning_tokens
        
        except Exception as e:
            yield ErrorEvent(error=str(e), recoverable=False, raw_error=e)
            return
        
        # Add response items to conversation state
        self._items.extend(response_items)
        
        # Yield final event if no tool calls
        if not tool_calls:
            yield FinalEvent(
                text=accumulated_text if accumulated_text.strip() else None,
                usage=usage,
            )
    
    def stream_user_turn(self, user_message: str) -> Iterator[LLMEvent]:
        """Send a user message and stream events."""
        # Add user message to items
        self._items.append({
            "type": "message",
            "role": "user",
            "content": user_message,
        })
        
        yield from self._stream_response()
    
    def stream_tool_results(self, tool_outputs: list[ToolOutput]) -> Iterator[LLMEvent]:
        """Send tool results and stream the model's response."""
        # Add function call outputs to items
        for output in tool_outputs:
            self._items.append({
                "type": "function_call_output",
                "call_id": output.call_id,
                "output": json.dumps(output.result),
            })
        
        # Clear pending calls that were resolved
        for output in tool_outputs:
            self._pending_calls.pop(output.call_id, None)
        
        yield from self._stream_response()
    
    def reset(self) -> None:
        """Clear conversation history."""
        self._items = []
        self._pending_calls = {}
