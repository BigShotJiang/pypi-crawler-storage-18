"""
Base types and protocols for LLM provider adapters.

This module defines the unified streaming event model that all providers
must emit, and the LLMSession protocol that adapters must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterator, Any


class LLMEventType(Enum):
    """Types of events emitted by LLM sessions."""
    
    TEXT_DELTA = "text_delta"         # Incremental assistant-visible text
    THOUGHT_DELTA = "thought_delta"   # Incremental thought summary
    TOOL_CALL = "tool_call"           # Model requests a tool
    FINAL = "final"                   # Model indicates completion
    ERROR = "error"                   # Provider/parse/protocol error


@dataclass
class LLMEvent:
    """Base class for all LLM events."""
    
    # type is set by subclasses in __post_init__, excluded from __init__
    type: LLMEventType = field(init=False)


@dataclass
class TextDeltaEvent(LLMEvent):
    """Incremental assistant-visible text."""
    
    text: str
    
    def __post_init__(self):
        self.type = LLMEventType.TEXT_DELTA


@dataclass
class ThoughtDeltaEvent(LLMEvent):
    """Incremental thought summary (provider-safe)."""
    
    text: str
    
    def __post_init__(self):
        self.type = LLMEventType.THOUGHT_DELTA


@dataclass
class ToolCallEvent(LLMEvent):
    """Model requests a tool call."""
    
    call_id: str       # Unique ID for matching results
    name: str          # Tool function name
    args: dict         # Tool arguments
    
    def __post_init__(self):
        self.type = LLMEventType.TOOL_CALL


@dataclass
class FinalEvent(LLMEvent):
    """Model indicates completion."""
    
    text: str | None = None           # Final text if any
    finish_reason: str | None = None  # Provider-specific finish reason
    usage: dict | None = None         # Token usage statistics
    
    def __post_init__(self):
        self.type = LLMEventType.FINAL


@dataclass
class ErrorEvent(LLMEvent):
    """Provider error, parse error, or protocol violation."""
    
    error: str
    recoverable: bool = False
    raw_error: Any = None
    
    def __post_init__(self):
        self.type = LLMEventType.ERROR


@dataclass
class ToolOutput:
    """Result of executing a tool."""
    
    call_id: str       # Matches ToolCallEvent.call_id
    name: str          # Tool function name
    result: dict       # Tool execution result
    success: bool      # Whether execution succeeded
    elapsed_ms: float = 0.0  # Execution time


class LLMSession(ABC):
    """Protocol for LLM provider sessions.
    
    Each provider implements this interface, maintaining its own
    native conversation state. The unified event stream allows
    the agent loop to remain provider-agnostic.
    """
    
    @property
    @abstractmethod
    def provider(self) -> str:
        """Return provider name (gemini, openai, anthropic)."""
        ...
    
    @property
    @abstractmethod
    def model(self) -> str:
        """Return the model identifier."""
        ...
    
    @abstractmethod
    def stream_user_turn(self, user_message: str) -> Iterator[LLMEvent]:
        """Send a user message and stream events.
        
        Args:
            user_message: The user's message text
            
        Yields:
            LLMEvent instances representing the model's response
        """
        ...
    
    @abstractmethod
    def stream_tool_results(self, tool_outputs: list[ToolOutput]) -> Iterator[LLMEvent]:
        """Send tool results and stream the model's response.
        
        Args:
            tool_outputs: Results from tool execution
            
        Yields:
            LLMEvent instances representing the model's response
        """
        ...
    
    @abstractmethod
    def reset(self) -> None:
        """Clear conversation history to start fresh."""
        ...
    
    @abstractmethod
    def set_tools(self, tools: list[Any]) -> None:
        """Configure the tools available to the model.
        
        Args:
            tools: List of ToolSpec instances from agent.tools
        """
        ...
