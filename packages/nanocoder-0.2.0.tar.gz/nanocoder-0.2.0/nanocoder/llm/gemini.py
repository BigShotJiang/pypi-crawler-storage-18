"""
Gemini adapter using google.genai SDK.

Implements the LLMSession protocol for Google Gemini models,
with proper thought signature preservation and streaming support.
"""

import os
import uuid
from typing import Iterator, Any

from google import genai
from google.genai import types

from .base import (
    LLMSession,
    LLMEvent,
    TextDeltaEvent,
    ThoughtDeltaEvent,
    ToolCallEvent,
    FinalEvent,
    ErrorEvent,
    ToolOutput,
)
from ..agent.tools import ToolSpec, get_current_working_dir


# Default system instruction template
SYSTEM_INSTRUCTION_TEMPLATE = """You are an expert coding assistant with filesystem and shell access.

WORKFLOW:
- Read files before editing to understand context
- For complex logic, write a Python script instead of chaining bash commands

RESPONSES:
- Always provide a brief summary after completing tasks
- Explain what you did and the outcome

Current directory: {cwd}"""


class GeminiSession(LLMSession):
    """LLMSession implementation for Google Gemini.
    
    Maintains native Gemini conversation state (list[types.Content])
    and converts streaming parts to unified events.
    
    IMPORTANT: Preserves thought signatures by appending complete
    response Content objects to history.
    """
    
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gemini-3-pro-preview",
        thinking_level: str = "high",
        include_thoughts: bool = True,
    ):
        """Initialize Gemini session.
        
        Args:
            api_key: Gemini API key (or from GEMINI_API_KEY env var)
            model: Model identifier
            thinking_level: Thinking level (high, medium, low)
            include_thoughts: Whether to include thought summaries
        """
        api_key = api_key or os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable not set")
        
        self.client = genai.Client(api_key=api_key)
        self._model = model
        self._thinking_level = thinking_level
        self._include_thoughts = include_thoughts
        
        # Native conversation state
        self._conversation_history: list[types.Content] = []
        
        # Tool configuration (set via set_tools)
        self._tools: list[ToolSpec] = []
        self._tool_callables: list[Any] = []
        
        # Build config (updated when tools change)
        self._config: types.GenerateContentConfig | None = None
    
    @property
    def provider(self) -> str:
        return "gemini"
    
    @property
    def model(self) -> str:
        return self._model
    
    def set_tools(self, tools: list[ToolSpec]) -> None:
        """Configure tools for the session.
        
        For Gemini, we pass Python callables directly which the SDK
        converts to function declarations using type hints and docstrings.
        """
        self._tools = tools
        self._tool_callables = [t.callable for t in tools]
        self._rebuild_config()
    
    def _rebuild_config(self) -> None:
        """Rebuild the GenerateContentConfig."""
        cwd = get_current_working_dir()
        system_instruction = SYSTEM_INSTRUCTION_TEMPLATE.format(cwd=cwd)
        
        self._config = types.GenerateContentConfig(
            system_instruction=system_instruction,
            tools=self._tool_callables if self._tool_callables else None,
            automatic_function_calling=types.AutomaticFunctionCallingConfig(
                disable=True
            ),
            thinking_config=types.ThinkingConfig(
                thinking_level=self._thinking_level,
                include_thoughts=self._include_thoughts,
            ),
        )
    
    def _generate_call_id(self) -> str:
        """Generate a unique call ID for tool calls."""
        return f"gemini_{uuid.uuid4().hex[:8]}"
    
    def _stream_and_collect(self) -> Iterator[LLMEvent]:
        """Stream from model and collect response parts.
        
        Yields events while collecting all parts for history preservation.
        """
        if self._config is None:
            self._rebuild_config()
        
        try:
            response_stream = self.client.models.generate_content_stream(
                model=self._model,
                contents=self._conversation_history,
                config=self._config,
            )
        except Exception as e:
            yield ErrorEvent(error=str(e), recoverable=False, raw_error=e)
            return
        
        # Collect all parts for history (preserves thought signatures)
        all_response_parts: list[Any] = []
        accumulated_text = ""
        tool_calls: list[ToolCallEvent] = []
        finish_reason = None
        
        for chunk in response_stream:
            if not chunk.candidates:
                continue
            
            candidate = chunk.candidates[0]
            
            # Check finish reason
            if hasattr(candidate, "finish_reason") and candidate.finish_reason:
                finish_reason = str(candidate.finish_reason)
            
            if not candidate.content or not candidate.content.parts:
                continue
            
            for part in candidate.content.parts:
                # Preserve entire part for history
                all_response_parts.append(part)
                
                # Check for function calls
                if part.function_call:
                    fc = part.function_call
                    call_id = self._generate_call_id()
                    args = dict(fc.args) if fc.args else {}
                    
                    event = ToolCallEvent(
                        call_id=call_id,
                        name=fc.name,
                        args=args,
                    )
                    tool_calls.append(event)
                    yield event
                
                # Check for thoughts (must check before text)
                elif hasattr(part, "thought") and part.thought:
                    if part.text:
                        yield ThoughtDeltaEvent(text=part.text)
                
                # Check for text content
                elif part.text:
                    accumulated_text += part.text
                    yield TextDeltaEvent(text=part.text)
        
        # Add complete response to history (preserves thought signatures)
        if all_response_parts:
            complete_response = types.Content(role="model", parts=all_response_parts)
            self._conversation_history.append(complete_response)
        
        # Yield final event if no tool calls (otherwise loop continues)
        if not tool_calls:
            yield FinalEvent(
                text=accumulated_text if accumulated_text.strip() else None,
                finish_reason=finish_reason,
            )
    
    def stream_user_turn(self, user_message: str) -> Iterator[LLMEvent]:
        """Send a user message and stream events."""
        # Add user message to history
        self._conversation_history.append(
            types.Content(role="user", parts=[types.Part(text=user_message)])
        )
        
        yield from self._stream_and_collect()
    
    def stream_tool_results(self, tool_outputs: list[ToolOutput]) -> Iterator[LLMEvent]:
        """Send tool results and stream the model's response."""
        # Build function response parts
        response_parts = []
        for output in tool_outputs:
            part = types.Part.from_function_response(
                name=output.name,
                response={"result": output.result},
            )
            response_parts.append(part)
        
        # Add tool results to history as user turn
        self._conversation_history.append(
            types.Content(role="user", parts=response_parts)
        )
        
        yield from self._stream_and_collect()
    
    def reset(self) -> None:
        """Clear conversation history."""
        self._conversation_history = []

