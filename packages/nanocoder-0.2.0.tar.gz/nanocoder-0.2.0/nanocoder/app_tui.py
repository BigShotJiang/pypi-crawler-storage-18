"""
Textual TUI for the coding agent.

Provides a terminal user interface with streaming message display,
tool call widgets, and thought panel.
"""

import os
import re

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll, Vertical
from textual.widget import Widget
from textual.widgets import Header, Footer, Input, Static, Markdown
from textual.reactive import reactive
from textual.worker import Worker, WorkerState
from textual import work
from rich.markup import escape as rich_escape

from .agent.core import CodingAgent, create_agent, AgentResponse
from .agent.exec import ToolCall


# =============================================================================
# UI Widgets
# =============================================================================


class UserMessage(Widget):
    """A user message bubble."""

    DEFAULT_CSS = """
    UserMessage {
        background: #1a5f2a;
        color: #e8f5e9;
        padding: 0 1;
        margin: 1 2 0 8;
        border: round #2e7d32;
        height: auto;
    }
    """

    def __init__(self, message: str) -> None:
        super().__init__()
        self.message = message

    def compose(self) -> ComposeResult:
        yield Static(f"[bold]You[/bold]\n{rich_escape(self.message)}")


class AgentMessage(Markdown):
    """An agent message with markdown rendering."""

    DEFAULT_CSS = """
    AgentMessage {
        background: #1a237e;
        color: #e8eaf6;
        padding: 0 1;
        margin: 1 8 0 2;
        border: round #3949ab;
        height: auto;
    }
    
    AgentMessage MarkdownParagraph {
        margin: 0;
        padding: 0;
    }
    
    AgentMessage MarkdownH1 {
        margin: 0;
        padding: 0;
    }
    
    AgentMessage MarkdownH2 {
        margin: 0;
        padding: 0;
    }
    
    AgentMessage MarkdownH3 {
        margin: 0;
        padding: 0;
    }
    """

    BORDER_TITLE = "Agent"


class StreamingAgentMessage(Markdown):
    """A streaming agent message that updates as text arrives."""

    DEFAULT_CSS = """
    StreamingAgentMessage {
        background: #1a237e;
        color: #e8eaf6;
        padding: 0 1;
        margin: 1 8 0 2;
        border: round #3949ab;
        height: auto;
    }
    
    StreamingAgentMessage MarkdownParagraph {
        margin: 0;
        padding: 0;
    }
    
    StreamingAgentMessage MarkdownH1 {
        margin: 0;
        padding: 0;
    }
    
    StreamingAgentMessage MarkdownH2 {
        margin: 0;
        padding: 0;
    }
    
    StreamingAgentMessage MarkdownH3 {
        margin: 0;
        padding: 0;
    }
    """

    BORDER_TITLE = "Agent ✍️"

    def __init__(self) -> None:
        super().__init__("")
        self._accumulated_text = ""

    def append_text(self, text: str) -> None:
        """Append text to the streaming message."""
        self._accumulated_text += text
        self.update(self._accumulated_text.rstrip())

    def finalize(self) -> None:
        """Mark the message as complete."""
        self.border_title = "Agent"


class ThinkingIndicator(Widget):
    """A thinking/loading indicator."""

    DEFAULT_CSS = """
    ThinkingIndicator {
        background: #311b92;
        color: #d1c4e9;
        padding: 1 2;
        margin: 1 8 0 2;
        border: round #4527a0;
        text-style: italic;
        height: auto;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("[bold]🤔 Thinking...[/bold]")


class StreamingThoughtMessage(Static):
    """A streaming thought summary message that updates as thoughts arrive."""

    DEFAULT_CSS = """
    StreamingThoughtMessage {
        background: #4a148c;
        color: #e1bee7;
        padding: 0 1;
        margin: 1 8 0 2;
        border: round #7b1fa2;
        height: auto;
    }
    """

    BORDER_TITLE = "💭 Thoughts"

    def __init__(self) -> None:
        super().__init__("")
        self._accumulated_text = ""

    def append_text(self, text: str) -> None:
        """Append thought text to the streaming message."""
        self._accumulated_text += text
        display_text = self._convert_to_rich(self._accumulated_text.rstrip())
        self.update(display_text)

    def _convert_to_rich(self, text: str) -> str:
        """Convert markdown headers to Rich markup."""
        # Convert ## headers to bold
        text = re.sub(r"^## (.+)$", r"[bold]\1[/bold]", text, flags=re.MULTILINE)
        text = re.sub(r"^### (.+)$", r"[bold]\1[/bold]", text, flags=re.MULTILINE)
        # Convert **bold** to Rich bold
        text = re.sub(r"\*\*(.+?)\*\*", r"[bold]\1[/bold]", text)
        # Convert `code` to Rich markup
        text = re.sub(r"`([^`]+)`", r"[cyan]\1[/cyan]", text)
        return text

    def finalize(self) -> None:
        """Mark the thought summary as complete."""
        self.border_title = "💭 Thought Summary"


class StreamingToolCall(Static):
    """A widget that shows a tool call in progress or completed."""

    DEFAULT_CSS = """
    StreamingToolCall {
        background: #263238;
        color: #b0bec5;
        padding: 0 1;
        margin: 1 8 0 2;
        border: round #546e7a;
        height: auto;
    }
    
    StreamingToolCall.running {
        border: round #ff9800;
    }
    
    StreamingToolCall.success {
        border: round #4caf50;
    }
    
    StreamingToolCall.error {
        border: round #f44336;
    }
    """

    BORDER_TITLE = "Tool"

    def __init__(self, tool_call: ToolCall) -> None:
        super().__init__("")
        self.tool_call = tool_call
        self._update_display()
        self.add_class("running")

    def _update_display(self) -> None:
        """Update the display based on current tool call state."""
        tc = self.tool_call
        args_summary = (
            ", ".join(
                f"{k}={repr(v)[:25]}{'...' if len(repr(v)) > 25 else ''}"
                for k, v in tc.args.items()
            )
            if tc.args
            else ""
        )

        if tc.result is None:
            content = f"⏳ [bold]{tc.name}[/bold]({args_summary})"
        elif tc.success:
            result_preview = self._get_result_preview(tc.result)
            content = f"✓ [bold]{tc.name}[/bold]({args_summary}) {result_preview}"
        else:
            error = tc.result.get("error", "Unknown error")
            content = (
                f"✗ [bold]{tc.name}[/bold]({args_summary}) [red]{str(error)[:50]}[/red]"
            )

        self.update(content)

    def _get_result_preview(self, result: dict) -> str:
        """Get a short preview of the result."""
        if "content" in result:
            return f"({len(result.get('content', ''))} chars)"
        elif "stdout" in result:
            rc = result.get("return_code", 0)
            return "(ok)" if rc == 0 else f"(exit {rc})"
        elif "success" in result:
            return str(result.get("success", ""))[:40]
        elif "bytes_written" in result:
            return f"({result.get('bytes_written', 0)} bytes)"
        return "(ok)"

    def mark_complete(self, tool_call: ToolCall) -> None:
        """Mark the tool call as complete with result."""
        self.tool_call = tool_call
        self.remove_class("running")
        if tool_call.success:
            self.add_class("success")
        else:
            self.add_class("error")
        self._update_display()


class WelcomeMessage(Widget):
    """Welcome message displayed on startup."""

    DEFAULT_CSS = """
    WelcomeMessage {
        background: #0d47a1;
        color: #bbdefb;
        padding: 2 4;
        margin: 2 4;
        border: double #1976d2;
        text-align: center;
        height: auto;
    }
    """

    def __init__(self, provider: str = "Unknown", model: str = "Unknown") -> None:
        super().__init__()
        self._provider = provider
        self._model = model

    def compose(self) -> ComposeResult:
        cwd = rich_escape(os.getcwd())
        yield Static(
            f"""[bold white]🤖 Nanocoder - Multi-Provider Coding Agent[/bold white]

[dim]Provider: {self._provider} | Model: {self._model}[/dim]

[bold]Available Tools:[/bold]
  [cyan]read_file[/cyan]   - Read file contents (with line ranges)
  [cyan]edit_file[/cyan]   - Create or edit files (search & replace)
  [cyan]run_command[/cyan] - Execute shell commands (persistent cwd)

[bold]Working Directory:[/bold] [green]{cwd}[/green]

[dim]Type your request below and press Enter. Use Ctrl+C or /quit to exit.[/dim]"""
        )


# =============================================================================
# Main Application
# =============================================================================


class CodingAgentApp(App):
    """A Textual app for the coding agent."""

    TITLE = "Nanocoder"
    SUB_TITLE = "Multi-Provider Coding Agent"

    CSS = """
    Screen {
        background: #121212;
    }
    
    Header {
        background: #6200ea;
        color: white;
    }
    
    Footer {
        background: #1f1f1f;
    }
    
    #chat-container {
        height: 1fr;
        border: solid #333;
        background: #1e1e1e;
    }
    
    #input-container {
        height: auto;
        padding: 1;
        background: #1f1f1f;
        dock: bottom;
    }
    
    #user-input {
        background: #2d2d2d;
        color: #fff;
        border: tall #6200ea;
        padding: 0 1;
    }
    
    #user-input:focus {
        border: tall #bb86fc;
    }
    
    #status-bar {
        height: 1;
        background: #1f1f1f;
        color: #888;
        padding: 0 2;
        text-align: right;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True),
        Binding("ctrl+l", "clear", "Clear Chat", show=True),
        Binding("escape", "focus_input", "Focus Input", show=False),
    ]

    is_processing = reactive(False)

    def __init__(self):
        super().__init__()
        self.agent: CodingAgent | None = None
        self._tool_widgets: dict[str, StreamingToolCall] = {}
        self._streaming_message: StreamingAgentMessage | None = None
        self._streaming_thought: StreamingThoughtMessage | None = None
        self._last_stream_type: str | None = None
        self._auto_scroll_enabled: bool = True
        self._thinking_widget: ThinkingIndicator | None = None
        self._error_message: str | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll(id="chat-container"):
            # Welcome message will be mounted after agent initialization
            pass
        with Vertical(id="input-container"):
            yield Input(placeholder="Ask me anything about coding...", id="user-input")
            yield Static("Initializing...", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        """Initialize the agent when the app mounts."""
        chat = self.query_one("#chat-container")
        
        try:
            # Create agent with streaming callbacks
            self.agent = create_agent(
                on_tool_start=self._on_tool_start,
                on_tool_end=self._on_tool_end,
                on_text_chunk=self._on_text_chunk,
                on_thought_chunk=self._on_thought_chunk,
                on_iteration_start=self._on_iteration_start,
            )
            
            # Update title with provider info
            provider = self.agent.provider.capitalize()
            model = self.agent.model
            self.title = f"Nanocoder ({provider})"
            self.sub_title = model
            
            # Mount welcome message
            welcome = WelcomeMessage(provider=provider, model=model)
            chat.mount(welcome)
            
            self.query_one("#status-bar", Static).update(
                f"✓ Connected to {provider} ({model})"
            )
        except ValueError as e:
            self._error_message = str(e)
            # Mount error welcome
            welcome = WelcomeMessage(provider="Error", model=str(e)[:30])
            chat.mount(welcome)
            self.query_one("#status-bar", Static).update(f"✗ {rich_escape(str(e))}")

        self.query_one("#user-input", Input).focus()

    def _is_near_bottom(self, chat: VerticalScroll, threshold: int = 50) -> bool:
        """Check if the scroll position is near the bottom."""
        max_scroll = chat.max_scroll_y
        current_scroll = chat.scroll_y
        return current_scroll >= max_scroll - threshold

    def _auto_scroll(self) -> None:
        """Scroll to bottom if auto-scroll is enabled."""
        if self._auto_scroll_enabled:
            chat = self.query_one("#chat-container", VerticalScroll)
            chat.scroll_end(animate=False)

    def on_vertical_scroll_scroll_y(self, event) -> None:
        """Handle scroll events to detect user scrolling."""
        if not self.is_processing:
            return

        chat = self.query_one("#chat-container", VerticalScroll)

        if self._is_near_bottom(chat, threshold=100):
            self._auto_scroll_enabled = True
        else:
            self._auto_scroll_enabled = False

    def _on_tool_start(self, tool_call: ToolCall) -> None:
        """Called when a tool starts (from worker thread)."""
        self.call_from_thread(self._add_tool_widget, tool_call)

    def _on_tool_end(self, tool_call: ToolCall) -> None:
        """Called when a tool completes (from worker thread)."""
        self.call_from_thread(self._update_tool_widget, tool_call)

    def _on_text_chunk(self, text: str) -> None:
        """Called when a text chunk arrives (from worker thread)."""
        self.call_from_thread(self._append_text_chunk, text)

    def _on_thought_chunk(self, text: str) -> None:
        """Called when a thought chunk arrives (from worker thread)."""
        self.call_from_thread(self._append_thought_chunk, text)

    def _on_iteration_start(self, iteration: int) -> None:
        """Called at the start of each compositional iteration."""
        if iteration > 1:
            self.call_from_thread(self._clear_tool_widgets_dict)

    def _clear_tool_widgets_dict(self) -> None:
        """Clear the tool widgets dictionary between iterations."""
        self._tool_widgets.clear()

    def _add_tool_widget(self, tool_call: ToolCall) -> None:
        """Add a streaming tool call widget."""
        chat = self.query_one("#chat-container")

        # Finalize pending thought block
        if self._streaming_thought is not None:
            self._streaming_thought.finalize()
            self._streaming_thought = None

        # Remove thinking indicator
        if self._thinking_widget:
            self._thinking_widget.remove()
            self._thinking_widget = None

        widget = StreamingToolCall(tool_call)
        key = f"{tool_call.name}:{id(tool_call)}"
        self._tool_widgets[key] = widget

        chat.mount(widget)
        self.call_after_refresh(self._auto_scroll)
        self._last_stream_type = "tool"

    def _update_tool_widget(self, tool_call: ToolCall) -> None:
        """Update a tool call widget when complete."""
        key = f"{tool_call.name}:{id(tool_call)}"
        if key in self._tool_widgets:
            self._tool_widgets[key].mark_complete(tool_call)

    def _append_thought_chunk(self, text: str) -> None:
        """Append a thought chunk to the streaming thought message."""
        chat = self.query_one("#chat-container")

        if self._last_stream_type != "thought" and self._streaming_thought is not None:
            self._streaming_thought.finalize()
            self._streaming_thought = None

        if not self._streaming_thought:
            if self._thinking_widget:
                self._thinking_widget.remove()
                self._thinking_widget = None

            self._streaming_thought = StreamingThoughtMessage()
            chat.mount(self._streaming_thought)

        self._streaming_thought.append_text(text)
        self._last_stream_type = "thought"
        self.call_after_refresh(self._auto_scroll)

    def _append_text_chunk(self, text: str) -> None:
        """Append a text chunk to the streaming message."""
        chat = self.query_one("#chat-container")

        # Finalize pending thought block
        if self._streaming_thought is not None:
            self._streaming_thought.finalize()
            self._streaming_thought = None

        if not self._streaming_message:
            if self._thinking_widget:
                self._thinking_widget.remove()
                self._thinking_widget = None

            self._streaming_message = StreamingAgentMessage()
            chat.mount(self._streaming_message)

        self._streaming_message.append_text(text)
        self._last_stream_type = "text"
        self.call_after_refresh(self._auto_scroll)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle user input submission."""
        user_input = event.value.strip()
        if not user_input:
            return

        event.input.clear()

        # Handle commands
        if user_input.lower() == "/quit":
            self.exit()
            return

        if user_input.lower() == "/clear":
            await self.action_clear()
            return

        if user_input.lower() == "/help":
            await self._show_help()
            return

        if user_input.lower() == "/provider":
            await self._show_provider_info()
            return

        if user_input.lower() == "/trace":
            await self._show_trace_info()
            return

        if not self.agent:
            self.notify("Agent not initialized. Check your API key.", severity="error")
            return

        if self.is_processing:
            self.notify(
                "Please wait for the current request to complete.", severity="warning"
            )
            return

        # Clear tracking state
        self._tool_widgets.clear()
        self._streaming_message = None
        self._streaming_thought = None
        self._last_stream_type = None
        self._auto_scroll_enabled = True

        # Add user message to chat
        chat = self.query_one("#chat-container")
        user_msg = UserMessage(user_input)
        await chat.mount(user_msg)

        # Show thinking indicator
        self.is_processing = True
        self.query_one("#status-bar", Static).update("⏳ Processing...")
        self._thinking_widget = ThinkingIndicator()
        await chat.mount(self._thinking_widget)

        chat.scroll_end(animate=False)

        # Start the worker
        self._call_agent(user_input)

    @work(thread=True)
    def _call_agent(self, user_input: str) -> AgentResponse:
        """Call the agent in a background thread."""
        return self.agent.chat(user_input)

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle worker state changes."""
        if event.state == WorkerState.SUCCESS:
            self.call_later(self._show_response, event.worker.result)
        elif event.state == WorkerState.ERROR:
            self.call_later(self._show_error, str(event.worker.error))

    async def _show_response(self, response: AgentResponse) -> None:
        """Show the agent's response."""
        chat = self.query_one("#chat-container")

        # Remove thinking indicator
        if self._thinking_widget:
            await self._thinking_widget.remove()
            self._thinking_widget = None

        # Finalize streaming thought
        if self._streaming_thought:
            self._streaming_thought.finalize()
            self._streaming_thought = None

        # Finalize streaming message
        if self._streaming_message:
            self._streaming_message.finalize()
            self._streaming_message = None
        else:
            # Fallback if streaming didn't happen
            agent_msg = AgentMessage(response.text)
            await chat.mount(agent_msg)

        chat.scroll_end(animate=False)
        self._last_stream_type = None

        self.query_one("#status-bar", Static).update("✓ Ready")
        self.is_processing = False

    async def _show_error(self, error: str) -> None:
        """Show an error message."""
        chat = self.query_one("#chat-container")

        if self._thinking_widget:
            await self._thinking_widget.remove()
            self._thinking_widget = None

        if self._streaming_thought:
            await self._streaming_thought.remove()
            self._streaming_thought = None

        if self._streaming_message:
            await self._streaming_message.remove()
            self._streaming_message = None

        error_widget = Static(f"[bold red]Error: {rich_escape(error)}[/bold red]")
        await chat.mount(error_widget)
        chat.scroll_end(animate=False)

        self._last_stream_type = None

        self.query_one("#status-bar", Static).update(f"✗ Error: {rich_escape(error)}")
        self.is_processing = False

    async def _show_help(self) -> None:
        """Show help information."""
        chat = self.query_one("#chat-container")
        help_text = """## Available Commands

- `/quit` - Exit the application
- `/clear` - Clear chat history
- `/help` - Show this help message
- `/provider` - Show current provider and model
- `/trace` - Show trace file path

## Available Tools

The agent can use these tools to help you:

| Tool | Description |
|------|-------------|
| `read_file` | Read contents of any file (supports line ranges) |
| `edit_file` | Create or edit files (search & replace) |
| `run_command` | Execute shell commands (persistent cwd) |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `NANOCODER_PROVIDER` | Provider (gemini, openai, anthropic) |
| `NANOCODER_MODEL` | Model identifier |
| `NANOCODER_SHOW_THOUGHTS` | Show thought panel (0/1) |

## Tips

- Be specific about what you want to accomplish
- The agent will read files before making changes
- You can ask it to run tests or lint your code
"""
        help_widget = AgentMessage(help_text)
        await chat.mount(help_widget)
        chat.scroll_end(animate=False)

    async def _show_provider_info(self) -> None:
        """Show current provider information."""
        chat = self.query_one("#chat-container")
        if self.agent:
            info = f"""## Current Provider

**Provider:** {self.agent.provider}
**Model:** {self.agent.model}
**Trace Path:** `{self.agent.trace_path}`
"""
        else:
            info = "Agent not initialized."
        
        info_widget = AgentMessage(info)
        await chat.mount(info_widget)
        chat.scroll_end(animate=False)

    async def _show_trace_info(self) -> None:
        """Show trace file information."""
        chat = self.query_one("#chat-container")
        if self.agent:
            info = f"**Trace file:** `{self.agent.trace_path}`"
        else:
            info = "Agent not initialized."
        
        info_widget = AgentMessage(info)
        await chat.mount(info_widget)
        chat.scroll_end(animate=False)

    async def action_clear(self) -> None:
        """Clear the chat history."""
        chat = self.query_one("#chat-container")
        await chat.remove_children()
        
        if self.agent:
            provider = self.agent.provider.capitalize()
            model = self.agent.model
            welcome = WelcomeMessage(provider=provider, model=model)
            self.agent.reset()
        else:
            welcome = WelcomeMessage()
        
        await chat.mount(welcome)
        self.notify("Chat history cleared", severity="information")

    def action_focus_input(self) -> None:
        """Focus the input field."""
        self.query_one("#user-input", Input).focus()

    def action_quit(self) -> None:
        """Quit the application."""
        self.exit()

