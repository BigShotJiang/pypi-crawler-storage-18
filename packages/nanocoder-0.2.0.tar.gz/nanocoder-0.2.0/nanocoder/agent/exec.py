"""
Tool execution with parallelism and callbacks.

Handles executing tool calls from the model, with support for:
- Parallel execution of independent calls via ThreadPoolExecutor
- Order preservation for results
- Callbacks for UI updates
"""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable

from .tools import TOOL_REGISTRY
from ..llm.base import ToolOutput


@dataclass
class ToolCall:
    """Represents a tool call made by the agent (for UI display)."""
    
    call_id: str
    name: str
    args: dict
    result: dict | None = None
    success: bool | None = None
    elapsed_ms: float = 0.0


class ToolExecutor:
    """Executes tool calls with parallelism and callbacks.
    
    Provides thread-safe execution of multiple tool calls with:
    - Parallel execution for I/O-bound operations
    - Order preservation for results
    - Optional callbacks for progress updates
    """
    
    def __init__(
        self,
        max_workers: int = 10,
        on_tool_start: Callable[[ToolCall], None] | None = None,
        on_tool_end: Callable[[ToolCall], None] | None = None,
    ):
        """Initialize the tool executor.
        
        Args:
            max_workers: Maximum number of concurrent tool executions
            on_tool_start: Callback when a tool starts executing
            on_tool_end: Callback when a tool finishes executing
        """
        self.max_workers = max_workers
        self.on_tool_start = on_tool_start
        self.on_tool_end = on_tool_end
        self._tool_calls: dict[str, ToolCall] = {}  # Track by call_id
    
    def execute_tool(self, name: str, args: dict) -> tuple[dict, bool]:
        """Execute a single tool and return result.
        
        Args:
            name: Tool function name
            args: Tool arguments
            
        Returns:
            Tuple of (result_dict, success_bool)
        """
        if name not in TOOL_REGISTRY:
            return {"error": f"Unknown function: {name}"}, False
        
        tool_spec = TOOL_REGISTRY[name]
        try:
            result = tool_spec.callable(**args)
            success = "error" not in result
            return result, success
        except Exception as e:
            return {"error": f"Tool execution error: {str(e)}"}, False
    
    def _execute_single_with_callbacks(
        self, call_id: str, name: str, args: dict, index: int
    ) -> tuple[int, ToolOutput]:
        """Execute a single tool with callbacks and timing.
        
        Args:
            call_id: Unique call identifier
            name: Tool function name
            args: Tool arguments
            index: Original position for order preservation
            
        Returns:
            Tuple of (index, ToolOutput)
        """
        # Create and track tool call
        tool_call = ToolCall(call_id=call_id, name=name, args=args)
        self._tool_calls[call_id] = tool_call
        
        # Notify start
        if self.on_tool_start:
            self.on_tool_start(tool_call)
        
        # Execute with timing
        start_time = time.perf_counter()
        result, success = self.execute_tool(name, args)
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        
        # Update tool call
        tool_call.result = result
        tool_call.success = success
        tool_call.elapsed_ms = elapsed_ms
        
        # Notify completion
        if self.on_tool_end:
            self.on_tool_end(tool_call)
        
        # Create output
        output = ToolOutput(
            call_id=call_id,
            name=name,
            result=result,
            success=success,
            elapsed_ms=elapsed_ms,
        )
        
        return index, output
    
    def execute_parallel(
        self, calls: list[tuple[str, str, dict]]
    ) -> list[ToolOutput]:
        """Execute multiple tool calls in parallel while preserving order.
        
        Uses ThreadPoolExecutor for true parallel execution of I/O-bound
        operations. Results are returned in the same order as input.
        
        Args:
            calls: List of (call_id, name, args) tuples
            
        Returns:
            List of ToolOutput objects in same order as input
        """
        if not calls:
            return []
        
        # Clear previous call tracking
        self._tool_calls.clear()
        
        # Single call - no parallelism overhead
        if len(calls) == 1:
            call_id, name, args = calls[0]
            _, output = self._execute_single_with_callbacks(call_id, name, args, 0)
            return [output]
        
        # Multiple calls - execute in parallel
        max_workers = min(self.max_workers, len(calls))
        results_dict: dict[int, ToolOutput] = {}
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks with their index
            future_to_index = {
                executor.submit(
                    self._execute_single_with_callbacks,
                    call_id, name, args, idx
                ): idx
                for idx, (call_id, name, args) in enumerate(calls)
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_index):
                try:
                    index, output = future.result()
                    results_dict[index] = output
                except Exception as e:
                    # Catastrophic failure - create error output
                    index = future_to_index[future]
                    call_id, name, args = calls[index]
                    results_dict[index] = ToolOutput(
                        call_id=call_id,
                        name=name,
                        result={"error": f"Tool execution failed: {str(e)}"},
                        success=False,
                    )
        
        # Return results in original order
        return [results_dict[i] for i in range(len(calls))]
    
    def get_tool_call(self, call_id: str) -> ToolCall | None:
        """Get a tracked tool call by ID."""
        return self._tool_calls.get(call_id)

