"""
Provider-agnostic agent loop.

The CodingAgent class orchestrates the interaction between the user,
LLM session, and tool execution, remaining provider-agnostic through
the unified event model.
"""

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Iterator

from .tools import get_tool_specs, ToolSpec
from .exec import ToolExecutor, ToolCall
from ..llm.base import (
    LLMSession,
    LLMEvent,
    LLMEventType,
    TextDeltaEvent,
    ThoughtDeltaEvent,
    ToolCallEvent,
    FinalEvent,
    ErrorEvent,
    ToolOutput,
)
from ..tracing.logger import TrajectoryLogger
from ..tracing.schema import TraceMode


@dataclass
class AgentResponse:
    """Response from the agent."""
    
    text: str
    tool_calls_count: int = 0
    iterations: int = 1
    error: str | None = None


class CodingAgent:
    """Provider-agnostic coding agent.
    
    Orchestrates the agent loop:
    1. Stream model output
    2. Detect tool calls
    3. Execute tools (parallel)
    4. Send tool results back
    5. Iterate until final answer
    """
    
    def __init__(
        self,
        session: LLMSession,
        tools: list[ToolSpec] | None = None,
        max_tool_workers: int = 10,
        show_thoughts: bool = True,
        trace_dir: str = ".nanocoder_traces",
        trace_mode: TraceMode = TraceMode.CONTENT,
        on_tool_start: Callable[[ToolCall], None] | None = None,
        on_tool_end: Callable[[ToolCall], None] | None = None,
        on_text_chunk: Callable[[str], None] | None = None,
        on_thought_chunk: Callable[[str], None] | None = None,
        on_iteration_start: Callable[[int], None] | None = None,
    ):
        """Initialize the coding agent.
        
        Args:
            session: LLM session (provider adapter)
            tools: List of tool specifications (defaults to all registered tools)
            max_tool_workers: Maximum concurrent tool executions
            show_thoughts: Whether to emit thought events
            trace_dir: Directory for trace files
            trace_mode: Trace logging mode
            on_tool_start: Callback when tool starts
            on_tool_end: Callback when tool completes
            on_text_chunk: Callback for text deltas
            on_thought_chunk: Callback for thought deltas
            on_iteration_start: Callback at start of each iteration
        """
        self.session = session
        self.tools = tools or get_tool_specs()
        self.show_thoughts = show_thoughts
        
        # Configure session with tools
        self.session.set_tools(self.tools)
        
        # Tool executor with callbacks
        self._executor = ToolExecutor(
            max_workers=max_tool_workers,
            on_tool_start=on_tool_start,
            on_tool_end=on_tool_end,
        )
        
        # Callbacks for streaming
        self.on_text_chunk = on_text_chunk
        self.on_thought_chunk = on_thought_chunk
        self.on_iteration_start = on_iteration_start
        
        # Trajectory logger
        self._logger = TrajectoryLogger(
            trace_dir=trace_dir,
            mode=trace_mode,
            provider=session.provider,
            model=session.model,
        )
        
        # Log run start with machine metadata
        self._logger.log_run_start()
        
        # State
        self._turn_count = 0
        self._total_tool_calls = 0
    
    @property
    def provider(self) -> str:
        """Get the provider name."""
        return self.session.provider
    
    @property
    def model(self) -> str:
        """Get the model name."""
        return self.session.model
    
    @property
    def trace_path(self) -> str:
        """Get the trace file path."""
        return str(self._logger.trace_path)
    
    def _process_events(
        self, events: Iterator[LLMEvent]
    ) -> tuple[str, str, list[ToolCallEvent], dict | None, str | None]:
        """Process events from the session, yielding callbacks.
        
        Returns:
            Tuple of (accumulated_text, accumulated_reasoning, tool_calls, usage, error)
        """
        accumulated_text = ""
        accumulated_reasoning = ""
        tool_calls: list[ToolCallEvent] = []
        usage: dict | None = None
        error = None
        
        for event in events:
            if event.type == LLMEventType.TEXT_DELTA:
                assert isinstance(event, TextDeltaEvent)
                accumulated_text += event.text
                if self.on_text_chunk:
                    self.on_text_chunk(event.text)
            
            elif event.type == LLMEventType.THOUGHT_DELTA:
                assert isinstance(event, ThoughtDeltaEvent)
                accumulated_reasoning += event.text
                if self.show_thoughts and self.on_thought_chunk:
                    self.on_thought_chunk(event.text)
            
            elif event.type == LLMEventType.TOOL_CALL:
                assert isinstance(event, ToolCallEvent)
                tool_calls.append(event)
            
            elif event.type == LLMEventType.FINAL:
                assert isinstance(event, FinalEvent)
                if event.text and not accumulated_text.strip():
                    accumulated_text = event.text
                if event.usage:
                    usage = event.usage
            
            elif event.type == LLMEventType.ERROR:
                assert isinstance(event, ErrorEvent)
                error = event.error
                self._logger.log_error(
                    error=error,
                    error_type=type(event.raw_error).__name__ if event.raw_error else None,
                    recoverable=event.recoverable,
                )
                if not event.recoverable:
                    break
        
        return accumulated_text, accumulated_reasoning, tool_calls, usage, error
    
    def _execute_tool_calls(
        self, tool_calls: list[ToolCallEvent]
    ) -> list[ToolOutput]:
        """Execute tool calls and return outputs."""
        # Build call tuples for executor
        calls = [
            (tc.call_id, tc.name, tc.args)
            for tc in tool_calls
        ]
        
        # Log tool starts
        for tc in tool_calls:
            self._logger.log_tool_start(
                call_id=tc.call_id,
                name=tc.name,
                args=tc.args,
            )
        
        # Execute in parallel
        outputs = self._executor.execute_parallel(calls)
        
        # Log tool ends
        for output in outputs:
            self._logger.log_tool_end(
                call_id=output.call_id,
                name=output.name,
                success=output.success,
                result=output.result,
                elapsed_ms=output.elapsed_ms,
            )
            self._total_tool_calls += 1
        
        return outputs
    
    def chat(self, user_message: str) -> AgentResponse:
        """Send a message and get a response, handling tool calls.
        
        Implements the agent loop:
        1. Stream model output
        2. Collect tool calls
        3. Execute tools (parallel)
        4. Send results back
        5. Repeat until final answer
        
        Args:
            user_message: The user's message
            
        Returns:
            AgentResponse with final text and metadata
        """
        self._turn_count += 1
        iteration = 0
        
        # Log turn start
        self._logger.log_turn_start(
            turn=self._turn_count,
            user_message=user_message,
        )
        
        # Log model request
        tool_names = [t.name for t in self.tools]
        self._logger.log_model_request(
            turn=self._turn_count,
            tool_names=tool_names,
        )
        
        # Start with user turn
        events = self.session.stream_user_turn(user_message)
        
        while True:
            iteration += 1
            
            # Notify iteration start
            if self.on_iteration_start:
                self.on_iteration_start(iteration)
            
            # Track timing for model response (ISO timestamps for replay)
            start_ts = datetime.now(timezone.utc).isoformat()
            
            # Process events
            accumulated_text, accumulated_reasoning, tool_calls, usage, error = self._process_events(events)
            
            # Record end time
            end_ts = datetime.now(timezone.utc).isoformat()
            
            # Handle error
            if error:
                return AgentResponse(
                    text=accumulated_text or f"Error: {error}",
                    tool_calls_count=self._total_tool_calls,
                    iterations=iteration,
                    error=error,
                )
            
            # If no tool calls, we're done
            if not tool_calls:
                # Log model response with full content and timing
                self._logger.log_model_response(
                    turn=self._turn_count,
                    text=accumulated_text,
                    reasoning=accumulated_reasoning if accumulated_reasoning else None,
                    tool_calls=[],
                    usage=usage,
                    start_ts=start_ts,
                    end_ts=end_ts,
                )
                
                return AgentResponse(
                    text=accumulated_text,
                    tool_calls_count=self._total_tool_calls,
                    iterations=iteration,
                )
            
            # Log model response with tool calls, content, and timing
            self._logger.log_model_response(
                turn=self._turn_count,
                text=accumulated_text,
                reasoning=accumulated_reasoning if accumulated_reasoning else None,
                tool_calls=[
                    {"call_id": tc.call_id, "name": tc.name, "args": tc.args}
                    for tc in tool_calls
                ],
                usage=usage,
                start_ts=start_ts,
                end_ts=end_ts,
            )
            
            # Execute tool calls
            tool_outputs = self._execute_tool_calls(tool_calls)
            
            # Send results back and continue loop
            events = self.session.stream_tool_results(tool_outputs)
    
    def reset(self) -> None:
        """Clear conversation history."""
        self.session.reset()
        self._turn_count = 0
        self._total_tool_calls = 0
        
        # Start new trace
        self._logger = TrajectoryLogger(
            trace_dir=self._logger.trace_dir,
            mode=self._logger.mode,
            provider=self.session.provider,
            model=self.session.model,
        )


def create_session(
    provider: str,
    model: str | None = None,
    **kwargs,
) -> LLMSession:
    """Factory function to create an LLM session.
    
    Args:
        provider: Provider name (gemini, openai, anthropic)
        model: Model identifier (uses default if None)
        **kwargs: Additional provider-specific arguments
        
    Returns:
        Configured LLMSession
    """
    provider = provider.lower()
    
    if provider == "gemini":
        from ..llm.gemini import GeminiSession
        return GeminiSession(
            model=model or "gemini-3-pro-preview",
            **kwargs,
        )
    
    elif provider == "openai":
        from ..llm.openai import OpenAISession
        return OpenAISession(
            model=model or "gpt-5.1-codex",
            **kwargs,
        )
    
    elif provider == "anthropic":
        from ..llm.anthropic import AnthropicSession
        return AnthropicSession(
            model=model or "claude-opus-4-5-20251101",
            **kwargs,
        )
    
    else:
        raise ValueError(f"Unknown provider: {provider}")


def create_agent(
    provider: str | None = None,
    model: str | None = None,
    **kwargs,
) -> CodingAgent:
    """Factory function to create a CodingAgent.
    
    Reads configuration from environment variables:
    - NANOCODER_PROVIDER: Provider name (default: gemini)
    - NANOCODER_MODEL: Model identifier
    - NANOCODER_SHOW_THOUGHTS: Whether to show thoughts (default: 1)
    - NANOCODER_TRACE_DIR: Trace directory (default: .nanocoder_traces)
    - NANOCODER_TRACE_MODE: Trace mode (default: content)
    - NANOCODER_MAX_TOOL_WORKERS: Max concurrent tools (default: 10)
    
    Args:
        provider: Override provider from env
        model: Override model from env
        **kwargs: Additional arguments passed to CodingAgent
        
    Returns:
        Configured CodingAgent
    """
    # Read from environment with defaults
    provider = provider or os.environ.get("NANOCODER_PROVIDER", "gemini")
    model = model or os.environ.get("NANOCODER_MODEL")
    show_thoughts = os.environ.get("NANOCODER_SHOW_THOUGHTS", "1") == "1"
    trace_dir = os.environ.get("NANOCODER_TRACE_DIR", ".nanocoder_traces")
    trace_mode_str = os.environ.get("NANOCODER_TRACE_MODE", "content")
    max_workers = int(os.environ.get("NANOCODER_MAX_TOOL_WORKERS", "10"))
    
    # Parse trace mode
    trace_mode = TraceMode(trace_mode_str)
    
    # Create session
    session = create_session(provider, model)
    
    # Create agent
    return CodingAgent(
        session=session,
        show_thoughts=show_thoughts,
        trace_dir=trace_dir,
        trace_mode=trace_mode,
        max_tool_workers=max_workers,
        **kwargs,
    )

