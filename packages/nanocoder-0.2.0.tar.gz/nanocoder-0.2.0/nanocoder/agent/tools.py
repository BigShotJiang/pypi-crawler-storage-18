"""
Tool definitions and registry for the coding agent.

Tools are defined once with JSON Schema specifications and used across
all providers. The schema is the authoritative source of truth.
"""

import os
import subprocess
import difflib
import threading
from pathlib import Path
from dataclasses import dataclass
from typing import Callable


@dataclass
class ToolSpec:
    """Specification for a tool available to the agent.
    
    The JSON schema is the authoritative source for parameter definitions.
    Provider adapters convert this to their native tool format.
    """
    
    name: str
    description: str
    parameters: dict  # JSON Schema for parameters
    callable: Callable[..., dict]
    
    def to_openai_tool(self) -> dict:
        """Convert to OpenAI function tool format."""
        return {
            "type": "function",
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }
    
    def to_anthropic_tool(self) -> dict:
        """Convert to Anthropic tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }


# =============================================================================
# Persistent Working Directory State
# =============================================================================

# Thread-safe working directory state
_cwd_lock = threading.Lock()
_current_working_dir = os.getcwd()


def get_current_working_dir() -> str:
    """Get the current persistent working directory (thread-safe)."""
    with _cwd_lock:
        return _current_working_dir


def set_current_working_dir(path: str) -> None:
    """Set the current persistent working directory (thread-safe)."""
    global _current_working_dir
    with _cwd_lock:
        _current_working_dir = path


# =============================================================================
# Tool Implementations
# =============================================================================


def read_file(
    path: str, line_start: int = 1, line_end: int | None = None, with_lines: bool = True
) -> dict:
    """Read file contents, optionally with line numbers or specific ranges.

    Use this to examine existing code, configuration files, or any text file.
    Supports reading specific line ranges to save context on large files.

    Args:
        path: The file path to read. Can be relative or absolute.
              Supports ~ for home directory expansion.
        line_start: Start line (1-indexed, default 1).
        line_end: End line (optional, reads to end if None).
        with_lines: If True, adds line numbers (e.g., " 10 | print('hello')").

    Returns:
        A dictionary containing 'content' (file contents), 'path' (resolved path),
        'total_lines', and 'lines_shown' on success, or 'error' on failure.
    """
    try:
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists():
            return {"error": f"File not found: {path}"}
        if not file_path.is_file():
            return {"error": f"Not a file: {path}"}

        lines = file_path.read_text(encoding="utf-8").splitlines()

        # Handle ranges (1-indexed input)
        start_idx = max(0, line_start - 1)
        end_idx = line_end if line_end else len(lines)
        selected_lines = lines[start_idx:end_idx]

        if with_lines:
            # Format: " 10 | print('hello')"
            width = len(str(end_idx))
            output = []
            for i, line in enumerate(selected_lines):
                num = start_idx + i + 1
                output.append(f"{num:>{width}} | {line}")
            content = "\n".join(output)
        else:
            content = "\n".join(selected_lines)

        return {
            "content": content,
            "path": str(file_path),
            "total_lines": len(lines),
            "lines_shown": f"{start_idx + 1}-{end_idx}",
        }
    except Exception as e:
        return {"error": str(e)}


def edit_file(path: str, search_text: str, replace_text: str) -> dict:
    """Edit a file by replacing a unique block of text, or create a new file.

    This tool handles both editing existing files and creating new ones:
    - To EDIT: Provide search_text (exact text to find) and replace_text (new text)
    - To CREATE: Provide empty search_text ("") and the file content in replace_text

    IMPORTANT: The search_text must be unique in the file.

    Args:
        path: The path to the file to edit or create.
        search_text: The exact block of text to be replaced. Use empty string
                     ("") to create a new file.
        replace_text: The new text to insert in place of search_text.

    Returns:
        A dictionary with 'success', 'path', and 'bytes_written' on success,
        or 'error' on failure.
    """
    try:
        file_path = Path(path).expanduser().resolve()

        # Handle file creation (empty search_text = create new file)
        if search_text == "":
            if file_path.exists():
                return {
                    "error": f"File already exists: {path}. "
                    "Use search_text to edit existing files, or delete first."
                }
            # Create parent directories if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(replace_text, encoding="utf-8")
            return {
                "success": f"File created: {file_path}",
                "path": str(file_path),
                "bytes_written": len(replace_text),
            }

        # Handle file editing
        if not file_path.exists():
            return {
                "error": f"File not found: {path}. Use empty search_text to create new files."
            }

        # Read content
        content = file_path.read_text(encoding="utf-8")

        # Validate uniqueness
        count = content.count(search_text)
        if count == 0:
            # Check if it's just a whitespace issue
            normalized_search = "".join(search_text.split())
            normalized_content = "".join(content.split())

            if normalized_search in normalized_content:
                return {
                    "error": "search_text not found, but similar content exists (whitespace mismatch). "
                    "Please re-read the file and copy the EXACT text including indentation."
                }

            # Try fuzzy matching for helpful suggestions
            if len(search_text.strip()) >= 20:
                lines = content.splitlines()
                search_lines = search_text.strip().splitlines()

                if search_lines:
                    best_ratio = 0
                    best_match = None
                    search_block = "\n".join(search_lines)

                    n_lines = len(search_lines)
                    if len(lines) >= n_lines:
                        for i in range(len(lines) - n_lines + 1):
                            window = "\n".join(lines[i : i + n_lines])
                            ratio = difflib.SequenceMatcher(
                                None, search_block, window
                            ).ratio()
                            if ratio > best_ratio:
                                best_ratio = ratio
                                best_match = (i, window)

                    threshold = 0.95 if len(search_block) < 50 else 0.90

                    if best_ratio > threshold and best_match:
                        line_num, match_content = best_match
                        return {
                            "error": f"search_text not found. Did you mean this block at line {line_num + 1}?\n"
                            f"Similarity: {best_ratio:.0%}\n"
                            f"Actual content:\n{match_content}\n\n"
                            "Please use the EXACT content above for search_text."
                        }

            return {
                "error": "search_text not found in file. "
                "Please ensure you copied the text exactly, including whitespace and indentation."
            }
        if count > 1:
            return {
                "error": f"search_text found {count} times. "
                "Please include more surrounding context to make the search block unique."
            }

        # Perform replacement
        new_content = content.replace(search_text, replace_text)
        file_path.write_text(new_content, encoding="utf-8")

        return {
            "success": True,
            "path": str(file_path),
            "bytes_written": len(new_content),
        }
    except Exception as e:
        return {"error": f"System Error: {str(e)}"}


# Dangerous command patterns to block
DANGEROUS_PATTERNS = [
    "rm -rf /",
    "dd if=",
    "mkfs",
    "> /dev/",
    "chmod 777",
    "wget http",
    "curl http",
    "sudo",
    "su ",
    "eval",
    "exec(",
    "format",
    ":(){ :|:& };:",  # Fork bomb
    "mv /*",
    "shred",
    "rmdir /",
    "del /f",
    "deltree",
]


def run_command(command: str, timeout: int = 30) -> dict:
    """Execute a shell command and return its output.

    Use this to run scripts, install packages, run tests, or perform git operations.
    Dangerous commands are automatically blocked for safety.

    The working directory persists across commands. Use 'cd <path>' to change
    directory, and subsequent commands will run in that directory.

    Args:
        command: The shell command to execute.
        timeout: Maximum execution time in seconds (1-300).

    Returns:
        A dictionary containing 'stdout', 'stderr', 'return_code', and 'cwd'
        on success, or 'error' (and optional 'security_warning', 'blocked_pattern')
        on failure.
    """
    try:
        # Security check for dangerous commands
        command_lower = command.lower()
        for pattern in DANGEROUS_PATTERNS:
            if pattern in command_lower:
                return {
                    "error": f"Potentially dangerous command blocked: contains '{pattern}'",
                    "security_warning": True,
                    "blocked_pattern": pattern,
                }

        # Validate timeout range
        if timeout < 1 or timeout > 300:
            return {"error": "Timeout must be between 1 and 300 seconds"}

        cwd = get_current_working_dir()
        
        # Handle 'cd' manually (shell builtin that doesn't persist)
        stripped_cmd = command.strip()
        if stripped_cmd == "cd" or stripped_cmd == "cd ~":
            new_cwd = str(Path.home())
            set_current_working_dir(new_cwd)
            return {
                "stdout": f"Changed directory to {new_cwd}",
                "stderr": "",
                "return_code": 0,
                "cwd": new_cwd,
            }
        elif stripped_cmd.startswith("cd "):
            target_dir = stripped_cmd[3:].strip()
            if target_dir.startswith("~"):
                new_path = Path(target_dir).expanduser().resolve()
            else:
                new_path = (Path(cwd) / target_dir).resolve()

            if new_path.is_dir():
                new_cwd = str(new_path)
                set_current_working_dir(new_cwd)
                return {
                    "stdout": f"Changed directory to {new_cwd}",
                    "stderr": "",
                    "return_code": 0,
                    "cwd": new_cwd,
                }
            else:
                return {
                    "stdout": "",
                    "stderr": f"cd: no such file or directory: {target_dir}",
                    "return_code": 1,
                    "cwd": cwd,
                }

        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
        )
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "return_code": result.returncode,
            "cwd": cwd,
        }
    except subprocess.TimeoutExpired:
        return {
            "error": f"Command timed out after {timeout} seconds",
            "cwd": get_current_working_dir(),
        }
    except Exception as e:
        return {"error": str(e), "cwd": get_current_working_dir()}


# =============================================================================
# Tool Registry
# =============================================================================

# JSON Schemas for tool parameters (authoritative source)
READ_FILE_SCHEMA = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "The file path to read. Can be relative or absolute. Supports ~ for home directory."
        },
        "line_start": {
            "type": "integer",
            "description": "Start line (1-indexed, default 1).",
            "default": 1
        },
        "line_end": {
            "type": "integer",
            "description": "End line (optional, reads to end if not specified)."
        },
        "with_lines": {
            "type": "boolean",
            "description": "If true, adds line numbers to output.",
            "default": True
        }
    },
    "required": ["path"]
}

EDIT_FILE_SCHEMA = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "The path to the file to edit or create."
        },
        "search_text": {
            "type": "string",
            "description": "The exact block of text to replace. Use empty string to create a new file."
        },
        "replace_text": {
            "type": "string",
            "description": "The new text to insert in place of search_text, or full content for new file."
        }
    },
    "required": ["path", "search_text", "replace_text"]
}

RUN_COMMAND_SCHEMA = {
    "type": "object",
    "properties": {
        "command": {
            "type": "string",
            "description": "The shell command to execute."
        },
        "timeout": {
            "type": "integer",
            "description": "Maximum execution time in seconds (1-300).",
            "default": 30
        }
    },
    "required": ["command"]
}


# Tool specifications
TOOL_REGISTRY: dict[str, ToolSpec] = {
    "read_file": ToolSpec(
        name="read_file",
        description="Read file contents, optionally with line numbers or specific ranges. "
                    "Use this to examine existing code, configuration files, or any text file.",
        parameters=READ_FILE_SCHEMA,
        callable=read_file,
    ),
    "edit_file": ToolSpec(
        name="edit_file",
        description="Edit a file by replacing a unique block of text, or create a new file. "
                    "To EDIT: provide search_text and replace_text. "
                    "To CREATE: provide empty search_text and file content in replace_text.",
        parameters=EDIT_FILE_SCHEMA,
        callable=edit_file,
    ),
    "run_command": ToolSpec(
        name="run_command",
        description="Execute a shell command and return its output. "
                    "Use for running scripts, tests, git operations, etc. "
                    "Working directory persists across commands.",
        parameters=RUN_COMMAND_SCHEMA,
        callable=run_command,
    ),
}


def get_tool_specs() -> list[ToolSpec]:
    """Get all registered tool specifications."""
    return list(TOOL_REGISTRY.values())

