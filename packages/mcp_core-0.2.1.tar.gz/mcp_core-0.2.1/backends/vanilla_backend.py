from openmcp.backends.base_provider import BaseProvider


class VanillaBackend(BaseProvider):

    def initialize(self, config):
        self._tool_functions = []

    def index_tools(self, tools):
        self._tool_functions = [tool.fn for tool in tools]

    def serve_tools(self):
        return self._tool_functions

