from setuptools import find_packages, setup

setup(
    name='aleph_blobstorage',
    version='0.1',
    packages=find_packages(),
)