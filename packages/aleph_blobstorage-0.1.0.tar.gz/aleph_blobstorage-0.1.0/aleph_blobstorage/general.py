import hashlib
import pathlib
import typing as T


def generate_content_hash(
    content: T.Union[pathlib.Path, bytes], *, hash_length: int = 15, prefix: str = ""
) -> str:
    """Generate SHA256 content hash (15 chars) for versioning"""
    hash_sha256 = hashlib.sha256()
    if isinstance(content, pathlib.Path):
        with open(content, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
    else:
        hash_sha256.update(content)
    return f"{prefix}{hash_sha256.hexdigest()[:hash_length]}"