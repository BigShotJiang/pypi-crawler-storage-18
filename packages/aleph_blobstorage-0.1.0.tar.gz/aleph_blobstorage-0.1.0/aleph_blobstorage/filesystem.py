import importlib
import pathlib


def get_folderpath_from_module(module_name: str) -> pathlib.Path:
    """
    Get the folder path from a module name.

    Args:
        module_name (str): The name of the module. e.g. "rl.infrastructure.storage.blobstorage"

    Returns:
        pathlib.Path: The folder path of the module.
    """
    path = None
    module = importlib.import_module(module_name)

    # Defensive - Check if module is a package
    try:
        path = pathlib.Path(module.__file__).parent
    except Exception as e:
        raise ValueError(f"Module {module_name} is not a package") from e

    return path