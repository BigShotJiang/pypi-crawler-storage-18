# How‑To: Serve HoloViz MCP Panel apps locally for exploration, learning, and validation.

## Local Usage

### Prerequisites

- Install the project following the [Installation Guide](../how-to/installation.md).

### Steps

1. Start the local Panel server:
	```bash
	uvx holoviz-mcp serve
	```
2. Open the URL printed in the terminal. This starts the bundled Panel apps.

## Online Demo

Try the hosted demo: [🤗 holoviz-mcp-ui](https://huggingface.co/spaces/awesome-panel/holoviz-mcp-ui)
