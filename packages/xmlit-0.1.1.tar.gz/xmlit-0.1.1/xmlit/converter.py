"""
Main XML to HTML Converter class with dynamic element processing
"""

import os
import xml.etree.ElementTree as ET
from pathlib import Path
from html import escape
from typing import Optional, Dict, List
import json

# PDF libraries will be imported lazily when needed
WEASYPRINT_AVAILABLE = None
PDFKIT_AVAILABLE = None

def _check_weasyprint():
    """Lazy check for weasyprint availability"""
    global WEASYPRINT_AVAILABLE
    if WEASYPRINT_AVAILABLE is None:
        try:
            from weasyprint import HTML, CSS
            WEASYPRINT_AVAILABLE = True
        except (ImportError, OSError):
            WEASYPRINT_AVAILABLE = False
    return WEASYPRINT_AVAILABLE

def _check_pdfkit():
    """Lazy check for pdfkit availability"""
    global PDFKIT_AVAILABLE
    if PDFKIT_AVAILABLE is None:
        try:
            import pdfkit
            PDFKIT_AVAILABLE = True
        except ImportError:
            PDFKIT_AVAILABLE = False
    return PDFKIT_AVAILABLE

from .element_processor import ElementProcessor, get_text, escape_html
from .config import ConverterConfig
from .processors import get_all_processors

# Import XMLConverter for backward compatibility and new plugin system
from .converter_v2 import XMLConverter


class XMLToHTMLConverter:
    """
    Flexible XML to HTML converter that dynamically handles various XML structures
    by analyzing the XML schema and generating appropriate HTML output.
    """
    
    HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        {css}
    </style>
</head>
<body>
    <div class="container">
        {back_link}
        <div class="header">
            <div class="law-title">{law_title}</div>
            <div class="law-meta">{law_meta}</div>
        </div>
        {enact_statement}
        {toc}
        {content}
    </div>
    {navigation}
</body>
</html>
"""
    
    def __init__(self, config: Optional[ConverterConfig] = None):
        """
        Initialize converter with configuration
        
        Args:
            config: ConverterConfig instance, or None for default config
        """
        self.config = config or ConverterConfig()
        self.processor = ElementProcessor(self.config)
        
        # Register default processors
        default_processors = get_all_processors()
        for element_name, processor_func in default_processors.items():
            self.processor.register_processor(element_name, processor_func)
        
        # Register custom processors from config
        for element_name, processor_func in self.config.element_processors.items():
            self.processor.register_processor(element_name, processor_func)
    
    def analyze_xml(self, xml_path: Path) -> Dict:
        """
        Analyze XML structure to understand its schema
        
        Args:
            xml_path: Path to XML file
            
        Returns:
            Dictionary with structure information
        """
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            return self.processor.analyze_xml_structure(root)
        except Exception as e:
            return {'error': str(e)}
    
    def convert_file(
        self,
        xml_path: Path,
        output_path: Optional[Path] = None,
        convert_to_pdf: Optional[bool] = None
    ) -> str:
        """
        Convert a single XML file to HTML
        
        Args:
            xml_path: Path to XML file
            output_path: Optional output path for HTML file
            convert_to_pdf: Whether to also convert to PDF (overrides config)
            
        Returns:
            HTML content as string
        """
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
        except ET.ParseError as e:
            return f"<html><body><h1>Error parsing XML</h1><p>{escape(str(e))}</p></body></html>"
        
        # Analyze structure (for future use)
        # structure = self.processor.analyze_xml_structure(root)
        
        # Extract law metadata
        law_attrs = root.attrib
        law_num = root.find('LawNum')
        law_title_elem = root.find('.//LawTitle')
        
        law_title = get_text(law_title_elem) if law_title_elem is not None else "法律"
        law_num_text = get_text(law_num) if law_num is not None else ""
        
        # Build law meta info
        meta_parts = []
        if law_attrs.get('Year'):
            era_map = {'Showa': '昭和', 'Heisei': '平成', 'Reiwa': '令和'}
            era = era_map.get(law_attrs.get('Era', ''), '')
            meta_parts.append(f"{era}{law_attrs.get('Year')}年")
        if law_attrs.get('PromulgateMonth') and law_attrs.get('PromulgateDay'):
            meta_parts.append(f"{law_attrs.get('PromulgateMonth')}月{law_attrs.get('PromulgateDay')}日")
        if law_attrs.get('LawType'):
            meta_parts.append(f"法律第{law_attrs.get('Num')}号")
        
        law_meta = " | ".join(meta_parts)
        if law_num_text:
            law_meta = f"{law_num_text} | {law_meta}"
        
        # Process EnactStatement
        enact_statement_elem = root.find('.//EnactStatement')
        enact_statement_html = ""
        if enact_statement_elem is not None:
            enact_text = get_text(enact_statement_elem)
            if enact_text:
                enact_statement_html = f'<div class="enact-statement" style="background: #fff3cd; padding: 20px; border-left: 4px solid #ffc107; margin: 20px 0; border-radius: 4px;"><p style="margin: 0; line-height: 1.8;">{escape_html(enact_text)}</p></div>'
        
        # Process TOC
        toc_html = ""
        if self.config.include_toc:
            toc_elem = root.find('.//TOC')
            if toc_elem is not None:
                toc_processor = self.processor.get_processor('TOC')
                toc_html = toc_processor(toc_elem, {})
        
        # Process main content
        main_provision = root.find('.//MainProvision')
        content_html = ""
        navigation_html = ""
        
        if main_provision is not None:
            context = {'processor': self.processor}
            content_html = self.processor.process_children(main_provision, context)
        
        # Process supplementary provisions
        law_body = root.find('.//LawBody')
        if law_body is not None:
            suppl_provisions = law_body.findall('SupplProvision')
            for suppl in suppl_provisions:
                suppl_processor = self.processor.get_processor('SupplProvision')
                content_html += suppl_processor(suppl, {})
            
            # Process AppdxTable
            for appdx_table in law_body.findall('AppdxTable'):
                appdx_processor = self.processor.get_processor('AppdxTable')
                content_html += appdx_processor(appdx_table, {})
        
        # Build navigation
        if self.config.include_navigation:
            navigation_items = self._extract_navigation_items(root)
            if navigation_items:
                navigation_html = f'''
                <div class="navigation">
                    <div style="font-weight: bold; margin-bottom: 10px; color: #2c3e50;">目次</div>
                    {"".join(navigation_items)}
                </div>
                '''
        
        back_link_html = ""
        if self.config.include_back_link:
            back_link_html = f'<a href="{self.config.back_link_url}" class="back-link">← Back to Index</a>'
        
        # Get CSS
        css = self._get_css()
        
        # Build final HTML
        final_html = self.HTML_TEMPLATE.format(
            title=escape_html(law_title),
            css=css,
            law_title=escape_html(law_title),
            law_meta=law_meta,
            enact_statement=enact_statement_html,
            toc=toc_html,
            content=content_html,
            navigation=navigation_html,
            back_link=back_link_html
        )
        
        # Write to file if output path provided
        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(final_html)
            
            # Convert to PDF if requested
            if convert_to_pdf is None:
                convert_to_pdf = self.config.convert_to_pdf
            
            if convert_to_pdf:
                pdf_path = output_path.with_suffix('.pdf')
                if self._html_to_pdf(output_path, pdf_path):
                    print(f"✅ PDF created: {pdf_path}")
                else:
                    print(f"❌ Failed to create PDF for {output_path.name}")
        
        return final_html
    
    def _extract_navigation_items(self, root: ET.Element) -> List[str]:
        """Extract navigation items from XML"""
        items = []
        
        main_provision = root.find('.//MainProvision')
        if main_provision is not None:
            for chapter in main_provision.findall('Chapter'):
                chapter_title = get_text(chapter.find('ChapterTitle'))
                chapter_num = chapter.get('Num', '')
                if chapter_title:
                    items.append(
                        f'<a href="#chapter-{chapter_num}" class="nav-link">{escape_html(chapter_title)}</a>'
                    )
            
            for article in main_provision.findall('Article'):
                article_title = get_text(article.find('ArticleTitle'))
                article_num = article.get('Num', '')
                if article_title:
                    items.append(
                        f'<a href="#article-{article_num}" class="nav-link">{escape_html(article_title)}</a>'
                    )
        
        return items
    
    def _get_css(self) -> str:
        """Get CSS styles"""
        if self.config.custom_css:
            return self.config.custom_css
        
        if self.config.css_file and self.config.css_file.exists():
            with open(self.config.css_file, 'r', encoding='utf-8') as f:
                return f.read()
        
        # Return default CSS
        return self._get_default_css()
    
    def _get_default_css(self) -> str:
        """Get default CSS styles"""
        return """
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Yu Gothic', 'Meiryo', sans-serif;
            line-height: 1.8;
            color: #333;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .header {
            border-bottom: 3px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .law-title {
            font-size: 2em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .law-meta {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 5px;
        }
        .toc {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 30px 0;
        }
        .toc-title {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        .toc-chapter {
            margin: 10px 0;
            padding-left: 20px;
        }
        .toc-section {
            margin: 5px 0;
            padding-left: 40px;
            color: #555;
        }
        .chapter {
            margin: 40px 0;
            border-top: 2px solid #e0e0e0;
            padding-top: 20px;
        }
        .chapter-title {
            font-size: 1.5em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .article {
            margin: 30px 0;
            padding: 20px;
            background: #fafafa;
            border-left: 4px solid #3498db;
            border-radius: 4px;
        }
        .article-title {
            font-size: 1.2em;
            font-weight: bold;
            color: #2980b9;
            margin-bottom: 10px;
        }
        .article-caption {
            font-size: 0.9em;
            color: #7f8c8d;
            margin-bottom: 5px;
            font-style: italic;
        }
        .paragraph {
            margin: 15px 0;
            padding-left: 20px;
        }
        .paragraph-num {
            font-weight: bold;
            color: #34495e;
            margin-right: 10px;
        }
        .sentence {
            margin: 10px 0;
            text-indent: 1em;
        }
        ruby {
            ruby-align: center;
        }
        rt {
            font-size: 0.7em;
            line-height: 1;
        }
        .item {
            margin: 10px 0;
            padding-left: 30px;
        }
        .item-title {
            font-weight: bold;
            color: #27ae60;
            margin-right: 10px;
        }
        .section {
            margin: 30px 0;
            padding-left: 20px;
        }
        .section-title {
            font-size: 1.3em;
            font-weight: bold;
            color: #8e44ad;
            margin-bottom: 15px;
        }
        .table-wrapper {
            margin: 20px 0;
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            vertical-align: top;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .navigation {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            max-width: 300px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .nav-link {
            display: block;
            padding: 5px 10px;
            color: #3498db;
            text-decoration: none;
            border-radius: 3px;
            margin: 2px 0;
        }
        .nav-link:hover {
            background: #ecf0f1;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-link:hover {
            background: #2980b9;
        }
        @media print {
            .navigation {
                display: none;
            }
            body {
                background: white;
                padding: 0;
            }
            .container {
                box-shadow: none;
                padding: 20px;
            }
        }
        @page {
            size: A4;
            margin: 2cm;
        }
        """
    
    def _html_to_pdf(self, html_path: Path, pdf_path: Path) -> bool:
        """Convert HTML to PDF"""
        try:
            if _check_weasyprint():
                from weasyprint import HTML
                HTML(filename=str(html_path)).write_pdf(str(pdf_path))
                return True
            elif _check_pdfkit():
                import pdfkit
                pdfkit.from_file(
                    str(html_path),
                    str(pdf_path),
                    options=self.config.pdf_options
                )
                return True
            else:
                print("⚠️  No PDF library available. Install weasyprint or pdfkit")
                return False
        except Exception as e:
            print(f"❌ Error converting to PDF: {e}")
            return False
    
    def convert_directory(
        self,
        input_dir: Path,
        output_dir: Optional[Path] = None,
        create_index: Optional[bool] = None
    ) -> Dict[str, str]:
        """
        Convert all XML files in a directory
        
        Args:
            input_dir: Directory containing XML files
            output_dir: Output directory (default: input_dir/html)
            create_index: Whether to create index page (default: from config)
            
        Returns:
            Dictionary mapping XML paths to HTML paths
        """
        if output_dir is None:
            output_dir = input_dir.parent / "html"
        
        if create_index is None:
            create_index = self.config.create_index
        
        output_dir.mkdir(parents=True, exist_ok=True)
        
        xml_files = list(input_dir.rglob("*.xml"))
        converted = {}
        
        print(f"Found {len(xml_files)} XML files")
        
        for xml_file in xml_files:
            rel_path = xml_file.relative_to(input_dir)
            html_path = output_dir / rel_path.with_suffix('.html')
            
            try:
                self.convert_file(xml_file, html_path)
                converted[str(xml_file)] = str(html_path)
                print(f"✅ Converted: {xml_file.name} -> {html_path.name}")
            except Exception as e:
                print(f"❌ Error converting {xml_file.name}: {e}")
        
        if create_index:
            self._create_index_page(converted, output_dir)
        
        print(f"\n✅ Converted {len(converted)} files to HTML")
        return converted
    
    def _create_index_page(self, converted_files: Dict[str, str], output_dir: Path):
        """Create index page listing all converted files"""
        # Implementation for index page creation
        pass

