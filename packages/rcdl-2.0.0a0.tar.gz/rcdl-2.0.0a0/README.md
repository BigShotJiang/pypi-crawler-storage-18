# RCDL

Riton Coomer Download Manager

## Dependencies
```bash
pipx install yt-dlp
sudo apt install aria2 ffmpeg
```

## Dev Command
```bash
# activate venv and install package in editable mode
source .venv/bin/activate
pip install -e .

# build package wheel
python3 -m build
```

## Preset Comparison
`rcdl fuse` will fuse part videos into one. here is a comparison of the result depending on the preset:  
![plot](plot.png)
