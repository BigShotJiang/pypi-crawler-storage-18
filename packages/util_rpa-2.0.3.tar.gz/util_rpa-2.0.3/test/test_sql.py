"""Tests for SQL utilities."""
from util_rpa.sql.sqlserver import SQLServer


def test_sqlclient_init(monkeypatch):
    """Test SQLServer initialization with environment variables."""
    monkeypatch.setenv("SQL_HOST", "srv")
    monkeypatch.setenv("SQL_DATABASE", "db")
    monkeypatch.setenv("SQL_USER", "user")
    monkeypatch.setenv("SQL_PASSWORD", "pass")

    db = SQLServer(
        host="srv",
        database="db",
        user="user",
        password="pass"
    )
    assert db is not None
