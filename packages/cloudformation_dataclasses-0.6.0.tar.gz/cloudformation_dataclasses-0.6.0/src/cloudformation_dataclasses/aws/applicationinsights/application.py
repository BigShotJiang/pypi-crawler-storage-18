"""PropertyTypes for AWS::ApplicationInsights::Application."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar, Optional, Union

from cloudformation_dataclasses.core.base import PropertyType, Tag
from cloudformation_dataclasses.intrinsics.functions import GetAtt, Ref, Sub


@dataclass
class Alarm(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "alarm_name": "AlarmName",
        "severity": "Severity",
    }

    alarm_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    severity: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class AlarmMetric(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "alarm_metric_name": "AlarmMetricName",
    }

    alarm_metric_name: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class ComponentConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "sub_component_type_configurations": "SubComponentTypeConfigurations",
        "configuration_details": "ConfigurationDetails",
    }

    sub_component_type_configurations: Optional[list[SubComponentTypeConfiguration]] = None
    configuration_details: Optional[ConfigurationDetails] = None


@dataclass
class ComponentMonitoringSetting(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "custom_component_configuration": "CustomComponentConfiguration",
        "tier": "Tier",
        "component_configuration_mode": "ComponentConfigurationMode",
        "default_overwrite_component_configuration": "DefaultOverwriteComponentConfiguration",
        "component_name": "ComponentName",
        "component_arn": "ComponentARN",
    }

    custom_component_configuration: Optional[ComponentConfiguration] = None
    tier: Optional[Union[str, Ref, GetAtt, Sub]] = None
    component_configuration_mode: Optional[Union[str, Ref, GetAtt, Sub]] = None
    default_overwrite_component_configuration: Optional[ComponentConfiguration] = None
    component_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    component_arn: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class ConfigurationDetails(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "net_weaver_prometheus_exporter": "NetWeaverPrometheusExporter",
        "windows_events": "WindowsEvents",
        "alarm_metrics": "AlarmMetrics",
        "alarms": "Alarms",
        "sql_server_prometheus_exporter": "SQLServerPrometheusExporter",
        "ha_cluster_prometheus_exporter": "HAClusterPrometheusExporter",
        "hana_prometheus_exporter": "HANAPrometheusExporter",
        "logs": "Logs",
        "processes": "Processes",
        "jmx_prometheus_exporter": "JMXPrometheusExporter",
    }

    net_weaver_prometheus_exporter: Optional[NetWeaverPrometheusExporter] = None
    windows_events: Optional[list[WindowsEvent]] = None
    alarm_metrics: Optional[list[AlarmMetric]] = None
    alarms: Optional[list[Alarm]] = None
    sql_server_prometheus_exporter: Optional[SQLServerPrometheusExporter] = None
    ha_cluster_prometheus_exporter: Optional[HAClusterPrometheusExporter] = None
    hana_prometheus_exporter: Optional[HANAPrometheusExporter] = None
    logs: Optional[list[Log]] = None
    processes: Optional[list[Process]] = None
    jmx_prometheus_exporter: Optional[JMXPrometheusExporter] = None


@dataclass
class CustomComponent(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "resource_list": "ResourceList",
        "component_name": "ComponentName",
    }

    resource_list: Optional[Union[list[str], Ref]] = None
    component_name: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class HAClusterPrometheusExporter(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "prometheus_port": "PrometheusPort",
    }

    prometheus_port: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class HANAPrometheusExporter(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "hana_port": "HANAPort",
        "prometheus_port": "PrometheusPort",
        "hana_secret_name": "HANASecretName",
        "hanasid": "HANASID",
        "agree_to_install_hanadb_client": "AgreeToInstallHANADBClient",
    }

    hana_port: Optional[Union[str, Ref, GetAtt, Sub]] = None
    prometheus_port: Optional[Union[str, Ref, GetAtt, Sub]] = None
    hana_secret_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    hanasid: Optional[Union[str, Ref, GetAtt, Sub]] = None
    agree_to_install_hanadb_client: Optional[Union[bool, Ref, GetAtt, Sub]] = None


@dataclass
class JMXPrometheusExporter(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "prometheus_port": "PrometheusPort",
        "jmxurl": "JMXURL",
        "host_port": "HostPort",
    }

    prometheus_port: Optional[Union[str, Ref, GetAtt, Sub]] = None
    jmxurl: Optional[Union[str, Ref, GetAtt, Sub]] = None
    host_port: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class Log(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "log_type": "LogType",
        "encoding": "Encoding",
        "log_group_name": "LogGroupName",
        "log_path": "LogPath",
        "pattern_set": "PatternSet",
    }

    log_type: Optional[Union[str, Ref, GetAtt, Sub]] = None
    encoding: Optional[Union[str, Ref, GetAtt, Sub]] = None
    log_group_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    log_path: Optional[Union[str, Ref, GetAtt, Sub]] = None
    pattern_set: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class LogPattern(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "pattern": "Pattern",
        "rank": "Rank",
        "pattern_name": "PatternName",
    }

    pattern: Optional[Union[str, Ref, GetAtt, Sub]] = None
    rank: Optional[Union[int, Ref, GetAtt, Sub]] = None
    pattern_name: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class LogPatternSet(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "pattern_set_name": "PatternSetName",
        "log_patterns": "LogPatterns",
    }

    pattern_set_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    log_patterns: Optional[list[LogPattern]] = None


@dataclass
class NetWeaverPrometheusExporter(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "prometheus_port": "PrometheusPort",
        "instance_numbers": "InstanceNumbers",
        "sapsid": "SAPSID",
    }

    prometheus_port: Optional[Union[str, Ref, GetAtt, Sub]] = None
    instance_numbers: Optional[Union[list[str], Ref]] = None
    sapsid: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class Process(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "process_name": "ProcessName",
        "alarm_metrics": "AlarmMetrics",
    }

    process_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    alarm_metrics: Optional[list[AlarmMetric]] = None


@dataclass
class SQLServerPrometheusExporter(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "prometheus_port": "PrometheusPort",
        "sql_secret_name": "SQLSecretName",
    }

    prometheus_port: Optional[Union[str, Ref, GetAtt, Sub]] = None
    sql_secret_name: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class SubComponentConfigurationDetails(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "windows_events": "WindowsEvents",
        "alarm_metrics": "AlarmMetrics",
        "logs": "Logs",
        "processes": "Processes",
    }

    windows_events: Optional[list[WindowsEvent]] = None
    alarm_metrics: Optional[list[AlarmMetric]] = None
    logs: Optional[list[Log]] = None
    processes: Optional[list[Process]] = None


@dataclass
class SubComponentTypeConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "sub_component_type": "SubComponentType",
        "sub_component_configuration_details": "SubComponentConfigurationDetails",
    }

    sub_component_type: Optional[Union[str, Ref, GetAtt, Sub]] = None
    sub_component_configuration_details: Optional[SubComponentConfigurationDetails] = None


@dataclass
class WindowsEvent(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "event_levels": "EventLevels",
        "log_group_name": "LogGroupName",
        "event_name": "EventName",
        "pattern_set": "PatternSet",
    }

    event_levels: Optional[Union[list[str], Ref]] = None
    log_group_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    event_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    pattern_set: Optional[Union[str, Ref, GetAtt, Sub]] = None

