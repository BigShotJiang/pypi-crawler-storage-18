"""PropertyTypes for AWS::EMRServerless::Application."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar, Optional, Union

from cloudformation_dataclasses.core.base import PropertyType, Tag
from cloudformation_dataclasses.intrinsics.functions import GetAtt, Ref, Sub


@dataclass
class AutoStartConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "enabled": "Enabled",
    }

    enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None


@dataclass
class AutoStopConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "enabled": "Enabled",
        "idle_timeout_minutes": "IdleTimeoutMinutes",
    }

    enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None
    idle_timeout_minutes: Optional[Union[int, Ref, GetAtt, Sub]] = None


@dataclass
class CloudWatchLoggingConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "encryption_key_arn": "EncryptionKeyArn",
        "enabled": "Enabled",
        "log_stream_name_prefix": "LogStreamNamePrefix",
        "log_group_name": "LogGroupName",
        "log_type_map": "LogTypeMap",
    }

    encryption_key_arn: Optional[Union[str, Ref, GetAtt, Sub]] = None
    enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None
    log_stream_name_prefix: Optional[Union[str, Ref, GetAtt, Sub]] = None
    log_group_name: Optional[Union[str, Ref, GetAtt, Sub]] = None
    log_type_map: Optional[list[LogTypeMapKeyValuePair]] = None


@dataclass
class ConfigurationObject(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "classification": "Classification",
        "properties": "Properties",
        "configurations": "Configurations",
    }

    classification: Optional[Union[str, Ref, GetAtt, Sub]] = None
    properties: Optional[dict[str, str]] = None
    configurations: Optional[list[ConfigurationObject]] = None


@dataclass
class IdentityCenterConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "identity_center_instance_arn": "IdentityCenterInstanceArn",
    }

    identity_center_instance_arn: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class ImageConfigurationInput(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "image_uri": "ImageUri",
    }

    image_uri: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class InitialCapacityConfig(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "worker_configuration": "WorkerConfiguration",
        "worker_count": "WorkerCount",
    }

    worker_configuration: Optional[WorkerConfiguration] = None
    worker_count: Optional[Union[int, Ref, GetAtt, Sub]] = None


@dataclass
class InitialCapacityConfigKeyValuePair(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "value": "Value",
        "key": "Key",
    }

    value: Optional[InitialCapacityConfig] = None
    key: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class InteractiveConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "studio_enabled": "StudioEnabled",
        "livy_endpoint_enabled": "LivyEndpointEnabled",
    }

    studio_enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None
    livy_endpoint_enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None


@dataclass
class LogTypeMapKeyValuePair(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "value": "Value",
        "key": "Key",
    }

    value: Optional[Union[list[str], Ref]] = None
    key: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class ManagedPersistenceMonitoringConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "encryption_key_arn": "EncryptionKeyArn",
        "enabled": "Enabled",
    }

    encryption_key_arn: Optional[Union[str, Ref, GetAtt, Sub]] = None
    enabled: Optional[Union[bool, Ref, GetAtt, Sub]] = None


@dataclass
class MaximumAllowedResources(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "memory": "Memory",
        "cpu": "Cpu",
        "disk": "Disk",
    }

    memory: Optional[Union[str, Ref, GetAtt, Sub]] = None
    cpu: Optional[Union[str, Ref, GetAtt, Sub]] = None
    disk: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class MonitoringConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "s3_monitoring_configuration": "S3MonitoringConfiguration",
        "prometheus_monitoring_configuration": "PrometheusMonitoringConfiguration",
        "managed_persistence_monitoring_configuration": "ManagedPersistenceMonitoringConfiguration",
        "cloud_watch_logging_configuration": "CloudWatchLoggingConfiguration",
    }

    s3_monitoring_configuration: Optional[S3MonitoringConfiguration] = None
    prometheus_monitoring_configuration: Optional[PrometheusMonitoringConfiguration] = None
    managed_persistence_monitoring_configuration: Optional[ManagedPersistenceMonitoringConfiguration] = None
    cloud_watch_logging_configuration: Optional[CloudWatchLoggingConfiguration] = None


@dataclass
class NetworkConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "subnet_ids": "SubnetIds",
        "security_group_ids": "SecurityGroupIds",
    }

    subnet_ids: Optional[Union[list[str], Ref]] = None
    security_group_ids: Optional[Union[list[str], Ref]] = None


@dataclass
class PrometheusMonitoringConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "remote_write_url": "RemoteWriteUrl",
    }

    remote_write_url: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class S3MonitoringConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "log_uri": "LogUri",
        "encryption_key_arn": "EncryptionKeyArn",
    }

    log_uri: Optional[Union[str, Ref, GetAtt, Sub]] = None
    encryption_key_arn: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class SchedulerConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "queue_timeout_minutes": "QueueTimeoutMinutes",
        "max_concurrent_runs": "MaxConcurrentRuns",
    }

    queue_timeout_minutes: Optional[Union[int, Ref, GetAtt, Sub]] = None
    max_concurrent_runs: Optional[Union[int, Ref, GetAtt, Sub]] = None


@dataclass
class WorkerConfiguration(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "disk_type": "DiskType",
        "memory": "Memory",
        "cpu": "Cpu",
        "disk": "Disk",
    }

    disk_type: Optional[Union[str, Ref, GetAtt, Sub]] = None
    memory: Optional[Union[str, Ref, GetAtt, Sub]] = None
    cpu: Optional[Union[str, Ref, GetAtt, Sub]] = None
    disk: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class WorkerTypeSpecificationInput(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "image_configuration": "ImageConfiguration",
    }

    image_configuration: Optional[ImageConfigurationInput] = None

