"""PropertyTypes for AWS::EKS::FargateProfile."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar, Optional, Union

from cloudformation_dataclasses.core.base import PropertyType, Tag
from cloudformation_dataclasses.intrinsics.functions import GetAtt, Ref, Sub


@dataclass
class Label(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "value": "Value",
        "key": "Key",
    }

    value: Optional[Union[str, Ref, GetAtt, Sub]] = None
    key: Optional[Union[str, Ref, GetAtt, Sub]] = None


@dataclass
class Selector(PropertyType):
    _property_mappings: ClassVar[dict[str, str]] = {
        "labels": "Labels",
        "namespace": "Namespace",
    }

    labels: Optional[list[Label]] = None
    namespace: Optional[Union[str, Ref, GetAtt, Sub]] = None

