
{
    "version": "2025.12.23",
    "target": "default",
    "variant": "cpu"
}
