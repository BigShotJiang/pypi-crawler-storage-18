# Hack4u Academy Courses Library

A library to list courses from Hack4u academy web.

## Courses available:

- Introducción a Linux [15 horas]
- Personalización de Entornos en Linux [3 horas]
- Python Ofensivo [35 horas]
- Introducción al Hacking [53 horas]
- Hacking Web [51 horas]

## Installation

Install with 'pip3':

```python3
pip3 install hack4u-kebris-c-tools
```

## Usage

### List courses:

```python3
from hack4u-kebris-c-tools import list_courses

for course in courses:
    print(course)
```

### Get course by name:

```python3
from hack4u-kebris-c-tools import get_course_by_name

course = get_course_by_name("Introducción al Hacking")
print(course)
```

### Calculate total duration of all the courses on Hack4u academy web

```python3
from hack4u-kebris-c-tools.utils import total_duration

print(f"Total duration: {total_duration()} hours")
```

### To use all utilities

```python3
from hack4u-kebris-c-tools import *
```
