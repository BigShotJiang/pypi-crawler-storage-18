"""Module containing data classes."""
