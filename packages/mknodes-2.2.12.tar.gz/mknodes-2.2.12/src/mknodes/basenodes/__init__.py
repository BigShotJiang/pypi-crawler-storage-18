"""Module containing base MkNodes."""
