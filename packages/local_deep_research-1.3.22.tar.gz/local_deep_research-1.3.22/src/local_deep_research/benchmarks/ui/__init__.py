"""Benchmark UI components package."""
