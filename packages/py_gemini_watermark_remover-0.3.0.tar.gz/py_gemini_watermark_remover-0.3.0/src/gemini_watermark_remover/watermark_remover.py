#!/usr/bin/env python3
"""
Gemini Watermark Remover - Python Implementation

Core watermark removal engine using reverse alpha blending.
"""

import cv2
import numpy as np
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional, Tuple, Union
from enum import Enum


class WatermarkSize(Enum):
    """Watermark size enumeration"""
    SMALL = (48, 48, 32)  # (width, height, margin)
    LARGE = (96, 96, 64)  # (width, height, margin)


class WatermarkRemover:
    """
    Gemini Watermark Removal Engine

    Uses reverse alpha blending to mathematically remove watermarks:
    original = (watermarked - alpha * logo_value) / (1 - alpha)
    """

    def __init__(self, logo_value: float = 255.0, auto_detect: bool = True):
        """
        Initialize the watermark remover.

        Args:
            logo_value: The brightness value of the Gemini logo (default: 255 = white)
            auto_detect: Enable automatic watermark detection for scaled images
        """
        self.logo_value = logo_value
        self.alpha_threshold = 0.002  # Ignore very small alpha (noise)
        self.max_alpha = 0.99  # Avoid division by near-zero
        self.auto_detect = auto_detect

        # Load real alpha maps from Gemini watermark captures
        script_dir = Path(__file__).parent
        bg_48_path = script_dir / 'bg_48.png'
        bg_96_path = script_dir / 'bg_96.png'

        # Fallback to assets directory for development
        if not bg_48_path.exists():
            script_dir = Path(__file__).parent.parent.parent / 'assets'
            bg_48_path = script_dir / 'bg_48.png'
            bg_96_path = script_dir / 'bg_96.png'

        if bg_48_path.exists() and bg_96_path.exists():
            self.bg_48 = cv2.imread(str(bg_48_path))
            self.bg_96 = cv2.imread(str(bg_96_path))
            self.alpha_map_small = self.calculate_alpha_map(self.bg_48)
            self.alpha_map_large = self.calculate_alpha_map(self.bg_96)
        else:
            # Fall back to default alpha maps if files not found
            self.bg_48 = None
            self.bg_96 = None
            self.alpha_map_small = None
            self.alpha_map_large = None

    @staticmethod
    def get_watermark_size(image_width: int, image_height: int) -> WatermarkSize:
        """
        Determine watermark size based on image dimensions.

        Gemini's rules:
        - Large (96x96, 64px margin): BOTH width AND height > 1024
        - Small (48x48, 32px margin): Otherwise (including 1024x1024)

        Args:
            image_width: Image width in pixels
            image_height: Image height in pixels

        Returns:
            WatermarkSize enum (SMALL or LARGE)
        """
        if image_width > 1024 and image_height > 1024:
            return WatermarkSize.LARGE
        return WatermarkSize.SMALL

    @staticmethod
    def calculate_alpha_map(bg_capture: np.ndarray) -> np.ndarray:
        """
        Calculate alpha map from background capture.

        Takes the maximum value across RGB channels and normalizes to [0, 1].

        Args:
            bg_capture: Background capture image (BGR format)

        Returns:
            Alpha map as float32 array with values in [0, 1]
        """
        # Take max of RGB channels for brightness
        if len(bg_capture.shape) == 3 and bg_capture.shape[2] == 3:
            gray = np.max(bg_capture, axis=2)
        else:
            gray = bg_capture

        # Normalize to [0, 1]
        alpha_map = gray.astype(np.float32) / 255.0
        return alpha_map

    @staticmethod
    def create_default_alpha_map(size: WatermarkSize) -> np.ndarray:
        """
        Create a default alpha map when no background capture is available.

        Creates a circular gradient mask centered on the logo.

        Args:
            size: Watermark size (SMALL or LARGE)

        Returns:
            Default alpha map
        """
        width, height, _ = size.value

        # Create circular gradient mask
        y, x = np.ogrid[:height, :width]
        center_y, center_x = height // 2, width // 2

        # Distance from center
        dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
        max_dist = min(width, height) // 2

        # Normalize and invert (center = high alpha, edges = low alpha)
        alpha = np.clip(1.0 - (dist / max_dist), 0.0, 1.0)

        # Apply smoothing for more realistic effect
        alpha = alpha ** 1.5  # Power curve for smooth falloff

        return alpha.astype(np.float32)

    def get_watermark_position(self, image_width: int, image_height: int,
                               size: WatermarkSize) -> Tuple[int, int]:
        """
        Calculate watermark position (bottom-right with margin).

        Args:
            image_width: Image width
            image_height: Image height
            size: Watermark size

        Returns:
            (x, y) position of top-left corner of watermark
        """
        w, h, margin = size.value
        x = image_width - w - margin
        y = image_height - h - margin
        return (x, y)

    def detect_watermark_by_feature(self, image: np.ndarray) -> Optional[Tuple[int, int, int, float]]:
        """
        Detect watermark using feature-based approach.

        The Gemini watermark has characteristic patterns:
        1. Center is brighter than edges (star shape with glow)
        2. Circular gradient pattern
        3. Located in bottom-right corner with margin

        Args:
            image: Input image (BGR format)

        Returns:
            Tuple of (x, y, detected_size, confidence) or None if not found
        """
        height, width = image.shape[:2]

        # Search in bottom-right corner
        search_x_start = max(0, int(width * 0.80))
        search_y_start = max(0, int(height * 0.80))

        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image

        candidates = []

        # Try different sizes (scaled watermarks range from ~20 to ~100 pixels)
        for test_size in [20, 24, 28, 32, 36, 40, 48, 56, 64, 72, 80, 96]:
            if test_size > min(height - search_y_start, width - search_x_start) - 5:
                continue

            # Scan positions in the search region
            for y in range(search_y_start, height - test_size - 2, 2):
                for x in range(search_x_start, width - test_size - 2, 2):
                    roi = gray[y:y+test_size, x:x+test_size]

                    # Calculate center vs edge brightness
                    third = test_size // 3
                    center_region = roi[third:2*third, third:2*third]
                    center = center_region.mean()

                    # Edge pixels (outer ring)
                    edge_pixels = np.concatenate([
                        roi[0, :],           # top row
                        roi[-1, :],          # bottom row
                        roi[:, 0],           # left column
                        roi[:, -1]           # right column
                    ])
                    edge = edge_pixels.mean()

                    # Watermark characteristic: center brighter than edge
                    diff = center - edge

                    # Additional check: the center should have relatively uniform brightness
                    center_std = center_region.std()

                    # Basic qualification
                    if center > 180 and diff > 30 and center_std < 40:
                        # Distance to right and bottom edges
                        dist_to_right = width - (x + test_size)
                        dist_to_bottom = height - (y + test_size)

                        candidates.append({
                            'x': x, 'y': y, 'size': test_size,
                            'center': center, 'edge': edge, 'diff': diff,
                            'std': center_std,
                            'dist_right': dist_to_right,
                            'dist_bottom': dist_to_bottom
                        })

        if not candidates:
            return None

        # Sort candidates by distance to corner (smaller = closer to corner = better)
        # Then by diff (larger = better)
        candidates.sort(key=lambda c: (c['dist_right'] + c['dist_bottom'], -c['diff']))

        # Take top candidates that are close to the corner
        top_candidates = [c for c in candidates if c['dist_right'] < 200 and c['dist_bottom'] < 150]

        if not top_candidates:
            top_candidates = candidates[:10]

        # Among close candidates, pick the one with best diff and reasonable std
        best = None
        best_score = 0
        for c in top_candidates:
            # Score: diff is primary, penalize high std
            score = c['diff'] - c['std'] * 0.3
            if score > best_score:
                best_score = score
                best = c

        if best:
            confidence = min(1.0, best['diff'] / 80)
            return (best['x'], best['y'], best['size'], confidence)

        return None

    def detect_watermark(self, image: np.ndarray,
                         search_region: Optional[Tuple[int, int, int, int]] = None
                         ) -> Optional[Tuple[int, int, int, float]]:
        """
        Auto-detect watermark position and scale using multiple methods.

        Args:
            image: Input image (BGR format)
            search_region: Optional (x, y, w, h) to limit search area.
                          If None, searches bottom-right corner area.

        Returns:
            Tuple of (x, y, detected_size, confidence) or None if not found
        """
        # Method 1: Feature-based detection (better for scaled images)
        feature_match = self.detect_watermark_by_feature(image)

        # Method 2: Template matching (if bg_96 is available)
        template_match = None
        if self.bg_96 is not None:
            template_match = self._detect_watermark_by_template(image, search_region)

        # Choose the best match
        if feature_match and template_match:
            # Prefer feature match if it has higher confidence or is closer to corner
            f_conf = feature_match[3]
            t_conf = template_match[3]

            # Feature match is usually more reliable for scaled images
            if f_conf > 0.5 or (f_conf > t_conf * 0.8):
                return feature_match
            return template_match

        return feature_match or template_match

    def _detect_watermark_by_template(self, image: np.ndarray,
                                       search_region: Optional[Tuple[int, int, int, int]] = None
                                       ) -> Optional[Tuple[int, int, int, float]]:
        """Template matching based watermark detection."""
        if self.bg_96 is None:
            return None

        height, width = image.shape[:2]

        # Define search region (default: right 25%, bottom 40%)
        if search_region is None:
            search_x = max(0, int(width * 0.75))
            search_y = max(0, int(height * 0.6))
            search_w = width - search_x
            search_h = height - search_y
        else:
            search_x, search_y, search_w, search_h = search_region

        # Extract search region
        roi = image[search_y:search_y+search_h, search_x:search_x+search_w]
        if roi.size == 0:
            return None

        # Convert to grayscale for matching
        if len(roi.shape) == 3:
            roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        else:
            roi_gray = roi

        # Use 96x96 template as base
        template = self.bg_96
        if len(template.shape) == 3:
            template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
        else:
            template_gray = template

        best_match = None
        best_val = -1

        # Multi-scale matching
        scales = np.arange(0.25, 1.55, 0.05)

        for scale in scales:
            new_size = int(96 * scale)
            if new_size < 16 or new_size > min(roi_gray.shape[:2]):
                continue

            scaled_template = cv2.resize(template_gray, (new_size, new_size),
                                        interpolation=cv2.INTER_LINEAR)

            if scaled_template.shape[0] > roi_gray.shape[0] or \
               scaled_template.shape[1] > roi_gray.shape[1]:
                continue

            result = cv2.matchTemplate(roi_gray, scaled_template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)

            match_x = max_loc[0] + search_x
            match_y = max_loc[1] + search_y

            # Weight by position
            pos_weight = (match_x / width) * 0.3 + (match_y / height) * 0.3
            weighted_val = max_val + pos_weight * 0.1

            if weighted_val > best_val:
                best_val = weighted_val
                best_match = (match_x, match_y, new_size, max_val)

        if best_match and best_match[3] > 0.35:
            return best_match

        return None

    def detect_and_remove_watermark(self, image: np.ndarray) -> np.ndarray:
        """
        Auto-detect and remove watermark from image, handling scaled images.

        Strategy:
        1. First check if standard position has watermark characteristics
        2. If yes, use standard position (most reliable)
        3. If no, try auto-detection for scaled images

        Args:
            image: Input image (BGR format)

        Returns:
            Image with watermark removed
        """
        if image is None or image.size == 0:
            raise ValueError("Empty image provided")

        # Ensure BGR format
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        elif image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

        result = image.copy()
        height, width = image.shape[:2]

        # Get standard watermark info
        size = self.get_watermark_size(width, height)
        std_x, std_y = self.get_watermark_position(width, height, size)
        w, h, _ = size.value

        # Check if standard position has watermark characteristics
        if std_x >= 0 and std_y >= 0 and std_x + w <= width and std_y + h <= height:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            roi = gray[std_y:std_y+h, std_x:std_x+w]

            third = w // 3
            center = roi[third:2*third, third:2*third].mean()
            edge = np.concatenate([roi[0,:], roi[-1,:], roi[:,0], roi[:,-1]]).mean()
            diff = center - edge

            # If standard position looks like a watermark, use it
            if center > 150 and diff > 20:
                # Standard position has watermark characteristics, use standard removal
                return self.remove_watermark(image, auto_detect=False)

        # Standard position doesn't look like a watermark
        # Try auto-detection for potentially scaled images
        detection = self.detect_watermark(image)

        if detection:
            det_x, det_y, det_size, _ = detection

            # Use detected position and size
            x, y = det_x, det_y
            wm_size = det_size

            # Scale alpha map to match detected size
            if self.alpha_map_large is not None:
                alpha_map = cv2.resize(self.alpha_map_large, (wm_size, wm_size),
                                      interpolation=cv2.INTER_LINEAR)
            else:
                alpha_map = self.create_default_alpha_map(WatermarkSize.LARGE)
                alpha_map = cv2.resize(alpha_map, (wm_size, wm_size),
                                      interpolation=cv2.INTER_LINEAR)

            # Ensure within bounds
            if x + wm_size > width:
                x = width - wm_size
            if y + wm_size > height:
                y = height - wm_size
            x = max(0, x)
            y = max(0, y)

            # Extract and process ROI
            roi = result[y:y+wm_size, x:x+wm_size]
            cleaned_roi = self.remove_watermark_from_region(roi, alpha_map)
            result[y:y+wm_size, x:x+wm_size] = cleaned_roi

            return result

        # Fall back to standard removal
        return self.remove_watermark(image, auto_detect=False)

    def remove_watermark_from_region(self, image_region: np.ndarray,
                                     alpha_map: np.ndarray) -> np.ndarray:
        """
        Apply reverse alpha blending to remove watermark from image region.

        Formula: original = (watermarked - alpha * logo) / (1 - alpha)

        Args:
            image_region: Image region containing watermark (BGR, uint8)
            alpha_map: Alpha map for the watermark (float32, [0, 1])

        Returns:
            Restored image region (BGR, uint8)
        """
        # Convert to float for computation
        image_f = image_region.astype(np.float32)

        # Expand alpha to 3 channels (BGR)
        alpha_3ch = np.expand_dims(alpha_map, axis=2)

        # Create mask for pixels above threshold
        valid_mask = alpha_map >= self.alpha_threshold

        # Clamp alpha to avoid division issues (only upper limit!)
        alpha_clamped = np.minimum(alpha_3ch, self.max_alpha)
        one_minus_alpha = 1.0 - alpha_clamped

        # Apply reverse alpha blending
        original = (image_f - alpha_clamped * self.logo_value) / one_minus_alpha

        # Only update pixels with significant watermark effect
        result = image_f.copy()
        for c in range(3):  # Process each channel
            result[:, :, c] = np.where(valid_mask, original[:, :, c], image_f[:, :, c])

        # Clamp to valid range and convert back
        result = np.clip(result, 0, 255).astype(np.uint8)
        return result

    def remove_watermark(self, image: np.ndarray,
                        force_size: Optional[WatermarkSize] = None,
                        alpha_map: Optional[np.ndarray] = None,
                        auto_detect: Optional[bool] = None) -> np.ndarray:
        """
        Remove watermark from image.

        Args:
            image: Input image (BGR format)
            force_size: Optional forced watermark size
            alpha_map: Optional custom alpha map (if None, uses default)
            auto_detect: Enable auto-detection for scaled images (default: use instance setting)

        Returns:
            Image with watermark removed
        """
        if image is None or image.size == 0:
            raise ValueError("Empty image provided")

        # Ensure BGR format
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        elif image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

        # Use auto-detection if enabled and no forced parameters
        use_auto = auto_detect if auto_detect is not None else self.auto_detect
        if use_auto and force_size is None and alpha_map is None:
            return self.detect_and_remove_watermark(image)

        # Make a copy to avoid modifying original
        result = image.copy()

        # Determine watermark size
        height, width = image.shape[:2]
        size = force_size or self.get_watermark_size(width, height)

        # Get watermark position
        x, y = self.get_watermark_position(width, height, size)
        w, h, _ = size.value

        # Get or create alpha map
        if alpha_map is None:
            # Use preloaded real alpha maps if available
            if size == WatermarkSize.SMALL and self.alpha_map_small is not None:
                alpha_map = self.alpha_map_small
            elif size == WatermarkSize.LARGE and self.alpha_map_large is not None:
                alpha_map = self.alpha_map_large
            else:
                # Fall back to default
                alpha_map = self.create_default_alpha_map(size)
        elif alpha_map.shape != (h, w):
            # Resize if needed
            alpha_map = cv2.resize(alpha_map, (w, h), interpolation=cv2.INTER_LINEAR)

        # Ensure alpha map is within image bounds
        if x < 0 or y < 0 or x + w > width or y + h > height:
            print(f"Warning: Watermark position ({x}, {y}) with size {w}x{h} exceeds image bounds")
            # Adjust to fit within bounds
            x = max(0, min(x, width - w))
            y = max(0, min(y, height - h))

        # Extract region of interest
        roi = result[y:y+h, x:x+w]

        # Remove watermark from region
        cleaned_roi = self.remove_watermark_from_region(roi, alpha_map)

        # Put cleaned region back
        result[y:y+h, x:x+w] = cleaned_roi

        return result

    def add_watermark(self, image: np.ndarray,
                     force_size: Optional[WatermarkSize] = None,
                     alpha_map: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Add watermark to image (for testing purposes).

        Formula: watermarked = alpha * logo + (1 - alpha) * original

        Args:
            image: Input image (BGR format)
            force_size: Optional forced watermark size
            alpha_map: Optional custom alpha map

        Returns:
            Image with watermark added
        """
        if image is None or image.size == 0:
            raise ValueError("Empty image provided")

        # Ensure BGR format
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        elif image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

        result = image.copy()

        # Determine watermark size
        height, width = image.shape[:2]
        size = force_size or self.get_watermark_size(width, height)

        # Get watermark position
        x, y = self.get_watermark_position(width, height, size)
        w, h, _ = size.value

        # Get or create alpha map
        if alpha_map is None:
            # Use preloaded real alpha maps if available
            if size == WatermarkSize.SMALL and self.alpha_map_small is not None:
                alpha_map = self.alpha_map_small
            elif size == WatermarkSize.LARGE and self.alpha_map_large is not None:
                alpha_map = self.alpha_map_large
            else:
                # Fall back to default
                alpha_map = self.create_default_alpha_map(size)
        elif alpha_map.shape != (h, w):
            alpha_map = cv2.resize(alpha_map, (w, h), interpolation=cv2.INTER_LINEAR)

        # Extract ROI
        roi = result[y:y+h, x:x+w].astype(np.float32)
        alpha_3ch = np.expand_dims(alpha_map, axis=2)

        # Apply alpha blending
        watermarked = alpha_3ch * self.logo_value + (1.0 - alpha_3ch) * roi
        result[y:y+h, x:x+w] = np.clip(watermarked, 0, 255).astype(np.uint8)

        return result


def is_url(path: str) -> bool:
    """Check if the path is a URL."""
    return path.startswith(('http://', 'https://'))


def load_image_from_url(url: str) -> Optional[np.ndarray]:
    """
    Load image from URL directly into memory.

    Args:
        url: Image URL

    Returns:
        Image as numpy array (BGR format), or None if failed
    """
    try:
        # Set User-Agent to avoid some server restrictions
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = np.frombuffer(resp.read(), np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            return image
    except urllib.error.URLError as e:
        print(f"Error: Failed to download image: {e.reason}")
        return None
    except Exception as e:
        print(f"Error: Failed to load image from URL: {e}")
        return None


def process_image(input_path: Union[str, Path],
                 output_path: Union[str, Path],
                 remove: bool = True,
                 force_size: Optional[WatermarkSize] = None,
                 logo_value: float = 255.0) -> bool:
    """
    Process a single image file or URL.

    Args:
        input_path: Path to input image or URL
        output_path: Path to output image
        remove: If True, remove watermark; if False, add watermark
        force_size: Optional forced watermark size
        logo_value: Logo brightness value

    Returns:
        True if successful, False otherwise
    """
    try:
        input_str = str(input_path)
        output_path = Path(output_path)

        # Check if input is URL
        if is_url(input_str):
            print(f"Downloading: {input_str[:80]}...")
            image = load_image_from_url(input_str)
            if image is None:
                return False
            input_name = input_str.split('/')[-1].split('?')[0] or 'remote_image'
        else:
            input_path = Path(input_str)
            # Read image from local file
            image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
            if image is None:
                print(f"Error: Failed to load image: {input_path}")
                return False
            input_name = input_path.name

        height, width = image.shape[:2]
        print(f"Processing: {input_name} ({width}x{height})")

        # Process image
        engine = WatermarkRemover(logo_value=logo_value)

        if remove:
            result = engine.remove_watermark(image, force_size=force_size)
        else:
            result = engine.add_watermark(image, force_size=force_size)

        # Create output directory if needed
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Determine output quality based on format
        ext = output_path.suffix.lower()
        if ext in ['.jpg', '.jpeg']:
            # JPEG: 100 = best quality (still lossy)
            success = cv2.imwrite(str(output_path), result, [cv2.IMWRITE_JPEG_QUALITY, 100])
        elif ext == '.png':
            # PNG: lossless, compression level affects size/speed
            success = cv2.imwrite(str(output_path), result, [cv2.IMWRITE_PNG_COMPRESSION, 6])
        elif ext == '.webp':
            # WebP: 101 = lossless mode
            success = cv2.imwrite(str(output_path), result, [cv2.IMWRITE_WEBP_QUALITY, 101])
        else:
            success = cv2.imwrite(str(output_path), result)

        if not success:
            print(f"Error: Failed to write image: {output_path}")
            return False

        print(f"Saved: {output_path.name}")
        return True

    except Exception as e:
        print(f"Error processing {input_str}: {e}")
        return False


def process_directory(input_dir: Union[str, Path],
                     output_dir: Union[str, Path],
                     remove: bool = True,
                     force_size: Optional[WatermarkSize] = None,
                     logo_value: float = 235.0) -> Tuple[int, int]:
    """
    Process all images in a directory.

    Args:
        input_dir: Input directory path
        output_dir: Output directory path
        remove: If True, remove watermark; if False, add watermark
        force_size: Optional forced watermark size
        logo_value: Logo brightness value

    Returns:
        Tuple of (successful_count, failed_count)
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)

    if not input_dir.is_dir():
        print(f"Error: Input directory does not exist: {input_dir}")
        return (0, 0)

    # Supported image formats
    extensions = ['.jpg', '.jpeg', '.png', '.webp', '.bmp']

    # Find all image files
    image_files = []
    for ext in extensions:
        image_files.extend(input_dir.glob(f'*{ext}'))
        image_files.extend(input_dir.glob(f'*{ext.upper()}'))

    if not image_files:
        print(f"No image files found in {input_dir}")
        return (0, 0)

    print(f"Found {len(image_files)} image(s) to process")

    success_count = 0
    fail_count = 0

    for image_file in image_files:
        output_file = output_dir / image_file.name

        if process_image(image_file, output_file, remove, force_size, logo_value):
            success_count += 1
        else:
            fail_count += 1

    print(f"\nProcessing complete: {success_count} succeeded, {fail_count} failed")
    return (success_count, fail_count)
