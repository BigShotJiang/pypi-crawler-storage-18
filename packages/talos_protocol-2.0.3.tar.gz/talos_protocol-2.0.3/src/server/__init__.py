"""Server and registry components."""
