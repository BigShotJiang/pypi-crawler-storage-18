---
spec_version: AFAD-v1
project_version: 0.29.1
context: RUNTIME
last_updated: 2025-12-23T00:00:00Z
maintainer: claude-opus-4-5
---

# Runtime Reference

---

## `number_format`

### Signature
```python
def number_format(
    value: int | float,
    locale_code: str = "en-US",
    *,
    minimum_fraction_digits: int = 0,
    maximum_fraction_digits: int = 3,
    use_grouping: bool = True,
    pattern: str | None = None,
) -> str:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `int \| float` | Y | Number to format. |
| `locale_code` | `str` | N | BCP 47 locale code. |
| `minimum_fraction_digits` | `int` | N | Minimum decimal places. |
| `maximum_fraction_digits` | `int` | N | Maximum decimal places. |
| `use_grouping` | `bool` | N | Use thousands separator. |
| `pattern` | `str \| None` | N | Custom Babel number pattern. |

### Constraints
- Return: Formatted number string.
- Raises: Never. Returns str(value) on error.
- State: None.
- Thread: Safe.

---

## `datetime_format`

### Signature
```python
def datetime_format(
    value: datetime | str,
    locale_code: str = "en-US",
    *,
    date_style: Literal["short", "medium", "long", "full"] = "medium",
    time_style: Literal["short", "medium", "long", "full"] | None = None,
    pattern: str | None = None,
) -> str:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `datetime \| str` | Y | Datetime or ISO string. |
| `locale_code` | `str` | N | BCP 47 locale code. |
| `date_style` | `Literal[...]` | N | Date format style. |
| `time_style` | `Literal[...] \| None` | N | Time format style. |
| `pattern` | `str \| None` | N | Custom Babel datetime pattern. |

### Constraints
- Return: Formatted datetime string.
- Raises: Never. Returns ISO format on error.
- State: None.
- Thread: Safe.

---

## `currency_format`

### Signature
```python
def currency_format(
    value: int | float,
    locale_code: str = "en-US",
    *,
    currency: str,
    currency_display: Literal["symbol", "code", "name"] = "symbol",
    pattern: str | None = None,
) -> str:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `int \| float` | Y | Monetary amount. |
| `locale_code` | `str` | N | BCP 47 locale code. |
| `currency` | `str` | Y | ISO 4217 currency code. |
| `currency_display` | `Literal[...]` | N | Display style. |
| `pattern` | `str \| None` | N | Custom CLDR currency pattern. |

### Constraints
- Return: Formatted currency string.
- Raises: Never. Returns "{currency} {value}" on error.
- State: None.
- Thread: Safe.

---

## `FunctionRegistry`

### Signature
```python
class FunctionRegistry:
    __slots__ = ("_functions",)

    def __init__(self) -> None: ...
    def register(
        self,
        func: Callable[..., FluentValue],
        *,
        ftl_name: str | None = None
    ) -> None: ...
    def call(
        self,
        ftl_name: str,
        positional: Sequence[FluentValue],
        named: Mapping[str, FluentValue],
    ) -> FluentValue: ...
    def get(self, name: str) -> Callable[..., FluentValue] | None: ...
    def get_callable(self, ftl_name: str) -> Callable[..., FluentValue] | None: ...
    def get_function_info(self, ftl_name: str) -> FunctionSignature | None: ...
    def copy(self) -> FunctionRegistry: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: Registry instance.
- State: Mutable registry dict.
- Thread: Unsafe for concurrent register().
- Memory: Uses __slots__ for reduced memory footprint.

---

## `FunctionRegistry.get_callable`

### Signature
```python
def get_callable(self, ftl_name: str) -> Callable[..., FluentValue] | None:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `ftl_name` | `str` | Y | FTL function name (e.g., "NUMBER"). |

### Constraints
- Return: Registered callable, or None if not found.
- State: Read-only access.
- Thread: Safe for reads.

---

## `FunctionRegistry.call`

### Signature
```python
def call(
    self,
    ftl_name: str,
    positional: Sequence[FluentValue],
    named: Mapping[str, FluentValue],
) -> FluentValue:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `ftl_name` | `str` | Y | Function name from FTL (e.g., "NUMBER"). |
| `positional` | `Sequence[FluentValue]` | Y | Positional arguments. |
| `named` | `Mapping[str, FluentValue]` | Y | Named arguments from FTL (camelCase). |

### Constraints
- Return: Function result as FluentValue.
- Raises: FluentReferenceError if function not found.
- Raises: FluentResolutionError if function execution fails.
- State: Read-only access to registry.
- Thread: Safe for calls.

---

## `FunctionRegistry.register`

### Signature
```python
def register(
    self,
    func: Callable[..., FluentValue],
    *,
    ftl_name: str | None = None,
    param_map: dict[str, str] | None = None,
) -> None:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `func` | `Callable[..., FluentValue]` | Y | Function to register. |
| `ftl_name` | `str \| None` | N | FTL name override (default: UPPERCASE of func name). |
| `param_map` | `dict[str, str] \| None` | N | Custom parameter mappings (overrides auto-generation). |

### Constraints
- Return: None.
- Raises: None.
- State: Mutates registry.
- Thread: Unsafe.

---

## `create_default_registry`

### Signature
```python
def create_default_registry() -> FunctionRegistry:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: Fresh FunctionRegistry with NUMBER, DATETIME, CURRENCY registered.
- Raises: Never.
- State: Returns new isolated instance each call.
- Thread: Safe.
- Import: `from ftllexengine.runtime.functions import create_default_registry`

---

## `FunctionCategory`

### Signature
```python
class FunctionCategory(Enum):
    FORMATTING = "formatting"
    TEXT = "text"
    CUSTOM = "custom"
```

### Contract
| Value | Description |
|:------|:------------|
| `FORMATTING` | Number, date, currency formatting functions. |
| `TEXT` | Text manipulation functions. |
| `CUSTOM` | User-defined functions. |

### Constraints
- Import: `from ftllexengine.runtime.function_metadata import FunctionCategory`
- Version: v0.27.0+

---

## `FunctionMetadata`

### Signature
```python
@dataclass(frozen=True)
class FunctionMetadata:
    python_name: str
    ftl_name: str
    requires_locale: bool
    expected_positional_args: int = 1
    category: FunctionCategory = FunctionCategory.FORMATTING
```

### Contract
| Field | Type | Req | Description |
|:------|:-----|:----|:------------|
| `python_name` | `str` | Y | Python function name (snake_case). |
| `ftl_name` | `str` | Y | FTL function name (UPPERCASE). |
| `requires_locale` | `bool` | Y | Whether function needs bundle locale injected. |
| `expected_positional_args` | `int` | N | Expected positional args from FTL (before locale). |
| `category` | `FunctionCategory` | N | Function category for documentation. |

### Constraints
- Immutable: Frozen dataclass.
- Thread: Safe.
- Import: `from ftllexengine.runtime.function_metadata import FunctionMetadata`
- Version: v0.27.0+

---

## `BUILTIN_FUNCTIONS`

### Signature
```python
BUILTIN_FUNCTIONS: dict[str, FunctionMetadata] = {
    "NUMBER": FunctionMetadata(...),
    "DATETIME": FunctionMetadata(...),
    "CURRENCY": FunctionMetadata(...),
}
```

### Constraints
- Type: `dict[str, FunctionMetadata]`
- Contents: Metadata for NUMBER, DATETIME, CURRENCY.
- Read-only: Do not modify at runtime.
- Import: `from ftllexengine.runtime.function_metadata import BUILTIN_FUNCTIONS`
- Version: v0.27.0+

---

## `is_builtin_with_locale_requirement`

### Signature
```python
def is_builtin_with_locale_requirement(func: object) -> bool:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `func` | `object` | Y | Callable to check. |

### Constraints
- Return: True if func has `_ftl_requires_locale = True`.
- Thread: Safe.
- Import: `from ftllexengine.runtime.functions import is_builtin_with_locale_requirement`
- Version: v0.27.0+

---

## `get_expected_positional_args`

### Signature
```python
def get_expected_positional_args(ftl_name: str) -> int | None:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `ftl_name` | `str` | Y | FTL function name (e.g., "NUMBER"). |

### Constraints
- Return: Expected positional arg count, or None if not built-in.
- Thread: Safe.
- Import: `from ftllexengine.runtime.function_metadata import get_expected_positional_args`
- Version: v0.27.0+

---

## `should_inject_locale`

### Signature
```python
def should_inject_locale(func_name: str, function_registry: FunctionRegistry) -> bool:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `func_name` | `str` | Y | FTL function name. |
| `function_registry` | `FunctionRegistry` | Y | Registry to check. |

### Constraints
- Return: True if locale should be injected for this call.
- Logic: Checks built-in status AND callable's `_ftl_requires_locale` attribute.
- Thread: Safe.
- Import: `from ftllexengine.runtime.function_metadata import should_inject_locale`
- Version: v0.27.0+

---

## `select_plural_category`

### Signature
```python
def select_plural_category(n: int | float, locale: str) -> str:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `n` | `int \| float` | Y | Number to categorize. |
| `locale` | `str` | Y | BCP 47 locale code. |

### Constraints
- Return: CLDR plural category (zero, one, two, few, many, other).
- Raises: Never. Returns "one" or "other" on invalid locale.
- State: None.
- Thread: Safe.

---

## FTL Function Name Mapping

| FTL Name | Python Function | Parameter Mapping |
|:---------|:----------------|:------------------|
| `NUMBER` | `number_format` | minimumFractionDigits -> minimum_fraction_digits |
| `DATETIME` | `datetime_format` | dateStyle -> date_style, timeStyle -> time_style |
| `CURRENCY` | `currency_format` | currencyDisplay -> currency_display |

---

## Custom Function Protocol

### Signature
```python
def CUSTOM_FUNCTION(
    positional_arg: FluentValue,
    locale_code: str,
    /,
    *,
    keyword_arg: str = "default",
) -> FluentValue:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| First positional | `FluentValue` | Y | Primary input value. |
| `locale_code` | `str` | Y | Locale code (positional-only). |
| Keyword args | `FluentValue` | N | Named options. |

### Constraints
- Return: FluentValue (typically str; non-string values converted by resolver).
- Raises: Should not raise. Return fallback on error.
- State: Should be stateless.
- Thread: Should be safe.

---

## `validate_resource`

### Signature
```python
def validate_resource(
    source: str,
    *,
    parser: FluentParserV1 | None = None,
) -> ValidationResult:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `source` | `str` | Y | FTL file content. |
| `parser` | `FluentParserV1 \| None` | N | Parser instance (creates default if not provided). |

### Constraints
- Return: ValidationResult with errors and warnings.
- Raises: Never. Critical parse errors returned as ValidationError.
- State: None (creates isolated parser if not provided).
- Thread: Safe.
- Import: `from ftllexengine.validation import validate_resource`

---

## `ResolutionContext`

### Signature
```python
@dataclass(slots=True)
class ResolutionContext:
    stack: list[str] = field(default_factory=list)
    max_depth: int = MAX_RESOLUTION_DEPTH

    def push(self, key: str) -> None: ...
    def pop(self) -> str: ...
    def contains(self, key: str) -> bool: ...
    @property
    def depth(self) -> int: ...
    def is_depth_exceeded(self) -> bool: ...
    def get_cycle_path(self, key: str) -> list[str]: ...
```

### Contract
| Field | Type | Description |
|:------|:-----|:------------|
| `stack` | `list[str]` | Resolution stack for cycle detection. |
| `max_depth` | `int` | Maximum resolution depth (default: 100). |

### Constraints
- Thread: Safe (explicit parameter passing, no global state).
- Purpose: Replaces thread-local state for async/concurrent compatibility.
- Import: `from ftllexengine.runtime import ResolutionContext`

---

## `ResolutionContext.push`

### Signature
```python
def push(self, key: str) -> None:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `key` | `str` | Y | Message key to push onto stack. |

### Constraints
- Return: None.
- State: Mutates stack.

---

## `ResolutionContext.pop`

### Signature
```python
def pop(self) -> str:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: Removed message key.
- Raises: IndexError if stack empty.
- State: Mutates stack.

---

## `ResolutionContext.contains`

### Signature
```python
def contains(self, key: str) -> bool:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `key` | `str` | Y | Message key to check. |

### Constraints
- Return: True if key is in resolution stack (cycle detected).
- State: Read-only.

---

## `ResolutionContext.depth`

### Signature
```python
@property
def depth(self) -> int:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: Current resolution depth (stack length).
- State: Read-only.

---

## `ResolutionContext.is_depth_exceeded`

### Signature
```python
def is_depth_exceeded(self) -> bool:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: True if depth >= max_depth.
- State: Read-only.

---

## `ResolutionContext.get_cycle_path`

### Signature
```python
def get_cycle_path(self, key: str) -> list[str]:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `key` | `str` | Y | Message key that caused cycle. |

### Constraints
- Return: List of keys showing cycle path including triggering key.
- State: Read-only.

---

## `FluentResolver`

### Signature
```python
class FluentResolver:
    __slots__ = ("function_registry", "locale", "messages", "terms", "use_isolating")

    def __init__(
        self,
        locale: str,
        messages: dict[str, Message],
        terms: dict[str, Term],
        *,
        function_registry: FunctionRegistry,
        use_isolating: bool = True,
    ) -> None: ...

    def resolve_message(
        self,
        message: Message,
        args: Mapping[str, FluentValue] | None = None,
        attribute: str | None = None,
        *,
        context: ResolutionContext | None = None,
    ) -> tuple[str, tuple[FluentError, ...]]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `locale` | `str` | Y | Locale code for plural selection. |
| `messages` | `dict[str, Message]` | Y | Message registry. |
| `terms` | `dict[str, Term]` | Y | Term registry. |
| `function_registry` | `FunctionRegistry` | Y | Function registry. |
| `use_isolating` | `bool` | N | Wrap values in Unicode bidi marks. |

### Constraints
- Return: Resolver instance.
- State: Immutable after construction.
- Thread: Safe (uses explicit context).
- Import: `from ftllexengine.runtime import FluentResolver`

---

## `FluentResolver.resolve_message`

### Signature
```python
def resolve_message(
    self,
    message: Message,
    args: Mapping[str, FluentValue] | None = None,
    attribute: str | None = None,
    *,
    context: ResolutionContext | None = None,
) -> tuple[str, tuple[FluentError, ...]]:
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `message` | `Message` | Y | Message AST. |
| `args` | `Mapping[str, FluentValue] \| None` | N | Variable arguments. |
| `attribute` | `str \| None` | N | Attribute name to resolve. |
| `context` | `ResolutionContext \| None` | N | Resolution context (creates fresh if None). |

### Constraints
- Return: Tuple of (formatted_string, errors).
- Raises: Never. Collects errors in tuple.
- State: Read-only.
- Thread: Safe.

---

## Module Constants

### `DEFAULT_CACHE_SIZE`

```python
DEFAULT_CACHE_SIZE: int = 1000
```

| Attribute | Value |
|:----------|:------|
| Type | `int` |
| Value | 1000 |
| Location | `ftllexengine.runtime.bundle` |

- Purpose: Default maximum cache entries for FluentBundle format results.
- Usage: Referenced by `FluentBundle.__init__`, `create()`, `for_system_locale()`.

---

### `UNICODE_FSI` / `UNICODE_PDI`

```python
UNICODE_FSI: str = "\u2068"  # U+2068 FIRST STRONG ISOLATE
UNICODE_PDI: str = "\u2069"  # U+2069 POP DIRECTIONAL ISOLATE
```

| Attribute | Value |
|:----------|:------|
| Type | `str` |
| Location | `ftllexengine.runtime.resolver` |

- Purpose: Unicode bidirectional isolation characters per Unicode TR9.
- Usage: Wraps interpolated values when `use_isolating=True`.

---

### `MAX_RESOLUTION_DEPTH`

```python
MAX_RESOLUTION_DEPTH: int = 100
```

| Attribute | Value |
|:----------|:------|
| Type | `int` |
| Value | 100 |
| Location | `ftllexengine.runtime.resolver` |

- Purpose: Maximum message reference chain depth.
- Usage: Prevents RecursionError from long non-cyclic reference chains.

---
