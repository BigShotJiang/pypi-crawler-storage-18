"""Hardware models container."""
