import scap

scap.main()
