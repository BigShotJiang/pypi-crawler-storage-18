# 首先应用 PyInstaller 修复
import argparse
import sys
import traceback
import os

# 在Windows上设置Python编码为UTF-8
if sys.platform == "win32":
    os.environ['PYTHONIOENCODING'] = 'utf-8'

from config import config
from fastmcp import FastMCP
from logging_config import setup_logger, get_log_info

# 初始化全局logger
logger = setup_logger(name="da_mcp_server")

# 记录导入模块的详细信息
logger.debug("开始导入MCP服务器模块...")
try:
    from settings.__main__ import register_settings_tools
    logger.debug("成功导入 register_settings_tools")
except ImportError as e:
    logger.error(f"导入 register_settings_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise
# 导入其他模块并记录详细日志
try:
    logger.debug("尝试导入 voucher_mgmt.__main__")
    from voucher_mgmt.__main__ import register_voucher_mgmt_tools
    logger.debug("成功导入 register_voucher_mgmt_tools")
except ImportError as e:
    logger.error(f"导入 register_voucher_mgmt_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 basic_data.__main__")
    from basic_data.__main__ import register_basic_data_tools
    logger.debug("成功导入 register_basic_data_tools")
except ImportError as e:
    logger.error(f"导入 register_basic_data_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 ledger_mgmt")
    from ledger_mgmt import register_ledger_mgmt_tools
    logger.debug("成功导入 register_ledger_mgmt_tools")
except ImportError as e:
    logger.error(f"导入 register_ledger_mgmt_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 financial_reports")
    from financial_reports import register_financial_report_tools, register_financial_report_query_tools, register_calculation_formula_tools
    logger.debug("成功导入 financial_reports 模块")
except ImportError as e:
    logger.error(f"导入 financial_reports 模块失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 financial_reports.cash_flow_mapping_tools")
    from financial_reports.cash_flow_mapping_tools import register_cash_flow_mapping_tools
    logger.debug("成功导入 register_cash_flow_mapping_tools")
except ImportError as e:
    logger.error(f"导入 register_cash_flow_mapping_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 file_manager")
    from file_manager import register_file_tools
    logger.debug("成功导入 register_file_tools")
except ImportError as e:
    logger.error(f"导入 register_file_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 cashier.__main__")
    from cashier.__main__ import register_cashier_tools
    logger.debug("成功导入 register_cashier_tools")
except ImportError as e:
    logger.error(f"导入 register_cashier_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 assets.__main__")
    from assets.__main__ import register_assets_tools
    logger.debug("成功导入 register_assets_tools")
except ImportError as e:
    logger.error(f"导入 register_assets_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 home_statistic.__main__")
    from home_statistic.__main__ import register_home_statistic_tools
    logger.debug("成功导入 register_home_statistic_tools")
except ImportError as e:
    logger.error(f"导入 register_home_statistic_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 file_upload_mcp.file_upload_tools")
    from file_upload_mcp.file_upload_tools import register_file_upload_tools
    logger.debug("成功导入 register_file_upload_tools")
except ImportError as e:
    logger.error(f"导入 register_file_upload_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise

try:
    logger.debug("尝试导入 financial_closing.__main__")
    from financial_closing.__main__ import register_financial_closing_tools
    logger.debug("成功导入 register_financial_closing_tools")
except ImportError as e:
    logger.error(f"导入 register_financial_closing_tools 失败: {e}")
    logger.debug(f"导入错误的详细堆栈: {traceback.format_exc()}")
    raise


# Stateful server (maintains session state)
try:
    logger.debug("开始创建 FastMCP 实例...")
    mcp = FastMCP("da_mcp_server")
    logger.info("✅ FastMCP 实例创建成功")
    logger.debug(f"MCP 服务器名称: da_mcp_server")
    logger.debug(f"MCP 服务器对象: {mcp}")
except Exception as e:
    logger.error(f"❌ 创建 FastMCP 实例失败: {e}")
    logger.debug(f"创建实例失败的详细堆栈: {traceback.format_exc()}")
    raise

# 注册所有工具模块并记录详细日志
tool_registrations = [
    ("设置管理工具", register_settings_tools),
    ("凭证管理工具", register_voucher_mgmt_tools),
    ("基础数据管理工具", register_basic_data_tools),
    ("账簿管理工具", register_ledger_mgmt_tools),
    ("报表相关工具", register_financial_report_tools),
    ("财务报表查询工具", register_financial_report_query_tools),
    ("计算公式管理工具", register_calculation_formula_tools),
    ("文件管理工具", register_file_tools),
    ("出纳管理工具", register_cashier_tools),
    ("资产管理工具", register_assets_tools),
    ("现金流量映射工具", register_cash_flow_mapping_tools),
    ("首页统计工具", register_home_statistic_tools),
    ("文件上传工具", register_file_upload_tools),
    ("结账管理工具", register_financial_closing_tools),
]

logger.info("开始注册MCP工具模块...")
for tool_name, register_func in tool_registrations:
    try:
        logger.debug(f"正在注册 {tool_name}...")
        mcp = register_func(mcp)
        logger.info(f"✅ {tool_name} 注册成功")
    except Exception as e:
        logger.error(f"❌ {tool_name} 注册失败: {e}")
        logger.debug(f"{tool_name} 注册失败的详细堆栈: {traceback.format_exc()}")
        raise

logger.info("🎉 所有MCP工具模块注册完成")

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='DeepSea Accounting MCP Server - 支持运行时配置的服务端'
    )

    # 后端服务配置参数
    parser.add_argument(
        '--backend-url',
        help='后端服务URL (默认: http://localhost:8000)',
        default=None
    )
    parser.add_argument(
        '--backend-token',
        help='后端服务访问令牌',
        default=None
    )

  
    # 日志配置参数
    log_group = parser.add_argument_group('日志配置')
    log_group.add_argument(
        '--debug',
        action='store_true',
        help='启用调试模式 (等价于 --log-level DEBUG)'
    )
    log_group.add_argument(
        '--log-dir',
        help='日志文件目录 (默认: ./logs)',
        default='./logs'
    )
    log_group.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help='日志级别 (默认: INFO)',
        default='INFO'
    )
    log_group.add_argument(
        '--console-log',
        action='store_true',
        default=True,
        help='启用控制台日志输出 (默认启用)'
    )
    log_group.add_argument(
        '--no-console-log',
        action='store_true',
        help='禁用控制台日志输出'
    )
    log_group.add_argument(
        '--file-log',
        action='store_true',
        default=True,
        help='启用文件日志输出 (默认启用)'
    )
    log_group.add_argument(
        '--no-file-log',
        action='store_true',
        help='禁用文件日志输出'
    )

    return parser.parse_args()


def apply_command_line_config(args):
    """应用命令行参数配置"""
    logger.debug("开始应用命令行参数配置...")
    config_changes = []

    # 配置后端服务
    if args.backend_url or args.backend_token:
        logger.debug(f"配置后端服务 - URL: {args.backend_url}, Token: {'已设置' if args.backend_token else '未设置'}")
        try:
            config.configure_backend(args.backend_url, args.backend_token)
            if args.backend_url:
                config_changes.append(f"后端服务URL: {args.backend_url}")
                logger.debug(f"后端服务URL配置成功: {args.backend_url}")
            if args.backend_token:
                config_changes.append("后端服务Token: 已设置")
                logger.debug("后端服务Token配置成功")
        except Exception as e:
            logger.error(f"配置后端服务失败: {e}")
            logger.debug(f"配置后端服务失败的详细堆栈: {traceback.format_exc()}")
            raise
  
    logger.debug(f"命令行参数配置完成，变更项: {config_changes}")
    return config_changes

# Run server with streamable_http transport
if __name__ == "__main__":
    main()
        
        


def main():
    """主函数，支持脚本入口点"""
    try:
        # 解析命令行参数
        args = parse_arguments()
        
        # 处理日志配置的互斥参数
        console_log = args.console_log and not args.no_console_log
        file_log = args.file_log and not args.no_file_log
        
        # 设置日志级别（debug模式优先）
        log_level = 'DEBUG' if args.debug else args.log_level
        
        # 设置日志
        logger = setup_logger(
            name="da_mcp_server",
            level=log_level,
            console=console_log,
            file=file_log,
            log_dir=args.log_dir
        )
        
        # 配置后端服务
        config_changes = configure_backend_service(args)
        
        # 启动服务器
        run_server(args, config_changes)
        
    except KeyboardInterrupt:
        if 'logger' in globals():
            logger.info("收到中断信号，正在关闭服务器...")
        print("\nMCP服务器已关闭")
        
    except Exception as e:
        # 确保logger已初始化
        if 'logger' not in globals():
            logger = setup_logger(name="da_mcp_server")
        
        # 检查是否是-32000错误相关的MCP错误
        if "-32000" in str(e) or "McpError" in str(type(e).__name__):
            logger.error("🔍 检测到MCP错误 -32000，这通常表示:")
            logger.error("  1. MCP协议通信问题")
            logger.error("  2. stdio传输配置问题")
            logger.error("  3. 客户端-服务器握手失败")
            logger.error("  4. JSON-RPC协议错误")
            logger.error("")
            logger.error("建议检查:")
            logger.error("  - 确保客户端正确配置了stdio传输")
            logger.error("  - 检查Python环境和依赖包")
            logger.error("  - 验证防火墙和权限设置")
            logger.error("  - 查看客户端的错误日志")
            logger.error("  - 检查日志文件中的详细错误信息")
            if 'args' in locals() and file_log:
                logger.error(f"  - 日志文件位置: {args.log_dir}")
        
        print(f"\n❌ MCP服务器启动失败: {e}")
        print(f"错误类型: {type(e).__name__}")
        if 'args' in locals() and args.debug:
            print(f"\n详细错误信息:\n{traceback.format_exc()}")
        if 'args' in locals() and file_log:
            print(f"\n📝 详细日志请查看: {args.log_dir}/")
        sys.exit(1)