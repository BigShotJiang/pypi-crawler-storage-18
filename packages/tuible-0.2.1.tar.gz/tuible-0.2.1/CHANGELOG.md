# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2025-12-26

### Added
- Index column support: New `index` or `idx` mode to dedicate the first column to an index column with auto-numbering or custom labels.

### Changed
- Renamed internal references from CliTable to Tuible for consistency.

### Fixed
- Removed unused `-cc` parameter.
- Fixed index column width calculation.

## [0.1.1] - 2024-XX-XX

### Added
- Initial release with basic table formatting features.