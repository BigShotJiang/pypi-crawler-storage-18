######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.098130                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

