######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.103144                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.exception

from ...exception import MetaflowException as MetaflowException

class AirflowException(metaflow.exception.MetaflowException, metaclass=type):
    def __init__(self, msg):
        ...
    ...

class NotSupportedException(metaflow.exception.MetaflowException, metaclass=type):
    ...

