######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.087619                                                            #
######################################################################################################

from __future__ import annotations


from .basic import SerializationErrorComponent as SerializationErrorComponent

def render_safely(func):
    """
    This is a decorator that can be added to any `MetaflowCardComponent.render`
    The goal is to render subcomponents safely and ensure that they are JSON serializable.
    """
    ...

