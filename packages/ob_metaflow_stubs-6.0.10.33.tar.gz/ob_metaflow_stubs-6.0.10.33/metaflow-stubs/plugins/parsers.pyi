######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.026728                                                            #
######################################################################################################

from __future__ import annotations


from .._vendor import yaml as yaml

def yaml_parser(content: str) -> dict:
    """
    Parse YAML content to a dictionary.
    
    Parameters
    ----------
    content : str
    
    Returns
    -------
    dict
    """
    ...

