######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.120218                                                            #
######################################################################################################

from __future__ import annotations

import enum
import typing
if typing.TYPE_CHECKING:
    import enum


class Spinners(enum.Enum, metaclass=enum.EnumType):
    def __new__(cls, value):
        ...
    ...

