######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.084395                                                            #
######################################################################################################

from __future__ import annotations



TYPE_CHECKING: bool

DEFAULT_BRANCH: str

def capsule_input_overrides(app_config: "AppConfig", capsule_input: dict):
    ...

