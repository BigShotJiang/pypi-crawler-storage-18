######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.1+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2025-12-23T22:20:36.114382                                                            #
######################################################################################################

from __future__ import annotations



def is_json_serializable(value):
    """
    Check if value is JSON serializable.
    """
    ...

def safe_serialize(data):
    ...

