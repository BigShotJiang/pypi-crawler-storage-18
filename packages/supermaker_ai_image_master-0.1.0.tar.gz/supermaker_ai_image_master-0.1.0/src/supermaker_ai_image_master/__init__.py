from urllib.parse import urlencode, urljoin

BASE_URL = "https://supermaker.ai/"
DEFAULT_PATH = "/image/"


def build_link(utm_source=None, utm_medium=None, utm_campaign=None, path=None):
    """
    Build a SuperMaker link with optional UTM parameters.
    """
    target_path = path or DEFAULT_PATH
    base = urljoin(BASE_URL, target_path.lstrip("/"))

    params = {
        "utm_source": utm_source,
        "utm_medium": utm_medium,
        "utm_campaign": utm_campaign,
    }
    query = {k: v for k, v in params.items() if v}
    if query:
        return f"{base}?{urlencode(query)}"
    return base


def generate_anchor(
    text="SuperMaker AI Image Master",
    rel="noopener",
    target="_blank",
    class_name=None,
    utm=None,
    path=None,
):
    """
    Generate an HTML anchor snippet pointing to SuperMaker.
    """
    utm = utm or {}
    href = build_link(
        utm_source=utm.get("utm_source"),
        utm_medium=utm.get("utm_medium"),
        utm_campaign=utm.get("utm_campaign"),
        path=path,
    )

    attrs = [
        f'href="{href}"',
        f'target="{target}"',
        f'rel="{rel}"' if rel else None,
        f'class="{class_name}"' if class_name else None,
    ]
    attr_str = " ".join(filter(None, attrs))
    return f"<a {attr_str}>{text}</a>"


__all__ = ["BASE_URL", "DEFAULT_PATH", "build_link", "generate_anchor"]
