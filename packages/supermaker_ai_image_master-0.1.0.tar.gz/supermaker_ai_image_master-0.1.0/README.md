# SuperMaker AI Image Master (Python)

构建指向 https://supermaker.ai/image/ 的外链及可嵌入 HTML 片段。

## 安装

```bash
pip install supermaker-ai-image-master
```

## 用法

```python
from supermaker_ai_image_master import build_link, generate_anchor

# 生成带 UTM 的链接
url = build_link(
    utm_source="blog",
    utm_medium="sidebar",
    utm_campaign="ai-image-master",
    # 可选：自定义路径
    # path="/image/",
)

# 生成外链 HTML
html = generate_anchor(
    text="SuperMaker AI Image Master",
    rel="sponsored noopener",
    utm={"utm_source": "blog"},
)
```

## API

- `build_link(utm_source=None, utm_medium=None, utm_campaign=None, path=None)` 返回 URL 字符串，默认指向 `/image/`。
- `generate_anchor(text="SuperMaker AI Image Master", rel="noopener", target="_blank", class_name=None, utm=None, path=None)` 返回 HTML `<a>` 字符串。

## 开发与测试

```bash
python3 -m pip install -e .
PYTHONPATH=src python3 -m unittest discover -s tests
```

## 发布（需 PyPI 凭据）

```bash
python3 -m pip install build twine
python3 -m build
python3 -m twine upload dist/*
```
