import pyodbc
import pandas as pd

class SQLServer:
    def __init__(self, host, database, user, password):
        self.conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={host};"
            f"DATABASE={database};"
            f"UID={user};"
            f"PWD={password};"
        )

    def query(self, sql: str, params=None) -> pd.DataFrame:
        with pyodbc.connect(self.conn_str) as conn:
            return pd.read_sql(sql, conn, params=params)

    def execute(self, sql: str, params=None) -> int:
        with pyodbc.connect(self.conn_str) as conn:
            cur = conn.cursor()
            cur.execute(sql, params or [])
            conn.commit()
            return cur.rowcount
