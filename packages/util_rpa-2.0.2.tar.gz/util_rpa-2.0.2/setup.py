"""Setup script for the util-rpa package."""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="util-rpa",
    version="2.0.0",
    author="Jonathan Bolo",
    author_email="jbolo.des@gmail.com",
    description="Utilidades corporativas para automatización RPA en Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",
    python_requires=">=3.9,<3.13",
    packages=find_packages(exclude=["tests*", "*.tests*"]),
    include_package_data=True,

    install_requires=[
        "pandas>=2.0,<3.0",
        "pyodbc>=5.1,<6.0",
        "python-dateutil>=2.8,<3.0",
    ],

    extras_require={
        "dev": [
            "pytest>=7,<9",
            "flake8",
            "flake8-docstrings>=1.6.0",
            "autopep8>=2.3.2",
            "mypy>=1.18.2",
            "twine>=4.0.2",
            "setuptools>=67.6.1",
            "python-dotenv>=1.0",
        ],
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: MIT License",
        "Topic :: Utilities",
    ],
)
