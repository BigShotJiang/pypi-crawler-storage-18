from __future__ import annotations
from collections.abc import Callable
from typing import Any
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.fable_library.list import (FSharpList, item, pick, length, try_pick, filter, exists, append, is_empty, head, choose, map)
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.seq import (of_list, to_list)
from .fable_modules.fable_library.seq2 import (List_distinct, List_distinctBy, List_groupBy)
from .fable_modules.fable_library.util import (get_enumerator, IEnumerator, to_iterator, IEnumerable_1, equals, safe_hash, equal_arrays, string_hash)
from .value import (ISAValue, ARCtrl_QueryModel_ISAValue__ISAValue_get_Category, ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue, ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText, ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue, ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue, ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent)

def _expr4308() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ValueCollection", None, ValueCollection)


class ValueCollection:
    def __init__(self, values: FSharpList[ISAValue]) -> None:
        self.values: FSharpList[ISAValue] = values

    def GetEnumerator(self, __unit: None=None) -> IEnumerator[ISAValue]:
        this: ValueCollection = self
        return get_enumerator(of_list(this.values))

    def __iter__(self) -> IEnumerator[ISAValue]:
        return to_iterator(self.GetEnumerator())

    def System_Collections_IEnumerable_GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: ValueCollection = self
        return get_enumerator(this)


ValueCollection_reflection = _expr4308

def ValueCollection__ctor_6ED77DA8(values: FSharpList[ISAValue]) -> ValueCollection:
    return ValueCollection(values)


def ValueCollection__ctor_78C6E8A5(values: IEnumerable_1[ISAValue]) -> ValueCollection:
    return ValueCollection__ctor_6ED77DA8(to_list(values))


def ValueCollection__Item_Z524259A4(this: ValueCollection, i: int) -> ISAValue:
    return item(i, this.values)


def ValueCollection__Item_Z721C83C5(this: ValueCollection, category: str) -> ISAValue:
    def chooser(v: ISAValue, this: Any=this, category: Any=category) -> ISAValue | None:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v).NameText == category:
            return v

        else: 
            return None


    return pick(chooser, this.values)


def ValueCollection__Item_ZDED3A0F(this: ValueCollection, category: OntologyAnnotation) -> ISAValue:
    def chooser(v: ISAValue, this: Any=this, category: Any=category) -> ISAValue | None:
        if equals(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v), category):
            return v

        else: 
            return None


    return pick(chooser, this.values)


def ValueCollection__TryItem_Z524259A4(this: ValueCollection, i: int) -> ISAValue | None:
    if length(this.values) > i:
        return item(i, this.values)

    else: 
        return None



def ValueCollection__TryItem_Z721C83C5(this: ValueCollection, category: str) -> ISAValue | None:
    def chooser(v: ISAValue, this: Any=this, category: Any=category) -> ISAValue | None:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v).NameText == category:
            return v

        else: 
            return None


    return try_pick(chooser, this.values)


def ValueCollection__TryItem_ZDED3A0F(this: ValueCollection, category: OntologyAnnotation) -> ISAValue | None:
    def chooser(v: ISAValue, this: Any=this, category: Any=category) -> ISAValue | None:
        if equals(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v), category):
            return v

        else: 
            return None


    return try_pick(chooser, this.values)


def ValueCollection__get_Values(this: ValueCollection) -> FSharpList[ISAValue]:
    return this.values


def ValueCollection__Characteristics_6DFDD678(this: ValueCollection, Name: str | None=None) -> ValueCollection:
    def predicate(v: ISAValue, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue(v)

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue(v):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(v) == name

            else: 
                return False



    return ValueCollection__ctor_6ED77DA8(filter(predicate, this.values))


def ValueCollection__Parameters_6DFDD678(this: ValueCollection, Name: str | None=None) -> ValueCollection:
    def predicate(v: ISAValue, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue(v)

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue(v):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(v) == name

            else: 
                return False



    return ValueCollection__ctor_6ED77DA8(filter(predicate, this.values))


def ValueCollection__Factors_6DFDD678(this: ValueCollection, Name: str | None=None) -> ValueCollection:
    def predicate(v: ISAValue, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue(v)

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue(v):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(v) == name

            else: 
                return False



    return ValueCollection__ctor_6ED77DA8(filter(predicate, this.values))


def ValueCollection__Components_6DFDD678(this: ValueCollection, Name: str | None=None) -> ValueCollection:
    def predicate(v: ISAValue, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent(v)

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent(v):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(v) == name

            else: 
                return False



    return ValueCollection__ctor_6ED77DA8(filter(predicate, this.values))


def ValueCollection__Filter_Z6E5A7CF3(this: ValueCollection, predicate: Callable[[OntologyAnnotation], bool]) -> ValueCollection:
    def predicate_1(v: ISAValue, this: Any=this, predicate: Any=predicate) -> bool:
        return predicate(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v))

    return ValueCollection__ctor_6ED77DA8(filter(predicate_1, this.values))


def ValueCollection__WithName_Z721C83C5(this: ValueCollection, name: str) -> ValueCollection:
    def _arrow4309(v: OntologyAnnotation, this: Any=this, name: Any=name) -> bool:
        return v.NameText == name

    return ValueCollection__Filter_Z6E5A7CF3(this, _arrow4309)


def ValueCollection__WithCategory_ZDED3A0F(this: ValueCollection, category: OntologyAnnotation) -> ValueCollection:
    def _arrow4310(y: OntologyAnnotation, this: Any=this, category: Any=category) -> bool:
        return equals(category, y)

    return ValueCollection__Filter_Z6E5A7CF3(this, _arrow4310)


def ValueCollection__Distinct(this: ValueCollection) -> ValueCollection:
    class ObjectExpr4311:
        @property
        def Equals(self) -> Callable[[ISAValue, ISAValue], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[ISAValue], int]:
            return safe_hash

    return ValueCollection__ctor_6ED77DA8(List_distinct(this.values, ObjectExpr4311()))


def ValueCollection__DistinctHeaderCategories(this: ValueCollection) -> ValueCollection:
    def projection(v: ISAValue, this: Any=this) -> OntologyAnnotation:
        return ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v)

    class ObjectExpr4312:
        @property
        def Equals(self) -> Callable[[OntologyAnnotation, OntologyAnnotation], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[OntologyAnnotation], int]:
            return safe_hash

    return ValueCollection__ctor_6ED77DA8(List_distinctBy(projection, this.values, ObjectExpr4312()))


def ValueCollection__Contains_ZDED3A0F(this: ValueCollection, category: OntologyAnnotation) -> bool:
    def predicate(v: ISAValue, this: Any=this, category: Any=category) -> bool:
        return equals(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(v), category)

    return exists(predicate, this.values)


def ValueCollection__Contains_Z721C83C5(this: ValueCollection, name: str) -> bool:
    def predicate(v: ISAValue, this: Any=this, name: Any=name) -> bool:
        return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(v) == name

    return exists(predicate, this.values)


def ValueCollection_op_Append_Z67658AE0(ps1: ValueCollection, ps2: ValueCollection) -> ValueCollection:
    return ValueCollection__ctor_6ED77DA8(append(ValueCollection__get_Values(ps1), ValueCollection__get_Values(ps2)))


def ARCtrl_QueryModel_ValueCollection__ValueCollection_get_IsEmpty(this: ValueCollection) -> bool:
    return is_empty(ValueCollection__get_Values(this))


def ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Length(this: ValueCollection) -> int:
    return length(ValueCollection__get_Values(this))


def ARCtrl_QueryModel_ValueCollection__ValueCollection_get_First(this: ValueCollection) -> ISAValue:
    return head(ValueCollection__get_Values(this))


def ARCtrl_QueryModel_ValueCollection__ValueCollection_get_TryFirst(this: ValueCollection) -> ISAValue | None:
    if ARCtrl_QueryModel_ValueCollection__ValueCollection_get_IsEmpty(this):
        return None

    else: 
        return ARCtrl_QueryModel_ValueCollection__ValueCollection_get_First(this)



def ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Last(this: ValueCollection) -> ISAValue:
    return item(ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Length(this) - 1, ValueCollection__get_Values(this))


def _expr4313() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.IOValueCollection", None, IOValueCollection)


class IOValueCollection:
    def __init__(self, values: FSharpList[Any]) -> None:
        self.values: FSharpList[Any] = values

    def GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: IOValueCollection = self
        return get_enumerator(of_list(this.values))

    def __iter__(self) -> IEnumerator[Any]:
        return to_iterator(self.GetEnumerator())

    def System_Collections_IEnumerable_GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: IOValueCollection = self
        return get_enumerator(this)


IOValueCollection_reflection = _expr4313

def IOValueCollection__ctor_Z7E9C64D(values: FSharpList[Any]) -> IOValueCollection:
    return IOValueCollection(values)


def IOValueCollection__Item_Z524259A4(this: IOValueCollection, i: int) -> Any:
    return item(i, this.values)


def IOValueCollection__Item_Z721C83C5(this: IOValueCollection, category: str) -> tuple[str, str]:
    def chooser(kv: Any, this: Any=this, category: Any=category) -> tuple[str, str] | None:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == category:
            return kv[0]

        else: 
            return None


    return pick(chooser, this.values)


def IOValueCollection__Item_43D2EC4F(this: IOValueCollection, io_key: tuple[str, str]) -> ISAValue:
    def chooser(kv: Any, this: Any=this, io_key: Any=io_key) -> ISAValue | None:
        if equal_arrays(io_key, kv[0]):
            return kv[1]

        else: 
            return None


    return pick(chooser, this.values)


def IOValueCollection__Item_ZDED3A0F(this: IOValueCollection, category: OntologyAnnotation) -> tuple[str, str]:
    def chooser(kv: Any, this: Any=this, category: Any=category) -> tuple[str, str] | None:
        if equals(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(kv[1]), category):
            return kv[0]

        else: 
            return None


    return pick(chooser, this.values)


def IOValueCollection__WithInput_Z721C83C5(this: IOValueCollection, inp: str) -> ValueCollection:
    def chooser(kv: Any, this: Any=this, inp: Any=inp) -> ISAValue | None:
        if kv[0][0] == inp:
            return kv[1]

        else: 
            return None


    return ValueCollection__ctor_6ED77DA8(choose(chooser, this.values))


def IOValueCollection__WithOutput_Z721C83C5(this: IOValueCollection, inp: str) -> ValueCollection:
    def chooser(kv: Any, this: Any=this, inp: Any=inp) -> ISAValue | None:
        if kv[0][1] == inp:
            return kv[1]

        else: 
            return None


    return ValueCollection__ctor_6ED77DA8(choose(chooser, this.values))


def IOValueCollection__Values_6DFDD678(this: IOValueCollection, Name: str | None=None) -> ValueCollection:
    def chooser(kv: Any, this: Any=this, Name: Any=Name) -> ISAValue | None:
        if Name is None:
            return kv[1]

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == name:
                return kv[1]

            else: 
                return None



    return ValueCollection__ctor_6ED77DA8(choose(chooser, this.values))


def IOValueCollection__Characteristics_6DFDD678(this: IOValueCollection, Name: str | None=None) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue(kv[1])

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue(kv[1]):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == name

            else: 
                return False



    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__Parameters_6DFDD678(this: IOValueCollection, Name: str | None=None) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue(kv[1])

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue(kv[1]):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == name

            else: 
                return False



    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__Factors_6DFDD678(this: IOValueCollection, Name: str | None=None) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue(kv[1])

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue(kv[1]):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == name

            else: 
                return False



    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__Components_6DFDD678(this: IOValueCollection, Name: str | None=None) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, Name: Any=Name) -> bool:
        if Name is None:
            return ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent(kv[1])

        else: 
            name: str = Name
            if ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent(kv[1]):
                return ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(kv[1]) == name

            else: 
                return False



    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__WithCategory_ZDED3A0F(this: IOValueCollection, category: OntologyAnnotation) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, category: Any=category) -> bool:
        return equals(ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(kv[1]), category)

    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__WithName_Z721C83C5(this: IOValueCollection, name: str) -> IOValueCollection:
    def predicate(kv: Any, this: Any=this, name: Any=name) -> bool:
        return ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(kv[1]).NameText == name

    return IOValueCollection__ctor_Z7E9C64D(filter(predicate, this.values))


def IOValueCollection__get_GroupBySource(this: IOValueCollection) -> FSharpList[tuple[str, FSharpList[tuple[str, ISAValue]]]]:
    def mapping_1(tupled_arg: tuple[str, FSharpList[Any]], this: Any=this) -> tuple[str, FSharpList[tuple[str, ISAValue]]]:
        def mapping(kv_1: Any, tupled_arg: Any=tupled_arg) -> tuple[str, ISAValue]:
            return (kv_1[0][1], kv_1[1])

        return (tupled_arg[0], map(mapping, tupled_arg[1]))

    def projection(kv: Any, this: Any=this) -> str:
        return kv[0][0]

    class ObjectExpr4315:
        @property
        def Equals(self) -> Callable[[str, str], bool]:
            def _arrow4314(x: str, y: str) -> bool:
                return x == y

            return _arrow4314

        @property
        def GetHashCode(self) -> Callable[[str], int]:
            return string_hash

    return map(mapping_1, List_groupBy(projection, this.values, ObjectExpr4315()))


def IOValueCollection__get_GroupBySink(this: IOValueCollection) -> FSharpList[tuple[str, FSharpList[tuple[str, ISAValue]]]]:
    def mapping_1(tupled_arg: tuple[str, FSharpList[Any]], this: Any=this) -> tuple[str, FSharpList[tuple[str, ISAValue]]]:
        def mapping(kv_1: Any, tupled_arg: Any=tupled_arg) -> tuple[str, ISAValue]:
            return (kv_1[0][0], kv_1[1])

        return (tupled_arg[0], map(mapping, tupled_arg[1]))

    def projection(kv: Any, this: Any=this) -> str:
        return kv[0][1]

    class ObjectExpr4317:
        @property
        def Equals(self) -> Callable[[str, str], bool]:
            def _arrow4316(x: str, y: str) -> bool:
                return x == y

            return _arrow4316

        @property
        def GetHashCode(self) -> Callable[[str], int]:
            return string_hash

    return map(mapping_1, List_groupBy(projection, this.values, ObjectExpr4317()))


def ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_Length(this: IOValueCollection) -> int:
    return ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Length(IOValueCollection__Values_6DFDD678(this))


def ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_First(this: IOValueCollection) -> ISAValue:
    return ARCtrl_QueryModel_ValueCollection__ValueCollection_get_First(IOValueCollection__Values_6DFDD678(this))


def ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_Last(this: IOValueCollection) -> ISAValue:
    return ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Last(IOValueCollection__Values_6DFDD678(this))


__all__ = ["ValueCollection_reflection", "ValueCollection__ctor_78C6E8A5", "ValueCollection__Item_Z524259A4", "ValueCollection__Item_Z721C83C5", "ValueCollection__Item_ZDED3A0F", "ValueCollection__TryItem_Z524259A4", "ValueCollection__TryItem_Z721C83C5", "ValueCollection__TryItem_ZDED3A0F", "ValueCollection__get_Values", "ValueCollection__Characteristics_6DFDD678", "ValueCollection__Parameters_6DFDD678", "ValueCollection__Factors_6DFDD678", "ValueCollection__Components_6DFDD678", "ValueCollection__Filter_Z6E5A7CF3", "ValueCollection__WithName_Z721C83C5", "ValueCollection__WithCategory_ZDED3A0F", "ValueCollection__Distinct", "ValueCollection__DistinctHeaderCategories", "ValueCollection__Contains_ZDED3A0F", "ValueCollection__Contains_Z721C83C5", "ValueCollection_op_Append_Z67658AE0", "ARCtrl_QueryModel_ValueCollection__ValueCollection_get_IsEmpty", "ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Length", "ARCtrl_QueryModel_ValueCollection__ValueCollection_get_First", "ARCtrl_QueryModel_ValueCollection__ValueCollection_get_TryFirst", "ARCtrl_QueryModel_ValueCollection__ValueCollection_get_Last", "IOValueCollection_reflection", "IOValueCollection__Item_Z524259A4", "IOValueCollection__Item_Z721C83C5", "IOValueCollection__Item_43D2EC4F", "IOValueCollection__Item_ZDED3A0F", "IOValueCollection__WithInput_Z721C83C5", "IOValueCollection__WithOutput_Z721C83C5", "IOValueCollection__Values_6DFDD678", "IOValueCollection__Characteristics_6DFDD678", "IOValueCollection__Parameters_6DFDD678", "IOValueCollection__Factors_6DFDD678", "IOValueCollection__Components_6DFDD678", "IOValueCollection__WithCategory_ZDED3A0F", "IOValueCollection__WithName_Z721C83C5", "IOValueCollection__get_GroupBySource", "IOValueCollection__get_GroupBySink", "ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_Length", "ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_First", "ARCtrl_QueryModel_IOValueCollection__IOValueCollection_get_Last"]

