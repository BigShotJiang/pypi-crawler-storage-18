from __future__ import annotations
from typing import Any
from .errors import (PersonHasNoLastNameException, PersonHasNoFirstNameException, PersonHasNoMidInitialsException, PersonHasNoEMailException, PersonHasNoPhoneException, PersonHasNoFaxException, PersonHasNoAddressException, PersonHasNoAffiliationException)
from .fable_modules.arctrl_core.person import Person
from .fable_modules.fable_library.result import FSharpResult_2

def last_name(p: Person) -> str:
    match_value: str | None = p.LastName
    if match_value is None:
        raise PersonHasNoLastNameException()

    else: 
        return match_value



def first_name(p: Person) -> str:
    match_value: str | None = p.FirstName
    if match_value is None:
        raise PersonHasNoFirstNameException()

    else: 
        return match_value



def mid_initials(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.MidInitials
    if match_value is None:
        raise PersonHasNoMidInitialsException()

    else: 
        return FSharpResult_2(0, match_value)



def email(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.EMail
    if match_value is None:
        raise PersonHasNoEMailException()

    else: 
        return FSharpResult_2(0, match_value)



def phone(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.Phone
    if match_value is None:
        raise PersonHasNoPhoneException()

    else: 
        return FSharpResult_2(0, match_value)



def fax(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.Fax
    if match_value is None:
        raise PersonHasNoFaxException()

    else: 
        return FSharpResult_2(0, match_value)



def address(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.Address
    if match_value is None:
        raise PersonHasNoAddressException()

    else: 
        return FSharpResult_2(0, match_value)



def affiliation(p: Person) -> FSharpResult_2[str, Any]:
    match_value: str | None = p.Affiliation
    if match_value is None:
        raise PersonHasNoAffiliationException()

    else: 
        return FSharpResult_2(0, match_value)



__all__ = ["last_name", "first_name", "mid_initials", "email", "phone", "fax", "address", "affiliation"]

