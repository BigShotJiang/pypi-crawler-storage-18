from __future__ import annotations
from typing import Any
from .arc_tables import (ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8, QNode, ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8, ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static, ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static)
from .errors import (StudyHasNoTitleException, StudyHasNoDescriptionException, StudyHasNoSubmissionDateException, StudyHasNoPublicReleaseDateException, StudyHasNoPublicationsException, StudyHasNoContactsException, StudyHasNoDesignDescriptorsException, StudyHasNoAssaysException)
from .fable_modules.arctrl_core.arc_types import (ArcStudy, ArcAssay)
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_core.person import Person
from .fable_modules.arctrl_core.publication import Publication
from .fable_modules.arctrl_core.Table.arc_table import ArcTable
from .fable_modules.arctrl_core.Table.composite_header import IOType
from .fable_modules.fable_library.list import FSharpList
from .fable_modules.fable_library.types import Array

def ARCtrl_ArcStudy__ArcStudy_Protocol_Z721C83C5(this: ArcStudy, sheet_name: str) -> ArcTable:
    return this.GetTable(sheet_name)


def ARCtrl_ArcStudy__ArcStudy_Protocol_Z524259A4(this: ArcStudy, index: int) -> ArcTable:
    return this.GetTableAt(index)


def ARCtrl_ArcStudy__ArcStudy_getRootInputs_Static_1680536E(study: ArcStudy) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8(study)


def ARCtrl_ArcStudy__ArcStudy_getFinalOutputs_Static_1680536E(study: ArcStudy) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8(study)


def ARCtrl_ArcStudy__ArcStudy_getRootInputOf_Static(study: ArcStudy, sample: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, study: Any=study, sample: Any=sample) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, sample, study)


def ARCtrl_ArcStudy__ArcStudy_getFinalOutputsOf_Static(study: ArcStudy, sample: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, study: Any=study, sample: Any=sample) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, sample, study)


def Study_identifier(s: ArcStudy) -> str:
    return s.Identifier


def Study_title(s: ArcStudy) -> str:
    match_value: str | None = s.Title
    if match_value is None:
        raise StudyHasNoTitleException()

    else: 
        return match_value



def Study_description(s: ArcStudy) -> str:
    match_value: str | None = s.Description
    if match_value is None:
        raise StudyHasNoDescriptionException()

    else: 
        return match_value



def Study_submissionDate(s: ArcStudy) -> str:
    match_value: str | None = s.SubmissionDate
    if match_value is None:
        raise StudyHasNoSubmissionDateException()

    else: 
        return match_value



def Study_publicReleaseDate(s: ArcStudy) -> str:
    match_value: str | None = s.PublicReleaseDate
    if match_value is None:
        raise StudyHasNoPublicReleaseDateException()

    else: 
        return match_value



def Study_publications(s: ArcStudy) -> Array[Publication]:
    match_value: Array[Publication] = s.Publications
    if len(match_value) == 0:
        raise StudyHasNoPublicationsException()

    else: 
        return match_value



def Study_contacts(s: ArcStudy) -> Array[Person]:
    match_value: Array[Person] = s.Contacts
    if len(match_value) == 0:
        raise StudyHasNoContactsException()

    else: 
        return match_value



def Study_designDescriptors(s: ArcStudy) -> Array[OntologyAnnotation]:
    match_value: Array[OntologyAnnotation] = s.StudyDesignDescriptors
    if len(match_value) == 0:
        raise StudyHasNoDesignDescriptorsException()

    else: 
        return match_value



def Study_assays(s: ArcStudy) -> Array[ArcAssay]:
    if len(s.RegisteredAssays) == 0:
        raise StudyHasNoAssaysException()

    else: 
        return s.RegisteredAssays



__all__ = ["ARCtrl_ArcStudy__ArcStudy_Protocol_Z721C83C5", "ARCtrl_ArcStudy__ArcStudy_Protocol_Z524259A4", "ARCtrl_ArcStudy__ArcStudy_getRootInputs_Static_1680536E", "ARCtrl_ArcStudy__ArcStudy_getFinalOutputs_Static_1680536E", "ARCtrl_ArcStudy__ArcStudy_getRootInputOf_Static", "ARCtrl_ArcStudy__ArcStudy_getFinalOutputsOf_Static", "Study_identifier", "Study_title", "Study_description", "Study_submissionDate", "Study_publicReleaseDate", "Study_publications", "Study_contacts", "Study_designDescriptors", "Study_assays"]

