from __future__ import annotations
from ..fable_modules.arctrl_rocrate.ldcontext import LDContext
from ..fable_modules.arctrl_rocrate.rocrate_context import (init_bioschemas_context, init_v1_2)

object_of: str = "objectOf"

result_of: str = "resultOf"

context: LDContext = LDContext(None, [init_bioschemas_context(), init_v1_2()])

__all__ = ["object_of", "result_of", "context"]

