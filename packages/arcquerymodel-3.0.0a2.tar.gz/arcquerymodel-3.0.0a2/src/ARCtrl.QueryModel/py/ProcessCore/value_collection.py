from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.seq import (pick, try_pick, exists, map)
from ..fable_modules.fable_library.seq2 import group_by
from ..fable_modules.fable_library.types import Array
from ..fable_modules.fable_library.util import (equals, get_enumerator, IEnumerator, to_iterator, equal_arrays, IEnumerable_1, string_hash)
from ..resize_array import (filter, distinct, distinct_by, append, choose)
from .property_value import (QPropertyValue, QPropertyValue__get_Category, QPropertyValue__get_IsCharacteristic, QPropertyValue__get_NameText, QPropertyValue__get_IsParameter, QPropertyValue__get_IsFactor, QPropertyValue__get_IsComponent)

def _expr4375() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.QValueCollection", None, QValueCollection)


class QValueCollection:
    def __init__(self, values: Array[QPropertyValue]) -> None:
        self.values: Array[QPropertyValue] = values

    def Item(self, i: int) -> QPropertyValue:
        this: QValueCollection = self
        return this.values[i]

    def GetAt(self, i: int) -> QPropertyValue:
        this: QValueCollection = self
        return this.values[i]

    def GetByName(self, category: str) -> QPropertyValue:
        this: QValueCollection = self
        def chooser(v: QPropertyValue) -> QPropertyValue | None:
            if QPropertyValue__get_Category(v).NameText == category:
                return v

            else: 
                return None


        return pick(chooser, this.values)

    def GetByCategory(self, category: OntologyAnnotation) -> QPropertyValue:
        this: QValueCollection = self
        def chooser(v: QPropertyValue) -> QPropertyValue | None:
            if equals(QPropertyValue__get_Category(v), category):
                return v

            else: 
                return None


        return pick(chooser, this.values)

    def TryGetAt(self, i: int) -> QPropertyValue | None:
        this: QValueCollection = self
        return this.values[i] if (len(this.values) > i) else None

    def TryGetByName(self, category: str) -> QPropertyValue | None:
        this: QValueCollection = self
        def chooser(v: QPropertyValue) -> QPropertyValue | None:
            if QPropertyValue__get_Category(v).NameText == category:
                return v

            else: 
                return None


        return try_pick(chooser, this.values)

    def TryGetByCategory(self, category: OntologyAnnotation) -> QPropertyValue | None:
        this: QValueCollection = self
        def chooser(v: QPropertyValue) -> QPropertyValue | None:
            if equals(QPropertyValue__get_Category(v), category):
                return v

            else: 
                return None


        return try_pick(chooser, this.values)

    @property
    def Values(self, __unit: None=None) -> Array[QPropertyValue]:
        this: QValueCollection = self
        return this.values

    def Characteristics(self, Name: str | None=None) -> QValueCollection:
        this: QValueCollection = self
        def f(v: QPropertyValue) -> bool:
            if Name is None:
                return QPropertyValue__get_IsCharacteristic(v)

            else: 
                name: str = Name
                if QPropertyValue__get_IsCharacteristic(v):
                    return QPropertyValue__get_NameText(v) == name

                else: 
                    return False



        return QValueCollection(filter(f, this.values))

    def Parameters(self, Name: str | None=None) -> QValueCollection:
        this: QValueCollection = self
        def f(v: QPropertyValue) -> bool:
            if Name is None:
                return QPropertyValue__get_IsParameter(v)

            else: 
                name: str = Name
                if QPropertyValue__get_IsParameter(v):
                    return QPropertyValue__get_NameText(v) == name

                else: 
                    return False



        return QValueCollection(filter(f, this.values))

    def Factors(self, Name: str | None=None) -> QValueCollection:
        this: QValueCollection = self
        def f(v: QPropertyValue) -> bool:
            if Name is None:
                return QPropertyValue__get_IsFactor(v)

            else: 
                name: str = Name
                if QPropertyValue__get_IsFactor(v):
                    return QPropertyValue__get_NameText(v) == name

                else: 
                    return False



        return QValueCollection(filter(f, this.values))

    def Components(self, Name: str | None=None) -> QValueCollection:
        this: QValueCollection = self
        def f(v: QPropertyValue) -> bool:
            if Name is None:
                return QPropertyValue__get_IsComponent(v)

            else: 
                name: str = Name
                if QPropertyValue__get_IsComponent(v):
                    return QPropertyValue__get_NameText(v) == name

                else: 
                    return False



        return QValueCollection(filter(f, this.values))

    def Filter(self, predicate: Callable[[OntologyAnnotation], bool]) -> QValueCollection:
        this: QValueCollection = self
        def f(v: QPropertyValue) -> bool:
            return predicate(QPropertyValue__get_Category(v))

        return QValueCollection(filter(f, this.values))

    def WithName(self, name: str) -> QValueCollection:
        this: QValueCollection = self
        def _arrow4373(v: OntologyAnnotation) -> bool:
            return v.NameText == name

        return this.Filter(_arrow4373)

    def WithCategory(self, category: OntologyAnnotation) -> QValueCollection:
        this: QValueCollection = self
        def _arrow4374(y: OntologyAnnotation) -> bool:
            return equals(category, y)

        return this.Filter(_arrow4374)

    def Distinct(self, __unit: None=None) -> QValueCollection:
        this: QValueCollection = self
        return QValueCollection(distinct(this.values))

    def DistinctHeaderCategories(self, __unit: None=None) -> QValueCollection:
        this: QValueCollection = self
        return QValueCollection(distinct_by(QPropertyValue__get_Category, this.values))

    def ContainsByCategory(self, category: OntologyAnnotation) -> bool:
        this: QValueCollection = self
        def predicate(v: QPropertyValue) -> bool:
            return equals(QPropertyValue__get_Category(v), category)

        return exists(predicate, this.values)

    def ContainsByName(self, name: str) -> bool:
        this: QValueCollection = self
        def predicate(v: QPropertyValue) -> bool:
            return QPropertyValue__get_NameText(v) == name

        return exists(predicate, this.values)

    @staticmethod
    def op_append(ps1: QValueCollection, ps2: QValueCollection) -> QValueCollection:
        return QValueCollection(append(ps1.Values, ps2.Values))

    @property
    def IsEmpty(self, __unit: None=None) -> bool:
        this: QValueCollection = self
        return len(this.Values) == 0

    @property
    def Length(self, __unit: None=None) -> int:
        this: QValueCollection = self
        return len(this.Values)

    @property
    def First(self, __unit: None=None) -> QPropertyValue:
        this: QValueCollection = self
        return this.Values[0]

    @property
    def TryFirst(self, __unit: None=None) -> QPropertyValue | None:
        this: QValueCollection = self
        return None if this.IsEmpty else this.First

    @property
    def Last(self, __unit: None=None) -> QPropertyValue:
        this: QValueCollection = self
        return this.Values[this.Length - 1]

    def GetEnumerator(self, __unit: None=None) -> IEnumerator[QPropertyValue]:
        this: QValueCollection = self
        return get_enumerator(this.values)

    def __iter__(self) -> IEnumerator[QPropertyValue]:
        return to_iterator(self.GetEnumerator())

    def System_Collections_IEnumerable_GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: QValueCollection = self
        return get_enumerator(this)


QValueCollection_reflection = _expr4375

def QValueCollection__ctor_10FDC500(values: Array[QPropertyValue]) -> QValueCollection:
    return QValueCollection(values)


def _expr4380() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.IOQValueCollection", None, IOQValueCollection)


class IOQValueCollection:
    def __init__(self, values: Array[Any]) -> None:
        self.values: Array[Any] = values

    def GetAt(self, i: int) -> Any:
        this: IOQValueCollection = self
        return this.values[i]

    def GetByName(self, name: str) -> tuple[str, str]:
        this: IOQValueCollection = self
        def chooser(kv: Any) -> tuple[str, str] | None:
            if QPropertyValue__get_NameText(kv[1]) == name:
                return kv[0]

            else: 
                return None


        return pick(chooser, this.values)

    def GetByIOName(self, io_key: tuple[str, str]) -> QPropertyValue:
        this: IOQValueCollection = self
        def chooser(kv: Any) -> QPropertyValue | None:
            if equal_arrays(io_key, kv[0]):
                return kv[1]

            else: 
                return None


        return pick(chooser, this.values)

    def GetByCategory(self, category: OntologyAnnotation) -> tuple[str, str]:
        this: IOQValueCollection = self
        def chooser(kv: Any) -> tuple[str, str] | None:
            if equals(QPropertyValue__get_Category(kv[1]), category):
                return kv[0]

            else: 
                return None


        return pick(chooser, this.values)

    def WithInput(self, inp: str) -> QValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> QPropertyValue | None:
            if kv[0][0] == inp:
                return kv[1]

            else: 
                return None


        return QValueCollection(choose(f, this.values))

    def WithOutput(self, inp: str) -> QValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> QPropertyValue | None:
            if kv[0][1] == inp:
                return kv[1]

            else: 
                return None


        return QValueCollection(choose(f, this.values))

    def Values(self, Name: str | None=None) -> QValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> QPropertyValue | None:
            if Name is None:
                return kv[1]

            else: 
                name: str = Name
                if QPropertyValue__get_NameText(kv[1]) == name:
                    return kv[1]

                else: 
                    return None



        return QValueCollection(choose(f, this.values))

    def Characteristics(self, Name: str | None=None) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            if Name is None:
                return QPropertyValue__get_IsCharacteristic(kv[1])

            else: 
                name: str = Name
                if QPropertyValue__get_IsCharacteristic(kv[1]):
                    return QPropertyValue__get_NameText(kv[1]) == name

                else: 
                    return False



        return IOQValueCollection(filter(f, this.values))

    def Parameters(self, Name: str | None=None) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            if Name is None:
                return QPropertyValue__get_IsParameter(kv[1])

            else: 
                name: str = Name
                if QPropertyValue__get_IsParameter(kv[1]):
                    return QPropertyValue__get_NameText(kv[1]) == name

                else: 
                    return False



        return IOQValueCollection(filter(f, this.values))

    def Factors(self, Name: str | None=None) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            if Name is None:
                return QPropertyValue__get_IsFactor(kv[1])

            else: 
                name: str = Name
                if QPropertyValue__get_IsFactor(kv[1]):
                    return QPropertyValue__get_NameText(kv[1]) == name

                else: 
                    return False



        return IOQValueCollection(filter(f, this.values))

    def Components(self, Name: str | None=None) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            if Name is None:
                return QPropertyValue__get_IsComponent(kv[1])

            else: 
                name: str = Name
                if QPropertyValue__get_IsComponent(kv[1]):
                    return QPropertyValue__get_NameText(kv[1]) == name

                else: 
                    return False



        return IOQValueCollection(filter(f, this.values))

    def WithCategory(self, category: OntologyAnnotation) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            return equals(QPropertyValue__get_Category(kv[1]), category)

        return IOQValueCollection(filter(f, this.values))

    def WithName(self, name: str) -> IOQValueCollection:
        this: IOQValueCollection = self
        def f(kv: Any) -> bool:
            return QPropertyValue__get_Category(kv[1]).NameText == name

        return IOQValueCollection(filter(f, this.values))

    @property
    def GroupBySource(self, __unit: None=None) -> IEnumerable_1[tuple[str, IEnumerable_1[tuple[str, QPropertyValue]]]]:
        this: IOQValueCollection = self
        def mapping_1(tupled_arg: tuple[str, IEnumerable_1[Any]]) -> tuple[str, IEnumerable_1[tuple[str, QPropertyValue]]]:
            def mapping(kv_1: Any, tupled_arg: Any=tupled_arg) -> tuple[str, QPropertyValue]:
                return (kv_1[0][1], kv_1[1])

            return (tupled_arg[0], map(mapping, tupled_arg[1]))

        def projection(kv: Any) -> str:
            return kv[0][0]

        class ObjectExpr4377:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4376(x: str, y: str) -> bool:
                    return x == y

                return _arrow4376

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return map(mapping_1, group_by(projection, this.values, ObjectExpr4377()))

    @property
    def GroupBySink(self, __unit: None=None) -> IEnumerable_1[tuple[str, IEnumerable_1[tuple[str, QPropertyValue]]]]:
        this: IOQValueCollection = self
        def mapping_1(tupled_arg: tuple[str, IEnumerable_1[Any]]) -> tuple[str, IEnumerable_1[tuple[str, QPropertyValue]]]:
            def mapping(kv_1: Any, tupled_arg: Any=tupled_arg) -> tuple[str, QPropertyValue]:
                return (kv_1[0][0], kv_1[1])

            return (tupled_arg[0], map(mapping, tupled_arg[1]))

        def projection(kv: Any) -> str:
            return kv[0][1]

        class ObjectExpr4379:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4378(x: str, y: str) -> bool:
                    return x == y

                return _arrow4378

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return map(mapping_1, group_by(projection, this.values, ObjectExpr4379()))

    def GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: IOQValueCollection = self
        return get_enumerator(this.values)

    def __iter__(self) -> IEnumerator[Any]:
        return to_iterator(self.GetEnumerator())

    def System_Collections_IEnumerable_GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: IOQValueCollection = self
        return get_enumerator(this)


IOQValueCollection_reflection = _expr4380

def IOQValueCollection__ctor_DA7D5B(values: Array[Any]) -> IOQValueCollection:
    return IOQValueCollection(values)


def ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_Length(this: IOQValueCollection) -> int:
    return this.Values().Length


def ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_First(this: IOQValueCollection) -> QPropertyValue:
    return this.Values().First


def ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_Last(this: IOQValueCollection) -> QPropertyValue:
    return this.Values().Last


__all__ = ["QValueCollection_reflection", "IOQValueCollection_reflection", "ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_Length", "ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_First", "ARCtrl_QueryModel_ProcessCore_IOQValueCollection__IOQValueCollection_get_Last"]

