from __future__ import annotations
from collections.abc import Callable
from typing import (Any, TypeVar)
from .knowledge_graph import (object_of, result_of)
from .property_value import (QPropertyValue, QPropertyValue__ctor_1118F6CB, QPropertyValue__get_IsCharacteristic, QPropertyValue__get_IsFactor)
from .value_collection import QValueCollection
from ..fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from ..fable_modules.arctrl_rocrate.ldcontext import LDContext
from ..fable_modules.arctrl_rocrate.ldobject import (LDNode, LDRef, LDGraph, LDGraph_reflection, LDNode_reflection)
from ..fable_modules.arctrl_rocrate.LDTypes.file import LDFile
from ..fable_modules.arctrl_rocrate.LDTypes.lab_process import LDLabProcess
from ..fable_modules.arctrl_rocrate.LDTypes.lab_protocol import LDLabProtocol
from ..fable_modules.arctrl_rocrate.LDTypes.sample import LDSample
from ..fable_modules.arctrl_rocrate.rocrate_context import (init_bioschemas_context, init_v1_2)
from ..fable_modules.fable_library.map_util import (try_get_value, get_item_from_dict, add_to_dict, add_to_set)
from ..fable_modules.fable_library.mutable_set import HashSet
from ..fable_modules.fable_library.option import (default_arg, bind, value as value_3, map)
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.seq import (is_empty, exists, find, iterate)
from ..fable_modules.fable_library.seq2 import (distinct, distinct_by)
from ..fable_modules.fable_library.string_ import (to_fail, printf)
from ..fable_modules.fable_library.types import (Array, FSharpRef)
from ..fable_modules.fable_library.util import (equals, safe_hash, structural_hash, ignore, string_hash)
from ..resize_array import (iter, choose, collect, append, singleton, filter, map as map_1)

_A_ = TypeVar("_A_")

_A = TypeVar("_A")

def _expr4384() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.ProcessSequence", None, ProcessSequence)


class ProcessSequence:
    def __init__(self, processes: Array[QLabProcess]) -> None:
        self.processes: Array[QLabProcess] = processes
        def _arrow4383(__unit: None=None) -> Any:
            d: Any = dict([])
            def f(p: QLabProcess) -> None:
                add_to_dict(d, p.Id, p)

            iter(f, self.processes)
            return d

        self._processMap: Any = _arrow4383()

    @property
    def Processes(self, __unit: None=None) -> Array[QLabProcess]:
        this: ProcessSequence = self
        return this.processes

    def HasProcess(self, id: str) -> Any:
        this: ProcessSequence = self
        return this._processMap.__contains__(id)

    def TryGetProcess(self, id: str) -> QLabProcess | None:
        this: ProcessSequence = self
        match_value: tuple[bool, QLabProcess]
        out_arg: QLabProcess = None
        def _arrow4381(__unit: None=None) -> QLabProcess:
            return out_arg

        def _arrow4382(v: QLabProcess) -> None:
            nonlocal out_arg
            out_arg = v

        match_value = (try_get_value(this._processMap, id, FSharpRef(_arrow4381, _arrow4382)), out_arg)
        return match_value[1] if match_value[0] else None

    def GetProcess(self, id: str) -> QLabProcess:
        this: ProcessSequence = self
        return get_item_from_dict(this._processMap, id)


ProcessSequence_reflection = _expr4384

def ProcessSequence__ctor_42F461E8(processes: Array[QLabProcess]) -> ProcessSequence:
    return ProcessSequence(processes)


def _expr4422() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.QGraph", None, QGraph, LDGraph_reflection())


class QGraph(LDGraph):
    def __init__(self, in_graph: LDGraph) -> None:
        super().__init__(in_graph.Id, in_graph.Nodes, in_graph.TryGetContext())
        this: FSharpRef[QGraph] = FSharpRef(None)
        this.contents = self
        def _arrow4419(__unit: None=None) -> LDContext:
            match_value: LDContext | None = this.contents.TryGetContext()
            return LDContext(None, [init_bioschemas_context(), init_v1_2()]) if (match_value is None) else match_value

        self.context: LDContext = _arrow4419()
        self.init_004052: int = 1
        def action_2(n: LDNode) -> None:
            if LDLabProcess.validate(n, self.context):
                inputs: Array[LDNode] = LDLabProcess.get_objects(n, this.contents, self.context)
                outputs: Array[LDNode] = LDLabProcess.get_results(n, this.contents, self.context)
                def action(input_node: LDNode, n: Any=n) -> None:
                    object_ofs: Array[Any] = input_node.GetPropertyValues(object_of, None, self.context)
                    (object_ofs.append(LDRef(n.Id)))
                    class ObjectExpr4420:
                        @property
                        def Equals(self) -> Callable[[Any, Any], bool]:
                            return equals

                        @property
                        def GetHashCode(self) -> Callable[[Any], int]:
                            return structural_hash

                    v: Array[Any] = list(distinct(object_ofs, ObjectExpr4420()))
                    input_node.SetProperty(object_of, v, self.context)

                iterate(action, inputs)
                def action_1(output_node: LDNode, n: Any=n) -> None:
                    result_ofs: Array[Any] = output_node.GetPropertyValues(result_of, None, self.context)
                    (result_ofs.append(LDRef(n.Id)))
                    class ObjectExpr4421:
                        @property
                        def Equals(self) -> Callable[[Any, Any], bool]:
                            return equals

                        @property
                        def GetHashCode(self) -> Callable[[Any], int]:
                            return structural_hash

                    v_1: Array[Any] = list(distinct(result_ofs, ObjectExpr4421()))
                    output_node.SetProperty(result_of, v_1, self.context)

                iterate(action_1, outputs)


        iterate(action_2, this.contents.Nodes)

    @property
    def ProcessSequence(self, __unit: None=None) -> ProcessSequence:
        this: QGraph = self
        def f(n: LDNode) -> QLabProcess | None:
            if LDLabProcess.validate(n, this.context):
                return QLabProcess(n, this)

            else: 
                return None


        return ProcessSequence(choose(f, this.Nodes))

    @property
    def Context(self, __unit: None=None) -> LDContext:
        this: QGraph = self
        return this.context

    @Context.setter
    def Context(self, v: LDContext) -> None:
        this: QGraph = self
        this.context = v

    @staticmethod
    def node_is_root(node: IONode, ps: ProcessSequence | None=None) -> bool:
        if ps is None:
            return is_empty(node.ResultOf())

        else: 
            ps_1: ProcessSequence = ps
            def predicate(p: LDNode) -> bool:
                return ps_1.HasProcess(p.Id)

            return not exists(predicate, node.ResultOf())


    @staticmethod
    def node_is_final(node: IONode, ps: ProcessSequence | None=None) -> bool:
        if ps is None:
            return is_empty(node.ObjectOf())

        else: 
            ps_1: ProcessSequence = ps
            def predicate(p: LDNode) -> bool:
                return ps_1.HasProcess(p.Id)

            return not exists(predicate, node.ObjectOf())


    @staticmethod
    def get_nodes(graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        if ps is None:
            def f_1(n: LDNode) -> IONode | None:
                if LDSample.validate(n, graph.Context):
                    return IONode(n, graph)

                elif LDFile.validate(n, graph.Context):
                    return IONode(n, graph)

                else: 
                    return None


            return choose(f_1, graph.Nodes)

        else: 
            ps_1: ProcessSequence = ps
            def f(p: QLabProcess) -> Array[IONode]:
                return append(p.Inputs, p.Outputs)

            class ObjectExpr4385:
                @property
                def Equals(self) -> Callable[[IONode, IONode], bool]:
                    return equals

                @property
                def GetHashCode(self) -> Callable[[IONode], int]:
                    return safe_hash

            return list(distinct(collect(f, ps_1.Processes), ObjectExpr4385()))


    @staticmethod
    def collect_backwards(node: IONode, f: Callable[[QLabProcess], Array[_A]], graph: QGraph, ps: ProcessSequence | None=None) -> Array[Any]:
        ps_1: ProcessSequence = default_arg(ps, graph.ProcessSequence)
        class ObjectExpr4386:
            @property
            def Equals(self) -> Callable[[IONode, IONode], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[IONode], int]:
                return safe_hash

        result_nodes: Any = HashSet([], ObjectExpr4386())
        class ObjectExpr4387:
            @property
            def Equals(self) -> Callable[[_A_, _A_], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[_A_], int]:
                return structural_hash

        result: Any = HashSet([], ObjectExpr4387())
        def loop(to_check_mut: Array[IONode]) -> Array[_A]:
            while True:
                (to_check,) = (to_check_mut,)
                if len(to_check) == 0:
                    return list(result)

                else: 
                    def f_3(n: IONode, to_check: Any=to_check) -> Array[IONode]:
                        if n in result_nodes:
                            return []

                        else: 
                            ignore(add_to_set(n, result_nodes))
                            def f_2(pn: LDNode, n: Any=n) -> Array[IONode]:
                                if ps_1.HasProcess(pn.Id):
                                    p: QLabProcess = ps_1.GetProcess(pn.Id)
                                    def f_1(r: _A | None=None, pn: Any=pn) -> None:
                                        ignore(add_to_set(r, result))

                                    iter(f_1, f(p))
                                    return p.Inputs

                                else: 
                                    return []


                            return collect(f_2, n.ResultOf())


                    to_check_mut = collect(f_3, to_check)
                    continue

                break

        return loop([node])

    @staticmethod
    def collect_forwards(node: IONode, f: Callable[[QLabProcess], Array[_A]], graph: QGraph, ps: ProcessSequence | None=None) -> Array[Any]:
        ps_1: ProcessSequence = default_arg(ps, graph.ProcessSequence)
        class ObjectExpr4388:
            @property
            def Equals(self) -> Callable[[IONode, IONode], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[IONode], int]:
                return safe_hash

        result_nodes: Any = HashSet([], ObjectExpr4388())
        class ObjectExpr4389:
            @property
            def Equals(self) -> Callable[[_A_, _A_], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[_A_], int]:
                return structural_hash

        result: Any = HashSet([], ObjectExpr4389())
        def loop(to_check_mut: Array[IONode]) -> Array[_A]:
            while True:
                (to_check,) = (to_check_mut,)
                if len(to_check) == 0:
                    return list(result)

                else: 
                    def f_3(n: IONode, to_check: Any=to_check) -> Array[IONode]:
                        if n in result_nodes:
                            return []

                        else: 
                            ignore(add_to_set(n, result_nodes))
                            def f_2(pn: LDNode, n: Any=n) -> Array[IONode]:
                                if ps_1.HasProcess(pn.Id):
                                    p: QLabProcess = ps_1.GetProcess(pn.Id)
                                    def f_1(r: _A | None=None, pn: Any=pn) -> None:
                                        ignore(add_to_set(r, result))

                                    iter(f_1, f(p))
                                    return p.Outputs

                                else: 
                                    return []


                            return collect(f_2, n.ObjectOf())


                    to_check_mut = collect(f_3, to_check)
                    continue

                break

        return loop([node])

    @staticmethod
    def get_previous_processes_of(node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> ProcessSequence:
        class ObjectExpr4390:
            @property
            def Equals(self) -> Callable[[QLabProcess, QLabProcess], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[QLabProcess], int]:
                return safe_hash

        return ProcessSequence(list(distinct(QGraph.collect_backwards(node, singleton, graph, ps), ObjectExpr4390())))

    @staticmethod
    def get_succeeding_processes_of(node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> ProcessSequence:
        class ObjectExpr4391:
            @property
            def Equals(self) -> Callable[[QLabProcess, QLabProcess], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[QLabProcess], int]:
                return safe_hash

        return ProcessSequence(list(distinct(QGraph.collect_forwards(node, singleton, graph, ps), ObjectExpr4391())))

    @staticmethod
    def get_processes_of(node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> ProcessSequence:
        class ObjectExpr4392:
            @property
            def Equals(self) -> Callable[[QLabProcess, QLabProcess], bool]:
                return equals

            @property
            def GetHashCode(self) -> Callable[[QLabProcess], int]:
                return safe_hash

        return ProcessSequence(list(distinct(append(QGraph.collect_forwards(node, singleton, graph, ps), QGraph.collect_backwards(node, singleton, graph, ps)), ObjectExpr4392())))

    @staticmethod
    def get_root_inputs(graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f(n: IONode) -> bool:
            return QGraph.node_is_root(n, ps)

        return QGraph.get_nodes_by(f, graph, ps)

    @staticmethod
    def get_final_outputs(graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f(n: IONode) -> bool:
            return QGraph.node_is_final(n, ps)

        return QGraph.get_nodes_by(f, graph, ps)

    @staticmethod
    def get_nodes_by(predicate: Callable[[IONode], bool], graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        if ps is None:
            def f_3(n_2: LDNode) -> IONode | None:
                def binder(io_node: IONode, n_2: Any=n_2) -> IONode | None:
                    if predicate(io_node):
                        return io_node

                    else: 
                        return None


                return bind(binder, IONode(n_2, graph) if LDSample.validate(n_2, graph.Context) else (IONode(n_2, graph) if LDFile.validate(n_2, graph.Context) else None))

            return choose(f_3, graph.Nodes)

        else: 
            ps_1: ProcessSequence = ps
            def f_2(p: QLabProcess) -> Array[IONode]:
                def f(n: IONode, p: Any=p) -> bool:
                    return predicate(n)

                def f_1(n_1: IONode, p: Any=p) -> bool:
                    return predicate(n_1)

                return append(filter(f, p.Inputs), filter(f_1, p.Outputs))

            class ObjectExpr4393:
                @property
                def Equals(self) -> Callable[[IONode, IONode], bool]:
                    return equals

                @property
                def GetHashCode(self) -> Callable[[IONode], int]:
                    return safe_hash

            return list(distinct(collect(f_2, ps_1.Processes), ObjectExpr4393()))


    @staticmethod
    def get_root_inputs_by(predicate: Callable[[IONode], bool], graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f(n: IONode) -> bool:
            return not exists(predicate, QGraph.get_previous_nodes_of(n, graph, ps))

        return filter(f, QGraph.get_nodes_by(predicate, graph, ps))

    @staticmethod
    def get_final_outputs_by(predicate: Callable[[IONode], bool], graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f(n: IONode) -> bool:
            return not exists(predicate, QGraph.get_succeeding_nodes_of(n, graph, ps))

        return filter(f, QGraph.get_nodes_by(predicate, graph, ps))

    @staticmethod
    def get_previous_nodes_of(node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def _arrow4394(lab_process: QLabProcess) -> Array[IONode]:
            return QLabProcess.inputs(lab_process)

        return QGraph.collect_backwards(node, _arrow4394, graph, ps)

    @staticmethod
    def get_succeeding_nodes_of(node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def _arrow4395(lab_process: QLabProcess) -> Array[IONode]:
            return QLabProcess.outputs(lab_process)

        return QGraph.collect_forwards(node, _arrow4395, graph, ps)

    @staticmethod
    def get_nodes_of_by(predicate: Callable[[IONode], bool], node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def _arrow4396(__unit: None=None) -> Array[IONode]:
            b: Array[IONode] = QGraph.get_succeeding_nodes_of(node, graph, ps)
            return append(QGraph.get_previous_nodes_of(node, graph, ps), b)

        return filter(predicate, _arrow4396())

    @staticmethod
    def get_root_inputs_of_by(predicate: Callable[[IONode], bool], node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f_1(p: QLabProcess) -> Array[IONode]:
            def f(input: IONode, p: Any=p) -> bool:
                if QGraph.node_is_root(input, ps):
                    return predicate(input)

                else: 
                    return False


            return filter(f, QLabProcess.inputs(p))

        return QGraph.collect_backwards(node, f_1, graph, ps)

    @staticmethod
    def get_final_outputs_of_by(predicate: Callable[[IONode], bool], node: IONode, graph: QGraph, ps: ProcessSequence | None=None) -> Array[IONode]:
        def f_1(p: QLabProcess) -> Array[IONode]:
            def f(output: IONode, p: Any=p) -> bool:
                if QGraph.node_is_final(output, ps):
                    return predicate(output)

                else: 
                    return False


            return filter(f, QLabProcess.outputs(p))

        return QGraph.collect_forwards(node, f_1, graph, ps)

    @staticmethod
    def get_values(graph: QGraph, ps: ProcessSequence | None=None) -> QValueCollection:
        ps_1: ProcessSequence = default_arg(ps, graph.ProcessSequence)
        def f(p: QLabProcess) -> Array[QPropertyValue]:
            return p.Values

        return QValueCollection(collect(f, ps_1.Processes))

    @staticmethod
    def get_previous_values_of(node: IONode, graph: QGraph, protocol_name: str | None=None, ps: ProcessSequence | None=None) -> QValueCollection:
        def f(p: QLabProcess) -> Array[QPropertyValue]:
            (pattern_matching_result,) = (None,)
            if protocol_name is not None:
                def _arrow4397(__unit: None=None, p: Any=p) -> bool:
                    pn: str = protocol_name
                    return (value_3(p.Protocol).Name != pn) if (p.Protocol is not None) else False

                if _arrow4397():
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                return []

            elif pattern_matching_result == 1:
                return p.Values


        return QValueCollection(QGraph.collect_backwards(node, f, graph, ps))

    @staticmethod
    def get_succeeding_values_of(node: IONode, graph: QGraph, protocol_name: str | None=None, ps: ProcessSequence | None=None) -> QValueCollection:
        def f(p: QLabProcess) -> Array[QPropertyValue]:
            (pattern_matching_result,) = (None,)
            if protocol_name is not None:
                def _arrow4398(__unit: None=None, p: Any=p) -> bool:
                    pn: str = protocol_name
                    return (value_3(p.Protocol).Name != pn) if (p.Protocol is not None) else False

                if _arrow4398():
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                return []

            elif pattern_matching_result == 1:
                return p.Values


        return QValueCollection(QGraph.collect_forwards(node, f, graph, ps))

    @staticmethod
    def get_values_of(node: IONode, graph: QGraph, protocol_name: str | None=None, ps: ProcessSequence | None=None) -> QValueCollection:
        def _arrow4399(__unit: None=None) -> Array[QPropertyValue]:
            b: Array[QPropertyValue] = QGraph.get_succeeding_values_of(node, graph, protocol_name, ps).Values
            return append(QGraph.get_previous_values_of(node, graph, protocol_name, ps).Values, b)

        return QValueCollection(_arrow4399())

    @staticmethod
    def only_values_of_protocol(protocol_name: str, graph: QGraph, ps: ProcessSequence | None=None) -> QValueCollection:
        def f(p: QLabProcess) -> Array[QPropertyValue]:
            match_value: QLabProtocol | None = p.Protocol
            (pattern_matching_result,) = (None,)
            if match_value is not None:
                def _arrow4400(__unit: None=None, p: Any=p) -> bool:
                    pt: QLabProtocol = match_value
                    return pt.Name == protocol_name

                if _arrow4400():
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                return p.Values

            elif pattern_matching_result == 1:
                return []


        def _arrow4401(__unit: None=None) -> Array[QLabProcess]:
            ps_1: ProcessSequence = default_arg(ps, graph.ProcessSequence)
            return ps_1.Processes

        return QValueCollection(collect(f, _arrow4401()))

    def NodesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4402(_arg: IONode) -> bool:
            return True

        return QGraph.get_nodes_of_by(_arrow4402, node, this)

    def FirstNodesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4403(_arg: IONode) -> bool:
            return True

        return QGraph.get_root_inputs_of_by(_arrow4403, node, this)

    def LastNodesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4404(_arg: IONode) -> bool:
            return True

        return QGraph.get_final_outputs_of_by(_arrow4404, node, this)

    def SamplesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4405(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_nodes_of_by(_arrow4405, node, this)

    def FirstSamplesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4406(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_root_inputs_of_by(_arrow4406, node, this)

    def LastSamplesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4407(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_final_outputs_of_by(_arrow4407, node, this)

    def SourcesOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4408(io: IONode) -> bool:
            return io.IsSource

        return QGraph.get_nodes_of_by(_arrow4408, node, this)

    def DataOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4409(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_nodes_of_by(_arrow4409, node, this)

    def FirstDataOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4410(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_root_inputs_of_by(_arrow4410, node, this)

    def LastDataOf(self, node: IONode) -> Array[IONode]:
        this: QGraph = self
        def _arrow4411(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_final_outputs_of_by(_arrow4411, node, this)

    def Values(self, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        if protocol_name is None:
            return QGraph.get_values(this)

        else: 
            pn: str = protocol_name
            return QGraph.only_values_of_protocol(pn, this)


    def ValuesWithCategory(self, ontology: OntologyAnnotation, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).WithCategory(ontology)

    def ValuesWithName(self, name: str, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).WithName(name)

    def Factors(self, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).Factors()

    def Parameters(self, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).Parameters()

    def Characteristics(self, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).Characteristics()

    def Components(self, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.Values(protocol_name).Components()

    def PreviousValuesOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return QGraph.get_previous_values_of(node, this, protocol_name, this.ProcessSequence)

    def SucceedingValuesOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return QGraph.get_succeeding_values_of(node, this, protocol_name, this.ProcessSequence)

    def ValuesOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return QValueCollection(append(this.PreviousValuesOf(node, protocol_name).Values, this.SucceedingValuesOf(node, protocol_name).Values))

    def CharacteristicsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.ValuesOf(node, protocol_name).Characteristics()

    def PreviousCharacteristicsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.PreviousValuesOf(node, protocol_name).Characteristics()

    def SucceedingCharacteristicsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.SucceedingValuesOf(node, protocol_name).Characteristics()

    def ParametersOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.ValuesOf(node, protocol_name).Parameters()

    def PreviousParametersOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.PreviousValuesOf(node, protocol_name).Parameters()

    def SucceedingParametersOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.SucceedingValuesOf(node, protocol_name).Parameters()

    def FactorsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.ValuesOf(node, protocol_name).Factors()

    def PreviousFactorsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.PreviousValuesOf(node, protocol_name).Factors()

    def SucceedingFactorsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.SucceedingValuesOf(node, protocol_name).Factors()

    def ComponentsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.ValuesOf(node, protocol_name).Components()

    def PreviousComponentsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.PreviousValuesOf(node, protocol_name).Components()

    def SucceedingComponentsOf(self, node: IONode, protocol_name: str | None=None) -> QValueCollection:
        this: QGraph = self
        return this.SucceedingValuesOf(node, protocol_name).Components()

    def ContainsByCategory(self, category: OntologyAnnotation, protocol_name: str | None=None) -> bool:
        this: QGraph = self
        return this.Values(protocol_name).ContainsByCategory(category)

    def ContainsByName(self, name: str, protocol_name: str | None=None) -> bool:
        this: QGraph = self
        return this.Values(protocol_name).ContainsByName(name)

    @property
    def IONodes(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        return QGraph.get_nodes(this)

    def c(self, name: str) -> IONode:
        this: QGraph = self
        def predicate(n: IONode) -> bool:
            return n.Name == name

        return find(predicate, this.IONodes)

    def GetIONodeById(self, id: str) -> IONode:
        this: QGraph = self
        return IONode(this.GetNode(id), this)

    @property
    def FirstNodes(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        return QGraph.get_root_inputs(this)

    @property
    def LastNodes(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        return QGraph.get_final_outputs(this)

    @property
    def Samples(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4412(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_nodes_by(_arrow4412, this)

    @property
    def FirstSamples(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4413(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_root_inputs_by(_arrow4413, this)

    @property
    def LastSamples(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4414(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_final_outputs_by(_arrow4414, this)

    @property
    def Sources(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4415(io: IONode) -> bool:
            return io.IsSource

        return QGraph.get_nodes_by(_arrow4415, this)

    @property
    def Data(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4416(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_nodes_by(_arrow4416, this)

    @property
    def FirstData(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4417(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_root_inputs_by(_arrow4417, this)

    @property
    def LastData(self, __unit: None=None) -> Array[IONode]:
        this: QGraph = self
        def _arrow4418(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_final_outputs_by(_arrow4418, this)


QGraph_reflection = _expr4422

def QGraph__ctor_34DF9647(in_graph: LDGraph) -> QGraph:
    return QGraph(in_graph)


def _expr4427() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.QLabProcess", None, QLabProcess, LDNode_reflection())


class QLabProcess(LDNode):
    def __init__(self, node: LDNode, parent_graph: QGraph | None=None) -> None:
        super().__init__(node.Id, node.SchemaType, node.AdditionalType)
        this: FSharpRef[QLabProcess] = FSharpRef(None)
        self.parent_graph: QGraph | None = parent_graph
        this.contents = self
        self.init_0040609_002D1: int = 1
        if not LDLabProcess.validate(node, self.context()):
            arg: str = node.Id
            to_fail(printf("The provided node with id %s is not a valid Process"))(arg)

        def action(kv: Any) -> None:
            if not (kv[0] == "Id"):
                this.contents.SetProperty(kv[0], kv[1])


        iterate(action, node.GetProperties(False))

    @staticmethod
    def name(lab_process: QLabProcess) -> str:
        return lab_process.Name

    @staticmethod
    def inputs(lab_process: QLabProcess) -> Array[IONode]:
        return lab_process.Inputs

    @staticmethod
    def outputs(lab_process: QLabProcess) -> Array[IONode]:
        return lab_process.Outputs

    @staticmethod
    def input_names(lab_process: QLabProcess) -> Array[str]:
        return lab_process.InputNames

    @staticmethod
    def output_names(lab_process: QLabProcess) -> Array[str]:
        return lab_process.OutputNames

    @staticmethod
    def input_types(lab_process: QLabProcess) -> Array[Array[str]]:
        return lab_process.InputTypes

    @staticmethod
    def output_types(lab_process: QLabProcess) -> Array[Array[str]]:
        return lab_process.OutputTypes

    @property
    def ParentGraph(self, __unit: None=None) -> QGraph | None:
        this: QLabProcess = self
        return this.parent_graph

    @property
    def Name(self, __unit: None=None) -> str:
        this: QLabProcess = self
        return LDLabProcess.get_name_as_string(this, this.context())

    @property
    def Inputs(self, __unit: None=None) -> Array[IONode]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(io_node: LDNode) -> IONode:
            return IONode(io_node, this.ParentGraph)

        return map_1(f, LDLabProcess.get_objects(this, parent_graph, this.context()))

    @property
    def Outputs(self, __unit: None=None) -> Array[IONode]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(io_node: LDNode) -> IONode:
            return IONode(io_node, this.ParentGraph)

        return map_1(f, LDLabProcess.get_results(this, parent_graph, this.context()))

    @property
    def InputNames(self, __unit: None=None) -> Array[str]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(i: LDNode) -> str:
            return LDSample.get_name_as_string(i, this.context())

        return map_1(f, LDLabProcess.get_objects(this, parent_graph, this.context()))

    @property
    def OutputNames(self, __unit: None=None) -> Array[str]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(i: LDNode) -> str:
            return LDSample.get_name_as_string(i, this.context())

        return map_1(f, LDLabProcess.get_results(this, parent_graph, this.context()))

    @property
    def InputTypes(self, __unit: None=None) -> Array[Array[str]]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(i: LDNode) -> Array[str]:
            return i.SchemaType

        return map_1(f, LDLabProcess.get_objects(this, parent_graph, this.context()))

    @property
    def OutputTypes(self, __unit: None=None) -> Array[Array[str]]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def f(i: LDNode) -> Array[str]:
            return i.SchemaType

        return map_1(f, LDLabProcess.get_results(this, parent_graph, this.context()))

    @property
    def ParameterValues(self, __unit: None=None) -> Array[QPropertyValue]:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        return map_1(QPropertyValue__ctor_1118F6CB, LDLabProcess.get_parameter_values(this, parent_graph, this.context()))

    @property
    def Protocol(self, __unit: None=None) -> QLabProtocol | None:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        def mapping_1(lp_node: LDNode) -> QLabProtocol:
            return QLabProtocol(lp_node, this.ParentGraph)

        return map(mapping_1, LDLabProcess.try_get_executes_lab_protocol(this, parent_graph, this.context()))

    @property
    def Components(self, __unit: None=None) -> Array[QPropertyValue]:
        this: QLabProcess = self
        match_value: QLabProtocol | None = this.Protocol
        if match_value is None:
            return []

        else: 
            protocol_node: QLabProtocol = match_value
            return protocol_node.Components


    def GetNextProcesses(self, __unit: None=None) -> Array[LDNode]:
        this: QLabProcess = self
        def projection(p: LDNode) -> str:
            return p.Id

        def f(io_node: IONode) -> Array[LDNode]:
            return io_node.ObjectOf()

        class ObjectExpr4424:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4423(x: str, y: str) -> bool:
                    return x == y

                return _arrow4423

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return list(distinct_by(projection, collect(f, this.Inputs), ObjectExpr4424()))

    def GetPreviousProcesses(self, __unit: None=None) -> Array[LDNode]:
        this: QLabProcess = self
        def projection(p: LDNode) -> str:
            return p.Id

        def f(io_node: IONode) -> Array[LDNode]:
            return io_node.ResultOf()

        class ObjectExpr4426:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4425(x: str, y: str) -> bool:
                    return x == y

                return _arrow4425

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return list(distinct_by(projection, collect(f, this.Outputs), ObjectExpr4426()))

    @property
    def Values(self, __unit: None=None) -> Array[QPropertyValue]:
        this: QLabProcess = self
        b_2: Array[QPropertyValue]
        b_1: Array[QPropertyValue]
        def f(i: IONode) -> Array[QPropertyValue]:
            return i.Characteristics

        b: Array[QPropertyValue] = collect(f, this.Inputs)
        def f_1(o: IONode) -> Array[QPropertyValue]:
            return o.Factors

        b_1 = append(collect(f_1, this.Outputs), b)
        b_2 = append(this.ParameterValues, b_1)
        return append(this.Components, b_2)

    def __hash__(self, __unit: None=None) -> int:
        this: QLabProcess = self
        return string_hash(this.Id)

    def __eq__(self, obj: Any=None) -> bool:
        this: QLabProcess = self
        return (this.Id == obj.Id) if isinstance(obj, QLabProcess) else False

    def context(self, __unit: None=None) -> LDContext | None:
        this: QLabProcess = self
        def mapping(g: QGraph) -> LDContext:
            return g.Context

        return map(mapping, this.parent_graph)


QLabProcess_reflection = _expr4427

def QLabProcess__ctor_Z446A066F(node: LDNode, parent_graph: QGraph | None=None) -> QLabProcess:
    return QLabProcess(node, parent_graph)


def _expr4428() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.QLabProtocol", None, QLabProtocol, LDNode_reflection())


class QLabProtocol(LDNode):
    def __init__(self, node: LDNode, parent_graph: QGraph | None=None) -> None:
        super().__init__(node.Id, node.SchemaType, node.AdditionalType)
        this: FSharpRef[QLabProtocol] = FSharpRef(None)
        self.parent_graph: QGraph | None = parent_graph
        this.contents = self
        self.init_0040726_002D2: int = 1
        if not LDLabProtocol.validate(node, self.context()):
            arg: str = node.Id
            to_fail(printf("The provided node with id %s is not a valid Process"))(arg)

        def action(kv: Any) -> None:
            if not (kv[0] == "Id"):
                this.contents.SetProperty(kv[0], kv[1])


        iterate(action, node.GetProperties(False))

    @staticmethod
    def name(lab_protocol: QLabProtocol) -> str:
        return lab_protocol.Name

    @staticmethod
    def components(lab_protocol: QLabProtocol) -> Array[QPropertyValue]:
        return lab_protocol.Components

    @property
    def ParentGraph(self, __unit: None=None) -> QGraph | None:
        this: QLabProtocol = self
        return this.parent_graph

    @property
    def Name(self, __unit: None=None) -> str:
        this: QLabProtocol = self
        return LDLabProtocol.get_name_as_string(this, this.context())

    @property
    def Components(self, __unit: None=None) -> Array[QPropertyValue]:
        this: QLabProtocol = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        return map_1(QPropertyValue__ctor_1118F6CB, LDLabProtocol.get_components(this, parent_graph, this.context()))

    def __hash__(self, __unit: None=None) -> int:
        this: QLabProtocol = self
        return string_hash(this.Id)

    def __eq__(self, obj: Any=None) -> bool:
        this: QLabProtocol = self
        return (this.Id == obj.Id) if isinstance(obj, QLabProtocol) else False

    def context(self, __unit: None=None) -> LDContext | None:
        this: QLabProtocol = self
        def mapping(g: QGraph) -> LDContext:
            return g.Context

        return map(mapping, this.parent_graph)


QLabProtocol_reflection = _expr4428

def QLabProtocol__ctor_Z446A066F(node: LDNode, parent_graph: QGraph | None=None) -> QLabProtocol:
    return QLabProtocol(node, parent_graph)


def _expr4439() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.IONode", None, IONode, LDNode_reflection())


class IONode(LDNode):
    def __init__(self, node: LDNode, parent_graph: QGraph | None=None) -> None:
        super().__init__(node.Id, node.SchemaType, node.AdditionalType)
        this: FSharpRef[IONode] = FSharpRef(None)
        self.parent_graph: QGraph | None = parent_graph
        this.contents = self
        self.init_0040767_002D3: int = 1
        def action(kv: Any) -> None:
            if not (kv[0] == "Id"):
                this.contents.SetProperty(kv[0], kv[1])


        iterate(action, node.GetProperties(False))

    @property
    def Name(self, __unit: None=None) -> str:
        this: IONode = self
        return LDSample.get_name_as_string(this, this.context())

    @property
    def IsSample(self, __unit: None=None) -> bool:
        this: IONode = self
        return LDSample.validate_sample(this, this.context())

    @property
    def IsSource(self, __unit: None=None) -> bool:
        this: IONode = self
        return LDSample.validate_source(this, this.context())

    @property
    def IsMaterial(self, __unit: None=None) -> bool:
        this: IONode = self
        return LDSample.validate_material(this, this.context())

    @property
    def IsFile(self, __unit: None=None) -> bool:
        this: IONode = self
        return LDFile.validate(this, this.context())

    @property
    def ParentGraph(self, __unit: None=None) -> QGraph | None:
        this: IONode = self
        return this.parent_graph

    @property
    def AdditionalProperties(self, __unit: None=None) -> Array[QPropertyValue]:
        this: IONode = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        return map_1(QPropertyValue__ctor_1118F6CB, LDSample.get_additional_properties(this, parent_graph, this.context()))

    @property
    def Characteristics(self, __unit: None=None) -> Array[QPropertyValue]:
        this: IONode = self
        return filter(QPropertyValue__get_IsCharacteristic, this.AdditionalProperties)

    @property
    def Factors(self, __unit: None=None) -> Array[QPropertyValue]:
        this: IONode = self
        return filter(QPropertyValue__get_IsFactor, this.AdditionalProperties)

    def HasResultOf(self, __unit: None=None) -> bool:
        this: IONode = self
        return this.HasProperty(result_of, this.context())

    def HasObjectOf(self, __unit: None=None) -> bool:
        this: IONode = self
        return this.HasProperty(object_of, this.context())

    def ResultOf(self, __unit: None=None) -> Array[LDNode]:
        this: IONode = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        return this.GetPropertyNodes(result_of, None, parent_graph, this.context())

    def ObjectOf(self, __unit: None=None) -> Array[LDNode]:
        this: IONode = self
        def mapping(g: QGraph) -> LDGraph:
            return g

        parent_graph: LDGraph | None = map(mapping, this.parent_graph)
        return this.GetPropertyNodes(object_of, None, parent_graph, this.context())

    def GetNodes(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetNodes requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4429(_arg: IONode) -> bool:
            return True

        return QGraph.get_nodes_of_by(_arrow4429, this, value_3(this.parent_graph))

    def GetPreviousNodes(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousNodes requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_nodes_of(this, value_3(this.parent_graph))

    def GetFirstNodes(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetFirstNodes requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4430(_arg: IONode) -> bool:
            return True

        return QGraph.get_root_inputs_of_by(_arrow4430, this, value_3(this.parent_graph))

    def GetSucceedingNodes(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingNodes requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_nodes_of(this, value_3(this.parent_graph))

    def GetLastNodes(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetLastNodes requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4431(_arg: IONode) -> bool:
            return True

        return QGraph.get_final_outputs_of_by(_arrow4431, this, value_3(this.parent_graph))

    def GetSamples(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSamples requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4432(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_nodes_of_by(_arrow4432, this, value_3(this.parent_graph))

    def GetFirstSamples(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetFirstSamples requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4433(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_root_inputs_of_by(_arrow4433, this, value_3(this.parent_graph))

    def GetLastSamples(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetLastSamples requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4434(io: IONode) -> bool:
            return io.IsSample

        return QGraph.get_final_outputs_of_by(_arrow4434, this, value_3(this.parent_graph))

    def GetSources(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSources requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4435(io: IONode) -> bool:
            return io.IsSource

        return QGraph.get_nodes_of_by(_arrow4435, this, value_3(this.parent_graph))

    def GetData(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetData requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4436(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_nodes_of_by(_arrow4436, this, value_3(this.parent_graph))

    def GetFirstData(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetFirstData requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4437(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_root_inputs_of_by(_arrow4437, this, value_3(this.parent_graph))

    def GetLastData(self, __unit: None=None) -> Array[IONode]:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetLastData requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        def _arrow4438(io: IONode) -> bool:
            return io.IsFile

        return QGraph.get_final_outputs_of_by(_arrow4438, this, value_3(this.parent_graph))

    def GetValues(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetValues requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_values_of(this, value_3(this.parent_graph))

    def GetPreviousValues(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousValues requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_values_of(this, value_3(this.parent_graph))

    def GetSucceedingValues(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingValues requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_values_of(this, value_3(this.parent_graph))

    def GetCharacteristics(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetCharacteristics requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_values_of(this, value_3(this.parent_graph)).Characteristics()

    def GetPreviousCharacteristics(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousCharacteristics requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_values_of(this, value_3(this.parent_graph)).Characteristics()

    def GetSucceedingCharacteristics(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingCharacteristics requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_values_of(this, value_3(this.parent_graph)).Characteristics()

    def GetParameters(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetParameters requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_values_of(this, value_3(this.parent_graph)).Parameters()

    def GetPreviousParameters(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousParameters requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_values_of(this, value_3(this.parent_graph)).Parameters()

    def GetSucceedingParameters(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingParameters requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_values_of(this, value_3(this.parent_graph)).Parameters()

    def GetFactors(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetFactors requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_values_of(this, value_3(this.parent_graph)).Factors()

    def GetPreviousFactors(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousFactors requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_values_of(this, value_3(this.parent_graph)).Factors()

    def GetSucceedingFactors(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingFactors requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_values_of(this, value_3(this.parent_graph)).Factors()

    def GetComponents(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetComponents requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_values_of(this, value_3(this.parent_graph)).Components()

    def GetPreviousComponents(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousComponents requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_values_of(this, value_3(this.parent_graph)).Components()

    def GetSucceedingComponents(self, __unit: None=None) -> QValueCollection:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingComponents requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_values_of(this, value_3(this.parent_graph)).Components()

    def GetProcesses(self, __unit: None=None) -> ProcessSequence:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetProcesses requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_processes_of(this, value_3(this.parent_graph))

    def GetPreviousProcesses(self, __unit: None=None) -> ProcessSequence:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetPreviousProcesses requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_previous_processes_of(this, value_3(this.parent_graph))

    def GetSucceedingProcesses(self, __unit: None=None) -> ProcessSequence:
        this: IONode = self
        if this.parent_graph is None:
            arg: str = this.Id
            to_fail(printf("IONode.GetSucceedingProcesses requires a parent QGraph to be set. Not set for node \"%s\""))(arg)

        return QGraph.get_succeeding_processes_of(this, value_3(this.parent_graph))

    def __hash__(self, __unit: None=None) -> int:
        this: IONode = self
        return string_hash(this.Id)

    def __eq__(self, obj: Any=None) -> bool:
        this: IONode = self
        return (this.Id == obj.Id) if isinstance(obj, IONode) else False

    def context(self, __unit: None=None) -> LDContext | None:
        this: IONode = self
        def mapping(g: QGraph) -> LDContext:
            return g.Context

        return map(mapping, this.parent_graph)


IONode_reflection = _expr4439

def IONode__ctor_Z446A066F(node: LDNode, parent_graph: QGraph | None=None) -> IONode:
    return IONode(node, parent_graph)


__all__ = ["ProcessSequence_reflection", "QGraph_reflection", "QLabProcess_reflection", "QLabProtocol_reflection", "IONode_reflection"]

