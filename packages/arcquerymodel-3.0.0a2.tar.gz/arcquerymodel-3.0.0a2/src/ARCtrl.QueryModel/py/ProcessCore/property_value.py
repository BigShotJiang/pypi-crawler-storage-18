from __future__ import annotations
from typing import Any
from ..fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from ..fable_modules.arctrl_rocrate.ldobject import (LDNode, LDNode_reflection)
from ..fable_modules.arctrl_rocrate.LDTypes.property_value import LDPropertyValue
from ..fable_modules.fable_library.option import value as value_1
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.seq import iterate
from ..fable_modules.fable_library.string_ import (to_fail, printf)
from ..fable_modules.fable_library.types import FSharpRef
from ..fable_modules.fable_library.util import string_hash
from .knowledge_graph import context

def _expr4328() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ProcessCore.QPropertyValue", None, QPropertyValue, LDNode_reflection())


class QPropertyValue(LDNode):
    def __init__(self, node: LDNode) -> None:
        super().__init__(node.Id, node.SchemaType, node.AdditionalType)
        this: FSharpRef[QPropertyValue] = FSharpRef(None)
        this.contents = self
        self.init_00408: int = 1
        if not LDPropertyValue.validate(node, context):
            arg: str = node.Id
            to_fail(printf("The provided node with id %s is not a valid PropertyValue"))(arg)

        def action(kv: Any) -> None:
            if not (kv[0] == "Id"):
                this.contents.SetProperty(kv[0], kv[1])


        iterate(action, node.GetProperties(False))

    def __hash__(self, __unit: None=None) -> int:
        this: QPropertyValue = self
        return string_hash(this.Id)

    def __eq__(self, obj: Any=None) -> bool:
        this: QPropertyValue = self
        return (this.Id == obj.Id) if isinstance(obj, QPropertyValue) else False


QPropertyValue_reflection = _expr4328

def QPropertyValue__ctor_1118F6CB(node: LDNode) -> QPropertyValue:
    return QPropertyValue(node)


def QPropertyValue__get_IsCharacteristic(this: QPropertyValue) -> bool:
    return LDPropertyValue.validate_characteristic_value(this, context)


def QPropertyValue__get_IsParameter(this: QPropertyValue) -> bool:
    return LDPropertyValue.validate_parameter_value(this, context)


def QPropertyValue__get_IsFactor(this: QPropertyValue) -> bool:
    return LDPropertyValue.validate_factor_value(this, context)


def QPropertyValue__get_IsComponent(this: QPropertyValue) -> bool:
    return LDPropertyValue.validate_component(this, context)


def QPropertyValue__get_TryNameText(this: QPropertyValue) -> str | None:
    return LDPropertyValue.try_get_name_as_string(this, context)


def QPropertyValue__get_Category(this: QPropertyValue) -> OntologyAnnotation:
    match_value: str | None = LDPropertyValue.try_get_property_idas_string(this, context)
    if match_value is None:
        return OntologyAnnotation(QPropertyValue__get_NameText(this))

    else: 
        property_id: str = match_value
        return OntologyAnnotation.from_term_annotation(property_id, QPropertyValue__get_TryNameText(this))



def QPropertyValue__get_NameText(this: QPropertyValue) -> str:
    return LDPropertyValue.get_name_as_string(this, context)


def QPropertyValue__get_TryUnitText(this: QPropertyValue) -> str | None:
    return LDPropertyValue.try_get_unit_text_as_string(this, context)


def QPropertyValue__get_UnitText(this: QPropertyValue) -> str:
    return value_1(LDPropertyValue.try_get_unit_text_as_string(this, context))


def QPropertyValue__get_TryValueText(this: QPropertyValue) -> str | None:
    return LDPropertyValue.try_get_value_as_string(this, context)


def QPropertyValue__get_ValueText(this: QPropertyValue) -> str:
    return LDPropertyValue.get_value_as_string(this, context)


def QPropertyValue__get_ValueWithUnitText(this: QPropertyValue) -> str:
    match_value: str | None = QPropertyValue__get_TryUnitText(this)
    if match_value is None:
        return QPropertyValue__get_ValueText(this)

    else: 
        unit_text: str = match_value
        return ((("" + QPropertyValue__get_ValueText(this)) + " ") + unit_text) + ""



__all__ = ["QPropertyValue_reflection", "QPropertyValue__get_IsCharacteristic", "QPropertyValue__get_IsParameter", "QPropertyValue__get_IsFactor", "QPropertyValue__get_IsComponent", "QPropertyValue__get_TryNameText", "QPropertyValue__get_Category", "QPropertyValue__get_NameText", "QPropertyValue__get_TryUnitText", "QPropertyValue__get_UnitText", "QPropertyValue__get_TryValueText", "QPropertyValue__get_ValueText", "QPropertyValue__get_ValueWithUnitText"]

