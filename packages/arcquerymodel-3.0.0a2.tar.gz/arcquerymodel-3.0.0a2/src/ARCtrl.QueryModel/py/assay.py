from __future__ import annotations
from typing import Any
from .arc_tables import (ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8, QNode, ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8, ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static, ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static)
from .fable_modules.arctrl_core.arc_types import ArcAssay
from .fable_modules.arctrl_core.Table.arc_table import ArcTable
from .fable_modules.arctrl_core.Table.composite_header import IOType
from .fable_modules.fable_library.list import FSharpList
from .fable_modules.fable_library.types import Array

def ARCtrl_ArcAssay__ArcAssay_Protocol_Z721C83C5(this: ArcAssay, sheet_name: str) -> ArcTable:
    return this.GetTable(sheet_name)


def ARCtrl_ArcAssay__ArcAssay_Protocol_Z524259A4(this: ArcAssay, index: int) -> ArcTable:
    return this.GetTableAt(index)


def ARCtrl_ArcAssay__ArcAssay_getRootInputs_Static_1501C0F8(assay: ArcAssay) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8(assay)


def ARCtrl_ArcAssay__ArcAssay_getFinalOutputs_Static_1501C0F8(assay: ArcAssay) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8(assay)


def ARCtrl_ArcAssay__ArcAssay_getRootInputOf_Static(assay: ArcAssay, sample: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, assay: Any=assay, sample: Any=sample) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, sample, assay)


def ARCtrl_ArcAssay__ArcAssay_getFinalOutputsOf_Static(assay: ArcAssay, sample: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, assay: Any=assay, sample: Any=sample) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, sample, assay)


__all__ = ["ARCtrl_ArcAssay__ArcAssay_Protocol_Z721C83C5", "ARCtrl_ArcAssay__ArcAssay_Protocol_Z524259A4", "ARCtrl_ArcAssay__ArcAssay_getRootInputs_Static_1501C0F8", "ARCtrl_ArcAssay__ArcAssay_getFinalOutputs_Static_1501C0F8", "ARCtrl_ArcAssay__ArcAssay_getRootInputOf_Static", "ARCtrl_ArcAssay__ArcAssay_getFinalOutputsOf_Static"]

