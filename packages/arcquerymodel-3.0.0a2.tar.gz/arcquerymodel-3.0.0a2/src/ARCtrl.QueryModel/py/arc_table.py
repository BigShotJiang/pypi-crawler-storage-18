from __future__ import annotations
from typing import (Any, Generic, TypeVar)
from .fable_modules.arctrl_core.Table.arc_table import ArcTable
from .fable_modules.arctrl_core.Table.composite_cell import CompositeCell
from .fable_modules.arctrl_core.Table.composite_header import (CompositeHeader, IOType)
from .fable_modules.fable_library.list import (FSharpList, item, try_find as try_find_1, length, map as map_2)
from .fable_modules.fable_library.map import try_find
from .fable_modules.fable_library.option import (some, map as map_1)
from .fable_modules.fable_library.range import range_big_int
from .fable_modules.fable_library.reflection import (TypeInfo, int32_type, class_type, union_type)
from .fable_modules.fable_library.seq import (pick, choose, to_list, delay, map, zip, collect)
from .fable_modules.fable_library.types import (Array, Union)
from .fable_modules.fable_library.util import IEnumerable_1
from .value import (ISAValue_tryCompose, ISAValue)
from .value_collection import (IOValueCollection__ctor_Z7E9C64D, IOValueCollection)

_T = TypeVar("_T")

def _expr4318(gen0: TypeInfo) -> TypeInfo:
    return union_type("ARCtrl.QueryModel.ProtocolExtensions.ProtocolDescriptor`1", [gen0], ProtocolExtensions_ProtocolDescriptor_1, lambda: [[("Item", gen0)], [("Item", class_type("Microsoft.FSharp.Collections.FSharpMap`2", [int32_type, gen0]))]])


class ProtocolExtensions_ProtocolDescriptor_1(Union, Generic[_T]):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["ForAll", "ForSpecific"]


ProtocolExtensions_ProtocolDescriptor_1_reflection = _expr4318

def ProtocolExtensions_ProtocolDescriptor_1__TryGet_Z524259A4(this: ProtocolExtensions_ProtocolDescriptor_1[Any], i: int) -> Any | None:
    if this.tag == 1:
        return try_find(i, this.fields[0])

    else: 
        return some(this.fields[0])



def _expr4319() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ArcTableExtensions.CRow", None, ArcTableExtensions_CRow)


class ArcTableExtensions_CRow:
    def __init__(self, vals: IEnumerable_1[tuple[CompositeHeader, CompositeCell]]) -> None:
        self.vals: IEnumerable_1[tuple[CompositeHeader, CompositeCell]] = vals


ArcTableExtensions_CRow_reflection = _expr4319

def ArcTableExtensions_CRow__ctor_Z6AE123C7(vals: IEnumerable_1[tuple[CompositeHeader, CompositeCell]]) -> ArcTableExtensions_CRow:
    return ArcTableExtensions_CRow(vals)


def ArcTableExtensions_CRow__get_Cells(this: ArcTableExtensions_CRow) -> IEnumerable_1[tuple[CompositeHeader, CompositeCell]]:
    return this.vals


def ArcTableExtensions_CRow_input_Z14327367(row: ArcTableExtensions_CRow) -> CompositeCell:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> CompositeCell | None:
        if tupled_arg[0].is_input:
            return tupled_arg[1]

        else: 
            return None


    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow_output_Z14327367(row: ArcTableExtensions_CRow) -> CompositeCell:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> CompositeCell | None:
        if tupled_arg[0].is_output:
            return tupled_arg[1]

        else: 
            return None


    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow_inputName_Z14327367(row: ArcTableExtensions_CRow) -> str:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> str | None:
        if tupled_arg[0].is_input:
            return tupled_arg[1].GetContent()[0]

        else: 
            return None


    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow_outputName_Z14327367(row: ArcTableExtensions_CRow) -> str:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> str | None:
        if tupled_arg[0].is_output:
            return tupled_arg[1].GetContent()[0]

        else: 
            return None


    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow_inputType_Z14327367(row: ArcTableExtensions_CRow) -> IOType:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> IOType | None:
        return tupled_arg[0].TryInput()

    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow_outputType_Z14327367(row: ArcTableExtensions_CRow) -> IOType:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], row: Any=row) -> IOType | None:
        return tupled_arg[0].TryOutput()

    return pick(chooser, ArcTableExtensions_CRow__get_Cells(row))


def ArcTableExtensions_CRow__get_InputName(this: ArcTableExtensions_CRow) -> str:
    return ArcTableExtensions_CRow_inputName_Z14327367(this)


def ArcTableExtensions_CRow__get_OutputName(this: ArcTableExtensions_CRow) -> str:
    return ArcTableExtensions_CRow_outputName_Z14327367(this)


def ArcTableExtensions_CRow__get_Input(this: ArcTableExtensions_CRow) -> str:
    return ArcTableExtensions_CRow__get_InputName(this)


def ArcTableExtensions_CRow__get_Output(this: ArcTableExtensions_CRow) -> str:
    return ArcTableExtensions_CRow__get_OutputName(this)


def ArcTableExtensions_CRow__get_InputType(this: ArcTableExtensions_CRow) -> IOType:
    return ArcTableExtensions_CRow_inputType_Z14327367(this)


def ArcTableExtensions_CRow__get_OutputType(this: ArcTableExtensions_CRow) -> IOType:
    return ArcTableExtensions_CRow_outputType_Z14327367(this)


def ArcTableExtensions_CRow__get_Values(this: ArcTableExtensions_CRow) -> IEnumerable_1[ISAValue]:
    def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], this: Any=this) -> ISAValue | None:
        return ISAValue_tryCompose(tupled_arg[0], tupled_arg[1])

    return choose(chooser, ArcTableExtensions_CRow__get_Cells(this))


def ARCtrl_ArcTable__ArcTable_get_Rows(this: ArcTable) -> FSharpList[ArcTableExtensions_CRow]:
    def _arrow4321(__unit: None=None, this: Any=this) -> IEnumerable_1[ArcTableExtensions_CRow]:
        def _arrow4320(i: int) -> ArcTableExtensions_CRow:
            return ArcTableExtensions_CRow__ctor_Z6AE123C7(zip(this.Headers, this.GetRow(i)))

        return map(_arrow4320, range_big_int(0, 1, this.RowCount - 1))

    return to_list(delay(_arrow4321))


def ARCtrl_ArcTable__ArcTable_get_ISAValues(this: ArcTable) -> IOValueCollection:
    def mapping_1(r: ArcTableExtensions_CRow, this: Any=this) -> IEnumerable_1[Any]:
        i: str = ArcTableExtensions_CRow__get_InputName(r)
        o: str = ArcTableExtensions_CRow__get_OutputName(r)
        def chooser(tupled_arg: tuple[CompositeHeader, CompositeCell], r: Any=r) -> Any | None:
            def mapping(v: ISAValue, tupled_arg: Any=tupled_arg) -> tuple[tuple[str, str], ISAValue]:
                return ((i, o), v)

            return map_1(mapping, ISAValue_tryCompose(tupled_arg[0], tupled_arg[1]))

        return choose(chooser, ArcTableExtensions_CRow__get_Cells(r))

    return IOValueCollection__ctor_Z7E9C64D(to_list(collect(mapping_1, ARCtrl_ArcTable__ArcTable_get_Rows(this))))


def ARCtrl_ArcTable__ArcTable_inputType_Static_16DC5D1F(t: ArcTable) -> IOType:
    def chooser(header: CompositeHeader, t: Any=t) -> IOType | None:
        return header.TryInput()

    return pick(chooser, t.Headers)


def ARCtrl_ArcTable__ArcTable_outputType_Static_16DC5D1F(t: ArcTable) -> IOType:
    def chooser(header: CompositeHeader, t: Any=t) -> IOType | None:
        return header.TryOutput()

    return pick(chooser, t.Headers)


def ARCtrl_ArcTable__ArcTable_get_InputType(this: ArcTable) -> IOType:
    return ARCtrl_ArcTable__ArcTable_inputType_Static_16DC5D1F(this)


def ARCtrl_ArcTable__ArcTable_get_OutputType(this: ArcTable) -> IOType:
    return ARCtrl_ArcTable__ArcTable_outputType_Static_16DC5D1F(this)


def ARCtrl_ArcTable__ArcTable_Item_Z524259A4(this: ArcTable, i: int) -> ArcTableExtensions_CRow:
    return item(i, ARCtrl_ArcTable__ArcTable_get_Rows(this))


def ARCtrl_ArcTable__ArcTable_Item_Z721C83C5(this: ArcTable, input: str) -> ArcTableExtensions_CRow:
    def predicate(arg: ArcTableExtensions_CRow, this: Any=this, input: Any=input) -> bool:
        return input == ArcTableExtensions_CRow_inputName_Z14327367(arg)

    row_1: ArcTableExtensions_CRow | None = try_find_1(predicate, ARCtrl_ArcTable__ArcTable_get_Rows(this))
    if row_1 is None:
        raise Exception(((("Sheet \"" + this.Name) + "\" does not contain row with input \"") + input) + "\"")

    else: 
        return row_1



def ARCtrl_ArcTable__ArcTable_get_RowCount(this: ArcTable) -> int:
    return length(ARCtrl_ArcTable__ArcTable_get_Rows(this))


def ARCtrl_ArcTable__ArcTable_get_InputNames(this: ArcTable) -> FSharpList[str]:
    def mapping(row: ArcTableExtensions_CRow, this: Any=this) -> str:
        return ArcTableExtensions_CRow_inputName_Z14327367(row)

    return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(this))


def ARCtrl_ArcTable__ArcTable_get_OutputNames(this: ArcTable) -> FSharpList[str]:
    def mapping(row: ArcTableExtensions_CRow, this: Any=this) -> str:
        return ArcTableExtensions_CRow_outputName_Z14327367(row)

    return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(this))


def ARCtrl_ArcTable__ArcTable_get_Inputs(this: ArcTable) -> FSharpList[tuple[str, IOType]]:
    def mapping(row: ArcTableExtensions_CRow, this: Any=this) -> tuple[str, IOType]:
        return (ArcTableExtensions_CRow_inputName_Z14327367(row), ArcTableExtensions_CRow_inputType_Z14327367(row))

    return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(this))


def ARCtrl_ArcTable__ArcTable_get_Outputs(this: ArcTable) -> FSharpList[tuple[str, IOType]]:
    def mapping(row: ArcTableExtensions_CRow, this: Any=this) -> tuple[str, IOType]:
        return (ArcTableExtensions_CRow_outputName_Z14327367(row), ArcTableExtensions_CRow_outputType_Z14327367(row))

    return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(this))


__all__ = ["ProtocolExtensions_ProtocolDescriptor_1_reflection", "ProtocolExtensions_ProtocolDescriptor_1__TryGet_Z524259A4", "ArcTableExtensions_CRow_reflection", "ArcTableExtensions_CRow__get_Cells", "ArcTableExtensions_CRow_input_Z14327367", "ArcTableExtensions_CRow_output_Z14327367", "ArcTableExtensions_CRow_inputName_Z14327367", "ArcTableExtensions_CRow_outputName_Z14327367", "ArcTableExtensions_CRow_inputType_Z14327367", "ArcTableExtensions_CRow_outputType_Z14327367", "ArcTableExtensions_CRow__get_InputName", "ArcTableExtensions_CRow__get_OutputName", "ArcTableExtensions_CRow__get_Input", "ArcTableExtensions_CRow__get_Output", "ArcTableExtensions_CRow__get_InputType", "ArcTableExtensions_CRow__get_OutputType", "ArcTableExtensions_CRow__get_Values", "ARCtrl_ArcTable__ArcTable_get_Rows", "ARCtrl_ArcTable__ArcTable_get_ISAValues", "ARCtrl_ArcTable__ArcTable_inputType_Static_16DC5D1F", "ARCtrl_ArcTable__ArcTable_outputType_Static_16DC5D1F", "ARCtrl_ArcTable__ArcTable_get_InputType", "ARCtrl_ArcTable__ArcTable_get_OutputType", "ARCtrl_ArcTable__ArcTable_Item_Z524259A4", "ARCtrl_ArcTable__ArcTable_Item_Z721C83C5", "ARCtrl_ArcTable__ArcTable_get_RowCount", "ARCtrl_ArcTable__ArcTable_get_InputNames", "ARCtrl_ArcTable__ArcTable_get_OutputNames", "ARCtrl_ArcTable__ArcTable_get_Inputs", "ARCtrl_ArcTable__ArcTable_get_Outputs"]

