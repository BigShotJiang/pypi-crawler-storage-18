from __future__ import annotations
from typing import Any
from .fable_modules.arctrl_core.Helper.regex import ActivePatterns__007CRegex_007C__007C
from .fable_modules.fable_library.int32 import parse
from .fable_modules.fable_library.reflection import (TypeInfo, int32_type, tuple_type, union_type)
from .fable_modules.fable_library.reg_exp import (get_item, groups)
from .fable_modules.fable_library.string_ import (to_fail, printf)
from .fable_modules.fable_library.types import (Array, Union)
from .fable_modules.fable_library.util import equals

def _expr4114() -> TypeInfo:
    return union_type("ARCtrl.QueryModel.FragmentSelector.CSV", [], CSV, lambda: [[("Item", int32_type)], [("Item", int32_type)], [("Item1", int32_type), ("Item2", int32_type)], [("Item1", int32_type), ("Item2", int32_type)], [("Item1", int32_type), ("Item2", int32_type)], [("Item1", tuple_type(int32_type, int32_type)), ("Item2", tuple_type(int32_type, int32_type))]])


class CSV(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Row", "Column", "Cell", "RowRange", "ColumnRange", "CellRange"]

    def IsIncludedIn(self, outer: CSV) -> bool:
        this: CSV = self
        (pattern_matching_result, end_row1, r2, start_row1, c2, end_col1, start_col1, c2_1, end_col1_1, end_row1_1, r2_1, start_col1_1, start_row1_1) = (None, None, None, None, None, None, None, None, None, None, None, None, None)
        if equals(outer, this):
            pattern_matching_result = 0

        elif outer.tag == 3:
            if this.tag == 0:
                pattern_matching_result = 1
                end_row1 = outer.fields[1]
                r2 = this.fields[0]
                start_row1 = outer.fields[0]

            else: 
                pattern_matching_result = 4


        elif outer.tag == 4:
            if this.tag == 1:
                pattern_matching_result = 2
                c2 = this.fields[0]
                end_col1 = outer.fields[1]
                start_col1 = outer.fields[0]

            else: 
                pattern_matching_result = 4


        elif outer.tag == 5:
            if this.tag == 2:
                pattern_matching_result = 3
                c2_1 = this.fields[1]
                end_col1_1 = outer.fields[1][1]
                end_row1_1 = outer.fields[1][0]
                r2_1 = this.fields[0]
                start_col1_1 = outer.fields[0][1]
                start_row1_1 = outer.fields[0][0]

            else: 
                pattern_matching_result = 4


        else: 
            pattern_matching_result = 4

        if pattern_matching_result == 0:
            return True

        elif pattern_matching_result == 1:
            return (r2 <= end_row1) if (r2 >= start_row1) else False

        elif pattern_matching_result == 2:
            return (c2 <= end_col1) if (c2 >= start_col1) else False

        elif pattern_matching_result == 3:
            return (c2_1 <= end_col1_1) if ((c2_1 >= start_col1_1) if ((r2_1 <= end_row1_1) if (r2_1 >= start_row1_1) else False) else False) else False

        elif pattern_matching_result == 4:
            return False


    @staticmethod
    def is_included_string(outer: str, inner: str) -> bool:
        outer_selector: CSV = CSV.from_string(outer)
        inner_selector: CSV = CSV.from_string(inner)
        return inner_selector.IsIncludedIn(outer_selector)

    @staticmethod
    def from_string(s: str) -> CSV:
        def _arrow4105(__unit: None=None) -> CSV:
            active_pattern_result: Any | None = ActivePatterns__007CRegex_007C__007C("row=(?<row>\\d*)$", s)
            if active_pattern_result is not None:
                m: Any = active_pattern_result
                return CSV(0, parse(get_item(groups(m), "row") or "", 511, False, 32))

            else: 
                active_pattern_result_1: Any | None = ActivePatterns__007CRegex_007C__007C("col=(?<column>\\d*)$", s)
                if active_pattern_result_1 is not None:
                    m_1: Any = active_pattern_result_1
                    return CSV(1, parse(get_item(groups(m_1), "column") or "", 511, False, 32))

                else: 
                    active_pattern_result_2: Any | None = ActivePatterns__007CRegex_007C__007C("cell=(?<row>\\d*),(?<column>\\d*)$", s)
                    if active_pattern_result_2 is not None:
                        m_2: Any = active_pattern_result_2
                        return CSV(2, parse(get_item(groups(m_2), "row") or "", 511, False, 32), parse(get_item(groups(m_2), "column") or "", 511, False, 32))

                    else: 
                        active_pattern_result_3: Any | None = ActivePatterns__007CRegex_007C__007C("row=(?<start>\\d*)-(?<end>\\d*)$", s)
                        if active_pattern_result_3 is not None:
                            m_3: Any = active_pattern_result_3
                            return CSV(3, parse(get_item(groups(m_3), "start") or "", 511, False, 32), parse(get_item(groups(m_3), "end") or "", 511, False, 32))

                        else: 
                            active_pattern_result_4: Any | None = ActivePatterns__007CRegex_007C__007C("col=(?<start>\\d*)-(?<end>\\d*)$", s)
                            if active_pattern_result_4 is not None:
                                m_4: Any = active_pattern_result_4
                                return CSV(4, parse(get_item(groups(m_4), "start") or "", 511, False, 32), parse(get_item(groups(m_4), "end") or "", 511, False, 32))

                            else: 
                                active_pattern_result_5: Any | None = ActivePatterns__007CRegex_007C__007C("cell=(?<startRow>\\d*),(?<startColumn>\\d*)-(?<endRow>\\d*),(?<endColumn>\\d*)$", s)
                                def _arrow4104(__unit: None=None) -> CSV:
                                    m_5: Any = active_pattern_result_5
                                    return CSV(5, (parse(get_item(groups(m_5), "startRow") or "", 511, False, 32), parse(get_item(groups(m_5), "startColumn") or "", 511, False, 32)), (parse(get_item(groups(m_5), "endRow") or "", 511, False, 32), parse(get_item(groups(m_5), "endColumn") or "", 511, False, 32)))

                                return _arrow4104() if (active_pattern_result_5 is not None) else to_fail(printf("Fragment Selector \"%s\" could not be parsed as text/csv."))(s)






        return _arrow4105()

    @staticmethod
    def from_string_zero_based(s: str) -> CSV:
        def _arrow4107(__unit: None=None) -> CSV:
            active_pattern_result: Any | None = ActivePatterns__007CRegex_007C__007C("row=(?<row>\\d*)$", s)
            if active_pattern_result is not None:
                m: Any = active_pattern_result
                return CSV(0, parse(m[0], 511, False, 32) - 1)

            else: 
                active_pattern_result_1: Any | None = ActivePatterns__007CRegex_007C__007C("col=(?<column>\\d*)$", s)
                if active_pattern_result_1 is not None:
                    m_1: Any = active_pattern_result_1
                    return CSV(1, parse(m_1[0], 511, False, 32) - 1)

                else: 
                    active_pattern_result_2: Any | None = ActivePatterns__007CRegex_007C__007C("cell=(?<row>\\d*),(?<column>\\d*)$", s)
                    if active_pattern_result_2 is not None:
                        m_2: Any = active_pattern_result_2
                        return CSV(2, parse(get_item(groups(m_2), "row") or "", 511, False, 32) - 1, parse(get_item(groups(m_2), "column") or "", 511, False, 32) - 1)

                    else: 
                        active_pattern_result_3: Any | None = ActivePatterns__007CRegex_007C__007C("row=(?<start>\\d*)-(?<end>\\d*)$", s)
                        if active_pattern_result_3 is not None:
                            m_3: Any = active_pattern_result_3
                            return CSV(3, parse(get_item(groups(m_3), "start") or "", 511, False, 32) - 1, parse(get_item(groups(m_3), "end") or "", 511, False, 32) - 1)

                        else: 
                            active_pattern_result_4: Any | None = ActivePatterns__007CRegex_007C__007C("col=(?<start>\\d*)-(?<end>\\d*)$", s)
                            if active_pattern_result_4 is not None:
                                m_4: Any = active_pattern_result_4
                                return CSV(4, parse(get_item(groups(m_4), "start") or "", 511, False, 32) - 1, parse(get_item(groups(m_4), "end") or "", 511, False, 32) - 1)

                            else: 
                                active_pattern_result_5: Any | None = ActivePatterns__007CRegex_007C__007C("cell=(?<startRow>\\d*),(?<startColumn>\\d*)-(?<endRow>\\d*),(?<endColumn>\\d*)$", s)
                                def _arrow4106(__unit: None=None) -> CSV:
                                    m_5: Any = active_pattern_result_5
                                    return CSV(5, (parse(get_item(groups(m_5), "startRow") or "", 511, False, 32) - 1, parse(get_item(groups(m_5), "startColumn") or "", 511, False, 32) - 1), (parse(get_item(groups(m_5), "endRow") or "", 511, False, 32) - 1, parse(get_item(groups(m_5), "endColumn") or "", 511, False, 32) - 1))

                                return _arrow4106() if (active_pattern_result_5 is not None) else to_fail(printf("Fragment Selector \"%s\" could not be parsed as text/csv."))(s)






        return _arrow4107()

    @staticmethod
    def get_zero_based_column_index_from_string(s: str) -> int:
        def _arrow4109(__unit: None=None) -> int:
            active_pattern_result: Any | None = ActivePatterns__007CRegex_007C__007C("col=(?<column>\\d*)$", s)
            def _arrow4108(__unit: None=None) -> int:
                m: Any = active_pattern_result
                return parse(get_item(groups(m), "column") or "", 511, False, 32) - 1

            return _arrow4108() if (active_pattern_result is not None) else to_fail(printf("Fragment Selector \"%s\" could not be parsed as text/csv column."))(s)

        return _arrow4109()

    @staticmethod
    def get_zero_based_row_index_from_string(s: str) -> int:
        def _arrow4111(__unit: None=None) -> int:
            active_pattern_result: Any | None = ActivePatterns__007CRegex_007C__007C("row=(?<row>\\d*)$", s)
            def _arrow4110(__unit: None=None) -> int:
                m: Any = active_pattern_result
                return parse(get_item(groups(m), "row") or "", 511, False, 32) - 1

            return _arrow4110() if (active_pattern_result is not None) else to_fail(printf("Fragment Selector \"%s\" could not be parsed as text/csv row."))(s)

        return _arrow4111()

    @staticmethod
    def get_zero_based_cell_index_from_string(s: str) -> tuple[int, int]:
        def _arrow4113(__unit: None=None) -> tuple[int, int]:
            active_pattern_result: Any | None = ActivePatterns__007CRegex_007C__007C("cell=(?<row>\\d*),(?<column>\\d*)$", s)
            def _arrow4112(__unit: None=None) -> tuple[int, int]:
                m: Any = active_pattern_result
                return (parse(get_item(groups(m), "row") or "", 511, False, 32) - 1, parse(get_item(groups(m), "column") or "", 511, False, 32) - 1)

            return _arrow4112() if (active_pattern_result is not None) else to_fail(printf("Fragment Selector \"%s\" could not be parsed as text/csv cell."))(s)

        return _arrow4113()


CSV_reflection = _expr4114

__all__ = ["CSV_reflection"]

