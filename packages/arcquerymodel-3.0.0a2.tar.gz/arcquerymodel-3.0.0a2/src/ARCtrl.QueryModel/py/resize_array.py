from collections.abc import Callable
from typing import (Any, TypeVar)
from .fable_modules.fable_library.option import value
from .fable_modules.fable_library.seq2 import (distinct as distinct_1, distinct_by as distinct_by_1)
from .fable_modules.fable_library.types import Array
from .fable_modules.fable_library.util import (get_enumerator, dispose, equals, structural_hash)

__A = TypeVar("__A")

__B = TypeVar("__B")

__C = TypeVar("__C")

__A_ = TypeVar("__A_")

__B_ = TypeVar("__B_")

def append(a: Array[Any], b: Array[Any]) -> Array[Any]:
    c: Array[__A] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __A = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (c.append(i))

    finally: 
        dispose(enumerator)

    enumerator_1: Any = get_enumerator(b)
    try: 
        while enumerator_1.System_Collections_IEnumerator_MoveNext():
            j: __A = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
            (c.append(j))

    finally: 
        dispose(enumerator_1)

    return c


def map(f: Callable[[__A], __B], a: Array[Any]) -> Array[Any]:
    b: Array[__B] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __A = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (b.append(f(i)))

    finally: 
        dispose(enumerator)

    return b


def choose(f: Callable[[__A], __B | None], a: Array[Any]) -> Array[Any]:
    b: Array[__B] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            match_value: __B | None = f(enumerator.System_Collections_Generic_IEnumerator_1_get_Current())
            if match_value is None:
                pass

            else: 
                x: __B = value(match_value)
                (b.append(x))


    finally: 
        dispose(enumerator)

    return b


def filter(f: Callable[[__A], bool], a: Array[Any]) -> Array[Any]:
    b: Array[__A] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __A = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            if f(i):
                (b.append(i))


    finally: 
        dispose(enumerator)

    return b


def fold(f: Callable[[__A, __B], __A], s: Any, a: Array[Any]) -> Any:
    state: __A = s
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __B = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            state = f(state, i)

    finally: 
        dispose(enumerator)

    return state


def fold_back(f: Callable[[__A, __B], __B], a: Array[Any], s: Any) -> Any:
    state: __B = s
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __A = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            state = f(i, state)

    finally: 
        dispose(enumerator)

    return state


def iter(f: Callable[[__A], None], a: Array[Any]) -> None:
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            f(enumerator.System_Collections_Generic_IEnumerator_1_get_Current())

    finally: 
        dispose(enumerator)



def reduce(f: Callable[[__A, __A], __A], a: Array[Any]) -> Any:
    if len(a) == 0:
        raise Exception("ResizeArray.reduce: empty array")

    elif len(a) == 1:
        return a[0]

    else: 
        a_5: Array[__A] = a
        state: __A = a_5[0]
        for i in range(1, (len(a_5) - 1) + 1, 1):
            state = f(state, a_5[i])
        return state



def collect(f: Callable[[__A], __B], a: Array[Any]) -> Array[Any]:
    b: Array[__C] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            with get_enumerator(f(enumerator.System_Collections_Generic_IEnumerator_1_get_Current())) as enumerator_1:
                while enumerator_1.System_Collections_IEnumerator_MoveNext():
                    j: __C = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
                    (b.append(j))

    finally: 
        dispose(enumerator)

    return b


def singleton(x: Any | None=None) -> Array[Any]:
    a: Array[__A] = []
    (a.append(x))
    return a


def distinct(a: Array[Any]) -> Array[Any]:
    class ObjectExpr4102:
        @property
        def Equals(self) -> Callable[[__A_, __A_], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[__A_], int]:
            return structural_hash

    return list(distinct_1(a, ObjectExpr4102()))


def distinct_by(f: Callable[[__A], __B], a: Array[Any]) -> Array[Any]:
    class ObjectExpr4103:
        @property
        def Equals(self) -> Callable[[__B_, __B_], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[__B_], int]:
            return structural_hash

    return list(distinct_by_1(f, a, ObjectExpr4103()))


__all__ = ["append", "map", "choose", "filter", "fold", "fold_back", "iter", "reduce", "collect", "singleton", "distinct", "distinct_by"]

