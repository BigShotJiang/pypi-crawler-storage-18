from __future__ import annotations
from typing import Any
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_core.Process.factor import Factor
from .fable_modules.arctrl_core.Process.material_attribute import (MaterialAttribute, MaterialAttribute_create_A220A8A)
from .fable_modules.arctrl_core.Process.protocol_parameter import ProtocolParameter
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.types import FSharpException

def _expr4240() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingParameterException", None, MissingParameterException, class_type("System.Exception"))


class MissingParameterException(FSharpException):
    def __init__(self, Data0: ProtocolParameter) -> None:
        super().__init__()
        self.Data0 = Data0


MissingParameterException_reflection = _expr4240

def _expr4241() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingCharacteristicException", None, MissingCharacteristicException, class_type("System.Exception"))


class MissingCharacteristicException(FSharpException):
    def __init__(self, Data0: MaterialAttribute) -> None:
        super().__init__()
        self.Data0 = Data0


MissingCharacteristicException_reflection = _expr4241

def _expr4243() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingFactorException", None, MissingFactorException, class_type("System.Exception"))


class MissingFactorException(FSharpException):
    def __init__(self, Data0: Factor) -> None:
        super().__init__()
        self.Data0 = Data0


MissingFactorException_reflection = _expr4243

def _expr4244() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingCategoryException", None, MissingCategoryException, class_type("System.Exception"))


class MissingCategoryException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation) -> None:
        super().__init__()
        self.Data0 = Data0


MissingCategoryException_reflection = _expr4244

def _expr4245() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingOATextException", None, MissingOATextException, class_type("System.Exception"))


class MissingOATextException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation) -> None:
        super().__init__()
        self.Data0 = Data0


MissingOATextException_reflection = _expr4245

def _expr4246() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingProtocolException", None, MissingProtocolException, class_type("System.Exception"))


class MissingProtocolException(FSharpException):
    def __init__(self, Data0: str) -> None:
        super().__init__()
        self.Data0 = Data0


MissingProtocolException_reflection = _expr4246

def _expr4249() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingProtocolWithTypeException", None, MissingProtocolWithTypeException, class_type("System.Exception"))


class MissingProtocolWithTypeException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation) -> None:
        super().__init__()
        self.Data0 = Data0


MissingProtocolWithTypeException_reflection = _expr4249

def _expr4250() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.ProtocolHasNoDescriptionException", None, ProtocolHasNoDescriptionException, class_type("System.Exception"))


class ProtocolHasNoDescriptionException(FSharpException):
    def __init__(self, Data0: str) -> None:
        super().__init__()
        self.Data0 = Data0


ProtocolHasNoDescriptionException_reflection = _expr4250

def _expr4251() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingValueException", None, MissingValueException, class_type("System.Exception"))


class MissingValueException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation) -> None:
        super().__init__()
        self.Data0 = Data0


MissingValueException_reflection = _expr4251

def _expr4254() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.MissingUnitException", None, MissingUnitException, class_type("System.Exception"))


class MissingUnitException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation) -> None:
        super().__init__()
        self.Data0 = Data0


MissingUnitException_reflection = _expr4254

def _expr4255() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.NoSynonymInTargOntologyException", None, NoSynonymInTargOntologyException, class_type("System.Exception"))


class NoSynonymInTargOntologyException(FSharpException):
    def __init__(self, Data0: OntologyAnnotation, Data1: str) -> None:
        super().__init__()
        self.Data0 = Data0
        self.Data1 = Data1


NoSynonymInTargOntologyException_reflection = _expr4255

def _expr4256() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.FieldNotFilledException", None, FieldNotFilledException, class_type("System.Exception"))


class FieldNotFilledException(FSharpException):
    def __init__(self, Data0: str) -> None:
        super().__init__()
        self.Data0 = Data0


FieldNotFilledException_reflection = _expr4256

def missing_category(oa: OntologyAnnotation) -> Any:
    raise MissingCategoryException(oa)


def missing_factor(oa: OntologyAnnotation) -> Any:
    raise MissingFactorException(Factor.create(None, oa))


def missing_parameter(oa: OntologyAnnotation) -> Any:
    raise MissingParameterException(ProtocolParameter.create(None, oa))


def missing_characteristic(oa: OntologyAnnotation) -> Any:
    raise MissingCharacteristicException(MaterialAttribute_create_A220A8A(None, oa))


def missing_oatext(oa: OntologyAnnotation) -> Any:
    raise MissingOATextException(oa)


def missing_value(oa: OntologyAnnotation) -> Any:
    raise MissingValueException(oa)


def no_synonym_in_target_ontology(oa: OntologyAnnotation, target_ont: str) -> Any:
    raise NoSynonymInTargOntologyException(oa, target_ont)


def missing_protocol_with_type(oa: OntologyAnnotation) -> Any:
    raise MissingProtocolWithTypeException(oa)


def protocol_has_no_description(name: str) -> Any:
    raise ProtocolHasNoDescriptionException(name)


def _expr4257() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoIDException", None, InvestigationHasNoIDException, class_type("System.Exception"))


class InvestigationHasNoIDException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoIDException_reflection = _expr4257

def _expr4258() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoFileNameException", None, InvestigationHasNoFileNameException, class_type("System.Exception"))


class InvestigationHasNoFileNameException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoFileNameException_reflection = _expr4258

def _expr4259() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoIdentifierException", None, InvestigationHasNoIdentifierException, class_type("System.Exception"))


class InvestigationHasNoIdentifierException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoIdentifierException_reflection = _expr4259

def _expr4261() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoTitleException", None, InvestigationHasNoTitleException, class_type("System.Exception"))


class InvestigationHasNoTitleException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoTitleException_reflection = _expr4261

def _expr4262() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoDescriptionException", None, InvestigationHasNoDescriptionException, class_type("System.Exception"))


class InvestigationHasNoDescriptionException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoDescriptionException_reflection = _expr4262

def _expr4263() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoSubmissionDateException", None, InvestigationHasNoSubmissionDateException, class_type("System.Exception"))


class InvestigationHasNoSubmissionDateException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoSubmissionDateException_reflection = _expr4263

def _expr4264() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoPublicReleaseDateException", None, InvestigationHasNoPublicReleaseDateException, class_type("System.Exception"))


class InvestigationHasNoPublicReleaseDateException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoPublicReleaseDateException_reflection = _expr4264

def _expr4265() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoOntologySourceReferencesException", None, InvestigationHasNoOntologySourceReferencesException, class_type("System.Exception"))


class InvestigationHasNoOntologySourceReferencesException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoOntologySourceReferencesException_reflection = _expr4265

def _expr4266() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoPublicationsException", None, InvestigationHasNoPublicationsException, class_type("System.Exception"))


class InvestigationHasNoPublicationsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoPublicationsException_reflection = _expr4266

def _expr4267() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoContactsException", None, InvestigationHasNoContactsException, class_type("System.Exception"))


class InvestigationHasNoContactsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoContactsException_reflection = _expr4267

def _expr4268() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoStudiesException", None, InvestigationHasNoStudiesException, class_type("System.Exception"))


class InvestigationHasNoStudiesException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoStudiesException_reflection = _expr4268

def _expr4269() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.InvestigationHasNoCommentsException", None, InvestigationHasNoCommentsException, class_type("System.Exception"))


class InvestigationHasNoCommentsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


InvestigationHasNoCommentsException_reflection = _expr4269

def _expr4270() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoIDException", None, StudyHasNoIDException, class_type("System.Exception"))


class StudyHasNoIDException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoIDException_reflection = _expr4270

def _expr4271() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoFileNameException", None, StudyHasNoFileNameException, class_type("System.Exception"))


class StudyHasNoFileNameException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoFileNameException_reflection = _expr4271

def _expr4273() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoIdentifierException", None, StudyHasNoIdentifierException, class_type("System.Exception"))


class StudyHasNoIdentifierException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoIdentifierException_reflection = _expr4273

def _expr4274() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoTitleException", None, StudyHasNoTitleException, class_type("System.Exception"))


class StudyHasNoTitleException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoTitleException_reflection = _expr4274

def _expr4275() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoDescriptionException", None, StudyHasNoDescriptionException, class_type("System.Exception"))


class StudyHasNoDescriptionException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoDescriptionException_reflection = _expr4275

def _expr4276() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoSubmissionDateException", None, StudyHasNoSubmissionDateException, class_type("System.Exception"))


class StudyHasNoSubmissionDateException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoSubmissionDateException_reflection = _expr4276

def _expr4277() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoPublicReleaseDateException", None, StudyHasNoPublicReleaseDateException, class_type("System.Exception"))


class StudyHasNoPublicReleaseDateException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoPublicReleaseDateException_reflection = _expr4277

def _expr4278() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoPublicationsException", None, StudyHasNoPublicationsException, class_type("System.Exception"))


class StudyHasNoPublicationsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoPublicationsException_reflection = _expr4278

def _expr4279() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoContactsException", None, StudyHasNoContactsException, class_type("System.Exception"))


class StudyHasNoContactsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoContactsException_reflection = _expr4279

def _expr4280() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoDesignDescriptorsException", None, StudyHasNoDesignDescriptorsException, class_type("System.Exception"))


class StudyHasNoDesignDescriptorsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoDesignDescriptorsException_reflection = _expr4280

def _expr4281() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoProtocolsException", None, StudyHasNoProtocolsException, class_type("System.Exception"))


class StudyHasNoProtocolsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoProtocolsException_reflection = _expr4281

def _expr4282() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoMaterialsException", None, StudyHasNoMaterialsException, class_type("System.Exception"))


class StudyHasNoMaterialsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoMaterialsException_reflection = _expr4282

def _expr4283() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoProcessSequenceException", None, StudyHasNoProcessSequenceException, class_type("System.Exception"))


class StudyHasNoProcessSequenceException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoProcessSequenceException_reflection = _expr4283

def _expr4284() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoAssaysException", None, StudyHasNoAssaysException, class_type("System.Exception"))


class StudyHasNoAssaysException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoAssaysException_reflection = _expr4284

def _expr4285() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoFactorsException", None, StudyHasNoFactorsException, class_type("System.Exception"))


class StudyHasNoFactorsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoFactorsException_reflection = _expr4285

def _expr4286() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoCharacteristicCategoriesException", None, StudyHasNoCharacteristicCategoriesException, class_type("System.Exception"))


class StudyHasNoCharacteristicCategoriesException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoCharacteristicCategoriesException_reflection = _expr4286

def _expr4287() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoUnitCategoriesException", None, StudyHasNoUnitCategoriesException, class_type("System.Exception"))


class StudyHasNoUnitCategoriesException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoUnitCategoriesException_reflection = _expr4287

def _expr4288() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.StudyHasNoStudyHasNoCommentsExceptionException", None, StudyHasNoStudyHasNoCommentsExceptionException, class_type("System.Exception"))


class StudyHasNoStudyHasNoCommentsExceptionException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


StudyHasNoStudyHasNoCommentsExceptionException_reflection = _expr4288

def _expr4289() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoIDException", None, PersonHasNoIDException, class_type("System.Exception"))


class PersonHasNoIDException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoIDException_reflection = _expr4289

def _expr4290() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoLastNameException", None, PersonHasNoLastNameException, class_type("System.Exception"))


class PersonHasNoLastNameException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoLastNameException_reflection = _expr4290

def _expr4291() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoFirstNameException", None, PersonHasNoFirstNameException, class_type("System.Exception"))


class PersonHasNoFirstNameException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoFirstNameException_reflection = _expr4291

def _expr4292() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoMidInitialsException", None, PersonHasNoMidInitialsException, class_type("System.Exception"))


class PersonHasNoMidInitialsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoMidInitialsException_reflection = _expr4292

def _expr4294() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoEMailException", None, PersonHasNoEMailException, class_type("System.Exception"))


class PersonHasNoEMailException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoEMailException_reflection = _expr4294

def _expr4295() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoPhoneException", None, PersonHasNoPhoneException, class_type("System.Exception"))


class PersonHasNoPhoneException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoPhoneException_reflection = _expr4295

def _expr4296() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoFaxException", None, PersonHasNoFaxException, class_type("System.Exception"))


class PersonHasNoFaxException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoFaxException_reflection = _expr4296

def _expr4297() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoAddressException", None, PersonHasNoAddressException, class_type("System.Exception"))


class PersonHasNoAddressException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoAddressException_reflection = _expr4297

def _expr4298() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoAffiliationException", None, PersonHasNoAffiliationException, class_type("System.Exception"))


class PersonHasNoAffiliationException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoAffiliationException_reflection = _expr4298

def _expr4299() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoRolesException", None, PersonHasNoRolesException, class_type("System.Exception"))


class PersonHasNoRolesException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoRolesException_reflection = _expr4299

def _expr4300() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.Errors.PersonHasNoCommentsException", None, PersonHasNoCommentsException, class_type("System.Exception"))


class PersonHasNoCommentsException(FSharpException):
    def __init__(self) -> None:
        super().__init__()


PersonHasNoCommentsException_reflection = _expr4300

__all__ = ["MissingParameterException_reflection", "MissingCharacteristicException_reflection", "MissingFactorException_reflection", "MissingCategoryException_reflection", "MissingOATextException_reflection", "MissingProtocolException_reflection", "MissingProtocolWithTypeException_reflection", "ProtocolHasNoDescriptionException_reflection", "MissingValueException_reflection", "MissingUnitException_reflection", "NoSynonymInTargOntologyException_reflection", "FieldNotFilledException_reflection", "missing_category", "missing_factor", "missing_parameter", "missing_characteristic", "missing_oatext", "missing_value", "no_synonym_in_target_ontology", "missing_protocol_with_type", "protocol_has_no_description", "InvestigationHasNoIDException_reflection", "InvestigationHasNoFileNameException_reflection", "InvestigationHasNoIdentifierException_reflection", "InvestigationHasNoTitleException_reflection", "InvestigationHasNoDescriptionException_reflection", "InvestigationHasNoSubmissionDateException_reflection", "InvestigationHasNoPublicReleaseDateException_reflection", "InvestigationHasNoOntologySourceReferencesException_reflection", "InvestigationHasNoPublicationsException_reflection", "InvestigationHasNoContactsException_reflection", "InvestigationHasNoStudiesException_reflection", "InvestigationHasNoCommentsException_reflection", "StudyHasNoIDException_reflection", "StudyHasNoFileNameException_reflection", "StudyHasNoIdentifierException_reflection", "StudyHasNoTitleException_reflection", "StudyHasNoDescriptionException_reflection", "StudyHasNoSubmissionDateException_reflection", "StudyHasNoPublicReleaseDateException_reflection", "StudyHasNoPublicationsException_reflection", "StudyHasNoContactsException_reflection", "StudyHasNoDesignDescriptorsException_reflection", "StudyHasNoProtocolsException_reflection", "StudyHasNoMaterialsException_reflection", "StudyHasNoProcessSequenceException_reflection", "StudyHasNoAssaysException_reflection", "StudyHasNoFactorsException_reflection", "StudyHasNoCharacteristicCategoriesException_reflection", "StudyHasNoUnitCategoriesException_reflection", "StudyHasNoStudyHasNoCommentsExceptionException_reflection", "PersonHasNoIDException_reflection", "PersonHasNoLastNameException_reflection", "PersonHasNoFirstNameException_reflection", "PersonHasNoMidInitialsException_reflection", "PersonHasNoEMailException_reflection", "PersonHasNoPhoneException_reflection", "PersonHasNoFaxException_reflection", "PersonHasNoAddressException_reflection", "PersonHasNoAffiliationException_reflection", "PersonHasNoRolesException_reflection", "PersonHasNoCommentsException_reflection"]

