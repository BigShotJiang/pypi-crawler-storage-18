from __future__ import annotations
from typing import Any
from .fable_modules.arctrl_core.comment import Comment
from .fable_modules.fable_library.list import (pick, FSharpList, try_pick, empty)
from .fable_modules.fable_library.option import (value, some, default_arg)
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.seq import of_list
from .fable_modules.fable_library.util import (get_enumerator, IEnumerator, to_iterator)

def CommentList_item(k: str, comments: FSharpList[Comment]) -> str | None:
    def chooser(c: Comment, k: Any=k, comments: Any=comments) -> (str | None) | None:
        if value(c.Name) == k:
            return some(c.Value)

        else: 
            return None


    return pick(chooser, comments)


def CommentList_tryItem(k: str, comments: FSharpList[Comment]) -> (str | None) | None:
    def chooser(c: Comment, k: Any=k, comments: Any=comments) -> (str | None) | None:
        if (value(c.Name) == k) if (c.Name is not None) else False:
            return some(c.Value)

        else: 
            return None


    return try_pick(chooser, comments)


def _expr4118() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.QCommentCollection", None, QCommentCollection)


class QCommentCollection:
    def __init__(self, comments: FSharpList[Comment]) -> None:
        self.comments: FSharpList[Comment] = comments

    def GetEnumerator(self, __unit: None=None) -> IEnumerator[Comment]:
        this: QCommentCollection = self
        return get_enumerator(of_list(QCommentCollection__get_Comments(this)))

    def __iter__(self) -> IEnumerator[Comment]:
        return to_iterator(self.GetEnumerator())

    def System_Collections_IEnumerable_GetEnumerator(self, __unit: None=None) -> IEnumerator[Any]:
        this: QCommentCollection = self
        return get_enumerator(this)


QCommentCollection_reflection = _expr4118

def QCommentCollection__ctor_2F324FC0(comments: FSharpList[Comment]) -> QCommentCollection:
    return QCommentCollection(comments)


def QCommentCollection__ctor_416FCF23(comments: FSharpList[Comment] | None=None) -> QCommentCollection:
    return QCommentCollection__ctor_2F324FC0(default_arg(comments, empty()))


def QCommentCollection__get_Comments(this: QCommentCollection) -> FSharpList[Comment]:
    return this.comments


def QCommentCollection__GetValueByName_Z721C83C5(this: QCommentCollection, key: str) -> str | None:
    return CommentList_item(key, QCommentCollection__get_Comments(this))


def QCommentCollection__TryGetValueByName_Z721C83C5(this: QCommentCollection, key: str) -> (str | None) | None:
    return CommentList_tryItem(key, QCommentCollection__get_Comments(this))


__all__ = ["CommentList_item", "CommentList_tryItem", "QCommentCollection_reflection", "QCommentCollection__ctor_416FCF23", "QCommentCollection__get_Comments", "QCommentCollection__GetValueByName_Z721C83C5", "QCommentCollection__TryGetValueByName_Z721C83C5"]

