from __future__ import annotations
from collections.abc import Callable
from typing import (Any, TypeVar)
from .arc_tables import (ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3, QNode__get_Name, ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static, QNode)
from .errors import (InvestigationHasNoTitleException, InvestigationHasNoDescriptionException, InvestigationHasNoSubmissionDateException, InvestigationHasNoPublicReleaseDateException, InvestigationHasNoOntologySourceReferencesException, InvestigationHasNoPublicationsException, InvestigationHasNoContactsException)
from .fable_modules.arctrl_core.arc_types import (ArcStudy, ArcAssay, ArcInvestigation)
from .fable_modules.arctrl_core.ontology_source_reference import OntologySourceReference
from .fable_modules.arctrl_core.person import Person
from .fable_modules.arctrl_core.publication import Publication
from .fable_modules.arctrl_core.Table.arc_table import ArcTable
from .fable_modules.arctrl_core.Table.arc_tables import ArcTables
from .fable_modules.fable_library.list import (FSharpList, collect as collect_1)
from .fable_modules.fable_library.map_util import (get_item_from_dict, add_to_dict)
from .fable_modules.fable_library.seq import (to_list, delay, collect, singleton, append)
from .fable_modules.fable_library.string_ import (to_fail, printf)
from .fable_modules.fable_library.types import Array
from .fable_modules.fable_library.util import (int32_to_string, IEnumerable_1)
from .value import ISAValue
from .value_collection import (ValueCollection__ctor_6ED77DA8, ValueCollection__get_Values, ValueCollection, ValueCollection__Characteristics_6DFDD678, ValueCollection__Factors_6DFDD678, ValueCollection__Parameters_6DFDD678)

_T = TypeVar("_T")

def dedupe_name(getter: Callable[[_T], str], setter: Callable[[str, _T], _T], elements: IEnumerable_1[Any]) -> FSharpList[Any]:
    dict_1: Any = dict([])
    def _arrow4323(__unit: None=None, getter: Any=getter, setter: Any=setter, elements: Any=elements) -> IEnumerable_1[_T]:
        def _arrow4322(e: _T | None=None) -> IEnumerable_1[_T]:
            name: str = getter(e)
            if name in dict_1:
                count: int = get_item_from_dict(dict_1, name) or 0
                dict_1[name] = count + 1
                return singleton(setter((name + " ") + int32_to_string(count), e))

            else: 
                add_to_dict(dict_1, name, 1)
                return singleton(e)


        return collect(_arrow4322, elements)

    return to_list(delay(_arrow4323))


def ARCtrl_ArcInvestigation__ArcInvestigation_get_ArcTables(this: ArcInvestigation) -> ArcTables:
    def getter(a_1: ArcTable, this: Any=this) -> str:
        return a_1.Name

    def setter(v: str, a_2: ArcTable, this: Any=this) -> ArcTable:
        return ArcTable.from_arc_table_values(v, a_2.Headers, a_2.Values)

    def _arrow4327(__unit: None=None, this: Any=this) -> IEnumerable_1[ArcTable]:
        def _arrow4324(s: ArcStudy) -> IEnumerable_1[ArcTable]:
            return s.Tables

        def _arrow4326(__unit: None=None) -> IEnumerable_1[ArcTable]:
            def _arrow4325(a: ArcAssay) -> IEnumerable_1[ArcTable]:
                return a.Tables

            return collect(_arrow4325, this.Assays)

        return append(collect(_arrow4324, this.Studies), delay(_arrow4326))

    return ArcTables(list(dedupe_name(getter, setter, delay(_arrow4327))))


def ARCtrl_ArcInvestigation__ArcInvestigation_PreviousValuesOf_Z69D21E40(this: ArcInvestigation, node: QNode, ProtocolName: str | None=None, StudyName: str | None=None, AssayName: str | None=None) -> ValueCollection:
    if StudyName is None:
        if AssayName is None:
            return ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(ARCtrl_ArcInvestigation__ArcInvestigation_get_ArcTables(this), QNode__get_Name(node), ProtocolName)

        else: 
            a_1: str = AssayName
            previous_nodes_1: FSharpList[str] = ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static(QNode__get_Name(node), ARCtrl_ArcInvestigation__ArcInvestigation_get_ArcTables(this))
            a_2: ArcAssay = this.GetAssay(a_1)
            def mapping_1(n_1: str, this: Any=this, node: Any=node, ProtocolName: Any=ProtocolName, StudyName: Any=StudyName, AssayName: Any=AssayName) -> FSharpList[ISAValue]:
                return ValueCollection__get_Values(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(a_2, n_1, ProtocolName))

            return ValueCollection__ctor_6ED77DA8(collect_1(mapping_1, previous_nodes_1))


    elif AssayName is None:
        s_1: str = StudyName
        previous_nodes: FSharpList[str] = ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static(QNode__get_Name(node), ARCtrl_ArcInvestigation__ArcInvestigation_get_ArcTables(this))
        s_2: ArcStudy = this.GetStudy(s_1)
        def mapping(n: str, this: Any=this, node: Any=node, ProtocolName: Any=ProtocolName, StudyName: Any=StudyName, AssayName: Any=AssayName) -> FSharpList[ISAValue]:
            return ValueCollection__get_Values(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(s_2, n, ProtocolName))

        return ValueCollection__ctor_6ED77DA8(collect_1(mapping, previous_nodes))

    else: 
        a: str = AssayName
        s: str = StudyName
        arg: str = QNode__get_Name(node)
        return to_fail(printf("Could not retreive previous of node %s: Cannot specify both StudyName and AssayName"))(arg)



def ARCtrl_ArcInvestigation__ArcInvestigation_PreviousCharacteristicsOf_Z69D21E40(this: ArcInvestigation, node: QNode, ProtocolName: str | None=None, StudyName: str | None=None, AssayName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcInvestigation__ArcInvestigation_PreviousValuesOf_Z69D21E40(this, node, ProtocolName, StudyName, AssayName))


def ARCtrl_ArcInvestigation__ArcInvestigation_PreviousFactorsOf_Z69D21E40(this: ArcInvestigation, node: QNode, ProtocolName: str | None=None, StudyName: str | None=None, AssayName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcInvestigation__ArcInvestigation_PreviousValuesOf_Z69D21E40(this, node, ProtocolName, StudyName, AssayName))


def ARCtrl_ArcInvestigation__ArcInvestigation_PreviousParametersOf_Z69D21E40(this: ArcInvestigation, node: QNode, ProtocolName: str | None=None, StudyName: str | None=None, AssayName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcInvestigation__ArcInvestigation_PreviousValuesOf_Z69D21E40(this, node, ProtocolName, StudyName, AssayName))


def Investigation_identifier(i: ArcInvestigation) -> str:
    return i.Identifier


def Investigation_title(i: ArcInvestigation) -> str:
    match_value: str | None = i.Title
    if match_value is None:
        raise InvestigationHasNoTitleException()

    else: 
        return match_value



def Investigation_description(i: ArcInvestigation) -> str:
    match_value: str | None = i.Description
    if match_value is None:
        raise InvestigationHasNoDescriptionException()

    else: 
        return match_value



def Investigation_submissionDate(i: ArcInvestigation) -> str:
    match_value: str | None = i.SubmissionDate
    if match_value is None:
        raise InvestigationHasNoSubmissionDateException()

    else: 
        return match_value



def Investigation_publicReleaseDate(i: ArcInvestigation) -> str:
    match_value: str | None = i.PublicReleaseDate
    if match_value is None:
        raise InvestigationHasNoPublicReleaseDateException()

    else: 
        return match_value



def Investigation_ontologySourceReferences(i: ArcInvestigation) -> Array[OntologySourceReference]:
    match_value: Array[OntologySourceReference] = i.OntologySourceReferences
    if len(match_value) == 0:
        raise InvestigationHasNoOntologySourceReferencesException()

    else: 
        return match_value



def Investigation_publications(i: ArcInvestigation) -> Array[Publication]:
    match_value: Array[Publication] = i.Publications
    if len(match_value) == 0:
        raise InvestigationHasNoPublicationsException()

    else: 
        return match_value



def Investigation_contacts(i: ArcInvestigation) -> Array[Person]:
    match_value: Array[Person] = i.Contacts
    if len(match_value) == 0:
        raise InvestigationHasNoContactsException()

    else: 
        return match_value



__all__ = ["dedupe_name", "ARCtrl_ArcInvestigation__ArcInvestigation_get_ArcTables", "ARCtrl_ArcInvestigation__ArcInvestigation_PreviousValuesOf_Z69D21E40", "ARCtrl_ArcInvestigation__ArcInvestigation_PreviousCharacteristicsOf_Z69D21E40", "ARCtrl_ArcInvestigation__ArcInvestigation_PreviousFactorsOf_Z69D21E40", "ARCtrl_ArcInvestigation__ArcInvestigation_PreviousParametersOf_Z69D21E40", "Investigation_identifier", "Investigation_title", "Investigation_description", "Investigation_submissionDate", "Investigation_publicReleaseDate", "Investigation_ontologySourceReferences", "Investigation_publications", "Investigation_contacts"]

