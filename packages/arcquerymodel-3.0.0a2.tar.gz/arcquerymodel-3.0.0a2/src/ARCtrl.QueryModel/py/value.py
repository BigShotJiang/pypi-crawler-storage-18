from __future__ import annotations
from collections.abc import Callable
from typing import Any
from .fable_modules.arctrl_core.conversion import (JsonTypes_composeCharacteristicValue, JsonTypes_composeFactorValue, JsonTypes_composeComponent, JsonTypes_composeParameterValue)
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_core.Process.component import (Component_reflection, Component__MapCategory_658CFBF6, Component, Component__get_NameText, Component__get_ValueWithUnitText)
from .fable_modules.arctrl_core.Process.factor import Factor
from .fable_modules.arctrl_core.Process.factor_value import (FactorValue_reflection, FactorValue__MapCategory_658CFBF6, FactorValue, FactorValue__get_NameText, FactorValue__get_ValueWithUnitText)
from .fable_modules.arctrl_core.Process.material_attribute import MaterialAttribute
from .fable_modules.arctrl_core.Process.material_attribute_value import (MaterialAttributeValue_reflection, MaterialAttributeValue__MapCategory_658CFBF6, MaterialAttributeValue, MaterialAttributeValue__get_NameText, MaterialAttributeValue__get_ValueWithUnitText)
from .fable_modules.arctrl_core.Process.process_parameter_value import (ProcessParameterValue_reflection, ProcessParameterValue)
from .fable_modules.arctrl_core.Process.protocol_parameter import ProtocolParameter
from .fable_modules.arctrl_core.Table.composite_cell import CompositeCell
from .fable_modules.arctrl_core.Table.composite_header import CompositeHeader
from .fable_modules.arctrl_core.value import Value as Value_4
from .fable_modules.fable_library.option import (value, bind, map)
from .fable_modules.fable_library.reflection import (TypeInfo, union_type)
from .fable_modules.fable_library.types import (Array, Union)

def _expr4307() -> TypeInfo:
    return union_type("ARCtrl.QueryModel.ISAValue", [], ISAValue, lambda: [[("Item", ProcessParameterValue_reflection())], [("Item", MaterialAttributeValue_reflection())], [("Item", FactorValue_reflection())], [("Item", Component_reflection())]])


class ISAValue(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Parameter", "Characteristic", "Factor", "Component"]


ISAValue_reflection = _expr4307

def ISAValue__MapCategory_658CFBF6(this: ISAValue, f: Callable[[OntologyAnnotation], OntologyAnnotation]) -> ISAValue:
    if this.tag == 1:
        return ISAValue(1, MaterialAttributeValue__MapCategory_658CFBF6(this.fields[0], f))

    elif this.tag == 2:
        return ISAValue(2, FactorValue__MapCategory_658CFBF6(this.fields[0], f))

    elif this.tag == 3:
        return ISAValue(3, Component__MapCategory_658CFBF6(this.fields[0], f))

    else: 
        return ISAValue(0, this.fields[0].MapCategory(f))



def ISAValue_tryCompose(header: CompositeHeader, cell: CompositeCell) -> ISAValue | None:
    if header.is_characteristic:
        return ISAValue(1, JsonTypes_composeCharacteristicValue(header, cell))

    elif header.is_factor:
        return ISAValue(2, JsonTypes_composeFactorValue(header, cell))

    elif header.is_component:
        return ISAValue(3, JsonTypes_composeComponent(header, cell))

    elif header.is_parameter:
        return ISAValue(0, JsonTypes_composeParameterValue(header, cell))

    else: 
        return None



def ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue(this: ISAValue) -> bool:
    if this.tag == 1:
        return True

    else: 
        return False



def ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue(this: ISAValue) -> bool:
    if this.tag == 0:
        return True

    else: 
        return False



def ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue(this: ISAValue) -> bool:
    if this.tag == 2:
        return True

    else: 
        return False



def ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent(this: ISAValue) -> bool:
    if this.tag == 3:
        return True

    else: 
        return False



def ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(this: ISAValue) -> OntologyAnnotation:
    if this.tag == 1:
        try: 
            return value(value(this.fields[0].Category).CharacteristicType)

        except Exception as match_value_1:
            raise Exception("Characteristic does not contain category")


    elif this.tag == 2:
        try: 
            return value(value(this.fields[0].Category).FactorType)

        except Exception as match_value_2:
            raise Exception("Factor does not contain category")


    elif this.tag == 3:
        try: 
            return value(this.fields[0].ComponentType)

        except Exception as match_value_3:
            raise Exception("Component does not contain category")


    else: 
        try: 
            return value(value(this.fields[0].Category).ParameterName)

        except Exception as match_value:
            raise Exception("Parameter does not contain category")




def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryCategory(this: ISAValue) -> OntologyAnnotation | None:
    if this.tag == 1:
        def binder_1(c_2: MaterialAttribute, this: Any=this) -> OntologyAnnotation | None:
            return c_2.CharacteristicType

        return bind(binder_1, this.fields[0].Category)

    elif this.tag == 2:
        def binder_2(c_3: Factor, this: Any=this) -> OntologyAnnotation | None:
            return c_3.FactorType

        return bind(binder_2, this.fields[0].Category)

    elif this.tag == 3:
        return this.fields[0].ComponentType

    else: 
        def binder(c: ProtocolParameter, this: Any=this) -> OntologyAnnotation | None:
            return c.ParameterName

        return bind(binder, this.fields[0].Category)



def ARCtrl_QueryModel_ISAValue__ISAValue_get_Unit(this: ISAValue) -> OntologyAnnotation:
    if this.tag == 1:
        c: MaterialAttributeValue = this.fields[0]
        try: 
            return value(c.Unit)

        except Exception as match_value_1:
            raise Exception(("Characteristic " + MaterialAttributeValue__get_NameText(c)) + " does not contain unit")


    elif this.tag == 2:
        f: FactorValue = this.fields[0]
        try: 
            return value(f.Unit)

        except Exception as match_value_2:
            raise Exception(("Factor " + FactorValue__get_NameText(f)) + " does not contain unit")


    elif this.tag == 3:
        c_1: Component = this.fields[0]
        try: 
            return value(c_1.ComponentUnit)

        except Exception as match_value_3:
            raise Exception(("Component " + Component__get_NameText(c_1)) + " does not contain unit")


    else: 
        p: ProcessParameterValue = this.fields[0]
        try: 
            return value(p.Unit)

        except Exception as match_value:
            raise Exception(("Parameter " + p.NameText) + " does not contain unit")




def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryUnit(this: ISAValue) -> OntologyAnnotation | None:
    if this.tag == 1:
        return this.fields[0].Unit

    elif this.tag == 2:
        return this.fields[0].Unit

    elif this.tag == 3:
        return this.fields[0].ComponentUnit

    else: 
        return this.fields[0].Unit



def ARCtrl_QueryModel_ISAValue__ISAValue_get_Value(this: ISAValue) -> Value_4:
    if this.tag == 1:
        c: MaterialAttributeValue = this.fields[0]
        try: 
            return value(c.Value)

        except Exception as match_value_1:
            raise Exception(("Characteristic " + MaterialAttributeValue__get_NameText(c)) + " does not contain value")


    elif this.tag == 2:
        f: FactorValue = this.fields[0]
        try: 
            return value(f.Value)

        except Exception as match_value_2:
            raise Exception(("Factor " + FactorValue__get_NameText(f)) + " does not contain value")


    elif this.tag == 3:
        c_1: Component = this.fields[0]
        try: 
            return value(c_1.ComponentValue)

        except Exception as match_value_3:
            raise Exception(("Component " + Component__get_NameText(c_1)) + " does not contain value")


    else: 
        p: ProcessParameterValue = this.fields[0]
        try: 
            return value(p.Value)

        except Exception as match_value:
            raise Exception(("Parameter " + p.NameText) + " does not contain value")




def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValue(this: ISAValue) -> Value_4 | None:
    if this.tag == 1:
        try: 
            return value(this.fields[0].Value)

        except Exception as match_value_1:
            return None


    elif this.tag == 2:
        try: 
            return value(this.fields[0].Value)

        except Exception as match_value_2:
            return None


    elif this.tag == 3:
        try: 
            return value(this.fields[0].ComponentValue)

        except Exception as match_value_3:
            return None


    else: 
        try: 
            return value(this.fields[0].Value)

        except Exception as match_value:
            return None




def ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit(this: ISAValue) -> bool:
    if this.tag == 1:
        return this.fields[0].Unit is not None

    elif this.tag == 2:
        return this.fields[0].Unit is not None

    elif this.tag == 3:
        return this.fields[0].ComponentUnit is not None

    else: 
        return this.fields[0].Unit is not None



def ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue(this: ISAValue) -> bool:
    if this.tag == 1:
        return this.fields[0].Value is not None

    elif this.tag == 2:
        return this.fields[0].Value is not None

    elif this.tag == 3:
        return this.fields[0].ComponentValue is not None

    else: 
        return this.fields[0].Value is not None



def ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory(this: ISAValue) -> bool:
    if this.tag == 1:
        return this.fields[0].Category is not None

    elif this.tag == 2:
        return this.fields[0].Category is not None

    elif this.tag == 3:
        return this.fields[0].ComponentType is not None

    else: 
        return this.fields[0].Category is not None



def ARCtrl_QueryModel_ISAValue__ISAValue_get_HeaderText(this: ISAValue) -> str:
    if this.tag == 1:
        return ("Characteristic [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

    elif this.tag == 2:
        return ("Factor [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

    elif this.tag == 3:
        return ("Component [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

    else: 
        return ("Parameter [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"



def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryHeaderText(this: ISAValue) -> str | None:
    if this.tag == 1:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory(this):
            return ("Characteristic [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

        else: 
            return None


    elif this.tag == 2:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory(this):
            return ("Factor [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

        else: 
            return None


    elif this.tag == 3:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory(this):
            return ("Component [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

        else: 
            return None


    elif ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory(this):
        return ("Parameter [" + ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this)) + "]"

    else: 
        return None



def ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText(this: ISAValue) -> str:
    return ARCtrl_QueryModel_ISAValue__ISAValue_get_Category(this).NameText


def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryNameText(this: ISAValue) -> str | None:
    def mapping(c: OntologyAnnotation, this: Any=this) -> str:
        return c.NameText

    return map(mapping, ARCtrl_QueryModel_ISAValue__ISAValue_get_TryCategory(this))


def ARCtrl_QueryModel_ISAValue__ISAValue_get_UnitText(this: ISAValue) -> str:
    return ARCtrl_QueryModel_ISAValue__ISAValue_get_Unit(this).NameText


def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryUnitText(this: ISAValue) -> str | None:
    def mapping(u: OntologyAnnotation, this: Any=this) -> str:
        return u.NameText

    return map(mapping, ARCtrl_QueryModel_ISAValue__ISAValue_get_TryUnit(this))


def ARCtrl_QueryModel_ISAValue__ISAValue_get_ValueText(this: ISAValue) -> str:
    return ARCtrl_QueryModel_ISAValue__ISAValue_get_Value(this).Text


def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValueText(this: ISAValue) -> str | None:
    def mapping(v: Value_4, this: Any=this) -> str:
        return v.Text

    return map(mapping, ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValue(this))


def ARCtrl_QueryModel_ISAValue__ISAValue_get_ValueWithUnitText(this: ISAValue) -> str:
    if this.tag == 1:
        return MaterialAttributeValue__get_ValueWithUnitText(this.fields[0])

    elif this.tag == 2:
        return FactorValue__get_ValueWithUnitText(this.fields[0])

    elif this.tag == 3:
        return Component__get_ValueWithUnitText(this.fields[0])

    else: 
        return this.fields[0].ValueWithUnitText



def ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValueWithUnitText(this: ISAValue) -> str | None:
    if this.tag == 1:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit(this) if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue(this) else False:
            return MaterialAttributeValue__get_ValueWithUnitText(this.fields[0])

        else: 
            return None


    elif this.tag == 2:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit(this) if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue(this) else False:
            return FactorValue__get_ValueWithUnitText(this.fields[0])

        else: 
            return None


    elif this.tag == 3:
        if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit(this) if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue(this) else False:
            return Component__get_ValueWithUnitText(this.fields[0])

        else: 
            return None


    elif ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit(this) if ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue(this) else False:
        return this.fields[0].ValueWithUnitText

    else: 
        return None



__all__ = ["ISAValue_reflection", "ISAValue__MapCategory_658CFBF6", "ISAValue_tryCompose", "ARCtrl_QueryModel_ISAValue__ISAValue_get_IsCharacteristicValue", "ARCtrl_QueryModel_ISAValue__ISAValue_get_IsParameterValue", "ARCtrl_QueryModel_ISAValue__ISAValue_get_IsFactorValue", "ARCtrl_QueryModel_ISAValue__ISAValue_get_IsComponent", "ARCtrl_QueryModel_ISAValue__ISAValue_get_Category", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryCategory", "ARCtrl_QueryModel_ISAValue__ISAValue_get_Unit", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryUnit", "ARCtrl_QueryModel_ISAValue__ISAValue_get_Value", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValue", "ARCtrl_QueryModel_ISAValue__ISAValue_get_HasUnit", "ARCtrl_QueryModel_ISAValue__ISAValue_get_HasValue", "ARCtrl_QueryModel_ISAValue__ISAValue_get_HasCategory", "ARCtrl_QueryModel_ISAValue__ISAValue_get_HeaderText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryHeaderText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_NameText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryNameText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_UnitText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryUnitText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_ValueText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValueText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_ValueWithUnitText", "ARCtrl_QueryModel_ISAValue__ISAValue_get_TryValueWithUnitText"]

