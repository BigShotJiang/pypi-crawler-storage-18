from __future__ import annotations
from typing import Any
from .fragment_selector import CSV
from .fable_modules.arctrl_core.arc_types import (ArcAssay, ArcStudy)
from .fable_modules.arctrl_core.data_context import (DataContext, DataContext__get_Explication)
from .fable_modules.arctrl_core.datamap import Datamap
from .fable_modules.arctrl_core.Helper.collections_ import Dictionary_ofSeq
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_file_system.path import combine
from .fable_modules.arctrl_python.arc import ARC
from .fable_modules.fable_library.array_ import (equals_with, add_range_in_place)
from .fable_modules.fable_library.option import (value, map)
from .fable_modules.fable_library.seq import (try_find, choose, collect, append, iterate)
from .fable_modules.fable_library.string_ import split
from .fable_modules.fable_library.types import Array
from .fable_modules.fable_library.util import (equals, IEnumerable_1)

def ObjectType_isString(ot: OntologyAnnotation) -> bool:
    match_value: str | None = ot.Name
    (pattern_matching_result,) = (None,)
    if match_value is not None:
        if match_value == "string":
            pattern_matching_result = 0

        elif match_value == "String":
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return False



def ObjectType_isFloat(ot: OntologyAnnotation) -> bool:
    match_value: str | None = ot.Name
    (pattern_matching_result,) = (None,)
    if match_value is not None:
        if match_value == "Float":
            pattern_matching_result = 0

        elif match_value == "float":
            pattern_matching_result = 0

        elif match_value == "double":
            pattern_matching_result = 0

        elif match_value == "Double":
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return False



def ObjectType_isInt(ot: OntologyAnnotation) -> bool:
    match_value: str | None = ot.Name
    (pattern_matching_result,) = (None,)
    if match_value is not None:
        if match_value == "int":
            pattern_matching_result = 0

        elif match_value == "Int":
            pattern_matching_result = 0

        elif match_value == "integer":
            pattern_matching_result = 0

        elif match_value == "Integer":
            pattern_matching_result = 0

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return False



DataContext_dataContexts: Array[DataContext] = []

def DataContext_selectorIsIncluded(outer: DataContext, inner: DataContext) -> bool:
    match_value: str | None = outer.Selector
    match_value_1: str | None = inner.Selector
    (pattern_matching_result, i_2, o_2) = (None, None, None)
    if match_value is not None:
        if match_value_1 is not None:
            if match_value == match_value_1:
                pattern_matching_result = 0

            else: 
                pattern_matching_result = 1
                i_2 = match_value_1
                o_2 = match_value


        else: 
            pattern_matching_result = 2


    else: 
        pattern_matching_result = 2

    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return CSV.is_included_string(o_2, i_2)

    elif pattern_matching_result == 2:
        return False



def DataContext_tryGetDataContextByName(name: str) -> DataContext | None:
    if name.find("#") >= 0:
        pattern_input: Array[str] = split(name, ["#"], None, 0)
        def _arrow4115(x: str, y: str, name: Any=name) -> bool:
            return x == y

        if (len(pattern_input) == 2) if (not equals_with(_arrow4115, pattern_input, None)) else False:
            selector: str = pattern_input[1]
            path: str = pattern_input[0]
            def predicate(n: DataContext, name: Any=name) -> bool:
                if True if (n.FilePath is None) else (n.Selector is None):
                    return False

                elif value(n.FilePath) == path:
                    if value(n.Selector) == selector:
                        return True

                    else: 
                        outer: str = value(n.Selector)
                        return CSV.is_included_string(outer, selector)


                else: 
                    return False


            return try_find(predicate, DataContext_dataContexts)

        else: 
            raise Exception("Match failure")


    else: 
        def predicate_1(n_1: DataContext, name: Any=name) -> bool:
            return n_1.NameText == name

        return try_find(predicate_1, DataContext_dataContexts)



def DataContext_getAbsolutePath(base_path: str, dc: DataContext) -> str:
    match_value: str | None = dc.FilePath
    if match_value is None:
        return base_path

    else: 
        def _arrow4116(__unit: None=None, base_path: Any=base_path, dc: Any=dc) -> bool:
            fp: str = match_value
            return fp.find(base_path) >= 0

        if _arrow4116():
            fp_1: str = match_value
            return fp_1

        else: 
            fp_2: str = match_value
            return combine(base_path, fp_2)




def ARCtrl_DataContext__DataContext_ExplicationEquals_ZDED3A0F(this: DataContext, explication: OntologyAnnotation) -> bool:
    if DataContext__get_Explication(this) is not None:
        return equals(value(DataContext__get_Explication(this)), explication)

    else: 
        return False



def ARCtrl_ARC__ARC_GetDataContextMap(this: ARC) -> Any:
    def chooser_2(dc: DataContext, this: Any=this) -> tuple[str, DataContext] | None:
        def mapping_1(name: str, dc: Any=dc) -> tuple[str, DataContext]:
            return (name, dc)

        return map(mapping_1, dc.Name)

    def mapping(dm: Datamap, this: Any=this) -> Array[DataContext]:
        return dm.DataContexts

    def _arrow4117(__unit: None=None, this: Any=this) -> IEnumerable_1[Datamap]:
        def chooser(a: ArcAssay) -> Datamap | None:
            return a.Datamap

        source_3: IEnumerable_1[Datamap] = choose(chooser, this.Assays)
        def chooser_1(s: ArcStudy) -> Datamap | None:
            return s.Datamap

        return append(choose(chooser_1, this.Studies), source_3)

    return Dictionary_ofSeq(choose(chooser_2, collect(mapping, _arrow4117())))


def ARCtrl_ARC__ARC_DataContextMapping(this: ARC) -> None:
    def action(a: ArcAssay, this: Any=this) -> None:
        if a.Datamap is not None:
            add_range_in_place(value(a.Datamap).DataContexts, DataContext_dataContexts)


    iterate(action, this.Assays)
    def action_1(s: ArcStudy, this: Any=this) -> None:
        if s.Datamap is not None:
            add_range_in_place(value(s.Datamap).DataContexts, DataContext_dataContexts)


    iterate(action_1, this.Studies)


__all__ = ["ObjectType_isString", "ObjectType_isFloat", "ObjectType_isInt", "DataContext_dataContexts", "DataContext_selectorIsIncluded", "DataContext_tryGetDataContextByName", "DataContext_getAbsolutePath", "ARCtrl_DataContext__DataContext_ExplicationEquals_ZDED3A0F", "ARCtrl_ARC__ARC_GetDataContextMap", "ARCtrl_ARC__ARC_DataContextMapping"]

