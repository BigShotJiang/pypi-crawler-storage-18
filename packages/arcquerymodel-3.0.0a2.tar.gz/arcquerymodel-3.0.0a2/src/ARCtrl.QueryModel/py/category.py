from __future__ import annotations
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_core.Table.composite_header import CompositeHeader
from .fable_modules.fable_library.types import to_string

def ARCtrl_CompositeHeader__CompositeHeader_get_IsCharacteristicCategory(this: CompositeHeader) -> bool:
    if this.tag == 1:
        return True

    else: 
        return False



def ARCtrl_CompositeHeader__CompositeHeader_get_IsParameterCategory(this: CompositeHeader) -> bool:
    if this.tag == 3:
        return True

    else: 
        return False



def ARCtrl_CompositeHeader__CompositeHeader_get_IsFactorCategory(this: CompositeHeader) -> bool:
    if this.tag == 2:
        return True

    else: 
        return False



def ARCtrl_CompositeHeader__CompositeHeader_get_IsComponentType(this: CompositeHeader) -> bool:
    if this.tag == 0:
        return True

    else: 
        return False



def ARCtrl_CompositeHeader__CompositeHeader_get_Category(this: CompositeHeader) -> OntologyAnnotation:
    if this.tag == 3:
        return this.fields[0]

    elif this.tag == 1:
        return this.fields[0]

    elif this.tag == 2:
        return this.fields[0]

    elif this.tag == 0:
        return this.fields[0]

    else: 
        raise Exception("Match failure: ARCtrl.CompositeHeader")



def ARCtrl_CompositeHeader__CompositeHeader_get_NameText(this: CompositeHeader) -> str:
    return ARCtrl_CompositeHeader__CompositeHeader_get_Category(this).NameText


def ARCtrl_CompositeHeader__CompositeHeader_get_HeaderText(this: CompositeHeader) -> str:
    return to_string(this)


__all__ = ["ARCtrl_CompositeHeader__CompositeHeader_get_IsCharacteristicCategory", "ARCtrl_CompositeHeader__CompositeHeader_get_IsParameterCategory", "ARCtrl_CompositeHeader__CompositeHeader_get_IsFactorCategory", "ARCtrl_CompositeHeader__CompositeHeader_get_IsComponentType", "ARCtrl_CompositeHeader__CompositeHeader_get_Category", "ARCtrl_CompositeHeader__CompositeHeader_get_NameText", "ARCtrl_CompositeHeader__CompositeHeader_get_HeaderText"]

