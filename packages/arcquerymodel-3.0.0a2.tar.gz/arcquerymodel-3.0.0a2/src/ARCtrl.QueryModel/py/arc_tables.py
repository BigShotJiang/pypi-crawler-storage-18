from __future__ import annotations
from collections.abc import Callable
from typing import Any
from .arc_table import (ArcTableExtensions_CRow__get_InputName, ArcTableExtensions_CRow__get_InputType, ArcTableExtensions_CRow__get_OutputName, ArcTableExtensions_CRow__get_OutputType, ArcTableExtensions_CRow, ARCtrl_ArcTable__ArcTable_get_Rows, ArcTableExtensions_CRow__get_Output, ArcTableExtensions_CRow__get_Input, ArcTableExtensions_CRow__get_Values, ARCtrl_ArcTable__ArcTable_get_ISAValues)
from .data_context import DataContext_tryGetDataContextByName
from .fable_modules.arctrl_core.data_context import (DataContext, DataContext__ctor_Z780A8A2A, DataContext__get_Explication, DataContext__get_Unit, DataContext__get_ObjectType, DataContext__get_Label, DataContext__get_Description, DataContext__get_GeneratedBy)
from .fable_modules.arctrl_core.ontology_annotation import OntologyAnnotation
from .fable_modules.arctrl_core.Table.arc_table import ArcTable
from .fable_modules.arctrl_core.Table.arc_tables import ArcTables
from .fable_modules.arctrl_core.Table.composite_cell import CompositeCell
from .fable_modules.arctrl_core.Table.composite_header import IOType
from .fable_modules.fable_library.list import (of_array, FSharpList, append, contains, singleton, map as map_2, collect as collect_2, is_empty, filter, empty as empty_1, of_seq as of_seq_1, unzip, concat as concat_1)
from .fable_modules.fable_library.map import (of_list, try_find, of_seq as of_seq_2, FSharpMap__TryFind)
from .fable_modules.fable_library.option import (default_arg, map as map_3, value as value_2)
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.seq import (concat, to_list, collect, choose, to_array, contains as contains_1, indexed, zip, map as map_1, delay, append as append_1, singleton as singleton_1, empty)
from .fable_modules.fable_library.seq2 import (List_distinct, distinct_by, distinct, List_groupBy)
from .fable_modules.fable_library.set import (of_seq, FSharpSet__Contains)
from .fable_modules.fable_library.string_ import compare_to
from .fable_modules.fable_library.types import Array
from .fable_modules.fable_library.util import (string_hash, IEnumerable_1, equals, safe_hash, compare_primitives, equal_arrays, array_hash, compare)
from .resize_array import (map, collect as collect_1, choose as choose_1, filter as filter_1)
from .value import ISAValue
from .value_collection import (ValueCollection__ctor_6ED77DA8, ValueCollection, ValueCollection__ctor_78C6E8A5, ValueCollection__get_Values, IOValueCollection__Values_6DFDD678, ValueCollection__WithCategory_ZDED3A0F, ValueCollection__WithName_Z721C83C5, ValueCollection__Factors_6DFDD678, ValueCollection__Parameters_6DFDD678, ValueCollection__Characteristics_6DFDD678, ValueCollection__Components_6DFDD678, ValueCollection__Contains_ZDED3A0F, ValueCollection__Contains_Z721C83C5)

def _expr4329() -> TypeInfo:
    return class_type("ARCtrl.QueryModel.ArcTables.QNode", None, QNode)


class QNode:
    def __init__(self, name: str, io_type: IOType, parent_process_sequence: ArcTables | None=None) -> None:
        self.name: str = name
        self.io_type: IOType = io_type
        self.parent_process_sequence: ArcTables | None = parent_process_sequence

    def __eq__(self, other: Any=None) -> bool:
        this: QNode = self
        return this.System_IEquatable_1_Equals2B595(other) if isinstance(other, QNode) else False

    def __hash__(self, __unit: None=None) -> int:
        this: QNode = self
        return string_hash(QNode__get_Name(this))

    def System_IEquatable_1_Equals2B595(self, other: QNode) -> bool:
        this: QNode = self
        return QNode__get_Name(other) == QNode__get_Name(this)

    def __cmp__(self, other: Any=None) -> int:
        this: QNode = self
        return this.System_IComparable_1_CompareTo2B595(other) if isinstance(other, QNode) else -1

    def System_IComparable_1_CompareTo2B595(self, other: QNode) -> int:
        this: QNode = self
        return compare_to(QNode__get_Name(other), QNode__get_Name(this))


QNode_reflection = _expr4329

def QNode__ctor_Z5F8C4AE5(name: str, io_type: IOType, parent_process_sequence: ArcTables | None=None) -> QNode:
    return QNode(name, io_type, parent_process_sequence)


def ARCtrl_IOType__IOType_get_isSource(this: IOType) -> bool:
    if this.tag == 0:
        return True

    else: 
        return False



def ARCtrl_IOType__IOType_get_isSample(this: IOType) -> bool:
    if this.tag == 1:
        return True

    else: 
        return False



def ARCtrl_IOType__IOType_get_isMaterial(this: IOType) -> bool:
    if this.tag == 3:
        return True

    else: 
        return False



def ARCtrl_IOType__IOType_get_isData(this: IOType) -> bool:
    if this.tag == 2:
        return True

    else: 
        return False



def ARCtrl_ArcTables__ArcTables_concat_Static_Z6D8BD2B8(pss: Any | None=None) -> ArcTables:
    return ArcTables(list(concat(pss)))


def ARCtrl_ArcTables__ArcTables_getNodes_Static_Z63B5F9B8(ps: Any | None=None) -> FSharpList[QNode]:
    def mapping_1(p: ArcTable, ps: Any=ps) -> IEnumerable_1[QNode]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> FSharpList[QNode]:
            return of_array([QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_InputName(r), ArcTableExtensions_CRow__get_InputType(r), ps), QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_OutputName(r), ArcTableExtensions_CRow__get_OutputType(r), ps)])

        return collect(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p))

    class ObjectExpr4330:
        @property
        def Equals(self) -> Callable[[QNode, QNode], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[QNode], int]:
            return safe_hash

    return List_distinct(to_list(collect(mapping_1, ps.Tables)), ObjectExpr4330())


def ARCtrl_ArcTables__ArcTables_getSubTreeOf_Static(node: str, ps: Any) -> ArcTables:
    def collect_forward_nodes(nodes_mut: FSharpList[str], node: Any=node, ps: Any=ps) -> FSharpList[str]:
        while True:
            (nodes,) = (nodes_mut,)
            def mapping(sheet: ArcTable, nodes: Any=nodes) -> IEnumerable_1[str]:
                def chooser(r: ArcTableExtensions_CRow, sheet: Any=sheet) -> str | None:
                    class ObjectExpr4332:
                        @property
                        def Equals(self) -> Callable[[str, str], bool]:
                            def _arrow4331(x: str, y: str) -> bool:
                                return x == y

                            return _arrow4331

                        @property
                        def GetHashCode(self) -> Callable[[str], int]:
                            return string_hash

                    if contains(ArcTableExtensions_CRow__get_InputName(r), nodes, ObjectExpr4332()):
                        return ArcTableExtensions_CRow__get_OutputName(r)

                    else: 
                        return None


                return choose(chooser, ARCtrl_ArcTable__ArcTable_get_Rows(sheet))

            class ObjectExpr4334:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4333(x_1: str, y_1: str) -> bool:
                        return x_1 == y_1

                    return _arrow4333

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            new_nodes: FSharpList[str] = List_distinct(append(nodes, to_list(collect(mapping, ps.Tables))), ObjectExpr4334())
            if equals(new_nodes, nodes):
                return nodes

            else: 
                nodes_mut = new_nodes
                continue

            break

    def collect_backward_nodes(nodes_1_mut: FSharpList[str], node: Any=node, ps: Any=ps) -> FSharpList[str]:
        while True:
            (nodes_1,) = (nodes_1_mut,)
            def mapping_1(sheet_1: ArcTable, nodes_1: Any=nodes_1) -> IEnumerable_1[str]:
                def chooser_1(r_1: ArcTableExtensions_CRow, sheet_1: Any=sheet_1) -> str | None:
                    class ObjectExpr4336:
                        @property
                        def Equals(self) -> Callable[[str, str], bool]:
                            def _arrow4335(x_2: str, y_2: str) -> bool:
                                return x_2 == y_2

                            return _arrow4335

                        @property
                        def GetHashCode(self) -> Callable[[str], int]:
                            return string_hash

                    if contains(ArcTableExtensions_CRow__get_Output(r_1), nodes_1, ObjectExpr4336()):
                        return ArcTableExtensions_CRow__get_Input(r_1)

                    else: 
                        return None


                return choose(chooser_1, ARCtrl_ArcTable__ArcTable_get_Rows(sheet_1))

            class ObjectExpr4338:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4337(x_3: str, y_3: str) -> bool:
                        return x_3 == y_3

                    return _arrow4337

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            new_nodes_1: FSharpList[str] = List_distinct(append(nodes_1, to_list(collect(mapping_1, ps.Tables))), ObjectExpr4338())
            if equals(new_nodes_1, nodes_1):
                return nodes_1

            else: 
                nodes_1_mut = new_nodes_1
                continue

            break

    forward_nodes: FSharpList[str] = collect_forward_nodes(singleton(node))
    backward_nodes: FSharpList[str] = collect_backward_nodes(singleton(node))
    def f(t_1: ArcTable, node: Any=node, ps: Any=ps) -> ArcTable:
        def chooser_2(tupled_arg: tuple[int, tuple[CompositeCell, CompositeCell]], t_1: Any=t_1) -> int | None:
            _arg: tuple[CompositeCell, CompositeCell] = tupled_arg[1]
            class ObjectExpr4340:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4339(x_4: str, y_4: str) -> bool:
                        return x_4 == y_4

                    return _arrow4339

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            class ObjectExpr4342:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4341(x_5: str, y_5: str) -> bool:
                        return x_5 == y_5

                    return _arrow4341

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            if True if contains_1(_arg[0].AsFreeText, forward_nodes, ObjectExpr4340()) else contains_1(_arg[1].AsFreeText, backward_nodes, ObjectExpr4342()):
                return None

            else: 
                return tupled_arg[0]


        def _arrow4343(__unit: None=None, t_1: Any=t_1) -> IEnumerable_1[tuple[CompositeCell, CompositeCell]]:
            source_9: Array[CompositeCell] = t_1.GetOutputColumn().Cells
            return zip(t_1.GetInputColumn().Cells, source_9)

        index_arr: Array[int] = to_array(choose(chooser_2, indexed(_arrow4343())))
        t_1.RemoveRows(index_arr)
        return t_1

    def mapping_2(t: ArcTable, node: Any=node, ps: Any=ps) -> ArcTable:
        return t.Copy()

    return ArcTables(map(f, list(to_list(map_1(mapping_2, ps)))))


def ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8(ps: Any | None=None) -> Array[QNode]:
    def f(p: ArcTable, ps: Any=ps) -> FSharpList[tuple[str, IOType]]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> tuple[str, IOType]:
            return (ArcTableExtensions_CRow__get_Input(r), ArcTableExtensions_CRow__get_InputType(r))

        return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p))

    inputs: Array[tuple[str, IOType]] = collect_1(f, ps.Tables)
    def f_1(p_1: ArcTable, ps: Any=ps) -> FSharpList[str]:
        def mapping_1(r_1: ArcTableExtensions_CRow, p_1: Any=p_1) -> str:
            return ArcTableExtensions_CRow__get_Output(r_1)

        return map_2(mapping_1, ARCtrl_ArcTable__ArcTable_get_Rows(p_1))

    class ObjectExpr4344:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    outputs: Any = of_seq(collect_1(f_1, ps.Tables), ObjectExpr4344())
    def f_2(tupled_arg: tuple[str, IOType], ps: Any=ps) -> QNode | None:
        iname: str = tupled_arg[0]
        if FSharpSet__Contains(outputs, iname):
            return None

        else: 
            return QNode__ctor_Z5F8C4AE5(iname, tupled_arg[1], ps)


    return choose_1(f_2, inputs)


def ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8(ps: Any | None=None) -> Array[QNode]:
    def f(p: ArcTable, ps: Any=ps) -> FSharpList[str]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> str:
            return ArcTableExtensions_CRow__get_Input(r)

        return map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p))

    class ObjectExpr4345:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    inputs: Any = of_seq(collect_1(f, ps.Tables), ObjectExpr4345())
    def projection(n: QNode, ps: Any=ps) -> str:
        return QNode__get_Name(n)

    def f_2(tupled_arg: tuple[str, IOType], ps: Any=ps) -> QNode | None:
        oname: str = tupled_arg[0]
        if FSharpSet__Contains(inputs, oname):
            return None

        else: 
            return QNode__ctor_Z5F8C4AE5(oname, tupled_arg[1], ps)


    def f_1(p_1: ArcTable, ps: Any=ps) -> FSharpList[tuple[str, IOType]]:
        def mapping_1(r_1: ArcTableExtensions_CRow, p_1: Any=p_1) -> tuple[str, IOType]:
            return (ArcTableExtensions_CRow__get_Output(r_1), ArcTableExtensions_CRow__get_OutputType(r_1))

        return map_2(mapping_1, ARCtrl_ArcTable__ArcTable_get_Rows(p_1))

    class ObjectExpr4347:
        @property
        def Equals(self) -> Callable[[str, str], bool]:
            def _arrow4346(x_1: str, y_1: str) -> bool:
                return x_1 == y_1

            return _arrow4346

        @property
        def GetHashCode(self) -> Callable[[str], int]:
            return string_hash

    return list(distinct_by(projection, choose_1(f_2, collect_1(f_1, ps.Tables)), ObjectExpr4347()))


def ARCtrl_ArcTables__ArcTables_getNodesBy_Static(predicate: Callable[[IOType], bool], ps: Any) -> Array[QNode]:
    def f(p: ArcTable, predicate: Any=predicate, ps: Any=ps) -> FSharpList[QNode]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> FSharpList[QNode]:
            def _arrow4349(__unit: None=None, r: Any=r) -> IEnumerable_1[QNode]:
                def _arrow4348(__unit: None=None) -> IEnumerable_1[QNode]:
                    return singleton_1(QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Output(r), ArcTableExtensions_CRow__get_InputType(r), ps)) if predicate(ArcTableExtensions_CRow__get_OutputType(r)) else empty()

                return append_1(singleton_1(QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Input(r), ArcTableExtensions_CRow__get_InputType(r), ps)) if predicate(ArcTableExtensions_CRow__get_InputType(r)) else empty(), delay(_arrow4348))

            return to_list(delay(_arrow4349))

        return collect_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p))

    class ObjectExpr4350:
        @property
        def Equals(self) -> Callable[[QNode, QNode], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[QNode], int]:
            return safe_hash

    return list(distinct(collect_1(f, ps.Tables), ObjectExpr4350()))


def ARCtrl_ArcTables__ArcTables_getRootInputsBy_Static(predicate: Callable[[IOType], bool], ps: Any) -> FSharpList[QNode]:
    def mapping_2(tupled_arg: tuple[QNode, FSharpList[tuple[QNode, QNode]]], predicate: Any=predicate, ps: Any=ps) -> tuple[QNode, FSharpList[QNode]]:
        def mapping_1(tuple_1: tuple[QNode, QNode], tupled_arg: Any=tupled_arg) -> QNode:
            return tuple_1[1]

        return (tupled_arg[0], map_2(mapping_1, tupled_arg[1]))

    def projection(tuple: tuple[QNode, QNode], predicate: Any=predicate, ps: Any=ps) -> QNode:
        return tuple[0]

    def f(p: ArcTable, predicate: Any=predicate, ps: Any=ps) -> FSharpList[tuple[QNode, QNode]]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> tuple[QNode, QNode]:
            return (QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Input(r), ArcTableExtensions_CRow__get_InputType(r), ps), QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Output(r), ArcTableExtensions_CRow__get_OutputType(r), ps))

        class ObjectExpr4351:
            @property
            def Equals(self) -> Callable[[tuple[QNode, QNode], tuple[QNode, QNode]], bool]:
                return equal_arrays

            @property
            def GetHashCode(self) -> Callable[[tuple[QNode, QNode]], int]:
                return array_hash

        return List_distinct(map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p)), ObjectExpr4351())

    class ObjectExpr4352:
        @property
        def Equals(self) -> Callable[[QNode, QNode], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[QNode], int]:
            return safe_hash

    class ObjectExpr4353:
        @property
        def Compare(self) -> Callable[[QNode, QNode], int]:
            return compare

    mappings: Any = of_list(map_2(mapping_2, List_groupBy(projection, to_list(collect_1(f, ps.Tables)), ObjectExpr4352())), ObjectExpr4353())
    def predicate_1(entity: QNode, predicate: Any=predicate, ps: Any=ps) -> bool:
        return predicate(QNode__get_IOType(entity))

    def loop(search_entities_mut: FSharpList[QNode], found_entities_mut: FSharpList[QNode], predicate: Any=predicate, ps: Any=ps) -> FSharpList[QNode]:
        while True:
            (search_entities, found_entities) = (search_entities_mut, found_entities_mut)
            if is_empty(search_entities):
                class ObjectExpr4354:
                    @property
                    def Equals(self) -> Callable[[QNode, QNode], bool]:
                        return equals

                    @property
                    def GetHashCode(self) -> Callable[[QNode], int]:
                        return safe_hash

                return List_distinct(found_entities, ObjectExpr4354())

            else: 
                targs: FSharpList[QNode] = filter(predicate_1, search_entities)
                def mapping_3(en: QNode, search_entities: Any=search_entities, found_entities: Any=found_entities) -> FSharpList[QNode]:
                    return default_arg(try_find(en, mappings), empty_1())

                def predicate_3(arg: QNode, search_entities: Any=search_entities, found_entities: Any=found_entities) -> bool:
                    return not predicate_1(arg)

                search_entities_mut = collect_2(mapping_3, filter(predicate_3, search_entities))
                found_entities_mut = targs
                continue

            break

    return loop(of_seq_1(ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8(ps)), empty_1())


def ARCtrl_ArcTables__ArcTables_getFinalOutputsBy_Static(predicate: Callable[[IOType], bool], ps: Any) -> FSharpList[QNode]:
    def mapping_2(tupled_arg: tuple[QNode, FSharpList[tuple[QNode, QNode]]], predicate: Any=predicate, ps: Any=ps) -> tuple[QNode, FSharpList[QNode]]:
        def mapping_1(tuple_1: tuple[QNode, QNode], tupled_arg: Any=tupled_arg) -> QNode:
            return tuple_1[1]

        return (tupled_arg[0], map_2(mapping_1, tupled_arg[1]))

    def projection(tuple: tuple[QNode, QNode], predicate: Any=predicate, ps: Any=ps) -> QNode:
        return tuple[0]

    def f(p: ArcTable, predicate: Any=predicate, ps: Any=ps) -> FSharpList[tuple[QNode, QNode]]:
        def mapping(r: ArcTableExtensions_CRow, p: Any=p) -> tuple[QNode, QNode]:
            return (QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Output(r), ArcTableExtensions_CRow__get_OutputType(r), ps), QNode__ctor_Z5F8C4AE5(ArcTableExtensions_CRow__get_Input(r), ArcTableExtensions_CRow__get_InputType(r), ps))

        class ObjectExpr4355:
            @property
            def Equals(self) -> Callable[[tuple[QNode, QNode], tuple[QNode, QNode]], bool]:
                return equal_arrays

            @property
            def GetHashCode(self) -> Callable[[tuple[QNode, QNode]], int]:
                return array_hash

        return List_distinct(map_2(mapping, ARCtrl_ArcTable__ArcTable_get_Rows(p)), ObjectExpr4355())

    class ObjectExpr4356:
        @property
        def Equals(self) -> Callable[[QNode, QNode], bool]:
            return equals

        @property
        def GetHashCode(self) -> Callable[[QNode], int]:
            return safe_hash

    class ObjectExpr4357:
        @property
        def Compare(self) -> Callable[[QNode, QNode], int]:
            return compare

    mappings: Any = of_list(map_2(mapping_2, List_groupBy(projection, to_list(collect_1(f, ps.Tables)), ObjectExpr4356())), ObjectExpr4357())
    def predicate_1(entity: QNode, predicate: Any=predicate, ps: Any=ps) -> bool:
        return predicate(QNode__get_IOType(entity))

    def loop(search_entities_mut: FSharpList[QNode], found_entities_mut: FSharpList[QNode], predicate: Any=predicate, ps: Any=ps) -> FSharpList[QNode]:
        while True:
            (search_entities, found_entities) = (search_entities_mut, found_entities_mut)
            if is_empty(search_entities):
                class ObjectExpr4358:
                    @property
                    def Equals(self) -> Callable[[QNode, QNode], bool]:
                        return equals

                    @property
                    def GetHashCode(self) -> Callable[[QNode], int]:
                        return safe_hash

                return List_distinct(found_entities, ObjectExpr4358())

            else: 
                targs: FSharpList[QNode] = filter(predicate_1, search_entities)
                def mapping_3(en: QNode, search_entities: Any=search_entities, found_entities: Any=found_entities) -> FSharpList[QNode]:
                    return default_arg(try_find(en, mappings), empty_1())

                def predicate_3(arg: QNode, search_entities: Any=search_entities, found_entities: Any=found_entities) -> bool:
                    return not predicate_1(arg)

                search_entities_mut = collect_2(mapping_3, filter(predicate_3, search_entities))
                found_entities_mut = targs
                continue

            break

    return loop(of_seq_1(ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8(ps)), empty_1())


def ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static(node: str, ps: Any) -> FSharpList[str]:
    def collect_backward_nodes(nodes_mut: FSharpList[str], node: Any=node, ps: Any=ps) -> FSharpList[str]:
        while True:
            (nodes,) = (nodes_mut,)
            def mapping(sheet: ArcTable, nodes: Any=nodes) -> IEnumerable_1[str]:
                def chooser(r: ArcTableExtensions_CRow, sheet: Any=sheet) -> str | None:
                    class ObjectExpr4360:
                        @property
                        def Equals(self) -> Callable[[str, str], bool]:
                            def _arrow4359(x: str, y: str) -> bool:
                                return x == y

                            return _arrow4359

                        @property
                        def GetHashCode(self) -> Callable[[str], int]:
                            return string_hash

                    if contains(ArcTableExtensions_CRow__get_Output(r), nodes, ObjectExpr4360()):
                        return ArcTableExtensions_CRow__get_Input(r)

                    else: 
                        return None


                return choose(chooser, ARCtrl_ArcTable__ArcTable_get_Rows(sheet))

            class ObjectExpr4362:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4361(x_1: str, y_1: str) -> bool:
                        return x_1 == y_1

                    return _arrow4361

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            new_nodes: FSharpList[str] = List_distinct(append(nodes, to_list(collect(mapping, ps.Tables))), ObjectExpr4362())
            if equals(new_nodes, nodes):
                return nodes

            else: 
                nodes_mut = new_nodes
                continue

            break

    return collect_backward_nodes(singleton(node))


def ARCtrl_ArcTables__ArcTables_getSucceedingNodesBy_Static(node: str, ps: Any) -> FSharpList[str]:
    def collect_forward_nodes(nodes_mut: FSharpList[str], node: Any=node, ps: Any=ps) -> FSharpList[str]:
        while True:
            (nodes,) = (nodes_mut,)
            def mapping(sheet: ArcTable, nodes: Any=nodes) -> IEnumerable_1[str]:
                def chooser(r: ArcTableExtensions_CRow, sheet: Any=sheet) -> str | None:
                    class ObjectExpr4364:
                        @property
                        def Equals(self) -> Callable[[str, str], bool]:
                            def _arrow4363(x: str, y: str) -> bool:
                                return x == y

                            return _arrow4363

                        @property
                        def GetHashCode(self) -> Callable[[str], int]:
                            return string_hash

                    if contains(ArcTableExtensions_CRow__get_InputName(r), nodes, ObjectExpr4364()):
                        return ArcTableExtensions_CRow__get_OutputName(r)

                    else: 
                        return None


                return choose(chooser, ARCtrl_ArcTable__ArcTable_get_Rows(sheet))

            class ObjectExpr4366:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4365(x_1: str, y_1: str) -> bool:
                        return x_1 == y_1

                    return _arrow4365

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            new_nodes: FSharpList[str] = List_distinct(append(nodes, to_list(collect(mapping, ps.Tables))), ObjectExpr4366())
            if equals(new_nodes, nodes):
                return nodes

            else: 
                nodes_mut = new_nodes
                continue

            break

    return collect_forward_nodes(singleton(node))


def ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate: Callable[[IOType], bool], node: str, ps: Any) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getNodesBy_Static(predicate, ARCtrl_ArcTables__ArcTables_getSubTreeOf_Static(node, ps))


def ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate: Callable[[IOType], bool], node: str, ps: Any) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_getRootInputsBy_Static(predicate, ARCtrl_ArcTables__ArcTables_getSubTreeOf_Static(node, ps))


def ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate: Callable[[IOType], bool], node: str, ps: Any) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_getFinalOutputsBy_Static(predicate, ARCtrl_ArcTables__ArcTables_getSubTreeOf_Static(node, ps))


def ARCtrl_ArcTables__ArcTables_getPreviousValuesOf_Static(ps: Any, node: str) -> ValueCollection:
    def f(p: ArcTable, ps: Any=ps, node: Any=node) -> FSharpList[tuple[str, FSharpList[ArcTableExtensions_CRow]]]:
        def projection(r: ArcTableExtensions_CRow, p: Any=p) -> str:
            return ArcTableExtensions_CRow__get_Output(r)

        class ObjectExpr4368:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4367(x: str, y: str) -> bool:
                    return x == y

                return _arrow4367

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return List_groupBy(projection, ARCtrl_ArcTable__ArcTable_get_Rows(p), ObjectExpr4368())

    class ObjectExpr4369:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    mappings: Any = of_seq_2(collect_1(f, ps.Tables), ObjectExpr4369())
    def loop(values_mut: FSharpList[ISAValue], last_state_mut: FSharpList[str], state_mut: FSharpList[str], ps: Any=ps, node: Any=node) -> FSharpList[ISAValue]:
        while True:
            (values, last_state, state) = (values_mut, last_state_mut, state_mut)
            if equals(last_state, state):
                return values

            else: 
                pattern_input: tuple[FSharpList[str], FSharpList[ISAValue]]
                def mapping_2(s: str, values: Any=values, last_state: Any=last_state, state: Any=state) -> tuple[FSharpList[str], FSharpList[ISAValue]]:
                    def mapping_1(rs: FSharpList[ArcTableExtensions_CRow], s: Any=s) -> tuple[FSharpList[str], FSharpList[ISAValue]]:
                        def mapping(r_1: ArcTableExtensions_CRow, rs: Any=rs) -> tuple[str, FSharpList[ISAValue]]:
                            return (ArcTableExtensions_CRow__get_Input(r_1), to_list(ArcTableExtensions_CRow__get_Values(r_1)))

                        tupled_arg: tuple[FSharpList[str], FSharpList[FSharpList[ISAValue]]] = unzip(map_2(mapping, rs))
                        return (tupled_arg[0], concat_1(tupled_arg[1]))

                    return default_arg(map_3(mapping_1, FSharpMap__TryFind(mappings, s)), (empty_1(), empty_1()))

                tupled_arg_1: tuple[FSharpList[FSharpList[str]], FSharpList[FSharpList[ISAValue]]] = unzip(map_2(mapping_2, state))
                pattern_input = (concat_1(tupled_arg_1[0]), concat_1(tupled_arg_1[1]))
                values_mut = append(pattern_input[1], values)
                last_state_mut = state
                state_mut = pattern_input[0]
                continue

            break

    return ValueCollection__ctor_6ED77DA8(loop(empty_1(), empty_1(), singleton(node)))


def ARCtrl_ArcTables__ArcTables_getSucceedingValuesOf_Static(ps: Any, sample: str) -> ValueCollection:
    def f(p: ArcTable, ps: Any=ps, sample: Any=sample) -> FSharpList[tuple[str, FSharpList[ArcTableExtensions_CRow]]]:
        def projection(r: ArcTableExtensions_CRow, p: Any=p) -> str:
            return ArcTableExtensions_CRow__get_Input(r)

        class ObjectExpr4371:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4370(x: str, y: str) -> bool:
                    return x == y

                return _arrow4370

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return List_groupBy(projection, ARCtrl_ArcTable__ArcTable_get_Rows(p), ObjectExpr4371())

    class ObjectExpr4372:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    mappings: Any = of_seq_2(collect_1(f, ps.Tables), ObjectExpr4372())
    def loop(values_mut: FSharpList[ISAValue], last_state_mut: FSharpList[str], state_mut: FSharpList[str], ps: Any=ps, sample: Any=sample) -> FSharpList[ISAValue]:
        while True:
            (values, last_state, state) = (values_mut, last_state_mut, state_mut)
            if equals(last_state, state):
                return values

            else: 
                pattern_input: tuple[FSharpList[str], FSharpList[ISAValue]]
                def mapping_2(s: str, values: Any=values, last_state: Any=last_state, state: Any=state) -> tuple[FSharpList[str], FSharpList[ISAValue]]:
                    def mapping_1(rs: FSharpList[ArcTableExtensions_CRow], s: Any=s) -> tuple[FSharpList[str], FSharpList[ISAValue]]:
                        def mapping(r_1: ArcTableExtensions_CRow, rs: Any=rs) -> tuple[str, FSharpList[ISAValue]]:
                            return (ArcTableExtensions_CRow__get_Output(r_1), to_list(ArcTableExtensions_CRow__get_Values(r_1)))

                        tupled_arg: tuple[FSharpList[str], FSharpList[FSharpList[ISAValue]]] = unzip(map_2(mapping, rs))
                        return (tupled_arg[0], concat_1(tupled_arg[1]))

                    return default_arg(map_3(mapping_1, FSharpMap__TryFind(mappings, s)), (empty_1(), empty_1()))

                tupled_arg_1: tuple[FSharpList[FSharpList[str]], FSharpList[FSharpList[ISAValue]]] = unzip(map_2(mapping_2, state))
                pattern_input = (concat_1(tupled_arg_1[0]), concat_1(tupled_arg_1[1]))
                values_mut = append(values, pattern_input[1])
                last_state_mut = state
                state_mut = pattern_input[0]
                continue

            break

    return ValueCollection__ctor_6ED77DA8(loop(empty_1(), empty_1(), singleton(sample)))


def ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(ps: Any, protocol_name: str) -> ArcTables:
    def f(t: ArcTable, ps: Any=ps, protocol_name: Any=protocol_name) -> bool:
        return t.Name == protocol_name

    return ArcTables(filter_1(f, ps.Tables))


def ARCtrl_ArcTables__ArcTables_NodesOf_Z301E6E48(this: ArcTables, node: QNode) -> Array[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_NodesOf_Z721C83C5(this: ArcTables, node: str) -> Array[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_FirstNodesOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_LastNodesOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_FirstNodesOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_LastNodesOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(_arg: IOType, this: Any=this, node: Any=node) -> bool:
        return True

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_SamplesOf_Z301E6E48(this: ArcTables, node: QNode) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_SamplesOf_Z721C83C5(this: ArcTables, node: str) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_FirstSamplesOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_LastSamplesOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_FirstSamplesOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_LastSamplesOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_SourcesOf_Z301E6E48(this: ArcTables, node: QNode) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSource(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_SourcesOf_Z721C83C5(this: ArcTables, node: str) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isSource(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_DataOf_Z301E6E48(this: ArcTables, node: QNode) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_DataOf_Z721C83C5(this: ArcTables, node: str) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_FirstDataOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_LastDataOf_Z301E6E48(this: ArcTables, node: QNode) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, QNode__get_Name(node), this)


def ARCtrl_ArcTables__ArcTables_FirstDataOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_LastDataOf_Z721C83C5(this: ArcTables, node: str) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this, node: Any=node) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static(predicate, node, this)


def ARCtrl_ArcTables__ArcTables_Values_6DFDD678(this: ArcTables, ProtocolName: str | None=None) -> ValueCollection:
    ps_1: ArcTables = ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this
    def f(s: ArcTable, this: Any=this, ProtocolName: Any=ProtocolName) -> FSharpList[ISAValue]:
        return ValueCollection__get_Values(IOValueCollection__Values_6DFDD678(ARCtrl_ArcTable__ArcTable_get_ISAValues(s)))

    return ValueCollection__ctor_78C6E8A5(collect_1(f, ps_1.Tables))


def ARCtrl_ArcTables__ArcTables_Values_59965269(this: ArcTables, ontology: OntologyAnnotation, ProtocolName: str | None=None) -> ValueCollection:
    ps_1: ArcTables = ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this
    def f(s: ArcTable, this: Any=this, ontology: Any=ontology, ProtocolName: Any=ProtocolName) -> FSharpList[ISAValue]:
        return ValueCollection__get_Values(ValueCollection__WithCategory_ZDED3A0F(IOValueCollection__Values_6DFDD678(ARCtrl_ArcTable__ArcTable_get_ISAValues(s)), ontology))

    return ValueCollection__ctor_78C6E8A5(collect_1(f, ps_1.Tables))


def ARCtrl_ArcTables__ArcTables_Values_27AED5E3(this: ArcTables, name: str, ProtocolName: str | None=None) -> ValueCollection:
    ps_1: ArcTables = ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this
    def f(s: ArcTable, this: Any=this, name: Any=name, ProtocolName: Any=ProtocolName) -> FSharpList[ISAValue]:
        return ValueCollection__get_Values(ValueCollection__WithName_Z721C83C5(IOValueCollection__Values_6DFDD678(ARCtrl_ArcTable__ArcTable_get_ISAValues(s)), name))

    return ValueCollection__ctor_78C6E8A5(collect_1(f, ps_1.Tables))


def ARCtrl_ArcTables__ArcTables_Factors_6DFDD678(this: ArcTables, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this))


def ARCtrl_ArcTables__ArcTables_Parameters_6DFDD678(this: ArcTables, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this))


def ARCtrl_ArcTables__ArcTables_Characteristics_6DFDD678(this: ArcTables, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this))


def ARCtrl_ArcTables__ArcTables_Components_6DFDD678(this: ArcTables, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, value_2(ProtocolName)) if (ProtocolName is not None) else this))


def ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    if ProtocolName is None:
        return ARCtrl_ArcTables__ArcTables_getPreviousValuesOf_Static(this, node)

    else: 
        ps: str = ProtocolName
        previous_nodes: FSharpList[str] = ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static(node, this)
        ps_3: ArcTables = ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, ps)
        def mapping(n: str, this: Any=this, node: Any=node, ProtocolName: Any=ProtocolName) -> ValueCollection:
            return ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(ps_3, n)

        return ValueCollection__ctor_78C6E8A5(collect(mapping, previous_nodes))



def ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    if ProtocolName is None:
        return ARCtrl_ArcTables__ArcTables_getSucceedingValuesOf_Static(this, node)

    else: 
        ps: str = ProtocolName
        succeeding_nodes: FSharpList[str] = ARCtrl_ArcTables__ArcTables_getSucceedingNodesBy_Static(node, this)
        ps_3: ArcTables = ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static(this, ps)
        def mapping(n: str, this: Any=this, node: Any=node, ProtocolName: Any=ProtocolName) -> ValueCollection:
            return ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(ps_3, n)

        return ValueCollection__ctor_78C6E8A5(collect(mapping, succeeding_nodes))



def ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, QNode__get_Name(node), ProtocolName)


def ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, QNode__get_Name(node), ProtocolName)


def ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__ctor_6ED77DA8(append(ValueCollection__get_Values(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, node, ProtocolName)), ValueCollection__get_Values(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, node, ProtocolName))))


def ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this, QNode__get_Name(node), ProtocolName)


def ARCtrl_ArcTables__ArcTables_CharacteristicsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_CharacteristicsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousCharacteristicsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousCharacteristicsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingCharacteristicsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingCharacteristicsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Characteristics_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_ParametersOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_ParametersOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousParametersOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousParametersOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingParametersOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingParametersOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Parameters_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_FactorsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_FactorsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousFactorsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousFactorsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingFactorsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingFactorsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Factors_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_ComponentsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_ComponentsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousComponentsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_PreviousComponentsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingComponentsOf_27AED5E3(this: ArcTables, node: str, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_SucceedingComponentsOf_Z5E11E140(this: ArcTables, node: QNode, ProtocolName: str | None=None) -> ValueCollection:
    return ValueCollection__Components_6DFDD678(ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(this, node, ProtocolName))


def ARCtrl_ArcTables__ArcTables_Contains_59965269(this: ArcTables, ontology: OntologyAnnotation, ProtocolName: str | None=None) -> bool:
    return ValueCollection__Contains_ZDED3A0F(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(this, ProtocolName), ontology)


def ARCtrl_ArcTables__ArcTables_Contains_27AED5E3(this: ArcTables, name: str, ProtocolName: str | None=None) -> bool:
    return ValueCollection__Contains_Z721C83C5(ARCtrl_ArcTables__ArcTables_Values_6DFDD678(this, ProtocolName), name)


def ARCtrl_ArcTables__ArcTables_get_Nodes(this: ArcTables) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_getNodes_Static_Z63B5F9B8(this)


def ARCtrl_ArcTables__ArcTables_get_FirstNodes(this: ArcTables) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8(this)


def ARCtrl_ArcTables__ArcTables_get_LastNodes(this: ArcTables) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8(this)


def ARCtrl_ArcTables__ArcTables_get_Samples(this: ArcTables) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getNodesBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_FirstSamples(this: ArcTables) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_LastSamples(this: ArcTables) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isSample(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_Sources(this: ArcTables) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isSource(io)

    return ARCtrl_ArcTables__ArcTables_getNodesBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_Data(this: ArcTables) -> Array[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getNodesBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_FirstData(this: ArcTables) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getRootInputsBy_Static(predicate, this)


def ARCtrl_ArcTables__ArcTables_get_LastData(this: ArcTables) -> FSharpList[QNode]:
    def predicate(io: IOType, this: Any=this) -> bool:
        return ARCtrl_IOType__IOType_get_isData(io)

    return ARCtrl_ArcTables__ArcTables_getFinalOutputsBy_Static(predicate, this)


def QNode__get_DataContext(this: QNode) -> DataContext | None:
    if ARCtrl_IOType__IOType_get_isData(this.io_type):
        match_value: DataContext | None = DataContext_tryGetDataContextByName(this.name)
        if match_value is None:
            return DataContext__ctor_Z780A8A2A(None, this.name)

        else: 
            dc: DataContext = match_value
            return DataContext__ctor_Z780A8A2A(dc.ID, this.name, None, dc.Format, dc.SelectorFormat, DataContext__get_Explication(dc), DataContext__get_Unit(dc), DataContext__get_ObjectType(dc), DataContext__get_Label(dc), DataContext__get_Description(dc), DataContext__get_GeneratedBy(dc), dc.Comments)


    else: 
        return None



def QNode__get_FilePath(this: QNode) -> str:
    if ARCtrl_IOType__IOType_get_isData(this.io_type):
        return value_2(value_2(QNode__get_DataContext(this)).FilePath)

    else: 
        return ""



def QNode__get_Selector(this: QNode) -> str | None:
    if ARCtrl_IOType__IOType_get_isData(this.io_type):
        return value_2(QNode__get_DataContext(this)).Selector

    else: 
        return None



def QNode__get_ParentProcessSequence(this: QNode) -> ArcTables:
    return default_arg(this.parent_process_sequence, ArcTables([]))


def QNode__get_Name(this: QNode) -> str:
    return this.name


def QNode__get_IOType(this: QNode) -> IOType:
    return this.io_type


def QNode__get_isSource(this: QNode) -> bool:
    return ARCtrl_IOType__IOType_get_isSource(QNode__get_IOType(this))


def QNode__get_isSample(this: QNode) -> bool:
    return ARCtrl_IOType__IOType_get_isSample(QNode__get_IOType(this))


def QNode__get_isData(this: QNode) -> bool:
    return ARCtrl_IOType__IOType_get_isData(QNode__get_IOType(this))


def QNode__get_isMaterial(this: QNode) -> bool:
    return ARCtrl_IOType__IOType_get_isMaterial(QNode__get_IOType(this))


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Nodes(this: QNode) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_NodesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstNodes(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_FirstNodesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastNodes(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_LastNodesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Samples(this: QNode) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_SamplesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstSamples(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_FirstSamplesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastSamples(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_LastSamplesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Sources(this: QNode) -> Array[QNode]:
    return ARCtrl_ArcTables__ArcTables_SourcesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Data(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_FirstDataOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstData(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_FirstDataOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastData(this: QNode) -> FSharpList[QNode]:
    return ARCtrl_ArcTables__ArcTables_LastNodesOf_Z301E6E48(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Values(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousValues(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingValues(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Characteristics(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_CharacteristicsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousCharacteristics(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousCharacteristicsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingCharacteristics(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingCharacteristicsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Parameters(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_ParametersOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousParameters(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousParametersOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingParameters(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingParametersOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Factors(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_FactorsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousFactors(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousFactorsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingFactors(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingFactorsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Components(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_ComponentsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousComponents(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_PreviousComponentsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


def ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingComponents(this: QNode) -> ValueCollection:
    return ARCtrl_ArcTables__ArcTables_SucceedingComponentsOf_Z5E11E140(QNode__get_ParentProcessSequence(this), this)


__all__ = ["QNode_reflection", "ARCtrl_IOType__IOType_get_isSource", "ARCtrl_IOType__IOType_get_isSample", "ARCtrl_IOType__IOType_get_isMaterial", "ARCtrl_IOType__IOType_get_isData", "ARCtrl_ArcTables__ArcTables_concat_Static_Z6D8BD2B8", "ARCtrl_ArcTables__ArcTables_getNodes_Static_Z63B5F9B8", "ARCtrl_ArcTables__ArcTables_getSubTreeOf_Static", "ARCtrl_ArcTables__ArcTables_getRootInputs_Static_Z63B5F9B8", "ARCtrl_ArcTables__ArcTables_getFinalOutputs_Static_Z63B5F9B8", "ARCtrl_ArcTables__ArcTables_getNodesBy_Static", "ARCtrl_ArcTables__ArcTables_getRootInputsBy_Static", "ARCtrl_ArcTables__ArcTables_getFinalOutputsBy_Static", "ARCtrl_ArcTables__ArcTables_getPreviousNodesBy_Static", "ARCtrl_ArcTables__ArcTables_getSucceedingNodesBy_Static", "ARCtrl_ArcTables__ArcTables_getNodesOfBy_Static", "ARCtrl_ArcTables__ArcTables_getRootInputsOfBy_Static", "ARCtrl_ArcTables__ArcTables_getFinalOutputsOfBy_Static", "ARCtrl_ArcTables__ArcTables_getPreviousValuesOf_Static", "ARCtrl_ArcTables__ArcTables_getSucceedingValuesOf_Static", "ARCtrl_ArcTables__ArcTables_onlyValuesOfProtocol_Static", "ARCtrl_ArcTables__ArcTables_NodesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_NodesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_FirstNodesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_LastNodesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_FirstNodesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_LastNodesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_SamplesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_SamplesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_FirstSamplesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_LastSamplesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_FirstSamplesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_LastSamplesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_SourcesOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_SourcesOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_DataOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_DataOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_FirstDataOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_LastDataOf_Z301E6E48", "ARCtrl_ArcTables__ArcTables_FirstDataOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_LastDataOf_Z721C83C5", "ARCtrl_ArcTables__ArcTables_Values_6DFDD678", "ARCtrl_ArcTables__ArcTables_Values_59965269", "ARCtrl_ArcTables__ArcTables_Values_27AED5E3", "ARCtrl_ArcTables__ArcTables_Factors_6DFDD678", "ARCtrl_ArcTables__ArcTables_Parameters_6DFDD678", "ARCtrl_ArcTables__ArcTables_Characteristics_6DFDD678", "ARCtrl_ArcTables__ArcTables_Components_6DFDD678", "ARCtrl_ArcTables__ArcTables_PreviousValuesOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_PreviousValuesOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_SucceedingValuesOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_ValuesOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_ValuesOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_CharacteristicsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_CharacteristicsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_PreviousCharacteristicsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_PreviousCharacteristicsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_SucceedingCharacteristicsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_SucceedingCharacteristicsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_ParametersOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_ParametersOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_PreviousParametersOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_PreviousParametersOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_SucceedingParametersOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_SucceedingParametersOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_FactorsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_FactorsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_PreviousFactorsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_PreviousFactorsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_SucceedingFactorsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_SucceedingFactorsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_ComponentsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_ComponentsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_PreviousComponentsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_PreviousComponentsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_SucceedingComponentsOf_27AED5E3", "ARCtrl_ArcTables__ArcTables_SucceedingComponentsOf_Z5E11E140", "ARCtrl_ArcTables__ArcTables_Contains_59965269", "ARCtrl_ArcTables__ArcTables_Contains_27AED5E3", "ARCtrl_ArcTables__ArcTables_get_Nodes", "ARCtrl_ArcTables__ArcTables_get_FirstNodes", "ARCtrl_ArcTables__ArcTables_get_LastNodes", "ARCtrl_ArcTables__ArcTables_get_Samples", "ARCtrl_ArcTables__ArcTables_get_FirstSamples", "ARCtrl_ArcTables__ArcTables_get_LastSamples", "ARCtrl_ArcTables__ArcTables_get_Sources", "ARCtrl_ArcTables__ArcTables_get_Data", "ARCtrl_ArcTables__ArcTables_get_FirstData", "ARCtrl_ArcTables__ArcTables_get_LastData", "QNode__get_DataContext", "QNode__get_FilePath", "QNode__get_Selector", "QNode__get_ParentProcessSequence", "QNode__get_Name", "QNode__get_IOType", "QNode__get_isSource", "QNode__get_isSample", "QNode__get_isData", "QNode__get_isMaterial", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Nodes", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstNodes", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastNodes", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Samples", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstSamples", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastSamples", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Sources", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Data", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_FirstData", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_LastData", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Values", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousValues", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingValues", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Characteristics", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousCharacteristics", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingCharacteristics", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Parameters", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousParameters", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingParameters", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Factors", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousFactors", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingFactors", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_Components", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_PreviousComponents", "ARCtrl_QueryModel_ArcTables_QNode__QNode_get_SucceedingComponents"]

