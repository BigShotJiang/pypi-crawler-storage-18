# vardict

### Introduction

