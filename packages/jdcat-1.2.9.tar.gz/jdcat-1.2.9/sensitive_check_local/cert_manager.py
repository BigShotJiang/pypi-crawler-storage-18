"""
Certificate management for mitmproxy HTTPS interception.

This module provides persistent certificate management by using the standard
~/.mitmproxy/ directory, ensuring certificates survive app reinstallation.
"""

import os
import platform
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict, Any
import logging
import datetime


class CertificateManager:
    """
    Manages mitmproxy certificates with persistent storage and system trust.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.mitmproxy_dir = Path.home() / '.mitmproxy'
        self.ca_cert_path = self.mitmproxy_dir / 'mitmproxy-ca-cert.pem'
        self.ca_key_path = self.mitmproxy_dir / 'mitmproxy-ca.pem'
        
    def ensure_mitmproxy_dir(self) -> None:
        """Ensure ~/.mitmproxy directory exists."""
        self.mitmproxy_dir.mkdir(exist_ok=True)
        self.logger.info(f"Ensured mitmproxy directory exists: {self.mitmproxy_dir}")
        
        # 创建证书安装引导文件
        self._create_certificate_guide_file()
    
    def _create_certificate_guide_file(self) -> None:
        """创建证书安装引导文件"""
        guide_file_path = self.mitmproxy_dir / "证书安装引导.txt"
        
        guide_content = """🔒 JDCat HTTPS证书安装指南
============================================================

📍 需要安装的证书文件:
   📄 mitmproxy-ca-cert.pem
   📂 完整路径: {cert_path}

⚠️  重要说明:
   证书目录中有多个文件，请只安装 mitmproxy-ca-cert.pem 文件！
   其他文件（.p12、.cer、dhparam等）无需手动安装。

🔧 安装步骤:
1. 在当前目录中，找到 "mitmproxy-ca-cert.pem" 文件
2. 双击该文件，或拖拽到 "钥匙串访问" 应用
3. 选择添加到 "系统" 钥匙串
4. 在钥匙串中找到 "mitmproxy" 证书，双击打开
5. 展开 "信任" 部分，将 "SSL" 设置为 "始终信任"
6. 输入管理员密码确认

💡 提示:
   • 只需安装一次，重装应用无需重复操作
   • 不信任证书将无法进行HTTPS流量拦截
   • 可在应用运行后随时通过状态栏菜单重新生成证书
   • 如需帮助，请查看应用内的详细说明

============================================================
JDCat - 敏感信息检测工具
生成时间: {timestamp}
""".format(
            cert_path=str(self.ca_cert_path),
            timestamp=datetime.datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")
        )
        
        try:
            with open(guide_file_path, 'w', encoding='utf-8') as f:
                f.write(guide_content)
            self.logger.info(f"Created certificate installation guide: {guide_file_path}")
        except Exception as e:
            self.logger.error(f"Failed to create certificate guide file: {e}")
    
    def get_ca_cert_path(self) -> Path:
        """Get the path to the CA certificate."""
        return self.ca_cert_path
    
    def get_ca_key_path(self) -> Path:
        """Get the path to the CA private key."""
        return self.ca_key_path
    
    def certificate_exists(self) -> bool:
        """Check if mitmproxy CA certificate exists."""
        return self.ca_cert_path.exists() and self.ca_key_path.exists()
    
    def setup_certificate_environment(self) -> Dict[str, str]:
        """
        Setup environment variables for mitmproxy certificate usage.
        
        Returns:
            Dict of environment variables to set.
        """
        env_vars = {}
        
        # Ensure directory exists
        self.ensure_mitmproxy_dir()
        
        # Set MITMPROXY_CONFDIR to use persistent directory
        env_vars['MITMPROXY_CONFDIR'] = str(self.mitmproxy_dir)
        
        # If certificate exists, set the CA cert path
        if self.certificate_exists():
            env_vars['MITMPROXY_CA_CERT'] = str(self.ca_cert_path)
            self.logger.info(f"Using existing certificate: {self.ca_cert_path}")
        else:
            self.logger.info("Certificate will be generated on first mitmproxy run")
        
        return env_vars
    
    def is_certificate_trusted_macos(self) -> bool:
        """
        Check if the certificate is trusted in macOS keychain.
        
        Returns:
            True if certificate is trusted, False otherwise.
        """
        if platform.system() != "Darwin":
            return False
            
        if not self.certificate_exists():
            return False
            
        try:
            # Use security command to check if certificate is trusted
            # verify-cert -c cert_file -p ssl
            # Note: verify-cert might return success if the cert is trusted in ANY keychain,
            # but sometimes we want to ensure it's in System keychain or at least findable.
            # However, for now, we trust verify-cert's judgment on trust.
            # If verify-cert says it's trusted, it works for interception.
            # BUT, to fix the issue where user can't find the cert and wants to reinstall,
            # we also check if we can FIND the certificate.
            
            # 1. Check trust
            verify_cmd = [
                'security', 'verify-cert', 
                '-c', str(self.ca_cert_path),
                '-p', 'ssl'  # SSL policy
            ]
            verify_result = subprocess.run(verify_cmd, capture_output=True, text=True)
            
            if verify_result.returncode != 0:
                return False

            # 2. Check existence in keychains (using SHA1 fingerprint to be precise)
            # If verify-cert passes but we can't find it, it's in a weird state.
            # We return False to allow user to re-install.
            try:
                # Get SHA1 fingerprint
                openssl_cmd = ['openssl', 'x509', '-in', str(self.ca_cert_path), '-noout', '-fingerprint']
                fp_result = subprocess.run(openssl_cmd, capture_output=True, text=True)
                if fp_result.returncode == 0:
                    # Output format: SHA1 Fingerprint=XX:XX:...
                    fingerprint = fp_result.stdout.strip().split('=')[1].replace(':', '')
                    
                    # Search by fingerprint
                    find_cmd = ['security', 'find-certificate', '-a', '-Z']
                    find_result = subprocess.run(find_cmd, capture_output=True, text=True)
                    if fingerprint not in find_result.stdout.replace(' ', ''):
                         self.logger.warning("Certificate trusted but not found in keychain listing. Marking as untrusted to allow reinstall.")
                         return False
            except Exception:
                pass # If openssl fails or something else, ignore and rely on verify-cert

            return True
        except Exception as e:
            self.logger.debug(f"Failed to check certificate trust: {e}")
            return False
    
    def trust_certificate_macos(self) -> tuple[bool, str]:
        """
        Trust the mitmproxy certificate in macOS keychain.
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        if platform.system() != "Darwin":
            msg = "Certificate trust is only supported on macOS"
            self.logger.warning(msg)
            return False, msg
            
        if not self.certificate_exists():
            msg = "Certificate does not exist, cannot trust"
            self.logger.error(msg)
            return False, msg
        
        try:
            # Use System Keychain for broader trust (especially for enterprise tools)
            # -d: Add to admin cert store
            # -r trustRoot: Trust as Root CA
            # -k: Specify System keychain
            
            import shlex
            cert_path_quoted = shlex.quote(str(self.ca_cert_path))
            
            system_keychain = "/Library/Keychains/System.keychain"
            security_cmd = f'security add-trusted-cert -d -r trustRoot -k {system_keychain} {cert_path_quoted}'
            
            # Direct Terminal Approach (User requested unified experience)
            # We create a temporary .command file to run in Terminal
            # This guarantees an interactive shell for sudo password and consistent UX
            import tempfile
            import os
            import stat
            
            # Create a temporary file with .command extension
            fd, command_path = tempfile.mkstemp(suffix='.command', prefix='install_cert_', text=True)
            
            try:
                with os.fdopen(fd, 'w') as f:
                    f.write('#!/bin/bash\n')
                    f.write('clear\n')
                    f.write('echo "🔐 正在安装 https 证书到系统钥匙串, 请在下方输入您的电脑登录密码"\n')
                    f.write(f'sudo {security_cmd}\n')
                    f.write('if [ $? -eq 0 ]; then\n')
                    f.write('    echo ""\n')
                    f.write('    echo "✅ 证书安装成功！"\n')
                    f.write('    exit 0\n')
                    f.write('else\n')
                    f.write('    echo ""\n')
                    f.write('    echo "❌ 证书安装失败。"\n')
                    f.write('    echo ""\n')
                    f.write('    read -n 1 -s -r -p "按任意键关闭此窗口..."\n')
                    f.write('    exit 1\n')
                    f.write('fi\n') 
                
                # Make executable
                os.chmod(command_path, os.stat(command_path).st_mode | stat.S_IEXEC)
                
                # Use AppleScript to run the command and monitor it for auto-close
                # This avoids the "Process Completed" lingering window and the "Terminate Process?" warning
                apple_script = f'''
                tell application "Terminal"
                    activate
                    set newTab to do script "{command_path}"
                    set targetWindow to first window whose tabs contains newTab
                    repeat
                        delay 0.5
                        try
                            if not (busy of newTab) then exit repeat
                        on error
                            -- Tab might be closed by user
                            exit repeat
                        end try
                    end repeat
                    try
                        close targetWindow
                    end try
                end tell
                '''
                
                subprocess.run(['osascript', '-e', apple_script])
                
                return True, "已打开终端窗口，请在终端中输入密码完成安装"
                
            except Exception as e:
                self.logger.error(f"Failed to create .command file: {e}")
                raise e

        except Exception as e:
            msg = f"Exception while trusting certificate: {e}"
            self.logger.error(msg)
            try:
                subprocess.run(['open', str(self.ca_cert_path)])
            except:
                pass
            return False, f"发生错误: {str(e)}，已尝试打开证书文件"
    
    def get_certificate_info(self) -> Dict[str, Any]:
        """
        Get information about the current certificate status.
        
        Returns:
            Dictionary with certificate information.
        """
        info = {
            'mitmproxy_dir': str(self.mitmproxy_dir),
            'ca_cert_path': str(self.ca_cert_path),
            'ca_key_path': str(self.ca_key_path),
            'certificate_exists': self.certificate_exists(),
            'directory_exists': self.mitmproxy_dir.exists(),
            'platform': platform.system(),
        }
        
        if platform.system() == "Darwin":
            info['trusted_in_keychain'] = self.is_certificate_trusted_macos()
        
        return info
    
    def initialize_certificates(self) -> Dict[str, Any]:
        """
        Initialize certificate setup for the application.
        
        This method:
        1. Ensures mitmproxy directory exists
        2. Sets up environment variables
        3. Optionally prompts for certificate trust on macOS
        
        Returns:
            Dictionary with setup results and environment variables.
        """
        self.logger.info("Initializing certificate management")
        
        # Setup environment
        env_vars = self.setup_certificate_environment()
        
        # Get current status
        cert_info = self.get_certificate_info()
        
        result = {
            'success': True,
            'env_vars': env_vars,
            'certificate_info': cert_info,
            'messages': []
        }
        
        if not cert_info['certificate_exists']:
            result['messages'].append("Certificate will be generated automatically on first mitmproxy run")
            # Mark that trust will be needed after certificate generation
            if platform.system() == "Darwin":
                result['needs_trust'] = True
                result['messages'].append("Certificate will need to be trusted after generation")
        else:
            result['messages'].append(f"Using existing certificate: {self.ca_cert_path}")
            
            # Check trust status on macOS
            if platform.system() == "Darwin":
                if not cert_info.get('trusted_in_keychain', False):
                    result['messages'].append("Certificate exists but is not trusted in keychain")
                    result['needs_trust'] = True
                else:
                    result['messages'].append("Certificate is trusted in system keychain")
        
        return result
    
    def prompt_certificate_trust(self) -> bool:
        """
        Prompt user to trust certificate and attempt to install it.
        
        Returns:
            True if certificate was successfully trusted or already trusted.
        """
        if platform.system() != "Darwin":
            return True  # Not applicable on non-macOS
            
        if not self.certificate_exists():
            self.logger.info("Certificate doesn't exist yet, will be handled after mitmproxy generates it")
            return True
            
        if self.is_certificate_trusted_macos():
            self.logger.info("Certificate is already trusted")
            return True
        
        self.logger.info("Certificate needs to be trusted for HTTPS interception")
        
        # Attempt to trust the certificate
        success, msg = self.trust_certificate_macos()
        if not success:
            self.logger.warning(f"Trust failed: {msg}")
        return success
    
    def regenerate_certificates(self) -> Dict[str, Any]:
        """
        重新生成mitmproxy证书。
        
        这会删除现有证书并强制mitmproxy生成新的证书。
        
        Returns:
            Dictionary with regeneration results.
        """
        result = {
            'success': False,
            'messages': [],
            'certificate_info': {},
            'needs_trust': False
        }
        
        try:
            self.logger.info("Starting certificate regeneration...")
            
            # 1. 备份现有证书（如果存在）
            if self.certificate_exists():
                backup_dir = self.mitmproxy_dir / 'backup'
                backup_dir.mkdir(exist_ok=True)
                
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                
                if self.ca_cert_path.exists():
                    backup_cert = backup_dir / f"mitmproxy-ca-cert_{timestamp}.pem"
                    shutil.copy2(self.ca_cert_path, backup_cert)
                    result['messages'].append(f"Backed up certificate to: {backup_cert}")
                
                if self.ca_key_path.exists():
                    backup_key = backup_dir / f"mitmproxy-ca_{timestamp}.pem"
                    shutil.copy2(self.ca_key_path, backup_key)
                    result['messages'].append(f"Backed up key to: {backup_key}")
            
            # 2. 删除现有证书文件
            cert_files_to_remove = [
                self.ca_cert_path,
                self.ca_key_path,
                self.mitmproxy_dir / 'mitmproxy-ca-cert.cer',
                self.mitmproxy_dir / 'mitmproxy-ca-cert.p12',
                self.mitmproxy_dir / 'mitmproxy-ca.p12',
                self.mitmproxy_dir / 'mitmproxy-dhparam.pem'
            ]
            
            removed_files = []
            for cert_file in cert_files_to_remove:
                if cert_file.exists():
                    cert_file.unlink()
                    removed_files.append(str(cert_file))
                    
            if removed_files:
                result['messages'].append(f"Removed {len(removed_files)} certificate files")
                self.logger.info(f"Removed certificate files: {removed_files}")
            
            # 3. 直接使用CertStore生成证书
            try:
                self.logger.info("Generating certificates using CertStore")
                
                # 设置环境变量
                env = os.environ.copy()
                env['MITMPROXY_CONFDIR'] = str(self.mitmproxy_dir)
                
                # 使用CertStore直接生成证书
                from mitmproxy.certs import CertStore
                
                # 创建CertStore并强制生成CA证书
                cert_store = CertStore.from_store(str(self.mitmproxy_dir), 'mitmproxy', 2048)
                ca_cert = cert_store.default_ca  # 这会触发证书生成
                
                result['messages'].append("Successfully generated certificates using CertStore")
                self.logger.info("Certificate generation via CertStore completed")
                    
            except Exception as cert_error:
                error_msg = f"Certificate generation failed: {cert_error}"
                result['messages'].append(error_msg)
                self.logger.error(error_msg)
            
            # 4. 验证新证书是否生成
            if self.certificate_exists():
                result['success'] = True
                result['messages'].append("New certificates generated successfully")
                
                # 检查是否需要信任
                if platform.system() == "Darwin":
                    if not self.is_certificate_trusted_macos():
                        result['needs_trust'] = True
                        result['messages'].append("New certificate needs to be trusted in keychain")
                    else:
                        result['messages'].append("New certificate is already trusted")
                        
            else:
                result['messages'].append("Certificate generation may have failed - files not found")
                
            # 5. 更新证书安装引导文件
            self._create_certificate_guide_file()
            
            # 6. 获取最新证书信息
            result['certificate_info'] = self.get_certificate_info()
            
        except Exception as e:
            result['messages'].append(f"Certificate regeneration failed: {str(e)}")
            self.logger.error(f"Certificate regeneration error: {e}")
            
        return result


# Global certificate manager instance
cert_manager = CertificateManager()


def get_certificate_manager() -> CertificateManager:
    """Get the global certificate manager instance."""
    return cert_manager


def setup_certificate_environment() -> Dict[str, str]:
    """
    Convenience function to setup certificate environment.
    
    Returns:
        Dictionary of environment variables to set.
    """
    return cert_manager.setup_certificate_environment()


def initialize_certificates() -> Dict[str, Any]:
    """
    Convenience function to initialize certificates.
    
    Returns:
        Dictionary with initialization results.
    """
    return cert_manager.initialize_certificates()