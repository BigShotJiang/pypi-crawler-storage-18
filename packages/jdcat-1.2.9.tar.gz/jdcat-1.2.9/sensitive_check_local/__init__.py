"""
Local helper CLI for sensitive-check project.
"""

from typing import Final

# 统一从 jdcat 主包获取版本号
try:
    from jdcat import __version__
except ImportError:
    # Fallback for local development if jdcat is not in path
    __version__ = "0.0.0"
