"""
JDCat - Sensitive Check Local Service Package

This package provides a pip-installable version of the sensitive-check-local service.
"""

__version__ = "1.2.9"
__author__ = "Sensitive Check Team"
__description__ = "支持自动证书"