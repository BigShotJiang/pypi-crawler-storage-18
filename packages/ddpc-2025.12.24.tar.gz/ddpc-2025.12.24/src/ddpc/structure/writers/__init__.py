"""Structure file writers."""
