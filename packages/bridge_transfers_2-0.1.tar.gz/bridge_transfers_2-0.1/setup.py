
from setuptools import setup
setup(
    name="bridge_transfers_2",
    version="0.1",
    py_modules=["carrier"],
)
