import shutil
import subprocess
import os
import socket
import ctypes.util
from pathlib import Path

def check_dependencies():
    """
    Checks for required system libraries that are often missing.
    Returns a list of missing library names.
    """
    missing = []
    
    # Check for libzvbi (required by tes3mp binary)
    # On Debian/Ubuntu it is usually libzvbi.so.0
    lib_name = "libzvbi.so.0"
    path = ctypes.util.find_library("zvbi")
    
    # If find_library fails, sometimes it's because ldconfig cache isn't updated
    # or it's named slightly differently. We can try loading it directly.
    if not path:
        try:
            ctypes.CDLL(lib_name)
        except OSError:
            missing.append(lib_name)
    
    return missing

def is_flatpak_installed():
    return shutil.which("flatpak") is not None

def get_install_dir():
    return Path.home() / ".local" / "share" / "tes3mp"

def is_tes3mp_installed():
    """Checks if TES3MP binary exists in the local user folder."""
    exe = get_install_dir() / "tes3mp-browser"
    return exe.exists()

def is_tailscale_installed():
    return shutil.which("tailscale") is not None

def is_tailscale_running():
    if not is_tailscale_installed():
        return False
    try:
        # Check if the daemon is active via systemctl (systemd based distros)
        # Note: This might not work on all distros (like Alpine), but covers 99% of desktop Linux users.
        cmd = subprocess.run(["systemctl", "is-active", "tailscaled"], capture_output=True, text=True)
        return "active" in cmd.stdout
    except Exception:
        # Fallback check: try to ping tailscale socket or just assume if binary works
        try:
             res = subprocess.run(["tailscale", "status"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
             return res.returncode == 0
        except Exception:
             return False

from .utils import load_stored_data_path

def check_data_files(project_root):
    # Check via the persistent config
    stored_path = load_stored_data_path()
    local_present = stored_path is not None and stored_path.exists()
    
    # Check the actual config file to see if it's already linked
    home = Path.home()
    # Check both Flatpak and standard config locations
    cfg_candidates = [
        home / ".var/app/org.tes3mp.TES3MP/config/openmw/openmw.cfg",
        home / ".config/openmw/openmw.cfg"
    ]
    
    config_linked = False
    
    for cfg in cfg_candidates:
        if cfg.exists():
            try:
                with open(cfg, 'r') as f:
                    content = f.read()
                    # We check for 'data=' and ensure it's not just the default
                    # A robust check is hard without parsing, but finding our repo path or just any custom data path is a good signal.
                    # For now, let's just check if it has a data= line that matches our local path if local path exists
                    if 'data="' in content:
                         config_linked = True
            except:
                pass
            
    return {
        "local_present": local_present,
        "config_linked": config_linked
    }

def is_port_free(port=25565):
    """
    Checks if the game port is currently in use by another process.
    Returns True if the port is FREE (good for starting server).
    Returns False if the port is TAKEN (bad for starting, good for joining).
    """
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        try:
            s.bind(("0.0.0.0", port))
            return True
        except OSError:
            return False
