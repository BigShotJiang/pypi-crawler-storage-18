import asyncio
import os
import sys
import argparse
import json
import random
import string
from datetime import datetime, timezone
from typing import Optional, List, Dict

import httpx
import pyperclip
from textual.app import App, ComposeResult
from textual.widgets import Input, Static, Footer
from textual.containers import Vertical, Horizontal
from textual.reactive import reactive
from textual.binding import Binding
from rich.markdown import Markdown

# --- CONFIGURATION ---
VERSION = "0.3.5"
APP_NAME = "59chat"
INTERNAL_PKG = "chat59"
SUPABASE_URL = "https://xdqxebyyjxklzisddmwl.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhkcXhlYnl5anhrbHppc2RkbXdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk4Mzc0NDAsImV4cCI6MjA3NTQxMzQ0MH0.37JtLjN6mGfdac-t-cqNADa8OQlYIgSkZEFSngwxlM0"

CSS = (
    "Screen { background: #000000; color: #FFFFFF; }\n"
    "#header { dock: top; height: 4; background: #000000; padding: 1 2; }\n"
    "#header-info { width: 1fr; content-align: left middle; }\n"
    "#header-status { width: auto; content-align: right middle; color: #22C55E; text-style: bold; }\n"
    "#chat-scroll { height: 1fr; padding: 1 2; }\n"
    "#bottom-bar { dock: bottom; height: auto; background: #000000; }\n"
    "#input-row { height: 1; background: #0A0A0A; padding: 0 2; }\n"
    "#input-prefix { width: auto; color: #FFFFFF; text-style: bold; }\n"
    "Input { background: transparent; border: none; width: 1fr; height: 1; color: #FFFFFF; padding: 0; }\n"
    "Input:focus { border: none; }\n"
    ".message-item { width: 100%; height: auto; margin-bottom: 2; }\n"
    ".message-item.own { align-horizontal: right; }\n"
    ".message-item.other { align-horizontal: left; }\n"
    ".msg-container { width: auto; min-width: 40%; max-width: 80%; height: auto; }\n"
    ".msg-header { height: 1; color: #FFFFFF; }\n"
    ".msg-content { height: auto; padding: 0 1; }\n"
    ".msg-line { height: 1; color: #525252; }\n"
)

def parse_iso_dt(s: str) -> datetime:
    try:
        clean_s = s.replace('Z', '+00:00').split('+')[0]
        if '.' in clean_s:
            base, ms = clean_s.split('.')
            clean_s = f"{base}.{ms[:6]}"
        return datetime.fromisoformat(f"{clean_s}+00:00")
    except:
        return datetime.now(timezone.utc)

class SupabaseClient:
    def __init__(self):
        self.base_url = f"{SUPABASE_URL}/rest/v1"
        self.headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    async def get_messages(self, room_id: str):
        async with httpx.AsyncClient() as client:
            url = f"{self.base_url}/messages?room_id=eq.{room_id}&order=created_at.asc"
            res = await client.get(url, headers=self.headers)
            return res.json()

    async def send_message(self, room_id: str, nickname: str, content: str):
        async with httpx.AsyncClient() as client:
            data = {"room_id": room_id, "nickname": nickname, "content": content}
            await client.post(f"{self.base_url}/messages", headers=self.headers, json=data)

    async def mark_read(self, msg_ids: List[int]):
        if not msg_ids: return
        now = datetime.now(timezone.utc).isoformat()
        async with httpx.AsyncClient() as client:
            ids_str = f"({','.join(map(str, msg_ids))})"
            url = f"{self.base_url}/messages?id=in.{ids_str}"
            await client.patch(url, headers=self.headers, json={"read_at": now})

    async def get_active_users(self, room_id: str):
        async with httpx.AsyncClient() as client:
            url = f"{self.base_url}/messages?room_id=eq.{room_id}&select=nickname"
            res = await client.get(url, headers=self.headers)
            data = res.json()
            return len({m['nickname'] for m in data}) if isinstance(data, list) else 1

class MessageItem(Vertical):
    def __init__(self, m, is_own):
        super().__init__(classes=f"message-item {'own' if is_own else 'other'}")
        self.m = m
        self.is_own = is_own
        self.rendered_markdown = False

    def compose(self) -> ComposeResult:
        with Vertical(classes="msg-container"):
            yield Static(id="msg-header", classes="msg-header", markup=True)
            yield Static(id="msg-content", classes="msg-content")
            yield Static(id="msg-line", classes="msg-line", markup=True)

    def on_mount(self):
        self.set_interval(0.5, self.refresh_msg)
        self.refresh_msg()

    def update_data(self, new_m):
        self.m = new_m

    def refresh_msg(self):
        now = datetime.now(timezone.utc)
        read_at = self.m.get('read_at')
        
        status = " [dim]○[/]"
        if read_at:
            read_dt = parse_iso_dt(read_at)
            rem = 59 - (now - read_dt).total_seconds()
            if rem <= 0:
                self.remove()
                return
            status = f" [bold #22C55E]●[/] [bold #EF4444]{int(rem)}s[/]"

        user_style = "bold #FFFFFF" if self.is_own else "bold #525252"
        prefix = "› "
        
        dt_utc = parse_iso_dt(self.m['created_at'])
        dt_local = dt_utc.astimezone()
        time_part = dt_local.strftime("%H:%M")
        
        tz_offset = dt_local.strftime("%z")
        tz_display = f" (GMT{int(tz_offset[:3]):+})" if tz_offset else ""
        
        header_text = f"[{user_style}]{prefix}{self.m['nickname']}[/] [dim]{time_part}{tz_display}[/]{status}"
        self.query_one("#msg-header").update(header_text)
        
        if not self.rendered_markdown:
            self.query_one("#msg-content").update(Markdown(self.m['content']))
            self.rendered_markdown = True
        
        box_width = self.query_one(".msg-container").content_size.width
        if box_width > 0:
            self.query_one("#msg-line").update(f"[dim]{'─' * box_width}[/]")

class FiftyNineChat(App):
    CSS = CSS
    status_text = reactive("")
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "QUIT"),
        Binding("ctrl+r", "new_room", "NEW ROOM"),
        Binding("ctrl+l", "copy_invite", "INVITE"),
    ]
    
    def __init__(self, room_id: Optional[str] = None, is_new: bool = False):
        super().__init__()
        self.api = SupabaseClient()
        self.room_id = room_id or ""
        self.nickname = ""
        self.running = True
        self.active_users = 1
        self.is_new_session = is_new
        self.displayed_messages = {}

    def compose(self) -> ComposeResult:
        with Horizontal(id="header"):
            yield Static(id="header-info")
            yield Static(id="header-status")
        from textual.containers import VerticalScroll
        yield VerticalScroll(id="chat-scroll")
        with Vertical(id="bottom-bar"):
            with Horizontal(id="input-row"):
                yield Static("› ", id="input-prefix")
                yield Input(placeholder="Type message...", id="message-input")
            yield Footer()

    def on_mount(self) -> None:
        try:
            self.nickname = self._generate_nickname()
            if not self.room_id:
                self.room_id = self._generate_room_id()
                self.is_new_session = True
            
            self._update_header()
            
            welcome_msg = {
                'id': 'welcome-msg',
                'nickname': 'SYSTEM',
                'content': "**WELCOME TO 59CHAT**\nMessages vanish in 59s. Local timezone supported.",
                'created_at': datetime.now(timezone.utc).isoformat(),
                'read_at': datetime.now(timezone.utc).isoformat()
            }
            self._add_message_to_scroll(welcome_msg)

            asyncio.create_task(self._watch_sync_loop())
            asyncio.create_task(self._presence_heartbeat())
            
            if self.is_new_session:
                asyncio.create_task(self.action_copy_invite())
                
            self.query_one("#message-input").focus()
        except Exception as e:
            self.notify(f"Init failed: {e}", severity="error")

    def watch_status_text(self, text: str):
        try:
            self.query_one("#header-status").update(text)
        except: pass

    async def on_input_submitted(self, event: Input.Submitted):
        content = event.value.strip()
        if not content: return
        try:
            await self.api.send_message(self.room_id, self.nickname, content)
            event.input.value = ""
        except: pass

    def _generate_nickname(self) -> str:
        adj = ["Cold", "Swift", "Pure", "Thin", "Hard", "Dark"]
        noun = ["Grid", "Line", "Type", "Form", "Node", "Void"]
        return f"{random.choice(adj)}{random.choice(noun)}"

    def _generate_room_id(self) -> str:
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    def _update_header(self):
        info = f"ROOM [bold #FFFFFF]{self.room_id}[/]  │  USER [bold #FFFFFF]{self.nickname}[/]  │  ONLINE [bold #22C55E]{self.active_users}[/]"
        self.query_one("#header-info").update(info)

    def _add_message_to_scroll(self, m):
        mid = m['id']
        if mid not in self.displayed_messages:
            scroll = self.query_one("#chat-scroll")
            is_own = m['nickname'] == self.nickname
            msg_widget = MessageItem(m, is_own)
            self.displayed_messages[mid] = msg_widget
            scroll.mount(msg_widget)
            scroll.scroll_end(animate=False)
        else:
            # Update existing message if read_at state changed
            widget = self.displayed_messages[mid]
            if m.get('read_at') and not widget.m.get('read_at'):
                widget.update_data(m)

    async def _presence_heartbeat(self):
        while self.running:
            try:
                self.active_users = await self.api.get_active_users(self.room_id)
                self._update_header()
                await asyncio.sleep(10)
            except: await asyncio.sleep(10)

    async def _watch_sync_loop(self):
        """Unified loop to watch for new messages and mark received messages as read."""
        while self.running:
            try:
                data = await self.api.get_messages(self.room_id)
                if isinstance(data, list):
                    # 1. Add/Update messages in UI
                    for m in data:
                        self._add_message_to_scroll(m)
                    
                    # 2. Mark unread messages sent by others as read
                    unread_received = [
                        m['id'] for m in data 
                        if m['nickname'] != self.nickname and m.get('read_at') is None
                    ]
                    if unread_received:
                        await self.api.mark_read(unread_received)
                
                await asyncio.sleep(1)
            except: await asyncio.sleep(2)

    async def action_copy_invite(self):
        py = "python" if sys.platform == "win32" else "python3"
        cmd = f"{py} -m pip install -U pip ; {py} -m pip install --no-cache-dir --only-binary=:all: -U {APP_NAME} ; {py} -m {INTERNAL_PKG} --join {self.room_id}"
        try:
            pyperclip.copy(cmd)
            self.status_text = "INVITATION COPIED!"
            await asyncio.sleep(3)
            self.status_text = ""
        except: pass

    def action_new_room(self):
        self.room_id = self._generate_room_id()
        scroll = self.query_one("#chat-scroll")
        for child in list(scroll.children): child.remove()
        self.displayed_messages.clear()
        self._update_header()
        asyncio.create_task(self.action_copy_invite())

    def on_unmount(self) -> None:
        self.running = False

def main_func():
    parser = argparse.ArgumentParser()
    parser.add_argument("--join", help="Room ID")
    parser.add_argument("--new", action="store_true", help="New room")
    args = parser.parse_args()
    app = FiftyNineChat(room_id=None if args.new else args.join, is_new=args.new)
    app.run()

if __name__ == "__main__":
    main_func()
