# SLIP-PLATE - Shamir DEK Plates

SLIP-PLATE is a Python tool designed to split Data Encryption Keys (DEKs) (128/192/256-bit) using Shamir's Secret Sharing and render them as OneKey-style physical plates with built-in checksums.

This project does not implement a wallet and does not interact with blockchains directly.

## Installation

You can now install SLIP-PLATE directly from PyPI:

```bash
pip install slip-plate
```

This will automatically install the necessary dependencies (`cryptography` and `pyshamir`) and register the `slip-plate` command in your terminal.

## Usage

After installation, you can run the tool from anywhere using the `slip-plate` command:

```bash
slip-plate --dek-size 256 --parts 3 --threshold 2
```

### Arguments
- `--dek-size`: Size of the DEK in bits (`128`, `192`, or `256`). Default: `256`.
- `--parts`: Total number of Shamir shares to create. Default: `3`.
- `--threshold`: Minimum number of shares required to reconstruct the key. Default: `2`.

### Example Output
The tool generates ANSI-rendered plates for your terminal:

```text
=== KEK Share 1 ===
     2 1     │         │        
     0 0 5 2 │ 1       │        
     4 2 1 5 │ 2 6 3 1 │        
     8 4 2 6 │ 8 4 2 6 │ 8 4 2 1
    ─────────────────────────────
 1 | ○ ● ● ● │ ● ○ ○ ● │ ● ● ○ ○ │
 2 | ○ ○ ● ○ │ ○ ○ ○ ○ │ ○ ○ ● ○ │
 . | . . . . | . . . . | . . . . |
 . | . . . . | . . . . | . . . . |
 . | . . . . | . . . . | . . . . |
11 | ○ ○ ○ ● │ ● ● ● ○ │ ○ ○ ● ○ │
12 | ● ● ○ ○ │ ● ● ○ ● │ ● ○ ○ ○ │
    ─────────────────────────────
```
Dots (…) represent truncated rows for brevity.


## Security Model
- **Offline Storage:** Plates are intended to be generated once and stored physically (e.g., punched into metal).
- **Ephemeral Memory:** DEKs are reconstructed from a quorum of shares only during active operations and are not persisted digitally.
- **Unique Nonces:** Encryption uses unique nonces per session, embedded in the ciphertext.
- **Minimal Footprint:** Designed to ensure no DEK is stored on disk in an unencrypted state.

## Development & Testing

If you want to contribute or run tests from the source code:

1. **Clone the repository:**
   ```bash
   git clone https://github.com/avra911/slip-plate.git
   cd slip-plate
   ```
2. **Install in editable mode:**
   ```bash
   pip install -e .
   ```
3. **Run tests:**
   ```bash
   pip install pytest
   pytest -q
   ```

## Notes and Caveats
- **Research Tool:** This is a demo/research tool. Review the code and cryptographic implementations before use in production environments.
- **Physical Security:** Treat printed/punched plates as high-security assets.
- **Checksums:** The built-in checksum helps detect transcription errors but does not replace proper key management procedures.

## Disclaimer

This software is provided as-is, without warranty of any kind.

It is intended for educational and experimental purposes.
No formal security audit has been performed.

Do not use this software to secure funds or data
that you cannot afford to lose.

The authors take no responsibility for loss of funds,
data corruption, or other damages resulting from the use
or misuse of this software.


---
Contributions are welcome! Feel free to open a PR or an issue on [GitHub](https://github.com/avra911/slip-plate).