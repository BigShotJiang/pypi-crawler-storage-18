# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

__all__ = ["PolicyListFieldsResponse"]

PolicyListFieldsResponse: TypeAlias = List[str]
