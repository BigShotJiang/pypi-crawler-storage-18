import requests
from bs4 import BeautifulSoup
import json
from typing import List, Dict, Optional, Union
import re


class WebTableToJSON:
    """
    A class to extract HTML tables from webpages and convert them to JSON format.
    """
    
    def __init__(self, headers: Optional[Dict[str, str]] = None):
        """
        Initialize the WebTableToJSON converter.
        
        Args:
            headers: Optional HTTP headers to use for requests
        """
        self.headers = headers or {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
    
    def fetch_webpage(self, url: str) -> str:
        """
        Fetch the HTML content of a webpage.
        
        Args:
            url: The URL of the webpage to fetch
            
        Returns:
            HTML content as string
            
        Raises:
            requests.RequestException: If the request fails
        """
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            raise requests.RequestException(f"Failed to fetch webpage: {str(e)}")
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize text content.
        
        Args:
            text: Raw text to clean
            
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        
        # Remove extra whitespace and normalize
        text = re.sub(r'\s+', ' ', text.strip())
        # Remove non-printable characters
        text = re.sub(r'[^\x20-\x7E\u00A0-\uFFFF]', '', text)
        return text
    
    def extract_table_data(self, table) -> List[Dict[str, str]]:
        """
        Extract data from a single HTML table element.
        
        Args:
            table: BeautifulSoup table element
            
        Returns:
            List of dictionaries representing table rows
        """
        rows = []
        headers = []
        
        # Try to find headers in thead or first tr
        thead = table.find('thead')
        if thead:
            header_row = thead.find('tr')
        else:
            header_row = table.find('tr')
        
        if header_row:
            # Extract headers
            header_cells = header_row.find_all(['th', 'td'])
            headers = [self.clean_text(cell.get_text()) for cell in header_cells]
            
            # If no proper headers found, create generic ones
            if not any(headers) or all(h == "" for h in headers):
                headers = [f"Column_{i+1}" for i in range(len(header_cells))]
        
        # Extract data rows
        tbody = table.find('tbody')
        if tbody:
            data_rows = tbody.find_all('tr')
        else:
            # Skip the header row if we used it for headers
            all_rows = table.find_all('tr')
            data_rows = all_rows[1:] if thead is None and header_row else all_rows
        
        for row in data_rows:
            cells = row.find_all(['td', 'th'])
            if not cells:
                continue
                
            row_data = {}
            for i, cell in enumerate(cells):
                # Handle cases where there are more cells than headers
                if i < len(headers):
                    key = headers[i] if headers[i] else f"Column_{i+1}"
                else:
                    key = f"Column_{i+1}"
                
                # Extract cell content
                cell_text = self.clean_text(cell.get_text())
                
                # Check for links
                link = cell.find('a')
                if link and link.get('href'):
                    row_data[key] = {
                        'text': cell_text,
                        'link': link.get('href')
                    }
                else:
                    row_data[key] = cell_text
            
            if row_data:  # Only add non-empty rows
                rows.append(row_data)
        
        return rows
    
    def extract_tables_from_html(self, html_content: str) -> List[Dict]:
        """
        Extract all tables from HTML content.
        
        Args:
            html_content: HTML content as string
            
        Returns:
            List of dictionaries, each containing table data and metadata
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        tables = soup.find_all('table')
        
        if not tables:
            return []
        
        result = []
        for i, table in enumerate(tables):
            table_data = self.extract_table_data(table)
            
            if table_data:  # Only include tables with data
                table_info = {
                    'table_index': i,
                    'row_count': len(table_data),
                    'column_count': len(table_data[0]) if table_data else 0,
                    'data': table_data
                }
                
                # Try to find table caption or title
                caption = table.find('caption')
                if caption:
                    table_info['caption'] = self.clean_text(caption.get_text())
                
                result.append(table_info)
        
        return result
    
    def url_to_json(self, url: str, table_index: Optional[int] = None) -> Union[Dict, List[Dict]]:
        """
        Convert HTML tables from a URL to JSON format.
        
        Args:
            url: The URL of the webpage containing tables
            table_index: Optional index of specific table to extract (0-based)
            
        Returns:
            JSON data - single table dict if table_index specified, otherwise list of all tables
        """
        try:
            html_content = self.fetch_webpage(url)
            tables = self.extract_tables_from_html(html_content)
            
            if not tables:
                return {"error": "No tables found on the webpage"}
            
            if table_index is not None:
                if 0 <= table_index < len(tables):
                    return tables[table_index]
                else:
                    return {"error": f"Table index {table_index} not found. Found {len(tables)} tables."}
            
            return tables
            
        except Exception as e:
            return {"error": f"Failed to process webpage: {str(e)}"}
    
    def html_to_json(self, html_content: str, table_index: Optional[int] = None) -> Union[Dict, List[Dict]]:
        """
        Convert HTML tables from HTML content to JSON format.
        
        Args:
            html_content: HTML content as string
            table_index: Optional index of specific table to extract (0-based)
            
        Returns:
            JSON data - single table dict if table_index specified, otherwise list of all tables
        """
        try:
            tables = self.extract_tables_from_html(html_content)
            
            if not tables:
                return {"error": "No tables found in the HTML content"}
            
            if table_index is not None:
                if 0 <= table_index < len(tables):
                    return tables[table_index]
                else:
                    return {"error": f"Table index {table_index} not found. Found {len(tables)} tables."}
            
            return tables
            
        except Exception as e:
            return {"error": f"Failed to process HTML content: {str(e)}"}


# Convenience functions for direct use
def convert_url_to_json(url: str, table_index: Optional[int] = None) -> Union[Dict, List[Dict]]:
    """
    Convert tables from a URL to JSON format.
    
    Args:
        url: The URL of the webpage containing tables
        table_index: Optional index of specific table to extract (0-based)
        
    Returns:
        JSON data
    """
    converter = WebTableToJSON()
    return converter.url_to_json(url, table_index)


def convert_html_to_json(html_content: str, table_index: Optional[int] = None) -> Union[Dict, List[Dict]]:
    """
    Convert tables from HTML content to JSON format.
    
    Args:
        html_content: HTML content as string
        table_index: Optional index of specific table to extract (0-based)
        
    Returns:
        JSON data
    """
    converter = WebTableToJSON()
    return converter.html_to_json(html_content, table_index)


# FastAPI integration helpers
def get_main_table(url: str) -> Dict:
    """
    Get the main data table from a URL (usually the largest table).
    
    Args:
        url: The URL of the webpage containing tables
        
    Returns:
        The main table data as a dictionary
    """
    converter = WebTableToJSON()
    tables = converter.url_to_json(url)
    
    if isinstance(tables, dict) and 'error' in tables:
        return tables
    
    if not tables:
        return {"error": "No tables found"}
    
    # Find the table with the most rows (likely the main data table)
    main_table = max(tables, key=lambda x: x.get('row_count', 0))
    return main_table


def get_clean_ranking_data(url: str) -> Dict:
    """
    Specialized function for ranking websites like NIRF.
    Attempts to extract and clean the main ranking table.
    
    Args:
        url: The URL of the ranking webpage
        
    Returns:
        Cleaned ranking data
    """
    try:
        converter = WebTableToJSON()
        html_content = converter.fetch_webpage(url)
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Look for the main ranking table (usually has the most rows)
        tables = soup.find_all('table')
        if not tables:
            return {"error": "No tables found"}
        
        # Find table with ranking data (look for common ranking indicators)
        ranking_table = None
        max_rows = 0
        
        for table in tables:
            rows = table.find_all('tr')
            if len(rows) > max_rows:
                # Check if this looks like a ranking table
                first_row = rows[0] if rows else None
                if first_row:
                    text = first_row.get_text().lower()
                    if any(keyword in text for keyword in ['rank', 'institute', 'college', 'university', 'name', 'score']):
                        ranking_table = table
                        max_rows = len(rows)
        
        if not ranking_table:
            # Fallback to largest table
            ranking_table = max(tables, key=lambda t: len(t.find_all('tr')))
        
        # Extract data from the ranking table
        data = converter.extract_table_data(ranking_table)
        
        # Clean up the data for ranking tables
        cleaned_data = []
        for row in data:
            cleaned_row = {}
            for key, value in row.items():
                # Handle complex cell content
                if isinstance(value, dict) and 'text' in value:
                    # Extract just the institution name from complex text
                    text = value['text']
                    if 'More Details' in text:
                        # Split and take the first part (institution name)
                        parts = text.split('More Details')[0].strip()
                        cleaned_row[key] = parts
                    else:
                        cleaned_row[key] = text
                else:
                    cleaned_row[key] = value
            
            if cleaned_row:
                cleaned_data.append(cleaned_row)
        
        return {
            'table_index': 0,
            'row_count': len(cleaned_data),
            'column_count': len(cleaned_data[0]) if cleaned_data else 0,
            'data': cleaned_data,
            'source_url': url
        }
        
    except Exception as e:
        return {"error": f"Failed to extract ranking data: {str(e)}"}


# Example usage and testing
if __name__ == "__main__":
    # Test with the NIRF ranking URL
    test_url = "https://www.nirfindia.org/Rankings/2025/ManagementRanking.html"
    
    print("Testing WebTableToJSON with NIRF Management Rankings...")
    print("=" * 60)
    
    try:
        # Test the main table extraction
        print("1. Getting main table...")
        main_table = get_main_table(test_url)
        print("FULL JSON OUTPUT:")
        print(json.dumps(main_table, indent=2, ensure_ascii=False))
        
        # Test the specialized ranking function
        print("\n" + "="*60)
        print("2. Getting clean ranking data...")
        ranking_data = get_clean_ranking_data(test_url)
        print("FULL JSON OUTPUT:")
        print(json.dumps(ranking_data, indent=2, ensure_ascii=False))
            
        # Test with a simple table URL for comparison
        print("\n" + "="*60)
        print("3. Testing with a simpler table...")
        simple_result = convert_url_to_json("https://www.w3schools.com/html/html_tables.asp", table_index=0)
        print("FULL JSON OUTPUT:")
        print(json.dumps(simple_result, indent=2, ensure_ascii=False))
            
    except Exception as e:
        print(f"Error: {e}")