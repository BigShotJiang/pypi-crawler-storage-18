# webtable2json

A Python library to extract HTML tables from webpages and convert them to JSON format. Perfect for web scraping, data extraction, and converting tabular web data into structured JSON.

## Features

- Extract tables from URLs or HTML content
- Clean and normalize table data
- Handle complex table structures (thead, tbody, colspan, etc.)
- Preserve links and metadata
- Specialized functions for ranking websites
- Type hints for better development experience
- Comprehensive error handling

## Installation

```bash
pip install webtable2json
```

## Quick Start

```python
from webtable2json import convert_url_to_json, WebTableToJSON

# Extract all tables from a URL
tables = convert_url_to_json("https://example.com/page-with-tables")

# Extract a specific table (0-based index)
table = convert_url_to_json("https://example.com/page-with-tables", table_index=0)

# Use the class for more control
converter = WebTableToJSON()
result = converter.url_to_json("https://example.com")
```

## Usage Examples

### Basic Table Extraction

```python
from webtable2json import convert_url_to_json

# Get all tables from a webpage
tables = convert_url_to_json("https://www.w3schools.com/html/html_tables.asp")

for i, table in enumerate(tables):
    print(f"Table {i}: {table['row_count']} rows, {table['column_count']} columns")
    print(f"First row: {table['data'][0]}")
```

### Working with HTML Content

```python
from webtable2json import convert_html_to_json

html = """
<table>
    <tr><th>Name</th><th>Age</th></tr>
    <tr><td>John</td><td>25</td></tr>
    <tr><td>Jane</td><td>30</td></tr>
</table>
"""

tables = convert_html_to_json(html)
print(tables[0]['data'])
# Output: [{'Name': 'John', 'Age': '25'}, {'Name': 'Jane', 'Age': '30'}]
```

### Advanced Usage with Custom Headers

```python
from webtable2json import WebTableToJSON

# Custom headers for requests
headers = {
    'User-Agent': 'My Custom Bot 1.0',
    'Accept': 'text/html,application/xhtml+xml'
}

converter = WebTableToJSON(headers=headers)
result = converter.url_to_json("https://example.com")
```

### Specialized Functions

```python
from webtable2json import get_main_table, get_clean_ranking_data

# Get the largest table (usually the main data table)
main_table = get_main_table("https://example.com/data-page")

# Specialized function for ranking websites
ranking_data = get_clean_ranking_data("https://www.nirfindia.org/Rankings/2025/ManagementRanking.html")
```

## API Reference

### Classes

#### `WebTableToJSON`

Main class for table extraction and conversion.

**Methods:**
- `__init__(headers=None)`: Initialize with optional custom headers
- `fetch_webpage(url)`: Fetch HTML content from URL
- `extract_table_data(table)`: Extract data from BeautifulSoup table element
- `extract_tables_from_html(html_content)`: Extract all tables from HTML
- `url_to_json(url, table_index=None)`: Convert tables from URL to JSON
- `html_to_json(html_content, table_index=None)`: Convert tables from HTML to JSON

### Functions

#### `convert_url_to_json(url, table_index=None)`
Convert tables from a URL to JSON format.

#### `convert_html_to_json(html_content, table_index=None)`
Convert tables from HTML content to JSON format.

#### `get_main_table(url)`
Get the main data table from a URL (usually the largest table).

#### `get_clean_ranking_data(url)`
Specialized function for ranking websites like NIRF.

## Output Format

Each table is returned as a dictionary with the following structure:

```json
{
    "table_index": 0,
    "row_count": 10,
    "column_count": 3,
    "caption": "Optional table caption",
    "data": [
        {
            "Column 1": "Value 1",
            "Column 2": "Value 2",
            "Column 3": {
                "text": "Link Text",
                "link": "https://example.com"
            }
        }
    ]
}
```

## Requirements

- Python 3.7+
- requests >= 2.25.0
- beautifulsoup4 >= 4.9.0

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
