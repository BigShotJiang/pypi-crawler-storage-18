"""Foundry MCP - MCP server for SDD toolkit spec management."""

__version__ = "0.5.0"

from foundry_mcp.server import create_server, main

__all__ = ["__version__", "create_server", "main"]
