# mvision

计算机视觉工具包。

## Installation

```bash
pip install mvision
```

## Usage

See `mvision/samples` for examples.

