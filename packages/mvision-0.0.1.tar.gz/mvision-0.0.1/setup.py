from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="mvision",
    version="0.0.1",
    author="User",
    author_email="user@example.com",
    description="计算机视觉工具包",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/example/mvision",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy",
        "opencv-python",
        "torch",
        "torchvision",
        "onnxruntime",
        "matplotlib",
        "imageio",
        "pyautogui",
        "mss"
    ],
)

