import numpy as np
import cv2
import os


class VideoStream:
    def __init__(self, output_size=640, exit_key="q") -> None:
        if isinstance(output_size, int):
            output_size = (output_size, output_size)
        self.output_size = output_size
        self.exit_key = exit_key

    @staticmethod
    def pad(image: np.ndarray, pt, pl, pb, pr, padding_value):
        image = np.pad(image, ((pt, pb), (pl, pr), (0, 0)), "constant", constant_values=padding_value)
        return image

    @staticmethod
    def scale(image: np.ndarray, ratio):
        height, width, _ = image.shape
        image = cv2.resize(image, (int(ratio * width), int(ratio * height)))
        return image

    @staticmethod
    def scale_and_pad(image: np.ndarray, dsize, padding_value=0):
        w, h = dsize
        height, width, _ = image.shape
        ratio = min(w / width, h / height)
        image = VideoStream.scale(image, ratio)
        height, width, _ = image.shape
        pt, pl = (h - height) // 2, (w - width) // 2
        pb, pr = h - height - pt, w - width - pl
        image = VideoStream.pad(image, pt, pl, pb, pr, padding_value)
        return image, ratio, pl, pt

    def post_process(self, frame):
        if self.output_size:
            frame, _, _, _ = self.scale_and_pad(frame, self.output_size)
        return frame

    def from_camera(self, horizontal_flip=True):
        cap = cv2.VideoCapture(0)
        assert cap.isOpened()

        # Warm-up camera
        for _ in range(3):
            _ = cap.read()

        while True:
            key = cv2.waitKey(1) & 0xFF
            if key == ord(self.exit_key):
                cap.release()
                break

            success, frame = cap.read()
            if not success:
                cap.release()
                raise Exception("camera connection lost")

            frame = self.post_process(frame)
            if horizontal_flip:
                frame = cv2.flip(frame, 1)
            yield frame

    def from_gif(self, file_path):
        import imageio

        cap = imageio.mimread(file_path)
        for frame in cap:
            key = cv2.waitKey(1) & 0xFF
            if key == ord(self.exit_key):
                break

            frame = self.post_process(frame)
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)  # convert to BGR
            yield frame

    def from_h264(self, file_path, show_cap_fps=False):
        cap = cv2.VideoCapture(file_path)
        if show_cap_fps:
            fps = int(cap.get(cv2.CAP_PROP_FPS))
            print("video fps:", fps)

        while True:
            key = cv2.waitKey(1) & 0xFF
            if key == ord(self.exit_key):
                cap.release()
                break

            ret, frame = cap.read()
            if not ret:
                break
            frame = self.post_process(frame)
            yield frame

    def from_screenshot(self):
        import pyautogui as pag
        import mss

        w, h = self.output_size
        capture_range = {"top": 0, "left": 0, "width": w, "height": h}
        cap = mss.mss()

        while True:
            key = cv2.waitKey(1) & 0xFF
            if key == ord(self.exit_key):
                break
            x, y = pag.position()  # 返回鼠标的坐标
            capture_range["top"] = y - capture_range["height"] // 2
            capture_range["left"] = x - capture_range["width"] // 2
            # 检查是否超出屏幕边界
            screen_width, screen_height = pag.size()
            if (
                capture_range["left"] < 0
                or capture_range["top"] < 0
                or capture_range["left"] + capture_range["width"] > screen_width
                or capture_range["top"] + capture_range["height"] > screen_height
            ):
                continue
            frame = cap.grab(capture_range)
            frame = np.array(frame)
            frame = self.post_process(frame)
            frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2RGB)
            yield frame

    def from_nv12(self, file_path, yuv_size=(1920, 1080)):
        yuv_w, yuv_h = yuv_size
        file_size = os.path.getsize(file_path)
        max_frame = file_size // (yuv_w * yuv_h * 3 // 2) - 1

        cur_frame = 0
        with open(file_path, "rb") as probe:
            while True:
                key = cv2.waitKey(1) & 0xFF
                if key == ord(self.exit_key):
                    break
                cur_frame += 1
                if cur_frame > max_frame:
                    break
                yuv = np.frombuffer(probe.read(yuv_w * yuv_h * 3 // 2), dtype=np.uint8).reshape((yuv_h * 3 // 2, yuv_w))
                yuv = self.post_process(yuv)
                yuv = cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR_I420)
                yield yuv
