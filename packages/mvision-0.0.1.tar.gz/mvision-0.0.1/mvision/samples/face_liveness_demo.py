import torch
import cv2
import argparse
import onnxruntime
from mvision.hub.canvas import Canvas, im2tensor
from mvision.hub.stream import VideoStream


def face_detector(frame, face_detect_sess, conf_thr):
    # 1. 人脸检测预处理：等比缩放+padding到检测模型需要的尺寸（参考 m10043）
    detect_frame, scale_ratio, padding_left, padding_top = VideoStream.scale_and_pad(frame, [512, 288], padding_value=0)
    frame_tensor = im2tensor(detect_frame).unsqueeze(0)  # Convert image to tensor
    bias_padding = torch.tensor([padding_left, padding_top, padding_left, padding_top])
    limit = torch.tensor([frame.shape[1] - 1, frame.shape[0] - 1, frame.shape[1] - 1, frame.shape[0] - 1])

    # 2. 运行人脸检测
    ort_inputs = {face_detect_sess.get_inputs()[0].name: frame_tensor.numpy()}
    ort_outs = face_detect_sess.run(None, ort_inputs)

    # 3. 解析人脸检测结果
    box_out, cls_out = ort_outs
    conf_mask = (torch.from_numpy(cls_out).max(dim=1)[0] > conf_thr).squeeze(0)
    torch_out = torch.concat((torch.from_numpy(box_out), torch.from_numpy(cls_out)), dim=1).squeeze(0)
    torch_out = torch_out.transpose(0, 1)[conf_mask]
    for box in torch_out:
        box_m, cls_m = box[:4], box[4:]
        box_m = (box_m - bias_padding) / scale_ratio
        box_m = torch.clamp(box_m, min=torch.Tensor([0, 0, 0, 0]), max=limit)
        pt1, pt2 = box_m[:2], box_m[2:4]
        conf, _ = cls_m.max(dim=0)
        yield pt1, pt2, conf


def face_liveness_detector(frame, liveness_sess, box, expand_ratio=2.7):
    orig_h, orig_w = frame.shape[:2]
    pt1, pt2 = box
    center_x = (pt1[0] + pt2[0]) / 2
    center_y = (pt1[1] + pt2[1]) / 2

    # # 检查最终大小是否至少是 min_size
    # if min(pt2[0] - pt1[0], pt2[1] - pt1[1]) < min_size:
    #     return None

    # 计算3倍大小的边长（取宽高的最大值，确保是方形）
    original_size = max(pt2[0] - pt1[0], pt2[1] - pt1[1])
    expanded_size = original_size * expand_ratio
    half_size = expanded_size / 2

    # 计算外扩后的框坐标（方形）
    expanded_x1 = center_x - half_size
    expanded_y1 = center_y - half_size
    expanded_x2 = center_x + half_size
    expanded_y2 = center_y + half_size

    # 确保框在图像区域内不溢出，并保持方形
    # 如果框超出边界，缩小尺寸以适配
    if expanded_x1 < 0:
        half_size = min(half_size, center_x)
    if expanded_y1 < 0:
        half_size = min(half_size, center_y)
    if expanded_x2 > orig_w - 1:
        half_size = min(half_size, orig_w - 1 - center_x)
    if expanded_y2 > orig_h - 1:
        half_size = min(half_size, orig_h - 1 - center_y)

    # 计算最终的方形框坐标
    final_pt1 = (center_x - half_size, center_y - half_size)
    final_pt2 = (center_x + half_size, center_y + half_size)

    # 确保坐标在图像范围内（浮点数取整）
    final_pt1 = (max(0, int(final_pt1[0])), max(0, int(final_pt1[1])))
    final_pt2 = (min(orig_w - 1, int(final_pt2[0])), min(orig_h - 1, int(final_pt2[1])))

    # 5. 裁剪人脸区域并resize（使用原始分辨率图像保证质量）
    face_crop = frame[final_pt1[1] : final_pt2[1], final_pt1[0] : final_pt2[0]]
    face_crop = cv2.resize(face_crop, (80, 80))

    # 6. 活体检测预处理
    face_tensor = im2tensor(face_crop, to_rgb=False).unsqueeze(0)
    face_tensor *= 255.0

    # 7. 运行活体检测
    liveness_inputs = {liveness_sess.get_inputs()[0].name: face_tensor.numpy()}
    liveness_outs = liveness_sess.run(None, liveness_inputs)

    # 8. 解析活体检测结果
    live_prob = torch.softmax(torch.from_numpy(liveness_outs[0]), dim=1)[0, 1]
    return live_prob, (final_pt1, final_pt2)


def run_demo(face_detect_onnx_path, liveness_onnx_path, size, camera, screenshot, h264):
    # Load Canvas instance
    canvas = Canvas()

    # Load dataloader instance
    if camera:
        test_data = VideoStream(size).from_camera()
    elif screenshot:
        test_data = VideoStream(size).from_screenshot()
    elif h264 is not None:
        test_data = VideoStream(size).from_h264(h264)
    else:
        raise Exception("At least one of the stream mode must be specified, see -help")

    # Load model instance
    face_detect_sess = onnxruntime.InferenceSession(face_detect_onnx_path)
    liveness_sess = onnxruntime.InferenceSession(liveness_onnx_path)

    for frame in test_data:
        orig_frame = frame.copy()
        canvas.load(orig_frame)

        # Detect faces
        faces = face_detector(frame, face_detect_sess, 0.25)

        # Detect liveness
        for pt1, pt2, conf in faces:
            result = face_liveness_detector(frame, liveness_sess, (pt1, pt2))
            if result is not None:
                liveness, (final_pt1, final_pt2) = result
                if liveness > 0.9:
                    color = (0, 255, 0)
                    status = "LIVE"
                else:
                    color = (0, 0, 255)
                    status = "SPOOF"
                canvas.draw_box(final_pt1, final_pt2, alpha=0.4, thickness=-1, color=color, title=f"{status} {liveness:.2f}")
                canvas.draw_box(final_pt1, final_pt2, color=color, title=f"{status} {liveness:.2f}")

        canvas.show("demo", wait_key=1)


if __name__ == "__main__":
    # 创建 ArgumentParser 对象
    parser = argparse.ArgumentParser(description="Face Detection + Liveness Detection Demo")

    # 添加命令行参数
    parser.add_argument("--size", type=int, nargs=2, default=[640, 360], help="输入图像尺寸，如 1920 1088")
    parser.add_argument("--face_detect_model", type=str, default="yolov10n_face_detect_512x288.onnx", help="人脸检测模型路径")
    parser.add_argument("--liveness_model", type=str, default="2.7_80x80_MiniFASNetV2.onnx", help="活体检测模型路径")
    parser.add_argument("--camera", action="store_true", help="摄像头采集模式")
    parser.add_argument("--screenshot", action="store_true", help="截屏采集模式")
    parser.add_argument("--h264", type=str, default=None, help="h264视频流输入")

    # 解析命令行参数
    args = parser.parse_args()

    # 确保 size 是列表类型（已由 argparse 保证），此处可直接传递
    run_demo(
        face_detect_onnx_path=args.face_detect_model,
        liveness_onnx_path=args.liveness_model,
        size=args.size,
        camera=args.camera,
        screenshot=args.screenshot,
        h264=args.h264,
    )
