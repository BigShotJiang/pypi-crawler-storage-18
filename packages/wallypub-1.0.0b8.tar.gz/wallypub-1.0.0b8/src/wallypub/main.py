from wallypub.tui.termui import wallypub

if __name__ == "__main__":
    wallypub()
