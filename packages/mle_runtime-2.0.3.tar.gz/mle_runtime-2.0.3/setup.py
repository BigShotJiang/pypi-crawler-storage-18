#!/usr/bin/env python3

from setuptools import setup, find_packages
import os

# Read README with proper encoding handling
def read_readme():
    readme_path = "readme.md"
    if os.path.exists(readme_path):
        try:
            with open(readme_path, "r", encoding="utf-8") as f:
                return f.read()
        except UnicodeDecodeError:
            with open(readme_path, "r", encoding="latin-1") as f:
                return f.read()
    return "MLE Runtime Research Edition - Advanced ML Inference Runtime"

setup(
    name="mle_runtime",
    version="2.0.3",
    description="MLE Runtime Research Edition - Advanced ML Inference Runtime",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="MLE Research Team",
    author_email="research@mle.ai",
    url="https://github.com/mle-ai/mle-runtime",
    packages=find_packages(),
    package_data={
        'mle_runtime': ['*.pyd', '*.so', '*.dll'],
    },
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "scipy>=1.7.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-benchmark>=3.4.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: C++",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="machine learning, inference, runtime, optimization, research",
)