class UnknownResource(Exception):
    pass
