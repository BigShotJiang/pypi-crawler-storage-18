from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class UsageEvent:
    provider: str
    model: str

    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    total_tokens: Optional[int] = None

    input_cost_usd: Optional[float] = None
    output_cost_usd: Optional[float] = None
    cost_usd: Optional[float] = None

    accuracy: str = "unknown"  # "exact" | "estimated" | "unknown"

    request_id: Optional[str] = None
    latency_ms: Optional[int] = None
    status: str = "ok"  # "ok" | "error"
    error_type: Optional[str] = None
    error_message: Optional[str] = None

    ts: datetime = field(default_factory=utcnow)

    # attribution
    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    trace_id: Optional[str] = None

    metadata: dict[str, Any] = field(default_factory=dict)
