from __future__ import annotations

import time
from typing import Any, AsyncIterator, Iterator, Optional, Tuple

from ..events import UsageEvent
from ..meter import Meter


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    # works for dicts and objects
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _extract_usage(resp_or_chunk: Any) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """
    LiteLLM often returns a response with:
      - resp.usage.prompt_tokens / completion_tokens / total_tokens
    For streaming, some configs return usage in the final chunk.
    """
    usage = _get_attr(resp_or_chunk, "usage", None)
    if usage is None:
        # sometimes nested differently; keep this minimal for v1
        return None, None, None

    in_tok = _get_attr(usage, "prompt_tokens", None)
    out_tok = _get_attr(usage, "completion_tokens", None)
    total = _get_attr(usage, "total_tokens", None)

    # Sometimes LiteLLM usage might be dict-like
    if isinstance(usage, dict):
        in_tok = usage.get("prompt_tokens", in_tok)
        out_tok = usage.get("completion_tokens", out_tok)
        total = usage.get("total_tokens", total)

    return in_tok, out_tok, total


def _guess_provider_from_model(model: str) -> str:
    """
    LiteLLM supports prefixes like 'openai/gpt-4o-mini', 'anthropic/claude-...'.
    If absent, we default to 'litellm'.
    """
    if "/" in model:
        return model.split("/", 1)[0].lower()
    if ":" in model:
        return model.split(":", 1)[0].lower()
    return "litellm"


class _StreamWrapper(Iterator[Any]):
    def __init__(self, inner: Iterator[Any], finalize) -> None:
        self._inner = inner
        self._finalize = finalize
        self._done = False

    def __iter__(self) -> "_StreamWrapper":
        return self

    def __next__(self) -> Any:
        try:
            return next(self._inner)
        except StopIteration:
            if not self._done:
                self._done = True
                self._finalize()
            raise
        except Exception:
            if not self._done:
                self._done = True
                self._finalize(error=True)
            raise


class _AsyncStreamWrapper(AsyncIterator[Any]):
    def __init__(self, inner: AsyncIterator[Any], finalize) -> None:
        self._inner = inner
        self._finalize = finalize
        self._done = False

    def __aiter__(self) -> "_AsyncStreamWrapper":
        return self

    async def __anext__(self) -> Any:
        try:
            return await self._inner.__anext__()
        except StopAsyncIteration:
            if not self._done:
                self._done = True
                self._finalize()
            raise
        except Exception:
            if not self._done:
                self._done = True
                self._finalize(error=True)
            raise


class LiteLLM:
    """
    LiteLLM-first wrapper.
    - completion(): sync
    - acompletion(): async
    Supports stream=True and stream=False.
    """

    def __init__(self, *, meter: Meter) -> None:
        self.meter = meter

        try:
            import litellm  # type: ignore
        except Exception as e:
            raise RuntimeError(
                "litellm is not installed. Install with: pip install -e '.[litellm]'"
            ) from e

        self._litellm = litellm

    def completion(self, **kwargs: Any):
        """
        Mirrors litellm.completion(**kwargs).
        If stream=True, returns an iterator you can for-loop; event is recorded when stream ends.
        """
        model = kwargs.get("model", "unknown")
        provider = _guess_provider_from_model(model)

        stream = bool(kwargs.get("stream", False))

        # Best effort: ask for usage in streaming if supported by downstream.
        # Not all providers respect this; we still handle missing usage.
        kwargs.setdefault("stream_options", {"include_usage": True})

        t0 = time.time()
        last_chunk_holder: dict[str, Any] = {"last": None}
        status = "ok"
        err_type = None
        err_msg = None
        request_id: Optional[str] = None
        final_model: str = model

        def finalize(error: bool = False) -> None:
            latency_ms = int((time.time() - t0) * 1000)

            resp_or_chunk = last_chunk_holder["last"]
            in_tok = out_tok = total = None

            if resp_or_chunk is not None:
                in_tok, out_tok, total = _extract_usage(resp_or_chunk)
                request_id_local = _get_attr(resp_or_chunk, "id", None)
                nonlocal request_id, final_model
                if request_id is None:
                    request_id = request_id_local
                final_model = _get_attr(resp_or_chunk, "model", final_model) or final_model

            accuracy = "exact" if (in_tok is not None and out_tok is not None) else "unknown"
            in_cost, out_cost, cost, _price = self.meter.compute_cost(provider, final_model, in_tok, out_tok)

            event = UsageEvent(
                provider=provider,
                model=final_model,
                input_tokens=in_tok,
                output_tokens=out_tok,
                total_tokens=total,
                input_cost_usd=in_cost,
                output_cost_usd=out_cost,
                cost_usd=cost,
                accuracy=accuracy,
                request_id=request_id,
                latency_ms=latency_ms,
                status="error" if error else status,
                error_type=err_type,
                error_message=err_msg,
                metadata={"integration": "litellm", "stream": stream},
            )
            self.meter.record(event)

        try:
            resp = self._litellm.completion(**kwargs)
            if not stream:
                latency_ms = int((time.time() - t0) * 1000)

                request_id = _get_attr(resp, "id", None)
                final_model = _get_attr(resp, "model", model) or model
                in_tok, out_tok, total = _extract_usage(resp)

                accuracy = "exact" if (in_tok is not None and out_tok is not None) else "unknown"
                in_cost, out_cost, cost, _price = self.meter.compute_cost(provider, final_model, in_tok, out_tok)

                self.meter.record(
                    UsageEvent(
                        provider=provider,
                        model=final_model,
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                        total_tokens=total,
                        input_cost_usd=in_cost,
                        output_cost_usd=out_cost,
                        cost_usd=cost,
                        accuracy=accuracy,
                        request_id=request_id,
                        latency_ms=latency_ms,
                        status="ok",
                        metadata={"integration": "litellm", "stream": False},
                    )
                )
                return resp

            # stream=True
            def gen():
                for chunk in resp:
                    last_chunk_holder["last"] = chunk
                    yield chunk

            return _StreamWrapper(gen(), finalize)

        except Exception as e:
            status = "error"
            err_type = type(e).__name__
            err_msg = str(e)
            finalize(error=True)
            raise

    async def acompletion(self, **kwargs: Any):
        """
        Mirrors litellm.acompletion(**kwargs).
        If stream=True, returns an async iterator; event is recorded when stream ends.
        """
        model = kwargs.get("model", "unknown")
        provider = _guess_provider_from_model(model)
        stream = bool(kwargs.get("stream", False))

        kwargs.setdefault("stream_options", {"include_usage": True})

        t0 = time.time()
        last_chunk_holder: dict[str, Any] = {"last": None}
        status = "ok"
        err_type = None
        err_msg = None
        request_id: Optional[str] = None
        final_model: str = model

        def finalize(error: bool = False) -> None:
            latency_ms = int((time.time() - t0) * 1000)

            resp_or_chunk = last_chunk_holder["last"]
            in_tok = out_tok = total = None

            if resp_or_chunk is not None:
                in_tok, out_tok, total = _extract_usage(resp_or_chunk)
                request_id_local = _get_attr(resp_or_chunk, "id", None)
                nonlocal request_id, final_model
                if request_id is None:
                    request_id = request_id_local
                final_model = _get_attr(resp_or_chunk, "model", final_model) or final_model

            accuracy = "exact" if (in_tok is not None and out_tok is not None) else "unknown"
            in_cost, out_cost, cost, _price = self.meter.compute_cost(provider, final_model, in_tok, out_tok)

            event = UsageEvent(
                provider=provider,
                model=final_model,
                input_tokens=in_tok,
                output_tokens=out_tok,
                total_tokens=total,
                input_cost_usd=in_cost,
                output_cost_usd=out_cost,
                cost_usd=cost,
                accuracy=accuracy,
                request_id=request_id,
                latency_ms=latency_ms,
                status="error" if error else status,
                error_type=err_type,
                error_message=err_msg,
                metadata={"integration": "litellm", "stream": stream, "async": True},
            )
            self.meter.record(event)

        try:
            resp = await self._litellm.acompletion(**kwargs)
            if not stream:
                latency_ms = int((time.time() - t0) * 1000)

                request_id = _get_attr(resp, "id", None)
                final_model = _get_attr(resp, "model", model) or model
                in_tok, out_tok, total = _extract_usage(resp)

                accuracy = "exact" if (in_tok is not None and out_tok is not None) else "unknown"
                in_cost, out_cost, cost, _price = self.meter.compute_cost(provider, final_model, in_tok, out_tok)

                self.meter.record(
                    UsageEvent(
                        provider=provider,
                        model=final_model,
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                        total_tokens=total,
                        input_cost_usd=in_cost,
                        output_cost_usd=out_cost,
                        cost_usd=cost,
                        accuracy=accuracy,
                        request_id=request_id,
                        latency_ms=latency_ms,
                        status="ok",
                        metadata={"integration": "litellm", "stream": False, "async": True},
                    )
                )
                return resp

            # stream=True (async iterator)
            async def agen():
                async for chunk in resp:
                    last_chunk_holder["last"] = chunk
                    yield chunk

            return _AsyncStreamWrapper(agen(), finalize)

        except Exception as e:
            status = "error"
            err_type = type(e).__name__
            err_msg = str(e)
            finalize(error=True)
            raise
