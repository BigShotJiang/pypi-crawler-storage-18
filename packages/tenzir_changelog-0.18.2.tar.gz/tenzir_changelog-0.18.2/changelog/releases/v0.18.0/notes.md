This release introduces a version-agnostic release workflow that simplifies publishing and CI integration, allowing commands to default to the latest release version. It also improves changelog browsing by sorting module entries chronologically rather than grouping them by project.

## 🚀 Features

### Version-agnostic release workflow with default version resolution

The `release publish` command now accepts the version as an optional argument, defaulting to the latest released version when omitted. This makes it easier to publish the most recent release without explicitly specifying its version.

A new `release version` command prints the latest released version. The `--bare` flag strips the `v` prefix, making it convenient for version-agnostic workflows that need to reference the release version in scripts or CI/CD pipelines.

Additionally, release version validation has been strengthened to ensure semantic versioning compliance.

*By @mavam and @claude.*

## 🔧 Changes

### Chronological sorting for module-based changelogs

The `show` command now sorts entries by date across all modules, placing the latest entries at the bottom of the table. Previously, entries were grouped by project first, which scattered recent changes throughout the output based on module name order.

*By @mavam and @claude.*
