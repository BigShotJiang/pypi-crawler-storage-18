#     Copyright (c) mlinfra 2024-2025. All Rights Reserved.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at:
#         https://www.apache.org/licenses/LICENSE-2.0
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
#     or implied. See the License for the specific language governing
#     permissions and limitations under the License.

import mlinfra.cli.terraform as terraform
import mlinfra.cli.utilities as utilities
import typer

cli = typer.Typer(
    name="mlinfra",
    help="Welcome to mlinfra",
    add_completion=False,
    pretty_exceptions_show_locals=False,
    no_args_is_help=True,
    short_help=["h"],
)
cli.add_typer(terraform.app, name="terraform", help="Terraform tasks on config file")
cli.add_typer(
    utilities.app,
    name="utils",
    help="Utilities to help users perform actions on config file",
    rich_help_panel="Utilities",
)


if __name__ == "__main__":
    cli()
