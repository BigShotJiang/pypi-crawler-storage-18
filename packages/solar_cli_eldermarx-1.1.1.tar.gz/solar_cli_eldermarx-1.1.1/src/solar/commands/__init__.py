"""SOLAR CLI Commands"""
