"""SOLAR Utilities Module"""
