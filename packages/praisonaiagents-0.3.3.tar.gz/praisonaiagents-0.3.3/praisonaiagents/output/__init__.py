"""
Output Styles Module for PraisonAI Agents.

Provides configurable output formatting:
- Predefined styles (concise, detailed, technical, etc.)
- Custom formatting rules
- Markdown/plain text/JSON output
- Response length control

Zero Performance Impact:
- All imports are lazy loaded via __getattr__
- Styles only applied when configured
- No overhead when not in use

Usage:
    from praisonaiagents.output import OutputStyle, OutputFormatter
    
    # Use predefined style
    style = OutputStyle.concise()
    
    # Apply to agent
    agent = Agent(
        instructions="...",
        output_style=style
    )
    
    # Or format manually
    formatter = OutputFormatter(style)
    formatted = formatter.format(response)
"""

__all__ = [
    # Core classes
    "OutputStyle",
    "OutputFormatter",
    # Style presets
    "StylePreset",
    # Configuration
    "OutputConfig",
]


def __getattr__(name: str):
    """Lazy load module components to avoid import overhead."""
    if name == "OutputStyle":
        from .style import OutputStyle
        return OutputStyle
    
    if name == "OutputFormatter":
        from .formatter import OutputFormatter
        return OutputFormatter
    
    if name == "StylePreset":
        from .style import StylePreset
        return StylePreset
    
    if name == "OutputConfig":
        from .config import OutputConfig
        return OutputConfig
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
