import unittest
import shutil
import tempfile
import time
import os
import numpy as np
import datetime
from concurrent.futures import ThreadPoolExecutor
from bv_engine import VectorExp

class BaseVectorDBTest(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db = self._create_db()
        
    def _create_db(self, path=None, delete_batch_size=1, shards=2, auto_compact=0):
        if path is None:
            path = self.test_dir
        return VectorExp(
            storage_base_path=path, 
            shards=shards,
            delete_batch_size=delete_batch_size,
            max_size_gb=1,
            auto_compact_threshold=auto_compact
        )
    
    def tearDown(self):
        if hasattr(self, 'db') and self.db:
            self._close_db(self.db)
        if os.path.exists(self.test_dir):
            try:
                shutil.rmtree(self.test_dir)
            except OSError:
                pass # Sometimes Windows holds locks

    def _close_db(self, db_instance):
        """Helper to cleanly close DB handles"""
        try:
            if hasattr(db_instance, 'storage'):
                db_instance.storage.close()
            if hasattr(db_instance, 'meta_storage'):
                db_instance.meta_storage.close()
        except:
            pass

class TestCoreFunctionality(BaseVectorDBTest):
    def setUp(self):
        super().setUp()
        self.vectors = [
            [1.0, 0.0], [0.9, 0.1], [0.0, 1.0], [0.5, 0.5], [0.1, 0.9]
        ]
        self.metas = [
            {"name": "A", "category": "news", "views": 100, "active": True},
            {"name": "B", "category": "news", "views": 200, "active": False},
            {"name": "C", "category": "sports", "views": 50, "active": True},
            {"name": "D", "category": "sports", "views": 150, "active": True},
            {"name": "E", "category": "tech", "views": 300, "active": False}
        ]
        self.ids = self.db.store_embeddings_batch(self.vectors, self.metas)

    def test_search_accuracy(self):
        results = self.db.search([1.0, 0.0], k=3)
        names = [r[2]["name"] for r in results]
        # [1.0, 0.0] is A. [0.9, 0.1] is B. [0.5, 0.5] is D.
        self.assertEqual(names, ["A", "B", "D"]) 
        self.assertAlmostEqual(results[0][1], 1.0, places=4)

    def test_dimension_mismatch(self):
        try:
            self.db.search([1.0, 0.0, 0.0], k=1)
        except Exception:
            pass

class TestAdvancedFiltering(BaseVectorDBTest):
    def setUp(self):
        super().setUp()
        # FIX: Ensure vectors and metas have same length (5 items)
        vectors = [[0.1, 0.1]] * 5 
        metas = [
            {"id": 1, "tag": "alpha", "score": 10, "date": "2023-01-01"},
            {"id": 2, "tag": "beta", "score": 20, "date": "2023-01-02"},
            {"id": 3, "tag": "gamma", "score": 30, "date": "2023-01-03"},
            {"id": 4, "tag": "alpha", "score": 40, "date": "2023-01-04"},
            {"id": 5, "tag": "beta", "score": 50, "date": "2023-01-05"},
        ]
        self.db.store_embeddings_batch(vectors, metas)

    def _get_ids(self, query):
        results = self.db.search([0.1, 0.1], query, k=10)
        return sorted([r[2]["id"] for r in results])

    def test_deep_nested_logic(self):
        query = {
            "$and": [
                {"$or": [{"tag": "alpha"}, {"tag": "beta"}]},
                {"score": {"$gt": 30}}
            ]
        }
        self.assertEqual(self._get_ids(query), [4, 5])

    def test_not_operator(self):
        query = {"tag": {"$not": {"tag": "alpha"}}}
        self.assertEqual(self._get_ids(query), [2, 3, 5])
        
        query = {"score": {"$not": {"$gt": 25}}}
        self.assertEqual(self._get_ids(query), [1, 2])

    def test_complex_range_interaction(self):
        query = {"$and": [{"score": {"$gt": 15}}, {"score": {"$lte": 45}}]}
        self.assertEqual(self._get_ids(query), [2, 3, 4])

class TestEdgeCasesAndTypes(BaseVectorDBTest):
    def test_special_characters_and_unicode(self):
        vec = [[0.5, 0.5]]
        meta = [{"desc": "Café ☕", "code": "A B", "empty": "", "special": "|:|separator"}]
        self.db.store_embeddings_batch(vec, meta)
        
        res = self.db.search(vec[0], {"desc": "Café ☕"}, k=1)
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0][2]["desc"], "Café ☕")
        
        res = self.db.search(vec[0], {"empty": ""}, k=1)
        self.assertEqual(len(res), 1)

    def test_date_handling(self):
        vec = [[0.1, 0.1]]
        d = datetime.datetime(2023, 10, 27, 12, 0, 0)
        meta = [{"timestamp": d}]
        self.db.store_embeddings_batch(vec, meta)
        
        res = self.db.search(vec[0], {"timestamp": d}, k=1)
        self.assertEqual(len(res), 1)
        
        res_str = self.db.search(vec[0], {"timestamp": d.isoformat()}, k=1)
        self.assertEqual(len(res_str), 1)

    def test_boolean_logic(self):
        vecs = [[0.1, 0.1], [0.2, 0.2]]
        metas = [{"flag": True}, {"flag": False}]
        self.db.store_embeddings_batch(vecs, metas)
        
        res_true = self.db.search([0.1, 0.1], {"flag": True}, k=10)
        self.assertEqual(len(res_true), 1)
        self.assertEqual(res_true[0][2]["flag"], True)

class TestPersistence(BaseVectorDBTest):
    def test_restart_db(self):
        vec = [[0.5, 0.5]]
        meta = [{"session": "persistence_check"}]
        self.db.store_embeddings_batch(vec, meta)
        
        self._close_db(self.db)
        # Prevent tearDown from accessing closed/deleted db
        self.db = None 
        
        new_db = self._create_db()
        results = new_db.search([0.5, 0.5], {"session": "persistence_check"}, k=1)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0][2]["session"], "persistence_check")
        
        # Assign to self.db for tearDown cleanup
        self.db = new_db

class TestConcurrency(BaseVectorDBTest):
    def test_concurrent_reads_writes(self):
        NUM_WRITERS = 4
        NUM_READERS = 4
        ITEMS_PER_WRITER = 100
        
        def writer_func(worker_id):
            for i in range(ITEMS_PER_WRITER):
                v = np.random.rand(2).tolist()
                m = {"worker": worker_id, "seq": i, "group": "concurrent"}
                self.db.store_embeddings_batch([v], [m])
                if i % 10 == 0: time.sleep(0.001)

        def reader_func():
            count = 0
            for _ in range(20):
                res = self.db.search([0.5, 0.5], {"group": "concurrent"}, k=5)
                count += len(res)
                time.sleep(0.001)
            return count

        with ThreadPoolExecutor(max_workers=NUM_WRITERS + NUM_READERS) as executor:
            writer_futures = [executor.submit(writer_func, i) for i in range(NUM_WRITERS)]
            reader_futures = [executor.submit(reader_func) for _ in range(NUM_READERS)]
            
            for f in writer_futures:
                f.result()
            for f in reader_futures:
                f.result()
                
        # Wait a bit for async tasks if any
        time.sleep(0.5)
        
        total_expected = NUM_WRITERS * ITEMS_PER_WRITER
        final_count = self.db.count()
        results = self.db.search([0.5, 0.5], {"group": "concurrent"}, k=10000)
        
        # Debugging output if assertion fails
        if len(results) != total_expected:
            print(f"\n[TestConcurrency] FAIL: Expected {total_expected}, Got {len(results)}. Total Docs: {final_count}")
        
        self.assertEqual(len(results), total_expected)

class TestCompactionAndLifecycle(BaseVectorDBTest):
    def test_compaction_reclaims_space(self):
        vecs = np.random.rand(1000, 4).astype(np.float32).tolist()
        metas = [{"i": i, "batch": "A"} for i in range(1000)]
        self.db.store_embeddings_batch(vecs, metas)
        
        self.db.delete({"i": {"$lt": 500}}, force_flush=True)
        
        results = self.db.search(vecs[0], {"batch": "A"}, k=2000)
        self.assertEqual(len(results), 500)
        
        reclaimed = self.db.compact()
        self.assertGreaterEqual(reclaimed, 0)
        
        remaining_check = self.db.search(vecs[999], {"i": 999}, k=1)
        self.assertEqual(len(remaining_check), 1)

    def test_auto_compaction_trigger(self):
        db = self._create_db(
            path=self.test_dir + "_auto",
            shards=1,
            delete_batch_size=1,
            auto_compact=10
        )
        
        vecs = [[0.1, 0.1]] * 20
        metas = [{"n": i} for i in range(20)]
        db.store_embeddings_batch(vecs, metas)
        
        db.delete({"n": {"$lt": 15}}, force_flush=True)
        time.sleep(0.5) # Wait for BG thread
        
        res = db.search([0.1, 0.1], None, k=100)
        
        # Debug info
        if len(res) != 5:
            print(f"\n[TestAutoCompact] Expected 5, Got {len(res)}")
            ids = [r[2]['n'] for r in res]
            print(f"Remaining IDs: {sorted(ids)}")
        
        self.assertEqual(len(res), 5)
        self._close_db(db)
        shutil.rmtree(self.test_dir + "_auto")

if __name__ == "__main__":
    unittest.main()
