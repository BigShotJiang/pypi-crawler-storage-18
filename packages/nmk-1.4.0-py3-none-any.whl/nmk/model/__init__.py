"""
nmk model handling module
"""
