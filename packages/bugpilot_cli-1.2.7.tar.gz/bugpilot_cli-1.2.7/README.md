# BugPilot CLI

AI-powered penetration testing tool.

## Install

```bash
pip install bugpilot-cli
```

## Quick Start

```bash
bugpilot
```

## Supported AI Providers

- Gemini (recommended)
- Groq (fast & free)
- Anthropic Claude
- Ollama (local/offline)

## Features

- Autonomous pentesting
- Multi-agent system
- Cross-platform (Windows/Linux/Termux/macOS)
- Unrestricted command execution

## Developer

LAKSHMIKANTHAN K (letchupkt)
