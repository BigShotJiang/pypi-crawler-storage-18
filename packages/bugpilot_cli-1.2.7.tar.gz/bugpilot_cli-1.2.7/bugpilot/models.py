"""
AI Model Integration Layer
Supports: Gemini, Groq, Ollama, Anthropic
"""

import os
import warnings
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

# Suppress Google API deprecation warning
warnings.filterwarnings('ignore', category=FutureWarning, module='google.generativeai')

try:
    from google import genai
    from google.genai import types
    USING_NEW_API = True
except ImportError:
    import google.generativeai as genai
    types = None
    USING_NEW_API = False

from groq import Groq
import anthropic
import httpx


class BaseModel(ABC):
    """Base class for all AI models"""
    
    def __init__(self, api_key: Optional[str] = None, model_name: str = None, **kwargs):
        self.api_key = api_key
        self.model_name = model_name
        self.kwargs = kwargs
    
    @abstractmethod
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response from the model"""
        pass


class GeminiModel(BaseModel):
    """Google Gemini model integration"""
    
    def __init__(self, api_key: str, model_name: str = "gemini-pro", **kwargs):
        super().__init__(api_key, model_name, **kwargs)
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name)
        self.chat = None
    
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response using Gemini"""
        try:
            if context and len(context) > 0:
                # Use chat mode for context
                if not self.chat:
                    self.chat = self.model.start_chat(history=[])
                response = self.chat.send_message(prompt)
            else:
                response = self.model.generate_content(prompt)
            
            return response.text
        except Exception as e:
            error_msg = str(e).lower()
            if 'quota' in error_msg or '429' in error_msg or 'resource_exhausted' in error_msg:
                return handle_quota_exceeded("Gemini")
            elif 'api_key' in error_msg or 'authentication' in error_msg or '401' in error_msg:
                return handle_auth_error("Gemini")
            elif 'timeout' in error_msg or 'connection' in error_msg:
                return handle_connection_error("Gemini")
            else:
                return f"Gemini Error: {str(e)}\n\nTry: /configure to switch AI provider"


# Helper functions for error handling
def handle_quota_exceeded(provider: str) -> str:
    """Fallback response for quota exceeded"""
    return f"""[!] **{provider} API Quota Exceeded**

Your {provider} API quota has been exceeded or rate limit reached.

**Options:**
1. Wait a few minutes and try again
2. Switch to another AI provider: /configure
3. Use local Ollama: No API key needed

**Recommended Alternatives:**
- Groq (Fast & Free tier available)
- Ollama (Runs locally, no limits)
- Gemini (Generous free tier)

**To switch provider:**
/configure -> Select AI Provider -> Enter new API key"""

def handle_auth_error(provider: str) -> str:
    """Fallback response for authentication errors"""
    return f"""[!] **{provider} Authentication Failed**

Invalid or missing API key.

**Fix:**
1. Get API key from {provider}
2. Run: /configure
3. Select {provider}
4. Enter your API key

**Get API Keys:**
- Gemini: https://makersuite.google.com/app/apikey
- Groq: https://console.groq.com/keys
- Anthropic: https://console.anthropic.com/"""

def handle_connection_error(provider: str) -> str:
    """Fallback response for connection errors"""
    return f"""[!] **{provider} Connection Error**

Cannot connect to {provider} API.

**Possible causes:**
- No internet connection
- Firewall blocking request
- {provider} service down

**Solutions:**
1. Check internet connection
2. Try again in a moment
3. Switch to local Ollama (works offline)

Run /configure to switch providers."""


class ModelFactory:
    """Factory for creating AI model instances"""
    
    @staticmethod
    def create_model(provider: str, api_key: Optional[str] = None, model_name: str = None, **kwargs) -> BaseModel:
        """Create and return appropriate model instance"""
        
        models = {
            "gemini": (GeminiModel, "gemini-2.0-flash-exp"),
            "groq": (GroqModel, "llama-3.3-70b-versatile"),
            "ollama": (OllamaModel, "llama3.2"),
            "anthropic": (AnthropicModel, "claude-3-5-sonnet-20241022"),
        }
        
        if provider not in models:
            raise ValueError(f"Unsupported provider: {provider}. Choose: gemini, groq, ollama, anthropic")
        
        model_class, default_model = models[provider]
        model_name = model_name or default_model
        
        if provider == "ollama":
            return model_class(model_name=model_name, **kwargs)
        else:
            if not api_key:
                raise ValueError(f"API key required for {provider}")
            return model_class(api_key=api_key, model_name=model_name, **kwargs)

    
    def __init__(self, api_key: str, model_name: str = "gpt-4-turbo-preview", **kwargs):
        super().__init__(api_key, model_name, **kwargs)
        self.client = Gemini(api_key=api_key)
    
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response using Gemini"""
        try:
            messages = []
            if context:
                messages.extend(context)
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=self.kwargs.get('temperature', 0.7),
                max_tokens=self.kwargs.get('max_tokens', 4096)
            )
            
            return response.choices[0].message.content
        except Exception as e:
            error_msg = str(e).lower()
            
            # Handle specific error types
            if 'quota' in error_msg or 'rate_limit' in error_msg or 'insufficient_quota' in error_msg:
                return self._handle_quota_exceeded("Gemini")
            elif 'invalid_api_key' in error_msg or 'authentication' in error_msg:
                return self._handle_auth_error("Gemini")
            elif 'timeout' in error_msg or 'connection' in error_msg:
                return self._handle_connection_error("Gemini")
            else:
                return f"Gemini Error: {str(e)}\n\nTry: /configure to switch AI provider"
    
    def _handle_quota_exceeded(self, provider: str) -> str:
        """Fallback response for quota exceeded"""
        return f"""⚠️ **{provider} API Quota Exceeded**

Your {provider} API quota has been exceeded or rate limit reached.

**Options:**
1. Wait a few minutes and try again
2. Switch to another AI provider: `/configure`
3. Use local Ollama: No API key needed

**Recommended Alternatives:**
• Groq (Fast & Free tier available)
• Ollama (Runs locally, no limits)
• Gemini (Generous free tier)

**To switch provider:**
```
/configure
→ Select AI Provider
→ Enter new API key
```"""
    
    def _handle_auth_error(self, provider: str) -> str:
        """Fallback response for authentication errors"""
        return f"""❌ **{provider} Authentication Failed**

Invalid or missing API key.

**Fix:**
1. Get API key from {provider}
2. Run: `/configure`
3. Select {provider}
4. Enter your API key

**Get API Keys:**
• Gemini: https://platform.Gemini.com/api-keys
• Gemini: https://makersuite.google.com/app/apikey
• Groq: https://console.groq.com/keys
• Anthropic: https://console.anthropic.com/"""
    
    def _handle_connection_error(self, provider: str) -> str:
        """Fallback response for connection errors"""
        return f"""🔌 **{provider} Connection Error**

Cannot connect to {provider} API.

**Possible causes:**
• No internet connection
• Firewall blocking request
• {provider} service down

**Solutions:**
1. Check internet connection
2. Try again in a moment
3. Switch to local Ollama (works offline)

Run `/configure` to switch providers."""


class GroqModel(BaseModel):
    """Groq model integration"""
    
    def __init__(self, api_key: str, model_name: str = "mixtral-8x7b-32768", **kwargs):
        super().__init__(api_key, model_name, **kwargs)
        self.client = Groq(api_key=api_key)
    
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response using Groq"""
        try:
            messages = []
            if context:
                messages.extend(context)
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=self.kwargs.get('temperature', 0.7),
                max_tokens=self.kwargs.get('max_tokens', 4096)
            )
            
            return response.choices[0].message.content
        except Exception as e:
            error_msg = str(e).lower()
            if 'quota' in error_msg or 'rate_limit' in error_msg or '429' in error_msg:
                return handle_quota_exceeded("Groq")
            elif 'invalid_api_key' in error_msg or 'authentication' in error_msg or '401' in error_msg:
                return handle_auth_error("Groq")
            elif 'timeout' in error_msg or 'connection' in error_msg:
                return handle_connection_error("Groq")
            else:
                return f"Groq Error: {str(e)}\n\nTry: /configure to switch AI provider"


class OllamaModel(BaseModel):
    """Ollama local model integration"""
    
    def __init__(self, model_name: str = "llama2", base_url: str = "http://localhost:11434", **kwargs):
        super().__init__(None, model_name, **kwargs)
        self.base_url = base_url
    
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response using Ollama"""
        try:
            url = f"{self.base_url}/api/generate"
            
            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "stream": False
            }
            
            response = httpx.post(url, json=payload, timeout=60.0)
            response.raise_for_status()
            
            return response.json().get("response", "No response")
        except Exception as e:
            return f"Error generating response: {str(e)}"


class AnthropicModel(BaseModel):
    """Anthropic Claude model integration"""
    
    def __init__(self, api_key: str, model_name: str = "claude-3-opus-20240229", **kwargs):
        super().__init__(api_key, model_name, **kwargs)
        self.client = anthropic.Anthropic(api_key=api_key)
    
    def generate(self, prompt: str, context: List[Dict[str, str]] = None) -> str:
        """Generate response using Anthropic"""
        try:
            messages = []
            if context:
                messages.extend(context)
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.messages.create(
                model=self.model_name,
                max_tokens=self.kwargs.get('max_tokens', 4096),
                messages=messages
            )
            
            return response.content[0].text
        except Exception as e:
            error_msg = str(e).lower()
            if 'quota' in error_msg or 'rate_limit' in error_msg or '429' in error_msg:
                return handle_quota_exceeded("Anthropic Claude")
            elif 'api_key' in error_msg or 'authentication' in error_msg or '401' in error_msg:
                return handle_auth_error("Anthropic Claude")
            elif 'timeout' in error_msg or 'connection' in error_msg:
                return handle_connection_error("Anthropic Claude")
            else:
                return f"Anthropic Error: {str(e)}\n\nTry: /configure to switch AI provider"


class ModelFactory:
    """Factory for creating AI model instances"""
    
    @staticmethod
    def create_model(provider: str, api_key: Optional[str] = None, model_name: str = None, **kwargs) -> BaseModel:
        """Create and return appropriate model instance"""
        
        models = {
            "gemini": (GeminiModel, "gemini-2.0-flash-exp"),
            "groq": (GroqModel, "llama-3.3-70b-versatile"),
            "ollama": (OllamaModel, "llama3.2"),
            "anthropic": (AnthropicModel, "claude-3-5-sonnet-20241022"),
        }
        
        if provider not in models:
            raise ValueError(f"Unsupported provider: {provider}")
        
        model_class, default_model = models[provider]
        model_name = model_name or default_model
        
        if provider == "ollama":
            return model_class(model_name=model_name, **kwargs)
        else:
            if not api_key:
                raise ValueError(f"API key required for {provider}")
            return model_class(api_key=api_key, model_name=model_name, **kwargs)

