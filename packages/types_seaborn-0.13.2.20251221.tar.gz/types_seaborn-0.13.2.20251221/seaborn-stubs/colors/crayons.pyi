crayons: dict[str, str]
