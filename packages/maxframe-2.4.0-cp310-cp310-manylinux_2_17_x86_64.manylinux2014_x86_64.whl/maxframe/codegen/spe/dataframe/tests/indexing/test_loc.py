# Copyright 1999-2025 Alibaba Group Holding Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ....core import SPECodeContext
from ...indexing import DataFrameLocGetItemAdapter, DataFrameLocSetItemAdapter


def test_dataframe_iloc_only_columns(df1):
    df = df1.iloc[:, [0, 1]]
    context = SPECodeContext()
    results = DataFrameLocGetItemAdapter().generate_code(df.op, context)
    expected_results = ["var_1 = var_0.loc[slice(None, None, None), [0, 1]]"]
    assert results == expected_results


def test_dataframe_iloc_set_only_column(df1):
    df1.iloc[:, 0] = 5
    context = SPECodeContext()
    results = DataFrameLocSetItemAdapter().generate_code(df1.op, context)
    expected_results = [
        "var_1 = var_0.copy()",
        "var_1.loc[slice(None, None, None), 0] = 5",
    ]
    assert results == expected_results
