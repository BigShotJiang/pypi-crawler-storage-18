# Copyright 1999-2025 Alibaba Group Holding Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .core import SeriesStringMethod, string_method_to_handlers

methods = set(string_method_to_handlers.keys())
del string_method_to_handlers


def _install():
    from ....core import CachedAccessor
    from ...core import SERIES_TYPE
    from .accessor import StringAccessor
    from .core import string_method_to_handlers

    for method in string_method_to_handlers:
        if not hasattr(StringAccessor, method):
            StringAccessor._register(method)

    for series in SERIES_TYPE:
        series.str = CachedAccessor("str", StringAccessor)


_install()
del _install
