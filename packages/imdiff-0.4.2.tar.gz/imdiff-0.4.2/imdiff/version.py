__version__ = '0.4.2'
version_info = __version__.split('.')
