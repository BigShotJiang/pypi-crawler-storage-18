from __future__ import annotations

import os
from typing import Optional


def getenv_any(keys: list[str], default: Optional[str] = None) -> Optional[str]:
    for k in keys:
        v = os.getenv(k)
        if v:
            return v
    return default


def normalize_whitespace(text: str) -> str:
    return " ".join(text.strip().split())


def is_local_dir(path: str) -> bool:
    return os.path.isdir(path)
