from __future__ import annotations


def build_prompt(candidate_report: str, reference_report: str) -> str:
    # 注意：你如果已经有更严格的 instruction，就把这段替换成你的版本即可
    return (
        'instruction: "Evaluate the accuracy of a candidate radiology report in comparison to a reference radiology report composed by expert radiologists. '
        "You should determine the following aspects and return the result as a JSON object with EXACTLY these keys:\n"
        '{'
        '"entity_name false_prediction": <int>, '
        '"entity_name false_prediction_explanation": <string>, '
        '"entity_name omission": <int>, '
        '"entity_name omission_explanation": <string>, '
        '"location false_prediction": <int>, '
        '"location false_prediction_explanation": <string>, '
        '"location omission": <int>, '
        '"location omission_explanation": <string>, '
        '"severity false_prediction": <int>, '
        '"severity false_prediction_explanation": <string>, '
        '"severity omission": <int>, '
        '"severity omission_explanation": <string>, '
        '"uncertainty false_prediction": <int>, '
        '"uncertainty false_prediction_explanation": <string>, '
        '"uncertainty omission": <int>, '
        '"uncertainty omission_explanation": <string>, '
        '"completeness_score": <float>, '
        '"completeness_reason": <string>, '
        '"readability_score": <float>, '
        '"readability_reason": <string>, '
        '"clinical_utility_score": <float>, '
        '"clinical_utility_reason": <string>, '
        '"weighted_final_score": <float>'
        "}\n"
        'Return ONLY the JSON object, no extra text."\n\n'
        f'input: "candidate radiology report: {candidate_report} '
        f'reference radiology report: {reference_report}"'
    )
