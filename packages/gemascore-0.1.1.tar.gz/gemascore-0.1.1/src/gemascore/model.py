# src/gemascore/model.py
from __future__ import annotations

import os
from typing import Optional, Tuple

import torch
from huggingface_hub import snapshot_download
from transformers import AutoProcessor

# transformers 兼容处理
try:
    from transformers import AutoModelForImageTextToText
    MODEL_CLASS = AutoModelForImageTextToText
except ImportError:
    from transformers import AutoModelForVision2Seq
    MODEL_CLASS = AutoModelForVision2Seq


# =========================
# 默认模型仓库
# =========================
DEFAULT_REPO_ID = "Gemascore/GEMA-Score-distilled"
DEFAULT_MODEL_KEY = "ct-qwen"

# =========================
# 允许下载的文件（关键！）
# =========================
ALLOW_PATTERNS = [
    "*/model.safetensors",
    "*/config.json",
    "*/generation_config.json",
    "*/processor_config.json",
    "*/tokenizer.json",
    "*/tokenizer_config.json",
    "*/special_tokens_map.json",
    "*/chat_template.jinja",
]


def resolve_model_dir(
    *,
    model_path: Optional[str],
    cache_dir: Optional[str],
    repo_id: str,
    subfolder: str,
    token: Optional[str],
) -> str:
    """
    返回最终可用于 from_pretrained 的本地模型目录
    """
    # ✅ 用户显式给了本地模型路径
    if model_path:
        if not os.path.isdir(model_path):
            raise FileNotFoundError(f"model_path not found: {model_path}")
        return model_path

    # ✅ 否则从 HuggingFace 下载（只下载必要文件）
    snapshot_root = snapshot_download(
        repo_id=repo_id,
        allow_patterns=ALLOW_PATTERNS,
        cache_dir=cache_dir,          # 不 mkdir，交给 HF
        token=token,
        resume_download=True,
    )

    model_dir = os.path.join(snapshot_root, subfolder)
    if not os.path.isdir(model_dir):
        raise FileNotFoundError(
            f"Subfolder '{subfolder}' not found in repo '{repo_id}'"
        )

    return model_dir


def load_model_and_processor(
    *,
    model_dir: str,
    device: str = "auto",
    dtype: Optional[str] = None,
) -> Tuple[torch.nn.Module, AutoProcessor]:

    # dtype 解析
    torch_dtype = None
    if dtype == "fp16":
        torch_dtype = torch.float16
    elif dtype == "bf16":
        torch_dtype = torch.bfloat16
    elif dtype == "fp32":
        torch_dtype = torch.float32

    processor = AutoProcessor.from_pretrained(
        model_dir,
        trust_remote_code=True,
    )

    model = MODEL_CLASS.from_pretrained(
        model_dir,
        device_map=device,
        torch_dtype=torch_dtype,
        trust_remote_code=True,
    )

    model.eval()
    return model, processor
