# src/gemascore/registry.py

MODEL_REGISTRY = {
    "ct-qwen": {
        "repo_id": "Gemascore/GEMA-Score-distilled",
        "subfolder": "GEMA-Score-distilled-CT-Qwen",
    },
    "ct-llama": {
        "repo_id": "Gemascore/GEMA-Score-distilled",
        "subfolder": "GEMA-Score-distilled-CT-llama",
    },
    "xray-qwen": {
        "repo_id": "Gemascore/GEMA-Score-distilled",
        "subfolder": "GEMA-Score-distilled-Xray-Qwen",
    },
    "xray-llama": {
        "repo_id": "Gemascore/GEMA-Score-distilled",
        "subfolder": "GEMA-Score-distilled-Xray-llama",
    },
}


def resolve_model_choice(model: str):
    if model not in MODEL_REGISTRY:
        raise ValueError(
            f"Unknown model '{model}'. "
            f"Available: {list(MODEL_REGISTRY.keys())}"
        )
    return MODEL_REGISTRY[model]
