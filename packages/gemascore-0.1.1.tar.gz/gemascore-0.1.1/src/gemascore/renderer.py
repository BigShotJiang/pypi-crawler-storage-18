from __future__ import annotations

from typing import Any, Dict


def _safe_get(d: Dict[str, Any], k: str, default: str = "") -> Any:
    return d.get(k, default)


def render_full_evaluation(d: Dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("📌 Error Analysis")
    lines.append("=" * 70)

    def block(title: str, prefix: str):
        fp = _safe_get(d, f"{prefix} false_prediction", 0)
        fp_exp = _safe_get(d, f"{prefix} false_prediction_explanation", "")
        om = _safe_get(d, f"{prefix} omission", 0)
        om_exp = _safe_get(d, f"{prefix} omission_explanation", "")

        lines.append(f"\n◆ {title}")
        lines.append(f"• False prediction : {fp}")
        if str(fp_exp).strip():
            lines.append(f"  ↳ {fp_exp}")
        lines.append(f"• Omission         : {om}")
        if str(om_exp).strip():
            lines.append(f"  ↳ {om_exp}")

    block("Entity Name", "entity_name")
    block("Location", "location")
    block("Severity", "severity")
    block("Uncertainty", "uncertainty")

    lines.append("\n📊 Quality Scores")
    lines.append("=" * 70)

    comp = _safe_get(d, "completeness_score", "")
    comp_r = _safe_get(d, "completeness_reason", "")
    read = _safe_get(d, "readability_score", "")
    read_r = _safe_get(d, "readability_reason", "")
    clin = _safe_get(d, "clinical_utility_score", "")
    clin_r = _safe_get(d, "clinical_utility_reason", "")
    final = _safe_get(d, "weighted_final_score", "")

    lines.append(f"\n◆ Completeness\n• Score  : {comp}\n• Reason : {comp_r}")
    lines.append(f"\n◆ Readability\n• Score  : {read}\n• Reason : {read_r}")
    lines.append(f"\n◆ Clinical Utility\n• Score  : {clin}\n• Reason : {clin_r}")
    lines.append(f"\n◆ Weighted Final\n• Score  : {final}")

    return "\n".join(lines)
