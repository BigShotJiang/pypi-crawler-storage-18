# src/gemascore/parser.py
from __future__ import annotations

import json
from typing import Any, Dict


class GemaScoreParseError(RuntimeError):
    """Raised when GEMA-Score JSON cannot be extracted."""


OUTPUT_ANCHOR = "output:"


def extract_json_from_output(text: str) -> Dict[str, Any]:
    """
    Extract JSON object following `output:` from model output.

    Uses JSONDecoder.raw_decode to tolerate trailing text after JSON.
    """

    if not text:
        raise GemaScoreParseError(
            "[gemascore] ERROR: Empty model output."
        )

    anchor_pos = text.find(OUTPUT_ANCHOR)
    if anchor_pos == -1:
        raise GemaScoreParseError(
            "[gemascore] ERROR: `output:` anchor not found in model output.\n\n"
            f"Raw output:\n{text}"
        )

    after_anchor = text[anchor_pos + len(OUTPUT_ANCHOR):].lstrip()

    # Find the first opening brace
    brace_pos = after_anchor.find("{")
    if brace_pos == -1:
        raise GemaScoreParseError(
            "[gemascore] ERROR: No opening '{' found after `output:`.\n\n"
            f"Text after anchor:\n{after_anchor[:1000]}"
        )

    json_candidate = after_anchor[brace_pos:]

    decoder = json.JSONDecoder()
    try:
        obj, end = decoder.raw_decode(json_candidate)
        return obj
    except json.JSONDecodeError as e:
        raise GemaScoreParseError(
            "[gemascore] ERROR: Failed to parse JSON after `output:`.\n\n"
            f"JSON candidate (first 1500 chars):\n{json_candidate[:1500]}\n\n"
            f"Original error: {e}"
        ) from e
