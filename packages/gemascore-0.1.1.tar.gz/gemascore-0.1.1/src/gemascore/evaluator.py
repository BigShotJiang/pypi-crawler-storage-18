# src/gemascore/evaluator.py
from __future__ import annotations

from typing import Any, Dict, Optional

import torch

from .model import (
    resolve_model_dir,
    load_model_and_processor,
    DEFAULT_REPO_ID,
)
from .registry import resolve_model_choice
from .prompt import build_prompt
from .parser import extract_json_from_output
from .renderer import render_full_evaluation


# ============================================================
# Core API: return structured JSON
# ============================================================
def evaluate_report_json(
    *,
    candidate_report: str,
    reference_report: str,
    model: str = "ct-qwen",
    model_path: Optional[str] = None,
    cache_dir: Optional[str] = None,
    repo_id: Optional[str] = None,
    subfolder: Optional[str] = None,
    token: Optional[str] = None,
    device: str = "auto",
    dtype: Optional[str] = None,
    max_new_tokens: int = 2048,
    repetition_penalty: float = 1.2,
) -> Dict[str, Any]:
    """
    Run GEMA-Score evaluation and return raw JSON dict.

    Parameters
    ----------
    candidate_report : str
    reference_report : str
    model : str
        One of: ct-qwen (default), ct-llama, xray-qwen, xray-llama
    model_path : str, optional
        Local directory containing model files (skip HF download)
    cache_dir : str, optional
        HuggingFace cache directory (must be writable)
    repo_id : str, optional
        Override HF repo id (advanced use)
    subfolder : str, optional
        Override HF subfolder (advanced use)
    token : str, optional
        HF token (or via HF_TOKEN env)
    device : str
        auto / cuda / cpu / cuda:0 ...
    dtype : str, optional
        fp16 / bf16 / fp32
    """

    # ------------------------------------------------------------
    # 1. Resolve model selection
    # ------------------------------------------------------------
    if model_path is None:
        model_cfg = resolve_model_choice(model)
        repo_id = repo_id or model_cfg["repo_id"]
        subfolder = subfolder or model_cfg["subfolder"]
    else:
        # Local path explicitly provided
        repo_id = repo_id or DEFAULT_REPO_ID
        subfolder = subfolder or ""

    # ------------------------------------------------------------
    # 2. Resolve local model directory
    # ------------------------------------------------------------
    model_dir = resolve_model_dir(
        model_path=model_path,
        cache_dir=cache_dir,
        repo_id=repo_id,
        subfolder=subfolder,
        token=token,
    )

    # ------------------------------------------------------------
    # 3. Load model + processor
    # ------------------------------------------------------------
    model_obj, processor = load_model_and_processor(
        model_dir=model_dir,
        device=device,
        dtype=dtype,
    )

    # ------------------------------------------------------------
    # 4. Build prompt
    # ------------------------------------------------------------
    prompt = build_prompt(
        candidate_report=candidate_report,
        reference_report=reference_report,
    )

    # ------------------------------------------------------------
    # 5. Inference
    # ------------------------------------------------------------
    inputs = processor(
        text=prompt,
        return_tensors="pt",
    )

    # move to device safely
    inputs = {k: v.to(model_obj.device) for k, v in inputs.items()}

    with torch.no_grad():
        output_ids = model_obj.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            repetition_penalty=repetition_penalty,
        )

    output_text = processor.batch_decode(
        output_ids,
        skip_special_tokens=True,
    )[0]

    # ------------------------------------------------------------
    # 6. Parse JSON
    # ------------------------------------------------------------
    return extract_json_from_output(output_text)


# ============================================================
# User-facing API: pretty text output
# ============================================================
def evaluate_report(
    *,
    candidate_report: str,
    reference_report: str,
    model: str = "ct-qwen",
    model_path: Optional[str] = None,
    cache_dir: Optional[str] = None,
    repo_id: Optional[str] = None,
    subfolder: Optional[str] = None,
    token: Optional[str] = None,
    device: str = "auto",
    dtype: Optional[str] = None,
    max_new_tokens: int = 2048,
    repetition_penalty: float = 1.2,
) -> str:
    """
    Run GEMA-Score evaluation and return formatted human-readable text.
    """

    data = evaluate_report_json(
        candidate_report=candidate_report,
        reference_report=reference_report,
        model=model,
        model_path=model_path,
        cache_dir=cache_dir,
        repo_id=repo_id,
        subfolder=subfolder,
        token=token,
        device=device,
        dtype=dtype,
        max_new_tokens=max_new_tokens,
        repetition_penalty=repetition_penalty,
    )

    return render_full_evaluation(data)
