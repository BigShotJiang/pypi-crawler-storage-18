# src/gemascore/__init__.py

__version__ = "0.1.1"

from .evaluator import evaluate_report, evaluate_report_json

__all__ = [
    "evaluate_report",
    "evaluate_report_json",
    "__version__",
]
