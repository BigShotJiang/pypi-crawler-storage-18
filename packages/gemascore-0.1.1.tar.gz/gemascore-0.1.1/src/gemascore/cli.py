from __future__ import annotations

import argparse
import os
import sys
from typing import Optional

from .evaluator import evaluate_report
from .utils import normalize_whitespace


def _read_maybe_file(s: str) -> str:
    # 如果是一个存在的文件路径，就读取；否则当作文本
    if os.path.isfile(s):
        with open(s, "r", encoding="utf-8") as f:
            return f.read()
    return s


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(prog="gemascore", description="GEMA-Score: radiology report evaluation")
    parser.add_argument("--candidate", required=True, help="Candidate report text OR path to a .txt file")
    parser.add_argument("--reference", required=True, help="Reference report text OR path to a .txt file")

    parser.add_argument("--model-path", default=None, help="Local model directory (contains model.safetensors etc.)")
    parser.add_argument("--cache-dir", default=None, help="Where to download/cache model weights (optional)")
    parser.add_argument("--repo-id", default="Gemascore/GEMA-Score-distilled", help="HF repo id (default: GEMA-Score)")
    parser.add_argument("--subfolder", default="GEMA-Score-distilled-CT-Qwen", help="HF subfolder (default: CT-Qwen)")
    parser.add_argument("--token", default=None, help="HF token (or set HF_TOKEN env var)")

    parser.add_argument("--device", default="auto", help="device_map for transformers (auto/cuda/cpu/...)")
    parser.add_argument("--dtype", default=None, help="fp16/bf16/fp32 (optional)")
    parser.add_argument("--max-new-tokens", type=int, default=2048)
    parser.add_argument("--repetition-penalty", type=float, default=1.2)

    args = parser.parse_args(argv)

    candidate = normalize_whitespace(_read_maybe_file(args.candidate))
    reference = normalize_whitespace(_read_maybe_file(args.reference))

    try:
        out = evaluate_report(
            candidate_report=candidate,
            reference_report=reference,
            model_path=args.model_path,
            cache_dir=args.cache_dir,
            repo_id=args.repo_id,
            subfolder=args.subfolder,
            token=args.token,
            device=args.device,
            dtype=args.dtype,
            max_new_tokens=args.max_new_tokens,
            repetition_penalty=args.repetition_penalty,
        )
        print(out)
    except Exception as e:
        print(f"[gemascore] ERROR: {e}", file=sys.stderr)
        sys.exit(1)
