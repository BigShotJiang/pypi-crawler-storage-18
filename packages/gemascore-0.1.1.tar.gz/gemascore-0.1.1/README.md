# gemascore

Evaluate a candidate radiology report against a reference report using a Hugging Face hosted (or locally cached) GEMA-Score distilled model.

## Install
```bash
pip install gemascore
```

## Python usage
```bash
from gemascore import evaluate_report

candidate = "no pneumothorax. mediastinal contours normal. patchy right nodular mid lung zone opacity."
reference = "no pneumothorax. mediastinum upper limits of normal in size. patchy bilateral ground-glass opacities, consolidation, or edema."

text = evaluate_report(
    candidate_report=candidate,
    reference_report=reference,
    model="ct-qwen",  # ct-qwen / ct-llama / xray-qwen / xray-llama
    cache_dir="/data/hf_cache",  # user path like model_path="/data/models/GEMA-Score-distilled-CT-Qwen"
)
print(text)
```
## CLI usage
```bash
gemascore \
  --candidate "no pneumothorax..." \
  --reference "no pneumothorax..." \
  --cache-dir /data/hf_cache # user path
```
## Notes
First run may download several GB of model weights.
If you already have a local checkpoint folder containing model.safetensors, pass --model-path instead.