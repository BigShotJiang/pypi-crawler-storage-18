from buptmw import BUPT_Auth, CAS_Credential

auth: CAS_Credential = {
    "username": "yourUsername",
    "password": "yourPassword"
}
user = BUPT_Auth(cas=auth)
