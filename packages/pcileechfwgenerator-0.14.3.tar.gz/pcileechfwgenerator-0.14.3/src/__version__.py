#!/usr/bin/env python3
"""Version information for PCILeech Firmware Generator."""

__version__ = "0.14.3"
__version_info__ = (0, 14, 2, "beta", 2)

# Release information
__title__ = "PCILeech Firmware Generator"
__description__ = "Generate spoofed PCIe DMA firmware from real donor hardware"
__author__ = "Ramsey McGrath"
__author_email__ = "ramsey@voltcyclone.info"
__license__ = "MIT"
__url__ = "https://github.com/voltcyclone/PCILeechFWGenerator"

# Build metadata
__build_date__ = "2025-11-08T04:45:09.947080"
__commit_hash__ = "c54f201"
