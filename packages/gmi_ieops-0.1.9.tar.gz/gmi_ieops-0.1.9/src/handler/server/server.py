from abc import ABC, abstractmethod

class BaseServer(ABC):
    @abstractmethod
    def shutdown(self) -> None:
        """request server graceful shutdown"""
    @abstractmethod
    async def serve(self) -> None:
        """serve the server"""