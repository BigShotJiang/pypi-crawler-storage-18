"""Tests for magpy controllers."""
