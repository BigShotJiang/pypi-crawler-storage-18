"""Tests for MagPy."""
