#!/usr/bin/env python3
"""
UCUP Command Line Interface

Provides CLI commands for UCUP framework operations including TOON format
conversion, testing, and token optimization tools.

Copyright (c) 2025 UCUP Framework Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Any, Optional

from .toon.toon_formatter import ToonFormatter, ToonSchema
from .config import load_ucup_config
from .validation import validate_data
from .metrics import record_build_metrics, show_build_benefits


class UCUPCLI:
    """UCUP Command Line Interface with TOON integration."""

    def __init__(self):
        self.toon_formatter = ToonFormatter()
        self.config = load_ucup_config()
        self._load_toon_config()

    def _load_toon_config(self):
        """Load TOON-specific configuration."""
        # Load custom schemas from config if available
        toon_config = self.config.get('toon', {})
        custom_schemas = toon_config.get('schemas', {})

        for schema_name, schema_config in custom_schemas.items():
            if schema_name not in self.toon_formatter.schemas:
                # Create schema from config
                from .toon.toon_formatter import ToonSchema
                schema = ToonSchema(**schema_config)
                self.toon_formatter.schemas[schema_name] = schema

    def run(self):
        """Main CLI entry point."""
        parser = argparse.ArgumentParser(
            description="UCUP Framework CLI - Token-efficient AI testing and validation",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  # Convert JSON to TOON for cost savings
  ucup toon convert data.json --output data.toon

  # Compare token usage between formats
  ucup toon compare data.json

  # Create custom schema for repeated data
  ucup toon schema create user_data_schema sample_data.json

  # Validate data with UCUP
  ucup validate data.json --schema user_schema

  # Show token savings report
  ucup toon report

  # Support UCUP development - multiple options available
  ucup donate show --platform paypal    # PayPal donation
  ucup donate show --platform github    # GitHub Sponsors
  ucup donate show --platform ko-fi     # Ko-fi donation
  ucup donate show                      # All donation options

  # Show sponsorship information
  ucup donate sponsor

Support UCUP: 💳 @ucup.ai.2025 (PayPal) - Multiple platforms available
            """
        )

        subparsers = parser.add_subparsers(dest='command', help='Available commands')

        # TOON commands
        toon_parser = subparsers.add_parser('toon', help='TOON format operations')
        toon_subparsers = toon_parser.add_subparsers(dest='toon_command')

        # TOON convert
        convert_parser = toon_subparsers.add_parser('convert', help='Convert data to TOON format')
        convert_parser.add_argument('input', help='Input file (JSON) or - for stdin')
        convert_parser.add_argument('--output', '-o', help='Output file (default: stdout)')
        convert_parser.add_argument('--schema', help='Schema name to use for optimization')
        convert_parser.add_argument('--format', choices=['toon', 'json', 'auto'], default='toon',
                                   help='Output format (default: toon)')
        convert_parser.add_argument('--compare', action='store_true',
                                   help='Show comparison with JSON format')

        # TOON compare
        compare_parser = toon_subparsers.add_parser('compare', help='Compare JSON vs TOON token usage')
        compare_parser.add_argument('input', help='Input file (JSON) or - for stdin')
        compare_parser.add_argument('--schema', help='Schema name to use')
        compare_parser.add_argument('--detailed', action='store_true',
                                   help='Show detailed comparison metrics')

        # TOON schema
        schema_parser = toon_subparsers.add_parser('schema', help='Schema management')
        schema_subparsers = schema_parser.add_subparsers(dest='schema_command')

        schema_create = schema_subparsers.add_parser('create', help='Create schema from sample data')
        schema_create.add_argument('name', help='Schema name')
        schema_create.add_argument('sample_file', help='Sample data file')
        schema_create.add_argument('--description', help='Schema description')

        schema_list = schema_subparsers.add_parser('list', help='List available schemas')

        # TOON report
        report_parser = toon_subparsers.add_parser('report', help='Token savings report')
        report_parser.add_argument('--limit', type=int, default=10,
                                  help='Number of recent conversions to analyze')

        # Validate command
        validate_parser = subparsers.add_parser('validate', help='Validate data with UCUP')
        validate_parser.add_argument('input', help='Input data file')
        validate_parser.add_argument('--schema', help='Validation schema')
        validate_parser.add_argument('--output', '-o', help='Output validation report file')

        # Config command
        config_parser = subparsers.add_parser('config', help='Configuration management')
        config_parser.add_argument('--show', action='store_true', help='Show current configuration')
        config_parser.add_argument('--init', action='store_true', help='Initialize default configuration')

        # Donation commands
        donate_parser = subparsers.add_parser('donate', help='Donation and sponsorship management')
        donate_subparsers = donate_parser.add_subparsers(dest='donate_command')

        donate_show = donate_subparsers.add_parser('show', help='Show donation page')
        donate_show.add_argument('--platform', help='Specific platform to show')

        donate_stats = donate_subparsers.add_parser('stats', help='Show donation statistics')

        donate_link = donate_subparsers.add_parser('link', help='Create donation link')
        donate_link.add_argument('platform', help='Donation platform')
        donate_link.add_argument('--amount', type=float, help='Donation amount')
        donate_link.add_argument('--currency', default='USD', help='Currency code')

        donate_sponsor = donate_subparsers.add_parser('sponsor', help='Show sponsorship information')

        # Version
        parser.add_argument('--version', action='version', version=f'UCUP {self.get_version()}')

        args = parser.parse_args()

        if not args.command:
            parser.print_help()
            return

        # Execute command
        try:
            getattr(self, f'cmd_{args.command}')(args)
        except AttributeError:
            print(f"Unknown command: {args.command}")
            parser.print_help()
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    def cmd_toon(self, args):
        """Handle TOON subcommands."""
        if not hasattr(args, 'toon_command') or not args.toon_command:
            print("Use 'ucup toon --help' for TOON commands")
            return

        method_name = f'cmd_toon_{args.toon_command}'
        if hasattr(self, method_name):
            getattr(self, method_name)(args)
        else:
            print(f"Unknown TOON command: {args.toon_command}")

    def cmd_toon_convert(self, args):
        """Convert data to TOON format."""
        # Load input data
        data = self._load_input_data(args.input)

        # Convert using formatter
        result = self.toon_formatter.format_with_choice(
            data,
            preferred_format=args.format,
            schema_name=args.schema,
            show_comparison=args.compare
        )

        # Output result
        output = result.toon_output if result.format_choice == 'toon' else result.json_output

        if args.output:
            with open(args.output, 'w') as f:
                f.write(output)
            print(f"Converted data saved to {args.output}")
        else:
            print(output)

        # Show metrics if requested
        if args.compare:
            self._show_conversion_metrics(result)

    def cmd_toon_compare(self, args):
        """Compare JSON vs TOON token usage."""
        data = self._load_input_data(args.input)

        result = self.toon_formatter.json_to_toon(data, schema_name=args.schema)

        print("=== TOKEN USAGE COMPARISON ===")
        print(f"JSON Tokens: {result.metrics.json_tokens}")
        print(f"TOON Tokens: {result.metrics.toon_tokens}")
        print(f"Savings: {result.metrics.savings_percentage:.1f}%")
        print(f"Compression Ratio: {result.metrics.compression_ratio:.2f}x")
        print(f"Est. Cost Savings: ${result.metrics.estimated_cost_savings:.4f}")

        if args.detailed:
            print("\n=== RECOMMENDATIONS ===")
            for rec in result.recommendations:
                print(f"• {rec}")

            print(f"\nConversion Time: {result.conversion_time:.3f}s")

    def cmd_toon_schema(self, args):
        """Handle schema subcommands."""
        if not hasattr(args, 'schema_command') or not args.schema_command:
            print("Use 'ucup toon schema --help' for schema commands")
            return

        method_name = f'cmd_toon_schema_{args.schema_command}'
        if hasattr(self, method_name):
            getattr(self, method_name)(args)

    def cmd_toon_schema_create(self, args):
        """Create a new TOON schema."""
        data = self._load_input_data(args.sample_file)

        schema = self.toon_formatter.create_custom_schema(
            args.name,
            data,
            args.description or f"Custom schema for {args.name}"
        )

        print(f"✅ Created schema '{args.name}'")
        print(f"Fields: {len(schema.fields)}")
        print(f"Array Fields: {len(schema.array_fields)}")
        print(f"Optimizations: {', '.join(schema.optimizations)}")

    def cmd_toon_schema_list(self, args):
        """List available TOON schemas."""
        print("=== AVAILABLE TOON SCHEMAS ===")
        for name, schema in self.toon_formatter.schemas.items():
            print(f"\n📋 {name}")
            print(f"   Description: {schema.description}")
            print(f"   Fields: {len(schema.fields)}")
            print(f"   Optimizations: {', '.join(schema.optimizations) if schema.optimizations else 'None'}")

    def cmd_toon_report(self, args):
        """Show token savings report."""
        report = self.toon_formatter.get_token_savings_report(args.limit)

        if "message" in report:
            print(report["message"])
            return

        print("=== TOKEN SAVINGS REPORT ===")
        print(f"Recent Conversions: {report['total_conversions']}")
        print(f"Average Savings: {report['average_savings_percentage']:.1f}%")
        print(f"Total Token Savings: {report['total_token_savings']}")

        if report['best_conversion']['schema_used']:
            print(f"Best Schema: {report['best_conversion']['schema_used']}")

        print("\n💡 RECOMMENDATIONS:")
        for rec in report['recommendations']:
            print(f"• {rec}")

        # Add donation prompt for significant savings
        if report['average_savings_percentage'] > 30:
            print("\n" + "="*50)
            print("🎉 Impressive savings! Support UCUP development:")
            print("   💳 PayPal: ucup donate show --platform paypal")
            print("   🐙 GitHub Sponsors: ucup donate show --platform github")
            print("   ☕ Ko-fi: ucup donate show --platform ko-fi")
            print("   🏛️ Open Collective: ucup donate show --platform opencollective")
            print("   📋 All options: ucup donate show")
            print("="*50)

    def cmd_validate(self, args):
        """Validate data with UCUP."""
        data = self._load_input_data(args.input)

        try:
            report = validate_data(data, schema_name=args.schema)

            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(report.to_dict(), f, indent=2)
                print(f"Validation report saved to {args.output}")
            else:
                print("=== VALIDATION REPORT ===")
                print(f"Status: {'✅ PASSED' if report.is_valid else '❌ FAILED'}")
                if report.errors:
                    print("Errors:")
                    for error in report.errors:
                        print(f"  • {error}")
                if report.warnings:
                    print("Warnings:")
                    for warning in report.warnings:
                        print(f"  • {warning}")

        except Exception as e:
            print(f"Validation error: {e}", file=sys.stderr)
            sys.exit(1)

    def cmd_config(self, args):
        """Handle configuration commands."""
        if args.show:
            print("=== UCUP CONFIGURATION ===")
            print(json.dumps(self.config, indent=2))
        elif args.init:
            print("Configuration initialization not yet implemented")
        else:
            print("Use 'ucup config --help' for config commands")

    def cmd_donate(self, args):
        """Handle donation subcommands."""
        if not hasattr(args, 'donate_command') or not args.donate_command:
            print("Use 'ucup donate --help' for donation commands")
            return

        # Initialize donation plugin
        try:
            from .plugins.donation_plugin import DonationPlugin
            donation_plugin = DonationPlugin()
            donation_plugin.initialize()
        except Exception as e:
            print(f"Failed to initialize donation plugin: {e}")
            return

        method_name = f'cmd_donate_{args.donate_command}'
        if hasattr(self, method_name):
            getattr(self, method_name)(args, donation_plugin)
        else:
            print(f"Unknown donation command: {args.donate_command}")

    def cmd_donate_show(self, args, donation_plugin):
        """Show donation page."""
        page = donation_plugin.execute("show_donate_page", platform=getattr(args, 'platform', None))
        print(page)

    def cmd_donate_stats(self, args, donation_plugin):
        """Show donation statistics."""
        stats = donation_plugin.execute("get_donation_stats")
        print("=== DONATION STATISTICS ===")
        print(f"Total Donations: {stats['total_donations']}")
        print(f"Total Amount: ${stats['total_amount']:.2f}")
        print(f"Monthly Donations: {stats['monthly_donations']}")
        print(f"Monthly Amount: ${stats['monthly_amount']:.2f}")
        print(f"Recent Donations (30 days): {stats['recent_donations']}")

        if stats['top_platforms']:
            print("\nTop Platforms:")
            for platform in stats['top_platforms']:
                print(f"  {platform['platform']}: ${platform['amount']:.2f} ({platform['count']} donations)")

    def cmd_donate_link(self, args, donation_plugin):
        """Create donation link."""
        try:
            link = donation_plugin.execute("create_donation_link",
                                         platform=args.platform,
                                         amount=getattr(args, 'amount', None),
                                         currency=getattr(args, 'currency', 'USD'))
            print(f"Donation link: {link}")
        except Exception as e:
            print(f"Error creating donation link: {e}")

    def cmd_donate_sponsor(self, args, donation_plugin):
        """Show sponsorship information."""
        sponsorship_info = donation_plugin.execute("show_sponsorship_call")
        print(sponsorship_info)

    def _load_input_data(self, input_path: str) -> Any:
        """Load data from file or stdin."""
        if input_path == '-':
            return json.load(sys.stdin)
        else:
            with open(input_path, 'r') as f:
                return json.load(f)

    def _show_conversion_metrics(self, result: 'ToonConversionResult'):
        """Display conversion metrics."""
        print("\n=== CONVERSION METRICS ===", file=sys.stderr)
        print(f"Format Chosen: {result.format_choice.upper()}", file=sys.stderr)
        print(f"JSON Tokens: {result.metrics.json_tokens}", file=sys.stderr)
        print(f"TOON Tokens: {result.metrics.toon_tokens}", file=sys.stderr)
        print(f"Savings: {result.metrics.savings_percentage:.1f}%", file=sys.stderr)
        print(f"Cost Savings: ${result.metrics.estimated_cost_savings:.4f}", file=sys.stderr)
        print(f"Conversion Time: {result.conversion_time:.3f}s", file=sys.stderr)

    def get_version(self) -> str:
        """Get UCUP version."""
        try:
            from importlib.metadata import version
            return version('ucup')
        except:
            return "0.2.0"


def main():
    """CLI entry point."""
    cli = UCUPCLI()
    cli.run()


if __name__ == '__main__':
    main()
