from setuptools import setup, find_packages

setup(
    name="59chat",
    version="0.1.1",
    author="YourName",
    description="59-second zero-trace terminal chat",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/59chat",
    packages=find_packages(),
    py_modules=["main"],
    install_requires=[
        "textual>=0.45.0",
        "supabase>=2.3.0",
        "python-dotenv>=1.0.0",
        "pyperclip>=1.8.2",
    ],
    entry_points={
        "console_scripts": [
            "59chat=main:main_func",
        ],
    },
    python_requires=">=3.10",
)
