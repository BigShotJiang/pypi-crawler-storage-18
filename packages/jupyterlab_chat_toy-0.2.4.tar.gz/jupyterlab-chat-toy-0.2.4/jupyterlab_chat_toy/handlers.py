"""API处理器定义 - 适配 OpenAI 兼容 API"""
import json
import traceback
from datetime import datetime
from typing import Dict, Any, Optional, AsyncGenerator
import aiohttp
import asyncio
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
from tornado import web

from .chat_manager import get_chat_manager
from .config import ChatConfig

class OpenAICompatibleHandler(APIHandler):
    """OpenAI 兼容的 API 处理器，用于转发到大模型服务"""
    
    # XSRF cookie 检查策略保持不变...
    
    @web.authenticated
    async def post(self):
        """处理聊天请求并转发到大模型服务"""
        try:
            # 获取请求数据
            request_data = self.get_json_body()
            
            # 验证请求数据
            if not request_data:
                self.set_status(400)
                self.finish({"error": {"message": "请求体不能为空"}})
                return
            
            # ===== 配置优先级逻辑 =====
            # 1. 从前端请求中获取配置（用户当前配置）
            frontend_model_service_url = request_data.get('model_service_url') + '/chat/completions'
            frontend_api_key = request_data.get('api_key')
            
            # 2. 从服务器配置中获取默认值
            config = self.settings.get("chat_config")
            
            if not config:
                self.log.error("服务器配置未初始化")
                self.set_status(500)
                self.finish({"error": {"message": "服务器配置错误"}})
                return
            
            # 3. 决定最终使用的配置
            # 模型服务地址：前端配置优先，否则使用服务器配置
            if frontend_model_service_url and frontend_model_service_url.strip():
                final_model_url = frontend_model_service_url.strip()
                self.log.info(f"使用前端配置的大模型服务地址: {final_model_url}")
            else:
                final_model_url = config.model_service_url
                self.log.info(f"使用服务器配置的大模型服务地址: {final_model_url}")
            
            # API Key：前端配置优先，否则使用服务器配置
            if frontend_api_key and frontend_api_key.strip():
                final_api_key = frontend_api_key.strip()
                self.log.info("使用前端配置的 API Key")
            elif config.api_key and config.api_key.strip():
                final_api_key = config.api_key
                self.log.info("使用服务器配置的 API Key")
            else:
                final_api_key = None
                self.log.info("未配置 API Key，将以无认证方式访问")
            
            # 4. 从请求数据中移除转发不需要的字段
            forward_data = {k: v for k, v in request_data.items() 
                           if k not in ['model_service_url', 'api_key']}
            
            # 准备转发请求头
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "JupyterLab-Chat-Toy/1.0"
            }
            
            # 如果有 API 密钥，添加到请求头
            if final_api_key:
                # 根据服务类型设置不同的认证头
                if "openai" in final_model_url or "api.openai" in final_model_url:
                    headers["Authorization"] = f"Bearer {final_api_key}"
                elif "claude" in final_model_url or "anthropic" in final_model_url:
                    headers["x-api-key"] = final_api_key
                    headers["anthropic-version"] = "2023-06-01"
                elif "azure" in final_model_url or "openai.azure" in final_model_url:
                    headers["api-key"] = final_api_key
                else:
                    # 通用 API 密钥头
                    headers["Authorization"] = f"Bearer {final_api_key}"
            
            # 获取流式参数
            stream = forward_data.get("stream", False)
            
            # 记录调试信息
            self.log.debug(f"转发配置 - URL: {final_model_url}, 使用认证: {'是' if final_api_key else '否'}")
            
            if stream:
                # 处理流式请求
                await self._handle_streaming_request(final_model_url, forward_data, headers)
            else:
                # 处理非流式请求
                await self._handle_standard_request(final_model_url, forward_data, headers)
                
        except json.JSONDecodeError:
            self.set_status(400)
            self.finish({"error": {"message": "无效的 JSON 数据"}})
        except Exception as e:
            self.log.error(f"处理请求时出错: {traceback.format_exc()}")
            self.set_status(500)
            self.finish({"error": {"message": f"服务器内部错误: {str(e)}"}})
    
    async def _handle_standard_request(self, model_service_url: str, 
                                     forward_data: Dict[str, Any], 
                                     headers: Dict[str, str]):
        """处理标准（非流式）请求"""
        async with aiohttp.ClientSession() as session:
            try:
                # 转发请求到大模型服务
                async with session.post(
                    model_service_url,
                    json=forward_data,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=300)
                ) as response:
                    
                    # 获取响应状态码
                    status_code = response.status
                    
                    # 获取响应内容
                    if status_code == 200:
                        response_data = await response.json()
                        
                        # 可选：将对话记录保存到聊天管理器
                        await self._save_conversation(forward_data, response_data)
                        
                        # 返回响应
                        self.finish(response_data)
                    else:
                        # 获取错误信息
                        error_text = await response.text()
                        self.log.error(f"大模型服务返回错误: {status_code} - {error_text}")
                        self.set_status(status_code)
                        
                        try:
                            error_data = json.loads(error_text)
                            self.finish({"error": error_data})
                        except:
                            self.finish({"error": {"message": f"大模型服务错误 (HTTP {status_code}): {error_text}"}})
                            
            except aiohttp.ClientError as e:
                self.log.error(f"连接大模型服务失败: {str(e)}")
                self.set_status(502)
                self.finish({"error": {"message": f"无法连接到大模型服务: {str(e)}"}})
            except asyncio.TimeoutError:
                self.log.error("请求大模型服务超时")
                self.set_status(504)
                self.finish({"error": {"message": "请求大模型服务超时"}})
    
    async def _handle_streaming_request(self, model_service_url: str,
                                      forward_data: Dict[str, Any], 
                                      headers: Dict[str, str]):
        """处理流式请求"""
        # 设置流式响应头
        self.set_header('Content-Type', 'text/event-stream')
        self.set_header('Cache-Control', 'no-cache')
        self.set_header('Connection', 'keep-alive')
        self.set_header('Access-Control-Allow-Origin', '*')
        
        async with aiohttp.ClientSession() as session:
            try:
                # 转发请求到大模型服务
                async with session.post(
                    model_service_url,
                    json=forward_data,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=300)
                ) as response:
                    
                    # 检查响应状态
                    if response.status != 200:
                        error_text = await response.text()
                        self.log.error(f"大模型服务流式响应错误: {response.status} - {error_text}")
                        self.write(f"data: {json.dumps({'error': {'message': f'大模型服务错误: {error_text}'}})}\n\n")
                        self.finish()
                        return
                    
                    # 流式转发响应
                    async for chunk in response.content.iter_any():
                        if chunk:
                            # 将 chunk 包装成 SSE 格式
                            chunk_str = chunk.decode('utf-8')
                            for line in chunk_str.split('\n'):
                                if line.strip():
                                    self.write(f"{line}\n")
                            
                            await self.flush()
                    
                    # 发送结束标记
                    self.write("data: [DONE]\n\n")
                    await self.flush()
                    
            except aiohttp.ClientError as e:
                self.log.error(f"流式请求失败: {str(e)}")
                error_msg = json.dumps({"error": {"message": f"流式请求失败: {str(e)}"}})
                self.write(f"data: {error_msg}\n\n")
            except Exception as e:
                self.log.error(f"流式处理异常: {traceback.format_exc()}")
                error_msg = json.dumps({"error": {"message": f"流式处理异常: {str(e)}"}})
                self.write(f"data: {error_msg}\n\n")
        
        self.finish()
    
    async def _save_conversation(self, request_data: Dict[str, Any], 
                               response_data: Dict[str, Any]):
        """保存对话记录到聊天管理器"""
        try:
            # 获取用户 ID
            user_id = self.get_current_user_id()
            
            # 获取消息
            messages = request_data.get("messages", [])
            if not messages:
                return
            
            # 获取最后一条用户消息
            user_messages = [m for m in messages if m.get("role") == "user"]
            if not user_messages:
                return
            
            last_user_msg = user_messages[-1]
            user_content = last_user_msg.get("content", "")
            
            # 获取 AI 回复
            choices = response_data.get("choices", [])
            if not choices:
                return
            
            ai_content = ""
            for choice in choices:
                message = choice.get("message", {})
                if message.get("role") == "assistant":
                    ai_content = message.get("content", "")
                    break
            
            if not ai_content:
                # 如果是流式响应的最终结果
                for choice in choices:
                    delta = choice.get("delta", {})
                    if delta.get("role") == "assistant":
                        ai_content = delta.get("content", "")
            
            if user_content and ai_content:
                # 获取聊天管理器
                chat_manager = self.settings.get("chat_manager")
                if chat_manager:
                    # 保存用户消息
                    await chat_manager.process_message(user_content, user_id)
                    # 注意：这里简化处理，实际可能需要更复杂的逻辑
                    
        except Exception as e:
            self.log.warning(f"保存对话记录失败: {str(e)}")
    
    def get_current_user_id(self):
        """获取当前用户 ID"""
        # 尝试多种方式获取用户 ID
        if hasattr(self, 'current_user') and self.current_user:
            return str(self.current_user)
        
        if hasattr(self, 'session') and hasattr(self.session, 'session_id'):
            return self.session.session_id
        
        # 从请求参数获取（JupyterHub）
        user = self.get_argument("user", None)
        if user:
            return user
        
        # 使用 IP 地址
        return self.request.remote_ip or "anonymous"

class HealthHandler(APIHandler):
    """健康检查处理器"""
    
    async def get(self):
        """健康检查端点"""
        self.finish({
            "status": "healthy",
            "service": "jupyterlab-chat-toy",
            "timestamp": datetime.now().isoformat(),
            "openai_compatible": True
        })

class ConfigHandler(APIHandler):
    """配置处理器 - 提供服务器配置给前端"""
    
    @web.authenticated
    async def get(self):
        """获取服务器配置（脱敏后）"""
        config = self.settings.get("chat_config")
        
        if not config:
            self.finish({
                "error": "配置未初始化",
                "openai_compatible": True
            })
            return
        
        # 获取脱敏后的配置
        try:
            frontend_config = config.to_dict()
        except Exception:
            frontend_config = config # 前面出错了，这里直接配置成字典
        
        # 添加额外信息
        try:
            frontend_config.update({
                "openai_compatible": True,
                "api_endpoint": f"{self.request.protocol}://{self.request.host}/chat-toy/v1/chat/completions",
                "jupyter_extension_url": "/chat-toy/v1/chat/completions",
                "config_source": "server",  # 标识配置来源
                "server_config": {
                    "has_api_key": bool(config.api_key),
                    "api_key_masked": "***" if config.api_key else "",
                    "model_service_url": config.ai_service_url
                }
            })
        
        except Exception:
            frontend_config.update({
                "openai_compatible": True,
                "api_endpoint": f"{self.request.protocol}://{self.request.host}/chat-toy/v1/chat/completions",
                "jupyter_extension_url": "/chat-toy/v1/chat/completions",
                "config_source": "server",  # 标识配置来源
                "server_config": {
                    "has_api_key": bool(config['api_key']),
                    "api_key_masked": "***" if config['api_key'] else "",
                    "model_service_url": config['ai_service_url']
                }
            })
        
        self.finish(frontend_config)
    
    @web.authenticated
    async def post(self):
        """更新服务器配置（如果需要）"""
        # 注意：通常不建议从前端直接更新服务器配置
        # 这里只返回当前配置
        return await self.get()

        
# 在 handlers.py 中添加调试处理器
class DebugHandler(APIHandler):
    """调试处理器，用于查看请求信息"""
    
    async def get(self):
        """显示当前请求信息"""
        info = {
            "request": {
                "method": self.request.method,
                "uri": self.request.uri,
                "path": self.request.path,
                "headers": dict(self.request.headers),
                "query": dict(self.request.arguments),
            },
            "user": {
                "authenticated": self.current_user is not None,
                "username": self.current_user,
            },
            "xsrf": {
                "cookie": self.get_cookie("_xsrf"),
                "token": getattr(self, 'xsrf_token', None),
            },
            "server": {
                "base_url": self.settings.get("base_url", "/"),
                "settings_keys": list(self.settings.keys()),
            }
        }
        self.finish(info)
    
    async def post(self):
        """测试 POST 请求"""
        data = self.get_json_body()
        self.finish({
            "status": "success",
            "received_data": data,
            "headers": dict(self.request.headers),
            "xsrf_cookie": self.get_cookie("_xsrf"),
        })

def setup_handlers(server_app):
    """设置所有处理器"""
    web_app = server_app.web_app
    base_url = web_app.settings["base_url"]
    server_app.log.info("base_url是%s"%(base_url))


    # 初始化聊天管理器
    chat_manager = get_chat_manager()
    web_app.settings["chat_manager"] = chat_manager
    web_app.settings["chat_config"] = server_app.chat_toy_config
    
    # API 前缀
    api_prefix = "chat-toy"
    
    # 定义处理器列表
    handlers = [
        # OpenAI 兼容 API（前端直接调用这个）
        (url_path_join(base_url, api_prefix, "v1", "chat", "completions"), OpenAICompatibleHandler),
        
        # 原有的聊天 API（可选保留）
        (url_path_join(base_url, api_prefix, "chat"), OpenAICompatibleHandler),
        
        # 配置相关
        (url_path_join(base_url, api_prefix, "config"), ConfigHandler),
        
        # 系统相关
        (url_path_join(base_url, api_prefix, "health"), HealthHandler),
    ]
    
    # 将处理器添加到 web 应用
    web_app.add_handlers(".*$", handlers)
    
    server_app.log.info(
        f"📡 已注册 OpenAI 兼容 API: {base_url}{api_prefix}/v1/chat/completions"
    )