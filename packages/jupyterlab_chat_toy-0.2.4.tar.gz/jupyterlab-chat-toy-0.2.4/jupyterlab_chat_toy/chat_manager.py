"""聊天业务逻辑管理"""
import asyncio
import json
import time
from datetime import datetime
from typing import Dict, List, Optional, Any
import uuid

class ChatManager:
    """聊天管理器，处理所有聊天相关的业务逻辑"""
    
    def __init__(self):
        self.message_history: Dict[str, List[Dict]] = {}
        self.sessions: Dict[str, Dict] = {}
        
    async def process_message(self, message: str, user: str = "anonymous", session_id: Optional[str] = None) -> Dict[str, Any]:
        """处理用户消息并生成回复"""
        
        # 如果没有提供session_id，则创建一个新的会话
        if not session_id or session_id not in self.sessions:
            session_id = self._create_session(user)
        
        # 创建消息ID和时间戳
        message_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        # 存储用户消息
        user_message = {
            "id": message_id,
            "content": message,
            "timestamp": timestamp,
            "type": "user",
            "user": user,
            "session_id": session_id
        }
        
        # 将消息添加到历史记录
        self._add_to_history(user, session_id, user_message)
        
        # 生成回复（这里可以集成AI模型，如调用OpenAI API）
        reply = await self._generate_reply(message, user, session_id)
        
        # 存储助手回复
        assistant_message = {
            "id": str(uuid.uuid4()),
            "content": reply,
            "timestamp": datetime.now().isoformat(),
            "type": "assistant",
            "session_id": session_id
        }
        
        # 将回复添加到历史记录
        self._add_to_history(user, session_id, assistant_message)
        
        # 返回响应
        return {
            "message": assistant_message,
            "session_id": session_id,
            "status": "success"
        }
    
    async def _generate_reply(self, message: str, user: str, session_id: str) -> str:
        """生成回复内容（这里可以替换为实际的AI模型调用）"""
        # 模拟AI处理延迟
        await asyncio.sleep(0.1)
        
        # 这里只是一个简单的回复示例
        # 实际项目中可以调用OpenAI、HuggingFace等API
        replies = [
            f"你好，{user}！我已经收到你的消息：'{message}'。",
            f"您说的 '{message}' 很有意思，能详细说说吗？",
            f"关于 '{message}'，我有以下想法：...",
            "这是一个很好的问题，让我思考一下...",
            "我已经记录了您的消息，稍后会为您详细解答。"
        ]
        
        import random
        return random.choice(replies)
    
    def _create_session(self, user: str) -> str:
        """创建一个新的聊天会话"""
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "user": user,
            "created_at": datetime.now().isoformat(),
            "last_active": datetime.now().isoformat()
        }
        
        # 初始化该会话的历史记录
        self.message_history[session_id] = []
        
        return session_id
    
    def _add_to_history(self, user: str, session_id: str, message: Dict):
        """将消息添加到历史记录"""
        if session_id not in self.message_history:
            self.message_history[session_id] = []
        
        # 限制历史记录长度，最多保留100条消息
        if len(self.message_history[session_id]) >= 100:
            self.message_history[session_id].pop(0)
        
        self.message_history[session_id].append(message)
        
        # 更新会话的最后活动时间
        if session_id in self.sessions:
            self.sessions[session_id]["last_active"] = datetime.now().isoformat()
    
    async def get_history(self, user: str, session_id: Optional[str] = None, limit: int = 50) -> Dict[str, Any]:
        """获取聊天历史记录"""
        if session_id:
            # 获取特定会话的历史记录
            history = self.message_history.get(session_id, [])[-limit:]
            sessions = [self.sessions.get(session_id, {})]
        else:
            # 获取用户的所有会话历史记录
            user_sessions = {
                sid: data for sid, data in self.sessions.items() 
                if data.get("user") == user
            }
            history = []
            for sid in user_sessions.keys():
                history.extend(self.message_history.get(sid, []))
            
            # 按时间排序并限制数量
            history.sort(key=lambda x: x.get("timestamp", ""))
            history = history[-limit:]
            sessions = list(user_sessions.values())
        
        return {
            "messages": history,
            "sessions": sessions,
            "total": len(history),
            "user": user
        }
    
    def clear_history(self, user: str, session_id: Optional[str] = None):
        """清空聊天历史记录"""
        if session_id:
            if session_id in self.message_history:
                self.message_history[session_id] = []
        else:
            # 清空用户的所有会话历史记录
            for sid, data in self.sessions.items():
                if data.get("user") == user and sid in self.message_history:
                    self.message_history[sid] = []

# 全局聊天管理器实例
_chat_manager = None

def get_chat_manager() -> ChatManager:
    """获取聊天管理器实例（单例模式）"""
    global _chat_manager
    if _chat_manager is None:
        _chat_manager = ChatManager()
    return _chat_manager