"""配置管理模块"""
import os
from typing import Dict, Any
from traitlets.config import LoggingConfigurable
from traitlets import (
    Unicode, Int, Bool, Float, Dict as DictTrait,
    Enum, List as ListTrait
)

class ChatConfig(LoggingConfigurable):
    """聊天扩展配置"""
    
    # OpenAI 兼容配置
    ai_service_url = Unicode(
        default_value="",
        config=True,
        help="大模型服务 URL（OpenAI 兼容 API）"
    )
    model_service_url = Unicode(
        default_value="",
        config=True,
        help="大模型服务 URL（OpenAI 兼容 API）"
    )

    api_key = Unicode(
        default_value="",
        allow_none=True,
        config=True,
        help="API 密钥，用于访问大模型服务"
    )
    
    model = Unicode(
        default_value="gpt-3.5-turbo",
        config=True,
        help="默认使用的模型名称"
    )
    
    # 模型参数
    max_tokens = Int(
        default_value=2000,
        config=True,
        min=1,
        max=16000,
        help="生成回复的最大令牌数"
    )
    
    temperature = Float(
        default_value=0.7,
        config=True,
        min=0.0,
        max=2.0,
        help="生成回复的温度参数"
    )
    
    top_p = Float(
        default_value=1.0,
        config=True,
        min=0.0,
        max=1.0,
        help="核采样概率"
    )
    
    # 功能配置
    streaming = Bool(
        default_value=True,
        config=True,
        help="是否启用流式响应"
    )
    
    # API 配置
    api_timeout = Int(
        default_value=300,
        config=True,
        min=1,
        max=600,
        help="API 请求超时时间（秒）"
    )
    
    # 界面配置
    show_timestamps = Bool(
        default_value=True,
        config=True,
        help="是否显示时间戳"
    )
    
    # 安全配置
    require_authentication = Bool(
        default_value=True,
        config=True,
        help="是否需要认证"
    )
    
    allowed_models = ListTrait(
        Unicode(),
        default_value=["gpt-3.5-turbo", "gpt-4", "custom"],
        config=True,
        help="允许使用的模型列表"
    )
    
    def __init__(self, parent=None, config=None, **kwargs):
        """
        初始化配置
        
        Args:
            parent: 父配置对象
            config: traitlets 配置对象
            **kwargs: 其他参数
        """
        # 传递 config 给父类，让 traitlets 自动处理配置文件
        super().__init__(parent=parent, config=config, **kwargs)
        
        # 由于 traitlets 的 config=True 会自动从 Jupyter 配置加载，
        # 我们只需要加载环境变量作为补充
        self._load_from_env()
        
        # 向后兼容：检查并映射旧配置项名称
        self._backward_compatibility()
    
    def _backward_compatibility(self):
        """
        向后兼容旧版本的配置项名称
        
        你的配置文件中使用了不同的命名，这里进行映射
        """
        # 获取 Jupyter 配置管理器
        if hasattr(self, 'config') and self.config:
            # 尝试从 ChatToyConfig 节读取旧配置
            if hasattr(self.config, 'ChatToyConfig'):
                toy_config = self.config.ChatToyConfig
                
                # 映射旧配置到新配置
                mapping = {
                    'model_service_url': 'ai_service_url',
                    'default_model': 'model',
                    'default_temperature': 'temperature',
                    'default_max_tokens': 'max_tokens',
                    'enable_streaming': 'streaming',
                    'api_key':'api_key'
                }
                
                for old_key, new_key in mapping.items():
                    if hasattr(toy_config, old_key):
                        old_value = getattr(toy_config, old_key)
                        if old_value is not None:
                            # 更新当前配置
                            setattr(self, new_key, old_value)
                            self.log.info(f"从 ChatToyConfig.{old_key} 加载配置: {old_value}")
    
    def _load_from_env(self):
        """从环境变量加载配置"""
        env_mapping = {
            "JUPYTER_CHAT_API_KEY": "api_key",
            "JUPYTER_CHAT_AI_SERVICE_URL": "ai_service_url",
            "JUPYTER_CHAT_MODEL": "model",
            "JUPYTER_CHAT_MAX_TOKENS": "max_tokens",
            "JUPYTER_CHAT_TEMPERATURE": "temperature",
            "JUPYTER_CHAT_STREAMING": "streaming",
            "JUPYTER_CHAT_API_TIMEOUT": "api_timeout",
        }
        
        for env_var, attr_name in env_mapping.items():
            if env_var in os.environ:
                env_value = os.environ[env_var]
                try:
                    # 尝试转换类型
                    current_value = getattr(self, attr_name)
                    if isinstance(current_value, bool):
                        # 处理布尔值
                        if env_value.lower() in ('true', '1', 'yes', 'on'):
                            setattr(self, attr_name, True)
                        elif env_value.lower() in ('false', '0', 'no', 'off'):
                            setattr(self, attr_name, False)
                    elif isinstance(current_value, int):
                        setattr(self, attr_name, int(env_value))
                    elif isinstance(current_value, float):
                        setattr(self, attr_name, float(env_value))
                    else:
                        setattr(self, attr_name, env_value)
                        
                    self.log.debug(f"从环境变量 {env_var} 加载配置: {env_value}")
                except Exception as e:
                    self.log.warning(f"无法从环境变量 {env_var} 加载配置: {e}")
    
    def to_dict(self) -> Dict[str, Any]:
        """将配置转换为字典"""
        return {
            # OpenAI 配置
            "ai_service_url": self.ai_service_url,
            "api_key":self.api_key,
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "streaming": self.streaming,
            "api_timeout": self.api_timeout,
            
            # 界面配置
            "show_timestamps": self.show_timestamps,
            "require_authentication": self.require_authentication,
            "allowed_models": self.allowed_models,
            
            # 注意：api_key 不在这里返回，以防泄露
        }
    
    def update(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """更新配置"""
        for key, value in new_config.items():
            if hasattr(self, key) and not key.startswith("_"):
                # 类型检查
                current_type = type(getattr(self, key))
                if isinstance(value, current_type):
                    setattr(self, key, value)
                else:
                    try:
                        # 尝试类型转换
                        setattr(self, key, current_type(value))
                    except (ValueError, TypeError):
                        self.log.warning(f"无法将 {key} 的值转换为 {current_type}")
        
        return self.to_dict()
    
    def validate(self) -> bool:
        """验证配置是否有效"""
        if not self.ai_service_url:
            self.log.error("未配置 AI 服务 URL")
            return False
        
        if not self.api_key and ("openai" in self.ai_service_url or "api.openai" in self.ai_service_url):
            self.log.warning("使用 OpenAI 服务但没有提供 API 密钥")
            # 这里不返回 False，因为有些服务可能不需要 API 密钥
        
        if self.max_tokens < 1 or self.max_tokens > 16000:
            self.log.error(f"max_tokens 必须在1-16000之间，当前值: {self.max_tokens}")
            return False
        
        if self.temperature < 0.0 or self.temperature > 2.0:
            self.log.error(f"temperature 必须在0.0-2.0之间，当前值: {self.temperature}")
            return False
        
        return True