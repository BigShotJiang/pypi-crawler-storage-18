"""聊天API实现"""
from typing import Dict, Any, Optional
from ..chat_manager import get_chat_manager

class ChatAPI:
    """聊天API类"""
    
    def __init__(self):
        self.chat_manager = get_chat_manager()
    
    async def process_message(self, message: str, user: str = "anonymous", session_id: Optional[str] = None) -> Dict[str, Any]:
        """处理消息并返回回复"""
        return await self.chat_manager.process_message(message, user, session_id)
    
    async def get_history(self, user: str, limit: int = 50, session_id: Optional[str] = None) -> Dict[str, Any]:
        """获取聊天历史"""
        return await self.chat_manager.get_history(user, session_id, limit)