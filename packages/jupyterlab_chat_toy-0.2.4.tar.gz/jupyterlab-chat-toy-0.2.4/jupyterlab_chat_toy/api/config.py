"""配置API实现"""
from typing import Dict, Any
from ..config import get_config

class ConfigAPI:
    """配置API类"""
    
    def __init__(self):
        self.config = get_config()
    
    async def get_config(self) -> Dict[str, Any]:
        """获取当前配置"""
        if self.config:
            return self.config.to_dict()
        return {}
    
    async def update_config(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """更新配置"""
        if self.config:
            return self.config.update(new_config)
        return {"error": "配置未初始化"}