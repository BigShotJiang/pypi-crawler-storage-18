"""
JupyterLab Chat Toy 服务器扩展主模块
支持 OpenAI 兼容 API 转发
"""
import json
import os
from .handlers import setup_handlers
from .config import ChatConfig
from ._version import __version__


HERE = os.path.dirname(os.path.abspath(__file__))

def _jupyter_server_extension_paths():
    """返回服务器扩展路径"""
    return [{
        "module": "jupyterlab_chat_toy"
    }]

def _load_jupyter_server_extension(server_app):
    """加载服务器扩展的主函数"""
    try:
        # 初始化配置 - 传递 server_app 的 config 对象
        chat_config = ChatConfig(parent=server_app, config=server_app.config)
        # server_app.log.info(f"✅ 系统的chat_config是个这个东西%s"%(chat_config))
        server_app.chat_toy_config = chat_config

        
        # 设置处理器
        setup_handlers(server_app)
        
        # 记录日志
        server_app.log.info(f"✅ JupyterLab Chat Toy 服务器扩展 v{__version__} 已加载")
        server_app.log.info(f"📡 OpenAI 兼容 API: {server_app.web_app.settings['base_url']}chat-toy/v1/chat/completions")
        server_app.log.info(f"🤖 AI 服务地址: {chat_config.ai_service_url}")
        server_app.log.info(f"🤖 API_KEY: {chat_config.api_key}")

        # 记录更多配置信息以便调试
        server_app.log.info(f"🔧 使用模型: {chat_config.model}")
        server_app.log.info(f"🌡️ 温度参数: {chat_config.temperature}")
        server_app.log.info(f"🔢 最大令牌数: {chat_config.max_tokens}")
        server_app.log.info(f"🌀 流式响应: {'开启' if chat_config.streaming else '关闭'}")
        
        # 验证配置
        if not chat_config.validate():
            server_app.log.warning("⚠️ 聊天扩展配置验证失败，某些功能可能不可用")
        else:
            server_app.log.info("✅ 配置验证通过")
        
        return {
            "name": "jupyterlab_chat_toy",
            "version": __version__,
            "config": chat_config.to_dict()
        }
        
    except Exception as e:
        server_app.log.error(f"❌ 加载服务器扩展失败: {str(e)},返回默认值")
        chat_config = {"ai_service_url":"default_url", "api_key":"", "model":"default_model","temperature":0.7,"max_tokens":2000,"streaming":True}
        server_app.chat_toy_config = chat_config
        # 设置处理器
        setup_handlers(server_app)

        return {
            "name": "jupyterlab_chat_toy",
            "version": __version__,
            "config": chat_config
        }

        # import traceback
        # server_app.log.error(traceback.format_exc())
        # raise

# 兼容性函数
load_jupyter_server_extension = _load_jupyter_server_extension