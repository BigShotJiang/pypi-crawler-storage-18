"use strict";
(self["webpackChunkjupyterlab_chat_toy"] = self["webpackChunkjupyterlab_chat_toy"] || []).push([["lib_index_js"],{

/***/ "./lib/ChatWidget/ChatComponent.js":
/*!*****************************************!*\
  !*** ./lib/ChatWidget/ChatComponent.js ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChatComponent = void 0;
// ChatComponent.tsx
const react_1 = __importStar(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const notebook_1 = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
const Header_1 = __webpack_require__(/*! ./Header */ "./lib/ChatWidget/Header.js");
const ConfigPanel_1 = __webpack_require__(/*! ./ConfigPanel */ "./lib/ChatWidget/ConfigPanel.js");
const MessageList_1 = __webpack_require__(/*! ./MessageList */ "./lib/ChatWidget/MessageList.js");
const InputArea_1 = __webpack_require__(/*! ./InputArea */ "./lib/ChatWidget/InputArea.js");
const useChat_1 = __webpack_require__(/*! ./hooks/useChat */ "./lib/ChatWidget/hooks/useChat.js");
const useStreaming_1 = __webpack_require__(/*! ./hooks/useStreaming */ "./lib/ChatWidget/hooks/useStreaming.js");
const useScroll_1 = __webpack_require__(/*! ./hooks/useScroll */ "./lib/ChatWidget/hooks/useScroll.js");
const easterEggHelper_1 = __webpack_require__(/*! ./utils/easterEggHelper */ "./lib/ChatWidget/utils/easterEggHelper.js");
// 导入错误分析工具，包括新的 explain 功能
const errorAnalyzer_1 = __webpack_require__(/*! ../utils/errorAnalyzer */ "./lib/utils/errorAnalyzer.js");
const MODEL_OPTIONS = [
    { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo' },
    { value: 'gpt-4', label: 'GPT-4' },
    { value: 'gpt-4-turbo', label: 'GPT-4 Turbo' },
    { value: 'claude-3-sonnet', label: 'Claude 3 Sonnet' },
    { value: 'claude-3-opus', label: 'Claude 3 Opus' },
    { value: 'llama-2-7b', label: 'Llama 2 7B' },
    { value: 'llama-2-13b', label: 'Llama 2 13B' },
    { value: 'llama-2-70b', label: 'Llama 2 70B' },
    { value: 'custom', label: '自定义模型' }
];
const ChatComponent = ({ notebookTracker }) => {
    const [inputValue, setInputValue] = react_1.useState('');
    const [isConfigVisible, setIsConfigVisible] = react_1.useState(false);
    const [errorDetectionSupported, setErrorDetectionSupported] = react_1.useState(true);
    // 使用自定义hooks - 添加 serverConfig 和 isLoading
    const { messages, config, serverConfig, // 从 useChat 中获取 serverConfig
    isLoading: isChatLoading, // 重命名以避免冲突
    addMessage, updateMessage, clearMessages, updateConfig, resetConfig, getActualModelName, refreshConfig // 如果需要重新加载配置
     } = useChat_1.useChat();
    const { isLoading: isStreamingLoading, // 重命名以避免冲突
    currentStreamingMessageId, streamToAI, stopStreaming, setIsLoading } = useStreaming_1.useStreaming();
    const { shouldAutoScroll, messagesEndRef, messagesContainerRef, smartScrollToBottom, scrollToBottomManually } = useScroll_1.useScroll();
    // 合并 loading 状态
    const isLoading = isChatLoading || isStreamingLoading;
    // 检查错误检测功能是否支持
    react_1.useEffect(() => {
        const supported = errorAnalyzer_1.isErrorDetectionSupported(notebookTracker);
        setErrorDetectionSupported(supported);
        if (!supported) {
            console.warn('错误检测功能在当前JupyterLab版本中可能不可用');
        }
    }, [notebookTracker]);
    // 切换配置面板显示
    const toggleConfigPanel = () => {
        setIsConfigVisible(prev => !prev);
    };
    // 插入代码到Notebook
    const insertCodeToNotebook = (code, language) => {
        if (!notebookTracker) {
            console.error('Notebook tracker not available');
            alert('错误：未找到活动的Notebook');
            return;
        }
        const current = notebookTracker.currentWidget;
        if (!current) {
            alert('错误：请先打开一个Notebook');
            return;
        }
        const { content } = current;
        const { activeCellIndex } = content;
        try {
            notebook_1.NotebookActions.insertBelow(content);
            const newCellIndex = activeCellIndex + 1;
            const newCell = content.widgets[newCellIndex];
            if (newCell && newCell.model.type === 'code') {
                const cellModel = newCell.model;
                if (cellModel.value && cellModel.value.text !== undefined) {
                    cellModel.value.text = code;
                }
                else if (cellModel.sharedModel) {
                    if (typeof cellModel.sharedModel.setSource === 'function') {
                        cellModel.sharedModel.setSource(code);
                    }
                    else if (cellModel.sharedModel.source !== undefined) {
                        cellModel.sharedModel.source = code;
                    }
                    else {
                        alert('无法设置代码内容：sharedModel 格式不支持');
                        return;
                    }
                }
                else if (cellModel.source !== undefined) {
                    cellModel.source = code;
                }
                else {
                    alert('无法设置代码内容：不支持的单元格模型');
                    return;
                }
                content.activeCellIndex = newCellIndex;
            }
        }
        catch (error) {
            console.error('插入代码失败:', error);
            alert('插入代码失败，请重试');
        }
    };
    // 统一的 AI 流式请求函数
    const sendToAI = async (prompt, userMessageContent) => {
        // 添加用户消息
        const userMessage = {
            id: Date.now(),
            content: userMessageContent || prompt.substring(0, 100) + '...',
            sender: 'user',
            timestamp: new Date(),
            type: 'text'
        };
        addMessage(userMessage);
        setInputValue('');
        setIsLoading(true);
        smartScrollToBottom('smooth');
        try {
            await streamToAI({
                message: prompt,
                messages: [...messages, userMessage],
                config,
                onNewMessage: addMessage,
                onUpdateMessage: updateMessage,
                onStreamingStart: (messageId) => {
                    // 可以根据需要处理流式开始
                },
                onStreamingEnd: () => {
                    // 流式结束处理
                },
                onError: (error) => {
                    const errorMessage = {
                        id: Date.now() + 1,
                        content: `请求失败: ${error instanceof Error ? error.message : '未知错误'}`,
                        sender: 'ai',
                        timestamp: new Date(),
                        type: 'text'
                    };
                    addMessage(errorMessage);
                }
            });
        }
        catch (error) {
            console.error('Streaming failed:', error);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleSend = async () => {
        if (!inputValue.trim() || isLoading)
            return;
        if (easterEggHelper_1.eggCheck(inputValue)) {
            // 简单的 alert 弹窗
            alert(easterEggHelper_1.eggcontent);
            setInputValue('');
            return;
        }
        // 检查是否是 /help 命令
        if (inputValue.trim() === '/help') {
            showHelpMessage();
            setInputValue('');
            return;
        }
        // 检查是否是 /fix 命令
        if (inputValue.trim().startsWith('/fix')) {
            if (!errorDetectionSupported) {
                const errorMessage = {
                    id: Date.now(),
                    content: '⚠️ 错误检测功能在当前JupyterLab版本中不可用。请升级到最新版本或使用其他方法分析错误。',
                    sender: 'ai',
                    timestamp: new Date(),
                    type: 'text'
                };
                addMessage(errorMessage);
                setInputValue('');
                smartScrollToBottom('smooth');
                return;
            }
            const fixResult = errorAnalyzer_1.handleFixCommand(notebookTracker, inputValue);
            if (!fixResult.shouldContinue) {
                // 如果是 /fix 命令但处理失败
                if (fixResult.error) {
                    const errorMessage = {
                        id: Date.now(),
                        content: fixResult.error,
                        sender: 'ai',
                        timestamp: new Date(),
                        type: 'text'
                    };
                    addMessage(errorMessage);
                    setInputValue('');
                    smartScrollToBottom('smooth');
                    return;
                }
                // 如果有分析提示词，发送给大模型
                if (fixResult.analysisPrompt) {
                    await sendToAI(fixResult.analysisPrompt, inputValue);
                    return;
                }
            }
        }
        // 检查是否是 /explain 命令
        if (inputValue.trim().startsWith('/explain')) {
            const explainResult = errorAnalyzer_1.handleExplainCommand(notebookTracker, inputValue);
            if (!explainResult.shouldContinue) {
                // 如果是 /explain 命令但处理失败
                if (explainResult.error) {
                    const errorMessage = {
                        id: Date.now(),
                        content: explainResult.error,
                        sender: 'ai',
                        timestamp: new Date(),
                        type: 'text'
                    };
                    addMessage(errorMessage);
                    setInputValue('');
                    smartScrollToBottom('smooth');
                    return;
                }
                // 如果有解释提示词，发送给大模型
                if (explainResult.explanationPrompt) {
                    await sendToAI(explainResult.explanationPrompt, inputValue);
                    return;
                }
            }
        }
        // 普通消息处理
        await sendToAI(inputValue, inputValue);
    };
    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };
    const handleClearChat = () => {
        stopStreaming();
        clearMessages();
    };
    // 显示帮助信息
    const showHelpMessage = () => {
        let helpContent = `🛠️ **可用命令**

\`/fix\` - 分析并修复当前活动单元格的错误
   用法: \`/fix [额外描述]\`
   示例: \`/fix 这个函数为什么报错？\`

\`/explain\` - 解释当前活动单元格的代码功能
   用法: \`/explain [额外问题]\`
   示例: \`/explain 这段代码的具体作用是什么？\`
   
\`/help\` - 显示帮助信息`;
        // 根据是否支持错误检测调整帮助信息
        if (!errorDetectionSupported) {
            helpContent += `

⚠️ **注意**: 错误修复功能(\`/fix\`)在当前JupyterLab版本中可能不可用。
   请确保：
   1. 你使用的是 JupyterLab 3.2.9 或更高版本
   2. 代码单元格已执行并产生了错误
   3. 包含错误的单元格处于活动状态`;
        }
        else {
            helpContent += `

**功能说明**：
• \`/fix\`: 分析当前单元格的错误并提供修复方案
• \`/explain\`: 解释当前单元格的代码功能和逻辑

使用步骤：
1. 确保目标单元格处于活动状态（点击选中）
2. 在聊天框输入相应命令
3. AI 会基于单元格内容提供帮助`;
        }
        helpContent += `

💡 提示：当你在输入框中输入 \`/\` 时，会显示命令提示。`;
        const helpMessage = {
            id: Date.now(),
            content: helpContent,
            sender: 'ai',
            timestamp: new Date(),
            type: 'text'
        };
        addMessage(helpMessage);
        smartScrollToBottom('smooth');
    };
    // 添加快捷命令提示
    const [showCommandHint, setShowCommandHint] = react_1.useState(false);
    // 监听输入变化，显示命令提示
    react_1.useEffect(() => {
        if (inputValue.trim() === '/') {
            setShowCommandHint(true);
        }
        else if (inputValue.trim().startsWith('/fix') || inputValue.trim().startsWith('/explain')) {
            setShowCommandHint(false);
        }
        else {
            setShowCommandHint(false);
        }
    }, [inputValue]);
    const actualModelName = getActualModelName();
    return (react_1.default.createElement("div", { style: {
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            fontFamily: 'var(--jp-ui-font-family)',
            fontSize: 'var(--jp-ui-font-size1)',
            background: 'var(--jp-layout-color0)',
            position: 'relative'
        } },
        react_1.default.createElement(Header_1.Header, { modelName: actualModelName, isLoading: isLoading, onStop: stopStreaming, onClear: handleClearChat, onToggleConfig: toggleConfigPanel, isConfigVisible: isConfigVisible }),
        !isChatLoading && (react_1.default.createElement(ConfigPanel_1.ConfigPanel, { config: config, serverConfig: serverConfig, modelOptions: MODEL_OPTIONS, onConfigChange: updateConfig, onReset: resetConfig, isVisible: isConfigVisible, onToggleVisibility: toggleConfigPanel })),
        react_1.default.createElement(MessageList_1.MessageList, { messages: messages, isLoading: isLoading, currentStreamingMessageId: currentStreamingMessageId, onInsertCode: insertCodeToNotebook, onScrollToBottom: scrollToBottomManually, shouldAutoScroll: shouldAutoScroll, messagesEndRef: messagesEndRef, messagesContainerRef: messagesContainerRef }),
        showCommandHint && (react_1.default.createElement("div", { style: {
                position: 'absolute',
                bottom: '80px',
                left: '10px',
                right: '10px',
                background: 'var(--jp-layout-color1)',
                border: '1px solid var(--jp-border-color1)',
                borderRadius: '6px',
                padding: '8px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                zIndex: 100,
                fontSize: '12px'
            } },
            react_1.default.createElement("div", { style: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '4px'
                } },
                react_1.default.createElement("span", { style: { fontWeight: 'bold', color: 'var(--jp-ui-font-color1)' } }, "\u53EF\u7528\u547D\u4EE4"),
                react_1.default.createElement("button", { onClick: () => setShowCommandHint(false), style: {
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--jp-ui-font-color2)',
                        cursor: 'pointer',
                        fontSize: '12px'
                    } }, "\u2715")),
            react_1.default.createElement("div", { style: {
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px'
                } },
                react_1.default.createElement("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '4px',
                        borderRadius: '4px',
                        background: errorDetectionSupported ? 'var(--jp-layout-color2)' : 'var(--jp-layout-color3)',
                        cursor: errorDetectionSupported ? 'pointer' : 'not-allowed',
                        opacity: errorDetectionSupported ? 1 : 0.6
                    }, onClick: () => {
                        if (errorDetectionSupported) {
                            setInputValue('/fix ');
                            setShowCommandHint(false);
                        }
                    }, title: errorDetectionSupported ? '' : '错误检测功能不可用' },
                    react_1.default.createElement("code", { style: {
                            background: errorDetectionSupported ? 'var(--jp-brand-color1)' : 'var(--jp-ui-font-color3)',
                            color: 'white',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontSize: '11px'
                        } }, "/fix"),
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("div", { style: { color: 'var(--jp-ui-font-color1)' } }, "\u5206\u6790\u5E76\u4FEE\u590D\u5F53\u524D\u5355\u5143\u683C\u7684\u9519\u8BEF"),
                        !errorDetectionSupported && (react_1.default.createElement("div", { style: {
                                fontSize: '10px',
                                color: 'var(--jp-ui-font-color3)',
                                marginTop: '2px'
                            } }, "\u5F53\u524D\u7248\u672C\u4E0D\u53EF\u7528")))),
                react_1.default.createElement("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '4px',
                        borderRadius: '4px',
                        background: 'var(--jp-layout-color2)',
                        cursor: 'pointer'
                    }, onClick: () => {
                        setInputValue('/explain ');
                        setShowCommandHint(false);
                    } },
                    react_1.default.createElement("code", { style: {
                            background: '#4CAF50',
                            color: 'white',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontSize: '11px'
                        } }, "/explain"),
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("div", { style: { color: 'var(--jp-ui-font-color1)' } }, "\u89E3\u91CA\u5F53\u524D\u5355\u5143\u683C\u7684\u4EE3\u7801\u529F\u80FD"))),
                react_1.default.createElement("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '4px',
                        borderRadius: '4px',
                        background: 'var(--jp-layout-color2)',
                        cursor: 'pointer'
                    }, onClick: () => {
                        setInputValue('/help');
                        setShowCommandHint(false);
                    } },
                    react_1.default.createElement("code", { style: {
                            background: 'var(--jp-accent-color1)',
                            color: 'white',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontSize: '11px'
                        } }, "/help"),
                    react_1.default.createElement("span", { style: { color: 'var(--jp-ui-font-color1)' } }, "\u663E\u793A\u5E2E\u52A9\u4FE1\u606F"))))),
        react_1.default.createElement(InputArea_1.InputArea, { value: inputValue, isLoading: isLoading, modelName: actualModelName, temperature: config.temperature, maxTokens: config.maxTokens, onChange: setInputValue, onSend: handleSend, onKeyPress: handleKeyPress }),
        react_1.default.createElement("style", null, `
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }

        @keyframes slideDown {
          from {
            opacity: 0;
            max-height: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            max-height: 300px;
            transform: translateY(0);
          }
        }

        .jp-ChatWidget * {
          scroll-behavior: smooth;
        }
      `)));
};
exports.ChatComponent = ChatComponent;


/***/ }),

/***/ "./lib/ChatWidget/ConfigPanel.js":
/*!***************************************!*\
  !*** ./lib/ChatWidget/ConfigPanel.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConfigPanel = void 0;
// ConfigPanel.tsx
const react_1 = __importStar(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const ConfigPanel = ({ config, serverConfig, onConfigChange, onReset, isVisible, onToggleVisibility }) => {
    const [showApiKey, setShowApiKey] = react_1.useState(false);
    const handleModelServiceUrlChange = (e) => {
        onConfigChange({ modelServiceUrl: e.target.value });
    };
    const handleApiKeyChange = (e) => {
        onConfigChange({ apiKey: e.target.value });
    };
    const handleModelNameChange = (e) => {
        onConfigChange({ modelName: e.target.value });
    };
    // 重置为服务器默认值
    const handleReset = () => {
        if (!serverConfig)
            return;
        const resetConfig = {};
        // 重置服务地址
        if (serverConfig.ai_service_url) {
            resetConfig.modelServiceUrl = serverConfig.ai_service_url;
        }
        // 重置模型名称（如果有）
        if (serverConfig.model) {
            resetConfig.modelName = serverConfig.model;
        }
        // 重置 API Key（清空用户配置，使用服务器的）
        resetConfig.apiKey = serverConfig.api_key;
        onConfigChange(resetConfig);
    };
    // 如果没有显示，只显示一个简单的展开按钮
    if (!isVisible) {
        return (react_1.default.createElement("div", { style: {
                padding: '8px 12px',
                borderBottom: '1px solid var(--jp-border-color1)',
                background: 'var(--jp-layout-color1)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                cursor: 'pointer',
                height: '32px'
            }, onClick: onToggleVisibility, title: "\u5C55\u5F00\u914D\u7F6E\u9762\u677F" },
            react_1.default.createElement("div", { style: {
                    fontSize: '11px',
                    color: 'var(--jp-ui-font-color2)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                } },
                react_1.default.createElement("span", { style: { fontSize: '10px' } }, "\u25B6"),
                react_1.default.createElement("span", null, "\u914D\u7F6E"))));
    }
    return (react_1.default.createElement("div", { style: {
            padding: '12px',
            borderBottom: '1px solid var(--jp-border-color1)',
            background: 'var(--jp-layout-color1)'
        } },
        react_1.default.createElement("div", { style: {
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '12px'
            } },
            react_1.default.createElement("div", { style: {
                    fontSize: '12px',
                    color: 'var(--jp-ui-font-color0)',
                    fontWeight: 'bold'
                } }, "\u914D\u7F6E"),
            react_1.default.createElement("button", { onClick: onToggleVisibility, style: {
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--jp-ui-font-color2)',
                    fontSize: '10px',
                    cursor: 'pointer',
                    padding: '2px 8px'
                }, title: "\u6536\u8D77\u914D\u7F6E\u9762\u677F" }, "\u6536\u8D77 \u25B2")),
        react_1.default.createElement("div", { style: { marginBottom: '12px' } },
            react_1.default.createElement("div", { style: {
                    fontSize: '12px',
                    marginBottom: '4px',
                    color: 'var(--jp-ui-font-color1)'
                } }, "\u670D\u52A1\u5730\u5740"),
            react_1.default.createElement("input", { type: "text", value: config.modelServiceUrl, onChange: handleModelServiceUrlChange, style: {
                    width: '100%',
                    padding: '6px 8px',
                    border: '1px solid var(--jp-border-color1)',
                    borderRadius: '4px',
                    fontSize: '12px',
                    background: 'var(--jp-input-background)',
                    color: 'var(--jp-ui-font-color1)',
                    outline: 'none'
                }, placeholder: "http://localhost:8000/v1/chat/completions" })),
        react_1.default.createElement("div", { style: { marginBottom: '12px' } },
            react_1.default.createElement("div", { style: {
                    fontSize: '12px',
                    marginBottom: '4px',
                    color: 'var(--jp-ui-font-color1)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                } },
                react_1.default.createElement("span", null, "API \u5BC6\u94A5"),
                react_1.default.createElement("button", { onClick: () => setShowApiKey(!showApiKey), style: {
                        background: 'transparent',
                        border: '1px solid var(--jp-border-color2)',
                        color: 'var(--jp-ui-font-color2)',
                        borderRadius: '3px',
                        padding: '1px 6px',
                        fontSize: '9px',
                        cursor: 'pointer'
                    } }, showApiKey ? '隐藏' : '显示')),
            react_1.default.createElement("input", { type: showApiKey ? "text" : "password", value: config.apiKey, onChange: handleApiKeyChange, style: {
                    width: '100%',
                    padding: '6px 8px',
                    border: '1px solid var(--jp-border-color1)',
                    borderRadius: '4px',
                    fontSize: '12px',
                    background: 'var(--jp-input-background)',
                    color: 'var(--jp-ui-font-color1)',
                    outline: 'none'
                }, placeholder: "\u8F93\u5165 API \u5BC6\u94A5\uFF08\u53EF\u9009\uFF09" })),
        react_1.default.createElement("div", { style: { marginBottom: '12px' } },
            react_1.default.createElement("div", { style: {
                    fontSize: '12px',
                    marginBottom: '4px',
                    color: 'var(--jp-ui-font-color1)'
                } }, "\u6A21\u578B\u540D\u79F0"),
            react_1.default.createElement("input", { type: "text", value: config.modelName || '', onChange: handleModelNameChange, style: {
                    width: '100%',
                    padding: '6px 8px',
                    border: '1px solid var(--jp-border-color1)',
                    borderRadius: '4px',
                    fontSize: '12px',
                    background: 'var(--jp-input-background)',
                    color: 'var(--jp-ui-font-color1)',
                    outline: 'none'
                }, placeholder: "\u4F8B\u5982: gpt-3.5-turbo, gpt-4 \u7B49" })),
        serverConfig && (react_1.default.createElement("div", { style: {
                display: 'flex',
                justifyContent: 'flex-end',
                marginTop: '8px'
            } },
            react_1.default.createElement("button", { onClick: handleReset, style: {
                    background: 'var(--jp-layout-color2)',
                    border: '1px solid var(--jp-border-color2)',
                    color: 'var(--jp-ui-font-color2)',
                    borderRadius: '4px',
                    padding: '4px 12px',
                    fontSize: '11px',
                    cursor: 'pointer'
                }, title: "\u91CD\u7F6E\u4E3A\u670D\u52A1\u5668\u9ED8\u8BA4\u914D\u7F6E" }, "\u91CD\u7F6E")))));
};
exports.ConfigPanel = ConfigPanel;


/***/ }),

/***/ "./lib/ChatWidget/Header.js":
/*!**********************************!*\
  !*** ./lib/ChatWidget/Header.js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Header = void 0;
// Header.tsx
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const Header = ({ modelName, isLoading, onStop, onClear, onToggleConfig, isConfigVisible }) => {
    return (react_1.default.createElement("div", { style: {
            background: 'var(--jp-brand-color1)',
            color: 'white',
            padding: '8px 12px',
            display: 'flex',
            alignItems: 'center',
            borderBottom: '1px solid var(--jp-border-color1)',
            justifyContent: 'space-between'
        } },
        react_1.default.createElement("div", { style: { display: 'flex', alignItems: 'center' } },
            react_1.default.createElement("span", { style: { fontWeight: 'bold', fontSize: '14px', marginRight: '8px' } }, "\uD83E\uDD16 AI \u804A\u5929 (\u6D41\u5F0F\u8F93\u51FA)"),
            react_1.default.createElement("div", { style: {
                    background: 'rgba(255,255,255,0.2)',
                    padding: '2px 6px',
                    borderRadius: '8px',
                    fontSize: '11px',
                } }, modelName)),
        react_1.default.createElement("div", { style: { display: 'flex', gap: '8px', alignItems: 'center' } },
            isLoading && (react_1.default.createElement("button", { onClick: onStop, style: {
                    background: 'rgba(255,255,255,0.2)',
                    border: '1px solid rgba(255,255,255,0.3)',
                    color: 'white',
                    borderRadius: '4px',
                    padding: '2px 6px',
                    fontSize: '11px',
                    cursor: 'pointer'
                }, title: "\u505C\u6B62\u751F\u6210" }, "\u505C\u6B62")),
            react_1.default.createElement("button", { onClick: onClear, style: {
                    background: 'transparent',
                    border: '1px solid rgba(255,255,255,0.3)',
                    color: 'white',
                    borderRadius: '4px',
                    padding: '2px 6px',
                    fontSize: '11px',
                    cursor: 'pointer'
                }, title: "\u6E05\u7A7A\u5BF9\u8BDD" }, "\u6E05\u7A7A"))));
};
exports.Header = Header;


/***/ }),

/***/ "./lib/ChatWidget/InputArea.js":
/*!*************************************!*\
  !*** ./lib/ChatWidget/InputArea.js ***!
  \*************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InputArea = void 0;
// InputArea.tsx
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const InputArea = ({ value, isLoading, modelName, temperature, maxTokens, onChange, onSend, onKeyPress }) => {
    return (react_1.default.createElement("div", { style: {
            borderTop: '1px solid var(--jp-border-color1)',
            padding: '10px',
            background: 'var(--jp-layout-color1)'
        } },
        react_1.default.createElement("div", { style: {
                display: 'flex',
                alignItems: 'flex-end',
                gap: '6px'
            } },
            react_1.default.createElement("textarea", { style: {
                    flex: 1,
                    minHeight: '36px',
                    maxHeight: '100px',
                    padding: '6px 10px',
                    border: '1px solid var(--jp-border-color1)',
                    borderRadius: '4px',
                    background: 'var(--jp-input-background)',
                    color: 'var(--jp-ui-font-color1)',
                    fontFamily: 'inherit',
                    fontSize: '13px',
                    resize: 'vertical',
                    outline: 'none'
                }, placeholder: "\u8F93\u5165\u4F60\u7684\u95EE\u9898...", value: value, onChange: (e) => onChange(e.target.value), onKeyPress: onKeyPress, disabled: isLoading, rows: 1 }),
            react_1.default.createElement("button", { style: {
                    background: value.trim() && !isLoading
                        ? 'var(--jp-brand-color1)'
                        : 'var(--jp-layout-color3)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '6px 12px',
                    cursor: value.trim() && !isLoading ? 'pointer' : 'not-allowed',
                    height: '36px',
                    fontSize: '12px',
                    fontWeight: 'bold'
                }, onClick: onSend, disabled: !value.trim() || isLoading }, isLoading ? '生成中...' : '发送')),
        react_1.default.createElement("div", { style: {
                fontSize: '10px',
                color: 'var(--jp-ui-font-color2)',
                marginTop: '4px',
                textAlign: 'center'
            } },
            "\u6D41\u5F0F\u8F93\u51FA | \u6A21\u578B: ",
            modelName,
            " | \u6E29\u5EA6: ",
            temperature,
            " | \u6700\u5927\u957F\u5EA6: ",
            maxTokens)));
};
exports.InputArea = InputArea;


/***/ }),

/***/ "./lib/ChatWidget/MessageContent.js":
/*!******************************************!*\
  !*** ./lib/ChatWidget/MessageContent.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MessageContent = void 0;
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const MessageContent = ({ content, onInsertCode }) => {
    const handleInsertCode = (code, language) => {
        if (onInsertCode) {
            onInsertCode(code, language);
        }
    };
    // 渲染代码块
    const renderCodeBlock = (codeContent, language = 'text') => {
        return (react_1.default.createElement("div", { style: {
                position: 'relative',
                margin: '8px 0'
            } },
            onInsertCode && (react_1.default.createElement("button", { onClick: () => handleInsertCode(codeContent, language), style: {
                    position: 'absolute',
                    top: '4px',
                    right: '4px',
                    background: 'var(--jp-brand-color1)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '3px',
                    padding: '2px 6px',
                    fontSize: '10px',
                    cursor: 'pointer',
                    zIndex: 10
                }, title: "\u63D2\u5165\u5230Jupyter\u5355\u5143\u683C" }, "\u63D2\u5165\u4EE3\u7801")),
            react_1.default.createElement("pre", { style: {
                    background: 'var(--jp-code-cell-background)',
                    border: '1px solid var(--jp-border-color1)',
                    borderRadius: '4px',
                    padding: '8px',
                    overflowX: 'auto',
                    fontFamily: 'var(--jp-code-font-family)',
                    fontSize: 'var(--jp-code-font-size)',
                    lineHeight: 'var(--jp-code-line-height)',
                    margin: 0
                } },
                react_1.default.createElement("code", { style: {
                        color: 'var(--jp-content-font-color1)',
                        display: 'block'
                    } }, codeContent))));
    };
    // 渲染表格
    const renderTable = (tableContent) => {
        const lines = tableContent.split('\n').filter(line => line.trim());
        if (lines.length < 2)
            return null;
        try {
            const headers = lines[0]
                .split('|')
                .filter(cell => cell.trim() !== '')
                .map(header => header.trim());
            const rows = lines.slice(2) // 跳过表头和分隔线
                .map(line => line.split('|')
                .filter(cell => cell.trim() !== '')
                .map(cell => cell.trim()))
                .filter(row => row.length > 0);
            return (react_1.default.createElement("div", { style: {
                    overflowX: 'auto',
                    margin: '12px 0'
                } },
                react_1.default.createElement("table", { style: {
                        borderCollapse: 'collapse',
                        width: '100%',
                        minWidth: '400px',
                        border: '1px solid var(--jp-border-color1)',
                        fontSize: '12px'
                    } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", { style: { backgroundColor: 'var(--jp-layout-color2)' } }, headers.map((header, index) => (react_1.default.createElement("th", { key: index, style: {
                                border: '1px solid var(--jp-border-color1)',
                                padding: '8px 12px',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            } }, header))))),
                    react_1.default.createElement("tbody", null, rows.map((row, rowIndex) => (react_1.default.createElement("tr", { key: rowIndex, style: {
                            borderBottom: '1px solid var(--jp-border-color2)'
                        } }, row.map((cell, cellIndex) => (react_1.default.createElement("td", { key: cellIndex, style: {
                            border: '1px solid var(--jp-border-color1)',
                            padding: '8px 12px',
                            textAlign: 'left'
                        } }, cell))))))))));
        }
        catch (error) {
            console.error('表格渲染错误:', error);
            return react_1.default.createElement("div", { style: { whiteSpace: 'pre-wrap' } }, tableContent);
        }
    };
    // 主渲染函数
    const renderContent = () => {
        if (!content)
            return null;
        try {
            // 分割代码块和普通文本
            const parts = content.split(/(```[\s\S]*?```)/g);
            return parts.map((part, index) => {
                // 代码块
                if (part.startsWith('```') && part.endsWith('```')) {
                    const codeMatch = part.match(/```(\w+)?\n?([\s\S]*?)```/);
                    if (codeMatch) {
                        const language = codeMatch[1] || 'text';
                        const codeContent = codeMatch[2].trim();
                        return react_1.default.createElement("div", { key: index }, renderCodeBlock(codeContent, language));
                    }
                }
                // 表格检测
                const tableMatch = part.match(/(\|[^\n]+\|\r?\n\|[-:\s|]+\|\r?\n(?:\|[^\n]+\|\r?\n)*)/);
                if (tableMatch) {
                    return react_1.default.createElement("div", { key: index }, renderTable(tableMatch[0]));
                }
                // 普通文本
                return (react_1.default.createElement("div", { key: index, style: {
                        lineHeight: '1.5',
                        margin: '4px 0',
                        whiteSpace: 'pre-wrap'
                    } }, part));
            });
        }
        catch (error) {
            console.error('内容渲染错误:', error);
            return react_1.default.createElement("div", { style: { whiteSpace: 'pre-wrap' } }, content);
        }
    };
    return (react_1.default.createElement("div", { style: {
            lineHeight: '1.5',
            fontSize: '13px',
            fontFamily: 'var(--jp-ui-font-family)'
        } }, renderContent()));
};
exports.MessageContent = MessageContent;


/***/ }),

/***/ "./lib/ChatWidget/MessageItem.js":
/*!***************************************!*\
  !*** ./lib/ChatWidget/MessageItem.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MessageItem = void 0;
// MessageItem.tsx
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const MessageContent_1 = __webpack_require__(/*! ./MessageContent */ "./lib/ChatWidget/MessageContent.js");
const MessageItem = ({ message, isStreaming, onInsertCode }) => {
    const formatTime = (date) => {
        return date.toLocaleTimeString('zh-CN', {
            hour: '2-digit',
            minute: '2-digit'
        });
    };
    return (react_1.default.createElement("div", { style: {
            display: 'flex',
            flexDirection: message.sender === 'user' ? 'row-reverse' : 'row',
            alignItems: 'flex-start',
            marginBottom: '12px'
        } },
        react_1.default.createElement("div", { style: {
                width: '28px',
                height: '28px',
                borderRadius: '50%',
                background: message.sender === 'user'
                    ? 'var(--jp-brand-color1)'
                    : 'var(--jp-accent-color1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '12px',
                margin: message.sender === 'user' ? '0 0 0 6px' : '0 6px 0 0',
                flexShrink: 0
            } }, message.sender === 'user' ? '👤' : '🤖'),
        react_1.default.createElement("div", { style: {
                maxWidth: '85%',
                textAlign: message.sender === 'user' ? 'right' : 'left'
            } },
            react_1.default.createElement("div", { style: {
                    background: message.sender === 'user'
                        ? 'var(--jp-brand-color1)'
                        : 'var(--jp-layout-color2)',
                    color: message.sender === 'user'
                        ? 'white'
                        : 'var(--jp-ui-font-color1)',
                    padding: '6px 10px',
                    borderRadius: '12px',
                    border: '1px solid var(--jp-border-color1)',
                    wordBreak: 'break-word',
                    position: 'relative'
                } },
                react_1.default.createElement(MessageContent_1.MessageContent, { content: message.content, onInsertCode: onInsertCode }),
                isStreaming && (react_1.default.createElement("span", { style: {
                        display: 'inline-block',
                        width: '2px',
                        height: '1em',
                        background: 'var(--jp-ui-font-color1)',
                        marginLeft: '2px',
                        animation: 'blink 1s infinite'
                    } }))),
            react_1.default.createElement("div", { style: {
                    fontSize: '10px',
                    color: 'var(--jp-ui-font-color2)',
                    marginTop: '2px'
                } },
                formatTime(message.timestamp),
                isStreaming && ' · 生成中...'))));
};
exports.MessageItem = MessageItem;


/***/ }),

/***/ "./lib/ChatWidget/MessageList.js":
/*!***************************************!*\
  !*** ./lib/ChatWidget/MessageList.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MessageList = void 0;
// MessageList.tsx
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const MessageItem_1 = __webpack_require__(/*! ./MessageItem */ "./lib/ChatWidget/MessageItem.js");
const MessageList = ({ messages, isLoading, currentStreamingMessageId, onInsertCode, onScrollToBottom, shouldAutoScroll, messagesEndRef, messagesContainerRef }) => {
    return (react_1.default.createElement("div", { ref: messagesContainerRef, style: {
            flex: 1,
            overflow: 'auto',
            padding: '8px',
            background: 'var(--jp-layout-color0)',
            position: 'relative'
        } },
        messages.map((message) => (react_1.default.createElement(MessageItem_1.MessageItem, { key: message.id, message: message, isStreaming: currentStreamingMessageId === message.id, onInsertCode: onInsertCode }))),
        isLoading && !currentStreamingMessageId && (react_1.default.createElement("div", { style: {
                display: 'flex',
                alignItems: 'center',
                marginBottom: '12px'
            } },
            react_1.default.createElement("div", { style: {
                    width: '28px',
                    height: '28px',
                    borderRadius: '50%',
                    background: 'var(--jp-accent-color1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '12px',
                    marginRight: '6px',
                    flexShrink: 0
                } }, "\uD83E\uDD16"),
            react_1.default.createElement("div", { style: {
                    background: 'var(--jp-layout-color2)',
                    padding: '6px 10px',
                    borderRadius: '12px',
                    border: '1px solid var(--jp-border-color1)',
                    color: 'var(--jp-ui-font-color2)',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center'
                } },
                react_1.default.createElement("div", { style: {
                        width: '12px',
                        height: '12px',
                        border: '2px solid var(--jp-ui-font-color3)',
                        borderTop: '2px solid transparent',
                        borderRadius: '50%',
                        animation: 'spin 1s linear infinite',
                        marginRight: '6px'
                    } }),
                "AI\u6B63\u5728\u601D\u8003..."))),
        !shouldAutoScroll && (react_1.default.createElement("button", { onClick: onScrollToBottom, style: {
                position: 'sticky',
                bottom: '16px',
                left: '50%',
                transform: 'translateX(-50%)',
                background: 'var(--jp-brand-color1)',
                color: 'white',
                border: 'none',
                borderRadius: '20px',
                padding: '8px 16px',
                fontSize: '12px',
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                zIndex: 100,
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
            } },
            react_1.default.createElement("span", null, "\u2193"),
            "\u6709\u65B0\u6D88\u606F")),
        react_1.default.createElement("div", { ref: messagesEndRef })));
};
exports.MessageList = MessageList;


/***/ }),

/***/ "./lib/ChatWidget/hooks/useChat.js":
/*!*****************************************!*\
  !*** ./lib/ChatWidget/hooks/useChat.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useChat = void 0;
// hooks/useChat.ts
const react_1 = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
const services_1 = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
// 使用 ServerConnection 获取服务器配置
const fetchServerConfig = async () => {
    try {
        const settings = services_1.ServerConnection.makeSettings();
        const url = '/chat-toy/config';
        const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, url);
        console.log('使用 ServerConnection 获取服务器配置');
        console.log('基础URL:', settings.baseUrl);
        console.log('请求URL:', url);
        const response = await services_1.ServerConnection.makeRequest(requestUrl, { method: 'GET' }, settings);
        if (response.ok) {
            const config = await response.json();
            console.log('获取到的服务器配置:', config);
            return config;
        }
        else {
            console.warn('获取服务器配置失败:', response.status);
            return null;
        }
    }
    catch (error) {
        console.warn('获取服务器配置时出错:', error);
        return null;
    }
};
const useChat = () => {
    const [messages, setMessages] = react_1.useState([
        {
            id: 1,
            content: '你好！我是 AI 助手。现在通过 JupyterLab 扩展连接大模型服务，体验更佳。',
            sender: 'ai',
            timestamp: new Date(),
            type: 'text'
        }
    ]);
    const [config, setConfig] = react_1.useState({
        modelServiceUrl: '',
        jupyterExtensionUrl: '/chat-toy/v1/chat/completions',
        apiKey: '',
        modelName: 'gpt-3.5-turbo',
        customModelName: '',
        temperature: 0.7,
        maxTokens: 2000,
    });
    const [isLoading, setIsLoading] = react_1.useState(true);
    const [serverConfig, setServerConfig] = react_1.useState(null);
    // 保存配置到 localStorage
    const saveConfigToLocalStorage = (newConfig) => {
        try {
            localStorage.setItem('chat-config', JSON.stringify({
                modelServiceUrl: newConfig.modelServiceUrl,
                apiKey: newConfig.apiKey,
                modelName: newConfig.modelName,
                customModelName: newConfig.customModelName,
                temperature: newConfig.temperature,
                maxTokens: newConfig.maxTokens,
            }));
        }
        catch (error) {
            console.warn('无法保存配置到本地存储:', error);
        }
    };
    // 从 localStorage 加载配置
    const loadConfigFromLocalStorage = () => {
        try {
            const saved = localStorage.getItem('chat-config');
            if (saved) {
                return JSON.parse(saved);
            }
        }
        catch (error) {
            console.warn('无法从本地存储加载配置:', error);
        }
        return {};
    };
    // 初始化配置：优先级 1. localStorage 2. 服务器配置 3. 默认值
    const initializeConfig = async () => {
        setIsLoading(true);
        try {
            // 1. 获取服务器配置
            const serverConfig = await fetchServerConfig();
            setServerConfig(serverConfig);
            // 2. 从 localStorage 加载用户配置
            const savedConfig = loadConfigFromLocalStorage();
            // 3. 构建初始配置
            const initialConfig = {
                // 默认值
                modelServiceUrl: 'http://localhost:8000/v1',
                jupyterExtensionUrl: '/chat-toy/v1/chat/completions',
                apiKey: '',
                modelName: 'gpt-3.5-turbo',
                customModelName: '',
                temperature: 0.7,
                maxTokens: 2000,
            };
            // 应用服务器配置（如果存在）
            if (serverConfig) {
                initialConfig.modelServiceUrl = serverConfig.ai_service_url;
                initialConfig.apiKey = serverConfig.api_key;
                initialConfig.modelName = serverConfig.model;
                initialConfig.temperature = serverConfig.default_temperature;
                initialConfig.maxTokens = serverConfig.default_max_tokens;
                initialConfig.jupyterExtensionUrl = serverConfig.jupyter_extension_url;
            }
            // 应用 localStorage 中的用户配置（覆盖服务器配置）
            if (Object.keys(savedConfig).length > 0) {
                // 合并配置，用户配置优先级更高
                Object.assign(initialConfig, savedConfig);
            }
            setConfig(initialConfig);
        }
        catch (error) {
            console.error('初始化配置失败:', error);
        }
        finally {
            setIsLoading(false);
        }
    };
    // 初始化
    react_1.useEffect(() => {
        initializeConfig();
    }, []);
    const addMessage = (message) => {
        setMessages(prev => [...prev, message]);
    };
    const updateMessage = (messageId, content) => {
        setMessages(prev => prev.map(msg => msg.id === messageId
            ? { ...msg, content, timestamp: new Date() }
            : msg));
    };
    const clearMessages = () => {
        setMessages([
            {
                id: 1,
                content: '对话已清空。现在通过 JupyterLab 扩展连接大模型服务，体验更佳。',
                sender: 'ai',
                timestamp: new Date(),
                type: 'text'
            }
        ]);
    };
    const updateConfigPartial = (newConfig) => {
        setConfig(prev => {
            const updated = { ...prev, ...newConfig };
            // 保存到 localStorage
            saveConfigToLocalStorage(updated);
            return updated;
        });
    };
    const resetConfig = () => {
        // 重置为服务器配置
        if (serverConfig) {
            const defaultConfig = {
                modelServiceUrl: serverConfig.ai_service_url,
                jupyterExtensionUrl: serverConfig.jupyter_extension_url,
                apiKey: serverConfig.api_key,
                modelName: serverConfig.model,
                customModelName: '',
                temperature: serverConfig.default_temperature,
                maxTokens: serverConfig.default_max_tokens,
            };
            setConfig(defaultConfig);
            // 清除 localStorage 中的配置
            localStorage.removeItem('chat-config');
        }
    };
    const getActualModelName = () => {
        return config.modelName === 'custom' ? config.customModelName : config.modelName;
    };
    // 测试连接 - 使用 ServerConnection
    const testConnection = async () => {
        try {
            const settings = services_1.ServerConnection.makeSettings();
            const url = '/chat-toy/health';
            const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, url);
            const response = await services_1.ServerConnection.makeRequest(requestUrl, { method: 'GET' }, settings);
            if (response.ok) {
                const health = await response.json();
                console.log('JupyterLab扩展连接测试成功:', health);
                return health.status === 'healthy';
            }
            return false;
        }
        catch (error) {
            console.error('JupyterLab扩展连接测试失败:', error);
            return false;
        }
    };
    return {
        messages,
        config,
        serverConfig,
        isLoading,
        addMessage,
        updateMessage,
        clearMessages,
        updateConfig: updateConfigPartial,
        resetConfig,
        getActualModelName,
        testConnection,
        refreshConfig: initializeConfig,
    };
};
exports.useChat = useChat;


/***/ }),

/***/ "./lib/ChatWidget/hooks/useScroll.js":
/*!*******************************************!*\
  !*** ./lib/ChatWidget/hooks/useScroll.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useScroll = void 0;
// hooks/useScroll.ts
const react_1 = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
const useScroll = () => {
    const [shouldAutoScroll, setShouldAutoScroll] = react_1.useState(true);
    const messagesEndRef = react_1.useRef(null);
    const messagesContainerRef = react_1.useRef(null);
    const isMountedRef = react_1.useRef(true);
    react_1.useEffect(() => {
        return () => {
            isMountedRef.current = false;
        };
    }, []);
    const isUserAtBottom = react_1.useCallback(() => {
        if (!messagesContainerRef.current)
            return true;
        const container = messagesContainerRef.current;
        const threshold = 100;
        return container.scrollHeight - container.scrollTop - container.clientHeight <= threshold;
    }, []);
    const smartScrollToBottom = react_1.useCallback((behavior = 'smooth') => {
        if (!isMountedRef.current || !shouldAutoScroll)
            return;
        requestAnimationFrame(() => {
            if (messagesEndRef.current && isMountedRef.current) {
                messagesEndRef.current.scrollIntoView({
                    behavior,
                    block: 'nearest'
                });
            }
        });
    }, [shouldAutoScroll]);
    const handleMessagesScroll = react_1.useCallback(() => {
        if (!messagesContainerRef.current)
            return;
        const atBottom = isUserAtBottom();
        if (atBottom && !shouldAutoScroll) {
            setShouldAutoScroll(true);
        }
        else if (!atBottom && shouldAutoScroll) {
            setShouldAutoScroll(false);
        }
    }, [shouldAutoScroll, isUserAtBottom]);
    react_1.useEffect(() => {
        const container = messagesContainerRef.current;
        if (container) {
            container.addEventListener('scroll', handleMessagesScroll);
            return () => {
                container.removeEventListener('scroll', handleMessagesScroll);
            };
        }
    }, [handleMessagesScroll]);
    const scrollToBottomManually = () => {
        setShouldAutoScroll(true);
        smartScrollToBottom('smooth');
    };
    return {
        shouldAutoScroll,
        messagesEndRef,
        messagesContainerRef,
        smartScrollToBottom,
        scrollToBottomManually,
        handleMessagesScroll
    };
};
exports.useScroll = useScroll;


/***/ }),

/***/ "./lib/ChatWidget/hooks/useStreaming.js":
/*!**********************************************!*\
  !*** ./lib/ChatWidget/hooks/useStreaming.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.useStreaming = void 0;
// hooks/useStreaming.ts
const react_1 = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
const services_1 = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
const useStreaming = () => {
    const [isLoading, setIsLoading] = react_1.useState(false);
    const [currentStreamingMessageId, setCurrentStreamingMessageId] = react_1.useState(null);
    const abortControllerRef = react_1.useRef(null);
    const processStreamResponse = async (response, messageId, onUpdateMessage) => {
        var _a;
        const reader = (_a = response.body) === null || _a === void 0 ? void 0 : _a.getReader();
        const decoder = new TextDecoder();
        if (!reader) {
            throw new Error('No reader available for stream');
        }
        let accumulatedContent = '';
        let buffer = '';
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) {
                    break;
                }
                const chunk = decoder.decode(value, { stream: true });
                buffer += chunk;
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    const trimmedLine = line.trim();
                    if (trimmedLine === '')
                        continue;
                    if (trimmedLine === 'data: [DONE]') {
                        return;
                    }
                    if (trimmedLine.startsWith('data: ')) {
                        try {
                            const jsonData = trimmedLine.slice(6);
                            const parsed = JSON.parse(jsonData);
                            if (parsed.choices && parsed.choices[0].delta) {
                                const delta = parsed.choices[0].delta;
                                if (delta.content) {
                                    accumulatedContent += delta.content;
                                    onUpdateMessage(messageId, accumulatedContent);
                                }
                            }
                            else if (parsed.error) {
                                console.error('Stream error:', parsed.error);
                                throw new Error(parsed.error.message || 'Stream error');
                            }
                        }
                        catch (e) {
                            console.warn('Failed to parse stream data:', e, 'Data:', trimmedLine);
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
    };
    const streamToAI = async (params) => {
        var _a;
        abortControllerRef.current = new AbortController();
        try {
            setIsLoading(true);
            const newMessageId = Date.now() + 1;
            params.onNewMessage({
                id: newMessageId,
                content: '',
                sender: 'ai',
                timestamp: new Date(),
                type: 'text'
            });
            setCurrentStreamingMessageId(newMessageId);
            const actualModelName = params.config.modelName === 'custom'
                ? params.config.customModelName
                : params.config.modelName;
            // 构建请求体
            const requestBody = {
                model_service_url: params.config.modelServiceUrl,
                api_key: params.config.apiKey || '',
                model: actualModelName,
                messages: [
                    ...params.messages.slice(-10).map(m => ({
                        role: m.sender === 'user' ? 'user' : 'assistant',
                        content: m.content
                    })),
                    {
                        role: 'user',
                        content: params.message
                    }
                ],
                stream: true,
                temperature: params.config.temperature,
                max_tokens: params.config.maxTokens
            };
            console.log('=== 请求调试信息 ===');
            console.log('Jupyter扩展地址:', params.config.jupyterExtensionUrl);
            console.log('API Key 长度:', ((_a = params.config.apiKey) === null || _a === void 0 ? void 0 : _a.length) || 0);
            console.log('大模型服务地址:', params.config.modelServiceUrl);
            console.log('请求体:', requestBody);
            // 使用 ServerConnection 发送请求
            // 注意：路径应该是相对于 Jupyter 服务器的路径
            const settings = services_1.ServerConnection.makeSettings();
            // const url = new URL(params.config.jupyterExtensionUrl, settings.baseUrl);
            const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, params.config.jupyterExtensionUrl);
            console.log('使用 ServerConnection 发送请求');
            console.log('基础URL:', settings.baseUrl);
            console.log('完整URL:', requestUrl.toString());
            const response = await services_1.ServerConnection.makeRequest(requestUrl, {
                method: 'POST',
                body: JSON.stringify(requestBody),
                signal: abortControllerRef.current.signal,
            }, settings);
            console.log('响应状态:', response.status, response.statusText);
            if (!response.ok) {
                const errorText = await response.text();
                console.error('错误响应内容:', errorText);
                throw new Error(`HTTP ${response.status}: ${response.statusText}. ${errorText}`);
            }
            await processStreamResponse(response, newMessageId, params.onUpdateMessage);
        }
        catch (error) {
            if (error.name === 'AbortError') {
                console.log('请求已取消');
                return;
            }
            console.error('调用 AI 服务时出错:', error);
            params.onError(error);
        }
        finally {
            abortControllerRef.current = null;
            setCurrentStreamingMessageId(null);
            setIsLoading(false);
        }
    };
    const stopStreaming = () => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
        }
    };
    return {
        isLoading,
        currentStreamingMessageId,
        streamToAI,
        stopStreaming,
        setIsLoading
    };
};
exports.useStreaming = useStreaming;


/***/ }),

/***/ "./lib/ChatWidget/utils/constants.js":
/*!*******************************************!*\
  !*** ./lib/ChatWidget/utils/constants.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ERROR_MESSAGES = exports.API_ENDPOINTS = exports.CHAT_CONSTANTS = void 0;
// src/utils/constants.ts - 这是一个普通的常量文件，隐藏彩蛋在其中
exports.CHAT_CONSTANTS = {
    MAX_MESSAGES: 100,
    DEFAULT_TEMPERATURE: 0.7,
    DEFAULT_MAX_TOKENS: 2000,
    // 看起来像普通的默认值，实际上是彩蛋触发词的掩码
    DEFAULT_CONFIG: {
        model: 'gpt-3.5-turbo',
        // 触发词被分割隐藏在各个属性中
        triggerParts: ['show_', 'hidden', '_feature'],
        // 响应消息隐藏在看似无意义的数据中
        specialFlags: {
            debugMode: false,
            experimental: true,
            // 这里隐藏了响应内容
            metadata: 'c29tZV9zZWNyZXRfc3R1ZmY=' // Base64: "some_secret_stuff"
        }
    }
};
// 看起来像 API 配置
exports.API_ENDPOINTS = {
    CHAT: '/v1/chat/completions',
    MODELS: '/v1/models',
    // 这里隐藏另一个触发词片段
    VERSION: '1.0.0.egg'
};
// 看起来像错误消息模板
exports.ERROR_MESSAGES = {
    CONNECTION_FAILED: '无法连接到服务器',
    TIMEOUT: '请求超时',
    // 这里隐藏了彩蛋的显示逻辑
    SPECIAL_CODES: {
        777: '隐藏功能已激活',
        888: '恭喜发现彩蛋',
        // 这个数字是特殊的触发条件
        TRIGGER_NUMBER: 1314520
    }
};


/***/ }),

/***/ "./lib/ChatWidget/utils/easterEggHelper.js":
/*!*************************************************!*\
  !*** ./lib/ChatWidget/utils/easterEggHelper.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.eggcontent = exports.eggCheck = exports.checkSpecialInput = exports.getAppVersion = exports.formatError = exports.validateInput = void 0;
// src/utils/easterEggHelper.ts
const constants_1 = __webpack_require__(/*! ./constants */ "./lib/ChatWidget/utils/constants.js");
// 看起来像是一个普通的工具函数
const validateInput = (input) => {
    if (!input || input.trim() === '')
        return false;
    // 在这里隐藏彩蛋检查逻辑
    const eggTrigger = extractEggTrigger();
    const normalizedInput = input.toLowerCase().trim();
    // 检查是否是彩蛋触发词
    if (normalizedInput === eggTrigger) {
        return false; // 返回 false 表示不发送到后端
    }
    return true;
};
exports.validateInput = validateInput;
// 看起来像是一个字符串处理函数
const formatError = (error) => {
    if (typeof error === 'string')
        return error;
    // 这里隐藏彩蛋响应逻辑
    if ((error === null || error === void 0 ? void 0 : error.code) === constants_1.ERROR_MESSAGES.SPECIAL_CODES.TRIGGER_NUMBER) {
        return decodeEggMessage();
    }
    return error.message || '未知错误';
};
exports.formatError = formatError;
// 看起来像是一个配置处理函数
const getAppVersion = () => {
    const version = constants_1.API_ENDPOINTS.VERSION;
    // 这里隐藏了彩蛋的触发检查
    checkForEggInVersion(version);
    return version;
};
exports.getAppVersion = getAppVersion;
// ========== 私有函数（不在导出中，更难被发现）==========
const extractEggTrigger = () => {
    // 从多个地方组合出触发词
    const parts = constants_1.CHAT_CONSTANTS.DEFAULT_CONFIG.triggerParts;
    return parts.join('');
};
const decodeEggMessage = () => {
    try {
        // 从 base64 解码
        const base64 = constants_1.CHAT_CONSTANTS.DEFAULT_CONFIG.specialFlags.metadata;
        const decoded = atob(base64);
        // 进一步解码（简单的字符替换）
        return decoded.replace(/_/g, ' ').replace('stuff', 'feature');
    }
    catch (e) {
        return 'Something went wrong';
    }
};
const checkForEggInVersion = (version) => {
    // 版本号中的隐藏检查
    if (version.includes('egg')) {
        // 这里可以设置全局标记，但不做明显操作
        window.__hasEggFlag = true;
    }
};
// 看起来像是一个普通的验证函数，但实际上检查彩蛋
const checkSpecialInput = (input) => {
    const eggTrigger = extractEggTrigger();
    // 检查多个可能的触发方式
    const checks = [
        input.trim() === eggTrigger,
        input.trim() === eggTrigger.split('').reverse().join(''),
        input.includes('show') && input.includes('feature') && input.includes('hidden'),
        parseInt(input) === constants_1.ERROR_MESSAGES.SPECIAL_CODES.TRIGGER_NUMBER
    ];
    const isEgg = checks.some(check => check === true);
    if (isEgg) {
        return {
            isValid: false,
            isEgg: true,
            eggMessage: decodeEggMessage()
        };
    }
    return { isValid: true };
};
exports.checkSpecialInput = checkSpecialInput;
// 最简单的彩蛋检查
const eggCheck = (text) => {
    const triggers = [
        '使出【绝招】',
    ];
    return triggers.includes(text.trim().toLowerCase());
};
exports.eggCheck = eggCheck;
exports.eggcontent = `为你准备了几款绝招，请开心使用：\n 1、🥁爆裂鼓槌  \n 2、🔭沧野水管 \n 3、👿恶魔低语`;


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.chatIcon = void 0;
const ui_components_1 = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
// 简单的聊天图标 SVG
const chatIconSvg = `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
</svg>
`;
exports.chatIcon = new ui_components_1.LabIcon({
    name: 'jupyterlab-chat:chat',
    svgstr: chatIconSvg
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const application_1 = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
const apputils_1 = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
const launcher_1 = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
const settingregistry_1 = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
const notebook_1 = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
const icons_1 = __webpack_require__(/*! ./icons */ "./lib/icons.js");
const widget_1 = __webpack_require__(/*! ./widget */ "./lib/widget.js");
/**
 * The command IDs used by the chat plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.open = 'jupyterlab-chat:open';
})(CommandIDs || (CommandIDs = {}));
/**
 * Initialization data for the jupyterlab-chat extension.
 */
const plugin = {
    id: 'jupyterlab-chat:plugin',
    autoStart: true,
    requires: [apputils_1.ICommandPalette, notebook_1.INotebookTracker],
    optional: [launcher_1.ILauncher, application_1.ILayoutRestorer, settingregistry_1.ISettingRegistry],
    activate: (app, palette, notebookTracker, launcher, restorer, settingRegistry) => {
        const { commands, shell } = app;
        // Create a widget tracker for the left sidebar
        const tracker = new apputils_1.WidgetTracker({
            namespace: 'jupyterlab-chat-sidebar'
        });
        // Create the chat widget
        let chatWidget = null;
        // Add command to open chat in sidebar
        commands.addCommand(CommandIDs.open, {
            label: 'AI Chat',
            caption: 'Open AI Chat Interface in Sidebar',
            icon: icons_1.chatIcon,
            execute: () => {
                if (!chatWidget || chatWidget.isDisposed) {
                    // Create the chat widget if it doesn't exist
                    chatWidget = new widget_1.ChatWidget(notebookTracker);
                    chatWidget.id = 'jupyterlab-chat-sidebar';
                    chatWidget.title.label = 'AI Chat';
                    chatWidget.title.closable = true;
                    chatWidget.title.icon = icons_1.chatIcon;
                    // Add to tracker
                    tracker.add(chatWidget);
                    // Add to left sidebar
                    shell.add(chatWidget, 'left', { rank: 800 });
                }
                // Activate the widget
                shell.activateById(chatWidget.id);
            }
        });
        // Add to command palette
        palette.addItem({
            command: CommandIDs.open,
            category: 'AI'
        });
        // Add to launcher if available
        if (launcher) {
            launcher.add({
                command: CommandIDs.open,
                category: 'AI'
            });
        }
        // Restore widget state if restorer is available
        if (restorer) {
            restorer.restore(tracker, {
                command: CommandIDs.open,
                name: () => 'jupyterlab-chat-sidebar'
            });
        }
        // Load settings if available
        if (settingRegistry) {
            Promise.all([settingRegistry.load(plugin.id), app.restored])
                .then(([settings]) => {
                console.log('jupyterlab-chat settings loaded:', settings.composite);
            })
                .catch(reason => {
                console.warn('Failed to load settings for jupyterlab-chat, using defaults.', reason);
            });
        }
    }
};
exports["default"] = plugin;


/***/ }),

/***/ "./lib/utils/errorAnalyzer.js":
/*!************************************!*\
  !*** ./lib/utils/errorAnalyzer.js ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.detectCodeLanguage = exports.buildCodeExplanationPrompt = exports.handleExplainCommand = exports.debugCellStructure = exports.isErrorDetectionSupported = exports.handleFixCommand = exports.buildErrorAnalysisPrompt = exports.getCurrentCellCode = exports.getCurrentCellErrors = void 0;
// 安全地处理 outputs，确保它是数组
const safeGetOutputs = (cellModel) => {
    if (!cellModel || typeof cellModel !== 'object') {
        return [];
    }
    const outputs = cellModel.outputs;
    // 如果 outputs 不存在或为 null/undefined，返回空数组
    if (!outputs) {
        return [];
    }
    // 如果已经是数组，直接返回
    if (Array.isArray(outputs)) {
        return outputs;
    }
    // 尝试转换非数组对象为数组
    try {
        // 如果 outputs 有 toArray 方法（某些 Jupyter 版本）
        if (typeof outputs.toArray === 'function') {
            const arr = outputs.toArray();
            return Array.isArray(arr) ? arr : [];
        }
        // 如果 outputs 是类似数组的对象（有 length 属性）
        if (outputs.length !== undefined) {
            return Array.from(outputs);
        }
        // 如果 outputs 是单个对象，包装成数组
        if (typeof outputs === 'object') {
            return [outputs];
        }
    }
    catch (error) {
        console.error('Failed to convert outputs to array:', error);
    }
    return [];
};
// 获取当前活动单元格的错误信息 - 兼容 JupyterLab 3.2.9
const getCurrentCellErrors = (notebookTracker) => {
    if (!notebookTracker) {
        console.warn('Notebook tracker not available');
        return null;
    }
    const current = notebookTracker.currentWidget;
    if (!current) {
        console.warn('No active notebook found');
        return null;
    }
    const { content } = current;
    const activeCell = content.activeCell;
    if (!activeCell) {
        console.warn('No active cell found');
        return null;
    }
    const cellModel = activeCell.model;
    // 使用安全的 outputs 获取方法
    const outputs = safeGetOutputs(cellModel);
    console.log('Cell outputs:', outputs); // 调试信息
    if (outputs.length === 0) {
        return null;
    }
    const errors = [];
    outputs.forEach((output) => {
        try {
            // 处理错误输出
            if (output.output_type === 'error') {
                const error = {
                    ename: output.ename || 'UnknownError',
                    evalue: output.evalue || 'Unknown error occurred',
                    traceback: output.traceback || []
                };
                errors.push(error);
            }
            // 检查流输出中的错误
            if (output.output_type === 'stream' && output.name === 'stderr') {
                let errorText = '';
                if (Array.isArray(output.text)) {
                    errorText = output.text.join('');
                }
                else if (typeof output.text === 'string') {
                    errorText = output.text;
                }
                if (errorText.trim()) {
                    errors.push({
                        ename: 'StreamError',
                        evalue: errorText.trim(),
                        traceback: []
                    });
                }
            }
            // 检查 display_data 中的错误
            if (output.output_type === 'display_data' && output.data) {
                const textData = output.data['text/plain'] || output.data['text/html'];
                if (typeof textData === 'string' && (textData.includes('Error') || textData.includes('Exception'))) {
                    errors.push({
                        ename: 'DisplayError',
                        evalue: textData.substring(0, 500),
                        traceback: []
                    });
                }
            }
        }
        catch (error) {
            console.warn('Error processing cell output:', error, output);
        }
    });
    return errors.length > 0 ? errors : null;
};
exports.getCurrentCellErrors = getCurrentCellErrors;
// 获取当前单元格的代码内容 - 兼容 JupyterLab 3.2.9
const getCurrentCellCode = (notebookTracker) => {
    if (!notebookTracker)
        return null;
    const current = notebookTracker.currentWidget;
    if (!current)
        return null;
    const activeCell = current.content.activeCell;
    if (!activeCell || activeCell.model.type !== 'code')
        return null;
    const cellModel = activeCell.model;
    let code = '';
    try {
        // 方法1: value.text（旧版本）
        if (cellModel.value && cellModel.value.text !== undefined) {
            code = cellModel.value.text;
        }
        // 方法2: sharedModel.getSource() 或 sharedModel.source
        else if (cellModel.sharedModel) {
            if (typeof cellModel.sharedModel.getSource === 'function') {
                code = cellModel.sharedModel.getSource();
            }
            else if (cellModel.sharedModel.source !== undefined) {
                code = cellModel.sharedModel.source;
            }
        }
        // 方法3: 直接访问 source 属性
        else if (cellModel.source !== undefined) {
            code = typeof cellModel.source === 'string' ? cellModel.source : '';
        }
        // 方法4: 尝试其他可能的属性
        else if (cellModel.getSource && typeof cellModel.getSource === 'function') {
            code = cellModel.getSource();
        }
    }
    catch (error) {
        console.warn('Error getting cell code:', error);
    }
    return code || null;
};
exports.getCurrentCellCode = getCurrentCellCode;
// 构建错误分析提示词
const buildErrorAnalysisPrompt = (error, userContext, code) => {
    let prompt = `请帮我分析并解决以下Python代码错误：\n\n`;
    prompt += `错误类型：${error.ename}\n`;
    prompt += `错误信息：${error.evalue}\n\n`;
    if (error.traceback && error.traceback.length > 0) {
        prompt += `堆栈跟踪（最近的部分）：\n`;
        const recentTraceback = error.traceback.slice(-3);
        recentTraceback.forEach(line => {
            prompt += `${line}\n`;
        });
        prompt += '\n';
    }
    if (code) {
        prompt += `相关代码：\n\`\`\`python\n${code}\n\`\`\`\n\n`;
    }
    if (userContext) {
        prompt += `额外上下文：${userContext}\n\n`;
    }
    prompt += `请按以下格式回答：
1. 错误原因分析
2. 解决方案（步骤清晰）
3. 修复后的代码示例（如果有）
4. 预防类似错误的建议

如果错误信息不足，请告诉我需要哪些额外信息来进一步分析。`;
    return prompt;
};
exports.buildErrorAnalysisPrompt = buildErrorAnalysisPrompt;
// 处理 /fix 命令
const handleFixCommand = (notebookTracker, userInput) => {
    console.log('handleFixCommand called with input:', userInput); // 调试信息
    if (!userInput.trim().startsWith('/fix')) {
        return { shouldContinue: true };
    }
    // 获取额外上下文（/fix 后面的内容）
    const context = userInput.trim().substring(4).trim();
    // 检查是否有活动的 notebook
    if (!notebookTracker || !notebookTracker.currentWidget) {
        return {
            shouldContinue: false,
            error: '没有活动的Notebook。请先打开一个Notebook文件。'
        };
    }
    const current = notebookTracker.currentWidget;
    // 检查是否有活动的单元格
    if (!current.content.activeCell) {
        return {
            shouldContinue: false,
            error: '没有活动的单元格。请先点击一个代码单元格。'
        };
    }
    // 检查是否是代码单元格
    if (current.content.activeCell.model.type !== 'code') {
        return {
            shouldContinue: false,
            error: '当前单元格不是代码单元格。请选择一个代码单元格。'
        };
    }
    // 获取当前单元格的错误
    const errors = exports.getCurrentCellErrors(notebookTracker);
    console.log('Found errors:', errors); // 调试信息
    if (!errors || errors.length === 0) {
        // 尝试获取代码内容，看看是否有代码
        const code = exports.getCurrentCellCode(notebookTracker);
        if (code) {
            // 即使没有错误，用户也可能想分析代码
            const analysisPrompt = `请帮我分析以下Python代码，看看是否有潜在问题或改进建议：\n\n\`\`\`python\n${code}\n\`\`\`\n\n${context ? `额外上下文：${context}\n\n` : ''}请提供代码分析和改进建议。`;
            return {
                shouldContinue: false,
                analysisPrompt
            };
        }
        return {
            shouldContinue: false,
            error: '当前活动单元格没有错误信息。请先执行包含错误的代码单元格，并确保它处于活动状态。'
        };
    }
    // 使用第一个错误进行分析
    const primaryError = errors[0];
    const code = exports.getCurrentCellCode(notebookTracker);
    // 构建分析提示词
    const analysisPrompt = exports.buildErrorAnalysisPrompt(primaryError, context, code);
    return {
        shouldContinue: false,
        analysisPrompt
    };
};
exports.handleFixCommand = handleFixCommand;
// 添加一个辅助函数来检查是否支持错误检测
const isErrorDetectionSupported = (notebookTracker) => {
    if (!notebookTracker)
        return false;
    try {
        const current = notebookTracker.currentWidget;
        if (!current)
            return true; // 没有活动的notebook不代表不支持
        const activeCell = current.content.activeCell;
        if (!activeCell)
            return true;
        const cellModel = activeCell.model;
        // 尝试访问模型属性，但不要抛出错误
        if (cellModel.outputs !== undefined) {
            // 检查是否可迭代
            const outputs = cellModel.outputs;
            return outputs !== null && (Array.isArray(outputs) ||
                typeof outputs === 'object' && outputs.length !== undefined);
        }
        return false;
    }
    catch (error) {
        console.warn('Error detection compatibility check failed:', error);
        return false;
    }
};
exports.isErrorDetectionSupported = isErrorDetectionSupported;
// 添加调试函数，帮助了解单元格结构
const debugCellStructure = (notebookTracker) => {
    if (!notebookTracker || !notebookTracker.currentWidget)
        return null;
    const current = notebookTracker.currentWidget;
    if (!current.content.activeCell)
        return null;
    const cellModel = current.content.activeCell.model;
    // 返回单元格模型的结构信息（不包含实际内容）
    return {
        type: cellModel.type,
        hasOutputs: cellModel.outputs !== undefined,
        outputsType: typeof cellModel.outputs,
        outputsIsArray: Array.isArray(cellModel.outputs),
        outputsLength: cellModel.outputs ? (Array.isArray(cellModel.outputs) ? cellModel.outputs.length : 'not an array') : 0,
        hasValue: cellModel.value !== undefined,
        hasSharedModel: cellModel.sharedModel !== undefined,
        hasSource: cellModel.source !== undefined,
        keys: Object.keys(cellModel).filter(key => !key.startsWith('_'))
    };
};
exports.debugCellStructure = debugCellStructure;
// 处理 /explain 命令
const handleExplainCommand = (notebookTracker, userInput) => {
    console.log('handleExplainCommand called with input:', userInput);
    if (!userInput.trim().startsWith('/explain')) {
        return { shouldContinue: true };
    }
    // 获取额外上下文（/explain 后面的内容）
    const context = userInput.trim().substring(8).trim();
    // 检查是否有活动的 notebook
    if (!notebookTracker || !notebookTracker.currentWidget) {
        return {
            shouldContinue: false,
            error: '没有活动的Notebook。请先打开一个Notebook文件。'
        };
    }
    const current = notebookTracker.currentWidget;
    // 检查是否有活动的单元格
    if (!current.content.activeCell) {
        return {
            shouldContinue: false,
            error: '没有活动的单元格。请先点击一个代码单元格。'
        };
    }
    // 检查是否是代码单元格
    if (current.content.activeCell.model.type !== 'code') {
        return {
            shouldContinue: false,
            error: '当前单元格不是代码单元格。请选择一个代码单元格。'
        };
    }
    // 获取当前单元格的代码
    const code = exports.getCurrentCellCode(notebookTracker);
    if (!code || code.trim() === '') {
        return {
            shouldContinue: false,
            error: '当前单元格没有代码内容。请先编写一些代码。'
        };
    }
    // 构建代码解释提示词
    const explanationPrompt = exports.buildCodeExplanationPrompt(code, context);
    return {
        shouldContinue: false,
        explanationPrompt
    };
};
exports.handleExplainCommand = handleExplainCommand;
// 构建代码解释提示词
const buildCodeExplanationPrompt = (code, userContext, language = 'python') => {
    // 限制代码长度，避免提示词过长
    const maxCodeLength = 2000;
    const displayCode = code.length > maxCodeLength
        ? code.substring(0, maxCodeLength) + '\n...（代码过长，已截断）'
        : code;
    let prompt = `请帮我解释以下${language}代码的功能和逻辑：\n\n`;
    prompt += `代码：\n\`\`\`${language}\n${displayCode}\n\`\`\`\n\n`;
    if (userContext) {
        prompt += `额外上下文：${userContext}\n\n`;
    }
    prompt += `请按照以下结构详细解释：
1. 代码的主要功能
2. 关键函数/方法的作用
3. 代码逻辑流程（可以用步骤说明）
4. 输入和输出（如果有）
5. 潜在的改进建议或注意事项

如果代码有错误或不完整的部分，请指出来并提供修正建议。

请用中文回答，保持解释清晰易懂。`;
    return prompt;
};
exports.buildCodeExplanationPrompt = buildCodeExplanationPrompt;
// 检测代码语言（可选功能，用于更精确的语言识别）
const detectCodeLanguage = (code) => {
    // 简单的语言检测逻辑
    if (code.includes('import numpy') || code.includes('import pandas') ||
        code.includes('def ') || code.includes('class ') || code.includes('print(')) {
        return 'python';
    }
    if (code.includes('function ') || code.includes('const ') || code.includes('let ') ||
        code.includes('console.log') || code.includes('var ')) {
        return 'javascript';
    }
    if (code.includes('#include') || code.includes('int main') ||
        code.includes('printf') || code.includes('std::')) {
        return 'c/c++';
    }
    if (code.includes('import java.') || code.includes('public class') ||
        code.includes('System.out.println')) {
        return 'java';
    }
    // 默认返回 python
    return 'python';
};
exports.detectCodeLanguage = detectCodeLanguage;


/***/ }),

/***/ "./lib/widget.js":
/*!***********************!*\
  !*** ./lib/widget.js ***!
  \***********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChatWidget = void 0;
// widget.tsx
const react_1 = __importDefault(__webpack_require__(/*! react */ "webpack/sharing/consume/default/react"));
const apputils_1 = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
const ChatComponent_1 = __webpack_require__(/*! ./ChatWidget/ChatComponent */ "./lib/ChatWidget/ChatComponent.js");
class ChatWidget extends apputils_1.ReactWidget {
    constructor(notebookTracker) {
        super();
        this.notebookTracker = notebookTracker;
        this.id = 'ai-chat-widget';
        this.title.label = 'AI Chat';
        this.title.closable = true;
        this.addClass('jp-ChatWidget');
    }
    render() {
        return react_1.default.createElement(ChatComponent_1.ChatComponent, { notebookTracker: this.notebookTracker });
    }
}
exports.ChatWidget = ChatWidget;


/***/ })

}]);
//# sourceMappingURL=lib_index_js.202a0db170153129ede9.js.map