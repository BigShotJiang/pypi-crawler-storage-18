from setuptools import setup, find_packages
import os
import json

# 读取 package.json 获取版本信息
with open('package.json') as f:
    package_json = json.load(f)

version = package_json['version']
name = package_json['name'].replace('@', '').replace('/', '-')

# 获取所有需要包含的文件
data_files = []

# 包含 labextension 文件 - 这是正确的方式
labextension_path = "jupyterlab_chat_toy/labextension"
if os.path.exists(labextension_path):
    for root, dirs, files in os.walk(labextension_path):
        for file in files:
            file_path = os.path.join(root, file)
            # 相对于 labextension_path 的路径
            rel_path = os.path.relpath(root, labextension_path)
            if rel_path == '.':
                target_dir = f"share/jupyter/labextensions/{name}"
            else:
                target_dir = f"share/jupyter/labextensions/{name}/{rel_path}"
            
            data_files.append((target_dir, [file_path]))
#  数据文件配置
data_files += [
    # 服务器配置文件
    ("etc/jupyter/jupyter_server_config.d", [
        "jupyter_config/jupyter_server_config.d/jupyterlab_chat_toy.json"
    ]),
    # Notebook 配置文件（JupyterLab 3.x 需要）
    ("etc/jupyter/jupyter_notebook_config.d", [
        "jupyter_config/jupyter_notebook_config.d/jupyterlab_chat_toy.json"
    ]),
    # 共享数据目录
    ("share/jupyter/labextensions/jupyterlab-chat-toy", [
        "jupyterlab_chat_toy/labextension/package.json"
    ] + [
        os.path.join("jupyterlab_chat_toy/labextension", f)
        for f in os.listdir("jupyterlab_chat_toy/labextension")
        if f.endswith((".js", ".css", ".json", ".png", ".svg"))
    ]),
]

setup(
    name=name,
    version=version,
    description=package_json.get('description', 'JupyterLab Chat Extension'),
    author='ChandlerFan',
    author_email='411342747@qq.com',
    # 包含 Python 包
    packages=find_packages(),  # 自动发现所有包
    # 或者明确指定：
    # packages=['jupyterlab_chat'],
    include_package_data=True,
    data_files=data_files,
    install_requires=[
        'jupyterlab>=3.2.9,<4',
        "jupyter-server>=1.6.0,<2",
        "tornado>=6.0,<7",
        "traitlets>=4.0,<6",
        "aiohttp>=3.8.0",  # 添加 aiohttp 用于 HTTP 请求
    ],
    zip_safe=False,
    classifiers=[
        'Framework :: Jupyter',
        'Framework :: Jupyter :: JupyterLab',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'License :: OSI Approved :: BSD License',
    ],
    # 开发依赖（可选）
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-asyncio>=0.15.0",
            "black>=21.0",
            "flake8>=3.9",
        ],
        "ai": [
            "openai>=0.27.0",
            "requests>=2.25.0",
        ]
    },
    
    # 关键：JupyterLab 3.x 扩展入口点
    entry_points={
        # 服务器扩展入口点（必须）
        "jupyter_server_extension": [
            "jupyterlab_chat_toy = jupyterlab_chat_toy"
        ],
        # Notebook 扩展入口点（可选，为了兼容性）
        "notebook.server_extension": [
            "jupyterlab_chat_toy = jupyterlab_chat_toy"
        ],
        # JupyterLab 3.x 前端扩展
        "jupyterlab.extension": [
            "jupyterlab_chat_toy = jupyterlab_chat_toy.labextension"
        ]
    },
    
    # 数据文件配置
    # data_files=[
    #     # 服务器配置文件
    #     ("etc/jupyter/jupyter_server_config.d", [
    #         "jupyter_config/jupyter_server_config.d/jupyterlab_chat_toy.json"
    #     ]),
    #     # Notebook 配置文件（JupyterLab 3.x 需要）
    #     ("etc/jupyter/jupyter_notebook_config.d", [
    #         "jupyter_config/jupyter_notebook_config.d/jupyterlab_chat_toy.json"
    #     ]),
    #     # 共享数据目录
    #     ("share/jupyter/labextensions/jupyterlab-chat-toy", [
    #         "jupyterlab_chat_toy/labextension/package.json"
    #     ] + [
    #         os.path.join("jupyterlab_chat_toy/labextension", f)
    #         for f in os.listdir("jupyterlab_chat_toy/labextension")
    #         if f.endswith((".js", ".css", ".json", ".png", ".svg"))
    #     ]),
    # ],
    python_requires='>=3.6',
    keywords=['jupyter', 'jupyterlab', 'jupyterlab-extension', 'chat'],
)