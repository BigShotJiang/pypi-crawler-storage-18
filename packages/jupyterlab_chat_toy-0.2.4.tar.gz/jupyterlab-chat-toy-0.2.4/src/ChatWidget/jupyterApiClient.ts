// services/jupyterApiClient.ts
export class JupyterApiClient {
  private baseUrl: string;
  private xsrfToken: string | null = null;
  
  constructor() {
    this.baseUrl = this.getBaseUrl();
    this.xsrfToken = this.getXSRFToken();
  }
  
  private getBaseUrl(): string {
    // 尝试从 JupyterLab 配置获取
    if (typeof window !== 'undefined') {
      // 方法1：从 window.Jupyter 获取
      if ((window as any).Jupyter) {
        return (window as any).Jupyter.notebook.base_url || '/';
      }
      
      // 方法2：从 PageConfig 获取（如果是 JupyterLab 扩展）
      if ((window as any).require) {
        try {
          const PageConfig = (window as any).require('@jupyterlab/coreutils').PageConfig;
          return PageConfig.getBaseUrl();
        } catch (e) {
          console.warn('无法加载 PageConfig:', e);
        }
      }
      
      // 方法3：从当前 URL 推断
      const pathParts = window.location.pathname.split('/');
      if (pathParts.length > 1) {
        // 如果是 JupyterLab，通常路径是 /lab 或 /user/username/lab
        const labIndex = pathParts.findIndex(part => part === 'lab');
        if (labIndex > 0) {
          return pathParts.slice(0, labIndex).join('/') + '/';
        }
      }
    }
    
    return '/';
  }
  
  private getXSRFToken(): string | null {
    if (typeof document === 'undefined') return null;
    
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
      const [name, value] = cookie.trim().split('=');
      if (name === '_xsrf') {
        return decodeURIComponent(value);
      }
    }
    return null;
  }
  
  private getAuthToken(): string | null {
    if (typeof window === 'undefined') return null;
    
    // 从 URL 参数获取 token
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('token');
  }
  
  private async makeRequest(url: string, options: RequestInit = {}): Promise<Response> {
    // 确保 URL 正确
    const fullUrl = url.startsWith('http') 
      ? url 
      : `${this.baseUrl.replace(/\/$/, '')}/${url.replace(/^\//, '')}`;
    
    // 添加默认头
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    } as Record<string, string>;
    
    // 添加 XSRF Token
    if (this.xsrfToken) {
      headers['X-XSRFToken'] = this.xsrfToken;
    }
    
    // 添加认证 Token
    const authToken = this.getAuthToken();
    if (authToken) {
      headers['Authorization'] = `Token ${authToken}`;
    }
    
    const response = await fetch(fullUrl, {
      ...options,
      headers,
      credentials: 'same-origin' // 重要：发送 cookie
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText}. ${errorText}`);
    }
    
    return response;
  }
  
  async chatCompletion(requestBody: any, stream: boolean = false): Promise<Response> {
    return this.makeRequest('chat-toy/v1/chat/completions', {
      method: 'POST',
      body: JSON.stringify({
        ...requestBody,
        stream
      })
    });
  }
  
  async getHealth(): Promise<any> {
    const response = await this.makeRequest('chat-toy/health');
    return response.json();
  }
  
  async getConfig(): Promise<any> {
    const response = await this.makeRequest('chat-toy/config');
    return response.json();
  }
}

// 全局实例
export const jupyterApiClient = new JupyterApiClient();