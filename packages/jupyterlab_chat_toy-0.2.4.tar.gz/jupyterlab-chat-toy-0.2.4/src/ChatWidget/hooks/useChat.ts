// hooks/useChat.ts
import { useState, useEffect } from 'react';
import { ServerConnection } from '@jupyterlab/services';
import { Message, ChatConfig, ServerConfig } from '../types';
import { jupyterApiClient } from '../jupyterApiClient';
import { URLExt } from '@jupyterlab/coreutils';

// 使用 ServerConnection 获取服务器配置
const fetchServerConfig = async (): Promise<ServerConfig | null> => {
  try {
    const settings = ServerConnection.makeSettings();
    const url = '/chat-toy/config';
    const requestUrl = URLExt.join(settings.baseUrl, url);

    console.log('使用 ServerConnection 获取服务器配置');
    console.log('基础URL:', settings.baseUrl);
    console.log('请求URL:', url);

    const response = await ServerConnection.makeRequest(
      requestUrl,
      { method: 'GET' },
      settings
    );
    
    if (response.ok) {
      const config = await response.json();
      console.log('获取到的服务器配置:', config);
      return config;
    } else {
      console.warn('获取服务器配置失败:', response.status);
      return null;
    }
  } catch (error) {
    console.warn('获取服务器配置时出错:', error);
    return null;
  }
};

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content: '你好！我是 AI 助手。现在通过 JupyterLab 扩展连接大模型服务，体验更佳。',
      sender: 'ai',
      timestamp: new Date(),
      type: 'text'
    }
  ]);
  
  const [config, setConfig] = useState<ChatConfig>({
    modelServiceUrl: '',
    jupyterExtensionUrl: '/chat-toy/v1/chat/completions',
    apiKey: '',
    modelName: 'gpt-3.5-turbo',
    customModelName: '',
    temperature: 0.7,
    maxTokens: 2000,
  });

  const [isLoading, setIsLoading] = useState(true);
  const [serverConfig, setServerConfig] = useState<ServerConfig | null>(null);

  // 保存配置到 localStorage
  const saveConfigToLocalStorage = (newConfig: ChatConfig) => {
    try {
      localStorage.setItem('chat-config', JSON.stringify({
        modelServiceUrl: newConfig.modelServiceUrl,
        apiKey: newConfig.apiKey,
        modelName: newConfig.modelName,
        customModelName: newConfig.customModelName,
        temperature: newConfig.temperature,
        maxTokens: newConfig.maxTokens,
      }));
    } catch (error) {
      console.warn('无法保存配置到本地存储:', error);
    }
  };

  // 从 localStorage 加载配置
  const loadConfigFromLocalStorage = (): Partial<ChatConfig> => {
    try {
      const saved = localStorage.getItem('chat-config');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (error) {
      console.warn('无法从本地存储加载配置:', error);
    }
    return {};
  };

  // 初始化配置：优先级 1. localStorage 2. 服务器配置 3. 默认值
  const initializeConfig = async () => {
    setIsLoading(true);
    
    try {
      // 1. 获取服务器配置
      const serverConfig = await fetchServerConfig();
      setServerConfig(serverConfig);
      
      // 2. 从 localStorage 加载用户配置
      const savedConfig = loadConfigFromLocalStorage();
      
      // 3. 构建初始配置
      const initialConfig: ChatConfig = {
        // 默认值
        modelServiceUrl: 'http://localhost:8000/v1',
        jupyterExtensionUrl: '/chat-toy/v1/chat/completions',
        apiKey: '',
        modelName: 'gpt-3.5-turbo',
        customModelName: '',
        temperature: 0.7,
        maxTokens: 2000,
      };
      
      // 应用服务器配置（如果存在）
      if (serverConfig) {
        initialConfig.modelServiceUrl = serverConfig.ai_service_url;
        initialConfig.apiKey = serverConfig.api_key;
        initialConfig.modelName = serverConfig.model;
        initialConfig.temperature = serverConfig.default_temperature;
        initialConfig.maxTokens = serverConfig.default_max_tokens;
        initialConfig.jupyterExtensionUrl = serverConfig.jupyter_extension_url;
      }
      
      // 应用 localStorage 中的用户配置（覆盖服务器配置）
      if (Object.keys(savedConfig).length > 0) {
        // 合并配置，用户配置优先级更高
        Object.assign(initialConfig, savedConfig);
      }
      
      setConfig(initialConfig);
      
    } catch (error) {
      console.error('初始化配置失败:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // 初始化
  useEffect(() => {
    initializeConfig();
  }, []);

  const addMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };

  const updateMessage = (messageId: number, content: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId 
        ? { ...msg, content, timestamp: new Date() }
        : msg
    ));
  };

  const clearMessages = () => {
    setMessages([
      {
        id: 1,
        content: '对话已清空。现在通过 JupyterLab 扩展连接大模型服务，体验更佳。',
        sender: 'ai',
        timestamp: new Date(),
        type: 'text'
      }
    ]);
  };

  const updateConfigPartial = (newConfig: Partial<ChatConfig>) => {
    setConfig(prev => {
      const updated = { ...prev, ...newConfig };
      // 保存到 localStorage
      saveConfigToLocalStorage(updated);
      return updated;
    });
  };

  const resetConfig = () => {
    // 重置为服务器配置
    if (serverConfig) {
      const defaultConfig: ChatConfig = {
        modelServiceUrl: serverConfig.ai_service_url,
        jupyterExtensionUrl: serverConfig.jupyter_extension_url,
        apiKey: serverConfig.api_key, // 清空 API Key，让用户重新输入
        modelName: serverConfig.model,
        customModelName: '',
        temperature: serverConfig.default_temperature,
        maxTokens: serverConfig.default_max_tokens,
      };
      
      setConfig(defaultConfig);
      // 清除 localStorage 中的配置
      localStorage.removeItem('chat-config');
    }
  };

  const getActualModelName = () => {
    return config.modelName === 'custom' ? config.customModelName : config.modelName;
  };

  // 测试连接 - 使用 ServerConnection
  const testConnection = async (): Promise<boolean> => {
    try {
      const settings = ServerConnection.makeSettings();
      const url = '/chat-toy/health';
      const requestUrl = URLExt.join(settings.baseUrl, url);

      const response = await ServerConnection.makeRequest(
        requestUrl,
        { method: 'GET' },
        settings
      );
      
      if (response.ok) {
        const health = await response.json();
        console.log('JupyterLab扩展连接测试成功:', health);
        return health.status === 'healthy';
      }
      return false;
    } catch (error) {
      console.error('JupyterLab扩展连接测试失败:', error);
      return false;
    }
  };

  return {
    messages,
    config,
    serverConfig,
    isLoading,
    addMessage,
    updateMessage,
    clearMessages,
    updateConfig: updateConfigPartial,
    resetConfig,
    getActualModelName,
    testConnection,
    refreshConfig: initializeConfig, // 重新加载配置
  };
};