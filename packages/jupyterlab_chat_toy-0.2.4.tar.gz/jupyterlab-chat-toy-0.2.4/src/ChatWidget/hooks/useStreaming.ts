// hooks/useStreaming.ts
import { useState, useRef } from 'react';
import { ServerConnection } from '@jupyterlab/services';
import { StreamingParams } from '../types';
import { URLExt } from '@jupyterlab/coreutils';

export const useStreaming = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [currentStreamingMessageId, setCurrentStreamingMessageId] = useState<number | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const processStreamResponse = async (
    response: Response, 
    messageId: number,
    onUpdateMessage: (messageId: number, content: string) => void
  ): Promise<void> => {
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    
    if (!reader) {
      throw new Error('No reader available for stream');
    }

    let accumulatedContent = '';
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        
        if (done) {
          break;
        }

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;

        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          
          if (trimmedLine === '') continue;
          if (trimmedLine === 'data: [DONE]') {
            return;
          }

          if (trimmedLine.startsWith('data: ')) {
            try {
              const jsonData = trimmedLine.slice(6);
              const parsed = JSON.parse(jsonData);
              
              if (parsed.choices && parsed.choices[0].delta) {
                const delta = parsed.choices[0].delta;
                
                if (delta.content) {
                  accumulatedContent += delta.content;
                  onUpdateMessage(messageId, accumulatedContent);
                }
              } else if (parsed.error) {
                console.error('Stream error:', parsed.error);
                throw new Error(parsed.error.message || 'Stream error');
              }
            } catch (e) {
              console.warn('Failed to parse stream data:', e, 'Data:', trimmedLine);
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  };

  const streamToAI = async (params: StreamingParams): Promise<void> => {
    abortControllerRef.current = new AbortController();
    
    try {
      setIsLoading(true);

      const newMessageId = Date.now() + 1;
      params.onNewMessage({
        id: newMessageId,
        content: '',
        sender: 'ai',
        timestamp: new Date(),
        type: 'text'
      });
      
      setCurrentStreamingMessageId(newMessageId);

      const actualModelName = params.config.modelName === 'custom' 
        ? params.config.customModelName 
        : params.config.modelName;
      
      // 构建请求体
      const requestBody = {
        model_service_url: params.config.modelServiceUrl,
        api_key: params.config.apiKey || '',
        model: actualModelName,
        messages: [
          ...params.messages.slice(-10).map(m => ({
            role: m.sender === 'user' ? 'user' : 'assistant',
            content: m.content
          })),
          {
            role: 'user',
            content: params.message
          }
        ],
        stream: true,
        temperature: params.config.temperature,
        max_tokens: params.config.maxTokens
      };

      console.log('=== 请求调试信息 ===');
      console.log('Jupyter扩展地址:', params.config.jupyterExtensionUrl);
      console.log('API Key 长度:', params.config.apiKey?.length || 0);
      console.log('大模型服务地址:', params.config.modelServiceUrl);
      console.log('请求体:', requestBody);

      // 使用 ServerConnection 发送请求
      // 注意：路径应该是相对于 Jupyter 服务器的路径
      const settings = ServerConnection.makeSettings();
      // const url = new URL(params.config.jupyterExtensionUrl, settings.baseUrl);
      const requestUrl = URLExt.join(settings.baseUrl, params.config.jupyterExtensionUrl);

      console.log('使用 ServerConnection 发送请求');
      console.log('基础URL:', settings.baseUrl);
      console.log('完整URL:', requestUrl.toString());

      const response = await ServerConnection.makeRequest(
        requestUrl,
        {
          method: 'POST',
          body: JSON.stringify(requestBody),
          signal: abortControllerRef.current.signal,
        },
        settings
      );

      console.log('响应状态:', response.status, response.statusText);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('错误响应内容:', errorText);
        throw new Error(`HTTP ${response.status}: ${response.statusText}. ${errorText}`);
      }

      await processStreamResponse(response, newMessageId, params.onUpdateMessage);
      
    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log('请求已取消');
        return;
      }
      console.error('调用 AI 服务时出错:', error);
      params.onError(error);
    } finally {
      abortControllerRef.current = null;
      setCurrentStreamingMessageId(null);
      setIsLoading(false);
    }
  };

  const stopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  return {
    isLoading,
    currentStreamingMessageId,
    streamToAI,
    stopStreaming,
    setIsLoading
  };
};