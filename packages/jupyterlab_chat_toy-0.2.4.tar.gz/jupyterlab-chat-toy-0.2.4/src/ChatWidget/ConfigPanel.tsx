// ConfigPanel.tsx
import React, { useState } from 'react';
import { ConfigPanelProps, ServerConfig } from './types';

export const ConfigPanel: React.FC<ConfigPanelProps> = ({ 
  config, 
  serverConfig,
  onConfigChange, 
  onReset,
  isVisible,
  onToggleVisibility 
}) => {
  const [showApiKey, setShowApiKey] = useState(false);

  const handleModelServiceUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onConfigChange({ modelServiceUrl: e.target.value });
  };

  const handleApiKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onConfigChange({ apiKey: e.target.value });
  };

  const handleModelNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onConfigChange({ modelName: e.target.value });
  };

  // 重置为服务器默认值
  const handleReset = () => {
    if (!serverConfig) return;
    
    const resetConfig: any = {};
    
    // 重置服务地址
    if (serverConfig.ai_service_url) {
      resetConfig.modelServiceUrl = serverConfig.ai_service_url;
    }
    
    // 重置模型名称（如果有）
    if (serverConfig.model) {
      resetConfig.modelName = serverConfig.model;
    }
    
    // 重置 API Key（清空用户配置，使用服务器的）
    resetConfig.apiKey = serverConfig.api_key;
    
    onConfigChange(resetConfig);
  };

  // 如果没有显示，只显示一个简单的展开按钮
  if (!isVisible) {
    return (
      <div style={{
        padding: '8px 12px',
        borderBottom: '1px solid var(--jp-border-color1)',
        background: 'var(--jp-layout-color1)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        cursor: 'pointer',
        height: '32px'
      }}
      onClick={onToggleVisibility}
      title="展开配置面板"
      >
        <div style={{ 
          fontSize: '11px', 
          color: 'var(--jp-ui-font-color2)',
          display: 'flex',
          alignItems: 'center',
          gap: '6px'
        }}>
          <span style={{ fontSize: '10px' }}>▶</span>
          <span>配置</span>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      padding: '12px',
      borderBottom: '1px solid var(--jp-border-color1)',
      background: 'var(--jp-layout-color1)'
    }}>
      {/* 面板标题栏 */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '12px'
      }}>
        <div style={{ 
          fontSize: '12px', 
          color: 'var(--jp-ui-font-color0)',
          fontWeight: 'bold'
        }}>
          配置
        </div>
        <button
          onClick={onToggleVisibility}
          style={{
            background: 'transparent',
            border: 'none',
            color: 'var(--jp-ui-font-color2)',
            fontSize: '10px',
            cursor: 'pointer',
            padding: '2px 8px'
          }}
          title="收起配置面板"
        >
          收起 ▲
        </button>
      </div>

      {/* 模型服务地址 */}
      <div style={{ marginBottom: '12px' }}>
        <div style={{ 
          fontSize: '12px', 
          marginBottom: '4px', 
          color: 'var(--jp-ui-font-color1)'
        }}>
          服务地址
        </div>
        <input
          type="text"
          value={config.modelServiceUrl}
          onChange={handleModelServiceUrlChange}
          style={{
            width: '100%',
            padding: '6px 8px',
            border: '1px solid var(--jp-border-color1)',
            borderRadius: '4px',
            fontSize: '12px',
            background: 'var(--jp-input-background)',
            color: 'var(--jp-ui-font-color1)',
            outline: 'none'
          }}
          placeholder="http://localhost:8000/v1/chat/completions"
        />
      </div>

      {/* API Key 配置 */}
      <div style={{ marginBottom: '12px' }}>
        <div style={{ 
          fontSize: '12px', 
          marginBottom: '4px', 
          color: 'var(--jp-ui-font-color1)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <span>API 密钥</span>
          <button
            onClick={() => setShowApiKey(!showApiKey)}
            style={{
              background: 'transparent',
              border: '1px solid var(--jp-border-color2)',
              color: 'var(--jp-ui-font-color2)',
              borderRadius: '3px',
              padding: '1px 6px',
              fontSize: '9px',
              cursor: 'pointer'
            }}
          >
            {showApiKey ? '隐藏' : '显示'}
          </button>
        </div>
        <input
          type={showApiKey ? "text" : "password"}
          value={config.apiKey}
          onChange={handleApiKeyChange}
          style={{
            width: '100%',
            padding: '6px 8px',
            border: '1px solid var(--jp-border-color1)',
            borderRadius: '4px',
            fontSize: '12px',
            background: 'var(--jp-input-background)',
            color: 'var(--jp-ui-font-color1)',
            outline: 'none'
          }}
          placeholder="输入 API 密钥（可选）"
        />
      </div>

      {/* 模型名称输入框 */}
      <div style={{ marginBottom: '12px' }}>
        <div style={{ 
          fontSize: '12px', 
          marginBottom: '4px', 
          color: 'var(--jp-ui-font-color1)'
        }}>
          模型名称
        </div>
        <input
          type="text"
          value={config.modelName || ''}
          onChange={handleModelNameChange}
          style={{
            width: '100%',
            padding: '6px 8px',
            border: '1px solid var(--jp-border-color1)',
            borderRadius: '4px',
            fontSize: '12px',
            background: 'var(--jp-input-background)',
            color: 'var(--jp-ui-font-color1)',
            outline: 'none'
          }}
          placeholder="例如: gpt-3.5-turbo, gpt-4 等"
        />
      </div>

      {/* 操作按钮 */}
      {serverConfig && (
        <div style={{ 
          display: 'flex', 
          justifyContent: 'flex-end',
          marginTop: '8px'
        }}>
          <button
            onClick={handleReset}
            style={{
              background: 'var(--jp-layout-color2)',
              border: '1px solid var(--jp-border-color2)',
              color: 'var(--jp-ui-font-color2)',
              borderRadius: '4px',
              padding: '4px 12px',
              fontSize: '11px',
              cursor: 'pointer'
            }}
            title="重置为服务器默认配置"
          >
            重置
          </button>
        </div>
      )}
    </div>
  );
};