// types.ts
import { INotebookTracker } from '@jupyterlab/notebook';

export interface Message {
  id: number;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type: 'text' | 'code';
  language?: string;
}

export interface ChatConfig {
  // 大模型服务地址
  modelServiceUrl: string;
  // JupyterLab扩展地址（固定）
  jupyterExtensionUrl: string;
  // API Key（前端配置）
  apiKey: string;
  modelName: string;
  customModelName: string;
  temperature: number;
  maxTokens: number;
}

export interface ServerConfig {
  // 服务器返回的配置信息
  // model_service_url: string;
  ai_service_url?:string;
  api_key: string;  // 脱敏后的
  default_model: string;
  model:string;
  custom_model_name?: string; // 添加这个字段
  default_temperature: number;
  default_max_tokens: number;
  enable_streaming: boolean;
  openai_compatible: boolean;
  api_endpoint: string;
  jupyter_extension_url: string;
  config_source: string;
  server_config: {
    has_api_key: boolean;
    api_key_masked: string;
    model_service_url: string;
  };
}

export interface ModelOption {
  value: string;
  label: string;
}

export interface ChatComponentProps {
  notebookTracker: INotebookTracker | null;
}

export interface HeaderProps {
  modelName: string;
  isLoading: boolean;
  onStop: () => void;
  onClear: () => void;
}

export interface ConfigPanelProps {
  config: ChatConfig;
  serverConfig?: ServerConfig | null;  // 添加 serverConfig 属性
  modelOptions: ModelOption[];
  onConfigChange: (newConfig: Partial<ChatConfig>) => void;
  onReset: () => void;
  isVisible: boolean;
  onToggleVisibility: () => void;
}

export interface MessageItemProps {
  message: Message;
  isStreaming: boolean;
  onInsertCode: (code: string, language: string) => void;
}

export interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  currentStreamingMessageId: number | null;
  onInsertCode: (code: string, language: string) => void;
  onScrollToBottom: () => void;
  shouldAutoScroll: boolean;
  messagesEndRef: React.RefObject<HTMLDivElement>;
  messagesContainerRef: React.RefObject<HTMLDivElement>;
}

export interface InputAreaProps {
  value: string;
  isLoading: boolean;
  modelName: string;
  temperature: number;
  maxTokens: number;
  onChange: (value: string) => void;
  onSend: () => void;
  onKeyPress: (e: React.KeyboardEvent) => void;
}

export interface StreamingParams {
  message: string;
  messages: Message[];
  config: ChatConfig;
  onNewMessage: (message: Message) => void;
  onUpdateMessage: (messageId: number, content: string) => void;
  onStreamingStart: (messageId: number) => void;
  onStreamingEnd: () => void;
  onError: (error: Error) => void;
}


export interface HeaderProps {
  modelName: string;
  isLoading: boolean;
  onStop: () => void;
  onClear: () => void;
  onToggleConfig: () => void; // 新增：切换配置面板回调
  isConfigVisible: boolean; // 新增：配置面板是否可见
}
