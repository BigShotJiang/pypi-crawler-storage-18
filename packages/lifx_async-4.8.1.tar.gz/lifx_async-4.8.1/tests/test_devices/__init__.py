"""Tests for device classes."""
