Copier Super Important Project
==============================

![PyPI](https://img.shields.io/pypi/v/copier-super-important-project?logo=pypi)
![Python Version](https://img.shields.io/pypi/pyversions/copier-super-important-project?logo=python)
![Tests](https://img.shields.io/github/actions/workflow/status/Karol-G/copier-super-important-project/ci.yml?branch=main&logo=github)
![Copier Template](https://img.shields.io/badge/copier-template-blue?logo=jinja)
![License](https://img.shields.io/github/license/Karol-G/copier-super-important-project)

A modern Python package powered by Copier.

## Features
- Source-first layout under `src/copier_super_important_project` with dynamic versioning from Git tags via `setuptools_scm`
- GitHub Actions CI for lint/test and PyPI publishing on version tags
- PyPI-friendly metadata with README and license ready to ship
- Minimal default test to keep CI green, even with no custom tests
- Copier-powered customization (name, package folder, author, remotes, Python version)

## Getting started

1. Install Copier if needed: `pip install copier`.
2. Generate a new project:
   ```bash
   copier copy https://github.com/Karol-G/copier-super-important-project new-project
   ```
3. Answer the prompts (project/package names, author, GitHub info, remote).
4. Enter the project directory, initialize git, and set your remote:
   ```bash
   cd new-project
   git init
   git remote add origin git@github.com:Karol-G/copier-super-important-project.git
   ```

## Development

- Install dev dependencies and run tests:
  ```bash
  python -m pip install --upgrade pip
  pip install -e .[dev]
  pytest || if [ $? -eq 5 ]; then echo \"No tests collected\"; fi
  ```

- Versioning is tag-driven via `setuptools_scm`. Create tags like `v0.1.0`:
  ```bash
  git tag v0.1.0 && git push origin v0.1.0
  ```

## Continuous Integration

- CI runs on pushes and pull requests to `main`.
- Publishing to PyPI triggers when pushing tags that start with `v`. Set `PYPI_API_TOKEN` in repository secrets.

## Project layout

```
.
├─ src/copier_super_important_project/          # Your package code
├─ tests/                           # Pytest tests (default sample included)
├─ .github/workflows/ci.yml         # CI + publish workflow
├─ pyproject.toml                   # PEP 621 metadata with setuptools_scm
└─ README.md                        # You are here
```

## License

Distributed under the MIT license. See `LICENSE` for details.
