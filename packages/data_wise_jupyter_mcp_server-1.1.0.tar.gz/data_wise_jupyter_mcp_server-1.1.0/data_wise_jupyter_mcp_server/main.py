"""
Jupyter Lab MCP Server
提供远程控制 Jupyter Lab 的 MCP 服务
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional
from fastmcp import FastMCP
from pydantic import BaseModel, Field

# 导入 Jupyter 控制器
try:
    from .jupyter_controller import JupyterController
except ImportError:
    from jupyter_controller import JupyterController


# 创建 FastMCP 实例
mcp = FastMCP("Jupyter Lab MCP Server")


class ServerInfoRequest(BaseModel):
    """服务器信息请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class NotebookRequest(BaseModel):
    """笔记本操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    path: str = Field(..., description="笔记本路径")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class CreateNotebookRequest(BaseModel):
    """创建笔记本请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    path: str = Field(..., description="笔记本路径")
    kernel_name: str = Field(default="python3", description="内核名称")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class ExecuteCodeRequest(BaseModel):
    """执行代码请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    notebook_path: str = Field(..., description="笔记本路径")
    code: str = Field(..., description="要执行的代码")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class KernelRequest(BaseModel):
    """内核操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class FileRequest(BaseModel):
    """文件操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    file_path: str = Field(..., description="文件路径")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class DownloadFileRequest(BaseModel):
    """下载文件请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    file_path: str = Field(..., description="要下载的文件路径")
    local_path: Optional[str] = Field(default=None, description="本地保存路径（可选）")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class DirectoryRequest(BaseModel):
    """目录操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    dir_path: str = Field(default="", description="目录路径，空字符串表示根目录")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


# 全局会话管理
_session_config = {
    "url": None,
    "token": None,
    "controller": None
}

# 初始化控制器（默认不验证SSL，适合开发和内网环境）
controller = JupyterController(verify_ssl=False)


def get_controller():
    """获取配置好的控制器"""
    return JupyterController(verify_ssl=False)


def get_session_controller():
    """获取会话控制器"""
    if _session_config["controller"] is None:
        _session_config["controller"] = JupyterController(verify_ssl=False)
    return _session_config["controller"]


def create_response(success=True, data=None, message=None, error=None):
    """创建标准响应格式"""
    if success:
        response = {
            "success": True,
            "message": message
        }
        if data:
            response.update(data)
    else:
        response = {
            "success": False,
            "error": error,
            "data": None
        }
    return json.dumps(response, ensure_ascii=False, indent=2)


@mcp.tool()
def connect_jupyter(
    url: str = "http://localhost:8888",
    token: Optional[str] = None
) -> str:
    """
    连接到 Jupyter Lab 服务器并保存会话配置
    
    建立与 Jupyter Lab 服务器的连接，保存配置信息供后续操作使用。
    调用此方法后，其他工具可以不再需要重复传递连接参数。
    默认信任所有SSL证书，适合开发和内网环境。
    
    Args:
        url: Jupyter Lab 服务器地址
        token: 访问令牌
        
    Returns:
        JSON格式的连接结果
    """
    try:
        # 保存会话配置
        _session_config["url"] = url
        _session_config["token"] = token
        _session_config["controller"] = None  # 重置控制器，下次使用时重新创建
        
        # 测试连接
        ctrl = JupyterController(verify_ssl=False)
        info = ctrl.get_server_info(url, token)
        
        response = {
            "success": True,
            "message": "成功连接到 Jupyter Lab 服务器",
            "server_info": info,
            "session_saved": True
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        # 连接失败时清除会话配置
        _session_config.update({
            "url": None,
            "token": None,
            "controller": None
        })
        
        error_response = {
            "success": False,
            "error": str(e),
            "message": "连接失败，请检查服务器地址和令牌",
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def disconnect_jupyter() -> str:
    """
    断开 Jupyter Lab 连接并清除会话配置
    
    清除保存的连接配置信息。
    
    Returns:
        JSON格式的断开连接结果
    """
    try:
        _session_config.update({
            "url": None,
            "token": None,
            "controller": None
        })
        
        response = {
            "success": True,
            "message": "已断开 Jupyter Lab 连接并清除会话配置"
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def get_connection_status(
    include_server_info: bool = False
) -> str:
    """
    获取当前连接状态和服务器信息
    
    显示当前保存的连接配置信息，可选择包含详细的服务器信息。
    
    Args:
        include_server_info: 是否包含详细的服务器信息
    
    Returns:
        JSON格式的连接状态和服务器信息
    """
    try:
        is_connected = _session_config["url"] is not None
        
        response = {
            "success": True,
            "connected": is_connected,
            "url": _session_config["url"],
            "has_token": _session_config["token"] is not None
        }
        
        # 如果请求包含服务器信息且已连接
        if include_server_info and is_connected:
            try:
                ctrl = get_controller()
                server_info = ctrl.get_server_info(_session_config["url"], _session_config["token"])
                
                response.update({
                    "server_info": server_info,
                    "server_accessible": True
                })
            except Exception as e:
                response.update({
                    "server_info": None,
                    "server_accessible": False,
                    "server_error": str(e)
                })
        elif include_server_info and not is_connected:
            response.update({
                "server_info": None,
                "server_accessible": False,
                "server_error": "未连接到服务器，请先调用 connect_jupyter"
            })
        
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)



@mcp.tool()
def manage_file(
    action: str,
    file_path: str,
    local_path: Optional[str] = None
) -> str:
    """
    文件管理工具（合并了文件信息获取和下载功能）
    
    支持的操作：
    - "info": 获取文件信息（不下载内容）
    - "download": 下载文件到本地
    
    需要先调用 connect_jupyter 建立连接。
    
    Args:
        action: 操作类型 ("info" 或 "download")
        file_path: 文件路径
        local_path: 本地保存路径（仅下载时使用，可选）
        
    Returns:
        JSON格式的操作结果
    """
    try:
        if not _session_config["url"]:
            return create_response(success=False, error="未连接到服务器，请先调用 connect_jupyter")
            
        ctrl = get_controller()
        
        if action == "info":
            info = ctrl.get_file_info(_session_config["url"], _session_config["token"], file_path)
            
            return create_response(
                success=True,
                data={"file_info": info, "action": "info"}
            )
            
        elif action == "download":
            result = ctrl.download_file(
                _session_config["url"],
                _session_config["token"],
                file_path,
                local_path
            )
            
            return create_response(
                success=True,
                data={"download_result": result, "action": "download"},
                message=f"文件 {file_path} 下载成功到 {result.get('local_path')}"
            )
        else:
            return create_response(success=False, error=f"不支持的操作: {action}，支持的操作: info, download")
            
    except Exception as e:
        return create_response(success=False, error=str(e))


@mcp.tool()
def list_directory_contents(
    dir_path: str = ""
) -> str:
    """
    列出目录内容
    
    列出指定目录下的所有文件和子目录。
    需要先调用 connect_jupyter 建立连接。
    
    Args:
        dir_path: 目录路径，空字符串表示根目录
        
    Returns:
        JSON格式的目录内容列表
    """
    try:
        if not _session_config["url"]:
            return create_response(success=False, error="未连接到服务器，请先调用 connect_jupyter")
            
        ctrl = get_controller()
        contents = ctrl.list_directory_contents(
            _session_config["url"], 
            _session_config["token"], 
            dir_path
        )
        
        return create_response(
            success=True,
            data={
                "directory_path": dir_path or "/",
                "contents": contents,
                "total_items": len(contents)
            }
        )
    except Exception as e:
        return create_response(success=False, error=str(e))


if __name__ == "__main__":
    mcp.run()


def main():
    """命令行入口点函数"""
    mcp.run()


@mcp.tool()
def manage_notebook(
    action: str,
    path: Optional[str] = None,
    kernel_name: str = "python3",
    code: Optional[str] = None
) -> str:
    """
    笔记本管理工具（合并了笔记本的多种操作）
    
    支持的操作：
    - "list": 列出所有笔记本
    - "create": 创建新笔记本（需要path参数）
    - "get_content": 获取笔记本内容（需要path参数）
    - "execute": 执行代码（需要path和code参数）
    
    需要先调用 connect_jupyter 建立连接。
    
    Args:
        action: 操作类型 ("list", "create", "get_content", "execute")
        path: 笔记本路径（create, get_content, execute操作需要）
        kernel_name: 内核名称（仅create时使用）
        code: 要执行的代码（仅execute时使用）
        
    Returns:
        JSON格式的操作结果
    """
    try:
        if not _session_config["url"]:
            return create_response(success=False, error="未连接到服务器，请先调用 connect_jupyter")
            
        ctrl = get_controller()
        
        if action == "list":
            notebooks = ctrl.list_notebooks(_session_config["url"], _session_config["token"])
            
            return create_response(
                success=True,
                data={"notebooks": notebooks, "total": len(notebooks), "action": "list"}
            )
            
        elif action == "create":
            if not path:
                return create_response(success=False, error="创建笔记本需要提供path参数")
                
            result = ctrl.create_notebook(
                _session_config["url"], 
                _session_config["token"], 
                path, 
                kernel_name
            )
            
            return create_response(
                success=True,
                data={"notebook": result, "action": "create"},
                message=f"笔记本 {path} 创建成功"
            )
            
        elif action == "get_content":
            if not path:
                return create_response(success=False, error="获取笔记本内容需要提供path参数")
                
            content = controller.get_notebook_content(
                _session_config["url"], 
                _session_config["token"], 
                path
            )
            
            return create_response(
                success=True,
                data={"notebook_content": content, "path": path, "action": "get_content"}
            )
            
        elif action == "execute":
            if not path or not code:
                return create_response(success=False, error="执行代码需要提供path和code参数")
                
            result = controller.execute_code(
                _session_config["url"],
                _session_config["token"],
                path,
                code
            )
            
            return create_response(
                success=True,
                data={"execution_result": result, "code": code, "notebook": path, "action": "execute"}
            )
        else:
            return create_response(success=False, error=f"不支持的操作: {action}，支持的操作: list, create, get_content, execute")
            
    except Exception as e:
        return create_response(success=False, error=str(e))


@mcp.tool()
def manage_kernel(
    action: str,
    kernel_id: Optional[str] = None
) -> str:
    """
    内核管理工具（合并了内核的多种操作）
    
    支持的操作：
    - "list": 列出所有内核
    - "restart": 重启内核（可指定kernel_id，否则重启所有）
    
    需要先调用 connect_jupyter 建立连接。
    
    Args:
        action: 操作类型 ("list", "restart")
        kernel_id: 内核ID（仅restart时可选）
        
    Returns:
        JSON格式的操作结果
    """
    try:
        if not _session_config["url"]:
            return create_response(success=False, error="未连接到服务器，请先调用 connect_jupyter")
            
        ctrl = get_controller()
        
        if action == "list":
            kernels = controller.list_kernels(_session_config["url"], _session_config["token"])
            
            return create_response(
                success=True,
                data={"kernels": kernels, "total": len(kernels), "action": "list"}
            )
            
        elif action == "restart":
            result = ctrl.restart_kernel(_session_config["url"], _session_config["token"], kernel_id)
            
            return create_response(
                success=True,
                data={"result": result, "action": "restart"},
                message="内核重启成功"
            )
        else:
            return create_response(success=False, error=f"不支持的操作: {action}，支持的操作: list, restart")
            
    except Exception as e:
        return create_response(success=False, error=str(e))