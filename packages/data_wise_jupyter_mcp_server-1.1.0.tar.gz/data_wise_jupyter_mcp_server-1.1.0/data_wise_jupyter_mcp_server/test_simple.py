"""
简单测试脚本 - 直接测试核心功能
使用方法: python test_simple.py <token>
"""

import sys
import json
from jupyter_controller import JupyterController

def test_all(token):
    """测试所有功能"""
    url = "http://localhost:8888"
    ctrl = JupyterController(verify_ssl=False)
    
    print("=" * 60)
    print("测试 Jupyter Lab MCP Server 核心功能")
    print("=" * 60)
    
    try:
        # 1. 测试连接和获取服务器信息
        print("\n1. 测试连接和获取服务器信息...")
        info = ctrl.get_server_info(url, token)
        print(f"✓ 服务器版本: {info.get('version', 'Unknown')}")
        
        # 2. 测试列出笔记本
        print("\n2. 测试列出笔记本...")
        notebooks = ctrl.list_notebooks(url, token)
        print(f"✓ 找到 {len(notebooks)} 个笔记本")
        
        # 3. 测试创建笔记本
        print("\n3. 测试创建笔记本...")
        test_nb = "test_simple.ipynb"
        result = ctrl.create_notebook(url, token, test_nb)
        print(f"✓ 笔记本创建成功: {test_nb}")
        
        # 4. 测试获取笔记本内容
        print("\n4. 测试获取笔记本内容...")
        content = ctrl.get_notebook_content(url, token, test_nb)
        print(f"✓ 笔记本内容获取成功，包含 {len(content.get('cells', []))} 个单元格")
        
        # 5. 测试执行代码
        print("\n5. 测试执行代码...")
        code = "print('Hello from test!')\nresult = 2 + 2\nprint(f'2 + 2 = {result}')"
        exec_result = ctrl.execute_code(url, token, test_nb, code)
        print(f"✓ 代码执行成功")
        if exec_result.get('outputs'):
            print(f"   输出: {exec_result['outputs'][:100]}...")
        
        # 6. 测试列出内核
        print("\n6. 测试列出内核...")
        kernels = ctrl.list_kernels(url, token)
        print(f"✓ 找到 {len(kernels)} 个内核")
        
        # 7. 测试列出目录内容
        print("\n7. 测试列出目录内容...")
        contents = ctrl.list_directory_contents(url, token, "")
        print(f"✓ 根目录包含 {len(contents)} 个项目")
        
        # 8. 测试获取文件信息
        print("\n8. 测试获取文件信息...")
        file_info = ctrl.get_file_info(url, token, test_nb)
        print(f"✓ 文件信息: {file_info.get('name')} ({file_info.get('size', 0)} 字节)")
        
        # 9. 测试下载文件
        print("\n9. 测试下载文件...")
        download_result = ctrl.download_file(url, token, test_nb, f"downloaded_{test_nb}")
        print(f"✓ 文件下载成功: {download_result.get('local_path')}")
        
        # 清理下载的文件
        import os
        try:
            os.unlink(f"downloaded_{test_nb}")
        except:
            pass
        
        print("\n" + "=" * 60)
        print("🎉 所有测试通过!")
        print("=" * 60)
        return True
        
    except Exception as e:
        print(f"\n❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使用方法: python test_simple.py <token>")
        print("示例: python test_simple.py b0fc5c838e90fe1a9354c19598696e056e660fdc8305f39e")
        sys.exit(1)
    
    token = sys.argv[1]
    success = test_all(token)
    sys.exit(0 if success else 1)
