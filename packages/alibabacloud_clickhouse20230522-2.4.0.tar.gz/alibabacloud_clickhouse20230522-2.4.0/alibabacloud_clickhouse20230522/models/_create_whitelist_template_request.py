# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreateWhitelistTemplateRequest(DaraModel):
    def __init__(
        self,
        region_id: str = None,
        security_iplist: str = None,
        template_name: str = None,
    ):
        # RegionId
        # 
        # This parameter is required.
        self.region_id = region_id
        # This parameter is required.
        self.security_iplist = security_iplist
        # This parameter is required.
        self.template_name = template_name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.region_id is not None:
            result['RegionId'] = self.region_id

        if self.security_iplist is not None:
            result['SecurityIPList'] = self.security_iplist

        if self.template_name is not None:
            result['TemplateName'] = self.template_name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RegionId') is not None:
            self.region_id = m.get('RegionId')

        if m.get('SecurityIPList') is not None:
            self.security_iplist = m.get('SecurityIPList')

        if m.get('TemplateName') is not None:
            self.template_name = m.get('TemplateName')

        return self

