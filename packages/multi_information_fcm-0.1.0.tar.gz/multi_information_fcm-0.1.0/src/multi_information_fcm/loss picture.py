import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import numpy as np
import pandas as pd
def loadDataSet(filename):
    E = pd.read_excel(filename,sheetname=0,header=None)
    E = np.array(E)
    return E
X = loadDataSet('e1(mse).xlsx')
loss_list = []

for i in range(len(X)):
    for j in range(len(X[0])):
        loss_list.append(X[i][j])
x1 = range(0, 5000)
y1 = loss_list
plt.plot(x1, y1, 'o-',label="Train_Accuracy")
plt.tick_params(axis='both',which='major',labelsize=14)
x_major_locator = MultipleLocator(4)
y_major_locator = MultipleLocator(10)
ax = plt.gca()
ax.xaxis.set_major_locator(x_major_locator)
ax.yaxis.set_major_locator(y_major_locator)
plt.xlim(0,5000)
plt.ylim(0,2)
plt.title('Test loss vs. epoches')
plt.legend(loc='best')
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(x1, y1, color='blue', linewidth=1.0, linestyle='-')
ax.xaxis.set_ticks_position('bottom')    # 将x轴刻度设在下面的坐标轴上
ax.yaxis.set_ticks_position('left')         # 将y轴刻度设在左边的坐标轴上
ax.spines['bottom'].set_position(('data', 0))   # 将两个坐标轴的位置设在数据点原点
ax.spines['left'].set_position(('data', 0))

# ax.plot(xSortAdd[:, 1], yHatAdd[srtIndAdd], color='red', linewidth=3.0, linestyle='-')

# ax.scatter(x1.flatten().A[0], y1.flatten().A[0], s=2, c='red')

# ax.axis([0, 144, 12000, 55000])
plt.xlabel('Steps')
plt.ylabel('MSE')
# year = [0,200,  400,  600,   8000]
plt.xticks(np.arange(0, 5000, 500))
# plt.yticks(np.arange(0, 0.1, 0.005))
# plt.title('House Price in West Lake, Hangzhou')
plt.show()
