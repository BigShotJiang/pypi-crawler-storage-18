# Multi-information-FCM
安装：`pip install .`