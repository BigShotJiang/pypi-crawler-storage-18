# aws-s3-risk-footprint

A CLI tool to analyze AWS S3 **regional distribution and security risk**.

`aws-s3-risk-footprint` provides fast, read-only visibility into where your S3 data lives, how it is distributed across AWS regions, and whether any buckets present elevated security risk — all directly from the terminal.

Designed for cloud security engineers, GRC teams, and AWS practitioners who need lightweight visibility without relying on the AWS Console.

---

## Features

- 🌍 Regional footprint view of S3 buckets across AWS regions
- 📊 Bucket counts by region (data locality & sprawl)
- 📂 Expandable inventory of individual bucket names
- 🔐 Security risk analysis (e.g. public bucket exposure)
- 📦 Optional object count inspection (on-demand)
- 🧭 AWS identity awareness (`whoami`)
- 🔑 Uses existing AWS credentials (no secrets stored)

---

## Installation

```bash
pip install aws-s3-risk-footprint
After installation, the CLI command is:

bash
Copy code
aws-s3-risk
Usage
Show regional distribution
bash
Copy code
aws-s3-risk map
Displays a regional summary of S3 buckets to help assess data residency and bucket sprawl.

Expand bucket inventory
bash
Copy code
aws-s3-risk expand
Filter by region:

bash
Copy code
aws-s3-risk expand --region us-east-1
Analyze security risk
bash
Copy code
aws-s3-risk risk
Include object counts (may incur additional API calls):

bash
Copy code
aws-s3-risk risk --objects
Buckets are classified into LOW / MEDIUM / HIGH risk based on exposure signals (e.g. public access).

Show AWS execution context
bash
Copy code
aws-s3-risk whoami
Displays the AWS identity (user or role) used to execute the tool.

Use Cases
Cloud security posture reviews

Data residency & compliance (e.g. GDPR)

Identifying publicly exposed S3 buckets

AWS account hygiene and inventory audits

Pre-migration or architecture assessments

Permissions Required
This tool is read-only and requires permissions such as:

s3:ListAllMyBuckets

s3:GetBucketLocation

s3:GetBucketPolicyStatus

s3:ListBucket (optional, for object counts)

No write actions are performed.

Disclaimer
Risk classifications are heuristic-based and intended for visibility only.
This tool does not modify AWS resources and is not a substitute for a full security audit.



