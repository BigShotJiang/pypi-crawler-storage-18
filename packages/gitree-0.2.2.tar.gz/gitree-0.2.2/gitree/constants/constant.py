# tree structure characters
BRANCH = "├─ "
LAST   = "└─ "
VERT   = "│  "
SPACE  = "   "

# emojis
EMPTY_DIR_EMOJI = "📁"
NORMAL_DIR_EMOJI = "📂"
FILE_EMOJI = "📄"