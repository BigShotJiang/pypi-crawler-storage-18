<p align="center">
  <img src="assets/banner.png" alt="Charm Banner" width="100%" />
</p>

<p align="center">
  <a href="https://charmos.io/">Homepage</a> ·
  <a href="https://github.com/CharmAIOS/Charm/tree/main/docs">Documentation</a> ·
  <a href="https://github.com/CharmAIOS/Charm/blob/main/CONTRIBUTING.md">Contributing</a> ·
  <a href="https://discord.gg/gdakynHUEb">Discord</a>
</p>

# Charm: The Unified Platform for Agentic Intelligence

> **Current Status: v0.4.0 (Developer Preview)**

**Charm** is a **Unified System Layer** that governs the development, execution, and distribution of AI agents.

It provides a standardized architecture that enables agents to assemble, interoperate, and scale across heterogeneous ecosystems, turning them into real, commercial-ready applications.

---

## Why Charm?
Before you dive deeper, we’d like you to take a moment to read this [blog post](https://charmos.io/blog/1) to understand our insights and perspective.

## Getting started
To explore Charm’s core concepts and code in more detail, check out our [documentation](https://github.com/CharmAIOS/Charm/tree/main/docs).
### Installation
Charm is available on PyPI. We recommend using [uv](https://github.com/astral-sh/uv) for the best experience.

#### Modern Setup
1. Initialize a new project
```bash
uv init my-agent
cd my-agent
```
2. Add Charm as a dependency
```bash
uv add charmos
# Requires Python 3.10+
```
#### Standard Pip Setup
1. Create a project folder
```bash
mkdir my-agent && cd my-agent
```
2. Create venv
```bash
python -m venv .venv
source .venv/bin/activate
```
2. Install
```bash
pip install charmos
```
## Contributing
To learn how to contribute to Charm, please read the contribution guide [here](https://github.com/CharmAIOS/Charm/blob/main/CONTRIBUTING.md).

## Contact
- Support and Questions: [Community](https://discord.gg/gdakynHUEb) / [Email](mailto:team@charmos.io)
- Join the Charm team: [Chat with us](mailto:uc@charmos.io)

## Changelog
Check our [updates](https://charmos.io/changelog)

## License
Charm is licensed under the [GNU Affero General Public License v3.0](https://github.com/CharmAIOS/CharmOS/blob/main/LICENSE)
