from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Generator
import asyncio
import inspect

class BaseAdapter(ABC):
    
    def __init__(self, agent_instance: Any):
        self.agent = agent_instance
        self._pending_inputs: Dict[str, Any] = {}

    @abstractmethod
    def invoke(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        pass

    def stream(self, inputs: Dict[str, Any]) -> Generator[Any, None, None]:
        result = self.invoke(inputs)
        yield result

    def get_state(self) -> Dict[str, Any]:
        return {}

    def set_tools(self, tools: List[Any]) -> None:
        pass

    def _execute_async_safely(self, coro):
        try:
            return asyncio.run(coro)
        except RuntimeError:
            loop = asyncio.get_event_loop()
            return loop.run_until_complete(coro)

    def _smart_invoke(self, func, *args, **kwargs):
        if inspect.iscoroutinefunction(func):
            return self._execute_async_safely(func(*args, **kwargs))
        
        result = func(*args, **kwargs)
        
        if inspect.iscoroutine(result):
            return self._execute_async_safely(result)
            
        return result

    def _smart_instantiate(self):
        """
        [Charm Core] Universal logic to handle Class or Factory Function entry points.
        If the agent provided is a callable (Class/Function) and not yet an executable instance,
        this method attempts to instantiate it.
        """
        # If it's not callable, it's likely already an instance.
        if not callable(self.agent):
            return

        # If it looks like an instance (has execution methods), don't re-instantiate.
        # Check for common execution methods across frameworks.
        if (hasattr(self.agent, "invoke") or 
            hasattr(self.agent, "kickoff") or 
            hasattr(self.agent, "run")):
            # It might be a callable instance (like a LangChain RunnableLambda), so we leave it alone.
            # But if it's a Class that happens to have these as static methods (rare), this might skip.
            # For standard usage, this check is sufficient.
            return

        try:
            print(f"[Charm] Auto-instantiating {type(self.agent).__name__}...")
            sig = inspect.signature(self.agent)
            
            if len(sig.parameters) == 0:
                # No arguments required
                self.agent = self.agent()
            else:
                # Try injecting inputs if the constructor expects arguments
                try:
                    self.agent = self.agent(self._pending_inputs)
                except TypeError:
                    # Fallback: Try empty constructor anyway (args might be optional)
                    self.agent = self.agent()
                    
        except Exception as e:
            print(f"[Charm] Warning: Auto-instantiation failed: {e}")