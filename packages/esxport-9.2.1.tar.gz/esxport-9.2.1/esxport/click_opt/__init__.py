"""Custom Click configuration."""
