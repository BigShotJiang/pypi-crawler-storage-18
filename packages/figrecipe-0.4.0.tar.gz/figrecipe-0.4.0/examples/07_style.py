#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Timestamp: "2025-12-21 23:07:43 (ywatanabe)"
# File: /home/ywatanabe/proj/figrecipe/examples/07_style.py


"""
Demo 07: Style Presets
======================
Demonstrates publication-quality styling with style presets,
colorblind-friendly palettes, and easy YAML-based customization.
"""

import sys

sys.path.insert(0, "../src")

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import figrecipe as fr


def main():
    print("Demo 07: Style Presets")
    print("=" * 50)

    # Setup output directory
    from pathlib import Path

    output_dir = Path(__file__).parent.parent / "outputs" / "examples"
    output_dir.mkdir(parents=True, exist_ok=True)

    # === List available presets ===
    print("\n1. Available style presets...")
    presets = fr.list_presets()
    print(f"   Presets: {presets}")

    # === Load SCIENTIFIC preset (default) ===
    print("\n2. Loading SCIENTIFIC preset (default)...")
    style = fr.load_style()  # or fr.load_style("SCIENTIFIC")
    print(f"   Font family: {style.fonts.family}")
    print(f"   Axis font size: {style.fonts.axis_label_pt} pt")
    print(f"   Tick font size: {style.fonts.tick_label_pt} pt")
    print(f"   Axes thickness: {style.axes.thickness_mm} mm")
    print(f"   Trace line width: {style.lines.trace_mm} mm")

    # === Colorblind-friendly palette ===
    print("\n3. Colorblind-friendly color palette...")
    palette = style.colors.palette
    for i, color in enumerate(palette[:6]):
        names = ["Blue", "Orange", "Green", "Purple", "Yellow", "Cyan"]
        print(f"   {names[i]}: {color}")

    # === Styled figure with auto color cycling ===
    print("\n4. Creating styled figure with auto color cycling...")

    x = np.linspace(0, 2 * np.pi, 100)

    # Create figure with style applied
    fig, ax = fr.subplots(
        axes_width_mm=70,
        axes_height_mm=50,
        margin_left_mm=15,
        margin_bottom_mm=12,
        apply_style_mm=True,  # Apply SCIENTIFIC style
    )

    # Colors auto-cycle from colorblind-friendly palette
    trace_lw = fr.mm_to_pt(style.lines.trace_mm)
    ax.plot(x, np.sin(x), linewidth=trace_lw, label="sin(x)", id="sin")
    ax.plot(x, np.cos(x), linewidth=trace_lw, label="cos(x)", id="cos")
    ax.plot(x, np.sin(2 * x), linewidth=trace_lw, label="sin(2x)", id="sin2x")
    ax.plot(x, np.cos(2 * x), linewidth=trace_lw, label="cos(2x)", id="cos2x")

    ax.set_xlabel("x (radians)")
    ax.set_ylabel("y")
    ax.set_title("Auto Color Cycling")
    ax.legend(loc="upper right")

    styled_path = output_dir / "07_style_colors.png"
    fig.fig.savefig(
        styled_path, dpi=300, bbox_inches="tight", transparent=True
    )
    print(f"   Saved: {styled_path}")

    # Save with validation
    recipe_path = output_dir / "07_style_colors.yaml"
    path, validation = fr.save(fig, recipe_path, validate=True)
    print(f"   Recipe: {recipe_path}")
    print(
        f"   Validation: {'PASSED' if validation.valid else 'FAILED'} (MSE: {validation.mse:.2f})"
    )
    plt.close(fig.fig)

    # === Compare different presets ===
    print("\n5. Comparing style presets...")

    for preset_name in presets:
        preset = fr.load_style(preset_name)
        print(f"   {preset_name}:")
        print(f"     - Font: {preset.fonts.family}")
        print(f"     - Axis size: {preset.axes.width_mm}x{preset.axes.height_mm} mm")
        print(f"     - Line width: {preset.lines.trace_mm} mm")

    # === Dark theme ===
    print("\n6. Dark theme example...")

    fig2, ax2 = fr.subplots(
        axes_width_mm=70,
        axes_height_mm=50,
        margin_left_mm=15,
        margin_bottom_mm=12,
    )

    # Apply dark theme
    from figrecipe.styles import apply_theme_colors

    apply_theme_colors(ax2.ax, theme="dark")

    ax2.plot(
        x,
        np.sin(x),
        color="#56B4E9",
        linewidth=1.5,
        label="Signal",
        id="signal",
    )
    ax2.fill_between(
        x,
        np.sin(x) - 0.2,
        np.sin(x) + 0.2,
        alpha=0.3,
        color="#56B4E9",
        id="confidence",
    )
    ax2.set_xlabel("Time (s)")
    ax2.set_ylabel("Amplitude")
    ax2.set_title("Dark Theme")
    ax2.legend()

    dark_path = output_dir / "07_style_dark.png"
    fig2.fig.savefig(dark_path, dpi=300, bbox_inches="tight")
    print(f"   Saved: {dark_path}")
    plt.close(fig2.fig)

    # === Manual style application ===
    print("\n7. Manual style application...")

    fig3, ax3 = plt.subplots(figsize=(4, 3))

    # Plot first
    ax3.plot(x, np.sin(x), label="Data")
    ax3.scatter(x[::10], np.sin(x[::10]), s=30, zorder=5, label="Points")
    ax3.set_xlabel("X axis")
    ax3.set_ylabel("Y axis")
    ax3.set_title("Manual Style")
    ax3.legend()

    # Apply style after plotting
    fr.apply_style(ax3)

    manual_path = output_dir / "07_style_manual.png"
    fig3.savefig(manual_path, dpi=300, bbox_inches="tight", transparent=True)
    print(f"   Saved: {manual_path}")
    plt.close(fig3)

    # === Custom YAML style ===
    print("\n8. Custom YAML style example...")
    print("   You can create your own style YAML file:")
    print("   >>> style = fr.load_style('/path/to/my_style.yaml')")
    print("   >>> fig, ax = fr.subplots(**style.to_subplots_kwargs())")

    print("\n" + "=" * 50)
    print("Demo complete!")
    print("\nKey style features:")
    print("  - Built-in presets: SCIENTIFIC, MINIMAL, PRESENTATION")
    print("  - fr.load_style('PRESET') to switch styles")
    print("  - Colorblind-friendly palette")
    print("  - Auto color cycling with apply_style_mm=True")
    print("  - Dark/light theme support")
    print("  - Publication-quality fonts and line widths")
    print("  - Custom YAML files for your own styles")


if __name__ == "__main__":
    main()

# EOF
