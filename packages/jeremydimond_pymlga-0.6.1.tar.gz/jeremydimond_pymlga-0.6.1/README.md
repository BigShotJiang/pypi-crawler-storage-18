# pymlga

Version: 0.6.1

Python machine learning by genetic algorithm

