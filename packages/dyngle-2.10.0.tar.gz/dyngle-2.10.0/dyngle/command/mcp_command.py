import json

from mcp.server import Server
from mcp.types import Tool, TextContent
from wizlib.parser import WizParser

from dyngle.command import DyngleCommand
from dyngle.model.context import Context
from dyngle.model.operation import OperationAccess
from dyngle.error import DyngleError


class McpCommand(DyngleCommand):
    """Run an MCP server exposing Dyngle operations as tools"""

    name = "mcp"

    @classmethod
    def add_args(cls, parser: WizParser):
        super().add_args(parser)
        parser.add_argument(
            "args", nargs="*", help="Optional operation arguments"
        )
        parser.add_argument(
            "--transport",
            default="stdio",
            choices=["stdio"],
            help="Transport protocol to use",
        )
        parser.add_argument(
            "--operations",
            default=None,
            help="Comma-separated list of operations to expose as tools",
        )

    def create_server(self) -> Server:
        """Create and configure the MCP server with tools for each
        operation"""
        server = Server("dyngle")

        # Store reference to operations for use in handlers
        operations = self.app.dyngleverse.operations
        
        # Store args from command line for use in tool calls
        command_args = getattr(self, 'args', [])
        
        # Parse and validate --operations filter if provided
        operations_filter = None
        if hasattr(self, 'operations') and self.operations:
            # Parse comma-separated list and strip whitespace
            op_list = [op.strip() for op in self.operations.split(',')]
            # Filter out empty strings
            op_list = [op for op in op_list if op]
            
            if op_list:
                # Validate all keys exist
                for op_key in op_list:
                    if op_key not in operations:
                        raise DyngleError(
                            f"Operation '{op_key}' not found in dyngleverse"
                        )
                operations_filter = set(op_list)

        @server.list_tools()
        async def list_tools() -> list[Tool]:
            """List all public operations as MCP tools"""
            tools = []
            
            for op_name, operation in operations.items():
                # Skip private operations
                if operation.access != OperationAccess.PUBLIC:
                    continue
                
                # Skip operations not in filter if filter is set
                if operations_filter and op_name not in operations_filter:
                    continue
                
                # Create input schema
                if operation.interface:
                    # Use Interface's JSON Schema conversion
                    properties = operation.interface.to_json_schema()
                    required = operation.interface.get_required_fields()
                    
                    input_schema = {
                        "type": "object",
                        "properties": properties,
                        "required": required,
                    }
                else:
                    # No interface - no parameters
                    input_schema = {
                        "type": "object",
                        "properties": {},
                    }
                
                # Create tool with metadata
                tool = Tool(
                    name=op_name,
                    description=operation.description or f"Execute {op_name} operation",
                    inputSchema=input_schema,
                )
                tools.append(tool)
            
            return tools

        @server.call_tool()
        async def call_tool(name: str, arguments: dict) -> list[TextContent]:
            """Execute a Dyngle operation"""
            operation = operations.get(name)
            if not operation:  # pragma: nocover
                error_msg = f"Unknown operation: {name}"
                result = json.dumps({"error": error_msg})
                return [TextContent(type="text", text=result)]
            
            # Prepare data and args based on interface
            if operation.interface_schema:
                # Interface present - all arguments become data
                data = arguments
            else:
                # No interface - no data
                data = {}
            
            # Create context from data
            context = Context(data)

            try:
                # Execute the operation with command-line args
                # Block stdout for MCP operations - results should come via return value
                return_value = operation.run(context, command_args, show_stdout=False)
                # Use default parameter to handle non-serializable types like Path objects
                result = json.dumps({"result": return_value}, default=str)
                
            except DyngleError as e:
                result = json.dumps({"error": str(e)})
            except Exception as e:
                error_msg = f"Unexpected error: {type(e).__name__}: {str(e)}"
                result = json.dumps({"error": error_msg})
            
            return [TextContent(type="text", text=result)]

        return server

    @DyngleCommand.wrap
    def execute(self):
        """Start the MCP server"""
        server = self.create_server()

        # Import and run with the specified transport
        from mcp.server.stdio import stdio_server

        # Run the server with stdio transport
        import asyncio
        
        async def run_server():  # pragma: nocover
            async with stdio_server() as (read_stream, write_stream):
                await server.run(
                    read_stream,
                    write_stream,
                    server.create_initialization_options()
                )
        
        asyncio.run(run_server())

        # Realistically we don't ever get here.
        self.status = f"MCP server started on {self.transport}"
