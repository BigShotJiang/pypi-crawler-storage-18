from collections import UserDict
from datetime import date, timedelta
from numbers import Number
from pathlib import PurePath

from yaml import safe_dump

from dyngle.error import DyngleError

def raise_format_error(key, part):
    raise DyngleError(
        f"Invalid expression or data reference '{part}' in '{key}'"
    )

class Context(UserDict):
    """Represents the entire set of values, expressions, and data which can be
    resolved in a template."""

    def dig(self, key: str, str_only: bool = True):
        """Given a key (which might be dot-separated), return
        the value (which might include evaluating expressions). Method name
        borrowed from Ruby."""

        parts = key.split(".")
        current = self.data
        for part in parts:
            if isinstance(current, dict):
                if part not in current:
                    raise_format_error(key, part)
                current = current[part]
            elif isinstance(current, list):
                if not part.isdigit() or (index:=int(part)) >= len(current):
                    raise_format_error(key, part)
                current = current[index]
            else:
                    raise_format_error(key, part)
            if callable(current):
                current = current(self)
        return _stringify(current) if str_only else current

def _stringify(value) -> str:
    if isinstance(value, bool):
        return "." if value is True else ""
    # elif isinstance(value, (Number, str, date, timedelta, PurePath)):
    #     return str(value)
    elif isinstance(value, (list, dict, tuple)):
        return safe_dump(value)
    elif isinstance(value, set):
        return safe_dump(list(value))
    else:
        # raise DyngleError(f"Unable to serialize value of type {type(value)}")
        return str(value)
