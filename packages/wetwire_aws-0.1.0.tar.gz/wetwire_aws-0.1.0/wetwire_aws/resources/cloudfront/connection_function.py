"""PropertyTypes for AWS::CloudFront::ConnectionFunction."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar

from wetwire_aws.base import PropertyType, Tag



@dataclass
class ConnectionFunctionConfig(PropertyType):
    comment: str | None = None
    runtime: str | None = None
    key_value_store_associations: list[KeyValueStoreAssociation] = field(default_factory=list)

@dataclass
class KeyValueStoreAssociation(PropertyType):
    key_value_store_arn: str | None = None
