"""PropertyTypes for AWS::CertificateManager::Certificate."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar

from wetwire_aws.base import PropertyType, Tag



@dataclass
class DomainValidationOption(PropertyType):
    domain_name: str | None = None
    hosted_zone_id: str | None = None
    validation_domain: str | None = None
