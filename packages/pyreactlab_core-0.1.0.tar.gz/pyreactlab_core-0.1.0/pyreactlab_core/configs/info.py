# version
__version__ = "0.1.0"
# author
__author__ = "Sina Gilassi"
# email
__email__ = "sina.gilassi@gmail.com"
# license
__license__ = "Apache-2.0"
# package name
__package_name__ = "PyReactLab-Core"
# package description
__description__ = "PyReactLab-Core is the core foundation of the PyReactLab ecosystem, offering shared data structures and algorithms for chemical reaction representation, stoichiometry, and reaction analysis."
