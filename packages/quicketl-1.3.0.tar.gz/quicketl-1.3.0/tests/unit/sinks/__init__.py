"""Tests for sink modules."""
