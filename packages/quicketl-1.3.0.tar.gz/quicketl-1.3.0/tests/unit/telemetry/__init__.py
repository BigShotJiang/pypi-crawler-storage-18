"""Tests for telemetry modules."""
