# CLI command tests
