"""Tests for notifiers package."""
