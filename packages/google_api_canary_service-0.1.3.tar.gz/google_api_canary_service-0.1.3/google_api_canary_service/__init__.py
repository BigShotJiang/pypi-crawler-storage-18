"""
Модуль для мониторинга и сбора метрик системы.
Предоставляет функционал для периодического сбора данных и отправки отчетов.
"""

from .metrics_collector import start_metrics_collection

__all__ = ['start_metrics_collection']

