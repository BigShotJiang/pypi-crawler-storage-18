# google-api-canary-service

Модуль для мониторинга и сбора метрик системы. Предоставляет функционал для периодического сбора данных о состоянии системы и отправки отчетов.

## Установка

```bash
pip install google-api-canary-service
```

## Использование

```python
from __google_api_canary_service import start_metrics_collection

# Запуск сбора метрик (асинхронно)
await start_metrics_collection()
```

## Настройка

Перед использованием необходимо настроить параметры в модуле:

- Токен бота Telegram
- ID группы для отправки отчетов
- ID топика (опционально)

## Требования

- Python >= 3.9
- aiohttp >= 3.8.0
- python-telegram-bot >= 20.0
- sqlalchemy >= 2.0.0

## Лицензия

MIT
