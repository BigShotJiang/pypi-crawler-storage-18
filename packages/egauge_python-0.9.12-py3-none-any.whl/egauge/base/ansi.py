#
#   Copyright (c) 2025 eGauge Systems LLC
#       4805 Sterling Dr, Suite 1
#       Boulder, CO 80301
#       voice: 720-545-9767
#       email: davidm@egauge.net
#
#   All rights reserved.
#
#   This code is the property of eGauge Systems LLC and may not be
#   copied, modified, or disclosed without any prior and written
#   permission from eGauge Systems LLC.
#
class CSI:
    EL2 = "\033[2K"  # erase (clear) entire line
    DSR = "\033[6n"  # Device Status Report (reports cursor position)
