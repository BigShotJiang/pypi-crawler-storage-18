import concurrent.futures
import time
from typing import Dict, Iterator, List, Optional, Union

import requests
from tqdm import tqdm

from deeploy.common.functions.functions import bool_to_bool_param
from deeploy.enums import AuthType
from deeploy.enums.artifact import Artifact
from deeploy.models import (
    CreateActuals,
    CreateAzureMLDeployment,
    CreateCustomMetric,
    CreateCustomMetricDataPoint,
    CreateDeployment,
    CreateEnvironmentVariable,
    CreateEvaluation,
    CreateExternalDeployment,
    CreateGuardrail,
    CreateRegistrationDeployment,
    CreateSageMakerDeployment,
    Deployment,
    EnvironmentVariable,
    GetPredictionLogsOptions,
    UpdateAzureMLDeployment,
    UpdateCustomMetric,
    UpdateDeployment,
    UpdateDeploymentDescription,
    UpdateExternalDeployment,
    UpdateRegistrationDeployment,
    UpdateSageMakerDeployment,
)
from deeploy.models.create_job_schedule import CreateJobSchedule
from deeploy.models.get_request_logs_options import GetRequestLogsOptions
from deeploy.models.guardrail import Guardrail
from deeploy.models.inference_options import (
    BaseInferenceOptions,
    ClientOptions,
    CompletionsInferenceOptions,
    ExplainInferenceOptions,
)
from deeploy.models.test_job_schedule import TestJobSchedule
from deeploy.models.update_job_schedule import UpdateJobSchedule


class DeeployService:
    """
    A class for interacting with the Deeploy API
    """

    request_timeout = 300

    def __init__(
        self,
        host: str,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        token: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        if not (access_key and secret_key) and not token:
            raise Exception(
                "No authentication method provided. Please provide a token or personal key pair"
            )
        self.set_config(
            host=host,
            access_key=access_key,
            secret_key=secret_key,
            token=token,
            organization_id=organization_id,
        )

    def set_config(
        self,
        host: str,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
        token: Optional[str] = None,
        organization_id: Optional[str] = None,
    ):
        self.__access_key = access_key
        self.__secret_key = secret_key
        self.__token = token
        self.__host = f"https://api.{host}"
        if not (access_key and secret_key) and not token:
            raise Exception(
                "No authentication method provided. Please provide a token or personal key pair"
            )

        self.__access_key = access_key
        self.__secret_key = secret_key
        self.__token = token
        self.__host = f"https://api.{host}"
        self.__request_session = requests.Session()

        if organization_id:
            self.__request_session.headers.update({"organization-id": organization_id})
        if access_key and secret_key:
            self.__request_session.auth = (access_key, secret_key)

    def get_repositories(self, workspace_id: str) -> dict:
        url = "%s/workspaces/%s/repositories" % (self.__host, workspace_id)
        self.__set_auth(AuthType.BASIC)
        repositories_response = self.__request_session.get(
            url,
            timeout=self.request_timeout,
        )

        return repositories_response.json()

    def create_environment_variable(
        self, workspace_id: str, environment_variable: CreateEnvironmentVariable
    ) -> dict:
        url = "%s/workspaces/%s/environmentVariables" % (self.__host, workspace_id)
        data = environment_variable.to_request_body()
        self.__set_auth(AuthType.BASIC)
        environment_variable_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(environment_variable_response):
            raise Exception(
                "Failed to create environment variable: %s"
                % str(environment_variable_response.json())
            )

        return environment_variable_response.json()

    def get_all_environment_variables(self, workspace_id: str) -> List[EnvironmentVariable]:
        url = "%s/workspaces/%s/environmentVariables" % (self.__host, workspace_id)
        self.__set_auth(AuthType.BASIC)
        environment_variables_response = self.__request_session.get(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(environment_variables_response):
            raise Exception("Failed to get environment variables.")

        return environment_variables_response.json()

    def get_environment_variable_ids_for_deployment_artifact(
        self, workspace_id: str, deployment_id: str, artifact: Artifact
    ) -> List[str]:
        url = "%s/workspaces/%s/environmentVariables/raw" % (self.__host, workspace_id)
        params = {
            "deploymentId": "eq:%s" % deployment_id,
            "artifact": "eq:%s" % artifact,
        }
        self.__set_auth(AuthType.BASIC)
        environment_variables_response = self.__request_session.get(
            url,
            params=params,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(environment_variables_response):
            raise Exception("Failed to get environment variables.")

        raw_environment_variables = environment_variables_response.json()["data"]
        environment_variable_ids = list(map(lambda env: env["id"], raw_environment_variables))

        return environment_variable_ids

    def get_deployment(
        self, workspace_id: str, deployment_id: str, withExamples: bool = False
    ) -> Deployment:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        params = {}
        if withExamples:
            params["withExamples"] = withExamples

        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.get(
            url,
            params=params,
            timeout=self.request_timeout,
        )
        if not self.__request_is_successful(deployment_response):
            raise Exception(
                "Failed to retrieve the deployment: %s" % str(deployment_response.json())
            )

        return deployment_response.json()

    def create_deployment(self, workspace_id: str, deployment: CreateDeployment) -> dict:
        url = "%s/workspaces/%s/deployments" % (self.__host, workspace_id)
        data = deployment.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to create the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def create_sagemaker_deployment(
        self, workspace_id: str, deployment: CreateSageMakerDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments" % (self.__host, workspace_id)
        data = deployment.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to create the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def create_azure_ml_deployment(
        self, workspace_id: str, deployment: CreateAzureMLDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments" % (self.__host, workspace_id)
        data = deployment.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to create the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def create_external_deployment(
        self, workspace_id: str, deployment: CreateExternalDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments" % (self.__host, workspace_id)
        data = deployment.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.post(
            url,
            json=data,
            auth=(self.__access_key, self.__secret_key),
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to create the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def create_registration_deployment(
        self, workspace_id: str, deployment: CreateRegistrationDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments" % (self.__host, workspace_id)
        data = deployment.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to create the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_deployment(
        self, workspace_id: str, deployment_id: str, update: UpdateDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_sagemaker_deployment(
        self, workspace_id: str, deployment_id: str, update: UpdateSageMakerDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_azure_ml_deployment(
        self, workspace_id: str, deployment_id: str, update: UpdateAzureMLDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_external_deployment(
        self, workspace_id: str, deployment_id: str, update: UpdateExternalDeployment
    ) -> Deployment:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_registration_deployment(
        self, workspace_id: str, deployment_id: str, update: UpdateRegistrationDeployment
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the Deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def update_deployment_description(
        self, workspace_id: str, deployment_id: str, update: UpdateDeploymentDescription
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/description" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = update.to_request_body()
        self.__set_auth(AuthType.BASIC)
        deployment_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )
        if not self.__request_is_successful(deployment_response):
            raise Exception("Failed to update the deployment: %s" % str(deployment_response.json()))

        return deployment_response.json()

    def create_job_schedule(self, workspace_id: str, options: CreateJobSchedule) -> dict:
        url = "%s/workspaces/%s/jobSchedules" % (
            self.__host,
            workspace_id,
        )
        data = options.to_request_body()
        self.__set_auth(AuthType.BASIC)
        job_schedule_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(job_schedule_response):
            raise Exception("Failed to create job schedule: %s" % str(job_schedule_response.json()))

        return job_schedule_response.json()

    def test_job_schedule(self, workspace_id: str, options: TestJobSchedule) -> List[Dict]:
        url = "%s/workspaces/%s/jobSchedules/test" % (
            self.__host,
            workspace_id,
        )
        data = options.to_request_body()
        self.__set_auth(AuthType.BASIC)
        data_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(data_response):
            raise Exception("Job schedule test failed: %s" % str(data_response.json()))

        return data_response.json()

    def update_job_schedule(
        self, workspace_id: str, job_schedule_id: str, options: UpdateJobSchedule
    ) -> dict:
        url = "%s/workspaces/%s/jobSchedules/%s" % (
            self.__host,
            workspace_id,
            job_schedule_id,
        )
        data = options.to_request_body()
        self.__set_auth(AuthType.BASIC)
        job_schedule_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(job_schedule_response):
            raise Exception("Failed to update job schedule: %s" % str(job_schedule_response.json()))

        return job_schedule_response.json()

    def deactivate_job_schedule(self, workspace_id: str, job_schedule_id: str) -> dict:
        url = "%s/workspaces/%s/jobSchedules/%s/deactivate" % (
            self.__host,
            workspace_id,
            job_schedule_id,
        )
        self.__set_auth(AuthType.BASIC)
        job_schedule_response = self.__request_session.patch(
            url,
            json={},
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(job_schedule_response):
            raise Exception(
                "Failed to deactivate job schedule: %s" % str(job_schedule_response.json())
            )

        return job_schedule_response.json()

    def activate_job_schedule(self, workspace_id: str, job_schedule_id: str) -> dict:
        url = "%s/workspaces/%s/jobSchedules/%s/activate" % (
            self.__host,
            workspace_id,
            job_schedule_id,
        )
        self.__set_auth(AuthType.BASIC)
        job_schedule_response = self.__request_session.patch(
            url,
            json={},
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(job_schedule_response):
            raise Exception(
                "Failed to activate job schedule: %s" % str(job_schedule_response.json())
            )

        return job_schedule_response.json()

    def predict(
        self,
        workspace_id: str,
        deployment_id: str,
        request_body: dict | list,
        client_options: Optional[ClientOptions] = None,
        inference_options: Optional[BaseInferenceOptions] = None,
    ) -> Union[dict, Iterator[bytes], object]:
        return self._infer(
            deployment_id, workspace_id, request_body, client_options, inference_options, "predict"
        )

    def explain(
        self,
        workspace_id: str,
        deployment_id: str,
        request_body: dict,
        client_options: Optional[ClientOptions] = None,
        explain_options: Optional[ExplainInferenceOptions] = None,
    ) -> dict:
        return self._infer(
            deployment_id, workspace_id, request_body, client_options, explain_options, "explain"
        )

    def completions(
        self,
        workspace_id: str,
        deployment_id: str,
        request_body: dict,
        client_options: Optional[ClientOptions] = None,
        completions_options: Optional[CompletionsInferenceOptions] = None,
    ) -> Union[dict, Iterator[bytes]]:
        return self._infer(
            deployment_id,
            workspace_id,
            request_body,
            client_options,
            completions_options,
            "completions",
        )

    def chat_completions(
        self,
        workspace_id: str,
        deployment_id: str,
        request_body: dict,
        client_options: Optional[ClientOptions] = None,
        inference_options: Optional[BaseInferenceOptions] = None,
    ) -> Union[dict, Iterator[bytes]]:
        return self._infer(
            deployment_id,
            workspace_id,
            request_body,
            client_options,
            inference_options,
            "chat/completions",
        )

    def embeddings(
        self,
        workspace_id: str,
        deployment_id: str,
        request_body: dict,
        client_options: Optional[ClientOptions] = None,
        inference_options: Optional[BaseInferenceOptions] = None,
    ) -> dict:
        return self._infer(
            deployment_id,
            workspace_id,
            request_body,
            client_options,
            inference_options,
            "embeddings",
        )

    def get_prediction_logs(
        self, workspace_id: str, deployment_id: str, params: GetPredictionLogsOptions
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/predictionLogs" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        self.__set_auth(AuthType.ALL)

        logs_response = self.__request_session.get(
            url,
            params=params.to_params(),
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(logs_response):
            raise Exception("Failed to get logs.")

        return logs_response.json()

    def get_request_logs(
        self,
        workspace_id: str,
        deployment_id: str,
        params: GetRequestLogsOptions,
        include_raw_body: bool = False,
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/requestLogs" % (
            self.__host,
            workspace_id,
            deployment_id,
        )

        params_to_send = params.to_params()
        if include_raw_body:
            params_to_send["includeRawBody"] = include_raw_body

        self.__set_auth(AuthType.ALL)
        logs_response = self.__request_session.get(
            url,
            params=params_to_send,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(logs_response):
            raise Exception("Failed to get logs.")

        return logs_response.json()

    def evaluate(
        self,
        workspace_id: str,
        deployment_id: str,
        prediction_log_id: str,
        evaluation_input: CreateEvaluation,
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/predictionLogs/%s/evaluatePrediction" % (
            self.__host,
            workspace_id,
            deployment_id,
            prediction_log_id,
        )

        data = evaluation_input.to_request_body()
        self.__set_auth(AuthType.ALL)
        evaluation_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(evaluation_response):
            if evaluation_response.status_code == 409:
                raise Exception("Log has already been evaluated.")
            elif evaluation_response.status_code in (401, 403):
                raise Exception("No permission to perform this action.")
            else:
                raise Exception("Failed to submit evaluation: %s" % evaluation_response.json())

        return evaluation_response.json()

    def actuals(self, workspace_id: str, deployment_id: str, actuals_input: CreateActuals) -> dict:
        url = "%s/workspaces/%s/deployments/%s/actuals" % (
            self.__host,
            workspace_id,
            deployment_id,
        )

        data = actuals_input.to_request_body()
        self.__set_auth(AuthType.ALL)
        actuals_response = self.__request_session.put(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(actuals_response):
            raise Exception("Failed to submit actuals: %s" % actuals_response.json())

        return actuals_response.json()

    def set_token(self, deployment_token) -> None:
        self.__token = deployment_token

    def __request_is_successful(self, request: requests.Response) -> bool:
        return 200 <= request.status_code < 300

    def __set_auth(self, supported_auth: AuthType):
        if (self.__access_key and self.__secret_key) and (
            supported_auth == AuthType.BASIC or supported_auth == AuthType.ALL
        ):
            self.__request_session.auth = (self.__access_key, self.__secret_key)
        elif (self.__token) and (
            supported_auth == AuthType.TOKEN or supported_auth == AuthType.ALL
        ):
            self.__request_session.auth = None
            self.__request_session.headers.update({"Authorization": "Bearer " + self.__token})

        elif (self.__access_key and self.__secret_key) and not (
            supported_auth == AuthType.BASIC or supported_auth == AuthType.ALL
        ):
            raise ValueError(
                "This function currently does not support authenticating with personal access key, please use a deployment token instead."
            )
        else:
            raise ValueError(
                "This function currently does not support authenticating with deployment token, please use a personal access key instead."
            )

    def get_custom_metrics_with_chart_data(
        self, workspace_id: str, deployment_id: str
    ) -> List[dict]:
        url = "%s/workspaces/%s/deployments/%s/customMetricsChartData" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        self.__set_auth(AuthType.ALL)

        logs_response = self.__request_session.get(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(logs_response):
            raise Exception("Failed to get logs.")

        return logs_response.json()

    def get_custom_metrics(self, workspace_id: str, deployment_id: str) -> dict:
        url = "%s/workspaces/%s/deployments/%s/customMetrics" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        self.__set_auth(AuthType.ALL)

        logs_response = self.__request_session.get(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(logs_response):
            raise Exception("Failed to get logs.")

        return logs_response.json()

    def create_custom_metric(
        self, workspace_id: str, deployment_id: str, create_custom_metric: CreateCustomMetric
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/customMetric" % (
            self.__host,
            workspace_id,
            deployment_id,
        )
        data = create_custom_metric.to_request_body()
        self.__set_auth(AuthType.BASIC)
        custom_metric_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(custom_metric_response):
            raise Exception(
                "Failed to create custom metric: %s" % str(custom_metric_response.json())
            )

        return custom_metric_response.json()

    def update_custom_metric(
        self,
        workspace_id: str,
        deployment_id: str,
        custom_metric_id: str,
        update_custom_metric: UpdateCustomMetric,
    ) -> dict:
        url = "%s/workspaces/%s/deployments/%s/customMetric/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
            custom_metric_id,
        )
        data = update_custom_metric.to_request_body()
        self.__set_auth(AuthType.BASIC)
        custom_metric_response = self.__request_session.patch(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(custom_metric_response):
            raise Exception(
                "Failed to update custom metric: %s" % str(custom_metric_response.json())
            )

        return custom_metric_response.json()

    def delete_custom_metric(self, workspace_id: str, deployment_id: str, custom_metric_id: str):
        url = "%s/workspaces/%s/deployments/%s/customMetric/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
            custom_metric_id,
        )
        self.__set_auth(AuthType.BASIC)
        custom_metric_response = self.__request_session.delete(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(custom_metric_response):
            raise Exception(
                "Failed to delete custom metric: %s" % str(custom_metric_response.json())
            )

        return

    def create_custom_metric_data_points(
        self,
        workspace_id: str,
        deployment_id: str,
        custom_metric_id: str,
        create_custom_metric_data_points: List[CreateCustomMetricDataPoint],
    ) -> List[dict]:
        url = "%s/workspaces/%s/deployments/%s/customMetric/%s/dataPoints" % (
            self.__host,
            workspace_id,
            deployment_id,
            custom_metric_id,
        )
        data = [
            create_custom_metric_data_point.to_request_body()
            for create_custom_metric_data_point in create_custom_metric_data_points
        ]
        self.__set_auth(AuthType.ALL)
        custom_metric_data_points_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(custom_metric_data_points_response):
            raise Exception(
                "Failed to create custom metric: %s"
                % str(custom_metric_data_points_response.json())
            )

        return custom_metric_data_points_response.json()

    def clear_custom_metric_data_points(
        self, workspace_id: str, deployment_id: str, custom_metric_id: str
    ):
        url = "%s/workspaces/%s/deployments/%s/customMetric/%s/dataPoints" % (
            self.__host,
            workspace_id,
            deployment_id,
            custom_metric_id,
        )
        self.__set_auth(AuthType.ALL)
        custom_metric_data_points_response = self.__request_session.delete(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(custom_metric_data_points_response):
            raise Exception(
                "Failed to delete data points of custom metric: %s"
                % str(custom_metric_data_points_response.json())
            )

        return

    def create_guardrail(self, workspace_id: str, guardrail: CreateGuardrail) -> dict:
        url = "%s/workspaces/%s/guardrails" % (self.__host, workspace_id)
        data = guardrail.to_request_body()
        self.__set_auth(AuthType.BASIC)
        guardrail_response = self.__request_session.post(
            url,
            json=data,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(guardrail_response):
            raise Exception("Failed to create guardrail: %s" % str(guardrail_response.json()))

        return guardrail_response.json()

    def get_all_guardrails_for_workspace(self, workspace_id: str) -> List[Guardrail]:
        url = "%s/workspaces/%s/guardrails" % (self.__host, workspace_id)
        self.__set_auth(AuthType.BASIC)
        guardrails_response = self.__request_session.get(
            url,
            timeout=self.request_timeout,
        )

        if not self.__request_is_successful(guardrails_response):
            raise Exception("Failed to get guardrails.")

        return guardrails_response.json()

    def _split_batch(self, request_body: dict | list, n_splits: int) -> List[dict]:
        """
        Split a batch request into smaller batches for parallel processing.
        Supports splitting on 'instances', 'inputs', or list format.

        Args:
            request_body (dict | list): The request body to be split.
            n_splits (int): Number of batches to split into.

        Returns:
            List[dict]: List of batch request bodies.

        Raises:
            ValueError: If the request body format cannot be split for parallel processing.
        """
        # Determine the key and data to split
        split_key = None
        data_to_split = None

        # Check if request_body is a list
        if isinstance(request_body, list):
            split_key = None  # Direct list splitting
            data_to_split = request_body
        elif isinstance(request_body, dict):
            # Check for 'instances' key
            if "instances" in request_body:
                split_key = "instances"
                data_to_split = request_body["instances"]
            # Check for 'inputs' key
            elif "inputs" in request_body:
                split_key = "inputs"
                data_to_split = request_body["inputs"]

        # Validate data can be split
        if not isinstance(data_to_split, list):
            raise ValueError(
                f"Cannot split batch: '{split_key or 'request_body'}' must be a list, "
                f"got {type(data_to_split).__name__}"
            )

        if len(data_to_split) == 0:
            raise ValueError(f"Cannot split batch: '{split_key or 'request_body'}' is empty")

        if len(data_to_split) < n_splits:
            # Adjust n_splits to the actual data size
            n_splits = len(data_to_split)

        # Split the data
        batch_size = len(data_to_split)
        split_size = max(1, batch_size // n_splits)

        if split_key is None:
            # Direct list splitting
            batches = [
                data_to_split[i * split_size : (i + 1) * split_size] for i in range(n_splits)
            ]
            # Handle remainder
            if batch_size % n_splits != 0:
                batches[-1].extend(data_to_split[n_splits * split_size :])
        else:
            # Dict-based splitting
            batches = [
                {**request_body, split_key: data_to_split[i * split_size : (i + 1) * split_size]}
                for i in range(n_splits)
            ]
            # Handle remainder
            if batch_size % n_splits != 0:
                batches[-1][split_key].extend(data_to_split[n_splits * split_size :])

        # Filter out empty batches
        if split_key is None:
            return [batch for batch in batches if batch]
        else:
            return [batch for batch in batches if batch.get(split_key)]

    def _single_infer(
        self,
        url: str,
        params: dict,
        request_body: dict,
        nr_retries: Optional[int] = None,
        stream: bool = False,
    ) -> Union[dict, Iterator[bytes], object]:
        """
        Perform a single inference request with retry logic.

        Args:
            url (str): The API endpoint URL.
            params (dict): Query parameters.
            request_body (dict or list): The request body.
            nr_retries (Optional[int]): Number of retries on failure (default: 0).

        Returns:
            dict: The inference result.

        Raises:
            Exception: If the request fails after all retries.
        """
        max_retries = nr_retries if nr_retries is not None else 0
        last_exception = None
        for attempt in range(max_retries + 1):
            try:
                # Check if streaming is requested via parameter or request body
                if stream is not None:
                    should_stream = stream
                else:
                    should_stream = isinstance(request_body, dict) and request_body.get("stream") is True
                prediction_response = self.__request_session.post(
                    url,
                    params=params,
                    json=request_body,
                    timeout=self.request_timeout,
                    stream=should_stream,
                )

                if not self.__request_is_successful(prediction_response):
                    error_msg = f"Failed to call inference endpoint: {prediction_response.json()}"

                    # Check if we should retry (only for server errors 5xx or connection issues)
                    if attempt < max_retries and prediction_response.status_code >= 500:
                        wait_time = 2**attempt  # Exponential backoff: 1s, 2s, 4s, 8s...
                        print(
                            f"Request failed (status {prediction_response.status_code}), retrying in {wait_time}s (attempt {attempt + 1}/{max_retries + 1})..."
                        )
                        time.sleep(wait_time)
                        continue
                    else:
                        raise Exception(error_msg)

                if should_stream:
                    return prediction_response.iter_content(chunk_size=None)
        
                return prediction_response.json()

            except requests.exceptions.RequestException as e:
                last_exception = e
                if attempt < max_retries:
                    wait_time = 2**attempt  # Exponential backoff
                    print(
                        f"Request error: {str(e)}, retrying in {wait_time}s (attempt {attempt + 1}/{max_retries + 1})..."
                    )
                    time.sleep(wait_time)
                else:
                    raise Exception(
                        f"Failed to call inference endpoint after {max_retries + 1} attempts: {str(e)}"
                    ) from e

        # This should not be reached, but just in case
        raise Exception(
            f"Failed to call inference endpoint after {max_retries + 1} attempts"
        ) from last_exception

    def _infer(
        self,
        deployment_id: str,
        workspace_id: str,
        request_body: dict,
        client_options: Optional[ClientOptions],
        inference_options: Optional[
            BaseInferenceOptions | ExplainInferenceOptions | CompletionsInferenceOptions
        ],
        path_suffix: str,
    ) -> Union[dict, Iterator[bytes], object]:
        """
        Internal method to perform inference using the DeeployService.
        Supports parallel batch processing when nr_requests is specified in options.

        Args:
            deployment_id (str): The ID of the deployment to use for inference.
            workspace_id (str): The ID of the workspace.
            request_body (dict): The request body containing input data for inference.
            options (InferenceOptions | ExplainInferenceOptions | CompletionsInferenceOptions | None): Options for the inference request.
            path_suffix (str): The API path suffix (e.g., 'predict', 'explain').

        Returns:
            dict: The prediction result from the deployment. If parallel processing is used,
                  returns a list of results from each batch.
        """
        if client_options is None:
            client_options = ClientOptions()

        if inference_options is None:
            inference_options = BaseInferenceOptions()

        params = {
            **(
                {"skipLog": bool_to_bool_param(inference_options.skip_log)}
                if inference_options.skip_log is not None
                else {}
            ),
            **(
                {"image": bool_to_bool_param(inference_options.image)}
                if isinstance(inference_options, ExplainInferenceOptions)
                and inference_options.image is not None
                else {}
            ),
            **(
                {"explain": bool_to_bool_param(inference_options.explain)}
                if isinstance(inference_options, CompletionsInferenceOptions)
                and inference_options.explain is not None
                else {}
            ),
            **(
                {"stream": bool_to_bool_param(client_options.stream)}
                if isinstance(client_options, ClientOptions)
                and client_options.stream is not None
                else {}
            ),
        }
        url = "%s/workspaces/%s/deployments/%s/%s" % (
            self.__host,
            workspace_id,
            deployment_id,
            path_suffix,
        )

        self.__set_auth(AuthType.ALL)

        # Check if streaming is requested
        # Priority: client_options.stream if explicitly set, otherwise check request_body
        if hasattr(client_options, 'stream') and client_options.stream is not None:
            should_stream = client_options.stream
        else:
            should_stream = isinstance(request_body, dict) and request_body.get("stream") is True

        # Check for streaming compatibility
        if should_stream:
            if client_options.nr_requests and client_options.nr_requests > 1:
                raise ValueError(
                    "Parallel processing with nr_requests is not supported when streaming is enabled. "
                    "Please set nr_requests to 1 or None, or disable streaming."
                )
            # For streaming, bypass parallel processing and call directly
            return self._single_infer(
                url, params, request_body, nr_retries=client_options.nr_retries, stream=should_stream
            )

        # Check if parallel processing is requested and applicable
        nr_requests = client_options.nr_requests if client_options.nr_requests else None

        # Determine if request can be batched
        can_batch = False
        if isinstance(request_body, list) and len(request_body) > 1:
            can_batch = True
        elif isinstance(request_body, dict):
            if ("instances" in request_body and len(request_body.get("instances", [])) > 1) or (
                "inputs" in request_body and len(request_body.get("inputs", [])) > 1
            ):
                can_batch = True

        if nr_requests and nr_requests > 1:
            if not can_batch:
                # Parallel processing requested but not applicable
                raise ValueError(
                    f"Parallel processing with nr_requests={nr_requests} is not applicable: "
                    f"request body must contain 'instances' or 'inputs' with multiple items, "
                    f"or be a list with multiple elements."
                )

            # Parallel batch processing
            try:
                batches = self._split_batch(request_body, nr_requests)
            except ValueError as e:
                # Re-raise with additional context
                raise ValueError(
                    f"Failed to split batch for parallel processing (nr_requests={nr_requests}): {str(e)}"
                ) from e

            if len(batches) == 1:
                # Not worth parallelizing
                return self._single_infer(
                    url, params, request_body, nr_retries=client_options.nr_retries
                )

            results = []

            with concurrent.futures.ThreadPoolExecutor(max_workers=nr_requests) as executor:
                # Submit all tasks
                futures = [
                    executor.submit(
                        self._single_infer, url, params, batch, client_options.nr_retries
                    )
                    for batch in batches
                ]

                # Collect results as they complete with progress bar
                if client_options.progress:
                    with tqdm(total=len(batches), desc="Processing batches", unit="batch") as pbar:
                        for future in concurrent.futures.as_completed(futures):
                            try:
                                results.append(future.result())
                                pbar.update(1)
                            except Exception as e:
                                # Cancel remaining futures
                                for f in futures:
                                    f.cancel()
                                raise e
                else:
                    for future in concurrent.futures.as_completed(futures):
                        try:
                            results.append(future.result())
                        except Exception as e:
                            # Cancel remaining futures
                            for f in futures:
                                f.cancel()
                            raise e

            return results
        else:
            # Standard single request
            return self._single_infer(
                url, params, request_body, nr_retries=client_options.nr_retries, stream=client_options.stream
            )
