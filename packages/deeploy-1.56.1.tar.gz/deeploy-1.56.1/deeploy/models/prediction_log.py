from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict

from deeploy.common.functions import to_lower_camel


class RequestLog(BaseModel):
    id: str
    deployment_id: str
    commit: Optional[str] = None
    request_content_type: str
    response_time_m_s: int
    status_code: int
    personal_keys_id: Optional[str] = None
    token_id: Optional[str] = None
    oidc_subject_id: Optional[str] = None
    created_at: str
    endpoint_path: Optional[str] = None
    streaming: bool = False
    prediction_logs: Optional[List[Dict]] = None
    applied_input_guardrail_ids: Optional[List[str]] = None
    applied_output_guardrail_ids: Optional[List[str]] = None
    available_input_guardrail_ids: Optional[List[str]] = None
    available_output_guardrail_ids: Optional[List[str]] = None
    raw_request_body: Optional[Dict] = None
    raw_response_body: Optional[Dict] = None
    model_config = ConfigDict(alias_generator=to_lower_camel)


class PredictionLog(BaseModel):
    id: str
    request_body: Optional[Dict] = None
    response_body: Optional[Dict] = None
    request_log: Dict
    request_log_id: str
    evaluation: Optional[Dict] = None
    actual: Optional[Dict] = None
    created_at: str
    tags: Dict
    endpoint_type: str
    streaming: bool = False
    model_config = ConfigDict(alias_generator=to_lower_camel)
