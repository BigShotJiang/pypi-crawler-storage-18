from typing import Optional

from pydantic import BaseModel


class ClientOptions(BaseModel):
    """
    Class containing the Deeploy client options

    Attributes:
      nr_retries: int indicating the number of retries for each request
      nr_requests: int indicating the number of requests to split the inference into (for parallel processing)
      progress: bool indicating whether to show a progress bar or not (default: True)
      stream: bool indicating whether to stream the response or not
    """

    nr_retries: Optional[int] = None
    nr_requests: Optional[int] = None
    progress: Optional[bool] = True
    stream: Optional[bool] = None


class BaseInferenceOptions(BaseModel):
    """
    Class containing the Deeploy inference base options

    Attributes:
      skip_log: bool indicating whether to skip logging the request
    """

    skip_log: Optional[bool] = None


class ExplainInferenceOptions(BaseInferenceOptions):
    """
    Class containing the Deeploy explain options

    Attributes:
      image: bool indicating whether to return an image or not
    """

    image: Optional[bool] = None


class CompletionsInferenceOptions(BaseInferenceOptions):
    """
    Class containing the Deeploy completions options

    Attributes:
      explain: bool indicating whether to return explanations or not
    """

    explain: Optional[bool] = False
