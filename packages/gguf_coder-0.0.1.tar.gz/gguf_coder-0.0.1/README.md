## setup
```
python -m gguf_coder
```

## launch
```
coder
```