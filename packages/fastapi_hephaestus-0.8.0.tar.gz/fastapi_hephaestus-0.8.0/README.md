# 🔥 FastAPI Hephaestus

> _Named after Hephaestus, the Greek god of forge and craftsmanship_ ⚒️

A beautiful CLI tool to forge production-ready FastAPI projects with your preferred configuration in seconds.

## ✨ Features

- **Interactive & Non-Interactive Modes** - Use guided prompts or CLI flags
- **Multiple Package Managers** - uv, pip, Poetry, PDM
- **Multiple Database Support** - PostgreSQL, MySQL, SQLite, MongoDB
- **ORM/ODM Options** - SQLAlchemy, SQLModel, Beanie
- **Auto-configured Migrations** - Alembic setup for SQL databases
- **Docker Support** - Generate Dockerfile and docker-compose.yml
- **Health Check Endpoints** - Built-in `/health` and `/ready` endpoints
- **Beautiful Output** - Rich-styled console with progress indicators
- **Clean Architecture** - Generated projects follow best practices

## 📋 Prerequisites

### Required

- **Python 3.12+** - Required for running FastAPI Hephaestus and generated projects

  ```bash
  # Check your Python version
  python --version
  ```

### Package Manager Prerequisites

You need to have the package manager installed that you plan to use for your projects:

| Manager | Installation | Documentation |
|---------|--------------|---------------|
| **uv** (recommended) | `curl -LsSf https://astral.sh/uv/install.sh \| sh` (Linux/macOS)<br>`powershell -c "irm https://astral.sh/uv/install.ps1 \| iex"` (Windows) | [uv docs](https://docs.astral.sh/uv/) |
| **pip** | Included with Python | [pip docs](https://pip.pypa.io/) |
| **Poetry** | `curl -sSL https://install.python-poetry.org \| python3 -` (Linux/macOS)<br>`(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content \| python -` (Windows) | [Poetry docs](https://python-poetry.org/docs/) |
| **PDM** | `pip install pdm` or `curl -sSL https://pdm-project.org/install-pdm.py \| python3 -` | [PDM docs](https://pdm-project.org/) |

#### Verify Installation

```bash
# uv
uv --version

# pip (included with Python)
pip --version

# Poetry
poetry --version

# PDM
pdm --version
```

### Optional Prerequisites

| Tool | Required For | Installation |
|------|--------------|--------------|
| **Docker** | Using `--docker` flag | [Get Docker](https://docs.docker.com/get-docker/) |
| **Docker Compose** | Running docker-compose.yml | Included with Docker Desktop, or [install separately](https://docs.docker.com/compose/install/) |
| **Git** | Version control | [Get Git](https://git-scm.com/downloads) |

### Database Prerequisites (for development)

If you want to run databases locally without Docker:

| Database | Installation |
|----------|--------------|
| **PostgreSQL** | [PostgreSQL Downloads](https://www.postgresql.org/download/) |
| **MySQL** | [MySQL Downloads](https://dev.mysql.com/downloads/) |
| **MongoDB** | [MongoDB Downloads](https://www.mongodb.com/try/download/community) |
| **SQLite** | Included with Python |

> **Note:** When using the `--docker` flag, databases are automatically configured in docker-compose.yml, so local installation is not required.

## 📦 Installation

### Using pip

```bash
pip install fastapi-hephaestus
```

### Using uv (recommended)

```bash
uv add fastapi-hephaestus
```

### Using Poetry

```bash
poetry add fastapi-hephaestus
```

### From source

```bash
git clone https://github.com/Agsdovah95/fastapi_hephaestus.git
cd fastapi_hephaestus
pip install -e .
```

## 🎯 Quick Start

### Interactive Mode

```bash
fastapi_hephaestus init
```

### Non-Interactive Mode

```bash
# Quick start with defaults
fastapi_hephaestus init --name my-api -y

# Full customization
fastapi_hephaestus init --name my-api --pm poetry --db postgres --orm sqlmodel --docker -y
```

## 📖 Commands

### `init`

Initialize a new FastAPI project.

#### Interactive Mode

```bash
fastapi_hephaestus init
```

You'll be guided through:

1. **Project Configuration** - Name and location
2. **Package Manager** - uv, pip, poetry, or pdm
3. **Database Configuration** - Type, ORM/ODM, and database
4. **Project Details** - Description

#### Non-Interactive Mode (CLI Flags)

| Flag | Short | Description | Default |
|------|-------|-------------|---------|
| `--name` | `-n` | Project name | Current directory name |
| `--path` | `-p` | Project path | `.` (current directory) |
| `--package-manager` | `--pm` | Package manager | `uv` |
| `--db-type` | | Database type: `sql` or `nosql` | `sql` |
| `--database` | `--db` | Database name | `postgres` / `mongodb` |
| `--orm` | | ORM for SQL databases | `sqlmodel` |
| `--odm` | | ODM for NoSQL databases | `beanie` |
| `--description` | `-d` | Project description | `A FastAPI project` |
| `--docker` | | Generate Docker files | `false` |
| `--yes` | `-y` | Skip prompts, use defaults | `false` |

#### Examples

```bash
# Interactive mode
fastapi_hephaestus init

# Quick with defaults (uses uv, postgres, sqlmodel)
fastapi_hephaestus init --name my-api -y

# Poetry + PostgreSQL + SQLAlchemy
fastapi_hephaestus init --name my-api --pm poetry --db postgres --orm sqlalchemy -y

# pip + MySQL + SQLModel + Docker
fastapi_hephaestus init --name my-api --pm pip --db mysql --orm sqlmodel --docker -y

# PDM + MongoDB + Beanie
fastapi_hephaestus init --name my-api --pm pdm --db-type nosql --db mongodb -y

# Full customization with Docker
fastapi_hephaestus init \
  --name awesome-api \
  --path ./projects \
  --pm poetry \
  --db postgres \
  --orm sqlmodel \
  --description "My awesome API" \
  --docker \
  -y
```

### `build`

Build the project for production (coming soon).

```bash
fastapi_hephaestus build
```

## 📁 Generated Project Structure

After running `init`, your project will have this structure:

```
your-project/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI application
│   ├── api/                  # API routes
│   │   ├── __init__.py
│   │   └── health.py        # Health check endpoints
│   ├── config/               # Configuration
│   │   ├── __init__.py
│   │   ├── settings.py       # Pydantic settings
│   │   ├── logger.py         # Logger setup
│   │   └── security.py       # Security config
│   ├── database/             # Database connections
│   ├── models/               # Database models
│   ├── repositories/         # Data access layer
│   ├── schemas/              # Pydantic schemas
│   ├── services/             # Business logic
│   ├── utils/                # Utilities
│   └── workers/              # Background workers
├── migrations/               # Alembic migrations (SQL only)
├── tests/                    # Test files
├── .env                      # Environment variables
├── .gitignore                # Git ignore file
├── dev.py                    # Development server runner
├── project.json              # Project configuration
├── pyproject.toml            # Dependencies
│
│   # With --docker flag:
├── Dockerfile                # Multi-stage Docker build
├── docker-compose.yml        # Docker Compose with database
└── .dockerignore             # Docker ignore file
```

## 🏃 Running Your Generated Project

After initialization, the commands depend on your chosen package manager:

### uv (default)

```bash
cd your-project
uv run dev.py
```

### pip

```bash
cd your-project
source .venv/bin/activate  # Linux/macOS
# or: .venv\Scripts\activate  # Windows
python dev.py
```

### Poetry

```bash
cd your-project
poetry run python dev.py
```

### PDM

```bash
cd your-project
pdm run python dev.py
```

### Docker

```bash
cd your-project
docker-compose up --build
```

Your API will be available at:

- **API**: http://localhost:8000
- **Docs**: http://localhost:8000/docs (Scalar API Reference)
- **Health**: http://localhost:8000/health
- **Ready**: http://localhost:8000/ready

## 🐳 Docker Support

When using the `--docker` flag, the following files are generated:

### Dockerfile

- Multi-stage build for smaller images
- Optimized for your chosen package manager
- Includes health check configuration
- Production-ready with non-root user considerations

### docker-compose.yml

- Pre-configured database service (PostgreSQL, MySQL, MongoDB, or SQLite volume)
- Health checks for database readiness
- Environment variable configuration
- Persistent data volumes

### Running with Docker

```bash
# Build and run
docker-compose up --build

# Run in background
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

## ⚙️ Configuration

The generated project uses environment variables for configuration. Edit `.env`:

```env
PROJECT_NAME=Your Project Name
PROJECT_DESCRIPTION=Your project description
VERSION=0.1.0
SERVER_HOST=127.0.0.1
SERVER_PORT=8000
```

## 📦 Package Manager Support

| Manager | Init Command | Add Deps | Run Command | Lock File |
|---------|--------------|----------|-------------|-----------|
| **uv** | `uv init` | `uv add` | `uv run` | `uv.lock` |
| **pip** | `python -m venv` | `pip install` | `.venv/bin/python` | `requirements.txt` |
| **Poetry** | `poetry init` | `poetry add` | `poetry run` | `poetry.lock` |
| **PDM** | `pdm init` | `pdm add` | `pdm run` | `pdm.lock` |

## 🗄️ Database Support

| Type  | Database   | Driver    | ORM/ODM              |
|-------|------------|-----------|----------------------|
| SQL   | PostgreSQL | asyncpg   | SQLAlchemy, SQLModel |
| SQL   | MySQL      | aiomysql  | SQLAlchemy, SQLModel |
| SQL   | SQLite     | aiosqlite | SQLAlchemy, SQLModel |
| NoSQL | MongoDB    | pymongo   | Beanie               |

## 🏥 Health Check Endpoints

Every generated project includes health check endpoints:

### GET `/health`

Basic health check for load balancers and monitoring.

```json
{
  "status": "healthy",
  "version": "0.1.0"
}
```

### GET `/ready`

Readiness check for Kubernetes and orchestration systems.

```json
{
  "status": "ready",
  "database": "connected"
}
```

## 📝 Example Session

```
$ fastapi_hephaestus init

  ╔═══════════════════════════════════════════════════════════╗
  ║     🚀  FastAPI Project Initializer  🚀                   ║
  ║                                                           ║
  ║     Scaffold your next API in seconds                     ║
  ╚═══════════════════════════════════════════════════════════╝

  📋  Project Configuration
  ──────────────────────────────────────────────────
     Project Name [my-project]: awesome-api
     Initialize in [.]: ./awesome-api

  📦  Package Manager
  ──────────────────────────────────────────────────
     Options: uv │ pip │ poetry │ pdm
     Select [uv]: poetry

  🗄️  Database Configuration
  ──────────────────────────────────────────────────
     Options: sql │ nosql
     Database Type [sql]: sql
     Options: sqlalchemy │ sqlmodel
     ORM [sqlmodel]: sqlmodel
     Options: postgres │ mysql │ sqlite
     Database [postgres]: postgres

  📝  Project Details
  ──────────────────────────────────────────────────
     Description [Your description here]: My awesome API

  ⠋ Setting up FastAPI project... ████████████████████ 100%

  ╭────── ✨ Project Created Successfully! ──────╮
  │                                               │
  │  Project         awesome-api                  │
  │  Location        ./awesome-api                │
  │  Package Manager poetry                       │
  │  Database        postgres                     │
  │  ORM             sqlmodel                     │
  │                                               │
  ╰───────────────────────────────────────────────╯

  ╭────────────── 🚀 Next Steps ──────────────────╮
  │                                               │
  │  Get started with your new project:           │
  │                                               │
  │  $ cd ./awesome-api                           │
  │  $ poetry run python dev.py                   │
  │                                               │
  │  Your API will be available at:               │
  │  → http://localhost:8000                      │
  │  → http://localhost:8000/docs (API docs)      │
  │                                               │
  ╰───────────────────────────────────────────────╯
```

## 🏗️ Project Architecture

This tool follows **SOLID principles** and clean architecture:

```
fastapi_hephaestus/
├── cli.py                    # CLI commands with Typer
├── constants.py              # Configuration constants
├── console/                  # UI layer
│   ├── theme.py              # Rich theme
│   └── printer.py            # ConsoleUI class
├── models/                   # Domain models
│   └── project_config.py     # ProjectConfig dataclass
├── generators/               # File generation
│   └── file_generator.py     # FileGenerator class
├── services/                 # Business logic
│   ├── package_managers.py   # Strategy pattern for package managers
│   ├── dependency_manager.py # Dependency resolution
│   └── project_initializer.py # Orchestration
└── templates/                # File templates
    └── templates.py          # TemplateProvider class
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the BSD License - see the [LICENSE.txt](LICENSE.txt) file for details.
