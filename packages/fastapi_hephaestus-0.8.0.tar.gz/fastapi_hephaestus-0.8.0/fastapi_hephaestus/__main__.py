"""Entry point for python -m fastapi_builder."""

from fastapi_hephaestus.cli import main

if __name__ == "__main__":
    main()

