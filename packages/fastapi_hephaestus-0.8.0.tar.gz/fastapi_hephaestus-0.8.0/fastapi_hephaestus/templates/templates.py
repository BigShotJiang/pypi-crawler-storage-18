"""
Template provider for generated project files.

This module contains all file templates used when generating
a new FastAPI project structure.
"""

import textwrap
from abc import ABC, abstractmethod
from typing import Protocol


class TemplateSource(Protocol):
    """Protocol defining the interface for template sources."""

    def get_main_app_template(self) -> str:
        """Return the main FastAPI application template."""
        ...

    def get_dev_runner_template(self) -> str:
        """Return the development runner template."""
        ...

    def get_env_template(self) -> str:
        """Return the .env file template."""
        ...

    def get_init_template(self) -> str:
        """Return the __init__.py template."""
        ...

    def get_settings_template(self) -> str:
        """Return the settings.py template."""
        ...

    def get_logger_template(self) -> str:
        """Return the logger.py template."""
        ...

    def get_security_template(self) -> str:
        """Return the security.py template."""
        ...

    def get_config_init_template(self) -> str:
        """Return the config __init__.py template."""
        ...


class TemplateProvider:
    """
    Provides file templates for project generation.

    This class follows the Single Responsibility Principle by handling
    only the provision of file templates. Each template is returned as
    a properly dedented string ready for file writing.

    Example:
        >>> provider = TemplateProvider()
        >>> main_template = provider.get_main_app_template()
    """

    @staticmethod
    def get_main_app_template() -> str:
        """
        Get the main FastAPI application template.

        Returns:
            A string containing the main.py template for the generated project.
        """
        return textwrap.dedent("""\
            from dotenv import load_dotenv
            from fastapi import FastAPI
            from scalar_fastapi import get_scalar_api_reference

            from app.api.health import router as health_router
            from app.config import settings

            load_dotenv()


            def create_app() -> FastAPI:
                app = FastAPI(
                    docs_url=None,
                    redoc_url=None,
                    title=settings.project_name,
                    description=settings.project_description,
                    version=settings.version,
                )

                # Include routers
                app.include_router(health_router)

                @app.get("/docs", include_in_schema=False)
                async def docs_html():
                    return get_scalar_api_reference(
                        openapi_url=app.openapi_url,
                    )

                return app


            app = create_app()
        """)

    @staticmethod
    def get_dev_runner_template() -> str:
        """
        Get the development runner template.

        Returns:
            A string containing the dev.py template.
        """
        return textwrap.dedent("""\
            import uvicorn


            def main():
                uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)


            if __name__ == "__main__":
                main()
        """)

    @staticmethod
    def get_env_template() -> str:
        """
        Get the .env file template.

        Returns:
            A string containing the .env template with default values.
        """
        return textwrap.dedent("""\
            PROJECT_NAME=FastAPI Setup Auto Generated Project
            PROJECT_DESCRIPTION=FastAPI Setup Auto Generated Project Description
            VERSION=0.1.0
            SERVER_HOST=127.0.0.1
            SERVER_PORT=8000
        """)

    @staticmethod
    def get_init_template() -> str:
        """
        Get the generic __init__.py template.

        Returns:
            A string containing the __init__.py template.
        """
        return textwrap.dedent("""\
            "Module level imports. Place all imports here. Then export using __all__."
        """)

    @staticmethod
    def get_settings_template() -> str:
        """
        Get the settings.py template.

        Returns:
            A string containing the settings configuration template.
        """
        return textwrap.dedent("""\
            from pydantic_settings import BaseSettings, SettingsConfigDict
            from functools import lru_cache
            from pydantic import Field
            from pathlib import Path

            BASE_DIR = Path(__file__).resolve().parents[2]


            class Settings(BaseSettings):
                model_config = SettingsConfigDict(
                    env_file=f"{BASE_DIR}/.env",
                    env_file_encoding="utf-8",
                )
                
                project_name: str = Field(..., validation_alias="PROJECT_NAME")
                project_description: str = Field(..., validation_alias="PROJECT_DESCRIPTION")
                version: str = Field(..., validation_alias="VERSION")
                server_host: str = Field(..., validation_alias="SERVER_HOST")
                server_port: int = Field(..., validation_alias="SERVER_PORT")

            @lru_cache(maxsize=1)
            def get_settings() -> Settings:
                return Settings()

            settings = get_settings()
        """)

    @staticmethod
    def get_logger_template() -> str:
        """
        Get the logger.py placeholder template.

        Returns:
            A string containing the logger placeholder template.
        """
        return textwrap.dedent("""\
            "Setup Custom Logger Here"
        """)

    @staticmethod
    def get_security_template() -> str:
        """
        Get the security.py placeholder template.

        Returns:
            A string containing the security placeholder template.
        """
        return textwrap.dedent("""\
            "Setup Security Config Here"
        """)

    @staticmethod
    def get_config_init_template() -> str:
        """
        Get the config module __init__.py template.

        Returns:
            A string containing the config __init__.py template.
        """
        return textwrap.dedent("""\
            from .settings import settings

            __all__ = ["settings"]
        """)

    @staticmethod
    def get_gitignore_template() -> str:
        """
        Get the .gitignore file template.

        Returns:
            A string containing the .gitignore template.
        """
        return textwrap.dedent("""\
            # Byte-compiled / optimized / DLL files
            __pycache__/
            *.py[cod]
            *$py.class

            # Virtual environments
            .venv/
            venv/
            ENV/
            env/

            # Package manager files
            .pdm-python
            .pdm.toml
            pdm.lock
            poetry.lock
            uv.lock

            # Distribution / packaging
            dist/
            build/
            *.egg-info/
            .eggs/

            # IDE / Editor
            .idea/
            .vscode/
            *.swp
            *.swo
            *~

            # Environment variables
            .env
            .env.local
            .env.*.local

            # Testing
            .pytest_cache/
            .coverage
            htmlcov/
            .tox/
            .nox/

            # Type checking
            .mypy_cache/
            .pytype/

            # Logs
            *.log
            logs/

            # Database
            *.db
            *.sqlite3

            # OS generated files
            .DS_Store
            Thumbs.db

            # Project specific
            project.json
        """)

    @staticmethod
    def get_dockerfile_template(package_manager: str = "uv") -> str:
        """
        Get the Dockerfile template based on package manager.

        Args:
            package_manager: The package manager used (uv, pip, poetry, pdm).

        Returns:
            A string containing the Dockerfile template.
        """
        if package_manager == "uv":
            return textwrap.dedent("""\
                # Build stage
                FROM python:3.12-slim as builder

                # Install uv
                COPY --from=ghcr.io/astral-sh/uv:latest /uv /bin/uv

                WORKDIR /app

                # Copy dependency files
                COPY pyproject.toml uv.lock ./

                # Install dependencies
                RUN uv sync --frozen --no-dev

                # Production stage
                FROM python:3.12-slim

                WORKDIR /app

                # Copy virtual environment from builder
                COPY --from=builder /app/.venv /app/.venv

                # Copy application code
                COPY . .

                # Set environment variables
                ENV PATH="/app/.venv/bin:$PATH"
                ENV PYTHONUNBUFFERED=1

                # Expose port
                EXPOSE 8000

                # Health check
                HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
                    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1

                # Run the application
                CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
            """)

        elif package_manager == "poetry":
            return textwrap.dedent("""\
                # Build stage
                FROM python:3.12-slim as builder

                # Install poetry
                RUN pip install poetry

                WORKDIR /app

                # Copy dependency files
                COPY pyproject.toml poetry.lock ./

                # Configure poetry to not create virtual environment
                RUN poetry config virtualenvs.create false

                # Install dependencies
                RUN poetry install --no-dev --no-interaction --no-ansi

                # Production stage
                FROM python:3.12-slim

                WORKDIR /app

                # Copy installed packages
                COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages

                # Copy application code
                COPY . .

                # Set environment variables
                ENV PYTHONUNBUFFERED=1

                # Expose port
                EXPOSE 8000

                # Health check
                HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
                    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1

                # Run the application
                CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
            """)

        elif package_manager == "pdm":
            return textwrap.dedent("""\
                # Build stage
                FROM python:3.12-slim as builder

                # Install pdm
                RUN pip install pdm

                WORKDIR /app

                # Copy dependency files
                COPY pyproject.toml pdm.lock ./

                # Install dependencies
                RUN pdm install --prod --no-self

                # Production stage
                FROM python:3.12-slim

                WORKDIR /app

                # Copy virtual environment from builder
                COPY --from=builder /app/.venv /app/.venv

                # Copy application code
                COPY . .

                # Set environment variables
                ENV PATH="/app/.venv/bin:$PATH"
                ENV PYTHONUNBUFFERED=1

                # Expose port
                EXPOSE 8000

                # Health check
                HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
                    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1

                # Run the application
                CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
            """)

        else:  # pip
            return textwrap.dedent("""\
                # Build stage
                FROM python:3.12-slim as builder

                WORKDIR /app

                # Create virtual environment
                RUN python -m venv /app/.venv

                # Copy requirements
                COPY requirements.txt ./

                # Install dependencies
                RUN /app/.venv/bin/pip install --no-cache-dir -r requirements.txt

                # Production stage
                FROM python:3.12-slim

                WORKDIR /app

                # Copy virtual environment from builder
                COPY --from=builder /app/.venv /app/.venv

                # Copy application code
                COPY . .

                # Set environment variables
                ENV PATH="/app/.venv/bin:$PATH"
                ENV PYTHONUNBUFFERED=1

                # Expose port
                EXPOSE 8000

                # Health check
                HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
                    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1

                # Run the application
                CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
            """)

    @staticmethod
    def get_docker_compose_template(database: str = "postgres") -> str:
        """
        Get the docker-compose.yml template based on database.

        Args:
            database: The database type (postgres, mysql, sqlite, mongodb).

        Returns:
            A string containing the docker-compose.yml template.
        """
        base = textwrap.dedent("""\
            services:
              app:
                build: .
                ports:
                  - "8000:8000"
                environment:
                  - PROJECT_NAME=${PROJECT_NAME:-FastAPI App}
                  - PROJECT_DESCRIPTION=${PROJECT_DESCRIPTION:-A FastAPI application}
                  - VERSION=${VERSION:-0.1.0}
                  - SERVER_HOST=0.0.0.0
                  - SERVER_PORT=8000
        """)

        if database == "postgres":
            return base + textwrap.dedent("""\
                  - DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/app
                depends_on:
                  db:
                    condition: service_healthy
                restart: unless-stopped

              db:
                image: postgres:16-alpine
                environment:
                  - POSTGRES_USER=postgres
                  - POSTGRES_PASSWORD=postgres
                  - POSTGRES_DB=app
                volumes:
                  - postgres_data:/var/lib/postgresql/data
                ports:
                  - "5432:5432"
                healthcheck:
                  test: ["CMD-SHELL", "pg_isready -U postgres"]
                  interval: 5s
                  timeout: 5s
                  retries: 5
                restart: unless-stopped

            volumes:
              postgres_data:
            """)

        elif database == "mysql":
            return base + textwrap.dedent("""\
                  - DATABASE_URL=mysql+aiomysql://root:mysql@db:3306/app
                depends_on:
                  db:
                    condition: service_healthy
                restart: unless-stopped

              db:
                image: mysql:8
                environment:
                  - MYSQL_ROOT_PASSWORD=mysql
                  - MYSQL_DATABASE=app
                volumes:
                  - mysql_data:/var/lib/mysql
                ports:
                  - "3306:3306"
                healthcheck:
                  test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
                  interval: 5s
                  timeout: 5s
                  retries: 5
                restart: unless-stopped

            volumes:
              mysql_data:
            """)

        elif database == "mongodb":
            return base + textwrap.dedent("""\
                  - MONGODB_URL=mongodb://mongo:mongo@db:27017/app
                depends_on:
                  db:
                    condition: service_healthy
                restart: unless-stopped

              db:
                image: mongo:7
                environment:
                  - MONGO_INITDB_ROOT_USERNAME=mongo
                  - MONGO_INITDB_ROOT_PASSWORD=mongo
                  - MONGO_INITDB_DATABASE=app
                volumes:
                  - mongo_data:/data/db
                ports:
                  - "27017:27017"
                healthcheck:
                  test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017/test --quiet
                  interval: 5s
                  timeout: 5s
                  retries: 5
                restart: unless-stopped

            volumes:
              mongo_data:
            """)

        else:  # sqlite
            return base + textwrap.dedent("""\
                  - DATABASE_URL=sqlite+aiosqlite:///./app.db
                volumes:
                  - sqlite_data:/app/data
                restart: unless-stopped

            volumes:
              sqlite_data:
            """)

    @staticmethod
    def get_dockerignore_template() -> str:
        """
        Get the .dockerignore file template.

        Returns:
            A string containing the .dockerignore template.
        """
        return textwrap.dedent("""\
            # Virtual environments
            .venv/
            venv/
            ENV/
            env/

            # Git
            .git/
            .gitignore

            # IDE
            .idea/
            .vscode/

            # Python cache
            __pycache__/
            *.py[cod]
            *$py.class
            .pytest_cache/
            .mypy_cache/

            # Build artifacts
            dist/
            build/
            *.egg-info/

            # Docker
            Dockerfile
            docker-compose.yml
            .dockerignore

            # Environment files
            .env
            .env.local
            .env.*.local

            # Tests
            tests/
            htmlcov/
            .coverage

            # Documentation
            docs/
            *.md

            # Misc
            *.log
            .DS_Store
            Thumbs.db
        """)

    @staticmethod
    def get_health_router_template() -> str:
        """
        Get the health check router template.

        Returns:
            A string containing the health router template.
        """
        return textwrap.dedent("""\
            \"\"\"
            Health check endpoints for the API.
            
            These endpoints are used for container orchestration and monitoring.
            \"\"\"

            from fastapi import APIRouter, status
            from pydantic import BaseModel


            router = APIRouter(tags=["Health"])


            class HealthResponse(BaseModel):
                \"\"\"Health check response model.\"\"\"
                status: str
                version: str


            class ReadyResponse(BaseModel):
                \"\"\"Readiness check response model.\"\"\"
                status: str
                database: str


            @router.get(
                "/health",
                response_model=HealthResponse,
                status_code=status.HTTP_200_OK,
                summary="Health Check",
                description="Check if the service is running.",
            )
            async def health_check() -> HealthResponse:
                \"\"\"
                Basic health check endpoint.
                
                Returns a simple status indicating the service is running.
                Used by load balancers and container orchestration.
                \"\"\"
                from app.config import settings
                return HealthResponse(status="healthy", version=settings.version)


            @router.get(
                "/ready",
                response_model=ReadyResponse,
                status_code=status.HTTP_200_OK,
                summary="Readiness Check",
                description="Check if the service is ready to accept traffic.",
            )
            async def readiness_check() -> ReadyResponse:
                \"\"\"
                Readiness check endpoint.
                
                Verifies that the service and its dependencies are ready.
                Used by Kubernetes and other orchestration systems.
                \"\"\"
                # TODO: Add actual database connectivity check
                return ReadyResponse(status="ready", database="connected")
        """)

