"""
File templates for project generation.
"""

from fastapi_hephaestus.templates.templates import TemplateProvider

__all__ = ["TemplateProvider"]

