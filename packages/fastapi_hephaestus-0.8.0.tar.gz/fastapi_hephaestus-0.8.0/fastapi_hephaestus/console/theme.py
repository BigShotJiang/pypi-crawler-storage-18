"""
Console theme configuration.

This module defines the custom theme for Rich console output,
providing consistent styling throughout the application.
"""

from rich.console import Console
from rich.theme import Theme

# Custom theme for consistent styling across the application
custom_theme = Theme(
    {
        "info": "cyan",
        "success": "bold green",
        "warning": "bold yellow",
        "error": "bold red",
        "highlight": "bold magenta",
        "muted": "dim white",
        "accent": "bold cyan",
    }
)


def get_console() -> Console:
    """
    Create and return a configured Console instance.

    Returns:
        A Rich Console instance with the custom theme applied.
    """
    return Console(theme=custom_theme)

