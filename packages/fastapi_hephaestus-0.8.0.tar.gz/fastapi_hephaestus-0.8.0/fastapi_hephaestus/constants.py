"""
Application constants and configuration values.

This module contains all the constant values used throughout the application.
"""

from pathlib import Path

# Base directory of the application
CURRENT_DIR: Path = Path.cwd()

# Supported package managers
PACKAGE_MANAGERS: list[str] = ["uv", "pip", "poetry", "pdm"]

# Database configurations
DATABASE_TYPES: list[str] = ["sql", "nosql"]
SQL_DATABASES: list[str] = ["postgres", "mysql", "sqlite"]
NOSQL_DATABASES: list[str] = ["mongodb"]
SQL_ORMS: list[str] = ["sqlalchemy", "sqlmodel"]
NOSQL_ODMS: list[str] = ["beanie"]

# Database driver mappings
DATABASE_DRIVERS: dict[str, str] = {
    "postgres": "asyncpg",
    "mysql": "aiomysql",
    "sqlite": "aiosqlite",
    "mongodb": "pymongo",
}

# Base dependencies for all projects
BASE_DEPENDENCIES: list[str] = [
    "fastapi",
    "uvicorn",
    "scalar-fastapi",
    "pydantic_settings",
    "python-dotenv",
]

# ORM-specific dependencies
ORM_DEPENDENCIES: dict[str, list[str]] = {
    "sqlmodel": ["sqlmodel", "alembic"],
    "sqlalchemy": ["SQLAlchemy", "alembic"],
}

# ODM-specific dependencies
ODM_DEPENDENCIES: dict[str, list[str]] = {
    "beanie": ["beanie"],
}

# Project folder structure
PROJECT_FOLDERS: list[str] = [
    "models",
    "schemas",
    "repositories",
    "services",
    "utils",
    "tests",
    "config",
    "api",
    "database",
    "workers",
]

