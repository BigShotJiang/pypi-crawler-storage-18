"""
Package manager strategy classes.

This module provides strategy classes for different package managers
(uv, pip, Poetry, PDM) following the Strategy pattern.
"""

import subprocess
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Protocol


class CommandRunner(Protocol):
    """Protocol for running shell commands."""

    def run(
        self,
        command: list[str],
        cwd: Path | None = None,
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a shell command."""
        ...


class SubprocessRunner:
    """Default implementation using subprocess."""

    @staticmethod
    def run(
        command: list[str],
        cwd: Path | None = None,
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """
        Run a shell command using subprocess.

        Args:
            command: The command and arguments to run.
            cwd: The working directory for the command.
            quiet: Whether to suppress output.

        Returns:
            The completed process result.
        """
        kwargs: dict = {"cwd": cwd}
        if quiet:
            kwargs["stdout"] = subprocess.DEVNULL
            kwargs["stderr"] = subprocess.DEVNULL
        return subprocess.run(command, **kwargs)


class PackageManagerStrategy(ABC):
    """
    Abstract base class for package manager operations.

    This class defines the interface that all package manager
    implementations must follow.
    """

    def __init__(self, runner: CommandRunner | None = None) -> None:
        """
        Initialize the package manager strategy.

        Args:
            runner: Optional command runner. Uses SubprocessRunner if not provided.
        """
        self.runner = runner or SubprocessRunner()

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of the package manager."""
        ...

    @abstractmethod
    def init_project(
        self,
        path: Path,
        name: str,
        description: str,
    ) -> None:
        """
        Initialize a new project.

        Args:
            path: The path where the project will be created.
            name: The name of the project.
            description: The project description.
        """
        ...

    @abstractmethod
    def add_dependencies(
        self,
        path: Path,
        dependencies: list[str],
    ) -> None:
        """
        Add dependencies to the project.

        Args:
            path: The project path.
            dependencies: List of package names to install.
        """
        ...

    @abstractmethod
    def run_command(
        self,
        path: Path,
        command: list[str],
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """
        Run a command in the project context.

        Args:
            path: The project path.
            command: The command to run.
            quiet: Whether to suppress output.

        Returns:
            The completed process result.
        """
        ...

    @abstractmethod
    def get_run_prefix(self) -> list[str]:
        """
        Get the command prefix for running scripts.

        Returns:
            List of command parts to prefix when running scripts.
            e.g., ["uv", "run"] or ["poetry", "run"]
        """
        ...

    @abstractmethod
    def get_dev_command(self) -> str:
        """
        Get the command to run the dev server.

        Returns:
            The full command string to run dev.py
        """
        ...


class UvPackageManager(PackageManagerStrategy):
    """
    Package manager implementation for uv.

    uv is a fast, Rust-based Python package installer and resolver.
    """

    @property
    def name(self) -> str:
        return "uv"

    def init_project(
        self,
        path: Path,
        name: str,
        description: str,
    ) -> None:
        """Initialize a new uv project."""
        self.runner.run(
            [
                "uv",
                "init",
                ".",
                "--name",
                name,
                "--description",
                description,
                "--quiet",
            ],
            cwd=path,
        )

    def add_dependencies(
        self,
        path: Path,
        dependencies: list[str],
    ) -> None:
        """Add dependencies using uv add."""
        self.runner.run(
            ["uv", "add", *dependencies, "--quiet"],
            cwd=path,
        )

    def run_command(
        self,
        path: Path,
        command: list[str],
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a command using uv run."""
        return self.runner.run(
            ["uv", "run", *command],
            cwd=path,
            quiet=quiet,
        )

    def get_run_prefix(self) -> list[str]:
        return ["uv", "run"]

    def get_dev_command(self) -> str:
        return "uv run dev.py"


class PipPackageManager(PackageManagerStrategy):
    """
    Package manager implementation for pip.

    Uses standard venv and pip with requirements.txt.
    """

    @property
    def name(self) -> str:
        return "pip"

    def _get_venv_python(self, path: Path) -> str:
        """Get the path to the venv Python executable."""
        if sys.platform == "win32":
            return str(path / ".venv" / "Scripts" / "python.exe")
        return str(path / ".venv" / "bin" / "python")

    def _get_venv_pip(self, path: Path) -> str:
        """Get the path to the venv pip executable."""
        if sys.platform == "win32":
            return str(path / ".venv" / "Scripts" / "pip.exe")
        return str(path / ".venv" / "bin" / "pip")

    def init_project(
        self,
        path: Path,
        name: str,
        description: str,
    ) -> None:
        """Initialize a new pip project with venv."""
        # Create virtual environment
        self.runner.run(
            [sys.executable, "-m", "venv", ".venv"],
            cwd=path,
            quiet=True,
        )

        # Create pyproject.toml
        pyproject_content = f'''[project]
name = "{name}"
version = "0.1.0"
description = "{description}"
requires-python = ">=3.12"

[build-system]
requires = ["setuptools>=61.0.0"]
build-backend = "setuptools.build_meta"
'''
        (path / "pyproject.toml").write_text(pyproject_content)

        # Create empty requirements.txt
        (path / "requirements.txt").write_text("")

    def add_dependencies(
        self,
        path: Path,
        dependencies: list[str],
    ) -> None:
        """Add dependencies using pip install."""
        venv_pip = self._get_venv_pip(path)

        # Install dependencies
        self.runner.run(
            [venv_pip, "install", *dependencies, "-q"],
            cwd=path,
        )

        # Update requirements.txt
        requirements_file = path / "requirements.txt"
        existing = set()
        if requirements_file.exists():
            existing = set(requirements_file.read_text().strip().split("\n"))
            existing.discard("")

        all_deps = existing | set(dependencies)
        requirements_file.write_text("\n".join(sorted(all_deps)) + "\n")

    def run_command(
        self,
        path: Path,
        command: list[str],
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a command using the venv Python."""
        venv_python = self._get_venv_python(path)
        return self.runner.run(
            [venv_python, "-m", *command],
            cwd=path,
            quiet=quiet,
        )

    def get_run_prefix(self) -> list[str]:
        # For pip, we use the venv python directly
        if sys.platform == "win32":
            return [".venv\\Scripts\\python.exe"]
        return [".venv/bin/python"]

    def get_dev_command(self) -> str:
        if sys.platform == "win32":
            return ".venv\\Scripts\\python.exe dev.py"
        return ".venv/bin/python dev.py"


class PoetryPackageManager(PackageManagerStrategy):
    """
    Package manager implementation for Poetry.

    Poetry is a dependency management and packaging tool for Python.
    """

    @property
    def name(self) -> str:
        return "poetry"

    def init_project(
        self,
        path: Path,
        name: str,
        description: str,
    ) -> None:
        """Initialize a new Poetry project."""
        self.runner.run(
            [
                "poetry",
                "init",
                "--name",
                name,
                "--description",
                description,
                "--python",
                ">=3.12",
                "--no-interaction",
            ],
            cwd=path,
            quiet=True,
        )

        # Configure Poetry to create venv in project directory
        self.runner.run(
            ["poetry", "config", "virtualenvs.in-project", "true", "--local"],
            cwd=path,
            quiet=True,
        )

    def add_dependencies(
        self,
        path: Path,
        dependencies: list[str],
    ) -> None:
        """Add dependencies using poetry add."""
        self.runner.run(
            ["poetry", "add", *dependencies, "--quiet"],
            cwd=path,
        )

    def run_command(
        self,
        path: Path,
        command: list[str],
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a command using poetry run."""
        return self.runner.run(
            ["poetry", "run", *command],
            cwd=path,
            quiet=quiet,
        )

    def get_run_prefix(self) -> list[str]:
        return ["poetry", "run"]

    def get_dev_command(self) -> str:
        return "poetry run python dev.py"


class PdmPackageManager(PackageManagerStrategy):
    """
    Package manager implementation for PDM.

    PDM is a modern Python package manager with PEP 582 support.
    """

    @property
    def name(self) -> str:
        return "pdm"

    def init_project(
        self,
        path: Path,
        name: str,
        description: str,
    ) -> None:
        """Initialize a new PDM project."""
        self.runner.run(
            [
                "pdm",
                "init",
                "--non-interactive",
                "--python",
                ">=3.12",
            ],
            cwd=path,
            quiet=True,
        )

        # Update pyproject.toml with project name and description
        pyproject_path = path / "pyproject.toml"
        if pyproject_path.exists():
            content = pyproject_path.read_text()
            # PDM creates a basic pyproject.toml, update name and description
            content = content.replace('name = ""', f'name = "{name}"')
            content = content.replace('description = ""', f'description = "{description}"')
            pyproject_path.write_text(content)

    def add_dependencies(
        self,
        path: Path,
        dependencies: list[str],
    ) -> None:
        """Add dependencies using pdm add."""
        self.runner.run(
            ["pdm", "add", *dependencies, "--quiet"],
            cwd=path,
        )

    def run_command(
        self,
        path: Path,
        command: list[str],
        quiet: bool = False,
    ) -> subprocess.CompletedProcess:
        """Run a command using pdm run."""
        return self.runner.run(
            ["pdm", "run", *command],
            cwd=path,
            quiet=quiet,
        )

    def get_run_prefix(self) -> list[str]:
        return ["pdm", "run"]

    def get_dev_command(self) -> str:
        return "pdm run python dev.py"


def get_package_manager(
    name: str,
    runner: CommandRunner | None = None,
) -> PackageManagerStrategy:
    """
    Factory function to get the appropriate package manager strategy.

    Args:
        name: The name of the package manager (uv, pip, poetry, pdm).
        runner: Optional command runner to inject.

    Returns:
        The package manager strategy instance.

    Raises:
        ValueError: If an unsupported package manager is requested.
    """
    managers: dict[str, type[PackageManagerStrategy]] = {
        "uv": UvPackageManager,
        "pip": PipPackageManager,
        "poetry": PoetryPackageManager,
        "pdm": PdmPackageManager,
    }

    if name not in managers:
        raise ValueError(
            f"Unsupported package manager: {name}. "
            f"Supported: {', '.join(managers.keys())}"
        )

    return managers[name](runner=runner)

