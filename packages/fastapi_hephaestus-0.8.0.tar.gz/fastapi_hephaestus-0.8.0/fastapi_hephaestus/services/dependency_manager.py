"""
Dependency manager for project dependencies.

This module provides the DependencyManager class that handles
resolving and installing project dependencies based on configuration.
"""

from abc import ABC, abstractmethod
from pathlib import Path

from fastapi_hephaestus.constants import (
    BASE_DEPENDENCIES,
    DATABASE_DRIVERS,
    ODM_DEPENDENCIES,
    ORM_DEPENDENCIES,
)
from fastapi_hephaestus.models.project_config import ProjectConfig
from fastapi_hephaestus.services.package_managers import (
    PackageManagerStrategy,
    get_package_manager,
)


class DependencyResolver(ABC):
    """Abstract base class for dependency resolution."""

    @abstractmethod
    def resolve(self, config: ProjectConfig) -> list[str]:
        """
        Resolve dependencies based on configuration.

        Args:
            config: The project configuration.

        Returns:
            A list of dependency package names.
        """
        pass


class FastAPIDependencyResolver(DependencyResolver):
    """
    Resolves dependencies for FastAPI projects.

    This resolver determines which packages to install based on
    the project's database type, ORM/ODM selection, and database choice.
    """

    def resolve(self, config: ProjectConfig) -> list[str]:
        """
        Resolve dependencies for a FastAPI project.

        Args:
            config: The project configuration.

        Returns:
            A list of all required dependency package names.
        """
        dependencies = list(BASE_DEPENDENCIES)

        # Add ORM dependencies
        if config.orm and config.orm in ORM_DEPENDENCIES:
            dependencies.extend(ORM_DEPENDENCIES[config.orm])

        # Add ODM dependencies
        if config.odm and config.odm in ODM_DEPENDENCIES:
            dependencies.extend(ODM_DEPENDENCIES[config.odm])

        # Add database driver
        if config.database in DATABASE_DRIVERS:
            dependencies.append(DATABASE_DRIVERS[config.database])

        return dependencies


class DependencyManager:
    """
    Manages project dependencies.

    This class follows the Single Responsibility Principle by handling
    only dependency-related operations. It uses the Strategy pattern
    to support multiple package managers.

    Attributes:
        resolver: The dependency resolver for determining packages.
        _package_manager: The package manager strategy (lazily initialized).
    """

    def __init__(
        self,
        resolver: DependencyResolver | None = None,
    ) -> None:
        """
        Initialize the DependencyManager.

        Args:
            resolver: Optional dependency resolver. Uses FastAPIDependencyResolver
                     if not provided.
        """
        self.resolver = resolver or FastAPIDependencyResolver()
        self._package_manager: PackageManagerStrategy | None = None

    def _get_package_manager(self, manager_name: str) -> PackageManagerStrategy:
        """
        Get or create the package manager strategy.

        Args:
            manager_name: The name of the package manager.

        Returns:
            The package manager strategy instance.
        """
        if self._package_manager is None or self._package_manager.name != manager_name:
            self._package_manager = get_package_manager(manager_name)
        return self._package_manager

    def init_project(
        self,
        project_path: Path,
        project_name: str,
        description: str,
        package_manager: str = "uv",
    ) -> None:
        """
        Initialize a new project using the specified package manager.

        Args:
            project_path: The path where the project will be created.
            project_name: The name of the project.
            description: The project description.
            package_manager: The package manager to use (uv, pip, poetry, pdm).
        """
        manager = self._get_package_manager(package_manager)
        manager.init_project(project_path, project_name, description)

    def install_dependencies(self, config: ProjectConfig) -> None:
        """
        Install project dependencies based on configuration.

        Args:
            config: The project configuration.
        """
        dependencies = self.resolver.resolve(config)
        manager = self._get_package_manager(config.package_manager)
        manager.add_dependencies(config.path, dependencies)

    def init_alembic(self, project_path: Path, package_manager: str = "uv") -> None:
        """
        Initialize Alembic for database migrations.

        Args:
            project_path: The path to the project.
            package_manager: The package manager to use for running alembic.
        """
        manager = self._get_package_manager(package_manager)
        manager.run_command(
            project_path,
            ["alembic", "init", "migrations", "--template", "async"],
            quiet=True,
        )

    def get_dev_command(self, package_manager: str = "uv") -> str:
        """
        Get the command to run the development server.

        Args:
            package_manager: The package manager being used.

        Returns:
            The command string to run dev.py.
        """
        manager = self._get_package_manager(package_manager)
        return manager.get_dev_command()
