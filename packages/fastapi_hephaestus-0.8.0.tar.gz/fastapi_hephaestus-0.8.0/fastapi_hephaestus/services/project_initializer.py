"""
Project initializer orchestrator.

This module provides the ProjectInitializer class that orchestrates
the entire project initialization process.
"""

import json
from pathlib import Path
from typing import Callable

from fastapi_hephaestus.console.printer import ConsoleUI
from fastapi_hephaestus.generators.file_generator import FileGenerator
from fastapi_hephaestus.models.project_config import ProjectConfig
from fastapi_hephaestus.services.dependency_manager import DependencyManager


class ProjectInitializer:
    """
    Orchestrates the project initialization process.

    This class follows the Single Responsibility Principle by handling
    only the orchestration of project initialization. It delegates
    specific tasks to specialized classes.

    The class also follows the Dependency Inversion Principle by
    depending on abstractions (injected dependencies) rather than
    concrete implementations.

    Attributes:
        ui: The console UI for user interaction and feedback.
        dependency_manager: The manager for handling dependencies.
        file_generator: The generator for creating project files.
    """

    def __init__(
        self,
        ui: ConsoleUI | None = None,
        dependency_manager: DependencyManager | None = None,
        file_generator: FileGenerator | None = None,
    ) -> None:
        """
        Initialize the ProjectInitializer.

        Args:
            ui: Optional console UI. Creates a new instance if not provided.
            dependency_manager: Optional dependency manager. Creates a new
                              instance if not provided.
            file_generator: Optional file generator. Creates a new instance
                          if not provided.
        """
        self.ui = ui or ConsoleUI()
        self.dependency_manager = dependency_manager or DependencyManager()
        self.file_generator = file_generator or FileGenerator()

    def validate_project_path(self, project_path: Path) -> bool:
        """
        Validate that a project can be created at the given path.

        Args:
            project_path: The path to validate.

        Returns:
            True if the path is valid for project creation, False otherwise.
        """
        if (project_path / "project.json").exists():
            self.ui.print_error("Project already initialized in this directory!")
            return False
        return True

    def ensure_directory_exists(self, project_path: Path) -> None:
        """
        Ensure the project directory exists.

        Args:
            project_path: The path to create if it doesn't exist.
        """
        if not project_path.exists():
            project_path.mkdir(parents=True, exist_ok=True)

    def save_project_config(self, config: ProjectConfig) -> None:
        """
        Save the project configuration to project.json.

        Args:
            config: The project configuration to save.
        """
        with open(config.path / "project.json", "w") as f:
            json.dump(config.to_dict(), f, indent=4)

    def initialize(
        self,
        config: ProjectConfig,
        progress_callback: Callable[[str], None] | None = None,
    ) -> bool:
        """
        Initialize a new FastAPI project.

        This method orchestrates the entire initialization process:
        1. Validates the project path
        2. Creates the directory
        3. Saves the configuration
        4. Initializes the uv project
        5. Installs dependencies
        6. Sets up database migrations (if SQL)
        7. Generates project structure and files

        Args:
            config: The project configuration.
            progress_callback: Optional callback for progress updates.
                             Receives a description string.

        Returns:
            True if initialization was successful, False otherwise.
        """
        # Validate project path
        if not self.validate_project_path(config.path):
            return False

        # Ensure directory exists
        self.ensure_directory_exists(config.path)

        # Save configuration
        self.save_project_config(config)

        # Initialize project with selected package manager
        if progress_callback:
            progress_callback(f"Initializing project with {config.package_manager}...")
        self.dependency_manager.init_project(
            config.path,
            config.name,
            config.description,
            config.package_manager,
        )

        # Install dependencies
        if progress_callback:
            progress_callback("Installing dependencies...")
        self.dependency_manager.install_dependencies(config)

        # Initialize Alembic for SQL projects
        if progress_callback:
            progress_callback("Configuring database...")
        if config.uses_alembic:
            self.dependency_manager.init_alembic(config.path, config.package_manager)

        # Generate project structure and files
        if progress_callback:
            progress_callback("Creating project structure and files...")
        self.file_generator.generate_all(config)

        return True

