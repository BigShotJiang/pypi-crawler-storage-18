"""
FastAPI Project Initializer - CLI Tool.

A beautiful CLI tool to scaffold FastAPI projects with your preferred configuration.
"""

__version__ = "0.2.0"
__author__ = "FastAPI Tools"

__all__ = ["__version__", "__author__"]

