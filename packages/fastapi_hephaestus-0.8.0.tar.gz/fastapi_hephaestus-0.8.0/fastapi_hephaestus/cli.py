"""
Command Line Interface for FastAPI Project Initializer.

This module defines the CLI commands using Typer and orchestrates
the user interaction through the console UI and services.
"""

from pathlib import Path
from typing import Annotated, Optional

import typer

from fastapi_hephaestus.console.printer import ConsoleUI
from fastapi_hephaestus.constants import (
    CURRENT_DIR,
    DATABASE_TYPES,
    NOSQL_DATABASES,
    NOSQL_ODMS,
    PACKAGE_MANAGERS,
    SQL_DATABASES,
    SQL_ORMS,
)
from fastapi_hephaestus.models.project_config import ProjectConfig
from fastapi_hephaestus.services.project_initializer import ProjectInitializer


# Typer application instance
app = typer.Typer(
    name="fastapi-hephaestus",
    help="FastAPI Hephaestus - Forge production-ready FastAPI projects in seconds.",
    add_completion=False,
)


class InitCommand:
    """
    Handler for the init command.

    This class encapsulates the logic for the project initialization
    command, collecting user input and delegating to the appropriate services.

    Attributes:
        ui: The console UI for user interaction.
        initializer: The project initializer service.
    """

    def __init__(
        self,
        ui: ConsoleUI | None = None,
        initializer: ProjectInitializer | None = None,
    ) -> None:
        """
        Initialize the InitCommand handler.

        Args:
            ui: Optional console UI. Creates a new instance if not provided.
            initializer: Optional project initializer. Creates a new instance
                        if not provided.
        """
        self.ui = ui or ConsoleUI()
        self.initializer = initializer or ProjectInitializer(ui=self.ui)

    def collect_project_config(self) -> tuple[str, Path]:
        """
        Collect basic project configuration from user.

        Returns:
            A tuple of (project_name, project_path).

        Raises:
            typer.Exit: If the project is already initialized.
        """
        self.ui.print_section("Project Configuration", "📋")

        project_name = typer.prompt(
            self.ui.styled_prompt("Project Name"),
            default=CURRENT_DIR.name,
        )

        project_path_input = typer.prompt(
            self.ui.styled_prompt("Initialize in"),
            default=".",
        )
        project_path = (
            CURRENT_DIR / project_path_input
            if project_path_input != "."
            else CURRENT_DIR
        )

        return project_name, project_path

    def collect_package_manager(self) -> str:
        """
        Collect package manager selection from user.

        Returns:
            The selected package manager.

        Raises:
            typer.Exit: If an invalid selection is made.
        """
        self.ui.print_section("Package Manager", "📦")
        self.ui.print_options(PACKAGE_MANAGERS)

        package_manager = typer.prompt(
            self.ui.styled_prompt("Select"),
            default="uv",
        )

        if package_manager not in PACKAGE_MANAGERS:
            self.ui.print_error(
                f"Invalid package manager! Must be one of: {', '.join(PACKAGE_MANAGERS)}"
            )
            raise typer.Exit(1)

        return package_manager

    def collect_database_config(self) -> tuple[str, str, str | None, str | None]:
        """
        Collect database configuration from user.

        Returns:
            A tuple of (database_type, database, orm, odm).

        Raises:
            typer.Exit: If invalid selections are made.
        """
        self.ui.print_section("Database Configuration", "🗄️")
        self.ui.print_options(DATABASE_TYPES)

        database_type = typer.prompt(
            self.ui.styled_prompt("Database Type"),
            default="sql",
        )

        if database_type not in DATABASE_TYPES:
            self.ui.print_error(
                f"Invalid database type! Must be one of: {', '.join(DATABASE_TYPES)}"
            )
            raise typer.Exit(1)

        orm = None
        odm = None

        # SQL configuration
        if database_type == "sql":
            self.ui.print_newline()
            self.ui.print_options(SQL_ORMS)
            orm = typer.prompt(self.ui.styled_prompt("ORM"), default="sqlmodel")

            if orm not in SQL_ORMS:
                self.ui.print_error(
                    f"Invalid ORM! Must be one of: {', '.join(SQL_ORMS)}"
                )
                raise typer.Exit(1)

            database_options = SQL_DATABASES
            default_database = "postgres"

        # NoSQL configuration
        else:
            self.ui.print_newline()
            self.ui.print_options(NOSQL_ODMS)
            odm = typer.prompt(self.ui.styled_prompt("ODM"), default="beanie")

            if odm not in NOSQL_ODMS:
                self.ui.print_error(
                    f"Invalid ODM! Must be one of: {', '.join(NOSQL_ODMS)}"
                )
                raise typer.Exit(1)

            database_options = NOSQL_DATABASES
            default_database = "mongodb"

        # Database selection
        self.ui.print_newline()
        self.ui.print_options(database_options)
        database = typer.prompt(
            self.ui.styled_prompt("Database"),
            default=default_database,
        )

        if database not in database_options:
            self.ui.print_error(
                f"Invalid database! Must be one of: {', '.join(database_options)}"
            )
            raise typer.Exit(1)

        return database_type, database, orm, odm

    def collect_project_details(self) -> str:
        """
        Collect project details from user.

        Returns:
            The project description.
        """
        self.ui.print_section("Project Details", "📝")

        description = typer.prompt(
            self.ui.styled_prompt("Description"),
            default="Your description here",
        )

        return description

    def run_with_progress(self, config: ProjectConfig) -> bool:
        """
        Run project initialization with progress display.

        Args:
            config: The project configuration.

        Returns:
            True if successful, False otherwise.
        """
        self.ui.print_newline(2)

        with self.ui.create_progress() as progress:
            task = progress.add_task("  Setting up FastAPI project...", total=4)

            def update_progress(description: str) -> None:
                progress.update(task, description=f"  [cyan]{description}[/cyan]")
                progress.advance(task)

            success = self.initializer.initialize(config, update_progress)

            if success:
                progress.update(task, description="  [green]✓ Setup complete![/green]")

        return success

    def execute(self) -> None:
        """
        Execute the init command in interactive mode.

        Collects all user input, creates a ProjectConfig, and runs
        the project initialization with progress display.
        """
        self.ui.print_header()

        # Collect configuration
        project_name, project_path = self.collect_project_config()

        # Validate path early
        if (project_path / "project.json").exists():
            self.ui.print_error("Project already initialized in this directory!")
            raise typer.Exit(1)

        # Ensure directory exists
        if not project_path.exists():
            project_path.mkdir(parents=True, exist_ok=True)

        package_manager = self.collect_package_manager()
        database_type, database, orm, odm = self.collect_database_config()
        description = self.collect_project_details()

        # Create configuration
        config = ProjectConfig(
            name=project_name,
            path=project_path,
            description=description,
            package_manager=package_manager,
            database_type=database_type,
            database=database,
            orm=orm,
            odm=odm,
        )

        # Run initialization
        success = self.run_with_progress(config)

        if success:
            self.ui.print_project_summary(config)
            self.ui.print_next_steps(str(config.path), config.package_manager)

    def execute_non_interactive(
        self,
        name: str,
        path: Path,
        package_manager: str,
        db_type: str,
        database: str,
        orm: str | None,
        odm: str | None,
        description: str,
        docker: bool,
    ) -> None:
        """
        Execute the init command in non-interactive mode.

        Args:
            name: Project name.
            path: Project path.
            package_manager: Package manager to use.
            db_type: Database type (sql/nosql).
            database: Database name.
            orm: ORM name (for SQL).
            odm: ODM name (for NoSQL).
            description: Project description.
            docker: Whether to generate Docker files.
        """
        self.ui.print_header()

        # Validate path
        if (path / "project.json").exists():
            self.ui.print_error("Project already initialized in this directory!")
            raise typer.Exit(1)

        # Ensure directory exists
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)

        # Create configuration
        config = ProjectConfig(
            name=name,
            path=path,
            description=description,
            package_manager=package_manager,
            database_type=db_type,
            database=database,
            orm=orm,
            odm=odm,
            docker=docker,
        )

        # Run initialization
        success = self.run_with_progress(config)

        if success:
            self.ui.print_project_summary(config)
            self.ui.print_next_steps(str(config.path), config.package_manager)


class BuildCommand:
    """
    Handler for the build command.

    Attributes:
        ui: The console UI for user interaction.
    """

    def __init__(self, ui: ConsoleUI | None = None) -> None:
        """
        Initialize the BuildCommand handler.

        Args:
            ui: Optional console UI. Creates a new instance if not provided.
        """
        self.ui = ui or ConsoleUI()

    def execute(self) -> None:
        """Execute the build command."""
        self.ui.print_build_header()
        self.ui.print_warning("Build command not yet implemented")
        self.ui.print_newline()


# ─────────────────────────────────────────────────────────────
# CLI Commands
# ─────────────────────────────────────────────────────────────


def validate_options(
    db_type: str,
    database: str,
    orm: str | None,
    odm: str | None,
    package_manager: str,
) -> None:
    """
    Validate CLI options for non-interactive mode.

    Args:
        db_type: Database type.
        database: Database name.
        orm: ORM name.
        odm: ODM name.
        package_manager: Package manager name.

    Raises:
        typer.BadParameter: If validation fails.
    """
    if package_manager not in PACKAGE_MANAGERS:
        raise typer.BadParameter(
            f"Invalid package manager '{package_manager}'. "
            f"Must be one of: {', '.join(PACKAGE_MANAGERS)}"
        )

    if db_type not in DATABASE_TYPES:
        raise typer.BadParameter(
            f"Invalid database type '{db_type}'. "
            f"Must be one of: {', '.join(DATABASE_TYPES)}"
        )

    if db_type == "sql":
        if database not in SQL_DATABASES:
            raise typer.BadParameter(
                f"Invalid SQL database '{database}'. "
                f"Must be one of: {', '.join(SQL_DATABASES)}"
            )
        if orm and orm not in SQL_ORMS:
            raise typer.BadParameter(
                f"Invalid ORM '{orm}'. "
                f"Must be one of: {', '.join(SQL_ORMS)}"
            )
    else:
        if database not in NOSQL_DATABASES:
            raise typer.BadParameter(
                f"Invalid NoSQL database '{database}'. "
                f"Must be one of: {', '.join(NOSQL_DATABASES)}"
            )
        if odm and odm not in NOSQL_ODMS:
            raise typer.BadParameter(
                f"Invalid ODM '{odm}'. "
                f"Must be one of: {', '.join(NOSQL_ODMS)}"
            )


@app.command()
def init(
    name: Annotated[
        Optional[str],
        typer.Option(
            "--name", "-n",
            help="Project name",
        ),
    ] = None,
    path: Annotated[
        Optional[str],
        typer.Option(
            "--path", "-p",
            help="Project path (default: current directory)",
        ),
    ] = None,
    package_manager: Annotated[
        str,
        typer.Option(
            "--pm", "--package-manager",
            help="Package manager: uv, pip, poetry, pdm",
        ),
    ] = "uv",
    db_type: Annotated[
        str,
        typer.Option(
            "--db-type",
            help="Database type: sql, nosql",
        ),
    ] = "sql",
    database: Annotated[
        Optional[str],
        typer.Option(
            "--db", "--database",
            help="Database: postgres, mysql, sqlite, mongodb",
        ),
    ] = None,
    orm: Annotated[
        Optional[str],
        typer.Option(
            "--orm",
            help="ORM for SQL: sqlalchemy, sqlmodel",
        ),
    ] = None,
    odm: Annotated[
        Optional[str],
        typer.Option(
            "--odm",
            help="ODM for NoSQL: beanie",
        ),
    ] = None,
    description: Annotated[
        str,
        typer.Option(
            "--description", "-d",
            help="Project description",
        ),
    ] = "A FastAPI project",
    docker: Annotated[
        bool,
        typer.Option(
            "--docker",
            help="Generate Dockerfile and docker-compose.yml",
        ),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes", "-y",
            help="Skip prompts, use defaults or provided options",
        ),
    ] = False,
) -> None:
    """
    Initialize a new FastAPI project.

    Run without flags for interactive mode, or use flags for non-interactive mode.

    Examples:

        # Interactive mode
        fastapi_hephaestus init

        # Non-interactive with defaults
        fastapi_hephaestus init --name my-api -y

        # Full non-interactive
        fastapi_hephaestus init --name my-api --pm poetry --db postgres --orm sqlmodel --docker -y
    """
    command = InitCommand()

    # If no name provided and not using -y flag, run interactive mode
    if name is None and not yes:
        command.execute()
        return

    # Non-interactive mode
    # Set defaults based on db_type
    if database is None:
        database = "postgres" if db_type == "sql" else "mongodb"

    if db_type == "sql" and orm is None:
        orm = "sqlmodel"
    elif db_type == "nosql" and odm is None:
        odm = "beanie"

    # Resolve project name and path
    project_name = name or CURRENT_DIR.name
    project_path = CURRENT_DIR / path if path else CURRENT_DIR

    # Validate options
    validate_options(db_type, database, orm, odm, package_manager)

    # Execute non-interactive
    command.execute_non_interactive(
        name=project_name,
        path=project_path,
        package_manager=package_manager,
        db_type=db_type,
        database=database,
        orm=orm if db_type == "sql" else None,
        odm=odm if db_type == "nosql" else None,
        description=description,
        docker=docker,
    )


@app.command()
def build() -> None:
    """
    Build the project for production.

    Note: This command is not yet implemented.
    """
    command = BuildCommand()
    command.execute()


def main() -> None:
    """Entry point for the CLI application."""
    app()
