"""
File generator for creating project structure and files.

This module provides the FileGenerator class that handles
creating directories and files for a new FastAPI project.
"""

import os
from pathlib import Path
from typing import Protocol

from fastapi_hephaestus.constants import PROJECT_FOLDERS
from fastapi_hephaestus.models.project_config import ProjectConfig
from fastapi_hephaestus.templates.templates import TemplateProvider


class FileWriter(Protocol):
    """Protocol for file writing operations."""

    def write(self, path: Path, content: str) -> None:
        """Write content to a file."""
        ...


class DefaultFileWriter:
    """Default implementation of file writing."""

    @staticmethod
    def write(path: Path, content: str) -> None:
        """
        Write content to a file.

        Args:
            path: The file path to write to.
            content: The content to write.
        """
        with open(path, "w") as f:
            f.write(content)


class FileGenerator:
    """
    Generates project structure and files.

    This class follows the Single Responsibility Principle by handling
    only file generation operations. It creates the directory structure
    and populates files with appropriate templates.

    Attributes:
        template_provider: The template provider for file content.
        file_writer: The file writer implementation.
    """

    def __init__(
        self,
        template_provider: TemplateProvider | None = None,
        file_writer: FileWriter | None = None,
    ) -> None:
        """
        Initialize the FileGenerator.

        Args:
            template_provider: Optional template provider. Creates a new
                             instance if not provided.
            file_writer: Optional file writer. Uses DefaultFileWriter if
                        not provided.
        """
        self.template_provider = template_provider or TemplateProvider()
        self.file_writer = file_writer or DefaultFileWriter()

    def create_directory_structure(self, project_path: Path) -> None:
        """
        Create the project directory structure.

        Creates all the standard folders for a FastAPI project
        including models, schemas, repositories, services, etc.

        Args:
            project_path: The root path of the project.
        """
        for folder in PROJECT_FOLDERS:
            (project_path / "app" / folder).mkdir(parents=True, exist_ok=True)

    def create_main_app_file(self, project_path: Path) -> None:
        """
        Create the main FastAPI application file.

        Args:
            project_path: The root path of the project.
        """
        content = self.template_provider.get_main_app_template()
        self.file_writer.write(project_path / "app" / "main.py", content)

    def create_dev_runner_file(self, project_path: Path) -> None:
        """
        Create the development runner file.

        Args:
            project_path: The root path of the project.
        """
        content = self.template_provider.get_dev_runner_template()
        self.file_writer.write(project_path / "dev.py", content)

    def create_env_file(self, project_path: Path) -> None:
        """
        Create the .env configuration file.

        Args:
            project_path: The root path of the project.
        """
        content = self.template_provider.get_env_template()
        self.file_writer.write(project_path / ".env", content)

    def create_init_files(self, project_path: Path) -> None:
        """
        Create __init__.py files in all directories.

        Walks through the project directory and creates appropriate
        __init__.py files. The config directory gets special treatment
        with additional configuration files.

        Args:
            project_path: The root path of the project.
        """
        # Directories to skip when creating __init__.py files
        skip_dirs = {".venv", ".git", "__pycache__", "node_modules", "migrations"}

        for root, dirs, files in os.walk(project_path):
            # Modify dirs in-place to skip certain directories
            dirs[:] = [d for d in dirs if d not in skip_dirs]

            for directory in dirs:
                dir_path = Path(root) / directory

                # Create standard __init__.py
                init_content = self.template_provider.get_init_template()
                self.file_writer.write(dir_path / "__init__.py", init_content)

                # Special handling for config directory
                if directory == "config":
                    self._create_config_files(dir_path)

    def _create_config_files(self, config_path: Path) -> None:
        """
        Create configuration files in the config directory.

        Creates settings.py, logger.py, security.py, and updates
        __init__.py with proper exports.

        Args:
            config_path: The path to the config directory.
        """
        # Settings file
        settings_content = self.template_provider.get_settings_template()
        self.file_writer.write(config_path / "settings.py", settings_content)

        # Logger placeholder
        logger_content = self.template_provider.get_logger_template()
        self.file_writer.write(config_path / "logger.py", logger_content)

        # Security placeholder
        security_content = self.template_provider.get_security_template()
        self.file_writer.write(config_path / "security.py", security_content)

        # Update __init__.py with exports
        init_content = self.template_provider.get_config_init_template()
        self.file_writer.write(config_path / "__init__.py", init_content)

    def remove_default_main(self, project_path: Path) -> None:
        """
        Remove the default main.py created by uv init.

        Args:
            project_path: The root path of the project.
        """
        default_main = project_path / "main.py"
        if default_main.exists():
            default_main.unlink()

    def create_gitignore_file(self, project_path: Path) -> None:
        """
        Create the .gitignore file.

        Args:
            project_path: The root path of the project.
        """
        content = self.template_provider.get_gitignore_template()
        self.file_writer.write(project_path / ".gitignore", content)

    def create_health_router(self, project_path: Path) -> None:
        """
        Create the health check router file.

        Args:
            project_path: The root path of the project.
        """
        content = self.template_provider.get_health_router_template()
        self.file_writer.write(project_path / "app" / "api" / "health.py", content)

    def create_docker_files(self, config: ProjectConfig) -> None:
        """
        Create Docker-related files.

        Creates Dockerfile, docker-compose.yml, and .dockerignore
        based on the project configuration.

        Args:
            config: The project configuration.
        """
        # Dockerfile
        dockerfile_content = self.template_provider.get_dockerfile_template(
            config.package_manager
        )
        self.file_writer.write(config.path / "Dockerfile", dockerfile_content)

        # docker-compose.yml
        compose_content = self.template_provider.get_docker_compose_template(
            config.database
        )
        self.file_writer.write(config.path / "docker-compose.yml", compose_content)

        # .dockerignore
        dockerignore_content = self.template_provider.get_dockerignore_template()
        self.file_writer.write(config.path / ".dockerignore", dockerignore_content)

    def generate_all(self, config: ProjectConfig) -> None:
        """
        Generate all project files and structure.

        This is the main entry point for generating a complete
        project structure based on the configuration.

        Args:
            config: The project configuration.
        """
        self.create_directory_structure(config.path)
        self.create_main_app_file(config.path)
        self.create_dev_runner_file(config.path)
        self.create_env_file(config.path)
        self.create_gitignore_file(config.path)
        self.create_health_router(config.path)
        self.remove_default_main(config.path)
        self.create_init_files(config.path)

        # Generate Docker files if requested
        if config.docker:
            self.create_docker_files(config)

