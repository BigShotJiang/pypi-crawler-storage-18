"""
Project configuration data model.

This module defines the data structure for project configuration
using dataclasses for immutability and type safety.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class ProjectConfig:
    """
    Immutable data class representing a project configuration.

    This class holds all the configuration options for a FastAPI project
    including name, path, database settings, and package manager preferences.

    Attributes:
        name: The name of the project.
        path: The file system path where the project will be created.
        description: A brief description of the project.
        package_manager: The package manager to use (uv, pip, poetry, pdm).
        database_type: The type of database (sql or nosql).
        database: The specific database to use (postgres, mysql, sqlite, mongodb).
        orm: The ORM to use for SQL databases (sqlalchemy, sqlmodel).
        odm: The ODM to use for NoSQL databases (beanie).
        docker: Whether to generate Docker configuration files.
    """

    name: str
    path: Path
    description: str = "Your description here"
    package_manager: str = "uv"
    database_type: str = "sql"
    database: str = "postgres"
    orm: Optional[str] = None
    odm: Optional[str] = None
    docker: bool = False

    def to_dict(self) -> dict:
        """
        Convert the configuration to a dictionary.

        Returns:
            A dictionary representation of the project configuration,
            suitable for JSON serialization.
        """
        return {
            "name": self.name,
            "description": self.description,
            "package_manager": self.package_manager,
            "database_type": self.database_type,
            "orm_selection": self.orm,
            "odm_selection": self.odm,
            "database_selection": self.database,
            "docker": self.docker,
        }

    @property
    def is_sql(self) -> bool:
        """Check if the project uses a SQL database."""
        return self.database_type == "sql"

    @property
    def is_nosql(self) -> bool:
        """Check if the project uses a NoSQL database."""
        return self.database_type == "nosql"

    @property
    def uses_alembic(self) -> bool:
        """Check if the project requires Alembic migrations."""
        return self.is_sql and self.orm in ["sqlalchemy", "sqlmodel"]

