# CANoe MCP Server

## Installation

### Using uvx (Recommended)
```bash
uvx canoe-mcp-server
```

### Using pip
```bash
pip install canoe-mcp-server
```

### From source
```bash
git clone https://github.com/MohamedHamed19m/CANoe_MCP.git
cd CANoe_MCP
pip install -e .
```

## Quick Start

1. **Start CANoe** with your configuration
2. **Run the MCP server:**
```bash
   canoe-mcp
```

## Configuration for Claude Desktop

Add to your `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "canoe": {
      "command": "uvx",
      "args": ["canoe-mcp-server"]
    }
  }
}
```

[Rest of your existing README...]