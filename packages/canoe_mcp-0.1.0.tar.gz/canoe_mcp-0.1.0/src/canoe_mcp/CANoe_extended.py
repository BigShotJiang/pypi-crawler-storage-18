from py_canoe import CANoe
from py_canoe.py_canoe import CANoe, PyCanoeException, DoTestModuleEventsUntil
import pythoncom
import sys
import win32com.client
import time


class Advanced_CANoe(CANoe):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def attach_to_running_instance(self):
        """Attach to a running CANoe instance."""
        try:
            # 1. Initialize COM library and CANoe Application COM object
            self._CANoe__init_canoe_application()
            
            # 2. Check if a configuration is already loaded in the CANoe instance
            if not self.application_com_obj.Configuration.Path: # Access Configuration via application_com_obj
                raise PyCanoeException("No configuration is loaded in the running CANoe instance.")
            
            # 3. Initialize all other CANoe COM objects
            self._CANoe__init_canoe_application_measurement()
            self._CANoe__init_canoe_application_simulation()
            self._CANoe__init_canoe_application_version()
            self.application_com_obj.Visible = True  # Ensure CANoe UI is visible

            self._CANoe__init_canoe_application_bus()
            self._CANoe__init_canoe_application_capl()
            self._CANoe__init_canoe_application_configuration()
            self._CANoe__init_canoe_application_environment()
            self._CANoe__init_canoe_application_networks()
            self._CANoe__init_canoe_application_system()
            self._CANoe__init_canoe_application_ui()
            self._CANoe__init_logging_collection()

            self._CANoe__log.debug(f'Successfully attached to running CANoe instance')
            return True


        except Exception as e:
            error_message = f"Failed to attach to running CANoe instance: {str(e)}"
            return False