"""CANoe MCP Server - Control Vector CANoe through MCP."""

__version__ = "0.1.0"
__author__ = "Mohamed Hamed"
__email__ = "your-email@example.com"

from canoe_mcp.server import main

__all__ = ["main"]