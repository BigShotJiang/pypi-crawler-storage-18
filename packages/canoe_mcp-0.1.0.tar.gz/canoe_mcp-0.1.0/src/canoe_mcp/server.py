from fastmcp import FastMCP
import asyncio
from canoe_mcp.CANoe_extended import Advanced_CANoe

# ---------------------- MCP Server Setup ----------------------
mcp = FastMCP(
    name="CANoe_MCP_Server",
    instructions="CANoe MCP server to control CANoe (attaching, start measuremns , disable measuremnts, compile all capl nodes)."
)

canoe_inst = Advanced_CANoe()



# ---------------------- Tools defintions ----------------------
@mcp.tool(
        name="attach_canoe_to_canoe_instance",
        tags={"canoe", "attach", "simulation"},
        description="""
        Connects the MCP server to an existing, running CANoe instance.
        Use this tool first when you need to do any action using CANoe.
        - Requires CANoe to be pre-launched externally.
        - Returns a connection status string + canoe path.
""",
        annotations={
            "idempotentHint": False,  # Only call once per session
        }
)
async def attach_canoe() -> str:
    try:
        attached = await asyncio.to_thread(canoe_inst.attach_to_running_instance)
        if attached:
            # accessing COM objects in the worker thread via lambda to read path
            config_path = await asyncio.to_thread(lambda: canoe_inst.application_com_obj.Configuration.Path)
            return f"Successfully attached to running CANoe instance with configuration: {config_path}"
        else:
            return "Failed to attach to running CANoe instance."
    except Exception as e:
        return f"Error attaching to running CANoe instance: {str(e)}"

@mcp.tool(
        name="compile_all_capl_nodes",
        tags={"canoe", "compile", "capl"},
        description="""
        Compiles all CAPL nodes in the currently loaded CANoe configuration.
        - Requires an active connection to a running CANoe instance.
        - Returns the compilation result as a dict.
        """,
        annotations={
            "idempotentHint": True,  # Can be called multiple times
        }
)
async def compile_nodes() -> dict:
    try:
        config_path = await asyncio.to_thread(lambda: canoe_inst.application_com_obj.Configuration.Path)
        if not config_path:
            return {"status": "error", "message": "No configuration is loaded in the CANoe instance."}
        
        await asyncio.to_thread(canoe_inst.clear_write_window_content)        

        await asyncio.to_thread(canoe_inst.compile_all_capl_nodes)

        compile_result = await asyncio.to_thread(canoe_inst.read_text_from_write_window)
        
        return {"status": "success", "message": compile_result}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    
@mcp.tool(
        name="start_measurement",
        tags={"canoe", "measurement", "simulation"},
        description="""
        Starts the CANoe measurement (simulation).
        - Requires an active connection to a running CANoe instance.
        - Returns a success or error message.
        """,
        annotations={
            "idempotentHint": False,
        }
)
async def start_measurement() -> str:
    try:
        await asyncio.to_thread(canoe_inst.start_measurement)
        return "CANoe measurement started successfully."
    except Exception as e:
        return f"Error starting CANoe measurement: {str(e)}"

@mcp.tool(
        name="stop_measurement",
        tags={"canoe", "measurement", "simulation"},
        description="""
        Stops the currently running CANoe measurement (simulation).
        - Requires an active connection to a running CANoe instance.
        - Returns a success or error message.
        """,
        annotations={
            "idempotentHint": False,
        }
)
async def stop_measurement() -> str:
    try:
        await asyncio.to_thread(canoe_inst.stop_measurement)
        return "CANoe measurement stopped successfully."
    except Exception as e:
        return f"Error stopping CANoe measurement: {str(e)}"

@mcp.tool(
        name="reset_measurement",
        tags={"canoe", "measurement", "simulation"},
        description="""
        Resets the CANoe measurement (simulation) to its initial state.
        - Requires an active connection to a running CANoe instance.
        - Returns a success or error message.
        """,
        annotations={
            "idempotentHint": True,
        }
)
async def reset_measurement() -> str:
    try:
        await asyncio.to_thread(canoe_inst.reset_measurement)
        return "CANoe measurement reset successfully."
    except Exception as e:
        return f"Error resetting CANoe measurement: {str(e)}"


# -------------------------
# Run MCP server
# -------------------------
def main():
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()

 