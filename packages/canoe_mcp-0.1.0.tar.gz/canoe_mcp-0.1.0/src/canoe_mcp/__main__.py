"""Entry point for running the CANoe MCP server."""
# Makes package runnable as a module with python -m canoe_mcp
from canoe_mcp.server import main

if __name__ == "__main__":
    main()