# zhtree

增强版 tree 命令 - 跨平台目录树显示工具，类似 Linux 的 tree 命令。此版本只显示名称，不显示任何图标。

## 功能特性

- 🌳 跨平台支持（Windows、Linux、macOS）
- 📁 显示目录树结构
- 🔍 支持多种过滤选项（排除目录、文件、扩展名）
- 📊 显示文件大小和修改时间
- 💾 支持输出到文件
- 📈 统计信息显示

## 安装

### 从 PyPI 安装（推荐）

```bash
pip install zhtree
```

### 从源码安装

```bash
git clone https://github.com/yourusername/zhtree.git
cd zhtree
pip install .
```

## 使用方法

### 基本用法

```bash
# 显示当前目录结构
tree

# 显示指定目录
tree C:\Users
tree /home/user

# 限制显示深度
tree -L 2

# 只显示目录
tree -d

# 显示隐藏文件
tree -a

# 显示文件大小
tree -s

# 显示修改时间
tree -t

# 同时显示大小和时间
tree -s -t

# 保存到文件
tree -o tree.txt
```

### 高级用法

```bash
# 排除指定目录
tree --exclude-dir .git --exclude-dir node_modules

# 排除指定扩展名
tree --exclude-ext .pyc --exclude-ext .log

# 排除指定文件
tree --exclude-file foo.py --exclude-file bar.txt

# 显示统计信息
tree --stats

# 显示详细信息（包括错误信息）
tree -v
```

## 命令行选项

| 选项 | 说明 |
|------|------|
| `path` | 目标目录路径（默认为当前目录） |
| `-L, --level` | 显示深度限制（默认：99） |
| `-d, --dir-only` | 只显示目录 |
| `-a, --all` | 显示隐藏文件 |
| `-s, --size` | 显示文件大小 |
| `-t, --time` | 显示修改时间 |
| `-o, --output` | 输出到文件 |
| `--stats` | 显示统计信息 |
| `-v, --verbose` | 显示详细信息 |
| `--exclude-dir` | 排除目录（可多次使用） |
| `--exclude-ext` | 排除扩展名（可多次使用） |
| `--exclude-file` | 排除文件（可多次使用） |

## 示例输出

```
目录结构: D:\project
================================
project/
├── src/
│   ├── main.py (2.5 KB) [2024-01-15 10:30]
│   └── utils.py (1.2 KB) [2024-01-14 15:20]
├── tests/
│   └── test_main.py (0.8 KB) [2024-01-13 09:15]
├── README.md (3.1 KB) [2024-01-16 14:45]
└── requirements.txt (0.2 KB) [2024-01-10 11:00]
```

## 开发

```bash
# 克隆仓库
git clone https://github.com/yourusername/zhtree.git
cd zhtree

# 安装开发依赖
pip install -e .

# 运行测试
python tree.py
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

## 作者

Your Name

