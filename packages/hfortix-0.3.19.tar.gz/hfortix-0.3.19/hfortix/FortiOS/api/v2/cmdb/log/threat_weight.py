"""
FortiOS CMDB - Cmdb Log Threat Weight

Configuration endpoint for managing cmdb log threat weight objects.

API Endpoints:
    GET    /cmdb/log/threat_weight
    PUT    /cmdb/log/threat_weight/{identifier}

Example Usage:
    >>> from hfortix.FortiOS import FortiOS
    >>> fgt = FortiOS(host="192.168.1.99", token="your-api-token")
    >>>
    >>> # List all items
    >>> items = fgt.api.cmdb.log.threat_weight.get()
    >>>
    >>> # Get specific item (if supported)
    >>> item = fgt.api.cmdb.log.threat_weight.get(name="item_name")
    >>>
    >>> # Create new item (use POST)
    >>> result = fgt.api.cmdb.log.threat_weight.post(
    ...     name="new_item",
    ...     # ... additional parameters
    ... )
    >>>
    >>> # Update existing item (use PUT)
    >>> result = fgt.api.cmdb.log.threat_weight.put(
    ...     name="existing_item",
    ...     # ... parameters to update
    ... )
    >>>
    >>> # Delete item
    >>> result = fgt.api.cmdb.log.threat_weight.delete(name="item_name")

Important:
    - Use **POST** to create new objects (404 error if already exists)
    - Use **PUT** to update existing objects (404 error if doesn't exist)
    - Use **GET** to retrieve configuration (no changes made)
    - Use **DELETE** to remove objects (404 error if doesn't exist)
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ....http_client_interface import IHTTPClient


class ThreatWeight:
    """
    Threatweight Operations.

    Provides CRUD operations for FortiOS threatweight configuration.

    Methods:
        get(): Retrieve configuration objects
        put(): Update existing configuration objects

    Important:
        - POST creates new objects (404 if name already exists)
        - PUT updates existing objects (404 if name doesn't exist)
        - GET retrieves objects without making changes
        - DELETE removes objects (404 if name doesn't exist)
    """

    def __init__(self, client: "IHTTPClient"):
        """
        Initialize ThreatWeight endpoint.

        Args:
            client: HTTPClient instance for API communication
        """
        self._client = client

    def get(
        self,
        payload_dict: dict[str, Any] | None = None,
        exclude_default_values: bool | None = None,
        stat_items: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Select all entries in a CLI table.

        Args:
            exclude_default_values: Exclude properties/objects with default value (optional)
            stat_items: Items to count occurrence in entire response (multiple items should be separated by '|'). (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}
        endpoint = "/log/threat-weight"
        if exclude_default_values is not None:
            params["exclude-default-values"] = exclude_default_values
        if stat_items is not None:
            params["stat-items"] = stat_items
        params.update(kwargs)
        return self._client.get(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def put(
        self,
        payload_dict: dict[str, Any] | None = None,
        before: str | None = None,
        after: str | None = None,
        status: str | None = None,
        level: list | None = None,
        blocked_connection: str | None = None,
        failed_connection: str | None = None,
        url_block_detected: str | None = None,
        botnet_connection_detected: str | None = None,
        malware: list | None = None,
        ips: list | None = None,
        web: list | None = None,
        geolocation: list | None = None,
        application: list | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Update this specific resource.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            before: If *action=move*, use *before* to specify the ID of the resource that this resource will be moved before. (optional)
            after: If *action=move*, use *after* to specify the ID of the resource that this resource will be moved after. (optional)
            status: Enable/disable the threat weight feature. (optional)
            level: Score mapping for threat weight levels. (optional)
            blocked_connection: Threat weight score for blocked connections. (optional)
            failed_connection: Threat weight score for failed connections. (optional)
            url_block_detected: Threat weight score for URL blocking. (optional)
            botnet_connection_detected: Threat weight score for detected botnet connections. (optional)
            malware: Anti-virus malware threat weight settings. (optional)
            ips: IPS threat weight settings. (optional)
            web: Web filtering threat weight settings. (optional)
            geolocation: Geolocation-based threat weight settings. (optional)
            application: Application-control threat weight settings. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}
        endpoint = "/log/threat-weight"
        if before is not None:
            data_payload["before"] = before
        if after is not None:
            data_payload["after"] = after
        if status is not None:
            data_payload["status"] = status
        if level is not None:
            data_payload["level"] = level
        if blocked_connection is not None:
            data_payload["blocked-connection"] = blocked_connection
        if failed_connection is not None:
            data_payload["failed-connection"] = failed_connection
        if url_block_detected is not None:
            data_payload["url-block-detected"] = url_block_detected
        if botnet_connection_detected is not None:
            data_payload["botnet-connection-detected"] = (
                botnet_connection_detected
            )
        if malware is not None:
            data_payload["malware"] = malware
        if ips is not None:
            data_payload["ips"] = ips
        if web is not None:
            data_payload["web"] = web
        if geolocation is not None:
            data_payload["geolocation"] = geolocation
        if application is not None:
            data_payload["application"] = application
        data_payload.update(kwargs)
        return self._client.put(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )
