"""
FortiOS CMDB - Cmdb System Vne Interface

Configuration endpoint for managing cmdb system vne interface objects.

API Endpoints:
    GET    /cmdb/system/vne_interface
    POST   /cmdb/system/vne_interface
    GET    /cmdb/system/vne_interface
    PUT    /cmdb/system/vne_interface/{identifier}
    DELETE /cmdb/system/vne_interface/{identifier}

Example Usage:
    >>> from hfortix.FortiOS import FortiOS
    >>> fgt = FortiOS(host="192.168.1.99", token="your-api-token")
    >>>
    >>> # List all items
    >>> items = fgt.api.cmdb.system.vne_interface.get()
    >>>
    >>> # Get specific item (if supported)
    >>> item = fgt.api.cmdb.system.vne_interface.get(name="item_name")
    >>>
    >>> # Create new item (use POST)
    >>> result = fgt.api.cmdb.system.vne_interface.post(
    ...     name="new_item",
    ...     # ... additional parameters
    ... )
    >>>
    >>> # Update existing item (use PUT)
    >>> result = fgt.api.cmdb.system.vne_interface.put(
    ...     name="existing_item",
    ...     # ... parameters to update
    ... )
    >>>
    >>> # Delete item
    >>> result = fgt.api.cmdb.system.vne_interface.delete(name="item_name")

Important:
    - Use **POST** to create new objects (404 error if already exists)
    - Use **PUT** to update existing objects (404 error if doesn't exist)
    - Use **GET** to retrieve configuration (no changes made)
    - Use **DELETE** to remove objects (404 error if doesn't exist)
"""

from typing import TYPE_CHECKING, Any, Coroutine, cast

if TYPE_CHECKING:
    from ....http_client_interface import IHTTPClient


class VneInterface:
    """
    Vneinterface Operations.

    Provides CRUD operations for FortiOS vneinterface configuration.

    Methods:
        get(): Retrieve configuration objects
        post(): Create new configuration objects
        put(): Update existing configuration objects
        delete(): Remove configuration objects

    Important:
        - POST creates new objects (404 if name already exists)
        - PUT updates existing objects (404 if name doesn't exist)
        - GET retrieves objects without making changes
        - DELETE removes objects (404 if name doesn't exist)
    """

    def __init__(self, client: "IHTTPClient"):
        """
        Initialize VneInterface endpoint.

        Args:
            client: HTTPClient instance for API communication
        """
        self._client = client

    def get(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        attr: str | None = None,
        skip_to_datasource: dict | None = None,
        acs: int | None = None,
        search: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Select a specific entry from a CLI table.

        Args:
            name: Object identifier (optional for list, required for specific)
            attr: Attribute name that references other table (optional)
            skip_to_datasource: Skip to provided table's Nth entry. E.g {datasource: 'firewall.address', pos: 10, global_entry: false} (optional)
            acs: If true, returned result are in ascending order. (optional)
            search: If present, the objects will be filtered by the search value. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if name:
            endpoint = f"/system/vne-interface/{name}"
        else:
            endpoint = "/system/vne-interface"
        if attr is not None:
            params["attr"] = attr
        if skip_to_datasource is not None:
            params["skip_to_datasource"] = skip_to_datasource
        if acs is not None:
            params["acs"] = acs
        if search is not None:
            params["search"] = search
        params.update(kwargs)
        return self._client.get(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def put(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        before: str | None = None,
        after: str | None = None,
        interface: str | None = None,
        ssl_certificate: str | None = None,
        bmr_hostname: str | None = None,
        auto_asic_offload: str | None = None,
        ipv4_address: str | None = None,
        br: str | None = None,
        update_url: str | None = None,
        mode: str | None = None,
        http_username: str | None = None,
        http_password: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Update this specific resource.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            name: Object identifier (required)
            before: If *action=move*, use *before* to specify the ID of the resource that this resource will be moved before. (optional)
            after: If *action=move*, use *after* to specify the ID of the resource that this resource will be moved after. (optional)
            name: VNE tunnel name. (optional)
            interface: Interface name. (optional)
            ssl_certificate: Name of local certificate for SSL connections. (optional)
            bmr_hostname: BMR hostname. (optional)
            auto_asic_offload: Enable/disable tunnel ASIC offloading. (optional)
            ipv4_address: Tunnel IPv4 address and netmask. (optional)
            br: IPv6 address or FQDN of the border relay. (optional)
            update_url: URL of provisioning server. (optional)
            mode: VNE tunnel mode. (optional)
            http_username: HTTP authentication user name. (optional)
            http_password: HTTP authentication password. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for put()")
        endpoint = f"/system/vne-interface/{name}"
        if before is not None:
            data_payload["before"] = before
        if after is not None:
            data_payload["after"] = after
        if name is not None:
            data_payload["name"] = name
        if interface is not None:
            data_payload["interface"] = interface
        if ssl_certificate is not None:
            data_payload["ssl-certificate"] = ssl_certificate
        if bmr_hostname is not None:
            data_payload["bmr-hostname"] = bmr_hostname
        if auto_asic_offload is not None:
            data_payload["auto-asic-offload"] = auto_asic_offload
        if ipv4_address is not None:
            data_payload["ipv4-address"] = ipv4_address
        if br is not None:
            data_payload["br"] = br
        if update_url is not None:
            data_payload["update-url"] = update_url
        if mode is not None:
            data_payload["mode"] = mode
        if http_username is not None:
            data_payload["http-username"] = http_username
        if http_password is not None:
            data_payload["http-password"] = http_password
        data_payload.update(kwargs)
        return self._client.put(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )

    def delete(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Delete this specific resource.

        Args:
            name: Object identifier (required)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for delete()")
        endpoint = f"/system/vne-interface/{name}"
        params.update(kwargs)
        return self._client.delete(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def exists(
        self,
        name: str,
        vdom: str | bool | None = None,
    ) -> bool:
        """
        Check if an object exists.

        Args:
            name: Object identifier
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.

        Returns:
            True if object exists, False otherwise

        Example:
            >>> if fgt.api.cmdb.firewall.address.exists("server1"):
            ...     print("Address exists")
        """
        import inspect

        from hfortix.FortiOS.exceptions_forti import ResourceNotFoundError

        # Call get() - returns dict (sync) or coroutine (async)
        result = self.get(name=name, vdom=vdom)

        # Check if async mode
        if inspect.iscoroutine(result):

            async def _async():
                try:
                    # Runtime check confirms result is a coroutine, cast for mypy
                    await cast(Coroutine[Any, Any, dict[str, Any]], result)
                    return True
                except ResourceNotFoundError:
                    return False

            # Type ignore justified: mypy can't verify Union return type narrowing

            return _async()  # type: ignore[return-value]

        # Sync mode - get() already executed, no exception means it exists
        return True

    def post(
        self,
        payload_dict: dict[str, Any] | None = None,
        nkey: str | None = None,
        name: str | None = None,
        interface: str | None = None,
        ssl_certificate: str | None = None,
        bmr_hostname: str | None = None,
        auto_asic_offload: str | None = None,
        ipv4_address: str | None = None,
        br: str | None = None,
        update_url: str | None = None,
        mode: str | None = None,
        http_username: str | None = None,
        http_password: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Create object(s) in this table.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            nkey: If *action=clone*, use *nkey* to specify the ID for the new resource to be created. (optional)
            name: VNE tunnel name. (optional)
            interface: Interface name. (optional)
            ssl_certificate: Name of local certificate for SSL connections. (optional)
            bmr_hostname: BMR hostname. (optional)
            auto_asic_offload: Enable/disable tunnel ASIC offloading. (optional)
            ipv4_address: Tunnel IPv4 address and netmask. (optional)
            br: IPv6 address or FQDN of the border relay. (optional)
            update_url: URL of provisioning server. (optional)
            mode: VNE tunnel mode. (optional)
            http_username: HTTP authentication user name. (optional)
            http_password: HTTP authentication password. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}
        endpoint = "/system/vne-interface"
        if nkey is not None:
            data_payload["nkey"] = nkey
        if name is not None:
            data_payload["name"] = name
        if interface is not None:
            data_payload["interface"] = interface
        if ssl_certificate is not None:
            data_payload["ssl-certificate"] = ssl_certificate
        if bmr_hostname is not None:
            data_payload["bmr-hostname"] = bmr_hostname
        if auto_asic_offload is not None:
            data_payload["auto-asic-offload"] = auto_asic_offload
        if ipv4_address is not None:
            data_payload["ipv4-address"] = ipv4_address
        if br is not None:
            data_payload["br"] = br
        if update_url is not None:
            data_payload["update-url"] = update_url
        if mode is not None:
            data_payload["mode"] = mode
        if http_username is not None:
            data_payload["http-username"] = http_username
        if http_password is not None:
            data_payload["http-password"] = http_password
        data_payload.update(kwargs)
        return self._client.post(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )
