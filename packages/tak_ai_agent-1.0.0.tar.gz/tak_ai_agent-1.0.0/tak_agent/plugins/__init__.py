"""Agent plugins (future expansion)"""
