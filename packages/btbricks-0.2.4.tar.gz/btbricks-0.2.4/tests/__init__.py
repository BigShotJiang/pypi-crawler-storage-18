"""Tests for btbricks package."""
