"""
name: Star_挖矿
cron: 0/5 * * * *
"""
# -*- coding: utf-8 -*-
import os
import random
import time

from loguru import logger
from xiaobo_task import XiaoboTask, Target

from _star import Star, RateLimit

APPNAME = "Star_挖矿"
FILENAME = 'StarNetworkToken'


def star_mining(target: Target):
    token = target.data[-1]

    with Star(token, target.proxy) as star:
        rate_limit = False
        try:
            result1, end_time = star.mining()
            # if target.index == 0:
            #     result = QLAPI.getEnvs({"searchValue": "star_mining_end_time"})
            #     if result.get('code') != 200:
            #         logger.error("环境变量【star_mining_end_time】ID查询失败，更新失败")
            #     else:
            #         eid = result.get('data')[0].get('id')
            #         result = QLAPI.updateEnv({'env': {"id": eid, "value": f'{end_time + 180}'}})
            #         if result.get('code') != 200:
            #             logger.error("环境变量【star_mining_end_time】ID查询失败，更新失败")
            #         else:
            #             logger.error(f"环境变量【star_mining_end_time】更新成功: {end_time + 180}")

            result2 = star.draw()

            reward_count = 0
            games = ['ballz', 'block_puzzle', 'brain_workout', 'puzzle_2048', 'sudoku', 'flappy']
            for game in games:
                if game == 'flappy':
                    score = str(random.randint(100, 200))
                elif game == 'puzzle_2048':
                    score = str(random.randint(12345, 23333))
                else:
                    score = str(random.randint(8888, 10000))

                reward = star.practice(game, score, target.refresh_proxy())
                if reward:
                    reward_count += 1
        except RateLimit:
            rate_limit = True

        target.logger.info(f'{result1}   {result2}   获得游戏奖励次数: {reward_count}{" (已被限制速度)" if rate_limit else ""}')


def main():
    # mining_end_time = os.getenv('star_mining_end_time', None)
    # if not mining_end_time:
    #     result = QLAPI.createEnv({'envs': [{"name": "star_mining_end_time", "value": "0"}]})
    #     if result.get('code') != 200:
    #         logger.error("环境变量【star_mining_end_time】创建失败，请手动创建")
    #         return
    #
    # if mining_end_time and int(mining_end_time) > time.time():
    #     logger.warning(f'挖矿结束时间未到，不进行挖矿，挖矿结束时间: {mining_end_time}，当前时间: {int(time.time())}')
    # else:
        with XiaoboTask(APPNAME, shuffle=False, use_proxy_ipv6=True) as task_manager:
            task_manager.submit_tasks_from_file(task_func=star_mining, filename=FILENAME)

            task_manager.wait()

            task_manager.statistics()


if __name__ == "__main__":
    main()
