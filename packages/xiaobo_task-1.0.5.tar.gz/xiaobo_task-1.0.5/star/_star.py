import base64
import hashlib
import json
import time
from datetime import datetime, timezone
from typing import Optional

from curl_cffi import Response

from xiaobo_task import get_session, TaskFailed, raise_response_error


def encrypt(payload, is_key: bool = False):
    timestamp = int(time.time() * 1000)
    data = json.dumps(payload).replace(' "', '"').replace(': ', ':') + ':D7C92C3FDB52D54147B668DC6F8A5@' + str(timestamp)
    sign = hashlib.md5(data.encode()).hexdigest()
    payload['timestamp'] = timestamp
    payload['key' if is_key else 'hash'] = sign
    return payload


def get_uid(token: str):
    payload = base64.b64decode(f'{token.split(".")[1]}==').decode()
    return json.loads(payload).get('id')


class RateLimit(Exception):
    pass


class Star:
    def __init__(self, token: str = None, proxy: str = None):
        self.token = token
        self.proxy = proxy
        self.session = get_session(proxy)
        self.session.proxy = proxy
        self.session.headers.update({'User-Agent': 'Dart/2.19 (dart:io)'})
        if self.token:
            self.session.headers.update({'Authorization': f'Bearer {self.token}'})

    def _post(self, endpoint: str, params: Optional[dict] = None, payload: Optional[dict] = None, **kwargs) -> Response:
        """
        发送 POST 请求并返回解析后的 JSON。

        Args:
            endpoint: API 端点（不含 base url）
            json_data: 请求体数据
            **kwargs: 传递给 session.post 的其他参数

        Returns:
            解析后的 JSON 字典

        Raises:
            ApiError: HTTP 错误或 JSON 解析失败
        """
        url = f"https://api.starnetwork.io{endpoint}"
        response = self.session.post(url, params=params, json=payload, **kwargs)
        # 检查 HTTP 状态码
        if response.status_code == 401:
            raise TaskFailed('登录已过期')
        if response.text.count('RATE_LIMITED') and response.text.count('timeout'):
            raise TaskFailed(f'账号请求限制中，剩余时间: {response.json().get("timeout")}')
        return response

    def login(self, username, password) -> Optional[str]:
        method_name = '登录'
        payload = encrypt({'email': username, 'password': password})
        response = self._post('/v3/email/login_check', payload=payload)
        if response.text.count('jwt'):
            body = response.json()
            if body.get('status') == 'blocked':
                raise TaskFailed(f'{method_name}失败: 账号已冻结')
            self.token = body.get('jwt')
            if self.token:
                self.session.headers.update({'Authorization': f'Bearer {self.token}'})
            return self.token
        if response.text.count('email_password_incorrect'):
            raise TaskFailed(f'{method_name}失败: 邮箱或密码不正确')
        raise_response_error(method_name, response)

    def mining(self):
        method_name = '挖矿'
        response = self._post('/v3/session/start')
        if response.text.count('endAt'):
            end_at = response.json().get('session').get('endAt')

            dt = datetime.strptime(end_at, "%Y-%m-%dT%H:%M:%S.%fZ")
            # 设置为 UTC 时区
            dt = dt.replace(tzinfo=timezone.utc)
            timestamp = dt.timestamp()

            if response.text.count('NEW_SESSION_STARTED'):
                return f'{method_name}: 成功', int(timestamp)
            if response.text.count('OLD_SESSION_RUNNING'):
                return f'{method_name}: 正在挖矿中', int(timestamp)

        raise_response_error(method_name, response)

    def draw(self):
        method_name = '加速抽奖'
        uid = get_uid(self.token)
        payload = encrypt({"id": uid, "action": "draw_boost"})
        response = self._post('/v3/event/draw', payload=payload)
        if response.text.count('drawResult'):
            result = response.json()['drawResult']
            return f'{method_name}: {result}'
        if response.text.count('NOT_YET_FINISH'):
            return f'{method_name}: 已经抽过奖了'
        raise_response_error(method_name, response)

    def practice(self, game: str, score: str, proxy: str = None):
        proxy = proxy if proxy else self.proxy
        method_name = '练习游戏'
        payload = encrypt({"game": game, "mode": "practice", "score": score, "extra": False}, True)
        response = self._post('/v3/game/record', payload=payload, proxy=proxy)
        if response.text.count('id'):
            return response.text.count('REWARDED')
        raise_response_error(method_name, response)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()


if __name__ == '__main__':
    _token = 'token'
    star = Star(_token)
    star.login('asda@aa.com', 'password')
    print(star.mining())
    print(star.draw())
    print(star.practice('flappy', '200'))
