import sys
from pathlib import Path

print(Path('a.txt'))
print(Path(sys.argv[0]).resolve())
print(Path(sys.argv[0]).resolve().parent)