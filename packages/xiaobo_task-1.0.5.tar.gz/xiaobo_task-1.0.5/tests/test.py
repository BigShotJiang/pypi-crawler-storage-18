data = {
'error_msg':'errorer1rorerror'
}

a = (
        data.get('message') or
        data.get('msg') or
        data.get('error') or
        data.get('error_message') or
        data.get('error_msg')
)

print(a)