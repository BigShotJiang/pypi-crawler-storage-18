"""
标准 API 封装模板 + 调用示例

目标：
1) 结构清晰：配置、客户端、错误、调用分层
2) 安全健壮：超时、重试、错误提示
3) 易扩展：可复用的请求方法 + 资源方法
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import logging
import time
from typing import Any, Dict, Iterable, Optional, Tuple
from urllib.parse import urljoin

from curl_cffi import requests

logger = logging.getLogger(__name__)


# ---------- 配置 ----------
@dataclass(frozen=True)
class APIConfig:
    base_url: str
    api_key: Optional[str] = None
    timeout: Tuple[float, float] = (5.0, 20.0)  # (连接超时, 读取超时)
    retries: int = 2
    backoff: float = 0.5  # 秒，指数退避基数
    user_agent: str = "ExampleAPIClient/1.0"

    def build_headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = {
            "User-Agent": self.user_agent,
            "Accept": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if extra:
            headers.update(extra)
        return headers


# ---------- 错误 ----------
class APIError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        response_text: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_text = response_text
        self.request_id = request_id


# ---------- 客户端 ----------
class APIClient:
    def __init__(self, config: APIConfig, session: Optional[requests.Session] = None) -> None:
        self._config = config
        self._session = session or requests.Session()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        url = urljoin(self._config.base_url.rstrip("/") + "/", path.lstrip("/"))
        hdrs = self._config.build_headers(headers)

        last_err: Optional[Exception] = None
        for attempt in range(self._config.retries + 1):
            try:
                resp = self._session.request(
                    method=method.upper(),
                    url=url,
                    params=params,
                    json=json_body,
                    data=data,
                    headers=hdrs,
                    timeout=self._config.timeout,
                )
                return self._handle_response(resp)
            except (requests.Timeout, requests.ConnectionError) as err:
                last_err = err
                if attempt < self._config.retries:
                    sleep_s = self._config.backoff * (2**attempt)
                    time.sleep(sleep_s)
                    continue
                raise APIError("Network error", response_text=str(err)) from err

        # 理论上不会到这里
        if last_err:
            raise APIError("Unknown network error", response_text=str(last_err))
        raise APIError("Unknown error")

    def _handle_response(self, resp: requests.Response) -> Any:
        request_id = resp.headers.get("X-Request-Id") or resp.headers.get("Request-Id")
        if not resp.ok:
            text = resp.text
            message = f"HTTP {resp.status_code}: {text[:200]}"
            raise APIError(
                message,
                status_code=resp.status_code,
                response_text=text,
                request_id=request_id,
            )

        # 尝试解析 JSON；若不是 JSON，返回文本
        content_type = resp.headers.get("Content-Type", "")
        if "application/json" in content_type:
            try:
                return resp.json()
            except json.JSONDecodeError as err:
                raise APIError("Invalid JSON response", response_text=resp.text) from err
        return resp.text

    # 常见动词快捷方法
    def get(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Any:
        return self.request("GET", path, params=params)

    def post(self, path: str, *, json_body: Optional[Dict[str, Any]] = None) -> Any:
        return self.request("POST", path, json_body=json_body)

    def put(self, path: str, *, json_body: Optional[Dict[str, Any]] = None) -> Any:
        return self.request("PUT", path, json_body=json_body)

    def delete(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Any:
        return self.request("DELETE", path, params=params)


# ---------- 资源层（按需扩展） ----------
class UsersAPI:
    def __init__(self, client: APIClient) -> None:
        self._client = client

    def get_user(self, user_id: str) -> Dict[str, Any]:
        return self._client.get(f"/users/{user_id}")

    def create_user(self, name: str, email: str) -> Dict[str, Any]:
        return self._client.post("/users", json_body={"name": name, "email": email})

    def list_users(self, page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        return self._client.get("/users", params={"page": page, "page_size": page_size})


# ---------- 调用模板 ----------
def main() -> None:
    # 1) 初始化配置
    config = APIConfig(
        base_url="https://api.example.com/v1",
        api_key="YOUR_API_KEY",
        timeout=(5.0, 20.0),
        retries=2,
        backoff=0.5,
    )

    # 2) 创建客户端
    client = APIClient(config)

    # 3) 按资源组织调用
    users_api = UsersAPI(client)

    try:
        user = users_api.get_user("123")
        print("User:", user)

        created = users_api.create_user("Alice", "alice@example.com")
        print("Created:", created)

        users = users_api.list_users(page=1, page_size=10)
        print("Users:", users)
    except APIError as err:
        logger.error(
            "API error: %s (status=%s, request_id=%s)",
            err,
            err.status_code,
            err.request_id,
        )


if __name__ == "__main__":
    main()
