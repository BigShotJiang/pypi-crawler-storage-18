"""
标准 API 封装模板 (curl_cffi 版本)

包含以下最佳实践：
1. 数据模型定义 (dataclass)
2. 自定义异常类
3. API 客户端类封装
4. 重试机制
5. 日志记录
6. 类型注解
7. 浏览器指纹模拟
"""

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, TypeVar, Generic

from curl_cffi.requests import Session, AsyncSession, Response

# ============================================================
# 1. 日志配置
# ============================================================
logger = logging.getLogger(__name__)


# ============================================================
# 2. 自定义异常类
# ============================================================
class APIError(Exception):
    """API 基础异常类"""

    def __init__(self, message: str, status_code: int | None = None, response: Any = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(APIError):
    """认证失败异常"""
    pass


class RateLimitError(APIError):
    """速率限制异常"""
    pass


class NotFoundError(APIError):
    """资源未找到异常"""
    pass


# ============================================================
# 3. 数据模型定义
# ============================================================
@dataclass
class User:
    """用户模型"""
    id: int
    name: str
    email: str
    is_active: bool = True


@dataclass
class CreateUserRequest:
    """创建用户请求"""
    name: str
    email: str


@dataclass
class UpdateUserRequest:
    """更新用户请求"""
    name: str | None = None
    email: str | None = None


# 泛型响应类型
T = TypeVar("T")


@dataclass
class APIResponse(Generic[T]):
    """统一 API 响应格式"""
    success: bool
    data: T | None = None
    message: str | None = None
    error_code: str | None = None


class HTTPMethod(Enum):
    """HTTP 方法枚举"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


# 浏览器指纹类型
class BrowserType(str, Enum):
    """支持的浏览器指纹类型"""
    CHROME = "chrome"
    CHROME_120 = "chrome120"
    CHROME_119 = "chrome119"
    CHROME_110 = "chrome110"
    CHROME_99 = "chrome99"
    EDGE = "edge101"
    SAFARI = "safari15_5"
    SAFARI_IOS = "safari_ios15_6"
    FIREFOX = "firefox"


# ============================================================
# 4. API 客户端封装
# ============================================================
class APIClient:

    """
    标准 API 客户端 (curl_cffi 版本)

    特点：
    - 支持浏览器指纹模拟，绕过 TLS 指纹检测
    - 支持 HTTP/2
    - 兼容 requests 风格的 API

    使用示例:
        client = APIClient(base_url="https://api.example.com", api_key="your-key")
        user = client.get_user(1)
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        impersonate: BrowserType | str = BrowserType.CHROME_120,
        proxy: str | None = None,
    ):
        """
        初始化 API 客户端

        Args:
            base_url: API 基础 URL
            api_key: API 密钥
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
            impersonate: 浏览器指纹类型
            proxy: 代理地址，如 "http://127.0.0.1:7890"
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.impersonate = impersonate.value if isinstance(impersonate, BrowserType) else impersonate

        # 构建默认请求头
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

        # 代理配置
        self._proxies = {"http": proxy, "https": proxy} if proxy else None

        # 创建 Session
        self._session = Session(
            impersonate=self.impersonate,
            timeout=timeout,
            proxies=self._proxies,
        )
        # 设置默认请求头
        self._session.headers.update(self._headers)

    def __enter__(self) -> "APIClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def close(self) -> None:
        """关闭客户端连接"""
        self._session.close()

    def _build_url(self, endpoint: str) -> str:
        """构建完整 URL"""
        if endpoint.startswith("http"):
            return endpoint
        return f"{self.base_url}/{endpoint.lstrip('/')}"

    def _handle_response(self, response: Response) -> dict[str, Any]:
        """
        处理响应，统一错误处理

        Args:
            response: HTTP 响应对象

        Returns:
            响应 JSON 数据

        Raises:
            APIError: API 调用失败时抛出
        """
        try:
            data = response.json()
        except Exception:
            data = {"raw": response.text}

        # 根据状态码处理不同错误
        if response.status_code == 401:
            raise AuthenticationError(
                "Authentication failed",
                status_code=response.status_code,
                response=data,
            )
        elif response.status_code == 404:
            raise NotFoundError(
                "Resource not found",
                status_code=response.status_code,
                response=data,
            )
        elif response.status_code == 429:
            raise RateLimitError(
                "Rate limit exceeded",
                status_code=response.status_code,
                response=data,
            )
        elif response.status_code >= 400:
            error_msg = data.get("message", "Request failed") if isinstance(data, dict) else "Request failed"
            raise APIError(
                error_msg,
                status_code=response.status_code,
                response=data,
            )

        return data

    def _request(
        self,
        method: HTTPMethod,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        data: dict[str, Any] | str | None = None,
    ) -> dict[str, Any]:
        """
        发送 HTTP 请求（带重试机制）

        Args:
            method: HTTP 方法
            endpoint: API 端点
            params: URL 查询参数
            json_data: JSON 请求体
            headers: 额外请求头
            data: 表单数据或原始数据

        Returns:
            响应数据
        """
        url = self._build_url(endpoint)
        request_headers = {**self._headers, **(headers or {})}
        last_exception: Exception | None = None

        for attempt in range(self.max_retries):
            try:
                logger.debug(f"Request {method.value} {url} (attempt {attempt + 1})")

                response = self._session.request(
                    method=method.value,
                    url=url,
                    params=params,
                    json=json_data,
                    data=data,
                    headers=request_headers,
                    timeout=self.timeout,
                )

                return self._handle_response(response)

            except RateLimitError:
                # 速率限制不重试，直接抛出
                raise
            except (ConnectionError, TimeoutError, OSError) as e:
                last_exception = e
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt == self.max_retries - 1:
                    raise APIError(f"Request failed after {self.max_retries} attempts: {e}")
            except APIError:
                # 其他 API 错误不重试
                raise

        raise APIError(f"Request failed: {last_exception}")

    # --------------------------------------------------------
    # 便捷方法
    # --------------------------------------------------------
    def get(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """GET 请求"""
        return self._request(HTTPMethod.GET, endpoint, params=params, **kwargs)

    def post(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        data: dict[str, Any] | str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """POST 请求"""
        return self._request(HTTPMethod.POST, endpoint, json_data=json_data, data=data, **kwargs)

    def put(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """PUT 请求"""
        return self._request(HTTPMethod.PUT, endpoint, json_data=json_data, **kwargs)

    def patch(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """PATCH 请求"""
        return self._request(HTTPMethod.PATCH, endpoint, json_data=json_data, **kwargs)

    def delete(
        self,
        endpoint: str,
        **kwargs,
    ) -> dict[str, Any]:
        """DELETE 请求"""
        return self._request(HTTPMethod.DELETE, endpoint, **kwargs)

    # --------------------------------------------------------
    # 业务方法示例 - 用户相关
    # --------------------------------------------------------
    def get_user(self, user_id: int) -> User:
        """
        获取用户信息

        Args:
            user_id: 用户 ID

        Returns:
            User 对象
        """
        data = self.get(f"/users/{user_id}")
        return User(
            id=data["id"],
            name=data["name"],
            email=data["email"],
            is_active=data.get("is_active", True),
        )

    def list_users(self, page: int = 1, page_size: int = 20) -> list[User]:
        """
        获取用户列表

        Args:
            page: 页码
            page_size: 每页数量

        Returns:
            用户列表
        """
        data = self.get("/users", params={"page": page, "page_size": page_size})
        return [
            User(
                id=item["id"],
                name=item["name"],
                email=item["email"],
                is_active=item.get("is_active", True),
            )
            for item in data.get("items", [])
        ]

    def create_user(self, request: CreateUserRequest) -> User:
        """
        创建用户

        Args:
            request: 创建用户请求

        Returns:
            创建的用户
        """
        data = self.post("/users", json_data={"name": request.name, "email": request.email})
        return User(
            id=data["id"],
            name=data["name"],
            email=data["email"],
        )

    def update_user(self, user_id: int, request: UpdateUserRequest) -> User:
        """
        更新用户

        Args:
            user_id: 用户 ID
            request: 更新请求

        Returns:
            更新后的用户
        """
        update_data = {}
        if request.name is not None:
            update_data["name"] = request.name
        if request.email is not None:
            update_data["email"] = request.email

        data = self.patch(f"/users/{user_id}", json_data=update_data)
        return User(
            id=data["id"],
            name=data["name"],
            email=data["email"],
            is_active=data.get("is_active", True),
        )

    def delete_user(self, user_id: int) -> bool:
        """
        删除用户

        Args:
            user_id: 用户 ID

        Returns:
            是否删除成功
        """
        self.delete(f"/users/{user_id}")
        return True


# ============================================================
# 5. 异步版本 API 客户端
# ============================================================
class AsyncAPIClient:
    """异步 API 客户端 (curl_cffi 版本)"""

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        impersonate: BrowserType | str = BrowserType.CHROME_120,
        proxy: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.impersonate = impersonate.value if isinstance(impersonate, BrowserType) else impersonate

        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

        self._proxies = {"http": proxy, "https": proxy} if proxy else None
        self._session: AsyncSession | None = None

    async def _get_session(self) -> AsyncSession:
        """懒加载获取 AsyncSession"""
        if self._session is None:
            self._session = AsyncSession(
                impersonate=self.impersonate,
                timeout=self.timeout,
                proxies=self._proxies,
            )
            self._session.headers.update(self._headers)
        return self._session

    async def __aenter__(self) -> "AsyncAPIClient":
        await self._get_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    async def close(self) -> None:
        """关闭客户端连接"""
        if self._session:
            await self._session.close()
            self._session = None

    def _build_url(self, endpoint: str) -> str:
        """构建完整 URL"""
        if endpoint.startswith("http"):
            return endpoint
        return f"{self.base_url}/{endpoint.lstrip('/')}"

    def _handle_response(self, response: Response) -> dict[str, Any]:
        """处理响应"""
        try:
            data = response.json()
        except Exception:
            data = {"raw": response.text}

        if response.status_code == 401:
            raise AuthenticationError("Authentication failed", response.status_code, data)
        elif response.status_code == 404:
            raise NotFoundError("Resource not found", response.status_code, data)
        elif response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", response.status_code, data)
        elif response.status_code >= 400:
            error_msg = data.get("message", "Request failed") if isinstance(data, dict) else "Request failed"
            raise APIError(error_msg, response.status_code, data)

        return data

    async def _request(
        self,
        method: HTTPMethod,
        endpoint: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        data: dict[str, Any] | str | None = None,
    ) -> dict[str, Any]:
        """异步请求（带重试机制）"""
        session = await self._get_session()
        url = self._build_url(endpoint)
        request_headers = {**self._headers, **(headers or {})}
        last_exception: Exception | None = None

        for attempt in range(self.max_retries):
            try:
                logger.debug(f"Async request {method.value} {url} (attempt {attempt + 1})")

                response = await session.request(
                    method=method.value,
                    url=url,
                    params=params,
                    json=json_data,
                    data=data,
                    headers=request_headers,
                    timeout=self.timeout,
                )

                return self._handle_response(response)

            except RateLimitError:
                raise
            except (ConnectionError, TimeoutError, OSError) as e:
                last_exception = e
                logger.warning(f"Async request failed (attempt {attempt + 1}): {e}")
                if attempt == self.max_retries - 1:
                    raise APIError(f"Request failed after {self.max_retries} attempts: {e}")
            except APIError:
                raise

        raise APIError(f"Request failed: {last_exception}")

    async def get(self, endpoint: str, **kwargs) -> dict[str, Any]:
        """GET 请求"""
        return await self._request(HTTPMethod.GET, endpoint, **kwargs)

    async def post(self, endpoint: str, **kwargs) -> dict[str, Any]:
        """POST 请求"""
        return await self._request(HTTPMethod.POST, endpoint, **kwargs)

    async def put(self, endpoint: str, **kwargs) -> dict[str, Any]:
        """PUT 请求"""
        return await self._request(HTTPMethod.PUT, endpoint, **kwargs)

    async def patch(self, endpoint: str, **kwargs) -> dict[str, Any]:
        """PATCH 请求"""
        return await self._request(HTTPMethod.PATCH, endpoint, **kwargs)

    async def delete(self, endpoint: str, **kwargs) -> dict[str, Any]:
        """DELETE 请求"""
        return await self._request(HTTPMethod.DELETE, endpoint, **kwargs)

    # --------------------------------------------------------
    # 异步业务方法示例
    # --------------------------------------------------------
    async def get_user(self, user_id: int) -> User:
        """获取用户信息"""
        data = await self.get(f"/users/{user_id}")
        return User(
            id=data["id"],
            name=data["name"],
            email=data["email"],
            is_active=data.get("is_active", True),
        )

    async def create_user(self, request: CreateUserRequest) -> User:
        """创建用户"""
        data = await self.post("/users", json_data={"name": request.name, "email": request.email})
        return User(id=data["id"], name=data["name"], email=data["email"])


# ============================================================
# 6. 使用示例
# ============================================================
def main():
    """同步调用示例"""
    # 方式1：直接实例化
    client = APIClient(
        base_url="https://api.example.com",
        api_key="your-api-key",
        timeout=30.0,
        max_retries=3,
        impersonate=BrowserType.CHROME_120,  # 模拟 Chrome 120 浏览器指纹
        proxy=None,  # 可设置代理: "http://127.0.0.1:7890"
    )

    try:
        # 获取单个用户
        user = client.get_user(1)
        print(f"User: {user.name} ({user.email})")

        # 获取用户列表
        users = client.list_users(page=1, page_size=10)
        for u in users:
            print(f"  - {u.name}")

        # 创建用户
        new_user = client.create_user(
            CreateUserRequest(name="John Doe", email="john@example.com")
        )
        print(f"Created user: {new_user.id}")

        # 更新用户
        updated_user = client.update_user(
            new_user.id,
            UpdateUserRequest(name="John Smith"),
        )
        print(f"Updated name to: {updated_user.name}")

        # 删除用户
        client.delete_user(new_user.id)
        print("User deleted")

    except NotFoundError as e:
        print(f"Not found: {e}")
    except AuthenticationError as e:
        print(f"Auth error: {e}")
    except RateLimitError as e:
        print(f"Rate limited: {e}")
    except APIError as e:
        print(f"API error: {e}")
    finally:
        client.close()

    # 方式2：使用上下文管理器（推荐）
    with APIClient(
        base_url="https://api.example.com",
        api_key="key",
        impersonate="chrome120",  # 也可以直接传字符串
    ) as client:
        try:
            user = client.get_user(1)
            print(f"User: {user.name}")
        except APIError as e:
            print(f"Error: {e}")


async def async_main():
    """异步调用示例"""
    async with AsyncAPIClient(
        base_url="https://api.example.com",
        api_key="your-api-key",
        impersonate=BrowserType.CHROME_120,
    ) as client:
        try:
            # 获取用户
            user = await client.get_user(1)
            print(f"User: {user.name}")

            # 创建用户
            new_user = await client.create_user(
                CreateUserRequest(name="Jane", email="jane@example.com")
            )
            print(f"Created: {new_user.name}")

        except APIError as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    # 运行同步示例
    main()

    # 运行异步示例
    # import asyncio
    # asyncio.run(async_main())
