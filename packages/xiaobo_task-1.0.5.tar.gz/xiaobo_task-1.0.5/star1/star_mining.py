"""
name: Star_挖矿
cron: 0/5 * * * *
"""
# -*- coding: utf-8 -*-
import random
from dataclasses import dataclass
from typing import List

from xiaobo_task import XiaoboTask, Target

from _star import Star, RateLimit

APPNAME = "Star_挖矿"
FILENAME = 'StarNetworkToken'


@dataclass
class GameConfig:
    """游戏配置"""
    name: str
    min_score: int
    max_score: int


# 游戏配置列表
GAMES: List[GameConfig] = [
    GameConfig('ballz', 8888, 10000),
    GameConfig('block_puzzle', 8888, 10000),
    GameConfig('brain_workout', 8888, 10000),
    GameConfig('puzzle_2048', 12345, 23333),
    GameConfig('sudoku', 8888, 10000),
    GameConfig('flappy', 100, 200),
]


def _play_all_games(star: Star, target: Target) -> tuple[int, bool]:
    """
    执行所有游戏并统计奖励。

    Args:
        star: Star 客户端
        target: 任务目标

    Returns:
        (奖励次数, 是否被限速)
    """
    reward_count = 0
    rate_limited = False

    for game in GAMES:
        try:
            score = str(random.randint(game.min_score, game.max_score))
            if star.play_game(game.name, score, target.refresh_proxy()):
                reward_count += 1
        except RateLimit:
            rate_limited = True
            break

    return reward_count, rate_limited


def star_mining(target: Target):
    """
    Star Network 挖矿任务。

    执行挖矿、抽奖和游戏练习。
    """
    token = target.data[-1]

    with Star(token, target.proxy) as star:
        # 挖矿
        mining_result, _ = star.mining()

        # 抽奖
        draw_result = star.draw_boost()

        # 游戏
        reward_count, rate_limited = _play_all_games(star, target)

        # 日志输出
        rate_limit_msg = " (已被限制速度)" if rate_limited else ""
        target.logger.info(
            f'{mining_result}   {draw_result}   获得游戏奖励次数: {reward_count}{rate_limit_msg}'
        )


def main():
    with XiaoboTask(APPNAME, shuffle=False, use_proxy_ipv6=True) as task_manager:
        task_manager.submit_tasks_from_file(task_func=star_mining, filename=FILENAME)
        task_manager.wait()
        task_manager.statistics()


if __name__ == "__main__":
    main()
