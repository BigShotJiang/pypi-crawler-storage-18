# -*- coding: utf-8 -*-
import base64
import hashlib
import json
import html as html_lib
import re
import time
from datetime import datetime, timezone
from typing import Optional, Tuple, Any

from xiaobo_task import get_session, TaskFailed

# 常量
_SIGN_SALT = "D7C92C3FDB52D54147B668DC6F8A5"
_BASE_URL = "https://api.starnetwork.io/v3"
_USER_AGENT = "Dart/2.19 (dart:io)"


class RateLimit(Exception):
    """请求速率限制异常"""
    pass


class ApiError(Exception):
    """API 响应错误"""

    def __init__(self, message: str, status_code: int = None, error_code: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


def _encrypt(payload: dict, is_key: bool = False) -> dict:
    """
    对请求负载进行签名加密。

    Args:
        payload: 原始请求数据
        is_key: 签名字段使用 'key' 还是 'hash'

    Returns:
        添加了时间戳和签名的负载
    """
    timestamp = int(time.time() * 1000)
    # 紧凑格式 JSON，无空格
    data = json.dumps(payload, separators=(',', ':')) + f':{_SIGN_SALT}@{timestamp}'
    sign = hashlib.md5(data.encode()).hexdigest()

    payload['timestamp'] = timestamp
    payload['key' if is_key else 'hash'] = sign
    return payload


def _parse_uid_from_token(token: str) -> str:
    """
    从 JWT token 中解析用户 ID。

    Args:
        token: JWT token 字符串

    Returns:
        用户 ID

    Raises:
        ValueError: token 格式无效
    """
    try:
        payload_part = token.split(".")[1]
        # JWT payload 需要补齐 padding
        padding = 4 - len(payload_part) % 4
        if padding != 4:
            payload_part += '=' * padding
        payload = base64.b64decode(payload_part).decode()
        return json.loads(payload).get('id')
    except Exception as e:
        raise ValueError(f"无效的 token 格式: {e}")



class Star:
    """Star Network API 客户端"""

    def __init__(self, token: Optional[str] = None, proxy: Optional[str] = None):
        """
        初始化 Star 客户端。

        Args:
            token: JWT 认证 token（可选，可后续通过 login 获取）
            proxy: 代理地址
        """
        self.token = token
        self.proxy = proxy
        self.session = get_session(proxy)
        self.session.headers.update({'User-Agent': _USER_AGENT})

        if self.token:
            self._set_auth_header()

    def _set_auth_header(self):
        """设置认证请求头"""
        self.session.headers.update({'Authorization': f'Bearer {self.token}'})

    def _post(self, endpoint: str, json_data: Optional[dict] = None, **kwargs) -> dict:
        """
        发送 POST 请求并返回解析后的 JSON。

        Args:
            endpoint: API 端点（不含 base url）
            json_data: 请求体数据
            **kwargs: 传递给 session.post 的其他参数

        Returns:
            解析后的 JSON 字典

        Raises:
            ApiError: HTTP 错误或 JSON 解析失败
        """
        url = f"{_BASE_URL}/{endpoint}"
        response = self.session.post(url, json=json_data, **kwargs)

        content_type = (response.headers.get('Content-Type') or '').lower()

        # 检查 HTTP 状态码
        # if response.status_code == 401:
        #     raise TaskFailed('登录已过期')

        if response.status_code >= 400:
            error_message = None
            if 'application/json' in content_type or '+json' in content_type:
                try:
                    data = response.json()
                    error_message = data.get('message') if isinstance(data, dict) else None
                except json.JSONDecodeError:
                    error_message = None
            elif 'text/html' in content_type or response.text.lstrip().startswith('<'):
                error_code, error_detail = _parse_cloudflare_error(response.text)
                error_message = _format_cloudflare_error(error_code, error_detail)

            if not error_message:
                error_message = response.text[:200]

            raise ApiError(
                f"HTTP {response.status_code}: {error_message}",
                status_code=response.status_code
            )

        # 解析 JSON
        try:
            return response.json()
        except json.JSONDecodeError:
            raise ApiError(f"无效的 JSON 响应: {response.text[:200]}")

    def login(self, username: str, password: str) -> bool:
        """
        使用邮箱密码登录。

        Args:
            username: 邮箱
            password: 密码

        Returns:
            登录成功返回 True

        Raises:
            TaskFailed: 账号冻结或密码错误
            Exception: 其他登录失败
        """
        payload = _encrypt({'email': username, 'password': password})
        data = self._post('email/login_check', json_data=payload)
        # 检查账号状态
        if data.get('status') == 'blocked':
            raise TaskFailed('登录失败: 账号已冻结')

        # 获取 token
        if 'jwt' in data:
            self.token = data['jwt']
            self._set_auth_header()
            return True

        # 处理错误
        error = _get_error_message(data)
        if error == 'email_password_incorrect':
            raise TaskFailed('登录失败: 邮箱或密码不正确')

        raise Exception(f'登录失败: {error}')

    def mining(self) -> Tuple[str, int]:
        """
        开始挖矿会话。

        Returns:
            (状态消息, 结束时间戳)

        Raises:
            Exception: 挖矿失败
        """
        data = self._post('session/start')

        # 检查响应结构
        session = data.get('session')
        if not session or 'endAt' not in session:
            raise Exception(f'挖矿失败: {_get_error_message(data)}')

        # 解析结束时间
        end_at = session['endAt']
        dt = datetime.strptime(end_at, "%Y-%m-%dT%H:%M:%S.%fZ")
        dt = dt.replace(tzinfo=timezone.utc)
        end_timestamp = int(dt.timestamp())

        # 根据状态返回消息
        status = data.get('status')
        if status == 'NEW_SESSION_STARTED':
            return '挖矿: 成功', end_timestamp
        if status == 'OLD_SESSION_RUNNING':
            return '挖矿: 正在挖矿中', end_timestamp
        ''
        return f'挖矿: {status or "未知状态"}', end_timestamp

    def draw_boost(self) -> str:
        """
        加速抽奖。

        Returns:
            抽奖结果消息

        Raises:
            Exception: 抽奖失败
        """
        uid = _parse_uid_from_token(self.token)
        payload = _encrypt({"id": uid, "action": "draw_boost"})
        data = self._post('event/draw', json_data=payload)

        # 检查抽奖结果
        if 'drawResult' in data:
            return f"加速抽奖: {data['drawResult']}"

        # 处理错误
        error = _get_error_message(data)
        if error == 'NOT_YET_FINISH':
            return '加速抽奖: 已经抽过奖了'

        raise Exception(f'加速抽奖失败: {error}')

    def play_game(self, game: str, score: str, proxy: Optional[str] = None) -> bool:
        """
        提交游戏练习分数。

        Args:
            game: 游戏名称
            score: 游戏分数
            proxy: 可选的代理地址（覆盖默认代理）

        Returns:
            是否获得奖励

        Raises:
            RateLimit: 请求被限速
            Exception: 提交失败
        """
        payload = _encrypt(
            {"game": game, "mode": "practice", "score": score, "extra": False},
            is_key=True
        )

        request_proxy = proxy if proxy else self.proxy
        data = self._post('game/record', json_data=payload, proxy=request_proxy)

        # 检查是否成功
        if 'id' in data:
            return data.get('status') == 'REWARDED'

        # 处理错误
        error = _get_error_message(data)
        if error == 'RATE_LIMITED':
            raise RateLimit('游戏请求被限速')

        raise Exception(f'练习游戏失败: {error}')

    def close(self):
        """关闭会话"""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


if __name__ == '__main__':
    _token = 'your_token_here'
    with Star(_token) as star:
        print(star.mining())
        print(star.draw_boost())
        print(star.play_game('flappy', '200'))
