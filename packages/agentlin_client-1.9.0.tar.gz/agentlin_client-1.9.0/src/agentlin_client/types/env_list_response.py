# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from .._models import BaseModel
from .env_info import EnvInfo

__all__ = ["EnvListResponse"]


class EnvListResponse(BaseModel):
    """列出环境响应"""

    environments: List[EnvInfo]

    total: int

    grouped: Optional[Dict[str, List[EnvInfo]]] = None
