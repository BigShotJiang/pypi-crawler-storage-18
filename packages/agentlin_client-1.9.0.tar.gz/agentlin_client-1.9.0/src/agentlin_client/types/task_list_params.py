# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Optional
from typing_extensions import Literal, TypedDict

__all__ = ["TaskListParams"]


class TaskListParams(TypedDict, total=False):
    limit: Optional[int]

    offset: Optional[int]

    session_id: Optional[str]

    status: Optional[
        List[
            Literal[
                "created", "queued", "working", "input-required", "paused", "completed", "canceled", "expired", "failed"
            ]
        ]
    ]

    user_id: Optional[str]
