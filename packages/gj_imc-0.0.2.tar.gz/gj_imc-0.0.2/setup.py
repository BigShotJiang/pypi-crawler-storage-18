from setuptools import setup

with open("README.md", "r") as arq:
    readme = arq.read()

setup(name='gj_imc',
    version='0.0.2',
    license='MIT License',
    author='Pedro Henrique Teodoro de Mendonça',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='pedrohenrique_teodoromendonca@hotmail.com',
    keywords='linear algebra, matrix, inverse, inverse matrix',
    description=u'Testando ainda',
    packages=['gj_imc'],
    install_requires=['numpy'],)