.. image:: https://github.com/easybuilders/easybuild/raw/develop/logo/png/easybuild_logo_2022_horizontal_dark_bg_transparent.png
   :align: center
   :height: 400px
   
.. image:: https://github.com/easybuilders/easybuild-framework/actions/workflows/unit_tests.yml/badge.svg?branch=develop

`EasyBuild <https://easybuild.io>`_ is a software build
and installation framework that allows you to manage (scientific) software
on High Performance Computing (HPC) systems in an efficient way.

The **easybuild-framework** package is the core of EasyBuild. It
supports the implementation and use of so-called easyblocks which
implement the software install procedure for a particular (group of) software
package(s).

The EasyBuild documentation is available at http://docs.easybuild.io/.

The EasyBuild framework source code is hosted on GitHub, along
with an issue tracker for bug reports and feature requests, see
https://github.com/easybuilders/easybuild-framework.

Related Python packages:

* **easybuild-easyblocks**

  * a collection of easyblocks that implement support for building and installing (groups of) software packages
  * GitHub repository: https://github.com/easybuilders/easybuild-easyblocks
  * package on PyPi: https://pypi.python.org/pypi/easybuild-easyblocks

* **easybuild-easyconfigs**

  * a collection of example easyconfig files that specify which software to build,
    and using which build options; these easyconfigs will be well tested
    with the latest compatible versions of the easybuild-framework and easybuild-easyblocks packages
  * GitHub repository: https://github.com/easybuilders/easybuild-easyconfigs
  * PyPi: https://pypi.python.org/pypi/easybuild-easyconfigs
