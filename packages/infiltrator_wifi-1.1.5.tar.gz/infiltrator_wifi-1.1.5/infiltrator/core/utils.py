"""
Utility functions for system checks and data processing.
"""
import shutil
import logging
from typing import Optional
from rich.console import Console

console = Console()

def check_dependencies(tools: list) -> bool:
    """Check if required system binaries are available."""
    missing = []
    for tool in tools:
        if not shutil.which(tool):
            missing.append(tool)
    
    if missing:
        console.print(f"[bold red]❌ Missing required tools: {', '.join(missing)}[/]")
        console.print("[yellow]Please install them via: sudo apt install aircrack-ng reaver hostapd dnsmasq[/]")
        return False
    return True

def get_vendor(mac_address: str) -> str:
    """Get vendor name from MAC address using manuf."""
    try:
        from manuf import manuf
        p = manuf.MacParser(update=False)
        vendor = p.get_manuf(mac_address)
        return vendor or "Unknown"
    except ImportError:
        return "Unknown (manuf not installed)"
    except Exception:
        return "Unknown"
