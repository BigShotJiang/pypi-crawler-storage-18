"""
Command-line interface with interactive menu-based navigation.
"""

import sys
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import print as rprint
from rich.console import Group
from rich.align import Align

from infiltrator.core.updater import check_for_updates
from infiltrator import __version__
from infiltrator.core.banner import display_banner

console = Console()

custom_style = questionary.Style([
    ('qmark', 'fg:#00FF00 bold'),
    ('question', 'bold'),
    ('answer', 'fg:#00FFFF bold'),
    ('pointer', 'fg:#FF0000 bold'),
    ('highlighted', 'fg:#00FFFF bold'),
    ('selected', 'fg:#00FFFF'),
    ('separator', 'fg:#666666'),
    ('instruction', 'fg:#666666'),
])

class CLI:
    """Main CLI interface for Infiltrator."""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.running = True
        
        from infiltrator.core.adapter_manager import AdapterManager
        self.adapter_manager = AdapterManager(logger)
        
        try:
            from infiltrator.modules.reconnaissance import ReconnaissanceModule
            from infiltrator.modules.exploitation import ExploitationModule
            from infiltrator.modules.post_attack import PostAttackModule
            
            self.recon_module = ReconnaissanceModule(config, logger, self.adapter_manager)
            self.exploit_module = ExploitationModule(config, logger, self.adapter_manager)
            self.post_module = PostAttackModule(config, logger, self.adapter_manager)
        except ImportError as e:
            console.print(f"[bold red]Warning: Some modules could not be loaded: {e}[/]")
        
        self.config.ensure_directories()
        
        # Version Check
        console.print("[dim]Checking for updates...[/]")
        self.update_available = check_for_updates(__version__)
        if self.update_available:
             console.print(Panel(
                f"[bold green]Update Available: {self.update_available}[/]\n"
                f"Current Version: {__version__}\n\n"
                f"Run: [bold cyan]pip install --upgrade infiltrator-wifi[/]",
                title="[bold yellow]NEW VERSION[/]",
                border_style="green"
            ))
            # Optional: questionary.press_any_key_to_continue().ask() 
        
        # Initial clear and scan
        console.clear()
        self.adapter_manager.scan_adapters()
    
    def run(self):
        """Main CLI loop."""
        while self.running:
            self._display_header()
            
            # Show active adapters summary
            self._print_adapter_summary()
            
            choice = questionary.select(
                "Select Operation:",
                choices=[
                    questionary.Separator("--- Reconnaissance ---"),
                    questionary.Choice("Passive Scanner & Analyzer", value="recon_1"),
                    questionary.Choice("Client Probe Monitor", value="recon_2"),
                    questionary.Choice("Target Tracker", value="recon_3"),
                    questionary.Choice("Geo-Spatial Mapper", value="recon_4"),
                    questionary.Choice("Protocol Fingerprinter", value="recon_5"),
                    
                    questionary.Separator("--- Exploitation ---"),
                    questionary.Choice("Deauth Attack Suite", value="exploit_1"),
                    questionary.Choice("Handshake / PMKID Capture", value="exploit_2"),
                    questionary.Choice("Evil Twin (MiTM)", value="exploit_3"),
                    questionary.Choice("WPS Brute-Forcer", value="exploit_4"),
                    questionary.Choice("WPA3 Downgrade Attack", value="exploit_5"),
                    questionary.Choice("802.1X Phishing", value="exploit_6"),
                    
                    questionary.Separator("--- Post-Attack ---"),
                    questionary.Choice("Offline Cracking", value="post_1"),
                    questionary.Choice("Automated Chain", value="post_2"),
                    questionary.Choice("Stealth & OPSEC", value="post_3"),
                    questionary.Choice("Cloud Cracking API", value="post_4"),
                    
                    questionary.Separator("--- System ---"),
                    questionary.Choice("Adapter Management", value="adapter"),
                    questionary.Choice("Settings", value="settings"),
                    questionary.Choice("Exit", value="exit"),
                ],
                style=custom_style,
                use_indicator=True,
                qmark="[+]"
            ).ask()
            
            if not choice: continue
                
            if choice == 'exit':
                self._exit()
            elif choice == 'adapter':
                self._adapter_menu()
            elif choice == 'settings':
                self._settings_menu()
            else:
                self._run_module_wrapper(choice)
    
    def _display_header(self):
        console.clear()
        display_banner()
        if self.update_available:
            console.print(Align.center(f"[bold green]Update Available: {self.update_available}[/] - [dim]pip install --upgrade infiltrator-wifi[/]"))
            console.print()

    def _run_module_wrapper(self, code):
        """Helper to run module functions safely."""
        try:
            if code.startswith('recon_'): module = self.recon_module
            elif code.startswith('exploit_'): module = self.exploit_module
            elif code.startswith('post_'): module = self.post_module
            
            # Map codes
            if code == 'recon_1': module.passive_scanner()
            elif code == 'recon_2': module.client_probe_monitor()
            elif code == 'recon_3': module.target_tracker()
            elif code == 'recon_4': module.geo_mapper()
            elif code == 'recon_5': module.protocol_fingerprinter()
            
            elif code == 'exploit_1': module.deauth_attack()
            elif code == 'exploit_2': module.handshake_capture()
            elif code == 'exploit_3': module.evil_twin()
            elif code == 'exploit_4': module.wps_attack()
            elif code == 'exploit_5': module.wpa3_downgrade()
            elif code == 'exploit_6': module.eap_phishing()
            
            elif code == 'post_1': module.offline_cracking()
            elif code == 'post_2': module.chain_execution()
            elif code == 'post_3': module.stealth_opsec()
            elif code == 'post_4': module.cloud_cracking()
            
            # Interaction pause
            console.print()
            questionary.press_any_key_to_continue().ask()
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled by user.[/]")
        except Exception as e:
            console.print(f"\n[red]Error executing module: {e}[/]")
            questionary.press_any_key_to_continue().ask()

    def _print_adapter_summary(self):
        adapters = list(self.adapter_manager.adapters.values())
        if not adapters:
            console.print("[red]No adapters found![/]", justify="center")
            return

        status_parts = []
        for a in adapters:
            color = "green" if a.is_monitor else "yellow"
            status_parts.append(f"[{color}]{a.interface}[/]")
        
        console.print(Align.center(f"[dim]Adapters:[/dim] {', '.join(status_parts)}"))
        console.print()

    def _adapter_menu(self):
        while True:
            self._display_header()
            
            # Adapter details table
            adapters = list(self.adapter_manager.adapters.values())
            if adapters:
                table = Table(title="Adapter Status", box=None, show_header=True)
                table.add_column("Interface", style="green")
                table.add_column("Mode", style="cyan")
                table.add_column("Channel")
                table.add_column("MAC")
                for a in adapters:
                    table.add_row(
                        a.interface, 
                        "Monitor" if a.is_monitor else "Managed", 
                        str(a.channel or "Auto"),
                        a.mac_address
                    )
                console.print(Align.center(table))
                console.print()
            
            choice = questionary.select(
                "Adapter Management:",
                choices=[
                    "Rescan Adapters",
                    "Enable Monitor Mode",
                    "Disable Monitor Mode",
                    "Spoof MAC Address",
                    "Restore MAC Address",
                    "Set Channel",
                    questionary.Separator(),
                    "Back to Main Menu"
                ],
                style=custom_style
            ).ask()
            
            if choice == "Back to Main Menu": break
            
            if choice == "Rescan Adapters":
                self.adapter_manager.scan_adapters()
            elif choice == "Enable Monitor Mode":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.enable_monitor_mode(iface)
            elif choice == "Disable Monitor Mode":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.disable_monitor_mode(iface)
            elif choice == "Spoof MAC Address":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.spoof_mac(iface)
            elif choice == "Restore MAC Address":
                iface = questionary.text("Interface name:").ask()
                self.adapter_manager.restore_mac(iface)
            elif choice == "Set Channel":
                iface = questionary.text("Interface name:").ask()
                ch = questionary.text("Channel:").ask()
                if ch.isdigit():
                    self.adapter_manager.set_channel(iface, int(ch))

    def _settings_menu(self):
        import json
        while True:
            self._display_header()
            
            choice = questionary.select(
                "Settings & Configuration:",
                choices=[
                    "View Current Config",
                    "Edit Configuration Wizard",
                    questionary.Separator(),
                    "Back to Main Menu"
                ],
                style=custom_style
            ).ask()
            
            if choice == "Back to Main Menu":
                break
            
            elif choice == "View Current Config":
                console.clear()
                self._display_header()
                console.print(Panel(json.dumps(self.config.config, indent=2), title="Current Configuration", border_style="cyan"))
                console.print()
                questionary.press_any_key_to_continue(message="Press any key to return...").ask()
                
            elif choice == "Edit Configuration Wizard":
                # Run the wizard script
                import subprocess
                try:
                    subprocess.run([sys.executable, "-m", "infiltrator.config_wizard"])
                    # Reload config
                    self.config = self.config.__class__() 
                except Exception as e:
                    console.print(f"[red]Error running wizard: {e}[/]")
                    questionary.press_any_key_to_continue().ask()

    def _exit(self):
        if questionary.confirm("Are you sure you want to exit?").ask():
            console.print("[yellow]Cleaning up processes...[/]")
            self.cleanup()
            console.print("[bold green]Goodbye![/]")
            self.running = False
    
    def cleanup(self):
        for interface in self.adapter_manager.monitor_adapters[:]:
            self.adapter_manager.disable_monitor_mode(interface)
        
        for adapter in self.adapter_manager.adapters.values():
            if adapter.mac_address != adapter.original_mac:
                self.adapter_manager.restore_mac(adapter.interface)
