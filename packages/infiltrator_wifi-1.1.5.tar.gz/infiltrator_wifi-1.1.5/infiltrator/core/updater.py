"""
Auto-update functionality for Infiltrator.
"""
import requests
from packaging import version
from rich.console import Console
from rich.panel import Panel

def check_for_updates(current_version: str):
    """
    Check for updates on PyPI.
    Returns the latest version string if an update is available, else None.
    """
    package_name = "infiltrator-wifi"
    try:
        response = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=3)
        if response.status_code == 200:
            data = response.json()
            latest_version = data["info"]["version"]
            
            if version.parse(latest_version) > version.parse(current_version):
                return latest_version
    except Exception:
        # Fail silently if network issue or PyPI down
        pass
    return None
