"""
Banner and branding for Infiltrator.
"""
import shutil
import pyfiglet
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich import box

console = Console()

def display_banner():
    """Display the Infiltrator banner dynamically based on terminal size."""
    # Get terminal width
    width = shutil.get_terminal_size().columns
    
    # Choose font based on width
    font = "slant" if width > 80 else "small"
    
    # Generate ASCII art
    f = pyfiglet.Figlet(font=font)
    ascii_art = f.renderText("Infiltrator")
    
    # Create the text object
    title_text = Text(ascii_art, style="bold cyan")
    
    # Create subtitle text with explicit styles
    from infiltrator import __version__
    subtitle = Text()
    subtitle.append("Wi-Fi Red Team Auditing Suite", style="bold white")
    subtitle.append(f" v{__version__}\n", style="bold yellow")
    subtitle.append("Dev: LAKSHMIKANTHAN K (letchupkt)", style="dim")
    
    # Create a responsive panel
    canvas = Align.center(
        Text.assemble(title_text, "\n", subtitle),
        vertical="middle",
    )
    
    banner_panel = Panel(
        canvas,
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
        expand=False
    )
    
    console.print()
    console.print(Align.center(banner_panel))
    
    # Warning with proper markup parsing
    console.print(Align.center("[bold red on black]  ⚠  For Educational and Authorized Testing Only  ⚠  [/]"))
    console.print()