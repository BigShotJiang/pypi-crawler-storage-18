# Aleph Secrets Manager

A simple Python tool for managing secrets in Azure Key Vault using a command-line interface (CLI). 

You may also use the underlying Azure Key Vault adaptor directly if for instance you want to load secrets into an application programmatically. 

## Purpose
- **Read, write, and delete secrets** in Azure Key Vault from the command line.
- Supports bulk upload/download from `.env` files.

## Dependencies
Install the following Python packages (see [`aleph_secrets_manager/requirements.txt`](./aleph_secrets_manager/requirements.txt)):

- `azure-identity`
- `azure-keyvault-secrets`
- `pydantic`
- `python-dotenv`

Install dependencies:
```sh
pip install -r aleph_secrets_manager/requirements.txt
```

## CLI Usage

Run the CLI from the project root:

### Read all secrets from Key Vault and save to a .env file
```sh
python cli.py -v <vault-name> read -f .env
```

### Write all secrets from a .env file to Key Vault
```sh
python cli.py -v <vault-name> write -f .env
```

### Delete secrets from Key Vault
```sh
python cli.py -v <vault-name> delete -k SECRET_1 -k SECRET_2
```

- Replace `<vault-name>` with your Azure Key Vault name.
- The `-f` flag specifies the path to your `.env` file.
- The `-k` flag can be repeated for each secret key to delete.

## Adaptor Usage
```python
# Initialize the secrets manager
vault_name = "test-kv"
secrets_manager = AzureSecretsManager(AzureClientFactory.create(vault_name))

# Read a secret
secrets_manager.read_secret("SECRET-1")

# Write secret
new_secret = Secret(key="NULL_SECRET", value="test123")
secrets_manager.write_secret(new_secret)

# List all secrets 
secrets_manager.list_all_secrets()

# Read all secrets
secrets_manager.read_all_secrets()

# Download all
env_path = Path().parent.parent / ".env"
secrets_manager.download_all_to_env_file(env_path)

# Upload from .env
secrets_manager.upload_from_env_file(env_path)

# Delete a secret
secrets_manager.delete_secret('SECRET_2')
secrets_manager.delete_secret('SECRET_1')

```

## Authentication
This tool uses Azure's `DefaultAzureCredential`. Make sure you are authenticated (e.g., via `az login`) and have access to the Key Vault (e.g. Key Vault Secrets User).

---