from setuptools import find_packages, setup

setup(
    name='aleph_secrets_manager',
    version='0.1',
    packages=find_packages(),
)