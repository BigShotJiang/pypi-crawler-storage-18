"""
Console UI printer class.

This module provides the ConsoleUI class that handles all console output
operations including headers, sections, prompts, and styled messages.
"""

from typing import Optional

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
)
from rich.table import Table

from fastapi_hephaestus.console.theme import get_console
from fastapi_hephaestus.models.project_config import ProjectConfig


class ConsoleUI:
    """
    A class responsible for all console UI operations.

    This class follows the Single Responsibility Principle by handling
    only console output operations. It provides methods for printing
    styled headers, sections, prompts, and messages.

    Attributes:
        console: The Rich Console instance for output.
    """

    def __init__(self, console: Optional[Console] = None) -> None:
        """
        Initialize the ConsoleUI with a console instance.

        Args:
            console: Optional Rich Console instance. If not provided,
                    a new instance with custom theme will be created.
        """
        self.console = console or get_console()

    def print_header(self) -> None:
        """Print the CLI header banner with application title."""
        self.console.print()
        header_text = """[bold cyan]
  ╔═══════════════════════════════════════════════════════════╗
  ║     🚀  [bold white]FastAPI Project Initializer[/bold white]  🚀                 ║
  ║                                                           ║
  ║     [dim]Scaffold your next API in seconds[/dim]                    ║
  ╚═══════════════════════════════════════════════════════════╝
[/bold cyan]"""
        self.console.print(header_text)

    def print_section(self, title: str, icon: str = "📋") -> None:
        """
        Print a styled section header.

        Args:
            title: The section title to display.
            icon: The emoji icon to display before the title.
        """
        self.console.print()
        self.console.print(f"  [bold yellow]{icon}  {title}[/bold yellow]")
        self.console.print(f"  [muted]{'─' * 50}[/muted]")

    def print_options(self, options: list[str]) -> None:
        """
        Print available options in a styled format.

        Args:
            options: List of option strings to display.
        """
        options_str = " │ ".join([f"[accent]{opt}[/accent]" for opt in options])
        self.console.print(f"     [muted]Options:[/muted] {options_str}")

    def print_success(self, message: str) -> None:
        """
        Print a success message with checkmark.

        Args:
            message: The success message to display.
        """
        self.console.print(f"  [success]✓[/success] {message}")

    def print_error(self, message: str) -> None:
        """
        Print an error message with X mark.

        Args:
            message: The error message to display.
        """
        self.console.print(f"  [error]✗[/error] {message}")

    def print_warning(self, message: str) -> None:
        """
        Print a warning message.

        Args:
            message: The warning message to display.
        """
        self.console.print(f"  [warning]⚠[/warning]  {message}")

    def print_newline(self, count: int = 1) -> None:
        """
        Print empty lines.

        Args:
            count: Number of empty lines to print.
        """
        for _ in range(count):
            self.console.print()

    @staticmethod
    def styled_prompt(label: str) -> str:
        """
        Create a styled prompt label for user input.

        Args:
            label: The prompt label text.

        Returns:
            A styled string suitable for typer.prompt().
        """
        return typer.style(f"     {label}", fg=typer.colors.CYAN, bold=True)

    def create_progress(self) -> Progress:
        """
        Create and return a configured Progress instance.

        Returns:
            A Rich Progress instance with spinner, text, bar, and percentage.
        """
        return Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[bold cyan]{task.description}[/bold cyan]"),
            BarColumn(bar_width=40, style="cyan", complete_style="green"),
            TaskProgressColumn(),
            console=self.console,
        )

    def print_project_summary(self, config: ProjectConfig) -> None:
        """
        Print a summary panel of the created project.

        Args:
            config: The project configuration to summarize.
        """
        self.print_newline(2)

        summary_table = Table(
            show_header=False,
            box=box.SIMPLE,
            padding=(0, 2),
            collapse_padding=True,
        )
        summary_table.add_column(style="dim")
        summary_table.add_column(style="bold white")

        summary_table.add_row("Project", f"[cyan]{config.name}[/cyan]")
        summary_table.add_row("Location", f"[cyan]{config.path}[/cyan]")
        summary_table.add_row(
            "Package Manager", f"[cyan]{config.package_manager}[/cyan]"
        )
        summary_table.add_row("Database", f"[cyan]{config.database}[/cyan]")

        if config.orm:
            summary_table.add_row("ORM", f"[cyan]{config.orm}[/cyan]")
        if config.odm:
            summary_table.add_row("ODM", f"[cyan]{config.odm}[/cyan]")

        self.console.print(
            Panel(
                summary_table,
                title="[bold green]✨ Project Created Successfully![/bold green]",
                border_style="green",
                padding=(1, 2),
            )
        )

    def print_next_steps(self, project_path: str) -> None:
        """
        Print the next steps panel after project creation.

        Args:
            project_path: The path to the created project.
        """
        self.print_newline()

        next_steps = f"""
[bold white]Get started with your new project:[/bold white]

  [bold cyan]$[/bold cyan] [white]cd {project_path}[/white]
  [bold cyan]$[/bold cyan] [white]uv run dev.py[/white]

[dim]Your API will be available at:[/dim]
  [bold green]→[/bold green] [link=http://localhost:8000]http://localhost:8000[/link]
  [bold green]→[/bold green] [link=http://localhost:8000/docs]http://localhost:8000/docs[/link] [dim](API docs)[/dim]
"""

        self.console.print(
            Panel(
                next_steps,
                title="[bold yellow]🚀 Next Steps[/bold yellow]",
                border_style="yellow",
                padding=(0, 2),
            )
        )

        self.print_newline()

    def print_build_header(self) -> None:
        """Print the build command header panel."""
        self.print_newline()
        self.console.print(
            Panel.fit(
                "[bold cyan]🔧 Building Project[/bold cyan]",
                border_style="cyan",
            )
        )
        self.print_newline()
