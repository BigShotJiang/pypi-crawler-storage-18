"""
Template provider for generated project files.

This module contains all file templates used when generating
a new FastAPI project structure.
"""

import textwrap
from abc import ABC, abstractmethod
from typing import Protocol


class TemplateSource(Protocol):
    """Protocol defining the interface for template sources."""

    def get_main_app_template(self) -> str:
        """Return the main FastAPI application template."""
        ...

    def get_dev_runner_template(self) -> str:
        """Return the development runner template."""
        ...

    def get_env_template(self) -> str:
        """Return the .env file template."""
        ...

    def get_init_template(self) -> str:
        """Return the __init__.py template."""
        ...

    def get_settings_template(self) -> str:
        """Return the settings.py template."""
        ...

    def get_logger_template(self) -> str:
        """Return the logger.py template."""
        ...

    def get_security_template(self) -> str:
        """Return the security.py template."""
        ...

    def get_config_init_template(self) -> str:
        """Return the config __init__.py template."""
        ...


class TemplateProvider:
    """
    Provides file templates for project generation.

    This class follows the Single Responsibility Principle by handling
    only the provision of file templates. Each template is returned as
    a properly dedented string ready for file writing.

    Example:
        >>> provider = TemplateProvider()
        >>> main_template = provider.get_main_app_template()
    """

    @staticmethod
    def get_main_app_template() -> str:
        """
        Get the main FastAPI application template.

        Returns:
            A string containing the main.py template for the generated project.
        """
        return textwrap.dedent("""\
            from dotenv import load_dotenv
            from fastapi import FastAPI
            from scalar_fastapi import get_scalar_api_reference

            from app.config import settings

            load_dotenv()


            def create_app() -> FastAPI:
                app = FastAPI(
                    docs_url=None,
                    redoc_url=None,
                    title=settings.project_name,
                    description=settings.project_description,
                )

                @app.get("/docs", include_in_schema=False)
                async def docs_html():
                    return get_scalar_api_reference(
                        openapi_url=app.openapi_url,
                    )

                return app


            app = create_app()
        """)

    @staticmethod
    def get_dev_runner_template() -> str:
        """
        Get the development runner template.

        Returns:
            A string containing the dev.py template.
        """
        return textwrap.dedent("""\
            import uvicorn


            def main():
                uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)


            if __name__ == "__main__":
                main()
        """)

    @staticmethod
    def get_env_template() -> str:
        """
        Get the .env file template.

        Returns:
            A string containing the .env template with default values.
        """
        return textwrap.dedent("""\
            PROJECT_NAME=FastAPI Setup Auto Generated Project
            PROJECT_DESCRIPTION=FastAPI Setup Auto Generated Project Description
            VERSION=0.1.0
            SERVER_HOST=127.0.0.1
            SERVER_PORT=8000
        """)

    @staticmethod
    def get_init_template() -> str:
        """
        Get the generic __init__.py template.

        Returns:
            A string containing the __init__.py template.
        """
        return textwrap.dedent("""\
            "Module level imports. Place all imports here. Then export using __all__."
        """)

    @staticmethod
    def get_settings_template() -> str:
        """
        Get the settings.py template.

        Returns:
            A string containing the settings configuration template.
        """
        return textwrap.dedent("""\
            from pydantic_settings import BaseSettings, SettingsConfigDict
            from functools import lru_cache
            from pydantic import Field
            from pathlib import Path

            BASE_DIR = Path(__file__).resolve().parents[2]


            class Settings(BaseSettings):
                model_config = SettingsConfigDict(
                    env_file=f"{BASE_DIR}/.env",
                    env_file_encoding="utf-8",
                )
                
                project_name: str = Field(..., validation_alias="PROJECT_NAME")
                project_description: str = Field(..., validation_alias="PROJECT_DESCRIPTION")
                version: str = Field(..., validation_alias="VERSION")
                server_host: str = Field(..., validation_alias="SERVER_HOST")
                server_port: int = Field(..., validation_alias="SERVER_PORT")

            @lru_cache(maxsize=1)
            def get_settings() -> Settings:
                return Settings()

            settings = get_settings()
        """)

    @staticmethod
    def get_logger_template() -> str:
        """
        Get the logger.py placeholder template.

        Returns:
            A string containing the logger placeholder template.
        """
        return textwrap.dedent("""\
            "Setup Custom Logger Here"
        """)

    @staticmethod
    def get_security_template() -> str:
        """
        Get the security.py placeholder template.

        Returns:
            A string containing the security placeholder template.
        """
        return textwrap.dedent("""\
            "Setup Security Config Here"
        """)

    @staticmethod
    def get_config_init_template() -> str:
        """
        Get the config module __init__.py template.

        Returns:
            A string containing the config __init__.py template.
        """
        return textwrap.dedent("""\
            from .settings import settings

            __all__ = ["settings"]
        """)

