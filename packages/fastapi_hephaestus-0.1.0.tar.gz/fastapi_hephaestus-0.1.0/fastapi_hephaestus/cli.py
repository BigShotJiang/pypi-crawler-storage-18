"""
Command Line Interface for FastAPI Project Initializer.

This module defines the CLI commands using Typer and orchestrates
the user interaction through the console UI and services.
"""

from pathlib import Path

import typer

from fastapi_hephaestus.console.printer import ConsoleUI
from fastapi_hephaestus.constants import (
    CURRENT_DIR,
    DATABASE_TYPES,
    NOSQL_DATABASES,
    NOSQL_ODMS,
    PACKAGE_MANAGERS,
    SQL_DATABASES,
    SQL_ORMS,
)
from fastapi_hephaestus.models.project_config import ProjectConfig
from fastapi_hephaestus.services.project_initializer import ProjectInitializer


# Typer application instance
app = typer.Typer(
    name="fastapi-tools",
    help="FastAPI Project Initializer - Scaffold your next API in seconds.",
    add_completion=False,
)


class InitCommand:
    """
    Handler for the init command.

    This class encapsulates the logic for the project initialization
    command, collecting user input and delegating to the appropriate services.

    Attributes:
        ui: The console UI for user interaction.
        initializer: The project initializer service.
    """

    def __init__(
        self,
        ui: ConsoleUI | None = None,
        initializer: ProjectInitializer | None = None,
    ) -> None:
        """
        Initialize the InitCommand handler.

        Args:
            ui: Optional console UI. Creates a new instance if not provided.
            initializer: Optional project initializer. Creates a new instance
                        if not provided.
        """
        self.ui = ui or ConsoleUI()
        self.initializer = initializer or ProjectInitializer(ui=self.ui)

    def collect_project_config(self) -> tuple[str, Path]:
        """
        Collect basic project configuration from user.

        Returns:
            A tuple of (project_name, project_path).

        Raises:
            typer.Exit: If the project is already initialized.
        """
        self.ui.print_section("Project Configuration", "📋")

        project_name = typer.prompt(
            self.ui.styled_prompt("Project Name"),
            default=CURRENT_DIR.name,
        )

        project_path_input = typer.prompt(
            self.ui.styled_prompt("Initialize in"),
            default=".",
        )
        project_path = (
            CURRENT_DIR / project_path_input
            if project_path_input != "."
            else CURRENT_DIR
        )

        return project_name, project_path

    def collect_package_manager(self) -> str:
        """
        Collect package manager selection from user.

        Returns:
            The selected package manager.

        Raises:
            typer.Exit: If an invalid selection is made.
        """
        self.ui.print_section("Package Manager", "📦")
        self.ui.print_options(PACKAGE_MANAGERS)

        package_manager = typer.prompt(
            self.ui.styled_prompt("Select"),
            default="uv",
        )

        if package_manager not in PACKAGE_MANAGERS:
            self.ui.print_error(
                f"Invalid package manager! Must be one of: {', '.join(PACKAGE_MANAGERS)}"
            )
            raise typer.Exit(1)

        return package_manager

    def collect_database_config(self) -> tuple[str, str, str | None, str | None]:
        """
        Collect database configuration from user.

        Returns:
            A tuple of (database_type, database, orm, odm).

        Raises:
            typer.Exit: If invalid selections are made.
        """
        self.ui.print_section("Database Configuration", "🗄️")
        self.ui.print_options(DATABASE_TYPES)

        database_type = typer.prompt(
            self.ui.styled_prompt("Database Type"),
            default="sql",
        )

        if database_type not in DATABASE_TYPES:
            self.ui.print_error(
                f"Invalid database type! Must be one of: {', '.join(DATABASE_TYPES)}"
            )
            raise typer.Exit(1)

        orm = None
        odm = None

        # SQL configuration
        if database_type == "sql":
            self.ui.print_newline()
            self.ui.print_options(SQL_ORMS)
            orm = typer.prompt(self.ui.styled_prompt("ORM"), default="sqlmodel")

            if orm not in SQL_ORMS:
                self.ui.print_error(
                    f"Invalid ORM! Must be one of: {', '.join(SQL_ORMS)}"
                )
                raise typer.Exit(1)

            database_options = SQL_DATABASES
            default_database = "postgres"

        # NoSQL configuration
        else:
            self.ui.print_newline()
            self.ui.print_options(NOSQL_ODMS)
            odm = typer.prompt(self.ui.styled_prompt("ODM"), default="beanie")

            if odm not in NOSQL_ODMS:
                self.ui.print_error(
                    f"Invalid ODM! Must be one of: {', '.join(NOSQL_ODMS)}"
                )
                raise typer.Exit(1)

            database_options = NOSQL_DATABASES
            default_database = "mongodb"

        # Database selection
        self.ui.print_newline()
        self.ui.print_options(database_options)
        database = typer.prompt(
            self.ui.styled_prompt("Database"),
            default=default_database,
        )

        if database not in database_options:
            self.ui.print_error(
                f"Invalid database! Must be one of: {', '.join(database_options)}"
            )
            raise typer.Exit(1)

        return database_type, database, orm, odm

    def collect_project_details(self) -> str:
        """
        Collect project details from user.

        Returns:
            The project description.
        """
        self.ui.print_section("Project Details", "📝")

        description = typer.prompt(
            self.ui.styled_prompt("Description"),
            default="Your description here",
        )

        return description

    def run_with_progress(self, config: ProjectConfig) -> bool:
        """
        Run project initialization with progress display.

        Args:
            config: The project configuration.

        Returns:
            True if successful, False otherwise.
        """
        self.ui.print_newline(2)

        with self.ui.create_progress() as progress:
            task = progress.add_task("  Setting up FastAPI project...", total=4)

            def update_progress(description: str) -> None:
                progress.update(task, description=f"  [cyan]{description}[/cyan]")
                progress.advance(task)

            success = self.initializer.initialize(config, update_progress)

            if success:
                progress.update(task, description="  [green]✓ Setup complete![/green]")

        return success

    def execute(self) -> None:
        """
        Execute the init command.

        Collects all user input, creates a ProjectConfig, and runs
        the project initialization with progress display.
        """
        self.ui.print_header()

        # Collect configuration
        project_name, project_path = self.collect_project_config()

        # Validate path early
        if (project_path / "project.json").exists():
            self.ui.print_error("Project already initialized in this directory!")
            raise typer.Exit(1)

        # Ensure directory exists
        if not project_path.exists():
            project_path.mkdir(parents=True, exist_ok=True)

        package_manager = self.collect_package_manager()
        database_type, database, orm, odm = self.collect_database_config()
        description = self.collect_project_details()

        # Create configuration
        config = ProjectConfig(
            name=project_name,
            path=project_path,
            description=description,
            package_manager=package_manager,
            database_type=database_type,
            database=database,
            orm=orm,
            odm=odm,
        )

        # Run initialization
        success = self.run_with_progress(config)

        if success:
            self.ui.print_project_summary(config)
            self.ui.print_next_steps(str(config.path))


class BuildCommand:
    """
    Handler for the build command.

    Attributes:
        ui: The console UI for user interaction.
    """

    def __init__(self, ui: ConsoleUI | None = None) -> None:
        """
        Initialize the BuildCommand handler.

        Args:
            ui: Optional console UI. Creates a new instance if not provided.
        """
        self.ui = ui or ConsoleUI()

    def execute(self) -> None:
        """Execute the build command."""
        self.ui.print_build_header()
        self.ui.print_warning("Build command not yet implemented")
        self.ui.print_newline()


# ─────────────────────────────────────────────────────────────
# CLI Commands
# ─────────────────────────────────────────────────────────────


@app.command()
def init() -> None:
    """
    Initialize a new FastAPI project with your preferred configuration.

    This command guides you through setting up a new FastAPI project,
    including selecting a package manager, database type, ORM/ODM,
    and creating the initial project structure.
    """
    command = InitCommand()
    command.execute()


@app.command()
def build() -> None:
    """
    Build the project for production.

    Note: This command is not yet implemented.
    """
    command = BuildCommand()
    command.execute()


def main() -> None:
    """Entry point for the CLI application."""
    app()

