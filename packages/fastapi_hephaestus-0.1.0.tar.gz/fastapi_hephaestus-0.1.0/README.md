# 🔥 FastAPI Hephaestus

> _Named after Hephaestus, the Greek god of forge and craftsmanship_ ⚒️

A beautiful CLI tool to forge production-ready FastAPI projects with your preferred configuration in seconds.

## ✨ Features

- **Interactive Setup** - Guided prompts for project configuration
- **Multiple Database Support** - PostgreSQL, MySQL, SQLite, MongoDB
- **ORM/ODM Options** - SQLAlchemy, SQLModel, Beanie
- **Auto-configured Migrations** - Alembic setup for SQL databases
- **Beautiful Output** - Rich-styled console with progress indicators
- **Clean Architecture** - Generated projects follow best practices

## 📦 Installation

### Using pip

```bash
pip install fastapi-hephaestus
```

### Using uv (recommended)

```bash
uv add fastapi-hephaestus
```

### From source

```bash
git clone https://github.com/Agsdovah95/fastapi_hephaestus.git
cd fastapi_hephaestus
pip install -e .
```

## 🎯 Quick Start

Initialize a new FastAPI project:

```bash
# Using the CLI command
fastapi_hephaestus init

# Or run directly with Python
python -m fastapi_hephaestus init

# Or with the main.py
python main.py init
```

## 📖 Commands

### `init`

Initialize a new FastAPI project with interactive prompts.

```bash
fastapi_hephaestus init
```

You'll be guided through:

1. **Project Configuration**

   - Project name
   - Project location

2. **Package Manager**

   - `pip` or `uv`

3. **Database Configuration**

   - Database type: `sql` or `nosql`
   - ORM (for SQL): `sqlalchemy` or `sqlmodel`
   - ODM (for NoSQL): `beanie`
   - Database: `postgres`, `mysql`, `sqlite`, or `mongodb`

4. **Project Details**
   - Description

### `build`

Build the project for production (coming soon).

```bash
fastapi_hephaestus build
```

## 📁 Generated Project Structure

After running `init`, your project will have this structure:

```
your-project/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI application
│   ├── api/                  # API routes
│   ├── config/               # Configuration
│   │   ├── __init__.py
│   │   ├── settings.py       # Pydantic settings
│   │   ├── logger.py         # Logger setup
│   │   └── security.py       # Security config
│   ├── database/             # Database connections
│   ├── models/               # Database models
│   ├── repositories/         # Data access layer
│   ├── schemas/              # Pydantic schemas
│   ├── services/             # Business logic
│   ├── utils/                # Utilities
│   └── workers/              # Background workers
├── migrations/               # Alembic migrations (SQL only)
├── tests/                    # Test files
├── .env                      # Environment variables
├── dev.py                    # Development server runner
├── project.json              # Project configuration
└── pyproject.toml            # Dependencies
```

## 🏃 Running Your Generated Project

After initialization:

```bash
cd your-project

# Start the development server
uv run dev.py
```

Your API will be available at:

- **API**: http://localhost:8000
- **Docs**: http://localhost:8000/docs (Scalar API Reference)

## ⚙️ Configuration

The generated project uses environment variables for configuration. Edit `.env`:

```env
PROJECT_NAME=Your Project Name
PROJECT_DESCRIPTION=Your project description
VERSION=0.1.0
SERVER_HOST=127.0.0.1
SERVER_PORT=8000
```

## 🗄️ Database Support

| Type  | Database   | Driver    | ORM/ODM              |
| ----- | ---------- | --------- | -------------------- |
| SQL   | PostgreSQL | asyncpg   | SQLAlchemy, SQLModel |
| SQL   | MySQL      | aiomysql  | SQLAlchemy, SQLModel |
| SQL   | SQLite     | aiosqlite | SQLAlchemy, SQLModel |
| NoSQL | MongoDB    | motor     | Beanie               |

## 📝 Example Session

```
$ fastapi_hephaestus init

  ╔═══════════════════════════════════════════════════════════╗
  ║     🚀  FastAPI Project Initializer  🚀                   ║
  ║                                                           ║
  ║     Scaffold your next API in seconds                     ║
  ╚═══════════════════════════════════════════════════════════╝

  📋  Project Configuration
  ──────────────────────────────────────────────────
     Project Name [my-project]: awesome-api
     Initialize in [.]: ./awesome-api

  📦  Package Manager
  ──────────────────────────────────────────────────
     Options: uv │ pip
     Select [uv]: uv

  🗄️  Database Configuration
  ──────────────────────────────────────────────────
     Options: sql │ nosql
     Database Type [sql]: sql
     Options: sqlalchemy │ sqlmodel
     ORM [sqlmodel]: sqlmodel
     Options: postgres │ mysql │ sqlite
     Database [postgres]: postgres

  📝  Project Details
  ──────────────────────────────────────────────────
     Description [Your description here]: My awesome API

  ⠋ Setting up FastAPI project... ████████████████████ 100%

  ╭────── ✨ Project Created Successfully! ──────╮
  │                                               │
  │  Project         awesome-api                  │
  │  Location        ./awesome-api                │
  │  Package Manager uv                           │
  │  Database        postgres                     │
  │  ORM             sqlmodel                     │
  │                                               │
  ╰───────────────────────────────────────────────╯

  ╭────────────── 🚀 Next Steps ──────────────────╮
  │                                               │
  │  Get started with your new project:           │
  │                                               │
  │  $ cd ./awesome-api                           │
  │  $ uv run dev.py                              │
  │                                               │
  │  Your API will be available at:               │
  │  → http://localhost:8000                      │
  │  → http://localhost:8000/docs (API docs)      │
  │                                               │
  ╰───────────────────────────────────────────────╯
```

## 🏗️ Project Architecture

This tool follows **SOLID principles** and clean architecture:

```
fastapi_hephaestus/
├── cli.py                    # CLI commands (InitCommand, BuildCommand)
├── constants.py              # Configuration constants
├── console/                  # UI layer
│   ├── theme.py              # Rich theme
│   └── printer.py            # ConsoleUI class
├── models/                   # Domain models
│   └── project_config.py     # ProjectConfig dataclass
├── generators/               # File generation
│   └── file_generator.py     # FileGenerator class
├── services/                 # Business logic
│   ├── dependency_manager.py # Package management
│   └── project_initializer.py # Orchestration
└── templates/                # File templates
    └── templates.py          # TemplateProvider class
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the BSD License - see the [LICENSE.txt](LICENSE.txt) file for details.
