"""
Tests for msgmodel library.
"""
