"""Project operations for Limitry SDK"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..generated.models import ProjectGetResponse

if TYPE_CHECKING:
    from ..client import Client


class Project:
    """Operations for project endpoints"""

    def __init__(self, client: "Client"):
        """
        Initialize Project operations.

        Args:
            client: The Limitry client instance
        """
        self._client = client

    async def get(self) -> ProjectGetResponse:
        """
        Get current project.

        Returns the project associated with the API key used for authentication.

        The project contains metadata about your organization's configuration, including:
        - Project ID and organization ID
        - Project name and slug
        - Creation and update timestamps

        This endpoint is useful for verifying your API key is valid and retrieving project details.

        Returns:
            ProjectGetResponse: The project data

        Raises:
            AuthenticationError: When authentication fails
            APIError: When API request fails
        """
        response = await self._client.request("GET", "/project")
        return ProjectGetResponse(**response)
