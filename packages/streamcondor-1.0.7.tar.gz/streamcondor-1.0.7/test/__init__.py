"""
Test package for StreamCondor.
"""
