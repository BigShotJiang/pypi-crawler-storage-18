# Installation

Follow this [guide](https://docs.astral.sh/uv/getting-started/installation/) to install UV. 

# Running it

To run the entrypoint, run the following command.

```bash
 uv run -m semistaticsim.groundtruth.simulator
```

You can set the target amount of simulation time to collect as well as the scan size. 
The bigger the scan size, the higher the RAM usage and jitting time, but it has the *potential* to go faster if you want to collect a lot of simulation time.

After collecting the data, plot the groundtruth of the first pickupable across all its valid receptacles: 

```bash
TODO @MIGUEL BROKEN? OSError: 'science' is not a valid package style, path of style file
uv run groundtruth/viz.py
```

To run the ai2thor simulation, you can use

```bash
 uv run -m semistaticsim.keyboardcontrol.main_skillsim
```

## How-to

Features are based around varying the level of scene-to-scene semantic transfer. Every simulator step, some dt time elapses. When the `duration_left` reaches 0, the transition model selects the next receptacle that the object will transition to. Then, the duration model sampels the amount of tiem that the objet will spend in that new receptacle.

Duration model:

1. even is "evenly spread duration of all steps"
2. instant is "spend NO time at this place, immediately transition at the next step" (this is what flowmaps currently has in your 2D simulator)
3. deterministic is "randomly split the day among all steps"
4. gaussian is the same as deterministic with some gaussian noise

Transition model:

1. "fixed_canonical": object cycles down a list of fixed receptacles
2. "fixed_0.1_0.9": object has 10% chance of staying put, 90% chance of going to the next receptacle in cycle  (this is what the 2D flowmaps simulator has)
3. "uniform_no_diag": fully uniform transition matrix
4. "uniform_full": fully uniform transition matrix
5. "location_weighted_uniform_no_diag": uniform transition matrix weighted by the ProcThor receptacle prior
6. "location_weighted_uniform_full": uniform transition matrix weighted by the ProcThor receptacle prior

### Preliminary scan experiments

 1. SCANSIZE 10: ~33.5 it/s : 335 steps/s
2. 100 : 33 : 3300


1000 : eta 50min

1000 : cpu: 3s/it; cuda is same!
