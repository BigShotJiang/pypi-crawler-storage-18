"""Core authentication utilities."""
