"""FastAPI dependencies for authentication."""
