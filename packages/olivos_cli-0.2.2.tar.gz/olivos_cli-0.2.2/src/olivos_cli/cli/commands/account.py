# -*- coding: utf-8 -*-
"""
account 命令实现
"""

from ...core import SUPPORTED_ADAPTERS, ConfigManager, get_logger
from ...core.exceptions import OlivOSConfigError
from ...olivos import OlivOSConfigManager
from ...models import Account, AccountServer
from ...utils.prompt import ask, confirm, select

logger = get_logger()


def cmd_account(config_manager: ConfigManager, args) -> int:
    """账号管理"""
    action = args.acc_action

    if not action:
        # 显示帮助信息
        logger.info_print("用法: olivos-cli account [ACTION] [OPTIONS]")
        logger.info_print("")
        logger.info_print("动作:")
        logger.info_print("  list (ls)     列出所有账号")
        logger.info_print("  add           添加账号")
        logger.info_print("  remove (rm)   删除账号")
        logger.info_print("  show          显示账号详情")
        logger.info_print("")
        logger.info_print("使用 'olivos-cli account [ACTION] --help' 查看具体动作的帮助")
        return 0

    config = config_manager.config
    install_path = config.git.expanded_install_path

    if not install_path.exists():
        logger.error_print(f"OlivOS 目录不存在: {install_path}")
        logger.info_print("请先运行: olivos-cli init")
        return 1

    olivos_config = OlivOSConfigManager(install_path)

    if action == "list":
        return _cmd_account_list(olivos_config)
    elif action == "add":
        return _cmd_account_add(olivos_config, args)
    elif action == "remove":
        return _cmd_account_remove(olivos_config, args)
    elif action == "show":
        return _cmd_account_show(olivos_config, args)

    return 0


def _cmd_account_list(config: OlivOSConfigManager) -> int:
    """列出所有账号"""
    accounts = config.list_accounts()

    from rich.console import Console
    from rich.table import Table

    console = logger.console

    if not accounts:
        console.print("[yellow]暂无账号配置[/yellow]")
        return 0

    table = Table(title="账号列表")
    table.add_column("ID", style="cyan")
    table.add_column("适配器", style="green")
    table.add_column("平台", style="blue")
    table.add_column("模型", style="yellow")

    for acc in accounts:
        table.add_row(str(acc.id), acc.sdk_type, acc.platform_type, acc.model_type)

    console.print(table)
    return 0


def _cmd_account_add(config: OlivOSConfigManager, args) -> int:
    """添加账号"""
    from ...utils.prompt import select_multiple

    # 选择适配器类型（支持多选）
    if args.adapter:
        adapter_types = [args.adapter]
        for adapter_type in adapter_types:
            if adapter_type not in SUPPORTED_ADAPTERS:
                logger.error_print(f"不支持的适配器: {adapter_type}")
                logger.info_print(f"支持的适配器: {', '.join(SUPPORTED_ADAPTERS.keys())}")
                return 1
    elif args.non_interactive:
        logger.error_print("非交互模式需要指定 --adapter 参数")
        return 1
    else:
        adapter_names = [SUPPORTED_ADAPTERS[k]["name"] for k in SUPPORTED_ADAPTERS]
        choices = list(SUPPORTED_ADAPTERS.keys())
        selected_names = select_multiple(
            "选择适配器类型（可多选）",
            adapter_names,
            min_select=1,
        )
        adapter_types = [choices[adapter_names.index(name)] for name in selected_names]

    # 为每个适配器添加账号
    added_count = 0
    failed_count = 0

    for i, adapter_type in enumerate(adapter_types):
        if len(adapter_types) > 1:
            logger.info_print(f"\n[{i+1}/{len(adapter_types)}] 配置 {SUPPORTED_ADAPTERS[adapter_type]['name']}")

        adapter_info = SUPPORTED_ADAPTERS[adapter_type]

        # 收集账号信息
        if args.id:
            account_id = args.id
        elif args.non_interactive:
            logger.error_print("非交互模式需要指定 --id 参数")
            return 1
        else:
            account_id = ask("账号 ID")

        # 密码/Token
        if args.token:
            password = args.token
        elif args.non_interactive:
            password = ""
        else:
            password = ask("密码/Token", password=True)

        # 服务器配置
        if adapter_type in ["onebot", "onebot12"]:
            host = args.host or ask("服务器地址", default="127.0.0.1")
            port = args.port or int(ask("服务器端口", default="57000"))
            access_token = args.token or ask("访问令牌 (可选)", default="")

            server = AccountServer(
                auto=True,
                type="post",
                host=host,
                port=port,
                access_token=access_token,
            )
        else:
            server = AccountServer()

        # 创建账号
        account = Account(
            id=account_id,
            password=password,
            sdk_type=adapter_info["sdk_type"],
            platform_type=adapter_info["platform_type"],
            model_type="default",
            server=server,
        )

        # 验证
        errors = config.validate_account(account)
        if errors:
            logger.error_print("账号配置验证失败:")
            for err in errors:
                logger.console.print(f"  - {err}", style="red")
            failed_count += 1
            continue

        # 添加
        try:
            config.add_account(account)
            added_count += 1
        except OlivOSConfigError as e:
            logger.error_print(str(e))
            failed_count += 1

    # 总结
    if added_count > 0:
        logger.success(f"成功添加 {added_count} 个账号")
    if failed_count > 0:
        logger.warning_print(f"{failed_count} 个账号添加失败")

    return 0 if failed_count == 0 else 1


def _cmd_account_remove(config: OlivOSConfigManager, args) -> int:
    """删除账号"""
    account_id = args.account_id

    # 确认
    if not confirm(f"确定要删除账号 {account_id} 吗？"):
        return 0

    if config.remove_account(account_id):
        logger.success(f"账号已删除: {account_id}")
        return 0
    else:
        logger.error_print(f"账号不存在: {account_id}")
        return 1


def _cmd_account_show(config: OlivOSConfigManager, args) -> int:
    """显示账号详情"""
    account = config.get_account(args.account_id)

    if not account:
        logger.error_print(f"账号不存在: {args.account_id}")
        return 1

    from rich.console import Console
    from rich.table import Table

    console = logger.console

    table = Table(title=f"账号详情: {args.account_id}")
    table.add_column("项", style="cyan")
    table.add_column("值", style="green")

    table.add_row("ID", str(account.id))
    table.add_row("SDK 类型", account.sdk_type)
    table.add_row("平台类型", account.platform_type)
    table.add_row("模型类型", account.model_type)
    table.add_row("调试模式", "是" if account.debug else "否")

    if account.server:
        table.add_row("服务器类型", account.server.type)
        table.add_row("服务器地址", f"{account.server.host}:{account.server.port}")

    console.print(table)
    return 0
