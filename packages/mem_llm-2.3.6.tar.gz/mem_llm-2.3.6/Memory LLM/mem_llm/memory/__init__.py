"""
Memory package initialization.
"""
