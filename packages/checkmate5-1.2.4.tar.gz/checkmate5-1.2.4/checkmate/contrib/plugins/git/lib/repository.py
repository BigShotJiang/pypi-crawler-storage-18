"""
Minimal helpers for git repository grouping used by the git plugin.
These are stubs to keep imports working; replace with full implementations
if you need real git grouping logic.
"""

import datetime
from collections import defaultdict


def get_first_date_for_group(start_date, group_type, n=1):
    """
    Returns the first date to use when grouping snapshots.
    """
    if isinstance(start_date, datetime.datetime):
        dt = start_date
    else:
        dt = datetime.datetime.now()
    if group_type == "weekly":
        delta = datetime.timedelta(weeks=n)
    elif group_type == "daily":
        delta = datetime.timedelta(days=n)
    elif group_type == "monthly":
        delta = datetime.timedelta(days=30 * n)
    else:
        delta = datetime.timedelta(0)
    return dt - delta


def group_snapshots_by_date(snapshots, group_type):
    """
    Groups snapshots by date bucket; stubbed to group all into a single bucket keyed by group_type.
    """
    grouped = defaultdict(list)
    key = group_type or "all"
    for snapshot in snapshots:
        grouped[key].append(snapshot)
    return dict(grouped)

