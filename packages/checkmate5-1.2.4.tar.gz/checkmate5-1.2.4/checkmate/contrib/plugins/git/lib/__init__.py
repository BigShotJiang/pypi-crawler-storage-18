"""
Git plugin helper stubs.
"""

from .repository import group_snapshots_by_date, get_first_date_for_group

__all__ = ["group_snapshots_by_date", "get_first_date_for_group"]

