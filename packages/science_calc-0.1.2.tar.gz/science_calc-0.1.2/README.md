# 🧪 ScienceCalc

A sleek, powerful, and fully responsive **Scientific Calculator** built with Python and [Textual](https://textual.textualize.io/). Designed for the terminal, featuring a modern glassmorphism-inspired aesthetic and a robust calculation engine.

![ScienceCalc Preview](https://raw.githubusercontent.com/Mahir29Flame/Science-Calc/main/preview.png)

## ✨ Features

- 📱 **Full-Screen UI**: A responsive layout that adapts to any terminal size.
- 🎨 **Modern Aesthetics**: Sleek dark mode palette (`#0f172a`, `#1e293b`) with vibrant highlights (`#38bdf8`).
- 🔢 **Scientific Functions**:
  - Trigonometry: `sin`, `cos`, `tan`
  - Logarithms: `log` (base 10), `ln` (natural log)
  - Constants: `π` (pi), `e`
  - Algebra: Square root (`√`), Powers (`^`), Percentages (`%`)
- ⌨️ **Keyboard Optimized**:
  - `Enter` to calculate
  - `Ctrl + D` to clear
  - `Ctrl + C` to quit
- 🧠 **Smart Engine**: Built-in error handling and precision rounding.

## 🚀 Getting Started

### Prerequisites

- Python 3.8+
- [Textual](https://textual.textualize.io/) library

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/Mahir29Flame/Science-Calc.git
   cd Science-Calc
   ```

2. **Install dependencies**:
   ```bash
   pip install textual
   ```

### Running the App

Execute the main script:
```bash
python main.py
```

For development mode (with live reload):
```bash
textual run --dev main.py
```

## 🛠️ Built With

- **[Textual](https://github.com/Textualize/textual)** - The TUI (Terminal User Interface) framework.
- **Python Math** - Powering the calculation engine.

## 📜 License

Distributed under the MIT License. See `LICENSE` for more information.

---
Created with ❤️ by [Mahir29Flame](https://github.com/Mahir29Flame)
