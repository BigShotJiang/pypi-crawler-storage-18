# generated from codegen/templates/_rectanglefrustum.py

from __future__ import annotations

__all__ = ["DRectangleFrustum"]

from typing import TYPE_CHECKING
from typing import Protocol
from typing import overload

from emath import DMatrix4
from emath import DVector3
from emath import DVector4

from ._dplane import DPlane

if TYPE_CHECKING:
    from ._dboundingbox3d import DBoundingBox3d


class DRectangleFrustumOverlappable(Protocol):
    def overlaps_d_rectangle_frustum(self, other: DRectangleFrustum) -> bool: ...


class DRectangleFrustum:
    __slots__ = [
        "_transform",
        "_projection",
        "_near_plane",
        "_far_plane",
        "_left_plane",
        "_right_plane",
        "_bottom_plane",
        "_top_plane",
    ]

    @overload
    def __init__(
        self,
        *,
        transform: DMatrix4 = DMatrix4(1),
        orthographic: tuple[float, float, float, float, float, float],
    ): ...

    @overload
    def __init__(
        self, *, transform: DMatrix4 = DMatrix4(1), perspective: tuple[float, float, float, float]
    ): ...

    @overload
    def __init__(
        self,
        *,
        transform: DMatrix4 = DMatrix4(1),
        orthographic_rh_zo: tuple[float, float, float, float, float, float],
    ): ...

    @overload
    def __init__(
        self,
        *,
        transform: DMatrix4 = DMatrix4(1),
        perspective_rh_zo: tuple[float, float, float, float],
    ): ...

    def __init__(
        self,
        *,
        transform: DMatrix4 = DMatrix4(1),
        orthographic: tuple[float, float, float, float, float, float] | None = None,
        perspective: tuple[float, float, float, float] | None = None,
        orthographic_rh_zo: tuple[float, float, float, float, float, float] | None = None,
        perspective_rh_zo: tuple[float, float, float, float] | None = None,
    ):
        projection_params = [orthographic, perspective, orthographic_rh_zo, perspective_rh_zo]
        if sum(p is not None for p in projection_params) != 1:
            raise TypeError(
                "exactly one of orthographic, perspective, orthographic_rh_zo, or "
                "perspective_rh_zo must be specified"
            )

        if orthographic is not None:
            projection = DMatrix4.orthographic(*orthographic)
        elif perspective is not None:
            projection = DMatrix4.perspective(*perspective)
        elif orthographic_rh_zo is not None:
            projection = DMatrix4.orthographic_rh_zo(*orthographic_rh_zo)
        else:
            assert perspective_rh_zo is not None
            projection = DMatrix4.perspective_rh_zo(*perspective_rh_zo)

        self._transform = transform
        self._projection = projection

        r = [projection.get_row(i) for i in range(4)]
        tip = transform.inverse().transpose()
        if orthographic_rh_zo is not None or perspective_rh_zo is not None:
            self._near_plane = _create_transformed_plane(tip, r[2])
        else:
            self._near_plane = _create_transformed_plane(tip, r[3] + r[2])
        self._far_plane = _create_transformed_plane(tip, r[3] - r[2])
        self._left_plane = _create_transformed_plane(tip, r[3] + r[0])
        self._right_plane = _create_transformed_plane(tip, r[3] - r[0])
        self._bottom_plane = _create_transformed_plane(tip, r[3] + r[1])
        self._top_plane = _create_transformed_plane(tip, r[3] - r[1])

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DRectangleFrustum):
            return False
        return self.planes == other.planes

    def __repr__(self) -> str:
        return (
            f"<RectangleFrustum "
            f"near_plane={self._near_plane} "
            f"far_plane={self._far_plane} "
            f"left_plane={self._left_plane} "
            f"right_plane={self._right_plane} "
            f"bottom_plane={self._bottom_plane} "
            f"top_plane={self._top_plane}>"
        )

    def overlaps(self, other: DVector3 | DRectangleFrustumOverlappable) -> bool:
        if isinstance(other, DVector3):
            return self.overlaps_d_vector_3(other)
        try:
            other_overlaps = other.overlaps_d_rectangle_frustum
        except AttributeError:
            raise TypeError(other)
        return other_overlaps(self)

    def overlaps_d_bounding_box_3d(self, other: DBoundingBox3d) -> bool:
        return other.overlaps_d_rectangle_frustum(self)

    def overlaps_d_vector_3(self, other: DVector3) -> bool:
        for plane in self.planes:
            if plane.get_signed_distance_to_point(other) < 0:
                return False
        return True

    @property
    def transform(self) -> DMatrix4:
        return self._transform

    @property
    def projection(self) -> DMatrix4:
        return self._projection

    @property
    def near_plane(self) -> DPlane:
        return self._near_plane

    @property
    def far_plane(self) -> DPlane:
        return self._far_plane

    @property
    def left_plane(self) -> DPlane:
        return self._left_plane

    @property
    def right_plane(self) -> DPlane:
        return self._right_plane

    @property
    def top_plane(self) -> DPlane:
        return self._top_plane

    @property
    def bottom_plane(self) -> DPlane:
        return self._bottom_plane

    @property
    def planes(self) -> tuple[DPlane, DPlane, DPlane, DPlane, DPlane, DPlane]:
        return (
            self._near_plane,
            self._far_plane,
            self._left_plane,
            self._right_plane,
            self._top_plane,
            self._bottom_plane,
        )

    @property
    def points(
        self,
    ) -> tuple[DVector3, DVector3, DVector3, DVector3, DVector3, DVector3, DVector3, DVector3]:
        vp = (self._transform @ self._projection).inverse()
        return (
            vp @ DVector3(-1, -1, -1),
            vp @ DVector3(1, -1, -1),
            vp @ DVector3(-1, 1, -1),
            vp @ DVector3(-1, -1, 1),
            vp @ DVector3(1, 1, 1),
            vp @ DVector3(-1, 1, 1),
            vp @ DVector3(1, -1, 1),
            vp @ DVector3(1, 1, -1),
        )


def _create_transformed_plane(inversed_transposed_transform: DMatrix4, plane: DVector4) -> DPlane:
    plane = inversed_transposed_transform @ plane
    return DPlane(plane.w, plane.xyz)
