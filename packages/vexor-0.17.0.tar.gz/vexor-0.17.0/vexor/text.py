"""Centralized user-facing text for Vexor CLI."""

from __future__ import annotations

class Styles:
    ERROR = "red"
    WARNING = "yellow"
    SUCCESS = "green"
    INFO = "dim"
    TITLE = "bold cyan"
    TABLE_HEADER = "bold magenta"


class Messages:
    APP_HELP = "Vexor – A vector-powered CLI for semantic search over filenames."
    HELP_QUERY = "Text used to semantically match file names."
    HELP_SEARCH_PATH = "Root directory whose search will be performed."
    HELP_SEARCH_TOP = "Number of results to display."
    HELP_SEARCH_FORMAT = (
        "Output format (rich=table, porcelain=tab-separated for scripts, porcelain-z=NUL-delimited)."
    )
    HELP_INCLUDE_HIDDEN = "Use the index built with hidden files included."
    HELP_INDEX_PATH = "Root directory to scan for indexing."
    HELP_INDEX_INCLUDE = "Include hidden files and directories when building the index."
    HELP_INDEX_CLEAR = "Remove the cached index for the specified path (respecting include-hidden, mode and recursion)."
    HELP_INDEX_SHOW = "Display metadata for the cached index matching the provided options."
    HELP_RECURSIVE = "Recurse into subdirectories (default). Disable to work only on the specified directory."
    HELP_MODE = (
        "Indexing mode (auto=smart default, name=filename, head=head snippet, brief=keyword summary, "
        "full=chunked content, code=python module/function/class chunks, outline=markdown headings) "
        "to control how embeddings are built."
    )
    HELP_EXTENSIONS = (
        "Limit indexing/searching to files whose names end with the provided extensions "
        "(repeat --ext; each value may also be a comma/space-separated list like "
        "--ext .py,.md or --ext '.py .md')."
    )
    HELP_EXCLUDE_PATTERNS = (
        "Exclude files or directories by gitignore-style patterns "
        "(repeat --exclude-pattern; supports wildcards and paths like tests/**; "
        "plain extensions like .js are treated as **/*.js)."
    )
    HELP_RESPECT_GITIGNORE = (
        "Respect .gitignore-style exclude rules when scanning (default). "
        "Use --no-respect-gitignore to include ignored files."
    )
    HELP_DOCTOR = "Check whether the `vexor` command is available on the current PATH."
    HELP_UPDATE = "Check if a newer Vexor release is available online."
    HELP_UPDATE_UPGRADE = "Upgrade Vexor automatically when a newer version is available."
    HELP_UPDATE_PRE = "Include pre-release versions when checking/upgrading."
    HELP_FEEDBACK = "Open the GitHub issue form (or use `gh` if available) to send feedback."
    HELP_STAR = "Star the Vexor repository on GitHub (or use `gh` if available)."
    HELP_ALIAS = "Print a shell alias that maps `vx` to `vexor` and optionally apply it."
    HELP_SET_API_KEY = "Persist an API key in ~/.vexor/config.json."
    HELP_CLEAR_API_KEY = "Remove the stored API key."
    HELP_SET_MODEL = "Set the default embedding model."
    HELP_SET_BATCH = "Set the default batch size (0 = single request)."
    HELP_SET_EMBED_CONCURRENCY = "Set the number of concurrent embedding requests."
    HELP_SET_PROVIDER = "Set the default embedding provider (e.g., gemini, openai, custom, or local)."
    HELP_SET_BASE_URL = "Override the provider's base URL (leave unset for official endpoints)."
    HELP_CLEAR_BASE_URL = "Remove the custom base URL override."
    HELP_SET_AUTO_INDEX = "Enable/disable automatic indexing before search (default: enabled)."
    HELP_SET_RERANK = "Set the rerank strategy (off, bm25, flashrank, remote)."
    HELP_SET_FLASHRANK_MODEL = (
        "Set the FlashRank model name (omit or empty resets to default)."
    )
    HELP_CLEAR_FLASHRANK = "Delete cached FlashRank reranker models."
    HELP_SET_REMOTE_RERANK_URL = "Set the remote rerank endpoint URL."
    HELP_SET_REMOTE_RERANK_MODEL = "Set the remote rerank model name."
    HELP_SET_REMOTE_RERANK_API_KEY = (
        "Set the remote rerank API key (or use VEXOR_REMOTE_RERANK_API_KEY)."
    )
    HELP_CLEAR_REMOTE_RERANK = "Clear remote rerank configuration."
    HELP_SHOW_CONFIG = "Show current configuration."
    HELP_SHOW_INDEX_ALL = "Show metadata for every cached index regardless of path."
    HELP_CLEAR_INDEX_ALL = "Delete all cached indexes stored under ~/.vexor."
    HELP_INSTALL_SKILLS = (
        "Install the bundled `vexor-cli` Agent Skill into an AI assistant skills directory "
        "(targets: claude, codex)."
    )
    HELP_INSTALL_FORCE = "Overwrite the destination skill folder if it already exists."
    HELP_LOCAL = "Manage local embedding models."
    HELP_SETUP_LOCAL = "Download a local embedding model and configure Vexor to use it."
    HELP_SETUP_LOCAL_MODEL = "Local embedding model name to download (fastembed model name)."
    HELP_LOCAL_CLEANUP = "Delete the local model cache stored under ~/.vexor/models."
    HELP_LOCAL_CUDA = "Enable CUDA for local embedding (requires onnxruntime-gpu)."
    HELP_LOCAL_CPU = "Disable CUDA and use CPU for local embedding."

    ERROR_API_KEY_MISSING = (
        "API key is missing or still set to the placeholder. "
        "Configure it via `vexor config --set-api-key <token>` or an environment variable."
    )
    ERROR_API_KEY_INVALID = "API key appears invalid. Verify the stored token and try again."
    ERROR_GENAI_PREFIX = "Gemini API request failed: "
    ERROR_OPENAI_PREFIX = "OpenAI API request failed: "
    ERROR_NO_EMBEDDINGS = "Embedding API returned no embeddings."
    ERROR_LOCAL_DEP_MISSING = (
        "Local model support is not installed. "
        "Install with `pip install \"vexor\\[local]\"` "
        "(or `vexor\\[local-cuda]` for GPU)."
    )
    ERROR_LOCAL_MODEL_LOAD = "Failed to load local model '{model}' ({reason})."
    ERROR_LOCAL_MODEL_EMBED = "Local model embed failed ({reason})."
    ERROR_LOCAL_MODEL_EMPTY = "Model name cannot be empty."
    ERROR_LOCAL_OPTIONS_CONFLICT = "Use --clean-up without combining it with other options."
    ERROR_LOCAL_CACHE_CLEANUP = "Failed to remove local model cache at {path} ({reason})."
    ERROR_LOCAL_CUDA_CONFLICT = "Use only one of --cuda or --cpu."
    ERROR_CUSTOM_BASE_URL_REQUIRED = (
        "Custom provider requires a base URL. Set it with `vexor config --set-base-url <URL>`."
    )
    ERROR_CUSTOM_MODEL_REQUIRED = (
        "Custom provider requires a model name. Set it with `vexor config --set-model <NAME>`."
    )
    ERROR_EMPTY_QUERY = "Query text must not be empty."
    ERROR_BATCH_NEGATIVE = "Batch size must be >= 0"
    ERROR_CONCURRENCY_INVALID = "Embedding concurrency must be >= 1"
    ERROR_MODE_INVALID = "Unsupported mode '{value}'. Allowed values: {allowed}."
    ERROR_PROVIDER_INVALID = "Unsupported provider '{value}'. Allowed values: {allowed}."
    ERROR_RERANK_INVALID = "Unsupported rerank value '{value}'. Allowed values: {allowed}."
    ERROR_FLASHRANK_MISSING = (
        "FlashRank reranker is not installed. Install with `pip install \"vexor\\[flashrank]\"`."
    )
    ERROR_FLASHRANK_MODEL_EMPTY = "FlashRank model name cannot be empty."
    ERROR_REMOTE_RERANK_INCOMPLETE = (
        "Remote rerank requires base URL, model, and API key."
    )
    ERROR_REMOTE_RERANK_URL_EMPTY = "Remote rerank URL cannot be empty."
    ERROR_REMOTE_RERANK_MODEL_EMPTY = "Remote rerank model name cannot be empty."
    ERROR_REMOTE_RERANK_API_KEY_EMPTY = "Remote rerank API key cannot be empty."
    ERROR_REMOTE_RERANK_CLEAR_CONFLICT = (
        "Use --clear-remote-rerank without combining it with remote rerank options."
    )
    ERROR_REMOTE_RERANK_FAILED = "Remote rerank request failed ({reason})."
    ERROR_FLASHRANK_CLEAR_CONFLICT = (
        "Use --clear-flashrank without combining it with other config options."
    )
    ERROR_FLASHRANK_CACHE_CLEANUP = "Failed to remove FlashRank cache at {path} ({reason})."
    ERROR_FLASHRANK_SETUP = "Failed to prepare FlashRank model ({reason})."
    ERROR_BASE_URL_CONFLICT = "Cannot set and clear the base URL in the same command."
    ERROR_EXTENSIONS_EMPTY = "Provide at least one valid file extension when using --ext."
    ERROR_BOOLEAN_INVALID = "Unsupported boolean value '{value}'. Use true/false, yes/no, 1/0, on/off."

    INFO_NO_FILES = "No files found in the selected directory."
    INFO_NO_RESULTS = "No matching files found."
    ERROR_INDEX_MISSING = (
        "No cached index found for {path}. Run `vexor index` first."
    )
    INFO_INDEX_SAVED = "Index saved to {path}."
    INFO_INDEX_EMPTY = "Index contains no files."
    INFO_INDEX_UP_TO_DATE = "Index already matches the current directory; nothing to do."
    WARNING_INDEX_STALE = "Cached index for {path} appears outdated; run `vexor index` to refresh."
    INFO_INDEX_RUNNING = "Indexing files under {path}..."
    INFO_INDEX_CLEARED = "Removed {count} cached index entr{plural} for {path}."
    INFO_INDEX_CLEAR_NONE = "No cached index found for {path}."
    ERROR_INDEX_SHOW_CONFLICT = "Cannot use --show together with --clear."
    INFO_INDEX_SHOW_HEADER = "Cached index details for {path}:"
    INFO_INDEX_SHOW_SUMMARY = (
        "Mode: {mode}\n"
        "Model: {model}\n"
        "Include hidden: {hidden}\n"
        "Recursive: {recursive}\n"
        "Respect gitignore: {gitignore}\n"
        "Exclude patterns: {exclude_patterns}\n"
        "Extensions: {extensions}\n"
        "Files: {files}\n"
        "Embedding dimension: {dimension}\n"
        "Version: {version}\n"
        "Generated at: {generated}"
    )
    INFO_INDEX_ALL_HEADER = "Cached index overview"
    INFO_INDEX_ALL_EMPTY = "No cached indexes found under ~/.vexor."
    INFO_INDEX_ALL_CLEARED = "Removed {count} cached index entr{plural} in total."
    INFO_INDEX_ALL_CLEAR_NONE = "Cache already empty; nothing to remove."
    INFO_FLASHRANK_CACHE_EMPTY = "FlashRank cache already empty at {path}"
    INFO_FLASHRANK_CACHE_CLEARED = "FlashRank cache removed at {path}"
    INFO_API_SAVED = "API key saved."
    INFO_API_CLEARED = "API key cleared."
    INFO_MODEL_SET = "Default model set to {value}."
    INFO_BATCH_SET = "Default batch size set to {value}."
    INFO_EMBED_CONCURRENCY_SET = "Embedding concurrency set to {value}."
    INFO_PROVIDER_SET = "Default provider set to {value}."
    INFO_BASE_URL_SET = "Base URL override set to {value}."
    INFO_BASE_URL_CLEARED = "Base URL override cleared."
    INFO_AUTO_INDEX_SET = "Auto index {value}."
    INFO_RERANK_SET = "Rerank strategy set to {value}."
    INFO_FLASHRANK_MODEL_SET = "FlashRank model set to {value}."
    INFO_FLASHRANK_MODEL_RESET = "FlashRank model reset to default ({value})."
    INFO_REMOTE_RERANK_URL_SET = "Remote rerank URL set to {value}."
    INFO_REMOTE_RERANK_MODEL_SET = "Remote rerank model set to {value}."
    INFO_REMOTE_RERANK_API_KEY_SET = "Remote rerank API key set."
    INFO_REMOTE_RERANK_CLEARED = "Remote rerank configuration cleared."
    INFO_LOCAL_SETUP_START = "Preparing local model {model}..."
    INFO_LOCAL_SETUP_HINT = "Use `vexor local --help` to configure a local embedding model."
    INFO_LOCAL_CACHE_DIR = "Local model cache: {path}"
    INFO_LOCAL_CACHE_EMPTY = "Local model cache already empty at {path}"
    INFO_LOCAL_CACHE_CLEARED = "Local model cache removed at {path}"
    INFO_LOCAL_SETUP_DONE = "Local model ready: {model}. Provider set to local."
    INFO_LOCAL_CUDA_ENABLED = "Local embeddings will use CUDA."
    INFO_LOCAL_CUDA_DISABLED = "Local embeddings will use CPU."
    INFO_FLASHRANK_SETUP_START = "Preparing FlashRank model..."
    INFO_FLASHRANK_SETUP_DONE = "FlashRank model ready."
    DOCTOR_LOCAL_CUDA_MISSING = "CUDA provider not available for local embeddings"
    DOCTOR_LOCAL_CUDA_IMPORT_FAILED = "Unable to import onnxruntime (CUDA check failed)"
    DOCTOR_LOCAL_CUDA_MISSING_DETAIL = (
        "Install `vexor\\[local-cuda]` or `onnxruntime-gpu`, "
        "and ensure CUDA drivers are installed. Available providers: {providers}"
    )
    DOCTOR_LOCAL_CUDA_IMPORT_DETAIL = (
        "Install `vexor\\[local-cuda]` or `onnxruntime-gpu` ({reason})"
    )
    INFO_CONFIG_EDITING = "Opening config file in editor ({editor}): {path}"
    ERROR_CONFIG_EDITOR_NOT_FOUND = "Unable to determine a text editor. Set $VISUAL or $EDITOR, or install nano/vi."
    ERROR_CONFIG_EDITOR_FAILED = "Editor exited with status {code}."
    ERROR_CONFIG_EDITOR_LAUNCH = "Failed to launch editor: {reason}."
    INFO_CONFIG_SUMMARY = (
        "API key set: {api}\n"
        "Default provider: {provider}\n"
        "Default model: {model}\n"
        "Default batch size: {batch}\n"
        "Embedding concurrency: {concurrency}\n"
        "Auto index: {auto_index}\n"
        "Rerank: {rerank}\n"
        "{flashrank_line}"
        "{remote_rerank_line}"
        "Local CUDA: {local_cuda}\n"
        "Custom base URL: {base_url}"
    )
    INFO_FLASHRANK_MODEL_SUMMARY = "FlashRank model: {value}"
    INFO_REMOTE_RERANK_SUMMARY = "Remote rerank: {value}"
    INFO_SEARCH_RUNNING = "Searching cached index under {path}..."
    INFO_DOCTOR_CHECKING = "Checking if `vexor` is on PATH..."
    INFO_DOCTOR_FOUND = "`vexor` command is available at {path}."
    ERROR_DOCTOR_MISSING = (
        "`vexor` command is not on PATH. Install with pip or add the script directory to PATH."
    )
    # Doctor check messages
    DOCTOR_TITLE = "Vexor Doctor v{version}"
    DOCTOR_CMD_FOUND = "`vexor` found at {path}"
    DOCTOR_CMD_MISSING = "`vexor` not found on PATH"
    DOCTOR_CMD_MISSING_DETAIL = "Install with pip or add the script directory to PATH."
    DOCTOR_CONFIG_EXISTS = "Config file exists at {path}"
    DOCTOR_CONFIG_DEFAULT = "No config file (using defaults)"
    DOCTOR_CONFIG_INVALID = "Config file is invalid JSON at {path}"
    DOCTOR_CACHE_CREATED = "Created cache directory at {path}"
    DOCTOR_CACHE_WRITABLE = "Cache directory writable at {path}"
    DOCTOR_CACHE_NOT_WRITABLE = "Cache directory not writable at {path}"
    DOCTOR_CACHE_CANNOT_CREATE = "Cannot create cache directory at {path}"
    DOCTOR_API_KEY_CONFIGURED = "API key configured ({masked})"
    DOCTOR_API_KEY_MISSING = "API key not configured"
    DOCTOR_API_KEY_MISSING_DETAIL = (
        "Run `vexor config --set-api-key <KEY>` or set VEXOR_API_KEY / "
        "OPENAI_API_KEY / GOOGLE_GENAI_API_KEY environment variable."
    )
    DOCTOR_API_KEY_NOT_REQUIRED = "Local provider selected (no API key required)"
    DOCTOR_API_SKIPPED = "Skipped (no API key)"
    DOCTOR_API_REACHABLE = "API reachable (model: {model}, dim: {dim})"
    DOCTOR_API_UNEXPECTED = "API returned unexpected response"
    DOCTOR_API_FAILED = "API request failed"
    DOCTOR_LOCAL_READY = "Local model ready (model: {model}, dim: {dim})"
    DOCTOR_LOCAL_UNEXPECTED = "Local model returned unexpected response"
    DOCTOR_LOCAL_FAILED = "Local model test failed"
    DOCTOR_ALL_PASSED = "All checks passed!"
    DOCTOR_SOME_FAILED = "Some checks failed. See details above."
    HELP_DOCTOR_SKIP_API = "Skip the API connectivity test."
    INFO_UPDATE_CHECKING = "Checking latest Vexor version..."
    INFO_UPDATE_CURRENT = "You are running Vexor v{current}."
    INFO_UPDATE_AVAILABLE = (
        "New version available: v{latest}. Visit {github} or {pypi} to download the update."
    )
    INFO_UPDATE_UP_TO_DATE = "You already have the latest version (v{latest})."
    ERROR_UPDATE_FETCH = "Unable to fetch latest version information ({reason})."
    INFO_UPDATE_INSTALL_METHOD = "Detected install method: {method}"
    WARNING_UPDATE_ADMIN = "This installation may require administrator privileges to upgrade."
    WARNING_UPDATE_GIT_DIRTY = "Git working tree has uncommitted changes at {path}."
    WARNING_UPDATE_STANDALONE = "Standalone binary detected at {path}."
    INFO_UPDATE_STANDALONE_ASSET = "Suggested asset: {asset}"
    INFO_UPDATE_STANDALONE_URL = "Download: {url}"
    INFO_UPDATE_UPGRADE_CMD = "Upgrade command: {cmd}"
    PROMPT_UPDATE_UPGRADE_CONFIRM = "Proceed with upgrade?"
    INFO_UPDATE_UPGRADE_CANCELLED = "Upgrade cancelled."
    INFO_UPDATE_UPGRADING = "Upgrading Vexor..."
    INFO_UPDATE_UPGRADE_DONE = "Upgrade finished. Re-run `vexor --version` to confirm."
    ERROR_UPDATE_UPGRADE_FAILED = "Upgrade failed (exit code {code})."
    PROMPT_ALIAS_APPLY = "Apply this alias to your shell profile?"
    INFO_ALIAS_APPLIED = "Alias added to {path}. Restart your shell to use it."
    INFO_ALIAS_ALREADY_SET = "Alias already present in {path}."
    WARNING_ALIAS_PROFILE_MISSING = (
        "Unable to determine a shell profile to update. Copy/paste the command above."
    )
    ERROR_ALIAS_WRITE = "Failed to write alias to {path} ({reason})."
    INFO_ALIAS_VX = "alias vx='vexor'"
    INFO_ALIAS_FISH = "alias vx 'vexor'"
    INFO_ALIAS_POWERSHELL = "Set-Alias vx vexor"
    INFO_FEEDBACK_OPENING = "Opening feedback form: {url}"
    INFO_FEEDBACK_GH = "Creating GitHub issue via `gh`..."
    WARNING_FEEDBACK_GH_FAILED = "Unable to run `gh issue create` ({reason}); opening browser instead."
    ERROR_FEEDBACK_LAUNCH = "Unable to open browser for {url} ({reason})."
    ERROR_INSTALL_SKILL_SOURCE = "Unable to locate the bundled skill files ({reason})."
    ERROR_INSTALL_SKILL_EXISTS = (
        "Skill destination already exists: {path}. Use --force to overwrite."
    )

    TABLE_TITLE = "Vexor semantic file search results"
    TABLE_HEADER_INDEX = "#"
    TABLE_HEADER_SIMILARITY = "Similarity"
    TABLE_HEADER_PATH = "File path"
    TABLE_HEADER_LINES = "Lines"
    TABLE_HEADER_PREVIEW = "Preview"
    TABLE_BACKEND_PREFIX = "Backend: "
    TABLE_RERANKER_PREFIX = "Reranker: "
    TABLE_INDEX_HEADER_ROOT = "Root"
    TABLE_INDEX_HEADER_MODE = "Mode"
    TABLE_INDEX_HEADER_MODEL = "Model"
    TABLE_INDEX_HEADER_HIDDEN = "Hidden"
    TABLE_INDEX_HEADER_RECURSIVE = "Recursive"
    TABLE_INDEX_HEADER_GITIGNORE = "Gitignore"
    TABLE_INDEX_HEADER_EXCLUDES = "Exclude"
    TABLE_INDEX_HEADER_EXTENSIONS = "Extensions"
    TABLE_INDEX_HEADER_FILES = "Files"
    TABLE_INDEX_HEADER_GENERATED = "Generated"

    INFO_INSTALL_SKILL_UP_TO_DATE = "Skill already up to date at {path}."
    INFO_INSTALL_SKILL_DONE = "Installed skill to {path}."

    INFO_STAR_SUCCESS = "Thank you for starring the Vexor repository!"
    INFO_STAR_BROWSER = "Opening {url} in your browser to star the repository..."
