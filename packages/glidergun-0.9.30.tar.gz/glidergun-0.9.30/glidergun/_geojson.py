import json
from collections.abc import Iterable
from typing import IO, Any, Literal, TypedDict

from shapely.geometry import Point, Polygon, mapping

from glidergun._utils import create_directory_for


class Feature(TypedDict):
    type: Literal["Feature"]
    geometry: dict[str, Any]
    properties: dict[str, Any]


class FeatureCollection(dict):
    type: Literal["FeatureCollection"]
    features: list[Feature]

    def __init__(self, features: Iterable[tuple[Point | Polygon, dict]], **kwargs):
        super().__init__(
            type="FeatureCollection",
            features=[{"type": "Feature", "geometry": mapping(g), "properties": p} for g, p in features],
            **kwargs,
        )

    def save(self, file: str | IO[str]):
        if isinstance(file, str):
            create_directory_for(file)
            with open(file, "w") as f:
                json.dump(self, f)
        else:
            json.dump(self, file)
