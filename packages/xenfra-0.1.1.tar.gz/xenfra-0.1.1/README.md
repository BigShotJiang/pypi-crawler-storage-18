# 🧘 Xenfra: Infrastructure in Zen Mode

**Xenfra** is a modular infrastructure engine for Python developers that automates the deployment of applications to DigitalOcean. It is designed as a library first, with a beautiful and interactive CLI as the default frontend.

It handles the complexity of server provisioning, context-aware configuration, Dockerization, and automatic HTTPS, allowing you to focus on your code.

## ✨ Core Philosophy

*   **Engine as the Brain**: `xenfra.engine` is the core library. It owns the DigitalOcean API, the SSH "Auto-Heal" retry loops, and the Dockerizer services. It is stateful, robust, and can be imported into any Python project.
*   **Clients as the Face**: Frontends like the default CLI (`xenfra.cli`) are thin, stateless clients responsible only for user interaction.
*   **Zen Mode**: If a server setup fails due to common issues like a locked package manager, the Engine automatically fixes it without exposing raw errors to the user.

## 🚀 Quickstart: As a Library

This demonstrates the power of Xenfra's engine for programmatic infrastructure management.

### 1. Installation

```bash
# Install from PyPI (once published)
pip install xenfra
```

### 2. Prerequisites

Ensure your DigitalOcean API token is available as an environment variable:

```bash
export DIGITAL_OCEAN_TOKEN="your_secret_token_here"
```

### 3. Programmatic Usage

```python
from xenfra.engine import InfraEngine

# Optional: a logger to receive status updates
def my_logger(message):
    print(f"[My App] {message}")

try:
    # The engine automatically finds and validates the API token
    engine = InfraEngine()

    # Define the server and deploy
    result = engine.deploy_server(
        name="my-app-server",
        region="nyc3",
        size="s-1vcpu-1gb",
        image="ubuntu-24-04-x64",
        logger=my_logger
    )

    print(f"🎉 Deployment successful! IP Address: {result.get('ip')}")

except Exception as e:
    print(f"❌ Deployment failed: {e}")
```

## 💻 CLI Usage

Xenfra also provides a beautiful, interactive CLI for manual control.

### 1. Installation

```bash
pip install xenfra
```

### 2. Configuration

Create a `.env` file in your project root with your DigitalOcean token:

```env
DIGITAL_OCEAN_TOKEN=dop_v1_your_token_here
```

### 3. Run the CLI

Once installed, simply run the `xenfra` command:

```bash
xenfra
```

This will launch the interactive menu where you can:
- **🚀 Deploy New Server**: A guided workflow to provision and deploy your application.
- **📋 List Active Servers**: View your current DigitalOcean droplets.
- **🧨 Destroy a Server**: Decommission servers you no longer need.

## 📦 Supported Frameworks & Features

*   **Smart Context Detection**: Automatically detects your package manager (`uv` or `pip`).
*   **Automatic Dockerization**: If a web framework is detected (`FastAPI`, `Flask`), Xenfra will:
    *   Generate a `Dockerfile`, `docker-compose.yml`, and `Caddyfile`.
    *   Deploy your application as a container.
    *   Configure **Caddy** as a reverse proxy with **automatic HTTPS**.

## 🤝 Contributing

Contributions are welcome! Please check our `CONTRIBUTING.md` for more details.

## 📄 Created by DevHusnainAi