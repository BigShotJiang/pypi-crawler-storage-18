def generate_stack(context, is_dockerized=False):
    """
    Generates a startup script.
    INCLUDES 'AGGRESSIVE MODE' to kill background updates.
    """
    project_type = context.get("type", "pip")
    packages = context.get("packages", "")

    script = """#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
LOG="/root/setup.log"
touch $LOG

echo "--------------------------------" >> $LOG
echo "🧘 XENFRA: Context-Aware Boot" >> $LOG
echo "--------------------------------" >> $LOG

# Create App Directory
mkdir -p /root/app
cd /root/app

# --- AGGRESSIVE FIX: KILL BACKGROUND UPDATES ---
echo "⚔️  [0/6] Stopping Background Updates..." >> $LOG
systemctl stop unattended-upgrades.service
systemctl stop apt-daily.service
systemctl stop apt-daily-upgrade.service
systemctl kill --kill-who=all apt-daily.service
systemctl kill --kill-who=all apt-daily-upgrade.service

# Force remove locks if they exist (The Nuclear Option)
rm -f /var/lib/dpkg/lock*
rm -f /var/lib/apt/lists/lock
rm -f /var/cache/apt/archives/lock
dpkg --configure -a
# -----------------------------------------------

# 1. System Updates
echo "🔄 [1/6] Refreshing Package Lists..." >> $LOG
apt-get update
apt-get install -y python3-pip python3-venv git curl

# 2. Install Docker & Compose
echo "🐳 [2/6] Installing Docker..." >> $LOG
apt-get install -y docker.io || (curl -fsSL https://get.docker.com | sh)
echo "🎶 [3/6] Installing Docker Compose..." >> $LOG
apt-get install -y docker-compose-v2
"""

    if is_dockerized:
        script += """
# --- DOCKERIZED DEPLOYMENT ---
echo "📦 [4/6] Installing Caddy..." >> $LOG
apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
curl -LsSf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -LsSf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt-get update
apt-get install -y caddy

echo "🚀 [5/6] Starting application with Docker Compose..." >> $LOG
cd /root/app
docker-compose -f /root/app/docker-compose.yml up -d

echo "🔒 [6/6] Reloading Caddy..." >> $LOG
# Caddy will automatically use the Caddyfile from the mounted volume in docker-compose
# We just need to make sure it's running. Docker-compose handles this.
# A system reload might be useful if Caddy was installed as a host service.
systemctl reload caddy || systemctl start caddy
"""
    else:
        # 3. Virtual Environment Setup (Non-Dockerized)
        if project_type == "uv":
            script += """
# --- STANDARD NON-DOCKER DEPLOYMENT (UV) ---
echo "⚡ [4/6] Installing UV..." >> $LOG
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env
export PATH="/root/.local/bin:$PATH"

echo "⚡ [5/6] Creating UV Venv..." >> $LOG
uv venv /root/venv
source /root/venv/bin/activate
"""
        else:
            script += """
# --- STANDARD NON-DOCKER DEPLOYMENT (PIP) ---
echo "🐍 [4/6] Creating Python Venv..." >> $LOG
python3 -m venv /root/venv
source /root/venv/bin/activate
echo "🐍 [5/6] Upgrading Pip..." >> $LOG
pip install --upgrade pip
"""
        # 4. Install Packages (Non-Dockerized)
        if packages:
            if project_type == "uv":
                script += f"""
echo "📦 [6/6] UV Installing Deps: {packages}..." >> $LOG
source /root/venv/bin/activate
uv pip install {packages}
"""
            else:
                script += f"""
echo "📦 [6/6] Pip Installing Deps: {packages}..." >> $LOG
source /root/venv/bin/activate
pip install {packages}
"""
        else:
            script += 'echo "ℹ️  [6/6] No packages detected." >> $LOG\n'

    # Finish
    script += """

echo "✅ SETUP COMPLETE" >> $LOG
touch /root/setup_complete
"""
    return script
