#! /usr/bin/python3

r'''###############################################################################
###################################################################################
#
#	Helpers Python Module
#	Version 1.0
#
#	Project Los Angeles
#
#	Tegridy Code 2025
#
#   https://github.com/Tegridy-Code/Project-Los-Angeles
#
###################################################################################
###################################################################################
#
#   Copyright 2025 Project Los Angeles / Tegridy Code
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
###################################################################################
'''

###################################################################################

import os
import hashlib

from .TMIDIX import midi2score, score2midi

###################################################################################

def get_normalized_md5_hash(midi_file):

    bfn = os.path.basename(midi_file)
    fn = os.path.splitext(bfn)[0]
    
    midi_data = open(midi_file, 'rb').read()
    
    old_md5 = hashlib.md5(midi_data).hexdigest()
    
    score = TMIDIX.midi2score(midi_data, do_not_check_MIDI_signature=True)
        
    norm_midi = TMIDIX.score2midi(score)
    
    new_md5 = hashlib.md5(norm_midi).hexdigest()
    
    output_dic = {'midi_name': fn,
                  'original_md5': old_md5,
                  'normalized_md5': new_md5
                 }

    return output_dic

###################################################################################

def normalize_midi_file(midi_file, output_dir='', output_file_name=''):

    if not output_file_name:
        output_file_name = os.path.basename(midi_file)

    if not output_dir:
        output_dir = os.getcwd()

    os.makedirs(output_dir, exist_ok=True)

    midi_path = os.path.join(output_dir, output_file_name)

    if os.path.exists(midi_path):
        fn = os.path.splitext(output_file_name)[0]
        output_file_name = f'{fn}_normalized.mid'
        midi_path = os.path.join(output_dir, output_file_name)
    
    midi_data = open(midi_file, 'rb').read()
    
    score = TMIDIX.midi2score(midi_data, do_not_check_MIDI_signature=True)
        
    norm_midi = TMIDIX.score2midi(score)

    with open(midi_path, 'wb') as fi:
        fi.write(norm_midi)

    return midi_path

###################################################################################
# This is the end of the Helpers Python Module
###################################################################################