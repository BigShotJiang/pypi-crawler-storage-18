# Rust String Analyzer

Rust String Analyzer is a Python package designed to assist developers in analyzing Rust code related to string handling, particularly focusing on the use and best practices of `String` and `&str` types in Rust APIs. It leverages structured pattern matching with large language models to process user inputs, identify key coding patterns, and generate comprehensive guidance to improve code clarity, safety, and efficiency.

## Features

- Analyzes user-provided Rust code snippets or descriptions.
- Identifies common patterns and pitfalls in string handling.
- Provides structured recommendations and insights.
- Emphasizes best practices for Rust API design involving string types.

## Installation

You can install Rust String Analyzer via pip:

```bash
pip install rust-string-analyzer
```

## Usage Example

Here's how to use the package in your Python code:

```python
# Import and invoke the main function to process user input:
from rust_string_analyzer import rust_string_analyzer

# Example user input about Rust string handling:
user_input = "How do I safely convert &str to String in Rust?"

# Call the analyzer:
results = rust_string_analyzer(user_input)

# Print the analysis results:
for result in results:
    print(result)
```

## Contributing

Contributions are welcome! Feel free to open issues or submit pull requests to improve the package.

## Issues

If you encounter any bugs or have feature requests, please report them here:

[GitHub Issues](https://github.com/yourgithubrepo/issues)

## Author

Eugene Evstafev  
Email: hi@euegne.plus

## License

This project is licensed under the MIT License. See the LICENSE file for details.