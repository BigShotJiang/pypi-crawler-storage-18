"""UI components for Crackerjack."""
