from __future__ import absolute_import
from typing import Callable, Optional
from log4py import logging
from fastapi import FastAPI
from mctech_discovery.discovery import get_discovery, get_configure
from . import middlewares

log = logging.getLogger('python.cloud.appServer')


def init_app_manager():
    # log.info('开始初始化各部分组件......')
    # #  配置合并完成，开始触发执行延迟初始化事件
    # #  @ts-expect-error 未暴露方法
    # appManager.onIniting(configure)
    # log.info('组件初始化完成！')
    pass


class AppServer:
    def __init__(self):
        self._app = FastAPI()
        self._configure = get_configure()
        self._discovery_client = get_discovery()

    @property
    def app(self):
        return self._app

    def _init(self):
        middlewares.create_actuator(self._configure, self._app)
        init_app_manager()
        middlewares.create_extras(self._app)

    def start(self, launchFn: Optional[Callable[[FastAPI, int], None]] = None):
        '''
        初始化配置并启动http监听服务

        :launchFn: 由调用问自主选择FastAPI的宿主实现和启动方式，传递的两个参数分别为FastAPI实例和从配置文件读取到的监听端口
        '''
        # 启动eureka(当前应用不会注册到注册中心)
        self._discovery_client.start()
        #  通过注册中心找到配置服务，加载远程配置
        self._discovery_client.load_config()
        self._configure.merge()
        #  初始化本地模块
        self._init()
        #  根据需要把当前应用注册到服务中心
        self._discovery_client.register()

        #  启动网站
        info = self._configure.get_app_info()
        port: Optional[int] = info['port']
        assert isinstance(port, int)
        if launchFn is not None:
            return launchFn(self._app, port)

        import uvicorn
        uvicorn.run(self._app, host="0.0.0.0", port=port, access_log=False)
        if log.isEnabledFor(logging.INFO):
            log.info("应用程序在端口 %s 启动完成." % port)

    def stop(self):
        self._discovery_client.unregister()
