from setuptools import setup, find_packages

setup(
    name="mctech_cloud",
    version="1.1.1",
    packages=find_packages(
        include=["mctech_cloud**"],
        exclude=["*.tests"]
    ),
    install_requires=["log4py", "fastapi", "starlette",
                      "mctech-actuator", "mctech-discovery"]
)
