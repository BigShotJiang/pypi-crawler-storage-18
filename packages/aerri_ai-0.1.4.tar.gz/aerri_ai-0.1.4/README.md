# 🚀 Aerri-AI

[![PyPI version](https://badge.fury.io/py/aerri-ai.svg)](https://badge.fury.io/py/aerri-ai)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**The most advanced AI coding assistant for your terminal** 🤖✨

Aerri-AI transforms your development workflow with intelligent file operations, code execution, and AI-powered assistance. Built with LangChain and powered by Groq's lightning-fast LLMs.

## ✨ Key Features

- 🔍 **Smart File Operations** - Read, write, edit, and delete files with AI assistance
- 🏃‍♂️ **Code Execution** - Run Python scripts and get instant feedback
- 🧠 **Workspace Memory** - Remembers your project context across sessions
- 🎯 **Error Fixing** - Automatically detect and fix code issues
- 🎨 **Beautiful CLI** - Animated interface with colorful output
- ⚡ **Lightning Fast** - Powered by Groq's high-performance LLMs

## 🚀 Quick Start

### Installation

```bash
pip install aerri-ai
```



### Usage

```bash
aerri-ai "Create a Python script that calculates fibonacci numbers"
```

## 💡 Examples

### File Operations
```bash
# Create a new file
aerri-ai "Create a FastAPI app with user authentication"

# Read and analyze existing code
aerri-ai "Explain what this main.py file does"

# Fix bugs automatically
aerri-ai "Fix the syntax errors in my Python script"
```

### Code Execution
```bash
# Run and debug code
aerri-ai "Run my script and fix any runtime errors"

# Test functionality
aerri-ai "Execute test.py and explain the results"
```

### Project Management
```bash
# List project files
aerri-ai "Show me all Python files in this directory"

# Get project overview
aerri-ai "Analyze my project structure and suggest improvements"
```

## 🛠️ Core Capabilities

| Feature | Description |
|---------|-------------|
| **File Reading** | Intelligent content analysis and explanation |
| **File Writing** | AI-assisted code generation and editing |
| **Code Execution** | Safe Python script execution with error handling |
| **File Management** | Smart file operations with safety checks |
| **Memory System** | Persistent workspace context and history |
| **Error Detection** | Automatic bug identification and fixing |

## 🎯 Use Cases

- **Rapid Prototyping** - Generate working code from natural language
- **Code Review** - Analyze and improve existing codebases
- **Bug Fixing** - Automatically detect and resolve issues
- **Learning** - Understand complex code through AI explanations
- **Automation** - Streamline repetitive development tasks

## 🔧 Configuration

Aerri-AI works out of the box but can be customized:

```bash
# Use different models (when available)
export GROQ_MODEL="llama-3.1-70b-versatile"

# Set custom workspace directory
export AERRI_WORKSPACE="/path/to/your/project"
```

## 📚 Advanced Usage

### Batch Operations
```bash
aerri-ai "Create a complete REST API with models, routes, and tests"
```

### Code Analysis
```bash
aerri-ai "Review my code for security vulnerabilities and performance issues"
```

### Documentation Generation
```bash
aerri-ai "Generate comprehensive documentation for my Python package"
```

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.




---

**Made with ❤️ for developers who love AI-powered productivity**
