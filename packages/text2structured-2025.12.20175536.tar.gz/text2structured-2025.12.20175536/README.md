# text2structured

Transform unstructured text inputs into structured, actionable insights using advanced language models.

## Overview

This package is designed to leverage the capabilities of langchain's messages to transform text inputs into structured, actionable insights. It uses the ChatLLM7 model from langchain_llm7 by default, but allows users to pass their own langchain llm instance for custom LLM usage.

## Installation

```bash
pip install text2structured
```

## Usage

```python
from text2structured import text2structured

user_input = "How Hurricanes Became a Hot Investment"
response = text2structured(user_input)
```

### Parameters

* `user_input`: the user input text to process (`str`)
* `llm`: the langchain llm instance to use, if not provided the default ChatLLM7 will be used (`Optional[BaseChatModel]`)
* `api_key`: the api key for llm7, if not provided the default rate limits for LLM7 free tier will be used (`Optional[str]`)

### Custom LLM usage

You can safely pass your own langchain llm instance to use a custom LLM. For example to use the openai model:
```python
from langchain_openai import ChatOpenAI
from text2structured import text2structured

llm = ChatOpenAI()
response = text2structured(user_input, llm=llm)
```

Similarly you can use anthropic or google models with their respective packages:
```python
# with anthropic model
from langchain_anthropic import ChatAnthropic
from text2structured import text2structured

llm = ChatAnthropic()
response = text2structured(user_input, llm=llm)

# with google model
from langchain_google_genai import ChatGoogleGenerativeAI
from text2structured import text2structured

llm = ChatGoogleGenerativeAI()
response = text2structured(user_input, llm=llm)
```

## Default rate limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you need higher rate limits you can get a free api key by registering at [https://token.llm7.io/](https://token.llm7.io/). You can pass your api key via environment variable `LLM7_API_KEY` or directly to the `text2structured` function:
```python
text2structured(user_input, api_key="your_api_key")
```

## Documentation

For more information about the(ChatLLM7) model and its API, please refer to the [langchain_llm7 documentation](https://docs.langchain.ai/docs/guide/chat-llm7) and the [langchain](https://docs.langchain.ai) documentation.

## GitHub Issues

Open issues on [GitHub](https://github.com/chigwell/text2structured/issues).

## Author

Eugene Evstafev (`hi@eugene.plus`).

## Social media

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-5a4881246)

## License

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

[![PyPI version](https://badge.fury.io/py/text2structured.svg)](https://badge.fury.io/py/text2structured)
[![Downloads](https://img.shields.io/pypi/dm/text2structured.svg)](https://pypi.org/project/text2structured/)