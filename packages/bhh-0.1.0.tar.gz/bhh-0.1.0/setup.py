from setuptools import setup, find_packages

setup(
    name="bhh",
    version="0.1.0",
    packages=find_packages(),
    description="BHH",
    author="Aria",
    author_email="aria.karami94713@gmail.com",
)
