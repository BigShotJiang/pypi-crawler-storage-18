"""
Focus Manager - Language-Agnostic Code Focus Management

A productivity tool for managing focus areas, sessions, and bookmarks across any codebase.
"""

__version__ = "1.0.0"

from .manager import FocusManager, FocusArea, Session, Bookmark
from .discover import FocusAreaDiscovery, DiscoveryConfig

__all__ = [
    "FocusManager",
    "FocusArea",
    "Session",
    "Bookmark",
    "FocusAreaDiscovery",
    "DiscoveryConfig",
]
