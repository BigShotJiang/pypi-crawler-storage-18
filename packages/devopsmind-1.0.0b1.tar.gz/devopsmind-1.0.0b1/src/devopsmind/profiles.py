import json
import hashlib
from pathlib import Path

from .constants import DATA_DIR
from .progress import load_state, save_state
from .snapshot import snapshot_exists, restore_snapshot

PROFILES_DIR = DATA_DIR / "profiles"
ACTIVE_PROFILE_FILE = DATA_DIR / "active_profile"


# -------------------------------------------------
# 🔐 Email hashing (LOCKED)
# -------------------------------------------------

def hash_email(email: str) -> str:
    return hashlib.sha256(email.strip().lower().encode()).hexdigest()


# -------------------------------------------------
# Helpers (PUBLIC — DO NOT REMOVE)
# -------------------------------------------------

def _profile_path(username: str) -> Path:
    return PROFILES_DIR / f"{username}.json"


def get_active_username():
    if ACTIVE_PROFILE_FILE.exists():
        return ACTIVE_PROFILE_FILE.read_text().strip() or None
    return None


def set_active_username(username: str):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_PROFILE_FILE.write_text(username)


def _infer_profile_from_state():
    state = load_state()
    profile = state.get("profile")
    return profile if isinstance(profile, dict) else None


def _infer_single_local_profile():
    if not PROFILES_DIR.exists():
        return None
    profiles = list(PROFILES_DIR.glob("*.json"))
    if len(profiles) == 1:
        return profiles[0].stem
    return None


def _ensure_restore_decision(state: dict, email_hash: str) -> bool:
    decisions = state.setdefault("restore_decision", {})

    if email_hash in decisions:
        return decisions[email_hash]

    choice = input(
        "⚠️ Existing progress found for this account.\n"
        "Restore cloud progress now? [Y/n]: "
    ).strip().lower()

    decision = choice in ("", "y", "yes")
    decisions[email_hash] = decision
    save_state(state)

    if decision:
        restore_snapshot(email_hash)

    return decision


# -------------------------------------------------
# Profile CRUD (PUBLIC — DO NOT REMOVE)
# -------------------------------------------------

def create_profile(username: str, gamer: str, email: str):
    email_hash = hash_email(email)

    PROFILES_DIR.mkdir(parents=True, exist_ok=True)

    profile = {
        "username": username,
        "gamer": gamer,
        "email_hash": email_hash,
        "user_id": username,
    }

    _profile_path(username).write_text(json.dumps(profile, indent=2))
    set_active_username(username)

    state = load_state()
    state.setdefault("profile", {}).update(profile)
    save_state(state)

    if snapshot_exists(email_hash):
        restored = _ensure_restore_decision(state, email_hash)
        return (
            "✔ Profile created. Progress restored."
            if restored
            else "✔ Profile created. Progress not restored."
        )

    return f"✅ Profile '{username}' created."


def login_profile(username: str):
    path = _profile_path(username)
    if not path.exists():
        return f"❌ Profile '{username}' does not exist."

    profile = json.loads(path.read_text())
    set_active_username(username)

    state = load_state()
    state.setdefault("profile", {}).update(profile)
    save_state(state)

    email_hash = profile.get("email_hash")

    if email_hash and snapshot_exists(email_hash):
        restored = _ensure_restore_decision(state, email_hash)
        return (
            f"🔐 Logged in as '{username}'. Progress restored."
            if restored
            else f"🔐 Logged in as '{username}'. Progress not restored."
        )

    return f"🔐 Logged in as '{username}'."


def show_profile():
    username = get_active_username()
    profile = None

    if username:
        path = _profile_path(username)
        if path.exists():
            profile = json.loads(path.read_text())

    if not profile:
        profile = _infer_profile_from_state()

    if not profile:
        return "❌ Active profile not found."

    return "\n".join(
        [
            f"👤 Username: {profile.get('username')}",
            f"🎮 Gamer: {profile.get('gamer')}",
            f"🆔 User ID: {profile.get('user_id')}",
        ]
    )


def list_profiles():
    if PROFILES_DIR.exists():
        names = sorted(p.stem for p in PROFILES_DIR.glob("*.json"))
        if names:
            active = get_active_username() or _infer_single_local_profile()
            return "\n".join(
                ("👉 " if n == active else "   ") + n for n in names
            )

    profile = _infer_profile_from_state()
    if profile:
        return f"👉 {profile.get('username')}"

    return "No profiles found."
