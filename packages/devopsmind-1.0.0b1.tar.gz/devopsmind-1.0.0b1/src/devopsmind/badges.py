from .progress import load_state

# -------------------------------------------------
# EXISTING FUNCTIONS (UNCHANGED)
# -------------------------------------------------

def show_badges():
    state = load_state()
    badges = state.get("badges", [])
    if not badges:
        return "No badges earned yet."
    return "\n".join(f"🏅 {b}" for b in badges)


# -------------------------------------------------
# NEW: Delta badge helper (NO HARD-CODED RULES)
# -------------------------------------------------

def evaluate_badges_delta(trigger_fn, *args, **kwargs):
    """
    Generic wrapper to compute newly earned badges (delta).

    - DOES NOT contain badge rules
    - DOES NOT decide eligibility
    - Delegates to existing badge logic
    """

    state_before = load_state()
    before = set(state_before.get("badges", []))

    # 🔒 Run existing badge logic (unchanged)
    trigger_fn(*args, **kwargs)

    state_after = load_state()
    after = set(state_after.get("badges", []))

    return sorted(after - before)
