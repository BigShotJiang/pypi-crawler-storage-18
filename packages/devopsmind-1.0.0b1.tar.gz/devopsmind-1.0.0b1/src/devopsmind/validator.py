from pathlib import Path
import importlib.util
import os

from .progress import record_completion, load_state, save_state
from .sync import attempt_sync
from devopsmind.achievements import show_badges
from .hint import show_hint
from .challenge_resolver import find_challenge_by_id


WORKSPACE_DIR = Path.home() / "workspace"
PLAY_MARKER = ".devopsmind_played"
FAIL_LIMIT = 3


# -------------------------------------------------
# Helpers
# -------------------------------------------------

def _workspace(challenge_id: str) -> Path:
    return WORKSPACE_DIR / challenge_id


def _cwd_matches_workspace(challenge_id: str) -> bool:
    try:
        return Path.cwd().resolve() == _workspace(challenge_id).resolve()
    except Exception:
        return False


def _was_played(challenge_id: str) -> bool:
    return (_workspace(challenge_id) / PLAY_MARKER).exists()


def _increment_fail(challenge_id: str) -> int:
    state = load_state()
    failures = state.setdefault("validation_failures", {})

    current = failures.get(challenge_id, 0)
    current += 1
    failures[challenge_id] = current

    save_state(state)
    return current


def _reset_fail(challenge_id: str):
    state = load_state()
    failures = state.get("validation_failures", {})
    if challenge_id in failures:
        del failures[challenge_id]
        save_state(state)


def _run_challenge_validator(challenge_id: str):
    ws = _workspace(challenge_id)
    challenge_dir = find_challenge_by_id(challenge_id)

    if not challenge_dir:
        return False, "Challenge source not found."

    validator_file = challenge_dir / "validator.py"
    if not validator_file.exists():
        return False, "Challenge validator not found."

    try:
        spec = importlib.util.spec_from_file_location(
            f"validator_{challenge_id}", validator_file
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if not hasattr(module, "validate"):
            return False, "Validator must define validate()"

        cwd = os.getcwd()
        try:
            os.chdir(ws)
            result = module.validate()
        finally:
            os.chdir(cwd)

        if not isinstance(result, tuple) or len(result) != 2:
            return False, "Validator must return (bool, message)"

        return bool(result[0]), str(result[1])

    except Exception as e:
        return False, f"Validator error: {e}"


# -------------------------------------------------
# Validator (CORE)
# -------------------------------------------------

def validate_only(
    challenge_id,
    stack=None,
    difficulty=None,
    skills=None,
    xp=None,
):
    ws = _workspace(challenge_id)

    if not ws.exists():
        return {"error": "Workspace not found.\nRun: devopsmind play <challenge_id>"}

    if not _was_played(challenge_id):
        return {"error": "Challenge not started.\nRun: devopsmind play <challenge_id>"}

    if not _cwd_matches_workspace(challenge_id):
        return {"error": f"Validation must be run from the challenge workspace.\ncd {ws}"}

    success, message = _run_challenge_validator(challenge_id)

    # -----------------------------
    # FAILURE PATH
    # -----------------------------
    if not success:
        attempts = _increment_fail(challenge_id)

        auto_hint = None
        if attempts >= FAIL_LIMIT:
            auto_hint = show_hint(challenge_id)

        return {
            "error": message,
            "attempts": attempts,
            "fail_limit": FAIL_LIMIT,   # ✅ ADDED
            "auto_hint": auto_hint,
        }

    # -----------------------------
    # SUCCESS PATH
    # -----------------------------
    _reset_fail(challenge_id)

    record_completion(
        challenge_id=challenge_id,
        stack=stack,
        difficulty=difficulty,
    )

    achievement_banner = show_badges()

    raw_sync = attempt_sync()
    sync_status = raw_sync

    if isinstance(raw_sync, dict) and raw_sync.get("already") is True:
        sync_status = {
            "info": "No changes to sync. Progress already up to date."
        }

    return {
        "challenge_id": challenge_id,
        "stack": stack,
        "difficulty": difficulty,
        "skills": skills or [],
        "xp_awarded": xp,
        "message": message,
        "achievement_banner": achievement_banner,
        "sync_status": sync_status,
    }
