from ...bm02.xrpd_processor import Bm02XrpdProcessor
from ...bm08.converter import Bm08Hdf5ToXdiConverter
from ...bm23.exafs_processor import Bm23ExafsProcessor
from ...exafs.processor import ExafsProcessor
from ...id11.xrpd_processor import Id11XrpdProcessor
from ...id12.converter import Id12Hdf5ToAsciiConverter
from ...id14.converter import Id14Hdf5ToSpecConverter
from ...id22.xrpd_processor import Id22XrpdProcessor
from ...id31.streamline_scanner import Id31StreamlineScanner
from ...id31.xrpd_processor import Id31XrpdProcessor
from ...id32.processor import Id32SpecGenProcessor
from ...streamline.scanner import StreamlineScanner
from ...wrappers.ewoks_macros import EwoksMacroHandler
from ...xrpd.processor import XrpdProcessor


def all_print():
    _print_objects(XrpdProcessor)
    _print_objects(ExafsProcessor)
    _print_objects(StreamlineScanner)
    _print_objects(Bm23ExafsProcessor)
    _print_objects(Bm02XrpdProcessor)
    _print_objects(Id11XrpdProcessor)
    _print_objects(Id22XrpdProcessor)
    _print_objects(Id31XrpdProcessor)
    _print_objects(Id14Hdf5ToSpecConverter)
    _print_objects(Id12Hdf5ToAsciiConverter)
    _print_objects(Id31StreamlineScanner)
    _print_objects(Id32SpecGenProcessor)
    _print_objects(EwoksMacroHandler)
    _print_objects(Bm08Hdf5ToXdiConverter)


def _print_objects(processor_cls):
    print()
    print("===================")
    obj = processor_cls()
    print(obj._parameters.name)
    print(obj.__info__())
