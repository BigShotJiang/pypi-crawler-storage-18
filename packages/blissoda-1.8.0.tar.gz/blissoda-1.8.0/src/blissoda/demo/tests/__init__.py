"""Integration tests."""

from . import confitest  # noqa F401 No auto-import like pytest
