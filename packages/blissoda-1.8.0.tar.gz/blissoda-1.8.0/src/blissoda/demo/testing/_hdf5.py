import pathlib
from typing import Tuple

import h5py
from silx.io.h5py_utils import retry
from silx.utils.retry import RetryError

from ._assert import demo_assert


@demo_assert("HDF5 group {data_path} in {file_path}")
@retry(retry_timeout=10, retry_period=0.2)
def assert_hdf5_group_exists(file_path: pathlib.Path, data_path: str) -> None:
    if not file_path.exists():
        raise RetryError(f"{str(file_path)!r} does not exist")
    file_path = str(file_path)
    with h5py.File(file_path, mode="r") as root:
        if data_path not in root:
            raise RetryError(f"{data_path!r} not in {file_path!r}")


@demo_assert("HDF5 dataset {data_path} in {file_path} with shape {expected_shape}")
@retry(retry_timeout=10, retry_period=0.2)
def assert_hdf5_dataset_exists(
    file_path: pathlib.Path,
    data_path: str,
    expected_shape: Tuple[int, ...],
) -> None:
    if not file_path.exists():
        raise RetryError(f"{str(file_path)!r} does not exist")
    file_path = str(file_path)
    with h5py.File(file_path, mode="r") as root:
        if data_path not in root:
            raise RetryError(f"{data_path!r} not in {file_path!r}")

        dset = root[data_path]
        if dset.shape != expected_shape:
            url = f"{file_path!r}::{data_path}"
            raise RetryError(
                f"Shape of {url!r} is {dset.shape} instead of {expected_shape}"
            )
