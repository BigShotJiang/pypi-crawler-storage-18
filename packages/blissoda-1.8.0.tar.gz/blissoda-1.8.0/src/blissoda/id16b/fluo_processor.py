from typing import Any
from typing import Dict
from typing import Optional

from ..fluo.processor import FluoProcessor
from ..processor import BlissScanType


class Id16bFluoProcessor(FluoProcessor):

    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        defaults: Optional[Dict[str, Any]] = None,
    ) -> None:
        if defaults is None:
            defaults = dict()
        defaults.setdefault("instrument_name", "id16b")
        defaults.setdefault("output_suffix", "_xrf")
        super().__init__(config=config, defaults=defaults)

    def _is_xrfmap(self, scan: BlissScanType) -> bool:
        return scan.scan_info["type"] == "fscan2d"

    def _is_fluoxas(self, scan: BlissScanType) -> bool:
        return False

    def _is_mosaic_xrfmap(self, scan: BlissScanType) -> bool:
        return False
