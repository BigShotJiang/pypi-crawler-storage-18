"""Tests for COS CLI"""
