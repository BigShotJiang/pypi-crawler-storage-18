# COS Data Manager - Visual Mockups (ASCII)

## Complete UI Flow and Layouts

This document provides ASCII-based visual mockups of all pages and interactions.

---

## 1. Home Dashboard (Landing Page)

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ SIDEBAR              │ MAIN CONTENT                                       ║
╠═══════════════════════════════════════════════════════════════════════════╣
║ ┌─────────────────┐ │ 🚀 COS Data Manager                                ║
║ │ 🗂️ COS Manager  │ │ Modern interface for Tencent Cloud Object Storage ║
║ │ Tencent Cloud   │ │                                                     ║
║ │                 │ │ ┌────────────────────────────────────────────────┐ ║
║ ├─────────────────┤ │ │ SYSTEM OVERVIEW                                │ ║
║ │ 📋 Navigation   │ │ ├────────┬───────────┬───────────┬──────────────┤ ║
║ │                 │ │ │ 🟢 COS │ 📁 Active │ 📤 Recent │ ⏱️ Session   │ ║
║ │ 🏠 Home ←       │ │ │ Status │  Bucket   │  Uploads  │   Time       │ ║
║ │ 🗂️ Files        │ │ │        │           │           │              │ ║
║ │ 🪣 Buckets      │ │ │ Connec-│ my-bucket │    5      │   15 min     │ ║
║ │ 📤 Transfers    │ │ │  ted   │           │           │              │ ║
║ │                 │ │ └────────┴───────────┴───────────┴──────────────┘ ║
║ ├─────────────────┤ │                                                     ║
║ │ ⚙️ Settings     │ │ QUICK ACTIONS                                      ║
║ │                 │ │ ┌──────────────┬──────────────┬─────────────────┐ ║
║ │ 🔧 Configure    │ │ │ 🗂️ Files     │ 🪣 Buckets   │ 📤 Transfers    │ ║
║ │                 │ │ │              │              │                 │ ║
║ ├─────────────────┤ │ │ [Browse]     │ [List All]   │ [Batch Upload]  │ ║
║ │ 💡 Quick Tips   │ │ │ [Upload]     │ [Create New] │ [Sync Folders]  │ ║
║ │ • Navigate from │ │ │ [Download]   │ [Configure]  │ [Track Progress]│ ║
║ │   sidebar       │ │ │              │              │                 │ ║
║ │ • Drag & drop   │ │ └──────────────┴──────────────┴─────────────────┘ ║
║ │   uploads       │ │                                                     ║
║ │ • Search files  │ │ RECENT ACTIVITY                                    ║
║ │                 │ │ ┌──────────────────────────────────────────────┐  ║
║ └─────────────────┘ │ │ [Recent Uploads] [Recent Downloads]          │  ║
║                      │ │                                              │  ║
║                      │ │ • data.csv → my-bucket/uploads/ (2m ago)    │  ║
║                      │ │ • model.pkl → my-bucket/models/ (5m ago)    │  ║
║                      │ │ • config.json → my-bucket/config/ (12m ago) │  ║
║                      │ │                                              │  ║
║                      │ └──────────────────────────────────────────────┘  ║
║                      │                                                     ║
║                      │ STORAGE STATISTICS                                 ║
║                      │ ┌──────────────────────────────────────────────┐  ║
║                      │ │ 📊 Usage by Type                             │  ║
║                      │ │ ████████ Data (45 GB)                        │  ║
║                      │ │ ██████ Archives (30 GB)                      │  ║
║                      │ │ ████ Code (20 GB)                            │  ║
║                      │ └──────────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 2. File Manager Page (Primary Workspace)

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ SIDEBAR              │ MAIN CONTENT                                       ║
╠═══════════════════════════════════════════════════════════════════════════╣
║ ┌─────────────────┐ │ 🗂️ File Manager                                    ║
║ │ 🗂️ COS Manager  │ │ Browse, upload, and download files                ║
║ │                 │ │                                                     ║
║ │ 📋 Navigation   │ │ ┌──────────────────────────────────────────────┐  ║
║ │                 │ │ │ 📍 CURRENT LOCATION                          │  ║
║ │ 🏠 Home         │ │ │ 🪣 Bucket: [my-bucket ▼]                     │  ║
║ │ 🗂️ Files ←      │ │ │ 📂 Prefix: [data/experiments/]               │  ║
║ │ 🪣 Buckets      │ │ │                                              │  ║
║ │ 📤 Transfers    │ │ │ 📍 cos://my-bucket/data/experiments/         │  ║
║ │                 │ │ └──────────────────────────────────────────────┘  ║
║ │ ⚙️ Settings     │ │                                                     ║
║ │                 │ │ [🔍 Browse] [📤 Upload] [🔄 Refresh] [⚙️]          ║
║ └─────────────────┘ │                                                     ║
║                      │ ┌──────────────┬───────────────────────────────┐  ║
║                      │ │ 📁 FOLDERS   │ 📄 FILES                      │  ║
║                      │ │              │                               │  ║
║                      │ │ ▼ data/      │ [🔍 Search...] [Type ▼] [📅] │  ║
║                      │ │  ▼ exp001/   │                               │  ║
║                      │ │   • raw/     │ ┌───────────────────────────┐ │  ║
║                      │ │   • proc/    │ │ ☑️  Name       Size   Date │ │  ║
║                      │ │  • exp002/   │ ├───────────────────────────┤ │  ║
║                      │ │  • exp003/   │ │ ☑️ 📊 data1.csv  2.4MB 2h │ │  ║
║                      │ │              │ │ ☐ 📝 log.txt   120KB  5h  │ │  ║
║                      │ │ • models/    │ │ ☐ 🧠 model.pkl 45MB  1d  │ │  ║
║                      │ │              │ │ ☐ ⚙️ config.json 8KB 3h  │ │  ║
║                      │ │ • archives/  │ │ ☐ 🖼️ plot.png  890KB 2d  │ │  ║
║                      │ │              │ │                           │ │  ║
║                      │ │              │ │ [← Prev] Page 1/5 [Next→] │ │  ║
║                      │ │              │ └───────────────────────────┘ │  ║
║                      │ │              │ [📥 Download] [🗑️ Delete]     │  ║
║                      │ └──────────────┴───────────────────────────────┘  ║
║                      │                                                     ║
║                      │ ┌──────────────────────────────────────────────┐  ║
║                      │ │ 📄 SELECTED: data1.csv                       │  ║
║                      │ │ Size: 2.4 MB | Modified: 2h ago             │  ║
║                      │ │ ETag: "abc123..." | Type: CSV                │  ║
║                      │ │                                              │  ║
║                      │ │ [📥 Download] [🔗 Get URL] [🗑️ Delete]       │  ║
║                      │ └──────────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 3. Upload Panel (Expanded State)

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ 📤 UPLOAD FILES                                                            ║
╠═══════════════════════════════════════════════════════════════════════════╣
║ Uploading to: cos://my-bucket/data/experiments/                           ║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │                                                                        │║
║ │               📤 Drag & Drop Files Here                                │║
║ │                  or click to browse                                    │║
║ │                                                                        │║
║ └────────────────────────────────────────────────────────────────────────┘║
║                                                                            ║
║ ┌──────────────────────────────────────────────────────────────────────┐ ║
║ │ FILES READY TO UPLOAD (3 files, 47.6 MB)                            │ ║
║ ├──────────────────────────────────────────────────────────────────────┤ ║
║ │ 📊 data.csv                    2.4 MB                                │ ║
║ │ 🧠 model.pkl                   45.0 MB                               │ ║
║ │ ⚙️ config.json                  8 KB                                 │ ║
║ └──────────────────────────────────────────────────────────────────────┘ ║
║                                                                            ║
║ ┌──────────────────┬───────────────────────────────────────────────────┐ ║
║ │ Subfolder:       │ If file exists:                                   │ ║
║ │ [experiment_001] │ [Overwrite ▼] [Skip] [Add timestamp]             │ ║
║ └──────────────────┴───────────────────────────────────────────────────┘ ║
║                                                                            ║
║                      [🚀 Upload Now]  [Cancel]                            ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 4. Upload Progress

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ UPLOADING FILES                                                            ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║ ████████████████████░░░░░░░░ 65% (2/3 files)                              ║
║                                                                            ║
║ Current: uploading model.pkl                                              ║
║ Speed: 12.5 MB/s | ETA: 2m 15s                                            ║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ UPLOAD STATUS                                                          │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ ✅ data.csv          2.4 MB    Completed                               │║
║ │ ⏳ model.pkl         45.0 MB   65% (29 MB / 45 MB)                     │║
║ │ ⏸️ config.json       8 KB      Waiting...                              │║
║ └────────────────────────────────────────────────────────────────────────┘║
║                                                                            ║
║                           [⏸️ Pause] [❌ Cancel]                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 5. Bucket Management Page

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ 🪣 Bucket Management                                                       ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║ [➕ Create New Bucket] [🔄 Refresh]                                        ║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ 🪣 Name            │ 🌍 Region      │ 📊 Size  │ 📅 Created           │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ my-data-bucket    │ ap-shanghai   │ 2.3 GB  │ 2024-01-15           │║
║ │ [📂 Browse] [⚙️ Configure] [🗑️ Delete]                                 │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ backup-bucket     │ ap-beijing    │ 45 GB   │ 2023-12-01           │║
║ │ [📂 Browse] [⚙️ Configure] [🗑️ Delete]                                 │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ test-bucket       │ ap-shanghai   │ 120 MB  │ 2024-11-20           │║
║ │ [📂 Browse] [⚙️ Configure] [🗑️ Delete]                                 │║
║ └────────────────────────────────────────────────────────────────────────┘║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ 📊 BUCKET DETAILS: my-data-bucket                                      │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ • Region: ap-shanghai                                                  │║
║ │ • ACL: Private                                                         │║
║ │ • Versioning: Enabled                                                  │║
║ │ • Encryption: Disabled                                                 │║
║ │ • Lifecycle Rules: 2 active                                            │║
║ │ • CORS: Configured                                                     │║
║ │ • Total Objects: 1,247                                                 │║
║ │ • Total Size: 2.3 GB                                                   │║
║ │                                                                         │║
║ │ [📂 Browse Files] [⚙️ Configure] [📊 Analytics] [🗑️ Delete Bucket]    │║
║ └────────────────────────────────────────────────────────────────────────┘║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 6. Batch Transfers Page

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ 📤 Batch Transfers                                                         ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║ [📤 Upload] [📥 Download] [🔄 Sync] ← Tabs                                ║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ 📤 BATCH UPLOAD                                                        │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ SOURCE                                                                 │║
║ │ 📁 Local Directory: /home/user/data/experiments/                      │║
║ │ [📁 Select Directory...]                                               │║
║ │                                                                         │║
║ │ DESTINATION                                                             │║
║ │ 🪣 Bucket: [my-bucket ▼]                                               │║
║ │ 📂 Prefix: uploads/batch_001/                                          │║
║ │                                                                         │║
║ │ OPTIONS                                                                 │║
║ │ ☑️ Include subdirectories                                              │║
║ │ ☑️ Skip existing files                                                 │║
║ │ ☐ Preserve file metadata                                               │║
║ │ ☐ Compress before upload                                               │║
║ │                                                                         │║
║ │ ┌──────────────────────────────────────────────────────────────────┐  │║
║ │ │ FILES TO UPLOAD                                                  │  │║
║ │ │ Total: 47 files | Size: 230 MB                                   │  │║
║ │ │                                                                  │  │║
║ │ │ data/exp_001/*.csv (12 files, 28 MB)                            │  │║
║ │ │ data/exp_002/*.csv (15 files, 35 MB)                            │  │║
║ │ │ models/*.pkl (5 files, 150 MB)                                  │  │║
║ │ │ configs/*.json (15 files, 17 MB)                                │  │║
║ │ └──────────────────────────────────────────────────────────────────┘  │║
║ │                                                                         │║
║ │                        [🚀 Start Upload]                               │║
║ │                                                                         │║
║ │ ┌──────────────────────────────────────────────────────────────────┐  │║
║ │ │ PROGRESS                                                         │  │║
║ │ │ ████████████░░░░░░░░ 65% (30/47 files)                          │  │║
║ │ │ Current: uploading exp_002_data.csv                             │  │║
║ │ │ Speed: 12.5 MB/s | ETA: 2m 15s                                  │  │║
║ │ │                                                                  │  │║
║ │ │ ✅ Completed: 30 files (150 MB)                                  │  │║
║ │ │ ⏳ In Progress: 1 file (2.4 MB)                                  │  │║
║ │ │ ⏸️ Waiting: 16 files (77.6 MB)                                   │  │║
║ │ └──────────────────────────────────────────────────────────────────┘  │║
║ └────────────────────────────────────────────────────────────────────────┘║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 7. Settings/Configuration Page

```
╔═══════════════════════════════════════════════════════════════════════════╗
║ ⚙️ Settings                                                                 ║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║ [🔐 Credentials] [👤 Profiles] [⚙️ Preferences] ← Tabs                     ║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ 🔐 CREDENTIALS                                                         │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ Profile: [default ▼]                                                   │║
║ │                                                                         │║
║ │ Secret ID:      [****************************]                         │║
║ │ Secret Key:     [****************************]                         │║
║ │ Region:         [ap-shanghai ▼]                                        │║
║ │ Default Bucket: [my-bucket]                                            │║
║ │                                                                         │║
║ │ [🧪 Test Connection] [💾 Save]                                         │║
║ │                                                                         │║
║ │ Status: 🟢 Connected (Last checked: 2 mins ago)                        │║
║ │                                                                         │║
║ │ ▼ ADVANCED OPTIONS                                                     │║
║ │ ┌──────────────────────────────────────────────────────────────────┐  │║
║ │ │ STS Token (Optional):                                            │  │║
║ │ │ [____________________________]                                   │  │║
║ │ │                                                                  │  │║
║ │ │ Assume Role ARN (Optional):                                      │  │║
║ │ │ [____________________________]                                   │  │║
║ │ │                                                                  │  │║
║ │ │ Endpoint URL (Optional):                                         │  │║
║ │ │ [https://cos.ap-shanghai.myqcloud.com]                          │  │║
║ │ │                                                                  │  │║
║ │ │ ☐ Disable SSL Verification (not recommended)                    │  │║
║ │ └──────────────────────────────────────────────────────────────────┘  │║
║ └────────────────────────────────────────────────────────────────────────┘║
║                                                                            ║
║ ┌────────────────────────────────────────────────────────────────────────┐║
║ │ ⚙️ UI PREFERENCES                                                       │║
║ ├────────────────────────────────────────────────────────────────────────┤║
║ │ Page Size:          [50 ▼] files per page                             │║
║ │ Date Format:        [Relative ▼] (2h ago vs 2024-12-15 10:30)         │║
║ │ File Size Format:   [Auto ▼] (KB, MB, GB)                             │║
║ │ Theme:              [Light ▼] [Dark] [Auto]                           │║
║ │ Default View:       [List ▼] [Grid]                                   │║
║ │                                                                         │║
║ │ [💾 Save Preferences]                                                  │║
║ └────────────────────────────────────────────────────────────────────────┘║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## 8. Empty States

### No Files
```
┌──────────────────────────┐
│                          │
│         📭               │
│                          │
│    No files found        │
│                          │
│ This folder is empty.    │
│ Upload files to get      │
│      started!            │
│                          │
│    [📤 Upload Files]     │
│                          │
└──────────────────────────┘
```

### Connection Error
```
┌──────────────────────────┐
│                          │
│         🔴               │
│                          │
│  Connection Failed       │
│                          │
│ Unable to connect to COS │
│ Please check credentials │
│                          │
│    [⚙️ Configure]        │
│    [🔄 Retry]            │
│                          │
└──────────────────────────┘
```

### Loading
```
┌──────────────────────────┐
│                          │
│         ⏳               │
│                          │
│    Loading files...      │
│                          │
│    ⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏        │
│                          │
└──────────────────────────┘
```

---

## 9. Mobile/Responsive Layout

### Mobile View (< 640px)
```
╔══════════════════════════╗
║ 🗂️ COS Manager  [☰]     ║
╠══════════════════════════╣
║ 📍 my-bucket             ║
║ data/experiments/        ║
║                          ║
║ [🔍] [📤] [🔄]           ║
║                          ║
║ ┌────────────────────┐  ║
║ │ 📄 FILES           │  ║
║ ├────────────────────┤  ║
║ │ 📊 data1.csv       │  ║
║ │ 2.4 MB | 2h ago    │  ║
║ │ [⬇️] [⋮]           │  ║
║ ├────────────────────┤  ║
║ │ 📝 log.txt         │  ║
║ │ 120 KB | 5h ago    │  ║
║ │ [⬇️] [⋮]           │  ║
║ └────────────────────┘  ║
║                          ║
║ Page 1 / 5               ║
║ [←] [→]                  ║
╚══════════════════════════╝
```

---

## 10. Interaction Flows

### File Upload Flow
```
1. Click "Upload"
   ↓
2. Drag files / Click browse
   ↓
3. Files appear in preview list
   ↓
4. Optionally: Set subfolder, overwrite mode
   ↓
5. Click "Upload Now"
   ↓
6. Progress bar shows upload status
   ↓
7. Success notification
   ↓
8. File list refreshes automatically
```

### File Download Flow
```
1. Browse to file location
   ↓
2. Select file(s) via checkbox
   ↓
3. Click "Download" button
   ↓
4. For single file: Direct download
   For multiple: Create ZIP archive
   ↓
5. Progress indicator (if large)
   ↓
6. Download starts automatically
   ↓
7. Success notification
```

### Bucket Navigation Flow
```
1. Select bucket from dropdown
   ↓
2. Enter prefix/path (optional)
   ↓
3. Click "Browse"
   ↓
4. Files load in list view
   ↓
5. Click folder in tree view
   ↓
6. Navigate down hierarchy
   ↓
7. Use breadcrumbs to navigate up
```

---

## Legend

```
Symbols:
━ ┃ ┏ ┓ ┗ ┛ ┣ ┫ ┳ ┻ ╋   Box drawing (single)
═ ║ ╔ ╗ ╚ ╝ ╠ ╣ ╦ ╩ ╬   Box drawing (double)
▼ ▶ ◀ ▲                   Triangles (dropdowns, collapsible)
☑️ ☐                       Checkboxes
[Button]                  Buttons
────                      Dividers
...                       Continuation

Emojis:
🗂️ File manager
🪣 Bucket
📁 Folder
📄 File
📊 Data/CSV
📝 Text/Log
🧠 Model
⚙️ Configuration
🖼️ Image
📦 Archive
🔍 Search
📤 Upload
📥 Download
🔄 Refresh
⚡ Quick action
🟢 Success/Online
🔴 Error/Offline
⏳ Loading
✅ Complete
❌ Error
```

---

**Document Version**: 1.0  
**Last Updated**: December 18, 2025  
**Purpose**: Visual reference for UI implementation
