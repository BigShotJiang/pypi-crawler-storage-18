"""Version information for MCP Memory Service."""

__version__ = "8.58.0"
