"""
QCOS Portal Client
Self-service para clientes
"""

import httpx
from typing import Optional, List, Dict, Any
from .exceptions import AuthenticationError, ResourceNotFoundError


class PortalClient:
    """Cliente para operações do Portal (clientes)."""
    
    def __init__(self, base_url: str, token: str, timeout: int = 30):
        self.client = httpx.AsyncClient(
            base_url=f"{base_url}/portal",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
    
    async def close(self):
        await self.client.aclose()
    
    async def get_profile(self) -> Dict[str, Any]:
        """Obter perfil do cliente."""
        response = await self.client.get("/profile")
        if response.status_code == 401:
            raise AuthenticationError("Token inválido")
        response.raise_for_status()
        return response.json()
    
    async def get_licenses(self) -> List[Dict[str, Any]]:
        """Obter licenças do cliente."""
        response = await self.client.get("/licenses")
        response.raise_for_status()
        return response.json()
    
    async def get_contracts(self) -> List[Dict[str, Any]]:
        """Obter contratos do cliente."""
        response = await self.client.get("/contracts")
        response.raise_for_status()
        return response.json()
    
    async def request_tier_upgrade(
        self, target_tier: str, notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """Solicitar upgrade de tier."""
        response = await self.client.post(
            "/billing/subscriptions/request",
            json={"plan": target_tier, "customer_notes": notes}
        )
        response.raise_for_status()
        return response.json()
