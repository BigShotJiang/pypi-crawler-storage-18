"""
Portal SDK - Python Client Library
Unified SDK for QCOS/SoftQuantus services integration

Install: pip install portal-sdk
"""

__version__ = "1.0.0"

from .licensing import LicensingClient
from .admin import AdminClient
from .billing import BillingClient
from .portal import PortalClient
from .exceptions import (
    QCOSSDKError,
    AuthenticationError,
    PermissionError,
    ResourceNotFoundError,
    QuotaExceededError,
    LicenseError,
)
from .models import (
    Customer,
    Contract,
    License,
    Subscription,
    Tier,
    APIKey,
    UsageLog,
)

__all__ = [
    # Version
    "__version__",
    # Clients
    "LicensingClient",
    "AdminClient",
    "BillingClient",
    "PortalClient",
    # Exceptions
    "QCOSSDKError",
    "AuthenticationError",
    "PermissionError",
    "ResourceNotFoundError",
    "QuotaExceededError",
    "LicenseError",
    # Models
    "Customer",
    "Contract",
    "License",
    "Subscription",
    "Tier",
    "APIKey",
    "UsageLog",
]
