"""
QCOS Licensing Client
Wrapper para licensing/client.py existente
"""

import sys
import os

# Adicionar path para importar licensing module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'licensing'))

try:
    from licensing.client import LicenseClient as _LicensingClient
    from licensing.models import SignedLicense, LicenseValidationResult
    
    class LicensingClient(_LicensingClient):
        """
        Cliente para validação e geração de licenças.
        Wrapper para licensing/client.py existente.
        """
        pass
        
except ImportError:
    # Fallback se licensing module não estiver disponível
    class LicensingClient:
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "Licensing module não encontrado. "
                "Certifique-se de que o diretório 'licensing' está no PYTHONPATH"
            )
