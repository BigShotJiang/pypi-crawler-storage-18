"""
QCOS Billing Client
Gestão de subscriptions, tiers, API keys e usage tracking
"""

import httpx
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime, date
from decimal import Decimal

from .exceptions import (
    AuthenticationError,
    QuotaExceededError,
    ResourceNotFoundError,
    ValidationError,
    NetworkError,
)


class BillingClient:
    """
    Cliente para gestão de billing, subscriptions e tiers.
    
    Usado para:
    - Criar/gerenciar subscriptions (free, pro, enterprise)
    - Verificar tier do cliente
    - Registrar uso de API (tokens, API calls, storage)
    - Verificar quotas e limites
    - Gerar API keys para clientes
    
    Exemplo de uso no Chat Service:
    
        billing = BillingClient(
            base_url="https://api.softquantus.com",
            api_key=os.getenv("QCOS_SERVICE_API_KEY")
        )
        
        # Verificar se cliente pode usar o serviço
        quota = await billing.check_quota(
            api_key=customer_api_key,
            usage_type="llm_tokens"
        )
        
        if quota.exceeded:
            raise QuotaExceededError("Upgrade para Pro!")
    """
    
    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 30,
    ):
        """
        Args:
            base_url: URL base da API (ex: https://api.softquantus.com)
            api_key: SERVICE_API_KEY para chamadas service-to-service
            token: JWT token para chamadas autenticadas (admin ou customer)
            timeout: Timeout em segundos para requests HTTP
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        elif token:
            headers["Authorization"] = f"Bearer {token}"
        
        self.client = httpx.AsyncClient(
            base_url=f"{self.base_url}/portal/billing",
            headers=headers,
            timeout=timeout,
        )
    
    async def close(self):
        """Fechar conexão HTTP."""
        await self.client.aclose()
    
    # =========================================================================
    # Subscriptions (Planos/Tiers)
    # =========================================================================
    
    async def create_subscription(
        self,
        customer_id: int,
        plan: Literal["free", "pro", "enterprise"],
        auto_renew: bool = True,
        customer_notes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Criar nova subscription para cliente.
        
        Args:
            customer_id: ID do cliente
            plan: Plano (free, pro, enterprise)
            auto_renew: Renovação automática
            customer_notes: Notas do cliente
        
        Returns:
            Subscription criada (pendente aprovação se não for free)
        
        Raises:
            ValidationError: Dados inválidos
            AuthenticationError: Sem permissão
        """
        response = await self.client.post(
            "/subscriptions/request",
            json={
                "plan": plan,
                "customer_notes": customer_notes,
                "accept_terms": True,
                "terms_version": "1.0",
            }
        )
        
        if response.status_code == 401:
            raise AuthenticationError("Token inválido")
        elif response.status_code == 400:
            raise ValidationError(response.json().get("detail", "Dados inválidos"))
        
        response.raise_for_status()
        return response.json()
    
    async def get_subscription(self, subscription_id: int) -> Dict[str, Any]:
        """Obter detalhes de uma subscription."""
        response = await self.client.get(f"/subscriptions/{subscription_id}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Subscription {subscription_id} não encontrada")
        
        response.raise_for_status()
        return response.json()
    
    async def list_subscriptions(
        self,
        customer_id: Optional[int] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Listar subscriptions."""
        params = {}
        if customer_id:
            params["customer_id"] = customer_id
        if status:
            params["status"] = status
        
        response = await self.client.get("/subscriptions", params=params)
        response.raise_for_status()
        return response.json()
    
    async def cancel_subscription(
        self,
        subscription_id: int,
        reason: Optional[str] = None
    ) -> Dict[str, Any]:
        """Cancelar subscription."""
        response = await self.client.post(
            f"/subscriptions/{subscription_id}/cancel",
            json={"reason": reason}
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Tiers & Limites
    # =========================================================================
    
    async def get_customer_tier(self, customer_id: int) -> Dict[str, Any]:
        """
        Obter tier atual do cliente com limites.
        
        Returns:
            {
                "name": "pro",
                "api_limit": 50000,
                "storage_limit": 107374182400,  # 100 GB
                "features": ["priority_support", "advanced_analytics"],
                "price_monthly": 99.00
            }
        """
        subscriptions = await self.list_subscriptions(
            customer_id=customer_id,
            status="active"
        )
        
        if not subscriptions:
            # Retornar tier free por padrão
            return {
                "name": "free",
                "api_limit": 1000,
                "storage_limit": 1073741824,  # 1 GB
                "features": [],
                "price_monthly": 0.00
            }
        
        # Retornar tier da subscription ativa
        subscription = subscriptions[0]
        return subscription["plan_details"]
    
    async def get_customer_tier_by_api_key(self, api_key: str) -> Dict[str, Any]:
        """Obter tier do cliente via API key."""
        response = await self.client.get(f"/tier/by-api-key/{api_key}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError("API key não encontrada")
        
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # API Keys
    # =========================================================================
    
    async def create_api_key(
        self,
        customer_id: int,
        name: str,
        expires_at: Optional[date] = None,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Criar API key para cliente.
        
        Args:
            customer_id: ID do cliente
            name: Nome descritivo da key
            expires_at: Data de expiração (opcional)
            scopes: Permissões (ex: ["chat:read", "chat:write"])
        
        Returns:
            {
                "api_key": "qcos_sk_...",  # ⚠️ Retornado apenas uma vez!
                "key_id": "uuid",
                "name": "Chat API Key",
                "created_at": "2025-01-01T00:00:00Z"
            }
        """
        response = await self.client.post(
            "/api-keys",
            json={
                "name": name,
                "expires_at": expires_at.isoformat() if expires_at else None,
                "scopes": scopes or [],
            }
        )
        response.raise_for_status()
        return response.json()
    
    async def list_api_keys(self, customer_id: int) -> List[Dict[str, Any]]:
        """Listar API keys do cliente (sem mostrar o valor da key)."""
        response = await self.client.get(f"/api-keys")
        response.raise_for_status()
        return response.json()
    
    async def revoke_api_key(self, key_id: str) -> Dict[str, Any]:
        """Revogar API key."""
        response = await self.client.delete(f"/api-keys/{key_id}")
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Usage Tracking
    # =========================================================================
    
    async def log_api_usage(
        self,
        api_key: str,
        usage_type: Literal["api_calls", "llm_tokens", "storage_bytes", "compute_hours"],
        quantity: int,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Registrar uso de API para billing.
        
        Args:
            api_key: API key do cliente
            usage_type: Tipo de uso (api_calls, llm_tokens, storage_bytes, compute_hours)
            quantity: Quantidade consumida
            metadata: Dados adicionais (ex: {"model": "gpt-4", "tokens": 1500})
        
        Example (Chat Service):
            await billing.log_api_usage(
                api_key=customer_api_key,
                usage_type="llm_tokens",
                quantity=1500,
                metadata={
                    "model": "gpt-4",
                    "prompt_tokens": 800,
                    "completion_tokens": 700
                }
            )
        """
        response = await self.client.post(
            "/usage/log",
            json={
                "api_key": api_key,
                "usage_type": usage_type,
                "quantity": quantity,
                "metadata": metadata or {},
            }
        )
        response.raise_for_status()
        return response.json()
    
    async def check_quota(
        self,
        api_key: str,
        usage_type: Literal["api_calls", "llm_tokens", "storage_bytes", "compute_hours"],
    ) -> Dict[str, Any]:
        """
        Verificar quota do cliente.
        
        Returns:
            {
                "usage_type": "llm_tokens",
                "current_usage": 45000,
                "limit": 50000,
                "exceeded": false,
                "remaining": 5000,
                "reset_at": "2025-02-01T00:00:00Z"
            }
        
        Raises:
            QuotaExceededError: Se quota foi excedida
        """
        response = await self.client.get(
            f"/usage/quota",
            params={"api_key": api_key, "usage_type": usage_type}
        )
        response.raise_for_status()
        data = response.json()
        
        if data["exceeded"]:
            raise QuotaExceededError(
                f"Quota excedida para {usage_type}",
                current_usage=data["current_usage"],
                limit=data["limit"]
            )
        
        return data
    
    async def get_usage_summary(
        self,
        customer_id: int,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Obter resumo de uso do cliente.
        
        Returns:
            {
                "period": {"start": "2025-01-01", "end": "2025-01-31"},
                "usage": {
                    "api_calls": 12500,
                    "llm_tokens": 450000,
                    "storage_bytes": 5368709120,  # 5 GB
                    "compute_hours": 24.5
                },
                "costs": {
                    "base_subscription": 99.00,
                    "overage": 12.50,
                    "total": 111.50
                }
            }
        """
        params = {}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()
        
        response = await self.client.get(
            f"/usage/summary",
            params=params
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Tier Upgrade Requests
    # =========================================================================
    
    async def request_tier_upgrade(
        self,
        target_tier: Literal["pro", "enterprise"],
        notes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Solicitar upgrade de tier (cliente).
        
        Args:
            target_tier: Tier desejado (pro, enterprise)
            notes: Justificativa
        
        Returns:
            Request criado (pendente aprovação do admin)
        """
        response = await self.client.post(
            "/subscriptions/request",
            json={
                "plan": target_tier,
                "customer_notes": notes,
                "accept_terms": True,
            }
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Admin - Aprovação de Subscriptions
    # =========================================================================
    
    async def approve_subscription(
        self,
        subscription_id: int,
        admin_notes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Aprovar subscription (admin only).
        
        Args:
            subscription_id: ID da subscription
            admin_notes: Notas do admin
        """
        response = await self.client.post(
            f"/admin/subscriptions/{subscription_id}/approve",
            json={"admin_notes": admin_notes}
        )
        
        if response.status_code == 403:
            raise AuthenticationError("Sem permissão (admin only)")
        
        response.raise_for_status()
        return response.json()
    
    async def reject_subscription(
        self,
        subscription_id: int,
        reason: str,
    ) -> Dict[str, Any]:
        """Rejeitar subscription (admin only)."""
        response = await self.client.post(
            f"/admin/subscriptions/{subscription_id}/reject",
            json={"reason": reason}
        )
        
        if response.status_code == 403:
            raise AuthenticationError("Sem permissão (admin only)")
        
        response.raise_for_status()
        return response.json()
