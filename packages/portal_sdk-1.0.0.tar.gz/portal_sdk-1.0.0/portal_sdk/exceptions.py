"""
QCOS SDK Exceptions
"""


class QCOSSDKError(Exception):
    """Base exception for QCOS SDK."""
    pass


class AuthenticationError(QCOSSDKError):
    """Raised when authentication fails."""
    pass


class PermissionError(QCOSSDKError):
    """Raised when user doesn't have permission."""
    pass


class ResourceNotFoundError(QCOSSDKError):
    """Raised when resource is not found."""
    pass


class QuotaExceededError(QCOSSDKError):
    """Raised when usage quota is exceeded."""
    
    def __init__(self, message: str, current_usage: int, limit: int):
        super().__init__(message)
        self.current_usage = current_usage
        self.limit = limit


class LicenseError(QCOSSDKError):
    """Raised when license validation fails."""
    pass


class LicenseExpiredError(LicenseError):
    """Raised when license has expired."""
    pass


class ValidationError(QCOSSDKError):
    """Raised when request validation fails."""
    pass


class NetworkError(QCOSSDKError):
    """Raised when network request fails."""
    pass


class RateLimitError(QCOSSDKError):
    """Raised when rate limit is exceeded."""
    
    def __init__(self, message: str, retry_after: int):
        super().__init__(message)
        self.retry_after = retry_after  # seconds
