"""
QCOS SDK Models
Pydantic models compartilhados
"""

from typing import Optional, List
from datetime import datetime, date
from pydantic import BaseModel, EmailStr


class Customer(BaseModel):
    id: int
    company_name: str
    email: EmailStr
    contact_name: Optional[str] = None
    industry: Optional[str] = None
    country: Optional[str] = None
    tier: str
    is_active: bool
    created_at: datetime


class Contract(BaseModel):
    id: int
    customer_id: int
    plan: str
    status: str
    start_date: date
    end_date: date
    value: float
    created_at: datetime


class License(BaseModel):
    id: int
    customer_id: int
    contract_id: int
    license_type: str
    modules: List[str]
    status: str
    valid_until: date
    created_at: datetime


class Subscription(BaseModel):
    id: int
    customer_id: int
    plan: str
    status: str
    auto_renew: bool
    created_at: datetime


class Tier(BaseModel):
    name: str
    api_limit: int
    storage_limit: int
    features: List[str]
    price_monthly: float


class APIKey(BaseModel):
    id: str
    name: str
    key: Optional[str] = None
    customer_id: int
    created_at: datetime
    expires_at: Optional[date] = None
    is_active: bool


class UsageLog(BaseModel):
    id: int
    customer_id: int
    api_key_id: str
    usage_type: str
    quantity: int
    timestamp: datetime
