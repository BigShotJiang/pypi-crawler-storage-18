"""
QCOS Admin Client
Gestão de clientes, contratos, licenças, funcionários (admin only)
"""

import httpx
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime, date

from .exceptions import (
    AuthenticationError,
    PermissionError,
    ResourceNotFoundError,
    ValidationError,
)


class AdminClient:
    """
    Cliente para operações administrativas (funcionários apenas).
    
    Usado para:
    - Gestão de clientes (CRUD)
    - Gestão de contratos
    - Gestão de licenças
    - Gestão de funcionários
    - Dashboard e relatórios
    
    Requer: JWT token de funcionário com permissões adequadas
    """
    
    def __init__(
        self,
        base_url: str,
        token: str,
        timeout: int = 30,
    ):
        """
        Args:
            base_url: URL base da API (ex: https://api.softquantus.com)
            token: JWT token do funcionário (EMPLOYEE_JWT_TOKEN)
            timeout: Timeout em segundos
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
        self.client = httpx.AsyncClient(
            base_url=f"{self.base_url}/admin",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        
        # Sub-clientes para diferentes recursos
        self.customers = CustomersAPI(self.client)
        self.contracts = ContractsAPI(self.client)
        self.licenses = LicensesAPI(self.client)
        self.employees = EmployeesAPI(self.client)
        self.dashboard = DashboardAPI(self.client)
    
    async def close(self):
        """Fechar conexão HTTP."""
        await self.client.aclose()


class CustomersAPI:
    """API de clientes (admin)."""
    
    def __init__(self, client: httpx.AsyncClient):
        self.client = client
    
    async def list(
        self,
        page: int = 1,
        per_page: int = 20,
        status: Optional[str] = None,
        search: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Listar clientes."""
        params = {"page": page, "per_page": per_page}
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        
        response = await self.client.get("/customers", params=params)
        
        if response.status_code == 403:
            raise PermissionError("Sem permissão para listar clientes")
        
        response.raise_for_status()
        return response.json()
    
    async def get(self, customer_id: int) -> Dict[str, Any]:
        """Obter detalhes do cliente."""
        response = await self.client.get(f"/customers/{customer_id}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Cliente {customer_id} não encontrado")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()
        return response.json()
    
    async def create(
        self,
        company_name: str,
        email: str,
        contact_name: Optional[str] = None,
        industry: Optional[str] = None,
        country: Optional[str] = None,
        tier: Literal["free", "pro", "enterprise"] = "free",
    ) -> Dict[str, Any]:
        """Criar novo cliente."""
        response = await self.client.post(
            "/customers",
            json={
                "company_name": company_name,
                "email": email,
                "contact_name": contact_name,
                "industry": industry,
                "country": country,
                "tier": tier,
            }
        )
        
        if response.status_code == 403:
            raise PermissionError("Sem permissão para criar clientes")
        elif response.status_code == 400:
            raise ValidationError(response.json().get("detail", "Dados inválidos"))
        
        response.raise_for_status()
        return response.json()
    
    async def update(
        self,
        customer_id: int,
        **kwargs
    ) -> Dict[str, Any]:
        """Atualizar cliente."""
        response = await self.client.put(
            f"/customers/{customer_id}",
            json=kwargs
        )
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Cliente {customer_id} não encontrado")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()
        return response.json()
    
    async def delete(self, customer_id: int) -> None:
        """Deletar cliente."""
        response = await self.client.delete(f"/customers/{customer_id}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Cliente {customer_id} não encontrado")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()


class ContractsAPI:
    """API de contratos (admin)."""
    
    def __init__(self, client: httpx.AsyncClient):
        self.client = client
    
    async def list(
        self,
        page: int = 1,
        per_page: int = 20,
        status: Optional[str] = None,
        customer_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Listar contratos."""
        params = {"page": page, "per_page": per_page}
        if status:
            params["status"] = status
        if customer_id:
            params["customer_id"] = customer_id
        
        response = await self.client.get("/contracts", params=params)
        response.raise_for_status()
        return response.json()
    
    async def get(self, contract_id: int) -> Dict[str, Any]:
        """Obter detalhes do contrato."""
        response = await self.client.get(f"/contracts/{contract_id}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Contrato {contract_id} não encontrado")
        
        response.raise_for_status()
        return response.json()
    
    async def create(
        self,
        customer_id: int,
        plan: str,
        start_date: date,
        end_date: date,
        value: float,
        **kwargs
    ) -> Dict[str, Any]:
        """Criar novo contrato."""
        response = await self.client.post(
            "/contracts",
            json={
                "customer_id": customer_id,
                "plan": plan,
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "value": value,
                **kwargs
            }
        )
        
        if response.status_code == 403:
            raise PermissionError("Sem permissão")
        elif response.status_code == 400:
            raise ValidationError(response.json().get("detail", "Dados inválidos"))
        
        response.raise_for_status()
        return response.json()
    
    async def update(
        self,
        contract_id: int,
        **kwargs
    ) -> Dict[str, Any]:
        """Atualizar contrato."""
        response = await self.client.put(
            f"/contracts/{contract_id}",
            json=kwargs
        )
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Contrato {contract_id} não encontrado")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()
        return response.json()
    
    async def delete(self, contract_id: int) -> None:
        """Deletar contrato."""
        response = await self.client.delete(f"/contracts/{contract_id}")
        response.raise_for_status()


class LicensesAPI:
    """API de licenças (admin)."""
    
    def __init__(self, client: httpx.AsyncClient):
        self.client = client
    
    async def list(
        self,
        page: int = 1,
        per_page: int = 20,
        status: Optional[str] = None,
        customer_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Listar licenças."""
        params = {"page": page, "per_page": per_page}
        if status:
            params["status"] = status
        if customer_id:
            params["customer_id"] = customer_id
        
        response = await self.client.get("/licenses", params=params)
        response.raise_for_status()
        return response.json()
    
    async def get(self, license_id: int) -> Dict[str, Any]:
        """Obter detalhes da licença."""
        response = await self.client.get(f"/licenses/{license_id}")
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Licença {license_id} não encontrada")
        
        response.raise_for_status()
        return response.json()
    
    async def create(
        self,
        customer_id: int,
        contract_id: int,
        license_type: str,
        valid_until: date,
        modules: List[str],
        **kwargs
    ) -> Dict[str, Any]:
        """Criar nova licença."""
        response = await self.client.post(
            "/licenses",
            json={
                "customer_id": customer_id,
                "contract_id": contract_id,
                "license_type": license_type,
                "valid_until": valid_until.isoformat(),
                "modules": modules,
                **kwargs
            }
        )
        
        if response.status_code == 403:
            raise PermissionError("Sem permissão")
        elif response.status_code == 400:
            raise ValidationError(response.json().get("detail", "Dados inválidos"))
        
        response.raise_for_status()
        return response.json()
    
    async def renew(
        self,
        license_id: int,
        new_valid_until: date,
    ) -> Dict[str, Any]:
        """Renovar licença."""
        response = await self.client.post(
            f"/licenses/{license_id}/renew",
            json={"new_valid_until": new_valid_until.isoformat()}
        )
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Licença {license_id} não encontrada")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()
        return response.json()
    
    async def revoke(self, license_id: int, reason: Optional[str] = None) -> Dict[str, Any]:
        """Revogar licença."""
        response = await self.client.post(
            f"/licenses/{license_id}/revoke",
            json={"reason": reason}
        )
        
        if response.status_code == 404:
            raise ResourceNotFoundError(f"Licença {license_id} não encontrada")
        elif response.status_code == 403:
            raise PermissionError("Sem permissão")
        
        response.raise_for_status()
        return response.json()


class EmployeesAPI:
    """API de funcionários (admin)."""
    
    def __init__(self, client: httpx.AsyncClient):
        self.client = client
    
    async def list(
        self,
        page: int = 1,
        per_page: int = 20,
    ) -> List[Dict[str, Any]]:
        """Listar funcionários."""
        response = await self.client.get(
            "/employees",
            params={"page": page, "per_page": per_page}
        )
        response.raise_for_status()
        return response.json()
    
    async def create(
        self,
        email: str,
        full_name: str,
        password: str,
        role: Literal["super_admin", "admin", "sales", "support", "finance", "viewer"],
        department: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Criar novo funcionário."""
        response = await self.client.post(
            "/employees",
            json={
                "email": email,
                "full_name": full_name,
                "password": password,
                "role": role,
                "department": department,
            }
        )
        
        if response.status_code == 403:
            raise PermissionError("Sem permissão (super_admin only)")
        elif response.status_code == 400:
            raise ValidationError(response.json().get("detail", "Dados inválidos"))
        
        response.raise_for_status()
        return response.json()


class DashboardAPI:
    """API de dashboard (admin)."""
    
    def __init__(self, client: httpx.AsyncClient):
        self.client = client
    
    async def get_metrics(self) -> Dict[str, Any]:
        """
        Obter métricas do dashboard.
        
        Returns:
            {
                "total_customers": 150,
                "active_contracts": 120,
                "active_licenses": 180,
                "expiring_licenses": 12,
                "pending_payments": 8,
                "recent_customers": [...],
                "recent_contracts": [...],
                "expiring_licenses": [...]
            }
        """
        response = await self.client.get("/dashboard")
        response.raise_for_status()
        return response.json()
