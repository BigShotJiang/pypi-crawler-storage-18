"""
Unit tests for Portal SDK clients.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
from portal_sdk import (
    AdminClient,
    BillingClient,
    PortalClient,
    AuthenticationError,
    PermissionError,
    ResourceNotFoundError,
)
from portal_sdk.models import Customer, Tier, Subscription


class TestAdminClient:
    """Tests for AdminClient."""

    def test_init_with_api_key(self):
        """Test client initialization with API key."""
        client = AdminClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        assert client.base_url == "http://localhost:8080"
        assert "X-API-Key" in client.client.headers

    def test_init_with_token(self):
        """Test client initialization with Bearer token."""
        client = AdminClient(
            base_url="http://localhost:8080",
            token="test-token"
        )
        assert "Authorization" in client.client.headers

    @patch('httpx.Client.get')
    def test_list_customers(self, mock_get):
        """Test listing customers."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {"id": 1, "name": "Test Customer", "email": "test@example.com"}
        ]
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        client = AdminClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        customers = client.list_customers()
        
        assert len(customers) == 1
        assert customers[0]["name"] == "Test Customer"


class TestBillingClient:
    """Tests for BillingClient."""

    def test_init(self):
        """Test client initialization."""
        client = BillingClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        assert client.base_url == "http://localhost:8080"

    @patch('httpx.Client.get')
    def test_get_tiers(self, mock_get):
        """Test getting tiers."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {
                "id": 1,
                "name": "Free",
                "requests_per_minute": 10,
                "requests_per_day": 100,
                "price_monthly": 0.0
            }
        ]
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        client = BillingClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        tiers = client.get_tiers()
        
        assert len(tiers) == 1
        assert tiers[0]["name"] == "Free"

    @patch('httpx.Client.post')
    def test_check_quota_allowed(self, mock_post):
        """Test quota check when allowed."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "allowed": True,
            "remaining": 90,
            "limit": 100
        }
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        client = BillingClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        result = client.check_quota("sub-123")
        
        assert result["allowed"] is True
        assert result["remaining"] == 90


class TestPortalClient:
    """Tests for PortalClient."""

    def test_init(self):
        """Test client initialization."""
        client = PortalClient(
            base_url="http://localhost:8080",
            api_key="test-key"
        )
        assert client.base_url == "http://localhost:8080"


class TestExceptions:
    """Tests for exception handling."""

    @patch('httpx.Client.get')
    def test_authentication_error(self, mock_get):
        """Test 401 raises AuthenticationError."""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"detail": "Invalid token"}
        
        # Make raise_for_status raise an exception
        from httpx import HTTPStatusError, Request, Response
        mock_response.raise_for_status.side_effect = HTTPStatusError(
            "401 Unauthorized",
            request=Mock(spec=Request),
            response=mock_response
        )
        mock_get.return_value = mock_response

        client = AdminClient(
            base_url="http://localhost:8080",
            api_key="invalid-key"
        )
        
        with pytest.raises(Exception):
            client.list_customers()


class TestModels:
    """Tests for Pydantic models."""

    def test_customer_model(self):
        """Test Customer model validation."""
        customer = Customer(
            id=1,
            name="Test Customer",
            email="test@example.com"
        )
        assert customer.id == 1
        assert customer.name == "Test Customer"

    def test_tier_model(self):
        """Test Tier model."""
        tier = Tier(
            id=1,
            name="Pro",
            requests_per_minute=100,
            requests_per_day=10000,
            price_monthly=29.99
        )
        assert tier.name == "Pro"
        assert tier.price_monthly == 29.99

    def test_subscription_model(self):
        """Test Subscription model."""
        sub = Subscription(
            id="sub-123",
            customer_id=1,
            tier_id=1,
            status="active"
        )
        assert sub.status == "active"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
