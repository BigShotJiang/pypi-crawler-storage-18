# streamlit-fhir-questionnaire

A Streamlit component for rendering FHIR Questionnaires and capturing user responses as FHIR QuestionnaireResponse resources.

## Features

- Render interactive FHIR Questionnaires in Streamlit apps
- Capture structured data as FHIR QuestionnaireResponse resources
- Support for various FHIR question types (string, text, decimal, date, coding, etc.)
- Conditional question display with `enableWhen` logic
- Real-time streaming mode for progressive response updates
- Built with React and the Tiro Health report renderer

## Installation

```bash
pip install streamlit-fhir-questionnaire
```

## Quick Start

```python
import streamlit as st
from streamlit_fhir_questionnaire import streamlit_fhir_questionnaire

# Define a FHIR Questionnaire
questionnaire = {
    "resourceType": "Questionnaire",
    "title": "Patient Information",
    "item": [
        {
            "linkId": "1",
            "text": "What is your name?",
            "type": "string"
        },
        {
            "linkId": "2",
            "text": "What is your date of birth?",
            "type": "date"
        }
    ]
}

# Render the questionnaire and capture responses
response = streamlit_fhir_questionnaire(
    questionnaire=questionnaire,
    key="patient_info"
)

# Display the captured FHIR QuestionnaireResponse
if response:
    st.write("FHIR QuestionnaireResponse:", response)
```

## Parameters

- **questionnaire** (dict, required): A FHIR Questionnaire resource defining the questions
- **initial_questionnaire_response** (dict, optional): Pre-populate the form with an initial response
- **questionnaire_response** (dict, optional): Controlled component state for the current response
- **key** (str, optional): Unique identifier for this component instance
- **streaming** (bool, optional): Enable streaming mode for real-time updates

## Development

### Prerequisites

- Python ^3.11
- Node.js and pnpm
- Poetry for Python dependency management

### Setup

1. Clone the repository
2. Install Python dependencies: `poetry install`
3. Set up frontend:
   ```bash
   cd streamlit_fhir_questionnaire/frontend
   pnpm install
   ```

### Running the Example

```bash
poetry run streamlit run streamlit_fhir_questionnaire/example.py
```

### Development Mode

1. Create a `.npmrc` file in the `streamlit_fhir_questionnaire/frontend/` directory with your GitHub token:
   ```
   //npm.pkg.github.com/:_authToken=YOUR_GITHUB_TOKEN
   @tiro-health:registry=https://npm.pkg.github.com/
   node-linker=hoisted
   ```

2. Start the frontend dev server:
   ```bash
   cd streamlit_fhir_questionnaire/frontend
   pnpm run dev
   ```

3. In `__init__.py`, set `_RELEASE = False` to use the dev server

4. Run the Streamlit app:
   ```bash
   poetry run streamlit run streamlit_fhir_questionnaire/example.py
   ```

### Building for Production

```bash
cd streamlit_fhir_questionnaire/frontend
pnpm build
```

## License

MIT License - Copyright (c) 2018-2021 Streamlit Inc.

## Credits

Built by [Tiro Health](https://tiro.health) using the [@tiro-health/report-renderer](https://github.com/Tiro-health/report-renderer) library.
