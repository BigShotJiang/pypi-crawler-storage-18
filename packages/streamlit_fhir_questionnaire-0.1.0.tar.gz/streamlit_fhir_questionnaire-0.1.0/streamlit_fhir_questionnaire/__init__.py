import os

import streamlit.components.v1 as components

# Create a _RELEASE constant. We'll set this to False while we're developing
# the component, and True when we're ready to package and distribute it.
# (This is, of course, optional - there are innumerable ways to manage your
# release process.)
_RELEASE = True

# Declare a Streamlit component. `declare_component` returns a function
# that is used to create instances of the component. We're naming this
# function "_component_func", with an underscore prefix, because we don't want
# to expose it directly to users. Instead, we will create a custom wrapper
# function, below, that will serve as our component's public API.

# It's worth noting that this call to `declare_component` is the
# *only thing* you need to do to create the binding between Streamlit and
# your component frontend. Everything else we do in this file is simply a
# best practice.

if not _RELEASE:
    _component_func = components.declare_component(
        "streamlit_fhir_questionnaire",
        url="http://localhost:5173",
    )
else:
    # When we're distributing a production version of the component, we'll
    # replace the `url` param with `path`, and point it to the component's
    # build directory:
    parent_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(parent_dir, "frontend", "dist")
    _component_func = components.declare_component("streamlit_fhir_questionnaire", path=build_dir)


# Create a wrapper function for the component. This is an optional
# best practice - we could simply expose the component function returned by
# `declare_component` and call it done. The wrapper allows us to customize
# our component's API: we can pre-process its input args, post-process its
# output value, and add a docstring for users.
def streamlit_fhir_questionnaire(
    *,
    questionnaire,
    initial_questionnaire_response=None,
    questionnaire_response=None,
    key=None,
    streaming=False,
):
    """Render a FHIR Questionnaire and capture responses.

    This component renders interactive FHIR Questionnaires and captures user
    input as FHIR QuestionnaireResponse resources.

    Parameters
    ----------
    questionnaire: dict
        A FHIR Questionnaire resource (as a Python dict or JSON-compatible object)
        defining the questions to display.
    initial_questionnaire_response: dict or None
        An optional initial FHIR QuestionnaireResponse to pre-populate the form.
    questionnaire_response: dict or None
        Current FHIR QuestionnaireResponse state. Use this for controlled component behavior.
    key: str or None
        An optional unique key for this component instance. If None and arguments change,
        the component will remount and lose state.
    streaming: bool
        If True, enables streaming mode for real-time response updates.

    Returns
    -------
    dict
        The current FHIR QuestionnaireResponse with user's answers.
    """
    # Call through to our private component function. Arguments we pass here
    # will be sent to the frontend, where they'll be available in an "args"
    # dictionary.
    #
    # "default" is a special argument that specifies the initial return
    # value of the component before the user has interacted with it.
    component_value = _component_func(
        questionnaire=questionnaire,
        initial_questionnaire_response=initial_questionnaire_response,
        questionnaire_response=questionnaire_response,
        key=key,
        default=0,
        streaming=streaming,
    )
    # We could modify the value returned from the component if we wanted.
    # There's no need to do this in our simple example - but it's an option.
    return component_value
