# MxBoxUtils

MxBoxUtils 是一个Python工具库，提供了文件操作、TOML配置解析等实用功能。

## 目录结构

```
MxBoxUtils/
├── src/
│   └── mx/             # 核心功能模块
│       ├── __init__.py # 包初始化文件
│       ├── file.py     # 文件操作工具
│       └── toml.py     # TOML配置文件解析工具
├── LICENSE             # 许可证文件
├── pyproject.toml      # 项目配置文件
└── README.md           # 项目说明文档
```

## 功能模块

### 1. 文件操作 (file.py)

提供文件和目录操作相关的功能。

#### files(f_path: str, f_ext: list[str]) -> list[str]
列出指定目录下的所有指定扩展名的文件名。
- **参数**: 
  - `f_path` - 目录路径
  - `f_ext` - 要匹配的文件扩展名列表（不包含点号）
- **返回值**: 包含所有匹配文件名的列表

#### 其他函数（待实现）
- `file_paths()` - 获取文件路径
- `images()` - 处理图像文件
- `image_paths()` - 获取图像文件路径
- `file_hash()` - 计算文件哈希值

### 2. TOML配置解析 (toml.py)

提供TOML配置文件解析功能。

#### load_toml(filepath)
加载TOML文件并返回解析后的数据。
- **参数**: 
  - `filepath` - TOML文件的路径
- **返回值**: 解析后的TOML数据字典，如果文件不存在则返回None

## 安装说明

```bash
# 从源代码安装
git clone https://gitee.com/RyanLuDev/MxBoxUtils
cd MxBoxUtils
pip install -e .
```

## 版本信息

当前版本: 0.1.5

## 系统要求

- Python 3.14 或更高版本

## 依赖

- pillow (图像处理相关功能需要)

## 开发依赖

- pytest
- twine
- build

## 贡献

欢迎提交Issue和Pull Request来帮助改进这个项目。

## 许可证

MIT License