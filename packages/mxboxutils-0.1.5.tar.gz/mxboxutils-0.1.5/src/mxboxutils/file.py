import hashlib
import os 
import pathlib
import shutil

IMG_TYPE = ["jpg", "jpeg", "png"]

def files(f_path:str,f_ext:list[str])->list[str]:
    f_ext = [ext.lower() for ext in f_ext]
    if not os.path.exists(f_path):
        return []
    exts = ["."+ext for ext in f_ext]
    files:list[str] = []
    for f in os.listdir(f_path):
        ext = "".join(pathlib.Path(f).suffixes)
        if ext in exts:
            files.append(f)
    return files

def file_paths():
    pass

def images():
    pass

def image_paths():
    pass

def file_hash():
    pass
