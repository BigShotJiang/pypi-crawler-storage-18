//! Shader compilation and caching

use crate::{GpuDevice, GpuResult};
use parking_lot::RwLock;
use std::collections::HashMap;
use std::sync::Arc;

/// Cache for compiled compute shaders
pub struct ShaderCache {
    device: Arc<GpuDevice>,
    modules: RwLock<HashMap<String, Arc<wgpu::ShaderModule>>>,
    pipelines: RwLock<HashMap<String, Arc<wgpu::ComputePipeline>>>,
}

impl ShaderCache {
    /// Create a new shader cache for a device
    pub fn new(device: Arc<GpuDevice>) -> Self {
        Self {
            device,
            modules: RwLock::new(HashMap::new()),
            pipelines: RwLock::new(HashMap::new()),
        }
    }

    /// Get or compile a shader module
    pub fn get_module(&self, name: &str, source: &str) -> GpuResult<Arc<wgpu::ShaderModule>> {
        // Check cache first
        {
            let modules = self.modules.read();
            if let Some(module) = modules.get(name) {
                return Ok(Arc::clone(module));
            }
        }

        // Compile and cache
        let module = self
            .device
            .device
            .create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some(name),
                source: wgpu::ShaderSource::Wgsl(source.into()),
            });

        let module = Arc::new(module);
        self.modules
            .write()
            .insert(name.to_string(), Arc::clone(&module));
        Ok(module)
    }

    /// Get or create a compute pipeline
    pub fn get_pipeline(
        &self,
        name: &str,
        module: &wgpu::ShaderModule,
        entry_point: &str,
        bind_group_layouts: &[&wgpu::BindGroupLayout],
    ) -> Arc<wgpu::ComputePipeline> {
        let key = format!("{}:{}", name, entry_point);

        // Check cache
        {
            let pipelines = self.pipelines.read();
            if let Some(pipeline) = pipelines.get(&key) {
                return Arc::clone(pipeline);
            }
        }

        // Create pipeline layout
        let layout = self
            .device
            .device
            .create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some(&format!("{}_layout", name)),
                bind_group_layouts,
                push_constant_ranges: &[],
            });

        // Create compute pipeline
        let pipeline =
            self.device
                .device
                .create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
                    label: Some(name),
                    layout: Some(&layout),
                    module,
                    entry_point: Some(entry_point),
                    compilation_options: wgpu::PipelineCompilationOptions::default(),
                    cache: None,
                });

        let pipeline = Arc::new(pipeline);
        self.pipelines.write().insert(key, Arc::clone(&pipeline));
        pipeline
    }

    /// Clear all cached shaders and pipelines
    pub fn clear(&self) {
        self.modules.write().clear();
        self.pipelines.write().clear();
    }
}

/// Built-in WGSL shaders for common operations
pub mod shaders {
    /// Element-wise addition shader
    pub const ADD_F32: &str = r#"
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = a[idx] + b[idx];
    }
}
"#;

    /// Element-wise multiplication shader
    pub const MUL_F32: &str = r#"
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = a[idx] * b[idx];
    }
}
"#;

    /// ReLU activation shader
    pub const RELU_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = max(input[idx], 0.0);
    }
}
"#;

    /// Reciprocal shader (1/x)
    pub const RECIP_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = 1.0 / input[idx];
    }
}
"#;

    /// Element-wise subtraction shader
    pub const SUB_F32: &str = r#"
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = a[idx] - b[idx];
    }
}
"#;

    /// Element-wise division shader
    pub const DIV_F32: &str = r#"
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = a[idx] / b[idx];
    }
}
"#;

    /// Broadcast add: add 1D bias to each row of 2D tensor
    /// out[i,j] = a[i,j] + b[j]
    pub const BROADCAST_ADD_F32: &str = r#"
struct Dims {
    rows: u32,
    cols: u32,
}

@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;  // 1D bias
@group(0) @binding(2) var<storage, read_write> out: array<f32>;
@group(0) @binding(3) var<uniform> dims: Dims;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    let total = dims.rows * dims.cols;
    if idx < total {
        let col = idx % dims.cols;
        out[idx] = a[idx] + b[col];
    }
}
"#;

    /// Scalar multiply shader
    pub const SCALAR_MUL_F32: &str = r#"
struct Scalar {
    value: f32,
}

@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;
@group(0) @binding(2) var<uniform> scalar: Scalar;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = input[idx] * scalar.value;
    }
}
"#;

    /// Absolute value shader
    pub const ABS_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = abs(input[idx]);
    }
}
"#;

    /// Negation shader
    pub const NEG_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = -input[idx];
    }
}
"#;

    /// Square root shader
    pub const SQRT_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = sqrt(input[idx]);
    }
}
"#;

    /// Exponential shader
    pub const EXP_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = exp(input[idx]);
    }
}
"#;

    /// Natural log shader
    pub const LOG_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = log(input[idx]);
    }
}
"#;

    /// Sigmoid shader: 1 / (1 + exp(-x))
    pub const SIGMOID_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = 1.0 / (1.0 + exp(-input[idx]));
    }
}
"#;

    /// Tanh shader
    pub const TANH_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        out[idx] = tanh(input[idx]);
    }
}
"#;

    /// GELU shader (approximate)
    pub const GELU_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let idx = gid.x;
    if idx < arrayLength(&out) {
        let x = input[idx];
        // Approximate GELU: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        let c = 0.7978845608;  // sqrt(2/pi)
        let inner = c * (x + 0.044715 * x * x * x);
        out[idx] = 0.5 * x * (1.0 + tanh(inner));
    }
}
"#;

    /// Matrix multiplication shader (naive, for correctness)
    pub const MATMUL_F32: &str = r#"
struct Dims {
    M: u32,
    N: u32,
    K: u32,
    _pad: u32,
}

@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> out: array<f32>;
@group(0) @binding(3) var<uniform> dims: Dims;

@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let row = gid.y;
    let col = gid.x;
    
    if row >= dims.M || col >= dims.N {
        return;
    }
    
    var sum: f32 = 0.0;
    for (var k: u32 = 0u; k < dims.K; k = k + 1u) {
        sum = sum + a[row * dims.K + k] * b[k * dims.N + col];
    }
    out[row * dims.N + col] = sum;
}
"#;

    /// Sum reduction shader
    pub const SUM_F32: &str = r#"
@group(0) @binding(0) var<storage, read> input: array<f32>;
@group(0) @binding(1) var<storage, read_write> out: array<f32>;

var<workgroup> sdata: array<f32, 256>;

@compute @workgroup_size(256)
fn main(
    @builtin(global_invocation_id) gid: vec3<u32>,
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wid: vec3<u32>
) {
    let idx = gid.x;
    let local_idx = lid.x;
    
    // Load to shared memory
    if idx < arrayLength(&input) {
        sdata[local_idx] = input[idx];
    } else {
        sdata[local_idx] = 0.0;
    }
    workgroupBarrier();
    
    // Parallel reduction
    for (var stride: u32 = 128u; stride > 0u; stride = stride >> 1u) {
        if local_idx < stride {
            sdata[local_idx] = sdata[local_idx] + sdata[local_idx + stride];
        }
        workgroupBarrier();
    }
    
    // Write result
    if local_idx == 0u {
        out[wid.x] = sdata[0];
    }
}
"#;
}
