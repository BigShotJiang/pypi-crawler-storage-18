//! GPU buffer abstraction for tensor storage

use crate::{GpuDevice, GpuResult};
use std::sync::Arc;

/// GPU buffer wrapper with size tracking
pub struct GpuBuffer {
    pub(crate) buffer: wgpu::Buffer,
    pub(crate) size: usize,
    pub(crate) device: Arc<GpuDevice>,
}

impl GpuBuffer {
    /// Create a new uninitialized buffer
    pub fn new(device: Arc<GpuDevice>, size: usize) -> Self {
        let buffer = device.create_buffer(
            size as u64,
            wgpu::BufferUsages::STORAGE
                | wgpu::BufferUsages::COPY_SRC
                | wgpu::BufferUsages::COPY_DST,
        );
        Self {
            buffer,
            size,
            device,
        }
    }

    /// Create a buffer from data
    pub fn from_bytes(device: Arc<GpuDevice>, data: &[u8]) -> Self {
        let buffer = device.create_buffer_init(
            data,
            wgpu::BufferUsages::STORAGE
                | wgpu::BufferUsages::COPY_SRC
                | wgpu::BufferUsages::COPY_DST,
        );
        Self {
            size: data.len(),
            buffer,
            device,
        }
    }

    /// Copy data to this buffer
    pub fn write(&self, data: &[u8]) {
        self.device.queue.write_buffer(&self.buffer, 0, data);
    }

    /// Read data from this buffer
    pub fn read(&self) -> GpuResult<Vec<u8>> {
        let staging = self.device.create_buffer(
            self.size as u64,
            wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
        );

        let mut encoder = self
            .device
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor { label: None });

        encoder.copy_buffer_to_buffer(&self.buffer, 0, &staging, 0, self.size as u64);
        self.device.submit_and_wait(encoder);

        let slice = staging.slice(..);
        let (tx, rx) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |result| {
            tx.send(result).unwrap();
        });
        self.device.device.poll(wgpu::Maintain::Wait);
        rx.recv().unwrap()?;

        let data = slice.get_mapped_range().to_vec();
        Ok(data)
    }

    /// Get buffer size in bytes
    pub fn size(&self) -> usize {
        self.size
    }

    /// Get underlying wgpu buffer reference
    pub fn raw(&self) -> &wgpu::Buffer {
        &self.buffer
    }
}
