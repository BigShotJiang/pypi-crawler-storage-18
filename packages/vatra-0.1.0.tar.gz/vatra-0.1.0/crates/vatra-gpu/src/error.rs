//! GPU error types

use thiserror::Error;

/// GPU operation result type
pub type GpuResult<T> = Result<T, GpuError>;

/// GPU-related errors
#[derive(Error, Debug)]
pub enum GpuError {
    #[error("No suitable GPU adapter found")]
    NoAdapter,

    #[error("Failed to request GPU device: {0}")]
    DeviceRequest(#[from] wgpu::RequestDeviceError),

    #[error("Buffer mapping failed: {0}")]
    BufferMapping(#[from] wgpu::BufferAsyncError),

    #[error("Shader compilation failed: {0}")]
    ShaderCompilation(String),

    #[error("Buffer size mismatch: expected {expected}, got {actual}")]
    BufferSizeMismatch { expected: usize, actual: usize },

    #[error("Invalid operation: {0}")]
    InvalidOperation(String),
}
