//! GPU backend initialization and device management

use crate::{GpuError, GpuResult};
use parking_lot::RwLock;
use std::sync::Arc;

/// Global GPU backend singleton
static BACKEND: RwLock<Option<Arc<GpuBackend>>> = RwLock::new(None);

/// Main GPU backend holding wgpu instance
pub struct GpuBackend {
    instance: wgpu::Instance,
    devices: RwLock<Vec<Arc<GpuDevice>>>,
}

impl GpuBackend {
    /// Initialize the global GPU backend
    pub fn init() -> GpuResult<Arc<Self>> {
        let mut guard = BACKEND.write();
        if let Some(ref backend) = *guard {
            return Ok(Arc::clone(backend));
        }

        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::VULKAN,
            ..Default::default()
        });

        let backend = Arc::new(Self {
            instance,
            devices: RwLock::new(Vec::new()),
        });

        *guard = Some(Arc::clone(&backend));
        Ok(backend)
    }

    /// Get the global backend instance
    pub fn get() -> GpuResult<Arc<Self>> {
        let guard = BACKEND.read();
        guard.clone().ok_or(GpuError::NoAdapter)
    }

    /// Get or create a GPU device by index
    pub fn device(&self, index: usize) -> GpuResult<Arc<GpuDevice>> {
        // Check if already created
        {
            let devices = self.devices.read();
            if let Some(device) = devices.get(index) {
                return Ok(Arc::clone(device));
            }
        }

        // Create new device
        let adapters = self.instance.enumerate_adapters(wgpu::Backends::VULKAN);
        let adapter = adapters.get(index).ok_or(GpuError::NoAdapter)?;

        let (device, queue) = pollster::block_on(adapter.request_device(
            &wgpu::DeviceDescriptor {
                label: Some("vatra-device"),
                required_features: wgpu::Features::empty(),
                required_limits: wgpu::Limits::default(),
                memory_hints: wgpu::MemoryHints::Performance,
            },
            None,
        ))?;

        let gpu_device = Arc::new(GpuDevice {
            device: Arc::new(device),
            queue: Arc::new(queue),
            index,
        });

        let mut devices = self.devices.write();
        if devices.len() <= index {
            devices.resize_with(index + 1, || Arc::clone(&gpu_device));
        }
        devices[index] = Arc::clone(&gpu_device);

        Ok(gpu_device)
    }

    /// List available GPU adapters
    pub fn list_adapters(&self) -> Vec<String> {
        self.instance
            .enumerate_adapters(wgpu::Backends::VULKAN)
            .into_iter()
            .map(|a| {
                let info = a.get_info();
                format!("{} ({:?})", info.name, info.backend)
            })
            .collect()
    }

    /// Get the number of available GPU devices
    pub fn device_count(&self) -> usize {
        self.instance
            .enumerate_adapters(wgpu::Backends::VULKAN)
            .len()
    }
}

/// A single GPU device with its queue
pub struct GpuDevice {
    pub device: Arc<wgpu::Device>,
    pub queue: Arc<wgpu::Queue>,
    pub index: usize,
}

impl GpuDevice {
    /// Create a new buffer with given size and usage
    pub fn create_buffer(&self, size: u64, usage: wgpu::BufferUsages) -> wgpu::Buffer {
        self.device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size,
            usage,
            mapped_at_creation: false,
        })
    }

    /// Create a buffer initialized with data
    pub fn create_buffer_init(&self, data: &[u8], usage: wgpu::BufferUsages) -> wgpu::Buffer {
        use wgpu::util::DeviceExt;
        self.device
            .create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: data,
                usage,
            })
    }

    /// Submit commands and wait for completion
    pub fn submit_and_wait(&self, encoder: wgpu::CommandEncoder) {
        let submission = self.queue.submit(std::iter::once(encoder.finish()));
        self.device
            .poll(wgpu::Maintain::WaitForSubmissionIndex(submission));
    }
}
