//! Vatra GPU Backend — wgpu-based Vulkan compute
//!
//! Provides low-level GPU abstractions for tensor operations.

mod backend;
mod buffer;
mod error;
pub mod shader;

pub use backend::{GpuBackend, GpuDevice};
pub use buffer::GpuBuffer;
pub use error::{GpuError, GpuResult};
pub use shader::ShaderCache;
