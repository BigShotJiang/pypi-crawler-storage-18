//! Linear algebra operations

use bytemuck::{Pod, Zeroable};
use vatra_core::{DType, Device, Shape, Tensor, VatraError, VatraResult};
use vatra_gpu::{shader::shaders, GpuBuffer, ShaderCache};

/// Uniform buffer for matrix dimensions
#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct MatmulDims {
    m: u32,
    n: u32,
    k: u32,
    _pad: u32,
}

/// Matrix multiplication: a @ b
pub fn matmul(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    if a.device() != b.device() {
        return Err(VatraError::DeviceMismatch);
    }

    // Check dimensions
    if a.ndim() < 2 || b.ndim() < 2 {
        return Err(VatraError::InvalidArgument(
            "matmul requires at least 2D tensors".into(),
        ));
    }

    let a_shape = a.shape();
    let b_shape = b.shape();

    let m = a_shape[a_shape.rank() - 2];
    let k = a_shape[a_shape.rank() - 1];
    let k2 = b_shape[b_shape.rank() - 2];
    let n = b_shape[b_shape.rank() - 1];

    if k != k2 {
        return Err(VatraError::IncompatibleShapes(
            format!("matmul: inner dimensions must match, got {} and {}", k, k2),
            String::new(),
        ));
    }

    let out_shape = Shape::from([m, n]);

    if a.device().is_cpu() {
        return matmul_cpu(a, b, m, n, k);
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("matmul_f32", shaders::MATMUL_F32)?;

    // Create output and dims buffers
    let out_buffer = GpuBuffer::new(device.clone(), m * n * 4);
    let dims = MatmulDims {
        m: m as u32,
        n: n as u32,
        k: k as u32,
        _pad: 0,
    };
    let dims_buffer =
        device.create_buffer_init(bytemuck::bytes_of(&dims), wgpu::BufferUsages::UNIFORM);

    // Create bind group layout
    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("matmul_layout"),
                entries: &[
                    storage_entry(0, true),
                    storage_entry(1, true),
                    storage_entry(2, false),
                    uniform_entry(3),
                ],
            });

    let pipeline = cache.get_pipeline("matmul_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: b.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: out_buffer.raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 3,
                resource: dims_buffer.as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("matmul_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("matmul_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        // workgroup_size is 16x16
        let wg_x = (n as u32 + 15) / 16;
        let wg_y = (m as u32 + 15) / 16;
        pass.dispatch_workgroups(wg_x, wg_y, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        out_shape,
        DType::F32,
        a.device(),
    ))
}

/// Dot product of two 1D tensors
pub fn dot(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    if a.ndim() != 1 || b.ndim() != 1 {
        return Err(VatraError::InvalidArgument(
            "dot requires 1D tensors".into(),
        ));
    }
    if a.numel() != b.numel() {
        return Err(VatraError::IncompatibleShapes(
            a.shape().to_string(),
            b.shape().to_string(),
        ));
    }

    let prod = super::mul(a, b)?;
    super::sum(&prod, None)
}

/// Outer product of two 1D tensors
pub fn outer(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    if a.ndim() != 1 || b.ndim() != 1 {
        return Err(VatraError::InvalidArgument(
            "outer requires 1D tensors".into(),
        ));
    }

    let a_col = a.unsqueeze(-1)?; // (n, 1)
    let b_row = b.unsqueeze(0)?; // (1, m)
    super::mul(&a_col, &b_row)
}

/// Transpose a tensor (swap last two dimensions)
pub fn transpose(a: &Tensor) -> VatraResult<Tensor> {
    a.t()
}

// ========== CPU fallback ==========

fn matmul_cpu(a: &Tensor, b: &Tensor, m: usize, n: usize, k: usize) -> VatraResult<Tensor> {
    let a_data = a.to_vec()?;
    let b_data = b.to_vec()?;
    let mut c_data = vec![0.0f32; m * n];

    for i in 0..m {
        for j in 0..n {
            let mut sum = 0.0;
            for kk in 0..k {
                sum += a_data[i * k + kk] * b_data[kk * n + j];
            }
            c_data[i * n + j] = sum;
        }
    }

    Tensor::from_slice(&c_data, [m, n], Device::Cpu)
}

// ========== Helpers ==========

fn storage_entry(binding: u32, read_only: bool) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Storage { read_only },
            has_dynamic_offset: false,
            min_binding_size: None,
        },
        count: None,
    }
}

fn uniform_entry(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Uniform,
            has_dynamic_offset: false,
            min_binding_size: None,
        },
        count: None,
    }
}
