//! Basic element-wise operations

use vatra_core::{DType, Device, Shape, Tensor, VatraError, VatraResult};
use vatra_gpu::{GpuBuffer, ShaderCache, shader::shaders};

/// Element-wise addition: a + b
pub fn add(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    check_same_device(a, b)?;
    let out_shape = broadcast_shapes(a, b)?;

    if a.device().is_cpu() {
        return add_cpu(a, b, &out_shape);
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("add_f32", shaders::ADD_F32)?;

    // Create output buffer
    let out_buffer = GpuBuffer::new(device.clone(), out_shape.numel() * 4);

    // Create bind group layout
    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("add_layout"),
                entries: &[
                    buffer_entry(0, true),
                    buffer_entry(1, true),
                    buffer_entry(2, false),
                ],
            });

    let pipeline = cache.get_pipeline("add_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: b.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: out_buffer.raw().as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("add_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("add_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        let workgroups = (out_shape.numel() as u32 + 255) / 256;
        pass.dispatch_workgroups(workgroups, 1, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        out_shape,
        DType::F32,
        a.device(),
    ))
}

#[repr(C)]
#[derive(Copy, Clone, Debug, bytemuck::Pod, bytemuck::Zeroable)]
struct BroadcastDims {
    rows: u32,
    cols: u32,
}

/// Broadcast add: add 1D bias to 2D tensor
/// a: [rows, cols]
/// b: [cols]
/// out: [rows, cols]
pub fn broadcast_add(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    check_same_device(a, b)?;

    let a_shape = a.shape();
    let b_shape = b.shape();

    if a_shape.dims().len() != 2 || b_shape.dims().len() != 1 {
        return Err(VatraError::IncompatibleShapes(
            a_shape.to_string(),
            b_shape.to_string(),
        ));
    }

    let rows = a_shape[0];
    let cols = a_shape[1];

    if b_shape[0] != cols {
        return Err(VatraError::IncompatibleShapes(
            a_shape.to_string(),
            b_shape.to_string(),
        ));
    }

    if a.device().is_cpu() {
        // CPU fallback
        let a_data = a.to_vec()?;
        let b_data = b.to_vec()?;
        let mut out_data = vec![0.0; rows * cols];

        for r in 0..rows {
            for c in 0..cols {
                out_data[r * cols + c] = a_data[r * cols + c] + b_data[c];
            }
        }
        return Tensor::from_slice(&out_data, a_shape.clone(), a.device());
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("broadcast_add_f32", shaders::BROADCAST_ADD_F32)?;

    let out_buffer = GpuBuffer::new(device.clone(), rows * cols * 4);

    let dims = BroadcastDims {
        rows: rows as u32,
        cols: cols as u32,
    };
    let dims_buffer = device.create_buffer_init(
        bytemuck::bytes_of(&dims),
        wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
    );

    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("broadcast_add_layout"),
                entries: &[
                    buffer_entry(0, true),  // a
                    buffer_entry(1, true),  // b (bias)
                    buffer_entry(2, false), // out
                    wgpu::BindGroupLayoutEntry {
                        binding: 3,
                        visibility: wgpu::ShaderStages::COMPUTE,
                        ty: wgpu::BindingType::Buffer {
                            ty: wgpu::BufferBindingType::Uniform,
                            has_dynamic_offset: false,
                            min_binding_size: None,
                        },
                        count: None,
                    },
                ],
            });

    let pipeline = cache.get_pipeline("broadcast_add_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: b.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: out_buffer.raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 3,
                resource: dims_buffer.as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("broadcast_add_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("broadcast_add_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        let workgroups = ((rows * cols) as u32 + 255) / 256;
        pass.dispatch_workgroups(workgroups, 1, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        a_shape.clone(),
        DType::F32,
        a.device(),
    ))
}

/// Element-wise subtraction: a - b
pub fn sub(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let neg_b = neg(b)?;
    add(a, &neg_b)
}

/// Element-wise multiplication: a * b
pub fn mul(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    check_same_device(a, b)?;
    let out_shape = broadcast_shapes(a, b)?;

    if a.device().is_cpu() {
        return mul_cpu(a, b, &out_shape);
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("mul_f32", shaders::MUL_F32)?;

    let out_buffer = GpuBuffer::new(device.clone(), out_shape.numel() * 4);

    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("mul_layout"),
                entries: &[
                    buffer_entry(0, true),
                    buffer_entry(1, true),
                    buffer_entry(2, false),
                ],
            });

    let pipeline = cache.get_pipeline("mul_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: b.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: out_buffer.raw().as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("mul_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("mul_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        let workgroups = (out_shape.numel() as u32 + 255) / 256;
        pass.dispatch_workgroups(workgroups, 1, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        out_shape,
        DType::F32,
        a.device(),
    ))
}

/// Element-wise division: a / b
pub fn div(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    // TODO: Implement proper div shader
    let recip_b = recip(b)?;
    mul(a, &recip_b)
}

/// Element-wise negation: -a
pub fn neg(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| -x).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "neg_f32", shaders::NEG_F32)
}

/// Element-wise reciprocal: 1/a
pub fn recip(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| 1.0 / x).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "recip_f32", shaders::RECIP_F32)
}

/// Element-wise exponential: e^a
pub fn exp(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| x.exp()).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "exp_f32", shaders::EXP_F32)
}

/// Element-wise natural log: ln(a)
pub fn log(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| x.ln()).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "log_f32", shaders::LOG_F32)
}

/// Element-wise power: a^b (scalar exponent)
pub fn pow_scalar(a: &Tensor, exp: f32) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| x.powf(exp)).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }
    Err(VatraError::Unsupported(
        "GPU pow not yet implemented".into(),
    ))
}

/// Element-wise square root: sqrt(a)
pub fn sqrt(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| x.sqrt()).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "sqrt_f32", shaders::SQRT_F32)
}

/// Element-wise absolute value: |a|
pub fn abs(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|x| x.abs()).collect();
        return Tensor::from_slice(&result, a.shape().clone(), a.device());
    }

    unary_gpu_op(a, "abs_f32", shaders::ABS_F32)
}

/// Helper for unary GPU operations (input -> output, same shape)
fn unary_gpu_op(a: &Tensor, name: &str, shader: &str) -> VatraResult<Tensor> {
    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module(name, shader)?;

    let out_shape = a.shape().clone();
    let out_buffer = GpuBuffer::new(device.clone(), out_shape.numel() * 4);

    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some(&format!("{}_layout", name)),
                entries: &[
                    buffer_entry(0, true),  // input
                    buffer_entry(1, false), // output
                ],
            });

    let pipeline = cache.get_pipeline(name, &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: out_buffer.raw().as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some(&format!("{}_encoder", name)),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some(&format!("{}_pass", name)),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        let workgroups = (out_shape.numel() as u32 + 255) / 256;
        pass.dispatch_workgroups(workgroups, 1, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        out_shape,
        DType::F32,
        a.device(),
    ))
}

// ========== CPU fallbacks ==========

fn add_cpu(a: &Tensor, b: &Tensor, out_shape: &Shape) -> VatraResult<Tensor> {
    let a_data = a.to_vec()?;
    let b_data = b.to_vec()?;

    // Simple case: same shape
    if a.shape() == b.shape() {
        let result: Vec<f32> = a_data
            .iter()
            .zip(b_data.iter())
            .map(|(x, y)| x + y)
            .collect();
        return Tensor::from_slice(&result, out_shape.clone(), Device::Cpu);
    }

    // Broadcasting case - simplified
    let mut result = vec![0.0f32; out_shape.numel()];
    for i in 0..out_shape.numel() {
        let a_idx = i % a.numel();
        let b_idx = i % b.numel();
        result[i] = a_data[a_idx] + b_data[b_idx];
    }
    Tensor::from_slice(&result, out_shape.clone(), Device::Cpu)
}

fn mul_cpu(a: &Tensor, b: &Tensor, out_shape: &Shape) -> VatraResult<Tensor> {
    let a_data = a.to_vec()?;
    let b_data = b.to_vec()?;

    if a.shape() == b.shape() {
        let result: Vec<f32> = a_data
            .iter()
            .zip(b_data.iter())
            .map(|(x, y)| x * y)
            .collect();
        return Tensor::from_slice(&result, out_shape.clone(), Device::Cpu);
    }

    let mut result = vec![0.0f32; out_shape.numel()];
    for i in 0..out_shape.numel() {
        let a_idx = i % a.numel();
        let b_idx = i % b.numel();
        result[i] = a_data[a_idx] * b_data[b_idx];
    }
    Tensor::from_slice(&result, out_shape.clone(), Device::Cpu)
}

// ========== Helpers ==========

fn check_same_device(a: &Tensor, b: &Tensor) -> VatraResult<()> {
    if a.device() != b.device() {
        return Err(VatraError::DeviceMismatch);
    }
    Ok(())
}

fn broadcast_shapes(a: &Tensor, b: &Tensor) -> VatraResult<Shape> {
    a.shape()
        .broadcast_with(b.shape())
        .ok_or_else(|| VatraError::IncompatibleShapes(a.shape().to_string(), b.shape().to_string()))
}

fn buffer_entry(binding: u32, read_only: bool) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Storage { read_only },
            has_dynamic_offset: false,
            min_binding_size: None,
        },
        count: None,
    }
}
