//! Reduction operations

use vatra_core::{DType, Device, Shape, Tensor, VatraError, VatraResult};
use vatra_gpu::{shader::shaders, GpuBuffer, ShaderCache};

/// Sum reduction over specified axis (None = all elements)
pub fn sum(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    match axis {
        None => sum_all(a),
        Some(ax) => sum_axis(a, ax),
    }
}

/// Sum all elements to a scalar
fn sum_all(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let total: f32 = data.iter().sum();
        return Tensor::from_slice(&[total], [], Device::Cpu);
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("sum_f32", shaders::SUM_F32)?;

    let n = a.numel();
    let workgroups = (n + 255) / 256;

    // Partial sums buffer
    let partial_buffer = GpuBuffer::new(device.clone(), workgroups * 4);

    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("sum_layout"),
                entries: &[storage_entry(0, true), storage_entry(1, false)],
            });

    let pipeline = cache.get_pipeline("sum_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: partial_buffer.raw().as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("sum_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("sum_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        pass.dispatch_workgroups(workgroups as u32, 1, 1);
    }

    device.submit_and_wait(encoder);

    // Read partial sums and finish on CPU
    let partial_data = partial_buffer.read()?;
    let partials: &[f32] = bytemuck::cast_slice(&partial_data);
    let total: f32 = partials.iter().sum();

    Tensor::from_slice(&[total], [], a.device())
}

/// Sum along a specific axis
fn sum_axis(a: &Tensor, axis: isize) -> VatraResult<Tensor> {
    let rank = a.ndim() as isize;
    let ax = if axis < 0 { rank + axis } else { axis };

    if ax < 0 || ax >= rank {
        return Err(VatraError::InvalidAxis {
            axis,
            rank: a.ndim(),
        });
    }
    let ax = ax as usize;

    // CPU fallback for axis reduction
    let data = a.to_vec()?;
    let shape = a.shape();
    let strides = shape.strides();

    // Calculate output shape
    let mut out_dims: Vec<usize> = shape.dims().to_vec();
    out_dims.remove(ax);
    let out_shape = if out_dims.is_empty() {
        Shape::scalar()
    } else {
        Shape::from(out_dims)
    };

    let mut result = vec![0.0f32; out_shape.numel()];
    let reduce_size = shape[ax];

    // Iterate over output positions
    for out_idx in 0..out_shape.numel() {
        let mut sum = 0.0f32;
        for r in 0..reduce_size {
            // Compute input index
            let mut in_idx = 0;
            let mut temp_out = out_idx;
            let out_strides = out_shape.strides();

            for d in 0..shape.rank() {
                if d == ax {
                    in_idx += r * strides[d];
                } else {
                    let out_d = if d < ax { d } else { d - 1 };
                    if out_d < out_strides.len() {
                        let coord = temp_out / out_strides[out_d];
                        temp_out %= out_strides[out_d];
                        in_idx += coord * strides[d];
                    }
                }
            }
            sum += data[in_idx];
        }
        result[out_idx] = sum;
    }

    Tensor::from_slice(&result, out_shape, a.device())
}

/// Mean reduction
pub fn mean(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    let s = sum(a, axis)?;
    let count = match axis {
        None => a.numel() as f32,
        Some(ax) => {
            let rank = a.ndim() as isize;
            let ax = if ax < 0 { rank + ax } else { ax };
            a.shape()[ax as usize] as f32
        }
    };
    let count_tensor = Tensor::full(s.shape().clone(), count, s.device())?;
    super::div(&s, &count_tensor)
}

/// Maximum value
pub fn max(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    // CPU implementation
    let data = a.to_vec()?;

    match axis {
        None => {
            let max_val = data.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
            Tensor::from_slice(&[max_val], [], a.device())
        }
        Some(ax) => {
            let rank = a.ndim() as isize;
            let ax = if ax < 0 { rank + ax } else { ax };
            if ax < 0 || ax >= rank {
                return Err(VatraError::InvalidAxis {
                    axis: ax,
                    rank: a.ndim(),
                });
            }
            // Similar to sum_axis but with max
            let shape = a.shape();
            let mut out_dims: Vec<usize> = shape.dims().to_vec();
            out_dims.remove(ax as usize);
            let out_shape = if out_dims.is_empty() {
                Shape::scalar()
            } else {
                Shape::from(out_dims)
            };

            let mut result = vec![f32::NEG_INFINITY; out_shape.numel()];
            let reduce_size = shape[ax as usize];
            let strides = shape.strides();
            let out_strides = out_shape.strides();

            for out_idx in 0..out_shape.numel() {
                for r in 0..reduce_size {
                    let mut in_idx = 0;
                    let mut temp_out = out_idx;
                    for d in 0..shape.rank() {
                        if d == ax as usize {
                            in_idx += r * strides[d];
                        } else {
                            let out_d = if d < ax as usize { d } else { d - 1 };
                            if out_d < out_strides.len() {
                                let coord = temp_out / out_strides[out_d];
                                temp_out %= out_strides[out_d];
                                in_idx += coord * strides[d];
                            }
                        }
                    }
                    result[out_idx] = result[out_idx].max(data[in_idx]);
                }
            }
            Tensor::from_slice(&result, out_shape, a.device())
        }
    }
}

/// Minimum value
pub fn min(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    let neg = super::neg(a)?;
    let max_neg = max(&neg, axis)?;
    super::neg(&max_neg)
}

/// Argmax (returns index of max value)
pub fn argmax(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    let data = a.to_vec()?;

    match axis {
        None => {
            let (idx, _) = data
                .iter()
                .enumerate()
                .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                .unwrap_or((0, &0.0));
            Tensor::from_slice(&[idx as f32], [], a.device())
        }
        Some(_) => {
            // Simplified: would need proper implementation
            Err(VatraError::Unsupported(
                "argmax with axis not yet implemented".into(),
            ))
        }
    }
}

// ========== Helper ==========

fn storage_entry(binding: u32, read_only: bool) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Storage { read_only },
            has_dynamic_offset: false,
            min_binding_size: None,
        },
        count: None,
    }
}
