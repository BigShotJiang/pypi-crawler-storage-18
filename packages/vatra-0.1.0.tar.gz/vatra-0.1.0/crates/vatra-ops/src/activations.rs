//! Activation functions

use vatra_core::{DType, Device, Shape, Tensor, VatraError, VatraResult};
use vatra_gpu::{shader::shaders, GpuBuffer, ShaderCache};

/// ReLU activation: max(0, x)
pub fn relu(a: &Tensor) -> VatraResult<Tensor> {
    if a.device().is_cpu() {
        let data = a.to_vec()?;
        let result: Vec<f32> = data.iter().map(|&x| x.max(0.0)).collect();
        return Tensor::from_slice(&result, a.shape().clone(), Device::Cpu);
    }

    let device = a.gpu_device()?;
    let cache = ShaderCache::new(device.clone());
    let module = cache.get_module("relu_f32", shaders::RELU_F32)?;

    let out_buffer = GpuBuffer::new(device.clone(), a.numel() * 4);

    let bind_group_layout =
        device
            .device
            .create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("relu_layout"),
                entries: &[storage_entry(0, true), storage_entry(1, false)],
            });

    let pipeline = cache.get_pipeline("relu_f32", &module, "main", &[&bind_group_layout]);

    let bind_group = device.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: None,
        layout: &bind_group_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: a.gpu_buffer().raw().as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: out_buffer.raw().as_entire_binding(),
            },
        ],
    });

    let mut encoder = device
        .device
        .create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("relu_encoder"),
        });

    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("relu_pass"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&pipeline);
        pass.set_bind_group(0, &bind_group, &[]);
        let workgroups = (a.numel() as u32 + 255) / 256;
        pass.dispatch_workgroups(workgroups, 1, 1);
    }

    device.submit_and_wait(encoder);

    Ok(Tensor::from_gpu_buffer(
        out_buffer,
        a.shape().clone(),
        DType::F32,
        a.device(),
    ))
}

/// Leaky ReLU: max(alpha * x, x)
pub fn leaky_relu(a: &Tensor, alpha: f32) -> VatraResult<Tensor> {
    let data = a.to_vec()?;
    let result: Vec<f32> = data
        .iter()
        .map(|&x| if x > 0.0 { x } else { alpha * x })
        .collect();
    Tensor::from_slice(&result, a.shape().clone(), a.device())
}

/// Sigmoid activation: 1 / (1 + exp(-x))
pub fn sigmoid(a: &Tensor) -> VatraResult<Tensor> {
    let data = a.to_vec()?;
    let result: Vec<f32> = data.iter().map(|&x| 1.0 / (1.0 + (-x).exp())).collect();
    Tensor::from_slice(&result, a.shape().clone(), a.device())
}

/// Tanh activation
pub fn tanh(a: &Tensor) -> VatraResult<Tensor> {
    let data = a.to_vec()?;
    let result: Vec<f32> = data.iter().map(|&x| x.tanh()).collect();
    Tensor::from_slice(&result, a.shape().clone(), a.device())
}

/// GELU activation (approximate)
pub fn gelu(a: &Tensor) -> VatraResult<Tensor> {
    let data = a.to_vec()?;
    let result: Vec<f32> = data
        .iter()
        .map(|&x| {
            0.5 * x
                * (1.0
                    + ((2.0_f32 / std::f32::consts::PI).sqrt() * (x + 0.044715 * x.powi(3))).tanh())
        })
        .collect();
    Tensor::from_slice(&result, a.shape().clone(), a.device())
}

/// Softmax over last dimension
pub fn softmax(a: &Tensor, dim: isize) -> VatraResult<Tensor> {
    let rank = a.ndim() as isize;
    let dim = if dim < 0 { rank + dim } else { dim };

    if dim < 0 || dim >= rank {
        return Err(VatraError::InvalidAxis {
            axis: dim,
            rank: a.ndim(),
        });
    }

    // For simplicity, only support last dimension
    if dim as usize != a.ndim() - 1 {
        return Err(VatraError::Unsupported(
            "softmax currently only supports last dimension".into(),
        ));
    }

    let data = a.to_vec()?;
    let shape = a.shape();
    let last_dim = shape[shape.rank() - 1];
    let batch_size = a.numel() / last_dim;

    let mut result = vec![0.0f32; a.numel()];

    for b in 0..batch_size {
        let start = b * last_dim;
        let end = start + last_dim;
        let slice = &data[start..end];

        // Numerical stability: subtract max
        let max_val = slice.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        let exp_sum: f32 = slice.iter().map(|&x| (x - max_val).exp()).sum();

        for (i, &x) in slice.iter().enumerate() {
            result[start + i] = (x - max_val).exp() / exp_sum;
        }
    }

    Tensor::from_slice(&result, shape.clone(), a.device())
}

/// Log softmax over last dimension
pub fn log_softmax(a: &Tensor, dim: isize) -> VatraResult<Tensor> {
    let sm = softmax(a, dim)?;
    super::log(&sm)
}

/// SiLU (Swish) activation: x * sigmoid(x)
pub fn silu(a: &Tensor) -> VatraResult<Tensor> {
    let sig = sigmoid(a)?;
    super::mul(a, &sig)
}

// ========== Helper ==========

fn storage_entry(binding: u32, read_only: bool) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::COMPUTE,
        ty: wgpu::BindingType::Buffer {
            ty: wgpu::BufferBindingType::Storage { read_only },
            has_dynamic_offset: false,
            min_binding_size: None,
        },
        count: None,
    }
}
