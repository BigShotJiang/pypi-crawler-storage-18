//! Python bindings for Vatra neural network library
//!
//! PyTorch-like API:
//! ```python
//! import vatra
//!
//! model = vatra.Sequential(
//!     vatra.Linear(784, 256),
//!     vatra.ReLU(),
//!     vatra.Linear(256, 10),
//! )
//! ```

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyModule as PyModuleType;
use pyo3::types::PyTuple;
use std::sync::{Arc, RwLock};

use ::vatra::prelude::*;
use ::vatra::{Conv2d, Embedding};
use ::vatra_core::{load_safetensors as rust_load, save_safetensors as rust_save, StateDict};

// ==================== Tensor ====================

#[pyclass(name = "Tensor", module = "vatra")]
#[derive(Clone)]
pub struct PyTensor {
    pub inner: Tensor,
}

#[pymethods]
impl PyTensor {
    #[new]
    #[pyo3(signature = (data, shape=None, device=None))]
    fn new(data: Vec<f32>, shape: Option<Vec<usize>>, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let sh = shape.unwrap_or_else(|| vec![data.len()]);
        let tensor =
            Tensor::from_slice(&data, sh, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: tensor })
    }

    #[staticmethod]
    #[pyo3(signature = (shape, device=None))]
    fn zeros(shape: Vec<usize>, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let tensor = Tensor::zeros(shape, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: tensor })
    }

    #[staticmethod]
    #[pyo3(signature = (shape, device=None))]
    fn ones(shape: Vec<usize>, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let tensor = Tensor::ones(shape, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: tensor })
    }

    #[staticmethod]
    #[pyo3(signature = (shape, device=None))]
    fn randn(shape: Vec<usize>, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let tensor = Tensor::randn(shape, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: tensor })
    }

    #[staticmethod]
    #[pyo3(signature = (shape, device=None))]
    fn rand(shape: Vec<usize>, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let tensor = Tensor::rand(shape, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: tensor })
    }

    fn __repr__(&self) -> String {
        format!(
            "Tensor(shape={:?}, device={})",
            self.inner.shape().dims(),
            self.inner.device()
        )
    }

    fn __str__(&self) -> String {
        format!("{}", self.inner)
    }

    #[getter]
    fn shape(&self) -> Vec<usize> {
        self.inner.shape().dims().to_vec()
    }

    #[getter]
    fn device(&self) -> String {
        self.inner.device().to_string()
    }

    #[getter]
    fn ndim(&self) -> usize {
        self.inner.shape().dims().len()
    }

    #[getter]
    fn numel(&self) -> usize {
        self.inner.shape().numel()
    }

    fn to_list(&self) -> PyResult<Vec<f32>> {
        self.inner
            .to_vec()
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn item(&self) -> PyResult<f32> {
        self.inner
            .item()
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn clone_tensor(&self) -> Self {
        Self {
            inner: self.inner.clone(),
        }
    }

    // Operators
    fn __add__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            add(&self.inner, &other_tensor).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __radd__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        self.__add__(other)
    }

    fn __sub__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            sub(&self.inner, &other_tensor).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __rsub__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            sub(&other_tensor, &self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __mul__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            mul(&self.inner, &other_tensor).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __rmul__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        self.__mul__(other)
    }

    fn __truediv__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            div(&self.inner, &other_tensor).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __rtruediv__(&self, other: &Bound<'_, PyAny>) -> PyResult<PyTensor> {
        let other_tensor = parse_other(other, &self.inner.device())?;
        let res =
            div(&other_tensor, &self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __matmul__(&self, other: &PyTensor) -> PyResult<PyTensor> {
        let res =
            matmul(&self.inner, &other.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __neg__(&self) -> PyResult<PyTensor> {
        let res = neg(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn __pow__(&self, exp: f32, _modulo: Option<i32>) -> PyResult<PyTensor> {
        // x^2 = x * x for now
        if exp == 2.0 {
            let res =
                mul(&self.inner, &self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
            Ok(Self { inner: res })
        } else {
            Err(PyValueError::new_err("Only power of 2 supported for now"))
        }
    }

    // Methods
    fn relu(&self) -> PyResult<PyTensor> {
        let res = relu(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn sigmoid(&self) -> PyResult<PyTensor> {
        let res = sigmoid(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn tanh(&self) -> PyResult<PyTensor> {
        let res = tanh(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn exp(&self) -> PyResult<PyTensor> {
        let res = exp(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn log(&self) -> PyResult<PyTensor> {
        let res = log(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn sqrt(&self) -> PyResult<PyTensor> {
        let res = sqrt(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn abs(&self) -> PyResult<PyTensor> {
        let res = abs(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn sum(&self) -> PyResult<PyTensor> {
        let res = ::vatra::prelude::sum(&self.inner, None)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn mean(&self) -> PyResult<PyTensor> {
        let res = mean(&self.inner, None).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn max(&self) -> PyResult<PyTensor> {
        let res = max(&self.inner, None).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn min(&self) -> PyResult<PyTensor> {
        let res = min(&self.inner, None).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn t(&self) -> PyResult<PyTensor> {
        let res = transpose(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }

    fn softmax(&self) -> PyResult<PyTensor> {
        let res = ::vatra::prelude::softmax(&self.inner, -1)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: res })
    }
}

fn parse_device(device: Option<String>) -> PyResult<Device> {
    match device.as_deref() {
        None => Ok(::vatra::prelude::get_default_device()),
        Some("cpu") => Ok(Device::Cpu),
        Some("cuda") | Some("gpu") | Some("vulkan") => Ok(Device::Vulkan(0)),
        Some(s) if s.starts_with("cuda:") || s.starts_with("vulkan:") => {
            if let Some(idx_str) = s.split(':').nth(1) {
                let idx = idx_str
                    .parse::<usize>()
                    .map_err(|_| PyValueError::new_err("Invalid device index"))?;
                Ok(Device::Vulkan(idx))
            } else {
                Ok(Device::Vulkan(0))
            }
        }
        _ => Err(PyValueError::new_err(
            "Unknown device. Use 'cpu', 'cuda', 'cuda:0', etc.",
        )),
    }
}

fn parse_other(obj: &Bound<'_, PyAny>, device: &Device) -> PyResult<Tensor> {
    if let Ok(t) = obj.extract::<PyRef<PyTensor>>() {
        Ok(t.inner.clone())
    } else if let Ok(val) = obj.extract::<f32>() {
        Ok(
            Tensor::from_slice(&[val], vatra_core::Shape::from(vec![1]), device.clone())
                .map_err(|e| PyValueError::new_err(e.to_string()))?,
        )
    } else if let Ok(val) = obj.extract::<i32>() {
        Ok(Tensor::from_slice(
            &[val as f32],
            vatra_core::Shape::from(vec![1]),
            device.clone(),
        )
        .map_err(|e| PyValueError::new_err(e.to_string()))?)
    } else {
        Err(PyValueError::new_err("Unsupported type for operation"))
    }
}

// ==================== Module Trait ====================

trait PyModule: Send + Sync {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor>;
    fn parameters(&self) -> Vec<Tensor>;
    fn name(&self) -> &'static str;
}

// ==================== NN Layers ====================

#[pyclass(name = "Linear", module = "vatra.nn")]
#[derive(Clone)]
struct PyLinear {
    inner: Linear,
}

#[pymethods]
impl PyLinear {
    #[new]
    #[pyo3(signature = (in_features, out_features, bias=true, device=None))]
    fn new(
        in_features: usize,
        out_features: usize,
        bias: bool,
        device: Option<String>,
    ) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let linear = Linear::new(in_features, out_features, bias, dev)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: linear })
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        let res = self
            .inner
            .forward(&x.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        format!(
            "Linear(in_features={}, out_features={}, bias={})",
            self.inner.in_features(),
            self.inner.out_features(),
            self.inner.bias.is_some()
        )
    }

    fn parameters(&self) -> Vec<PyTensor> {
        self.inner
            .parameters()
            .into_iter()
            .map(|t| PyTensor { inner: t })
            .collect()
    }

    #[getter]
    fn weight(&self) -> PyTensor {
        PyTensor {
            inner: self.inner.weight.clone(),
        }
    }

    #[getter]
    fn bias(&self) -> Option<PyTensor> {
        self.inner
            .bias
            .as_ref()
            .map(|b| PyTensor { inner: b.clone() })
    }
}

impl PyModule for PyLinear {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        self.inner.forward(x)
    }
    fn parameters(&self) -> Vec<Tensor> {
        self.inner.parameters()
    }
    fn name(&self) -> &'static str {
        "Linear"
    }
}

#[pyclass(name = "ReLU", module = "vatra.nn")]
#[derive(Clone)]
struct PyReLU;

#[pymethods]
impl PyReLU {
    #[new]
    fn new() -> Self {
        Self
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        x.relu()
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        "ReLU()".to_string()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        vec![]
    }
}

#[pyclass(name = "Sigmoid", module = "vatra.nn")]
#[derive(Clone)]
struct PySigmoid;

#[pymethods]
impl PySigmoid {
    #[new]
    fn new() -> Self {
        Self
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        x.sigmoid()
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        "Sigmoid()".to_string()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        vec![]
    }
}

#[pyclass(name = "Tanh", module = "vatra.nn")]
#[derive(Clone)]
struct PyTanh;

#[pymethods]
impl PyTanh {
    #[new]
    fn new() -> Self {
        Self
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        x.tanh()
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        "Tanh()".to_string()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        vec![]
    }
}

#[pyclass(name = "Softmax", module = "vatra.nn")]
#[derive(Clone)]
struct PySoftmax;

#[pymethods]
impl PySoftmax {
    #[new]
    fn new() -> Self {
        Self
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        x.softmax()
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        "Softmax()".to_string()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        vec![]
    }
}

#[pyclass(name = "Flatten", module = "vatra.nn")]
#[derive(Clone)]
struct PyFlatten;

#[pymethods]
impl PyFlatten {
    #[new]
    fn new() -> Self {
        Self
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        // Just return as-is for now
        Ok(x.clone())
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        "Flatten()".to_string()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        vec![]
    }
}

// ==================== Conv2d ====================

#[pyclass(name = "Conv2d", module = "vatra")]
#[derive(Clone)]
struct PyConv2d {
    inner: Conv2d,
}

#[pymethods]
impl PyConv2d {
    #[new]
    #[pyo3(signature = (in_channels, out_channels, kernel_size, stride=1, padding=0, bias=true, device=None))]
    fn new(
        in_channels: usize,
        out_channels: usize,
        kernel_size: usize,
        stride: usize,
        padding: usize,
        bias: bool,
        device: Option<String>,
    ) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let conv = Conv2d::new(
            in_channels,
            out_channels,
            (kernel_size, kernel_size),
            (stride, stride),
            (padding, padding),
            bias,
            dev,
        )
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: conv })
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        let res = self
            .inner
            .forward(&x.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        format!(
            "Conv2d(in_channels={}, out_channels={}, kernel_size={:?}, stride={:?}, padding={:?})",
            self.inner.weight.shape()[1],
            self.inner.weight.shape()[0],
            (self.inner.weight.shape()[2], self.inner.weight.shape()[3]),
            self.inner.stride,
            self.inner.padding
        )
    }

    fn parameters(&self) -> Vec<PyTensor> {
        self.inner
            .parameters()
            .into_iter()
            .map(|t| PyTensor { inner: t })
            .collect()
    }
}

// ==================== Embedding ====================

#[pyclass(name = "Embedding", module = "vatra")]
#[derive(Clone)]
struct PyEmbedding {
    inner: Embedding,
}

#[pymethods]
impl PyEmbedding {
    #[new]
    #[pyo3(signature = (num_embeddings, embedding_dim, device=None))]
    fn new(num_embeddings: usize, embedding_dim: usize, device: Option<String>) -> PyResult<Self> {
        let dev = parse_device(device)?;
        let emb = Embedding::new(num_embeddings, embedding_dim, dev)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner: emb })
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        let res = self
            .inner
            .forward(&x.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyTensor { inner: res })
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        format!(
            "Embedding({}, {})",
            self.inner.num_embeddings, self.inner.embedding_dim
        )
    }

    fn parameters(&self) -> Vec<PyTensor> {
        self.inner
            .parameters()
            .into_iter()
            .map(|t| PyTensor { inner: t })
            .collect()
    }

    #[getter]
    fn weight(&self) -> PyTensor {
        PyTensor {
            inner: self.inner.weight.clone(),
        }
    }

    #[getter]
    fn num_embeddings(&self) -> usize {
        self.inner.num_embeddings
    }

    #[getter]
    fn embedding_dim(&self) -> usize {
        self.inner.embedding_dim
    }
}

// ==================== Sequential ====================

enum Layer {
    Linear(Linear),
    Conv2d(Conv2d),
    Embedding(Embedding),
    ReLU,
    Sigmoid,
    Tanh,
    Softmax,
    Flatten,
}

impl Layer {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        match self {
            Layer::Linear(l) => l.forward(x),
            Layer::Conv2d(c) => c.forward(x),
            Layer::Embedding(e) => e.forward(x),
            Layer::ReLU => relu(x),
            Layer::Sigmoid => sigmoid(x),
            Layer::Tanh => tanh(x),
            Layer::Softmax => ::vatra::prelude::softmax(x, -1),
            Layer::Flatten => Ok(x.clone()),
        }
    }

    fn parameters(&self) -> Vec<Tensor> {
        match self {
            Layer::Linear(l) => l.parameters(),
            Layer::Conv2d(c) => c.parameters(),
            Layer::Embedding(e) => e.parameters(),
            _ => vec![],
        }
    }

    fn repr(&self) -> String {
        match self {
            Layer::Linear(l) => format!(
                "Linear(in_features={}, out_features={}, bias={})",
                l.in_features(),
                l.out_features(),
                l.bias.is_some()
            ),
            Layer::Conv2d(c) => {
                format!("Conv2d({} -> {})", c.weight.shape()[1], c.weight.shape()[0])
            }
            Layer::Embedding(e) => format!("Embedding({}, {})", e.num_embeddings, e.embedding_dim),
            Layer::ReLU => "ReLU()".to_string(),
            Layer::Sigmoid => "Sigmoid()".to_string(),
            Layer::Tanh => "Tanh()".to_string(),
            Layer::Softmax => "Softmax()".to_string(),
            Layer::Flatten => "Flatten()".to_string(),
        }
    }
}

#[pyclass(name = "Sequential", module = "vatra.nn")]
struct PySequential {
    layers: Arc<RwLock<Vec<Layer>>>,
}

#[pymethods]
impl PySequential {
    #[new]
    #[pyo3(signature = (*args))]
    fn new(args: &Bound<'_, PyTuple>) -> PyResult<Self> {
        let seq = Self {
            layers: Arc::new(RwLock::new(Vec::new())),
        };

        for arg in args.iter() {
            seq.add_layer_from_py(&arg)?;
        }

        Ok(seq)
    }

    fn add(&self, layer: &Bound<'_, PyAny>) -> PyResult<()> {
        self.add_layer_from_py(layer)
    }

    fn forward(&self, x: &PyTensor) -> PyResult<PyTensor> {
        let layers = self.layers.read().unwrap();
        let mut current = x.inner.clone();
        for layer in layers.iter() {
            current = layer
                .forward(&current)
                .map_err(|e| PyValueError::new_err(e.to_string()))?;
        }
        Ok(PyTensor { inner: current })
    }

    fn __call__(&self, x: &PyTensor) -> PyResult<PyTensor> {
        self.forward(x)
    }

    fn __repr__(&self) -> String {
        let layers = self.layers.read().unwrap();
        let mut s = "Sequential(\n".to_string();
        for (i, layer) in layers.iter().enumerate() {
            s.push_str(&format!("  ({}) {}\n", i, layer.repr()));
        }
        s.push_str(")");
        s
    }

    fn __len__(&self) -> usize {
        self.layers.read().unwrap().len()
    }

    fn parameters(&self) -> Vec<PyTensor> {
        let layers = self.layers.read().unwrap();
        let mut params = Vec::new();
        for layer in layers.iter() {
            for p in layer.parameters() {
                params.push(PyTensor { inner: p });
            }
        }
        params
    }
}

impl PySequential {
    fn add_layer_from_py(&self, layer: &Bound<'_, PyAny>) -> PyResult<()> {
        let mut layers = self.layers.write().unwrap();

        if let Ok(linear) = layer.extract::<PyLinear>() {
            layers.push(Layer::Linear(linear.inner.clone()));
        } else if layer.extract::<PyReLU>().is_ok() {
            layers.push(Layer::ReLU);
        } else if layer.extract::<PySigmoid>().is_ok() {
            layers.push(Layer::Sigmoid);
        } else if layer.extract::<PyTanh>().is_ok() {
            layers.push(Layer::Tanh);
        } else if layer.extract::<PySoftmax>().is_ok() {
            layers.push(Layer::Softmax);
        } else if layer.extract::<PyFlatten>().is_ok() {
            layers.push(Layer::Flatten);
        } else {
            return Err(PyValueError::new_err("Unknown layer type"));
        }

        Ok(())
    }
}

// ==================== Optimizers ====================

#[pyclass(name = "SGD", module = "vatra.optim")]
struct PySGD {
    inner: SGD,
}

#[pymethods]
impl PySGD {
    #[new]
    #[pyo3(signature = (params, lr=0.01, momentum=0.0, weight_decay=0.0))]
    fn new(params: Vec<PyTensor>, lr: f32, momentum: f32, weight_decay: f32) -> Self {
        let tensors: Vec<Tensor> = params.into_iter().map(|p| p.inner).collect();
        let mut sgd = SGD::new(tensors, lr);
        if momentum > 0.0 {
            sgd = sgd.momentum(momentum);
        }
        if weight_decay > 0.0 {
            sgd = sgd.weight_decay(weight_decay);
        }
        Self { inner: sgd }
    }

    fn step(&mut self, gradients: Vec<PyTensor>) -> PyResult<()> {
        let grads: Vec<Tensor> = gradients.into_iter().map(|g| g.inner).collect();
        self.inner
            .step(&grads)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn zero_grad(&mut self) {
        self.inner.zero_grad();
    }

    fn __repr__(&self) -> String {
        format!("SGD(lr={})", self.inner.lr())
    }
}

#[pyclass(name = "Adam", module = "vatra.optim")]
struct PyAdam {
    inner: Adam,
}

#[pymethods]
impl PyAdam {
    #[new]
    #[pyo3(signature = (params, lr=0.001, betas=(0.9, 0.999), weight_decay=0.0))]
    fn new(params: Vec<PyTensor>, lr: f32, betas: (f32, f32), weight_decay: f32) -> Self {
        let tensors: Vec<Tensor> = params.into_iter().map(|p| p.inner).collect();
        let mut adam = Adam::new(tensors, lr).betas(betas.0, betas.1);
        if weight_decay > 0.0 {
            adam = adam.weight_decay(weight_decay);
        }
        Self { inner: adam }
    }

    fn step(&mut self, gradients: Vec<PyTensor>) -> PyResult<()> {
        let grads: Vec<Tensor> = gradients.into_iter().map(|g| g.inner).collect();
        self.inner
            .step(&grads)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn zero_grad(&mut self) {
        self.inner.zero_grad();
    }

    fn __repr__(&self) -> String {
        format!("Adam(lr={})", self.inner.lr())
    }
}

#[pyclass(name = "AdamW", module = "vatra.optim")]
struct PyAdamW {
    inner: AdamW,
}

#[pymethods]
impl PyAdamW {
    #[new]
    #[pyo3(signature = (params, lr=0.001, betas=(0.9, 0.999), weight_decay=0.01))]
    fn new(params: Vec<PyTensor>, lr: f32, betas: (f32, f32), weight_decay: f32) -> Self {
        let tensors: Vec<Tensor> = params.into_iter().map(|p| p.inner).collect();
        let adam = AdamW::new(tensors, lr)
            .betas(betas.0, betas.1)
            .weight_decay(weight_decay);
        Self { inner: adam }
    }

    fn step(&mut self, gradients: Vec<PyTensor>) -> PyResult<()> {
        let grads: Vec<Tensor> = gradients.into_iter().map(|g| g.inner).collect();
        self.inner
            .step(&grads)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn zero_grad(&mut self) {
        self.inner.zero_grad();
    }

    fn __repr__(&self) -> String {
        format!("AdamW(lr={})", self.inner.lr())
    }
}

// ==================== Functional ====================

#[pyfunction]
fn mse_loss(pred: &PyTensor, target: &PyTensor) -> PyResult<PyTensor> {
    let diff = sub(&pred.inner, &target.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let sq = mul(&diff, &diff).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let loss =
        ::vatra::prelude::sum(&sq, None).map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(PyTensor { inner: loss })
}

#[pyfunction]
fn cross_entropy_loss(pred: &PyTensor, target: &PyTensor) -> PyResult<PyTensor> {
    // Simplified CE loss
    mse_loss(pred, target)
}

#[pyfunction]
fn l1_loss(pred: &PyTensor, target: &PyTensor) -> PyResult<PyTensor> {
    let diff = sub(&pred.inner, &target.inner).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let abs_diff = abs(&diff).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let loss =
        ::vatra::prelude::sum(&abs_diff, None).map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(PyTensor { inner: loss })
}

#[pyfunction]
#[pyo3(name = "sum", signature = (input, dim=None))]
fn py_sum(input: &PyTensor, dim: Option<isize>) -> PyResult<PyTensor> {
    let res = ::vatra::prelude::sum(&input.inner, dim)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(PyTensor { inner: res })
}

#[pyfunction]
#[pyo3(name = "softmax", signature = (input, dim=-1))]
fn py_softmax(input: &PyTensor, dim: isize) -> PyResult<PyTensor> {
    let res = ::vatra::prelude::softmax(&input.inner, dim)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(PyTensor { inner: res })
}

// ==================== Autograd ====================

#[pyclass]
struct PyValueAndGradFn {
    f: PyObject,
}

#[pymethods]
impl PyValueAndGradFn {
    #[pyo3(signature = (*args))]
    fn __call__(
        &self,
        py: Python<'_>,
        args: &Bound<'_, PyTuple>,
    ) -> PyResult<(PyTensor, Vec<PyTensor>)> {
        // Convert args to Tensors
        let mut tensors = Vec::with_capacity(args.len());
        for arg in args.iter() {
            let t: PyRef<PyTensor> = arg.extract()?;
            tensors.push(t.inner.clone());
        }

        // Define closure for autograd
        let f_obj = self.f.clone_ref(py);
        let closure = move |params: &[Tensor]| -> VatraResult<Tensor> {
            // Call Python function
            Python::with_gil(|py| {
                // Convert params back to PyTensors
                let py_args_vec: Vec<PyObject> = params
                    .iter()
                    .map(|t| {
                        Bound::new(py, PyTensor { inner: t.clone() })
                            .unwrap()
                            .into_any()
                            .unbind()
                    })
                    .collect();
                let py_args =
                    PyTuple::new(py, py_args_vec).map_err(|e| VatraError::Custom(e.to_string()))?;

                // Call the python function
                let result = f_obj
                    .call1(py, py_args)
                    .map_err(|e| VatraError::Custom(e.to_string()))?;

                // Extract result tensor
                let py_tensor: PyRef<PyTensor> = result
                    .extract(py)
                    .map_err(|e| VatraError::Custom(e.to_string()))?;
                Ok(py_tensor.inner.clone())
            })
        };

        // Compute value and grad
        let grad_fn = ::vatra::autograd::value_and_grad_multi(closure);
        let (val, grads) = grad_fn(&tensors).map_err(|e| PyValueError::new_err(e.to_string()))?;

        // Convert back to Python
        let py_val = PyTensor { inner: val };
        let py_grads = grads.into_iter().map(|t| PyTensor { inner: t }).collect();

        Ok((py_val, py_grads))
    }
}

#[pyfunction]
#[pyo3(name = "value_and_grad")]
fn py_value_and_grad(py: Python<'_>, f: PyObject) -> PyResult<PyObject> {
    let grad_fn = PyValueAndGradFn { f };
    Ok(Bound::new(py, grad_fn)?.into_any().into())
}

// ==================== Save/Load ====================

/// Save model weights to safetensors file
#[pyfunction]
#[pyo3(signature = (state_dict, path))]
fn save(state_dict: std::collections::HashMap<String, PyTensor>, path: String) -> PyResult<()> {
    let sd: StateDict = state_dict.into_iter().map(|(k, v)| (k, v.inner)).collect();
    rust_save(&sd, &path, None).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Load model weights from safetensors file
#[pyfunction]
#[pyo3(signature = (path, device=None))]
fn load(
    path: String,
    device: Option<String>,
) -> PyResult<std::collections::HashMap<String, PyTensor>> {
    let dev = parse_device(device)?;
    let (sd, _meta) = rust_load(&path, dev).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let result: std::collections::HashMap<String, PyTensor> = sd
        .into_iter()
        .map(|(k, v)| (k, PyTensor { inner: v }))
        .collect();
    Ok(result)
}

/// Get vatra version
#[pyfunction]
fn version() -> String {
    format!("{}", env!("CARGO_PKG_VERSION"))
}

// ==================== Module Registration ====================

#[pymodule]
fn vatra(m: &Bound<'_, PyModuleType>) -> PyResult<()> {
    // Core Tensor
    m.add_class::<PyTensor>()?;

    // NN layers
    m.add_class::<PyLinear>()?;
    m.add_class::<PyConv2d>()?;
    m.add_class::<PyEmbedding>()?;
    m.add_class::<PyReLU>()?;
    m.add_class::<PySigmoid>()?;
    m.add_class::<PyTanh>()?;
    m.add_class::<PySoftmax>()?;
    m.add_class::<PyFlatten>()?;
    m.add_class::<PySequential>()?;

    // Optimizers
    m.add_class::<PySGD>()?;
    m.add_class::<PyAdam>()?;
    m.add_class::<PyAdamW>()?;

    // Loss functions
    m.add_function(wrap_pyfunction!(mse_loss, m)?)?;
    m.add_function(wrap_pyfunction!(cross_entropy_loss, m)?)?;
    m.add_function(wrap_pyfunction!(l1_loss, m)?)?;
    m.add_function(wrap_pyfunction!(py_sum, m)?)?;
    m.add_function(wrap_pyfunction!(py_softmax, m)?)?;

    // Save/Load
    m.add_function(wrap_pyfunction!(save, m)?)?;
    m.add_function(wrap_pyfunction!(load, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;

    // Autograd
    m.add_function(wrap_pyfunction!(py_value_and_grad, m)?)?;

    // Device management
    #[pyfn(m)]
    fn cuda_is_available() -> bool {
        Device::cuda_is_available()
    }

    #[pyfn(m)]
    fn is_available() -> bool {
        Device::cuda_is_available()
    }

    #[pyfn(m)]
    fn device_count() -> usize {
        Device::device_count()
    }

    #[pyfn(m)]
    #[pyo3(name = "set_default_device")]
    fn py_set_default_device(device: String) -> PyResult<()> {
        let dev = match device.as_str() {
            "cpu" => Device::Cpu,
            "auto" => Device::auto(),
            "cuda" | "gpu" | "vulkan" => Device::Vulkan(0),
            s if s.starts_with("cuda:") || s.starts_with("vulkan:") => {
                if let Some(idx_str) = s.split(':').nth(1) {
                    let idx = idx_str
                        .parse::<usize>()
                        .map_err(|_| PyValueError::new_err("Invalid device index"))?;
                    Device::Vulkan(idx)
                } else {
                    Device::Vulkan(0)
                }
            }
            _ => return Err(PyValueError::new_err("Unknown device")),
        };
        ::vatra::prelude::set_default_device(dev);
        Ok(())
    }

    #[pyfn(m)]
    fn get_default_device() -> String {
        ::vatra::prelude::get_default_device().to_string()
    }

    Ok(())
}
