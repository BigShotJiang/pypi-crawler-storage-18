//! # Vatra — Vulkan Neural Network Library
//!
//! **PyTorch's ergonomics + JAX's philosophy**, powered by Vulkan via wgpu.
//!
//! ## Quick Start
//!
//! ```ignore
//! use vatra::prelude::*;
//!
//! // Create tensors
//! let x = Tensor::randn([32, 784], Device::Vulkan(0))?;
//!
//! // Build a simple MLP
//! let model = Sequential::new()
//!     .add(Linear::new(784, 256, true, Device::Vulkan(0))?)
//!     .add(ReLU)
//!     .add(Linear::new(256, 10, true, Device::Vulkan(0))?);
//!
//! // Forward pass
//! let out = model.forward(&x)?;
//!
//! // JAX-style gradients
//! let loss_fn = |x: &Tensor| ops::sum(x, None);
//! let grad_fn = grad(loss_fn);
//! let gradient = grad_fn(&out)?;
//! ```
//!
//! ## Modules
//!
//! - [`core`] — Tensor, Device, Shape, DType
//! - [`ops`] — Element-wise, linear algebra, reductions, activations
//! - [`autograd`] — grad(), vmap(), scan(), JIT
//! - [`nn`] — Linear, Conv2d, Embedding, BatchNorm, Sequential
//! - [`optim`] — SGD, Adam, AdamW

// Re-export all crates
pub use vatra_autograd as autograd;
pub use vatra_core as core;
pub use vatra_gpu as gpu;
pub use vatra_nn as nn;
pub use vatra_ops as ops;
pub use vatra_optim as optim;

// Convenient re-exports at top level
pub use vatra_autograd::{grad, scan, value_and_grad, vmap};
pub use vatra_core::{
    CheckpointMetadata, DType, Device, Shape, StateDict, Tensor, VATRA_FORMAT_VERSION, VatraError,
    VatraResult, get_default_device, load_checkpoint, load_safetensors, save_checkpoint,
    save_safetensors, set_default_device, with_device,
};
pub use vatra_nn::{
    Conv2d, Dropout, Embedding, Linear, Module, ReLU, Sequential, Sigmoid, Softmax,
};
pub use vatra_optim::{Adam, AdamW, Optimizer, SGD};

/// Prelude — import everything commonly needed
pub mod prelude {
    // Core types
    pub use vatra_core::{
        DType, Device, Shape, Tensor, VatraError, VatraResult, get_default_device,
        set_default_device, with_device,
    };

    // Serialization
    pub use vatra_core::{
        CheckpointMetadata, StateDict, VATRA_FORMAT_VERSION, load_checkpoint, load_safetensors,
        save_checkpoint, save_safetensors,
    };

    // Operations
    pub use vatra_autograd::ops::{
        add, div, exp, log, matmul, max, mean, mul, neg, relu, sigmoid, softmax, sub, sum, tanh,
        transpose,
    };
    pub use vatra_ops::{abs, argmax, dot, gelu, log_softmax, min, outer, sqrt};

    // Autograd
    pub use vatra_autograd::{grad, scan, value_and_grad, vmap};

    // Neural network
    pub use vatra_nn::{
        BatchNorm1d, BatchNorm2d, Conv1d, Conv2d, Dropout, Dropout2d, Embedding, F, GELU,
        LayerNorm, LeakyReLU, Linear, Module, ReLU, Sequential, Sigmoid, Softmax, Tanh,
    };

    // Optimizers
    pub use vatra_optim::{Adam, AdamW, Optimizer, SGD};
}
