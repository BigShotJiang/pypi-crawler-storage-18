//! Computation tape for reverse-mode autodiff

use parking_lot::RwLock;
use smallvec::SmallVec;
use std::sync::Arc;
use vatra_core::Tensor;

/// Global tape for gradient computation
thread_local! {
    static TAPE: RwLock<Option<Tape>> = RwLock::new(None);
}

/// Operation types for backward pass
#[derive(Debug, Clone)]
pub enum Op {
    // Binary ops
    Add { a: usize, b: usize },
    Mul { a: usize, b: usize },
    Sub { a: usize, b: usize },
    Div { a: usize, b: usize },
    Matmul { a: usize, b: usize },

    // Unary ops
    Neg { input: usize },
    Exp { input: usize },
    Log { input: usize },
    Relu { input: usize },
    Sigmoid { input: usize },
    Tanh { input: usize },
    Softmax { input: usize, dim: isize },
    Transpose { input: usize },

    // Reductions
    Sum { input: usize, shape: Vec<usize> },
    Mean { input: usize, shape: Vec<usize> },

    // Input (no gradient needed from this)
    Input,
}

/// Entry in the computation tape
#[derive(Debug, Clone)]
pub struct TapeEntry {
    /// The output tensor (with cached value for backward)
    pub output: Tensor,
    /// The operation that produced this tensor
    pub op: Op,
    /// Indices of input tensors in the tape
    pub inputs: SmallVec<[usize; 2]>,
}

use std::collections::HashMap;

/// Computation tape recording operations for autodiff
pub struct Tape {
    /// Recorded operations
    entries: Vec<TapeEntry>,
    /// Map from Tensor ID to tape index
    tensor_id_to_idx: HashMap<usize, usize>,
    /// Whether recording is active
    recording: bool,
}

impl Tape {
    /// Create a new empty tape
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
            tensor_id_to_idx: HashMap::new(),
            recording: true,
        }
    }

    /// Start recording operations
    pub fn start() {
        TAPE.with(|t| {
            *t.write() = Some(Tape::new());
        });
    }

    /// Stop recording and return the tape
    pub fn stop() -> Option<Tape> {
        TAPE.with(|t| t.write().take())
    }

    /// Check if tape is actively recording
    pub fn is_recording() -> bool {
        TAPE.with(|t| {
            t.read()
                .as_ref()
                .map(|tape| tape.recording)
                .unwrap_or(false)
        })
    }

    /// Record a tensor as input
    pub fn record_input(tensor: Tensor) -> usize {
        TAPE.with(|t| {
            let mut guard = t.write();
            if let Some(tape) = guard.as_mut() {
                if let Some(&idx) = tape.tensor_id_to_idx.get(&tensor.id()) {
                    return idx;
                }
                let idx = tape.entries.len();
                tape.tensor_id_to_idx.insert(tensor.id(), idx);
                tape.entries.push(TapeEntry {
                    output: tensor,
                    op: Op::Input,
                    inputs: SmallVec::new(),
                });
                idx
            } else {
                0 // Not recording
            }
        })
    }

    /// Record an operation
    pub fn record_op(output: Tensor, op: Op, inputs: &[usize]) -> usize {
        TAPE.with(|t| {
            let mut guard = t.write();
            if let Some(tape) = guard.as_mut() {
                let idx = tape.entries.len();
                tape.tensor_id_to_idx.insert(output.id(), idx);
                tape.entries.push(TapeEntry {
                    output,
                    op,
                    inputs: SmallVec::from_slice(inputs),
                });
                idx
            } else {
                0
            }
        })
    }

    /// Get tape index for a tensor ID
    pub fn get_index(tensor_id: usize) -> Option<usize> {
        TAPE.with(|t| {
            t.read()
                .as_ref()
                .and_then(|tape| tape.tensor_id_to_idx.get(&tensor_id).copied())
        })
    }

    /// Get tape entries
    pub fn entries(&self) -> &[TapeEntry] {
        &self.entries
    }

    /// Number of entries
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Check if empty
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Backward pass: compute gradients
    pub fn backward(&self, output_idx: usize) -> Vec<Option<Tensor>> {
        let n = self.entries.len();
        let mut grads: Vec<Option<Tensor>> = vec![None; n];

        // Initialize output gradient as ones
        let output = &self.entries[output_idx].output;
        grads[output_idx] = Some(
            Tensor::ones(output.shape().clone(), output.device())
                .expect("Failed to create gradient tensor"),
        );

        // Backward pass in reverse order
        for i in (0..=output_idx).rev() {
            let grad = match &grads[i] {
                Some(g) => g.clone(),
                None => continue,
            };

            let entry = &self.entries[i];

            match &entry.op {
                Op::Add { a, b } => {
                    // d/da (a + b) = 1, d/db (a + b) = 1
                    accumulate_grad(&mut grads, *a, &grad);
                    accumulate_grad(&mut grads, *b, &grad);
                }
                Op::Mul { a, b } => {
                    // d/da (a * b) = b, d/db (a * b) = a
                    let a_tensor = &self.entries[*a].output;
                    let b_tensor = &self.entries[*b].output;

                    if let Ok(grad_a) = vatra_ops::mul(&grad, b_tensor) {
                        accumulate_grad(&mut grads, *a, &grad_a);
                    }
                    if let Ok(grad_b) = vatra_ops::mul(&grad, a_tensor) {
                        accumulate_grad(&mut grads, *b, &grad_b);
                    }
                }
                Op::Sub { a, b } => {
                    accumulate_grad(&mut grads, *a, &grad);
                    if let Ok(neg_grad) = vatra_ops::neg(&grad) {
                        accumulate_grad(&mut grads, *b, &neg_grad);
                    }
                }
                Op::Neg { input } => {
                    if let Ok(neg_grad) = vatra_ops::neg(&grad) {
                        accumulate_grad(&mut grads, *input, &neg_grad);
                    }
                }
                Op::Relu { input } => {
                    // d/dx relu(x) = 1 if x > 0 else 0
                    let input_tensor = &self.entries[*input].output;
                    if let Ok(data) = input_tensor.to_vec() {
                        let mask: Vec<f32> = data
                            .iter()
                            .map(|&x| if x > 0.0 { 1.0 } else { 0.0 })
                            .collect();
                        if let Ok(mask_tensor) = Tensor::from_slice(
                            &mask,
                            input_tensor.shape().clone(),
                            input_tensor.device(),
                        ) {
                            if let Ok(grad_input) = vatra_ops::mul(&grad, &mask_tensor) {
                                accumulate_grad(&mut grads, *input, &grad_input);
                            }
                        }
                    }
                }
                Op::Matmul { a, b } => {
                    // d/dA (A @ B) = grad @ B^T
                    // d/dB (A @ B) = A^T @ grad
                    let a_tensor = &self.entries[*a].output;
                    let b_tensor = &self.entries[*b].output;

                    if let Ok(b_t) = b_tensor.t() {
                        if let Ok(grad_a) = vatra_ops::matmul(&grad, &b_t) {
                            accumulate_grad(&mut grads, *a, &grad_a);
                        }
                    }
                    if let Ok(a_t) = a_tensor.t() {
                        if let Ok(grad_b) = vatra_ops::matmul(&a_t, &grad) {
                            accumulate_grad(&mut grads, *b, &grad_b);
                        }
                    }
                }
                Op::Sum { input, shape } => {
                    // Gradient is broadcast back to original shape
                    if let Ok(expanded) =
                        Tensor::full(vatra_core::Shape::from(shape.clone()), 1.0, grad.device())
                    {
                        if let Ok(grad_input) = vatra_ops::mul(&grad, &expanded) {
                            accumulate_grad(&mut grads, *input, &grad_input);
                        }
                    }
                }
                // Other ops - simplified for now
                Op::Softmax { input, dim } => {
                    // y = softmax(x)
                    // grad_input = y * (grad - sum(grad * y, dim))
                    // Note: This assumes sum reduces dimension. We might need to unsqueeze for broadcasting
                    // if the library doesn't handle it automatically.
                    // For now, let's try basic implementation.

                    let y = &self.entries[i].output;

                    if let Ok(dy_y) = vatra_ops::mul(&grad, y) {
                        if let Ok(sum_dy_y) = vatra_ops::sum(&dy_y, Some(*dim)) {
                            // We need to ensure sum_dy_y has correct shape for broadcasting
                            // If sum reduced the rank, we need to add 1 at dim
                            let mut shape = sum_dy_y.shape().dims().to_vec();
                            let rank = y.shape().dims().len();
                            let d = if *dim < 0 {
                                (rank as isize + *dim) as usize
                            } else {
                                *dim as usize
                            };

                            if shape.len() < rank {
                                shape.insert(d, 1);
                                let shape_isize: Vec<isize> =
                                    shape.iter().map(|&x| x as isize).collect();
                                if let Ok(sum_reshaped) = sum_dy_y.reshape(&shape_isize) {
                                    if let Ok(sub_res) = vatra_ops::sub(&grad, &sum_reshaped) {
                                        if let Ok(grad_input) = vatra_ops::mul(y, &sub_res) {
                                            accumulate_grad(&mut grads, *input, &grad_input);
                                        }
                                    }
                                }
                            } else {
                                // Already correct rank (keepdim=true?)
                                if let Ok(sub_res) = vatra_ops::sub(&grad, &sum_dy_y) {
                                    if let Ok(grad_input) = vatra_ops::mul(y, &sub_res) {
                                        accumulate_grad(&mut grads, *input, &grad_input);
                                    }
                                }
                            }
                        }
                    }
                }
                Op::Transpose { input } => {
                    if let Ok(grad_t) = vatra_ops::transpose(&grad) {
                        accumulate_grad(&mut grads, *input, &grad_t);
                    }
                }
                _ => {}
            }
        }

        grads
    }
}

fn accumulate_grad(grads: &mut [Option<Tensor>], idx: usize, grad: &Tensor) {
    match &mut grads[idx] {
        Some(existing) => {
            if let Ok(sum) = vatra_ops::add(existing, grad) {
                grads[idx] = Some(sum);
            }
        }
        None => {
            grads[idx] = Some(grad.clone());
        }
    }
}

impl Default for Tape {
    fn default() -> Self {
        Self::new()
    }
}
