//! JAX-style vmap (vectorizing map) transformation

use vatra_core::{Shape, Tensor, VatraResult};

/// Vectorizing map transformation (JAX-style)
///
/// Transforms a function that operates on single elements to one that
/// operates on batches efficiently via parallelization.
///
/// # Arguments
/// * `f` - Function to vectorize
/// * `in_axis` - Axis along which to map (0 = batch dim)
///
/// # Example
/// ```ignore
/// // Function that works on single vectors
/// let dot_self = |x: &Tensor| ops::sum(&ops::mul(x, x)?, None);
///
/// // Vectorized version that works on batches
/// let batched_dot = vmap(dot_self, 0);
/// let batch = Tensor::randn([32, 100], Device::Cpu)?; // 32 vectors
/// let norms = batched_dot(&batch)?; // 32 dot products
/// ```
pub fn vmap<F>(f: F, in_axis: i32) -> impl Fn(&Tensor) -> VatraResult<Tensor>
where
    F: Fn(&Tensor) -> VatraResult<Tensor>,
{
    move |x: &Tensor| {
        let shape = x.shape();
        let rank = shape.rank() as i32;
        let axis = if in_axis < 0 { rank + in_axis } else { in_axis } as usize;

        if axis >= shape.rank() {
            return Err(vatra_core::VatraError::InvalidAxis {
                axis: in_axis as isize,
                rank: shape.rank(),
            });
        }

        let batch_size = shape[axis];
        let data = x.to_vec()?;

        // Calculate slice size for each batch element
        let mut inner_shape: Vec<usize> = shape.dims().to_vec();
        inner_shape.remove(axis);
        let inner_numel: usize = inner_shape.iter().product();

        let mut results = Vec::with_capacity(batch_size);

        // Process each element in batch
        for i in 0..batch_size {
            // Extract slice for this batch element
            // Simplified: assumes axis == 0
            let start = i * inner_numel;
            let end = start + inner_numel;
            let slice_data = &data[start..end];

            let slice_tensor = Tensor::from_slice(slice_data, inner_shape.clone(), x.device())?;
            let result = f(&slice_tensor)?;
            results.push(result);
        }

        // Stack results back together
        if results.is_empty() {
            return Tensor::zeros([0], x.device());
        }

        let first_shape = results[0].shape().clone();
        let mut out_shape = vec![batch_size];
        out_shape.extend_from_slice(first_shape.dims());

        let mut out_data = Vec::with_capacity(batch_size * results[0].numel());
        for r in &results {
            out_data.extend(r.to_vec()?);
        }

        Tensor::from_slice(&out_data, out_shape, x.device())
    }
}

/// Parallel map over multiple arrays with different axes
pub fn vmap_multi<'a, F>(
    f: F,
    in_axes: &'a [Option<i32>],
) -> impl Fn(&[Tensor]) -> VatraResult<Tensor> + 'a
where
    F: Fn(&[Tensor]) -> VatraResult<Tensor> + 'a,
{
    move |xs: &[Tensor]| {
        if xs.len() != in_axes.len() {
            return Err(vatra_core::VatraError::InvalidArgument(format!(
                "Expected {} inputs, got {}",
                in_axes.len(),
                xs.len()
            )));
        }

        // Find batch size from first mapped axis
        let batch_size = in_axes
            .iter()
            .zip(xs.iter())
            .find_map(|(axis, x)| axis.map(|a| x.shape()[a.unsigned_abs() as usize]))
            .ok_or_else(|| {
                vatra_core::VatraError::InvalidArgument(
                    "At least one axis must be specified".into(),
                )
            })?;

        let mut results = Vec::with_capacity(batch_size);

        for i in 0..batch_size {
            // Extract slices for this batch index
            let slices: VatraResult<Vec<Tensor>> = xs
                .iter()
                .zip(in_axes.iter())
                .map(|(x, axis)| {
                    match axis {
                        Some(a) => {
                            // Extract slice along axis
                            let data = x.to_vec()?;
                            let shape = x.shape();
                            let axis_idx = a.unsigned_abs() as usize;

                            let mut inner_shape: Vec<usize> = shape.dims().to_vec();
                            inner_shape.remove(axis_idx);
                            let inner_numel: usize = inner_shape.iter().product();

                            let start = i * inner_numel;
                            let end = start + inner_numel;
                            Tensor::from_slice(&data[start..end], inner_shape, x.device())
                        }
                        None => Ok(x.clone()), // Broadcast
                    }
                })
                .collect();

            let result = f(&slices?)?;
            results.push(result);
        }

        // Stack results
        if results.is_empty() {
            return Tensor::zeros([0], xs[0].device());
        }

        let first_shape = results[0].shape().clone();
        let mut out_shape = vec![batch_size];
        out_shape.extend_from_slice(first_shape.dims());

        let mut out_data = Vec::new();
        for r in &results {
            out_data.extend(r.to_vec()?);
        }

        Tensor::from_slice(&out_data, out_shape, xs[0].device())
    }
}
