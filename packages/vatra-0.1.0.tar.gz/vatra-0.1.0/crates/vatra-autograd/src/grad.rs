//! JAX-style grad transformation

use crate::tape::Tape;
use vatra_core::{Tensor, VatraResult};

/// A function that can be differentiated
pub trait GradFn<Args, Output> {
    fn call(&self, args: Args) -> Output;
}

// Implement for closures with single Tensor argument
impl<F> GradFn<&Tensor, VatraResult<Tensor>> for F
where
    F: Fn(&Tensor) -> VatraResult<Tensor>,
{
    fn call(&self, args: &Tensor) -> VatraResult<Tensor> {
        self(args)
    }
}

/// Transform a function to compute its gradient (JAX-style)
///
/// # Example
/// ```ignore
/// let loss_fn = |x: &Tensor| {
///     let y = ops::mul(x, x)?;  // x^2
///     ops::sum(&y, None)
/// };
///
/// let grad_fn = grad(loss_fn);
/// let x = Tensor::randn([3], Device::Cpu)?;
/// let gradient = grad_fn(&x)?;  // 2*x
/// ```
pub fn grad<F>(f: F) -> impl Fn(&Tensor) -> VatraResult<Tensor>
where
    F: Fn(&Tensor) -> VatraResult<Tensor>,
{
    move |x: &Tensor| {
        // Start recording
        Tape::start();

        // Record input
        let input_idx = Tape::record_input(x.clone());

        // Execute forward pass
        let output = f(x)?;
        let output_idx = Tape::record_input(output.clone());

        // Stop recording and get tape
        let tape = Tape::stop().expect("Tape should exist");

        // Compute gradients via backward pass
        let grads = tape.backward(output_idx);

        // Return gradient of input
        grads[input_idx].clone().ok_or_else(|| {
            vatra_core::VatraError::InvalidArgument("No gradient computed for input".into())
        })
    }
}

/// Compute both value and gradient (more efficient than separate calls)
pub fn value_and_grad<F>(f: F) -> impl Fn(&Tensor) -> VatraResult<(Tensor, Tensor)>
where
    F: Fn(&Tensor) -> VatraResult<Tensor>,
{
    move |x: &Tensor| {
        Tape::start();
        let input_idx = Tape::record_input(x.clone());

        let output = f(x)?;
        let output_idx = Tape::record_input(output.clone());

        let tape = Tape::stop().expect("Tape should exist");
        let grads = tape.backward(output_idx);

        let gradient = grads[input_idx].clone().ok_or_else(|| {
            vatra_core::VatraError::InvalidArgument("No gradient computed".into())
        })?;

        Ok((output, gradient))
    }
}

/// Compute gradients with respect to multiple parameters
pub fn grad_multi<F>(f: F) -> impl Fn(&[Tensor]) -> VatraResult<Vec<Tensor>>
where
    F: Fn(&[Tensor]) -> VatraResult<Tensor>,
{
    move |params: &[Tensor]| {
        Tape::start();

        // Record all inputs
        let input_indices: Vec<usize> = params
            .iter()
            .map(|p| Tape::record_input(p.clone()))
            .collect();

        let output = f(params)?;
        let output_idx = Tape::record_input(output);

        let tape = Tape::stop().expect("Tape should exist");
        let grads = tape.backward(output_idx);

        // Collect gradients for all inputs
        input_indices
            .iter()
            .map(|&idx| {
                grads[idx].clone().ok_or_else(|| {
                    vatra_core::VatraError::InvalidArgument("No gradient computed".into())
                })
            })
            .collect::<VatraResult<Vec<Tensor>>>()
    }
}

/// Compute both value and gradients for multiple parameters
pub fn value_and_grad_multi<F>(f: F) -> impl Fn(&[Tensor]) -> VatraResult<(Tensor, Vec<Tensor>)>
where
    F: Fn(&[Tensor]) -> VatraResult<Tensor>,
{
    move |params: &[Tensor]| {
        Tape::start();

        // Record all inputs
        let input_indices: Vec<usize> = params
            .iter()
            .map(|p| Tape::record_input(p.clone()))
            .collect();

        let output = f(params)?;
        let output_idx = Tape::record_input(output.clone());

        let tape = Tape::stop().expect("Tape should exist");
        let grads = tape.backward(output_idx);

        // Collect gradients for all inputs
        let gradients = input_indices
            .iter()
            .map(|&idx| {
                grads[idx].clone().ok_or_else(|| {
                    vatra_core::VatraError::InvalidArgument("No gradient computed".into())
                })
            })
            .collect::<VatraResult<Vec<Tensor>>>()?;

        Ok((output, gradients))
    }
}

/// Check if currently inside a gradient computation
pub fn inside_grad() -> bool {
    Tape::is_recording()
}
