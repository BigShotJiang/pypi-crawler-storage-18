//! Autograd-aware operations

use crate::tape::{Op, Tape};
use vatra_core::{Tensor, VatraResult};

// ========== Binary Operations ==========

pub fn add(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::add(a, b)?;
    if Tape::is_recording() {
        let idx_a = Tape::record_input(a.clone());
        let idx_b = Tape::record_input(b.clone());
        Tape::record_op(out.clone(), Op::Add { a: idx_a, b: idx_b }, &[idx_a, idx_b]);
    }
    Ok(out)
}

pub fn sub(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::sub(a, b)?;
    if Tape::is_recording() {
        let idx_a = Tape::record_input(a.clone());
        let idx_b = Tape::record_input(b.clone());
        Tape::record_op(out.clone(), Op::Sub { a: idx_a, b: idx_b }, &[idx_a, idx_b]);
    }
    Ok(out)
}

pub fn mul(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::mul(a, b)?;
    if Tape::is_recording() {
        let idx_a = Tape::record_input(a.clone());
        let idx_b = Tape::record_input(b.clone());
        Tape::record_op(out.clone(), Op::Mul { a: idx_a, b: idx_b }, &[idx_a, idx_b]);
    }
    Ok(out)
}

pub fn div(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::div(a, b)?;
    if Tape::is_recording() {
        let idx_a = Tape::record_input(a.clone());
        let idx_b = Tape::record_input(b.clone());
        Tape::record_op(out.clone(), Op::Div { a: idx_a, b: idx_b }, &[idx_a, idx_b]);
    }
    Ok(out)
}

pub fn matmul(a: &Tensor, b: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::matmul(a, b)?;
    if Tape::is_recording() {
        let idx_a = Tape::record_input(a.clone());
        let idx_b = Tape::record_input(b.clone());
        Tape::record_op(
            out.clone(),
            Op::Matmul { a: idx_a, b: idx_b },
            &[idx_a, idx_b],
        );
    }
    Ok(out)
}

// ========== Unary Operations ==========

pub fn neg(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::neg(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Neg { input: idx }, &[idx]);
    }
    Ok(out)
}

pub fn exp(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::exp(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Exp { input: idx }, &[idx]);
    }
    Ok(out)
}

pub fn log(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::log(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Log { input: idx }, &[idx]);
    }
    Ok(out)
}

// ========== Activations ==========

pub fn relu(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::relu(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Relu { input: idx }, &[idx]);
    }
    Ok(out)
}

pub fn sigmoid(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::sigmoid(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Sigmoid { input: idx }, &[idx]);
    }
    Ok(out)
}

pub fn tanh(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::tanh(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Tanh { input: idx }, &[idx]);
    }
    Ok(out)
}

pub fn softmax(a: &Tensor, dim: isize) -> VatraResult<Tensor> {
    let out = vatra_ops::softmax(a, dim)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Softmax { input: idx, dim }, &[idx]);
    }
    Ok(out)
}

// ========== Reductions ==========

pub fn sum(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    // vatra_ops::sum очікує (Tensor, Option<isize>)
    let out = vatra_ops::sum(a, axis)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        let shape = a.shape().dims().to_vec();
        Tape::record_op(out.clone(), Op::Sum { input: idx, shape }, &[idx]);
    }
    Ok(out)
}

pub fn mean(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    let out = vatra_ops::mean(a, axis)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        let shape = a.shape().dims().to_vec();
        Tape::record_op(out.clone(), Op::Mean { input: idx, shape }, &[idx]);
    }
    Ok(out)
}

pub fn max(a: &Tensor, axis: Option<isize>) -> VatraResult<Tensor> {
    let out = vatra_ops::max(a, axis)?;
    // Max backward needs indices (argmax)
    // TODO: Implement Max backward
    Ok(out)
}

pub fn transpose(a: &Tensor) -> VatraResult<Tensor> {
    let out = vatra_ops::transpose(a)?;
    if Tape::is_recording() {
        let idx = Tape::record_input(a.clone());
        Tape::record_op(out.clone(), Op::Transpose { input: idx }, &[idx]);
    }
    Ok(out)
}
