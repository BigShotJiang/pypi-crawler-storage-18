//! JIT compilation for fused operations

use parking_lot::RwLock;
use std::collections::HashMap;
use std::sync::Arc;
use vatra_core::{Tensor, VatraResult};

/// JIT compiler for operation fusion
///
/// Traces operations and compiles them into optimized compute shaders.
/// This is similar to JAX's jit() but for WGSL shaders.
pub struct Jit {
    /// Cache of compiled traces
    cache: RwLock<HashMap<String, Arc<CompiledTrace>>>,
    /// Whether tracing is active
    tracing: RwLock<bool>,
    /// Current trace being recorded
    current_trace: RwLock<Option<Trace>>,
}

/// A recorded trace of operations
#[derive(Debug, Clone)]
pub struct Trace {
    /// Sequence of operations
    ops: Vec<TraceOp>,
    /// Input shapes
    input_shapes: Vec<Vec<usize>>,
}

/// A single operation in a trace
#[derive(Debug, Clone)]
pub enum TraceOp {
    Add(usize, usize), // input indices
    Mul(usize, usize),
    MatMul(usize, usize),
    Relu(usize),
    Sigmoid(usize),
    Sum(usize),
    Constant(Vec<f32>), // inline constant
}

/// A compiled trace ready for execution
pub struct CompiledTrace {
    /// Generated WGSL shader code
    shader_code: String,
    /// Input bindings info
    num_inputs: usize,
}

impl Jit {
    /// Create a new JIT compiler
    pub fn new() -> Self {
        Self {
            cache: RwLock::new(HashMap::new()),
            tracing: RwLock::new(false),
            current_trace: RwLock::new(None),
        }
    }

    /// Get global JIT instance
    pub fn global() -> &'static Jit {
        static JIT: std::sync::OnceLock<Jit> = std::sync::OnceLock::new();
        JIT.get_or_init(|| Jit::new())
    }

    /// Start tracing operations
    pub fn start_trace(&self, input_shapes: Vec<Vec<usize>>) {
        *self.tracing.write() = true;
        *self.current_trace.write() = Some(Trace {
            ops: Vec::new(),
            input_shapes,
        });
    }

    /// Stop tracing and compile
    pub fn stop_trace(&self) -> Option<Arc<CompiledTrace>> {
        *self.tracing.write() = false;
        let trace = self.current_trace.write().take()?;
        let compiled = self.compile_trace(&trace);
        Some(Arc::new(compiled))
    }

    /// Check if currently tracing
    pub fn is_tracing(&self) -> bool {
        *self.tracing.read()
    }

    /// Record an operation during tracing
    pub fn record_op(&self, op: TraceOp) {
        if let Some(trace) = self.current_trace.write().as_mut() {
            trace.ops.push(op);
        }
    }

    /// Compile a trace into a fused shader
    fn compile_trace(&self, trace: &Trace) -> CompiledTrace {
        let mut shader = String::new();
        shader.push_str("// Auto-generated fused kernel\n\n");

        // Generate bindings
        for i in 0..trace.input_shapes.len() {
            shader.push_str(&format!(
                "@group(0) @binding({}) var<storage, read> input{}: array<f32>;\n",
                i, i
            ));
        }
        shader.push_str(&format!(
            "@group(0) @binding({}) var<storage, read_write> output: array<f32>;\n\n",
            trace.input_shapes.len()
        ));

        // Generate main function
        shader.push_str("@compute @workgroup_size(256)\n");
        shader.push_str("fn main(@builtin(global_invocation_id) gid: vec3<u32>) {\n");
        shader.push_str("    let idx = gid.x;\n");
        shader.push_str("    if idx >= arrayLength(&output) { return; }\n\n");

        // Generate fused operations
        let mut temp_idx = 0;
        for op in &trace.ops {
            match op {
                TraceOp::Add(a, b) => {
                    shader.push_str(&format!(
                        "    let t{} = input{}[idx] + input{}[idx];\n",
                        temp_idx, a, b
                    ));
                    temp_idx += 1;
                }
                TraceOp::Mul(a, b) => {
                    shader.push_str(&format!(
                        "    let t{} = input{}[idx] * input{}[idx];\n",
                        temp_idx, a, b
                    ));
                    temp_idx += 1;
                }
                TraceOp::Relu(a) => {
                    shader.push_str(&format!(
                        "    let t{} = max(input{}[idx], 0.0);\n",
                        temp_idx, a
                    ));
                    temp_idx += 1;
                }
                TraceOp::Sigmoid(a) => {
                    shader.push_str(&format!(
                        "    let t{} = 1.0 / (1.0 + exp(-input{}[idx]));\n",
                        temp_idx, a
                    ));
                    temp_idx += 1;
                }
                _ => {}
            }
        }

        // Write output
        if temp_idx > 0 {
            shader.push_str(&format!("    output[idx] = t{};\n", temp_idx - 1));
        } else {
            shader.push_str("    output[idx] = input0[idx];\n");
        }
        shader.push_str("}\n");

        CompiledTrace {
            shader_code: shader,
            num_inputs: trace.input_shapes.len(),
        }
    }
}

impl Default for Jit {
    fn default() -> Self {
        Self::new()
    }
}

impl CompiledTrace {
    /// Get the generated shader code
    pub fn shader_code(&self) -> &str {
        &self.shader_code
    }

    /// Get number of inputs
    pub fn num_inputs(&self) -> usize {
        self.num_inputs
    }
}

/// JIT-compile a function (decorator-style)
///
/// # Example
/// ```ignore
/// let fast_fn = jit(|x: &Tensor| {
///     let y = ops::mul(x, x)?;
///     ops::relu(&y)
/// });
/// ```
pub fn jit<F>(f: F) -> impl Fn(&Tensor) -> VatraResult<Tensor>
where
    F: Fn(&Tensor) -> VatraResult<Tensor>,
{
    // For now, just pass through - full JIT would trace and cache
    move |x: &Tensor| f(x)
}
