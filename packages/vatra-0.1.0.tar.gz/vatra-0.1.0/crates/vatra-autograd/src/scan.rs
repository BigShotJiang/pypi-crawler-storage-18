//! JAX-style parallel scan primitive

use vatra_core::{Tensor, VatraResult};

/// Parallel prefix scan (like JAX's lax.scan)
///
/// Scans over the leading axis of `xs`, threading through `carry`.
/// This is useful for RNNs, cumulative operations, and more.
///
/// # Arguments
/// * `f` - Function (carry, x) -> (carry, y) to apply at each step
/// * `init` - Initial carry value
/// * `xs` - Tensor to scan over (first axis is scan axis)
///
/// # Returns
/// Final carry and stacked outputs
///
/// # Example
/// ```ignore
/// // Cumulative sum using scan
/// let cumsum = |carry: &Tensor, x: &Tensor| {
///     let new_carry = ops::add(carry, x)?;
///     Ok((new_carry.clone(), new_carry))
/// };
///
/// let xs = Tensor::from_slice(&[1.0, 2.0, 3.0, 4.0], [4], Device::Cpu)?;
/// let init = Tensor::zeros([1], Device::Cpu)?;
/// let (final_carry, ys) = scan(cumsum, &init, &xs)?;
/// // ys = [1, 3, 6, 10]
/// ```
pub fn scan<F>(f: F, init: &Tensor, xs: &Tensor) -> VatraResult<(Tensor, Tensor)>
where
    F: Fn(&Tensor, &Tensor) -> VatraResult<(Tensor, Tensor)>,
{
    let shape = xs.shape();
    if shape.rank() == 0 {
        return Err(vatra_core::VatraError::InvalidArgument(
            "scan requires at least 1D input".into(),
        ));
    }

    let scan_length = shape[0];
    let data = xs.to_vec()?;

    // Calculate element size
    let mut inner_shape: Vec<usize> = shape.dims().to_vec();
    inner_shape.remove(0);
    let inner_numel: usize = if inner_shape.is_empty() {
        1
    } else {
        inner_shape.iter().product()
    };

    let inner_shape_ref = if inner_shape.is_empty() {
        vec![1] // Scalar elements become 1D
    } else {
        inner_shape.clone()
    };

    let mut carry = init.clone();
    let mut outputs = Vec::with_capacity(scan_length);

    for i in 0..scan_length {
        let start = i * inner_numel;
        let end = start + inner_numel;
        let x_slice = Tensor::from_slice(&data[start..end], inner_shape_ref.clone(), xs.device())?;

        let (new_carry, y) = f(&carry, &x_slice)?;
        carry = new_carry;
        outputs.push(y);
    }

    // Stack outputs
    let mut out_data = Vec::new();
    let out_element_shape = if outputs.is_empty() {
        inner_shape_ref.clone()
    } else {
        outputs[0].shape().dims().to_vec()
    };

    for y in &outputs {
        out_data.extend(y.to_vec()?);
    }

    let mut out_shape = vec![scan_length];
    out_shape.extend(out_element_shape);

    let stacked = Tensor::from_slice(&out_data, out_shape, xs.device())?;

    Ok((carry, stacked))
}

/// Reverse scan (from end to beginning)
pub fn scan_reverse<F>(f: F, init: &Tensor, xs: &Tensor) -> VatraResult<(Tensor, Tensor)>
where
    F: Fn(&Tensor, &Tensor) -> VatraResult<(Tensor, Tensor)>,
{
    let shape = xs.shape();
    if shape.rank() == 0 {
        return Err(vatra_core::VatraError::InvalidArgument(
            "scan requires at least 1D input".into(),
        ));
    }

    let scan_length = shape[0];
    let data = xs.to_vec()?;

    let mut inner_shape: Vec<usize> = shape.dims().to_vec();
    inner_shape.remove(0);
    let inner_numel: usize = if inner_shape.is_empty() {
        1
    } else {
        inner_shape.iter().product()
    };
    let inner_shape_ref = if inner_shape.is_empty() {
        vec![1]
    } else {
        inner_shape.clone()
    };

    let mut carry = init.clone();
    let mut outputs = Vec::with_capacity(scan_length);

    for i in (0..scan_length).rev() {
        let start = i * inner_numel;
        let end = start + inner_numel;
        let x_slice = Tensor::from_slice(&data[start..end], inner_shape_ref.clone(), xs.device())?;

        let (new_carry, y) = f(&carry, &x_slice)?;
        carry = new_carry;
        outputs.push(y);
    }

    outputs.reverse();

    let mut out_data = Vec::new();
    let out_element_shape = if outputs.is_empty() {
        inner_shape_ref
    } else {
        outputs[0].shape().dims().to_vec()
    };

    for y in &outputs {
        out_data.extend(y.to_vec()?);
    }

    let mut out_shape = vec![scan_length];
    out_shape.extend(out_element_shape);

    let stacked = Tensor::from_slice(&out_data, out_shape, xs.device())?;

    Ok((carry, stacked))
}

/// Cumulative sum using scan
pub fn cumsum(xs: &Tensor, axis: i32) -> VatraResult<Tensor> {
    // Simplified: only supports axis 0
    if axis != 0 {
        return Err(vatra_core::VatraError::Unsupported(
            "cumsum currently only supports axis=0".into(),
        ));
    }

    let shape = xs.shape();
    let init = Tensor::zeros(shape.dims()[1..].to_vec(), xs.device())?;

    let (_, result) = scan(
        |carry, x| {
            let new_carry = vatra_ops::add(carry, x)?;
            Ok((new_carry.clone(), new_carry))
        },
        &init,
        xs,
    )?;

    Ok(result)
}

/// Cumulative product using scan
pub fn cumprod(xs: &Tensor, axis: i32) -> VatraResult<Tensor> {
    if axis != 0 {
        return Err(vatra_core::VatraError::Unsupported(
            "cumprod currently only supports axis=0".into(),
        ));
    }

    let shape = xs.shape();
    let init = Tensor::ones(shape.dims()[1..].to_vec(), xs.device())?;

    let (_, result) = scan(
        |carry, x| {
            let new_carry = vatra_ops::mul(carry, x)?;
            Ok((new_carry.clone(), new_carry))
        },
        &init,
        xs,
    )?;

    Ok(result)
}
