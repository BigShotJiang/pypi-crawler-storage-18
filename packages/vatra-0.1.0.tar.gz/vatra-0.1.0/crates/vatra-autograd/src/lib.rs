#![allow(dead_code, unused_imports, unused_variables, unused_doc_comments)]
//! Vatra Autograd — JAX-style automatic differentiation
//!
//! Provides functional transformations for gradients:
//! - `grad(f)` — transform function to compute gradients
//! - `value_and_grad(f)` — compute value and gradients together
//! - `vmap(f)` — auto-vectorization
//! - `scan(f)` — parallel prefix scan

mod grad;
mod jit;
pub mod ops; // Added this line
mod scan;
mod tape;
mod vmap;

pub use grad::{GradFn, grad, grad_multi, value_and_grad, value_and_grad_multi};
pub use jit::Jit;
pub use scan::scan;
pub use tape::{Tape, TapeEntry};
pub use vmap::vmap;
