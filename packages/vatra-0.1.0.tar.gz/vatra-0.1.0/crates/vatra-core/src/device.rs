//! Device abstraction for compute locations

use std::cell::RefCell;
use std::fmt;

thread_local! {
    static DEFAULT_DEVICE: RefCell<Device> = RefCell::new(Device::Cpu);
}

/// Compute device (CPU or GPU)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Device {
    /// CPU computation
    Cpu,
    /// Vulkan GPU with device index
    Vulkan(usize),
}

impl Device {
    /// Default GPU device (index 0)
    pub fn gpu() -> Self {
        Device::Vulkan(0)
    }

    /// Check if this is a GPU device
    pub fn is_gpu(&self) -> bool {
        matches!(self, Device::Vulkan(_))
    }

    /// Check if this is CPU
    pub fn is_cpu(&self) -> bool {
        matches!(self, Device::Cpu)
    }

    /// Get GPU index if this is a GPU device
    pub fn gpu_index(&self) -> Option<usize> {
        match self {
            Device::Vulkan(idx) => Some(*idx),
            Device::Cpu => None,
        }
    }

    /// Check if GPU is available on this system
    ///
    /// # Example
    /// ```ignore
    /// if Device::cuda_is_available() {
    ///     println!("GPU is available!");
    /// }
    /// ```
    pub fn cuda_is_available() -> bool {
        // Try to initialize GPU backend
        vatra_gpu::GpuBackend::init()
            .map(|backend| backend.device_count() > 0)
            .unwrap_or(false)
    }

    /// Alias for cuda_is_available (Vulkan backend)
    pub fn vulkan_is_available() -> bool {
        Self::cuda_is_available()
    }

    /// Automatically select best available device
    /// Returns GPU if available, otherwise CPU
    ///
    /// # Example
    /// ```ignore
    /// use vatra::prelude::*;
    ///
    /// // Like PyTorch: device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    /// let device = Device::auto();
    ///
    /// let x = Tensor::randn([100, 100], device)?;
    /// ```
    pub fn auto() -> Self {
        if Self::cuda_is_available() {
            Device::Vulkan(0)
        } else {
            Device::Cpu
        }
    }

    /// Get number of available GPUs
    pub fn device_count() -> usize {
        vatra_gpu::GpuBackend::init()
            .map(|backend| backend.device_count())
            .unwrap_or(0)
    }
}

impl Default for Device {
    fn default() -> Self {
        get_default_device()
    }
}

impl fmt::Display for Device {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Device::Cpu => write!(f, "cpu"),
            Device::Vulkan(idx) => write!(f, "vulkan:{}", idx),
        }
    }
}

// ========== Global Default Device API ==========

/// Set the default device for tensor creation
///
/// # Example
/// ```ignore
/// use vatra::prelude::*;
///
/// // Set GPU as default
/// set_default_device(Device::Vulkan(0));
///
/// // Now tensors are created on GPU by default
/// let x = Tensor::randn([100, 100])?;  // On GPU!
/// ```
pub fn set_default_device(device: Device) {
    DEFAULT_DEVICE.with(|d| {
        *d.borrow_mut() = device;
    });
}

/// Get the current default device
pub fn get_default_device() -> Device {
    DEFAULT_DEVICE.with(|d| *d.borrow())
}

/// Context manager for temporarily changing default device
///
/// # Example
/// ```ignore
/// with_device(Device::Vulkan(0), || {
///     let x = Tensor::randn([100, 100])?; // On GPU
///     Ok(())
/// })?;
/// // Back to previous default
/// ```
pub fn with_device<F, T>(device: Device, f: F) -> T
where
    F: FnOnce() -> T,
{
    let old = get_default_device();
    set_default_device(device);
    let result = f();
    set_default_device(old);
    result
}
