//! Core Tensor type with GPU backing

use crate::{DType, Device, Shape, VatraError, VatraResult};
use parking_lot::RwLock;
use rand_distr::{Distribution, Normal, Uniform};
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};
use vatra_gpu::{GpuBackend, GpuBuffer, GpuDevice};

static TENSOR_ID_COUNTER: AtomicUsize = AtomicUsize::new(0);

/// A multi-dimensional array stored on GPU
///
/// This is the core data structure for all computations.
/// Tensors are immutable by default (JAX-style).
#[derive(Clone)]
pub struct Tensor {
    /// Unique identifier for autograd tracking
    pub(crate) id: usize,
    /// GPU buffer holding the data
    storage: Arc<TensorStorage>,
    /// Shape of the tensor
    shape: Shape,
    /// Element data type
    dtype: DType,
    /// Device where tensor resides
    device: Device,
    /// Whether gradients should be tracked
    requires_grad: bool,
    /// Gradient (lazily computed)
    grad: Arc<RwLock<Option<Tensor>>>,
}

impl Tensor {
    fn next_id() -> usize {
        TENSOR_ID_COUNTER.fetch_add(1, Ordering::Relaxed)
    }
}

/// Internal storage for tensor data
pub(crate) enum TensorStorage {
    Gpu(GpuBuffer),
    Cpu(Vec<u8>),
}

impl Tensor {
    // ========== Constructors (PyTorch-like) ==========

    /// Create a tensor from f32 slice
    pub fn from_slice(data: &[f32], shape: impl Into<Shape>, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        if data.len() != shape.numel() {
            return Err(VatraError::ShapeMismatch {
                expected: format!("{} elements", shape.numel()),
                actual: format!("{} elements", data.len()),
            });
        }

        let bytes = bytemuck::cast_slice(data);
        let storage = match device {
            Device::Vulkan(idx) => {
                let backend = GpuBackend::init()?;
                let gpu_device = backend.device(idx)?;
                TensorStorage::Gpu(GpuBuffer::from_bytes(gpu_device, bytes))
            }
            Device::Cpu => TensorStorage::Cpu(bytes.to_vec()),
        };

        Ok(Self {
            id: Self::next_id(),
            storage: Arc::new(storage),
            shape,
            dtype: DType::F32,
            device,
            requires_grad: false,
            grad: Arc::new(RwLock::new(None)),
        })
    }

    /// Create a tensor filled with zeros
    pub fn zeros(shape: impl Into<Shape>, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        let numel = shape.numel();
        let data = vec![0.0f32; numel];
        Self::from_slice(&data, shape, device)
    }

    /// Create a tensor filled with ones
    pub fn ones(shape: impl Into<Shape>, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        let numel = shape.numel();
        let data = vec![1.0f32; numel];
        Self::from_slice(&data, shape, device)
    }

    /// Create a tensor filled with a constant value
    pub fn full(shape: impl Into<Shape>, value: f32, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        let numel = shape.numel();
        let data = vec![value; numel];
        Self::from_slice(&data, shape, device)
    }

    /// Create a tensor with random values from uniform distribution [0, 1)
    pub fn rand(shape: impl Into<Shape>, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        let numel = shape.numel();
        let mut rng = rand::thread_rng();
        let dist = Uniform::new(0.0f32, 1.0f32);
        let data: Vec<f32> = (0..numel).map(|_| dist.sample(&mut rng)).collect();
        Self::from_slice(&data, shape, device)
    }

    /// Create a tensor with random values from standard normal distribution
    pub fn randn(shape: impl Into<Shape>, device: Device) -> VatraResult<Self> {
        let shape = shape.into();
        let numel = shape.numel();
        let mut rng = rand::thread_rng();
        let dist = Normal::new(0.0f32, 1.0f32).unwrap();
        let data: Vec<f32> = (0..numel).map(|_| dist.sample(&mut rng)).collect();
        Self::from_slice(&data, shape, device)
    }

    /// Create an identity matrix
    pub fn eye(n: usize, device: Device) -> VatraResult<Self> {
        let mut data = vec![0.0f32; n * n];
        for i in 0..n {
            data[i * n + i] = 1.0;
        }
        Self::from_slice(&data, [n, n], device)
    }

    /// Create a 1D tensor with values in range [start, end) with step
    pub fn arange(start: f32, end: f32, step: f32, device: Device) -> VatraResult<Self> {
        let mut data = Vec::new();
        let mut val = start;
        while val < end {
            data.push(val);
            val += step;
        }
        let len = data.len();
        Self::from_slice(&data, [len], device)
    }

    /// Create a 1D tensor with n evenly spaced values between start and end
    pub fn linspace(start: f32, end: f32, steps: usize, device: Device) -> VatraResult<Self> {
        if steps == 0 {
            return Self::from_slice(&[], [0], device);
        }
        if steps == 1 {
            return Self::from_slice(&[start], [1], device);
        }
        let step = (end - start) / (steps - 1) as f32;
        let data: Vec<f32> = (0..steps).map(|i| start + i as f32 * step).collect();
        Self::from_slice(&data, [steps], device)
    }

    // ========== Default Device Constructors ==========
    // These use the global default device set by set_default_device()

    /// Create zeros on default device
    pub fn zeros_d(shape: impl Into<Shape>) -> VatraResult<Self> {
        Self::zeros(shape, crate::get_default_device())
    }

    /// Create ones on default device
    pub fn ones_d(shape: impl Into<Shape>) -> VatraResult<Self> {
        Self::ones(shape, crate::get_default_device())
    }

    /// Create random normal tensor on default device
    pub fn randn_d(shape: impl Into<Shape>) -> VatraResult<Self> {
        Self::randn(shape, crate::get_default_device())
    }

    /// Create random uniform tensor on default device
    pub fn rand_d(shape: impl Into<Shape>) -> VatraResult<Self> {
        Self::rand(shape, crate::get_default_device())
    }

    /// Create full tensor on default device
    pub fn full_d(shape: impl Into<Shape>, value: f32) -> VatraResult<Self> {
        Self::full(shape, value, crate::get_default_device())
    }

    /// Create identity matrix on default device
    pub fn eye_d(n: usize) -> VatraResult<Self> {
        Self::eye(n, crate::get_default_device())
    }

    /// Create from slice on default device
    pub fn from_slice_d(data: &[f32], shape: impl Into<Shape>) -> VatraResult<Self> {
        Self::from_slice(data, shape, crate::get_default_device())
    }

    // ========== Properties ==========

    /// Get tensor shape
    pub fn shape(&self) -> &Shape {
        &self.shape
    }

    /// Get unique tensor ID
    pub fn id(&self) -> usize {
        self.id
    }

    /// Get number of dimensions
    pub fn ndim(&self) -> usize {
        self.shape.rank()
    }

    /// Get total number of elements
    pub fn numel(&self) -> usize {
        self.shape.numel()
    }

    /// Get data type
    pub fn dtype(&self) -> DType {
        self.dtype
    }

    /// Get device
    pub fn device(&self) -> Device {
        self.device
    }

    /// Check if gradient tracking is enabled
    pub fn requires_grad(&self) -> bool {
        self.requires_grad
    }

    /// Enable gradient tracking (returns new tensor)
    pub fn with_grad(mut self) -> Self {
        self.requires_grad = true;
        self
    }

    /// Disable gradient tracking (returns new tensor)
    pub fn detach(&self) -> Self {
        Self {
            id: Self::next_id(),
            storage: Arc::clone(&self.storage),
            shape: self.shape.clone(),
            dtype: self.dtype,
            device: self.device,
            requires_grad: false,
            grad: Arc::new(RwLock::new(None)),
        }
    }

    /// Get gradient if computed
    pub fn grad(&self) -> Option<Tensor> {
        self.grad.read().clone()
    }

    // ========== Data Access ==========

    /// Read tensor data as f32 slice (synchronous, copies from GPU)
    pub fn to_vec(&self) -> VatraResult<Vec<f32>> {
        match &*self.storage {
            TensorStorage::Gpu(buffer) => {
                let bytes = buffer.read()?;
                Ok(bytemuck::cast_slice(&bytes).to_vec())
            }
            TensorStorage::Cpu(data) => Ok(bytemuck::cast_slice(data).to_vec()),
        }
    }

    /// Get a single scalar value (for 0-dim tensors or single element)
    pub fn item(&self) -> VatraResult<f32> {
        if self.numel() != 1 {
            return Err(VatraError::InvalidArgument(
                "item() requires tensor with exactly one element".into(),
            ));
        }
        let data = self.to_vec()?;
        Ok(data[0])
    }

    // ========== Shape Operations ==========

    /// Reshape tensor to new dimensions
    pub fn reshape(&self, new_shape: &[isize]) -> VatraResult<Self> {
        let new_shape = self.shape.reshape(new_shape).ok_or_else(|| {
            VatraError::InvalidArgument(format!("Cannot reshape {} to {:?}", self.shape, new_shape))
        })?;

        Ok(Self {
            id: Self::next_id(),
            storage: Arc::clone(&self.storage),
            shape: new_shape,
            dtype: self.dtype,
            device: self.device,
            requires_grad: self.requires_grad,
            grad: Arc::new(RwLock::new(None)),
        })
    }

    /// Flatten tensor to 1D
    pub fn flatten(&self) -> VatraResult<Self> {
        self.reshape(&[-1])
    }

    /// Squeeze dimensions of size 1
    pub fn squeeze(&self) -> Self {
        let new_dims: Vec<usize> = self
            .shape
            .dims()
            .iter()
            .copied()
            .filter(|&d| d != 1)
            .collect();
        let new_shape = if new_dims.is_empty() {
            Shape::scalar()
        } else {
            Shape::from(new_dims)
        };

        Self {
            id: Self::next_id(),
            storage: Arc::clone(&self.storage),
            shape: new_shape,
            dtype: self.dtype,
            device: self.device,
            requires_grad: self.requires_grad,
            grad: Arc::new(RwLock::new(None)),
        }
    }

    /// Add a dimension at specified position
    pub fn unsqueeze(&self, dim: isize) -> VatraResult<Self> {
        let rank = self.shape.rank() as isize;
        let dim = if dim < 0 { rank + dim + 1 } else { dim };

        if dim < 0 || dim > rank {
            return Err(VatraError::InvalidAxis {
                axis: dim,
                rank: self.shape.rank(),
            });
        }

        let mut new_dims = self.shape.dims().to_vec();
        new_dims.insert(dim as usize, 1);

        Ok(Self {
            id: Self::next_id(),
            storage: Arc::clone(&self.storage),
            shape: Shape::from(new_dims),
            dtype: self.dtype,
            device: self.device,
            requires_grad: self.requires_grad,
            grad: Arc::new(RwLock::new(None)),
        })
    }

    /// Transpose (swap last two dimensions)
    pub fn t(&self) -> VatraResult<Self> {
        if self.ndim() < 2 {
            return Err(VatraError::InvalidArgument(
                "transpose requires at least 2D tensor".into(),
            ));
        }
        // Note: Real implementation would use strided views
        // This is a placeholder that clones storage
        Ok(Self {
            id: Self::next_id(),
            storage: Arc::clone(&self.storage),
            shape: self.shape.transpose(),
            dtype: self.dtype,
            device: self.device,
            requires_grad: self.requires_grad,
            grad: Arc::new(RwLock::new(None)),
        })
    }

    // ========== Device Transfer ==========

    /// Move tensor to a different device
    pub fn to(&self, device: Device) -> VatraResult<Self> {
        if self.device == device {
            return Ok(self.clone());
        }

        let data = self.to_vec()?;
        Self::from_slice(&data, self.shape.clone(), device)
    }

    /// Move to CPU
    pub fn cpu(&self) -> VatraResult<Self> {
        self.to(Device::Cpu)
    }

    /// Move to GPU
    pub fn gpu(&self) -> VatraResult<Self> {
        self.to(Device::Vulkan(0))
    }

    // ========== Internal Helpers ==========

    /// Get GPU buffer (panics if on CPU)
    pub fn gpu_buffer(&self) -> &GpuBuffer {
        match &*self.storage {
            TensorStorage::Gpu(buf) => buf,
            TensorStorage::Cpu(_) => panic!("Tensor is on CPU"),
        }
    }

    /// Get the GPU device
    pub fn gpu_device(&self) -> VatraResult<Arc<GpuDevice>> {
        match self.device {
            Device::Vulkan(idx) => {
                let backend = GpuBackend::get()?;
                Ok(backend.device(idx)?)
            }
            Device::Cpu => Err(VatraError::Unsupported("Tensor is on CPU".into())),
        }
    }

    /// Create tensor from existing GPU buffer
    pub fn from_gpu_buffer(buffer: GpuBuffer, shape: Shape, dtype: DType, device: Device) -> Self {
        Self {
            id: Self::next_id(),
            storage: Arc::new(TensorStorage::Gpu(buffer)),
            shape,
            dtype,
            device,
            requires_grad: false,
            grad: Arc::new(RwLock::new(None)),
        }
    }
}

impl std::fmt::Debug for Tensor {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Tensor({}, dtype={}, device={}, grad={})",
            self.shape, self.dtype, self.device, self.requires_grad
        )
    }
}

impl std::fmt::Display for Tensor {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // Try to display tensor data
        match self.to_vec() {
            Ok(data) => {
                if self.numel() <= 10 {
                    write!(f, "tensor({:?}, shape={})", data, self.shape)
                } else {
                    let preview: Vec<f32> = data.iter().take(5).copied().collect();
                    write!(f, "tensor([{:?}..., shape={}])", preview, self.shape)
                }
            }
            Err(_) => write!(f, "{:?}", self),
        }
    }
}
