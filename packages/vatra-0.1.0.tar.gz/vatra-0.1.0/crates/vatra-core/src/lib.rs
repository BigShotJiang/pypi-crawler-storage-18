//! Vatra Core — Tensor type and fundamental abstractions
//!
//! This crate provides the core `Tensor` type with GPU backing,
//! device abstraction, data types, and model serialization.

mod device;
mod dtype;
mod error;
pub mod serialization;
mod shape;
mod tensor;

pub use device::{Device, get_default_device, set_default_device, with_device};
pub use dtype::DType;
pub use error::{VatraError, VatraResult};
pub use serialization::{
    CheckpointMetadata, LayerConfig, ModelArchitecture, StateDict, VATRA_FORMAT_VERSION,
    load_checkpoint, load_safetensors, save_checkpoint, save_safetensors,
};
pub use shape::Shape;
pub use tensor::Tensor;

/// Prelude with commonly used types
pub mod prelude {
    pub use crate::serialization::{StateDict, load_safetensors, save_safetensors};
    pub use crate::{DType, Device, Shape, Tensor, VatraResult};
}
