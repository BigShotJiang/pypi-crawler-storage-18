//! Model serialization and deserialization
//!
//! Supports:
//! - Safetensors format for weights
//! - Full model checkpoints with architecture
//! - Version tracking

use crate::{Device, Tensor, VatraError, VatraResult};
use safetensors::serialize;
use safetensors::tensor::{SafeTensors, TensorView};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

/// Current version of the Vatra serialization format
pub const VATRA_FORMAT_VERSION: &str = "0.1.0";

/// Metadata stored with model checkpoints
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CheckpointMetadata {
    /// Vatra version that created this checkpoint
    pub vatra_version: String,
    /// Format version for compatibility checking
    pub format_version: String,
    /// Model architecture name (if available)
    pub architecture: Option<String>,
    /// Model configuration as JSON
    pub config: Option<String>,
    /// Number of parameters
    pub num_parameters: usize,
    /// Total bytes
    pub total_bytes: usize,
    /// Tensor shapes
    pub shapes: HashMap<String, Vec<usize>>,
    /// Custom metadata
    pub custom: HashMap<String, String>,
}

impl CheckpointMetadata {
    pub fn new() -> Self {
        Self {
            vatra_version: env!("CARGO_PKG_VERSION").to_string(),
            format_version: VATRA_FORMAT_VERSION.to_string(),
            ..Default::default()
        }
    }
}

/// Layer configuration for architecture saving
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerConfig {
    /// Layer type name (Linear, Conv2d, etc.)
    pub layer_type: String,
    /// Layer parameters
    pub params: HashMap<String, serde_json::Value>,
}

/// Full model architecture
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelArchitecture {
    /// List of layers
    pub layers: Vec<LayerConfig>,
    /// Model name
    pub name: Option<String>,
}

/// State dictionary - named tensor mapping
pub type StateDict = HashMap<String, Tensor>;

/// Save tensors to safetensors format
pub fn save_safetensors<P: AsRef<Path>>(
    state_dict: &StateDict,
    path: P,
    metadata: Option<&CheckpointMetadata>,
) -> VatraResult<()> {
    // Convert tensors to the format safetensors expects
    let mut tensor_bytes: HashMap<String, Vec<u8>> = HashMap::new();
    let mut shapes: HashMap<String, Vec<usize>> = HashMap::new();

    for (name, tensor) in state_dict {
        let data = tensor.to_vec()?;
        let bytes: Vec<u8> = data.iter().flat_map(|f| f.to_le_bytes()).collect();
        tensor_bytes.insert(name.clone(), bytes);
        shapes.insert(name.clone(), tensor.shape().dims().to_vec());
    }

    // Create metadata HashMap for safetensors
    let mut meta_map: HashMap<String, String> = HashMap::new();
    if let Some(meta) = metadata {
        meta_map.insert("vatra_version".to_string(), meta.vatra_version.clone());
        meta_map.insert("format_version".to_string(), meta.format_version.clone());
        if let Some(arch) = &meta.architecture {
            meta_map.insert("architecture".to_string(), arch.clone());
        }
        if let Some(config) = &meta.config {
            meta_map.insert("config".to_string(), config.clone());
        }
        meta_map.insert(
            "num_parameters".to_string(),
            meta.num_parameters.to_string(),
        );
        for (k, v) in &meta.custom {
            meta_map.insert(format!("custom_{}", k), v.clone());
        }
    } else {
        meta_map.insert(
            "vatra_version".to_string(),
            env!("CARGO_PKG_VERSION").to_string(),
        );
        meta_map.insert(
            "format_version".to_string(),
            VATRA_FORMAT_VERSION.to_string(),
        );
    }

    // Serialize shapes to metadata
    let shapes_json = serde_json::to_string(&shapes).map_err(|e| {
        VatraError::SerializationError(format!("Failed to serialize shapes: {}", e))
    })?;
    meta_map.insert("shapes".to_string(), shapes_json);

    // Build tensor views for safetensors
    let tensor_views: Vec<(&str, TensorView<'_>)> = tensor_bytes
        .iter()
        .map(|(name, data)| {
            let shape = shapes.get(name).unwrap();
            (
                name.as_str(),
                TensorView::new(safetensors::Dtype::F32, shape.clone(), data).unwrap(),
            )
        })
        .collect();

    // Serialize to bytes
    let bytes = serialize(tensor_views, &Some(meta_map))
        .map_err(|e| VatraError::SerializationError(format!("Failed to serialize: {}", e)))?;

    // Write to file
    fs::write(path.as_ref(), bytes)
        .map_err(|e| VatraError::IoError(format!("Failed to write file: {}", e)))?;

    Ok(())
}

/// Load tensors from safetensors format
pub fn load_safetensors<P: AsRef<Path>>(
    path: P,
    device: Device,
) -> VatraResult<(StateDict, CheckpointMetadata)> {
    let data = fs::read(path.as_ref())
        .map_err(|e| VatraError::IoError(format!("Failed to read file: {}", e)))?;

    let safetensors = SafeTensors::deserialize(&data).map_err(|e| {
        VatraError::SerializationError(format!("Failed to parse safetensors: {}", e))
    })?;

    // Build metadata from file size
    let mut metadata = CheckpointMetadata {
        total_bytes: data.len(),
        ..CheckpointMetadata::new()
    };

    // Load shapes from the embedded metadata (we stored it as JSON in "shapes" key)
    // Since direct metadata access isn't available, we'll infer from tensor shapes
    let mut shapes: HashMap<String, Vec<usize>> = HashMap::new();

    // Load tensors
    let mut state_dict = StateDict::new();
    for name in safetensors.names() {
        let tensor_view = safetensors.tensor(&name).map_err(|e| {
            VatraError::SerializationError(format!("Failed to get tensor {}: {}", name, e))
        })?;

        let bytes = tensor_view.data();
        let tensor_data: Vec<f32> = bytes
            .chunks_exact(4)
            .map(|chunk| f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
            .collect();

        let shape = tensor_view.shape().to_vec();
        let numel = tensor_data.len();
        shapes.insert(name.to_string(), shape.clone());

        let tensor = Tensor::from_slice(&tensor_data, shape, device)?;
        state_dict.insert(name.to_string(), tensor);

        metadata.num_parameters += numel;
    }

    metadata.shapes = shapes;

    Ok((state_dict, metadata))
}

/// Save full model checkpoint (architecture + weights)
pub fn save_checkpoint<P: AsRef<Path>>(
    state_dict: &StateDict,
    architecture: &ModelArchitecture,
    path: P,
    custom_metadata: HashMap<String, String>,
) -> VatraResult<()> {
    let num_params: usize = state_dict.values().map(|t| t.shape().numel()).sum();

    let arch_json = serde_json::to_string(architecture).map_err(|e| {
        VatraError::SerializationError(format!("Failed to serialize architecture: {}", e))
    })?;

    let metadata = CheckpointMetadata {
        vatra_version: env!("CARGO_PKG_VERSION").to_string(),
        format_version: VATRA_FORMAT_VERSION.to_string(),
        architecture: architecture.name.clone(),
        config: Some(arch_json),
        num_parameters: num_params,
        custom: custom_metadata,
        ..Default::default()
    };

    save_safetensors(state_dict, path, Some(&metadata))
}

/// Load full model checkpoint
pub fn load_checkpoint<P: AsRef<Path>>(
    path: P,
    device: Device,
) -> VatraResult<(StateDict, Option<ModelArchitecture>, CheckpointMetadata)> {
    let (state_dict, metadata) = load_safetensors(path, device)?;

    let architecture = metadata
        .config
        .as_ref()
        .and_then(|config| serde_json::from_str(config).ok());

    Ok((state_dict, architecture, metadata))
}

/// Save only weights (no metadata)
pub fn save_weights<P: AsRef<Path>>(state_dict: &StateDict, path: P) -> VatraResult<()> {
    save_safetensors(state_dict, path, None)
}

/// Load only weights
pub fn load_weights<P: AsRef<Path>>(path: P, device: Device) -> VatraResult<StateDict> {
    let (state_dict, _) = load_safetensors(path, device)?;
    Ok(state_dict)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metadata_default() {
        let meta = CheckpointMetadata::new();
        assert_eq!(meta.format_version, VATRA_FORMAT_VERSION);
    }
}
