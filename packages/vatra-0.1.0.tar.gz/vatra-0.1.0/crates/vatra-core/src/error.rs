//! Core error types

use thiserror::Error;

/// Vatra result type
pub type VatraResult<T> = Result<T, VatraError>;

/// Core Vatra errors
#[derive(Error, Debug)]
pub enum VatraError {
    #[error("GPU error: {0}")]
    Gpu(#[from] vatra_gpu::GpuError),

    #[error("Shape mismatch: expected {expected}, got {actual}")]
    ShapeMismatch { expected: String, actual: String },

    #[error("Incompatible shapes for operation: {0} and {1}")]
    IncompatibleShapes(String, String),

    #[error("Invalid axis {axis} for tensor with {rank} dimensions")]
    InvalidAxis { axis: isize, rank: usize },

    #[error("Type mismatch: expected {expected}, got {actual}")]
    TypeMismatch { expected: String, actual: String },

    #[error("Device mismatch: tensors on different devices")]
    DeviceMismatch,

    #[error("Operation not supported: {0}")]
    Unsupported(String),

    #[error("Invalid argument: {0}")]
    InvalidArgument(String),

    #[error("IO error: {0}")]
    IoError(String),

    #[error("Serialization error: {0}")]
    SerializationError(String),

    #[error("Custom error: {0}")]
    Custom(String),
}
