//! Tensor shape representation

use smallvec::SmallVec;
use std::fmt;
use std::ops::Index;

/// Tensor shape with small-vector optimization
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Shape {
    dims: SmallVec<[usize; 4]>,
}

impl Shape {
    /// Create a new shape from dimensions
    pub fn new(dims: impl Into<SmallVec<[usize; 4]>>) -> Self {
        Self { dims: dims.into() }
    }

    /// Create a scalar shape (0 dimensions)
    pub fn scalar() -> Self {
        Self {
            dims: SmallVec::new(),
        }
    }

    /// Number of dimensions (rank)
    pub fn rank(&self) -> usize {
        self.dims.len()
    }

    /// Total number of elements
    pub fn numel(&self) -> usize {
        self.dims.iter().product()
    }

    /// Get dimensions as slice
    pub fn dims(&self) -> &[usize] {
        &self.dims
    }

    /// Check if this is a scalar (0-dim)
    pub fn is_scalar(&self) -> bool {
        self.dims.is_empty()
    }

    /// Check if this is a vector (1-dim)
    pub fn is_vector(&self) -> bool {
        self.dims.len() == 1
    }

    /// Check if this is a matrix (2-dim)
    pub fn is_matrix(&self) -> bool {
        self.dims.len() == 2
    }

    /// Get strides for row-major layout
    pub fn strides(&self) -> SmallVec<[usize; 4]> {
        let mut strides = SmallVec::with_capacity(self.dims.len());
        let mut stride = 1;
        for &dim in self.dims.iter().rev() {
            strides.push(stride);
            stride *= dim;
        }
        strides.reverse();
        strides
    }

    /// Check if shapes are broadcastable
    pub fn broadcast_with(&self, other: &Shape) -> Option<Shape> {
        let max_rank = self.rank().max(other.rank());
        let mut result = SmallVec::with_capacity(max_rank);

        for i in 0..max_rank {
            let a = self
                .dims
                .get(self.rank().saturating_sub(max_rank - i))
                .copied()
                .unwrap_or(1);
            let b = other
                .dims
                .get(other.rank().saturating_sub(max_rank - i))
                .copied()
                .unwrap_or(1);

            match (a, b) {
                (x, y) if x == y => result.push(x),
                (1, y) => result.push(y),
                (x, 1) => result.push(x),
                _ => return None,
            }
        }

        Some(Shape::new(result))
    }

    /// Transpose shape (swap last two dims)
    pub fn transpose(&self) -> Shape {
        if self.rank() < 2 {
            return self.clone();
        }
        let mut dims = self.dims.clone();
        let n = dims.len();
        dims.swap(n - 1, n - 2);
        Shape::new(dims)
    }

    /// Reshape to new dimensions (-1 for inferred)
    pub fn reshape(&self, new_dims: &[isize]) -> Option<Shape> {
        let numel = self.numel();
        let mut result: SmallVec<[usize; 4]> = SmallVec::new();
        let mut infer_idx = None;
        let mut product = 1usize;

        for (i, &d) in new_dims.iter().enumerate() {
            if d == -1 {
                if infer_idx.is_some() {
                    return None; // Only one -1 allowed
                }
                infer_idx = Some(i);
                result.push(0); // Placeholder
            } else if d < 0 {
                return None;
            } else {
                product *= d as usize;
                result.push(d as usize);
            }
        }

        if let Some(idx) = infer_idx {
            if numel % product != 0 {
                return None;
            }
            result[idx] = numel / product;
        } else if product != numel {
            return None;
        }

        Some(Shape::new(result))
    }
}

impl Index<usize> for Shape {
    type Output = usize;

    fn index(&self, index: usize) -> &Self::Output {
        &self.dims[index]
    }
}

impl fmt::Display for Shape {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(")?;
        for (i, d) in self.dims.iter().enumerate() {
            if i > 0 {
                write!(f, ", ")?;
            }
            write!(f, "{}", d)?;
        }
        write!(f, ")")
    }
}

impl From<&[usize]> for Shape {
    fn from(dims: &[usize]) -> Self {
        Self::new(SmallVec::from_slice(dims))
    }
}

impl From<Vec<usize>> for Shape {
    fn from(dims: Vec<usize>) -> Self {
        Self::new(SmallVec::from_vec(dims))
    }
}

impl<const N: usize> From<[usize; N]> for Shape {
    fn from(dims: [usize; N]) -> Self {
        Self::new(SmallVec::from_slice(&dims))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_broadcast() {
        let a = Shape::from([3, 1]);
        let b = Shape::from([1, 4]);
        assert_eq!(a.broadcast_with(&b), Some(Shape::from([3, 4])));

        let c = Shape::from([2, 3, 4]);
        let d = Shape::from([4]);
        assert_eq!(c.broadcast_with(&d), Some(Shape::from([2, 3, 4])));
    }

    #[test]
    fn test_reshape() {
        let shape = Shape::from([2, 3, 4]);
        assert_eq!(shape.reshape(&[6, 4]), Some(Shape::from([6, 4])));
        assert_eq!(shape.reshape(&[-1, 4]), Some(Shape::from([6, 4])));
        assert_eq!(shape.reshape(&[24]), Some(Shape::from([24])));
    }
}
