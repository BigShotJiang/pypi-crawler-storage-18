//! Data types for tensor elements

use std::fmt;

/// Tensor element data type
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DType {
    /// 16-bit floating point
    F16,
    /// 32-bit floating point
    F32,
    /// 64-bit floating point
    F64,
    /// 32-bit signed integer
    I32,
    /// 64-bit signed integer
    I64,
    /// 32-bit unsigned integer
    U32,
    /// Boolean
    Bool,
}

impl DType {
    /// Size of this dtype in bytes
    pub fn size_bytes(&self) -> usize {
        match self {
            DType::F16 => 2,
            DType::F32 => 4,
            DType::F64 => 8,
            DType::I32 => 4,
            DType::I64 => 8,
            DType::U32 => 4,
            DType::Bool => 1,
        }
    }

    /// Check if this is a floating point type
    pub fn is_float(&self) -> bool {
        matches!(self, DType::F16 | DType::F32 | DType::F64)
    }

    /// Check if this is an integer type
    pub fn is_int(&self) -> bool {
        matches!(self, DType::I32 | DType::I64 | DType::U32)
    }
}

impl Default for DType {
    fn default() -> Self {
        DType::F32
    }
}

impl fmt::Display for DType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DType::F16 => write!(f, "f16"),
            DType::F32 => write!(f, "f32"),
            DType::F64 => write!(f, "f64"),
            DType::I32 => write!(f, "i32"),
            DType::I64 => write!(f, "i64"),
            DType::U32 => write!(f, "u32"),
            DType::Bool => write!(f, "bool"),
        }
    }
}
