//! Embedding layer for token/word embeddings

use crate::Module;
use rand_distr::{Distribution, Normal};
use vatra_core::{Device, Tensor, VatraResult};

/// Embedding layer - lookup table for token embeddings
///
/// Maps integer indices to dense vectors.
/// Input: tensor of indices [batch, seq_len]
/// Output: tensor [batch, seq_len, embedding_dim]
#[derive(Clone)]
pub struct Embedding {
    /// Embedding weight matrix [num_embeddings, embedding_dim]
    pub weight: Tensor,
    /// Number of embeddings (vocabulary size)
    pub num_embeddings: usize,
    /// Dimension of each embedding vector
    pub embedding_dim: usize,
    /// Optional padding index (will be zeros)
    pub padding_idx: Option<usize>,
}

impl Embedding {
    /// Create a new Embedding layer
    ///
    /// # Arguments
    /// * `num_embeddings` - Size of the vocabulary (number of embeddings)
    /// * `embedding_dim` - Dimension of each embedding vector
    /// * `device` - Device to place the embedding weights
    pub fn new(num_embeddings: usize, embedding_dim: usize, device: Device) -> VatraResult<Self> {
        // Initialize with normal distribution
        let std = 1.0 / (embedding_dim as f32).sqrt();
        let weight = Self::init_weight(num_embeddings, embedding_dim, std, device)?;

        Ok(Self {
            weight,
            num_embeddings,
            embedding_dim,
            padding_idx: None,
        })
    }

    /// Create embedding with padding index
    pub fn with_padding(
        num_embeddings: usize,
        embedding_dim: usize,
        padding_idx: usize,
        device: Device,
    ) -> VatraResult<Self> {
        let mut emb = Self::new(num_embeddings, embedding_dim, device)?;
        emb.padding_idx = Some(padding_idx);
        // Zero out padding index row
        // (Would need in-place ops, skip for now)
        Ok(emb)
    }

    fn init_weight(
        num_embeddings: usize,
        embedding_dim: usize,
        std: f32,
        device: Device,
    ) -> VatraResult<Tensor> {
        let numel = num_embeddings * embedding_dim;
        let mut rng = rand::thread_rng();
        let dist = Normal::new(0.0, std).map_err(|e| {
            vatra_core::VatraError::InvalidArgument(format!("Distribution error: {}", e))
        })?;
        let data: Vec<f32> = (0..numel).map(|_| dist.sample(&mut rng)).collect();
        Tensor::from_slice(&data, [num_embeddings, embedding_dim], device)
    }

    /// Look up embeddings for given indices
    ///
    /// # Arguments
    /// * `indices` - Tensor of integer indices
    pub fn forward_indices(&self, indices: &[usize]) -> VatraResult<Tensor> {
        let weight_data = self.weight.to_vec()?;
        let batch_size = indices.len();
        let mut out_data = vec![0.0f32; batch_size * self.embedding_dim];

        for (i, &idx) in indices.iter().enumerate() {
            if idx >= self.num_embeddings {
                return Err(vatra_core::VatraError::InvalidArgument(format!(
                    "Index {} out of bounds for embedding with {} entries",
                    idx, self.num_embeddings
                )));
            }
            let offset = idx * self.embedding_dim;
            for j in 0..self.embedding_dim {
                out_data[i * self.embedding_dim + j] = weight_data[offset + j];
            }
        }

        Tensor::from_slice(
            &out_data,
            [batch_size, self.embedding_dim],
            self.weight.device(),
        )
    }
}

impl Module for Embedding {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // x should contain integer indices
        // For now, assume x is a 1D or 2D tensor of indices stored as f32
        let x_data = x.to_vec()?;
        let shape = x.shape();

        if shape.dims().len() == 1 {
            // 1D: [seq_len]
            let indices: Vec<usize> = x_data.iter().map(|&v| v as usize).collect();
            let embedded = self.forward_indices(&indices)?;
            // Output: [seq_len, embedding_dim]
            Ok(embedded)
        } else if shape.dims().len() == 2 {
            // 2D: [batch, seq_len]
            let batch = shape[0];
            let seq_len = shape[1];
            let mut out_data = vec![0.0f32; batch * seq_len * self.embedding_dim];
            let weight_data = self.weight.to_vec()?;

            for b in 0..batch {
                for s in 0..seq_len {
                    let idx = x_data[b * seq_len + s] as usize;
                    if idx >= self.num_embeddings {
                        return Err(vatra_core::VatraError::InvalidArgument(format!(
                            "Index {} out of bounds",
                            idx
                        )));
                    }
                    let w_offset = idx * self.embedding_dim;
                    let o_offset = (b * seq_len + s) * self.embedding_dim;
                    for e in 0..self.embedding_dim {
                        out_data[o_offset + e] = weight_data[w_offset + e];
                    }
                }
            }

            Tensor::from_slice(
                &out_data,
                [batch, seq_len, self.embedding_dim],
                self.weight.device(),
            )
        } else {
            Err(vatra_core::VatraError::InvalidArgument(
                "Embedding input must be 1D or 2D".to_string(),
            ))
        }
    }

    fn parameters(&self) -> Vec<Tensor> {
        vec![self.weight.clone()]
    }

    fn named_parameters(&self) -> Vec<(String, Tensor)> {
        vec![("weight".to_string(), self.weight.clone())]
    }
}
