//! Convolutional layers

use crate::Module;
use rand_distr::{Distribution, Normal};
use vatra_core::{Device, Shape, Tensor, VatraError, VatraResult};

/// 1D Convolution layer
pub struct Conv1d {
    /// Weight [out_channels, in_channels, kernel_size]
    pub weight: Tensor,
    /// Optional bias [out_channels]
    pub bias: Option<Tensor>,
    /// Stride
    pub stride: usize,
    /// Padding
    pub padding: usize,
    training: bool,
}

impl Conv1d {
    pub fn new(
        in_channels: usize,
        out_channels: usize,
        kernel_size: usize,
        stride: usize,
        padding: usize,
        bias: bool,
        device: Device,
    ) -> VatraResult<Self> {
        let std = (2.0 / (in_channels * kernel_size) as f32).sqrt();
        let weight = init_tensor([out_channels, in_channels, kernel_size], std, device)?;
        let bias_tensor = if bias {
            Some(Tensor::zeros([out_channels], device)?)
        } else {
            None
        };

        Ok(Self {
            weight,
            bias: bias_tensor,
            stride,
            padding,
            training: true,
        })
    }
}

impl Module for Conv1d {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // Simplified CPU implementation via im2col
        conv1d_forward(
            x,
            &self.weight,
            self.bias.as_ref(),
            self.stride,
            self.padding,
        )
    }

    fn parameters(&self) -> Vec<Tensor> {
        let mut params = vec![self.weight.clone()];
        if let Some(ref b) = self.bias {
            params.push(b.clone());
        }
        params
    }
}

/// 2D Convolution layer
#[derive(Clone)]
pub struct Conv2d {
    /// Weight [out_channels, in_channels, kernel_h, kernel_w]
    pub weight: Tensor,
    /// Optional bias [out_channels]
    pub bias: Option<Tensor>,
    /// Stride (h, w)
    pub stride: (usize, usize),
    /// Padding (h, w)
    pub padding: (usize, usize),
    training: bool,
}

impl Conv2d {
    /// Create a new Conv2d layer
    pub fn new(
        in_channels: usize,
        out_channels: usize,
        kernel_size: (usize, usize),
        stride: (usize, usize),
        padding: (usize, usize),
        bias: bool,
        device: Device,
    ) -> VatraResult<Self> {
        let (kh, kw) = kernel_size;
        let std = (2.0 / (in_channels * kh * kw) as f32).sqrt();
        let weight = init_tensor([out_channels, in_channels, kh, kw], std, device)?;

        let bias_tensor = if bias {
            Some(Tensor::zeros([out_channels], device)?)
        } else {
            None
        };

        Ok(Self {
            weight,
            bias: bias_tensor,
            stride,
            padding,
            training: true,
        })
    }

    /// Convenience constructor with square kernel
    pub fn square(
        in_channels: usize,
        out_channels: usize,
        kernel_size: usize,
        device: Device,
    ) -> VatraResult<Self> {
        Self::new(
            in_channels,
            out_channels,
            (kernel_size, kernel_size),
            (1, 1),
            (0, 0),
            true,
            device,
        )
    }
}

impl Module for Conv2d {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // x: [batch, in_channels, height, width]
        conv2d_forward(
            x,
            &self.weight,
            self.bias.as_ref(),
            self.stride,
            self.padding,
        )
    }

    fn parameters(&self) -> Vec<Tensor> {
        let mut params = vec![self.weight.clone()];
        if let Some(ref b) = self.bias {
            params.push(b.clone());
        }
        params
    }

    fn train(&mut self, mode: bool) {
        self.training = mode;
    }
}

// ========== Implementation helpers ==========

fn init_tensor<const N: usize>(shape: [usize; N], std: f32, device: Device) -> VatraResult<Tensor> {
    let numel: usize = shape.iter().product();
    let mut rng = rand::thread_rng();
    let dist = Normal::new(0.0, std).unwrap();
    let data: Vec<f32> = (0..numel).map(|_| dist.sample(&mut rng)).collect();
    Tensor::from_slice(&data, shape.to_vec(), device)
}

fn conv1d_forward(
    x: &Tensor,
    weight: &Tensor,
    bias: Option<&Tensor>,
    stride: usize,
    padding: usize,
) -> VatraResult<Tensor> {
    let x_data = x.to_vec()?;
    let w_data = weight.to_vec()?;

    let x_shape = x.shape();
    let w_shape = weight.shape();

    // x: [batch, in_channels, length]
    // w: [out_channels, in_channels, kernel_size]
    let batch = x_shape[0];
    let in_ch = x_shape[1];
    let in_len = x_shape[2];
    let out_ch = w_shape[0];
    let kernel_size = w_shape[2];

    let out_len = (in_len + 2 * padding - kernel_size) / stride + 1;
    let mut out_data = vec![0.0f32; batch * out_ch * out_len];

    for b in 0..batch {
        for oc in 0..out_ch {
            for o in 0..out_len {
                let mut sum = 0.0f32;
                for ic in 0..in_ch {
                    for k in 0..kernel_size {
                        let in_pos = (o * stride + k) as isize - padding as isize;
                        if in_pos >= 0 && (in_pos as usize) < in_len {
                            let x_idx = b * in_ch * in_len + ic * in_len + in_pos as usize;
                            let w_idx = oc * in_ch * kernel_size + ic * kernel_size + k;
                            sum += x_data[x_idx] * w_data[w_idx];
                        }
                    }
                }
                out_data[b * out_ch * out_len + oc * out_len + o] = sum;
            }
        }
    }

    let mut out = Tensor::from_slice(&out_data, [batch, out_ch, out_len], x.device())?;

    if let Some(b) = bias {
        let bias_data = b.to_vec()?;
        let mut biased = out.to_vec()?;
        for batch_idx in 0..batch {
            for oc in 0..out_ch {
                for o in 0..out_len {
                    biased[batch_idx * out_ch * out_len + oc * out_len + o] += bias_data[oc];
                }
            }
        }
        out = Tensor::from_slice(&biased, [batch, out_ch, out_len], x.device())?;
    }

    Ok(out)
}

fn conv2d_forward(
    x: &Tensor,
    weight: &Tensor,
    bias: Option<&Tensor>,
    stride: (usize, usize),
    padding: (usize, usize),
) -> VatraResult<Tensor> {
    let x_data = x.to_vec()?;
    let w_data = weight.to_vec()?;

    let x_shape = x.shape();
    let w_shape = weight.shape();

    // x: [batch, in_channels, h, w]
    // weight: [out_channels, in_channels, kh, kw]
    let batch = x_shape[0];
    let in_ch = x_shape[1];
    let in_h = x_shape[2];
    let in_w = x_shape[3];
    let out_ch = w_shape[0];
    let kh = w_shape[2];
    let kw = w_shape[3];

    let (sh, sw) = stride;
    let (ph, pw) = padding;

    let out_h = (in_h + 2 * ph - kh) / sh + 1;
    let out_w = (in_w + 2 * pw - kw) / sw + 1;

    let mut out_data = vec![0.0f32; batch * out_ch * out_h * out_w];

    for b in 0..batch {
        for oc in 0..out_ch {
            for oh in 0..out_h {
                for ow in 0..out_w {
                    let mut sum = 0.0f32;
                    for ic in 0..in_ch {
                        for ki in 0..kh {
                            for kj in 0..kw {
                                let ih = (oh * sh + ki) as isize - ph as isize;
                                let iw = (ow * sw + kj) as isize - pw as isize;

                                if ih >= 0 && ih < in_h as isize && iw >= 0 && iw < in_w as isize {
                                    let x_idx = b * in_ch * in_h * in_w
                                        + ic * in_h * in_w
                                        + ih as usize * in_w
                                        + iw as usize;
                                    let w_idx = oc * in_ch * kh * kw + ic * kh * kw + ki * kw + kj;
                                    sum += x_data[x_idx] * w_data[w_idx];
                                }
                            }
                        }
                    }
                    out_data[b * out_ch * out_h * out_w + oc * out_h * out_w + oh * out_w + ow] =
                        sum;
                }
            }
        }
    }

    let mut out = Tensor::from_slice(&out_data, [batch, out_ch, out_h, out_w], x.device())?;

    if let Some(bias_tensor) = bias {
        let bias_data = bias_tensor.to_vec()?;
        let mut biased = out.to_vec()?;
        for b in 0..batch {
            for oc in 0..out_ch {
                for oh in 0..out_h {
                    for ow in 0..out_w {
                        biased
                            [b * out_ch * out_h * out_w + oc * out_h * out_w + oh * out_w + ow] +=
                            bias_data[oc];
                    }
                }
            }
        }
        out = Tensor::from_slice(&biased, [batch, out_ch, out_h, out_w], x.device())?;
    }

    Ok(out)
}
