//! Linear (fully connected) layer

use crate::Module;
use rand::Rng;
use rand_distr::{Distribution, Normal};
use vatra_core::{Device, Tensor, VatraResult};

/// Fully connected linear layer: y = x @ W^T + b
#[derive(Clone)]
pub struct Linear {
    /// Weight matrix [out_features, in_features]
    pub weight: Tensor,
    /// Optional bias [out_features]
    pub bias: Option<Tensor>,
    /// Whether in training mode
    training: bool,
}

impl Linear {
    /// Create a new Linear layer
    ///
    /// # Arguments
    /// * `in_features` — Size of input
    /// * `out_features` — Size of output
    /// * `bias` — Whether to include bias
    /// * `device` — Device to place parameters
    pub fn new(
        in_features: usize,
        out_features: usize,
        bias: bool,
        device: Device,
    ) -> VatraResult<Self> {
        // Kaiming/He initialization
        let std = (2.0 / in_features as f32).sqrt();
        let weight = Self::init_weight(out_features, in_features, std, device)?;

        let bias_tensor = if bias {
            Some(Tensor::zeros([out_features], device)?)
        } else {
            None
        };

        Ok(Self {
            weight,
            bias: bias_tensor,
            training: true,
        })
    }

    /// Create a Linear layer with specified initialization
    pub fn with_init(
        in_features: usize,
        out_features: usize,
        init_std: f32,
        device: Device,
    ) -> VatraResult<Self> {
        let weight = Self::init_weight(out_features, in_features, init_std, device)?;
        let bias = Some(Tensor::zeros([out_features], device)?);

        Ok(Self {
            weight,
            bias,
            training: true,
        })
    }

    fn init_weight(
        out_features: usize,
        in_features: usize,
        std: f32,
        device: Device,
    ) -> VatraResult<Tensor> {
        let mut rng = rand::thread_rng();
        let dist = Normal::new(0.0, std).unwrap();
        let data: Vec<f32> = (0..out_features * in_features)
            .map(|_| dist.sample(&mut rng))
            .collect();
        Tensor::from_slice(&data, [out_features, in_features], device)
    }

    /// Get input features
    pub fn in_features(&self) -> usize {
        self.weight.shape()[1]
    }

    /// Get output features
    pub fn out_features(&self) -> usize {
        self.weight.shape()[0]
    }
}

impl Module for Linear {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // x: [batch, in_features]
        // weight: [out_features, in_features]
        // out = x @ weight.T

        let weight_t = self.weight.t()?;
        let mut out = vatra_ops::matmul(x, &weight_t)?;

        if let Some(ref bias) = self.bias {
            out = vatra_ops::broadcast_add(&out, bias)?;
        }

        Ok(out)
    }

    fn parameters(&self) -> Vec<Tensor> {
        let mut params = vec![self.weight.clone()];
        if let Some(ref bias) = self.bias {
            params.push(bias.clone());
        }
        params
    }

    fn named_parameters(&self) -> Vec<(String, Tensor)> {
        let mut params = vec![("weight".to_string(), self.weight.clone())];
        if let Some(ref bias) = self.bias {
            params.push(("bias".to_string(), bias.clone()));
        }
        params
    }

    fn train(&mut self, mode: bool) {
        self.training = mode;
    }

    fn training(&self) -> bool {
        self.training
    }
}
