//! Normalization layers

use crate::Module;
use vatra_core::{Device, Tensor, VatraResult};

/// Batch Normalization for 1D inputs (e.g., after Linear)
pub struct BatchNorm1d {
    /// Learnable scale parameter
    pub gamma: Tensor,
    /// Learnable shift parameter
    pub beta: Tensor,
    /// Running mean (for inference)
    pub running_mean: Tensor,
    /// Running variance (for inference)
    pub running_var: Tensor,
    /// Epsilon for numerical stability
    eps: f32,
    /// Momentum for running stats
    momentum: f32,
    training: bool,
}

impl BatchNorm1d {
    pub fn new(num_features: usize, device: Device) -> VatraResult<Self> {
        Ok(Self {
            gamma: Tensor::ones([num_features], device)?,
            beta: Tensor::zeros([num_features], device)?,
            running_mean: Tensor::zeros([num_features], device)?,
            running_var: Tensor::ones([num_features], device)?,
            eps: 1e-5,
            momentum: 0.1,
            training: true,
        })
    }
}

impl Module for BatchNorm1d {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // x: [batch, features]
        let x_data = x.to_vec()?;
        let batch = x.shape()[0];
        let features = x.shape()[1];

        let gamma = self.gamma.to_vec()?;
        let beta = self.beta.to_vec()?;

        let mut out = vec![0.0f32; batch * features];

        if self.training {
            // Compute batch statistics
            for f in 0..features {
                let mut mean = 0.0f32;
                for b in 0..batch {
                    mean += x_data[b * features + f];
                }
                mean /= batch as f32;

                let mut var = 0.0f32;
                for b in 0..batch {
                    let diff = x_data[b * features + f] - mean;
                    var += diff * diff;
                }
                var /= batch as f32;

                let std = (var + self.eps).sqrt();
                for b in 0..batch {
                    let normalized = (x_data[b * features + f] - mean) / std;
                    out[b * features + f] = gamma[f] * normalized + beta[f];
                }
            }
        } else {
            // Use running statistics
            let rm = self.running_mean.to_vec()?;
            let rv = self.running_var.to_vec()?;

            for f in 0..features {
                let std = (rv[f] + self.eps).sqrt();
                for b in 0..batch {
                    let normalized = (x_data[b * features + f] - rm[f]) / std;
                    out[b * features + f] = gamma[f] * normalized + beta[f];
                }
            }
        }

        Tensor::from_slice(&out, x.shape().clone(), x.device())
    }

    fn parameters(&self) -> Vec<Tensor> {
        vec![self.gamma.clone(), self.beta.clone()]
    }

    fn train(&mut self, mode: bool) {
        self.training = mode;
    }
}

/// Batch Normalization for 2D inputs (e.g., after Conv2d)
pub struct BatchNorm2d {
    inner: BatchNorm1d,
}

impl BatchNorm2d {
    pub fn new(num_features: usize, device: Device) -> VatraResult<Self> {
        Ok(Self {
            inner: BatchNorm1d::new(num_features, device)?,
        })
    }
}

impl Module for BatchNorm2d {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        // x: [batch, channels, h, w] -> reshape, normalize, reshape back
        let shape = x.shape();
        let batch = shape[0];
        let channels = shape[1];
        let h = shape[2];
        let w = shape[3];

        // Transpose to [batch, h, w, channels] then flatten to [batch*h*w, channels]
        let x_data = x.to_vec()?;
        let mut transposed = vec![0.0f32; x_data.len()];

        for b in 0..batch {
            for c in 0..channels {
                for i in 0..h {
                    for j in 0..w {
                        let src = b * channels * h * w + c * h * w + i * w + j;
                        let dst = b * h * w * channels + i * w * channels + j * channels + c;
                        transposed[dst] = x_data[src];
                    }
                }
            }
        }

        // Apply 1D batch norm across channels
        let flat = Tensor::from_slice(&transposed, [batch * h * w, channels], x.device())?;
        let normed = self.inner.forward(&flat)?;
        let normed_data = normed.to_vec()?;

        // Transpose back
        let mut result = vec![0.0f32; x_data.len()];
        for b in 0..batch {
            for c in 0..channels {
                for i in 0..h {
                    for j in 0..w {
                        let src = b * h * w * channels + i * w * channels + j * channels + c;
                        let dst = b * channels * h * w + c * h * w + i * w + j;
                        result[dst] = normed_data[src];
                    }
                }
            }
        }

        Tensor::from_slice(&result, shape.clone(), x.device())
    }

    fn parameters(&self) -> Vec<Tensor> {
        self.inner.parameters()
    }
}

/// Layer Normalization
pub struct LayerNorm {
    /// Learnable scale
    pub gamma: Tensor,
    /// Learnable shift
    pub beta: Tensor,
    /// Normalized shape
    normalized_shape: Vec<usize>,
    eps: f32,
}

impl LayerNorm {
    pub fn new(normalized_shape: Vec<usize>, device: Device) -> VatraResult<Self> {
        let numel: usize = normalized_shape.iter().product();
        Ok(Self {
            gamma: Tensor::ones(normalized_shape.clone(), device)?,
            beta: Tensor::zeros(normalized_shape.clone(), device)?,
            normalized_shape,
            eps: 1e-5,
        })
    }
}

impl Module for LayerNorm {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        let x_data = x.to_vec()?;
        let norm_size: usize = self.normalized_shape.iter().product();
        let batch_size = x.numel() / norm_size;

        let gamma = self.gamma.to_vec()?;
        let beta = self.beta.to_vec()?;

        let mut out = vec![0.0f32; x.numel()];

        for b in 0..batch_size {
            let start = b * norm_size;
            let end = start + norm_size;
            let slice = &x_data[start..end];

            // Compute mean and variance
            let mean: f32 = slice.iter().sum::<f32>() / norm_size as f32;
            let var: f32 =
                slice.iter().map(|&v| (v - mean).powi(2)).sum::<f32>() / norm_size as f32;
            let std = (var + self.eps).sqrt();

            for (i, &v) in slice.iter().enumerate() {
                let normalized = (v - mean) / std;
                out[start + i] = gamma[i % gamma.len()] * normalized + beta[i % beta.len()];
            }
        }

        Tensor::from_slice(&out, x.shape().clone(), x.device())
    }

    fn parameters(&self) -> Vec<Tensor> {
        vec![self.gamma.clone(), self.beta.clone()]
    }
}
