//! Functional API for common operations (like torch.nn.functional)

use crate::Module;
use vatra_core::{Tensor, VatraResult};

/// Cross entropy loss
pub fn cross_entropy(input: &Tensor, target: &Tensor) -> VatraResult<Tensor> {
    let log_softmax = vatra_ops::log_softmax(input, -1)?;
    let neg_log = vatra_ops::neg(&log_softmax)?;

    // For now, simple mean over all elements
    // Full implementation would index by target
    vatra_ops::mean(&neg_log, None)
}

/// Mean squared error loss
pub fn mse_loss(input: &Tensor, target: &Tensor) -> VatraResult<Tensor> {
    let diff = vatra_ops::sub(input, target)?;
    let sq = vatra_ops::mul(&diff, &diff)?;
    vatra_ops::mean(&sq, None)
}

/// L1 loss (mean absolute error)
pub fn l1_loss(input: &Tensor, target: &Tensor) -> VatraResult<Tensor> {
    let diff = vatra_ops::sub(input, target)?;
    let abs_diff = vatra_ops::abs(&diff)?;
    vatra_ops::mean(&abs_diff, None)
}

/// Binary cross entropy loss
pub fn binary_cross_entropy(input: &Tensor, target: &Tensor) -> VatraResult<Tensor> {
    let one = Tensor::ones(input.shape().clone(), input.device())?;
    let eps = Tensor::full(input.shape().clone(), 1e-7, input.device())?;

    // -[y * log(p + eps) + (1-y) * log(1-p + eps)]
    let input_safe = vatra_ops::add(input, &eps)?;
    let one_minus_input = vatra_ops::sub(&one, input)?;
    let one_minus_input_safe = vatra_ops::add(&one_minus_input, &eps)?;

    let log_input = vatra_ops::log(&input_safe)?;
    let log_one_minus = vatra_ops::log(&one_minus_input_safe)?;

    let term1 = vatra_ops::mul(target, &log_input)?;
    let one_minus_target = vatra_ops::sub(&one, target)?;
    let term2 = vatra_ops::mul(&one_minus_target, &log_one_minus)?;

    let sum = vatra_ops::add(&term1, &term2)?;
    let neg = vatra_ops::neg(&sum)?;
    vatra_ops::mean(&neg, None)
}

/// Softmax along dimension
pub fn softmax(input: &Tensor, dim: isize) -> VatraResult<Tensor> {
    vatra_ops::softmax(input, dim)
}

/// Log softmax along dimension
pub fn log_softmax(input: &Tensor, dim: isize) -> VatraResult<Tensor> {
    vatra_ops::log_softmax(input, dim)
}

/// ReLU activation
pub fn relu(input: &Tensor) -> VatraResult<Tensor> {
    vatra_ops::relu(input)
}

/// Sigmoid activation
pub fn sigmoid(input: &Tensor) -> VatraResult<Tensor> {
    vatra_ops::sigmoid(input)
}

/// Tanh activation
pub fn tanh(input: &Tensor) -> VatraResult<Tensor> {
    vatra_ops::tanh(input)
}

/// Dropout (functional)
pub fn dropout(input: &Tensor, p: f32, training: bool) -> VatraResult<Tensor> {
    if !training {
        return Ok(input.clone());
    }

    let mut dropout = crate::Dropout::new(p);
    dropout.train(training);
    dropout.forward(input)
}

/// Linear transformation (functional)
pub fn linear(input: &Tensor, weight: &Tensor, bias: Option<&Tensor>) -> VatraResult<Tensor> {
    let weight_t = weight.t()?;
    let mut out = vatra_ops::matmul(input, &weight_t)?;

    if let Some(b) = bias {
        out = vatra_ops::add(&out, b)?;
    }

    Ok(out)
}
