//! Dropout layer

use crate::Module;
use rand::Rng;
use vatra_core::{Tensor, VatraResult};

/// Dropout layer for regularization
pub struct Dropout {
    /// Probability of dropping a unit
    p: f32,
    /// Whether in training mode
    training: bool,
}

impl Dropout {
    /// Create a new Dropout layer
    pub fn new(p: f32) -> Self {
        Self { p, training: true }
    }
}

impl Default for Dropout {
    fn default() -> Self {
        Self::new(0.5)
    }
}

impl Module for Dropout {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        if !self.training || self.p == 0.0 {
            return Ok(x.clone());
        }

        if self.p >= 1.0 {
            return Tensor::zeros(x.shape().clone(), x.device());
        }

        let data = x.to_vec()?;
        let mut rng = rand::thread_rng();
        let scale = 1.0 / (1.0 - self.p); // Inverted dropout

        let result: Vec<f32> = data
            .iter()
            .map(|&v| {
                if rng.r#gen::<f32>() < self.p {
                    0.0
                } else {
                    v * scale
                }
            })
            .collect();

        Tensor::from_slice(&result, x.shape().clone(), x.device())
    }

    fn train(&mut self, mode: bool) {
        self.training = mode;
    }

    fn training(&self) -> bool {
        self.training
    }
}

/// 2D Dropout (for conv layers, drops entire channels)
pub struct Dropout2d {
    p: f32,
    training: bool,
}

impl Dropout2d {
    pub fn new(p: f32) -> Self {
        Self { p, training: true }
    }
}

impl Module for Dropout2d {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        if !self.training || self.p == 0.0 {
            return Ok(x.clone());
        }

        let shape = x.shape();
        let batch = shape[0];
        let channels = shape[1];
        let spatial: usize = shape.dims()[2..].iter().product();

        let data = x.to_vec()?;
        let mut rng = rand::thread_rng();
        let scale = 1.0 / (1.0 - self.p);

        let mut result = data.clone();
        for b in 0..batch {
            for c in 0..channels {
                if rng.r#gen::<f32>() < self.p {
                    let start = (b * channels + c) * spatial;
                    for i in 0..spatial {
                        result[start + i] = 0.0;
                    }
                } else {
                    let start = (b * channels + c) * spatial;
                    for i in 0..spatial {
                        result[start + i] *= scale;
                    }
                }
            }
        }

        Tensor::from_slice(&result, shape.clone(), x.device())
    }

    fn train(&mut self, mode: bool) {
        self.training = mode;
    }
}
