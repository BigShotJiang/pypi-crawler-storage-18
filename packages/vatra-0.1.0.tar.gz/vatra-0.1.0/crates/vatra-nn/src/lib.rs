#![allow(dead_code, unused_imports, unused_variables)]
//! Vatra NN — Neural Network Layers (PyTorch-like API)
//!
//! Provides familiar layer abstractions:
//! - `Linear`, `Conv2d`, `BatchNorm`, `Embedding`, etc.
//! - `Sequential` container
//! - `Module` trait for custom layers

mod activation;
mod conv;
mod dropout;
mod embedding;
pub mod functional;
mod linear;
mod module;
mod norm;
mod sequential;

pub use activation::{GELU, LeakyReLU, ReLU, Sigmoid, Softmax, Tanh};
pub use conv::{Conv1d, Conv2d};
pub use dropout::{Dropout, Dropout2d};
pub use embedding::Embedding;
pub use functional as F;
pub use linear::Linear;
pub use module::Module;
pub use norm::{BatchNorm1d, BatchNorm2d, LayerNorm};
pub use sequential::Sequential;
