//! Sequential container module

use crate::Module;
use vatra_core::{Tensor, VatraResult};

/// Sequential container — stacks modules and runs them in order
pub struct Sequential {
    layers: Vec<Box<dyn Module + Send + Sync>>,
}

impl Sequential {
    /// Create an empty Sequential
    pub fn new() -> Self {
        Self { layers: Vec::new() }
    }

    /// Create Sequential from a vector of modules
    pub fn from_layers(layers: Vec<Box<dyn Module + Send + Sync>>) -> Self {
        Self { layers }
    }

    /// Add a layer to the end
    pub fn push<M: Module + Send + Sync + 'static>(&mut self, module: M) {
        self.layers.push(Box::new(module));
    }

    /// Add a layer (builder pattern)
    pub fn add<M: Module + Send + Sync + 'static>(mut self, module: M) -> Self {
        self.layers.push(Box::new(module));
        self
    }

    /// Get number of layers
    pub fn len(&self) -> usize {
        self.layers.len()
    }

    /// Check if empty
    pub fn is_empty(&self) -> bool {
        self.layers.is_empty()
    }

    /// Iterate over layers
    pub fn iter(&self) -> impl Iterator<Item = &(dyn Module + Send + Sync)> {
        self.layers.iter().map(|b| b.as_ref())
    }
}

impl Default for Sequential {
    fn default() -> Self {
        Self::new()
    }
}

impl Module for Sequential {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        let mut out = x.clone();
        for layer in &self.layers {
            out = layer.forward(&out)?;
        }
        Ok(out)
    }

    fn parameters(&self) -> Vec<Tensor> {
        self.layers.iter().flat_map(|l| l.parameters()).collect()
    }

    fn named_parameters(&self) -> Vec<(String, Tensor)> {
        self.layers
            .iter()
            .enumerate()
            .flat_map(|(i, l)| {
                l.named_parameters()
                    .into_iter()
                    .map(move |(name, p)| (format!("{}.{}", i, name), p))
            })
            .collect()
    }

    fn train(&mut self, mode: bool) {
        for layer in &mut self.layers {
            layer.train(mode);
        }
    }
}

/// Macro for creating Sequential models (PyTorch-like syntax)
#[macro_export]
macro_rules! sequential {
    ($($layer:expr),* $(,)?) => {
        Sequential::new()
            $(.add($layer))*
    };
}
