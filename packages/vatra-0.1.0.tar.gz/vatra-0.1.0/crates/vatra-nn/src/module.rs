//! Module trait — base for all neural network layers

use vatra_core::{Tensor, VatraResult};

/// Base trait for neural network modules (PyTorch-style)
pub trait Module {
    /// Forward pass
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor>;

    /// Get all trainable parameters
    fn parameters(&self) -> Vec<Tensor> {
        Vec::new()
    }

    /// Get named parameters (for serialization)
    fn named_parameters(&self) -> Vec<(String, Tensor)> {
        Vec::new()
    }

    /// Set training/evaluation mode
    fn train(&mut self, _mode: bool) {}

    /// Check if in training mode
    fn training(&self) -> bool {
        true
    }

    /// Number of trainable parameters
    fn num_parameters(&self) -> usize {
        self.parameters().iter().map(|p| p.numel()).sum()
    }
}

/// Extension trait for applying modules with call syntax
pub trait ModuleExt: Module {
    /// Apply the module (syntactic sugar for forward)
    fn call(&self, x: &Tensor) -> VatraResult<Tensor> {
        self.forward(x)
    }
}

impl<T: Module> ModuleExt for T {}

/// A module that can be trained
pub trait TrainableModule: Module {
    /// Zero all gradients
    fn zero_grad(&mut self);

    /// Apply gradients with learning rate
    fn apply_gradients(&mut self, grads: &[Tensor], lr: f32) -> VatraResult<()>;
}
