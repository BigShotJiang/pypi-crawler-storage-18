//! Activation function modules

use crate::Module;
use vatra_core::{Tensor, VatraResult};

/// ReLU activation module
#[derive(Debug, Clone, Copy, Default)]
pub struct ReLU;

impl Module for ReLU {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::relu(x)
    }
}

/// Sigmoid activation module
#[derive(Debug, Clone, Copy, Default)]
pub struct Sigmoid;

impl Module for Sigmoid {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::sigmoid(x)
    }
}

/// Tanh activation module
#[derive(Debug, Clone, Copy, Default)]
pub struct Tanh;

impl Module for Tanh {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::tanh(x)
    }
}

/// GELU activation module
#[derive(Debug, Clone, Copy, Default)]
pub struct GELU;

impl Module for GELU {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::gelu(x)
    }
}

/// SiLU (Swish) activation module
#[derive(Debug, Clone, Copy, Default)]
pub struct SiLU;

impl Module for SiLU {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::silu(x)
    }
}

/// Softmax activation module
pub struct Softmax {
    dim: isize,
}

impl Softmax {
    pub fn new(dim: isize) -> Self {
        Self { dim }
    }
}

impl Default for Softmax {
    fn default() -> Self {
        Self { dim: -1 }
    }
}

impl Module for Softmax {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::softmax(x, self.dim)
    }
}

/// LeakyReLU activation module
pub struct LeakyReLU {
    alpha: f32,
}

impl LeakyReLU {
    pub fn new(alpha: f32) -> Self {
        Self { alpha }
    }
}

impl Default for LeakyReLU {
    fn default() -> Self {
        Self { alpha: 0.01 }
    }
}

impl Module for LeakyReLU {
    fn forward(&self, x: &Tensor) -> VatraResult<Tensor> {
        vatra_ops::leaky_relu(x, self.alpha)
    }
}
