#![allow(dead_code, unused_imports, unused_variables)]
//! Vatra Optimizers — Training optimizers
//!
//! Provides standard optimizers:
//! - SGD with momentum
//! - Adam and AdamW

mod adam;
mod sgd;

pub use adam::{Adam, AdamW};
pub use sgd::SGD;

use vatra_core::{Tensor, VatraResult};

/// Base trait for optimizers
pub trait Optimizer {
    /// Perform a single optimization step
    fn step(&mut self, gradients: &[Tensor]) -> VatraResult<()>;

    /// Zero all gradients
    fn zero_grad(&mut self);

    /// Get current learning rate
    fn lr(&self) -> f32;

    /// Set learning rate
    fn set_lr(&mut self, lr: f32);
}
