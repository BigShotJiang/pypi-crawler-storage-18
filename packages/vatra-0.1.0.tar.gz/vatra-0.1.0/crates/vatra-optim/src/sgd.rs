//! Stochastic Gradient Descent with momentum

use crate::Optimizer;
use vatra_core::{Device, Tensor, VatraResult};

/// SGD optimizer with optional momentum and weight decay
pub struct SGD {
    /// Parameters to optimize
    params: Vec<Tensor>,
    /// Learning rate
    lr: f32,
    /// Momentum factor
    momentum: f32,
    /// Weight decay (L2 regularization)
    weight_decay: f32,
    /// Whether to use Nesterov momentum
    nesterov: bool,
    /// Velocity buffers for momentum
    velocities: Vec<Option<Vec<f32>>>,
}

impl SGD {
    /// Create a new SGD optimizer
    pub fn new(params: Vec<Tensor>, lr: f32) -> Self {
        let n = params.len();
        Self {
            params,
            lr,
            momentum: 0.0,
            weight_decay: 0.0,
            nesterov: false,
            velocities: vec![None; n],
        }
    }

    /// Builder: set momentum
    pub fn momentum(mut self, momentum: f32) -> Self {
        self.momentum = momentum;
        self
    }

    /// Builder: set weight decay
    pub fn weight_decay(mut self, weight_decay: f32) -> Self {
        self.weight_decay = weight_decay;
        self
    }

    /// Builder: enable Nesterov momentum
    pub fn nesterov(mut self, nesterov: bool) -> Self {
        self.nesterov = nesterov;
        self
    }

    /// Get parameters
    pub fn params(&self) -> &[Tensor] {
        &self.params
    }

    /// Get mutable parameters
    pub fn params_mut(&mut self) -> &mut [Tensor] {
        &mut self.params
    }
}

impl Optimizer for SGD {
    fn step(&mut self, gradients: &[Tensor]) -> VatraResult<()> {
        if gradients.len() != self.params.len() {
            return Err(vatra_core::VatraError::InvalidArgument(format!(
                "Expected {} gradients, got {}",
                self.params.len(),
                gradients.len()
            )));
        }

        for (i, (param, grad)) in self.params.iter_mut().zip(gradients.iter()).enumerate() {
            let mut param_data = param.to_vec()?;
            let grad_data = grad.to_vec()?;

            // Apply weight decay
            if self.weight_decay != 0.0 {
                for (p, g) in param_data.iter_mut().zip(grad_data.iter()) {
                    *p -= self.weight_decay * self.lr * *p;
                }
            }

            // Apply momentum
            if self.momentum != 0.0 {
                let velocity =
                    self.velocities[i].get_or_insert_with(|| vec![0.0; param_data.len()]);

                for (v, g) in velocity.iter_mut().zip(grad_data.iter()) {
                    *v = self.momentum * *v + *g;
                }

                if self.nesterov {
                    for (p, (v, g)) in param_data
                        .iter_mut()
                        .zip(velocity.iter().zip(grad_data.iter()))
                    {
                        *p -= self.lr * (self.momentum * *v + *g);
                    }
                } else {
                    for (p, v) in param_data.iter_mut().zip(velocity.iter()) {
                        *p -= self.lr * *v;
                    }
                }
            } else {
                // Simple gradient descent
                for (p, g) in param_data.iter_mut().zip(grad_data.iter()) {
                    *p -= self.lr * *g;
                }
            }

            // Update parameter tensor
            *param = Tensor::from_slice(&param_data, param.shape().clone(), param.device())?;
        }

        Ok(())
    }

    fn zero_grad(&mut self) {
        // Velocities are kept, only gradients are zeroed (handled externally)
    }

    fn lr(&self) -> f32 {
        self.lr
    }

    fn set_lr(&mut self, lr: f32) {
        self.lr = lr;
    }
}
