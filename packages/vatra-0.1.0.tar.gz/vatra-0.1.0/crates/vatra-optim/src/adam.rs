//! Adam and AdamW optimizers

use crate::Optimizer;
use vatra_core::{Tensor, VatraResult};

/// Adam optimizer
pub struct Adam {
    params: Vec<Tensor>,
    lr: f32,
    beta1: f32,
    beta2: f32,
    eps: f32,
    weight_decay: f32,
    /// First moment estimates
    m: Vec<Vec<f32>>,
    /// Second moment estimates
    v: Vec<Vec<f32>>,
    /// Step counter
    t: usize,
}

impl Adam {
    /// Create a new Adam optimizer
    pub fn new(params: Vec<Tensor>, lr: f32) -> Self {
        let n = params.len();
        Self {
            params,
            lr,
            beta1: 0.9,
            beta2: 0.999,
            eps: 1e-8,
            weight_decay: 0.0,
            m: vec![Vec::new(); n],
            v: vec![Vec::new(); n],
            t: 0,
        }
    }

    /// Builder: set betas
    pub fn betas(mut self, beta1: f32, beta2: f32) -> Self {
        self.beta1 = beta1;
        self.beta2 = beta2;
        self
    }

    /// Builder: set epsilon
    pub fn eps(mut self, eps: f32) -> Self {
        self.eps = eps;
        self
    }

    /// Builder: set weight decay (L2)
    pub fn weight_decay(mut self, weight_decay: f32) -> Self {
        self.weight_decay = weight_decay;
        self
    }

    /// Get parameters
    pub fn params(&self) -> &[Tensor] {
        &self.params
    }
}

impl Optimizer for Adam {
    fn step(&mut self, gradients: &[Tensor]) -> VatraResult<()> {
        if gradients.len() != self.params.len() {
            return Err(vatra_core::VatraError::InvalidArgument(format!(
                "Expected {} gradients, got {}",
                self.params.len(),
                gradients.len()
            )));
        }

        self.t += 1;
        let t = self.t as f32;

        // Bias-corrected learning rate
        let bias_correction1 = 1.0 - self.beta1.powi(self.t as i32);
        let bias_correction2 = 1.0 - self.beta2.powi(self.t as i32);
        let lr = self.lr * (bias_correction2.sqrt() / bias_correction1);

        for (i, (param, grad)) in self.params.iter_mut().zip(gradients.iter()).enumerate() {
            let mut param_data = param.to_vec()?;
            let grad_data = grad.to_vec()?;

            // Initialize moment buffers if needed
            if self.m[i].is_empty() {
                self.m[i] = vec![0.0; param_data.len()];
                self.v[i] = vec![0.0; param_data.len()];
            }

            // Apply L2 weight decay
            let mut grad_with_decay = grad_data.clone();
            if self.weight_decay != 0.0 {
                for (g, p) in grad_with_decay.iter_mut().zip(param_data.iter()) {
                    *g += self.weight_decay * *p;
                }
            }

            // Update biased first moment estimate
            for (m, g) in self.m[i].iter_mut().zip(grad_with_decay.iter()) {
                *m = self.beta1 * *m + (1.0 - self.beta1) * *g;
            }

            // Update biased second moment estimate
            for (v, g) in self.v[i].iter_mut().zip(grad_with_decay.iter()) {
                *v = self.beta2 * *v + (1.0 - self.beta2) * *g * *g;
            }

            // Update parameters
            for (p, (m, v)) in param_data
                .iter_mut()
                .zip(self.m[i].iter().zip(self.v[i].iter()))
            {
                *p -= lr * *m / (v.sqrt() + self.eps);
            }

            *param = Tensor::from_slice(&param_data, param.shape().clone(), param.device())?;
        }

        Ok(())
    }

    fn zero_grad(&mut self) {
        // Moment buffers are kept
    }

    fn lr(&self) -> f32 {
        self.lr
    }

    fn set_lr(&mut self, lr: f32) {
        self.lr = lr;
    }
}

/// AdamW optimizer (decoupled weight decay)
pub struct AdamW {
    inner: Adam,
}

impl AdamW {
    /// Create a new AdamW optimizer
    pub fn new(params: Vec<Tensor>, lr: f32) -> Self {
        Self {
            inner: Adam::new(params, lr),
        }
    }

    /// Builder: set betas
    pub fn betas(mut self, beta1: f32, beta2: f32) -> Self {
        self.inner = self.inner.betas(beta1, beta2);
        self
    }

    /// Builder: set weight decay
    pub fn weight_decay(mut self, weight_decay: f32) -> Self {
        self.inner = self.inner.weight_decay(weight_decay);
        self
    }

    /// Get parameters
    pub fn params(&self) -> &[Tensor] {
        self.inner.params()
    }
}

impl Optimizer for AdamW {
    fn step(&mut self, gradients: &[Tensor]) -> VatraResult<()> {
        // AdamW applies weight decay directly to parameters, not gradients
        // First, apply weight decay
        for param in &mut self.inner.params {
            if self.inner.weight_decay != 0.0 {
                let mut data = param.to_vec()?;
                for p in &mut data {
                    *p *= 1.0 - self.inner.lr * self.inner.weight_decay;
                }
                *param = Tensor::from_slice(&data, param.shape().clone(), param.device())?;
            }
        }

        // Store weight decay, set to 0 for inner Adam step
        let wd = self.inner.weight_decay;
        self.inner.weight_decay = 0.0;
        let result = self.inner.step(gradients);
        self.inner.weight_decay = wd;

        result
    }

    fn zero_grad(&mut self) {
        self.inner.zero_grad();
    }

    fn lr(&self) -> f32 {
        self.inner.lr()
    }

    fn set_lr(&mut self, lr: f32) {
        self.inner.set_lr(lr);
    }
}
