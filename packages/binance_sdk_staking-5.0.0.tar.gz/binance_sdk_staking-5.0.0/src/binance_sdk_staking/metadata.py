NAME = "binance-sdk-staking"
