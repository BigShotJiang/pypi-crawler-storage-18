# Changelog

All notable changes to the Eventdisplay-ML project will be documented in this file.
Changes for upcoming releases can be found in the [docs/changes](docs/changes) directory.

This changelog is generated using [Towncrier](https://towncrier.readthedocs.io/).

<!-- towncrier release notes start -->


## [v0.1.0](https://github.com/Eventdisplay/Eventdisplay-ML/releases/tag/v0.1.0) - 2025-12-22

First release of Eventdisplay-ML. Provides basic functionality for direction and energy reconstruction applied to VERITAS data and simulations.

### New Features

- Train and apply scripts for direction and energy reconstruction. ([#4](https://github.com/Eventdisplay/Eventdisplay-ML/pull/4))

### Maintenance

- Initial commit of CI workflows. ([#2](https://github.com/Eventdisplay/Eventdisplay-ML/pull/2))
- Initial commit and mv of python scripts from https://github.com/VERITAS-Observatory/EventDisplay_v4/pull/331. ([#3](https://github.com/Eventdisplay/Eventdisplay-ML/pull/3))
- Introduce data processing module to avoid code duplication. ([#8](https://github.com/Eventdisplay/Eventdisplay-ML/pull/8))
- Add unit tests. ([#10](https://github.com/Eventdisplay/Eventdisplay-ML/pull/10))
