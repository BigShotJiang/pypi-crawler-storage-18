"""Tests for plugin system."""
