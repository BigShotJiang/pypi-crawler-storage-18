"""Tests for configuration package."""
