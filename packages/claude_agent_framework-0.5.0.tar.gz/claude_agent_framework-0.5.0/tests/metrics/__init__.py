"""Tests for metrics package."""
