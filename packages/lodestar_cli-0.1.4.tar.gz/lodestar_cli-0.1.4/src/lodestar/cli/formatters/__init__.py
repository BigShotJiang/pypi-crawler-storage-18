"""CLI output formatters."""
