"""Lodestar test suite."""
