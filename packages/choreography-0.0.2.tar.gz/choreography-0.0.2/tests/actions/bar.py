async def action():
    print("Action executed from bar.py")
