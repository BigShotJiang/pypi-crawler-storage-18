def action():
    print("Action executed from foo.py")
