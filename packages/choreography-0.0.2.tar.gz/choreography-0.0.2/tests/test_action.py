import pathlib

from choreography.action import (
    clear_action_context,
    determine_shell,
    get_python_actions,
    get_script_actions,
    load_modules_from_directory,
    set_action_directory,
)

TEST_ACTIONS_DIR = pathlib.Path(__file__).parent.resolve() / "actions"


def test_get_python_actions(tmp_path):
    # Create a temporary actions directory
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a sample action module
    action_file = actions_dir / "sample_action.py"
    action_file.write_text(
        """def action():
    print("Sample action executed")
"""
    )
    # Load actions from the temporary directory
    set_action_directory(str(actions_dir))
    actions = get_python_actions()
    assert "sample_action" in actions
    assert callable(actions["sample_action"])

    # Test caching - calling again should return cached result
    actions_cached = get_python_actions()
    assert actions_cached is actions  # Same object due to caching

    set_action_directory(str(tmp_path / "non_existent"))
    assert get_python_actions() == {}


async def test_load_modules_from_directory():
    modules = load_modules_from_directory(str(TEST_ACTIONS_DIR))
    assert "foo" in [module.__name__ for module in modules]
    assert "bar" in [module.__name__ for module in modules]
    assert len(modules) == 2


def test_load_modules_with_invalid_py_file(tmp_path):
    """Test load_modules_from_directory handles files that can't be loaded as modules."""
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a valid Python file
    valid_file = actions_dir / "valid.py"
    valid_file.write_text("def action(): pass")

    # Create a .py file with a name that might cause issues
    # (though Python's importlib is quite robust)
    weird_file = actions_dir / "weird-name.py"
    weird_file.write_text("def action(): pass")

    # This should still load successfully
    modules = load_modules_from_directory(str(actions_dir))
    # Both should load (Python importlib handles most cases)
    assert len(modules) >= 1


def test_get_script_actions(tmp_path):
    # Create a temporary actions directory
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a sample shell script action
    shell_script_file = actions_dir / "sample_script.sh"
    shell_script_file.write_text(
        """#!/bin/bash
echo "Sample shell script executed"
"""
    )
    # Load script actions from the temporary directory
    set_action_directory(str(actions_dir))
    actions = get_script_actions()
    assert "sample_script" in actions
    shell, content = actions["sample_script"]
    assert shell == "bash"
    assert 'echo "Sample shell script executed"' in content

    # Create a sample PowerShell script action
    ps_script_file = actions_dir / "sample_script_ps.ps1"
    ps_script_file.write_text(
        """Write-Output "Sample PowerShell script executed"
"""
    )
    clear_action_context()
    set_action_directory(str(actions_dir))
    actions = get_script_actions()
    assert "sample_script_ps" in actions
    shell, content = actions["sample_script_ps"]
    assert shell == "powershell"
    assert 'Write-Output "Sample PowerShell script executed"' in content

    # confirm caching works - call again without clearing
    actions_cached = get_script_actions()
    assert actions == actions_cached
    assert actions is actions_cached  # Same object due to walrus operator cache


def test_determine_shell():
    bash_script = "#!/bin/bash\necho Hello"
    sh_script = "#!/bin/env sh\necho Hello"
    zsh_script = "#!/bin/zsh\necho Hello"
    no_shebang_script = "echo Hello"

    assert determine_shell(bash_script) == "bash"
    assert determine_shell(sh_script) == "sh"
    assert determine_shell(zsh_script) == "zsh"
    assert determine_shell(no_shebang_script) == "sh"


def test_determine_shell_edge_cases():
    """Test determine_shell with edge cases to ensure all branches are covered."""
    # Test when only zsh is in shebang (not bash)
    zsh_only_script = "#!/usr/bin/env zsh\necho Hello"
    assert determine_shell(zsh_only_script) == "zsh"

    # Test when only sh is in shebang (not bash or zsh)
    sh_only_script = "#!/bin/sh\necho Hello"
    assert determine_shell(sh_only_script) == "sh"

    # Test script with empty first line
    empty_line_script = "\necho Hello"
    assert determine_shell(empty_line_script) == "sh"

    # Test shebang with python (no bash/zsh/sh) - should default to sh
    python_script = "#!/usr/bin/env python\nprint('Hello')"
    assert determine_shell(python_script) == "sh"


def test_get_python_actions_with_module_without_action(tmp_path):
    """Test get_python_actions when a module doesn't have an 'action' function."""
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a module without an action function
    no_action_file = actions_dir / "no_action.py"
    no_action_file.write_text(
        """def some_other_function():
    print("Not an action")
"""
    )

    # Create a module with an action function
    with_action_file = actions_dir / "with_action.py"
    with_action_file.write_text(
        """def action():
    print("This is an action")
"""
    )

    clear_action_context()
    set_action_directory(str(actions_dir))
    actions = get_python_actions()

    # Should only include modules with action function
    assert "with_action" in actions
    assert "no_action" not in actions


def test_get_script_actions_with_non_script_file(tmp_path):
    """Test get_script_actions to ensure it only processes non-Python script files."""
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a text file that shouldn't be processed as a script
    text_file = actions_dir / "readme.txt"
    text_file.write_text("This is just a text file")

    # Create a valid shell script
    shell_file = actions_dir / "valid.sh"
    shell_file.write_text("#!/bin/bash\necho 'Valid script'")

    clear_action_context()
    set_action_directory(str(actions_dir))
    actions = get_script_actions()

    # Both should be included (non-.py files are treated as scripts)
    assert "readme" in actions
    assert "valid" in actions

    # Verify the shell script has correct shell type
    shell, content = actions["valid"]
    assert shell == "bash"


def test_get_script_actions_without_shebang(tmp_path):
    """Test get_script_actions with script file without shebang."""
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a script without shebang
    script_file = actions_dir / "no_shebang.sh"
    script_file.write_text("echo 'No shebang here'")

    clear_action_context()
    set_action_directory(str(actions_dir))
    actions = get_script_actions()

    assert "no_shebang" in actions
    shell, content = actions["no_shebang"]
    # Should default to "sh"
    assert shell == "sh"


def test_load_modules_with_none_spec(tmp_path, monkeypatch):
    """Test load_modules_from_directory when spec_from_file_location returns None."""
    import importlib.util

    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a Python file
    test_file = actions_dir / "test.py"
    test_file.write_text("def action(): pass")

    def mock_spec_from_file_location(name, location):
        # Return None to simulate the case where spec creation fails
        return None

    monkeypatch.setattr(
        importlib.util, "spec_from_file_location", mock_spec_from_file_location
    )

    # This should handle None spec gracefully
    modules = load_modules_from_directory(str(actions_dir))
    assert len(modules) == 0
