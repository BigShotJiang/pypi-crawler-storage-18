import os
import pathlib

import pytest

from choreography.action import ACTION_DIR, PYTHON_ACTION_CONTEXT, SCRIPT_ACTION_CONTEXT

MY_DIR = pathlib.Path(__file__).parent.resolve()


@pytest.fixture(autouse=True)
def clear_action_context():
    PYTHON_ACTION_CONTEXT.set({})
    SCRIPT_ACTION_CONTEXT.set({})
    ACTION_DIR.set("actions")
    yield


@pytest.fixture(autouse=True)
def test_cwd_to_tests():
    original_cwd = pathlib.Path.cwd()
    try:
        os.chdir(MY_DIR)
        yield
    finally:
        os.chdir(original_cwd)
