from choreography import __version__, __version_info__


def test_version_format():
    assert isinstance(__version__, str)
    assert len(__version_info__) >= 2  # At least major and minor versions
    assert all(isinstance(part, int) for part in __version_info__)
    assert __version__.startswith(".".join(str(part) for part in __version_info__[:2]))
