import pathlib

import pytest

from choreography.models import Choreography, Task, load_choreography_from_file

CHOREO_PATH = pathlib.Path(__file__).parent.resolve() / "choreography.yaml"
FIXTURES = pathlib.Path(__file__).parent.resolve() / "fixtures"


async def test_load_choreography_file():
    await load_choreography_from_file(str(CHOREO_PATH))


async def test_load_invalid_choreography_file():
    invalid_path = FIXTURES / "invalid_choreography.yaml"
    with pytest.raises(SystemExit):
        await load_choreography_from_file(str(invalid_path))


async def test_duplicate_keys_in_yaml_file(tmp_path):
    """Test that duplicate keys in YAML cause an error."""
    yaml_file = tmp_path / "duplicate.yaml"
    yaml_file.write_text(
        """tasks:
  task1:
    type: shell
    script: echo "first"
  task1:
    type: shell
    script: echo "second"
"""
    )
    with pytest.raises(SystemExit):
        await load_choreography_from_file(str(yaml_file))


@pytest.mark.parametrize(
    "data,should_raise",
    [
        ({"tasks": {"task1": {"type": "shell", "script": "foo"}}}, False),
        (
            {
                "tasks": {
                    "task1": {
                        "type": "shell",
                        "depends_on": ["task2"],
                        "script": "echo hi",
                    },
                    "task2": {"type": "python", "action": "bar"},
                }
            },
            False,
        ),
        (
            {
                "tasks": {
                    "task1": {
                        "type": "shell",
                        "depends_on": ["task3"],
                        "script": "echo hi",
                    },
                    "task2": {"type": "python", "action": "bar"},
                }
            },
            True,
        ),
        (
            {
                "tasks": {
                    "task1": {
                        "type": "shell",
                        "depends_on": ["task2"],
                        "script": "echo hi",
                    },
                    "task2": {
                        "type": "python",
                        "depends_on": ["task1"],
                        "action": "bar",
                    },
                }
            },
            True,
        ),
    ],
)
def test_model_validation(data, should_raise):
    if should_raise:
        with pytest.raises(ValueError):
            Choreography(**data)
    else:
        Choreography(**data)


@pytest.mark.parametrize(
    "data,should_raise",
    [
        ({"id": "task;", "type": "shell", "script": "echo hello"}, True),
        ({"id": "task1", "type": "python", "action": "hi"}, False),
        ({"id": "task2", "type": "shell"}, True),
        ({"id": "task3", "type": "python"}, True),
        ({"id": "task4", "type": "shell", "script": "echo hi", "action": "foo"}, True),
    ],
)
async def test_task_model_validation(data, should_raise):
    if should_raise:
        with pytest.raises(ValueError):
            Task(**data)
    else:
        Task(**data)


def test_duplicate_keys_impossible_in_dict_format():
    """Test that duplicate keys are impossible in the new dictionary format.

    In YAML/Python dictionaries, duplicate keys automatically overwrite,
    so this is no longer a validation concern.
    """
    # This would have duplicate keys in list format, but in dict format
    # the second definition overwrites the first
    data = {
        "tasks": {
            "task1": {"type": "shell", "script": "first"},
            "task1": {"type": "shell", "script": "second"},  # noqa
        }
    }
    choreo = Choreography(**data)  # type: ignore
    # The second definition wins
    assert choreo.tasks["task1"].script == "second"
