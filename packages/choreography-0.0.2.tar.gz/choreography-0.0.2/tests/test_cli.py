from typer.testing import CliRunner

from choreography.cli import app

runner = CliRunner()


def test_cli_no_args():
    result = runner.invoke(app, [])
    assert result.exit_code == 0


def test_cli_no_file():
    result = runner.invoke(app, ["--choreography-file", "nonexistent.yaml"])
    assert result.exit_code != 0
    assert "does not exist" in result.stderr


def test_cli_bad_action_path():
    result = runner.invoke(
        app,
        [
            "--actions-path",
            "nonexistent_actions",
        ],
    )
    assert result.exit_code != 0
    assert "Action" in result.stderr


def test_cli_with_id():
    result = runner.invoke(
        app,
        [
            "python-action",
        ],
    )
    assert result.exit_code == 0


def test_cli_with_bad_id():
    result = runner.invoke(
        app,
        [
            "nonexistent-task",
        ],
    )
    assert result.exit_code != 0
    assert "not found" in result.stderr


def test_cli_with_failing_task():
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/faileography.yaml",
        ],
    )
    assert result.exit_code != 0
    assert "boom" in result.stderr
    assert "happy" in result.stdout
    assert "All good!" not in result.stdout


def test_cli_with_failing_dependent_task():
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/faileography-complex.yaml",
        ],
    )
    assert result.exit_code != 0
    assert "dependent_failure" in result.stderr
    assert "success" in result.stdout


def test_cli_with_id_and_dependencies():
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/dependencies.yaml",
            "third",
        ],
    )
    assert result.exit_code == 0
    assert "first" in result.stdout
    assert "second" in result.stdout
    assert "third" in result.stdout


def test_cli_with_id_when_dependency_fails():
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/dependency-failure.yaml",
            "dependent",
        ],
    )
    assert result.exit_code != 0
    assert "failure" in result.stderr
    assert "failed with return code" in result.stderr
    assert "Should not run" not in result.stdout


def test_cli_with_groups():
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "choreography.yaml",
            "--group",
            "tasks",
            "--group",
            "async-tasks",
        ],
    )
    assert result.exit_code == 0
    assert "python-action" in result.stdout
    assert "independent-task" in result.stdout
    assert "say-hello" in result.stdout
    assert "async-python-action" in result.stdout


def test_cli_with_groups_and_dependencies():
    """Test that when filtering by groups, dependent tasks are also included."""
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/group-with-dependencies.yaml",
            "--group",
            "mygroup",
        ],
    )
    assert result.exit_code == 0
    # Task in group should run
    assert "task-in-group" in result.stdout
    # Its dependency should also run even though it's not in the group
    assert "base-task" in result.stdout
    # Unrelated task should not run
    assert "unrelated-task" not in result.stdout


def test_cli_with_groups_dependency_in_different_group():
    """Test that dependencies in other groups are included when needed."""
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/group-with-external-dep.yaml",
            "--group",
            "mygroup",
        ],
    )
    assert result.exit_code == 0
    # Tasks in mygroup should run
    assert "task-in-group" in result.stdout
    assert "task-with-external-dep" in result.stdout
    # Dependency from othergroup should run because it's needed
    assert "external-task" in result.stdout


def test_cli_with_groups_including_task_without_deps():
    """Test filtering by groups when some tasks have no dependencies."""
    result = runner.invoke(
        app,
        [
            "--choreography-file",
            "fixtures/group-no-dependencies.yaml",
            "--group",
            "mygroup",
        ],
    )
    assert result.exit_code == 0
    # Both tasks in group should run
    assert "task-in-group-no-deps" in result.stdout
    assert "task-in-group-with-deps" in result.stdout
    # Dependency should run
    assert "base-task" in result.stdout
    # Unrelated task should not run
    assert "unrelated-task" not in result.stdout
