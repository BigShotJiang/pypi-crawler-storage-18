from typing import Awaitable, cast
from unittest.mock import MagicMock

import pytest

from choreography.run import (
    parse_python_snippet,
    print_output_footer,
    print_output_header,
    run_action,
    run_script,
    run_task,
)


@pytest.mark.parametrize(
    "task,stderr,returncode",
    [
        (MagicMock(id="task1", type="shell", script="echo hello", action=""), "", 0),
        (
            MagicMock(
                id="task2", type="shell", script="nonexistent_command", action=""
            ),
            "not found",
            127,
        ),
        (
            MagicMock(
                id="task3",
                type="python",
                action="nonexistent_action",
            ),
            "Action 'nonexistent_action' for task 'task3' not found in actions directory.",
            -1,
        ),
    ],
)
async def test_run_task(task, stderr, returncode, capsys):
    task.name = ""
    task_returncode = await run_task(task)
    assert task_returncode == returncode
    captured = capsys.readouterr()
    assert stderr in captured.err


@pytest.mark.parametrize(
    "action_callable,returncode,output",
    [
        (
            lambda: print("Action executed successfully"),
            0,
            "Action executed successfully\n",
        ),
        (lambda: 1 / 0, -1, "Error executing action: division by zero"),
    ],
)
async def test_run_action(action_callable, returncode, output):
    test_returncode, test_output = await run_action(action_callable)
    assert test_returncode == returncode
    assert output in test_output


@pytest.mark.parametrize(
    "script,expected_returncode,expected_output",
    [
        (
            "nonexistent_command",
            127,
            "not found",
        ),
        (
            "echo 'Hello, World!'",
            0,
            "Hello, World!",
        ),
        (
            ">&2 echo 'Error occurred'; exit 1",
            1,
            "Error occurred",
        ),
    ],
)
async def test_run_script(script, expected_returncode, expected_output):
    returncode, output = await run_script(script)

    if callable(expected_returncode):
        assert expected_returncode(returncode)
    else:
        assert returncode == expected_returncode

    if expected_output:
        assert expected_output in output


def test_print_output_header_with_tty(monkeypatch, capsys):
    """Test print_output_header when running in a TTY."""
    mock_isatty = MagicMock(return_value=True)
    mock_terminal_size = MagicMock(return_value=MagicMock(columns=100))
    monkeypatch.setattr("sys.stderr.isatty", mock_isatty)
    monkeypatch.setattr("os.get_terminal_size", mock_terminal_size)
    task = MagicMock(id="test-task", name="Test Task")

    print_output_header(task)

    captured = capsys.readouterr()
    assert "Test Task" in captured.err
    assert "=" in captured.err
    mock_isatty.assert_called_once()
    mock_terminal_size.assert_called_once()


def test_print_output_header_without_tty(monkeypatch, capsys):
    """Test print_output_header when not running in a TTY."""
    mock_isatty = MagicMock(return_value=False)
    monkeypatch.setattr("sys.stderr.isatty", mock_isatty)
    task = MagicMock(id="test-task", name="Test Task")

    print_output_header(task)

    captured = capsys.readouterr()
    assert "Test Task" in captured.err
    assert "=" in captured.err
    mock_isatty.assert_called_once()


def test_print_output_footer_with_tty(monkeypatch, capsys):
    """Test print_output_footer when running in a TTY."""
    mock_isatty = MagicMock(return_value=True)
    mock_terminal_size = MagicMock(return_value=MagicMock(columns=100))
    monkeypatch.setattr("sys.stderr.isatty", mock_isatty)
    monkeypatch.setattr("os.get_terminal_size", mock_terminal_size)

    print_output_footer()

    captured = capsys.readouterr()
    assert "=" in captured.err
    mock_isatty.assert_called_once()
    mock_terminal_size.assert_called_once()


def test_print_output_footer_without_tty(monkeypatch, capsys):
    """Test print_output_footer when not running in a TTY."""
    mock_isatty = MagicMock(return_value=False)
    monkeypatch.setattr("sys.stderr.isatty", mock_isatty)

    print_output_footer()

    captured = capsys.readouterr()
    assert "=" in captured.err
    mock_isatty.assert_called_once()


async def test_run_script_with_tty(monkeypatch):
    """Test run_script sets PY_COLORS when running in a TTY."""
    mock_isatty = MagicMock(return_value=True)
    monkeypatch.setattr("sys.stdout.isatty", mock_isatty)

    returncode, output = await run_script("echo 'test'")

    assert returncode == 0
    assert "test" in output
    mock_isatty.assert_called_once()


async def test_run_script_without_tty(monkeypatch):
    """Test run_script when not running in a TTY."""
    mock_isatty = MagicMock(return_value=False)
    monkeypatch.setattr("sys.stdout.isatty", mock_isatty)

    returncode, output = await run_script("echo 'test'")

    assert returncode == 0
    assert "test" in output
    mock_isatty.assert_called_once()


async def test_parse_python_snippet():
    snippet = """
return 'hi!'
"""
    action_callable = parse_python_snippet(snippet)
    assert callable(action_callable)
    assert action_callable() == "hi!"

    snippet_async = """
import asyncio
await asyncio.sleep(0.1)
return 'hello!'
"""
    action_callable_async = parse_python_snippet(snippet_async)
    assert callable(action_callable_async)
    result = await cast(Awaitable, action_callable_async())
    assert result == "hello!"


async def test_run_task_shell_with_action(tmp_path, capsys):
    """Test shell task using action from file instead of inline script."""
    from choreography.action import clear_action_context, set_action_directory
    from choreography.models import Task

    # Create a temporary actions directory
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()

    # Create a sample shell script action
    shell_script_file = actions_dir / "test_script.sh"
    shell_script_file.write_text(
        """#!/bin/bash
echo "Script from file executed"
"""
    )

    clear_action_context()
    set_action_directory(str(actions_dir))

    task = Task(
        id="test-shell-action",
        name="Test Shell Action",
        type="shell",
        action="test_script",
        output="auto",
    )

    returncode = await run_task(task)
    assert returncode == 0
    captured = capsys.readouterr()
    # Successful tasks output to stdout, not stderr
    assert "Test Shell Action" in captured.out or "test-shell-action" in captured.out


async def test_run_task_shell_with_missing_action(capsys):
    """Test shell task with missing action file."""
    from choreography.action import clear_action_context
    from choreography.models import Task

    clear_action_context()

    task = Task(
        id="test-missing-action",
        name="Test Missing Action",
        type="shell",
        action="nonexistent_action",
        output="auto",
    )

    returncode = await run_task(task)
    assert returncode == -1
    captured = capsys.readouterr()
    assert "not found in actions directory" in captured.err


async def test_run_task_python_with_inline_script(capsys):
    """Test Python task using inline script instead of action file."""
    from choreography.models import Task

    task = Task(
        id="test-python-inline",
        name="Test Python Inline",
        type="python",
        script="print('Inline Python code executed')",
        output="auto",
    )

    returncode = await run_task(task)
    assert returncode == 0
    captured = capsys.readouterr()
    # Successful tasks output to stdout, not stderr
    assert "Test Python Inline" in captured.out or "test-python-inline" in captured.out


async def test_run_task_python_with_syntax_error(capsys):
    """Test Python task with syntax error in inline script."""
    from choreography.models import Task

    task = Task(
        id="test-python-syntax-error",
        name="Test Python Syntax Error",
        type="python",
        script="this is not valid python syntax !!!",
        output="auto",
    )

    returncode = await run_task(task)
    assert returncode == -1
    captured = capsys.readouterr()
    assert "Syntax error" in captured.err


async def test_run_task_with_output_always_success(capsys):
    """Test task with output='always' that succeeds."""
    from choreography.models import Task

    task = Task(
        id="test-output-always",
        name="Test Output Always",
        type="shell",
        script="echo 'Success with output always'",
        output="always",
    )

    returncode = await run_task(task)
    assert returncode == 0
    captured = capsys.readouterr()
    # Should show output even on success
    assert "Success with output always" in captured.err
    # Should show header/footer for output="always"
    assert "Test Output Always" in captured.err or "test-output-always" in captured.err


async def test_run_task_python_with_empty_script(tmp_path, capsys):
    """Test Python task with empty or None script falls back to action."""
    from choreography.action import clear_action_context, set_action_directory
    from choreography.models import Task

    # Create a temporary actions directory with a Python action
    actions_dir = tmp_path / "actions"
    actions_dir.mkdir()
    action_file = actions_dir / "test_action.py"
    action_file.write_text(
        """def action():
    print("Action from file executed")
"""
    )

    clear_action_context()
    set_action_directory(str(actions_dir))

    # Test with empty script (should use action)
    task = Task(
        id="test-python-empty-script",
        name="Test Python Empty Script",
        type="python",
        action="test_action",
        script="",  # Empty script
        output="auto",
    )

    returncode = await run_task(task)
    assert returncode == 0
    # Output should show it succeeded
    captured = capsys.readouterr()
    assert (
        "Test Python Empty Script" in captured.out
        or "test-python-empty-script" in captured.out
    )
