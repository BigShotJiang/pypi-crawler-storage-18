import asyncio
from typing import Annotated

import typer

from .choreograph import choreograph_it

app = typer.Typer()


@app.command()
def cli(
    choreography_file: Annotated[
        str, typer.Option(help="Path to the choreography YAML file")
    ] = "",
    actions_path: Annotated[
        str, typer.Option(help="Path to the actions directory")
    ] = "",
    id: Annotated[str, typer.Argument(help="ID of the choreography to run")] = "",
    group: Annotated[
        list[str] | None,
        typer.Option(help="Group of tasks to run, can be specified multiple times"),
    ] = None,
) -> None:
    """
    The little task runner that could! Support for shell scripts and python functions as tasks with asyncio support.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:  # pragma: no cover
        loop = asyncio.new_event_loop()  # pragma: no cover
        asyncio.set_event_loop(loop)  # pragma: no cover
    loop.run_until_complete(
        choreograph_it(
            file_path=choreography_file, actions_path=actions_path, id=id, groups=group
        )
    )


def main():
    app()  # pragma: no cover
