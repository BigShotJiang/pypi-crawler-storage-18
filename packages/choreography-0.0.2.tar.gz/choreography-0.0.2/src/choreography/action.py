import importlib.util
import os
import pathlib
from contextvars import ContextVar
from typing import Callable

PYTHON_ACTION_CONTEXT: ContextVar[dict[str, Callable]] = ContextVar(
    "PYTHON_ACTION_CONTEXT", default={}
)
SCRIPT_ACTION_CONTEXT: ContextVar[dict[str, str]] = ContextVar(
    "SCRIPT_ACTION_CONTEXT", default={}
)
ACTION_DIR = ContextVar("ACTION_DIR", default="actions")


def clear_action_context() -> None:
    PYTHON_ACTION_CONTEXT.set({})
    SCRIPT_ACTION_CONTEXT.set({})
    ACTION_DIR.set("actions")


def set_action_directory(directory_path: str) -> None:
    ACTION_DIR.set(directory_path)


def load_modules_from_directory(directory_path: str) -> list:
    modules = []

    for filename in os.listdir(directory_path):
        if filename.endswith(".py"):
            module_name = filename[:-3]
            file_path = os.path.join(directory_path, filename)
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                modules.append(module)
    return modules


def get_python_actions() -> dict[str, Callable]:
    actions = {}
    try:
        modules = load_modules_from_directory(ACTION_DIR.get())
    except FileNotFoundError:
        return actions

    if actions := PYTHON_ACTION_CONTEXT.get():
        return actions
    for module in modules:
        if hasattr(module, "action"):
            actions[module.__name__] = getattr(module, "action")
    PYTHON_ACTION_CONTEXT.set(actions)
    return actions


def determine_shell(script: str) -> str:
    first_line = script.split("\n", 1)[0]
    if first_line.startswith("#!"):
        if "bash" in first_line:
            return "bash"
        elif "zsh" in first_line:
            return "zsh"
        elif "sh" in first_line:
            return "sh"
    return "sh"


def get_script_actions() -> dict[str, str]:
    if actions := SCRIPT_ACTION_CONTEXT.get():
        return actions
    actions = {}
    for filename in os.listdir(ACTION_DIR.get()):
        filepath = pathlib.Path(os.path.join(ACTION_DIR.get(), filename))
        if not filename.endswith(".py") and filepath.is_file():
            shell = ""
            action_name = filename.rsplit(".", 1)[0]
            extension = filename.rsplit(".", 1)[-1]
            if extension == "ps1":
                shell = "powershell"
            content = filepath.read_text()
            shell = determine_shell(content) if not shell else shell
            actions[action_name] = (shell, content)
    SCRIPT_ACTION_CONTEXT.set(actions)
    return actions
