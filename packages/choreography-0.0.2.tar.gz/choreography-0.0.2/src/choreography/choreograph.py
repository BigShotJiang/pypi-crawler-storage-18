import asyncio
import pathlib
import time
from typing import Callable

from colorama import Fore, Style

from .action import (
    clear_action_context,
    get_python_actions,
    set_action_directory,
)
from .models import Choreography, Task, load_choreography_from_file
from .outputs import write_to_stderr
from .run import run_task, task_counts


async def choreograph_it(
    file_path: str = "",
    actions_path: str = "",
    id: str = "",
    groups: list[str] | None = None,
) -> None:
    start = time.time()
    clear_action_context()
    if not file_path:
        path = pathlib.Path.cwd() / "choreography.yaml"
    else:
        path = pathlib.Path(file_path)

    if not path.exists():
        write_to_stderr(f"Choreography file {file_path} does not exist.")
        exit(-1)
    file_path = str(path.resolve())

    choreography = await load_choreography_from_file(file_path)

    set_action_directory(
        str(pathlib.Path(actions_path) if actions_path else path.parent / "actions")
    )
    if id:
        return await execute_task_and_dependants(id, choreography)

    choreography.tasks = {
        task.id: task for task in choreography.tasks.values() if task.always
    }
    await execute_choreography(choreography, groups=groups)
    end = time.time()
    if task_counts.tasks_failed == 0:
        print(
            f"✨{Fore.YELLOW}{Style.BRIGHT}Choreography executed {task_counts.tasks_run} tasks in {end - start:.2f} seconds.{Style.RESET_ALL}✨"
        )


def validate_actions(actions: dict[str, Callable], tasks: list[Task]) -> None:
    for task in tasks:
        if task.type == "python":
            if task.action not in actions:
                write_to_stderr(
                    f"Action '{task.action}' for task '{task.id}' not found in actions directory."
                )
                exit(-1)


async def execute_choreography(
    ch: Choreography, groups: list[str] | None = None
) -> None:
    task_definitions = [t for t in ch.tasks.values()]
    if groups:
        filtered = [
            t for t in task_definitions if any(group in groups for group in t.groups)
        ]
        # get dependent tasks as well
        task_ids = {t.id for t in task_definitions}
        for task in filtered:
            for dep in task.depends_on:
                if dep in task_ids:
                    filtered.append(ch.tasks[dep])
        task_definitions = filtered

    actions = get_python_actions()
    validate_actions(actions, task_definitions)

    free_tasks = []
    complex_tasks = []

    for task in task_definitions:
        depends_on = task.depends_on
        if depends_on:
            complex_tasks.append(task)
            continue
        free_tasks.append(run_task(task))

    return_codes = await asyncio.gather(*free_tasks)
    if any(code != 0 for code in return_codes):
        failures = [
            task.id for task, code in zip(task_definitions, return_codes) if code != 0
        ]
        write_to_stderr(f"One or more actions failed: {failures}")
        exit(-1)

    # now check for complex actions that can be run based on sastisfied dependencies
    while complex_tasks:
        runnable_actions = []
        for task in complex_tasks:
            depends_on = task.depends_on
            if all(dep not in [a.id for a in complex_tasks] for dep in depends_on):
                runnable_actions.append(task)

        coros = []
        for task in runnable_actions:
            coros.append(run_task(task))
            complex_tasks.remove(task)

        return_codes = await asyncio.gather(*coros)
        if any(code != 0 for code in return_codes):
            failures = [
                task.id
                for task, code in zip(runnable_actions, return_codes)
                if code != 0
            ]
            write_to_stderr(f"One or more actions failed: {failures}")
            exit(-1)


async def execute_task_and_dependants(
    task_id: str,
    choreography: Choreography,
    completed_tasks: set[str] | None = None,
):
    if completed_tasks is None:
        completed_tasks = set()

    if task_id not in choreography.tasks:
        write_to_stderr(f"Task with id '{task_id}' not found in choreography.")
        exit(-1)

    task = choreography.tasks[task_id]

    # First, execute all dependencies
    for dep_id in task.depends_on:
        await execute_task_and_dependants(dep_id, choreography, completed_tasks)

    returncode = await run_task(task)
    completed_tasks.add(task_id)

    if returncode != 0:
        write_to_stderr(f"Task '{task.id}' failed with return code {returncode}")
        exit(-1)
