import ast
import asyncio
import io
import os
import sys
from typing import Awaitable, Callable

from .action import get_python_actions, get_script_actions
from .models import Task
from .outputs import (
    capture_all_std,
    print_output_footer,
    print_output_header,
    print_task_failure,
    print_task_success,
    write_to_stderr,
)


class TaskCounts:
    def __init__(self):
        self.tasks_run = 0
        self.tasks_failed = 0

    def failed(self):
        self.tasks_failed += 1

    def run(self):
        self.tasks_run += 1


task_counts = TaskCounts()


def parse_python_snippet(snippet: str):
    """Parse a Python code snippet and return it as an actual function object, wrapping it in a async function if it uses await."""
    tree = ast.parse(snippet)
    is_async = any(isinstance(node, ast.Await) for node in ast.walk(tree))

    if is_async:
        func_def = "async def _snippet_func():\n"
    else:
        func_def = "def _snippet_func():\n"

    for line in snippet.splitlines():
        func_def += "    " + line + "\n"

    local_vars = {}
    exec(func_def, {}, local_vars)
    return local_vars["_snippet_func"]


async def run_task(task: Task):
    match task.type:
        case "shell":
            if task.action:
                actions = get_script_actions()
                if task.action not in actions:
                    write_to_stderr(
                        f"Action '{task.action}' for task '{task.id}' not found in actions directory."
                    )
                    return -1
                shell, script = actions[task.action]
                returncode, out = await run_script(script, executable=shell)
            else:
                returncode, out = await run_script(task.script)
        case "python":
            if task.script and isinstance(task.script, str) and task.script.strip():
                try:
                    action_callable = parse_python_snippet(task.script)
                except SyntaxError as e:
                    write_to_stderr(
                        f"Syntax error in Python script for task '{task.id}': {e}"
                    )
                    return -1
                returncode, out = await run_action(action_callable)
            else:
                actions = get_python_actions()
                action_name = task.action
                if action_name not in actions:
                    write_to_stderr(
                        f"Action '{action_name}' for task '{task.id}' not found in actions directory."
                    )
                    return -1
                action_callable = actions[action_name]
                returncode, out = await run_action(action_callable)
    if returncode == 0:
        print_task_success(task)
        task_counts.run()
    if returncode != 0 or (task.output == "always"):
        print_task_failure(task) if returncode != 0 else None
        print_output_header(task, always=(task.output == "always"))
        sys.stderr.write(f"{out}\n")
        print_output_footer(always=(task.output == "always"))
        if returncode != 0:
            task_counts.failed()

    return returncode


async def run_action(
    action_callable: Callable[..., None] | Callable[..., Awaitable[None]],
) -> tuple[int, str]:
    with capture_all_std(io.StringIO()) as f:
        try:
            if asyncio.iscoroutinefunction(action_callable):
                await action_callable()
            else:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, action_callable)
            return 0, f.getvalue()
        except Exception as e:
            write_to_stderr(f"Error executing action: {e}")
            return -1, f.getvalue()


async def run_script(script: str, executable: str = "sh") -> tuple[int, str]:
    if sys.stdout.isatty():
        os.environ["PY_COLORS"] = "1"
    proc = await asyncio.create_subprocess_shell(
        script,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        executable=executable,
    )
    out, _ = await proc.communicate()
    returncode = await proc.wait()
    return returncode, out.decode()
