from __future__ import annotations

import io
import os
import sys
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from typing import TYPE_CHECKING

from colorama import Fore, Style
from wcwidth import wcswidth

if TYPE_CHECKING:
    from .models import Task


def write_to_stderr(message: str) -> None:
    sys.stderr.write(f"{Fore.RED}{Style.BRIGHT}{message}{Style.RESET_ALL}\n")


@contextmanager
def capture_all_std(buffer: io.StringIO):
    with redirect_stdout(buffer), redirect_stderr(buffer):
        yield buffer


def print_task_success(task: Task) -> None:
    name = task.name or task.id
    print(f"{Fore.GREEN}{Style.BRIGHT}{name} ✔{Style.RESET_ALL}")


def print_task_failure(task: Task) -> None:
    name = task.name or task.id
    sys.stderr.write(f"{Fore.RED}{Style.BRIGHT}{name} ✘{Style.RESET_ALL}\n")


def print_output_header(task: Task, always: bool = False) -> None:
    if sys.stderr.isatty():
        term_size = os.get_terminal_size().columns
    else:
        term_size = 80
    if term_size > 80:
        term_size = 80
    name = task.name or task.id
    size_with_padding = wcswidth(name) + 2
    separator_length = max(0, term_size - size_with_padding)
    left_separator = "=" * (separator_length // 2)
    right_separator = "=" * (separator_length - len(left_separator))
    color = Fore.GREEN if always else Fore.RED
    output = f"{color}{Style.BRIGHT}{left_separator} {name} {right_separator}{Style.RESET_ALL}"
    sys.stderr.write(f"{output}\n")


def print_output_footer(always: bool = False) -> None:
    if sys.stderr.isatty():
        term_size = os.get_terminal_size().columns
    else:
        term_size = 80
    if term_size > 80:
        term_size = 80
    color = Fore.GREEN if always else Fore.RED
    sys.stderr.write(f"{color}{Style.BRIGHT}{'=' * term_size}{Style.RESET_ALL}\n")
