from typing import Annotated, Literal

import aiofiles
import yaml
from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    ValidationError,
    model_validator,
)
from typing_extensions import Self

from .outputs import write_to_stderr


class DuplicateKeySafeLoader(yaml.SafeLoader):
    """YAML loader that detects duplicate keys."""

    pass


def detect_duplicate_keys(loader, node, deep=False):
    """Detect duplicate keys in YAML mappings and error out."""
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            # Get line numbers for better error messages
            line = key_node.start_mark.line + 1
            write_to_stderr(
                f"Error: Duplicate key '{key}' found at line {line}. "
                f"Previous definition will be overwritten."
            )
            exit(-1)
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


# Register the constructor
DuplicateKeySafeLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, detect_duplicate_keys
)


def id_has_valid_chars(value: str) -> str:
    invalid_chars = " !@#$%^&*()+={}[]|\\;:'\"<>,.?/~`"
    if any(char in invalid_chars for char in value):
        raise ValueError(f"ID '{value}' contains invalid characters.")
    return value


class Task(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: Annotated[str, AfterValidator(id_has_valid_chars)]
    name: str = ""
    type: Literal["shell", "python"]
    groups: list[str] = []
    action: str = ""
    script: str = ""
    depends_on: list[str] = []
    always: bool = True
    output: Literal["auto", "always"] = "auto"

    @model_validator(mode="after")
    def validate_task(self) -> Self:
        if not self.script and not self.action:
            raise ValueError(f"Task {self.id} requires a script or action")
        # can have either script or action, but not both
        if self.script and self.action:
            raise ValueError(f"Task {self.id} cannot have both script and action")
        return self


class Choreography(BaseModel):
    tasks: dict[str, Task]

    @model_validator(mode="before")
    def reformat_dict(cls, data: dict) -> dict:
        for k, v in data["tasks"].items():
            v["id"] = k
        return data

    @model_validator(mode="after")
    def validate_tasks(self) -> Self:
        # ensure all dependencies exist
        all_ids = set(task.id for task in self.tasks.values())
        for task in self.tasks.values():
            for dep in task.depends_on:
                if dep not in all_ids:
                    raise ValueError(f"Task {task.id} has unknown dependency: {dep}")

        # ensure no circular dependencies
        def has_cycle(task_id: str, visited: set[str], path: set[str]) -> bool:
            if task_id in path:
                return True
            if task_id in visited:
                return False
            visited.add(task_id)
            path.add(task_id)
            task_deps = next(
                (t.depends_on for t in self.tasks.values() if t.id == task_id), []
            )
            for dep in task_deps:
                if has_cycle(dep, visited, path):
                    return True
            path.remove(task_id)
            return False

        visited = set()
        for task in self.tasks.values():
            if has_cycle(task.id, visited, set()):
                raise ValueError(
                    f"Circular dependency detected involving task: {task.id}"
                )

        return self


async def load_choreography_from_file(file_path: str) -> Choreography:
    async with aiofiles.open(file_path, mode="r") as f:
        content = await f.read()
        data = yaml.load(content, Loader=DuplicateKeySafeLoader)
        try:
            return Choreography(**data)
        except ValidationError as e:
            write_to_stderr(f"Error loading choreography: {e}")
            exit(-1)
