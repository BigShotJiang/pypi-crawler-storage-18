from importlib.metadata import version

from colorama import just_fix_windows_console

from .choreograph import choreograph_it

just_fix_windows_console()
__all__ = ["choreograph_it"]


__version__ = version("choreography")
__version_info__ = tuple(int(part) for part in __version__.split(".") if part.isdigit())
