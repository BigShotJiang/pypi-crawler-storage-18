# SoulEyez Beta Program

Welcome to the SoulEyez beta! Thank you for helping us test and improve this penetration testing management platform.

## What is SoulEyez?

SoulEyez is a comprehensive penetration testing management tool designed to streamline your security assessments. It helps you:

- **Organize engagements** - Manage multiple assessments with isolated data
- **Track hosts & services** - Discover and catalog your attack surface
- **Run security tools** - Execute 21+ integrated tools with automatic result parsing
- **Record findings** - Document vulnerabilities with severity ratings
- **Manage credentials** - Securely store discovered credentials (encrypted at rest)
- **Generate reports** - Export professional deliverables

## Version: 2.0.6

This beta includes:

### Core Features (Stable)
- Multi-layer security (vault encryption + user authentication)
- Role-based access control (Admin, Lead, Analyst, Viewer)
- Tier-based features (FREE / PRO)
- Engagement management with team collaboration
- Host and service discovery
- 20+ tool parsers (Nmap, Gobuster, SQLMap, Nuclei, etc.)
- Auto-chaining of tools based on discoveries
- Credential encryption with master password
- Evidence vault with export
- Report generation (Markdown, HTML)

### PRO Features (Requires PRO tier)
- AI-powered scanning suggestions
- Automated tool chaining
- Metasploit Framework integration
- Advanced reporting

## Known Limitations

### Not Yet Implemented
- Docker deployment
- Windows native support (works in WSL)

### Current Constraints
- **Tested on**: Kali Linux, Ubuntu 22.04+
- **Python**: 3.8+ required
- **Database**: SQLite (single-user optimized)
- **MSF Integration**: Requires local Metasploit installation

### Known Issues
- Large scan outputs (>10MB) may slow the UI
- Some parsers may not handle malformed tool output

## Quick Start

```bash
# One-time setup
sudo apt install pipx
pipx ensurepath
source ~/.bashrc

# Install SoulEyez
pipx install souleyez

# Launch the dashboard
souleyez dashboard
```

On first run, SoulEyez will detect that pentesting tools aren't installed and prompt you to run the setup wizard. The wizard will install tools like nmap, sqlmap, gobuster, metasploit, and more.

After tools are installed, the setup wizard will guide you through:
1. Setting up vault encryption (required)
2. Creating your admin account
3. Creating your first engagement

## Reporting Issues & Feedback

### Email (Preferred for Beta)
**cysoul.secit@gmail.com**

When reporting issues, please include:
- SoulEyez version (`souleyez --version`)
- Operating system and version
- Steps to reproduce
- Error messages (screenshots or copy/paste)
- Expected vs actual behavior

### Bug Report Template
```
**Description:**
[Brief description of the issue]

**Steps to Reproduce:**
1.
2.
3.

**Expected Behavior:**
[What should happen]

**Actual Behavior:**
[What actually happens]

**Environment:**
- OS:
- Python:
- SoulEyez version:

**Screenshots/Logs:**
[If applicable]
```

### Feature Requests
We welcome feature suggestions! Please prefix your issue title with `[Feature Request]`.

## Security Vulnerabilities

For security-related issues, please do NOT open a public GitHub issue.

Contact: cysoul.secit@gmail.com

Or see [SECURITY.md](SECURITY.md) for our security policy.

## Beta Feedback Survey

Help us improve SoulEyez by completing our quick feedback survey:

**[Take the Beta Feedback Survey](https://docs.google.com/forms/d/e/1FAIpQLSfylyvCor681VLeP7qGgFRDHCyzRDCFhiyjE6IqLbQDUB6-Jg/viewform?usp=send_form)**

## Beta Testing Guidelines

### What We Need Tested
- [ ] Full workflow: Create engagement → Add hosts → Run scans → Record findings → Generate report
- [ ] Credential encryption/decryption cycle
- [ ] Multi-user collaboration features
- [ ] Tool parsers (especially edge cases)
- [ ] Auto-chaining behavior
- [ ] Report generation quality
- [ ] UI responsiveness and navigation

### What to Avoid
- Don't test on production networks without authorization
- Don't store real client data in the beta (use test data)
- Don't share your vault password

## Support

- **Email**: cysoul.secit@gmail.com
- **Built-in Help**: Run `souleyez --help` or `souleyez <command> --help`
- **Diagnostics**: Run `souleyez doctor` to check your setup

## Thank You!

Your feedback is invaluable in making SoulEyez better. Every bug report, feature suggestion, and piece of feedback helps us build a tool that truly serves the security community.

---

**Version**: 2.0.6
**Release Date**: December 2025
**Maintainer**: Cyber Soul Security
**License**: See LICENSE file
