# NanoBot

Minimalist robot navigation framework using **cascading decision nodes**.

Designed for **NVIDIA Jetson** robots (Nano, Orin, Xavier, TX2) with Python 3.6+ support.

![NanoBot in Maze Simulation](image.png)

*Robot navigating a maze using sensor data (front, left, right distances displayed). The maze server runs on your PC and the NanoBot client runs on the Jetson Nano.*

## Principle

Nodes execute **in cascade by priority order**. The first one to return a decision **wins**. No voting, no scoring, no conflict.

```
SafetyNode (priority 0)      ->  Avoid collisions
     | (if None)
NavigationNode (priority 10) ->  Handle turns
     | (if None)
ExplorerNode (priority 50)   ->  Move forward when safe
```

## Installation

```bash
pip install nanobot

# With server support (requests)
pip install nanobot[server]

# With dev tools
pip install nanobot[dev]
```

---

## Jetson Setup

NanoBot is designed to run on NVIDIA Jetson boards (Nano, Orin Nano, Xavier, TX2, etc.). Here's how to set up a wireless connection between your PC and the Jetson.

### Option 1: Windows Mobile Hotspot (Recommended)

1. **On Windows PC:**
   - Go to Settings > Network & Internet > Mobile hotspot
   - Turn on "Share my Internet connection"
   - Note the network name and password
   - The hotspot IP is usually `192.168.137.1`

2. **On Jetson Nano:**
   ```bash
   # Connect to the hotspot WiFi
   nmcli device wifi connect "YourHotspotName" password "YourPassword"

   # Check the Jetson's IP
   hostname -I
   ```

3. **Run the maze server on PC:**
   ```bash
   python maze-server.py
   # Server starts on http://192.168.137.1:8777
   ```

4. **Run NanoBot on Jetson:**
   ```bash
   python -m nanobot -s 192.168.137.1:8777 -d
   ```

### Option 2: Direct Ethernet Connection

1. Connect Jetson to PC via Ethernet cable
2. Configure static IPs on both devices (same subnet)
3. Run server and client as above

---

## Maze Server

The maze simulation server (`maze-server.py`) provides a virtual environment to test navigation algorithms before deploying on real hardware.

**Features:**
- Procedurally generated mazes
- Real-time sensor simulation (front, left, right distances)
- HTTP API for commands and sensor data
- Visual feedback with Pygame

**API Endpoints:**
- `GET /sensors` - Returns sensor distances as JSON
- `POST /command` - Send movement commands (`{"action": "forward", "speed": 0.5}`)
- `GET /status` - Robot position and state

**Running the server:**
```bash
# On your PC
python maze-server.py

# The server window shows the maze and robot position
# Robot sensors are displayed as colored lines
```

---

## Quick Start

```python
from nanobot import NodeEngine, SensorData
from nanobot.nodes import SafetyNode, NavigationNode, ExplorerNode

# Create engine
engine = NodeEngine(debug=True)
engine.add_node(SafetyNode())
engine.add_node(NavigationNode())
engine.add_node(ExplorerNode())

# Main loop
while True:
    sensors = get_sensors()  # Your sensors
    decision = engine.tick(sensors)

    if decision:
        robot.execute(decision.action, decision.speed)
```

## CLI

```bash
# Simulation (local test scenarios)
python -m nanobot

# Run tests
python -m nanobot --test

# Connect to maze server
python -m nanobot -s 192.168.137.1:8777 -d
```

---

## Creating Custom Nodes

### Step 1: Understand the Node Interface

Every node must inherit from `Node` and implement `evaluate()`:

```python
from nanobot.core import Node, Decision, Action

class MyNode(Node):
    def __init__(self):
        # name: unique identifier
        # priority: lower = higher priority (0 is highest)
        super().__init__("MY_NODE", priority=25)

    def evaluate(self, sensors):
        """
        Called every tick by the engine.

        Args:
            sensors: SensorData with distance measurements

        Returns:
            Decision if this node wants to act
            None to pass control to the next node
        """
        # Your logic here
        return None
```

### Step 2: Return Decision or None

The key rule: **return `Decision` to act, `None` to pass**.

```python
def evaluate(self, sensors):
    # Condition met -> take action
    if sensors.front < 0.5:
        return Decision(
            action=Action.STOP,
            speed=0.0,
            reason="Obstacle too close"
        )

    # Condition not met -> let next node decide
    return None
```

### Step 3: Complete Example - Wall Follower

```python
from nanobot.core import Node, Decision, Action

class WallFollowerNode(Node):
    """
    Follows the right wall at a target distance.

    Priority 30: runs after Safety (0) and Navigation (10),
    but before Explorer (50).
    """

    def __init__(self, target_distance: float = 0.5):
        super().__init__("WALL_FOLLOWER", priority=30)
        self.target_distance = target_distance
        self.tolerance = 0.15

    def evaluate(self, sensors):
        # Skip if no right sensor
        if sensors.right is None:
            return None

        # Too far from wall -> turn right to approach
        if sensors.right > self.target_distance + self.tolerance:
            return Decision(
                action=Action.TURN_RIGHT,
                speed=0.3,
                reason=f"Wall too far ({sensors.right:.2f}m)"
            )

        # Too close to wall -> turn left to move away
        if sensors.right < self.target_distance - self.tolerance:
            return Decision(
                action=Action.TURN_LEFT,
                speed=0.3,
                reason=f"Wall too close ({sensors.right:.2f}m)"
            )

        # Good distance -> pass to Explorer for forward movement
        return None
```

### Step 4: Add Your Node to the Engine

```python
from nanobot import NodeEngine
from nanobot.nodes import SafetyNode, ExplorerNode

engine = NodeEngine(debug=True)
engine.add_node(SafetyNode())        # Priority 0
engine.add_node(WallFollowerNode())  # Priority 30
engine.add_node(ExplorerNode())      # Priority 50
```

### Important Rules

1. **`evaluate(sensors)`** must return `Decision` or `None`
2. **`None`** = let the next node decide
3. **Lower priority** = executed first (0 = highest priority)
4. **Never block** in `evaluate()` (no `sleep`, no I/O, no network)
5. **Keep it fast** - evaluate() is called every tick (10-100 Hz)

### Node with State

Nodes can maintain state between ticks:

```python
class PatrolNode(Node):
    """Alternates between left and right turns."""

    def __init__(self):
        super().__init__("PATROL", priority=40)
        self.turn_count = 0
        self.turn_left_next = True

    def evaluate(self, sensors):
        # Only patrol when path is clear
        if sensors.front < 1.0:
            return None

        # Alternate direction every 10 calls
        self.turn_count += 1
        if self.turn_count >= 10:
            self.turn_count = 0
            self.turn_left_next = not self.turn_left_next

            action = Action.TURN_LEFT if self.turn_left_next else Action.TURN_RIGHT
            return Decision(action=action, speed=0.2, reason="Patrol turn")

        return None

    def reset(self):
        """Called by engine.reset()"""
        self.turn_count = 0
        self.turn_left_next = True
```

---

## Loading Plugins

```python
from nanobot.plugins import load_node, load_nodes_from_dir

# Load a node from file
MyNode = load_node("plugins/my_node.py")
engine.add_node(MyNode())

# Load all nodes from directory
for NodeClass in load_nodes_from_dir("plugins/"):
    engine.add_node(NodeClass())
```

---

## Async / Threaded Execution

For real-time applications where sensor reading or motor control shouldn't block:

### AsyncNodeEngine

```python
from nanobot import AsyncNodeEngine
from nanobot.nodes import SafetyNode, NavigationNode, ExplorerNode

# Create async engine
engine = AsyncNodeEngine(debug=True)
engine.add_node(SafetyNode())
engine.add_node(NavigationNode())
engine.add_node(ExplorerNode())

# Define how to read sensors
def read_sensors():
    # Your sensor reading code
    return SensorData(front=lidar.front, left=lidar.left, right=lidar.right)

# Optional: callback when decision changes
def on_decision(decision):
    motor.execute(decision.action, decision.speed)

# Start background processing at 10 Hz
engine.start(
    sensor_callback=read_sensors,
    tick_rate=10.0,
    decision_callback=on_decision
)

# Main thread stays free
while running:
    # Do other things...
    decision = engine.get_decision()  # Non-blocking
    print(f"Latest: {decision}")

# Cleanup
engine.stop()
```

### SensorThread

For slow sensors (LIDAR scans):

```python
from nanobot import SensorThread

def slow_lidar_read():
    # Takes 50ms to complete
    return lidar.full_scan()

sensor_thread = SensorThread(slow_lidar_read, rate=20.0)
sensor_thread.start()

# Get latest reading without waiting
sensors = sensor_thread.read()
```

### DecisionExecutor

For rate-limited motor control:

```python
from nanobot import DecisionExecutor

def send_to_motor(decision):
    motor.execute(decision.action, decision.speed)

executor = DecisionExecutor(send_to_motor, rate_limit=20.0)
executor.start()

# Queue decisions (won't block)
executor.submit(decision)

# Or replace queue with latest (drops old)
executor.submit_replace(decision)
```

---

## SensorData Structure

```python
SensorData(
    front=1.5,        # Front distance (meters)
    left=0.8,         # Left distance
    right=0.6,        # Right distance
    left_front=1.2,   # Left diagonal
    right_front=0.9,  # Right diagonal
    back=2.0          # Rear
)
```

## Available Actions

- `Action.FORWARD` - Move forward
- `Action.BACKWARD` - Move backward
- `Action.TURN_LEFT` - Turn left
- `Action.TURN_RIGHT` - Turn right
- `Action.STOP` - Stop

---

## Advanced Nodes (v0.2.0+)

### A* Pathfinding

Navigate to specific coordinates using A* algorithm:

```python
from nanobot.nodes import PathfindingNode, SafetyNode

engine = NodeEngine()
engine.add_node(SafetyNode())

pathfinder = PathfindingNode(priority=20)
engine.add_node(pathfinder)

# Set a goal (world coordinates in meters)
pathfinder.set_goal(x=2.0, y=1.5)

# Update robot odometry each tick
pathfinder.update_odometry(robot_x, robot_y, robot_angle)

# Run engine - it will navigate to goal
decision = engine.tick(sensors)
```

### Wall Following

Follow walls with PID control:

```python
from nanobot.nodes import WallFollowerNode, RightWallFollowerNode

# Right wall follower at 0.5m distance
wall_follower = RightWallFollowerNode(target_distance=0.5)
engine.add_node(wall_follower)

# Activate wall following
wall_follower.start()

# Run engine
decision = engine.tick(sensors)

# Stop when done
wall_follower.stop()
```

### Systematic Exploration

Frontier-based exploration to map unknown areas:

```python
from nanobot.nodes import ExplorationNode, SafetyNode

engine = NodeEngine()
engine.add_node(SafetyNode())

explorer = ExplorationNode(priority=40)
engine.add_node(explorer)

# Start exploration
explorer.start()

# Update odometry each tick
explorer.update_odometry(robot_x, robot_y, robot_angle)

# Run until complete
while not explorer.is_complete():
    decision = engine.tick(sensors)
    print(f"Progress: {explorer.get_progress()*100:.1f}%")

# Get the generated map
exploration_map = explorer.get_map()
```

---

## Hardware Adapters

For real Jetson Nano robots:

```python
from nanobot.adapters import MotorAdapter, SensorAdapter

class JetsonMotor(MotorAdapter):
    """PWM motor control on Jetson GPIO."""

    def __init__(self):
        # Initialize GPIO pins
        pass

    def execute(self, action, speed):
        # Send PWM signals to motors
        pass

    def stop(self):
        # Emergency stop
        pass

class LidarSensor(SensorAdapter):
    """RPLidar or YDLidar sensor."""

    def read(self):
        # Read from LIDAR and extract distances
        return SensorData(front=1.0, left=0.5, right=0.8)
```

## Tests

```bash
pytest nanobot/tests/ -v
```

## Architecture

```
nanobot/
|-- core/
|   |-- engine.py       # NodeEngine - executes nodes
|   |-- node.py         # Node, Action, Decision
|   +-- sensors.py      # SensorData
|-- nodes/
|   |-- safety.py       # Priority 0 - collision avoidance
|   |-- navigation.py   # Priority 10 - turning
|   |-- pathfinding.py  # Priority 20 - A* pathfinding
|   |-- wall_follower.py# Priority 30 - wall following + PID
|   |-- exploration.py  # Priority 40 - frontier exploration
|   +-- explorer.py     # Priority 50 - basic exploration
|-- adapters/
|   |-- base.py         # Abstract interfaces
|   +-- mock.py         # Mock implementations
|-- async_engine.py     # Threaded execution
|-- plugins.py          # Dynamic loading
|-- config.py           # Robot configuration
+-- main.py             # CLI
```

## License

MIT
