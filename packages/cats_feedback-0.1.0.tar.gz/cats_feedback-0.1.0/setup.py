from setuptools import setup, find_packages

setup(
    name='cats_feedback',
    version='0.1.0',
    description='Feedback about cats library',
    author='Mahdi',
    author_email='louatimahdi390@gmail.com',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'ipython>=8.0.0',
        'requests>=2.25.0'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)