# cats_feedback

End-to-end feedback collection system for Python libraries.

## Features
- Interactive feedback form in Jupyter/Colab
- Automatic thank-you message
- Email confirmation with custom HTML template
- Dynamic form fields (demo date, problem file)

## Installation

```bash
pip install cats_feedback