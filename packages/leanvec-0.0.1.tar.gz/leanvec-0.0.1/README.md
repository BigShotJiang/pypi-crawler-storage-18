## Executive Summary

This report evaluates the performance of the **BlitzVec** local Vector DB library across four scales: **500,000** to **2,000,000** vectors, using **768-dimensional** embeddings.

The latest benchmarks highlight BlitzVec's efficiency in handling high-concurrency environments and the significant performance advantages of metadata-filtered searches. As the dataset scales, the library maintains a predictable performance curve, making it a reliable choice for local-first vector storage and retrieval.

---

## 1. Key Performance Metrics

The following data (from 500k to 2M) represents actual measured performance (_VPS: Vectors per second; QPS: Queries per second_):

| Metric                    | 500k  | 1M    | 1.5M  | 2M    | 5M (Extrap.) | 10M (Extrap.) |
| ------------------------- | ----- | ----- | ----- | ----- | ------------ | ------------- |
| **Bulk Indexing (VPS)**   | 3,460 | 1,840 | 1,429 | 1,155 | \~680        | \~420         |
| **Pure Read QPS**         | 144.4 | 77.0  | 52.6  | 39.3  | \~15.2       | \~7.4         |
| **Search QPS (Filtered)** | 148.6 | 111.5 | 90.9  | 81.1  | \~42.5       | \~24.8        |
| **Search QPS (Load)**     | 24.6  | 20.9  | 17.1  | 14.7  | \~7.8        | \~4.5         |
| **Mixed Load QPS**        | 87.8  | 47.9  | 20.8  | 5.0   | \< 1.0\*     | \< 0.5\*      |

_Note: This benchmark was executed in a AWS EC2 t3.micro, with 2 cpu cores, 1gb ram and a 8gb gp3 (3000 IOPS) general purpose SSD (around U$12/month)._

---

## 2. Scenario Analysis

### Scenario 1: Bulk Indexing (Ingestion)

BlitzVec is designed for rapid data setup.

* **Performance:** Achieving over **3,400 VPS** at the 500k mark.
* **Observation:** While ingestion speed naturally tapers as the index grows, it maintains a steady rate above 1,100 VPS even at 2 million vectors, ensuring that initial data loads remain manageable for large local datasets.

### Scenario 2: The Filtering Advantage

The data confirms that metadata filtering is the most effective way to maintain high performance at scale.

* **Comparison:** At 2,000,000 vectors, a **Filtered Search (81.10 QPS)** is more than **2x faster** than a **Pure Read (39.30 QPS)** and over **5x faster** than a search performed under system load.
* **Insight:** BlitzVec optimizes the search space by utilizing metadata to prune candidates before executing expensive vector calculations.

### Scenario 3: Performance Under Load

These metrics simulate real-world usage where search queries occur while the system is under background stress.

* **Stability:** Even at the 2M vector limit, the library provides a consistent **14.73 QPS** under load.
* **Mixed Load Scaling:** The Mixed Load QPS (simulating concurrent reads, writes, and deletes) shows a sharper decline as the dataset approaches 2M vectors, suggesting that for high-concurrency write environments, maintaining smaller or partitioned indexes is optimal.

---

## 3. What Users Can Expect

### Predictable Scaling

Search speeds (Pure Read) scale predictably with the volume of data. When your dataset doubles (e.g., 500k to 1M), the QPS roughly halves, indicating a linear relationship that allows for easy capacity planning.

### Efficient Search in Real-World Conditions

By utilizing **Filtered Search**, users can keep latency low even as the database grows. The library is highly effective for:

* **Metadata-Heavy Workloads:** Where specific attributes (User ID, Category, Timestamp) are used to narrow down results.
* **Moderate Concurrency:** Maintaining responsive search even while other operations are occurring.

---

## 4. Best Practices for Maximum Performance

1. **Prioritize Filtering:** Always apply metadata filters where possible. A filtered search at 2M vectors is nearly as fast as a pure read at 1M vectors.
2. **Monitor Mixed Loads at Scale:** If your application requires high-frequency writes and deletes simultaneously with searches, consider indexing strategies that keep individual collection sizes below 1.5M vectors for peak Mixed Load QPS.
3. **Bulk Ingestion:** Utilize the bulk indexing feature for initial setups to take advantage of the high VPS rates (up to 3,460 vec/s).