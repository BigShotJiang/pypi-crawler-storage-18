import unittest
import shutil
import tempfile
import time
import os
import numpy as np

# Import the Wrapper Class
from lean import LeanVecWrapper

class BaseVectorDBTest(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db = LeanVecWrapper(self.test_dir)
        
    def tearDown(self):
        # Clean up memory references
        if hasattr(self, 'db'): 
            del self.db
        # Clean up disk
        if os.path.exists(self.test_dir):
            try:
                shutil.rmtree(self.test_dir)
            except OSError:
                pass 

    def _store_batch(self, vectors, metas, ids=None):
        """Helper that adapts to the Wrapper's batch input format"""
        # Inject IDs into metadata if provided
        if ids:
            for i, meta in enumerate(metas):
                meta["id"] = str(ids[i])
        
        # Wrapper handles JSON serialization
        self.db.store_embeddings_batch(vectors, metas)

    def _ids(self, results):
        """Helper to extract IDs from wrapper results (List[Dict])"""
        return sorted([r["id"] for r in results])

class TestAdvancedFilters(BaseVectorDBTest):
    def setUp(self):
        super().setUp()
        vec = [0.1, 0.1]
        # Setup data with mix of types
        self._store_batch(
            [vec]*6, 
            [
                {"id": "1", "tag": "A", "score": 10, "active": True},
                {"id": "2", "tag": "B", "score": 20, "active": True},
                {"id": "3", "tag": "A", "score": 30, "active": False},
                {"id": "4", "tag": "C", "score": 40, "active": True},
                {"id": "5", "tag": "B", "score": 50, "active": False},
                {"id": "6", "tag": "A", "score": 60, "active": True},
            ]
        )
        self.vec = vec

    def test_gt_lt(self):
        # score > 35 -> 4, 5, 6
        res = self.db.search(self.vec, filters={"score": {"$gt": 35}}, k=10)
        self.assertEqual(self._ids(res), ["4", "5", "6"])

        # score < 25 -> 1, 2
        res = self.db.search(self.vec, filters={"score": {"$lt": 25}}, k=10)
        self.assertEqual(self._ids(res), ["1", "2"])

    def test_and_logic(self):
        # tag=A AND score > 20 -> 3, 6
        query = {"$and": [
            {"tag": "A"},
            {"score": {"$gt": 20}}
        ]}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["3", "6"])

    def test_or_logic(self):
        # tag=C OR score < 15 -> 4, 1
        query = {"$or": [
            {"tag": "C"},
            {"score": {"$lt": 15}}
        ]}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["1", "4"])

    def test_in_nin(self):
        # tag IN [B, C] -> 2, 4, 5
        res = self.db.search(self.vec, filters={"tag": {"$in": ["B", "C"]}}, k=10)
        self.assertEqual(self._ids(res), ["2", "4", "5"])

        # tag NIN [A, B] -> C(4)
        res = self.db.search(self.vec, filters={"tag": {"$nin": ["A", "B"]}}, k=10)
        self.assertEqual(self._ids(res), ["4"])

    def test_not_complex(self):
        # NOT (tag=A OR score < 20) -> 2, 4, 5
        query = {"$not": {"$or": [{"tag": "A"}, {"score": {"$lt": 20}}]}}
        res = self.db.search(self.vec, filters=query, k=10)
        self.assertEqual(self._ids(res), ["2", "4", "5"])

class TestBulkDelete(BaseVectorDBTest):
    def test_large_scale_delete(self):
        """
        Verify we can delete > 10k items by filter.
        (Previously limited by search K-limit).
        """
        count = 15_000
        # Use a small dimension for speed in generation
        # NOTE: Wrapper enforces consistent dimension. We use 2 here.
        vecs = [[0.1, 0.1]] * count
        
        # 10k items to delete (group A), 5k to keep (group B)
        metas = []
        for i in range(count):
            group = "A" if i < 10000 else "B"
            metas.append({"id": str(i), "group": group})
            
        print(f"Inserting {count} vectors for delete test...")
        self.db.store_embeddings_batch(vecs, metas)
        
        self.assertEqual(self.db.count(), 15000)
        
        # Perform Bulk Delete
        print("Deleting group 'A' (10,000 items)...")
        start = time.time()
        deleted_count = self.db.delete({"group": "A"})
        dur = time.time() - start
        
        print(f"Deleted {deleted_count} items in {dur:.4f}s")
        
        self.assertEqual(deleted_count, 10000)
        self.assertEqual(self.db.count(), 5000)
        
        # Verify survivors are Group B
        res = self.db.search([0.1, 0.1], filters={"group": "B"}, k=1)
        self.assertTrue(len(res) > 0)
        
        # Verify Group A is gone
        res_gone = self.db.search([0.1, 0.1], filters={"group": "A"}, k=1)
        self.assertEqual(len(res_gone), 0)

class TestWrapperFeatures(BaseVectorDBTest):
    def test_autocut(self):
        """Test the elbow detection logic"""
        # Distance scores (smaller is better). 
        # 0.1 -> 0.12 (small change)
        # 0.12 -> 0.13 (small change)
        # 0.13 -> 0.50 (HUGE JUMP > 20%) -> Cut here
        # 0.50 -> 0.51
        scores = [0.1, 0.12, 0.13, 0.50, 0.51]
        
        indices = self.db.autocut_scores(scores)
        # Should return indices from 3 onwards (0.50 is index 3)
        self.assertEqual(indices, [3, 4])

    def test_dimension_enforcement(self):
        """Ensure we can't insert mixed dimensions"""
        # 1. First insert sets dimension to 2
        self.db.store_embedding([0.1, 0.1], {"id": "1"})
        
        # 2. Try inserting dimension 3
        with self.assertRaises(ValueError):
            self.db.store_embedding([0.1, 0.1, 0.1], {"id": "2"})
            
        # 3. New instance should respect config
        del self.db
        new_db = LeanVecWrapper(self.test_dir)
        with self.assertRaises(ValueError):
            new_db.store_embedding([0.1, 0.1, 0.1], {"id": "3"})

class TestPerformance(BaseVectorDBTest):
    def test_filter_speed_large(self):
        """Performance check using the wrapper"""
        count = 10000
        # Use standard dimension
        vecs = np.random.rand(count, 768).astype(np.float32).tolist()
        metas = []
        for i in range(count):
            metas.append({
                "id": str(i),
                "val": i,
                "group": "A"
            })
        
        start = time.time()
        self.db.store_embeddings_batch(vecs, metas)
        print(f"\n[Perf] Inserted {count} in {time.time()-start:.2f}s")
        
        start = time.time()
        # Find top half of values
        res = self.db.search(vecs[0], k=10, filters={"val": {"$gt": count/2}})
        dur = time.time() - start
        
        print(f"[Perf] Range Search via Wrapper: {dur*1000:.2f}ms")
        self.assertTrue(dur < 0.1) # Tolerance

if __name__ == "__main__":
    unittest.main()