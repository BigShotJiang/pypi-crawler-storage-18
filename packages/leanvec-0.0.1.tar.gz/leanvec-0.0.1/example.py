import lean
import time
import numpy as np

DB_PATH = "./my_db"
DIM = 768
COUNT = 500_000

# Cleanup for fresh start if needed (optional)
# if os.path.exists(DB_PATH): shutil.rmtree(DB_PATH)

print(f"Initializing DB at {DB_PATH}...")
db = lean.LeanDB(DB_PATH)

current_count = db.count()
print(f"Current vectors in DB: {current_count}")

if current_count < COUNT:
    needed = COUNT - current_count
    print(f"Generating {needed} new vectors...")
    
    batch_size = 5000
    start_load = time.time()
    
    for i in range(current_count, COUNT):
        vec = np.random.rand(DIM).astype(np.float32).tolist()
        
        # Simulate Batch Insert loop
        # We use single add here to test WAL speed, but batching is trivial to add
        meta = {"color": "red" if i % 2 == 0 else "blue", "type": "A" if i % 3 == 0 else "B"}
        db.add(f"id_{i}", vec, meta)
        
        if i % 10000 == 0 and i > 0:
            print(f"Inserted {i} vectors... ({(i - current_count)/(time.time()-start_load):.0f} vec/s)")

    print(f"Loaded {needed} vectors in {time.time() - start_load:.2f}s")
    
    # Save Snapshot to disk so next reload is fast
    print("Snapshotting to disk...")
    s = time.time()
    db.persist()
    print(f"Snapshot took {time.time() - s:.2f}s")

else:
    print("DB already populated. Skipping generation.")

# --- Performance Tests ---

query_vec = np.random.rand(DIM).astype(np.float32).tolist()

# 1. Search with Filter
start = time.time()
results = db.search(query_vec, 5, {"color": "blue", "type": "A"})
dur = time.time() - start
print(f"Filtered Search Result: {results}")
print(f"Time: {dur*1000:.2f}ms")

# 2. Delete Persistence Check
print("Deleting id_0...")
db.delete("id_0")
# Should not find id_0
res = db.search(query_vec, 1, None) # Rough check
print(f"Count after delete: {db.count()}")

# Stress test and measure queries per second
n_queries = 1000
n_vectors_per_query = 5000
start = time.time()
for _ in range(n_queries):
    db.search(np.random.rand(DIM).astype(np.float32).tolist(), n_vectors_per_query, None)
dur = time.time() - start
print(f"Performed {n_queries} queries of {n_vectors_per_query} vectors in {dur:.2f}s -> {n_queries/dur:.2f} QPS")
