import os, datetime, decimal, time, threading
import numpy as np

from blitz_vec import BlitzVec

class VectorExp:
    SEP = "|"
    MAX_CHAR = "\xff"
    
    def __init__(
        self,
        storage_base_path="vectordb_data",
        shards=2,
        max_size_gb=50,
        delete_batch_size=1000
    ):
        GB = 1024 * 1024 * 1024
        os.makedirs(storage_base_path, exist_ok=True)
        
        # Dim is 0 by default, Rust will learn it from disk or first insert
        self.storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "index_data"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.8) // shards,
            dim=0
        )
        self.meta_storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "meta_blobs"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.2) // shards,
            dim=0
        )
        
        self._write_lock = threading.Lock() 
        self._id_lock = threading.Lock()
        
        self._last_timestamp = 0
        self._counter = 0
        self.actual_dim = 0
        
        self._pending_deletes = []
        self._delete_batch_lock = threading.Lock()
        self._delete_batch_size = delete_batch_size
        
    def store_embeddings_batch(self, vectors, metadata_dicts=None, text_field=None):
        count = len(vectors)
        if count == 0: 
            return []
        
        dim = len(vectors[0])
        if self.actual_dim == 0: 
            self.actual_dim = dim
        
        ids = self._generate_ids(count)
        if metadata_dicts is None: 
            metadata_dicts = [{} for _ in range(count)]
        
        vec_np = np.array(vectors, dtype=np.float32)
        norms = np.linalg.norm(vec_np, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vec_np /= norms
        
        index_entries = []
        for uid, meta in zip(ids, metadata_dicts):
            for key, value in meta.items():
                if text_field and key == text_field: 
                    continue
                val_str = self._format_for_indexing(value)
                prefix = f"idx_{key}:{val_str}"
                index_entries.append((prefix, uid))
        
        with self._write_lock:
            # Vectors -> IVF/RAM + LMDB
            self.storage.store_flat_vectors(vec_np, ids)
            # Metas -> LMDB Blobs
            self.meta_storage.store_data(metadata_dicts, ids)
            
            if index_entries:
                self.storage.batch_index_insert(index_entries)
                
        return ids
    
    def search(self, query_embedding, metadata_filter=None, k=5):
        if self.actual_dim == 0: 
            self.actual_dim = len(query_embedding)
        
        query_np = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_np)
        if query_norm > 0:
            query_np /= query_norm
        
        filter_tree = self._compile_filter(metadata_filter)
        allowed_iter = None
        if filter_tree:
            # Gets IDs from LMDB String Indices
            allowed_iter = self.storage.get_ids_from_filter(filter_tree)
            if allowed_iter is not None and len(allowed_iter) == 0:
                return []
        
        # Rust IVF Search
        results = self.storage.search_flat(query_np, allowed_iter, k)
        
        if not results: 
            return []
            
        final_ids = [res[1] for res in results]
        scores = [res[0] for res in results]
        final_metas = self.meta_storage.get_data(final_ids)
        
        return list(zip(final_ids, scores, final_metas))
    
    def delete(self, metadata_query, force_flush=False):
        filter_tree = self._compile_filter(metadata_query)
        if filter_tree is None: 
            return 0
        
        blitz_iter = self.storage.get_ids_from_filter(filter_tree)
        if not blitz_iter: 
            return 0
        
        ids = blitz_iter.to_list()
        if not ids: 
            return 0
        
        if force_flush or self._delete_batch_size <= 1:
            return self._execute_delete(ids)
        
        with self._delete_batch_lock:
            self._pending_deletes.extend(ids)
            if len(self._pending_deletes) < self._delete_batch_size:
                return len(ids)
            ids_to_delete = self._pending_deletes[:]
            self._pending_deletes.clear()
        
        return self._execute_delete(ids_to_delete)
    
    def _execute_delete(self, ids_to_delete):
        if not ids_to_delete:
            return 0
        metadatas = self.meta_storage.get_data(ids_to_delete)
        indices_to_delete = []
        for uid, meta in zip(ids_to_delete, metadatas):
            if meta:
                for key, value in meta.items():
                    val_str = self._format_for_indexing(value)
                    indices_to_delete.append((f"idx_{key}:{val_str}", uid))
        
        with self._write_lock:
            self.storage.delete_flat_vectors(ids_to_delete)
            if indices_to_delete:
                self.storage.batch_index_delete(indices_to_delete)
            self.meta_storage.delete_data(ids_to_delete)
            
        return len(ids_to_delete)
    
    def flush_deletes(self):
        with self._delete_batch_lock:
            if not self._pending_deletes:
                return 0
            ids_to_delete = self._pending_deletes[:]
            self._pending_deletes.clear()
        return self._execute_delete(ids_to_delete)
    
    def count(self):
        return self.storage.get_data_count()
    
    def compact(self):
        if self.actual_dim == 0:
            return 0
        with self._write_lock:
            return self.storage.compact_vectors(self.actual_dim)
    
    def _format_for_indexing(self, value):
        if isinstance(value, (datetime.date, datetime.datetime)): 
            return value.isoformat()
        if isinstance(value, bool): 
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            offset = decimal.Decimal(2**63)
            return f"{decimal.Decimal(value) + offset:064.8f}"
        return str(value)
    
    def _generate_ids(self, count):
        ids = []
        with self._id_lock:
            now = int(time.time() * 1000)
            if now <= self._last_timestamp: 
                now = self._last_timestamp
            start_idx = self._counter
            self._counter += count
            self._last_timestamp = now
            base_id = (now << 16)
            for i in range(count):
                ids.append(base_id | ((start_idx + i) & 0xFFFF))
        return ids

    def _invert_query(self, query):
        if not isinstance(query, dict):
            return {"$ne": query} 
        if "$not" in query:
            return query["$not"]
        if "$or" in query:
            return {"$and": [self._invert_query(q) for q in query["$or"]]}
        if "$and" in query:
            return {"$or": [self._invert_query(q) for q in query["$and"]]}
        keys = list(query.keys())
        if len(keys) > 1:
            sub_queries = [{k: v} for k, v in query.items()]
            return {"$or": [self._invert_query(sub) for sub in sub_queries]}
        key = keys[0]
        val = query[key]
        if key == "$eq": return {"$ne": val}
        if key == "$ne": return val
        if key == "$gt": return {"$lte": val}
        if key == "$gte": return {"$lt": val}
        if key == "$lt": return {"$gte": val}
        if key == "$lte": return {"$gt": val}
        if key == "$in": return {"$nin": val}
        if key == "$nin": return {"$in": val}
        return {key: self._invert_query(val)}
    
    def _compile_filter(self, query):
        if not query: 
            return None
        nodes = []
        for key, value in query.items():
            if key == "$and":
                sub_nodes = [self._compile_filter(q) for q in value]
                nodes.extend([n for n in sub_nodes if n])
                continue
            if key == "$or":
                sub_nodes = [self._compile_filter(q) for q in value]
                valid_subs = [n for n in sub_nodes if n]
                if valid_subs: 
                    nodes.append((3, valid_subs))
                continue
            if key == "$not":
                inverted = self._invert_query(value)
                sub_node = self._compile_filter(inverted)
                if sub_node:
                    nodes.append(sub_node)
                continue
            prefix_base = f"idx_{key}:"
            if isinstance(value, dict):
                if "$not" in value:
                    inverted = self._invert_query({key: value["$not"]})
                    sub_node = self._compile_filter(inverted)
                    if sub_node:
                        nodes.append(sub_node)
                    continue
                field_nodes = []
                if "$in" in value:
                    or_nodes = []
                    for v in value["$in"]:
                        val_str = self._format_for_indexing(v)
                        or_nodes.append((0, f"{prefix_base}{val_str}"))
                    if or_nodes: 
                        field_nodes.append((3, or_nodes))
                if "$ne" in value:
                    val_str = self._format_for_indexing(value["$ne"])
                    r1_start = f"{prefix_base}"
                    r1_end = f"{prefix_base}{val_str}"
                    r2_start = f"{prefix_base}{val_str}{self.MAX_CHAR}"
                    r2_end = f"{prefix_base}{self.MAX_CHAR}"
                    ne_node = (3, [(1, r1_start, r1_end), (1, r2_start, r2_end)])
                    field_nodes.append(ne_node)
                if "$nin" in value:
                    nin_nodes = []
                    for v in value["$nin"]:
                        val_str = self._format_for_indexing(v)
                        r1_start = f"{prefix_base}"
                        r1_end = f"{prefix_base}{val_str}"
                        r2_start = f"{prefix_base}{val_str}{self.MAX_CHAR}"
                        r2_end = f"{prefix_base}{self.MAX_CHAR}"
                        nin_nodes.append((3, [(1, r1_start, r1_end), (1, r2_start, r2_end)]))
                    if nin_nodes:
                        if len(nin_nodes) == 1:
                            field_nodes.append(nin_nodes[0])
                        else:
                            field_nodes.append((2, nin_nodes))
                gt = value.get("$gt")
                gte = value.get("$gte")
                lt = value.get("$lt")
                lte = value.get("$lte")
                if any(x is not None for x in [gt, gte, lt, lte]):
                    if gte is not None: 
                        s = f"{prefix_base}{self._format_for_indexing(gte)}"
                    elif gt is not None: 
                        s = f"{prefix_base}{self._format_for_indexing(gt)}{self.MAX_CHAR}"
                    else: 
                        s = f"{prefix_base}"
                    if lte is not None: 
                        e = f"{prefix_base}{self._format_for_indexing(lte)}{self.MAX_CHAR}"
                    elif lt is not None: 
                        e = f"{prefix_base}{self._format_for_indexing(lt)}"
                    else: 
                        e = f"{prefix_base}{self.MAX_CHAR}"
                    field_nodes.append((1, s, e))
                if field_nodes:
                    if len(field_nodes) == 1: 
                        nodes.append(field_nodes[0])
                    else: 
                        nodes.append((2, field_nodes))
            else:
                val_str = self._format_for_indexing(value)
                nodes.append((0, f"{prefix_base}{val_str}"))
        if not nodes: 
            return None
        if len(nodes) == 1: 
            return nodes[0]
        return (2, nodes)