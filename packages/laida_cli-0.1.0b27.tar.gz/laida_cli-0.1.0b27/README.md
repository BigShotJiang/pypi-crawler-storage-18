# LAIDA CLI

[![PyPI version](https://badge.fury.io/py/laida-cli.svg)](https://pypi.org/project/laida-cli/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**L**ayered **A**rtificial **I**nteligence **D**esign **A**rchitecture

A methodology-driven CLI that transforms project requirements into production-ready software through structured AI collaboration.

## Key Features

- **Claude Code Native** - Built specifically for [Claude Code](https://claude.ai/code), leveraging its agentic capabilities for autonomous software development
- **Structured Methodology** - 5 phases, 20 steps that guide from requirements to deployment
- **Mission Control TUI** - Interactive dashboard with real-time streaming output
- **YAML-First Architecture** - All artifacts are structured, traceable, and version-controllable
- **Scale-Adaptive** - Automatically adjusts methodology depth based on project complexity

## Installation

```bash
# With TUI (Recommended)
pip install "laida-cli[tui]"

# Basic installation
pip install laida-cli
```

### Requirements

- Python 3.11+
- [Claude Code CLI](https://docs.anthropic.com/en/docs/claude-code) installed and authenticated

## Quick Start

```bash
# Initialize project structure
laida init

# Launch Mission Control
laida tui
```

Then use keyboard shortcuts:
- Press `E` to edit your project context (13-section questionnaire)
- Press `L` to authenticate with Claude Code
- Press `R` to run the next step

## Mission Control TUI

```
╭─────────────────────────────────────╮
│  LAIDA Mission Control  β0.1.5     │
╰─────────────────────────────────────╯
```

An interactive terminal dashboard for orchestrating the LAIDA methodology:

| Key | Action | Description |
|:---:|--------|-------------|
| `R` | Run | Execute next phase/step with confirmation dialog |
| `E` | Edit | Open `project_context.yaml` in your editor |
| `S` | Status | Display project progress overview |
| `L` | Login | Authenticate with Claude Code |
| `V` | Validate | Check artifact integrity |
| `Q` | Quit | Exit Mission Control |

### Dashboard Components

- **Live Feed** - Real-time streaming output from Claude Code execution
- **Progress Panel** - Visual tracker showing completed/pending phases
- **File Tree** - Browse generated artifacts in `outputs/`
- **Git Status** - Current branch and working tree status
- **Telemetry** - Session time, task duration, memory usage

## Commands

| Command | Description |
|---------|-------------|
| `laida init` | Initialize project with methodology templates |
| `laida tui` | Launch Mission Control dashboard |
| `laida login` | Authenticate with Claude Code |
| `laida status` | Show project progress |
| `laida run <phase> <step>` | Execute a specific step |
| `laida validate` | Validate generated artifacts |

## Methodology

LAIDA executes a structured 5-phase methodology:

| Phase | Name | Deliverables |
|:-----:|------|--------------|
| 0 | Strategic Foundation | Project scale, tech stack (TDR), risks, QAS, bounded contexts, ADRs |
| 1 | Module Design | RTM, module specifications, DDD aggregates |
| 2 | Physical Design | File structure, Chain-of-Thought architecture |
| 3 | Contract Definition | API contracts, dependency analysis |
| 4 | Implementation | Production code, tests, CI/CD, documentation |

Each phase contains 4 steps, totaling 20 sequential steps from requirements to deployment.

## Project Structure

```
your-project/
├── .laida/                              # Methodology engine
│   ├── config.yaml                      # Phase/step definitions
│   ├── prompts/                         # Claude Code prompts per step
│   ├── templates/                       # Artifact schemas
│   │   └── project_context_template.yaml
│   ├── matrices/                        # Tech selection criteria
│   └── rules/                           # Scale calculation
├── inputs/
│   ├── project_context.yaml             # YOUR PROJECT DETAILS
│   └── project_context_template.yaml    # Reference template
└── outputs/
    └── phase{0-4}/                      # Generated artifacts
```

## Project Context

The `project_context.yaml` is your project's DNA. It contains 13 sections that LAIDA uses to make intelligent decisions:

| Section | Purpose |
|---------|---------|
| Project Identity | Name, type, description |
| Business Context | Domain, criticality, deadlines |
| Scale Expectations | Users, RPS, data volume, growth |
| Team Context | Size, skills, availability |
| Technical Context | Infrastructure, legacy systems, integrations |
| Security | Auth, encryption, compliance (GDPR, HIPAA, etc.) |
| Observability | Logging, metrics, tracing, alerting |
| Recovery | RTO, RPO, backup strategy |
| Quality Standards | Coverage, complexity limits, performance budgets |
| Architecture Preferences | Paradigm, deployment model |
| Domain-Specific | Custom fields for your industry |
| Known Concerns | Documented risks and constraints |
| Success Criteria | Measurable goals |

## How It Works

1. **You describe** your project in `project_context.yaml`
2. **LAIDA calculates** project scale (small/medium/large) and selects optimal tech stack
3. **Claude Code executes** each step autonomously, generating structured YAML artifacts
4. **Artifacts chain** together - each step references outputs from previous steps
5. **Phase 4 generates** production Python code, tests, and CI/CD configuration

## Development

```bash
git clone https://github.com/your-org/laida-cli
cd laida-cli
pip install -e ".[all]"

# Quality checks
pytest tests/ -v
ruff check src/
mypy src/laida_cli/
```

## License

MIT

---

Built for [Claude Code](https://claude.ai/code) | [Documentation](https://github.com/your-org/laida-cli) | [Issues](https://github.com/your-org/laida-cli/issues)
