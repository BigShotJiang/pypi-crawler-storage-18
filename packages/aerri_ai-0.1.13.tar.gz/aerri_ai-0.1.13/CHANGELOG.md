# Changelog

All notable changes to Aerri-AI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.3] - 2024-12-21

### Added
- Workspace memory system for persistent context
- Animated CLI interface with loading indicators
- File change tracking and explanation
- Enhanced error handling and reporting

### Changed
- Improved code execution with better error messages
- Optimized file operations for better performance

### Fixed
- Various bug fixes and stability improvements

## [0.1.2] - 2024-12-20

### Added
- Python code execution capability
- File deletion with safety checks
- Directory listing functionality

### Changed
- Enhanced AI response quality
- Improved file writing with backup

## [0.1.1] - 2024-12-19

### Added
- Basic file read/write operations
- Integration with Groq LLMs
- LangChain and LangGraph orchestration

### Changed
- Initial CLI interface improvements

## [0.1.0] - 2024-12-18

### Added
- Initial release
- Basic AI coding assistant functionality
- File operations support
- Command-line interface
