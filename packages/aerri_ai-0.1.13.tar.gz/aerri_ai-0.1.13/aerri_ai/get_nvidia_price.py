import yfinance as yf

def main():
    ticker = yf.Ticker('NVDA')
    data = ticker.history(period='1d')
    if not data.empty:
        price = data['Close'][-1]
        print(f"NVIDIA (NVDA) current price: ${price:.2f}")
    else:
        print('No data retrieved')

if __name__ == '__main__':
    main()
