"""
Aerri-AI: The most advanced AI coding assistant for your terminal.

Aerri-AI transforms your development workflow with intelligent file operations,
code execution, and AI-powered assistance. Built with LangChain and powered by
Groq's lightning-fast LLMs.

Key Features:
- Smart file operations with AI assistance
- Code execution and debugging
- Workspace memory across sessions
- Error detection and fixing
- Beautiful animated CLI interface
- Lightning-fast responses via Groq

Example usage:
    $ aerri-ai "Create a FastAPI app with user authentication"
    $ aerri-ai "Fix the bugs in my Python script"
    $ aerri-ai "Explain what this code does"
"""

__version__ = "0.1.3"
__author__ = "Adu"
__email__ = "adu@aerri-ai.com"
__license__ = "MIT"

from .cli import main

__all__ = ["main"]