# tup

Run any command in the cloud. Close your laptop, keep running.

```bash
# Local
uv run python train.py

# Cloud (just prefix with tup)
tup uv run python train.py
```

## Installation

```bash
pip install tup
```

## Quick Start

```bash
# Configure (one-time)
tup config set api_url https://tup-api.your-account.workers.dev

# Run a command in the cloud
tup python train.py --epochs 100

# Detach and check later
tup --detach python train.py --epochs 1000
tup logs        # Stream logs
tup status      # Check job status
```

## Usage

```bash
tup <command>                    # Run command, stream logs until done
tup --detach <command>           # Run in background, return job ID
tup --name "exp-v1" <command>    # Named job for easy reference

tup logs [job-id]                # Stream logs (default: latest job)
tup status                       # List all jobs
tup stop <job-id>                # Kill a running job
tup attach <job-id>              # Reattach to running job's logs
```

## Options

```bash
--detach, -d          Run in background
--name, -n NAME       Job name
--instance TYPE       Instance size: lite, basic, standard-1, standard-2, standard-3, standard-4
--env KEY=VALUE       Pass environment variable (can repeat)
--timeout DURATION    Max runtime (e.g., "2h", "30m", "1d")
```

## Configuration

Configuration is stored in `~/.tup/config.toml`:

```toml
[default]
api_url = "https://tup-api.your-account.workers.dev"

[env]
# Environment variables passed to all jobs
WANDB_API_KEY = "your-key"
TINKER_API_KEY = "your-key"
```

Or use environment variables:

```bash
export TUP_API_URL="https://tup-api.your-account.workers.dev"
```

## How It Works

1. `tup` packages your current directory (respecting `.gitignore`)
2. Uploads the bundle to Cloudflare R2
3. Spins up a container with your command
4. Streams logs back to your terminal
5. Container runs until your command exits

## Self-Hosting

Deploy your own tup backend:

```bash
cd worker
cp wrangler.example.toml wrangler.toml
# Edit wrangler.toml with your account details
pnpm install
pnpm run deploy
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for architecture details.

## Instance Types

| Type | vCPU | Memory | Disk | ~Cost/hour |
|------|------|--------|------|------------|
| lite | 1/16 | 256MB | 2GB | $0.002 |
| basic | 1/4 | 1GB | 4GB | $0.01 |
| standard-1 | 1/2 | 4GB | 8GB | $0.04 |
| standard-2 | 1 | 6GB | 12GB | $0.08 |
| standard-3 | 2 | 8GB | 16GB | $0.16 |
| standard-4 | 4 | 12GB | 20GB | $0.32 |

## License

MIT
