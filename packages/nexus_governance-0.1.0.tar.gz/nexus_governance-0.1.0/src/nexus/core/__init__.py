"""Core kernel."""
