from . import BaseClientParser
from ..parser import ENDSWITH_DARWIN
from ua_extract.enums import AppType


class MobileApp(BaseClientParser):
    __slots__ = ()
    APP_TYPE = AppType.MobileApp

    fixture_files = [
        'local/client/mobile_apps.yml',
        'upstream/client/mobile_apps.yml',
    ]

    STRIP_EXTRA_SUFFIXES = (
        '.*Android',
        '.*CFNetwork',
    )

    def check_all_regexes(self) -> bool:
        # Don't check ahocorasick for user agents like:
        # R/3.6.0 (ubuntu-16.04) R (3.6.0 x86_64-pc-linux-gnu x86_64 linux-gnu)
        if self.user_agent.lower().startswith("r/"):
            return True
        if super().check_all_regexes():
            return True
        if ENDSWITH_DARWIN.search(self.user_agent.lower()):
            return True
        return False


__all__ = [
    'MobileApp',
]
