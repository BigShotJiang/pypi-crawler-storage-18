from .base import BaseDeviceParser
from ua_extract.enums import DeviceType

# Extracted from ^(?:chrome|firefox|Abcd|Dark|KvshClient|Node.js|Report Runner|url|Zeus|ZmEu)$
GENERIC_BOT_UAS = {
    'chrome',
    'firefox',
    'abcd',
    'dark',
    'kvshclient',
    'node.js',
    'report runner',
    'url',
    'zeus',
    'zmeu',
    'google',
}


class Bot(BaseDeviceParser):
    __slots__ = ()
    DEVICE_TYPE = DeviceType.Unknown

    fixture_files = [
        'upstream/bots.yml',
    ]

    STRIP_EXTRA_SUFFIXES = (
        r'.*admantx\.com',
        r'.+monitoring',
        r'.+Podcast Sync',
        r'.*(?:Fetcher|Finder)',
        r'.+isitwp\.com',
        r'.*spider|baidu Transcoder',
        r'.*yahoo-ad-monitoring-SLN24857',
        r'.*outbrain',
        r'.*crawlingpolicy',
        r'.*www\.pinterest\.com',
    )

    def check_all_regexes(self) -> bool:
        if super().check_all_regexes():
            return True
        return self.user_agent.lower() in GENERIC_BOT_UAS

    def is_bot(self) -> bool:
        return self.matched_regex is not None

    def set_details(self) -> None:
        return super().set_details() if self.is_bot() else None


__all__ = [
    'Bot',
]
