#!/bin/bash

unset http_proxy
unset https_proxy
unset HTTP_PROXY
unset HTTPS_PROXY

#############################  kwargs ##########################
WARMUP=0.0
TBS=32
LR=1e-5
MAX_LENGTH=8196
FPS=2.0

# Path to training data
data_files=(
    "hpdv3:/path/to/your/hpdv3/train.json"
    "rapidata-t2v:/path/to/your/rapidata/train.parquet"
    "your-source:/path/to/your/other/dataset"
)
DATA_PATH=$(printf '%s,' "${data_files[@]}" | sed 's/,$//')

# Path to evaluation data (Optional)
EVAL_DATA_PATH="Path/to/eval/data"


# Example Task Instruction
TASK_INSTRUCTION="Provide the task instruction here.
The task instruction should clearly explain the evaluation criteria.
It should include a {prompt} placeholder for the text prompt.
"

# Path to the pretrained model
PRETRAIN_PATH="path/to/your/pretrained/vision-language/model"

# Save and log paths
current_time=$(date +"%m%d%H%M")
SAVE_MODEL_NAME=lightrft-srm-lr$LR-loss_type-dataset-pretrained_model-$current_time
mkdir -p results/$SAVE_MODEL_NAME

LOG_BASE=log
mkdir -p $LOG_BASE

############################### env settings #####################
export GPUS_PER_NODE=$GPUS_PER_NODE
export NNODES=$NNODES
export NODE_RANK=$RANK
export MASTER_ADDR=$MASTER_ADDR
export MASTER_PORT=$MASTER_PORT

# Compute total world size (number of processes)
export WORLD_SIZE=$((NNODES * GPUS_PER_NODE))

# export NCCL_DEBUG=INFO

############################### torchrun #####################
set -x

torchrun --nnodes $NNODES --nproc-per-node $GPUS_PER_NODE --node_rank $NODE_RANK --master-port $MASTER_PORT --master-addr $MASTER_ADDR examples/srm_training/train_srm_vl.py \
    --pretrain ${PRETRAIN_PATH} \
    --save_path results/$SAVE_MODEL_NAME \
    --ckpt_path results/$SAVE_MODEL_NAME \
    --train_batch_size ${TBS} \
    --micro_train_batch_size 4 \
    --max_epochs 5 \
    --lr_warmup_ratio ${WARMUP} \
    --prompt_max_len $MAX_LENGTH \
    --zero_stage 3 \
    --bf16 \
    --actor_learning_rate $LR \
    --train_data $DATA_PATH \
    --gradient_checkpointing \
    --save_steps 100 \
    --max_ckpt_num 5 \
    --use_tensorboard "tensorboard/$SAVE_MODEL_NAME" \
    --l2 1.0e-4 \
    --flash_attn \
    --loss_type hps \
    --margin 0.1 \
    --scale_for_train \
    --pooling_method attn \
    --heads_types preference \
    --task_instruction "$TASK_INSTRUCTION" \
    --fps $FPS \
    2>&1 | tee log/lightrft_srm_vl_${NODE_RANK}.log


#    --eval_data ${EVAL_DATA_PATH} \
#    --eval_steps 500 \
#    --adam_offload \
#    --probing_layer 17 \  # Default is -1, the last layer


