# pdb4ambermini

基于 pdb4amber 的精简版工具（去除对 Amber 可执行程序的依赖），用于清理和准备 PDB/CIF 结构，生成更适合 Amber 力场的拓扑。

## 支持的功能
- 读取本地文件、stdin、URL 或 PDB ID（依赖 ParmEd 下载功能）。
- 自动识别并重命名组氨酸（HIS → HID/HIE/HIP），可选常 pH 模式（ASP/GLU/HIS → AS4/GL4/HIP）。
- 检测二硫键并重命名 CYS→CYX，写出 S–S CONECT 记录（可关闭）。
- 识别残基缺口、非标准残基；输出重编号对照表、非标准残基子集、二硫键列表。
- 支持删除氢原子、去水、按掩码 strip 原子/残基、选择模型、处理 altloc（保留/丢弃/按占据度）。
- 支持突变残基（如 `-m \"3-ALA,4-GLU\"`），并输出为 PDB 或 MOL2。

## 安装
```bash
pip install pdb4ambermini
```

## 命令行用法
```bash
# 查看帮助
pdb4ambermini --help

# 最简单用法，输出到文件
pdb4ambermini input.pdb -o cleaned.pdb

# 仅保留蛋白并去水
pdb4ambermini input.pdb -p -d -o protein.pdb

# 按掩码删除原子/残基
pdb4ambermini input.pdb -s ':LIG,HOH' -o stripped.pdb

# 处理 PDB ID，常 pH 重命名，按模型选择
pdb4ambermini 1tsu --pdbid --constantph --model 1 -o out.pdb

# 突变并保留 altloc
pdb4ambermini input.pdb -m "10-ALA,15-GLU" --keep-altlocs -o mutated.pdb
```

主要命令行参数：
- `-i/--in` 输入文件（默认 stdin）；`-o/--out` 输出文件（默认 stdout）。
- `-y/--nohyd` 去氢；`-d/--dry` 去水；`-s/--strip` 原子/残基掩码。
- `-m/--mutate` 突变残基；`-p` 仅保留蛋白；`-a` 仅保留 Amber 支持残基。
- `--constantph` 常 pH 重命名；`--most-populous` altloc 取占据度最大；`--keep-altlocs` 保留 altloc。
- `--pdbid` 按 PDB ID 下载；`--model` 指定模型（负数保留全部）。
- `--no-conect` 不写二硫键 CONECT；`--noter` 不写 TER。

## Python 调用示例
```python
from pdb4ambermini.pdb4amber import run

ns_names, gaps, disulfides = run(
    arg_pdbout="cleaned.pdb",
    arg_pdbin="input.pdb",   # 可为路径、类似文件对象或 parmed.Structure
    arg_nohyd=False,
    arg_dry=False,
    arg_strip_atom_mask=None,
    arg_mutate_string=None,
    arg_prot=False,
    arg_amber_compatible_residues=False,
    arg_constph=False,
    arg_mostpop=False,
    arg_model=0,
    arg_keep_altlocs=False,
    arg_logfile="pdb4ambermini.log",
    arg_conect=True,
    arg_noter=False,
)
print("非标准残基:", ns_names)
print("缺口:", gaps)
print("二硫键:", disulfides)
```

## 许可证
MIT License。项目源自 pdb4amber（BSD-3-Clause，AMBER 项目），原始源码的版权与 BSD 条款已在 LICENSE 中致谢并注明。
