"""Core FastAPI application components."""
