#![allow(non_local_definitions)]
use pyo3::prelude::*;
use pyo3::types::{PyList, PyBytes, PyNone, PyTuple, PyAny};
use numpy::{PyReadonlyArray1, PyReadonlyArray2};
use lmdb::{Environment, Transaction, WriteFlags, Database, EnvironmentFlags, Cursor, Error as LmdbError};
use rayon::prelude::*;
use std::sync::{Arc, atomic::{AtomicBool, AtomicUsize, Ordering}};
use std::path::Path;
use std::fs;
use std::collections::HashSet;
use byteorder::{ByteOrder, LittleEndian, BigEndian};
use parking_lot::{RwLock};
use std::cmp::Ordering as CmpOrdering;
use std::thread;
use crossbeam_channel::{Sender, unbounded};

#[cfg(target_arch = "x86_64")]
use std::arch::x86_64::*;

// --- CONFIG ---
const MDB_NOTLS: EnvironmentFlags = EnvironmentFlags::NO_TLS;
const MDB_MAPASYNC: EnvironmentFlags = EnvironmentFlags::MAP_ASYNC;
const MDB_SET_RANGE: u32 = 17;
const MDB_NEXT: u32 = 8;
const MDB_LAST: u32 = 6;
const VECTORS_PER_PAGE: usize = 256;
const DELETED_MARKER: i64 = i64::MIN;
const SEGMENT_SIZE: usize = 8_192; 

// Quantization settings
const QUANT_MIN: f32 = -3.0;
const QUANT_MAX: f32 = 3.0;
const QUANT_RANGE: f32 = QUANT_MAX - QUANT_MIN;
const QUANT_SCALE: f32 = 255.0 / QUANT_RANGE;
const QUANT_INV_SCALE: f32 = QUANT_RANGE / 255.0;

#[derive(Debug, PartialEq, Clone, Copy)]
struct ScoredId {
    score: f32,
    id: i64,
}

impl Ord for ScoredId {
    fn cmp(&self, other: &Self) -> CmpOrdering {
        other.score.partial_cmp(&self.score).unwrap_or(CmpOrdering::Equal)
    }
}

impl PartialOrd for ScoredId {
    fn partial_cmp(&self, other: &Self) -> Option<CmpOrdering> {
        Some(self.cmp(other))
    }
}

impl Eq for ScoredId {}

// --- KERNEL: F32 Dot Product ---
#[inline(always)]
fn dot_product_f32(a: &[f32], b: &[f32]) -> f32 {
    let len = a.len();
    #[cfg(target_arch = "x86_64")]
    unsafe {
        let mut sum_v = _mm256_setzero_ps();
        let mut i = 0;
        while i + 16 <= len {
            let va0 = _mm256_loadu_ps(a.as_ptr().add(i));
            let vb0 = _mm256_loadu_ps(b.as_ptr().add(i));
            sum_v = _mm256_fmadd_ps(va0, vb0, sum_v);
            let va1 = _mm256_loadu_ps(a.as_ptr().add(i+8));
            let vb1 = _mm256_loadu_ps(b.as_ptr().add(i+8));
            sum_v = _mm256_fmadd_ps(va1, vb1, sum_v);
            i += 16;
        }
        
        let sum128 = _mm_add_ps(_mm256_castps256_ps128(sum_v), _mm256_extractf128_ps(sum_v, 1));
        let mut arr = [0.0; 4];
        _mm_storeu_ps(arr.as_mut_ptr(), sum128);
        let mut sum: f32 = arr.iter().sum();
        
        while i < len {
            sum += *a.get_unchecked(i) * *b.get_unchecked(i);
            i += 1;
        }
        sum
    }
    #[cfg(not(target_arch = "x86_64"))]
    { a.iter().zip(b).map(|(x,y)| x*y).sum() }
}

// --- KERNEL: Integer AVX2 ---
#[inline(always)]
fn dot_product_i8_u8_avx2(
    query_i8: &[i8], 
    vec_u8: &[u8], 
    alpha_scale: f32, 
    bias: f32
) -> f32 {
    let len = query_i8.len();
    let mut dot_int: i32 = 0;

    #[cfg(target_arch = "x86_64")]
    unsafe {
        let mut sum_v = _mm256_setzero_si256();
        let one_v = _mm256_set1_epi16(1);
        let mut i = 0;

        while i + 64 <= len {
            let v_idx0 = _mm256_loadu_si256(vec_u8.as_ptr().add(i) as *const _);
            let v_qry0 = _mm256_loadu_si256(query_i8.as_ptr().add(i) as *const _);
            let v_pairs0 = _mm256_maddubs_epi16(v_idx0, v_qry0);
            let v_i32_0 = _mm256_madd_epi16(v_pairs0, one_v);
            sum_v = _mm256_add_epi32(sum_v, v_i32_0);

            let v_idx1 = _mm256_loadu_si256(vec_u8.as_ptr().add(i+32) as *const _);
            let v_qry1 = _mm256_loadu_si256(query_i8.as_ptr().add(i+32) as *const _);
            let v_pairs1 = _mm256_maddubs_epi16(v_idx1, v_qry1);
            let v_i32_1 = _mm256_madd_epi16(v_pairs1, one_v);
            sum_v = _mm256_add_epi32(sum_v, v_i32_1);

            i += 64;
        }
        
        if i + 32 <= len {
            let v_idx = _mm256_loadu_si256(vec_u8.as_ptr().add(i) as *const _);
            let v_qry = _mm256_loadu_si256(query_i8.as_ptr().add(i) as *const _);
            let v_pairs = _mm256_maddubs_epi16(v_idx, v_qry);
            let v_i32 = _mm256_madd_epi16(v_pairs, one_v);
            sum_v = _mm256_add_epi32(sum_v, v_i32);
            i += 32;
        }

        let sum128 = _mm_add_epi32(_mm256_castsi256_si128(sum_v), _mm256_extracti128_si256(sum_v, 1));
        let sum64 = _mm_add_epi32(sum128, _mm_shuffle_epi32(sum128, 0x4E));
        let sum32 = _mm_add_epi32(sum64, _mm_shuffle_epi32(sum64, 0xB1));
        dot_int = _mm_cvtsi128_si32(sum32);

        let mut scalar_sum = 0;
        while i < len {
            scalar_sum += (*vec_u8.get_unchecked(i) as i32) * (*query_i8.get_unchecked(i) as i32);
            i += 1;
        }
        dot_int += scalar_sum;
    }

    (dot_int as f32 * alpha_scale) + bias
}

#[derive(Debug)]
enum StorageError { Lmdb(LmdbError), Io(std::io::Error), Py(PyErr) }
impl From<LmdbError> for StorageError { fn from(err: LmdbError) -> Self { StorageError::Lmdb(err) } }
impl From<std::io::Error> for StorageError { fn from(err: std::io::Error) -> Self { StorageError::Io(err) } }
impl From<PyErr> for StorageError { fn from(err: PyErr) -> Self { StorageError::Py(err) } }
impl From<StorageError> for PyErr {
    fn from(err: StorageError) -> PyErr {
        match err {
            StorageError::Lmdb(e) => pyo3::exceptions::PyIOError::new_err(format!("LMDB: {}", e)),
            StorageError::Io(e) => pyo3::exceptions::PyIOError::new_err(format!("IO: {}", e)),
            StorageError::Py(e) => e,
        }
    }
}

#[derive(Debug)]
enum FilterNode { Exact(String), Range(String, String), And(Vec<FilterNode>), Or(Vec<FilterNode>) }
impl FilterNode {
    fn from_py(obj: &PyAny) -> PyResult<Self> {
        let tuple = obj.downcast::<PyTuple>()?;
        let op_code: u8 = tuple.get_item(0)?.extract()?;
        match op_code {
            0 => Ok(FilterNode::Exact(tuple.get_item(1)?.extract()?)),
            1 => Ok(FilterNode::Range(tuple.get_item(1)?.extract()?, tuple.get_item(2)?.extract()?)),
            2 | 3 => {
                let list: &PyList = tuple.get_item(1)?.downcast()?;
                let nodes = list.iter().map(FilterNode::from_py).collect::<PyResult<Vec<_>>>()?;
                if op_code == 2 { Ok(FilterNode::And(nodes)) } else { Ok(FilterNode::Or(nodes)) }
            },
            _ => Err(pyo3::exceptions::PyValueError::new_err("Invalid OpCode")),
        }
    }
}

#[pyclass(module = "blitz_vec")]
struct BlitzIterator { ids: HashSet<i64>, count: usize }
#[pymethods]
impl BlitzIterator {
    fn __len__(&self) -> usize { self.count }
    fn to_list(&self) -> Vec<i64> { self.ids.iter().cloned().collect() }
}

struct MemTable {
    ids: Vec<i64>,
    vectors: Vec<f32>,
    dim: usize,
}

impl MemTable {
    fn new(dim: usize) -> Self {
        MemTable { 
            ids: Vec::with_capacity(SEGMENT_SIZE), 
            vectors: Vec::with_capacity(SEGMENT_SIZE * dim), 
            dim 
        }
    }
    fn insert(&mut self, id: i64, vec: &[f32]) {
        if self.dim == 0 && !vec.is_empty() {
            self.dim = vec.len();
        }
        self.ids.push(id);
        self.vectors.extend_from_slice(vec);
    }
    fn len(&self) -> usize { self.ids.len() }
    
    fn search_scan(&self, query: &[f32], filter: &Option<&HashSet<i64>>, deleted: &HashSet<i64>, candidates: &mut Vec<ScoredId>) {
        if self.dim == 0 || self.dim != query.len() { return; }
        let count = self.ids.len();
        
        let has_filter = filter.is_some();
        let has_deletes = !deleted.is_empty();

        if !has_filter && !has_deletes {
            // FAST PATH
            for i in 0..count {
                let id = unsafe { *self.ids.get_unchecked(i) };
                let start = i * self.dim;
                let vec = unsafe { self.vectors.get_unchecked(start..start+self.dim) };
                let score = dot_product_f32(query, vec);
                candidates.push(ScoredId { score, id });
            }
            return;
        }

        for i in 0..count {
            let id = unsafe { *self.ids.get_unchecked(i) };
            if has_deletes && deleted.contains(&id) { continue; }
            if has_filter { if !filter.as_ref().unwrap().contains(&id) { continue; } }
            
            let start = i * self.dim;
            let vec = unsafe { self.vectors.get_unchecked(start..start+self.dim) };
            let score = dot_product_f32(query, vec);
            candidates.push(ScoredId { score, id });
        }
    }
}

#[derive(Clone)]
struct CompressedList {
    ids: Vec<i64>,
    data: Vec<u8>,
}

impl CompressedList {
    fn new() -> Self {
        CompressedList { ids: Vec::new(), data: Vec::new() }
    }
    fn push_quantized(&mut self, id: i64, vec_f32: &[f32]) {
        self.ids.push(id);
        self.data.reserve(vec_f32.len());
        for &x in vec_f32 {
            let scaled = (x - QUANT_MIN) * QUANT_SCALE;
            self.data.push(scaled.clamp(0.0, 255.0) as u8);
        }
    }
}
unsafe impl Sync for CompressedList {}
unsafe impl Send for CompressedList {}

struct IvfIndex {
    centroids: Vec<f32>,
    lists: Vec<CompressedList>,
    dim: usize,
    count: usize,
}

impl IvfIndex {
    fn new(dim: usize) -> Self {
        IvfIndex { centroids: Vec::new(), lists: Vec::new(), dim, count: 0 }
    }
    
    fn train_and_build(dim: usize, data: &[(i64, Vec<f32>)]) -> Self {
        let count = data.len();
        if count == 0 || dim == 0 { return IvfIndex::new(dim); }
        let k = ((count as f32).sqrt() * 1.0).clamp(2.0, 1024.0) as usize; 
        let mut centroids = Vec::with_capacity(k * dim);
        let step = (count / k).max(1);
        for i in 0..k {
            let idx = (i * step) % count;
            centroids.extend_from_slice(&data[idx].1);
        }
        for _ in 0..5 {
            let mut new_centroids = vec![0.0f32; k * dim];
            let mut counts = vec![0usize; k];
            for (_, vec) in data {
                let mut best_sim = f32::NEG_INFINITY;
                let mut best_c = 0;
                for (c_idx, c_vec) in centroids.chunks_exact(dim).enumerate() {
                    let sim = dot_product_f32(vec, c_vec);
                    if sim > best_sim { best_sim = sim; best_c = c_idx; }
                }
                let dest = &mut new_centroids[best_c*dim..(best_c+1)*dim];
                for (i, x) in vec.iter().enumerate() { dest[i] += x; }
                counts[best_c] += 1;
            }
            for c in 0..k {
                let count = counts[c].max(1) as f32;
                let slice = &mut new_centroids[c*dim..(c+1)*dim];
                let mut norm = 0.0;
                for x in slice.iter_mut() { *x /= count; norm += x.powi(2); }
                let norm = norm.sqrt().max(1e-6);
                for x in slice.iter_mut() { *x /= norm; }
            }
            centroids = new_centroids;
        }
        let mut lists = vec![CompressedList::new(); k];
        for (id, vec) in data {
            let mut best_sim = f32::NEG_INFINITY;
            let mut best_c = 0;
            for (c_idx, c_vec) in centroids.chunks_exact(dim).enumerate() {
                let sim = dot_product_f32(vec, c_vec);
                if sim > best_sim { best_sim = sim; best_c = c_idx; }
            }
            lists[best_c].push_quantized(*id, vec);
        }
        IvfIndex { centroids, lists, dim, count }
    }

    fn merge_new_data(&self, new_data: &[(i64, Vec<f32>)], deleted_ids: &HashSet<i64>) -> Self {
        let mut new_lists = self.lists.clone();
        if !deleted_ids.is_empty() {
            for list in &mut new_lists {
                let mut i = 0;
                while i < list.ids.len() {
                    if deleted_ids.contains(&list.ids[i]) {
                        list.ids.swap_remove(i);
                        let last_idx = list.ids.len();
                        let start = i * self.dim;
                        let end_src = last_idx * self.dim;
                        for j in 0..self.dim { list.data[start + j] = list.data[end_src + j]; }
                        list.data.truncate(end_src);
                    } else { i += 1; }
                }
            }
        }
        let mut added_count = 0;
        let retained_count: usize = new_lists.iter().map(|l| l.ids.len()).sum();
        for (id, vec) in new_data {
            if deleted_ids.contains(id) { continue; }
            let mut best_sim = f32::NEG_INFINITY;
            let mut best_c = 0;
            for (c_idx, c_vec) in self.centroids.chunks_exact(self.dim).enumerate() {
                let sim = dot_product_f32(vec, c_vec);
                if sim > best_sim { best_sim = sim; best_c = c_idx; }
            }
            new_lists[best_c].push_quantized(*id, vec);
            added_count += 1;
        }
        IvfIndex { centroids: self.centroids.clone(), lists: new_lists, dim: self.dim, count: retained_count + added_count }
    }
    
    // --- OPTIMIZATION: Specialized Loops + Prefetching ---
    fn search_scan(
        &self, 
        query: &[f32], 
        filter: &Option<&HashSet<i64>>, 
        deleted: &HashSet<i64>, 
        candidates: &mut Vec<ScoredId>
    ) {
        if self.count == 0 || self.dim != query.len() { return; }
        
        // Quantize Query
        let q_scale_factor = 63.0 / 2.0;
        let mut query_i8 = Vec::with_capacity(self.dim);
        for &x in query {
            let val = (x * q_scale_factor).clamp(-63.0, 63.0) as i8;
            query_i8.push(val);
        }
        let alpha_scale = QUANT_INV_SCALE / q_scale_factor;
        let q_sum: f32 = query.iter().sum();
        let bias = q_sum * QUANT_MIN;

        // Centroid Selection
        let num_centroids = self.lists.len();
        let mut probes: Vec<(f32, usize)> = Vec::with_capacity(num_centroids);
        for (i, c) in self.centroids.chunks_exact(self.dim).enumerate() {
            probes.push((dot_product_f32(query, c), i));
        }
        
        let n_probes = (num_centroids as f32).sqrt().ceil() as usize;
        let n_probes = n_probes.clamp(1, num_centroids);
        
        if n_probes < num_centroids {
            probes.select_nth_unstable_by(n_probes, |a, b| b.0.partial_cmp(&a.0).unwrap_or(CmpOrdering::Equal));
        }
        let top_probes = &probes[0..n_probes];

        // Reserve space to prevent reallocation during scan
        // Estimate: 50 items per cluster * n_probes
        let est_capacity = 50 * n_probes;
        if candidates.capacity() < candidates.len() + est_capacity {
            candidates.reserve(est_capacity);
        }

        let has_filter = filter.is_some();
        let has_deletes = !deleted.is_empty();

        // --- DISPATCH TO SPECIALIZED LOOPS ---
        // This removes the "if deleted" check from the hot loop in the common case
        
        for (_, c_idx) in top_probes {
            let list = &self.lists[*c_idx];
            let count = list.ids.len();
            if count == 0 { continue; }
            
            #[cfg(target_arch = "x86_64")]
            unsafe { _mm_prefetch(list.data.as_ptr() as *const i8, _MM_HINT_T0); }

            if !has_filter && !has_deletes {
                // HOT PATH: No Filter, No Deletes
                for i in 0..count {
                    let id = unsafe { *list.ids.get_unchecked(i) };
                    let start = i * self.dim;
                    #[cfg(target_arch = "x86_64")]
                    unsafe { if i + 1 < count { _mm_prefetch(list.data.as_ptr().add((i+1)*self.dim) as *const i8, _MM_HINT_T0); } }

                    let vec_u8 = unsafe { list.data.get_unchecked(start..start+self.dim) };
                    let score = dot_product_i8_u8_avx2(&query_i8, vec_u8, alpha_scale, bias);
                    candidates.push(ScoredId { score, id });
                }
            } else if has_deletes && !has_filter {
                // PATH: Deletes only
                for i in 0..count {
                    let id = unsafe { *list.ids.get_unchecked(i) };
                    if deleted.contains(&id) { continue; }

                    let start = i * self.dim;
                    #[cfg(target_arch = "x86_64")]
                    unsafe { if i + 1 < count { _mm_prefetch(list.data.as_ptr().add((i+1)*self.dim) as *const i8, _MM_HINT_T0); } }

                    let vec_u8 = unsafe { list.data.get_unchecked(start..start+self.dim) };
                    let score = dot_product_i8_u8_avx2(&query_i8, vec_u8, alpha_scale, bias);
                    candidates.push(ScoredId { score, id });
                }
            } else if has_filter {
                // PATH: Filter (+/- Deletes)
                let f_set = filter.as_ref().unwrap();
                for i in 0..count {
                    let id = unsafe { *list.ids.get_unchecked(i) };
                    if has_deletes && deleted.contains(&id) { continue; }
                    if !f_set.contains(&id) { continue; }
                    
                    let start = i * self.dim;
                    #[cfg(target_arch = "x86_64")]
                    unsafe { if i + 1 < count { _mm_prefetch(list.data.as_ptr().add((i+1)*self.dim) as *const i8, _MM_HINT_T0); } }

                    let vec_u8 = unsafe { list.data.get_unchecked(start..start+self.dim) };
                    let score = dot_product_i8_u8_avx2(&query_i8, vec_u8, alpha_scale, bias);
                    candidates.push(ScoredId { score, id });
                }
            }
        }
    }
}

// Crucial: Use Arc for HashSet to avoid cloning
struct ShardCore {
    memtable: RwLock<MemTable>,
    frozen_segments: RwLock<Vec<Arc<MemTable>>>,
    ivf_index: RwLock<Arc<IvfIndex>>,
    deleted_ids: RwLock<Arc<HashSet<i64>>>, // Changed from HashSet to Arc<HashSet>
    compaction_tx: Sender<bool>,
    dim: AtomicUsize,
}

impl ShardCore {
    fn new(dim: usize, tx: Sender<bool>) -> Self {
        ShardCore {
            memtable: RwLock::new(MemTable::new(dim)),
            frozen_segments: RwLock::new(Vec::new()),
            ivf_index: RwLock::new(Arc::new(IvfIndex::new(dim))),
            deleted_ids: RwLock::new(Arc::new(HashSet::new())),
            compaction_tx: tx,
            dim: AtomicUsize::new(dim),
        }
    }
    
    fn update_dim(&self, dim: usize) {
        if dim > 0 {
            let _ = self.dim.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |x| if x == 0 { Some(dim) } else { None });
        }
    }
    
    fn insert_batch(&self, ids: &[i64], vectors: &[f32], dim: usize) {
        self.update_dim(dim);
        let mut mt = self.memtable.write();
        let count = ids.len();
        for i in 0..count {
            let start = i * dim;
            mt.insert(ids[i], &vectors[start..start+dim]);
            if mt.len() >= SEGMENT_SIZE {
                let old_mt = std::mem::replace(&mut *mt, MemTable::new(dim));
                self.frozen_segments.write().push(Arc::new(old_mt));
                let _ = self.compaction_tx.send(true);
            }
        }
    }
    
    fn search(&self, query: &[f32], filter: &Option<&HashSet<i64>>, k: usize) -> Vec<(f32, i64)> {
        let dim = self.dim.load(Ordering::Relaxed);
        if dim == 0 || query.len() != dim { return Vec::new(); }

        let mut candidates = Vec::with_capacity(4096);
        
        // Arc Clone is cheap (atomic increment)
        let deleted_arc = self.deleted_ids.read().clone();
        let ivf_arc = self.ivf_index.read().clone();

        {
             let mt = self.memtable.read();
             mt.search_scan(query, filter, &deleted_arc, &mut candidates);
        }

        let frozen_snapshot = self.frozen_segments.read().clone();
        for seg in frozen_snapshot.iter() {
            seg.search_scan(query, filter, &deleted_arc, &mut candidates);
        }

        ivf_arc.search_scan(query, filter, &deleted_arc, &mut candidates);
        
        if candidates.is_empty() { return Vec::new(); }
        
        if candidates.len() > k {
            candidates.select_nth_unstable_by(k, |a, b| b.score.partial_cmp(&a.score).unwrap_or(CmpOrdering::Equal));
            candidates.truncate(k);
        }
        
        candidates.into_iter().map(|s| (s.score, s.id)).collect()
    }
    
    fn compact(&self) {
        let frozen_snapshot = {
            let mut lock = self.frozen_segments.write();
            if lock.is_empty() { return; }
            std::mem::take(&mut *lock)
        };
        let dim = self.dim.load(Ordering::Relaxed);
        let mut new_data = Vec::new();
        for seg in frozen_snapshot {
            for (i, &id) in seg.ids.iter().enumerate() {
                let start = i * seg.dim;
                let vec = seg.vectors[start..start+seg.dim].to_vec();
                new_data.push((id, vec));
            }
        }
        let new_ivf = {
            let current_ivf = self.ivf_index.read().clone();
            // We need actual HashSet for logic
            let deletions_arc = self.deleted_ids.read().clone();
            let deletions = &*deletions_arc; 
            
            let total_existing = current_ivf.count;
            let total_new = new_data.len();
            if total_existing < 4096 || total_new > (total_existing / 2) {
                 let mut all_data = new_data;
                 for list in &current_ivf.lists {
                     let count = list.ids.len();
                     for i in 0..count {
                         let id = list.ids[i];
                         if !deletions.contains(&id) {
                             let start = i * dim;
                             let slice_u8 = &list.data[start..start+dim];
                             let mut vec = Vec::with_capacity(dim);
                             for &b in slice_u8 {
                                 let val = (b as f32 * QUANT_INV_SCALE) + QUANT_MIN;
                                 vec.push(val);
                             }
                             all_data.push((id, vec));
                         }
                     }
                 }
                 IvfIndex::train_and_build(dim, &all_data)
            } else {
                 current_ivf.merge_new_data(&new_data, &deletions)
            }
        };
        
        *self.ivf_index.write() = Arc::new(new_ivf);
        
        // Clear deleted ids via Copy-On-Write
        let mut lock = self.deleted_ids.write();
        *lock = Arc::new(HashSet::new());
    }
}

// ... BlitzVec implementation ...

#[pyclass(module = "blitz_vec")]
struct BlitzVec {
    shards: Vec<Arc<ShardCore>>,
    lmdb_env: Vec<Arc<Environment>>,
    lmdb_dbs: Vec<Database>,
    num_shards: usize,
    running: Arc<AtomicBool>,
    _compaction_threads: Vec<thread::JoinHandle<()>>,
}

impl BlitzVec {
    #[inline]
    fn shard_for_id(id: i64, num_shards: usize) -> usize {
        (id.unsigned_abs() as usize) % num_shards
    }
    
    fn make_key(page_id: u32) -> Vec<u8> {
        let mut k = Vec::with_capacity(5);
        k.push(b'p'); 
        k.extend_from_slice(&page_id.to_be_bytes()); 
        k
    }
    
    fn load_disk(&self) {
        self.lmdb_env.par_iter().zip(&self.lmdb_dbs).zip(&self.shards)
            .for_each(|((env, db), shard)| {
                let txn = env.begin_ro_txn().expect("RO");
                let cursor = txn.open_ro_cursor(*db).expect("Cur");
                let mut dim = shard.dim.load(Ordering::Relaxed);
                
                if dim == 0 {
                    if let Ok(bytes) = txn.get(*db, &b"__sys_dim__".to_vec()) {
                        if bytes.len() == 4 {
                            dim = u32::from_le_bytes(bytes.try_into().unwrap()) as usize;
                            shard.update_dim(dim);
                        }
                    }
                }
                
                if dim == 0 { return; }
                
                let mut loaded_data = Vec::new();
                let row_size = 8 + dim * 4;
                
                if let Ok((Some(k), v)) = cursor.get(Some(b"p"), None, MDB_SET_RANGE) {
                    let mut curr_k = k;
                    let mut curr_v = v;
                    loop {
                        if !curr_k.starts_with(b"p") { break; }
                        let mut pos = 0;
                        while pos + row_size <= curr_v.len() {
                            let id = LittleEndian::read_i64(&curr_v[pos..pos+8]);
                            if id != DELETED_MARKER {
                                let ptr = curr_v[pos+8..].as_ptr() as *const f32;
                                let slc = unsafe { std::slice::from_raw_parts(ptr, dim) };
                                loaded_data.push((id, slc.to_vec()));
                            }
                            pos += row_size;
                        }
                        match cursor.get(None, None, MDB_NEXT) {
                            Ok((Some(nk), nv)) => { curr_k = nk; curr_v = nv; }
                            _ => break
                        }
                    }
                }
                
                if !loaded_data.is_empty() {
                    let idx = IvfIndex::train_and_build(dim, &loaded_data);
                    *shard.ivf_index.write() = Arc::new(idx);
                }
            });
    }
    // ... eval_node ...
    fn eval_node(&self, node: &FilterNode) -> HashSet<i64> {
        match node {
            FilterNode::Exact(key) => {
                let digest = md5::compute(key.as_bytes());
                let hash_int = u128::from_be_bytes(digest.0);
                let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
                
                let env = &self.lmdb_env[shard_idx];
                let db = self.lmdb_dbs[shard_idx];
                let txn = env.begin_ro_txn().expect("RO txn");
                let cursor = txn.open_ro_cursor(db).expect("Cursor");
                
                let mut ids = HashSet::new();
                let key_bytes = key.as_bytes();
                
                if let Ok((Some(mut k), _)) = cursor.get(Some(key_bytes), None, MDB_SET_RANGE) {
                    loop {
                        if k.len() < 8 || !k.starts_with(key_bytes) || k.get(key.len()) != Some(&b'|') { break; }
                        ids.insert(LittleEndian::read_i64(&k[k.len()-8..]));
                        if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { k = next_k; } else { break; }
                    }
                }
                ids
            },
            FilterNode::Range(start, end) => {
                let sep_idx = start.find(':').map(|i| i + 1).unwrap_or(0);
                let field_prefix = &start[0..sep_idx];
                let start_bytes = start.as_bytes();
                let end_bytes = end.as_bytes();
                
                let shard_results: Vec<HashSet<i64>> = (0..self.num_shards)
                    .into_par_iter()
                    .map(|shard_idx| {
                        let mut found = HashSet::new();
                        let env = &self.lmdb_env[shard_idx];
                        let db = self.lmdb_dbs[shard_idx];
                        let txn = env.begin_ro_txn().expect("RO txn");
                        let cursor = txn.open_ro_cursor(db).expect("Cursor");
                        
                        if let Ok((Some(mut k), _)) = cursor.get(Some(start_bytes), None, MDB_SET_RANGE) {
                            loop {
                                if k >= end_bytes || !k.starts_with(field_prefix.as_bytes()) { break; }
                                if k.len() > 8 { found.insert(LittleEndian::read_i64(&k[k.len()-8..])); }
                                if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { k = next_k; } else { break; }
                            }
                        }
                        found
                    })
                    .collect();
                shard_results.into_iter().flatten().collect()
            },
            FilterNode::And(nodes) => {
                if nodes.is_empty() { return HashSet::new(); }
                let results: Vec<HashSet<i64>> = nodes.par_iter().map(|n| self.eval_node(n)).collect();
                let mut sorted_results: Vec<&HashSet<i64>> = results.iter().collect();
                sorted_results.sort_by(|a, b| a.len().cmp(&b.len()));
                let mut base_set = sorted_results[0].clone();
                for other_set in &sorted_results[1..] {
                    base_set.retain(|id| other_set.contains(id));
                    if base_set.is_empty() { break; }
                }
                base_set
            },
            FilterNode::Or(nodes) => {
                let results: Vec<HashSet<i64>> = nodes.par_iter().map(|n| self.eval_node(n)).collect();
                let mut base_set = HashSet::new();
                for s in results { base_set.extend(s); }
                base_set
            }
        }
    }
}

#[pymethods]
impl BlitzVec {
    #[new]
    #[pyo3(signature = (base_path, num_shards=5, map_size=200_000_000_000, dim=0))]
    fn new(base_path: String, num_shards: usize, map_size: usize, dim: usize) -> PyResult<Self> {
        let mut shards = Vec::with_capacity(num_shards);
        let mut envs = Vec::with_capacity(num_shards);
        let mut dbs = Vec::with_capacity(num_shards);
        let mut threads = Vec::with_capacity(num_shards);
        let running = Arc::new(AtomicBool::new(true));
        
        for i in 0..num_shards {
            let path_str = format!("{}/shard_{}", base_path, i);
            fs::create_dir_all(&path_str)?;
            let env = Environment::new()
                .set_map_size(map_size)
                .set_max_dbs(1)
                .set_max_readers(4096)
                .set_flags(MDB_MAPASYNC | MDB_NOTLS)
                .open(Path::new(&path_str)).map_err(StorageError::Lmdb)?;
            let db = env.open_db(None).map_err(StorageError::Lmdb)?;
            
            let (tx, rx) = unbounded::<bool>();
            let shard = Arc::new(ShardCore::new(dim, tx));
            
            let shard_clone = shard.clone();
            let running_clone = running.clone();
            let handle = thread::spawn(move || {
                while running_clone.load(Ordering::Relaxed) {
                    if let Ok(_) = rx.recv_timeout(std::time::Duration::from_millis(300)) {
                        shard_clone.compact();
                    }
                }
            });
            
            shards.push(shard);
            envs.push(Arc::new(env));
            dbs.push(db);
            threads.push(handle);
        }
        
        let instance = BlitzVec {
            shards,
            lmdb_env: envs,
            lmdb_dbs: dbs,
            num_shards,
            running,
            _compaction_threads: threads
        };
        
        instance.load_disk();
        Ok(instance)
    }
    
    fn close(&self) -> PyResult<()> {
        self.running.store(false, Ordering::Relaxed);
        Ok(())
    }
    
    fn get_ids_from_filter(&self, py: Python<'_>, filter_tree: PyObject) -> PyResult<Option<BlitzIterator>> {
        let node = FilterNode::from_py(filter_tree.as_ref(py))?;
        let ids = py.allow_threads(|| self.eval_node(&node));
        Ok(Some(BlitzIterator { count: ids.len(), ids }))
    }
    
    #[pyo3(signature = (query_vector, filter_obj=None, k=10))]
    fn search_flat<'py>(&self, py: Python<'py>, query_vector: PyReadonlyArray1<'py, f32>, filter_obj: Option<&BlitzIterator>, k: usize) -> PyResult<Vec<(f32, i64)>> {
        let query_slice = query_vector.as_slice()?;
        let filter_set = filter_obj.map(|iter| &iter.ids);
        
        let results: Vec<Vec<(f32, i64)>> = py.allow_threads(|| {
            self.shards.par_iter()
                .map(|shard| {
                    shard.search(query_slice, &filter_set, k)
                })
                .collect()
        });
        
        let mut merged_results = Vec::new();
        for res in results { merged_results.extend(res); }

        if merged_results.len() > k {
            merged_results.select_nth_unstable_by(k, |a, b| b.0.partial_cmp(&a.0).unwrap_or(CmpOrdering::Equal));
            merged_results.truncate(k);
        }
        merged_results.sort_unstable_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(CmpOrdering::Equal));
        
        Ok(merged_results)
    }

    fn store_flat_vectors<'py>(&self, py: Python<'py>, data: PyReadonlyArray2<'py, f32>, identifiers: Vec<i64>) -> PyResult<()> {
        let vectors = data.as_array();
        let dim = vectors.shape()[1];
        let row_size = 8 + dim * 4;

        let mut buckets: Vec<Vec<Vec<u8>>> = (0..self.num_shards).map(|_| Vec::with_capacity(identifiers.len() / self.num_shards)).collect();
        let mut ram_buckets: Vec<Vec<(i64, usize)>> = (0..self.num_shards).map(|_| Vec::with_capacity(identifiers.len() / self.num_shards)).collect();

        for (i, &id) in identifiers.iter().enumerate() {
            let s_idx = BlitzVec::shard_for_id(id, self.num_shards);
            let mut row = Vec::with_capacity(row_size);
            row.extend_from_slice(&id.to_le_bytes());
            let vec_slice = vectors.row(i);
            let slice_u8 = unsafe { std::slice::from_raw_parts(vec_slice.as_ptr() as *const u8, dim * 4) };
            row.extend_from_slice(slice_u8);
            buckets[s_idx].push(row);
            ram_buckets[s_idx].push((id, i));
        }

        let results: Vec<Result<(), StorageError>> = py.allow_threads(|| {
            buckets.into_par_iter().zip(ram_buckets).enumerate()
                .map(|(shard_idx, (lmdb_rows, ram_rows))| {
                    if lmdb_rows.is_empty() { return Ok(()); }
                    let shard_core = &self.shards[shard_idx];
                    
                    {
                        let mut batch_vectors = Vec::with_capacity(ram_rows.len() * dim);
                        let mut batch_ids = Vec::with_capacity(ram_rows.len());
                        for (id, row_i) in ram_rows {
                            batch_ids.push(id);
                            let vec_slice = vectors.row(row_i);
                            if let Some(slc) = vec_slice.as_slice() { batch_vectors.extend_from_slice(slc); } 
                            else { for x in vec_slice { batch_vectors.push(*x); } }
                        }
                        shard_core.insert_batch(&batch_ids, &batch_vectors, dim);
                    }

                    let env = &self.lmdb_env[shard_idx];
                    let db = self.lmdb_dbs[shard_idx];
                    let mut txn = env.begin_rw_txn()?;
                    let _ = txn.put(db, &b"__sys_dim__".to_vec(), &(dim as u32).to_le_bytes(), WriteFlags::empty());
                    let mut page_count = 0u32;
                    let mut buffer = Vec::new();
                    {
                         #[allow(unused_mut)]
                         let mut cursor = txn.open_ro_cursor(db)?;
                         if let Ok((Some(k), v)) = cursor.get(None, None, MDB_LAST) {
                             if k.starts_with(b"p") && k.len() == 5 {
                                 page_count = BigEndian::read_u32(&k[1..5]);
                                 if v.len() < VECTORS_PER_PAGE * row_size { buffer = v.to_vec(); } 
                                 else { page_count += 1; }
                             }
                         }
                    }
                    for row in lmdb_rows {
                        if buffer.len() + row.len() > VECTORS_PER_PAGE * row_size {
                            let key = BlitzVec::make_key(page_count);
                            txn.put(db, &key, &buffer, WriteFlags::empty())?;
                            buffer.clear();
                            page_count += 1;
                        }
                        buffer.extend_from_slice(&row);
                    }
                    if !buffer.is_empty() {
                         let key = BlitzVec::make_key(page_count);
                         txn.put(db, &key, &buffer, WriteFlags::empty())?;
                    }
                    txn.commit()?;
                    Ok(())
                })
                .collect()
        });

        for res in results { if let Err(e) = res { return Err(e.into()); } }
        Ok(())
    }

    fn delete_flat_vectors<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<()> {
        let mut buckets: Vec<Vec<i64>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for &id in &identifiers { buckets[BlitzVec::shard_for_id(id, self.num_shards)].push(id); }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(s_idx, ids)| {
                if ids.is_empty() { return; }
                let shard = &self.shards[s_idx];
                let mut guard = shard.deleted_ids.write();
                // Copy-On-Write logic for deletions to support lock-free reads
                // We create a new HashSet, insert, and swap the Arc
                let mut new_set = (**guard).clone();
                for id in ids { new_set.insert(id); }
                *guard = Arc::new(new_set);
            });
        });
        Ok(())
    }
    
    // ... rest of the implementation (index inserts, deletes, get_data) ...
    // These remain largely the same, they just need to close the impl block.
    // Included for completeness/compilation.
    
    fn batch_index_insert(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        let mut buckets: Vec<Vec<(Vec<u8>, Vec<u8>)>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push((key, Vec::new()));
        }
        let results: Vec<Result<(), StorageError>> = py.allow_threads(|| {
            buckets.into_par_iter().enumerate().map(|(shard_idx, mut batch)| {
                if batch.is_empty() { return Ok(()); }
                batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));
                let env = &self.lmdb_env[shard_idx];
                let mut txn = env.begin_rw_txn()?;
                let db = self.lmdb_dbs[shard_idx];
                for (k, v) in batch { txn.put(db, &k, &v, WriteFlags::empty())?; }
                txn.commit()?;
                Ok(())
            }).collect()
        });
        for res in results { if let Err(e) = res { return Err(e.into()); } }
        Ok(())
    }

    fn batch_index_delete(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        let mut buckets: Vec<Vec<Vec<u8>>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push(key);
        }
        let results: Vec<Result<(), StorageError>> = py.allow_threads(|| {
            buckets.into_par_iter().enumerate().map(|(shard_idx, mut keys)| {
                if keys.is_empty() { return Ok(()); }
                keys.sort_unstable();
                let env = &self.lmdb_env[shard_idx];
                let mut txn = env.begin_rw_txn()?;
                let db = self.lmdb_dbs[shard_idx];
                for k in keys { let _ = txn.del(db, &k, None); }
                txn.commit()?;
                Ok(())
            }).collect()
        });
        for res in results { if let Err(e) = res { return Err(e.into()); } }
        Ok(())
    }

    fn store_data<'py>(&self, py: Python<'py>, data: Vec<PyObject>, identifiers: Vec<i64>) -> PyResult<()> {
        if data.is_empty() { return Ok(()); }
        let pickle = PyModule::import(py, "pickle")?;
        let dumps = pickle.getattr("dumps")?;
        let mut buckets: Vec<Vec<([u8; 8], Vec<u8>)>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() {
            let shard_idx = BlitzVec::shard_for_id(id, self.num_shards);
            let bytes_obj = dumps.call1((&data[i],))?;
            let val_bytes = bytes_obj.extract::<&PyBytes>()?.as_bytes().to_vec();
            buckets[shard_idx].push((id.to_le_bytes(), val_bytes));
        }
        let results: Vec<Result<(), StorageError>> = py.allow_threads(|| {
            buckets.into_par_iter().enumerate().map(|(shard_idx, mut batch)| {
                if batch.is_empty() { return Ok(()); }
                batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));
                let env = &self.lmdb_env[shard_idx];
                let mut txn = env.begin_rw_txn()?;
                let db = self.lmdb_dbs[shard_idx];
                for (k, v) in batch { txn.put(db, &k, &v, WriteFlags::empty())?; }
                txn.commit()?;
                Ok(())
            }).collect()
        });
        for res in results { if let Err(e) = res { return Err(e.into()); } }
        Ok(())
    }

    fn get_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<&'py PyList> {
        let mut buckets: Vec<Vec<(usize, [u8; 8])>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() {
            buckets[BlitzVec::shard_for_id(id, self.num_shards)].push((i, id.to_le_bytes()));
        }
        let mut results: Vec<Option<Vec<u8>>> = vec![None; identifiers.len()];
        let ptr_int = results.as_mut_ptr() as usize;
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, reqs)| {
                if reqs.is_empty() { return; }
                let env = &self.lmdb_env[shard_idx];
                let db = self.lmdb_dbs[shard_idx];
                if let Ok(txn) = env.begin_ro_txn() {
                    let ptr = ptr_int as *mut Option<Vec<u8>>;
                    for (orig_idx, key_bytes) in reqs {
                        if let Ok(bytes) = txn.get(db, &key_bytes) {
                            unsafe { std::ptr::write(ptr.add(orig_idx), Some(bytes.to_vec())); }
                        }
                    }
                }
            });
        });
        let pickle = PyModule::import(py, "pickle")?;
        let loads = pickle.getattr("loads")?;
        let py_list = PyList::empty(py);
        for opt in results {
            let obj = if let Some(bytes) = opt { loads.call1((PyBytes::new(py, &bytes),))? } else { PyNone::get(py).into() };
            py_list.append(obj)?;
        }
        Ok(py_list)
    }

    fn delete_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<()> {
        let mut buckets: Vec<Vec<[u8; 8]>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() { buckets[BlitzVec::shard_for_id(id, self.num_shards)].push(id.to_le_bytes()); }
        let results: Vec<Result<(), StorageError>> = py.allow_threads(|| {
            buckets.into_par_iter().enumerate().map(|(shard_idx, mut keys)| {
                if keys.is_empty() { return Ok(()); }
                keys.sort_unstable();
                let env = &self.lmdb_env[shard_idx];
                let mut txn = env.begin_rw_txn()?;
                let db = self.lmdb_dbs[shard_idx];
                for k in keys { let _ = txn.del(db, &k, None); }
                txn.commit()?;
                Ok(())
            }).collect()
        });
        for res in results { if let Err(e) = res { return Err(e.into()); } }
        Ok(())
    }

    fn get_data_count(&self) -> PyResult<usize> {
        let total: usize = self.shards.par_iter().map(|s| {
            let mt = s.memtable.read().len();
            let ivf = s.ivf_index.read().count;
            mt + ivf
        }).sum();
        Ok(total)
    }

    fn compact_vectors<'py>(&self, _py: Python<'py>, _dim: usize) -> PyResult<usize> {
        for shard in &self.shards { let _ = shard.compaction_tx.send(true); }
        Ok(0)
    }
}

#[pymodule]
fn blitz_vec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<BlitzVec>()?;
    m.add_class::<BlitzIterator>()?;
    Ok(())
}