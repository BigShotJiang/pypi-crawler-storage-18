import unittest

from supermaker_ai_video_downloader import (
    BASE_URL,
    DEFAULT_PATH,
    build_link,
    generate_anchor,
)


class TestVideoDownloader(unittest.TestCase):
    def test_build_link_defaults(self):
        url = build_link()
        self.assertTrue(url.startswith(BASE_URL))
        self.assertIn(DEFAULT_PATH.strip("/"), url)

    def test_build_link_with_params(self):
        url = build_link(
            utm_source="blog",
            utm_medium="banner",
            utm_campaign="launch",
        )
        self.assertIn("utm_source=blog", url)
        self.assertIn("utm_medium=banner", url)
        self.assertIn("utm_campaign=launch", url)
        self.assertIn(DEFAULT_PATH.strip("/"), url)

    def test_generate_anchor(self):
        anchor = generate_anchor(
            text="Try SuperMaker Video",
            rel="sponsored noopener",
            utm={"utm_source": "docs"},
            class_name="supermaker-video-link",
        )
        self.assertTrue(anchor.startswith("<a "))
        self.assertIn('class="supermaker-video-link"', anchor)
        self.assertIn(">Try SuperMaker Video</a>", anchor)
        self.assertIn("utm_source=docs", anchor)


if __name__ == "__main__":
    unittest.main()
