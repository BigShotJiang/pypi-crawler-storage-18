
{
    "version": "2025.12.21",
    "target": "default",
    "variant": "cpu"
}
