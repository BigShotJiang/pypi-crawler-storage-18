<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="3.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:jp="http://www.jpo.go.jp"
    exclude-result-prefixes="jp">

    <!-- this xslt was created with reference to pat_common.xsl
         of Internet Application Software version i5.30 provided by JPO -->

    <xsl:include href="v4xva_prm.xsl" />
    <xsl:include href="helpers.xsl" />
    <xsl:variable name="doc-code" select="normalize-space(/descendant::jp:document-code[1])" /> <!--
    先頭の書類識別コードを取得 -->
    <xsl:variable name="payment" select="substring($node,1,11)" />
    <xsl:key name="item-use-key" match="item" use="@key" />

    <!-- image size tag parameter is set by saxon -->
    <xsl:param name="image_size_tag" as="xs:string" />

    <!-- conv1
         ====================================================================
         jp:addressed-to-person あて先 
         jp:addressed-to-person 信託関係事項
         jp:law-of-industrial-regenerate 産業再生法
         jp:kind-of-accelerated-examination 早期審査の種別
         jp:secret-design-term 秘密意匠請求期間
         ==================================================================== -->
    <xsl:template
        match="jp:addressed-to-person | jp:trust-relation |
        jp:law-of-industrial-regenerate |
        jp:kind-of-accelerated-examination | jp:secret-design-term">
        <xsl:variable name="tag" select="key('item-use-key', local-name(), $conv1)[1]" />

        <!-- <div> -->
        <xsl:element name="div">

            <!-- (　　)?【信託関係事項】　　　-->
            <xsl:call-template name="space-suffix">
                <xsl:with-param name="str">
                    <xsl:if test="parent::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:value-of select="$tag/@jp-tag" />
                </xsl:with-param>
                <xsl:with-param name="length" select="11" />
            </xsl:call-template>

            <!-- (　　)?【信託関係事項】　　　hoge-->
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>
    <!-- The template above is an alternative to a template of the following pattern. -->
    <!-- 信託関係事項 -->
    <xsl:template match="jp:trust-relation-OBSOLETE">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="parent::jp:contents-of-amendment">
                    <xsl:value-of select="concat('　　【信託関係事項】　',.)" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="concat('【信託関係事項】　　　',.)" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <xsl:variable name="conv1">
        <item key="addressed-to-person" jp-tag="【あて先】" class="document-tag" />
        <item key="trust-relation" jp-tag="【信託関係事項】" class="document-tag" />
        <item key="law-of-industrial-regenerate" jp-tag="【国等の委託研究の成果に係る記載事項】" class="document-tag" />
        <item key="kind-of-accelerated-examination" jp-tag="【早期審査の種別】" class="document-tag" />
        <item key="secret-design-term" jp-tag="【秘密にすることを請求する期間】" class="document-tag" />
    </xsl:variable>
    <!-- ====================================================================
         end of conv 1
         ====================================================================-->

    <!--   conv2 
         ====================================================================
         jp:relief-sought-in-demands 請求の趣旨 
         jp:financial-institution-name 金融機関名
         jp:account-type 口座種別
         jp:account-number 口座番号
         jp:share 持分
         jp:office-in-japan 日本における営業所
         jp:office 営業所
         jp:legal-entity-property 法人の法的性質
         jp:general-power-of-attorney-id 包括委任状番号
         jp:original-language-of-address 住所又は居所原語表記
         jp:kind-of-appeals 審判の種別
         ==================================================================== -->
    <xsl:template
        match="jp:relief-sought-in-demands | jp:financial-institution-name |
        jp:account-type | jp:account-number | jp:share | jp:office-in-japan | jp:office |
        jp:legal-entity-property | jp:general-power-of-attorney-id |
        jp:original-language-of-address | jp:kind-of-appeals">
        <xsl:variable name="tag" select="key('item-use-key', local-name(), $conv2)[1]" />
        <xsl:element name="div">
            <xsl:value-of select="$tag/@jp-tag" />
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>
    <!-- The template above is an alternative to a template of the following pattern. -->
    <!--   請求の趣旨
         <xsl:template match="jp:relief-sought-in-demands-OBSOLETE">
         <xsl:element name="div">
         <xsl:value-of select="concat('　　【請求の趣旨】　　',.)" />
         </xsl:element>
         </xsl:template>
    -->

    <xsl:variable name="conv2">
        <item key="relief-sought-in-demands" jp-tag="　　【請求の趣旨】　　" />
        <item key="financial-institution-name" jp-tag="　　【金融機関名】　　" />
        <item key="account-type" jp-tag="　　【口座種別】　　　" />
        <item key="account-number" jp-tag="　　【口座番号】　　　" />
        <item key="share" jp-tag="　　【持分】　　　　　" />
        <item key="office-in-japan" jp-tag="　　【日本における営業所】　" />
        <item key="office" jp-tag="　　【営業所】　　　　" />
        <item key="legal-entity-property" jp-tag="　　【法人の法的性質】　" />
        <item key="general-power-of-attorney-id" jp-tag="　　【包括委任状番号】　" />
        <item key="original-language-of-address" jp-tag="　　【住所又は居所原語表記】　" />
        <item key="kind-of-appeals" jp-tag="　　【審判の種別】　　" />
    </xsl:variable>
    <!-- ====================================================================
         end of conv 2
         ====================================================================-->

    <!--   conv3
         ====================================================================
         jp:number-of-annexation 併合件数
         jp:name-of-old-depository 旧寄託機関の名称
         jp:old-depository-number 旧受託番号
         jp:name-of-new-depository 新寄託機関の名称    
         jp:new-depository-number 新受託番号
         jp:srep-request-no 調査報告番号
         ==================================================================== -->
    <xsl:template name="use-conv3">
        <xsl:param name="key" />
        <xsl:variable name="tag" select="key('item-use-key', $key, $conv3)[1]" />
        <xsl:call-template name="space-suffix">
            <xsl:with-param name="str">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="$tag/@jp-tag" />
            </xsl:with-param>
            <xsl:with-param name="length" select="11" />
        </xsl:call-template>
        <xsl:value-of select="." />
    </xsl:template>
    <!-- The template above is an alternative to a template of the following pattern. -->
    <!-- 併合件数
         <xsl:template name="併合件数編集-OBSOLETE">
         <xsl:choose>
         <xsl:when test="ancestor::jp:contents-of-amendment">
         <xsl:value-of select="'　　【併合件数】　　　'" />
         </xsl:when>
         <xsl:otherwise>
         <xsl:value-of select="'【併合件数】　　　　　'" />
         </xsl:otherwise>
         </xsl:choose>
         <xsl:value-of select="." />
         </xsl:template>
    -->

    <xsl:variable name="conv3">
        <item key="新受託番号編集" jp-tag="【新受託番号】" />
        <item key="新寄託機関の名称編集" jp-tag="【新寄託機関の名称】" />
        <item key="旧受託番号編集" jp-tag="【旧受託番号】" />
        <item key="旧寄託機関の名称編集" jp-tag="【旧寄託機関の名称】" />
        <item key="併合件数編集" jp-tag="【併合件数】" />
        <item key="調査報告番号編集" jp-tag="【調査報告番号】" />
    </xsl:variable>
    <!-- ====================================================================
         end of conv 3
         ====================================================================-->

    <!-- ====================================================================
         use conv 3
         ====================================================================-->
    <!-- ====================================================================
         jp:number-of-annexation
         ====================================================================-->
    <!-- 併合件数 -->
    <xsl:template match="jp:number-of-annexation">
        <xsl:element name="div">
            <!-- <xsl:call-template name="併合件数編集" /> -->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'併合件数編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:name-of-old-depository
         ====================================================================-->
    <!-- 旧寄託機関の名称 -->
    <xsl:template match="jp:name-of-old-depository">
        <xsl:element name="div">
            <!-- <xsl:call-template name="旧寄託機関の名称編集" /> -->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'旧寄託機関の名称編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:old-depository-number
         ====================================================================-->
    <!-- 旧受託番号 -->
    <xsl:template match="jp:old-depository-number">
        <xsl:element name="div">
            <!-- <xsl:call-template name="旧受託番号編集" /> -->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'旧受託番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:name-of-new-depository
         ====================================================================-->
    <!-- 新寄託機関の名称 -->
    <xsl:template match="jp:name-of-new-depository">
        <xsl:element name="div">
            <!-- <xsl:call-template name="新寄託機関の名称編集" /> -->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'新寄託機関の名称編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:new-depository-number
         ====================================================================-->
    <!-- 新受託番号 -->
    <xsl:template match="jp:new-depository-number">
        <xsl:element name="div">
            <!--<xsl:call-template
            name="新受託番号編集" />-->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'新受託番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:srep-request-no
         ====================================================================-->
    <!-- 調査報告番号 -->
    <xsl:template match="jp:srep-request-no">
        <xsl:element name="div">
            <!-- <xsl:call-template name="調査報告番号編集" /> -->
            <xsl:call-template name="use-conv3">
                <xsl:with-param name="key" select="'調査報告番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>
    <!-- ====================================================================
         end of use conv 3
         ====================================================================-->

    <!-- conv4
         ====================================================================
         jp:text 住所又は居所編集
         jp:relation-attorney-special-matter 代理関係の特記事項編集
         jp:contact 連絡先編集
         jp:office-address 就業場所編集
         jp:kana フリカナ編集
         jp:fax ファクシミリ番号編集
         jp:phone 電話番号編集
         jp:registered-number 識別番号編集
         ====================================================================-->
    <xsl:template name="use-conv4">
        <xsl:param name="key" />
        <xsl:variable name="tag" select="key('item-use-key', $key, $conv4)[1]" />
        <xsl:call-template name="space-suffix">
            <xsl:with-param name="str">
                <xsl:if
                    test="(ancestor::jp:attorney-disappear-article
                            or ancestor::jp:attorney-change-article)
                        and ($node = 'jp:attorney-a7421' or $node = 'jp:attorney-a7423'
                            or $node = 'jp:attorney-a7425' or $node = 'jp:attorney-a7426'
                            or $node = 'jp:attorney-a7427' or $node = 'jp:attorney-a7428'
                            or $node = 'jp:attorney-a7431' or $node = 'jp:attorney-a7433'
                            or $node = 'jp:attorney-a7435' or $node = 'jp:attorney-a7436'
                            or $node = 'jp:attorney-a7437') ">
                    <xsl:value-of select="'　'" />
                </xsl:if>
                <xsl:value-of select="$tag/@jp-tag" />
            </xsl:with-param>
            <xsl:with-param name="length" select="11" />
        </xsl:call-template>
        <xsl:value-of select="." />
    </xsl:template>
    <!-- The template above is an alternative to a template of the following pattern. -->
    <!-- 住所又は居所編集
         <xsl:template name="住所又は居所編集-OBSOLETE">
         <xsl:choose>
         <xsl:when
         test="(ancestor::jp:attorney-disappear-article
         or ancestor::jp:attorney-change-article)
         and ($node = 'jp:attorney-a7421' or $node = 'jp:attorney-a7423'
         or $node = 'jp:attorney-a7425' or $node = 'jp:attorney-a7426'
         or $node = 'jp:attorney-a7427' or $node = 'jp:attorney-a7428'
         or $node = 'jp:attorney-a7431' or $node = 'jp:attorney-a7433'
         or $node = 'jp:attorney-a7435' or $node = 'jp:attorney-a7436'
         or $node = 'jp:attorney-a7437') ">
         <xsl:value-of select="'　　　【住所又は居所】　'" />
         </xsl:when>
         <xsl:otherwise>
         <xsl:value-of select="'　　【住所又は居所】　'" />
         </xsl:otherwise>
         </xsl:choose>
         <xsl:value-of select="." />
         </xsl:template>
    -->

    <xsl:variable name="conv4">
        <item key="住所又は居所編集" jp-tag="　　【住所又は居所】" />
        <item key="代理関係の特記事項編集" jp-tag="　　【代理関係の特記事項】" />
        <item key="連絡先編集" jp-tag="　　【連絡先】" />
        <item key="就業場所編集" jp-tag="　　【就業場所】" />
        <item key="フリカナ編集" jp-tag="　　【フリガナ】" />
        <item key="ファクシミリ番号編集" jp-tag="　　【ファクシミリ番号】" />
        <item key="電話番号編集" jp-tag="　　【電話番号】" />
        <item key="識別番号編集" jp-tag="　　【識別番号】" />
        <item key="attorney" jp-tag="　　【弁理士】　　　　" />
        <item key="lawyer" jp-tag="　　【弁護士】　　　　" />
    </xsl:variable>

    <!-- ====================================================================
         jp:lawyer 弁護士
         jp:attorney 弁理士 
         ====================================================================-->
    <xsl:template match="jp:lawyer | jp:attorney">
        <xsl:variable name="tag" select="key('item-use-key', local-name(), $conv4)[1]/@jp-tag" />
        <xsl:element name="div">
            <xsl:if
                test="(ancestor::jp:attorney-disappear-article
                        or ancestor::jp:attorney-change-article)
                    and ($node = 'jp:attorney-a7421' or $node = 'jp:attorney-a7423'
                        or $node = 'jp:attorney-a7425' or $node = 'jp:attorney-a7426'
                        or $node = 'jp:attorney-a7427' or $node = 'jp:attorney-a7428'
                        or $node = 'jp:attorney-a7431' or $node = 'jp:attorney-a7433'
                        or $node = 'jp:attorney-a7435' or $node = 'jp:attorney-a7436'
                        or $node = 'jp:attorney-a7437') ">
                <xsl:value-of select="'　'" />
            </xsl:if>
            <xsl:value-of select="$tag" />
        </xsl:element>
    </xsl:template>
    <!-- ====================================================================
         end of conv 4
         ====================================================================-->

    <!-- ====================================================================
         use conv 4
         ====================================================================-->
    <!-- ====================================================================
         jp:kana フリガナ
         ====================================================================-->
    <xsl:template match="jp:kana">
        <xsl:element name="div">
            <!-- <xsl:call-template name="フリカナ編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'フリカナ編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:registered-number
         ====================================================================-->
    <!-- 識別番号 -->
    <xsl:template match="jp:registered-number">
        <xsl:element name="div">
            <!-- <xsl:call-template name="識別番号編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'識別番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:office-address
         ====================================================================-->
    <!-- 就業場所 -->
    <xsl:template match="jp:office-address">
        <xsl:element name="div">
            <!-- <xsl:call-template name="就業場所編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'就業場所編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:contact
         ====================================================================-->
    <!-- 連絡先 -->
    <xsl:template match="jp:contact">
        <xsl:element name="div">
            <!-- <xsl:call-template name="連絡先編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'連絡先編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:relation-attorney-special-matter
         ====================================================================-->
    <!-- 代理関係の特記事項 -->
    <xsl:template match="jp:relation-attorney-special-matter">
        <xsl:element name="div">
            <!--<xsl:call-template
            name="代理関係の特記事項編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'代理関係の特記事項編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:phone
         ====================================================================-->
    <!-- 電話番号 -->
    <xsl:template match="jp:phone">
        <xsl:element name="div">
            <!-- <xsl:call-template name="電話番号編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'電話番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:fax
         ====================================================================-->
    <!-- ファクシミリ番号 -->
    <xsl:template match="jp:fax">
        <xsl:element name="div">
            <!-- <xsl:call-template name="ファクシミリ番号編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'ファクシミリ番号編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:text
         ====================================================================-->
    <!-- 住所又は居所 -->
    <xsl:template match="jp:text">
        <xsl:element name="div">
            <!-- <xsl:call-template name="住所又は居所編集" /> -->
            <xsl:call-template name="use-conv4">
                <xsl:with-param name="key" select="'住所又は居所編集'" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>
    <!-- ====================================================================
         end of use conv 4
         ====================================================================-->

    <!-- ====================================================================
         templates
         template match -> apply-template
         ====================================================================-->
    <!-- ====================================================================
         jp:applicants 申請者の記事
         jp:applicant-of-case-article 事件の出願人の記事
         jp:presenter-article 提出者の記事
         ==================================================================== -->
    <xsl:template match="jp:applicants | jp:applicant-of-case-article | jp:presenter-article">
        <xsl:element name="div">
            <xsl:for-each select="jp:applicant">
                <xsl:apply-templates select="." />
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:agents 代理人の記事
         jp:attorney-change-article 変更する代理人の記事
         jp:attorney-disappear-article 消滅する代理人の記事
         jp:proceeded-attorney-article 手続した代理人の記事
         jp:attorney-of-case-article 事件の出願人の代理人の記事
         ==================================================================== -->
    <xsl:template
        match="jp:agents | jp:attorney-change-article |
        jp:attorney-disappear-article | jp:proceeded-attorney-article |
        jp:attorney-of-case-article">
        <xsl:element name="div">
            <xsl:for-each select="jp:agent">
                <xsl:apply-templates select="." />
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:submission-object-list-article
         ====================================================================-->
    <!-- 提出物件の目録 -->
    <xsl:template match="jp:submission-object-list-article">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="'【提出物件の目録】'" />
            </xsl:element>
            <xsl:apply-templates select="jp:list-group" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:special-mention-matter-article
         ====================================================================-->
    <!-- 特記事項 -->
    <xsl:template match="jp:special-mention-matter-article">
        <xsl:element name="div">
            <xsl:apply-templates select="jp:article" />
        </xsl:element>
    </xsl:template>


    <!-- ====================================================================
         jp:application-country-article
         ====================================================================-->
    <!-- 出願国名 -->
    <xsl:template match="jp:application-country-article">
        <xsl:for-each select="jp:country">
            <xsl:apply-templates select="." />
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         jp:submission-date 提出日
         jp:dispatch-date 発送日 
         jp:notice-filing-date 出願番号通知の出願日
         jp:proof-filing-date 証明しようとする出願日
         jp:submit-date-of-amendment 補正書の提出年月日
         ====================================================================-->
    <xsl:template
        match="jp:submission-date | jp:dispatch-date |
        jp:notice-filing-date | jp:proof-filing-date |
        jp:submit-date-of-amendment">
        <xsl:apply-templates select="jp:date" />
    </xsl:template>

    <!-- ====================================================================
         jp:amount-paid 納付済金額
         jp:amount-proper-payment 適正納付金額
         jp:amount-restoration-claim 返還請求金額 
         ====================================================================-->
    <xsl:template match="jp:amount-paid | jp:amount-proper-payment | jp:amount-restoration-claim">
        <xsl:apply-templates select="jp:fee" />
    </xsl:template>

    <!-- ====================================================================
         jp:target-document-article
         ====================================================================-->
    <!-- 返還請求対象書類 -->
    <xsl:template match="jp:target-document-article">
        <xsl:apply-templates select="jp:target-document" />
    </xsl:template>

    <!-- ====================================================================
         jp:contents-part-article
         ====================================================================-->
    <!-- 記部の記事 -->
    <xsl:template match="jp:contents-part-article">
        <xsl:apply-templates select="jp:contents-part-group" />
    </xsl:template>

    <!-- ====================================================================
         jp:nationality
         ====================================================================-->
    <!-- 国籍 -->
    <xsl:template match="jp:nationality">
        <xsl:apply-templates select="jp:country" />
    </xsl:template>

    <!-- ====================================================================
         jp:contents-part-group
         ====================================================================-->
    <!-- 記部 -->
    <xsl:template match="jp:contents-part-group">
        <xsl:apply-templates select="jp:contents-name" />
        <xsl:apply-templates select="p" />
    </xsl:template>

    <!-- ====================================================================
         併合納付の明細編集
         <xsl:template name="併合納付の明細編集">
         ====================================================================-->
    <xsl:template match="jp:annexation-payment">
        <xsl:element name="div">
            <xsl:apply-templates select="jp:application-reference" />
            <xsl:apply-templates select="jp:number-of-claim" />
            <xsl:apply-templates select="jp:payment-years" />
            <xsl:apply-templates select="jp:fee" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:priority-doc-location-info
         ====================================================================-->
    <!-- 優先権書類の所在情報     -->
    <xsl:template match="jp:priority-doc-location-info">
        <xsl:apply-templates select="jp:country" />
        <xsl:apply-templates select="jp:doc-number" />
    </xsl:template>

    <!-- ====================================================================
         jp:inventors 発明者の記事
         ====================================================================-->
    <xsl:template match="jp:inventors">
        <xsl:element name="div">
            <xsl:for-each select="jp:inventor">
                <xsl:apply-templates select="." />
            </xsl:for-each>
            <xsl:for-each select="deceased-inventor">
                <xsl:apply-templates select="." />
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:declaration-priority-ear-app 先の出願に基づく優先権主張
         ====================================================================-->
    <xsl:template match="jp:declaration-priority-ear-app">
        <xsl:element name="div">
            <xsl:apply-templates select="jp:earlier-app" />
        </xsl:element>
    </xsl:template>
    <!-- ====================================================================
         end of the templates
         template match -> apply-template
         ====================================================================-->

    <!-- ====================================================================
         全角変換
         ====================================================================-->
    <xsl:template match="@num | @mode-num | @ex-num">
        <xsl:value-of select="normalize-space(.)" />
    </xsl:template>

    <!-- ====================================================================
         heading
         <xsl:template name="既定外項目名編集">
         ====================================================================-->
    <xsl:template match="heading">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【' || . || '】'" />
        </xsl:element>
    </xsl:template>
    <!-- ====================================================================
         end of the templates
         template match -> call-template
         ====================================================================-->

    <!-- ====================================================================
         templates
         template match -> value-of
         ====================================================================-->
    <!-- ====================================================================
         jp:generated-access-code アクセスコード
         ====================================================================-->
    <xsl:template match="jp:generated-access-code">
        <xsl:element name="div">
            <xsl:value-of select="'　　【アクセスコード】　' || ." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:number-of-class 商品及役務の区分の数
         <xsl:template name="商品及び役務の区分の数編集">
         ====================================================================-->
    <xsl:template match="jp:number-of-class">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【商品及び役務の区分の数】　' || ." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:representative-applicant
         ====================================================================-->
    <!-- 代表出願人 -->
    <xsl:template match="jp:representative-applicant">
        <xsl:element name="div">
            <xsl:value-of select="'　　【代表出願人】'" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:contents-name
         ====================================================================-->
    <!--  項目名 -->
    <xsl:template match="jp:contents-name">
        <xsl:element name="div">
            <xsl:value-of select="'　　【' || . || '】'" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:denominator 持分率（分母）
         jp:moleclar 持分率（分子）
         jp:ipc 分類
         patcit/text | nplcit/text
         jp:item-content
         jp:publications-etc 刊行物等
         ====================================================================-->
    <xsl:template
        match="jp:denominator | jp:moleclar | jp:ipc | patcit/text |
        nplcit/text | jp:item-content | jp:publications-etc">
        <xsl:value-of select="." />
    </xsl:template>
    <!-- ====================================================================
         end of the templates
         template match -> value-of
         ====================================================================-->

    <!-- ====================================================================
         misc templates
         ====================================================================-->
    <!-- ====================================================================
         jp:dispatch-number 発送番号編集
         <xsl:template name="発送番号編集">
         ====================================================================-->
    <xsl:template match="jp:dispatch-number">
        <xsl:element name="div">
            <xsl:call-template name="space-suffix-11">
                <xsl:with-param name="tag" select="'【発送番号】'" />
            </xsl:call-template>
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:share-rate 持分の割合編集
         <xsl:template name="持分の割合編集">
         ====================================================================-->
    <xsl:template match="jp:share-rate">
        <xsl:element name="div">
            <xsl:call-template name="space-suffix-11">
                <xsl:with-param name="tag" select="'【持分の割合】'" />
            </xsl:call-template>

            <xsl:apply-templates select="jp:moleclar" />
            <xsl:value-of select="'/'" />
            <xsl:apply-templates select="jp:denominator" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:ipc-article 国際特許分類編集 
         <xsl:template name="国際特許分類編集">
         ====================================================================-->
    <xsl:template match="jp:ipc-article">
        <xsl:element name="div">
            <xsl:for-each select="jp:ipc">
                <xsl:element name="div">
                    <xsl:if test="position() = 1">
                        <xsl:call-template name="space-suffix">
                            <xsl:with-param name="str">
                                <xsl:choose>
                                    <xsl:when test="ancestor::jp:contents-of-amendment">
                                        <xsl:value-of select="'　　【国際特許分類】'" />
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <xsl:value-of select="'【国際特許分類】'" />
                                    </xsl:otherwise>
                                </xsl:choose>
                            </xsl:with-param>
                            <xsl:with-param name="length" select="11" />
                        </xsl:call-template>
                    </xsl:if>
                    <xsl:if test="position() &gt; 1">
                        <!-- '　' x 11 -->
                        <xsl:value-of select="'　　　　　　　　　　　'" />
                    </xsl:if>
                    <xsl:apply-templates select="." />
                </xsl:element>
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:citation
         ====================================================================-->
    <!-- 援用の表示 -->
    <xsl:template match="jp:citation">
        <xsl:choose>
            <xsl:when test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="concat('　　【援用の表示】　　',.)" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="concat('　　　【援用の表示】　',.)" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:payment-years 納付年分
         <xsl:template name="納付年分編集">
         ====================================================================-->
    <xsl:template match="jp:payment-years">
        <xsl:element name="div">
            <xsl:call-template name="space-suffix">
                <xsl:with-param name="str" as="xs:string">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:annexation-payment
                            or ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　【納付年分】'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'【納付年分】'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:with-param>
                <xsl:with-param name="length" select="11" />
            </xsl:call-template>

            <xsl:apply-templates select="jp:year-from" />
            <xsl:apply-templates select="jp:year-to" />

        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:proof-necessity プルーフの要否
         <xsl:template name="プルーフの要否編集">
         ====================================================================-->
    <xsl:template match="jp:proof-necessity">
        <xsl:element name="div">
            <xsl:call-template name="space-suffix-11">
                <xsl:with-param name="tag" select="'【プルーフの要否】'" />
            </xsl:call-template>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="normalize-space(.) = '0'">
                            <xsl:value-of select="'不要'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = '1'">
                            <xsl:value-of select="'要'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = ''">
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:call-template name="書誌編集エラー処理" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:rule-outside-item-article
         ====================================================================-->
    <!-- 規定外の項目 -->
    <xsl:template match="jp:rule-outside-item-article">
        <xsl:for-each select="jp:rule-outside-group">
            <xsl:element name="div">
                <xsl:value-of select="'*規定外の項目'" />
            </xsl:element>
            <xsl:element name="div">
                <xsl:apply-templates select="." />
            </xsl:element>
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         jp:rule-outside-group 規定外記事
         ====================================================================-->
    <xsl:template match="jp:rule-outside-group">
        <xsl:element name="div">
            <xsl:apply-templates select="jp:item-name" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         項目名編集
         <xsl:template name="項目名編集">
         ====================================================================-->
    <xsl:template match="jp:item-name">
        <xsl:element name="div">
            <xsl:value-of select="'【' || . || '】'" />
            <xsl:choose>
                <xsl:when test="string-length(normalize-space(.)) &lt;= 8">
                    <xsl:call-template name="repeat-chars">
                        <xsl:with-param name="char" select="'　'" />
                        <xsl:with-param name="count" select="9 - string-length(normalize-space(.))" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　'" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:apply-templates select="following-sibling::jp:item-content" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:sequence-list
         ====================================================================-->
    <!-- 配列表 -->
    <xsl:template match="jp:sequence-list">
        <xsl:element name="div">
            <xsl:value-of select="'【配列表】'" />
        </xsl:element>
        <xsl:apply-templates select="p" />
    </xsl:template>

    <!-- ====================================================================
         jp:amendment-article 補正の記事
         ====================================================================-->
    <xsl:template match="jp:amendment-article">
        <xsl:element name="div">
            <xsl:for-each select="jp:amendment-group">
                <xsl:element name="div">
                    <xsl:apply-templates select="." />
                </xsl:element>
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:amendment-group 手続補正
         ====================================================================-->
    <xsl:template match="jp:amendment-group">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="parent::jp:contents-of-amendment">
                    <xsl:value-of select="parent::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="parent::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                    <xsl:value-of select="'【誤訳訂正' || ./@jp:serial-number || '】'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'【手続補正' || ./@jp:serial-number || '】'" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>

        <xsl:choose>
            <xsl:when test="parent::jp:contents-of-amendment">
                <xsl:apply-templates select="*" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:apply-templates select="jp:document-code" />
                <xsl:apply-templates select="jp:receipt-number" />
                <xsl:apply-templates select="jp:submission-date" />
                <xsl:apply-templates select="jp:file-reference-id" />
                <xsl:apply-templates select="jp:item-of-amendment" />
                <xsl:apply-templates select="jp:way-of-amendment" />
                <xsl:apply-templates select="jp:contents-of-amendment" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:way-of-amendment 方法
         <xsl:template name="方法編集">
         ====================================================================-->
    <xsl:template match="jp:way-of-amendment">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="jp-tag" as="xs:string">
            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                    <xsl:value-of select="'【訂正方法】'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'【補正方法】'" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:call-template name="space-suffix">
                <xsl:with-param name="str">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　' || $jp-tag" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="$jp-tag" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:with-param>
                <xsl:with-param name="length" select="12" />
            </xsl:call-template>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:when test="normalize-space(.) = ''">
                </xsl:when>
                <xsl:when test="normalize-space(.) = '1'">
                    <xsl:value-of select="'追加'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = '2'">
                    <xsl:value-of select="'削除'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = '3'">
                    <xsl:value-of select="'変更'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="書誌編集エラー処理" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:contents-of-amendment 補正の内容
         ====================================================================-->
    <xsl:template match="jp:contents-of-amendment">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of
                        select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                    <xsl:value-of select="'　【訂正の内容】'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　【補正の内容】'" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>

        <xsl:element name="div">
            <xsl:apply-templates select="*" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:appeal-article 審判事件の表示
         ====================================================================-->
    <xsl:template match="jp:appeal-article">
        <xsl:element name="div">
            <xsl:value-of select="'　　【審判事件の表示】'" />
        </xsl:element>

        <xsl:apply-templates select="jp:appeal-reference/jp:doc-number" />
        <xsl:apply-templates select="jp:appeal-reference/jp:date" />
        <xsl:apply-templates select="jp:application-reference" />
        <xsl:apply-templates select="jp:kind-of-appeals" />
        <xsl:apply-templates select="jp:file-reference-id" />
    </xsl:template>

    <!-- ====================================================================
         jp:article 条文
         ====================================================================-->
    <xsl:template match="jp:article">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="position() = 1">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　【特記事項】　　　'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'【特記事項】　　　　　'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　　　　　　　　　　'" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:call-template name="条文変換" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         条文変換
         ====================================================================-->
    <xsl:template name="条文変換">
        <xsl:variable name="code" select="normalize-space(.)" />

        <xsl:choose>
            <xsl:when test="./@jp:error-code">
                <xsl:value-of select="." />
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="$code =  ''"> <!-- (I) -->
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:variable name="value">
                            <xsl:choose>
                                <xsl:when test="$kind-of-law = 'patent'">
                                    <xsl:value-of
                                        select="key('item-use-key', $code, $patent-articles)[1]/@value" />
                                </xsl:when>
                                <xsl:when test="$kind-of-law = 'utility'">
                                    <xsl:value-of
                                        select="key('item-use-key', $code, $utility-articles)[1]/@value" />
                                </xsl:when>
                            </xsl:choose>
                        </xsl:variable>
                        <xsl:choose>
                            <xsl:when test="string-length($value) = 0">
                                <!-- (II) -->
                                <xsl:value-of select="'＊＊＊　書誌書類　内容エラー　＊＊＊'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <!-- (III) -->
                                <xsl:value-of select="$value" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
                <!-- (I)   $code が'' ならそのまま出力
                     (III)  $codeが 040など条文コードなら テーブルから対応する条文が出力
                     (II) $codeの条文コードがテーブルになければエラー
                -->
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="patent-articles">
        <item key="010" value="通常出願" />
        <item key="030" value="昭和６２年改正前特許法第３８条ただし書の規定による特許出願" />
        <item key="040" value="特許法第４４条第１項の規定による特許出願" />
        <item key="041" value="平成５年改正前特許法第４４条第１項の規定による特許出願" />
        <item key="051" value="特許法第４６条第１項の規定による特許出願" />
        <item key="052" value="特許法第４６条第２項の規定による特許出願" />
        <item key="053" value="昭和６０年改正前特許法第４５条第１項の規定による特許出願" />
        <item key="054" value="平成５年改正前特許法第４６条第１項の規定による特許出願" />
        <item key="055" value="平成５年改正前特許法第４６条第２項の規定による特許出願" />
        <item key="060" value="昭和６０年改正前特許法第５３条第４項に規定する特許出願" />
        <item key="070" value="特許法第４６条の２第１項の規定による実用新案登録に基づく特許出願" />
        <item key="511" value="特許法第３０条第１項の規定の適用を受けようとする特許出願" />
        <item key="512" value="特許法第３０条第３項の規定の適用を受けようとする特許出願" />
        <item key="513" value="平成５年改正前特許法第３０条第１項の規定の適用を受けようとする特許出願" />
        <item key="514" value="平成５年改正前特許法第３０条第３項の規定の適用を受けようとする特許出願" />
        <item key="515" value="平成２３年改正前特許法第３０条第１項の規定の適用を受けようとする特許出願" />
        <item key="516" value="平成２３年改正前特許法第３０条第３項の規定の適用を受けようとする特許出願" />
        <item key="517" value="特許法第３０条第２項の規定の適用を受けようとする特許出願" />
        <item key="521" value="特許法第３６条の２第１項の規定による特許出願" />
        <item key="526" value="特許法第３８条の３の規定による特許出願" />
        <item key="531" value="特許法第１８４条の１４の規定により特許法第３０条第１項の規定の適用を受けようとする特許出願" />
        <item key="532" value="特許法第１８４条の１４の規定により特許法第３０条第３項の規定の適用を受けようとする特許出願" />
        <item key="533" value="特許法第１８４条の１４の規定により平成２３年改正前特許法第３０条第１項の規定の適用を受けようとする特許出願" />
        <item key="534" value="特許法第１８４条の１４の規定により平成２３年改正前特許法第３０条第３項の規定の適用を受けようとする特許出願" />
        <item key="535" value="特許法第１８４条の１４の規定により特許法第３０条第２項の規定の適用を受けようとする特許出願" />
        <item key="999" value="条文記載誤り" />
    </xsl:variable>

    <xsl:variable name="utility-articles">
        <item key="010" value="通常出願" />
        <item key="040" value="実用新案法第９条第１項において準用する特許法第４４条第１項の規定による実用新案登録出願" />
        <item key="041" value="平成５年改正前実用新案法第９条第１項において準用する平成５年改正前特許法第４４条第１項の規定による実用新案登録出願" />
        <item key="042" value="実用新案法第１１条第１項において準用する特許法第４４条第１項の規定による実用新案登録出願" />
        <item key="051" value="実用新案法第８条第１項の規定による実用新案登録出願" />
        <item key="052" value="実用新案法第８条第２項の規定による実用新案登録出願" />
        <item key="054" value="平成５年改正前実用新案法第８条第１項の規定による実用新案登録出願" />
        <item key="055" value="平成５年改正前実用新案法第８条第２項の規定による実用新案登録出願" />
        <item key="056" value="平成５年改正法附則第５条第１項の規定による実用新案登録出願" />
        <item key="057" value="平成５年改正法附則第５条第５項の規定による実用新案登録出願" />
        <item key="058" value="実用新案法第１０条第１項の規定による実用新案登録出願" />
        <item key="059" value="実用新案法第１０条第２項の規定による実用新案登録出願" />
        <item key="060" value="昭和６０年改正前実用新案法第１３条において準用する昭和６０年改正前特許法第５３条第４項に規定する実用新案登録出願" />
        <item key="511" value="実用新案法第９条第１項において準用する特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="512" value="実用新案法第９条第１項において準用する特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="513" value="平成５年改正前実用新案法第９条第１項において準用する平成５年改正前特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="514" value="平成５年改正前実用新案法第９条第１項において準用する平成５年改正前特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="515" value="実用新案法第１１条第１項において準用する特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="516" value="実用新案法第１１条第１項において準用する特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="517" value="実用新案法第１１条第１項において準用する平成２３年改正前特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="518" value="実用新案法第１１条第１項において準用する平成２３年改正前特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="519" value="実用新案法第１１条第１項において準用する特許法第３０条第２項の規定の適用を受けようとする実用新案登録出願" />
        <item key="531"
            value="実用新案法第４８条の１５第３項で準用する特許法第１８４条の１４の規定により実用新案法第１１条第１項で準用する特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="532"
            value="実用新案法第４８条の１５第３項で準用する特許法第１８４条の１４の規定により実用新案法第１１条第１項で準用する特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="533"
            value="実用新案法第４８条の１５第３項で準用する特許法第１８４条の１４の規定により実用新案法第１１条第１項で準用する平成２３年改正前特許法第３０条第１項の規定の適用を受けようとする実用新案登録出願" />
        <item key="534"
            value="実用新案法第４８条の１５第３項で準用する特許法第１８４条の１４の規定により実用新案法第１１条第１項で準用する平成２３年改正前特許法第３０条第３項の規定の適用を受けようとする実用新案登録出願" />
        <item key="535"
            value="実用新案法第４８条の１５第３項で準用する特許法第１８４条の１４の規定により実用新案法第１１条第１項で準用する特許法第３０条第２項の規定の適用を受けようとする実用新案登録出願" />
        <item key="999" value="条文記載誤り" />
    </xsl:variable>

    <!-- ====================================================================
         jp:application-reference 出願書類参照
         ====================================================================-->
    <xsl:template match="jp:application-reference">
        <xsl:choose>
            <xsl:when test="parent::jp:earlier-app or parent::jp:parent-application-article">
                <xsl:call-template name="出願書類参照編集" />
                <xsl:if test=".//jp:date">
                    <xsl:choose>
                        <xsl:when test="./@appl-type = 'application'">
                            <xsl:choose>
                                <xsl:when
                                    test="
                                        ((./@appl-type='application') and (.//jp:doc-number !='')) or
                                        ((following-sibling::jp:application-reference/@appl-type='application' or
                                                following-sibling::jp:application-reference/@appl-type='international-application') and
                                            (following-sibling::jp:application-reference//jp:doc-number !=''))  or
                                        ((preceding-sibling::jp:application-reference/@appl-type='application' or
                                                preceding-sibling::jp:application-reference/@appl-type='international-application') and
                                            (preceding-sibling::jp:application-reference//jp:doc-number !=''))">
                                    <xsl:element name="div">
                                        <xsl:call-template name="先の出願日編集" />
                                    </xsl:element>
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:apply-templates select=".//jp:date" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:apply-templates select=".//jp:date" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:if>
            </xsl:when>
            <xsl:otherwise>
                <xsl:apply-templates select="jp:document-id/jp:doc-number" />
                <xsl:call-template name="出願書類参照編集" />
                <xsl:apply-templates select="jp:document-id/jp:date" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         出願書類参照編集
         ====================================================================-->
    <xsl:template name="出願書類参照編集">
        <xsl:choose>
            <xsl:when
                test="(ancestor::jp:indication-of-case-article
                        or ancestor::jp:parent-application-article)
                    and (./@appl-type = 'international-application')
                    and (./@jp:kind-of-law)">
                <xsl:choose>
                    <xsl:when
                        test="$payment = 'jp:payment-' or $node = 'jp:demand-e853'
                            or $node = 'jp:demand-e854' or $node = 'jp:demand-e862' ">
                        <xsl:value-of select="'【出願の区分】　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　【出願の区分】　　'" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:choose>
                    <xsl:when test="./@jp:kind-of-law = 'patent'">
                        <xsl:value-of select="'特許'" />
                    </xsl:when>
                    <xsl:when test="./@jp:kind-of-law = 'utility'">
                        <xsl:value-of select="'実用新案登録'" />
                    </xsl:when>
                    <xsl:when test="./@jp:kind-of-law = ''">
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise />
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         先の出願日編集
         ====================================================================-->
    <xsl:template name="先の出願日編集">
        <xsl:variable name="date-str" select="normalize-space(.//jp:date)" />
        <xsl:variable name="m" select="substring(normalize-space(.//jp:date),5,2)" />
        <xsl:variable name="d" select="substring(normalize-space(.//jp:date),7,2)" />

        <xsl:choose>
            <xsl:when
                test="($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                        or $node = 'jp:demand-e854' or $node = 'jp:demand-e862')
                    and not(ancestor::jp:contents-of-amendment)">
                <xsl:value-of select="'【出願日】　　　　　　'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="'　　【出願日】　　　　'" />
            </xsl:otherwise>
        </xsl:choose>

        <xsl:choose>
            <xsl:when test=".//jp:date/@jp:error-code">
                <xsl:value-of select=".//jp:date" />
            </xsl:when>
            <xsl:when test="string-length($date-str) != 8" />
            <xsl:when
                test="(number(.//jp:date) != number($date-str)) or (number($date-str) &lt; 19260101)">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="gengo">
                    <xsl:with-param name="date" select="$date-str" />
                </xsl:call-template>
                <xsl:call-template name="warekinen">
                    <xsl:with-param name="date" select="$date-str" />
                </xsl:call-template>
                <xsl:value-of select="'年'" />
                <xsl:value-of select="$m || '月'" />
                <xsl:value-of select="$d || '日'" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         deceased-inventor
         ====================================================================-->
    <xsl:template match="deceased-inventor">
        <xsl:element name="div">
            <xsl:value-of select="'unsupported tag' || name()" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         designated-states | designated-states-as-inventor
         ====================================================================-->
    <xsl:template match="designated-states | designated-states-as-inventor">
        <xsl:element name="div">
            <xsl:value-of select="'unsupported tag' || name()" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         residence
         ====================================================================-->
    <xsl:template match="residence">
        <xsl:element name="div">
            <xsl:value-of select="'unsupported tag' || name()" />
        </xsl:element>
        <xsl:apply-templates select="country" />
    </xsl:template>

    <!-- ====================================================================
         jp:earlier-app 先の出願
         ====================================================================-->
    <xsl:template match="jp:earlier-app">
        <xsl:variable name="node">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:call-template name="先の出願編集">
                <xsl:with-param name="node" select="$node" />
            </xsl:call-template>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:opinion-contents-article
         ====================================================================-->
    <!-- 意見の内容 -->
    <xsl:template match="jp:opinion-contents-article">
        <xsl:variable name="sikibetu">
            <xsl:choose>
                <xsl:when test="parent::jp:contents-of-amendment">
                    <xsl:value-of select="parent::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:variable name="jp-tag"
                select="key('item-use-key', $sikibetu, $opinion-tag)[1]/@jp-tag" />
            <xsl:choose>
                <xsl:when test="string-length($jp-tag) = 0">
                    <xsl:value-of select="'【特許料等に関する特記事項】'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$jp-tag" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>

        <xsl:for-each select="p">
            <xsl:apply-templates select="." />
        </xsl:for-each>
    </xsl:template>

    <xsl:variable name="opinion-tag">
        <item key="jp:response-a59" jp-tag="【弁明の内容】" />
        <item key="jp:etcetera-a781" jp-tag="【上申の内容】" />
        <item key="jp:etcetera-a87" jp-tag="【実施の状況等】" />
        <item key="jp:etcetera-a871" jp-tag="【早期審査に関する事情説明】" />
        <item key="jp:etcetera-a872" jp-tag="【補充の内容】" />
        <item key="jp:amendment-a524" jp-tag="【訂正の理由等】" />
        <item key="jp:response-a53" jp-tag="【意見の内容】" />
        <item key="jp:etcetera-a621" jp-tag="【手数料に関する特記事項】" />
        <item key="jp:etcetera-a623" jp-tag="【請求人の意見】" />
        <item key="jp:etcetera-a624" jp-tag="【請求人の意見】" />
        <item key="jp:etcetera-a917" jp-tag="【回復の理由】" />
        <item key="jp:etcetera-a918" jp-tag="【申出の理由】" />
    </xsl:variable>

    <!-- ====================================================================
         jp:num-claim-decrease-amendment 補正により減少する請求項の数編集
         ====================================================================-->
    <xsl:template match="jp:num-claim-decrease-amendment">
        <xsl:variable name="sikibetu">
            <xsl:choose>
                <xsl:when test="parent::jp:contents-of-amendment">
                    <xsl:value-of select="parent::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$sikibetu = 'jp:amendment-a524'">
                    <xsl:choose>
                        <xsl:when test="./@jp:adopted-law = 'claim'">
                            <xsl:value-of select="'【訂正により減少する請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'invention'">
                            <xsl:value-of select="'【訂正により減少する発明の数】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="./@jp:adopted-law = 'claim'">
                            <xsl:value-of select="'【補正により減少する請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'invention'">
                            <xsl:value-of select="'【補正により減少する発明の数】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>


    <!-- ====================================================================
         jp:num-claim-increase-amendment 補正により増加する請求項の数編集
         ====================================================================-->
    <xsl:template match="jp:num-claim-increase-amendment">
        <xsl:variable name="sikibetu">
            <xsl:choose>
                <xsl:when test="parent::jp:contents-of-amendment">
                    <xsl:value-of select="parent::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$sikibetu = 'jp:amendment-a524'">
                    <xsl:choose>
                        <xsl:when test="./@jp:adopted-law = 'claim'">
                            <xsl:value-of select="'【訂正により増加する請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'invention'">
                            <xsl:value-of select="'【訂正により増加する発明の数】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="./@jp:adopted-law = 'claim'">
                            <xsl:value-of select="'【補正により増加する請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'invention'">
                            <xsl:value-of select="'【補正により増加する発明の数】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:delivery-way 交付方法
         ====================================================================-->
    <xsl:template match="jp:delivery-way">
        <xsl:element name="div">
            <xsl:call-template name="padding-beginning-of-string">
                <xsl:with-param name="input-string">
                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:value-of select="'【交付方法】'" />
                </xsl:with-param>
                <xsl:with-param name="length" select="11" />
            </xsl:call-template>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="normalize-space(.) = '1'">
                            <xsl:value-of select="'手交'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = '2'">
                            <xsl:value-of select="'郵送'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = ''">
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:call-template name="書誌編集エラー処理" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:number-of-copy 請求部数編集
         ====================================================================-->
    <xsl:template match="jp:number-of-copy">
        <xsl:element name="div">

            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【請求部数】'" />

            <xsl:if test="string-length(normalize-space(.)) != 0">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　　' || ." />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　　　　' || ." />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:if>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:indicate-payment 納付の表示
         <xsl:template name="納付の表示編集">
         ====================================================================-->
    <xsl:template match="jp:indicate-payment">
        <xsl:element name="div">

            <xsl:call-template name="padding-beginning-of-string">
                <xsl:with-param name="input-string">
                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:value-of select="'【納付の表示】'" />
                </xsl:with-param>
                <xsl:with-param name="length" select="11" />
            </xsl:call-template>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when
                            test="($node = 'jp:payment-r200' or $node = 'jp:payment-r210')
                                and $kind-of-law = 'trademark'">
                            <xsl:choose>
                                <xsl:when test="normalize-space(.) = ''" />
                                <xsl:when test="normalize-space(.) = '1'">
                                    <xsl:value-of select="'分割納付'" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:call-template name="書誌編集エラー処理" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:choose>
                                <xsl:when test="normalize-space(.) = ''" />
                                <xsl:when test="normalize-space(.) = '0'">
                                    <xsl:value-of select="'一括納付'" />
                                </xsl:when>
                                <xsl:when test="normalize-space(.) = '1'">
                                    <xsl:value-of select="'分割納付'" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:call-template name="書誌編集エラー処理" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:proof-matter-article 証明に係る事項
         ====================================================================-->
    <xsl:template match="jp:proof-matter-article">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【証明に係る事項】'" />
        </xsl:element>

        <xsl:for-each select="p">
            <xsl:apply-templates select="." />
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         jp:kind-of-annexation 併合識別
         <xsl:template name="併合識別編集">
         ====================================================================-->
    <xsl:template match="jp:kind-of-annexation">
        <xsl:element name="div">

            <xsl:call-template name="padding-beginning-of-string">
                <xsl:with-param name="input-string">
                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:value-of select="'【併合識別】'" />
                </xsl:with-param>
                <xsl:with-param name="length" select="11" />
            </xsl:call-template>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:if test="normalize-space(.) = '1'">
                        <xsl:value-of select="'併合'" />
                    </xsl:if>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:annexation-payment-article
         ====================================================================-->
    <!-- 併合納付の明細の記事 -->
    <xsl:template match="jp:annexation-payment-article">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【併合納付の明細】'" />
        </xsl:element>

        <xsl:for-each select="jp:annexation-payment">
            <xsl:apply-templates select="." />
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         jp:publications-etc-article
         ====================================================================-->
    <!-- 刊行物等の記事 -->
    <xsl:template match="jp:publications-etc-article">
        <xsl:element name="div">
            <xsl:call-template name="space-suffix-11">
                <xsl:with-param name="tag" select="'【刊行物等】'" />
            </xsl:call-template>
            <xsl:if test="jp:publications-etc[1]">
                <xsl:apply-templates select="./jp:publications-etc[1]" />
            </xsl:if>
        </xsl:element>
        <xsl:for-each select="jp:publications-etc">
            <xsl:if test="position() != 1">
                <xsl:element name="div">
                    <xsl:value-of select="'　　　　　　　　　　　'" />
                    <xsl:apply-templates select="." />
                </xsl:element>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>


    <!-- ====================================================================
         jp:class-of-goods-and-service
         ====================================================================-->
    <!-- 商品及び役務の区分 -->
    <xsl:template match="jp:class-of-goods-and-service">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【商品及び役務の区分】　'" />

            <xsl:for-each select="jp:class">
                <xsl:value-of select="'第' || . || '類'" />
                <xsl:if test="position() != last()">
                    <xsl:value-of select="', '" />
                </xsl:if>
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:target-document 対象書類
         ====================================================================-->
    <xsl:template match="jp:target-document">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:choose>
                    <xsl:when test="parent::jp:target-document-article">
                        <xsl:if test="position() = 1">
                            <xsl:if test="ancestor::jp:contents-of-amendment">
                                <xsl:value-of select="'　　'" />
                            </xsl:if>
                            <xsl:value-of select="'【返還請求対象書類】'" />
                        </xsl:if>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:if test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【返還請求対象書類】'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates select="jp:document-code" />
            <xsl:apply-templates select="jp:submission-date" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         U
         ====================================================================-->
    <!-- 下線 -->
    <xsl:template match="u">
        <u>
            <xsl:apply-templates />
        </u>
    </xsl:template>

    <!-- ====================================================================
         br
         ====================================================================-->
    <!-- 段落内改行 -->
    <xsl:template match="br">
        <br />
    </xsl:template>

    <!-- ====================================================================
         img
         ====================================================================-->
    <!-- イメージ  -->
    <xsl:template match="img">
        <xsl:variable name="item" select="key('image-table', @file)[1]" />

        <xsl:element name="div">
            <xsl:element name="img">
                <xsl:attribute name="src">
                    <xsl:value-of select="$item/@new" />
                </xsl:attribute>
                <xsl:attribute name="width">
                    <xsl:value-of select="$item/@width" />
                </xsl:attribute>
                <xsl:attribute name="height">
                    <xsl:value-of select="$item/@height" />
                </xsl:attribute>
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         img
         ====================================================================-->
    <!-- イメージ  -->
    <xsl:template match="img" mode="title">
        <xsl:variable name="item" select="key('image-table', @file)[1]" />

        <xsl:element name="div">
            <xsl:element name="img">
                <xsl:attribute name="src">
                    <xsl:value-of select="$item/@new" />
                </xsl:attribute>
                <xsl:attribute name="width">
                    <xsl:value-of select="$item/@width" />
                </xsl:attribute>
                <xsl:attribute name="height">
                    <xsl:value-of select="$item/@height" />
                </xsl:attribute>
                <xsl:attribute name="title">
                    <xsl:choose>
                        <xsl:when test="parent::chemistry">
                            <xsl:value-of select="'　　【化'" />
                            <xsl:apply-templates select="parent::chemistry/@num" />
                        </xsl:when>
                        <xsl:when test="parent::maths">
                            <xsl:value-of select="'　　【数'" />
                            <xsl:apply-templates select="parent::maths/@num" />
                        </xsl:when>
                        <xsl:when test="parent::tables">
                            <xsl:value-of select="'　　【表'" />
                            <xsl:apply-templates select="parent::tables/@num" />
                        </xsl:when>
                        <xsl:when test="parent::figure">
                            <xsl:value-of select="'【図'" />
                            <xsl:apply-templates select="parent::figure/@num" />
                        </xsl:when>
                    </xsl:choose>
                    <xsl:value-of select="'】'" />
                </xsl:attribute>
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:year-from 納付年分（自）
         jp:year-to 納付年分（至）
         ====================================================================-->
    <xsl:template match="jp:year-from | jp:year-to">
        <xsl:variable name="year" as="xs:string" select="normalize-space(.)" />
        <xsl:variable name="length" as="xs:integer" select="string-length($year)" />
        <xsl:choose>
            <xsl:when test="./@jp:error-code">
                <xsl:value-of select="." />
            </xsl:when>
            <xsl:when test="$length = 0 or $length &gt; 2">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:if test="name(.) = 'jp:year-to'">
                    <xsl:value-of select="'から'" />
                </xsl:if>
                <xsl:value-of select="'第' || . || '年分'" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:payment 納付
         ====================================================================-->
    <xsl:template match="jp:payment">
        <xsl:apply-templates select="jp:account" />
        <xsl:for-each select="jp:fee">
            <xsl:element name="div">
                <xsl:apply-templates select="." />
            </xsl:element>
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         振込先編集
         <xsl:template name="振込先編集">
         ====================================================================-->
    <xsl:template match="jp:bank-account">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="'【返還金振込先】'" />
            </xsl:element>

            <xsl:apply-templates select="jp:financial-institution-name" />
            <xsl:apply-templates select="jp:account-type" />
            <xsl:apply-templates select="jp:account-number" />
            <xsl:apply-templates select="jp:kana" />
            <xsl:apply-templates select="jp:name" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:representative-group 代表者情報
         ====================================================================-->
    <xsl:template match="jp:representative-group">
        <xsl:for-each select="jp:representative">
            <xsl:apply-templates select="jp:kana" />
            <xsl:apply-templates select="jp:name" />
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select="jp:original-language-of-name" />
            </xsl:if>
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         jp:fee 納付方法・納付金額
         ====================================================================-->
    <xsl:template match="jp:fee">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <xsl:when
                test="$kinddoc = 'jp:payment-r110' or $kinddoc = 'jp:payment-r111'
                    or $kinddoc = 'jp:payment-r112' or $kinddoc = 'jp:payment-r113'
                    or $kinddoc = 'jp:payment-r114' or $kinddoc = 'jp:payment-r115'
                    or $kinddoc = 'jp:payment-r21' or $kinddoc = 'jp:payment-r210'
                    or $kinddoc = 'jp:payment-r211' ">
                <xsl:value-of select="'　　【補充金額】　　　'" />
            </xsl:when>
            <xsl:when
                test="parent:: jp:amount-paid and not(ancestor::jp:contents-of-amendment)">
                <xsl:value-of select="'【納付済金額】　　　　'" />
            </xsl:when>
            <xsl:when test="parent:: jp:amount-paid ">
                <xsl:value-of select="'　　【納付済金額】　　'" />
            </xsl:when>
            <xsl:when
                test=" parent:: jp:amount-restoration-claim and not(ancestor::jp:contents-of-amendment)">
                <xsl:value-of select="'【返還請求金額】　　　'" />
            </xsl:when>
            <xsl:when test=" parent:: jp:amount-restoration-claim ">
                <xsl:value-of select="'　　【返還請求金額】　'" />
            </xsl:when>
            <xsl:when
                test="parent:: jp:amount-proper-payment and not(ancestor::jp:contents-of-amendment)">
                <xsl:value-of select="'【適正納付金額】　　　'" />
            </xsl:when>
            <xsl:when test="parent:: jp:amount-proper-payment ">
                <xsl:value-of select="'　　【適正納付金額】　'" />
            </xsl:when>
            <xsl:when
                test="($kinddoc = 'jp:etcetera-a914') and
                    ancestor::jp:charge-article">
                <xsl:value-of select="'　　【加算金額】　　　'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="'　　【納付金額】　　　'" />
            </xsl:otherwise>
        </xsl:choose>

        <xsl:choose>
            <xsl:when test="./@jp:error-code">
                <xsl:value-of select="./@amount" />
            </xsl:when>
            <xsl:when
                test="./@amount != '' and string(number(./@amount)) != 'NaN'">
                <xsl:value-of
                    select="format-number(xs:integer(normalize-space(./@amount)), '#,###')" />
                <xsl:value-of select="'円'" />
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:account 予納台帳番号・納付書番号
         <xsl:template name="予納台帳番号編集">
         ====================================================================-->
    <xsl:template match="jp:account">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="./@account-type = 'deposit'">
                    <xsl:value-of select="'　　【予納台帳番号】　' || ./@number" />
                </xsl:when>
                <xsl:when test="./@account-type = 'form'">
                    <xsl:value-of select="'　　【納付書番号】　　' || ./@number" />
                </xsl:when>

                <xsl:when test="./@account-type = 'electronic-cash'">
                    <xsl:value-of select="'　　【納付番号】　　　'" />
                    <xsl:choose>
                        <xsl:when test="./@jp:error-code">
                            <xsl:value-of select="./@number" />
                        </xsl:when>
                        <xsl:when test="string-length(normalize-space(./@number)) = 0" />
                        <xsl:otherwise>
                            <xsl:call-template name="split-at-n-chars">
                                <xsl:with-param name="input-string"
                                    select="substring(normalize-space(./@number),1,16)" />
                                <xsl:with-param name="n-chars" select="4" />
                                <xsl:with-param name="sep" select="'-'" />
                            </xsl:call-template>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>

                <xsl:when test="./@account-type = 'transfer'">
                    <xsl:value-of select="'　　【振替番号】　　　' || ./@number" />
                </xsl:when>

                <xsl:when test="./@account-type = 'credit-card'">
                    <xsl:value-of select="'　　【指定立替納付】'" />
                    <xsl:if test="./@jp:error-code">
                        <xsl:value-of select="'　' || ./@number" />
                    </xsl:if>
                </xsl:when>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:return-reques 返還の申出
         <xsl:template name="返還の申出編集">
         ====================================================================-->
    <xsl:template match="jp:return-request">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　【返還の申出】　　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　　【返還の申出】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="normalize-space(.) = '0'">
                            <xsl:value-of select="'無'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = '1'">
                            <xsl:value-of select="'有'" />
                        </xsl:when>
                        <xsl:when test="normalize-space(.) = ''">
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:call-template name="書誌編集エラー処理" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:invention-contents-article
         ====================================================================-->
    <!-- 申出に係る発明の内容 -->
    <xsl:template match="jp:invention-contents-article">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【申出に係る発明の内容】'" />
        </xsl:element>
        <xsl:for-each select="p">
            <xsl:apply-templates select="." />
        </xsl:for-each>
    </xsl:template>

    <!-- ====================================================================
         SUP
         ====================================================================-->
    <!-- 上付  -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>

    <!-- ====================================================================
         SUB
         ====================================================================-->
    <!-- 下付 -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>

    <!-- ====================================================================
         jp:file-reference-id
         ====================================================================-->
    <!-- 整理番号 -->
    <xsl:template match="jp:file-reference-id">
        <xsl:element name="div">
            <xsl:call-template name="整理番号項目名編集" />
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         整理番号項目名編集
         ====================================================================-->
    <xsl:template name="整理番号項目名編集">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="c-payment">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of
                        select="substring(ancestor::jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$payment" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <xsl:when test="$kinddoc = 'jp:aib31c1'">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【書類記号】　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【書類記号】　　　　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【訂正対象書類整理番号】　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　【訂正対象書類整理番号】　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="parent::jp:amendment-group">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【補正対象書類整理番号】　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　【補正対象書類整理番号】　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="ancestor::jp:indication-of-case-article">
                        <xsl:choose>
                            <xsl:when
                                test="$c-payment = 'jp:payment-' or $kinddoc = 'jp:demand-e853'
                                    or $kinddoc = 'jp:demand-e854' or $kinddoc = 'jp:demand-e862' ">
                                <xsl:value-of select="'【整理番号】　　　　　'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'　　【整理番号】　　　'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:parent-application-article
                            or ancestor::jp:declaration-priority-ear-app">
                        <xsl:value-of select="'　　【整理番号】　　　'" />
                    </xsl:when>
                    <xsl:when
                        test="parent::jp:contents-of-amendment
                        and ancestor::jp:appeal-article">
                        <xsl:value-of select="'　　【整理番号】　　　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【整理番号】　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【整理番号】　　　　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:dtext その他編集
         <xsl:template name="その他編集">
         ====================================================================-->
    <xsl:template name="jp:dtext">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:submission-object-list-article">
                    <xsl:value-of select="'　　【提出物件の特記事項】　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　【その他】　　　　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'【その他】　　　　　　'" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         事件の表示編集
         <xsl:template name="事件の表示編集">
         ====================================================================-->
    <xsl:template match="jp:indication-of-case-article">
        <xsl:variable name="node">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="kindlaw">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">

                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$kind-of-law" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="paym">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$payment" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:choose>
                    <xsl:when
                        test="$node = 'jp:application-a631' or $node = 'jp:application-a632' or
                            $node = 'jp:application-a633' or $node = 'jp:application-a634' or
                            $node = 'jp:application-a635' or $node = 'jp:etcetera-a621' or
                            $node = 'jp:etcetera-a623' or $node = 'jp:etcetera-a624' or
                            $node = 'jp:etcetera-a625' or $node = 'jp:etcetera-a626' or
                            $node = 'jp:etcetera-a627' or $node = 'jp:etcetera-a914' or
                            $node = 'jp:amendment-a5210' or $node = 'jp:amendment-a5211' or
                            $node = 'jp:amendment-a5212' or $node = 'jp:amendment-a525' or
                            $node = 'jp:amendment-a526' or $node = 'jp:amendment-a527' or
                            $node = 'jp:amendment-a528' or $node = 'jp:amendment-a529' or
                            $node = 'jp:etcetera-a917' or $node = 'jp:etcetera-a918' or
                            $node = 'jp:etcetera-a919'">
                        <xsl:choose>
                            <xsl:when
                                test="($node = 'jp:etcetera-a623' or $node = 'jp:etcetera-a624') and $kindlaw = 'utility'
                                    and ./jp:application-reference/@appl-type = 'registration'
                                    and string-length(normalize-space(./jp:application-reference/jp:document-id/jp:date)) = 0">
                                <xsl:if
                                    test="./jp:application-reference/@appl-type != 'registration'">
                                    <xsl:if test="ancestor::jp:contents-of-amendment">
                                        <xsl:value-of select="'　　'" />
                                    </xsl:if>
                                    <xsl:value-of select="'【出願の表示】'" />
                                </xsl:if>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:if test="ancestor::jp:contents-of-amendment">
                                    <xsl:value-of select="'　　'" />
                                </xsl:if>
                                <xsl:value-of select="'【出願の表示】'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="($node = 'jp:demand-e853' or $node = 'jp:demand-e854' or
                                $node = 'jp:demand-e862') or ($paym = 'jp:payment-')">
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when
                                test="($node = 'jp:etcetera-a915') and $kindlaw = 'utility'
                                    and ./jp:application-reference/@appl-type = 'registration'
                                    and string-length(normalize-space(./jp:application-reference/jp:document-id/jp:date)) = 0">
                                <xsl:if
                                    test="./jp:application-reference/@appl-type != 'registration'">
                                    <xsl:if test="ancestor::jp:contents-of-amendment">
                                        <xsl:value-of select="'　　'" />
                                    </xsl:if>
                                    <xsl:value-of select="'【事件の表示】'" />
                                </xsl:if>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:if test="ancestor::jp:contents-of-amendment">
                                    <xsl:value-of select="'　　'" />
                                </xsl:if>
                                <xsl:value-of select="'【事件の表示】'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'international-application']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'international-application']//jp:date" />
            <xsl:for-each
                select="jp:application-reference[@appl-type = 'international-application']">
                <xsl:element name="div">
                    <xsl:call-template name="出願書類参照編集" />
                </xsl:element>
            </xsl:for-each>
            <xsl:apply-templates select="jp:appeal-reference/jp:doc-number" />
            <xsl:apply-templates select="jp:appeal-reference/jp:date" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'application']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'registration']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'examined-pub']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'un-examined-pub']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference[@appl-type = 'application']//jp:date" />
            <xsl:apply-templates select="jp:file-reference-id" />
            <xsl:apply-templates select="jp:receipt-number" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:notice-contents-group 届出の内容
         ====================================================================-->
    <xsl:template match="jp:notice-contents-group">
        <xsl:variable name="node0">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:variable name="jp-tag">
                <xsl:choose>
                    <xsl:when test="$node0 = 'jp:applicant-a55'">
                        <xsl:value-of select="'【申立の内容】　　'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:etcetera-a601'">
                        <xsl:value-of select="'【請求の内容】　　'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:etcetera-a821' or $node0 = 'jp:payment-r220'">
                        <xsl:value-of select="'【補足の内容】　　'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:etcetera-a831'">
                        <xsl:value-of select="'【提出の理由】　　'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:etcetera-a623' or $node0 = 'jp:etcetera-a624'">
                        <xsl:value-of select="'【評価の請求に係る請求項の表示】'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:application-a631'">
                        <xsl:value-of select="'【確認事項】　　　'" />
                    </xsl:when>
                    <xsl:when
                        test="$node0 = 'jp:application-a632' or $node0 = 'jp:application-a635'
                            or $node0 = 'jp:amendment-a526' or $node0 = 'jp:amendment-a528'
                            or $node0 = 'jp:amendment-a5210' or $node0 = 'jp:amendment-a5212'">
                        <xsl:value-of select="'【職権作成の表示】　'" />
                    </xsl:when>
                    <xsl:when test="$node0 = 'jp:etcetera-a603'">
                        <xsl:value-of select="'【請求の内容】　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【届出の内容】　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:variable>

            <xsl:choose>
                <xsl:when test="not(ancestor::jp:contents-of-amendment)">
                    <xsl:call-template name="space-suffix">
                        <xsl:with-param name="str" as="xs:string" select="$jp-tag" />
                        <xsl:with-param name="length" as="xs:integer" select="11" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$jp-tag" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:date 日付
         <xsl:template name="日付編集">
         ====================================================================-->
    <xsl:template match="jp:date">
        <xsl:element name="div">
            <xsl:call-template name="日付タイトル" />

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:when test="string-length(normalize-space(.)) = 0">
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="日付変換" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         日付タイトル
         ====================================================================-->
    <xsl:template name="日付タイトル">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="parent::jp:submission-date">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="$node" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:choose>
                                <xsl:when
                                    test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                                    <xsl:value-of
                                        select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:value-of
                                        select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="$node" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="kindlaw">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$kind-of-law" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="paym">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$payment" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <xsl:when test="parent::jp:submission-date">
                <xsl:choose>
                    <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                        <xsl:choose>
                            <xsl:when test="ancestor::jp:contents-of-amendment">
                                <xsl:value-of select="'　　【訂正対象書類提出日】　'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:if test="ancestor::jp:amendment-group/jp:submission-date">
                                    <xsl:value-of select="'　【訂正対象書類提出日】　'" />
                                </xsl:if>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:contents-of-amendment/jp:amendment-group/jp:submission-date">
                        <xsl:value-of select="'　　【補正対象書類提出日】　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:amendment-group/jp:submission-date">
                        <xsl:value-of select="'　【補正対象書類提出日】　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:target-document/jp:submission-date">
                        <xsl:value-of select="'　　【提出日】　　　　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【提出日】　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【提出日】　　　　　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>

            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'application']">
                <xsl:choose>
                    <xsl:when
                        test="(ancestor::jp:indication-of-case-article)
                            and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                or $node = 'jp:demand-e854' or $node = 'jp:demand-e862')
                            and not(ancestor::jp:contents-of-amendment)">
                        <xsl:value-of select="'【出願日】　　　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　【出願日】　　　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'international-application']">
                <xsl:choose>
                    <xsl:when
                        test="(ancestor::jp:indication-of-case-article)
                            and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                or $node = 'jp:demand-e854' or $node = 'jp:demand-e862')
                            and not(ancestor::jp:contents-of-amendment)">
                        <xsl:value-of select="'【国際出願日】　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　【国際出願日】　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'registration']">
                <xsl:value-of select="'　　【登録日】　　　　'" />
            </xsl:when>
            <xsl:when test="ancestor::jp:priority-claim">
                <xsl:value-of select="'　　【出願日】　　　　'" />
            </xsl:when>

            <xsl:when test="ancestor::jp:appeal-reference">
                <xsl:choose>
                    <xsl:when
                        test="(ancestor::jp:indication-of-case-article)
                            and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                or $node = 'jp:demand-e854' or $node = 'jp:demand-e862')
                            and not(ancestor::jp:contents-of-amendment)">
                        <xsl:value-of select="'【審判請求日】　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　【審判請求日】　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>

            <xsl:when test="ancestor::jp:dispatch-date">
                <xsl:choose>
                    <xsl:when test="$paym = 'jp:payment-'">
                        <xsl:if test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:choose>
                            <xsl:when test="$kindlaw = 'patent'">
                                <xsl:value-of select="'【特許査定の謄本発送日】　'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'【登録査定の謄本発送日】　'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when test="ancestor::jp:contents-of-amendment">
                                <xsl:value-of select="'　　【発送日】　　　　'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'【発送日】　　　　　　'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>

            <xsl:otherwise>
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="ancestor::jp:submit-date-of-amendment">
                        <xsl:value-of select="'【補正書の提出年月日】　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:notice-filing-date">
                        <xsl:value-of select="'【出願番号通知の出願日】　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:proof-filing-date">
                        <xsl:value-of select="'【証明しようとする出願日】　'" />
                    </xsl:when>
                    <xsl:when test="ancestor::jp:receipt-date">
                        <xsl:value-of select="'【１９条補正のＷＩＰＯ受領日】　'" />
                    </xsl:when>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         日付変換
         ====================================================================-->
    <xsl:template name="日付変換">
        <xsl:variable name="date-str" as="xs:string" select="normalize-space(.)" />
        <xsl:variable name="law" select="ancestor::jp:application-reference/@jp:kind-of-law" />

        <xsl:choose>
            <xsl:when test="ancestor::jp:priority-claim and string-length($date-str) = 8">
                <xsl:value-of select="substring($date-str, 1, 4) || '年'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="gengo">
                    <xsl:with-param name="date" select="normalize-space(.)" />
                </xsl:call-template>
                <xsl:call-template name="warekinen">
                    <xsl:with-param name="date" select="normalize-space(.)" />
                </xsl:call-template>
                <xsl:value-of select="'年'" />
            </xsl:otherwise>
        </xsl:choose>
        <xsl:if test="string-length($date-str) = 8">
            <xsl:value-of select="substring($date-str, 5, 2) || '月'" />
            <xsl:value-of select="substring($date-str, 7, 2) || '日'" />
        </xsl:if>
        <xsl:if
            test="(ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'application'])
                and ((ancestor::jp:parent-application-article and
                        not(ancestor::jp:parent-application-article [@jp:kind-of-application = 'based-on-utility']))
                    or ancestor::jp:declaration-priority-ear-app
                    or ancestor::jp:indication-of-case-article)">
            <xsl:value-of select="'提出の'" />
            <xsl:choose>
                <xsl:when test="$law = 'patent'">
                    <xsl:value-of select="'特許願'" />
                </xsl:when>
                <xsl:when test="$law = 'utility'">
                    <xsl:value-of select="'実用新案登録願'" />
                </xsl:when>
                <xsl:when test="$law = 'design'">
                    <xsl:value-of select="'意匠登録願'" />
                </xsl:when>
                <xsl:when test="$law = 'trademark'">
                    <xsl:value-of select="'商標登録願'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="書誌編集エラー処理" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:if>
        <xsl:if
            test="ancestor::jp:application-reference
                and ancestor::jp:application-reference [@appl-type = 'international-application']">
            <xsl:value-of select="'提出'" />
        </xsl:if>

    </xsl:template>


    <!-- ====================================================================
         jp:document-code
         ====================================================================-->
    <!-- 書類識別コード -->
    <xsl:template match="jp:document-code">
        <xsl:element name="div">
            <xsl:call-template name="書類名タイトル" />
            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="書類名変換" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         書類名タイトル
         ====================================================================-->
    <xsl:template name="書類名タイトル">

        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <xsl:when test="parent::jp:amendment-charge-article">
                <xsl:value-of select="'　　【補正対象書類名】　'" />
            </xsl:when>
            <xsl:when test="parent::jp:target-document">
                <xsl:value-of select="'　　【書類名】　　　　'" />
            </xsl:when>
            <xsl:when test="parent::jp:amendment-group">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                        <xsl:value-of select="'　【訂正対象書類名】　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　【補正対象書類名】　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　【書類名】　　　　'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【書類名】　　　　　　'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         書類名変換
         ====================================================================-->
    <xsl:template name="書類名変換">
        <xsl:choose>
            <xsl:when test="parent::jp:amendment-group">
                <xsl:call-template name="書類名振り分け">
                    <xsl:with-param name="code"
                        select="normalize-space(parent::jp:amendment-group/jp:document-code)" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="parent::jp:contents-of-amendment">
                <xsl:call-template name="書類名振り分け">
                    <xsl:with-param name="code"
                        select="normalize-space(parent::jp:contents-of-amendment/jp:document-code)" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="parent::jp:amendment-charge-article">
                <xsl:call-template name="書類名振り分け">
                    <xsl:with-param name="code"
                        select="normalize-space(parent::jp:amendment-charge-article/jp:document-code)" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="parent::jp:target-document">
                <xsl:call-template name="書類名振り分け">
                    <xsl:with-param name="code"
                        select="normalize-space(parent::jp:target-document/jp:document-code)" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書類名振り分け">
                    <xsl:with-param name="code" select="normalize-space($doc-code)" />
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         書類名振り分け
         ====================================================================-->
    <xsl:template name="書類名振り分け">
        <xsl:param name="code" />
        <xsl:choose>
            <xsl:when test="substring($code,1,1) = 'A' ">
                <xsl:call-template name="書類名出願">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="substring($code,1,1) = 'R' ">
                <xsl:call-template name="書類名登録">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="substring($code,1,1) = 'E' ">
                <xsl:call-template name="書類名請求">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="substring($code,1,1) = 'C' ">
                <xsl:call-template name="書類名審判">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         書類名出願（Ａで始まる書類識別コード）
         ====================================================================-->
    <xsl:template name="書類名出願">
        <xsl:param name="code" />
        <xsl:variable name="doc-name">
            <xsl:choose>
                <xsl:when test="$kind-of-law = 'patent'">
                    <xsl:value-of select="key('item-use-key', $code, $a-doc-code-patent)[1]/@value" />
                </xsl:when>
                <xsl:when test="$kind-of-law = 'utility'">
                    <xsl:value-of select="key('item-use-key', $code, $a-doc-code-utility)[1]/@value" />
                </xsl:when>
                <xsl:when test="$kind-of-law = 'design'">
                    <xsl:value-of select="key('item-use-key', $code, $a-doc-code-design)[1]/@value" />
                </xsl:when>
                <xsl:when test="$kind-of-law = 'trademark'">
                    <xsl:value-of
                        select="key('item-use-key', $code, $a-doc-code-trademark)[1]/@value" />
                </xsl:when>
            </xsl:choose>
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="string-length($doc-name) = 0">
                <xsl:value-of select="'***エラー***'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$doc-name" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="a-doc-code-patent">
        <item key="A151" value="手続補正書（方式）" />
        <item key="A1521" value="手続補正書" />
        <item key="A1522" value="手続補正書" />
        <item key="A1523" value="手続補正書" />
        <item key="A15210" value="特許協力条約第３４条補正の翻訳文提出書（職権）" />
        <item key="A15211" value="特許協力条約第３４条補正の写し提出書" />
        <item key="A15212" value="特許協力条約第３４条補正の写し提出書（職権）" />
        <item key="A1524" value="誤訳訂正書" />
        <item key="A1525" value="特許協力条約第１９条補正の翻訳文提出書" />
        <item key="A1526" value="特許協力条約第１９条補正の翻訳文提出書（職権）" />
        <item key="A1527" value="特許協力条約第１９条補正の写し提出書" />
        <item key="A1528" value="特許協力条約第１９条補正の写し提出書（職権）" />
        <item key="A1529" value="特許協力条約第３４条補正の翻訳文提出書" />
        <item key="A153" value="意見書" />
        <item key="A155" value="受継申立書" />
        <item key="A159" value="弁明書" />
        <item key="A1601" value="期間延長請求書" />
        <item key="A1621" value="出願審査請求書" />
        <item key="A1625" value="出願審査請求書（他人）" />
        <item key="A1627" value="出願公開請求書" />
        <item key="A163" value="特許願" />
        <item key="A1631" value="翻訳文提出書" />
        <item key="A1632" value="国内書面" />
        <item key="A1634" value="国際出願翻訳文提出書" />
        <item key="A1635" value="国際出願翻訳文提出書（職権）" />
        <item key="A167" value="受託番号変更届" />
        <item key="A1681" value="代表者選定届" />
        <item key="A1691" value="雑書類" />
        <item key="A1711" value="出願人名義変更届" />
        <item key="A1712" value="出願人名義変更届（一般承継）" />
        <item key="A17421" value="代理人変更届" />
        <item key="A17422" value="代理人受任届" />
        <item key="A17423" value="代理人選任届" />
        <item key="A17424" value="代理人辞任届" />
        <item key="A17425" value="代理人解任届" />
        <item key="A17426" value="代理権変更届" />
        <item key="A17427" value="代理権消滅届" />
        <item key="A17428" value="包括委任状援用制限届" />
        <item key="A17431" value="復代理人変更届" />
        <item key="A17432" value="復代理人受任届" />
        <item key="A17433" value="復代理人選任届" />
        <item key="A17434" value="復代理人辞任届" />
        <item key="A17435" value="復代理人解任届" />
        <item key="A17436" value="復代理権変更届" />
        <item key="A17437" value="復代理権消滅届" />
        <item key="A1761" value="出願取下書" />
        <item key="A1762" value="出願放棄書" />
        <item key="A1764" value="先の出願に基づく優先権主張取下書" />
        <item key="A1765" value="パリ条約による優先権主張放棄書" />
        <item key="A1781" value="上申書" />
        <item key="A179" value="優先権証明書提出書" />
        <item key="A180" value="新規性の喪失の例外証明書提出書" />
        <item key="A1801" value="新規性喪失の例外適用申請書" />
        <item key="A181" value="出願日証明書提出書" />
        <item key="A182" value="物件提出書" />
        <item key="A1821" value="手続補足書" />
        <item key="A1822" value="証明書類提出書" />
        <item key="A1831" value="刊行物等提出書" />
        <item key="A187" value="優先審査に関する事情説明書" />
        <item key="A1871" value="早期審査に関する事情説明書" />
        <item key="A1872" value="早期審査に関する事情説明補充書" />
        <item key="A1IB101" value="国際出願の写し" />
        <item key="A1IB101J" value="国際出願の願書の写し" />
        <item key="A1IB210" value="国際調査報告" />
        <item key="A1IB21J" value="国際調査報告（日本語）" />
        <item key="A1IB304" value="優先権主張の書類提出に関する通知" />
        <item key="A1IB305" value="先の出願番号の遅れた提出の通知" />
        <item key="A1IB306" value="記録の変更通知" />
        <item key="A1IB307" value="国際出願又は指定の取り下げの通知" />
        <item key="A1IB310" value="送達書類に関する通知（その他雑通知等）" />
        <item key="A1IB317" value="優先権に関する取下の通知" />
        <item key="A1IB31A" value="優先権書類" />
        <item key="A1IB31B" value="条約１９条補正" />
        <item key="A1IB31B1" value="条約１９条補正（職権）" />
        <item key="A1IB31C" value="条約３４条補正" />
        <item key="A1IB31C1" value="条約３４条補正（職権）" />
        <item key="A1IB31E" value="国際予備審査報告（日本語／英語以外の言語）" />
        <item key="A1IB31J" value="国際予備審査報告（日本語）" />
        <item key="A1IB324" value="指定が取り下げられたものとみなす旨の通知" />
        <item key="A1IB325" value="国際出願が取り下げられたものとみなす通知" />
        <item key="A1IB331" value="選択の通知" />
        <item key="A1IB334" value="後にする選択の届出が提出・選択無とみなす通知" />
        <item key="A1IB338" value="国際予備審査報告（英語）" />
        <item key="A1IB339" value="予備審査請求又は選択の取り下げの通知" />
        <item key="A1IB345" value="他に使用すべき様式がない場合の通知" />
        <item key="A1IB349" value="国際公開" />
        <item key="A1IB3491" value="日本語国際公開（職権）" />
        <item key="A1IB3492" value="外国語国際公開図面（職権）" />
        <item key="A1IB3493" value="外国語国際公開配列表（職権）" />
        <item key="A1IB350" value="予備審査請求書の提出又は選択無とみなす通知" />
        <item key="A1IB500" value="ＩＢ回答書" />
        <item key="A1IBC101" value="訂正／国際出願の写し" />
        <item key="A1IBC210" value="訂正／国際調査報告" />
        <item key="A1IBC21J" value="訂正／国際調査報告（日本語）" />
        <item key="A1IBC304" value="訂正／優先権主張の書類提出に関する通知" />
        <item key="A1IBC305" value="訂正／先の出願番号の遅れた提出の通知" />
        <item key="A1IBC306" value="訂正／記録の変更通知" />
        <item key="A1IBC307" value="訂正／国際出願又は指定の取り下げの通知" />
        <item key="A1IBC310" value="訂正／送達書類に関する通知（その他雑通知等）" />
        <item key="A1IBC317" value="訂正／優先権に関する取下の通知" />
        <item key="A1IBC31A" value="訂正／優先権書類" />
        <item key="A1IBC31B" value="訂正／条約１９条補正" />
        <item key="A1IBC31C" value="訂正／条約３４条補正" />
        <item key="A1IBC31E" value="訂正／国際予備審査報告（日本語／英語以外の言語）" />
        <item key="A1IBC31J" value="訂正／国際予備審査報告（日本語）" />
        <item key="A1IBC324" value="訂正／指定が取り下げられたものとみなす旨の通知" />
        <item key="A1IBC325" value="訂正／国際出願が取り下げられたものとみなす通知" />
        <item key="A1IBC331" value="訂正／選択の通知" />
        <item key="A1IBC334" value="訂正／後にする選択の届出が提出・選択無とみなす通知" />
        <item key="A1IBC338" value="訂正／国際予備審査報告（英語）" />
        <item key="A1IBC339" value="訂正／予備審査請求又は選択の取り下げの通知" />
        <item key="A1IBC345" value="訂正／他に使用すべき様式がない場合の通知" />
        <item key="A1IBC349" value="訂正／国際公開" />
        <item key="A1IBC350" value="訂正／予備審査請求書の提出又は選択無とみなす通知" />
        <item key="A1IB318" value="優先権主張に関する通知" />
        <item key="A1IB335" value="指定または選択の取り消しの通知" />
        <item key="A1IB346" value="請求の範囲の補正書の提出に関する通知" />
        <item key="A1IB369" value="予備審査請求がされなかった旨の通知" />
        <item key="A1IB373" value="特許性に関する国際予備報告（第Ｉ章）" />
        <item key="A1IB374" value="国際調査機関の見解の翻訳の写しの送付通知" />
        <item key="A1IB399" value="国際出願経過情報様式" />
        <item key="A1IB3494" value="日本語国際公開要約図（職権）" />
        <item key="A1IB3495" value="外国語国際公開要約図（職権）" />
        <item key="A1IB3731" value="非公式コメント" />
        <item key="A1IB501" value="補充国際調査報告" />
        <item key="A1IB502" value="補充国際調査報告を作成しない旨の決定" />
        <item key="A16330" value="明細書" />
        <item key="A16331" value="図面" />
        <item key="A16332" value="要約書" />
        <item key="A16333" value="特許請求の範囲" />
        <item key="A1914" value="出願審査請求手数料返還請求書" />
        <item key="A1915" value="既納手数料返還請求書" />
        <item key="A1916" value="世界知的所有権機関へのアクセスコード付与請求書" />
        <item key="A1603" value="期間延長請求書（期間徒過）" />
        <item key="A1917" value="回復理由書" />
        <item key="A1918" value="保全審査に付することを求める申出書" />
        <item key="A1919" value="不送付通知申出書" />
    </xsl:variable>

    <xsl:variable name="a-doc-code-utility">
        <item key="A251" value="'手続補正書（方式）'" />
        <item key="A2521" value="'手続補正書'" />
        <item key="A2522" value="'手続補正書'" />
        <item key="A2523" value="'手続補正書'" />
        <item key="A25210'" value="'特許協力条約第３４条補正の翻訳文提出書（職権）'" />
        <item key="A25211'" value="'特許協力条約第３４条補正の写し提出書'" />
        <item key="A25212'" value="'特許協力条約第３４条補正の写し提出書（職権）'" />
        <item key="A2524'" value="'誤訳訂正書'" />
        <item key="A2525'" value="'特許協力条約第１９条補正の翻訳文提出書'" />
        <item key="A2526'" value="'特許協力条約第１９条補正の翻訳文提出書（職権）'" />
        <item key="A2527'" value="'特許協力条約第１９条補正の写し提出書'" />
        <item key="A2528'" value="'特許協力条約第１９条補正の写し提出書（職権）'" />
        <item key="A2529'" value="'特許協力条約第３４条補正の翻訳文提出書'" />
        <item key="A253" value="'意見書'" />
        <item key="A255" value="'受継申立書'" />
        <item key="A259" value="'弁明書'" />
        <item key="A2601" value="'期間延長請求書'" />
        <item key="A2621'" value="'出願審査請求書'" />
        <item key="A2623'" value="'実用新案技術評価請求書'" />
        <item key="A2625'" value="'出願審査請求書（他人）'" />
        <item key="A2626'" value="'国内処理請求書'" />
        <item key="A263'" value="'実用新案登録願'" />
        <item key="A2632'" value="'国内書面'" />
        <item key="A2633'" value="'図面の提出書'" />
        <item key="A2634'" value="'国際出願翻訳文提出書'" />
        <item key="A2635'" value="'国際出願翻訳文提出書（職権）'" />
        <item key="A2681" value="'代表者選定届'" />
        <item key="A2691" value="'雑書類'" />
        <item key="A2711" value="'出願人名義変更届'" />
        <item key="A2712" value="'出願人名義変更届（一般承継）'" />
        <item key="A27421" value="'代理人変更届'" />
        <item key="A27422" value="'代理人受任届'" />
        <item key="A27423" value="'代理人選任届'" />
        <item key="A27424" value="'代理人辞任届'" />
        <item key="A27425" value="'代理人解任届'" />
        <item key="A27426" value="'代理権変更届'" />
        <item key="A27427" value="'代理権消滅届'" />
        <item key="A27428" value="'包括委任状援用制限届'" />
        <item key="A27431" value="'復代理人変更届'" />
        <item key="A27432" value="'復代理人受任届'" />
        <item key="A27433" value="'復代理人選任届'" />
        <item key="A27434" value="'復代理人辞任届'" />
        <item key="A27435" value="'復代理人解任届'" />
        <item key="A27436" value="'復代理権変更届'" />
        <item key="A27437" value="'復代理権消滅届'" />
        <item key="A2761'" value="'出願取下書'" />
        <item key="A2762'" value="'出願放棄書'" />
        <item key="A2764'" value="'先の出願に基づく優先権主張取下書'" />
        <item key="A2765" value="'パリ条約による優先権主張放棄書'" />
        <item key="A2781" value="'上申書'" />
        <item key="A279" value="'優先権証明書提出書'" />
        <item key="A280" value="'新規性の喪失の例外証明書提出書'" />
        <item key="A2801'" value="'新規性喪失の例外適用申請書'" />
        <item key="'A281'" value="'出願日証明書提出書'" />
        <item key="'A282'" value="'物件提出書'" />
        <item key="'A2821'" value="'手続補足書'" />
        <item key="'A2822'" value="'証明書類提出書'" />
        <item key="A2831'" value="'刊行物等提出書'" />
        <item key="A287'" value="'優先審査に関する事情説明書'" />
        <item key="A2871" value="'早期審査に関する事情説明書'" />
        <item key="A2872" value="'早期審査に関する事情説明補充書'" />
        <item key="'A2IB101'" value="'国際出願の写し'" />
        <item key="'A2IB101J'" value="'国際出願の願書の写し'" />
        <item key="'A2IB210'" value="'国際調査報告'" />
        <item key="'A2IB21J'" value="'国際調査報告（日本語）'" />
        <item key="'A2IB304'" value="'優先権主張の書類提出に関する通知'" />
        <item key="'A2IB305'" value="'先の出願番号の遅れた提出の通知'" />
        <item key="'A2IB306'" value="'記録の変更通知'" />
        <item key="'A2IB307'" value="'国際出願又は指定の取り下げの通知'" />
        <item key="'A2IB310'" value="'送達書類に関する通知（その他雑通知等）'" />
        <item key="'A2IB317'" value="'優先権に関する取下の通知'" />
        <item key="'A2IB31A'" value="'優先権書類'" />
        <item key="'A2IB31B'" value="'条約１９条補正'" />
        <item key="'A2IB31B1'" value="'条約１９条補正（職権）'" />
        <item key="'A2IB31C'" value="'条約３４条補正'" />
        <item key="'A2IB31C1'" value="'条約３４条補正（職権）'" />
        <item key="'A2IB31E'" value="'国際予備審査報告（日本語／英語以外の言語）'" />
        <item key="'A2IB31J'" value="'国際予備審査報告（日本語）'" />
        <item key="'A2IB324'" value="'指定が取り下げられたものとみなす旨の通知'" />
        <item key="'A2IB325'" value="'国際出願が取り下げられたものとみなす通知'" />
        <item key="'A2IB331'" value="'選択の通知'" />
        <item key="'A2IB334'" value="'後にする選択の届出が提出・選択無とみなす通知'" />
        <item key="'A2IB338'" value="'国際予備審査報告（英語）'" />
        <item key="'A2IB339'" value="'予備審査請求又は選択の取り下げの通知'" />
        <item key="'A2IB345'" value="'他に使用すべき様式がない場合の通知'" />
        <item key="'A2IB349'" value="'国際公開'" />
        <item key="'A2IB3491'" value="'日本語国際公開（職権）'" />
        <item key="'A2IB3492'" value="'外国語国際公開図面（職権）'" />
        <item key="'A2IB3493'" value="'外国語国際公開配列表（職権）'" />
        <item key="'A2IB350'" value="'予備審査請求書の提出又は選択無とみなす通知'" />
        <item key="'A2IB500'" value="'ＩＢ回答書'" />
        <item key="'A2IBC101'" value="'訂正／国際出願の写し'" />
        <item key="'A2IBC210'" value="'訂正／国際調査報告'" />
        <item key="'A2IBC21J'" value="'訂正／国際調査報告（日本語）'" />
        <item key="'A2IBC304'" value="'訂正／優先権主張の書類提出に関する通知'" />
        <item key="'A2IBC305'" value="'訂正／先の出願番号の遅れた提出の通知'" />
        <item key="'A2IBC306'" value="'訂正／記録の変更通知'" />
        <item key="'A2IBC307'" value="'訂正／国際出願又は指定の取り下げの通知'" />
        <item key="'A2IBC310'" value="'訂正／送達書類に関する通知（その他雑通知等）'" />
        <item key="'A2IBC317'" value="'訂正／優先権に関する取下の通知'" />
        <item key="'A2IBC31A'" value="'訂正／優先権書類'" />
        <item key="'A2IBC31B'" value="'訂正／条約１９条補正'" />
        <item key="'A2IBC31C'" value="'訂正／条約３４条補正'" />
        <item key="'A2IBC31E'" value="'訂正／国際予備審査報告（日本語／英語以外の言語）'" />
        <item key="'A2IBC31J'" value="'訂正／国際予備審査報告（日本語）'" />
        <item key="'A2IBC324'" value="'訂正／指定が取り下げられたものとみなす旨の通知'" />
        <item key="'A2IBC325'" value="'訂正／国際出願が取り下げられたものとみなす通知'" />
        <item key="'A2IBC331'" value="'訂正／選択の通知'" />
        <item key="'A2IBC334'" value="'訂正／後にする選択の届出が提出・選択無とみなす通知'" />
        <item key="'A2IBC338'" value="'訂正／国際予備審査報告（英語）'" />
        <item key="'A2IBC339'" value="'訂正／予備審査請求又は選択の取り下げの通知'" />
        <item key="'A2IBC345'" value="'訂正／他に使用すべき様式がない場合の通知'" />
        <item key="'A2IBC349'" value="'訂正／国際公開'" />
        <item key="'A2IBC350'" value="'訂正／予備審査請求書の提出又は選択無とみなす通知'" />
        <item key="'A2IB318'" value="'優先権主張に関する通知'" />
        <item key="'A2IB335'" value="'指定または選択の取り消しの通知'" />
        <item key="'A2IB346'" value="'請求の範囲の補正書の提出に関する通知'" />
        <item key="'A2IB369'" value="'予備審査請求がされなかった旨の通知'" />
        <item key="'A2IB373'" value="'特許性に関する国際予備報告（第Ｉ章）'" />
        <item key="'A2IB374'" value="'国際調査機関の見解の翻訳の写しの送付通知'" />
        <item key="'A2IB399'" value="'国際出願経過情報様式'" />
        <item key="'A2IB3494'" value="'日本語国際公開要約図（職権）'" />
        <item key="'A2IB3495'" value="'外国語国際公開要約図（職権）'" />
        <item key="'A2IB3731'" value="'非公式コメント'" />
        <item key="'A2IB501'" value="'補充国際調査報告'" />
        <item key="'A2IB502'" value="'補充国際調査報告を作成しない旨の決定'" />
        <item key="'A26330'" value="'明細書'" />
        <item key="'A26331'" value="'図面'" />
        <item key="'A26332'" value="'要約書'" />
        <item key="A26333'" value="'実用新案登録請求の範囲'" />
        <item key="A2915'" value="'既納手数料（登録料）返還請求書'" />
        <item key="A2624'" value="'実用新案技術評価請求書（他人）'" />
        <item key="A2916'" value="'世界知的所有権機関へのアクセスコード付与請求書'" />
        <item key="A2603'" value="'期間延長請求書（期間徒過）'" />
        <item key="A2917" value="'回復理由書'" />
    </xsl:variable>

    <xsl:variable name="a-doc-code-design">
        <item key="A351" value="'手続補正書（方式）'" />
        <item key="A3523" value="'手続補正書'" />
        <item key="A35231'" value="'手続補正書（複数）'" />
        <item key="A353" value="'意見書'" />
        <item key="A355" value="'受継申立書'" />
        <item key="A359" value="'弁明書'" />
        <item key="A3601" value="'期間延長請求書'" />
        <item key="A363'" value="'意匠登録願'" />
        <item key="A3630'" value="'意匠登録願（複数）'" />
        <item key="A3636'" value="'類似意匠登録願'" />
        <item key="A3681" value="'代表者選定届'" />
        <item key="A3691" value="'雑書類'" />
        <item key="A3711" value="'出願人名義変更届'" />
        <item key="A3712" value="'出願人名義変更届（一般承継）'" />
        <item key="A37421" value="'代理人変更届'" />
        <item key="A37422" value="'代理人受任届'" />
        <item key="A37423" value="'代理人選任届'" />
        <item key="A37424" value="'代理人辞任届'" />
        <item key="A37425" value="'代理人解任届'" />
        <item key="A37426" value="'代理権変更届'" />
        <item key="A37427" value="'代理権消滅届'" />
        <item key="A37428" value="'包括委任状援用制限届'" />
        <item key="A37431" value="'復代理人変更届'" />
        <item key="A37432" value="'復代理人受任届'" />
        <item key="A37433" value="'復代理人選任届'" />
        <item key="A37434" value="'復代理人辞任届'" />
        <item key="A37435" value="'復代理人解任届'" />
        <item key="A37436" value="'復代理権変更届'" />
        <item key="A37437" value="'復代理権消滅届'" />
        <item key="A3761" value="'出願取下書'" />
        <item key="A3762" value="'出願放棄書'" />
        <item key="A3765" value="'パリ条約による優先権主張放棄書'" />
        <item key="A37731'" value="'出願変更届（独立→類似）'" />
        <item key="A37732'" value="'出願変更届（類似→独立）'" />
        <item key="A3781" value="'上申書'" />
        <item key="A379" value="'優先権証明書提出書'" />
        <item key="A380" value="'新規性の喪失の例外証明書提出書'" />
        <item key="'A381'" value="'出願日証明書提出書'" />
        <item key="'A382'" value="'物件提出書'" />
        <item key="'A3821" value="'手続補足書'" />
        <item key="'A3822" value="'証明書類提出書'" />
        <item key="A3824'" value="'ひな形又は見本補足書'" />
        <item key="A3833'" value="'特徴記載書'" />
        <item key="A3826'" value="'意匠法第９条第５項に基づく協議の結果届'" />
        <item key="'A3871'" value="'早期審査に関する事情説明書'" />
        <item key="'A3872'" value="'早期審査に関する事情説明補充書'" />
        <item key="A3907'" value="'秘密意匠期間変更請求書'" />
        <item key="A3915" value="'既納手数料返還請求書'" />
        <item key="A3603" value="'期間延長請求書（期間徒過）'" />
        <item key="A3917'" value="'回復理由書'" />
    </xsl:variable>

    <xsl:variable name="a-doc-code-trademark">
        <item key="A451" value="'手続補正書（方式）'" />
        <item key="A4523'" value="'手続補正書'" />
        <item key="A453'" value="'意見書'" />
        <item key="A455'" value="'受継申立書'" />
        <item key="A459'" value="'弁明書'" />
        <item key="A4601'" value="'期間延長請求書'" />
        <item key="A463'" value="'商標登録願'" />
        <item key="A4639'" value="'団体商標登録願'" />
        <item key="A4632'" value="'防護標章登録願'" />
        <item key="A4633'" value="'防護標章登録に基づく権利存続期間更新登録願'" />
        <item key="A4634'" value="'書換登録申請書'" />
        <item key="A46341'" value="'外国語図面'" />
        <item key="A46342'" value="'外国語要約書'" />
        <item key="A4635'" value="'防護標章登録に基づく権利書換登録申請書'" />
        <item key="A4637'" value="'重複登録商標に係る商標権存続期間更新登録願'" />
        <item key="A4638'" value="'地域団体商標登録願'" />
        <item key="A4681'" value="'代表者選定届'" />
        <item key="A4691'" value="'雑書類'" />
        <item key="A4711'" value="'出願人名義変更届'" />
        <item key="A4712'" value="'出願人名義変更届（一般承継）'" />
        <item key="A4713'" value="'出願人名義変更届（特例商標登録出願）'" />
        <item key="A4714'" value="'出願人名義変更届（特例商標登録出願）（一般承継）'" />
        <item key="A4715'" value="'書換登録申請者名義変更届'" />
        <item key="A47421'" value="'代理人変更届'" />
        <item key="A47422'" value="'代理人受任届'" />
        <item key="A47423'" value="'代理人選任届'" />
        <item key="A47424'" value="'代理人辞任届'" />
        <item key="A47425'" value="'代理人解任届'" />
        <item key="A47426'" value="'代理権変更届'" />
        <item key="A47427'" value="'代理権消滅届'" />
        <item key="A47428'" value="'包括委任状援用制限届'" />
        <item key="A47431'" value="'復代理人変更届'" />
        <item key="A47432'" value="'復代理人受任届'" />
        <item key="A47433'" value="'復代理人選任届'" />
        <item key="A47434'" value="'復代理人辞任届'" />
        <item key="A47435'" value="'復代理人解任届'" />
        <item key="A47436'" value="'復代理権変更届'" />
        <item key="A47437'" value="'復代理権消滅届'" />
        <item key="A4761'" value="'出願取下書'" />
        <item key="A4762'" value="'出願放棄書'" />
        <item key="A4765'" value="'パリ条約による優先権主張放棄書'" />
        <item key="A4766'" value="'書換登録申請取下書'" />
        <item key="A4768'" value="'使用に基づく特例の適用の主張取下書'" />
        <item key="A4781'" value="'上申書'" />
        <item key="A479'" value="'優先権証明書提出書'" />
        <item key="A480'" value="'出願時の特例証明書提出書'" />
        <item key="A481'" value="'出願日証明書提出書'" />
        <item key="A482'" value="'物件提出書'" />
        <item key="'A4821'" value="'手続補足書'" />
        <item key="'A4822'" value="'証明書類提出書'" />
        <item key="A4831'" value="'刊行物等提出書'" />
        <item key="A4871'" value="'早期審査に関する事情説明書'" />
        <item key="A4872'" value="'早期審査に関する事情説明補充書'" />
        <item key="A4908'" value="'協議の結果届'" />
        <item key="A4915'" value="'既納手数料返還請求書'" />
        <item key="A4603'" value="'期間延長請求書（期間徒過）'" />
    </xsl:variable>

    <!-- ====================================================================
         書類名登録（Ｒで始まる書類識別コード）
         ====================================================================-->
    <xsl:template name="書類名登録">
        <xsl:param name="code" />
        <xsl:variable name="doc-name">
            <xsl:value-of select="key('item-use-key', $code, $r-doc-code)[1]/@value" />
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="string-length($doc-name) = 0">
                <xsl:value-of select="'***エラー***'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$doc-name" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="r-doc-code">
        <item key="R1100" value="特許料納付書" />
        <item key="R120" value="特許料納付書" />
        <item key="R2100" value="実用新案登録料納付書" />
        <item key="R220" value="実用新案登録料納付書" />
        <item key="R3100" value="意匠登録料納付書" />
        <item key="R320" value="意匠登録料納付書" />
        <item key="R4100" value="商標登録料納付書" />
        <item key="R4200" value="商標登録料納付書" />
        <item key="R1101" value="追加の特許の特許料納付書" />
        <item key="R3102" value="類似意匠登録料納付書" />
        <item key="R4103" value="防護標章登録料納付書" />
        <item key="R4104" value="商標更新登録料納付書" />
        <item key="R4105" value="防護標章更新登録料納付書" />
        <item key="R1110" value="特許料納付書（設定補充）" />
        <item key="R2110" value="実用新案登録料納付書（設定補充）" />
        <item key="R3110" value="意匠登録料納付書（設定補充）" />
        <item key="R4110" value="商標登録料納付書（設定補充）" />
        <item key="R1111" value="追加の特許の特許料納付書（設定補充）" />
        <item key="R3112" value="類似意匠登録料納付書（設定補充）" />
        <item key="R4113" value="防護標章登録料納付書（設定補充）" />
        <item key="R4114" value="商標更新登録料納付書（設定補充）" />
        <item key="R4115" value="防護標章更新登録料納付書（設定補充）" />
        <item key="R121" value="特許料納付書（補充）" />
        <item key="R221" value="実用新案登録料納付書（補充）" />
        <item key="R321" value="意匠登録料納付書（補充）" />
        <item key="R4210" value="商標登録料納付書（分納補充）" />
        <item key="R4201" value="商標権存続期間更新登録申請書" />
        <item key="R4211" value="商標権存続期間更新登録申請書（補充）" />
        <item key="R4220" value="手続補足書" />
    </xsl:variable>

    <!-- ====================================================================
         書類名請求（Ｅで始まる書類識別コード）
         ====================================================================-->
    <xsl:template name="書類名請求">
        <xsl:param name="code" />
        <xsl:variable name="doc-name">
            <xsl:value-of select="key('item-use-key', $code, $e-doc-code)[1]/@value" />
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="string-length($doc-name) = 0">
                <xsl:value-of select="'***エラー***'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$doc-name" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="e-doc-code">
        <item key="E1841" value="優先権証明請求書" />
        <item key="E2841" value="優先権証明請求書" />
        <item key="E1842" value="証明請求書" />
        <item key="E2842" value="証明請求書" />
        <item key="E1851" value="ファイル記録事項記載書類の交付請求書" />
        <item key="E2851" value="ファイル記録事項記載書類の交付請求書" />
        <item key="E1852" value="認証付ファイル記録事項記載書類の交付請求書" />
        <item key="E2852" value="認証付ファイル記録事項記載書類の交付請求書" />
        <item key="E1853" value="登録事項記載書類の交付請求書" />
        <item key="E2853" value="登録事項記載書類の交付請求書" />
        <item key="E3853" value="登録事項記載書類の交付請求書" />
        <item key="E4853" value="登録事項記載書類の交付請求書" />
        <item key="E1854" value="認証付登録事項記載書類の交付請求書" />
        <item key="E2854" value="認証付登録事項記載書類の交付請求書" />
        <item key="E3854" value="認証付登録事項記載書類の交付請求書" />
        <item key="E4854" value="認証付登録事項記載書類の交付請求書" />
        <item key="E1861" value="ファイル記録事項の閲覧（縦覧）請求書" />
        <item key="E2861" value="ファイル記録事項の閲覧（縦覧）請求書" />
        <item key="E1862" value="登録事項の閲覧請求書" />
        <item key="E2862" value="登録事項の閲覧請求書" />
        <item key="E3862" value="登録事項の閲覧請求書" />
        <item key="E4862" value="登録事項の閲覧請求書" />
    </xsl:variable>

    <!-- ====================================================================
         書類名審判（Ｃで始まる書類識別コード）
         ====================================================================-->
    <xsl:template name="書類名審判">
        <xsl:param name="code" />
        <xsl:variable name="doc-name">
            <xsl:value-of select="key('item-use-key', $code, $c-doc-code)[1]/@value" />
        </xsl:variable>
        <xsl:choose>
            <xsl:when test="string-length($doc-name) = 0">
                <xsl:value-of select="'***エラー***'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$doc-name" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="c-doc-code">
        <item key="C154" value="回答書" />
        <item key="C254" value="回答書" />
        <item key="C354" value="回答書" />
        <item key="C454" value="回答書" />

        <item key="C1561" value="異議申立書" />
        <item key="C2561" value="異議申立書" />
        <item key="C4561" value="異議申立書" />

        <item key="C157" value="答弁書" />
        <item key="C257" value="答弁書" />
        <item key="C357" value="答弁書" />
        <item key="C457" value="答弁書" />

        <item key="C158" value="弁駁書" />
        <item key="C258" value="弁駁書" />
        <item key="C358" value="弁駁書" />
        <item key="C458" value="弁駁書" />

        <item key="C160" value="審判請求書" />
        <item key="C260" value="審判請求書" />
        <item key="C360" value="審判請求書" />
        <item key="C460" value="審判請求書" />

        <item key="C1601" value="判定請求書" />
        <item key="C2601" value="判定請求書" />
        <item key="C3601" value="判定請求書" />
        <item key="C4601" value="判定請求書" />

        <item key="C1609" value="請求取下書" />
        <item key="C2609" value="請求取下書" />
        <item key="C3609" value="請求取下書" />
        <item key="C4609" value="請求取下書" />

        <item key="C16091" value="一部請求取下書" />
        <item key="C26091" value="一部請求取下書" />
        <item key="C36091" value="一部請求取下書" />
        <item key="C46091" value="一部請求取下書" />

        <item key="C1611" value="訂正請求書" />
        <item key="C2611" value="訂正請求書" />

        <item key="C1619" value="訂正請求取下書" />
        <item key="C2619" value="訂正請求取下書" />

        <item key="C164" value="審理再開申立書" />
        <item key="C264" value="審理再開申立書" />
        <item key="C364" value="審理再開申立書" />
        <item key="C464" value="審理再開申立書" />

        <item key="C16511" value="書面審理申立書" />
        <item key="C26511" value="書面審理申立書" />
        <item key="C36511" value="書面審理申立書" />
        <item key="C46511" value="書面審理申立書" />

        <item key="C16512" value="口頭審理申立書" />
        <item key="C26512" value="口頭審理申立書" />
        <item key="C36512" value="口頭審理申立書" />
        <item key="C46512" value="口頭審理申立書" />

        <item key="C16513" value="口頭審理陳述要領書" />
        <item key="C26513" value="口頭審理陳述要領書" />
        <item key="C36513" value="口頭審理陳述要領書" />
        <item key="C46513" value="口頭審理陳述要領書" />

        <item key="C16514" value="証拠申出書" />
        <item key="C26514" value="証拠申出書" />
        <item key="C36514" value="証拠申出書" />
        <item key="C46514" value="証拠申出書" />

        <item key="C16515" value="証拠説明書" />
        <item key="C26515" value="証拠説明書" />
        <item key="C36515" value="証拠説明書" />
        <item key="C46515" value="証拠説明書" />

        <item key="C16517" value="録音テープ等の内容説明書" />
        <item key="C26517" value="録音テープ等の内容説明書" />
        <item key="C36517" value="録音テープ等の内容説明書" />
        <item key="C46517" value="録音テープ等の内容説明書" />

        <item key="C1652" value="証拠調申立書" />
        <item key="C2652" value="証拠調申立書" />
        <item key="C3652" value="証拠調申立書" />
        <item key="C4652" value="証拠調申立書" />

        <item key="C16541" value="尋問事項書" />
        <item key="C26541" value="尋問事項書" />
        <item key="C36541" value="尋問事項書" />
        <item key="C46541" value="尋問事項書" />

        <item key="C1654" value="証人尋問申出書" />
        <item key="C2654" value="証人尋問申出書" />
        <item key="C3654" value="証人尋問申出書" />
        <item key="C4654" value="証人尋問申出書" />

        <item key="C16542" value="回答希望事項記載書面" />
        <item key="C26542" value="回答希望事項記載書面" />
        <item key="C36542" value="回答希望事項記載書面" />
        <item key="C46542" value="回答希望事項記載書面" />

        <item key="C16543" value="尋問に代わる書面の提出書" />
        <item key="C26543" value="尋問に代わる書面の提出書" />
        <item key="C36543" value="尋問に代わる書面の提出書" />
        <item key="C46543" value="尋問に代わる書面の提出書" />

        <item key="C16544" value="書証の申出書" />
        <item key="C26544" value="書証の申出書" />
        <item key="C36544" value="書証の申出書" />
        <item key="C46544" value="書証の申出書" />

        <item key="C16546" value="文書特定の申出書" />
        <item key="C26546" value="文書特定の申出書" />
        <item key="C36546" value="文書特定の申出書" />
        <item key="C46546" value="文書特定の申出書" />

        <item key="C1655" value="検証申出書" />
        <item key="C2655" value="検証申出書" />
        <item key="C3655" value="検証申出書" />
        <item key="C4655" value="検証申出書" />

        <item key="C1657" value="鑑定の申出書" />
        <item key="C2657" value="鑑定の申出書" />
        <item key="C3657" value="鑑定の申出書" />
        <item key="C4657" value="鑑定の申出書" />

        <item key="C16572" value="鑑定事項書" />
        <item key="C26572" value="鑑定事項書" />
        <item key="C36572" value="鑑定事項書" />
        <item key="C46572" value="鑑定事項書" />

        <item key="C16573" value="鑑定書" />
        <item key="C26573" value="鑑定書" />
        <item key="C36573" value="鑑定書" />
        <item key="C46573" value="鑑定書" />

        <item key="C1659" value="期日変更請求書" />
        <item key="C2659" value="期日変更請求書" />
        <item key="C3659" value="期日変更請求書" />
        <item key="C4659" value="期日変更請求書" />

        <item key="C16591" value="証拠調申請取下書" />
        <item key="C26591" value="証拠調申請取下書" />
        <item key="C36591" value="証拠調申請取下書" />
        <item key="C46591" value="証拠調申請取下書" />

        <item key="C16592" value="不出頭の届出書" />
        <item key="C26592" value="不出頭の届出書" />
        <item key="C36592C46592" value="不出頭の届出書" />
        <item key="C46592" value="不出頭の届出書" />

        <item key="C1661" value="異議取下書" />
        <item key="C2661" value="異議取下書" />
        <item key="C4661" value="異議取下書" />

        <item key="C1662" value="一部異議取下書" />
        <item key="C2662" value="一部異議取下書" />
        <item key="C4662" value="一部異議取下書" />

        <item key="C1875C2875" value="優先審理に関する事情説明書" />
        <item key="C2875" value="優先審理に関する事情説明書" />

        <item key="C1876" value="早期審理に関する事情説明書" />
        <item key="C2876" value="早期審理に関する事情説明書" />
        <item key="C3876C4876" value="早期審理に関する事情説明書" />
        <item key="C4876" value="早期審理に関する事情説明書" />

        <item key="C1877" value="早期審理に関する事情説明補充書" />
        <item key="C2877" value="早期審理に関する事情説明補充書" />
        <item key="C3877" value="早期審理に関する事情説明補充書" />
        <item key="C4877" value="早期審理に関する事情説明補充書" />
    </xsl:variable>


    <!-- ====================================================================
         文書番号編集
         <xsl:template name="文書番号編集">
         ====================================================================-->
    <xsl:template match="jp:doc-number">
        <xsl:variable name="law" select="ancestor::jp:application-reference/@jp:kind-of-law" />
        <xsl:element name="div">


            <xsl:choose>
                <xsl:when test="ancestor::jp:application-reference or ancestor::jp:appeal-reference">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:application-reference
                                and ancestor::jp:application-reference [@appl-type = 'registration']">
                            <xsl:choose>
                                <xsl:when
                                    test="ancestor::jp:indication-of-case-article
                                        and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                            or $node = 'jp:demand-e854' or $node = 'jp:demand-e862') ">
                                </xsl:when>
                                <xsl:when test="ancestor::jp:annexation-payment">
                                </xsl:when>
                                <xsl:when
                                    test="ancestor::jp:indication-of-case-article
                                        and ($node = 'jp:etcetera-a623' or $node = 'jp:etcetera-a624' or $node = 'jp:etcetera-a915')
                                        and $kind-of-law = 'utility'
                                        and string-length(normalize-space(ancestor::jp:application-reference/jp:document-id/jp:date)) = 0">
                                    <xsl:if
                                        test="//jp:application-reference/@appl-type != 'registration'">
                                        <xsl:value-of select="'　　'" />
                                    </xsl:if>
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:value-of select="'　　'" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:choose>
                                <xsl:when
                                    test="ancestor::jp:indication-of-case-article
                                        and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                            or $node = 'jp:demand-e854' or $node = 'jp:demand-e862') ">
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:value-of select="'　　'" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="ancestor::jp:application-reference">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:application-reference [@appl-type = 'application']">
                            <xsl:value-of select="'【出願番号】　　　'" />
                        </xsl:when>
                        <xsl:when
                            test="ancestor::jp:application-reference [@appl-type = 'international-application']">
                            <xsl:value-of select="'【国際出願番号】　'" />
                        </xsl:when>
                        <xsl:when
                            test="ancestor::jp:application-reference [@appl-type = 'registration']">
                            <xsl:choose>
                                <xsl:when test="$law = 'patent'">
                                    <xsl:value-of select="'【特許番号】　　　'" />
                                </xsl:when>
                                <xsl:when test="$law = 'utility'">
                                    <xsl:value-of select="'【実用新案登録番号】　'" />
                                </xsl:when>
                                <xsl:when test="$law = 'design'">
                                    <xsl:value-of select="'【意匠登録番号】　'" />
                                </xsl:when>
                                <xsl:when test="$law = 'trademark'">
                                    <xsl:value-of select="'【商標登録番号】　'" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:value-of select="'【登録番号】　　　'" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:when
                            test="ancestor::jp:application-reference [@appl-type = 'examined-pub']">
                            <xsl:value-of select="'【出願公告番号】　'" />
                        </xsl:when>
                        <xsl:when
                            test="ancestor::jp:application-reference [@appl-type = 'un-examined-pub']">
                            <xsl:value-of select="'【出願公開番号】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:when>
                <xsl:when test="ancestor::jp:appeal-reference">
                    <xsl:value-of select="'【審判番号】　　　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:priority-doc-location-info">
                    <xsl:value-of select="'　　【提供国（機関）における出願の番号】　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:priority-claim">
                    <xsl:value-of select="'　　【出願番号】　　　'" />
                </xsl:when>
            </xsl:choose>

            <xsl:choose>
                <xsl:when
                    test="ancestor::jp:application-reference or ancestor::jp:appeal-reference">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:application-reference
                                and ancestor::jp:application-reference [@appl-type = 'registration']">
                            <xsl:choose>
                                <xsl:when
                                    test="ancestor::jp:indication-of-case-article
                                        and ($payment = 'jp:payment-'
                                            or $node = 'jp:demand-e853' or $node = 'jp:demand-e854'
                                            or $node = 'jp:demand-e862') and not($law = 'utility') ">
                                    <xsl:value-of select="'　　'" />
                                </xsl:when>
                                <xsl:when
                                    test="ancestor::jp:annexation-payment and not($law = 'utility')">
                                    <xsl:value-of select="'　　'" />
                                </xsl:when>
                                <xsl:otherwise>
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:choose>
                                <xsl:when
                                    test="ancestor::jp:indication-of-case-article
                                        and ($payment = 'jp:payment-' or $node = 'jp:demand-e853'
                                            or $node = 'jp:demand-e854' or $node = 'jp:demand-e862')">
                                    <xsl:value-of select="'　　'" />
                                </xsl:when>
                                <xsl:otherwise>
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="normalize-space(.) = ''" />
                        <xsl:otherwise>
                            <xsl:call-template name="文書番号内容編集" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         文書番号内容編集
         ====================================================================-->
    <xsl:template name="文書番号内容編集">
        <xsl:variable name="number" select="normalize-space(.)" />
        <xsl:variable name="law" select="ancestor::jp:application-reference/@jp:kind-of-law" />
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <!--  項目内容の編集  -->
        <xsl:choose>
            <!--　出願番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'application']">
                <xsl:call-template name="translate-application-number">
                    <xsl:with-param name="number" select="$number" />
                    <xsl:with-param name="law" select="$law" />
                    <xsl:with-param name="kinddoc" select="$kinddoc" />
                </xsl:call-template>
            </xsl:when>
            <!--　国際出願番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'international-application']">
                <xsl:call-template name="translate-intl-application-number">
                    <xsl:with-param name="number" select="$number" />
                </xsl:call-template>
            </xsl:when>
            <!--　登録番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'registration']">
                <xsl:call-template name="translate-registered-number">
                    <xsl:with-param name="number" select="$number" />
                    <xsl:with-param name="law" select="$law" />
                </xsl:call-template>
            </xsl:when>
            <!--　公告番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'examined-pub']">
                <xsl:call-template name="translate-examind-pub-number">
                    <xsl:with-param name="number" select="$number" />
                    <xsl:with-param name="law" select="$law" />
                </xsl:call-template>
            </xsl:when>
            <!--　公開番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'un-examined-pub']">
                <xsl:call-template name="translate-pub-number">
                    <xsl:with-param name="number" select="$number" />
                    <xsl:with-param name="law" select="$law" />
                </xsl:call-template>
            </xsl:when>
            <!-- ====================================================================
                 審判番号
                 ====================================================================-->
            <xsl:when test="ancestor::jp:appeal-reference">
                <xsl:call-template name="translate-appeal-number">
                    <xsl:with-param name="number" select="$number" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$number" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 出願番号の変換 -->
    <xsl:template name="translate-application-number">
        <xsl:param name="number" as="xs:string" />
        <xsl:param name="law" as="xs:string" />
        <xsl:param name="kinddoc" as="xs:string" />

        <xsl:choose>
            <xsl:when test="string-length($number) != 10">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="number($number) &gt;= 2000000000">
                        <xsl:choose>
                            <xsl:when test="$law = 'patent'">
                                <xsl:value-of select="'特願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'utility'">
                                <xsl:value-of select="'実願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'design'">
                                <xsl:value-of select="'意願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'trademark'">
                                <xsl:value-of select="'商願'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'　　'" />
                            </xsl:otherwise>
                        </xsl:choose>
                        <!-- '.' に含まれる後半6桁については, オリジナル pat_common.xslでは先頭から続く0はスペースに変換していた。
                             '2001000001' -> '2001-     1'
                             ここでは  0 そのまま表示する。
                             '2001000001' -> '2001-000001'
                        -->
                        <xsl:value-of
                            select="substring($number,1,4) || '-' || substring($number, 5)" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="和暦変換" />
                        <xsl:choose>
                            <xsl:when test="$law = 'patent'">
                                <xsl:value-of select="'特許願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'utility'">
                                <xsl:value-of select="'実用新案登録願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'design'">
                                <xsl:value-of select="'意匠登録願'" />
                            </xsl:when>
                            <xsl:when test="$law = 'trademark'">
                                <xsl:choose>
                                    <xsl:when
                                        test="$kinddoc = 'jp:payment-r100' or $kinddoc = 'jp:payment-r110'">
                                        <xsl:value-of select="'商標登録願'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="$kinddoc = 'jp:payment-r103' or $kinddoc = 'jp:payment-r113'">
                                        <xsl:value-of select="'防護標章登録願'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="$kinddoc = 'jp:payment-r104' or $kinddoc = 'jp:payment-r114'">
                                        <xsl:value-of select="'商標更新登録願'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="$kinddoc = 'jp:payment-r105' or $kinddoc = 'jp:payment-r115'">
                                        <xsl:value-of select="'防護標章更新登録願'" />
                                    </xsl:when>
                                </xsl:choose>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'　　'" />
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:value-of select="'第' || substring($number, 5) || '号'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 国際出願番号の変換 -->
    <xsl:template name="translate-intl-application-number">
        <xsl:param name="number" as="xs:string" />

        <xsl:choose>
            <xsl:when test="string-length($number) = 12">
                <xsl:value-of
                    select="'PCT/' || substring($number,1,6) || '/' || substring($number,7,6)" />
            </xsl:when>
            <xsl:when test="string-length($number) = 9">
                <xsl:value-of
                    select="'PCT/' || substring($number,1,4) || '/' || substring($number,5,5)" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 登録番号の変換 -->
    <xsl:template name="translate-registered-number">
        <xsl:param name="number" as="xs:string" />
        <xsl:param name="law" as="xs:string" />

        <xsl:choose>
            <xsl:when
                test="($law = 'patent' and string-length($number) != 7)
                    or ($law = 'utility' and string-length($number) != 7)">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:when
                test="($law != 'patent' and $law != 'utility')
                    and (string-length($number) &lt; 7)">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="$law = 'patent'">
                        <xsl:value-of select="'特許第'" />
                    </xsl:when>
                    <xsl:when test="$law = 'utility'">
                        <xsl:value-of select="'実用新案登録第'" />
                    </xsl:when>
                    <xsl:when test="$law = 'design'">
                        <xsl:value-of select="'意匠登録第'" />
                    </xsl:when>
                    <xsl:when test="$law = 'trademark'">
                        <xsl:value-of select="'商標登録第'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'　　第'" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:value-of select="substring($number, 1, 7) || '号'" />
                <xsl:if test="string-length($number) &gt;= 8">
                    <xsl:value-of select="substring($number,8)" />
                </xsl:if>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 公告番号の変換 -->
    <xsl:template name="translate-examind-pub-number">
        <xsl:param name="number" as="xs:string" />
        <xsl:param name="law" as="xs:string" />

        <xsl:choose>
            <xsl:when test="string-length($number) != 10">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="和暦変換" />
                <xsl:choose>
                    <xsl:when test="$law = 'patent'">
                        <xsl:value-of select="'特許'" />
                    </xsl:when>
                    <xsl:when test="$law = 'utility'">
                        <xsl:value-of select="'実用新案'" />
                    </xsl:when>
                    <xsl:when test="$law = 'trademark'">
                        <xsl:value-of select="'商標'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:value-of select="'出願公告第' || substring($number, 5, 6) || '号'" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 公開番号の変換 -->
    <xsl:template name="translate-pub-number">
        <xsl:param name="number" as="xs:string" />
        <xsl:param name="law" as="xs:string" />

        <xsl:choose>
            <xsl:when test="string-length($number) != 10">
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="xs:integer($number) &gt;= 2000000000">
                        <xsl:choose>
                            <xsl:when test="$law = 'patent'">
                                <xsl:value-of select="'特開'" />
                            </xsl:when>
                            <xsl:when test="$law = 'utility'">
                                <xsl:value-of select="'実開'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="書誌編集エラー処理" />
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:value-of
                            select="substring($number,1,4) || '-' || substring($number, 5, 6)" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="和暦変換" />
                        <xsl:choose>
                            <xsl:when test="$law = 'patent'">
                                <xsl:value-of select="'特許'" />
                            </xsl:when>
                            <xsl:when test="$law = 'utility'">
                                <xsl:value-of select="'実用新案'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="書誌編集エラー処理" />
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:value-of select="'出願公開第' || substring($number, 5, 6) || '号'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- 審判番号の変換 -->
    <xsl:template name="translate-appeal-number">
        <xsl:param name="number" as="xs:string" />
        <xsl:variable name="lower-5digits" as="xs:integer"
            select="xs:integer(substring($number, 5, 5))" />
        <xsl:variable name="lower-6digits" as="xs:integer"
            select="xs:integer(substring($number, 5, 6))" />

        <xsl:choose>
            <xsl:when test="string-length($number) = 9">
                <xsl:choose>
                    <xsl:when test="number($number) &gt;= 200700000">
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when test="number($number) &gt;= 200000000">
                                <xsl:choose>
                                    <xsl:when
                                        test="1 &lt;= $lower-5digits and $lower-5digits &lt;= 30000">
                                        <xsl:value-of select="'不服'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="30001 &lt;= $lower-5digits and $lower-5digits  &lt;= 35000">
                                        <xsl:value-of select="'取消'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="35001 &lt;= $lower-5digits and $lower-5digits  &lt;= 39000">
                                        <xsl:value-of select="'無効'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="39001 &lt;= $lower-5digits and $lower-5digits  &lt;= 40000">
                                        <xsl:value-of select="'訂正'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="40001 &lt;= $lower-5digits and $lower-5digits  &lt;= 50000">
                                        <xsl:value-of select="'無効'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="50001 &lt;= $lower-5digits and $lower-5digits  &lt;= 60000">
                                        <xsl:value-of select="'補正'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="60001 &lt;= $lower-5digits and $lower-5digits  &lt;= 65000">
                                        <xsl:value-of select="'判定'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="65001 &lt;= $lower-5digits and $lower-5digits  &lt;= 66000">
                                        <xsl:value-of select="'不服'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="66001 &lt;= $lower-5digits and $lower-5digits  &lt;= 67000">
                                        <xsl:value-of select="'取消'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="67001 &lt;= $lower-5digits and $lower-5digits  &lt;= 68000">
                                        <xsl:value-of select="'無効'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="68001 &lt;= $lower-5digits and $lower-5digits  &lt;= 69000">
                                        <xsl:value-of select="'異議'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69001 &lt;= $lower-5digits and $lower-5digits  &lt;= 69500">
                                        <xsl:value-of select="'補正'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69501 &lt;= $lower-5digits and $lower-5digits  &lt;= 69600">
                                        <xsl:value-of select="'判定'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69601 &lt;= $lower-5digits and $lower-5digits  &lt;= 69700">
                                        <xsl:value-of select="'再審'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69701 &lt;= $lower-5digits and $lower-5digits  &lt;= 69800">
                                        <xsl:value-of select="'除斥'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69801 &lt;= $lower-5digits and $lower-5digits  &lt;= 69900">
                                        <xsl:value-of select="'忌避'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="69901 &lt;= $lower-5digits and $lower-5digits  &lt;= 70000">
                                        <xsl:value-of select="'証拠'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="70001 &lt;= $lower-5digits and $lower-5digits  &lt;= 95000">
                                        <xsl:choose>
                                            <xsl:when
                                                test="number($number) &gt;= 200400000 and 80001 &lt;= $lower-5digits and $lower-5digits  &lt;= 90000">
                                                <xsl:value-of select="'無効'" />
                                            </xsl:when>
                                            <xsl:otherwise>
                                                <xsl:value-of select="'異議'" />
                                            </xsl:otherwise>
                                        </xsl:choose>
                                    </xsl:when>
                                    <xsl:when
                                        test="95001 &lt;= $lower-5digits and $lower-5digits  &lt;= 96000">
                                        <xsl:value-of select="'再審'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="96001 &lt;= $lower-5digits and $lower-5digits  &lt;= 97000">
                                        <xsl:value-of select="'除斥'" />
                                    </xsl:when>
                                    <xsl:when
                                        test="97001 &lt;= $lower-5digits and $lower-5digits  &lt;= 98000">
                                        <xsl:value-of select="'忌避'" />
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <xsl:value-of select="'証拠'" />
                                    </xsl:otherwise>
                                </xsl:choose>
                                <xsl:value-of select="substring($number,1,4) || '-'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="和暦変換" />
                                <xsl:value-of select="'審判第'" />
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:value-of select="substring($number, 5, 5)" />
                        <xsl:if test="number($number) &lt; 200000000">
                            <xsl:value-of select="'号'" />
                        </xsl:if>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="string-length($number) = 10">
                <xsl:choose>
                    <xsl:when test="number($number) &gt;= 2007000001">
                        <xsl:choose>
                            <xsl:when test="1 &lt;= $lower-6digits and $lower-6digits &lt;= 199999">
                                <xsl:value-of select="'不服'" />
                            </xsl:when>
                            <xsl:when
                                test="300001 &lt;= $lower-6digits and $lower-6digits  &lt;= 349999">
                                <xsl:value-of select="'取消'" />
                            </xsl:when>
                            <xsl:when
                                test="390001 &lt;= $lower-6digits and $lower-6digits  &lt;= 399999">
                                <xsl:value-of select="'訂正'" />
                            </xsl:when>
                            <xsl:when
                                test="400001 &lt;= $lower-6digits and $lower-6digits  &lt;= 409999">
                                <xsl:value-of select="'無効'" />
                            </xsl:when>
                            <xsl:when
                                test="500001 &lt;= $lower-6digits and $lower-6digits  &lt;= 509999">
                                <xsl:value-of select="'補正'" />
                            </xsl:when>
                            <xsl:when
                                test="600001 &lt;= $lower-6digits and $lower-6digits  &lt;= 609999">
                                <xsl:value-of select="'判定'" />
                            </xsl:when>
                            <xsl:when
                                test="650001 &lt;= $lower-6digits and $lower-6digits  &lt;= 669999">
                                <xsl:value-of select="'不服'" />
                            </xsl:when>
                            <xsl:when
                                test="670001 &lt;= $lower-6digits and $lower-6digits  &lt;= 679999">
                                <xsl:value-of select="'取消'" />
                            </xsl:when>
                            <xsl:when
                                test="680001 &lt;= $lower-6digits and $lower-6digits  &lt;= 684999">
                                <xsl:value-of select="'無効'" />
                            </xsl:when>
                            <xsl:when
                                test="685001 &lt;= $lower-6digits and $lower-6digits  &lt;= 689999">
                                <xsl:value-of select="'異議'" />
                            </xsl:when>
                            <xsl:when
                                test="690001 &lt;= $lower-6digits and $lower-6digits  &lt;= 694999">
                                <xsl:value-of select="'補正'" />
                            </xsl:when>
                            <xsl:when
                                test="695001 &lt;= $lower-6digits and $lower-6digits  &lt;= 695999">
                                <xsl:value-of select="'判定'" />
                            </xsl:when>
                            <xsl:when
                                test="696001 &lt;= $lower-6digits and $lower-6digits  &lt;= 696999">
                                <xsl:value-of select="'再審'" />
                            </xsl:when>
                            <xsl:when
                                test="697001 &lt;= $lower-6digits and $lower-6digits  &lt;= 697999">
                                <xsl:value-of select="'除斥'" />
                            </xsl:when>
                            <xsl:when
                                test="698001 &lt;= $lower-6digits and $lower-6digits  &lt;= 698999">
                                <xsl:value-of select="'忌避'" />
                            </xsl:when>
                            <xsl:when
                                test="699001 &lt;= $lower-6digits and $lower-6digits  &lt;= 699999">
                                <xsl:value-of select="'証拠'" />
                            </xsl:when>
                            <xsl:when
                                test="700001 &lt;= $lower-6digits and $lower-6digits  &lt;= 799999">
                                <xsl:value-of select="'異議'" />
                            </xsl:when>
                            <xsl:when
                                test="800001 &lt;= $lower-6digits and $lower-6digits  &lt;= 899999">
                                <xsl:value-of select="'無効'" />
                            </xsl:when>
                            <xsl:when
                                test="900001 &lt;= $lower-6digits and $lower-6digits  &lt;= 909999">
                                <xsl:value-of select="'異議'" />
                            </xsl:when>
                            <xsl:when
                                test="950001 &lt;= $lower-6digits and $lower-6digits  &lt;= 959999">
                                <xsl:value-of select="'再審'" />
                            </xsl:when>
                            <xsl:when
                                test="960001 &lt;= $lower-6digits and $lower-6digits  &lt;= 969999">
                                <xsl:value-of select="'除斥'" />
                            </xsl:when>
                            <xsl:when
                                test="970001 &lt;= $lower-6digits and $lower-6digits  &lt;= 979999">
                                <xsl:value-of select="'忌避'" />
                            </xsl:when>
                            <xsl:when
                                test="980001 &lt;= $lower-6digits and $lower-6digits  &lt;= 989999">
                                <xsl:value-of select="'証拠'" />
                            </xsl:when>
                        </xsl:choose>
                        <xsl:value-of
                            select="substring($number,1,4) || '-' || substring($number, 5, 6)" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         和暦変換
         INPUT: jp:doc-number e.g. 2000123456
         OUTPUT: 昭和|平成NN年
         ====================================================================-->
    <xsl:template name="和暦変換">
        <xsl:variable name="day" select="normalize-space(.)" />
        <xsl:variable name="year" as="xs:integer" select="xs:integer(substring($day, 1, 4))" />
        <xsl:variable name="doc-number" as="xs:integer" select="xs:integer(substring($day, 1, 10))" />
        <xsl:choose>
            <!--　四法が対象外　-->
            <xsl:when
                test="(ancestor::jp:application-reference [@jp:kind-of-law != 'patent']
                        and ancestor::jp:application-reference [@jp:kind-of-law != 'utility']
                        and ancestor::jp:application-reference [@jp:kind-of-law != 'design']
                        and ancestor::jp:application-reference [@jp:kind-of-law != 'trademark']) or
                    not(ancestor::jp:application-reference [@jp:kind-of-law]) ">
                <xsl:choose>
                    <xsl:when test="$year &gt;= 1989">
                        <xsl:call-template name="平成編集" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="昭和編集" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <!--　出願番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'application']">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:application-reference [@jp:kind-of-law = 'patent']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989001146">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:application-reference [@jp:kind-of-law = 'utility']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000491">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when test="ancestor::jp:application-reference [@jp:kind-of-law = 'design']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000124">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:application-reference [@jp:kind-of-law = 'trademark']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000354">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                </xsl:choose>
            </xsl:when>
            <!--　公告番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'examined-pub']">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:application-reference [@jp:kind-of-law = 'patent']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000600">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:application-reference [@jp:kind-of-law = 'utility']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000480">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:application-reference [@jp:kind-of-law = 'trademark']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989000000">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                </xsl:choose>
            </xsl:when>
            <!--　公開番号　-->
            <xsl:when
                test="ancestor::jp:application-reference
                    and ancestor::jp:application-reference [@appl-type = 'un-examined-pub']">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:application-reference [@jp:kind-of-law = 'patent']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989003200">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when
                        test="ancestor::jp:application-reference [@jp:kind-of-law = 'utility']">
                        <xsl:choose>
                            <xsl:when test="$doc-number &gt; 1989001800">
                                <xsl:call-template name="平成編集" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:call-template name="昭和編集" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                </xsl:choose>
            </xsl:when>
            <!--　審判番号　-->
            <xsl:when test="ancestor::jp:appeal-reference">
                <xsl:choose>
                    <xsl:when test="$doc-number&gt; 198900000">
                        <xsl:call-template name="平成編集" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="昭和編集" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         平成編集
         INPUT: xs:string contains [0-9]+ in jp:doc-number
         OUTPUT: 平成NN年 
         ====================================================================-->
    <xsl:template name="平成編集">
        <xsl:variable name="year" as="xs:integer"
            select="xs:integer(substring(normalize-space(.),1,4))" />
        <xsl:variable name="hyy" select="$year - 1988" />
        <xsl:value-of select="'平成' || $hyy || '年'" />
    </xsl:template>

    <!-- ====================================================================
         昭和編集
         INPUT: xs:string contains [0-9]+ in jp:doc-number
         OUTPUT: 昭和NN年 
         ====================================================================-->
    <xsl:template name="昭和編集">
        <xsl:variable name="year" as="xs:integer"
            select="xs:integer(substring(normalize-space(.),1,4))" />
        <xsl:variable name="syy" select="$year - 1925" />
        <xsl:value-of select="'昭和' || $syy || '年'" />
    </xsl:template>

    <!-- ====================================================================
         受付番号編集
         <xsl:template name="受付番号編集">
         ====================================================================-->
    <xsl:template match="jp:receipt-number">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="c-payment">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of
                        select="substring(ancestor::jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$payment" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　【訂正対象書類受付番号】　'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'　【訂正対象書類受付番号】　'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:when test="parent::jp:amendment-group">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　【補正対象書類受付番号】　'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'　【補正対象書類受付番号】　'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:when test="ancestor::jp:indication-of-case-article">
                    <xsl:choose>
                        <xsl:when
                            test="$c-payment = 'jp:payment-'
                                or $kinddoc = 'jp:demand-e853'
                                or $kinddoc = 'jp:demand-e854'
                                or $kinddoc = 'jp:demand-e862' ">
                            <xsl:value-of select="'【受付番号】　　　'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'　　【受付番号】　　　'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　【受付番号】　　　'" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         請求項の数編集
         <xsl:template name="請求項の数編集">
         ====================================================================-->
    <xsl:template match="jp:number-of-claim">

        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="$kinddoc = 'jp:etcetera-a623' or $kinddoc = 'jp:etcetera-a624'">
                            <xsl:value-of select="'　　【評価の請求に係る請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'claim' ">
                            <xsl:value-of select="'　　【請求項の数】　　'" />
                        </xsl:when>
                        <xsl:when test="./@jp:adopted-law = 'invention' ">
                            <xsl:value-of select="'　　【発明の数】　　　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when
                            test="$kinddoc = 'jp:etcetera-a623' or $kinddoc = 'jp:etcetera-a624'">
                            <xsl:value-of select="'【評価の請求に係る請求項の数】　'" />
                        </xsl:when>
                        <xsl:when test="ancestor::jp:annexation-payment">
                            <xsl:choose>
                                <xsl:when test="./@jp:adopted-law = 'claim' ">
                                    <xsl:value-of select="'　　【請求項の数】　　'" />
                                </xsl:when>
                                <xsl:when test="./@jp:adopted-law = 'invention' ">
                                    <xsl:value-of select="'　　【発明の数】　　　'" />
                                </xsl:when>
                            </xsl:choose>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:choose>
                                <xsl:when test="./@jp:adopted-law = 'claim' ">
                                    <xsl:value-of select="'【請求項の数】　　　　'" />
                                </xsl:when>
                                <xsl:when test="./@jp:adopted-law = 'invention' ">
                                    <xsl:value-of select="'【発明の数】　　　　　'" />
                                </xsl:when>
                            </xsl:choose>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>
            <xsl:value-of select="." />

        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         氏名又は名称編集
         <xsl:template name="氏名又は名称編集">
         ====================================================================-->
    <xsl:template match="jp:name">
        <xsl:element name="div">

            <xsl:choose>
                <xsl:when test="ancestor::jp:inventor">
                    <xsl:value-of select="'　　【氏名】　　　　　'" />
                </xsl:when>
                <xsl:when test=" parent::jp:bank-account">
                    <xsl:value-of select="'　　【口座名義人】　　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:representative">
                    <xsl:variable name="meisyo"
                        select="normalize-space(preceding-sibling::jp:representative-identification)" />
                    <xsl:call-template name="space-suffix">
                        <xsl:with-param name="str" as="xs:string">
                            <xsl:if
                                test="(ancestor::jp:attorney-disappear-article
                                        or ancestor::jp:attorney-change-article)
                                    and ($node = 'jp:attorney-a7421' or $node = 'jp:attorney-a7423'
                                        or $node = 'jp:attorney-a7425' or $node = 'jp:attorney-a7426'
                                        or $node = 'jp:attorney-a7427' or $node = 'jp:attorney-a7428'
                                        or $node = 'jp:attorney-a7431' or $node = 'jp:attorney-a7433'
                                        or $node = 'jp:attorney-a7435' or $node = 'jp:attorney-a7436'
                                        or $node = 'jp:attorney-a7437') ">
                                <xsl:value-of select="'　'" />
                            </xsl:if>
                            <xsl:value-of select="'　　【' || $meisyo || '】　'" />
                        </xsl:with-param>
                        <xsl:with-param name="length" select="11" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:if
                        test="(ancestor::jp:attorney-disappear-article
                                or ancestor::jp:attorney-change-article)
                            and ($node = 'jp:attorney-a7421' or $node = 'jp:attorney-a7423'
                                or $node = 'jp:attorney-a7425' or $node = 'jp:attorney-a7426'
                                or $node = 'jp:attorney-a7427' or $node = 'jp:attorney-a7428'
                                or $node = 'jp:attorney-a7431' or $node = 'jp:attorney-a7433'
                                or $node = 'jp:attorney-a7435' or $node = 'jp:attorney-a7436'
                                or $node = 'jp:attorney-a7437') ">
                        <xsl:value-of select="'　　　【氏名又は名称】　'" />
                    </xsl:if>
                    <xsl:value-of select="'　　【氏名又は名称】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         氏名又は名称原語表記編集
         <xsl:template name="氏名又は名称原語表記編集">
         ====================================================================-->
    <xsl:template match="jp:original-language-of-name">
        <xsl:element name="div">

            <xsl:choose>
                <xsl:when test="ancestor::jp:representative">
                    <xsl:variable name="meisyo"
                        select="normalize-space(preceding-sibling::jp:representative-identification)" />
                    <xsl:call-template name="space-suffix">
                        <xsl:with-param name="str" as="xs:string">
                            <xsl:value-of select="'　　【' || $meisyo || '原語表記】　'" />
                        </xsl:with-param>
                        <xsl:with-param name="length" select="11" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　【氏名又は名称原語表記】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         事件との関係編集
         <xsl:template name="事件との関係編集">
         ====================================================================-->
    <xsl:template match="jp:relation-of-case">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">

            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:etcetera-a621' or $kinddoc = 'jp:etcetera-a625'">
                    <xsl:value-of select="'　　【出願人との関係】　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:presenter-article">
                    <xsl:value-of select="'　　【請求人との関係】　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　【事件との関係】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:document-name 物件名
         ====================================================================-->
    <xsl:template match="jp:document-name">
        <xsl:if test="not(ancestor::jp:attaching-document-group)">
            <xsl:call-template name="物件名編集" />
        </xsl:if>
    </xsl:template>

    <!-- ====================================================================
         物件名編集
         ====================================================================-->
    <xsl:template name="物件名編集">
        <xsl:variable name="node0">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:list-group">
                            <xsl:value-of select="'　　【物件名】　　　　'" />
                        </xsl:when>
                        <xsl:when test="$node = 'jp:etcetera-a831'">
                            <xsl:value-of select="'　　【提出する刊行物等】　'" />
                        </xsl:when>
                        <xsl:when test="$node = 'jp:presentment-a82'">
                            <xsl:value-of select="'　　【提出する物件】　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="ancestor::jp:list-group">
                            <xsl:value-of select="'　　【物件名】　　　　'" />
                        </xsl:when>
                        <xsl:when test="$node = 'jp:etcetera-a831'">
                            <xsl:value-of select="'【提出する刊行物等】　'" />
                        </xsl:when>
                        <xsl:when test="$node = 'jp:presentment-a82'">
                            <xsl:value-of select="'【提出する物件】　　　'" />
                        </xsl:when>
                    </xsl:choose>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="ancestor::jp:list-group">
                    <xsl:value-of select=". || '　' || following-sibling::jp:number-of-object" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="." />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         証拠方法編集
         ====================================================================-->
    <xsl:template match="jp:proof-means">
        <xsl:element name="div">
            <xsl:variable name="kinddoc">
                <xsl:choose>
                    <xsl:when test="ancestor::jp:contents-of-amendment">
                        <xsl:choose>
                            <xsl:when
                                test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                                <xsl:value-of
                                    select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of
                                    select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="$node" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:variable>

            <xsl:call-template name="space-suffix">
                <xsl:with-param name="str" as="xs:string">
                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:choose>
                        <xsl:when
                            test="$kinddoc = 'jp:payment-r220' or $kinddoc = 'jp:etcetera-a821'">
                            <xsl:value-of select="'【補足対象書類名】'" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="'【証拠方法】'" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:with-param>
            </xsl:call-template>
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         対象項目編集
         <xsl:template name="対象項目編集">
         ====================================================================-->
    <xsl:template match="jp:item-of-amendment">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">

            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$kinddoc = 'jp:amendment-a524'">
                    <xsl:value-of select="'　【訂正対象項目名】　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　【補正対象項目名】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         証明又は交付に係る書類名編集
         <xsl:template name="証明又は交付に係る書類名編集">
         ====================================================================-->
    <xsl:template match="jp:proof-or-deliverty-document">
        <xsl:variable name="node">
            <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
        </xsl:variable>

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$node = 'jp:demand-e842'">
                    <xsl:value-of select="'【証明に係る書類名】　'" />
                </xsl:when>
                <xsl:when test="$node = 'jp:demand-e841'">
                    <xsl:value-of select="'【証明に係る他の書類名】　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'【交付に係る書類名】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         原出願の表示編集
         <xsl:template name="原出願の表示編集">
         ====================================================================-->
    <xsl:template match="jp:parent-application-article">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="./@jp:kind-of-application = 'based-on-utility'">
                        <xsl:value-of select="'【基礎とした実用新案登録及びその実用新案登録出願の表示】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【原出願の表示】'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates
                select="jp:application-reference [@appl-type = 'registration']//jp:doc-number" />
            <xsl:apply-templates select="jp:application-reference [@appl-type = 'registration']" />
            <xsl:apply-templates
                select="jp:application-reference [@appl-type = 'application']//jp:doc-number" />
            <xsl:apply-templates select="jp:application-reference [@appl-type = 'application']" />
            <xsl:apply-templates
                select="jp:application-reference [@appl-type = 'international-application']//jp:doc-number" />
            <xsl:apply-templates
                select="jp:application-reference [@appl-type = 'international-application']" />
            <xsl:apply-templates select="jp:file-reference-id" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         パリ条約による優先権等の主張編集
         <xsl:template name="パリ条約による優先権等の主張編集">
         ====================================================================-->
    <xsl:template match="jp:priority-claims">
        <xsl:element name="div">
            <xsl:apply-templates select="jp:priority-claim" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:priority-claim パリ優先権主張
         ====================================================================-->
    <xsl:template match="jp:priority-claim">
        <xsl:variable name="node">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when
                        test="$node = 'jp:withdrawal-abandonment-a765'
                            or $node = 'jp:presentment-a79'">
                        <xsl:value-of select="'【最初の出願の表示】'" />
                    </xsl:when>
                    <xsl:when test="$node = 'jp:etcetera-a916'">
                        <xsl:value-of select="'【提出した優先権証明書】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【パリ条約による優先権等の主張】'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates select="jp:country" />
            <xsl:apply-templates select="jp:date" />
            <xsl:apply-templates select="jp:doc-number" />
            <xsl:apply-templates select="jp:ip-type" />
            <xsl:apply-templates select="jp:generated-access-code" />
            <xsl:apply-templates select="jp:priority-doc-location-info" />
            <xsl:apply-templates select="jp:use-of-das" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:ip-type 出願の区分
         <xsl:call-template name="DAS出願区分編集" />
         ====================================================================-->
    <xsl:template match="jp:ip-type">
        <xsl:element name="div">
            <xsl:value-of select="'　　【出願の区分】　　'" />
            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:when test="normalize-space(.) = 'patent'">
                    <xsl:value-of select="'特許'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = 'utility'">
                    <xsl:value-of select="'実用新案登録'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = 'design'">
                    <xsl:value-of select="'意匠登録'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = ''">
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="書誌編集エラー処理" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:use-of-das DAS利用編集
         ====================================================================-->
    <xsl:template match="jp:use-of-das">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:priority-claim">
                    <xsl:value-of select="'　　【優先権証明書に係る付与】　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　　'" />
                    </xsl:if>
                    <xsl:value-of select="'【本出願に係る付与】　'" />
                </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:when test="normalize-space(.) = '1'">
                    <xsl:value-of select="'希望'" />
                </xsl:when>
                <xsl:when test="normalize-space(.) = ''">
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="書誌編集エラー処理" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:charge-article 手数料の表示編集
         <xsl:template name="手数料の表示編集">
         ====================================================================-->
    <xsl:template match="jp:charge-article">
        <xsl:variable name="kinddoc">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-document" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$node" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="kind-of-law">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="ancestor::jp:contents-of-amendment/@jp:kind-of-law" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$kind-of-law" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:variable name="payment">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment//jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="substring(ancestor::jp:contents-of-amendment/@jp:kind-of-document,1,11)" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$payment" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:choose>
                    <xsl:when test="$payment = 'jp:payment-'">
                        <xsl:if test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:choose>
                            <xsl:when test="$kind-of-law = 'patent'">
                                <xsl:value-of select="'【特許料の表示】'" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="'【登録料の表示】'" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when test="ancestor::jp:amendment-charge-article">
                    </xsl:when>
                    <xsl:when test="$kinddoc = 'jp:etcetera-a914'">
                        <xsl:if test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【返還の表示】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:if test="ancestor::jp:contents-of-amendment">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【手数料の表示】'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates select="jp:payment" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         <xsl:template name="手数料補正編集">
         ====================================================================-->
    <xsl:template match="jp:amendment-charge-article">
        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:element name="div">
                <xsl:value-of select="'【手数料補正】'" />
            </xsl:element>
            <xsl:apply-templates select="jp:document-code" />
            <xsl:apply-templates select="jp:charge-article" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         発明者編集
         <xsl:template name="発明者編集">
         ====================================================================-->
    <xsl:template match="jp:inventor">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="$kind-of-law = 'patent'">
                        <xsl:value-of select="'【発明者】'" />
                    </xsl:when>
                    <xsl:when test="$kind-of-law = 'utility'">
                        <xsl:value-of select="'【考案者】'" />
                    </xsl:when>
                </xsl:choose>
            </xsl:element>

            <xsl:apply-templates select=".//jp:registered-number" />
            <xsl:apply-templates select=".//jp:text" />
            <xsl:apply-templates select=".//jp:kana" />
            <xsl:apply-templates select=".//jp:name" />
        </xsl:element>
    </xsl:template>


    <!-- ====================================================================
         代理人前編集
         <xsl:template name="代理人前編集">
         ====================================================================-->
    <xsl:template match="jp:agent">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:call-template name="代理人編集" />
            </xsl:element>

            <xsl:apply-templates select=".//jp:registered-number" />
            <xsl:apply-templates select=".//jp:text" />
            <xsl:apply-templates select="jp:attorney" />
            <xsl:apply-templates select="jp:lawyer" />
            <xsl:apply-templates select="jp:addressbook/jp:kana" />
            <xsl:apply-templates select="jp:addressbook/jp:name" />
            <xsl:choose>
                <xsl:when test="ancestor::jp:attorney-of-case-article">
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="jp:office-address" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:apply-templates select="jp:representative-group" />
            <xsl:apply-templates select=".//jp:phone" />
            <xsl:apply-templates select=".//jp:fax" />
            <xsl:apply-templates select="jp:contact" />
            <xsl:apply-templates select="jp:relation-attorney-special-matter" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         代理人編集
         ====================================================================-->
    <xsl:template name="代理人編集">
        <xsl:variable name="code">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="normalize-space(ancestor::jp:amendment-group//jp:contents-of-amendment/jp:amendment-group/jp:document-code)" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="normalize-space(ancestor::jp:amendment-group/jp:document-code)" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$doc-code" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:if test="ancestor::jp:contents-of-amendment">
            <xsl:value-of select="'　　'" />
        </xsl:if>
        <xsl:choose>
            <xsl:when test="./@jp:kind-of-agent"><!--@jp:kind-of-agent属性が存在する場合-->
                <xsl:call-template name="code-to-agents1">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise><!--@jp:kind-of-agent属性が存在しない場合-->
                <xsl:call-template name="code-to-agents2">
                    <xsl:with-param name="code" select="$code" />
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="code-to-agents1">
        <xsl:param name="code" />
        <xsl:choose>
            <xsl:when test="ancestor::jp:proceeded-attorney-article">
                <xsl:choose>
                    <xsl:when test="matches($code, '^A[12]74[23]2$')">
                        <xsl:value-of select="'【受任した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]74[23]4$')">
                        <xsl:value-of select="'【辞任した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]743[13567]$')">
                        <xsl:value-of select="'【'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:agents">
                <xsl:choose>
                    <xsl:when test="matches($code, '^A[12]71[12]$')">
                        <xsl:value-of select="'【承継人'" />
                    </xsl:when>

                    <xsl:when
                        test="
                        matches($code, '^A[12]63$') or
                        matches($code, '^A[12]63[245]$') or
                        matches($code, '^A[12]601$') or
                        matches($code, '^A[12]62[15]$') or
                        matches($code, '^A[12]6[89]1$') or
                        matches($code, '^A[12]603$') or
                        matches($code, '^A262[346]$') or
                        $code = 'A167' or $code = 'A1627' or $code = 'A1631' or $code = 'A2633' or
                        matches($code, '^A[12]5[1359]$') or
                        matches($code, '^A[12]52[5-9]$') or
                        matches($code, '^A[12]521[012]$') or
                        matches($code, '^A[12]523$') or
                        $code = 'A1524' or
                        matches($code, '^A[12]76[1245]$') or
                        matches($code, '^A[12]742[135678]$') or
                        matches($code, '^A[12]781$') or
                        matches($code, '^A[12]79$') or
                        matches($code, '^A[12]801?$') or
                        matches($code, '^A[12]8[12]$') or
                        matches($code, '^A[12]82[12]$') or
                        matches($code, '^A[12]831$') or
                        matches($code, '^A[12]87[12]?$') or
                        matches($code, '^A[12]91[5-7]$') or
                        matches($code, '^A191[489]$') or
                        matches($code, '^R[1-4]1[01]0$') or
                        matches($code, '^R[13]1[01][12]$') or
                        matches($code, '^R41[01][3-5]$') or
                        matches($code, '^R[1-3]2[01]$') or
                        matches($code, '^R42[01][01]$') or
                        matches($code, '^A[12]IB3491$') or
                        $code = 'R4220' or
                        substring($code,1,1) = 'C'">
                        <xsl:value-of select="'【'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-of-case-article">
                <xsl:choose>
                    <xsl:when test="$code = 'A1711' or $code = 'A2711'">
                        <xsl:value-of select="'【譲渡人'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A1712' or $code = 'A2712'">
                        <xsl:value-of select="'【被承継人'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]743[24]$')">
                        <xsl:value-of select="'【'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-change-article">
                <xsl:choose>
                    <xsl:when
                        test="matches($code, '^A[12]632?$') or
                        matches($code, '^A[12]71[12]$') or
                        matches($code, '^C[12]60$') or
                        $code = 'C360' or $code = 'C4660'">
                        <xsl:value-of select="'【選任した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]74[23][13]$')">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【選任した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]74[23]5$')">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【解任した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]74[23]6$')">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【代理権を変更した'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]74[23]7$')">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【代理権の消滅した'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17428' or $code = 'A27428'">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【援用を制限した'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-disappear-article">
                <xsl:choose>
                    <xsl:when test="matches($code, '^A[12]74[23]1$')">
                        <xsl:if test="not(ancestor::jp:contents-of-amendment)">
                            <xsl:value-of select="'　　'" />
                        </xsl:if>
                        <xsl:value-of select="'【代理権の消滅した'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
        </xsl:choose>
        <xsl:choose>
            <xsl:when test="./@jp:kind-of-agent = 'representative'">
                <xsl:value-of select="'代理人'" />
            </xsl:when>
            <xsl:when test="./@jp:kind-of-agent = 'sub-representative'">
                <xsl:value-of select="'復代理人'" />
            </xsl:when>
            <xsl:when test="./@jp:kind-of-agent = 'legal-representative'">
                <xsl:value-of select="'法定代理人'" />
            </xsl:when>
            <xsl:when test="./@jp:kind-of-agent = 'designated-representative'">
                <xsl:value-of select="'指定代理人'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="./@jp:kind-of-agent" />
            </xsl:otherwise>
        </xsl:choose>
        <xsl:value-of select="'】'" />
    </xsl:template>

    <xsl:template name="code-to-agents2">
        <xsl:param name="code" />
        <xsl:choose>
            <xsl:when test="ancestor::jp:proceeded-attorney-article">
                <xsl:choose>
                    <xsl:when test="$code = 'A17422' or $code = 'A27422'">
                        <xsl:value-of select="'【受任した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17424' or $code = 'A27424'">
                        <xsl:value-of select="'【辞任した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17432' or $code = 'A27432'">
                        <xsl:value-of select="'【受任した復代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17434' or $code = 'A27434'">
                        <xsl:value-of select="'【辞任した代理人】'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]743[13567]$')">
                        <xsl:value-of select="'【代理人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:agents">
                <xsl:choose>
                    <xsl:when test="matches($code, '^A[12]71[12]$')">
                        <xsl:value-of select="'【承継人代理人】'" />
                    </xsl:when>
                    <xsl:when
                        test="
                        matches($code, '^A[12]63$') or
                        matches($code, '^A[12]63[245]$') or
                        matches($code, '^A[12]51$') or
                        matches($code, '^A[12]521[0-2]$') or
                        matches($code, '^A[12]52[35-9]$') or
                        matches($code, '^A[12]5[359]$') or
                        matches($code, '^A[12]601$') or
                        matches($code, '^A[12]62[15]$') or
                        matches($code, '^A[12]6[89]1$') or
                        matches($code, '^A[12]742[135-8]$') or
                        matches($code, '^A[12]76[1245]$') or
                        matches($code, '^A[12]781$') or
                        matches($code, '^A[12]79$') or
                        matches($code, '^A[12]801?$') or
                        matches($code, '^A[12]8[12]$') or
                        matches($code, '^A[12]82[12]$') or
                        matches($code, '^A[12]831$') or
                        matches($code, '^A[12]87[12]?$') or
                        matches($code, '^R[1-4]100$') or
                        matches($code, '^R[1-4]110$') or
                        matches($code, '^R41[01][3-5]$') or
                        matches($code, '^R[1-3]2[01]$') or
                        matches($code, '^R42[01][01]$') or
                        matches($code, '^A[12]IB3491$') or
                        matches($code, '^A[12]603$') or
                        matches($code, '^A[12]91[5-7]$') or
                        matches($code, '^A191[89]$') or
                        $code = 'A1631' or $code = 'A2633' or $code = 'A1524' or
                        $code = 'A2623' or $code = 'A2626' or $code = 'A1627' or
                        $code = 'A167' or $code = 'R1101' or $code = 'R3102' or
                        $code = 'R1111' or $code = 'R3112'or $code = 'R4220' or
                        $code = 'A2624' or $code = 'A1914'">
                        <xsl:value-of select="'【代理人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-of-case-article">
                <xsl:choose>
                    <xsl:when test="$code = 'A1711' or $code = 'A2711'">
                        <xsl:value-of select="'【譲渡人代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A1712' or $code = 'A2712'">
                        <xsl:value-of select="'【被承継人代理人】'" />
                    </xsl:when>
                    <xsl:when
                        test="matches($code, '^A[12]743[24]$')">
                        <xsl:value-of select="'【代理人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-change-article">
                <xsl:choose>
                    <xsl:when
                        test="matches($code, '^A[12]63$') or
                        matches($code, '^A[12]632$') or
                        matches($code, '^A[12]71[12]$') or
                        matches($code, '^A[12]742[13]$')">
                        <!-- test="$code = 'A163' or $code = 'A263'
                             or $code = 'A1632' or $code = 'A2632'
                             or $code = 'A1711' or $code = 'A2711'
                             or $code = 'A1712' or $code = 'A2712'
                             or $code = 'A17421' or $code = 'A27421'
                             or $code = 'A17423' or $code = 'A27423'"> -->
                        <xsl:value-of select="'【選任した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17425' or $code = 'A27425'">
                        <xsl:value-of select="'【解任した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17426' or $code = 'A27426'">
                        <xsl:value-of select="'【代理権を変更した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17427' or $code = 'A27427'">
                        <xsl:value-of select="'【代理権の消滅した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17428' or $code = 'A27428'">
                        <xsl:value-of select="'【援用を制限した代理人】'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^A[12]743[13]$')">
                        <xsl:value-of select="'【選任した復代理人】　'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17435' or $code = 'A27435'">
                        <xsl:value-of select="'【解任した復代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17436' or $code = 'A27436'">
                        <xsl:value-of select="'【代理権を変更した復代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17437' or $code = 'A27437'">
                        <xsl:value-of select="'【代理権の消滅した復代理人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:when test="ancestor::jp:attorney-disappear-article">
                <xsl:choose>
                    <xsl:when test="$code = 'A17421' or $code = 'A27421'">
                        <xsl:value-of select="'【代理権の消滅した代理人】'" />
                    </xsl:when>
                    <xsl:when test="$code = 'A17431' or $code = 'A27431'">
                        <xsl:value-of select="'【代理権の消滅した復代理人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:call-template name="書誌編集エラー処理" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         先の出願編集
         ====================================================================-->
    <xsl:template name="先の出願編集">
        <xsl:param name="node" />

        <xsl:element name="div">
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:choose>
                <xsl:when test="$node = 'jp:withdrawal-abandonment-a764'">
                    <xsl:value-of select="'【先の出願の表示】'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'【先の出願に基づく優先権主張】'" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>

        <xsl:apply-templates
            select="jp:application-reference[@appl-type = 'application']//jp:doc-number" />
        <xsl:apply-templates
            select="jp:application-reference[@appl-type = 'international-application']//jp:doc-number" />
        <xsl:apply-templates select="jp:application-reference" />
        <xsl:apply-templates select="jp:file-reference-id" />
    </xsl:template>

    <!-- ====================================================================
         jp:rejection-case-accept-notice-art 拒絶理由通知を受けた事件の表示
         ====================================================================-->
    <xsl:template match="jp:rejection-case-accept-notice-art">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="'【拒絶理由通知を受けた事件の表示】'" />
            </xsl:element>

            <xsl:for-each select="jp:application-reference">
                <xsl:apply-templates select=".//jp:doc-number" />
            </xsl:for-each>
            <xsl:apply-templates select="jp:appeal-reference/jp:doc-number" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         jp:list-group 目録
         ====================================================================-->
    <xsl:template match="jp:list-group">
        <xsl:apply-templates select="jp:document-name" />
        <xsl:apply-templates select="jp:citation" />
        <xsl:apply-templates select="jp:return-request" />
        <xsl:apply-templates select="jp:general-power-of-attorney-id" />
        <xsl:apply-templates select="jp:dtext" />
    </xsl:template>

    <!-- ====================================================================
         申請者前編集
         <xsl:template name="申請者前編集">
         ====================================================================-->
    <xsl:template match="jp:applicant">
        <xsl:element name="div">

            <xsl:element name="div">
                <xsl:call-template name="申請者編集" />
            </xsl:element>

            <xsl:apply-templates select="jp:relation-of-case" />
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select="jp:share" />
                <xsl:apply-templates select="jp:representative-applicant" />
            </xsl:if>
            <xsl:apply-templates select=".//jp:registered-number" />
            <xsl:apply-templates select=".//jp:text" />
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select=".//jp:original-language-of-address" />
            </xsl:if>
            <xsl:apply-templates select="jp:addressbook/jp:kana" />
            <xsl:apply-templates select="jp:addressbook/jp:name" />
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select="jp:addressbook/jp:original-language-of-name" />
            </xsl:if>
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select="jp:office-address" />
                <xsl:apply-templates select="jp:office-in-japan" />
                <xsl:apply-templates select="jp:office" />
            </xsl:if>
            <xsl:apply-templates select="jp:representative-group" />
            <xsl:if test="ancestor::jp:applicants or ancestor::jp:presenter-article">
                <xsl:apply-templates select="jp:legal-entity-property" />
            </xsl:if>
            <xsl:apply-templates select="jp:nationality" />
            <xsl:apply-templates select=".//jp:phone" />
            <xsl:apply-templates select=".//jp:fax" />
            <xsl:apply-templates select="jp:contact" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         申請者編集
         ====================================================================-->
    <xsl:template name="申請者編集">
        <xsl:variable name="code">
            <xsl:choose>
                <xsl:when test="ancestor::jp:contents-of-amendment">
                    <xsl:choose>
                        <xsl:when
                            test="ancestor::jp:contents-of-amendment//jp:contents-of-amendment">
                            <xsl:value-of
                                select="normalize-space(ancestor::jp:amendment-group//jp:contents-of-amendment/jp:amendment-group/jp:document-code)" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of
                                select="normalize-space(ancestor::jp:amendment-group/jp:document-code)" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="normalize-space($doc-code)" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <xsl:when test="ancestor::jp:presenter-article">
                <xsl:value-of select="'　　【提出者】'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="./@jp:kind-of-application = 'appeal'">
                        <xsl:value-of select="'【審判請求人】'" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when test="ancestor::jp:applicants">
                                <xsl:call-template name="code-to-applicants1">
                                    <xsl:with-param name="code" select="$code" />
                                </xsl:call-template>
                            </xsl:when>
                            <xsl:otherwise><!--ancestor::jp:applicant-of-case-article-->
                                <xsl:call-template name="code-to-applicants2">
                                    <xsl:with-param name="code" select="$code" />
                                </xsl:call-template>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="code-to-applicants1">
        <xsl:param name="code" />
        <xsl:choose>
            <xsl:when test="matches($code, 'A[12]51|A[12]523')">
                <!-- = 'A151' or $code = 'A251' or $code = 'A1523' or $code = 'A2523' -->
                <xsl:value-of select="'【補正をする者】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^A263[2-6]?$') or
                matches($code, '^A276[1245]$') or
                matches($code, '^A253|A2521[012]|A252[5-9]$') or
                matches($code, '^A2801|A2917|A2IB3491$')">
                <!-- 
                     test="$code = 'A263' or $code = 'A2632'
                     or $code = 'A2633' or $code = 'A2634' or $code = 'A2635' or $code = 'A2626' 
                     or $code = 'A2761' or $code = 'A2762' or $code = 'A2764' or $code = 'A2765'
                     or $code = 'A253' or $code = 'A25210' or $code = 'A25211'
                     or $code = 'A25212' or $code = 'A2525' or $code = 'A2526'
                     or $code = 'A2527' or $code = 'A2528' or $code = 'A2529'
                     or $code = 'A2IB3491' or $code = 'A2801'
                     or $code = 'A2917'"> -->
                <xsl:value-of select="'【実用新案登録出願人】'" />
            </xsl:when>
            <xsl:when test="matches($code, '^A[12]55$')">
                <xsl:value-of select="'【受継申立人】'" />
            </xsl:when>
            <xsl:when test="matches($code, '^A[12]681$')">
                <xsl:value-of select="'【代表者】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^A[12]711$') or
                matches($code, '^A[12]712$')">
                <xsl:value-of select="'【承継人】'" />
            </xsl:when>

            <xsl:when
                test="matches($code, '^A[12]742[1-8]$') or
                matches($code, '^A[12]743[1-7]$') or
                $code = 'A167' or $code = 'A1916' or $code = 'A2916'">
                <!--
                     test=" $code = 'A17421' or $code = 'A27421'
                     or $code = 'A17422' or $code = 'A27422'
                     or $code = 'A17423' or $code = 'A27423'
                     or $code = 'A17424' or $code = 'A27424'
                     or $code = 'A17425' or $code = 'A27425'
                     or $code = 'A17426' or $code = 'A27426'
                     or $code = 'A17427' or $code = 'A27427'
                     or $code = 'A17428' or $code = 'A27428'
                     or $code = 'A17431' or $code = 'A27431'
                     or $code = 'A17432' or $code = 'A27432'
                     or $code = 'A17433' or $code = 'A27433'
                     or $code = 'A17434' or $code = 'A27434'
                     or $code = 'A17435' or $code = 'A27435'
                     or $code = 'A17436' or $code = 'A27436'
                     or $code = 'A17437' or $code = 'A27437'
                     or $code = 'A167' or $code = 'A1916' or $code = 'A2916'"> -->
                <xsl:value-of select="'【手続をした者】'" />
            </xsl:when>

            <xsl:when test="$code = 'A159' or $code = 'A259'">
                <xsl:value-of select="'【弁明をする者】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^A[12]691$') or
                matches($code, '^A[12]79$') or
                matches($code, '^A[12]8[012]$') or
                matches($code, '^A[12]822$') or
                matches($code, '^A[12]831$') or
                matches($code, '^A[12]87[12]?$')">
                <!--test="
                     $code = 'A1691' or $code = 'A2691'
                     or $code = 'A179' or $code = 'A279'
                     or $code = 'A180' or $code = 'A280'
                     or $code = 'A181' or $code = 'A281'
                     or $code = 'A182' or $code = 'A282'
                     or $code = 'A1822' or $code = 'A2822'
                     or $code = 'A1831' or $code = 'A2831'
                     or $code = 'A187' or $code = 'A287'
                     or $code = 'A1871' or $code = 'A2871'
                     or $code = 'A1872' or $code = 'A2872'"> -->
                <xsl:value-of select="'【提出者】'" />
            </xsl:when>

            <xsl:when
                test="matches($code, '^A[12]6[02]1$') or
                matches($code, '^A262[34]$') or
                matches($code, '^A[12]625$') or
                matches($code, '^E[12]84[12]$') or
                matches($code, '^E[12]85[1-4]$') or
                matches($code, '^E[12]86[12]$') or
                matches($code, '^E[34]85[34]$') or
                matches($code, '^E[34]862$') or
                matches($code, '^A[12]603$')">
                <!-- test="$code =  'A1601' or $code = 'A2601'
                     or $code = 'A1621' or $code = 'A2621'
                     or $code = 'A2623'
                     or $code = 'A2624'
                     or $code = 'A1625' or $code = 'A2625'
                     or $code = 'E1841' or $code = 'E2841'
                     or $code = 'E1842' or $code = 'E2842'
                     or $code = 'E1851' or $code = 'E2851'
                     or $code = 'E1852' or $code = 'E2852'
                     or $code = 'E1853' or $code = 'E2853'
                     or $code = 'E1854' or $code = 'E2854'
                     or $code = 'E1861' or $code = 'E2861'
                     or $code = 'E1862' or $code = 'E2862'
                     or $code = 'E3853' or $code = 'E4853'
                     or $code = 'E3854' or $code = 'E4854'
                     or $code = 'E3862' or $code = 'E4862'
                     or $code = 'A1603' or $code = 'A2603'"> -->
                <xsl:value-of select="'【請求人】'" />
            </xsl:when>
            <xsl:when test="$code = 'A1781' or $code = 'A2781'">
                <xsl:value-of select="'【上申をする者】'" />
            </xsl:when>
            <xsl:when test="$code = 'A1821' or $code = 'A2821' or $code = 'R4220'">
                <xsl:value-of select="'【補足をする者】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4201' or $code = 'R4211'">
                <xsl:value-of select="'【更新登録申請人】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^R[1-4]100$') or
                matches($code, '^R410[3-5]$') or
                matches($code, '^R[1-4]110$') or
                matches($code, '^R11[01][12]$') or
                matches($code, '^R411[3-5]$') or
                matches($code, '^R[1-3]20$') or
                matches($code, '^R42[01]0$') or
                matches($code, '^R[1-3]21$')">
                <!-- test="$code =  'R1100' or $code = 'R2100' or $code = 'R3100' or $code = 'R4100'
                     or $code = 'R4103' or $code = 'R4104' or $code = 'R4105'
                     or $code = 'R1110' or $code = 'R2110'or $code = 'R3110' or $code = 'R4110'
                     or $code = 'R1101' or $code = 'R3102' or $code = 'R1111' or $code = 'R3112'
                     or $code = 'R4113' or $code = 'R4114' or $code = 'R4115'
                     or $code = 'R120' or $code = 'R220' or $code = 'R320'
                     or $code = 'R4200' or $code = 'R4210'
                     or $code = 'R121' or $code = 'R221' or $code = 'R321' -->
                <xsl:value-of select="'【納付者】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^A163[1245]?$') or
                matches($code, '^A176[1245]$') or
                matches($code, '^A1521[012]$') or
                matches($code, '^A152[4-9]$') or
                $code = 'A153' or $code = 'A1IB3491' or
                $code = 'A1801' or $code = 'A1917' or  $code = 'A1627'">
                <!-- test="
                     or  $code ='A163' or $code = 'A1631' or $code = 'A1632' or $code = 'A1634' or $code = 'A1635'
                     or $code = 'A1761' or $code = 'A1762' or $code = 'A1764' or $code = 'A1765'
                     or $code = 'A15210' or $code = 'A15211' or $code = 'A15212'
                     or $code = 'A1524' or $code = 'A1525' or $code = 'A1526'
                     or $code = 'A1527' or $code = 'A1528' or $code = 'A1529'-->
                <xsl:value-of select="'【特許出願人】'" />
            </xsl:when>
            <xsl:when test="substring($code,1,1) = 'C' ">
                <xsl:choose>
                    <xsl:when test="matches($code, '^C[1-4]6543$')">
                        <xsl:value-of select="'【回答者】'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^C[1-4]6573$')">
                        <xsl:value-of select="'【鑑定人】'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '$C[1-4]6592^')">
                        <xsl:value-of select="'【証人】'" />
                    </xsl:when>
                    <xsl:when test="matches($code, '^C[12]875$')">
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="'【審判請求人】'" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>

            <xsl:when test="$code = 'A1914' or $code = 'A1915' or $code = 'A2915'">
                <xsl:value-of select="'【返還請求人】'" />
            </xsl:when>
            <xsl:when test="$code = 'A1918' or $code = 'A1919'">
                <xsl:value-of select="'【申出人】'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="code-to-applicants2">
        <xsl:param name="code" />
        <xsl:choose>
            <xsl:when test="matches($code, '^R11[01][01]$')">
                <xsl:value-of select="'【特許出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R2100' or $code = 'R2110'">
                <xsl:value-of select="'【実用新案登録出願人】'" />
            </xsl:when>
            <xsl:when test="matches($code, 'R31[01][02]')">
                <xsl:value-of select="'【意匠登録出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4100' or $code = 'R4110'">
                <xsl:value-of select="'【商標登録出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4103' or $code = 'R4113'">
                <xsl:value-of select="'【防護標章登録出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4104' or $code = 'R4114'">
                <xsl:value-of select="'【更新登録出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4105' or $code = 'R4115'">
                <xsl:value-of select="'【防護標章更新登録出願人】'" />
            </xsl:when>
            <xsl:when test="$code = 'R120' or $code = 'R121'">
                <xsl:value-of select="'【特許権者】'" />
            </xsl:when>
            <xsl:when test="$code = 'R220' or $code = 'R221'">
                <xsl:value-of select="'【実用新案権者】'" />
            </xsl:when>
            <xsl:when test="$code = 'R320' or $code = 'R321'">
                <xsl:value-of select="'【意匠権者】'" />
            </xsl:when>
            <xsl:when test="$code = 'R4200' or $code = 'R4210'">
                <xsl:value-of select="'【商標権者】'" />
            </xsl:when>
            <xsl:when test="$code = 'A1711' or $code = 'A2711'">
                <xsl:value-of select="'【譲渡人】'" />
            </xsl:when>
            <xsl:when test="$code = 'A1712' or $code = 'A2712'">
                <xsl:value-of select="'【被承継人】'" />
            </xsl:when>
            <xsl:when
                test="matches($code, '^A[12]742[24]$') or
                matches($code, '^A[12]743[1-7]$')">
                <!-- test="$code =  'A17422' or $code = 'A27422' or $code = 'A17424' or $code =
                'A27424'
                     or $code = 'A17431' or $code = 'A27431'
                     or $code = 'A17432' or $code = 'A27432'
                     or $code = 'A17433' or $code = 'A27433'
                     or $code = 'A17434' or $code = 'A27434'
                     or $code = 'A17435' or $code = 'A27435'
                     or $code = 'A17436' or $code = 'A27436'
                     or $code = 'A17437' or $code = 'A27437'"> -->
                <xsl:value-of select="'【手続をした者】'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="書誌編集エラー処理" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- ====================================================================
         jp:country 国コード
         <xsl:template name="国コード編集">
         ====================================================================-->
    <xsl:template match="jp:country">
        <xsl:element name="div">
            <xsl:choose>
                <xsl:when test="ancestor::jp:application-country-article">
                    <xsl:value-of select="'【出願国・地域名】　　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:priority-doc-location-info">
                    <xsl:value-of select="'　　【優先権証明書提供国（機関）】　'" />
                </xsl:when>
                <xsl:when test="ancestor::jp:priority-claim">
                    <xsl:value-of select="'　　【国・地域名】　　'" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'　　【国籍・地域】　　'" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:choose>
                <xsl:when test="./@jp:error-code">
                    <xsl:value-of select="." />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="国名県名変換" />
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         国名県名変換
         ====================================================================-->
    <xsl:template name="国名県名変換">
        <xsl:variable name="kuni" select="normalize-space(.)" />
        <xsl:variable name="item" select="key('item-use-key', $kuni, $countries)[1]" />
        <xsl:choose>
            <xsl:when test="string-length($item/@value) = 0">
                <xsl:value-of select="'***エラー***'" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$item/@value" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:variable name="countries">
        <item key="00" value="住所無し" />
        <item key="01" value="北海道" />
        <item key="02" value="青森県" />
        <item key="03" value="岩手県" />
        <item key="04" value="宮城県" />
        <item key="05" value="秋田県" />
        <item key="06" value="山形県" />
        <item key="07" value="福島県" />
        <item key="08" value="茨城県" />
        <item key="09" value="栃木県" />
        <item key="10" value="群馬県" />
        <item key="11" value="埼玉県" />
        <item key="12" value="千葉県" />
        <item key="13" value="東京都" />
        <item key="14" value="神奈川県" />
        <item key="15" value="新潟県" />
        <item key="16" value="富山県" />
        <item key="17" value="石川県" />
        <item key="18" value="福井県" />
        <item key="19" value="山梨県" />
        <item key="20" value="長野県" />
        <item key="21" value="岐阜県" />
        <item key="22" value="静岡県" />
        <item key="23" value="愛知県" />
        <item key="24" value="三重県" />
        <item key="25" value="滋賀県" />
        <item key="26" value="京都府" />
        <item key="27" value="大阪府" />
        <item key="28" value="兵庫県" />
        <item key="29" value="奈良県" />
        <item key="30" value="和歌山県" />
        <item key="31" value="鳥取県" />
        <item key="32" value="島根県" />
        <item key="33" value="岡山県" />
        <item key="34" value="広島県" />
        <item key="35" value="山口県" />
        <item key="36" value="徳島県" />
        <item key="37" value="香川県" />
        <item key="38" value="愛媛県" />
        <item key="39" value="高知県" />
        <item key="40" value="福岡県" />
        <item key="41" value="佐賀県" />
        <item key="42" value="長崎県" />
        <item key="43" value="熊本県" />
        <item key="44" value="大分県" />
        <item key="45" value="宮崎県" />
        <item key="46" value="鹿児島県" />
        <item key="47" value="沖縄県" />
        <item key="JP" value="日本" />
        <item key="AD" value="アンドラ" />
        <item key="AE" value="アラブ首長国連邦" />
        <item key="AF" value="アフガニスタン" />
        <item key="AG" value="アンティグア・バーブーダ" />
        <item key="AI" value="アンギラ" />
        <item key="AL" value="アルバニア" />
        <item key="AM" value="アルメニア" />
        <item key="AO" value="アンゴラ" />
        <item key="AP" value="アフリカ地域工業所有権機関" />
        <item key="AR" value="アルゼンチン" />
        <item key="AT" value="オーストリア" />
        <item key="AU" value="オーストラリア" />
        <item key="AW" value="アルバ島" />
        <item key="AZ" value="アゼルバイジャン" />
        <item key="BA" value="ボスニア・ヘルツェゴビナ" />
        <item key="BB" value="バルバドス" />
        <item key="BD" value="バングラデシュ" />
        <item key="BE" value="ベルギー" />
        <item key="BF" value="ブルキナファソ" />
        <item key="BG" value="ブルガリア" />
        <item key="BH" value="バーレーン" />
        <item key="BI" value="ブルンジ" />
        <item key="BJ" value="ベナン" />
        <item key="BM" value="バーミューダ" />
        <item key="BN" value="ブルネイ" />
        <item key="BO" value="ボリビア" />
        <item key="BQ" value="ボネール島、シント・ユースタティウス島、サバ島" />
        <item key="BR" value="ブラジル" />
        <item key="BS" value="バハマ" />
        <item key="BT" value="ブータン" />
        <item key="BU" value="ビルマ" />
        <item key="BW" value="ボツワナ" />
        <item key="BX" value="ベネルクス商標庁及びベネルクス意匠庁" />
        <item key="BY" value="ベラルーシ" />
        <item key="BZ" value="ベリーズ" />
        <item key="CA" value="カナダ" />
        <item key="CD" value="コンゴ民主共和国" />
        <item key="CF" value="中央アフリカ" />
        <item key="CG" value="コンゴ共和国" />
        <item key="CH" value="スイス" />
        <item key="CI" value="コートジボワール" />
        <item key="CK" value="クック諸島" />
        <item key="CL" value="チリ" />
        <item key="CM" value="カメルーン" />
        <item key="CN" value="中華人民共和国" />
        <item key="CO" value="コロンビア" />
        <item key="CR" value="コスタリカ" />
        <item key="CS" value="チェッコ・スロヴァキア" />
        <item key="CU" value="キューバ" />
        <item key="CV" value="カーボヴェルデ" />
        <item key="CW" value="キュラソー島" />
        <item key="CY" value="キプロス" />
        <item key="CZ" value="チェコ" />
        <item key="DD" value="ドイツ民主共和国" />
        <item key="DE" value="ドイツ" />
        <item key="DJ" value="ジブチ" />
        <item key="DK" value="デンマーク" />
        <item key="DM" value="ドミニカ" />
        <item key="DO" value="ドミニカ共和国" />
        <item key="DZ" value="アルジェリア" />
        <item key="EA" value="ユーラシア特許庁" />
        <item key="EC" value="エクアドル" />
        <item key="EE" value="エストニア" />
        <item key="EG" value="エジプト" />
        <item key="EM" value="欧州連合知的財産庁" />
        <item key="EP" value="欧州特許庁" />
        <item key="ER" value="エリトリア" />
        <item key="ES" value="スペイン" />
        <item key="ET" value="エチオピア" />
        <item key="FI" value="フィンランド" />
        <item key="FJ" value="フィジー" />
        <item key="FK" value="フォークランド諸島" />
        <item key="FO" value="フェロー諸島" />
        <item key="FR" value="フランス" />
        <item key="GA" value="ガボン" />
        <item key="GB" value="英国" />
        <item key="GC" value="湾岸協力理事会特許庁" />
        <item key="GD" value="グレナダ" />
        <item key="GE" value="ジョージア" />
        <item key="GG" value="ガーンジー島" />
        <item key="GH" value="ガーナ" />
        <item key="GI" value="ジブラルタル" />
        <item key="GM" value="ガンビア" />
        <item key="GN" value="ギニア" />
        <item key="GQ" value="赤道ギニア" />
        <item key="GR" value="ギリシャ" />
        <item key="GT" value="グアテマラ" />
        <item key="GW" value="ギニアビサウ" />
        <item key="GY" value="ガイアナ" />
        <item key="HK" value="香港" />
        <item key="HN" value="ホンジュラス" />
        <item key="HR" value="クロアチア" />
        <item key="HT" value="ハイチ" />
        <item key="HU" value="ハンガリー" />
        <item key="HV" value="上ヴォルタ共和国" />
        <item key="IB" value="国際事務局" />
        <item key="ID" value="インドネシア" />
        <item key="IE" value="アイルランド" />
        <item key="IL" value="イスラエル" />
        <item key="IM" value="マン島" />
        <item key="IN" value="インド" />
        <item key="IQ" value="イラク" />
        <item key="IR" value="イラン" />
        <item key="IS" value="アイスランド" />
        <item key="IT" value="イタリア" />
        <item key="JE" value="ジャージー島" />
        <item key="JM" value="ジャマイカ" />
        <item key="JO" value="ヨルダン" />
        <item key="KE" value="ケニア" />
        <item key="KG" value="キルギス" />
        <item key="KH" value="カンボジア" />
        <item key="KI" value="キリバス" />
        <item key="KM" value="コモロ" />
        <item key="KN" value="セントクリストファー・ネーヴィス" />
        <item key="KP" value="北朝鮮" />
        <item key="KR" value="大韓民国" />
        <item key="KW" value="クウェート" />
        <item key="KY" value="ケイマン諸島" />
        <item key="KZ" value="カザフスタン" />
        <item key="LA" value="ラオス" />
        <item key="LB" value="レバノン" />
        <item key="LC" value="セントルシア" />
        <item key="LI" value="リヒテンシュタイン" />
        <item key="LK" value="スリランカ" />
        <item key="LR" value="リベリア" />
        <item key="LS" value="レソト" />
        <item key="LT" value="リトアニア" />
        <item key="LU" value="ルクセンブルク" />
        <item key="LV" value="ラトビア" />
        <item key="LY" value="リビア" />
        <item key="MA" value="モロッコ" />
        <item key="MC" value="モナコ" />
        <item key="MD" value="モルドバ" />
        <item key="MG" value="マダガスカル" />
        <item key="MK" value="北マケドニア共和国" />
        <item key="ML" value="マリ" />
        <item key="MM" value="ミャンマー" />
        <item key="MN" value="モンゴル" />
        <item key="MO" value="マカオ" />
        <item key="MR" value="モーリタニア" />
        <item key="MS" value="モンセラット" />
        <item key="MT" value="マルタ" />
        <item key="MU" value="モーリシャス" />
        <item key="MV" value="モルディブ" />
        <item key="MW" value="マラウイ" />
        <item key="MX" value="メキシコ" />
        <item key="MY" value="マレーシア" />
        <item key="MZ" value="モザンビーク" />
        <item key="ME" value="モンテネグロ" />
        <item key="NA" value="ナミビア" />
        <item key="NE" value="ニジェール" />
        <item key="NG" value="ナイジェリア" />
        <item key="NI" value="ニカラグア" />
        <item key="NL" value="オランダ" />
        <item key="NO" value="ノルウェー" />
        <item key="NP" value="ネパール" />
        <item key="NR" value="ナウル" />
        <item key="NU" value="ニウエ" />
        <item key="NZ" value="ニュージーランド" />
        <item key="OA" value="アフリカ知的所有権機関" />
        <item key="OM" value="オマーン" />
        <item key="PA" value="パナマ" />
        <item key="PE" value="ペルー" />
        <item key="PG" value="パプアニューギニア" />
        <item key="PH" value="フィリピン" />
        <item key="PK" value="パキスタン" />
        <item key="PL" value="ポーランド" />
        <item key="PR" value="プエルトリコ" />
        <item key="PT" value="ポルトガル" />
        <item key="PW" value="パラオ" />
        <item key="PY" value="パラグアイ" />
        <item key="QA" value="カタール" />
        <item key="RH" value="南ローデシア" />
        <item key="RO" value="ルーマニア" />
        <item key="RU" value="ロシア" />
        <item key="RW" value="ルワンダ" />
        <item key="RS" value="セルビア" />
        <item key="SA" value="サウジアラビア" />
        <item key="SB" value="ソロモン" />
        <item key="SC" value="セーシェル" />
        <item key="SD" value="スーダン" />
        <item key="SE" value="スウェーデン" />
        <item key="SG" value="シンガポール" />
        <item key="SH" value="セントヘレナ島" />
        <item key="SI" value="スロベニア" />
        <item key="SK" value="スロバキア" />
        <item key="SL" value="シエラレオネ" />
        <item key="SM" value="サンマリノ" />
        <item key="SN" value="セネガル" />
        <item key="SO" value="ソマリア" />
        <item key="SR" value="スリナム" />
        <item key="ST" value="サントメ・プリンシペ" />
        <item key="SU" value="ソヴィエト連邦" />
        <item key="SV" value="エルサルバドル" />
        <item key="SX" value="シント・マールテン島" />
        <item key="SY" value="シリア" />
        <item key="SZ" value="エスワティニ" />
        <item key="TD" value="チャド" />
        <item key="TG" value="トーゴ" />
        <item key="TH" value="タイ" />
        <item key="TJ" value="タジキスタン" />
        <item key="TK" value="トケラウ諸島" />
        <item key="TL" value="東ティモール" />
        <item key="TM" value="トルクメニスタン" />
        <item key="TN" value="チュニジア" />
        <item key="TO" value="トンガ" />
        <item key="TR" value="トルコ" />
        <item key="TT" value="トリニダード・トバゴ" />
        <item key="TV" value="ツバル" />
        <item key="TW" value="台湾" />
        <item key="TZ" value="タンザニア" />
        <item key="UA" value="ウクライナ" />
        <item key="UG" value="ウガンダ" />
        <item key="US" value="アメリカ合衆国" />
        <item key="UY" value="ウルグアイ" />
        <item key="UZ" value="ウズベキスタン" />
        <item key="VA" value="バチカン" />
        <item key="VC" value="セントビンセント" />
        <item key="VE" value="ベネズエラ" />
        <item key="VG" value="ヴァージン諸島" />
        <item key="VN" value="ベトナム" />
        <item key="VU" value="バヌアツ" />
        <item key="WO" value="世界知的所有権機関" />
        <item key="WS" value="サモア" />
        <item key="XX" value="無国籍、その他の国名及び地域名" />
        <item key="YD" value="南イエメン" />
        <item key="YE" value="イエメン" />
        <item key="YU" value="セルビア・モンテネグロ" />
        <item key="ZA" value="南アフリカ" />
        <item key="ZM" value="ザンビア" />
        <item key="ZR" value="ザイール" />
        <item key="ZW" value="ジンバブエ" />
        <item key="99" value="９９" />
    </xsl:variable>

    <!-- ====================================================================
         未サポートタグ
         ====================================================================-->
    <xsl:template
        match="country | kind | name | prefix | last-name | first-name | midle-name
        | suffix | iid | role | orgname | department | synonym | address-1
        | address-2 | address-3 | mailcode | pobox | room | address-floor
        | building | street | city | county | state | postcode | email | url
        | ead | dtext | text | region | customer-number
        | jp:inventor/jp:addressbook/jp:original-language-of-name
        | jp:inventor/jp:addressbook/jp:address/jp:original-language-of-address
        | jp:inventor/jp:addressbook/jp:phone | jp:inventor/jp:addressbook/jp:fax
        | deceased-inventor/jp:registered-number | other-method
        | jp:agent/jp:representative-group//jp:original-language-of-name
        | jp:applicant-of-case-article//jp:share | jp:applicant-of-case-article//jp:representative-applicant
        | jp:applicant-of-case-article/jp:applicant//jp:original-language-of-address
        | jp:applicant-of-case-article/jp:applicant/jp:addressbook/jp:original-language-of-name
        | jp:applicant-of-case-article/jp:applicant/jp:representative-group//jp:original-language-of-name
        | jp:applicant-of-case-article//jp:office-address | jp:applicant-of-case-article//jp:office
        | jp:applicant-of-case-article//jp:office-in-japan
        | jp:applicant-of-case-article//jp:legal-entity-property
        | jp:attorney-of-case-article//jp:office-address
        | jp:rejection-case-accept-notice-art/jp:appeal-reference/jp:date
        | jp:rejection-case-accept-notice-art//country | jp:rejection-case-accept-notice-art//kind
        | jp:rejection-case-accept-notice-art//name
        | jp:rejection-case-accept-notice-art/jp:application-reference//jp:date
        | jp:withdrawal-kind | jp:withdrawn-date/jp:date | jp:accepted-date/jp:date
        | jp:preliminary-exam-report/jp:date | jp:demand-date/jp:date
        | jp:regional-patent-group/jp:regional-patent | jp:nationality-and-residence
        | doc-page | abst-problem | abst-solution
        | address-4 | address-5">
        <xsl:param name="i" />
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:value-of select="'unsupported tag' || name()" />
            </xsl:element>
            <xsl:element name="div">
                <xsl:value-of select="'&lt;' || name()" />
                <xsl:apply-templates select="./@*" />
                <xsl:value-of select="'&gt;' || . || '&lt;/' || name() || '&gt;'" />
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         ｐタグ未サポート
         ====================================================================-->
    <xsl:template
        match="b | i | smallcaps | dl | ul | ol | bio-deposit | crossref
        | o | pre | table-external-doc">
        <xsl:element name="div">
            <xsl:element name="div">
                <xsl:value-of select="'unsupported tag' || name()" />
            </xsl:element>
            <xsl:element name="div">
                <xsl:value-of select="'&lt;' || name()" />
                <xsl:apply-templates select="./@*" />
                <xsl:value-of select="'&gt;' || . || '&lt;/' || name() || '&gt;'" />
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         未サポートタグＥＭＰＴＹ
         ====================================================================-->
    <xsl:template
        match="priority-doc-requested | priority-doc-attached | fee-total
        | credit-card">
        <xsl:param name="i" />
        <xsl:element name="div">
            <xsl:value-of select="'unsupported tag' || name()" />
        </xsl:element>
        <xsl:element name="div">
            <xsl:value-of select="'&lt;' || name()" />
            <xsl:apply-templates select="./@*" />
            <xsl:value-of select="'&gt;' || . || '&lt;/' || name() || '&gt;'" />
        </xsl:element>
    </xsl:template>

    <!-- ====================================================================
         書誌編集エラー処理
         ====================================================================-->
    <xsl:template name="書誌編集エラー処理">
        <xsl:value-of select="'***エラー***'" />
    </xsl:template>

    <!-- ====================================================================
         属性値出力１
         ====================================================================-->
    <xsl:template
        match="@number | @expires | @name | @postal-code | @account-type
        | @jp:error-code | @appl-type | @jp:kind-of-law | @lang | @name-type
        | @sequence | @designation | @app-type | @jp:kind-of-application">
        <xsl:value-of select="' ' || name() || '=&quot;' || . || '&quot;'" />
    </xsl:template>

    <!-- ====================================================================
         属性値出力２
         ====================================================================-->
    <xsl:template
        match="@to-dead-inventor | @kind | @jp:kind-of-agent
        | @legal-representative| @amount | @fee-code | @quantity | @currency">
        <xsl:value-of select="' ' || name() || '=&quot;' || . || '&quot;'" />
    </xsl:template>

    <!-- ====================================================================
         属性値出力３
         ====================================================================-->
    <xsl:template match="@*" mode="misapo">
        <xsl:value-of select="' ' || name() || '=&quot;' || . || '&quot;'" />
    </xsl:template>


    <!-- 特実で切り分けが不要な要素  -->
    <xsl:template
        match="description | drawings | abstract |
        technical-field | background-art |  citation-list | patent-literature |
        non-patent-literature | tech-solution | description-of-drawings |
        industrial-applicability | sequence-list-text | reference-signs-list |
        reference-to-deposited-biological-material">
        <xsl:variable name="tags-table" select="key('item-use-key', name(), $tags)[1]" />

        <!-- <div class="description"> -->
        <xsl:element name="div">
            <xsl:attribute name="class" select="name()" />

            <!-- <div class="item-tag">(　　)?【書類名】明細書</div> -->
            <xsl:element name="div">
                <xsl:attribute name="class" select="$tags-table/@class" />
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="$tags-table/@jp-tag" />
            </xsl:element>

            <xsl:apply-templates />
        </xsl:element>
    </xsl:template>


    <!-- 特実で切り分けが必要な要素,項目後に改行しない要素。例：【発明の名称】ほげほげ -->
    <xsl:template match="invention-title">
        <xsl:variable name="tags-table"
            select="key('item-use-key', name() || $law-suffix, $tags)[1]" />

        <!-- <div class="invention-title"> -->
        <xsl:element name="div">
            <xsl:attribute name="class" select="name()" />

            <!-- <span class="item-tag">(　　)?【発明の名称】</span> -->
            <xsl:element name="span">
                <xsl:attribute name="class" select="$tags-table/@class" />
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="$tags-table/@jp-tag" />
            </xsl:element>

            <!-- <span>ほげほげ</span> -->
            <xsl:element name="span">
                <xsl:apply-templates />
            </xsl:element>

        </xsl:element>
    </xsl:template>

    <!-- 特実で切り分けが必要な要素,項目後に改行する要素。例：【発明の概要】\nほげほげ -->
    <xsl:template
        match="claims | summary-of-invention | disclosure | tech-problem |
        advantageous-effects | description-of-embodiments | best-mode">
        <xsl:variable name="item" select="key('item-use-key', name() || $law-suffix, $tags)[1]" />

        <!-- <div class="claims"> -->
        <xsl:element name="div">
            <xsl:attribute name="class" select="name()" />

            <!-- <div class="item-tag">(　　)?【発明の概要】</div> -->
            <xsl:element name="div">
                <xsl:attribute name="class" select="$item/@class" />
                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="$item/@jp-tag" />
            </xsl:element>

            <xsl:apply-templates />
        </xsl:element>

    </xsl:template>

    <xsl:template match="claim">
        <xsl:element name="div">
            <xsl:attribute name="class" select="name()" />
            <xsl:attribute name="data-claim-num" select="@num" />

            <xsl:element name="div">
                <xsl:attribute name="class" select="'claim-tag'" />

                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>
                <xsl:value-of select="'【請求項'" />
                <xsl:apply-templates select="@num" />
                <xsl:value-of select="'】'" />
            </xsl:element>

            <xsl:for-each select="claim-text">
                <xsl:apply-templates select="." />
            </xsl:for-each>
        </xsl:element>
    </xsl:template>

    <xsl:template match="claim-text">
        <xsl:element name="div">
            <xsl:apply-templates />
        </xsl:element>
    </xsl:template>

    <!-- 特許文献 非特許文献 図の説明 -->
    <xsl:template match="patcit | nplcit | figref">
        <xsl:variable name="tags-table" select="key('item-use-key', name(), $tags)[1]" />

        <!-- <div class="patcit-tag">   【特許文献1】 ＊＊＊＊</div> -->
        <xsl:element name="div">
            <xsl:attribute name="class" select="$tags-table/@class" />
            <xsl:attribute name="data-num" select="@num" />
            <xsl:value-of select="$tags-table/@jp-tag" />
            <xsl:value-of select="@num" />
            <xsl:value-of select="'】'" />
            <xsl:value-of select="." />
        </xsl:element>
    </xsl:template>

    <!-- 実施例 -->
    <xsl:template match="embodiments-example">
        <xsl:element name="div">
            <xsl:attribute name="class" select="'embodiments-example'" />
            <xsl:attribute name="data-num" select="@ex-num" />
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【実施例'" />
            <xsl:apply-templates select="@ex-num" />
            <xsl:value-of select="'】'" />
        </xsl:element>

        <xsl:apply-templates select="p" />
    </xsl:template>

    <!-- 実施例 -->
    <xsl:template match="mode-for-invention">
        <xsl:element name="div">
            <xsl:attribute name="class" select="'mode-for-invention'" />
            <xsl:attribute name="data-num" select="@mode-num" />
            <xsl:if test="ancestor::jp:contents-of-amendment">
                <xsl:value-of select="'　　'" />
            </xsl:if>
            <xsl:value-of select="'【実施例'" />
            <xsl:apply-templates select="@mode-num" />
            <xsl:value-of select="'】'" />
        </xsl:element>

        <xsl:apply-templates select="p" />
    </xsl:template>

    <!--  図,化,表,数   -->
    <xsl:template match="figure | chemistry | tables | maths">
        <xsl:variable name="item" select="key('item-use-key', name(), $tags)[1]" />

        <xsl:element name="div">
            <xsl:attribute name="class" select="name()" />
            <xsl:attribute name="data-num" select="@num" />

            <xsl:element name="div">
                <xsl:attribute name="class" select="$item/@class" />

                <xsl:if test="ancestor::jp:contents-of-amendment">
                    <xsl:value-of select="'　　'" />
                </xsl:if>

                <xsl:value-of select="$item/@jp-tag" />
                <xsl:apply-templates select="@num" />
                <xsl:value-of select="'】'" />
            </xsl:element>

            <xsl:apply-templates />
        </xsl:element>
    </xsl:template>

    <!--  段落 ,段落内テキスト  -->
    <xsl:template match="p">

        <!-- <p (data-num="0001")? > -->
        <xsl:element name="div">
            <xsl:if test="normalize-space(./@num) != ''">
                <xsl:attribute name="data-num" select="@num" />

                <!-- <span class="paragaraph-tag">(　)?【0001】</span>-->
                <xsl:element name="div">
                    <xsl:attribute name="class" select="'paragraph-tag'" />

                    <xsl:if test="ancestor::jp:contents-of-amendment">
                        <xsl:value-of select="'　'" />
                    </xsl:if>
                    <xsl:value-of select="'　【'" />
                    <xsl:value-of select="@num" />
                    <xsl:value-of select="'】'" />
                </xsl:element>
            </xsl:if>

            <!-- <div>text</div> -->
            <xsl:element name="div">
                <xsl:apply-templates />
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <!-- lookup <images> in source xml -->
    <xsl:key name="image-table" match="images/image[@size_tag=$image_size_tag]" use="@orig" />

    <!--  イメージ   -->
    <xsl:template match="figure/img | chemistry/img | tables/img | maths/img">
        <xsl:variable name="img-type" select="name(..)" />
        <xsl:variable name="img-number" select="../@num" />
        <xsl:variable name="img-desc" select="//description-of-drawings//figref[@num=$img-number]" />
        <xsl:variable name="item" select="key('image-table', @file)[1]" />
        <xsl:element name="div">
            <xsl:element name="img">
                <xsl:attribute name="src">
                    <xsl:value-of select="$item/@new" />
                </xsl:attribute>
                <xsl:attribute name="width">
                    <xsl:value-of select="$item/@width" />
                </xsl:attribute>
                <xsl:attribute name="height">
                    <xsl:value-of select="$item/@height" />
                </xsl:attribute>
                <xsl:attribute name="alt">
                    <xsl:value-of select="$img-type" />
                    <xsl:text> No.</xsl:text>
                    <xsl:value-of select="$img-number" />
                    <xsl:text> </xsl:text>
                    <xsl:value-of select="$img-desc" />
                </xsl:attribute>
            </xsl:element>
        </xsl:element>
    </xsl:template>

    <xsl:variable name="law-suffix">
        <xsl:choose>
            <xsl:when test="$kind-of-law = 'patent'">
                <xsl:value-of select="'-p'" />
            </xsl:when>
            <xsl:when test="$kind-of-law = 'utility'">
                <xsl:value-of select="'-u'" />
            </xsl:when>
        </xsl:choose>
    </xsl:variable>

    <xsl:variable name="tags">
        <item key="description" jp-tag="【書類名】明細書" class="document-tag" />
        <item key="drawings" jp-tag="【書類名】図面" class="document-tag" />
        <item key="claims-p" jp-tag="【書類名】特許請求の範囲" class="document-tag" />
        <item key="claims-u" jp-tag="【書類名】実用新案登録請求の範囲" class="document-tag" />
        <item key="abstract" jp-tag="【書類名】要約書" class="document-tag" />
        <item key="invention-title-p" jp-tag="【発明の名称】" class="item-tag" />
        <item key="invention-title-u" jp-tag="【考案の名称】" class="item-tag" />
        <item key="technical-field" jp-tag="【技術分野】" class="item-tag" />
        <item key="background-art" jp-tag="【背景技術】" class="item-tag" />
        <item key="citation-list" jp-tag="【先行技術文献】" class="item-tag" />
        <item key="patent-literature" jp-tag="【特許文献】" class="item-tag" />
        <item key="non-patent-literature" jp-tag="【非特許文献】" class="item-tag" />
        <item key="disclosure-p" jp-tag="【発明の開示】" class="item-tag" />
        <item key="disclosure-u" jp-tag="【考案の開示】" class="item-tag" />
        <item key="summary-of-invention-p" jp-tag="【発明の概要】" class="item-tag" />
        <item key="summary-of-invention-u" jp-tag="【考案の概要】" class="item-tag" />
        <item key="tech-problem-p" jp-tag="【発明が解決しようとする課題】" class="item-tag" />
        <item key="tech-problem-u" jp-tag="【考案が解決しようとする課題】" class="item-tag" />
        <item key="tech-solution" jp-tag="【課題を解決するための手段】" class="item-tag" />
        <item key="advantageous-effects-p" jp-tag="【発明の効果】" classe="item-tag" />
        <item key="advantageous-effects-u" jp-tag="【考案の効果】" classe="item-tag" />
        <item key="description-of-drawings" jp-tag="【図面の簡単な説明】" class="item-tag" />
        <item key="description-of-embodiments-p" jp-tag="【発明を実施するための形態】" class="item-tag" />
        <item key="description-of-embodiments-u" jp-tag="【考案を実施するための形態】" class="item-tag" />
        <item key="best-mode-p" jp-tag="【発明を実施するための最良の形態】" class="item-tag" />
        <item key="best-mode-u" jp-tag="【考案を実施するための最良の形態】" class="item-tag" />
        <item key="industrial-applicability" jp-tag="【産業上の利用可能性】" class="item-tag" />
        <item key="reference-signs-list" jp-tag="【符号の説明】" class="item-tag" />
        <item key="sequence-list-text" jp-tag="【配列表フリーテキスト】" class="item-tag" />
        <item key="mode-for-invention" jp-tag="【実施例】" class="item-tag" />
        <item key="reference-to-deposited-biological-material" jp-tag="【受託番号】" class="item-tag" />
        <item key="figure" jp-tag="【図" class="figure-tag" />
        <item key="chemistry" jp-tag="　　【化" class="chemistry" />
        <item key="tables" jp-tag="　　【表" class="table" />
        <item key="maths" jp-tag="　　【数" class="maths" />
        <item key="embodiments-example" jp-tag="【実施例" class="embodiments-example" />
        <item key="patcit" jp-tag="　　【特許文献" class="patcit" />
        <item key="nplcit" jp-tag="　　【非特許文献" class="nplcit" />
        <item key="figref" jp-tag="　　【図" class="figref" />
    </xsl:variable>

</xsl:stylesheet>