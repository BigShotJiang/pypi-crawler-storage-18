"""Synth AI SDK API."""
