from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "ZAI: Advanced Hybrid Transformer Framework with MoE, SSM, and Adaptive Routing"

setup(
    name="HAXZARC",
    version="0.1.6",
    author="Akik Faraji",
    author_email="akikfaraji@gmail.com",
    description="Advanced Hybrid Transformer Framework with MoE, SSM, and Adaptive Routing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/akikfaraji/zai",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.30.0",
        "tokenizers>=0.13.0",
        "sentencepiece>=0.1.98",
        "einops>=0.7.0",
        "tqdm>=4.65.0",
        "numpy>=1.24.0",
        "datasets>=2.14.0",
        "accelerate>=0.23.0",
        "quanto",
        "pydantic>=2.0",
        "pyarrow>=14.0.0",
        "pandas>=2.0.0",
        "psutil>=5.9.0",
        "scipy>=1.11.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    include_package_data=True,
    package_data={
        "haxzarc": [
            "tokenizer/pretrained/*.json",
            "tokenizer/pretrained/metadata.json",
        ],
    },
    zip_safe=False,
)
