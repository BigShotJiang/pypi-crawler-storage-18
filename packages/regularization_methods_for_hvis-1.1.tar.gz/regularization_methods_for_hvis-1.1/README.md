# Regularization Methods for HVIs

This repository contains a hierarchical solver packaged for Python. The solver is aimed at variational inequalities
defined over the solution set of a monotone inclusion problem. The problem setting and the employed algorithm are
described in [[1]](#1).

## Installation

The package is available through pip, and may be installed via:

```bash
pip install Regularization-Methods-for-HVIs
```

If running the package locally, you can install it using:

```bash
pip install .
```

## Examples

Examples may in found in
the [/examples](https://github.com/Hierarchical-VIs/Regularization-Methods-for-HVIs/tree/main/examples) directory of the
repository. These examples additionally constitute the plots generated in the paper [[1]](#1).

## References

<a id="1">[1]</a> Yet unpublished. 