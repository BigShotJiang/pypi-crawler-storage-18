"""
Tests for the theme module.
"""

import pytest
import re
from grucli.theme import Colors, Borders, Icons, Styles, get_terminal_width


# ANSI escape code pattern
ANSI_PATTERN = re.compile(r'\033\[[0-9;]*m')


class TestColors:
    """Test color constants."""
    
    def test_colors_are_valid_ansi(self):
        """All color codes should be valid ANSI sequences."""
        color_attrs = [
            'PRIMARY', 'SECONDARY', 'ACCENT',
            'SUCCESS', 'WARNING', 'ERROR', 'INFO', 'MUTED', 'WHITE',
            'READ_OP', 'WRITE_OP', 'DESTRUCTIVE_OP',
            'PROMPT', 'HEADER', 'TITLE', 'SUBTITLE',
            'DIM', 'BOLD', 'ITALIC', 'UNDERLINE', 'REVERSE', 'RESET',
            'INPUT_ACTIVE', 'INPUT_DISABLED', 'INPUT_CONFIRM', 'INPUT_ERROR'
        ]
        
        for attr in color_attrs:
            value = getattr(Colors, attr)
            assert value.startswith('\033['), f"{attr} should start with ANSI escape"
    
    def test_reset_is_standard(self):
        """Reset should be the standard ANSI reset code."""
        assert Colors.RESET == '\033[0m'
    
    def test_semantic_colors_distinct(self):
        """Semantic colors should be distinct from each other."""
        assert Colors.SUCCESS != Colors.ERROR
        assert Colors.SUCCESS != Colors.WARNING
        assert Colors.ERROR != Colors.WARNING
    
    def test_tool_category_colors_distinct(self):
        """Tool category colors should be distinct."""
        assert Colors.READ_OP != Colors.WRITE_OP
        assert Colors.WRITE_OP != Colors.DESTRUCTIVE_OP
        assert Colors.READ_OP != Colors.DESTRUCTIVE_OP


class TestBorders:
    """Test border characters."""
    
    def test_rounded_corners_exist(self):
        """Rounded corner characters should exist."""
        assert Borders.TOP_LEFT == "╭"
        assert Borders.TOP_RIGHT == "╮"
        assert Borders.BOTTOM_LEFT == "╰"
        assert Borders.BOTTOM_RIGHT == "╯"
    
    def test_lines_exist(self):
        """Line characters should exist."""
        assert Borders.HORIZONTAL == "─"
        assert Borders.VERTICAL == "│"
    
    def test_can_draw_box(self):
        """Should be able to draw a simple box."""
        box = (
            f"{Borders.TOP_LEFT}{Borders.HORIZONTAL * 5}{Borders.TOP_RIGHT}\n"
            f"{Borders.VERTICAL}     {Borders.VERTICAL}\n"
            f"{Borders.BOTTOM_LEFT}{Borders.HORIZONTAL * 5}{Borders.BOTTOM_RIGHT}"
        )
        assert "╭" in box
        assert "╯" in box


class TestIcons:
    """Test icon characters."""
    
    def test_status_icons_exist(self):
        """Status icons should exist."""
        assert Icons.CHECK == "✓"
        assert Icons.CROSS == "✗"
        assert Icons.WARNING == "⚠"
        assert Icons.INFO == "ℹ"
    
    def test_tool_icons_exist(self):
        """Tool category icons should exist."""
        assert Icons.READ == "[READ]"
        assert Icons.WRITE == "[WRITE]"
        assert Icons.DELETE == "[DELETE]"
    
    def test_spinner_frames_exist(self):
        """Spinner should have frames."""
        assert len(Icons.SPINNER_FRAMES) > 0
        assert len(Icons.SPINNER_FRAMES) >= 8  # Should have enough frames for smooth animation


class TestStyles:
    """Test style helper functions."""
    
    def test_success_applies_color(self):
        """success() should apply green color."""
        result = Styles.success("test")
        assert Colors.SUCCESS in result
        assert Colors.RESET in result
        assert "test" in result
    
    def test_error_applies_color(self):
        """error() should apply red color."""
        result = Styles.error("test")
        assert Colors.ERROR in result
        assert Colors.RESET in result
    
    def test_warning_applies_color(self):
        """warning() should apply yellow color."""
        result = Styles.warning("test")
        assert Colors.WARNING in result
        assert Colors.RESET in result
    
    def test_muted_applies_color(self):
        """muted() should apply gray color."""
        result = Styles.muted("test")
        assert Colors.MUTED in result
        assert Colors.RESET in result
    
    def test_style_returns_string(self):
        """All style functions should return strings."""
        assert isinstance(Styles.success("test"), str)
        assert isinstance(Styles.error("test"), str)
        assert isinstance(Styles.bold("test"), str)
        assert isinstance(Styles.primary("test"), str)


class TestTerminalWidth:
    """Test terminal width utility."""
    
    def test_returns_integer(self):
        """get_terminal_width() should return an integer."""
        width = get_terminal_width()
        assert isinstance(width, int)
    
    def test_returns_reasonable_value(self):
        """Width should be a reasonable terminal size."""
        width = get_terminal_width()
        assert width >= 40  # Minimum reasonable terminal
        assert width <= 500  # Maximum reasonable terminal
