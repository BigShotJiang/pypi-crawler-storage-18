"""
Integration tests for grucli.
"""

import pytest
from grucli.permissions import (
    PermissionGroup,
    PermissionStore,
    get_tool_permission_group,
)


class TestPermissionFlowAllowOnce:
    """Test the allow once permission flow."""
    
    def test_allow_once_does_not_persist(self):
        """After allowing once, same tool should require permission again."""
        store = PermissionStore()
        
        # Simulate "allow once" - we don't call allow_always
        # Check that nothing is stored
        assert not store.is_allowed(PermissionGroup.READ)
        
        # Simulate allowing once (nothing stored)
        # Next check should still require permission
        assert not store.is_allowed(PermissionGroup.READ)


class TestPermissionFlowAllowAlways:
    """Test the allow always permission flow."""
    
    def test_allow_always_persists(self):
        """Allow always should persist for session."""
        store = PermissionStore()
        
        # Allow read operations always
        store.allow_always(PermissionGroup.READ)
        
        # Should be allowed on subsequent checks
        assert store.is_allowed(PermissionGroup.READ)
        assert store.is_allowed(PermissionGroup.READ)
        assert store.is_allowed(PermissionGroup.READ)
    
    def test_allow_always_applies_to_group(self):
        """Allow always should apply to all tools in group."""
        store = PermissionStore()
        
        # Allow read group
        store.allow_always(PermissionGroup.READ)
        
        # All read tools should be allowed
        read_tools = ['read_file', 'get_current_directory_structure']
        for tool in read_tools:
            group = get_tool_permission_group(tool)
            assert store.is_allowed(group), f"{tool} should be allowed"


class TestPermissionFlowDenyCascade:
    """Test that denying cascades properly."""
    
    def test_deny_leaves_store_unchanged(self):
        """Denying should not change permission store."""
        store = PermissionStore()
        
        # Store is empty
        assert not store.is_allowed(PermissionGroup.READ)
        
        # Simulating deny - nothing should change
        # (In real code, we just don't call allow_always)
        
        # Should still not be allowed
        assert not store.is_allowed(PermissionGroup.READ)


class TestMultiToolSequence:
    """Test sequences of multiple tools."""
    
    def test_multiple_read_tools_with_allow_always(self):
        """Multiple read tools should be auto-approved after allow always."""
        store = PermissionStore()
        
        # First tool - allow always for read
        store.allow_always(PermissionGroup.READ)
        
        # Subsequent read tools should be auto-approved
        tools = [
            'read_file',
            'get_current_directory_structure',
            'read_file',
        ]
        
        for tool in tools:
            group = get_tool_permission_group(tool)
            assert store.is_allowed(group), f"{tool} should be auto-approved"
    
    def test_mixed_groups_require_separate_approval(self):
        """Different groups should require separate approvals."""
        store = PermissionStore()
        
        # Allow read
        store.allow_always(PermissionGroup.READ)
        
        # Read should be allowed
        assert store.is_allowed(PermissionGroup.READ)
        
        # Write should still need approval
        assert not store.is_allowed(PermissionGroup.WRITE)
        
        # Destructive should still need approval
        assert not store.is_allowed(PermissionGroup.DESTRUCTIVE)
    
    def test_destructive_requires_own_approval(self):
        """Destructive operations require their own approval."""
        store = PermissionStore()
        
        # Allow read and write
        store.allow_always(PermissionGroup.READ)
        store.allow_always(PermissionGroup.WRITE)
        
        # Destructive still needs approval
        assert not store.is_allowed(PermissionGroup.DESTRUCTIVE)
        
        # Allow destructive
        store.allow_always(PermissionGroup.DESTRUCTIVE)
        assert store.is_allowed(PermissionGroup.DESTRUCTIVE)


class TestSessionReset:
    """Test session reset behavior."""
    
    def test_reset_clears_all_permissions(self):
        """Reset should clear all allowed groups."""
        store = PermissionStore()
        
        # Allow all groups
        store.allow_always(PermissionGroup.READ)
        store.allow_always(PermissionGroup.WRITE)
        store.allow_always(PermissionGroup.DESTRUCTIVE)
        
        # Verify all allowed
        assert store.is_allowed(PermissionGroup.READ)
        assert store.is_allowed(PermissionGroup.WRITE)
        assert store.is_allowed(PermissionGroup.DESTRUCTIVE)
        
        # Reset
        store.reset()
        
        # Verify all need approval again
        assert not store.is_allowed(PermissionGroup.READ)
        assert not store.is_allowed(PermissionGroup.WRITE)
        assert not store.is_allowed(PermissionGroup.DESTRUCTIVE)
