"""
Tests for the UI module.
"""

import pytest
from grucli.ui import (
    format_tool_call_block,
    format_diff,
    Spinner,
)
from grucli.theme import Colors, Borders


class TestToolCallFormatting:
    """Test tool call display formatting."""
    
    def test_read_tool_uses_correct_color(self):
        """Read tools should use cyan color."""
        result = format_tool_call_block('read_file', {'path': 'test.py'}, 'read')
        assert Colors.READ_OP in result or '📖' in result
        assert 'read_file' in result
    
    def test_write_tool_uses_correct_color(self):
        """Write tools should use orange color."""
        result = format_tool_call_block('create_file', {'path': 'test.py', 'content': 'hello'}, 'write')
        assert Colors.WRITE_OP in result or '📝' in result
        assert 'create_file' in result
    
    def test_destructive_tool_uses_correct_color(self):
        """Destructive tools should use red color."""
        result = format_tool_call_block('delete_file', {'path': 'test.py'}, 'destructive')
        assert Colors.DESTRUCTIVE_OP in result or '🗑' in result
        assert 'delete_file' in result
    
    def test_contains_box_characters(self):
        """Output should contain box drawing characters."""
        result = format_tool_call_block('read_file', {'path': 'test.py'}, 'read')
        assert Borders.TOP_LEFT in result or Borders.HORIZONTAL in result
    
    def test_includes_arguments(self):
        """Output should include tool arguments."""
        result = format_tool_call_block('read_file', {'path': 'src/main.py'}, 'read')
        assert 'path' in result
        assert 'src/main.py' in result or 'main.py' in result
    
    def test_truncates_long_values(self):
        """Long argument values should be truncated."""
        long_content = "x" * 200
        result = format_tool_call_block('create_file', {'content': long_content}, 'write')
        # Should not contain full content, should have ellipsis
        assert long_content not in result
        assert "..." in result or len(result) < 400


class TestDiffFormatting:
    """Test GitHub-style diff display."""
    
    def test_additions_in_green(self):
        """Additions should be marked with + and green color."""
        result = format_diff("old", "new", "test.py")
        assert Colors.SUCCESS in result or '+' in result
        assert 'new' in result
    
    def test_deletions_in_red(self):
        """Deletions should be marked with - and red color."""
        result = format_diff("old", "new", "test.py")
        assert Colors.ERROR in result or '-' in result
        assert 'old' in result
    
    def test_includes_filename(self):
        """Diff should include filename."""
        result = format_diff("old", "new", "config.json")
        assert 'config.json' in result
    
    def test_has_box_structure(self):
        """Diff should have box structure."""
        result = format_diff("old", "new", "test.py")
        assert Borders.TOP_LEFT in result or Borders.HORIZONTAL in result
    
    def test_multiline_content(self):
        """Should handle multiline content."""
        old = "line1\nline2\nline3"
        new = "line1\nmodified\nline3"
        result = format_diff(old, new, "test.py")
        assert 'line1' in result or '+' in result
    
    def test_truncates_many_lines(self):
        """Should truncate very long diffs."""
        old = "\n".join([f"line{i}" for i in range(50)])
        new = "replaced"
        result = format_diff(old, new, "test.py")
        # Should indicate truncation
        assert 'more lines' in result or '...' in result


class TestSpinner:
    """Test the loading spinner."""
    
    def test_spinner_has_frames(self):
        """Spinner should have animation frames."""
        spinner = Spinner()
        assert len(spinner.frames) > 0
    
    def test_spinner_has_message(self):
        """Spinner should have a message."""
        spinner = Spinner("Loading model")
        assert spinner.message == "Loading model"
    
    def test_spinner_default_message(self):
        """Spinner should have default message."""
        spinner = Spinner()
        assert spinner.message == "Generating"
    
    def test_spinner_starts_not_running(self):
        """Spinner should start in stopped state."""
        spinner = Spinner()
        assert not spinner._running
    
    def test_spinner_stop_sets_flag(self):
        """Stopping spinner should set running to False."""
        spinner = Spinner()
        spinner._running = True
        spinner.stop()
        assert not spinner._running
    
    def test_spinner_context_manager(self):
        """Spinner should work as context manager."""
        with Spinner() as s:
            # Should start running
            pass
        # Should stop after context
        assert not s._running
