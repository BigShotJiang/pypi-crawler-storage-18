import pytest
from prompt_toolkit.formatted_text import ANSI, to_formatted_text
from grucli.theme import Colors


def test_ansi_object_conversion():
    """Verify that ANSI object can be converted to fragments using to_formatted_text."""
    text = f"{Colors.PRIMARY}Hello{Colors.RESET}"
    ansi_obj = ANSI(text)
    
    # ANSI objects themselves are not iterable, but to_formatted_text handles them
    fragments = to_formatted_text(ansi_obj)
    assert len(fragments) > 0
    
    # Each fragment should be a tuple (style, text)
    for fragment in fragments:
        assert isinstance(fragment, tuple)
        assert len(fragment) >= 2


def test_ansi_list_flattening():
    """Verify the pattern used in select_option: extending a list with fragments from to_formatted_text(ANSI)."""
    text_list = []
    
    # This is what we now do in select_option
    text_list.extend(to_formatted_text(ANSI(f"{Colors.HEADER}Title{Colors.RESET}\n")))
    text_list.extend(to_formatted_text(ANSI(f"  Option 1\n")))
    
    # Verify the structure is a flat list of fragments
    for item in text_list:
        assert isinstance(item, tuple), "List should contain fragments, not ANSI objects"
        assert not isinstance(item, ANSI), "List should not contain raw ANSI objects"


def test_ansi_unpacking_raises_typeerror():
    """Verify that we can't unpack an ANSI object directly, which caused the user's crash."""
    ansi_obj = ANSI("test")
    
    # This raised TypeError in the user's crash when prompt_toolkit's split_lines
    # tried to iterate over a list containing the ANSI object.
    with pytest.raises(TypeError):
        # ANSI is not iterable directly
        for x in ansi_obj:
            pass
