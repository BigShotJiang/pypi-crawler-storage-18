"""
Session statistics tracking for grucli.
"""

import time
import uuid
import sys
from .theme import Colors, Borders, Icons


class SessionStats:
    """Track statistics for the current session."""
    
    def __init__(self):
        self.session_id = str(uuid.uuid4())[:8]  # Short ID
        self.start_time = time.time()
        self.tool_calls_total = 0
        self.tool_calls_success = 0
        self.tool_calls_failed = 0
        self.model_usage = {}  # {model_name: {'reqs': 0, 'input_tokens': 0, 'cache_reads': 0, 'output_tokens': 0}}
        self.api_time_total = 0
    
    def record_tool_call(self, success=True):
        """Record a tool call result."""
        self.tool_calls_total += 1
        if success:
            self.tool_calls_success += 1
        else:
            self.tool_calls_failed += 1
            
    def record_request(self, model_name, api_duration=0):
        """Record an API request."""
        if model_name not in self.model_usage:
            self.model_usage[model_name] = {'reqs': 0, 'input_tokens': 0, 'cache_reads': 0, 'output_tokens': 0}
        self.model_usage[model_name]['reqs'] += 1
        self.api_time_total += api_duration
        
    def record_tokens(self, model_name, input_tokens=0, output_tokens=0, cache_reads=0):
        """Record token usage for a model."""
        if model_name not in self.model_usage:
            self.model_usage[model_name] = {'reqs': 0, 'input_tokens': 0, 'cache_reads': 0, 'output_tokens': 0}
        self.model_usage[model_name]['input_tokens'] += input_tokens
        self.model_usage[model_name]['output_tokens'] += output_tokens
        self.model_usage[model_name]['cache_reads'] += cache_reads

    def get_formatted_summary(self):
        """Generate a formatted summary of the session."""
        end_time = time.time()
        wall_time = end_time - self.start_time
        
        minutes = int(wall_time // 60)
        seconds = int(wall_time % 60)
        wall_time_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"
        
        tool_success_rate = 0.0
        if self.tool_calls_total > 0:
            tool_success_rate = (self.tool_calls_success / self.tool_calls_total) * 100
            
        api_time_pct = 0.0
        if wall_time > 0:
            api_time_pct = (self.api_time_total / wall_time) * 100

        summary = []
        
        # Header
        summary.append("")
        summary.append(f"{Colors.MUTED}{Borders.HORIZONTAL * 50}{Colors.RESET}")
        summary.append(f"{Colors.PRIMARY}{Colors.BOLD}Session Summary{Colors.RESET}  {Colors.MUTED}#{self.session_id}{Colors.RESET}")
        summary.append(f"{Colors.MUTED}{Borders.HORIZONTAL * 50}{Colors.RESET}")
        
        # Time
        summary.append(f"  {Colors.MUTED}Duration:{Colors.RESET}    {Colors.WHITE}{wall_time_str}{Colors.RESET}")
        summary.append(f"  {Colors.MUTED}API Time:{Colors.RESET}    {Colors.WHITE}{self.api_time_total:.1f}s{Colors.RESET} {Colors.MUTED}({api_time_pct:.0f}%){Colors.RESET}")
        
        # Tools
        if self.tool_calls_total > 0:
            success_color = Colors.SUCCESS if self.tool_calls_failed == 0 else Colors.WARNING
            summary.append(f"  {Colors.MUTED}Tool Calls:{Colors.RESET}  {Colors.WHITE}{self.tool_calls_total}{Colors.RESET} {Colors.MUTED}({Colors.SUCCESS}{Icons.CHECK}{self.tool_calls_success}{Colors.MUTED} {Colors.ERROR}{Icons.CROSS}{self.tool_calls_failed}{Colors.MUTED}){Colors.RESET}")
        
        # Model usage
        if self.model_usage:
            summary.append("")
            summary.append(f"  {Colors.MUTED}Models Used:{Colors.RESET}")
            for model, usage in self.model_usage.items():
                # Truncate long model names
                display_model = model if len(model) < 30 else model[:27] + "..."
                summary.append(f"    {Colors.SECONDARY}{display_model}{Colors.RESET} {Colors.MUTED}({usage['reqs']} requests){Colors.RESET}")

        summary.append(f"{Colors.MUTED}{Borders.HORIZONTAL * 50}{Colors.RESET}")
        summary.append("")
        
        return "\n".join(summary)

    def print_summary(self):
        """Print the session summary."""
        print(self.get_formatted_summary())


# Global instance
STATS = SessionStats()
