"""
Command handling for grucli slash commands.
"""

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from . import api
from . import config
from . import tools
from . import auth
from . import interrupt
from . import chat_manager
from . import ui
from .theme import Colors, Icons, Borders
import os
import time

CMD_LIST = ['/exit', '/clear', '/help', '/model', '/manage-api-keys', '/gemini-login', '/gemini-auth-mode', '/show-reasoning', '/save', '/load', '/manage-chats']


class ChatCompleter(Completer):
    """Completer for slash commands and @file mentions."""
    
    def __init__(self):
        self._file_cache = []
        self._last_cache_time = 0

    def get_completions(self, document, complete_event):
        text_before_cursor = document.text_before_cursor
        if not text_before_cursor:
            return

        last_space = text_before_cursor.rfind(' ')
        current_word = text_before_cursor[last_space+1:]

        if text_before_cursor.startswith('/') and ' ' not in text_before_cursor:
            for cmd in CMD_LIST:
                if cmd.startswith(text_before_cursor):
                    yield Completion(
                        cmd,
                        start_position=-len(text_before_cursor),
                        display=HTML(f'<style color="#af5fff">{cmd}</style>')
                    )
            return

        if text_before_cursor.startswith('/load ') and ' ' not in text_before_cursor[6:]:
            chat_prefix = text_before_cursor[6:].lower()
            chats = chat_manager.list_chats()
            for chat in chats:
                name = chat['name']
                if name.lower().startswith(chat_prefix):
                    yield Completion(
                        name,
                        start_position=-len(chat_prefix),
                        display=HTML(f'<style color="#af5fff">{name}</style>')
                    )
            return

        if '@' in current_word:
            at_idx = current_word.rfind('@')
            mention = current_word[at_idx+1:]
            mention_lower = mention.lower()
            
            # Simple cache to avoid walking disk on every character
            now = time.time()
            if now - self._last_cache_time > 5:
                self._file_cache = tools.list_files_recursive()
                self._last_cache_time = now
                
            for file_path in self._file_cache:
                if mention_lower in file_path.lower():
                    yield Completion(
                        file_path,
                        start_position=-len(mention),
                        display=HTML(f'<style color="#af5fff">@{file_path}</style>')
                    )


completer = ChatCompleter()


def manage_api_key(api_type='gemini'):
    """Manage saved API keys."""
    api_name = api_type.capitalize()
    
    print(f"\n{Colors.PRIMARY}{Colors.BOLD}{api_name} API Key Management{Colors.RESET}")
    print(f"{Colors.MUTED}{Borders.HORIZONTAL * 30}{Colors.RESET}\n")
    
    print(f"  {Colors.SUCCESS}1{Colors.RESET}) Change stored API key")
    print(f"  {Colors.WARNING}2{Colors.RESET}) Change password")
    print(f"  {Colors.ERROR}3{Colors.RESET}) Remove stored API key")
    print(f"  {Colors.MUTED}4{Colors.RESET}) Cancel")
    print()
    
    choice = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}Choose (1-4): {Colors.RESET}").strip()

    if choice == '1':
        if config.has_saved_api_key(api_type):
            print(f"\n{Colors.MUTED}Enter new {api_name} API key:{Colors.RESET}")
            new_api_key = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}> {Colors.RESET}").strip()
            if new_api_key:
                config.save_encrypted_api_key(new_api_key, api_type)
                print(f"{Colors.SUCCESS}{Icons.CHECK} API key updated.{Colors.RESET}")
            else:
                print(f"{Colors.WARNING}No API key provided.{Colors.RESET}")
        else:
            print(f"{Colors.WARNING}No saved API key found. Use the main interface to save a new API key.{Colors.RESET}")

    elif choice == '2':
        config.change_encrypted_api_key_password(api_type)

    elif choice == '3':
        config.remove_saved_api_key(api_type)

    elif choice == '4':
        print(f"{Colors.MUTED}Cancelled.{Colors.RESET}")
    else:
        print(f"{Colors.ERROR}Invalid option. Please choose 1-4.{Colors.RESET}")


def handle_command(cmd, state):
    """Handle slash commands."""
    c = cmd.lower().strip()
    
    if c == '/exit':
        return "exit"
        
    elif c == '/clear':
        # Reload custom prompt on clear
        sys_prompt = api.get_system_prompt()
        state['messages'] = [{"role": "system", "content": sys_prompt}]
        print(f"{Colors.SUCCESS}{Icons.CHECK} Chat cleared.{Colors.RESET}\n")
        return "continue"
        
    elif c == '/help':
        print(f"\n{Colors.PRIMARY}{Colors.BOLD}Available Commands{Colors.RESET}")
        print(f"{Colors.MUTED}{Borders.HORIZONTAL * 40}{Colors.RESET}\n")
        
        commands_help = [
            ('/help', 'Show this help message'),
            ('/exit', 'Exit the application'),
            ('/clear', 'Clear the current chat history'),
            ('/model', 'Switch between different models'),
            ('/manage-api-keys', 'Manage your saved API keys'),
            ('/gemini-login', 'Login with your Google account'),
            ('/gemini-auth-mode', 'Toggle Google Auth vs API Key mode'),
            ('/show-reasoning', 'Toggle showing reasoning tokens [true/false]'),
            ('/save [name]', 'Save current chat history'),
            ('/load [name]', 'Load a saved chat history'),
            ('/manage-chats', 'Manage (load/rename/delete) saved chats'),
        ]
        
        for cmd_name, desc in commands_help:
            print(f"  {Colors.SECONDARY}{cmd_name:20}{Colors.RESET} {Colors.MUTED}{desc}{Colors.RESET}")
        
        print(f"\n{Colors.MUTED}Tip: Use @filename to attach file contents to your message.{Colors.RESET}\n")
        return "continue"
        
    elif c == '/model':
        return "select_model"
        
    elif c == '/manage-api-keys':
        print(f"\n{Colors.PRIMARY}{Colors.BOLD}Select API to Manage{Colors.RESET}")
        print(f"{Colors.MUTED}{Borders.HORIZONTAL * 25}{Colors.RESET}\n")
        
        print(f"  {Colors.SUCCESS}1{Colors.RESET}) OpenAI API")
        print(f"  {Colors.SUCCESS}2{Colors.RESET}) Anthropic API")
        print(f"  {Colors.SUCCESS}3{Colors.RESET}) Gemini API")
        print(f"  {Colors.SUCCESS}4{Colors.RESET}) Cerebras API")
        print(f"  {Colors.MUTED}5{Colors.RESET}) Cancel")
        print()

        choice = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}Choose (1-5): {Colors.RESET}").strip()
        if choice == '1':
            manage_api_key('openai')
        elif choice == '2':
            manage_api_key('anthropic')
        elif choice == '3':
            manage_api_key('gemini')
        elif choice == '4':
            manage_api_key('cerebras')
        elif choice == '5':
            print(f"{Colors.MUTED}Cancelled.{Colors.RESET}")
        else:
            print(f"{Colors.ERROR}Invalid option.{Colors.RESET}")

        return "continue"
        
    elif c == '/gemini-login':
        print(f"\n{Colors.INFO}Starting Google OAuth login flow...{Colors.RESET}")
        try:
            auth.perform_oauth_login()
            print(f"{Colors.SUCCESS}{Icons.CHECK} Successfully logged in with Google!{Colors.RESET}")
            config.set_use_google_auth(True)
            print(f"{Colors.MUTED}Switched to Google Auth mode.{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.ERROR}{Icons.CROSS} Login failed: {e}{Colors.RESET}")
        return "continue"
        
    elif c == '/gemini-auth-mode':
        current_mode = "Google Auth" if config.is_using_google_auth() else "Gemini API Key"
        print(f"\n{Colors.PRIMARY}{Colors.BOLD}Gemini Authentication Mode{Colors.RESET}")
        print(f"{Colors.MUTED}{Borders.HORIZONTAL * 30}{Colors.RESET}")
        print(f"\n{Colors.MUTED}Current mode:{Colors.RESET} {Colors.SECONDARY}{current_mode}{Colors.RESET}")
        
        if config.is_using_google_auth():
            project_id = os.environ.get('GOOGLE_CLOUD_PROJECT') or os.environ.get('GOOGLE_CLOUD_PROJECT_ID') or config.get_google_cloud_project()
            print(f"{Colors.MUTED}Project ID:{Colors.RESET} {Colors.SECONDARY}{project_id or 'Not set'}{Colors.RESET}")
        
        print(f"\n  {Colors.SUCCESS}1{Colors.RESET}) Use Google Auth (Login with Google)")
        print(f"  {Colors.SUCCESS}2{Colors.RESET}) Use Gemini API Key")
        print(f"  {Colors.WARNING}3{Colors.RESET}) Set Google Cloud Project ID")
        print(f"  {Colors.MUTED}4{Colors.RESET}) Cancel")
        print()
        
        choice = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}Choose (1-4): {Colors.RESET}").strip()
        if choice == '1':
            config.set_use_google_auth(True)
            print(f"{Colors.SUCCESS}{Icons.CHECK} Switched to Google Auth mode.{Colors.RESET}")
            if not auth.get_auth_token():
                print(f"{Colors.MUTED}No active session found. Starting login...{Colors.RESET}")
                auth.perform_oauth_login()
        elif choice == '2':
            config.set_use_google_auth(False)
            print(f"{Colors.SUCCESS}{Icons.CHECK} Switched to Gemini API Key mode.{Colors.RESET}")
        elif choice == '3':
            new_project_id = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}Enter Project ID: {Colors.RESET}").strip()
            if new_project_id:
                config.set_google_cloud_project(new_project_id)
                print(f"{Colors.SUCCESS}{Icons.CHECK} Project ID set to: {new_project_id}{Colors.RESET}")
        elif choice == '4':
            print(f"{Colors.MUTED}Cancelled.{Colors.RESET}")
        else:
            print(f"{Colors.ERROR}Invalid option.{Colors.RESET}")
        return "continue"
        
    elif c.startswith('/show-reasoning'):
        parts = c.split()
        if len(parts) > 1:
            val = parts[1]
            if val in ['true', 'on', '1', 'yes']:
                api.SHOW_REASONING = True
                print(f"{Colors.SUCCESS}{Icons.CHECK} Showing reasoning tokens enabled (session only).{Colors.RESET}")
            elif val in ['false', 'off', '0', 'no']:
                api.SHOW_REASONING = False
                print(f"{Colors.SUCCESS}{Icons.CHECK} Showing reasoning tokens disabled.{Colors.RESET}")
            else:
                print(f"{Colors.ERROR}Invalid value: {val}. Use true/false.{Colors.RESET}")
        else:
            # Toggle if no value provided
            api.SHOW_REASONING = not api.SHOW_REASONING
            status = "enabled" if api.SHOW_REASONING else "disabled"
            print(f"{Colors.SUCCESS}{Icons.CHECK} Showing reasoning tokens {status}.{Colors.RESET}")
        return "continue"
        
    elif c.startswith('/save'):
        parts = cmd.split(None, 1)
        if len(parts) > 1:
            name = parts[1].strip()
        else:
            print(f"\n{Colors.MUTED}Enter a name for this chat:{Colors.RESET}")
            name = interrupt.safe_input(f"{Colors.INPUT_ACTIVE}> {Colors.RESET}").strip()
            
        if not name:
            print(f"{Colors.ERROR}Chat name required.{Colors.RESET}")
            return "continue"
            
        path = chat_manager.save_chat(name, state['messages'], state['current_model'], api.CURRENT_API)
        print(f"{Colors.SUCCESS}{Icons.CHECK} Chat saved to {Colors.SECONDARY}{path}{Colors.RESET}\n")
        return "continue"

    elif c.startswith('/load'):
        parts = cmd.split(None, 1)
        if len(parts) > 1:
            name = parts[1].strip()
        else:
            # If no name provided, list chats and let user pick
            chats = chat_manager.list_chats()
            if not chats:
                print(f"{Colors.WARNING}No saved chats found.{Colors.RESET}")
                return "continue"
            
            title = "Select Chat to Load"
            options = [f"{c['name']} ({Colors.MUTED}{c['model']}{Colors.RESET})" for c in chats]
            result = ui.select_option(options, title)
            if not result:
                return "continue"
            _, idx = result
            name = chats[idx]['name']
            
        chat_data = chat_manager.load_chat(name)
        if chat_data:
            state['messages'] = chat_data['messages']
            
            print(f"{Colors.SUCCESS}{Icons.CHECK} Chat '{name}' loaded.{Colors.RESET}\n")
            os.system('cls' if os.name == 'nt' else 'clear')
            ui.print_messages(state['messages'])
            return "continue"
        else:
            print(f"{Colors.ERROR}Chat '{name}' not found.{Colors.RESET}")
            return "continue"

    elif c == '/manage-chats':
        chat_to_load = chat_manager.manage_chats_ui()
        if chat_to_load:
            chat_data = chat_manager.load_chat(chat_to_load)
            if chat_data:
                state['messages'] = chat_data['messages']
                
                print(f"{Colors.SUCCESS}{Icons.CHECK} Chat '{chat_to_load}' loaded.{Colors.RESET}\n")
                os.system('cls' if os.name == 'nt' else 'clear')
                ui.print_messages(state['messages'])
        return "continue"
        
    else:
        print(f"{Colors.ERROR}Unknown command: {cmd}{Colors.RESET}")
        print(f"{Colors.MUTED}Type /help for available commands.{Colors.RESET}")
        return "continue"