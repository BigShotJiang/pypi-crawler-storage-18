class CppApiError(Exception):
    pass
class CppBuildError(CppApiError):
    pass
class CppModuleNotFoundError(CppApiError):
    pass
class CppModuleOutdatedError(CppApiError):
    pass
class CppReloadWarning(UserWarning):
    pass
class CppValidationError(CppApiError):
    pass
class CppParseError(CppApiError):
    pass
class CppGeneratorError(CppApiError):
    pass