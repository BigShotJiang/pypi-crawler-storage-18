from typing import List, Optional
import re
class BuildErrorFormatter:
    @staticmethod
    def format_type_mismatch(expected: str, got: str, location: str) -> str:
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ TYPE MISMATCH ERROR                                          ║
╚══════════════════════════════════════════════════════════════╝
Location: {location}
Expected: {expected}
Got:      {got}
Suggestions:
  • Check if you're passing the correct type
  • For struct → dict: use struct_instance.to_dict()
  • For dict → struct: use StructName.from_dict(dict_instance)
  • For vector conversions: Python list ↔ std::vector is automatic
Type Conversion Examples:
  point_dict = point.to_dict()
  point = Point.from_dict({{"x": 10, "y": 20}})
  points: List[Point] = [...]
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ DEPENDENCY ERROR                                             ║
╚══════════════════════════════════════════════════════════════╝
Module: {module}
Missing Dependency: {missing_dep}
To Fix:
  1. Add dependency to {module}.cp:
     SOURCE(path/to/{module}.cpp) {module}
     DEPENDS({missing_dep})
     PUBLIC(
         ...
     )
  2. Ensure {missing_dep} module exists in plugins/ directory
  3. Rebuild:
     python -m includecpp rebuild --verbose
Dependency Chain:
  {module} → {missing_dep}
        cycle_display = " → ".join(cycle + [cycle[0]])
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ CIRCULAR DEPENDENCY DETECTED                                 ║
╚══════════════════════════════════════════════════════════════╝
Dependency Cycle:
  {cycle_display}
To Fix:
  • Refactor modules to remove circular dependency
  • Use forward declarations where possible
  • Consider merging modules if they're tightly coupled
  • Create a third module for shared types
Example Refactoring:
  Before:
    module_a → module_b → module_a  ❌
  After:
    module_a → shared_types
    module_b → shared_types         ✓
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ MODULE NOT FOUND                                             ║
╚══════════════════════════════════════════════════════════════╝
Requested: {module}
Available modules:
  {', '.join(available) if available else '(none)'}
To Fix:
  • Check spelling of module name
  • Ensure {module}.cp exists in plugins/ directory
  • Run 'python -m includecpp rebuild' to build all modules
  • Run 'python -m includecpp list' to see available modules
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ BUILD FAILED                                                 ║
╚══════════════════════════════════════════════════════════════╝
Module: {module}
Reason:
  {reason}
To Debug:
  • Run with --verbose flag for detailed output
  • Check {module}.cpp for syntax errors
  • Verify all includes are available
  • Check build log in AppData/IncludeCPP/
        lines = stderr.split('\n')
        formatted = []
        error_count = 0
        for line in lines:
            if ': error:' in line:
                error_count += 1
                parts = line.split(':')
                if len(parts) >= 4:
                    file_path = parts[0].strip()
                    line_num = parts[1].strip() if parts[1].strip().isdigit() else "?"
                    error_msg = ':'.join(parts[3:]).strip()
                    formatted.append("")
                    formatted.append("╔══════════════════════════════════════════╗")
                    formatted.append("║ COMPILATION ERROR                        ║")
                    formatted.append("╚══════════════════════════════════════════╝")
                    formatted.append("")
                    formatted.append(f"Module: {module_name}")
                    formatted.append(f"File: {file_path}")
                    formatted.append(f"Line: {line_num}")
                    formatted.append(f"Error: {error_msg}")
                    formatted.append("")
                    if "undefined reference" in error_msg.lower() or "unresolved external" in error_msg.lower():
                        formatted.append("Suggestion:")
                        formatted.append("  • Check if function/class is declared in header")
                        formatted.append("  • Verify all source files are listed in .cp file")
                        formatted.append("  • Check for missing DEPENDS() if using types from other modules")
                        formatted.append("  • Ensure function is in 'includecpp' namespace")
                    elif "no matching function" in error_msg.lower() or "no member named" in error_msg.lower():
                        formatted.append("Suggestion:")
                        formatted.append("  • Check parameter types match function signature")
                        formatted.append("  • Verify template instantiations are correct")
                        formatted.append("  • Check for const/reference qualifiers")
                        formatted.append("  • Ensure all required headers are included")
                    elif "expected" in error_msg.lower() and "before" in error_msg.lower():
                        formatted.append("Suggestion:")
                        formatted.append("  • Check for missing semicolons")
                        formatted.append("  • Verify bracket/parenthesis matching")
                        formatted.append("  • Check for typos in type names")
                    elif "does not name a type" in error_msg.lower():
                        formatted.append("Suggestion:")
                        formatted.append("  • Check if type is defined before use")
                        formatted.append("  • Verify
                        formatted.append("  • Check namespace qualifications (std::, includecpp::)")
                    elif "incomplete type" in error_msg.lower():
                        formatted.append("Suggestion:")
                        formatted.append("  • Add forward declaration or full type definition")
                        formatted.append("  • Check if header file is included")
                        formatted.append("  • Verify struct/class definition is complete")
            elif re.match(r'.*\(\d+\):\s*error\s+C\d+:', line):
                error_count += 1
                match = re.match(r'(.*)\((\d+)\):\s*error\s+C\d+:\s*(.*)', line)
                if match:
                    file_path = match.group(1).strip()
                    line_num = match.group(2)
                    error_msg = match.group(3).strip()
                    formatted.append("")
                    formatted.append("╔══════════════════════════════════════════╗")
                    formatted.append("║ COMPILATION ERROR                        ║")
                    formatted.append("╚══════════════════════════════════════════╝")
                    formatted.append("")
                    formatted.append(f"Module: {module_name}")
                    formatted.append(f"File: {file_path}")
                    formatted.append(f"Line: {line_num}")
                    formatted.append(f"Error: {error_msg}")
                    formatted.append("")
            elif ': warning:' in line or 'warning C' in line:
                if not formatted or formatted[-1] != "":
                    formatted.append("")
                formatted.append(f"⚠️  {line}")
            elif ': note:' in line:
                formatted.append(f"ℹ️  {line}")
            elif not line.strip():
                if formatted and formatted[-1] != "":
                    formatted.append("")
        if error_count > 0:
            header = [
                "",
                "═" * 60,
                f"COMPILATION FAILED: {error_count} error(s) in {module_name}",
                "═" * 60,
                ""
            ]
            formatted = header + formatted
        return '\n'.join(formatted) if formatted else stderr
    @staticmethod
    def format_cmake_error(stderr: str, module_name: str) -> str:
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ CMAKE CONFIGURATION ERROR                                    ║
╚══════════════════════════════════════════════════════════════╝
Module: {module_name}
CMake Output:
{stderr}
Common Issues:
  • CMake not installed or not in PATH
  • C++ compiler not found (install g++, clang++, or MSVC)
  • pybind11 not found (auto-installed, check network)
  • Python development headers missing
To Fix:
  • Install CMake 3.15+ from cmake.org
  • Install C++ compiler:
    - Windows: Visual Studio or MinGW
    - Linux: apt-get install g++ cmake python3-dev
    - macOS: xcode-select --install
  • Run with --verbose for detailed CMake output
        return f"""
╔══════════════════════════════════════════════════════════════╗
║ MODULE IMPORT ERROR                                          ║
╚══════════════════════════════════════════════════════════════╝
Module: {module}
Path: {pyd_path}
Error:
  {error_msg}
Common Causes:
  • Missing dependencies (DLLs on Windows, .so on Linux)
  • Python version mismatch (rebuild for current Python)
  • Corrupted .pyd file (rebuild module)
  • Missing Visual C++ Redistributable (Windows)
To Fix:
  1. Rebuild module:
     python -m includecpp rebuild {module} --clean
  2. Check Python version matches build:
     python --version
  3. Windows: Install Visual C++ Redistributable
     https://aka.ms/vs/17/release/vc_redist.x64.exe
  4. Run with --verbose for detailed output