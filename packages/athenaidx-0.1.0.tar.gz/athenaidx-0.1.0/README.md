# AthenaIDX — Selenium Page Object Model helpers

This repository contains the `athenaidx` Python package that wraps interactions with the AthenaIDX web UI using Selenium and a Page Object Model (POM) layout.

Quick start

1. Create and activate a virtualenv:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install --upgrade pip
```

2. Install dev dependencies for running tests locally (recommended):

```bat
pip install -r requirements-dev.txt
```

3. Run the example test (requires Chrome or `webdriver-manager`):

```bat
pytest -q
```

Basic usage (programmatic):

```py
from athenaidx.driver.manager import DriverManager
from athenaidx.page_objects.example_page import ExamplePage

dm = DriverManager(headless=True)
driver = dm.create_driver()
try:
    page = ExamplePage(driver)
    page.open("https://example.com")
    print(page.get_header_text())
finally:
    driver.quit()
```

Notes
- Consider installing `webdriver-manager` for simpler driver management in local development and CI.
- For CI, configure your workflow to run headless Chrome or use a Selenium standalone server.
