"""Top-level package for athenaidx.

Expose a package version here so tooling and downstream consumers can read it.
"""

__all__ = ["__version__"]

# Package version (single source of truth for builds). Update this when releasing.
__version__ = "0.1.0"
