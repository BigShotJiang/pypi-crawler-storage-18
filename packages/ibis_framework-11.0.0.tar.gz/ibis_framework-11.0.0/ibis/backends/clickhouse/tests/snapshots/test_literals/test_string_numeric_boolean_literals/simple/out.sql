SELECT
  'simple' AS "'simple'"