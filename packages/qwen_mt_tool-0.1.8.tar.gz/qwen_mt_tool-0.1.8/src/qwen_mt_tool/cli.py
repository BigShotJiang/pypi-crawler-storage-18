import argparse
import concurrent.futures
import glob
import logging
import os

import colorlog
from openai import OpenAI

# Dictionary to map model names to their descriptions (optional, for reference)
# Using qwen-mt-plus as default using OpenAI compatible endpoint
DEFAULT_MODEL = "qwen-mt-plus"
MAX_WORKERS = 1

# Setup logging
log_colors = {
    "DEBUG": "cyan",
    "INFO": "green",
    "WARNING": "yellow",
    "ERROR": "red",
    "CRITICAL": "red,bg_white",
}

formatter = colorlog.ColoredFormatter(
    "%(log_color)s%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    reset=True,
    log_colors=log_colors,
)

handler = logging.StreamHandler()
handler.setFormatter(formatter)

logger = logging.getLogger("main")
logger.setLevel(logging.INFO)
logger.addHandler(handler)

# File handler for translation.log with same format (but no color)
file_handler = logging.FileHandler("translation.log")
file_formatter = logging.Formatter(
    "%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
)
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

# Setup usage logger
usage_logger = logging.getLogger("usage")
usage_logger.setLevel(logging.INFO)
usage_handler = logging.FileHandler("usage.log")
usage_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
)
usage_logger.addHandler(usage_handler)

prompt_template = """
# Role
You are a senior software development engineer, proficient in multiple programming languages, including but not limited to Python, Java, C++, Go, JavaScript, and others. You have a deep understanding of professional terminology in the field of software engineering.

# Task
I need you to translate the following English document, which may contain code, into professional, precise, and formal Chinese.

# Translation Requirements
1. **Strictly preserve formatting**: Do not arbitrarily change the formatting, including but not limited to paragraphs, numbering, and code.
2. **Be faithful to the original text**: Translate strictly according to the meaning and intent of the original text, without adding or removing any information.
3. **Use precise terminology**: Use professional terminology from the Chinese software development field. For proper nouns, retain the original text.
4. **Ensure clear sentences**: The translation must be clear, unambiguous, and consistent with the expression conventions of Chinese software development documentation.
5. **Preserve formatting**: Maintain the original text’s paragraphs, numbering, and basic formatting.
6. **Preserve code**: Retain the original text’s code format and content. The content within the code, including but not limited to the code itself and its comments, must remain unchanged.

# Text to translate
{text_to_translate}
"""


translation_options_with_terms = {
    "source_lang": "English",
    "target_lang": "Chinese",
    # "terms": [
    #     {
    #         "source": "生物传感器",
    #         "target": "biological sensor"
    #     },
    #     {
    #         "source": "身体健康状况",
    #         "target": "health status of the body"
    #     }
    # ]
}


def split_text_into_chunks(text, max_chars=8000):
    """
    Split text into chunks by lines to avoid exceeding token limits,
    while trying to preserve code block integrity (do not split inside ```...```).
    """
    lines = text.splitlines(keepends=True)
    current_chunk = []
    current_length = 0
    in_code_block = False
    
    for line in lines:
        # standard markdown code block check
        if line.lstrip().startswith("```"):
            in_code_block = not in_code_block
        
        current_chunk.append(line)
        current_length += len(line)
        
        # Only yield if over limit AND not inside a code block
        # If a single code block is huge (> max_chars), we might still have to yield eventually
        # or risk API error. For now, prefer integrity.
        if current_length > max_chars and not in_code_block:
            yield "".join(current_chunk)
            current_chunk = []
            current_length = 0
            
    if current_chunk:
        yield "".join(current_chunk)


def find_markdown_files(root_dir):
    """Recursively find markdown files, excluding already translated ones."""
    md_files = []
    # glob.glob with recursive=True requires ** pattern
    # search for all .md files
    all_md_files = glob.glob(os.path.join(root_dir, "**", "*.md"), recursive=True)

    for f in all_md_files:
        # Check if it's already a translated file to avoid double translation
        if f.endswith("_zh_cn.md") or f.endswith("_zh_CN.md"):
            continue
        md_files.append(f)

    return md_files


def translate_text(text, api_key):
    """Call OpenAI compatible API to translate text."""

    if not api_key:
        logger.error("API Key not provided.")
        return None, None

    # Base URL for Qwen-MT OpenAI compatibility
    # Beijing region: https://dashscope.aliyuncs.com/compatible-mode/v1
    # Singapore region: https://dashscope-intl.aliyuncs.com/compatible-mode/v1
    base_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"

    try:
        client = OpenAI(api_key=api_key, base_url=base_url)

        messages = [{"role": "user", "content": text}]

        # using extra_body to pass translation_options
        completion = client.chat.completions.create(
            model=DEFAULT_MODEL,
            messages=messages,
            extra_body={
                "translation_options": translation_options_with_terms
            }
        )

        # Extract content
        translated_content = completion.choices[0].message.content
        # Extract usage
        usage = completion.usage
        return translated_content, usage

    except Exception as e:
        logger.error(f"Exception during translation: {e}")
        return None, None


def translate_file(file_path, api_key):
    """Handle translation of a single file with splitting and skipping logic."""
    # Check if output file already exists
    output_path = f"{file_path[:-3]}_zh_CN.md"
    
    if os.path.exists(output_path):
        logger.info(f"Skipping {file_path}: Translation already exists at {output_path}")
        return file_path, True # Success (skipped)

    logger.info(f"Processing file: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if not content.strip():
            logger.warning(f"File {file_path} is empty, skipping.")
            return file_path, True # Empty considered success/done

        final_translated_content = []
        total_input_tokens = 0
        total_output_tokens = 0
        total_tokens = 0
        
        chunks = list(split_text_into_chunks(content))
        total_chunks = len(chunks)
        
        if total_chunks > 1:
            logger.info(f"File {file_path} split into {total_chunks} chunks.")

        for i, chunk in enumerate(chunks, 1):
            if total_chunks > 1:
                logger.info(f"[{file_path}] Translating chunk {i}/{total_chunks}...")
            # to_be_translated_content = prompt_template.format(text_to_translate=chunk)
            translated_chunk, usage = translate_text(chunk, api_key=api_key)
            
            if translated_chunk:
                final_translated_content.append(translated_chunk)
                if usage:
                    total_input_tokens += usage.prompt_tokens
                    total_output_tokens += usage.completion_tokens
                    total_tokens += usage.total_tokens
            else:
                logger.error(f"Failed to translate chunk {i} of {file_path}")
                return file_path, False # Failed

        # Write output
        full_content = "\n\n".join(final_translated_content)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(full_content)
        
        logger.info(f"Saved translation to {output_path}")
        
        # Log aggregated usage
        usage_msg = f"File: {file_path}, Input: {total_input_tokens}, Output: {total_output_tokens}, Total: {total_tokens}"
        logger.info(f"Translation successful [{file_path}]. Total Usage - {usage_msg}")
        usage_logger.info(usage_msg)
        return file_path, True

    except Exception as e:
        logger.error(f"Error processing file {file_path}: {e}")
        return file_path, False


def main():
    parser = argparse.ArgumentParser(description="Translate markdown files using Qwen-MT.")
    parser.add_argument("path", nargs="?", default=os.getcwd(), help="File or directory path to translate")
    parser.add_argument("--workers", type=int, default=MAX_WORKERS, help=f"Number of concurrent workers (default: {MAX_WORKERS})")
    parser.add_argument("--api-key", type=str, help="DashScope API Key (overrides DASHSCOPE_API_KEY env var)")
    args = parser.parse_args()

    # Determine API Key: Argument > Environment Variable
    api_key = args.api_key or os.getenv("DASHSCOPE_API_KEY")

    if not api_key:
        logger.error(
            "API Key not found. Please provide it via --api-key argument or DASHSCOPE_API_KEY environment variable."
        )
        return
    
    # Hide key in logs for security, print only partial or just presence
    logger.info(f"Using API Key: {api_key[:4]}...{api_key[-4:] if len(api_key)>8 else ''}")

    target_path = os.path.abspath(args.path)
    files_to_translate = []

    if os.path.isfile(target_path):
        if target_path.endswith(".md") and not (target_path.endswith("_zh_cn.md") or target_path.endswith("_zh_CN.md")):
            files_to_translate = [target_path]
        else:
            logger.error(f"Invalid file: {target_path}. Must be a .md file and not a translation output.")
            return
    elif os.path.isdir(target_path):
        logger.info(f"Scanning for markdown files in {target_path}...")
        files_to_translate = find_markdown_files(target_path)
    else:
        logger.error(f"Path not found: {target_path}")
        return

    count = len(files_to_translate)
    logger.info(f"Found {count} files to translate.")

    if count == 0:
        logger.info("No files found. Exiting.")
        return

    logger.info(f"Starting translation with {args.workers} workers...")

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        # Submit all tasks
        future_to_file = {executor.submit(translate_file, f, api_key): f for f in files_to_translate}
        
        completed_count = 0
        for future in concurrent.futures.as_completed(future_to_file):
            completed_count += 1
            file_path, success = future.result()
            remaining = count - completed_count
            logger.info(f"Progress: [{completed_count}/{count}] Completed. ({remaining} Remaining)")



if __name__ == "__main__":
    main()
