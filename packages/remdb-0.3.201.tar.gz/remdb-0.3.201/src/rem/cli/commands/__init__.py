"""
CLI commands for REM.
"""
