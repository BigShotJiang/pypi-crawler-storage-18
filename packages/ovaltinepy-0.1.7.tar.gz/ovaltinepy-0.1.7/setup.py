from setuptools import setup, find_packages
import os

# Read the README.md for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ovaltinepy",
    version="0.1.7",
    install_requires=[
        "colorama",
        "pygeohash",
        "zstandard",
        "PyYAML",
        "base91",
    ],
    author="ghostescript",
    author_email="anonymosmauros@gmail.com",
    description="A versatile command-line tool for encoding, decoding, hashing, and string manipulation.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ghostescript/ovaltinepy",
    packages=['ovaltinepy'],
    package_dir={'ovaltinepy': '.'},
    entry_points={
        'console_scripts': [
            'ovaltinepy=ovaltinepy.ovaltine:main',
        ],
    },
)
