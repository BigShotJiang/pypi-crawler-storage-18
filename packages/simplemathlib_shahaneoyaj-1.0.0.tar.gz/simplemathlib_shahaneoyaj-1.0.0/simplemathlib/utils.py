"""
Utility functions for the library.
"""

def validate_positive_number(value: float) -> bool:
    """
    Check if a number is positive.
    """
    return value > 0

def format_result(result: float, decimals: int = 2) -> str:
    """
    Format result with specified decimal places.
    """
    return f"{result:.{decimals}f}"
