"""
Geometry module.
"""
from .shapes import circle_area, rectangle_area, triangle_area

__all__ = ['circle_area', 'rectangle_area', 'triangle_area']
