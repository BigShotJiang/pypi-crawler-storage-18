"""
Geometry shapes module.
Simple geometric calculations.
"""

import math

def circle_area(radius: float) -> float:
    """
    Calculate area of a circle.
    
    Args:
        radius: Radius of the circle
    
    Returns:
        Area of the circle
    """
    if radius < 0:
        raise ValueError("Radius cannot be negative")
    return math.pi * radius ** 2

def rectangle_area(length: float, width: float) -> float:
    """
    Calculate area of a rectangle.
    """
    if length < 0 or width < 0:
        raise ValueError("Dimensions cannot be negative")
    return length * width

def triangle_area(base: float, height: float) -> float:
    """
    Calculate area of a triangle.
    """
    if base < 0 or height < 0:
        raise ValueError("Dimensions cannot be negative")
    return 0.5 * base * height
