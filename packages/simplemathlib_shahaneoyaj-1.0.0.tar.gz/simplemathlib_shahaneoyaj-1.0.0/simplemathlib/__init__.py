"""
SimpleMathLib - A simple mathematics library.
Version 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from .basic_operations import *
from .geometry import *
from .utils import *

__all__ = ['add', 'subtract', 'multiply', 'divide',
           'circle_area', 'rectangle_area', 'triangle_area',
           'validate_positive_number', 'format_result']
