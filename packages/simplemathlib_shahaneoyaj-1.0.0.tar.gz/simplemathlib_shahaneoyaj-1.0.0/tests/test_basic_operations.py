import unittest
from simplemathlib.basic_operations import add, subtract, multiply, divide

class TestBasicOperations(unittest.TestCase):
    """Test cases for basic operations."""
    
    def test_add(self):
        """Test addition operation."""
        self.assertEqual(add(5, 3), 8)
        self.assertEqual(add(-1, 1), 0)
        self.assertEqual(add(0, 0), 0)
    
    def test_subtract(self):
        """Test subtraction operation."""
        self.assertEqual(subtract(10, 5), 5)
        self.assertEqual(subtract(5, 10), -5)
    
    def test_multiply(self):
        """Test multiplication operation."""
        self.assertEqual(multiply(4, 3), 12)
        self.assertEqual(multiply(0, 5), 0)
    
    def test_divide(self):
        """Test division operation."""
        self.assertEqual(divide(10, 2), 5)
        self.assertEqual(divide(5, 2), 2.5)
    
    def test_divide_by_zero(self):
        """Test division by zero raises error."""
        with self.assertRaises(ValueError):
            divide(10, 0)

if __name__ == '__main__':
    unittest.main()
