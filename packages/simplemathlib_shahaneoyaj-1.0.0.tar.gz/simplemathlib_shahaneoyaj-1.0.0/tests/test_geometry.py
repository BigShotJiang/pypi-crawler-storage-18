import unittest
import math
from simplemathlib.geometry import circle_area, rectangle_area, triangle_area

class TestGeometry(unittest.TestCase):
    """Test cases for geometry operations."""
    
    def test_circle_area(self):
        """Test circle area calculation."""
        self.assertAlmostEqual(circle_area(1), math.pi)
        self.assertAlmostEqual(circle_area(2), math.pi * 4)
    
    def test_circle_negative_radius(self):
        """Test circle with negative radius raises error."""
        with self.assertRaises(ValueError):
            circle_area(-1)
    
    def test_rectangle_area(self):
        """Test rectangle area calculation."""
        self.assertEqual(rectangle_area(4, 5), 20)
        self.assertEqual(rectangle_area(3, 7), 21)
    
    def test_rectangle_negative_dimensions(self):
        """Test rectangle with negative dimensions raises error."""
        with self.assertRaises(ValueError):
            rectangle_area(-1, 5)
    
    def test_triangle_area(self):
        """Test triangle area calculation."""
        self.assertEqual(triangle_area(4, 5), 10)
        self.assertEqual(triangle_area(3, 6), 9)
    
    def test_triangle_negative_dimensions(self):
        """Test triangle with negative dimensions raises error."""
        with self.assertRaises(ValueError):
            triangle_area(4, -5)

if __name__ == '__main__':
    unittest.main()
