﻿from setuptools import setup, find_packages

setup(
    name="simplemathlib_shahaneoyaj",  # CHANGE THIS TO YOUR UNIQUE NAME
    version="1.0.0",
    author="Your Name",
    packages=find_packages(),
)