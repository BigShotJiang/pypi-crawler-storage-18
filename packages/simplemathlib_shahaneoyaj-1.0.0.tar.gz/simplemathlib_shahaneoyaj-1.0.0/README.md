# SimpleMathLib - Semester Lab Project

A simple mathematics library created for educational purposes.

## Quick Start

1. Make sure you have Python 3.6 or higher
2. Navigate to the project folder in terminal
3. Install the library:
```bash
pip install -e .