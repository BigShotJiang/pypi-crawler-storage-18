**Project:**
[![License](https://img.shields.io/github/license/davidbrownell/dbrownell_VSCodeTools?color=dark-green)](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/master/LICENSE)

**Package:**
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/dbrownell_VSCodeTools?color=dark-green)](https://pypi.org/project/dbrownell_VSCodeTools/)
[![PyPI - Version](https://img.shields.io/pypi/v/dbrownell_VSCodeTools?color=dark-green)](https://pypi.org/project/dbrownell_VSCodeTools/)
[![PyPI - Downloads](https://img.shields.io/pypi/dm/dbrownell_VSCodeTools)](https://pypistats.org/packages/dbrownell-vscodetools)

**Development:**
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![CI](https://github.com/davidbrownell/dbrownell_VSCodeTools/actions/workflows/CICD.yml/badge.svg)](https://github.com/davidbrownell/dbrownell_VSCodeTools/actions/workflows/CICD.yml)
[![Code Coverage](https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/davidbrownell/f15146b1b8fdc0a5d45ac0eb786a84f7/raw/dbrownell_VSCodeTools_code_coverage.json)](https://github.com/davidbrownell/dbrownell_VSCodeTools/actions)
[![GitHub commit activity](https://img.shields.io/github/commit-activity/y/davidbrownell/dbrownell_VSCodeTools?color=dark-green)](https://github.com/davidbrownell/dbrownell_VSCodeTools/commits/main/)

<!-- Content above this delimiter will be copied to the generated README.md file. DO NOT REMOVE THIS COMMENT, as it will cause regeneration to fail. -->

## Contents
- [Overview](#overview)
- [Installation](#installation)
- [Development](#development)
- [Additional Information](#additional-information)
- [License](#license)

## Overview
TODO: Complete this section

### How to use `dbrownell_VSCodeTools`
TODO: Complete this section

<!-- Content below this delimiter will be copied to the generated README.md file. DO NOT REMOVE THIS COMMENT, as it will cause regeneration to fail. -->

## Installation

| Installation Method | Command |
| --- | --- |
| Via [uv](https://github.com/astral-sh/uv) | `uv add dbrownell_VSCodeTools` |
| Via [pip](https://pip.pypa.io/en/stable/) | `pip install dbrownell_VSCodeTools` |



## Development
Please visit [Contributing](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/CONTRIBUTING.md) and [Development](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/DEVELOPMENT.md) for information on contributing to this project.

## Additional Information
Additional information can be found at these locations.

| Title | Document | Description |
| --- | --- | --- |
| Code of Conduct | [CODE_OF_CONDUCT.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/CODE_OF_CONDUCT.md) | Information about the norms, rules, and responsibilities we adhere to when participating in this open source community. |
| Contributing | [CONTRIBUTING.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/CONTRIBUTING.md) | Information about contributing to this project. |
| Development | [DEVELOPMENT.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/DEVELOPMENT.md) | Information about development activities involved in making changes to this project. |
| Governance | [GOVERNANCE.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/GOVERNANCE.md) | Information about how this project is governed. |
| Maintainers | [MAINTAINERS.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/MAINTAINERS.md) | Information about individuals who maintain this project. |
| Security | [SECURITY.md](https://github.com/davidbrownell/dbrownell_VSCodeTools/blob/main/SECURITY.md) | Information about how to privately report security issues associated with this project. |

## License
`dbrownell_VSCodeTools` is licensed under the <a href="https://choosealicense.com/licenses/MIT/" target="_blank">MIT</a> license.
