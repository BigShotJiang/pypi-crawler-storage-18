from typing import Any, Literal

from eth_typing import HexStr
from hexbytes import HexBytes

BlockID = int | HexStr | HexBytes | Literal["earliest", "latest", "pending"]
"""
An ID that can match a block, such as the literals ``"earliest"``, ``"latest"``, or ``"pending"``
as well as a block number or hash (HexBytes).
"""

ContractCode = str | bytes | HexBytes
"""
A type that represents contract code, which can be represented in string, bytes, or HexBytes.
"""

SnapshotID = Any
"""
An ID representing a point in time on a blockchain, as used in the
:meth:`~ape.managers.chain.ChainManager.snapshot` and
:meth:`~ape.managers.chain.ChainManager.snapshot` methods. Can be a ``str``, ``int``, ``bytes``,
``tuple[bytes, int]``, etc. Providers will expect and handle snapshot IDs differently.
There shouldn't be a need to change providers when using this feature, so there should not be
confusion over this type in practical use cases.
"""
