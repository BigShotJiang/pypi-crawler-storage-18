NAME = "bluer_objects"

ICON = "🌀"

DESCRIPTION = f"{ICON} Object management in Bash."

VERSION = "6.373.1"

REPO_NAME = "bluer-objects"

MARQUEE = (
    "https://github.com/kamangir/assets/raw/main/blue-objects/marquee.png?raw=true"
)

ALIAS = "@objects"


def fullname() -> str:
    return f"{NAME}-{VERSION}"
