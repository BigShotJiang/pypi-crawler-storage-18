"""
Custom exceptions for CSV schema validation.

This module defines specific exception classes for different types of errors
that can occur during CSV validation, providing better error handling and
more informative error messages.
"""
from __future__ import annotations

from typing import Any


class CSVValidationError(Exception):
    """Base exception for CSV validation errors."""
    
    def __init__(self, message: str, row: int | None = None, column: str | None = None, 
                 value: Any | None = None, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.row = row
        self.column = column
        self.value = value
        self.details = details or {}
    
    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary format for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "error_message": self.message,
            "row": self.row,
            "column": self.column,
            "value": self.value,
            "details": self.details
        }


class SchemaValidationError(CSVValidationError):
    """Raised when schema validation fails."""
    
    def __init__(self, message: str, field_path: str | None = None, 
                 details: dict[str, Any] | None = None):
        super().__init__(message, details=details)
        self.field_path = field_path


# Field validation exceptions are now in csv-field-validators package
# Re-export for backward compatibility
from .field_validators import (
    EnumValidationError,
    FieldValidationError,
    PatternValidationError,
    RangeValidationError,
    RequiredFieldError,
    TypeValidationError,
)


class FileError(CSVValidationError):
    """Raised when there are file-related errors."""
    
    def __init__(self, message: str, file_path: str, details: dict[str, Any] | None = None):
        super().__init__(message, details=details)
        self.file_path = file_path
    
    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary format for JSON serialization."""
        result = super().to_dict()
        result["details"]["file_path"] = self.file_path
        return result


class CSVFileError(FileError):
    """Raised when there are CSV file-specific errors."""
    
    def __init__(self, message: str, file_path: str, details: dict[str, Any] | None = None):
        super().__init__(message, file_path, details)


class SchemaFileError(FileError):
    """Raised when there are schema file-specific errors."""
    
    def __init__(self, message: str, file_path: str, details: dict[str, Any] | None = None):
        super().__init__(message, file_path, details)


class EmptyFileError(FileError):
    """Raised when a file is empty."""
    
    def __init__(self, file_path: str, file_type: str = "file"):
        message = f"{file_type.title()} file is empty"
        super().__init__(message, file_path, details={"file_type": file_type})


class InvalidJSONError(SchemaFileError):
    """Raised when schema file contains invalid JSON."""
    
    def __init__(self, file_path: str, json_error: str):
        message = f"Invalid JSON in schema file: {json_error}"
        super().__init__(message, file_path, details={"json_error": json_error})


# ValidationConfigurationError is now in csv-field-validators package
from .field_validators import ValidationConfigurationError
