"""
CSV Schema Core - Core schema definition and validation for CSV files.

This package provides the fundamental building blocks for CSV schema validation,
including Pydantic models for schema definition and core validation logic.
"""

from .models import CSVSchema, FieldSchema, FieldType
from .types import SchemaDict, FieldDict, ValidationResult, BOOLEAN_VALUES
from .validator import validate_schema_structure

__version__ = "0.1.0"
__all__ = [
    "CSVSchema",
    "FieldSchema", 
    "FieldType",
    "SchemaDict",
    "FieldDict",
    "ValidationResult",
    "BOOLEAN_VALUES",
    "validate_schema_structure",
]
