"""
Type definitions for CSV schema core.

This module provides type aliases and protocols for better type safety
and code documentation in the core schema package.
"""
from __future__ import annotations

from typing import Any, Protocol

# Type aliases for better readability
ValidationResult = dict[str, Any]
SchemaDict = dict[str, Any]
FieldDict = dict[str, Any]


class SchemaValidatorProtocol(Protocol):
    """Protocol for schema validation functions."""
    
    def __call__(self, schema: SchemaDict) -> ValidationResult:
        """Validate a schema and return validation result."""
        ...


# Constants for supported field types
SUPPORTED_FIELD_TYPES = frozenset({"string", "number", "integer", "boolean"})
NUMERIC_FIELD_TYPES = frozenset({"number", "integer"})
BOOLEAN_VALUES = ["true", "false"]
