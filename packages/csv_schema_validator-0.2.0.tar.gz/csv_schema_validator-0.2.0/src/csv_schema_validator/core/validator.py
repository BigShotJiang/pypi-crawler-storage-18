"""
Schema validation module for CSV schemas.
"""
from __future__ import annotations

from typing import Any
from pydantic import ValidationError

from .models import CSVSchema
from .types import SchemaDict, ValidationResult


class SchemaValidationError(Exception):
    """Raised when schema validation fails."""
    
    def __init__(self, message: str, field_path: str | None = None, 
                 details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.field_path = field_path
        self.details = details or {}
    
    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary format for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "error_message": self.message,
            "row": None,
            "column": None,
            "value": None,
            "details": self.details
        }


def validate_schema_structure(schema_dict: SchemaDict) -> ValidationResult:
    """
    Validate the structure of a CSV schema.

    Args:
        schema_dict: Dictionary containing the schema definition

    Returns:
        Dictionary with validation results:
        - is_valid: Boolean indicating if schema is valid
        - errors: List of validation errors
        - validated_schema: Pydantic model instance if valid
    """
    try:
        validated_schema = CSVSchema(**schema_dict)
        return {"is_valid": True, "errors": [], "validated_schema": validated_schema}
    except ValidationError as e:
        errors = []
        for error in e.errors():
            field_path = ".".join(str(x) for x in error["loc"])
            schema_error = SchemaValidationError(
                message=error["msg"],
                field_path=field_path,
                details={"input": error["input"], "type": error["type"]}
            )
            errors.append(schema_error.to_dict())

        return {"is_valid": False, "errors": errors, "validated_schema": None}
    except TypeError as e:
        schema_error = SchemaValidationError(
            message=str(e),
            details={"schema_dict": schema_dict}
        )
        return {
            "is_valid": False,
            "errors": [schema_error.to_dict()],
            "validated_schema": None,
        }
    except Exception as e:
        schema_error = SchemaValidationError(
            message=f"Unexpected error during schema validation: {str(e)}",
            details={"schema_dict": schema_dict}
        )
        return {
            "is_valid": False,
            "errors": [schema_error.to_dict()],
            "validated_schema": None,
        }
