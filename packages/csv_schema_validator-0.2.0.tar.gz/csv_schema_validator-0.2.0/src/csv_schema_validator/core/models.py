"""
Pydantic models for CSV schema definition.
"""
from __future__ import annotations

from enum import Enum
from typing import ClassVar

from pydantic import BaseModel, Field, field_validator, model_validator


class FieldType(str, Enum):
    STRING = "string"
    NUMBER = "number"
    INTEGER = "integer"
    BOOLEAN = "boolean"


class FieldSchema(BaseModel):
    """Schema definition for a single CSV field."""
    
    name: str = Field(..., description="Field name")
    type: FieldType = Field(..., description="Field data type")
    required: bool = Field(..., description="Whether the field is required")
    description: str | None = Field(None, description="Field description")
    pattern: str | None = Field(None, description="Field pattern")
    enum: list[str] | None = Field(None, description="Field enum")
    min: int | None = Field(None, description="Field minimum value")
    max: int | None = Field(None, description="Field maximum value")
    
    # Class variables for validation
    _SUPPORTED_TYPES: ClassVar[set[str]] = {"string", "number", "integer", "boolean"}
    _NUMERIC_TYPES: ClassVar[set[str]] = {"number", "integer"}

    @field_validator("pattern")
    @classmethod
    def validate_pattern(cls, v: str | None) -> str | None:
        """Validate that the pattern is a valid regex."""
        if v is not None:
            import re
            try:
                re.compile(v)
            except re.error as e:
                raise ValueError(f"Invalid pattern: {e}")
        return v

    @model_validator(mode="after")
    def validate_min_max(self) -> FieldSchema:
        """Validate that min/max constraints are only applied to numeric types."""
        if self.min is not None or self.max is not None:
            if self.type.value not in self._NUMERIC_TYPES:
                raise ValueError(
                    f"min/max constraints not applicable for {self.type.value} type"
                )
        return self


class CSVSchema(BaseModel):
    """Schema definition for a CSV file."""
    
    name: str = Field(..., description="Schema name")
    description: str | None = Field(None, description="Schema description")
    fields: list[FieldSchema] = Field(..., min_length=1, description="Field definitions")

    @field_validator("fields")
    @classmethod
    def validate_fields(cls, v: list[FieldSchema]) -> list[FieldSchema]:
        """Validate that field names are unique."""
        names = [field.name for field in v]
        if len(names) != len(set(names)):
            raise ValueError("Field names must be unique")
        return v
