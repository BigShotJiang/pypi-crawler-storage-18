"""
Schema validation module - re-exports from csv-schema-core.
"""
from __future__ import annotations

from .core import validate_schema_structure

# Re-export for backward compatibility
__all__ = ["validate_schema_structure"]
