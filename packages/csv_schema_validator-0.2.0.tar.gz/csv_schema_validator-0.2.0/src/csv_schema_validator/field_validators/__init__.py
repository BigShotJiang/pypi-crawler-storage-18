"""
CSV Field Validators - Comprehensive field validation for CSV data.

This package provides field-level validation functionality for CSV data,
including type validation, pattern matching, enum validation, range validation,
and required field checking.
"""

from .exceptions import (
    EnumValidationError,
    FieldValidationError,
    PatternValidationError,
    RangeValidationError,
    RequiredFieldError,
    TypeValidationError,
    ValidationConfigurationError,
)
from .types import ErrorDict, FieldDict, HeaderData, RowData, ValidationProtocol
from .validator import FieldValidator

__version__ = "0.1.0"
__all__ = [
    "FieldValidator",
    "FieldValidationError",
    "TypeValidationError",
    "PatternValidationError",
    "EnumValidationError",
    "RangeValidationError",
    "RequiredFieldError",
    "ValidationConfigurationError",
    "ErrorDict",
    "FieldDict",
    "HeaderData",
    "RowData",
    "ValidationProtocol",
]
