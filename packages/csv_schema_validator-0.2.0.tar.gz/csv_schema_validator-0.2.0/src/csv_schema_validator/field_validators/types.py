"""
Type definitions for CSV field validation.

This module provides type aliases and protocols for better type safety
and code documentation in the field validation package.
"""
from __future__ import annotations

from typing import Any, Protocol

# Type aliases for better readability
ErrorDict = dict[str, Any]
FieldDict = dict[str, Any]
RowData = list[str]
HeaderData = list[str]


class ValidationProtocol(Protocol):
    """Protocol for validation functions."""
    
    def __call__(self, value: str, **kwargs: Any) -> ErrorDict | None:
        """Validate a value and return error dict if invalid, None if valid."""
        ...


# Constants for supported field types
SUPPORTED_FIELD_TYPES = frozenset({"string", "number", "integer", "boolean"})
NUMERIC_FIELD_TYPES = frozenset({"number", "integer"})
