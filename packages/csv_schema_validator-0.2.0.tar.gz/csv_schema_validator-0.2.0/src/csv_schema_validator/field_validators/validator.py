"""
Field validation module for CSV field validation.

This module provides comprehensive field validation functionality including
type validation, pattern matching, enum validation, range validation, and
required field checking.
"""
from __future__ import annotations

import re
from typing import Any

from ..core import BOOLEAN_VALUES

from .exceptions import (
    EnumValidationError,
    PatternValidationError,
    RangeValidationError,
    RequiredFieldError,
    TypeValidationError,
    ValidationConfigurationError,
)


class FieldValidator:
    """Validates individual fields and rows against schema definitions."""
    
    @staticmethod
    def validate_row(
        row: list[str], header: list[str], schema: dict[str, Any], row_number: int
    ) -> list[dict[str, Any]]:
        """
        Validate a single row against the schema.
        
        Args:
            row: List of field values
            header: List of column names
            schema: Schema definition dictionary
            row_number: Row number for error reporting
            
        Returns:
            List of error dictionaries
        """
        fields_schema_dict = FieldValidator.dict_array_to_dict(schema["fields"], "name")
        errors = []

        for i in range(len(row)):
            if i < len(header) and header[i] in fields_schema_dict:
                field_errors = FieldValidator.is_field_valid(
                    row[i], fields_schema_dict[header[i]], row_number, header[i]
                )
                errors.extend(field_errors)

        return errors

    @staticmethod
    def is_field_valid(
        field: str, field_schema: dict[str, Any], row_number: int, column: str
    ) -> list[dict[str, Any]]:
        """
        Validate a single field against its schema definition.
        
        Args:
            field: Field value to validate
            field_schema: Schema definition for this field
            row_number: Row number for error reporting
            column: Column name for error reporting
            
        Returns:
            List of error dictionaries
        """
        errors = []
        
        # Type validation (must be done first)
        type_error = FieldValidator.is_type_valid(field, field_schema["type"], row_number, column)
        if type_error:
            errors.append(type_error)
            # If type is invalid, don't validate other constraints
            return errors

        # Additional validations only if type is valid
        if "enum" in field_schema:
            enum_error = FieldValidator.validate_enum(field, field_schema["enum"], row_number, column)
            if enum_error:
                errors.append(enum_error)

        if "pattern" in field_schema:
            pattern_error = FieldValidator.validate_pattern(field, field_schema["pattern"], row_number, column)
            if pattern_error:
                errors.append(pattern_error)

        if "min" in field_schema or "max" in field_schema:
            range_error = FieldValidator.validate_range(
                field, field_schema.get("min"), field_schema.get("max"), row_number, column
            )
            if range_error:
                errors.append(range_error)

        return errors

    @staticmethod
    def is_type_valid(field: str, field_type: str, row_number: int, column: str) -> dict[str, Any] | None:
        """
        Validate field type.
        
        Args:
            field: Field value to validate
            field_type: Expected type
            row_number: Row number for error reporting
            column: Column name for error reporting
            
        Returns:
            Error dictionary if validation fails, None if valid
        """
        supported_types = frozenset({"string", "number", "integer", "boolean"})
        
        if field_type not in supported_types:
            error = ValidationConfigurationError(
                message=f"Unsupported field type: {field_type}",
                details={"supported_types": list(supported_types)}
            )
            return error.to_dict()

        if field_type == "string":
            return None

        if field_type == "number":
            try:
                float(field)
                return None
            except ValueError:
                error = TypeValidationError(column, row_number, field, "number")
                return error.to_dict()

        if field_type == "integer":
            try:
                int(field)
                return None
            except ValueError:
                error = TypeValidationError(column, row_number, field, "integer")
                return error.to_dict()

        if field_type == "boolean":
            if field.lower() in BOOLEAN_VALUES:
                return None
            else:
                error = TypeValidationError(column, row_number, field, "boolean")
                error.details = {"supported_values": BOOLEAN_VALUES}
                return error.to_dict()

        return None

    @staticmethod
    def validate_pattern(field: str, pattern: str, row_number: int, column: str) -> dict[str, Any] | None:
        """
        Validate field against regex pattern.
        
        Args:
            field: Field value to validate
            pattern: Regex pattern to match
            row_number: Row number for error reporting
            column: Column name for error reporting
            
        Returns:
            Error dictionary if validation fails, None if valid
        """
        if not re.match(pattern, field):
            error = PatternValidationError(column, row_number, field, pattern)
            return error.to_dict()
        return None

    @staticmethod
    def validate_enum(field: str, allowed_values: list[str], row_number: int, column: str) -> dict[str, Any] | None:
        """
        Validate field against enum values.
        
        Args:
            field: Field value to validate
            allowed_values: List of allowed values
            row_number: Row number for error reporting
            column: Column name for error reporting
            
        Returns:
            Error dictionary if validation fails, None if valid
        """
        if field not in allowed_values:
            error = EnumValidationError(column, row_number, field, allowed_values)
            return error.to_dict()
        return None

    @staticmethod
    def validate_range(field: str, min_value: float | None, max_value: float | None, 
                      row_number: int, column: str) -> dict[str, Any] | None:
        """
        Validate field against min/max range.
        
        Args:
            field: Field value to validate
            min_value: Minimum allowed value
            max_value: Maximum allowed value
            row_number: Row number for error reporting
            column: Column name for error reporting
            
        Returns:
            Error dictionary if validation fails, None if valid
        """
        try:
            numeric_value = float(field)
        except ValueError:
            # Type validation should have caught this, but just in case
            error = TypeValidationError(column, row_number, field, "number")
            return error.to_dict()

        if min_value is not None and numeric_value < min_value:
            error = RangeValidationError(column, row_number, field, min_value=min_value)
            return error.to_dict()

        if max_value is not None and numeric_value > max_value:
            error = RangeValidationError(column, row_number, field, max_value=max_value)
            return error.to_dict()

        return None

    @staticmethod
    def dict_array_to_dict(array: list[dict[str, Any]], by_key: str) -> dict[str, dict[str, Any]]:
        """
        Convert list of dictionaries to dictionary keyed by specified field.
        
        Args:
            array: List of dictionaries
            by_key: Key to use for dictionary keys
            
        Returns:
            Dictionary keyed by the specified field
        """
        return {item[by_key]: item for item in array}

    @staticmethod
    def validate_required_fields(header: list[str], required_fields: list[str]) -> dict[str, Any]:
        """
        Validate that all required fields are present in the header.
        
        Args:
            header: List of column names in CSV
            required_fields: List of required field names
            
        Returns:
            Dictionary with validation results
        """
        missing_fields = set(required_fields) - set(header)
        
        if missing_fields:
            error = RequiredFieldError("", -1)  # Header-level error
            error.message = f"Missing required fields: {', '.join(missing_fields)}"
            error.details = {
                "required_fields": required_fields,
                "missing_fields": list(missing_fields),
                "available_fields": header
            }
            return {"is_valid": False, "errors": [error.to_dict()]}
        else:
            return {"is_valid": True, "errors": []}
