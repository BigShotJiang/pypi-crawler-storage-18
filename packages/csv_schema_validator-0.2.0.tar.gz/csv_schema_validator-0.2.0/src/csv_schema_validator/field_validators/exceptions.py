"""
Field validation exceptions for CSV field validation.

This module defines specific exception classes for different types of field validation
errors that can occur during CSV field validation, providing better error handling and
more informative error messages.
"""
from __future__ import annotations

from typing import Any


class FieldValidationError(Exception):
    """Base exception for field validation errors."""
    
    def __init__(self, message: str, field_name: str, row: int, 
                 value: Any, expected_type: str | None = None,
                 details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.field_name = field_name
        self.row = row
        self.value = value
        self.expected_type = expected_type
        self.details = details or {}
    
    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary format for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "error_message": self.message,
            "row": self.row,
            "column": self.field_name,
            "value": self.value,
            "details": self.details
        }


class TypeValidationError(FieldValidationError):
    """Raised when field type validation fails."""
    
    def __init__(self, field_name: str, row: int, value: Any, expected_type: str):
        message = f"Invalid type for field '{field_name}': expected {expected_type}, got {type(value).__name__}"
        super().__init__(message, field_name, row, value, expected_type)
        self.details = {
            "expected_type": expected_type,
            "actual_type": type(value).__name__
        }


class PatternValidationError(FieldValidationError):
    """Raised when field pattern validation fails."""
    
    def __init__(self, field_name: str, row: int, value: Any, pattern: str):
        message = f"Field '{field_name}' does not match required pattern"
        super().__init__(message, field_name, row, value, details={"expected_pattern": pattern})


class EnumValidationError(FieldValidationError):
    """Raised when field enum validation fails."""
    
    def __init__(self, field_name: str, row: int, value: Any, allowed_values: list[str]):
        message = f"Field '{field_name}' value '{value}' is not in allowed values"
        super().__init__(message, field_name, row, value, details={"allowed_values": allowed_values})


class RangeValidationError(FieldValidationError):
    """Raised when field range validation fails."""
    
    def __init__(self, field_name: str, row: int, value: Any, min_value: float | None = None, 
                 max_value: float | None = None):
        if min_value is not None and max_value is not None:
            message = f"Field '{field_name}' value '{value}' is outside range [{min_value}, {max_value}]"
            details = {"min_value": min_value, "max_value": max_value}
        elif min_value is not None:
            message = f"Field '{field_name}' value '{value}' is below minimum {min_value}"
            details = {"min_value": min_value}
        else:
            message = f"Field '{field_name}' value '{value}' exceeds maximum {max_value}"
            details = {"max_value": max_value}
        
        super().__init__(message, field_name, row, value, details=details)


class RequiredFieldError(FieldValidationError):
    """Raised when a required field is missing."""
    
    def __init__(self, field_name: str, row: int):
        message = f"Required field '{field_name}' is missing"
        super().__init__(message, field_name, row, None)


class ValidationConfigurationError(Exception):
    """Raised when there are configuration errors in validation setup."""
    
    def __init__(self, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}
    
    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary format for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "error_message": self.message,
            "row": None,
            "column": None,
            "value": None,
            "details": self.details
        }
