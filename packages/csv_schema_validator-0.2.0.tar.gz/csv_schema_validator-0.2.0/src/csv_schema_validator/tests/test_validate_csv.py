import pytest
import tempfile
import os

from csv_schema_validator.validate_csv import validate_csv


class TestValidateCSV:
    """Test suite for the validate_csv function"""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test files"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    @pytest.fixture
    def basic_schema(self):
        """Create a basic schema file for testing"""
        return {
            "name": "Test Schema",
            "description": "Basic test schema",
            "fields": [
                {
                    "name": "id",
                    "type": "integer",
                    "required": True,
                    "description": "Unique identifier",
                },
                {
                    "name": "name",
                    "type": "string",
                    "required": True,
                    "description": "Name field",
                },
                {
                    "name": "email",
                    "type": "string",
                    "required": True,
                    "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
                    "description": "Email address",
                },
                {
                    "name": "department",
                    "type": "string",
                    "required": True,
                    "enum": ["Engineering", "Marketing", "Sales"],
                    "description": "Department",
                },
                {
                    "name": "salary",
                    "type": "number",
                    "required": True,
                    "min": 30000,
                    "max": 200000,
                    "description": "Salary",
                },
                {
                    "name": "is_active",
                    "type": "boolean",
                    "required": True,
                    "description": "Active status",
                },
            ],
        }

    @pytest.fixture
    def invalid_schema(self):
        """Create an invalid schema file for testing"""
        return {
            "name": "Invalid Schema",
            "description": "Invalid schema",
            "fields": [
                {
                    "name": "id",
                    "required": True,
                },
            ],
            "invalid_field": "invalid_field",
        }

    @pytest.fixture
    def non_json_non_text_schema(self):
        """Create a non JSON non text schema file for testing"""
        return 123

    @pytest.fixture
    def non_json_text_schema(self):
        """Create a non JSON schema file for testing"""
        return "invalid schema"

    @pytest.fixture
    def valid_csv(self, temp_dir):
        """Create a valid CSV file for testing"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000,true
2,Jane Smith,jane.smith@company.com,Marketing,65000,false"""

        csv_file = os.path.join(temp_dir, "valid.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        return csv_file

    @pytest.fixture
    def invalid_csv(self, temp_dir):
        """Create an invalid CSV file for testing"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,invalid-email,Engineering,75000,true
2,Jane Smith,jane.smith@company.com,InvalidDept,65000,false
3,invalid-id,Bob Johnson,bob@company.com,Sales,25000,maybe
4,Alice Williams,alice@company.com,Marketing,300000,true"""
        csv_file = os.path.join(temp_dir, "invalid.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        return csv_file

    @pytest.fixture
    def non_matching_csv(self, temp_dir):
        """Create a non matching CSV file for testing"""
        csv_content = """id,namee,email,department,salary,is_active
1,John Doe,john.doe@company,Engineerin,75000,yes
two,Jane Smith,jane.smith@company.com,Marketing,65000,false"""
        csv_file = os.path.join(temp_dir, "non_matching.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        return csv_file

    def test_validate_csv_empty_file(self, temp_dir, basic_schema):
        """Test validation of empty CSV file"""
        empty_csv = os.path.join(temp_dir, "empty.csv")
        with open(empty_csv, "w") as f:
            f.write("")

            result = validate_csv(empty_csv, basic_schema)
            assert result == {
                "is_valid": False,
                "errors": [
                    {
                        "error_type": "EmptyFileError",
                        "error_message": "Csv file is empty",
                        "row": None,
                        "column": None,
                        "value": None,
                        "details": {"file_type": "CSV", "file_path": empty_csv},
                    }
                ],
            }

    def test_validate_invalid_schema(self, valid_csv, invalid_schema):
        result = validate_csv(valid_csv, invalid_schema)
        assert result == {
            "is_valid": False,
            "errors": [
                {
                    "error_type": "SchemaValidationError",
                    "error_message": "Field required",
                    "row": None,
                    "column": None,
                    "value": None,
                    "details": {
                        "input": {"name": "id", "required": True},
                        "type": "missing"
                    },
                }
            ],
            "validated_schema": None,
        }

    def test_non_json_text_schema(self, valid_csv, non_json_text_schema):
        result = validate_csv(valid_csv, non_json_text_schema)
        assert result == {
            "is_valid": False,
            "errors": [
                {
                    "error_type": "SchemaValidationError",
                    "error_message": "csv_schema_validator.core.models.CSVSchema() argument after ** must be a mapping, not str",
                    "row": None,
                    "column": None,
                    "value": None,
                    "details": {"schema_dict": "invalid schema"},
                }
            ],
            "validated_schema": None,
        }

    def test_non_json_non_text_schema(self, valid_csv, non_json_non_text_schema):
        result = validate_csv(valid_csv, non_json_non_text_schema)
        assert result == {
            "is_valid": False,
            "errors": [
                {
                    "error_type": "SchemaValidationError",
                    "error_message": "csv_schema_validator.core.models.CSVSchema() argument after ** must be a mapping, not int",
                    "row": None,
                    "column": None,
                    "value": None,
                    "details": {"schema_dict": 123},
                }
            ],
            "validated_schema": None,
        }

    def test_validate_valid_csv(self, valid_csv, basic_schema):
        result = validate_csv(valid_csv, basic_schema)
        assert result == {
            "is_valid": True,
            "errors": [],
        }

    def test_validate_non_matching_csv(self, non_matching_csv, basic_schema):
        result = validate_csv(non_matching_csv, basic_schema)
        assert result == {
            "is_valid": False,
            "errors": [
                {
                    "error_type": "RequiredFieldError",
                    "error_message": "Missing required fields: name",
                    "row": -1,
                    "column": "",
                    "value": None,
                    "details": {
                        "required_fields": [
                            "id",
                            "name",
                            "email",
                            "department",
                            "salary",
                            "is_active",
                        ],
                        "missing_fields": ["name"],
                        "available_fields": [
                            "id",
                            "namee",
                            "email",
                            "department",
                            "salary",
                            "is_active",
                        ],
                    },
                },
                {
                    "error_type": "PatternValidationError",
                    "error_message": "Field 'email' does not match required pattern",
                    "value": "john.doe@company",
                    "column": "email",
                    "row": 2,
                    "details": {
                        "expected_pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
                    },
                },
                {
                    "error_type": "EnumValidationError",
                    "error_message": "Field 'department' value 'Engineerin' is not in allowed values",
                    "value": "Engineerin",
                    "column": "department",
                    "row": 2,
                    "details": {"allowed_values": ["Engineering", "Marketing", "Sales"]},
                },
                {
                    "error_type": "TypeValidationError",
                    "error_message": "Invalid type for field 'is_active': expected boolean, got str",
                    "value": "yes",
                    "column": "is_active",
                    "row": 2,
                    "details": {"supported_values": ["true", "false"]},
                },
                {
                    "error_type": "TypeValidationError",
                    "error_message": "Invalid type for field 'id': expected integer, got str",
                    "value": "two",
                    "column": "id",
                    "row": 3,
                    "details": {"expected_type": "integer", "actual_type": "str"},
                },
            ],
        }

    def test_validate_csv_edge_case_data_types(self, temp_dir, basic_schema):
        """Test edge cases for different data types"""
        csv_content = """id,name,email,department,salary,is_active
,John Doe,john.doe@company.com,Engineering,75000,true
1, ,jane.smith@company.com,Marketing,65000,false
2,Jane Smith,,Sales,65000,true
3,Bob Johnson,bob@company.com,,65000,false
4,Alice Williams,alice@company.com,Engineering,,true
5,Charlie Brown,charlie@company.com,Marketing,65000,
6,David Wilson,david@company.com,Engineering,30000,true
7,Eve Davis,eve@company.com,Marketing,200000,false"""

        csv_file = os.path.join(temp_dir, "edge_cases.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        assert len(result["errors"]) > 0
        # Should have errors for empty id, empty name, invalid email, missing department, etc.

    def test_validate_csv_min_max_boundaries(self, temp_dir, basic_schema):
        """Test min/max constraints at exact boundaries"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,30000,true
2,Jane Smith,jane.smith@company.com,Marketing,200000,false
3,Bob Johnson,bob@company.com,Sales,29999,true
4,Alice Williams,alice@company.com,Engineering,200001,false"""

        csv_file = os.path.join(temp_dir, "boundaries.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        # Should have errors for salary values outside min/max range
        salary_errors = [error for error in result["errors"] if error.get("column") == "salary"]
        assert len(salary_errors) >= 2  # At least 29999 and 200001 should fail

    def test_validate_csv_large_file(self, temp_dir, basic_schema):
        """Test validation with a large CSV file (performance test)"""
        # Generate a CSV with 1000+ rows
        csv_content = "id,name,email,department,salary,is_active\n"
        for i in range(1000):
            csv_content += f"{i+1},User{i+1},user{i+1}@company.com,Engineering,75000,true\n"

        csv_file = os.path.join(temp_dir, "large.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        assert len(result["errors"]) == 0

    def test_validate_csv_with_quotes_and_commas(self, temp_dir, basic_schema):
        """Test CSV with quoted fields containing commas"""
        csv_content = '''id,name,email,department,salary,is_active
1,"Doe, John",john.doe@company.com,Engineering,75000,true
2,"Smith, Jane",jane.smith@company.com,"Marketing, Digital",65000,false'''

        csv_file = os.path.join(temp_dir, "quoted.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        # Should fail because "Marketing, Digital" is not in the enum
        assert not result["is_valid"]
        enum_errors = [error for error in result["errors"] if error.get("error_type") == "EnumValidationError"]
        assert len(enum_errors) > 0

    def test_validate_csv_unicode_characters(self, temp_dir, basic_schema):
        """Test CSV with unicode and special characters"""
        csv_content = """id,name,email,department,salary,is_active
1,José García,jose.garcia@company.com,Engineering,75000,true
2,François Müller,francois.muller@company.com,Marketing,65000,false
3,李小明,li.xiaoming@company.com,Sales,70000,true"""

        csv_file = os.path.join(temp_dir, "unicode.csv")
        with open(csv_file, "w", encoding='utf-8') as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        assert len(result["errors"]) == 0

    def test_validate_schema_duplicate_field_names(self, temp_dir):
        """Test schema with duplicate field names"""
        schema = {
            "name": "Test Schema",
            "fields": [
                {"name": "id", "type": "integer", "required": True},
                {"name": "id", "type": "string", "required": True}  # Duplicate name
            ]
        }

        csv_content = """id,name
1,John"""
        csv_file = os.path.join(temp_dir, "test.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, schema)
        assert not result["is_valid"]
        assert "Field names must be unique" in str(result["errors"])

    def test_validate_schema_invalid_regex_pattern(self, temp_dir):
        """Test schema with invalid regex pattern"""
        schema = {
            "name": "Test Schema", 
            "fields": [
                {"name": "email", "type": "string", "pattern": "[invalid regex", "required": True}
            ]
        }

        csv_content = """email
test@example.com"""
        csv_file = os.path.join(temp_dir, "test.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, schema)
        assert not result["is_valid"]
        # Should fail schema validation due to invalid regex

    def test_validate_schema_min_max_on_string_boolean(self, temp_dir):
        """Test schema with min/max constraints on string/boolean fields"""
        schema = {
            "name": "Test Schema",
            "fields": [
                {"name": "name", "type": "string", "min": 5, "required": True},
                {"name": "active", "type": "boolean", "max": 10, "required": True}
            ]
        }

        csv_content = """name,active
John,true"""
        csv_file = os.path.join(temp_dir, "test.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, schema)
        assert not result["is_valid"]
        # Should fail schema validation due to min/max on string/boolean

    def test_validate_csv_nonexistent_file(self, basic_schema):
        """Test validation with non-existent CSV file"""
        result = validate_csv("nonexistent_file.csv", basic_schema)
        assert result == {
            "is_valid": False,
            "errors": [
                {
                    "error_type": "CSVFileError",
                    "error_message": "CSV file not found: nonexistent_file.csv",
                    "row": None,
                    "column": None,
                    "value": None,
                    "details": {"file_path": "nonexistent_file.csv"},
                }
            ],
        }

    def test_validate_csv_whitespace_only_fields(self, temp_dir, basic_schema):
        """Test CSV with whitespace-only fields"""
        csv_content = """id,name,email,department,salary,is_active
1,   ,john.doe@company.com,Engineering,75000,true
2,John Doe,   ,Marketing,65000,false
3,John Doe,john.doe@company.com,   ,75000,true"""

        csv_file = os.path.join(temp_dir, "whitespace.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        # Should have errors for whitespace-only fields

    def test_validate_csv_number_formats(self, temp_dir, basic_schema):
        """Test various number formats"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000.0,true
2,Jane Smith,jane.smith@company.com,Marketing,65000.50,false
3,Bob Johnson,bob@company.com,Sales,1e5,true
4,Alice Williams,alice@company.com,Engineering,inf,false"""

        csv_file = os.path.join(temp_dir, "number_formats.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        # Should have errors for invalid number formats like 'inf'

    def test_validate_csv_boolean_case_variations(self, temp_dir, basic_schema):
        """Test boolean values with different cases"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000,TRUE
2,Jane Smith,jane.smith@company.com,Marketing,65000,FALSE
3,Bob Johnson,bob@company.com,Sales,70000,True
4,Alice Williams,alice@company.com,Engineering,80000,False"""

        csv_file = os.path.join(temp_dir, "boolean_cases.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        # Boolean validation is case-insensitive, so TRUE/FALSE/True/False should all be valid

    def test_validate_csv_no_required_fields(self, temp_dir):
        """Test schema where no fields are required"""
        schema = {
            "name": "Test Schema",
            "fields": [
                {"name": "id", "type": "integer", "required": False},
                {"name": "name", "type": "string", "required": False}
            ]
        }

        csv_content = """id,name
1,John"""
        csv_file = os.path.join(temp_dir, "no_required.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, schema)
        assert result["is_valid"]
        assert len(result["errors"]) == 0

    def test_validate_csv_extra_columns(self, temp_dir, basic_schema):
        """Test CSV with extra columns not in schema"""
        csv_content = """id,name,email,department,salary,is_active,extra_column
1,John Doe,john.doe@company.com,Engineering,75000,true,extra_value
2,Jane Smith,jane.smith@company.com,Marketing,65000,false,another_extra"""

        csv_file = os.path.join(temp_dir, "extra_columns.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        # Extra columns should be ignored, not cause validation errors

    def test_validate_csv_error_message_clarity(self, temp_dir, basic_schema):
        """Test that error messages are clear and actionable"""
        csv_content = """id,name,email,department,salary,is_active
invalid-id,John Doe,invalid-email,InvalidDept,25000,maybe"""

        csv_file = os.path.join(temp_dir, "error_clarity.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        
        # Check that error messages contain helpful information
        errors = result["errors"]
        error_types = [error.get("error_type") for error in errors]
        
        # Should have specific error types that are actionable
        expected_error_types = ["TypeValidationError", "PatternValidationError", "EnumValidationError", "TypeValidationError", "RangeValidationError"]
        for expected_type in expected_error_types:
            assert any(error_type == expected_type for error_type in error_types), f"Missing expected error type: {expected_type}"

    def test_validate_csv_empty_fields_with_required_constraints(self, temp_dir):
        """Test empty fields when they are required"""
        schema = {
            "name": "Test Schema",
            "fields": [
                {"name": "id", "type": "integer", "required": True},
                {"name": "name", "type": "string", "required": True},
                {"name": "email", "type": "string", "required": False}  # Not required
            ]
        }

        csv_content = """id,name,email
,John Doe,
1,,jane@example.com"""

        csv_file = os.path.join(temp_dir, "empty_required.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, schema)
        assert not result["is_valid"]
        # Should have errors for empty required fields

    def test_validate_csv_very_long_strings(self, temp_dir, basic_schema):
        """Test CSV with very long string values"""
        long_name = "A" * 1000  # Very long name
        csv_content = f"""id,name,email,department,salary,is_active
1,{long_name},john.doe@company.com,Engineering,75000,true"""

        csv_file = os.path.join(temp_dir, "long_strings.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        # Long strings should be handled gracefully

    def test_validate_csv_scientific_notation(self, temp_dir, basic_schema):
        """Test CSV with scientific notation in numeric fields"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,7.5e4,true
2,Jane Smith,jane.smith@company.com,Marketing,6.5e4,false"""

        csv_file = os.path.join(temp_dir, "scientific.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert result["is_valid"]
        # Scientific notation should be handled correctly

    def test_validate_csv_negative_numbers(self, temp_dir, basic_schema):
        """Test CSV with negative numbers"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,-75000,true"""

        csv_file = os.path.join(temp_dir, "negative.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        # Negative salary should fail min constraint

    def test_validate_csv_zero_values(self, temp_dir, basic_schema):
        """Test CSV with zero values"""
        csv_content = """id,name,email,department,salary,is_active
0,John Doe,john.doe@company.com,Engineering,0,true"""

        csv_file = os.path.join(temp_dir, "zero.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)

        result = validate_csv(csv_file, basic_schema)
        assert not result["is_valid"]
        # Zero salary should fail min constraint
