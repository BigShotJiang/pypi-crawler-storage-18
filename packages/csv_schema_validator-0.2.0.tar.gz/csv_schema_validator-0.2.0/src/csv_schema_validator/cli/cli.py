"""
Command-line interface for CSV schema validation.
"""
from __future__ import annotations

import json
import os
import sys

from .. import validate_csv
from ..exceptions import InvalidJSONError, SchemaFileError

"""
CLI usages:
csv-schema-validator <csv_file> <schema_file>    # Validate CSV against schema
csv-schema-validator -h                          # Show help
csv-schema-validator --help                      # Show help
csv-schema-validator -v                          # Show version
csv-schema-validator --version                   # Show version
"""


def show_help() -> None:
    """Display help information."""
    help_text = """
csv-schema-validator - Validate CSV files against JSON schemas

USAGE:
    csv-schema-validator <csv_file> <schema_file>

ARGUMENTS:
    csv_file      Path to the CSV file to validate
    schema_file   Path to the JSON schema file

OPTIONS:
    -h, --help    Show this help message
    -v, --version Show version information

EXAMPLES:
    # Validate a CSV file against a schema
    csv-schema-validator employees.csv employee_schema.json
    
    # Show help
    csv-schema-validator --help
    
    # Show version
    csv-schema-validator --version

SCHEMA FORMAT:
    The schema file should be a JSON file with the following structure:
    {
        "name": "Schema Name",
        "description": "Schema description",
        "fields": [
            {
                "name": "field_name",
                "type": "string|number|integer|boolean",
                "required": true|false,
                "description": "Field description",
                "pattern": "regex_pattern",     // optional
                "enum": ["value1", "value2"],   // optional
                "min": 0,                       // optional
                "max": 100                      // optional
            }
        ]
    }

EXIT CODES:
    0    Validation passed
    1    Validation failed or error occurred

For more information, visit: https://github.com/your-repo/csv-schema-validator
"""
    print(help_text.strip())


def show_version() -> None:
    """Display version information."""
    print("csv-schema-validator 0.1.1")


def cli() -> None:
    """
    Command-line interface.
    """
    # Handle help and version flags
    if len(sys.argv) == 2:
        arg = sys.argv[1]
        if arg in ["-h", "--help"]:
            show_help()
            sys.exit(0)
        elif arg in ["-v", "--version"]:
            show_version()
            sys.exit(0)
        else:
            print("Usage: csv-schema-validator <csv_file> <schema_file>", file=sys.stderr)
            print("Use --help for more information.", file=sys.stderr)
            sys.exit(1)
    
    # Check for help flags even with other arguments
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            if arg in ["-h", "--help"]:
                show_help()
                sys.exit(0)
            elif arg in ["-v", "--version"]:
                show_version()
                sys.exit(0)
    
    if len(sys.argv) != 3:
        print("Usage: csv-schema-validator <csv_file> <schema_file>", file=sys.stderr)
        print("Use --help for more information.", file=sys.stderr)
        sys.exit(1)

    csv_file, schema_file = sys.argv[1:3]

    if not csv_file or not schema_file:
        print("Usage: csv-schema-validator <csv_file> <schema_file>")
        sys.exit(1)

    if not os.path.exists(csv_file):
        print(f"Error: CSV file {csv_file} does not exist")
        sys.exit(1)

    if not os.path.exists(schema_file):
        print(f"Error: Schema file {schema_file} does not exist")
        sys.exit(1)

    try:
        with open(schema_file, "r", encoding="utf-8") as f:
            schema = json.load(f)
    except json.JSONDecodeError as e:
        error = InvalidJSONError(schema_file, str(e))
        print(f"Error: {error.message}", file=sys.stderr)
        sys.exit(1)
    except IOError as e:
        error = SchemaFileError(f"Cannot read schema file: {str(e)}", schema_file)
        print(f"Error: {error.message}", file=sys.stderr)
        sys.exit(1)

    try:
        result = validate_csv(csv_file, schema)
        print(
            f"❌ Validation failed: {len(result['errors'])} errors found"
            if not result["is_valid"]
            else "✅ Validation passed"
        )
        print()
        for error in result["errors"]:
            print(
                f"Row {error['row'] if 'row' in error else -1}, Column {error['column'] if 'column' in error else -1}: {error['error_type'] if 'error_type' in error else 'Unknown error'}"
            )
            print(f"  Value: {error['value'] if 'value' in error else 'Unknown value'}")
            print(
                f"  Details: {error['details'] if 'details' in error else 'Unknown details'}"
            )
            print(
                f"  Error message: {error['error_message'] if 'error_message' in error else 'Unknown error message'}"
            )
            print()
        sys.stdout.flush()
        
        # Exit with appropriate code
        sys.exit(0 if result["is_valid"] else 1)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    cli()
