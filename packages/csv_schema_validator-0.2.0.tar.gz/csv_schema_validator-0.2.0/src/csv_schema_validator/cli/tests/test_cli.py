import pytest
import subprocess
import tempfile
import os
import json
from pathlib import Path


class TestCLI:
    """Test suite for the CLI interface using subprocess"""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test files"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    @pytest.fixture
    def project_root(self):
        """Get the project root directory"""
        return Path(__file__).parent.parent.parent.parent.parent

    @pytest.fixture
    def basic_schema(self, temp_dir):
        """Create a basic schema file for testing"""
        schema = {
            "name": "Test Schema",
            "description": "Basic test schema",
            "fields": [
                {
                    "name": "id",
                    "type": "integer",
                    "required": True,
                    "description": "Unique identifier",
                },
                {
                    "name": "name",
                    "type": "string",
                    "required": True,
                    "description": "Name field",
                },
                {
                    "name": "email",
                    "type": "string",
                    "required": True,
                    "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
                    "description": "Email address",
                },
                {
                    "name": "department",
                    "type": "string",
                    "required": True,
                    "enum": ["Engineering", "Marketing", "Sales"],
                    "description": "Department",
                },
                {
                    "name": "salary",
                    "type": "number",
                    "required": True,
                    "min": 30000,
                    "max": 200000,
                    "description": "Salary",
                },
                {
                    "name": "is_active",
                    "type": "boolean",
                    "required": True,
                    "description": "Active status",
                },
            ],
        }
        
        schema_file = os.path.join(temp_dir, "schema.json")
        with open(schema_file, "w") as f:
            json.dump(schema, f, indent=2)
        return schema_file

    @pytest.fixture
    def valid_csv(self, temp_dir):
        """Create a valid CSV file for testing"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000,true
2,Jane Smith,jane.smith@company.com,Marketing,65000,false
3,Bob Johnson,bob.johnson@company.com,Sales,55000,true"""
        
        csv_file = os.path.join(temp_dir, "valid.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        return csv_file

    @pytest.fixture
    def invalid_csv(self, temp_dir):
        """Create an invalid CSV file for testing"""
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,invalid-email,Engineering,75000,true
2,Jane Smith,jane.smith@company.com,InvalidDept,65000,false
3,invalid-id,Bob Johnson,bob@company.com,Sales,25000,maybe
4,Alice Williams,alice@company.com,Marketing,300000,true"""
        
        csv_file = os.path.join(temp_dir, "invalid.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        return csv_file

    @pytest.fixture
    def empty_csv(self, temp_dir):
        """Create an empty CSV file for testing"""
        csv_file = os.path.join(temp_dir, "empty.csv")
        with open(csv_file, "w") as f:
            f.write("")
        return csv_file

    @pytest.fixture
    def malformed_json_schema(self, temp_dir):
        """Create a malformed JSON schema file for testing"""
        schema_file = os.path.join(temp_dir, "malformed.json")
        with open(schema_file, "w") as f:
            f.write('{"name": "Test", "fields": [{"name": "id", "type": "integer"')  # Missing closing braces
        return schema_file

    def run_cli(self, csv_file, schema_file, project_root):
        """Helper method to run the CLI command"""
        import sys
        # Use absolute paths for the files
        abs_csv_file = os.path.abspath(csv_file)
        abs_schema_file = os.path.abspath(schema_file)
        
        cmd = [
            sys.executable, "-m", "csv_schema_validator.cli.cli",
            abs_csv_file, abs_schema_file
        ]
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )

    # === SUCCESS CASES ===
    
    def test_cli_success_with_valid_files(self, valid_csv, basic_schema, project_root):
        """Test CLI with valid CSV and schema files"""
        result = self.run_cli(valid_csv, basic_schema, project_root)
        
        assert result.returncode == 0
        assert "✅ Validation passed" in result.stdout
        assert "❌ Validation failed" not in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_success_with_minimal_valid_data(self, temp_dir, basic_schema, project_root):
        """Test CLI with minimal valid data"""
        # Create CSV with just one valid row
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000,true"""
        
        csv_file = os.path.join(temp_dir, "minimal.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        
        result = self.run_cli(csv_file, basic_schema, project_root)
        
        assert result.returncode == 0
        assert "✅ Validation passed" in result.stdout

    # === VALIDATION FAILURE CASES ===
    
    def test_cli_validation_failure_with_invalid_data(self, invalid_csv, basic_schema, project_root):
        """Test CLI with invalid CSV data"""
        result = self.run_cli(invalid_csv, basic_schema, project_root)
        
        # The new exception system provides clear error messages instead of crashes
        assert result.returncode == 1
        assert "❌ Validation failed" in result.stdout
        assert "PatternValidationError" in result.stdout or "EnumValidationError" in result.stdout

    def test_cli_validation_failure_with_empty_csv(self, empty_csv, basic_schema, project_root):
        """Test CLI with empty CSV file"""
        result = self.run_cli(empty_csv, basic_schema, project_root)
        
        assert result.returncode == 1  # CLI now exits with error on validation failure
        assert "❌ Validation failed" in result.stdout
        assert "EmptyFileError" in result.stdout

    # === FILE ERROR CASES ===
    
    def test_cli_missing_csv_file(self, basic_schema, project_root):
        """Test CLI with non-existent CSV file"""
        result = self.run_cli("nonexistent.csv", basic_schema, project_root)
        
        assert result.returncode == 1
        assert "Error: CSV file" in result.stdout
        assert "nonexistent.csv does not exist" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_missing_schema_file(self, valid_csv, project_root):
        """Test CLI with non-existent schema file"""
        result = self.run_cli(valid_csv, "nonexistent.json", project_root)
        
        assert result.returncode == 1
        assert "Error: Schema file" in result.stdout
        assert "nonexistent.json does not exist" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_missing_both_files(self, project_root):
        """Test CLI with both files missing"""
        result = self.run_cli("missing.csv", "missing.json", project_root)
        
        assert result.returncode == 1
        # Should fail on the first missing file (CSV)
        assert "Error: CSV file" in result.stdout
        assert "missing.csv does not exist" in result.stdout

    # === HELP AND VERSION OPTIONS ===
    
    def test_cli_help_long_flag(self, project_root):
        """Test CLI with --help flag"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "--help"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator - Validate CSV files against JSON schemas" in result.stdout
        assert "USAGE:" in result.stdout
        assert "ARGUMENTS:" in result.stdout
        assert "OPTIONS:" in result.stdout
        assert "EXAMPLES:" in result.stdout
        assert "SCHEMA FORMAT:" in result.stdout
        assert "EXIT CODES:" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_help_short_flag(self, project_root):
        """Test CLI with -h flag"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "-h"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator - Validate CSV files against JSON schemas" in result.stdout
        assert "USAGE:" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_version_long_flag(self, project_root):
        """Test CLI with --version flag"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "--version"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator 0.1.1" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_version_short_flag(self, project_root):
        """Test CLI with -v flag"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "-v"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator 0.1.1" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_help_with_other_args(self, project_root):
        """Test CLI with help flag and other arguments (help should take precedence)"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "file.csv", "--help"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator - Validate CSV files against JSON schemas" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    def test_cli_version_with_other_args(self, project_root):
        """Test CLI with version flag and other arguments (version should take precedence)"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "file.csv", "-v"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 0
        assert "csv-schema-validator 0.1.1" in result.stdout
        # Allow for RuntimeWarning about module import
        assert result.stderr == "" or "RuntimeWarning" in result.stderr

    # === ARGUMENT ERROR CASES ===
    
    def test_cli_no_arguments(self, project_root):
        """Test CLI with no arguments"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 1
        assert "Usage: csv-schema-validator <csv_file> <schema_file>" in result.stderr
        assert "Use --help for more information." in result.stderr

    def test_cli_insufficient_arguments_one(self, project_root):
        """Test CLI with only one argument"""
        import sys
        cmd = [sys.executable, "-m", "csv_schema_validator.cli.cli", "test.csv"]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        assert result.returncode == 1
        assert "Usage: csv-schema-validator <csv_file> <schema_file>" in result.stderr
        assert "Use --help for more information." in result.stderr

    def test_cli_too_many_arguments(self, valid_csv, basic_schema, project_root):
        """Test CLI with too many arguments"""
        import sys
        cmd = [
            sys.executable, "-m", "csv_schema_validator.cli.cli",
            valid_csv, basic_schema, "extra_arg"
        ]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            env={**os.environ, "PYTHONPATH": os.path.join(project_root, "src")}
        )
        
        # Your current CLI doesn't validate argument count, so this might work
        # or might fail depending on how sys.argv is handled
        # This test documents the current behavior
        assert result.returncode in [0, 1]  # Either success or failure is acceptable

    # === JSON ERROR CASES ===
    
    def test_cli_malformed_json_schema(self, valid_csv, malformed_json_schema, project_root):
        """Test CLI with malformed JSON schema"""
        result = self.run_cli(valid_csv, malformed_json_schema, project_root)
        
        # Your current CLI will crash with a JSON decode error
        # This test documents the current behavior
        assert result.returncode != 0
        # The error will be in stderr as a Python traceback
        assert "JSONDecodeError" in result.stderr or "json" in result.stderr.lower()

    def test_cli_empty_schema_file(self, valid_csv, temp_dir, project_root):
        """Test CLI with empty schema file"""
        empty_schema = os.path.join(temp_dir, "empty.json")
        with open(empty_schema, "w") as f:
            f.write("")
        
        result = self.run_cli(valid_csv, empty_schema, project_root)
        
        # Empty JSON file should cause JSON decode error
        assert result.returncode != 0
        assert "JSONDecodeError" in result.stderr or "json" in result.stderr.lower()

    # === OUTPUT FORMATTING TESTS ===
    
    def test_cli_output_formatting_success(self, valid_csv, basic_schema, project_root):
        """Test CLI output formatting for successful validation"""
        result = self.run_cli(valid_csv, basic_schema, project_root)
        
        assert result.returncode == 0
        output_lines = result.stdout.strip().split('\n')
        
        # Should have success message
        assert any("✅ Validation passed" in line for line in output_lines)
        
        # Should not have error details
        assert not any("Row" in line and "Column" in line for line in output_lines)

    def test_cli_output_formatting_failure(self, invalid_csv, basic_schema, project_root):
        """Test CLI output formatting for validation failure"""
        result = self.run_cli(invalid_csv, basic_schema, project_root)
        
        # The new exception system provides clear error messages instead of crashes
        assert result.returncode == 1
        assert "❌ Validation failed" in result.stdout
        assert "PatternValidationError" in result.stdout or "EnumValidationError" in result.stdout

    # === EDGE CASES ===
    
    def test_cli_with_unicode_data(self, temp_dir, basic_schema, project_root):
        """Test CLI with Unicode data in CSV"""
        csv_content = """id,name,email,department,salary,is_active
1,José García,jose.garcia@company.com,Engineering,75000,true
2,François Dupont,francois.dupont@company.com,Marketing,65000,false"""
        
        csv_file = os.path.join(temp_dir, "unicode.csv")
        with open(csv_file, "w", encoding="utf-8") as f:
            f.write(csv_content)
        
        result = self.run_cli(csv_file, basic_schema, project_root)
        
        assert result.returncode == 0
        assert "✅ Validation passed" in result.stdout

    def test_cli_with_large_csv(self, temp_dir, basic_schema, project_root):
        """Test CLI with larger CSV file"""
        # Create CSV with 100 rows
        csv_content = "id,name,email,department,salary,is_active\n"
        for i in range(1, 101):
            csv_content += f"{i},Person {i},person{i}@company.com,Engineering,{50000 + i},true\n"
        
        csv_file = os.path.join(temp_dir, "large.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        
        result = self.run_cli(csv_file, basic_schema, project_root)
        
        assert result.returncode == 0
        assert "✅ Validation passed" in result.stdout

    def test_cli_with_special_characters_in_paths(self, temp_dir, basic_schema, project_root):
        """Test CLI with special characters in file paths"""
        # Create files with spaces and special characters
        csv_content = """id,name,email,department,salary,is_active
1,John Doe,john.doe@company.com,Engineering,75000,true"""
        
        csv_file = os.path.join(temp_dir, "file with spaces.csv")
        with open(csv_file, "w") as f:
            f.write(csv_content)
        
        result = self.run_cli(csv_file, basic_schema, project_root)
        
        assert result.returncode == 0
        assert "✅ Validation passed" in result.stdout

    # === PERFORMANCE TESTS ===
    
    def test_cli_execution_time(self, valid_csv, basic_schema, project_root):
        """Test that CLI executes within reasonable time"""
        import time
        
        start_time = time.time()
        result = self.run_cli(valid_csv, basic_schema, project_root)
        end_time = time.time()
        
        execution_time = end_time - start_time
        
        assert result.returncode == 0
        assert execution_time < 5.0  # Should complete within 5 seconds