"""
CSV Schema Validator CLI - Command-line interface for CSV schema validation.

This package provides a command-line interface for validating CSV files against
JSON schemas using the csv-schema-validator library.
"""

from .cli import cli, show_help, show_version

__version__ = "0.1.1"
__all__ = [
    "cli",
    "show_help", 
    "show_version",
]
