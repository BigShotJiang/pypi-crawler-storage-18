"""
CSV validation module using custom exceptions.
"""
from __future__ import annotations

import csv
from pathlib import Path

from .exceptions import (
    CSVFileError,
    EmptyFileError,
    ValidationConfigurationError,
)
from .schema_validator import validate_schema_structure
from .types import HeaderData, SchemaDict, ValidationResult
from .validator import FieldValidator


def validate_csv(csv_file: str | Path, schema: SchemaDict) -> ValidationResult:
    """
    Validate a CSV file against a JSON schema.

    Args:
        csv_file: The path to the CSV file to validate.
        schema: The JSON schema to validate the CSV file against.

    Returns:
        A dictionary containing the validation results:
        - is_valid: A boolean indicating if the CSV file is valid.
        - errors: A list of errors found in the CSV file.
        Each error is a dictionary containing the following keys:
        - error_type: The type of error.
        - error_message: Human-readable error message.
        - row: Row number where error occurred (-1 for header errors).
        - column: Column name where error occurred.
        - value: The value that caused the error.
        - details: Additional error details.
    """
    csv_path = Path(csv_file)
    
    # Validate schema first
    schema_validation_result = validate_schema_structure(schema)
    if not schema_validation_result["is_valid"]:
        return schema_validation_result

    # Extract required field names
    try:
        required_field_names = [
            field["name"] for field in schema["fields"] if field["required"]
        ]
    except (KeyError, TypeError) as e:
        error = ValidationConfigurationError(
            message=f"Invalid schema structure: {str(e)}",
            details={"schema": schema}
        )
        return {"is_valid": False, "errors": [error.to_dict()]}

    all_errors = []

    try:
        with open(csv_path, "r", encoding="utf-8") as file:
            reader = csv.reader(file)
            try:
                header: HeaderData = next(reader)
            except StopIteration:
                error = EmptyFileError(str(csv_path), "CSV")
                return {"is_valid": False, "errors": [error.to_dict()]}

            # Validate required fields are present
            header_result = FieldValidator.validate_required_fields(
                header, required_field_names
            )
            if not header_result["is_valid"]:
                all_errors.extend(header_result["errors"])

            # Validate each row
            for row_number, row in enumerate(reader, start=2):  # Start at 2 (header is row 1)
                row_errors = FieldValidator.validate_row(
                    row, header, schema, row_number
                )
                all_errors.extend(row_errors)

    except FileNotFoundError:
        error = CSVFileError(
            message=f"CSV file not found: {csv_path}",
            file_path=str(csv_path)
        )
        return {"is_valid": False, "errors": [error.to_dict()]}
    except PermissionError:
        error = CSVFileError(
            message=f"Permission denied reading CSV file: {csv_path}",
            file_path=str(csv_path)
        )
        return {"is_valid": False, "errors": [error.to_dict()]}
    except UnicodeDecodeError as e:
        error = CSVFileError(
            message=f"Unable to decode CSV file: {str(e)}",
            file_path=str(csv_path),
            details={"encoding_error": str(e)}
        )
        return {"is_valid": False, "errors": [error.to_dict()]}
    except Exception as e:
        error = CSVFileError(
            message=f"Unexpected error reading CSV file: {str(e)}",
            file_path=str(csv_path),
            details={"error_type": type(e).__name__}
        )
        return {"is_valid": False, "errors": [error.to_dict()]}

    return {
        "is_valid": len(all_errors) == 0,
        "errors": all_errors,
    }
