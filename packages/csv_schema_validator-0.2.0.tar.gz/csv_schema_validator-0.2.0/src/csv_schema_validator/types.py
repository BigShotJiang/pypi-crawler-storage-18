"""
Type definitions for CSV schema validation.

This module provides type aliases and protocols for better type safety
and code documentation.
"""
from __future__ import annotations

from typing import Any, Protocol

from .core import FieldDict, SchemaDict, ValidationResult, BOOLEAN_VALUES
from .field_validators import ErrorDict, RowData, HeaderData, ValidationProtocol

# Re-export for backward compatibility
__all__ = [
    "ErrorDict",
    "FieldDict", 
    "SchemaDict",
    "ValidationResult",
    "BOOLEAN_VALUES",
    "RowData",
    "HeaderData",
    "ValidationProtocol",
]

# Error type constants
ERROR_TYPES = frozenset({
    "CSVValidationError",
    "SchemaValidationError", 
    "FieldValidationError",
    "TypeValidationError",
    "PatternValidationError",
    "EnumValidationError",
    "RangeValidationError",
    "RequiredFieldError",
    "FileError",
    "CSVFileError",
    "SchemaFileError",
    "EmptyFileError",
    "InvalidJSONError",
    "ValidationConfigurationError",
})
