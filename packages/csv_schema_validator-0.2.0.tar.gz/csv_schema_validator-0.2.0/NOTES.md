# csv-schema-validator

Here's how to publish your package to PyPI so everyone can install it with `pip install csv-schema-validator`:

## 1. Install build tools
```bash
pip install build twine
```

## 2. Build the package
```bash
python -m build
```
This creates `dist/` folder with your package files.

## 3. Upload to PyPI

**For Test PyPI first (recommended):**
```bash
python -m twine upload --repository testpypi dist/*
```
Test with: `pip install --index-url https://test.pypi.org/simple/ csv-schema-validator`

**For real PyPI:**
```bash
python -m twine upload dist/*
```

## 4. You'll be prompted for credentials:
- Username: your PyPI username
- Password: your PyPI password (or API token)

## 5. After publishing, anyone can install:
```bash
pip install csv-schema-validator
```

## Important notes:
- **Version numbers**: Each upload needs a new version number in `pyproject.toml`
- **Package name**: Make sure `csv-schema-validator` isn't already taken on PyPI (you might need to change the name)
- **Test first**: Always test with Test PyPI before uploading to real PyPI
- **API tokens**: Consider using PyPI API tokens instead of passwords for security

Try Test PyPI first to make sure everything works!

---

pip install -e .

python3 -m venv .venv

source .venv/bin/activate

deactivate


Run with coverage:

pytest --cov=src/csv_schema_validator --cov-report=html

Run specific test file:

pytest tests/test_validate_csv.py

pytest src/csv_schema_validator/tests/test_validate_csv.py
pytest src/csv_schema_validator_cli/tests/test_cli.py

Run specific test:

pytest tests/test_validate_csv.py::TestValidateCSV::test_validate_csv_valid_file