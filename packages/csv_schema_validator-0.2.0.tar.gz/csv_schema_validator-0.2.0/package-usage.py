from csv_schema_validator import validate_csv

schema = {
    "name": "Employee Data Schema",
    "description": "Schema for validating employee CSV files",
    "fields": [
        {
            "name": "employee_id",
            "type": "integer",
            "required": True,
            "description": "Unique employee identifier",
        },
        {
            "name": "first_name",
            "type": "string",
            "required": True,
            "description": "Employee's first name",
        },
        {
            "name": "last_name",
            "type": "string",
            "required": True,
            "description": "Employee's last name",
        },
        {
            "name": "email",
            "type": "string",
            "required": True,
            "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
            "description": "Valid email address",
        },
        {
            "name": "department",
            "type": "string",
            "required": True,
            "enum": ["Engineering", "Marketing", "Sales", "HR", "Finance"],
            "description": "Employee department",
        },
        {
            "name": "salary",
            "type": "number",
            "required": True,
            "min": 30000,
            "max": 200000,
            "description": "Annual salary in USD",
        },
        {
            "name": "hire_date",
            "type": "string",
            "required": True,
            "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
            "description": "Hire date in YYYY-MM-DD format",
        },
        {
            "name": "is_active",
            "type": "boolean",
            "required": True,
            "description": "Whether employee is currently active",
        },
        {
            "name": "non_required_non_existing",
            "type": "string",
            "required": False,
            "description": "Check if won't be reported",
        },
    ],
}


print(
    f"valid_employees.csv valid: {validate_csv('valid_employees.csv', schema)}"
)
print(
    f"invalid_employees.csv valid: {validate_csv('invalid_employees.csv', schema)}"
)
