# Pandoc GUI (Doc-Kit)

A lightweight, platform-independent desktop application for converting documents using Pandoc.

## Installation

pip install pandoc-gui


## Usage

Once installed, you can launch the application using the simple command:

pandoc-gui


## Features
*   **Zero Dependencies**: Uses standard Python libraries (`tkinter`, `subprocess`).
*   **Platform Independent**: Works on Windows, macOS, and Linux.
*   **Drag & Drop**: (Coming soon)
*   **Auto-detection**: Automatically finds installed Pandoc formats.

## Requirements
*   **Python 3.6+**
*   **Pandoc**: Must be installed on your system path.
