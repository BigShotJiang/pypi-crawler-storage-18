from setuptools import setup, find_packages

setup(
    name="pandoc-gui",  # This is the name used for 'pip install'
    version="1.0.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="A Universal Pandoc GUI Converter",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/pandoc-gui",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            # This allows the user to type 'pandoc_gui' in the terminal
            'pandoc_gui=pandoc_gui.gui:main',
        ],
    },
)
