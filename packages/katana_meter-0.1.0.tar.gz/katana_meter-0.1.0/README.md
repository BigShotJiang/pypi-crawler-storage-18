# Katana Meter

Deterministic audio analyzer for LUFS, Peak and ΔE.

## Install
```bash
pip install katana-meter

