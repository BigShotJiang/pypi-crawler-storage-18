"""
ZAI Model Package
"""

from .base import BaseModel
from zai.config import ModelConfig

def create_model(config: ModelConfig) -> BaseModel:
    """
    Factory function to create a model based on the configuration.
    """
    if config.architecture.value == 'zai_igris':
        from zai.models.igris import IgrisModel
        return IgrisModel(config)
    # Add other models here
    # elif config.architecture == 'berudra':
    #     return BerudraModel(config)
    else:
        raise ValueError(f"Unsupported architecture: {config.architecture}")

__all__ = ['BaseModel', 'create_model']