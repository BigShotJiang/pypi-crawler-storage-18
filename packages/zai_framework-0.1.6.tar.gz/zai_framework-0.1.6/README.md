# ZAI Framework

**Advanced Hybrid Transformer Framework with MoE, SSM, and Adaptive Routing**

[![PyPI version](https://badge.fury.io/py/zai-framework.svg)](https://badge.fury.io/py/zai-framework)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🔥 Features

- **Hybrid Architecture**: Combines Local/Global Attention + State Space Models (SSM)
- **Mixture of Experts (MoE)**: 4-expert system with intelligent Top-2 routing
- **Adaptive Routing**: Dynamic 4D path selection (depth/width/path/expert)
- **Chain of Thought (CoT)**: Built-in reasoning module
- **Efficient**: 9.4% sparse activation, memory-optimized
- **Easy to Use**: Simple API, pretrained tokenizers included

## 📦 Installation

```bash
pip install zai-framework
```

## 🚀 Quick Start

```python
import zai
from zai.models import IGRIS_1M
from zai.tokenizer import load_pretrained

# Load tokenizer
tokenizer = load_pretrained('zai_bpe_10k')

# Create model
model = IGRIS_1M(vocab_size=tokenizer.get_vocab_size())

# Your code here...
```

## 📊 Models Available

- **IGRIS_1M**: 5.66M parameters, efficient for CPU training

## 📄 License

MIT License

## 👨‍💻 Author

Created by Akik Faraji

**Built with ❤️ and AI assistance**
