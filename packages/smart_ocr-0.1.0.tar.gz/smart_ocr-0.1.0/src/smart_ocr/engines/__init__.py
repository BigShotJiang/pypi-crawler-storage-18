"""OCR engine adapters."""

from smart_ocr.engines.base import BaseEngine, EngineCapabilities
from smart_ocr.engines.deepseek import DeepSeekEngine
from smart_ocr.engines.gemini import GeminiEngine
from smart_ocr.engines.mistral import MistralEngine
from smart_ocr.engines.nougat import NougatEngine

__all__ = [
    "BaseEngine",
    "EngineCapabilities",
    "NougatEngine",
    "DeepSeekEngine",
    "MistralEngine",
    "GeminiEngine",
]
