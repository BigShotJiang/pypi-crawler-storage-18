"""Entry point for running documentation-search-enhanced as a module."""

from .main import main

if __name__ == "__main__":
    main()
