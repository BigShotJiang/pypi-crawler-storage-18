"""Plan state calculations and lookup operations."""


def recalculate_progress(plan: dict) -> None:
    """Recalculate all progress fields."""
    total_tasks = 0
    completed_tasks = 0

    for phase in plan.get("phases", []):
        tasks = phase.get("tasks", [])
        phase_total = len(tasks)
        phase_completed = sum(1 for t in tasks if t["status"] == "completed")

        phase["progress"] = {
            "completed": phase_completed,
            "total": phase_total,
            "percentage": (phase_completed / phase_total * 100) if phase_total > 0 else 0,
        }

        # Update phase status based on tasks
        if phase_completed == phase_total and phase_total > 0:
            phase["status"] = "completed"
        elif any(t["status"] == "in_progress" for t in tasks) or phase_completed > 0:
            phase["status"] = "in_progress"

        total_tasks += phase_total
        completed_tasks += phase_completed

    plan["summary"] = {
        "total_phases": len(plan.get("phases", [])),
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "overall_progress": (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0,
    }


def get_current_phase(plan: dict) -> dict | None:
    """Find the current in_progress or first pending phase."""
    for phase in plan.get("phases", []):
        if phase["status"] == "in_progress":
            return phase
    for phase in plan.get("phases", []):
        if phase["status"] == "pending":
            return phase
    return None


def get_next_task(plan: dict) -> tuple[dict, dict] | None:
    """Find the next actionable task with all dependencies met."""
    for phase in plan.get("phases", []):
        if phase["status"] in ("completed", "skipped"):
            continue
        for task in phase.get("tasks", []):
            if task["status"] == "in_progress":
                return phase, task
            if task["status"] == "pending":
                deps = task.get("depends_on", [])
                all_deps_met = True
                for dep in deps:
                    for p in plan.get("phases", []):
                        for t in p.get("tasks", []):
                            if t["id"] == dep and t["status"] != "completed":
                                all_deps_met = False
                                break
                if all_deps_met:
                    return phase, task
    return None


def find_task(plan: dict, task_id: str) -> tuple[dict, dict] | None:
    """Find a task by ID, return (phase, task) or None."""
    for phase in plan.get("phases", []):
        for task in phase.get("tasks", []):
            if task["id"] == task_id:
                return phase, task
    return None


def find_phase(plan: dict, phase_id: str) -> dict | None:
    """Find a phase by ID."""
    for phase in plan.get("phases", []):
        if phase["id"] == phase_id:
            return phase
    return None


def task_to_dict(phase: dict, task: dict) -> dict:
    """Convert a task to a JSON-serializable dict."""
    return {
        "id": task["id"],
        "title": task["title"],
        "status": task["status"],
        "phase_id": phase["id"],
        "phase_name": phase["name"],
        "agent_type": task.get("agent_type"),
        "depends_on": task.get("depends_on", []),
        "tracking": task.get("tracking", {}),
    }
