class MetricsConstants:
    METRICS_METER_NAME = "XRL_GATEWAY_CONFIG"

    SANDBOX_REQUEST_TOTAL = "request.total"
    SANDBOX_REQUEST_SUCCESS = "request.success"
    SANDBOX_REQUEST_FAILURE = "request.failure"

    SANDBOX_REQUEST_RT = "request.rt"

    SANDBOX_TOTAL_COUNT = "sandbox.count.total"
    SANDBOX_COUNT_IMAGE = "sandbox.count.image"

    SANDBOX_CPU = "system.cpu"
    SANDBOX_MEM = "system.memory"
    SANDBOX_DISK = "system.disk"
    SANDBOX_NET = "system.network"
