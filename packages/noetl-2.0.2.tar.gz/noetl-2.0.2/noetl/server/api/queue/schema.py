"""Queue schemas removed."""
