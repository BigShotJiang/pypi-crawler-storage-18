"""
Internal Django webhook handlers for PayTechUZ.
"""
from .payme import PaymeWebhook
from .click import ClickWebhook
from .atmos import AtmosWebhook
from .uzum import UzumWebhook
from .paynet import PaynetWebhook

__all__ = [
    'PaymeWebhook',
    'ClickWebhook',
    'AtmosWebhook',
    'UzumWebhook',
    'PaynetWebhook'
]
