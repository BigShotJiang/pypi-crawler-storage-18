# dv-api-metrics
- Python code to collect metrics from datasets in [Dataverse](https://dataverse.org/) collections.
- Used primarily to support the CAFE project.
- Note: This library will become obsolete when the Dataverse Hub supports more metrics including dataset download metrics. 

## Objectives
- **Track collection change over time**. Collection change could include tracking unique depositors and datasets created. 
- **Track dataset engagement over time**. Dataset engagement could include tracking dataset and file download counts, as well as dataset citations (where possible). 

## Desired Metrics
- Number of datasets created per month
- Number of collections per month
- Number of dataset downloads per month
- Dataset keyword frequency per month
- Number of (unique) depositors per month
- Number of file downloads per month per dataset
- Make Data Count (MDC) metrics
    - Number of Make Data Count unique downloads per month
    - Number of Make Data Count unique views per dataset
    - Number of Make Data Count citations per dataset
- Total number of harvested datasets
- Number of datasets per subject
- Number of datasets per Geographic Coverage Country / Nation
- Number of datasets per keyword term (available via the UI facets, so should be in search API)

## Additional Metrics
- Number of harvested dataset engagements (Note: not available via APIs)

## Desired Formats
Open questions:
- Are reports preferred to raw data outputs?
    - Raw data (e.g., outputs from API queries)
    - Reports (e.g., summaries of API query output)
## Technical Limitations
- Metrics will be collected using existing Dataverse Metrics API endpoints or Native API endpoints.
- Make Data Count metrics range from 2020-09 to the present.
