"""HFS Worker 命令行入口"""
import argparse
import os


def main():
    parser = argparse.ArgumentParser(description='HFS Worker')
    parser.add_argument('--redis-url', required=True, help='Redis URL')
    parser.add_argument('--space-id', required=True, help='Space ID')
    parser.add_argument('--project-id', help='Project ID')
    parser.add_argument('--node-id', help='Node ID')
    args = parser.parse_args()
    
    # 设置环境变量（兼容现有代码）
    os.environ['HFS_REDIS_URL'] = args.redis_url
    os.environ['HFS_SPACE_ID'] = args.space_id
    if args.project_id:
        os.environ['HFS_PROJECT_ID'] = args.project_id
    if args.node_id:
        os.environ['HFS_NODE_ID'] = args.node_id
    
    from .worker import Worker
    
    worker = Worker(
        redis_url=args.redis_url,
        space_id=args.space_id,
        project_id=args.project_id,
        node_id=args.node_id,
    )
    worker.run()


if __name__ == '__main__':
    main()
