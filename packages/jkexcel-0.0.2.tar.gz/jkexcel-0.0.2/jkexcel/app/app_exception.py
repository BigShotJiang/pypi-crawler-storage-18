class ExecutionFaultedException(Exception):
    pass
