"""Test package for Bingomatic."""
