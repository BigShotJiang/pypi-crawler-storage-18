# TorMadeEasy: Share Files with Friends and Family!

Have you ever wanted to send a large file to a friend or family member, but it was too big for email? Or maybe you wanted to share a folder of vacation photos without having to upload it to a cloud service first?

**TorMadeEasy** is here to help! It's a simple tool that turns your computer into your own personal file-sharing station. You can share files of any size, directly from your computer, with anyone you want.

## How it Works (the simple version)

1.  You choose a file on your computer to share.
2.  `tormadeeasy` gives you a special "magnet link" for that file.
3.  You send that magnet link to your friend or family member.
4.  They can use that link with a torrent client to download the file directly from you!

It's fast, private, and there are no file size limits.

## Quick Start Guide for Friends and Family

Here's how to get started with `tormadeeasy`:

### Step 1: Install `tormadeeasy`

You'll need to have Python and `pip` installed on your computer. Then, open a terminal (on Mac or Linux) or a command prompt (on Windows) and type:

```bash
pip install tormadeeasy
```

### Step 2: Set up `ngrok` (a one-time thing)

The first time you share a file, `tormadeeasy` will ask you for something called an "ngrok authtoken". This is a special key that helps create a secure connection from your computer to your friend's computer.

1.  Go to [ngrok.com](https://ngrok.com) and sign up for a free account.
2.  On your ngrok dashboard, you'll find your authtoken. Copy it.
3.  When `tormadeeasy` asks for the token, just paste it in and press Enter. You'll only have to do this once!

### Step 3: Share a File!

To share a file, use the `up` command. For example, if you have a file called `vacation_photos.zip` on your desktop, you would type:

```bash
tormadeeasy up /path/to/your/vacation_photos.zip
```

(Make sure to replace `/path/to/your/vacation_photos.zip` with the actual path to your file!)

`tormadeeasy` will then give you a magnet link. It will look something like this:

```
magnet:?xt=urn:btih:a1b2c3d4...
```

**This is the link you share with your friends and family!** Your computer is now "seeding" the file, which means it's ready to be downloaded.

### Step 4: Downloading a File

If a friend sends you a magnet link from `tormadeeasy`, you can use the `down` command to download it:

```bash
tormadeeasy down "magnet:?xt=urn:btih:a1b2c3d4..."
```

The file will be downloaded to a `downloads` folder in your current directory.

### Other Useful Commands

*   **`tormadeeasy progress`**: Check the progress of your downloads.
*   **`tormadeeasy stop`**: When you're all done sharing and downloading, use this command to stop the `tormadeeasy` services.

## Having Trouble?

*   **Can't download your own file?** You can't download a file that you are currently sharing from the same computer. This is to prevent the tool from getting confused!
*   **Invalid magnet link?** If you use a magnet link that's not correct, `tormadeeasy` will let you know.

---

We hope you enjoy using `tormadeeasy` to share files with your loved ones!
