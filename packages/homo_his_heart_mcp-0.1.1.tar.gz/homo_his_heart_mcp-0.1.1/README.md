# Time Server MCP

A time server tool built with FastMCP that provides current time information.

## Features

- Get current time in any timezone
- Simple and easy-to-use API
- Built with FastMCP for efficient communication

## Installation

```bash
pip install time-server-mcp
```

## Usage

### Running the Server

```bash
python -m time_server
```

### Using the Tool

The server provides a `get_current_time` tool that can be called with an optional timezone parameter.

Example usage:

```python
from mcp.client import MCPClient

# Connect to the server
client = MCPClient()

# Get current time in system default timezone
result = client.call("get_current_time")
print(result)

# Get current time in a specific timezone
result = client.call("get_current_time", timezone="Asia/Shanghai")
print(result)
```

## API

### `get_current_time(timezone: Optional[str] = None) -> str`

Gets the current time.

**Parameters:**
- `timezone`: Optional timezone string, e.g., "Asia/Shanghai", "America/New_York". If not provided, system default timezone is used.

**Returns:**
- Formatted current time string in the format: `YYYY-MM-DD HH:MM:SS.SSSSSS TIMEZONE`

## License

MIT
