# udf-tools

`udf-tools` is a comprehensive Python library and command-line interface (CLI) for handling UYAP UDF (National Judiciary Network Project Document Format) files. It allows you to create, edit, and convert UDF documents with ease.

## Features
- **Create & Edit**: Build UDF documents from scratch using a modern Python API.
- **DOCX to UDF**: Convert standard World (.docx) documents to UDF format.
- **Offset Management**: Handles the complex internal XML structure and offset-based text referencing of UDF files automatically.
- **CLI Support**: Easy-to-use command-line interface for batch conversions.
- **Rich Output**: Enhanced terminal experience with progress indicators.

## Installation
```bash
pip install udf-tools
```

## Usage

### As a Library
```python
from udf_tools.editor import UDFEditor
from udf_tools.models.styles import UDFStyle

# Initialize editor
editor = UDFEditor()

# Add custom styles
editor.add_style(UDFStyle(name="Header", size=16.0, bold=True))

# Add content
editor.add_paragraph("TÜRKİYE CUMHURİYETİ", alignment=1)
editor.add_paragraph("MAHKEME KARARI", style="Header", alignment=1)
editor.add_paragraph("Bu belge otomatik olarak oluşturulmuştur.")

# Save as .udf
editor.save("output_document.udf")
```

### As a CLI
```bash
# Convert DOCX to UDF
udf-tools convert input.docx output.udf

# Show help
udf-tools --help
```

## Technical Details
UDF is a ZIP-based format containing a `content.xml` file. The core of the document is a single CDATA block of text, where various elements (paragraphs, tables, styles) reference the text using `startOffset` and `length`. `udf-tools` manages these offsets for you, so you can focus on building your document.

## License
MIT
