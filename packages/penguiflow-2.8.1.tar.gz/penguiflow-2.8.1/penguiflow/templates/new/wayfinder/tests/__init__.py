"""Tests for wayfinder template."""
