"""Tests configuration"""
