<div align='center'>

<a><img src='https://raw.githubusercontent.com/jiyun233/nonebot_plugin_nearcade_reporter/master/favicon.png' width='200px' height='200px' akt='nearcade'></a>

[![python3](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-apache-blue.svg)](https://opensource.org/license/apache-2-0)

<h1>Nearcade Reporter</h1>

</div>

一个接入 [Nearcade](https://nearcade.phizone.cn/) 支持 正则命名分组 与 多机厅别名配置 查询 / 更新街机厅当前人数 的 NoneBot2 插件

## 🚀 使用示例

### 查询人数：
```text
秋叶原几人
akiba几人
```

### 更新人数：
```text
机厅人数 秋叶原 12
机厅人数 ikebukuro 30
```

### 搜索机厅:
```text
查找机厅 keywrod
```

**搜索机厅只有SUPERUSERS可用**

## ⚙️ 配置方式

### 查询人数
```toml
QUERY_ATTENDANCE_MATCH='{
  "enabled": true,
  "pattern": "^(?P<arcade>\\\\S+)几人$",
  "reply_message": "{arcade} 当前人数: {count}"
}'
```

### 更新人数正则
```toml
UPDATE_ATTENDANCE_MATCH='{
  "enabled": true,
  "pattern": "^机厅人数\\\\s*(?P<arcade>\\\\S+)\\\\s*(?P<count>(?:100|[1-9]\\\\d?|0))$",
  "reply_message": "更新成功，{arcade} 当前人数: {count}"
}'
```

### 机厅配置
```toml
ARCADES='{
  "1001": {
    "arcade_source": "bemani",
    "aliases": ["秋叶原", "akiba"],
    "default_game_id": 1001
  }
}'
```
**请先使用搜索机厅获取机厅ID与机台GameID**


### ⚠️ 注意事项

正则表达式中必须给机厅别名分组命名 **arcade** 人数命名 **count**

环境变量中的 JSON 必须是合法 JSON

正则中的反斜杠需要 双重转义（例如 \\S、\\s、\\d）
