"""Version information for OpenDraft."""

__version__ = "1.6.3"
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())
