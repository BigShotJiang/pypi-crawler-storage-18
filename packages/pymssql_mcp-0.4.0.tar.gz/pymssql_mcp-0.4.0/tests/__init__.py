"""Tests for mssql-mcp."""
