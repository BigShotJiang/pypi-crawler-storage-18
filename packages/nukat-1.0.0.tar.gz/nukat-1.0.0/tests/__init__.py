"""Tests for nukat."""
