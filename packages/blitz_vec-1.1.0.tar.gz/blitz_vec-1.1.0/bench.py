import asyncio
import numpy as np
import time
import random
import logging
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor
from bv_engine import VectorExp

# --- CONFIGURATION ---
TOTAL_VECTORS = 2_000_000
DIMENSION = 768
BATCH_SIZE = 5_000
CONCURRENT_WORKERS = 2  # Number of threads
LOG_FILE = "benchmark_metrics.log"

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler()]
)

class LocalBenchmark:
    def __init__(self):
        self.db = VectorExp(
            shards=CONCURRENT_WORKERS,
            max_size_gb=100,
            delete_batch_size=50  # Optimize for high-throughput mixed workloads
        )
        self.results = {}
        self.executor = ThreadPoolExecutor(max_workers=CONCURRENT_WORKERS)

    def generate_batch(self, size, offset=0):
        vectors = np.random.rand(size, DIMENSION).astype(np.float32).tolist()
        metadatas = [
            {
                "category": random.choice(["electronics", "books", "clothing", "home"]),
                "price": random.uniform(10, 1000),
                "timestamp": time.time(),
                "indexed_at": offset + i
            }
            for i in range(size)
        ]
        return vectors, metadatas

    async def run_in_thread(self, func, *args):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self.executor, func, *args)

    # --- SCENARIOS ---

    async def scenario_1_bulk_index(self):
        logging.info("SCENARIO 1: Bulk Indexing (Direct Access)")
        start_time = time.perf_counter()
        pbar = tqdm(total=TOTAL_VECTORS, desc="Ingesting", unit="vec")
        
        for i in range(0, TOTAL_VECTORS, BATCH_SIZE):
            vecs, metas = self.generate_batch(BATCH_SIZE, i)
            await self.run_in_thread(self.db.store_embeddings_batch, vecs, metas)
            pbar.update(len(vecs))
            
        pbar.close()
        total_time = time.perf_counter() - start_time
        vps = TOTAL_VECTORS / total_time
        logging.info(f"Complete. VPS: {vps:.2f}")
        self.results["Bulk Indexing (VPS)"] = vps

    async def scenario_2_index_while_search(self):
        logging.info("SCENARIO 2: Search Throughput during Indexing")
        duration = 30
        search_count = 0
        start_time = time.perf_counter()

        async def search_worker():
            nonlocal search_count
            while time.perf_counter() - start_time < duration:
                v = np.random.rand(DIMENSION).tolist()
                await self.run_in_thread(self.db.search, v, None, 5)
                search_count += 1

        async def index_worker():
            while time.perf_counter() - start_time < duration:
                vecs, metas = self.generate_batch(100)
                await self.run_in_thread(self.db.store_embeddings_batch, vecs, metas)

        # Run MORE searchers to stress test concurrency
        workers = [search_worker() for _ in range(6)] + [index_worker() for _ in range(2)]
        await asyncio.gather(*workers)
        
        qps = search_count / duration
        logging.info(f"Complete. Search QPS under load: {qps:.2f}")
        self.results["Search QPS (under Load)"] = qps

    async def scenario_3_filtered_search(self):
        logging.info("SCENARIO 3: Deterministic Filtered Search")
        filters = [
            (None, "No Filter"),
            ({"category": "electronics"}, "Equality (25%)"),
            ({"price": {"$lt": 100}}, "Range Filter"),
            ({"$and": [{"category": "clothing"}, {"price": {"$gt": 500}}]}, "Complex AND")
        ]
        
        qps_results = []
        for filt, label in filters:
            requests = 200
            start_time = time.perf_counter()
            
            tasks = [self.run_in_thread(self.db.search, np.random.rand(DIMENSION).tolist(), filt, 5) 
                    for _ in range(requests)]
            await asyncio.gather(*tasks)
            
            elapsed = time.perf_counter() - start_time
            qps = requests / elapsed
            qps_results.append(qps)
            print(f" - {label}: {qps:.2f} QPS")

        self.results["Search QPS (Filtered)"] = np.mean(qps_results)

    async def scenario_4_mixed_load(self):
        logging.info("SCENARIO 4: Mixed Search/Insert/Delete Load")
        duration = 30
        ops = [0]
        start_time = time.perf_counter()

        async def worker():
            while time.perf_counter() - start_time < duration:
                choice = random.random()
                if choice < 0.7:  # More searches
                    await self.run_in_thread(self.db.search, np.random.rand(DIMENSION).tolist(), {"category": "books"}, 5)
                elif choice < 0.95:  # Some inserts
                    vecs, metas = self.generate_batch(10)
                    await self.run_in_thread(self.db.store_embeddings_batch, vecs, metas)
                else:  # Rare deletes
                    await self.run_in_thread(self.db.delete, {"price": {"$lt": 15}})
                ops[0] += 1

        # More workers to stress test
        await asyncio.gather(*[worker() for _ in range(CONCURRENT_WORKERS * 2)])
        
        # Flush any pending deletes
        await self.run_in_thread(self.db.flush_deletes)
        
        total_qps = ops[0] / duration
        logging.info(f"Complete. Mixed Load Operations/sec: {total_qps:.2f}")
        self.results["Mixed Load QPS"] = total_qps

    async def scenario_5_pure_read_concurrency(self):
        """NEW: Test pure concurrent read performance"""
        logging.info("SCENARIO 5: Pure Concurrent Read Performance")
        duration = 10
        search_count = 0
        start_time = time.perf_counter()

        async def search_worker():
            nonlocal search_count
            while time.perf_counter() - start_time < duration:
                v = np.random.rand(DIMENSION).tolist()
                # Mix of filtered and unfiltered
                filt = {"category": random.choice(["electronics", "books"])} if random.random() < 0.5 else None
                await self.run_in_thread(self.db.search, v, filt, 5)
                search_count += 1

        # Many concurrent readers
        workers = [search_worker() for _ in range(CONCURRENT_WORKERS * 3)]
        await asyncio.gather(*workers)
        
        qps = search_count / duration
        logging.info(f"Complete. Pure Read QPS: {qps:.2f}")
        self.results["Pure Read QPS"] = qps

    async def run_all(self):
        await self.scenario_1_bulk_index()
        await self.scenario_5_pure_read_concurrency()
        await self.scenario_2_index_while_search()
        await self.scenario_3_filtered_search()
        await self.scenario_4_mixed_load()
        
        print("\n" + "="*60)
        print("BENCHMARK RESULTS SUMMARY")
        print("="*60)
        for metric, value in self.results.items():
            print(f"{metric:.<45} {value:>10.2f}")
        print("="*60)
        
        self.executor.shutdown()

if __name__ == "__main__":
    benchmark = LocalBenchmark()
    asyncio.run(benchmark.run_all())