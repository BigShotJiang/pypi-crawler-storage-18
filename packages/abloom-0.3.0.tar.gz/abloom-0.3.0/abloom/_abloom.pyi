from typing import Iterable

class BloomFilter:
    """High-performance Split Block Bloom Filter.

    A space-efficient probabilistic data structure that tests whether an element
    is a member of a set. False positive matches are possible, but false negatives
    are not. This implementation uses the Split Block Bloom Filter (SBBF) algorithm
    with 512-bit blocks for optimal performance.

    Args:
        capacity: Expected number of items to be inserted. Must be greater than 0.
        fp_rate: Target false positive rate. Must be between 0.0 and 1.0 (exclusive).
                Default is 0.01 (1%).

    Raises:
        ValueError: If capacity is 0 or fp_rate is not in the valid range.

    Example:
        >>> bf = BloomFilter(capacity=10000, fp_rate=0.01)
        >>> bf.add("example")
        >>> "example" in bf
        True
        >>> "not_added" in bf
        False
    """

    capacity: int
    """Expected number of items that can be inserted."""

    fp_rate: float
    """Target false positive rate (between 0.0 and 1.0)."""

    k: int
    """Number of hash functions used (always 8 for SBBF)."""

    byte_count: int
    """Total number of bytes in the filter."""

    bit_count: int
    """Total number of bits in the filter."""

    def __init__(self, capacity: int, fp_rate: float = 0.01) -> None:
        """Initialize a new Bloom filter.

        Args:
            capacity: Expected number of items to be inserted. Must be greater than 0.
            fp_rate: Target false positive rate. Must be between 0.0 and 1.0 (exclusive).
                    Default is 0.01 (1%).

        Raises:
            ValueError: If capacity is 0 or fp_rate is not in the valid range.
        """
        ...

    def add(self, item: object) -> None:
        """Add an item to the bloom filter.

        Args:
            item: Any hashable Python object to add to the filter.

        Raises:
            TypeError: If the item is not hashable.
        """
        ...

    def update(self, items: Iterable[object]) -> None:
        """Add items from an iterable to the bloom filter.

        Args:
            items: An iterable of hashable Python objects to add to the filter.

        Raises:
            TypeError: If any item is not hashable or items is not iterable.
        """
        ...

    def __contains__(self, item: object) -> bool:
        """Test if an item might be in the bloom filter.

        Args:
            item: Any hashable Python object to test for membership.

        Returns:
            True if the item might be in the filter (possible false positive).
            False if the item is definitely not in the filter (no false negatives).

        Raises:
            TypeError: If the item is not hashable.
        """
        ...

    def __eq__(self, other: object) -> bool:
        """Test equality with another BloomFilter.

        Two BloomFilters are equal if they have the same capacity, fp_rate,
        and identical bit patterns.

        Args:
            other: Another object to compare with.

        Returns:
            True if both filters have the same parameters and bit content.
        """
        ...

    def __ne__(self, other: object) -> bool:
        """Test inequality with another BloomFilter.

        Args:
            other: Another object to compare with.

        Returns:
            True if filters differ in parameters or bit content.
        """
        ...

    def __bool__(self) -> bool:
        """Test if the filter is non-empty.

        Returns:
            True if any bits are set in the filter (items may have been added).
            False if the filter is empty (no bits set).
        """
        ...

    def __or__(self, other: BloomFilter) -> BloomFilter:
        """Return the union of two BloomFilters.

        Both filters must have the same capacity and fp_rate.

        Args:
            other: Another BloomFilter with matching parameters.

        Returns:
            A new BloomFilter containing all items from both filters.

        Raises:
            ValueError: If capacity or fp_rate differ between filters.
        """
        ...

    def __ior__(self, other: BloomFilter) -> BloomFilter:
        """Update this BloomFilter with the union of itself and another.

        Both filters must have the same capacity and fp_rate.

        Args:
            other: Another BloomFilter with matching parameters.

        Returns:
            This BloomFilter (modified in place).

        Raises:
            ValueError: If capacity or fp_rate differ between filters.
        """
        ...

    def copy(self) -> BloomFilter:
        """Return a shallow copy of the bloom filter.

        Returns:
            A new BloomFilter with the same parameters and bit content.
        """
        ...

    def clear(self) -> None:
        """Remove all items from the bloom filter.

        Resets the filter to its initial empty state while preserving
        capacity and fp_rate settings.
        """
        ...
