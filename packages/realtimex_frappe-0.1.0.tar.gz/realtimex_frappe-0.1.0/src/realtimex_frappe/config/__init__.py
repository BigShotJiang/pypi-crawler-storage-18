"""Configuration models and utilities."""
