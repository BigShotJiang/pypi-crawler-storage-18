import sys

import pybFoam
from pybFoam import (
    Time,
    Word,
    adjustPhi,
    constrainHbyA,
    constrainPressure,
    createPhi,
    fvc,
    fvm,
    fvMesh,
    fvScalarMatrix,
    fvVectorMatrix,
    pisoControl,
    solve,
    surfaceScalarField,
    volScalarField,
    volVectorField,
)


def create_fields(mesh):
    p = volScalarField.read_field(mesh, "p")
    U = volVectorField.read_field(mesh, "U")
    phi = createPhi(U)
    nu = volScalarField.read_field(mesh, "nu")  # Assumes viscosity is read like a field
    return p, U, phi, nu


def main(argv):
    argList = pybFoam.argList(argv)
    runTime = Time(argList)
    mesh = fvMesh(runTime)

    p, U, phi, nu = create_fields(mesh)

    # Optional: pressure reference
    pRefCell = 0
    pRefValue = 0.0

    piso = pisoControl(mesh)

    while runTime.loop():
        print(f"Time = {runTime.timeName()}")

        # Courant number computation assumed handled elsewhere
        # (optionally bind and call selectCourantNo)

        UEqn = fvVectorMatrix(fvm.ddt(U) + fvm.div(phi, U) - fvm.laplacian(nu, U))

        if piso.momentumPredictor():
            solve(UEqn + fvc.grad(p))

        while piso.correct():
            rAU = volScalarField(Word("rAU"), 1.0 / UEqn.A())
            HbyA = volVectorField(constrainHbyA(rAU * UEqn.H(), U, p))

            phiHbyA = surfaceScalarField(
                Word("phiHbyA"),
                fvc.flux(HbyA) + fvc.interpolate(rAU) * fvc.ddtCorr(U, phi),
            )

            adjustPhi(phiHbyA, U, p)
            constrainPressure(p, U, phiHbyA, rAU)

            while piso.correctNonOrthogonal():
                pEqn = fvScalarMatrix(fvm.laplacian(rAU, p) - fvc.div(phiHbyA))
                pEqn.setReference(pRefCell, pRefValue, False)
                pEqn.solve(p.select(piso.finalInnerIter()))

                if piso.finalNonOrthogonalIter():
                    phi.assign(phiHbyA - pEqn.flux())

            print("corrected p")
            # Optionally include continuityErrs()
            U.assign(HbyA - rAU * fvc.grad(p))
            U.correctBoundaryConditions()

        runTime.write(True)
        runTime.printExecutionTime()

    print("End")


if __name__ == "__main__":
    main(sys.argv)
