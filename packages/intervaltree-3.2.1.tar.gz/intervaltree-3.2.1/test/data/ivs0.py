"""
Empty IntervalTree data.
"""
data = []
