# Recipes SDK

Python SDK for working with recipes from JSON files.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```python
from recipes_sdk import RecipesSDK
import json

# Create SDK instance
sdk = RecipesSDK(language="en")  # or "ru"

# Random recipe
recipe_json = sdk.get_random_recipe()
recipe = json.loads(recipe_json)

# With allergens and calories filtering
recipe_json = sdk.get_random_recipe(
    user_allergens=["nuts", "gluten"], 
    max_calories=300
)
recipe = json.loads(recipe_json)

# Get all recipes by category
breakfast_json = sdk.get_recipes_by_category("breakfast")
breakfast_recipes = json.loads(breakfast_json)

# Get random recipe from category
random_breakfast_json = sdk.get_random_recipe_by_category("breakfast")
random_breakfast = json.loads(random_breakfast_json)
```

## API

- `get_random_recipe(user_allergens=None, max_calories=None)` - random recipe from all categories (returns JSON string)
- `get_recipes_by_category(category, user_allergens=None, max_calories=None)` - all recipes from category (returns JSON string)
- `get_random_recipe_by_category(category, user_allergens=None, max_calories=None)` - random recipe from category (returns JSON string)
- `get_all_categories()` - list of available categories (returns JSON string)
- `get_all_recipes(user_allergens=None, max_calories=None)` - all recipes from all categories (returns JSON string)

All methods support filtering by allergens and calories.

## Categories

- `breakfast` - breakfast recipes (loaded from breakfast_1.json, breakfast_2.json, breakfast_3.json, breakfast_4.json)
- `lunch` - lunch recipes (loaded from lunch.json, lunch_1.json)
- `dinner` - dinner recipes (loaded from dinner.json, dinner_1.json)
- `snack` - snack recipes (loaded from snack.json)

SDK automatically loads all available files for each category.

## Recipe Format

Each recipe contains:
- `id` - unique identifier
- `name` - object with `ru` and `en` fields
- `calories`, `protein`, `fat`, `carbs` - nutritional information
- `total_g` - total weight in grams
- `recipe` - cooking instructions with `ru` and `en` fields
- `allergens` - list of allergens with `ru` and `en` fields
- `is_pp` - boolean flag
- `prep_time` - preparation time with `ru` and `en` fields
- `ingredients_details` - detailed ingredients list with `ru` and `en` fields
- `tips` - cooking tips with `ru` and `en` fields