BRANCH = "├─ "
LAST   = "└─ "
VERT   = "│  "
SPACE  = "   "