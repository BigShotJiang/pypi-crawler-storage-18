# kind + FreeLens on a VM (GHCR)

This guide documents a VM-friendly workflow for running PyPNM on kind and managing it in FreeLens. The model below assumes **one PyPNM service per CMTS**, with multiple namespaces living on a single VM/cluster.

## Prerequisites

- VM with Docker installed and running.
- `curl` and `sudo` available.
- Network access to GHCR (`ghcr.io/mgarcia01752/pypnm`).

## Install kubectl + kind

Use the bootstrap helper for Debian/Ubuntu-style hosts (no repo clone required):

```bash
curl -fsSL https://raw.githubusercontent.com/mgarcia01752/PyPNM/main/tools/k8s/pypnm_kind_vm_bootstrap.sh \
  -o /tmp/pypnm_kind_vm_bootstrap.sh
bash /tmp/pypnm_kind_vm_bootstrap.sh
```

## Create the cluster and deploy from GHCR

Pick a release tag, then deploy into a namespace (one namespace per CMTS). This script pulls manifests from GitHub, so no repo clone is required:

```bash
TAG="v0.9.62.0"
NAMESPACE="pypnm-cmts-a"

curl -fsSL https://raw.githubusercontent.com/mgarcia01752/PyPNM/main/tools/k8s/pypnm_k8s_remote_deploy.sh \
  -o /tmp/pypnm_k8s_remote_deploy.sh
bash /tmp/pypnm_k8s_remote_deploy.sh --create --tag "${TAG}" --namespace "${NAMESPACE}" --replicas 1
```

Health check:

```bash
kubectl port-forward --namespace "${NAMESPACE}" deploy/pypnm-api 8000:8000
curl -i http://127.0.0.1:8000/health
```

## Connect with FreeLens

1. Add the kubeconfig from the VM to FreeLens.
   - If FreeLens runs on the VM, it can use `~/.kube/config` directly.
   - If FreeLens runs on your workstation, copy the kubeconfig or use an SSH tunnel.
2. Select the target namespace (for example, `pypnm-cmts-a`).
3. Use FreeLens port-forwarding on the `pypnm-api` Service/Pod to reach port 8000.

Tip: keep one FreeLens workspace per CMTS namespace so it is easy to keep sessions isolated.

## One VM, multiple CMTS (one PyPNM per CMTS)

Deploy a PyPNM instance per CMTS by assigning a unique namespace and configuration per CMTS:

```bash
TAG="v0.9.62.0"

for CMTS in cmts-a cmts-b cmts-c; do
  NAMESPACE="pypnm-${CMTS}"
  bash /tmp/pypnm_k8s_remote_deploy.sh --create --tag "${TAG}" --namespace "${NAMESPACE}" --replicas 1
done
```

### CMTS-specific config

Each instance should point at exactly one CMTS. Use a per-namespace config patch and apply it as described in [PyPNM on Kubernetes (kind)](pypnm-deploy.md) ("Config overrides" section). Keep the CMTS routing and retrieval settings unique per namespace.

## Teardown

```bash
NAMESPACE="pypnm-cmts-a"

bash /tmp/pypnm_k8s_remote_deploy.sh --teardown --namespace "${NAMESPACE}"
```

To delete the cluster after all namespaces are removed:

```bash
kind delete cluster --name pypnm-dev
```
