from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Union, Any

# --- HELPER MODELS (Legacy) ---


class FilterCondition(BaseModel):
    col: str
    op: str
    val: Any


class AggDef(BaseModel):
    col: str
    op: str
    alias: str = ""


class CastChange(BaseModel):
    col: str
    action: str

# --- EXISTING LEGACY PARAMS (Restored) ---


class SelectColsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)


class DropColsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)


class RenameColParams(BaseModel):
    old: str = ""
    new: str = ""


class KeepColsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)


class AddColParams(BaseModel):
    name: str = ""
    expr: str = "1"


class CleanCastParams(BaseModel):
    changes: List[CastChange] = Field(default_factory=list)


class FilterRowsParams(BaseModel):
    logic: Literal["AND", "OR"] = "AND"
    conditions: List[FilterCondition] = Field(default_factory=list)


class SortRowsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)
    desc: bool = False


class DeduplicateParams(BaseModel):
    subset: List[str] = Field(default_factory=list)


class SampleParams(BaseModel):
    method: Literal["Fraction", "N"] = "Fraction"
    val: float = 0.1


class JoinDatasetParams(BaseModel):
    alias: str = ""
    how: Literal["inner", "left", "outer", "cross", "semi", "anti"] = "left"
    left_on: List[str] = Field(default_factory=list)
    right_on: List[str] = Field(default_factory=list)


class AggregateParams(BaseModel):
    keys: List[str] = Field(default_factory=list)
    aggs: List[AggDef] = Field(default_factory=list)


class WindowFuncParams(BaseModel):
    target: str = ""
    name: str = ""
    op: str = "sum"
    over: List[str] = Field(default_factory=list)
    sort: List[str] = Field(default_factory=list)


class ReshapeParams(BaseModel):
    mode: Literal["Pivot", "Unpivot"] = "Pivot"
    # Pivot
    idx: List[str] = Field(default_factory=list)
    col: str = ""
    val: str = ""
    agg: str = "first"
    # Unpivot
    id_vars: List[str] = Field(default_factory=list)
    val_vars: List[str] = Field(default_factory=list)


# --- PHASE 1 ENTERPRISE PARAMS (New) ---

class FillNullsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)
    strategy: Literal["forward", "backward", "mean",
                      "median", "min", "max", "zero", "literal"] = "forward"
    literal_val: Optional[Union[str, float, int]] = None


class RegexExtractParams(BaseModel):
    col: str = ""
    pattern: str = ""
    alias: str = ""


class TimeBinParams(BaseModel):
    col: str = ""
    interval: str = "1h"


class RollingAggParams(BaseModel):
    target: str = ""
    window_size: int = 3
    op: Literal["mean", "sum", "min", "max", "std"] = "mean"
    center: bool = False


class NumericBinParams(BaseModel):
    col: str = ""
    bins: int = 5
    labels: Optional[List[str]] = None


class StringCaseParams(BaseModel):
    col: str = ""
    case: Literal["upper", "lower", "title", "trim"] = "upper"
    alias: str = ""


class StringReplaceParams(BaseModel):
    col: str = ""
    pat: str = ""
    val: str = ""
    alias: str = ""


class MathOpParams(BaseModel):
    col: str = ""
    op: Literal["round", "abs", "ceil", "floor", "sqrt"] = "round"
    precision: int = 2
    alias: str = ""


class DateExtractParams(BaseModel):
    col: str = ""
    part: Literal["year", "month", "day", "hour", "minute",
                  "second", "weekday", "minute", "second"] = "year"
    alias: str = ""


# --- PHASE 2 ENTERPRISE PARAMS (New) ---

class DropNullsParams(BaseModel):
    cols: List[str] = Field(default_factory=list)
    how: Literal["any", "all"] = "any"


class TextSliceParams(BaseModel):
    col: str = ""
    start: int = 0
    length: Optional[int] = None
    alias: str = ""


class TextLengthParams(BaseModel):
    col: str = ""
    alias: str = ""


class CumulativeParams(BaseModel):
    col: str = ""
    op: Literal["cumsum", "cummin", "cummax", "cumprod"] = "cumsum"
    alias: str = ""
    reverse: bool = False


class RankParams(BaseModel):
    col: str = ""
    method: Literal["average", "min", "max",
                    "dense", "ordinal", "random"] = "dense"
    descending: bool = False
    alias: str = ""


class DiffParams(BaseModel):
    col: str = ""
    method: Literal["diff", "pct_change"] = "diff"
    n: int = 1
    alias: str = ""


class MathSciParams(BaseModel):
    col: str = ""
    op: Literal["log", "log10", "exp", "pow", "sqrt", "cbrt", "mod"] = "log"
    arg: float = 2.0


class ClipParams(BaseModel):
    col: str = ""
    min_val: Optional[float] = None
    max_val: Optional[float] = None


class DateOffsetParams(BaseModel):
    col: str = ""
    offset: str = "1d"
    action: Literal["add", "sub"] = "add"


class DateDiffParams(BaseModel):
    start_col: str = ""
    end_col: str = ""
    unit: Literal["days", "hours", "minutes",
                  "seconds", "milliseconds"] = "days"
    alias: str = ""
