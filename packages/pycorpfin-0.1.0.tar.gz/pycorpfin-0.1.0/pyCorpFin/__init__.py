# pycorpfin/__init__.py
"""pyCorpFin - Corporate Finance Calculations Library"""

__version__ = "0.1.0"

from .core import (
    presentValue,
    futureValue,
    annuity,
    emi,
    IRR,
    calculate_mirr,
    calculate_xirr
)

__all__ = [
    'presentValue',
    'futureValue',
    'annuity',
    'emi',
    'IRR',
    'calculate_mirr',
    'calculate_xirr'
]