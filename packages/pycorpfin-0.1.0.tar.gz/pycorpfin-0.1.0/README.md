# pyCorpFin

A Python library for corporate finance calculations with built-in AI agent integration for LangChain, LangGraph, and other agentic frameworks.

## Features

- **Core Finance Functions**: NPV, IRR, MIRR, XIRR, EMI calculations
- **AI Agent Ready**: Pre-built tools for LangChain and LangGraph
- **Zero Dependencies**: Core library works without external packages
- **Pure Python**: No compiled extensions required

## Installation

### Basic Installation
```bash
pip install pyCorpFin
```

### With LangChain Support
```bash
pip install pyCorpFin[langchain]
```

### With LangGraph Support
```bash
pip install pyCorpFin[langgraph]
```

### With All AI Features
```bash
pip install pyCorpFin[all]
```

## Quick Start

### Direct Usage
```python
from pyCorpFin import IRR, calculate_xirr
from datetime import datetime

# Calculate IRR
cashflows = [-1000, 300, 400, 500]
irr = IRR(cashflows)
print(f"IRR: {irr:.2%}")

# Calculate XIRR
dates = [datetime(2023, 1, 1), datetime(2023, 6, 1), 
         datetime(2023, 12, 1), datetime(2024, 6, 1)]
xirr = calculate_xirr(cashflows, dates)
print(f"XIRR: {xirr:.2%}")
```

### With LangChain
```python
from pyCorpFin.tools import get_langchain_tools
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

# Get finance tools
tools = get_langchain_tools()

# Create agent
llm = ChatOpenAI(temperature=0)
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Use the agent
result = agent.run(
    "Calculate the IRR for an investment of $10,000 that returns "
    "$3,000 per year for 4 years"
)
```

### With LangGraph
```python
from langgraph.prebuilt import create_react_agent
from pyCorpFin.tools import get_langchain_tools
from langchain_openai import ChatOpenAI

tools = get_langchain_tools()
model = ChatOpenAI(model="gpt-4")

agent = create_react_agent(model, tools)

response = agent.invoke({
    "messages": [("user", "What's the EMI on a $100,000 loan at 8% for 20 years?")]
})
```

## API Reference

### Core Functions

- `IRR(cashflows, guess=0.1)` - Internal Rate of Return
- `calculate_mirr(cashflows, finance_rate, reinvest_rate)` - Modified IRR
- `calculate_xirr(cashflows, dates, guess=0.1)` - Extended IRR
- `presentValue(cf, r, n)` - Present Value
- `futureValue(cf, r, n)` - Future Value
- `emi(PV, r, n)` - Equated Monthly Installment

## License

MIT License