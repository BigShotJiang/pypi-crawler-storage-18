# tests/test_core.py
import pytest
from pyCorpFin import IRR, calculate_mirr, emi
from datetime import datetime

def test_irr():
    cashflows = [-1000, 300, 400, 500]
    result = IRR(cashflows)
    assert isinstance(result, float)
    assert 0.05 < result < 0.20

def test_emi():
    result = emi(100000, 0.08/12, 240)
    assert 800 < result < 900

def test_mirr():
    cashflows = [-1000, 300, 400, 500]
    result = calculate_mirr(cashflows, 0.10, 0.08)
    assert isinstance(result, float)