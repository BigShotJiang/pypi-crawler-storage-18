# dataset-split-jin18


A reversible, state-aware dataset splitter for machine learning experiments.
