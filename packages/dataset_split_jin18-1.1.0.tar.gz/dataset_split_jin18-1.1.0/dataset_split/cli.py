import random
import shutil
import json
import argparse
from pathlib import Path

DEFAULT_MANIFEST = "split_manifest.json"


# ============================================================
# Utilities
# ============================================================

def remove_empty_dirs_and_root(root: Path):
    """
    Remove all empty subdirectories under root,
    and remove root itself if it becomes empty.
    """
    if not root.exists():
        return

    # Remove subdirectories first (deep to shallow)
    for sub in sorted(root.rglob("*"), reverse=True):
        if sub.is_dir():
            try:
                sub.rmdir()  # only removes empty dirs
            except OSError:
                pass

    # Remove root if empty
    try:
        root.rmdir()
    except OSError:
        pass


# ============================================================
# Core logic
# ============================================================

def split_dataset(
    src_root,
    infer_root,
    val_root,
    infer_per_class,
    val_per_class,
    seed,
    copy_mode,
    manifest_path,
    force=False,
):
    src_root = Path(src_root)
    infer_root = Path(infer_root)
    val_root = Path(val_root)

    if manifest_path.exists() and not force:
        raise RuntimeError(
            f"Manifest already exists: {manifest_path}\n"
            "Refusing to split again to avoid data corruption.\n"
            "Use --force if you know what you are doing."
        )

    random.seed(seed)
    manifest = {}

    classes = sorted([d for d in src_root.iterdir() if d.is_dir()])

    for cls_dir in classes:
        cls = cls_dir.name
        files = [f for f in cls_dir.iterdir() if f.is_file()]

        need = infer_per_class + val_per_class
        if len(files) < need:
            raise RuntimeError(f"{cls}: has {len(files)} files, need >= {need}")

        random.shuffle(files)
        infer_files = files[:infer_per_class]
        val_files = files[infer_per_class : infer_per_class + val_per_class]

        infer_dir = infer_root / cls
        val_dir = val_root / cls
        infer_dir.mkdir(parents=True, exist_ok=True)
        val_dir.mkdir(parents=True, exist_ok=True)

        manifest[cls] = {
            "infer": [f.name for f in infer_files],
            "val": [f.name for f in val_files],
        }

        for f in infer_files:
            dst = infer_dir / f.name
            shutil.copy2(f, dst) if copy_mode else shutil.move(f, dst)

        for f in val_files:
            dst = val_dir / f.name
            shutil.copy2(f, dst) if copy_mode else shutil.move(f, dst)

        print(f"[OK] {cls}: infer={len(infer_files)}, val={len(val_files)}")

    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    print(f"\n[SUCCESS] Split complete. Manifest saved to {manifest_path}")


def restore_dataset(
    src_root,
    infer_root,
    val_root,
    manifest_path,
    force=False,
):
    src_root = Path(src_root)
    infer_root = Path(infer_root)
    val_root = Path(val_root)

    if not manifest_path.exists():
        raise RuntimeError("Manifest not found, cannot restore.")

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    missing = []

    for cls, groups in manifest.items():
        for name in groups.get("infer", []):
            if not (infer_root / cls / name).exists():
                missing.append(f"infer/{cls}/{name}")
        for name in groups.get("val", []):
            if not (val_root / cls / name).exists():
                missing.append(f"val/{cls}/{name}")

    if missing and not force:
        raise RuntimeError(
            f"Missing files detected ({len(missing)}).\n"
            "Restore is not safe.\n"
            "Use --force to continue anyway."
        )

    for cls, groups in manifest.items():
        src_dir = src_root / cls
        src_dir.mkdir(parents=True, exist_ok=True)

        for name in groups.get("infer", []):
            src = infer_root / cls / name
            if src.exists():
                shutil.move(src, src_dir / name)
            else:
                print(f"[WARN] Missing infer file, skipped: {src}")

        for name in groups.get("val", []):
            src = val_root / cls / name
            if src.exists():
                shutil.move(src, src_dir / name)
            else:
                print(f"[WARN] Missing val file, skipped: {src}")

        print(f"[RESTORED] {cls}")

    # v1.1 cleanup: remove empty workdirs AND their roots
    remove_empty_dirs_and_root(infer_root)
    remove_empty_dirs_and_root(val_root)

    # remove manifest
    manifest_path.unlink()
    print("[CLEANUP] Manifest removed, work directories fully cleaned")

    print("\n[SUCCESS] Dataset restored (CLEAN state)")


def status_dataset(
    src_root,
    infer_root,
    val_root,
    manifest_path,
    json_output=False,
):
    src_root = Path(src_root)
    infer_root = Path(infer_root)
    val_root = Path(val_root)

    manifest_exists = manifest_path.exists()
    infer_files = [f for f in infer_root.rglob("*") if f.is_file()] if infer_root.exists() else []
    val_files = [f for f in val_root.rglob("*") if f.is_file()] if val_root.exists() else []

    state = "UNKNOWN"
    missing = []
    next_action = None

    if not manifest_exists:
        if not infer_files and not val_files:
            state = "CLEAN"
            next_action = "split"
        else:
            state = "DIRTY"
            next_action = "manual cleanup"
    else:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)

        for cls, groups in manifest.items():
            for name in groups.get("infer", []):
                if not (infer_root / cls / name).exists():
                    missing.append(f"infer/{cls}/{name}")
            for name in groups.get("val", []):
                if not (val_root / cls / name).exists():
                    missing.append(f"val/{cls}/{name}")

        if missing:
            state = "DIRTY"
            next_action = "manual cleanup"
        else:
            state = "SPLIT_APPLIED"
            next_action = "restore"

    result = {
        "state": state,
        "infer_files": len(infer_files),
        "val_files": len(val_files),
        "manifest": str(manifest_path) if manifest_exists else None,
        "missing_files": missing,
        "next_action": next_action,
    }

    if json_output:
        print(json.dumps(result, indent=2))
        return

    print(f"[STATUS] {state}")
    print(f"- Manifest: {'exists' if manifest_exists else 'not found'}")
    print(f"- infer files: {len(infer_files)}")
    print(f"- val files: {len(val_files)}")

    if missing:
        print(f"- Missing files: {len(missing)}")
        print("- Restore is NOT safe")

    print(f"- Next allowed action: {next_action}")


# ============================================================
# CLI
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="dataset-split v1.1 — reversible dataset splitter (clean restore)"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # split
    p_split = sub.add_parser("split", help="Split dataset into infer/val")
    p_split.add_argument("--src", required=True)
    p_split.add_argument("--infer", required=True)
    p_split.add_argument("--val", required=True)
    p_split.add_argument("--infer-per-class", type=int, default=5)
    p_split.add_argument("--val-per-class", type=int, default=10)
    p_split.add_argument("--seed", type=int, default=42)
    p_split.add_argument("--copy", action="store_true", help="Copy instead of move")
    p_split.add_argument("--force", action="store_true", help="Force operation")
    p_split.add_argument("--manifest", default=DEFAULT_MANIFEST)

    # restore
    p_restore = sub.add_parser("restore", help="Restore dataset and fully cleanup")
    p_restore.add_argument("--src", required=True)
    p_restore.add_argument("--infer", required=True)
    p_restore.add_argument("--val", required=True)
    p_restore.add_argument("--force", action="store_true")
    p_restore.add_argument("--manifest", default=DEFAULT_MANIFEST)

    # status
    p_status = sub.add_parser("status", help="Show dataset status")
    p_status.add_argument("--src", required=True)
    p_status.add_argument("--infer", required=True)
    p_status.add_argument("--val", required=True)
    p_status.add_argument("--manifest", default=DEFAULT_MANIFEST)
    p_status.add_argument("--json", action="store_true")

    args = parser.parse_args()
    manifest_path = Path(args.manifest)

    if args.command == "split":
        split_dataset(
            args.src,
            args.infer,
            args.val,
            args.infer_per_class,
            args.val_per_class,
            args.seed,
            args.copy,
            manifest_path,
            force=args.force,
        )
    elif args.command == "restore":
        restore_dataset(
            args.src,
            args.infer,
            args.val,
            manifest_path,
            force=args.force,
        )
    elif args.command == "status":
        status_dataset(
            args.src,
            args.infer,
            args.val,
            manifest_path,
            json_output=args.json,
        )


if __name__ == "__main__":
    main()
