"""DuckDice API Python Wrapper"""
from .api import DuckDiceAPI, DuckDiceAPIException, DuckDiceConfig

__version__ = "1.0.4"
__all__ = ["DuckDiceAPI", "DuckDiceAPIException", "DuckDiceConfig"]
