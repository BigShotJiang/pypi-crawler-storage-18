from __future__ import annotations

import asyncio
import os
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from enum import Enum, auto, unique
from functools import reduce
from typing import Self

import attrs


@attrs.define(frozen=True)
class _BaseStream(ABC):
    seq: Iterable = attrs.field(validator=attrs.validators.instance_of(Iterable), repr=False)
    ops: tuple = attrs.field(default=(), validator=attrs.validators.instance_of(tuple), repr=False)

    @classmethod
    @abstractmethod
    def from_iterable(cls, it: Iterable) -> Self: ...

    @abstractmethod
    def map[T, U](self, *fns: Callable[[T], U]) -> Self: ...

    @abstractmethod
    def filter[T](self, *fns: Callable[[T], bool]) -> Self: ...

    @abstractmethod
    def partition[T](self, fn: Callable[[T], bool]) -> tuple[Self, Self]: ...

    @abstractmethod
    def fold[T, U](
        self, initial: T, fn: Callable[[T], U], *, workers: int = 1, use_threads: bool = False
    ) -> U: ...

    @abstractmethod
    def collect(self) -> tuple: ...

    @abstractmethod
    def par_collect(self, workers: int = 4, *, use_threads: bool = False) -> tuple: ...

    @abstractmethod
    async def async_collect(self) -> tuple: ...


@attrs.define(frozen=True)
class Stream(_BaseStream):
    """An immutable lazy iterator with functional operations.

    #### Why bother?
    Readability counts, abstracting common operations helps reduce cognitive complexity when reading code.

    #### Comparison
    Take this imperative pipeline of operations, it iterates once over the data, skipping the value if it fails one of the filter checks:

    ```python
    >>> res = []
    ...
    >>> for x in range(1_000_000):
    ...     item = triple(x)
    ...
    ...     if not is_gt_ten(item):
    ...         continue
    ...
    ...     item = min_two(item)
    ...
    ...     if not is_even_num(item):
    ...         continue
    ...
    ...     item = square(item)
    ...
    ...     if not is_lt_400(item):
    ...         continue
    ...
    ...     res.append(item)
    >>> [100, 256]
    ```
    number of tokens: `90`

    number of keywords: `11`

    keyword breakdown: `{'for': 1, 'in': 1, 'if': 3, 'not': 3, 'continue': 3}`

    After a bit of experience with python you might use list comprehensions, however this is arguably _less_ clear and iterates multiple times over the same data
    ```python
    >>> mul_three = [triple(x) for x in range(1_000_000)]
    >>> gt_ten = [x for x in mul_three if is_gt_ten(x)]
    >>> sub_two = [min_two(x) for x in gt_ten]
    >>> is_even = [x for x in sub_two if is_even_num(x)]
    >>> squared = [square(x) for x in is_even]
    >>> lt_400 = [x for x in squared if is_lt_400(x)]
    >>> [100, 256]
    ```
    number of tokens: `92`

    number of keywords: `15`

    keyword breakdown: `{'for': 6, 'in': 6, 'if': 3}`

    This still has a lot of tokens that the developer has to read to understand the code. The extra keywords add noise that cloud the actual transformations.

    Using a `Stream` results in this:
    ```python
    >>> (
    ...     Stream.from_iterable(range(1_000_000))
    ...     .map(triple)
    ...     .filter(is_gt_ten)
    ...     .map(min_two)
    ...     .filter(is_even_num)
    ...     .map(square)
    ...     .filter(is_lt_400)
    ...     .collect()
    ... )
    >>> (100, 256)
    ```
    number of tokens: `60`

    number of keywords: `0`

    keyword breakdown: `{}`

    The business logic is arguably much clearer like this.
    """

    @classmethod
    def from_iterable(cls, it: Iterable) -> Self:
        """This is the recommended way of creating a `Stream` object.

        ```python
        >>> Stream.from_iterable([0, 1, 2, 3]).collect() == (0, 1, 2, 3)
        ```
        """
        if not isinstance(it, Iterable):
            it = [it]
        return cls(seq=iter(it))

    def map[T, U](self, *fns: Callable[[T], U]) -> Self:
        """Map a function to the elements in the `Stream`. Will return a new `Stream` with the modified sequence.

        ```python
        >>> Stream.from_iterable([0, 1, 2, 3]).map(add_one).collect() == (1, 2, 3, 4)
        ```

        This can also be mixed with `safe` functions:
        ```python
        >>> Stream.from_iterable([0, 1, 2, 3]).map(add_one).collect() == (Ok(inner=1), Ok(inner=2), Ok(inner=3), Ok(inner=4))

        >>> @safe
        ... def two_div_value(x: float) -> float:
        ...     return 2 / x

        >>> Stream.from_iterable([0, 1, 2, 4]).map(two_div_value).collect() == (Err(error=ZeroDivisionError('division by zero')), Ok(inner=2.0), Ok(inner=1.0), Ok(inner=0.5))
        ```

        Simple functions can be passed in sequence to compose more complex transformations
        ```python
        >>> Stream.from_iterable(range(5)).map(mul_two, add_one).collect() == (1, 3, 5, 7, 9)
        ```
        """
        plan = (*self.ops, *tuple((_OpType.MAP, fn) for fn in fns))
        return Stream(seq=self.seq, ops=plan)

    def filter[T](self, *fns: Callable[[T], bool]) -> Self:
        """Filter the stream based on a predicate. Will return a new `Stream` with the modified sequence.

        ```python
        >>> Stream.from_iterable([0, 1, 2, 3]).filter(lambda x: x % 2 == 0).collect() == (0, 2)
        ```

        Simple functions can be passed in sequence to compose more complex filters
        ```python
        >>> Stream.from_iterable(range(20)).filter(divisible_by_3, divisible_by_5).collect() == (0, 15)
        ```
        """
        plan = (*self.ops, *tuple((_OpType.FILTER, fn) for fn in fns))
        return Stream(seq=self.seq, ops=plan)

    def partition[T](
        self, fn: Callable[[T], bool], *, workers: int = 1, use_threads: bool = False
    ) -> tuple[Self, Self]:
        """Similar to `filter` except splits the True and False values. Will return a two new `Stream` with the partitioned sequences.

        Each partition is independently replayable.
        ```python
        >>> part1, part2 = Stream.from_iterable([0, 1, 2, 3]).partition(lambda x: x % 2 == 0)
        >>> part1.collect() == (0, 2)
        >>> part2.collect() == (1, 3)
        ```

        As `partition` triggers an action, the parameters will be forwarded to the `par_collect` call if the `workers` are greater than 1.
        ```python
        >>> Stream.from_iterable(range(10)).map(add_one, add_one).partition(divisible_by_3, workers=4)
        >>> part1.map(add_one).par_collect() == (4, 7, 10)
        >>> part2.collect() == (2, 4, 5, 7, 8, 10, 11)
        ```
        """
        # have to materialise to be able to replay each side independently
        if workers > 1:
            seq_tuple = self.par_collect(workers=workers, use_threads=use_threads)
        else:
            seq_tuple = self.collect()
        return (
            Stream(seq=(x for x in seq_tuple if fn(x))),
            Stream(seq=(x for x in seq_tuple if not fn(x))),
        )

    def fold[T, U](
        self, initial: T, fn: Callable[[T], U], *, workers: int = 1, use_threads: bool = False
    ) -> U:
        """Fold the results into a single value. `fold` triggers an action so will incur a `collect`.

        ```python
        >>> Stream.from_iterable([1, 2, 3, 4]).fold(0, lambda a, b: a + b) == 10
        >>> Stream.from_iterable([[1], [2], [3], [4]]).fold([0], lambda a, b: a + b) == [0, 1, 2, 3, 4]
        >>> Stream.from_iterable([1, 2, 3, 4]).fold(1, lambda a, b: a * b) == 24
        ```

        As `fold` triggers an action, the parameters will be forwarded to the `par_collect` call if the `workers` are greater than 1.
        This will only effect the `collect` that is used to create the iterable to reduce, not the `fold` operation itself.
        ```python
        >>> Stream.from_iterable([1, 2, 3, 4]).map(some_expensive_fn).fold(0, add, workers=4, use_threads=False)
        ```
        """
        if workers > 1:
            return reduce(fn, self.par_collect(workers=workers, use_threads=use_threads), initial)
        return reduce(fn, self.collect(), initial)

    def collect(self) -> tuple:
        """Materialise the sequence from the `Stream`.

        ```python
        >>> stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
        >>> stream.collect() == (1, 2, 3, 4)
        ```
        """
        return tuple(
            elem for x in self.seq if (elem := _apply_fns(x, self.ops)) != _Nothing.NOTHING
        )

    def par_collect(self, workers: int = 4, *, use_threads: bool = False) -> tuple:
        """Materialise the sequence from the `Stream` in parallel.

        ```python
        >>> stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
        >>> stream.par_collect() == (1, 2, 3, 4)
        ```

        Use the `workers` arg to select the number of workers to use. Use `-1` to use all available processors (except 1).
        Defaults to `4`.
        ```python
        >>> stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
        >>> stream.par_collect(workers=-1) == (1, 2, 3, 4)
        ```

        For smaller I/O bound tasks use the `use_threads` flag as True.
        If False the processing will use `ProcessPoolExecutor` else it will use `ThreadPoolExecutor`.
        ```python
        >>> stream = Stream.from_iterable([0, 1, 2, 3]).map(add_one)
        >>> stream.par_collect(use_threads=True) == (1, 2, 3, 4)
        ```

        Note that all operations should be pickle-able, for that reason `Stream` does not support lambdas or closures.
        """
        if workers == -1:
            workers = (os.cpu_count() - 1) or 4

        executor_cls = ThreadPoolExecutor if use_threads else ProcessPoolExecutor

        with executor_cls(max_workers=workers) as ex:
            res = tuple(ex.map(_apply_fns_worker, ((x, self.ops) for x in self.seq)))

        return tuple(elem for elem in res if elem != _Nothing.NOTHING)

    async def async_collect(self) -> tuple:
        """Async version of collect. Note that all functions in the stream should be `Awaitable`.

        ```python
        >>> Stream.from_iterable(file_paths).map(async_read_files).async_collect()
        ```

        If there are no operations in the `Stream` then this will act as a normal collect.

        ```python
        >>> Stream.from_iterable(file_paths).async_collect()
        ```
        """
        if not self.ops:
            return self.collect()

        res = await asyncio.gather(*(_async_apply_fns(x, self.ops) for x in self.seq))
        return tuple(elem for elem in res if elem != _Nothing.NOTHING)


@unique
class _OpType(Enum):
    MAP = auto()
    FILTER = auto()


class _Nothing(Enum):
    NOTHING = auto()


def _apply_fns_worker[T, U](args: tuple[T, tuple[tuple[_OpType, Callable], ...]]) -> U | None:
    elem, ops = args
    return _apply_fns(elem, ops)


def _apply_fns[T, U](elem: T, ops: tuple[tuple[_OpType, Callable], ...]) -> U | None:
    res = elem
    for op, op_fn in ops:
        if op == _OpType.MAP:
            res = op_fn(res)
        elif op == _OpType.FILTER and not op_fn(res):
            return _Nothing.NOTHING
    return res


async def _async_apply_fns[T, U](elem: T, ops: tuple[tuple[_OpType, Callable], ...]) -> U | None:
    res = elem
    for op, op_fn in ops:
        if op == _OpType.MAP:
            res = await op_fn(res)
        elif op == _OpType.FILTER and not await op_fn(res):
            return _Nothing.NOTHING
    return res
