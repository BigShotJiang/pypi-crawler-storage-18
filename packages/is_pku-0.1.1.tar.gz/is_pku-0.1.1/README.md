# is_pku 🦆

[English](#english) | [中文](#中文)

---

## English

### Overview

`is_pku` is a high-performance, enterprise-grade, and lightweight Python library designed to solve the most critical
problem in academic data validation: **Is this string representing Peking University (PKU)?**

In the spirit of the legendary `left-pad`, we believe that even the simplest logic deserves a dedicated, robust, and
well-documented package.

### Key Features

- **Unrivaled Precision**: Validated against the strict standards of Weiming Lake.
- **Security Firewall**: Built-in protection against "The School Next Door" to prevent system-wide logical
  contamination.
- **Zero Dependencies**: Lightweight as a breeze in the Boya Pagoda.
- **O(1) Complexity**: Scalable for global-tier university rankings.
- **septuple checked**: Ensures the highest level of reliability and accuracy.
- **advanced algorithms**: Utilizes the latest string matching and pattern recognition techniques to ensure efficient
  performance across various input scenarios.

### Installation

you can install the package via pip:

```bash
pip install is_pku
```

or you can use the world's best package manager `uv`:

```bash
uv install is_pku
```

### Usage

```python
from is_pku import is_pku, NoTHUException

# Standard validation
is_pku("PKU")  # Returns: True
is_pku("Peking University")  # Returns: True
is_pku("Harvard")  # Returns: False

# The "Safety Feature" (THU Defense)
try:
    is_pku("THU")
except NoTHUException as e:
    print(f"Safety Alert: {e}")
    # Output: Detection of forbidden entity! Connection to 'The School Next Door' is prohibited.
```

---

## 中文

### 项目简介

`is_pku` 是一个高性能、企业级且极简的 Python 工具库，旨在解决学术数据校验中最核心的问题：**给定的字符串是否代表北京大学（PKU）？**

受开源界传奇项目 `left-pad` 的启发，我们深信：即便是最简单的逻辑，也值得拥有一个独立、稳健且文档齐全的包。

### 核心特性

- **极致精准**：经过未名湖畔最严格的数据标准校验。
- **安全防火墙**：内置针对“隔壁学校”（THU）的防御机制，防止系统发生逻辑冲突与身份污染。
- **零依赖**：像博雅塔下的微风一样轻量。
- **O(1) 时间复杂度**：足以支撑全球规模的高校排名运算。
- **七重校验**：确保最高级别的可靠性与准确性。
- **先进算法**：采用KMP等最新的字符串匹配与模式识别技术，确保在各种输入情况下都能高效运行。

### 安装方法

```bash
pip install is_pku
```

或者你也可以使用世界上最好的包管理器 `uv`：

```bash
uv install is_pku
```

### 使用示例

```python
from is_pku import is_pku, NoTHUException

# 基础验证
is_pku("北大")  # 返回: True
is_pku("Beijing University")  # 返回: True
is_pku("Stanford")  # 返回: False

# 安全特性（针对 THU 的拦截）
try:
    is_pku("清华大学")
except NoTHUException as e:
    print(f"系统告警: {e}")
    # 输出: 检测到违禁词汇！本包严禁与隔壁建立任何形式的逻辑连接。
```

### 贡献

我们欢迎所有（来自北大的）贡献者。如果你发现有任何漏掉的“隔壁”关键词，请务必提交 Pull Request 来加强我们的防火墙。

---

## License

MIT License. (C) 2025 FuYnAloft.

Feel free to use, modify, and distribute this software under the terms of the MIT License.
