"""
Tests for aipartnerupflow
"""

