# fin-insight-extract
[![PyPI version](https://badge.fury.io/py/fin-insight-extract.svg)](https://badge.fury.io/py/fin-insight-extract)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/fin-insight-extract)](https://pepy.tech/project/fin-insight-extract)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


## Overview

A new package that extracts and structures key business and financial insights from news articles or reports. The package takes unstructured text input, such as news headlines or summaries, and uses llmatch-messages to parse and extract specific details like company names, financial figures, market impacts, and strategic moves. It returns a structured output that includes the key entities involved, the nature of the announcement, potential market implications, and any notable figures or metrics mentioned.

## Installation

Installation can be done via pip:

```bash
pip install fin_insight_extract
```

## Usage

Extract financial and business insights from unstructured text:

```python
from fin_insight_extract import fin_insight_extract

user_input = "The company has announced a 20% increase in revenue for the quarter"
response = fin_insight_extract(user_input=user_input)

print(response)
```

## Parameters

* `user_input`: The unstructured text to process. (`str`)
* `llm`: A LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used. (`Optional[BaseChatModel]`)
* `api_key`: The API key for LLM7. If not provided, the default `ChatLLM7` will be used. If provided, it will also be used for the default `ChatLLM7`. (`Optional[str]`)

## Using Custom LLMs

You can safely pass your own LLM instance (based on <https://docs(langchain.io)>) if you want to use another LLM. For example, to use OpenAI:

```python
from langchain_openai import ChatOpenAI
from fin_insight_extract import fin_insight_extract

llm = ChatOpenAI()
response = fin_insight_extract(user_input="The company has announced a 20% increase in revenue for the quarter", llm=llm)
print(response)
```

Similarly, you can use Anthropics:

```python
from langchain_anthropic import ChatAnthropic
from fin_insight_extract import fin_insight_extract

llm = ChatAnthropic()
response = fin_insight_extract(user_input="The company has announced a 20% increase in revenue for the quarter", llm=llm)
print(response)
```

or Google:

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from fin_insight_extract import fin_insight_extract

llm = ChatGoogleGenerativeAI()
response = fin_insight_extract(user_input="The company has announced a 20% increase in revenue for the quarter", llm=llm)
print(response)
```

## Rate Limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you need higher rate limits, you can pass your own API key via environment variable `LLM7_API_KEY` or directly:

```python
from fin_insight_extract import fin_insight_extract

response = fin_insight_extract(user_input="The company has announced a 20% increase in revenue for the quarter", api_key="your_api_key")
print(response)
```

Get a free API key at <https://token.llm7.io/>

## Contributing

Report issues at: <https://github.com/chigwell/fin-insight-extract>

## Author

authored by Eugene Evstafev (<hi@eugevstfev.plus>)