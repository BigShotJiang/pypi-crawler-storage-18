"""MuukTest Repair MCP Server - Analyze and repair E2E test failures."""

__version__ = "0.1.1"

from .server import main

__all__ = ["main"]
