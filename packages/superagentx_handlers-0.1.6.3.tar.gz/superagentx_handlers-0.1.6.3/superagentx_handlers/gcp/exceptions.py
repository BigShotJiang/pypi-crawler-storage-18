class AuthException(Exception):
    pass
