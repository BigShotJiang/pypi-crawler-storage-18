__all__ =   [
                "SteamShortcutManager"
            ]