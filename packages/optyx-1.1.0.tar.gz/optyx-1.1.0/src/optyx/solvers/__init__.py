"""SciPy solver integration."""
