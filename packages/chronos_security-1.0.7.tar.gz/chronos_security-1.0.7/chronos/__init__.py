"""
CHRONOS - Unified Quantum Security Platform
============================================

A comprehensive quantum security platform for present and future threats.
Provides quantum-resistant cryptography, threat detection, and security analysis.
"""

__version__ = "1.0.6"
__author__ = "CHRONOS Team"
__description__ = "Unified quantum security platform for present and future threats"

from chronos.core import *
