"""
Feature 2.2: Quantum Readiness Score
====================================

Generates a credit-score-like number (0-1000) measuring organizational
readiness for quantum computing threats. Includes benchmarking against
industry standards and improvement roadmaps.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta


class ReadinessGrade(Enum):
    """Letter grades for readiness scores"""
    A_PLUS = ("A+", 850, 1000, "Excellent - Industry Leader")
    A = ("A", 750, 849, "Very Good")
    B = ("B", 650, 749, "Good - Above Average")
    C = ("C", 550, 649, "Acceptable - Average")
    D = ("D", 450, 549, "Poor - Below Average")
    F = ("F", 0, 449, "Critical - Immediate Action Required")
    
    @classmethod
    def get_grade_for_score(cls, score: float) -> "ReadinessGrade":
        """Get grade for a given score"""
        for grade in cls:
            if grade.value[1] <= score <= grade.value[2]:
                return grade
        return cls.F


@dataclass
class CryptoInventoryScore:
    """Scoring component: Cryptographic Inventory (400 points max)"""
    has_complete_inventory: bool = False
    documented_key_sizes: bool = False
    identified_vulnerable_systems: bool = False
    prioritized_by_sensitivity: bool = False
    inventory_updated_within_90_days: bool = False
    includes_cloud_services: bool = False
    includes_third_party_apis: bool = False
    documented_in_sbom: bool = False
    
    def calculate_score(self) -> float:
        """Calculate score (max 400 points)"""
        score = 0.0
        
        # Core requirements: 100 points each
        if self.has_complete_inventory:
            score += 100
        if self.documented_key_sizes:
            score += 100
        if self.identified_vulnerable_systems:
            score += 100
        if self.prioritized_by_sensitivity:
            score += 100
        
        # Maintenance: 100 points
        if self.inventory_updated_within_90_days:
            score += 100
        
        # Completeness bonuses: 50 points each
        if self.includes_cloud_services:
            score += 50
        if self.includes_third_party_apis:
            score += 50
        
        # Format bonus: 100 points
        if self.documented_in_sbom:
            score += 100
        
        return min(score, 400)


@dataclass
class MigrationProgressScore:
    """Scoring component: Migration Progress (250 points max)"""
    total_vulnerable_systems: int = 100
    systems_migrated: int = 0
    systems_in_progress: int = 0
    has_migration_roadmap: bool = False
    tested_pqc_in_dev: bool = False
    hybrid_mode_implemented: bool = False
    
    def calculate_score(self) -> float:
        """Calculate score (max 250 points)"""
        if self.total_vulnerable_systems == 0:
            return 0.0
        
        # Base score: percentage of completion
        completion_rate = self.systems_migrated / self.total_vulnerable_systems
        base_score = completion_rate * 250
        
        # Bonuses
        bonus = 0.0
        if self.has_migration_roadmap:
            bonus += 50
        if self.tested_pqc_in_dev:
            bonus += 30
        if self.hybrid_mode_implemented:
            bonus += 40
        
        total = base_score + bonus
        return min(total, 250)


@dataclass
class ThreatDetectionScore:
    """Scoring component: Threat Detection Capability (150 points max)"""
    has_network_monitoring: bool = False
    has_hndl_detection: bool = False
    has_darkweb_monitoring: bool = False
    has_anomaly_detection: bool = False
    active_realtime_monitoring: bool = False
    
    def calculate_score(self) -> float:
        """Calculate score (max 150 points)"""
        score = 0.0
        
        if self.has_network_monitoring:
            score += 50
        if self.has_hndl_detection:
            score += 50
        if self.has_darkweb_monitoring:
            score += 30
        if self.has_anomaly_detection:
            score += 20
        
        # Active monitoring bonus: 50 points
        if self.active_realtime_monitoring:
            score += 50
        
        return min(score, 150)


@dataclass
class ComplianceGovernanceScore:
    """Scoring component: Compliance & Governance (100 points max)"""
    pqc_policy_documented: bool = False
    board_awareness: bool = False
    budget_allocated: bool = False
    meets_nist_guidelines: bool = False
    regular_audits_scheduled: bool = False
    
    def calculate_score(self) -> float:
        """Calculate score (max 100 points)"""
        score = 0.0
        
        if self.pqc_policy_documented:
            score += 25
        if self.board_awareness:
            score += 25
        if self.budget_allocated:
            score += 25
        if self.meets_nist_guidelines:
            score += 25
        if self.regular_audits_scheduled:
            score += 50
        
        return min(score, 100)


@dataclass
class TeamReadinessScore:
    """Scoring component: Team Readiness (100 points max)"""
    employees_trained: int = 0
    training_hours_per_employee: float = 0.0
    dedicated_quantum_team: bool = False
    external_consultants_engaged: bool = False
    
    def calculate_score(self) -> float:
        """Calculate score (max 100 points)"""
        score = 0.0
        
        # Training tiering
        if self.employees_trained >= 51:
            score += 100
        elif self.employees_trained >= 21:
            score += 60
        elif self.employees_trained >= 6:
            score += 40
        elif self.employees_trained >= 1:
            score += 20
        
        # Team structure bonuses
        if self.dedicated_quantum_team:
            score += 25
        if self.external_consultants_engaged:
            score += 15
        
        return min(score, 100)


@dataclass
class IndustryBenchmark:
    """Industry-specific benchmark data"""
    industry: str
    average_score: float
    percentile_50: float
    percentile_75: float
    percentile_90: float
    
    def get_benchmark_rank(self, score: float) -> str:
        """Get benchmark rank for a score"""
        if score >= self.percentile_90:
            return "Top 10%"
        elif score >= self.percentile_75:
            return "Top 25%"
        elif score >= self.percentile_50:
            return "Top 50%"
        else:
            return "Below Average"


class IndustryBenchmarks:
    """Pre-calculated industry benchmarks"""
    
    BENCHMARKS = {
        "healthcare": IndustryBenchmark("Healthcare", 520, 480, 600, 720),
        "financial": IndustryBenchmark("Financial", 680, 640, 750, 850),
        "technology": IndustryBenchmark("Technology", 710, 670, 780, 880),
        "government": IndustryBenchmark("Government", 650, 610, 720, 820),
        "retail": IndustryBenchmark("Retail", 450, 410, 520, 650),
        "manufacturing": IndustryBenchmark("Manufacturing", 420, 380, 490, 620),
        "general": IndustryBenchmark("General", 500, 460, 580, 700),
    }
    
    @classmethod
    def get_benchmark(cls, industry: str) -> IndustryBenchmark:
        """Get benchmark for industry"""
        return cls.BENCHMARKS.get(industry.lower(), cls.BENCHMARKS["general"])


@dataclass
class ImprovementMilestone:
    """Improvement roadmap milestone"""
    days_to_achieve: int
    title: str
    improvements: List[Tuple[str, float]]  # (description, points_gained)
    total_points: float = 0.0
    
    def __post_init__(self):
        self.total_points = sum(points for _, points in self.improvements)


@dataclass
class QuantumReadinessScore:
    """Complete quantum readiness assessment"""
    timestamp: datetime = field(default_factory=datetime.now)
    organization_name: str = ""
    industry: str = "general"
    
    # Scoring components
    inventory: CryptoInventoryScore = field(default_factory=CryptoInventoryScore)
    migration: MigrationProgressScore = field(default_factory=MigrationProgressScore)
    detection: ThreatDetectionScore = field(default_factory=ThreatDetectionScore)
    compliance: ComplianceGovernanceScore = field(default_factory=ComplianceGovernanceScore)
    team: TeamReadinessScore = field(default_factory=TeamReadinessScore)
    
    # Calculated values
    total_score: float = 0.0
    grade: Optional[ReadinessGrade] = None
    percentile: float = 0.0
    
    def calculate_score(self) -> float:
        """Calculate total readiness score (0-1000)"""
        self.total_score = (
            self.inventory.calculate_score() +
            self.migration.calculate_score() +
            self.detection.calculate_score() +
            self.compliance.calculate_score() +
            self.team.calculate_score()
        )
        self.grade = ReadinessGrade.get_grade_for_score(self.total_score)
        return self.total_score
    
    def get_benchmark_comparison(self) -> Dict[str, any]:
        """Compare against industry benchmarks"""
        benchmark = IndustryBenchmarks.get_benchmark(self.industry)
        percentile = self._calculate_percentile(benchmark)
        
        return {
            "industry": self.industry,
            "your_score": self.total_score,
            "industry_average": benchmark.average_score,
            "percentile": percentile,
            "benchmark_rank": benchmark.get_benchmark_rank(self.total_score),
            "above_average": self.total_score > benchmark.average_score,
            "gap_to_75th_percentile": benchmark.percentile_75 - self.total_score,
        }
    
    def _calculate_percentile(self, benchmark: IndustryBenchmark) -> float:
        """Estimate percentile ranking"""
        if self.total_score >= benchmark.percentile_90:
            return 90.0
        elif self.total_score >= benchmark.percentile_75:
            return 75.0
        elif self.total_score >= benchmark.percentile_50:
            return 50.0
        else:
            return max(0.0, (self.total_score / benchmark.percentile_50) * 50)
    
    def generate_improvement_roadmap(self, target_score: float = 750) -> List[ImprovementMilestone]:
        """Generate improvement roadmap to reach target score"""
        milestones = []
        
        # Quick wins: 30 days
        quick_improvements = [
            ("Complete cryptographic inventory", 100),
            ("Deploy basic monitoring tool", 50),
            ("Document PQC policy", 25),
            ("Board briefing on quantum risks", 25),
        ]
        milestone_30 = ImprovementMilestone(
            days_to_achieve=30,
            title="Quick Wins Phase",
            improvements=quick_improvements
        )
        milestones.append(milestone_30)
        
        # Medium term: 90 days
        medium_improvements = [
            ("Migrate 10% of systems", 25),
            ("Train 20 employees", 40),
            ("Implement hybrid cryptography", 40),
            ("Deploy dark web monitoring", 30),
        ]
        milestone_90 = ImprovementMilestone(
            days_to_achieve=90,
            title="Medium-Term Progress",
            improvements=medium_improvements
        )
        milestones.append(milestone_90)
        
        # Extended: 180 days
        extended_improvements = [
            ("Migrate 30% of systems", 75),
            ("Train 50+ employees", 40),
            ("Full anomaly detection", 20),
            ("NIST compliance audit", 25),
        ]
        milestone_180 = ImprovementMilestone(
            days_to_achieve=180,
            title="Extended Roadmap",
            improvements=extended_improvements
        )
        milestones.append(milestone_180)
        
        return milestones
    
    def format_report(self) -> str:
        """Generate formatted readiness report"""
        benchmark = IndustryBenchmarks.get_benchmark(self.industry)
        roadmap = self.generate_improvement_roadmap()
        
        lines = [
            "🎯 QUANTUM READINESS SCORE REPORT",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "",
            f"Organization: {self.organization_name}",
            f"Industry: {self.industry.title()}",
            f"Assessment Date: {self.timestamp.strftime('%Y-%m-%d')}",
            "",
            "OVERALL SCORE:",
            f"  Score: {self.total_score:.0f} / 1000",
            f"  Grade: {self.grade.value[0]} ({self.grade.value[3]})",
            "",
            "COMPONENT BREAKDOWN:",
            f"  🗂️  Cryptographic Inventory: {self.inventory.calculate_score():.0f} / 400",
            f"  🔄 Migration Progress: {self.migration.calculate_score():.0f} / 250",
            f"  📊 Threat Detection: {self.detection.calculate_score():.0f} / 150",
            f"  📋 Compliance & Governance: {self.compliance.calculate_score():.0f} / 100",
            f"  👥 Team Readiness: {self.team.calculate_score():.0f} / 100",
            "",
            "INDUSTRY BENCHMARKING:",
            f"  Your Score: {self.total_score:.0f}",
            f"  Industry Average: {benchmark.average_score:.0f}",
            f"  Percentile: {self.get_benchmark_comparison()['percentile']:.0f}th",
            f"  Rank: {self.get_benchmark_comparison()['benchmark_rank']}",
            f"  Above Average: {'✓ Yes' if self.get_benchmark_comparison()['above_average'] else '✗ No'}",
            "",
            "IMPROVEMENT ROADMAP (Target: 750):",
        ]
        
        for milestone in roadmap:
            projected_score = self.total_score + milestone.total_points
            target_date = self.timestamp + timedelta(days=milestone.days_to_achieve)
            lines.append(f"  {milestone.title} (+{milestone.total_points:.0f} pts)")
            lines.append(f"    Timeline: {milestone.days_to_achieve} days ({target_date.strftime('%Y-%m-%d')})")
            lines.append(f"    Projected Score: {projected_score:.0f}")
            for desc, points in milestone.improvements:
                lines.append(f"      • {desc} (+{points:.0f})")
            lines.append("")
        
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        
        return "\n".join(lines)


def create_readiness_score(
    organization_name: str,
    industry: str,
    inventory_complete: bool = False,
    migration_percentage: float = 0.0,
    employees_trained: int = 0,
    has_monitoring: bool = False,
    has_policy: bool = False,
) -> QuantumReadinessScore:
    """Factory function to create and calculate readiness score"""
    
    score = QuantumReadinessScore(
        organization_name=organization_name,
        industry=industry,
    )
    
    # Configure inventory
    score.inventory.has_complete_inventory = inventory_complete
    if inventory_complete:
        score.inventory.documented_key_sizes = True
        score.inventory.identified_vulnerable_systems = True
        score.inventory.prioritized_by_sensitivity = True
        score.inventory.inventory_updated_within_90_days = True
    
    # Configure migration
    score.migration.systems_migrated = int(score.migration.total_vulnerable_systems * migration_percentage)
    
    # Configure team
    score.team.employees_trained = employees_trained
    
    # Configure detection
    score.detection.has_network_monitoring = has_monitoring
    
    # Configure compliance
    score.compliance.pqc_policy_documented = has_policy
    
    score.calculate_score()
    return score
