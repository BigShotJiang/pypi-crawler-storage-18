"""
Feature 2.3: Q-Day Timeline Predictor
=====================================

Predicts when specific cryptographic algorithms will become breakable by
quantum computers. Uses multiple estimation methods including exponential growth
modeling, industry consensus, and per-algorithm analysis.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import math


class QuantumAlgorithm(Enum):
    """Cryptographic algorithms with quantum vulnerability profiles"""
    RSA_1024 = ("RSA-1024", 2000, 2028, 2030, "🚨 URGENT")
    RSA_2048 = ("RSA-2048", 4000, 2033, 2035, "🚨 CRITICAL")
    RSA_4096 = ("RSA-4096", 8000, 2036, 2038, "⚠️  WARNING")
    ECC_256 = ("ECC-256", 2000, 2030, 2032, "🚨 CRITICAL")
    ECC_384 = ("ECC-384", 3000, 2035, 2037, "⚠️  WARNING")
    ECC_521 = ("ECC-521", 5000, 2037, 2039, "✓ RELATIVELY SAFE")
    AES_128 = ("AES-128", 1000, 2040, 2045, "✓ LESS URGENT")
    AES_256 = ("AES-256", 2000, 2050, 2060, "✓ SAFE")
    
    @property
    def name_str(self) -> str:
        return self.value[0]
    
    @property
    def logical_qubits_needed(self) -> int:
        return self.value[1]
    
    @property
    def conservative_breakage_year(self) -> int:
        return self.value[2]
    
    @property
    def optimistic_breakage_year(self) -> int:
        return self.value[3]
    
    @property
    def risk_level(self) -> str:
        return self.value[4]


@dataclass
class QuantumComputerProgress:
    """Track quantum computing hardware progress"""
    year: int
    max_qubits: int
    gate_error_rate: float  # 10^-x format, so 3 means 10^-3
    notes: str = ""


class QuantumProgressTracker:
    """Tracks quantum computing progress from historical data"""
    
    # Historical and projected quantum computer progress
    HISTORICAL_PROGRESS = [
        QuantumComputerProgress(2020, 65, 3.0, "IBM Falcon"),
        QuantumComputerProgress(2021, 127, 3.0, "IBM Hummingbird"),
        QuantumComputerProgress(2022, 433, 4.0, "IBM Osprey"),
        QuantumComputerProgress(2023, 1121, 4.2, "IBM Condor"),
        QuantumComputerProgress(2024, 1386, 4.5, "IBM Heron + others"),
    ]
    
    # Qubit doubling time: approximately 1.5 years
    DOUBLING_TIME_YEARS = 1.5
    
    @classmethod
    def get_projected_qubits(cls, year: int) -> int:
        """Project qubit count for future year using exponential growth"""
        if year <= 2024:
            # Find closest historical year
            closest = min(cls.HISTORICAL_PROGRESS, 
                         key=lambda x: abs(x.year - year))
            return closest.max_qubits
        
        # Use exponential growth model
        base_year = 2024
        base_qubits = 1386
        years_ahead = year - base_year
        projected = base_qubits * (2 ** (years_ahead / cls.DOUBLING_TIME_YEARS))
        return int(projected)
    
    @classmethod
    def predict_qubits_available_by_year(cls, target_qubits: int) -> int:
        """Predict year when target qubit count will be available"""
        current_qubits = 1386
        current_year = 2024
        
        if target_qubits <= current_qubits:
            return current_year
        
        # Solve: target = current × 2^(years / doubling_time)
        # years = doubling_time × log₂(target / current)
        years_needed = cls.DOUBLING_TIME_YEARS * math.log2(target_qubits / current_qubits)
        return current_year + int(years_needed)


@dataclass
class AlgorithmBreakageEstimate:
    """Estimate for when an algorithm becomes breakable"""
    algorithm: QuantumAlgorithm
    logical_qubits_needed: int
    
    # Prediction methods
    exponential_model_year: int = 0
    conservative_year: int = 0
    optimistic_year: int = 0
    industry_consensus_year: int = 0
    
    # Final estimate
    expected_breakage_year: int = 0
    confidence_range: Tuple[int, int] = (0, 0)
    risk_level: str = ""
    
    def calculate_estimates(self) -> None:
        """Calculate all prediction methods"""
        
        # Method 1: Exponential Growth Model
        self.exponential_model_year = QuantumProgressTracker.predict_qubits_available_by_year(
            self.logical_qubits_needed
        )
        
        # Method 2 & 3: Algorithm-specific estimates (from research)
        self.conservative_year = self.algorithm.conservative_breakage_year
        self.optimistic_year = self.algorithm.optimistic_breakage_year
        
        # Method 4: Industry consensus (NIST, NSA, IBM consensus)
        self.industry_consensus_year = self.conservative_year
        
        # Calculate expected breakage as average of methods
        all_estimates = [
            self.exponential_model_year,
            self.conservative_year,
            self.industry_consensus_year,
        ]
        self.expected_breakage_year = int(sum(all_estimates) / len(all_estimates))
        
        # Confidence range (±3 years from expected)
        self.confidence_range = (
            self.expected_breakage_year - 3,
            self.expected_breakage_year + 3
        )
        
        self.risk_level = self.algorithm.risk_level


@dataclass
class DataAssetThreat:
    """Quantify threat to specific data asset"""
    asset_name: str
    algorithm: QuantumAlgorithm
    current_year: int = 2024
    lifespan_years: int = 10
    value: float = 1_000_000
    
    def get_threat_status(self) -> str:
        """Get threat status based on algorithm breakage timing"""
        estimate = AlgorithmBreakageEstimate(algorithm=self.algorithm, 
                                            logical_qubits_needed=self.algorithm.logical_qubits_needed)
        estimate.calculate_estimates()
        
        data_lifetime_end = self.current_year + self.lifespan_years
        breakage_year = estimate.expected_breakage_year
        
        if data_lifetime_end <= breakage_year:
            return f"✓ SAFE: Data expires {data_lifetime_end}, quantum threat {breakage_year}"
        elif breakage_year - self.current_year <= 5:
            return f"🚨 URGENT: Breakage by {breakage_year}, {self.lifespan_years}-year data"
        elif breakage_year - self.current_year <= 10:
            return f"🚨 CRITICAL: Breakage by {breakage_year}, {self.lifespan_years}-year data"
        else:
            return f"⚠️  WARNING: Breakage by {breakage_year}, {self.lifespan_years}-year data"


@dataclass
class ThreatTimeline:
    """Complete threat timeline across all algorithms"""
    timestamp: datetime = field(default_factory=datetime.now)
    organization_name: str = ""
    
    # Asset details
    assets_by_algorithm: Dict[QuantumAlgorithm, List[Tuple[str, int]]] = field(default_factory=dict)
    
    # Data sensitivity mapping
    data_lifespan_years: int = 10
    current_year: int = 2024
    
    def add_asset(self, algorithm: QuantumAlgorithm, asset_name: str, count: int = 1) -> None:
        """Add asset using specific algorithm"""
        if algorithm not in self.assets_by_algorithm:
            self.assets_by_algorithm[algorithm] = []
        self.assets_by_algorithm[algorithm].append((asset_name, count))
    
    def get_risk_segments(self) -> Dict[str, List[Tuple[QuantumAlgorithm, int, int]]]:
        """Organize threats by time periods"""
        segments = {
            "immediate_0_5_years": [],
            "near_term_5_10_years": [],
            "medium_term_10_15_years": [],
            "long_term_15_plus_years": [],
        }
        
        for algorithm in QuantumAlgorithm:
            estimate = AlgorithmBreakageEstimate(
                algorithm=algorithm,
                logical_qubits_needed=algorithm.logical_qubits_needed
            )
            estimate.calculate_estimates()
            
            years_until = estimate.expected_breakage_year - self.current_year
            systems_affected = sum(count for asset_name, count in 
                                 self.assets_by_algorithm.get(algorithm, []))
            
            if systems_affected == 0:
                continue
            
            threat = (algorithm, estimate.expected_breakage_year, systems_affected)
            
            if years_until <= 5:
                segments["immediate_0_5_years"].append(threat)
            elif years_until <= 10:
                segments["near_term_5_10_years"].append(threat)
            elif years_until <= 15:
                segments["medium_term_10_15_years"].append(threat)
            else:
                segments["long_term_15_plus_years"].append(threat)
        
        return segments
    
    def format_timeline_report(self) -> str:
        """Generate formatted threat timeline report"""
        segments = self.get_risk_segments()
        
        lines = [
            "📅 QUANTUM THREAT TIMELINE",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "",
            f"Organization: {self.organization_name}",
            f"Assessment Date: {self.timestamp.strftime('%Y-%m-%d')}",
            f"Data Lifespan: {self.data_lifespan_years} years",
            "",
            "IMMEDIATE RISK (0-5 years):",
        ]
        
        if segments["immediate_0_5_years"]:
            for algo, year, count in sorted(segments["immediate_0_5_years"], 
                                          key=lambda x: x[1]):
                lines.append(f"  {algo.risk_level} {algo.name_str} breakable by {year}")
                lines.append(f"     Systems affected: {count}")
                lines.append(f"     Action: MIGRATE IMMEDIATELY")
        else:
            lines.append("  ✓ No immediate threats")
        
        lines.append("")
        lines.append("NEAR-TERM RISK (5-10 years):")
        if segments["near_term_5_10_years"]:
            for algo, year, count in sorted(segments["near_term_5_10_years"],
                                          key=lambda x: x[1]):
                lines.append(f"  {algo.risk_level} {algo.name_str} breakable by {year}")
                lines.append(f"     Systems affected: {count}")
                lines.append(f"     Action: START MIGRATION NOW")
        else:
            lines.append("  ✓ No near-term threats")
        
        lines.append("")
        lines.append("MEDIUM-TERM RISK (10-15 years):")
        if segments["medium_term_10_15_years"]:
            for algo, year, count in sorted(segments["medium_term_10_15_years"],
                                          key=lambda x: x[1]):
                lines.append(f"  {algo.risk_level} {algo.name_str} breakable by {year}")
                lines.append(f"     Systems affected: {count}")
                lines.append(f"     Action: Plan migration roadmap")
        else:
            lines.append("  ✓ No medium-term threats")
        
        lines.append("")
        lines.append("LONG-TERM CONCERNS (15+ years):")
        if segments["long_term_15_plus_years"]:
            for algo, year, count in sorted(segments["long_term_15_plus_years"],
                                          key=lambda x: x[1]):
                lines.append(f"  {algo.risk_level} {algo.name_str} breakable by {year}")
                lines.append(f"     Systems affected: {count}")
                lines.append(f"     Action: Monitor and maintain readiness")
        else:
            lines.append("  ✓ No long-term concerns")
        
        lines.append("")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        lines.append("")
        
        # Critical insight
        data_lifetime_end = self.current_year + self.data_lifespan_years
        lines.append("CRITICAL INSIGHT:")
        lines.append(f"  Data with {self.data_lifespan_years}-year lifespan extends to {data_lifetime_end}")
        
        # Find algorithms that break within data lifetime
        at_risk = []
        for algo in QuantumAlgorithm:
            estimate = AlgorithmBreakageEstimate(
                algorithm=algo,
                logical_qubits_needed=algo.logical_qubits_needed
            )
            estimate.calculate_estimates()
            
            if estimate.expected_breakage_year <= data_lifetime_end:
                if estimate.expected_breakage_year >= self.current_year:
                    at_risk.append((algo.name_str, estimate.expected_breakage_year))
        
        if at_risk:
            lines.append(f"  {algo.name_str} will still be valuable when broken")
            lines.append("")
            lines.append("RECOMMENDATION:")
            earliest_break = min(at_risk, key=lambda x: x[1])[1]
            months_available = (earliest_break - self.current_year) * 12
            lines.append(f"  ⚡ Begin migration within 6 months to complete before {earliest_break}")
            lines.append(f"  Available time: ~{months_available} months")
        else:
            lines.append("  Data will likely be worthless before quantum threat materializes")
            lines.append("")
            lines.append("RECOMMENDATION:")
            lines.append("  ✓ Consider planned (non-urgent) migration timeline")
        
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        
        return "\n".join(lines)


def create_threat_timeline(organization_name: str) -> ThreatTimeline:
    """Factory function to create threat timeline"""
    timeline = ThreatTimeline(organization_name=organization_name)
    return timeline


def estimate_algorithm_breakage(algorithm: QuantumAlgorithm) -> AlgorithmBreakageEstimate:
    """Generate breakage estimate for specific algorithm"""
    estimate = AlgorithmBreakageEstimate(
        algorithm=algorithm,
        logical_qubits_needed=algorithm.logical_qubits_needed
    )
    estimate.calculate_estimates()
    return estimate


def get_all_algorithm_estimates() -> Dict[str, AlgorithmBreakageEstimate]:
    """Get breakage estimates for all algorithms"""
    estimates = {}
    for algo in QuantumAlgorithm:
        estimate = estimate_algorithm_breakage(algo)
        estimates[algo.name_str] = estimate
    return estimates
