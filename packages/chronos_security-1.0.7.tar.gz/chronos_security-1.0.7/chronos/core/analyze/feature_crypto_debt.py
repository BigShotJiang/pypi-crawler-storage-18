"""
Feature 2.1: Cryptographic Debt Calculator
============================================

Calculates the financial cost and risk of delaying post-quantum migration.
Provides ROI analysis for immediate vs. delayed migration strategies.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from decimal import Decimal
import math


class DataSensitivityLevel(Enum):
    """Data sensitivity classification levels"""
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class IndustrySector(Enum):
    """Industry classification with breach costs per record"""
    HEALTHCARE = ("Healthcare", 408)
    FINANCIAL = ("Financial", 321)
    TECHNOLOGY = ("Technology", 308)
    RETAIL = ("Retail", 285)
    GOVERNMENT = ("Government", 350)
    MANUFACTURING = ("Manufacturing", 220)
    ENERGY = ("Energy", 290)
    GENERAL = ("General", 165)


@dataclass
class AlgorithmVulnerability:
    """Quantum vulnerability profile for cryptographic algorithm"""
    algorithm: str
    key_size: int
    q_day_baseline: int  # Year when algorithm becomes breakable
    adjustment_factor: float = 0.0  # +/- years based on latest breakthroughs


class QDayProbabilityModel:
    """Model for estimating Q-Day probability distribution"""
    
    def __init__(self):
        """Initialize with consensus-based probability distribution"""
        # Base distribution based on research consensus
        self.distribution = {
            2028: 0.05,
            2030: 0.15,
            2032: 0.25,
            2033: 0.30,
            2035: 0.20,
            2037: 0.05,
        }
    
    def adjust_for_breakthroughs(self, breakthrough_years: int) -> Dict[int, float]:
        """Adjust probability based on recent quantum computing breakthroughs"""
        adjusted = {}
        for year, probability in self.distribution.items():
            adjusted_year = year - breakthrough_years
            adjusted[adjusted_year] = probability
        return adjusted
    
    def get_expected_q_day(self, adjusted_dist: Dict[int, float]) -> float:
        """Calculate expected Q-Day year"""
        return sum(year * prob for year, prob in adjusted_dist.items())
    
    def get_probability_by_year(self, year: int, adjusted_dist: Dict[int, float]) -> float:
        """Get probability that Q-Day has occurred by given year"""
        cumulative = 0.0
        for q_day_year, prob in sorted(adjusted_dist.items()):
            if q_day_year <= year:
                cumulative += prob
        return cumulative


class DataValueDecayModel:
    """Model for estimating data value over time"""
    
    # Data lifespan by type (in years)
    LIFESPAN_BY_TYPE = {
        "medical_records": 50,
        "financial_records": 10,
        "trade_secrets": 20,
        "customer_data": 5,
        "credentials": 1,
        "generic": 7,
    }
    
    @staticmethod
    def calculate_data_value_at_year(
        current_year: int,
        target_year: int,
        data_lifespan: int,
        data_value_today: float,
        decay_type: str = "linear"
    ) -> float:
        """Calculate remaining data value at target year"""
        years_elapsed = target_year - current_year
        
        if years_elapsed >= data_lifespan:
            return 0.0  # Data no longer valuable
        
        if decay_type == "linear":
            remaining_lifespan = data_lifespan - years_elapsed
            return data_value_today * (remaining_lifespan / data_lifespan)
        
        elif decay_type == "exponential":
            # Faster decay for time-sensitive data
            decay_rate = 0.95  # 5% annual decay
            return data_value_today * (decay_rate ** years_elapsed)
        
        return data_value_today


class BreachCostCalculator:
    """Calculate total cost of quantum-enabled data breach"""
    
    @staticmethod
    def calculate_breach_cost(
        num_records: int,
        industry: IndustrySector,
        annual_revenue: float,
        additional_factors: Optional[Dict[str, float]] = None
    ) -> Dict[str, float]:
        """
        Calculate total breach cost including direct and indirect impacts.
        
        Returns:
            Dictionary with cost breakdown
        """
        industry_name, cost_per_record = industry.value
        
        # Direct breach costs
        direct_cost = num_records * cost_per_record
        
        # Regulatory fines (GDPR: up to 4% annual revenue)
        regulatory_fines = annual_revenue * 0.04
        
        # Legal fees (average $1-5M)
        legal_fees = 3_000_000
        
        # Reputation damage (25% of breach cost)
        reputation_damage = direct_cost * 0.25
        
        # Business disruption (15% of breach cost)
        business_disruption = direct_cost * 0.15
        
        # Customer compensation (10% of breach cost)
        customer_compensation = direct_cost * 0.10
        
        total_cost = (
            direct_cost +
            regulatory_fines +
            legal_fees +
            reputation_damage +
            business_disruption +
            customer_compensation
        )
        
        return {
            "direct_breach_cost": direct_cost,
            "regulatory_fines": regulatory_fines,
            "legal_fees": legal_fees,
            "reputation_damage": reputation_damage,
            "business_disruption": business_disruption,
            "customer_compensation": customer_compensation,
            "total_breach_cost": total_cost,
        }


class MigrationCostCalculator:
    """Calculate total cost of migration"""
    
    @staticmethod
    def calculate_migration_cost(
        num_systems: int,
        num_certificates: int,
        num_employees: int,
        complexity_score: int,  # 1-10
        timeline_urgency: float,  # 1.0 = normal, 2.0 = double speed required
        expected_downtime_minutes: float = 0.0,
    ) -> Dict[str, float]:
        """
        Calculate total migration cost including all components.
        
        Args:
            num_systems: Number of affected systems
            num_certificates: Number of certificates to replace
            num_employees: Team size for training
            complexity_score: 1-10 scale
            timeline_urgency: Multiplier for rush costs
            expected_downtime_minutes: Expected downtime impact
        
        Returns:
            Dictionary with cost breakdown
        """
        # Software updates: $50-200 per endpoint
        update_cost_per_system = 50 + (complexity_score * 15)
        software_updates = num_systems * update_cost_per_system
        
        # Certificate replacement: $100-500 per cert
        cert_cost_per_cert = 100 + (complexity_score * 40)
        certificate_replacement = num_certificates * cert_cost_per_cert
        
        # Developer time: $150/hour × estimated hours
        # Estimate: 40 + (10 × complexity) hours per system
        dev_hours_per_system = 40 + (10 * complexity_score)
        total_dev_hours = num_systems * dev_hours_per_system
        developer_time = total_dev_hours * 150
        
        # Testing: 20% of development cost
        testing_cost = developer_time * 0.20
        
        # Downtime cost: $5,600 per minute (average enterprise)
        downtime_cost = expected_downtime_minutes * 5600
        
        # Training: $500-2,000 per employee
        training_per_employee = 500 + (complexity_score * 150)
        training_cost = num_employees * training_per_employee
        
        subtotal = (
            software_updates +
            certificate_replacement +
            developer_time +
            testing_cost +
            downtime_cost +
            training_cost
        )
        
        # Apply timeline urgency multiplier
        total_cost = subtotal * timeline_urgency
        
        return {
            "software_updates": software_updates * timeline_urgency,
            "certificate_replacement": certificate_replacement * timeline_urgency,
            "developer_time": developer_time * timeline_urgency,
            "testing": testing_cost * timeline_urgency,
            "downtime": downtime_cost * timeline_urgency,
            "training": training_cost * timeline_urgency,
            "total_migration_cost": total_cost,
        }


@dataclass
class CryptographicDebtAnalysis:
    """Complete cryptographic debt analysis"""
    timestamp: datetime = field(default_factory=datetime.now)
    
    # Input parameters
    rsa_keys_found: int = 0
    data_sensitivity: DataSensitivityLevel = DataSensitivityLevel.MEDIUM
    data_lifespan_years: int = 10
    industry_sector: IndustrySector = IndustrySector.GENERAL
    annual_revenue: float = 0.0
    num_exposed_records: int = 0
    countries_of_operation: List[str] = field(default_factory=list)
    
    # Calculated values
    q_day_probability: float = 0.0
    expected_q_day: int = 2033
    data_still_at_risk: bool = True
    breach_cost_breakdown: Dict[str, float] = field(default_factory=dict)
    migration_cost_breakdown: Dict[str, float] = field(default_factory=dict)
    roi_analysis: Dict[str, float] = field(default_factory=dict)
    
    def calculate_all(
        self,
        num_systems: int = 100,
        num_certificates: int = 50,
        num_employees: int = 25,
        complexity_score: int = 5,
        quantum_breakthroughs: int = 0,
    ) -> None:
        """Execute complete cryptographic debt analysis"""
        
        # Step 1: Calculate Q-Day probability
        qday_model = QDayProbabilityModel()
        adjusted_dist = qday_model.adjust_for_breakthroughs(quantum_breakthroughs)
        self.expected_q_day = int(qday_model.get_expected_q_day(adjusted_dist))
        current_year = datetime.now().year
        self.q_day_probability = qday_model.get_probability_by_year(
            current_year + 10, adjusted_dist
        )
        
        # Step 2: Check if data still at risk
        data_lifetime_end = current_year + self.data_lifespan_years
        self.data_still_at_risk = data_lifetime_end > self.expected_q_day
        
        # Step 3: Calculate breach costs
        self.breach_cost_breakdown = BreachCostCalculator.calculate_breach_cost(
            self.num_exposed_records,
            self.industry_sector,
            self.annual_revenue
        )
        
        # Step 4: Calculate migration costs
        self.migration_cost_breakdown = MigrationCostCalculator.calculate_migration_cost(
            num_systems,
            num_certificates,
            num_employees,
            complexity_score,
            timeline_urgency=1.0,  # Normal timeline
            expected_downtime_minutes=30.0,
        )
        
        # Step 5: Calculate ROI
        self._calculate_roi(num_systems, num_certificates, num_employees, complexity_score)
    
    def _calculate_roi(
        self,
        num_systems: int,
        num_certificates: int,
        num_employees: int,
        complexity_score: int,
    ) -> None:
        """Calculate ROI for migrate now vs wait scenarios"""
        
        current_cost = self.migration_cost_breakdown["total_migration_cost"]
        
        # Option A: Migrate Now
        option_a_cost = current_cost
        option_a_risk = 0.0  # Minimal risk
        
        # Option B: Wait until 2030 (typical regulatory pressure deadline)
        inflation_rate = 0.15  # 15% over 6 years
        delayed_cost_base = current_cost * (1 + inflation_rate)
        
        # When rushing in 2030, costs increase 50%
        rushed_multiplier = 1.5
        delayed_cost_rushed = delayed_cost_base * rushed_multiplier
        
        # Risk of breach while waiting
        breach_cost = self.breach_cost_breakdown["total_breach_cost"]
        breach_probability = self.q_day_probability
        expected_breach_loss = breach_cost * breach_probability
        
        option_b_total = delayed_cost_rushed + expected_breach_loss
        
        # Calculate savings and ROI
        total_savings = option_b_total - option_a_cost
        roi_percentage = (total_savings / option_a_cost * 100) if option_a_cost > 0 else 0
        
        self.roi_analysis = {
            "migrate_now_cost": option_a_cost,
            "migrate_delayed_cost": delayed_cost_rushed,
            "inflation_impact": delayed_cost_base - current_cost,
            "rush_cost_premium": delayed_cost_rushed - delayed_cost_base,
            "breach_risk_probability": breach_probability,
            "expected_breach_loss": expected_breach_loss,
            "option_b_total_cost": option_b_total,
            "total_savings_by_migrating_now": total_savings,
            "roi_percentage": roi_percentage,
            "break_even_breaches_prevented": 1 if total_savings > 0 else float('inf'),
        }
    
    def format_report(self) -> str:
        """Generate formatted analysis report"""
        lines = [
            "💰 CRYPTOGRAPHIC DEBT ANALYSIS",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "",
            "CURRENT STATUS:",
            f"  Quantum-Vulnerable Assets: {self.rsa_keys_found} RSA keys",
            f"  Data Sensitivity: {self.data_sensitivity.value}",
            f"  Data Lifespan: {self.data_lifespan_years} years",
            f"  Expected Q-Day: {self.expected_q_day} (Q-Day probability: {self.q_day_probability*100:.1f}%)",
            f"  Industry Sector: {self.industry_sector.value[0]}",
            "",
            "RISK ASSESSMENT:",
            f"  {'🚨 CRITICAL' if self.data_still_at_risk else '✓ LOW'}: "
            f"Data {'will' if self.data_still_at_risk else 'will NOT'} still be valuable when quantum breaks encryption",
            "",
            "FINANCIAL IMPACT:",
        ]
        
        # Add breach cost breakdown
        if self.breach_cost_breakdown:
            lines.append(f"  Direct Breach Cost: ${self.breach_cost_breakdown['direct_breach_cost']:,.0f}")
            lines.append(f"  Regulatory Fines: ${self.breach_cost_breakdown['regulatory_fines']:,.0f}")
            lines.append(f"  Legal Fees: ${self.breach_cost_breakdown['legal_fees']:,.0f}")
            lines.append(f"  Reputation Damage: ${self.breach_cost_breakdown['reputation_damage']:,.0f}")
            lines.append(f"  Total Potential Breach Loss: ${self.breach_cost_breakdown['total_breach_cost']:,.0f}")
        
        lines.append("")
        lines.append("MIGRATION COST:")
        if self.migration_cost_breakdown:
            lines.append(f"  Migration Cost (Today): ${self.migration_cost_breakdown['total_migration_cost']:,.0f}")
        
        lines.append("")
        lines.append("ROI ANALYSIS:")
        if self.roi_analysis:
            lines.append(f"  Migrate Now: Spend ${self.roi_analysis['migrate_now_cost']:,.0f}")
            lines.append(f"  Migrate Delayed (2030): Spend ${self.roi_analysis['option_b_total_cost']:,.0f}")
            lines.append(f"  Total Savings: ${self.roi_analysis['total_savings_by_migrating_now']:,.0f}")
            lines.append(f"  ROI: {self.roi_analysis['roi_percentage']:.0f}%")
            lines.append(f"  Break-even: Prevented {int(self.roi_analysis['break_even_breaches_prevented'])} breach(es)")
        
        lines.append("")
        lines.append("RECOMMENDATION:")
        if self.data_still_at_risk:
            lines.append("  ⚡ IMMEDIATE MIGRATION REQUIRED")
            if self.migration_cost_breakdown:
                monthly_risk = self.roi_analysis.get('total_savings_by_migrating_now', 0) / 12
                lines.append(f"  Every month delayed ≈ ${monthly_risk:,.0f} additional risk")
        else:
            lines.append("  ✓ Data value expires before quantum threat materializes")
            lines.append("  Consider planned migration timeline")
        
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        
        return "\n".join(lines)


def create_debt_analysis(
    rsa_keys: int,
    data_sensitivity: str,
    data_lifespan: int,
    industry: str,
    annual_revenue: float,
    exposed_records: int = 1000,
    num_systems: int = 100,
    num_certificates: int = 50,
    num_employees: int = 25,
    complexity: int = 5,
) -> CryptographicDebtAnalysis:
    """Factory function to create and calculate debt analysis"""
    
    analysis = CryptographicDebtAnalysis(
        rsa_keys_found=rsa_keys,
        data_sensitivity=DataSensitivityLevel[data_sensitivity.upper()],
        data_lifespan_years=data_lifespan,
        industry_sector=IndustrySector[industry.upper().replace("-", "_")],
        annual_revenue=annual_revenue,
        num_exposed_records=exposed_records,
    )
    
    analysis.calculate_all(
        num_systems=num_systems,
        num_certificates=num_certificates,
        num_employees=num_employees,
        complexity_score=complexity,
    )
    
    return analysis
