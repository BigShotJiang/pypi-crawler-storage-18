"""
CHRONOS Module 6: REPORT - Part 6.4: Compliance & Evidence Pack
Auditor-friendly artifacts for SBOM, NIST SSDF, and regulatory compliance.
"""

import datetime
import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional


@dataclass
class SBOMComponent:
    """SBOM component for CycloneDX/SPDX"""
    name: str
    version: str
    component_type: str  # library, application, container
    purl: str
    supplier: str
    licenses: List[str]
    hashes: Dict[str, str]
    vulnerabilities: List[str]


@dataclass
class SSdFEvidence:
    """NIST SP 800-218 SSDF evidence"""
    practice_code: str  # PO1.1, PO1.2, etc.
    practice_name: str
    maturity_level: str  # Weak, Partial, Progressing, Complete
    evidence_items: List[str]
    gaps: List[str]
    remediation_timeline: str


@dataclass
class ComplianceAttestation:
    """Attestation of compliance posture"""
    standard: str  # SBOM-minimum, SSDF, SOC2, etc.
    assessed_date: str
    attestation_status: str  # Passing, Partial, Failing
    coverage_percent: float
    auditor_notes: str


class ComplianceEvidencePackSimulatorPart64:
    """Generate compliance & evidence packs"""
    
    def __init__(self):
        self.sbom_components = []
        self.ssdf_practices = []
        self.attestations = []
    
    def generate_sbom(self, format_type: str = "cyclonedx") -> Dict:
        """Generate SBOM in CycloneDX or SPDX format"""
        components = [
            SBOMComponent(
                name="cryptography",
                version="41.0.0",
                component_type="library",
                purl="pkg:pypi/cryptography@41.0.0",
                supplier="PyPA",
                licenses=["Apache-2.0"],
                hashes={"SHA-256": "a1b2c3d4e5f6..."},
                vulnerabilities=[],
            ),
            SBOMComponent(
                name="openssl",
                version="3.0.10",
                component_type="library",
                purl="pkg:deb/openssl@3.0.10-1ubuntu2",
                supplier="Debian",
                licenses=["Apache-2.0"],
                hashes={"SHA-256": "f6e5d4c3b2a1..."},
                vulnerabilities=["CVE-2024-45678"],
            ),
            SBOMComponent(
                name="express",
                version="4.18.0",
                component_type="library",
                purl="pkg:npm/express@4.18.0",
                supplier="Node.js Foundation",
                licenses=["MIT"],
                hashes={"SHA-256": "9h8g7f6e5d4c..."},
                vulnerabilities=[],
            ),
            SBOMComponent(
                name="log4j",
                version="2.17.1",
                component_type="library",
                purl="pkg:maven/org.apache.logging.log4j/log4j@2.17.1",
                supplier="Apache",
                licenses=["Apache-2.0"],
                hashes={"SHA-256": "z9y8x7w6v5u4..."},
                vulnerabilities=[],
            ),
            SBOMComponent(
                name="api-gateway-prod",
                version="1.2.3",
                component_type="application",
                purl="pkg:docker/api-gateway-prod@sha256:abc123",
                supplier="Internal",
                licenses=["Proprietary"],
                hashes={"SHA-256": "abc123def456..."},
                vulnerabilities=["CVE-2024-45680", "GHSA-xxxx-yyyy-zzzz"],
            ),
            SBOMComponent(
                name="postgres",
                version="15.0",
                component_type="library",
                purl="pkg:deb/postgresql@15.0-1",
                supplier="PostgreSQL",
                licenses=["PostgreSQL"],
                hashes={"SHA-256": "p9o8n7m6l5k4..."},
                vulnerabilities=[],
            ),
        ]
        self.sbom_components = components
        
        if format_type == "cyclonedx":
            return {
                "bomFormat": "CycloneDX",
                "specVersion": "1.5",
                "version": 1,
                "components": [asdict(c) for c in components],
                "metadata": {
                    "timestamp": datetime.datetime.utcnow().isoformat(),
                    "component": {
                        "name": "CHRONOS Quantum Security Platform",
                        "version": "1.0.6",
                    }
                }
            }
        else:  # SPDX
            return {
                "spdxVersion": "SPDX-2.3",
                "dataLicense": "CC0-1.0",
                "name": "CHRONOS Quantum Security Scan",
                "documentNamespace": f"https://chronos.example.com/sbom-{datetime.datetime.utcnow().isoformat()}",
                "creationInfo": {
                    "created": datetime.datetime.utcnow().isoformat(),
                    "creators": ["Tool: CHRONOS-1.0.6"],
                },
                "packages": [asdict(c) for c in components],
            }
    
    def map_ssdf_practices(self) -> List[SSdFEvidence]:
        """Map to NIST SP 800-218 SSDF practices"""
        practices = [
            SSdFEvidence(
                practice_code="PO1.1",
                practice_name="Perform threat modeling",
                maturity_level="Progressing",
                evidence_items=[
                    "Threat model for API gateway (2024-Q4)",
                    "Supply chain risk assessment (Module 5 threat intel)",
                ],
                gaps=[
                    "Threat models missing for legacy services",
                    "No regular update cycle (annual vs quarterly needed)",
                ],
                remediation_timeline="Q1 2025",
            ),
            SSdFEvidence(
                practice_code="PO2.1",
                practice_name="Maintain supply chain inventory",
                maturity_level="Partial",
                evidence_items=[
                    "SBOM generated for all prod containers",
                    "Dependency scanner results (Module 5.1.1)",
                    "Shadow data inventory (Module 5.3)",
                ],
                gaps=[
                    "Transitive dependency tracking incomplete",
                    "No SBOM for all development dependencies",
                ],
                remediation_timeline="Q1 2025",
            ),
            SSdFEvidence(
                practice_code="PS2.1",
                practice_name="Implement configuration management",
                maturity_level="Partial",
                evidence_items=[
                    "Container image configuration documented",
                    "TLS cipher suite baseline defined",
                    "OpenSSL configuration hardening in place",
                ],
                gaps=[
                    "No automated compliance scanning for configs",
                    "Legacy services exempt from config policy",
                ],
                remediation_timeline="Q2 2025",
            ),
            SSdFEvidence(
                practice_code="PS3.1",
                practice_name="Perform sensitive data protection",
                maturity_level="Weak",
                evidence_items=[
                    "Shadow data discovery completed (Module 5.3)",
                    "Encryption inventory in place",
                ],
                gaps=[
                    "Missing PII classification policy",
                    "Re-encryption with PQC not yet started",
                    "No data minimization processes",
                ],
                remediation_timeline="Q1-Q3 2025",
            ),
            SSdFEvidence(
                practice_code="PO3.2",
                practice_name="Publish software supply chain risk information",
                maturity_level="Weak",
                evidence_items=[
                    "Threat intelligence feeds aggregated (Module 5.4)",
                ],
                gaps=[
                    "No SCA reports shared with stakeholders",
                    "No incident disclosure process",
                ],
                remediation_timeline="Q2 2025",
            ),
        ]
        self.ssdf_practices = practices
        return practices
    
    def sbom_minimum_checklist(self) -> Dict:
        """NTIA SBOM minimum elements checklist"""
        return {
            "component_analysis": {
                "name": "Component Name",
                "implemented": True,
                "sample_data": ["cryptography", "openssl", "express"],
            },
            "version": {
                "name": "Component Version",
                "implemented": True,
                "sample_data": ["41.0.0", "3.0.10", "4.18.0"],
            },
            "supplier": {
                "name": "Supplier/Author",
                "implemented": True,
                "sample_data": ["PyPA", "Debian", "Node.js Foundation"],
            },
            "component_hash": {
                "name": "Component Hash",
                "implemented": True,
                "sample_data": ["SHA-256: a1b2c3d4e5f6..."],
            },
            "licenses": {
                "name": "Licenses",
                "implemented": True,
                "sample_data": ["Apache-2.0", "MIT", "PostgreSQL"],
            },
            "known_vulnerabilities": {
                "name": "Known Vulnerabilities",
                "implemented": True,
                "sample_data": ["CVE-2024-45678", "GHSA-xxxx-yyyy-zzzz"],
            },
        }
    
    def generate_compliance_pack(self, standards: List[str] = None) -> Dict:
        """Generate complete compliance evidence pack"""
        if standards is None:
            standards = ["sbom", "ssdf"]
        
        pack = {
            "generated_at": datetime.datetime.utcnow().isoformat(),
            "standards_assessed": standards,
            "artifacts": [],
        }
        
        if "sbom" in standards:
            pack["sbom_cyclonedx"] = self.generate_sbom("cyclonedx")
            pack["sbom_spdx"] = self.generate_sbom("spdx")
            pack["sbom_minimum_checklist"] = self.sbom_minimum_checklist()
            pack["artifacts"].append("sbom_cyclonedx.json")
            pack["artifacts"].append("sbom_spdx.json")
            pack["artifacts"].append("sbom_minimum_elements_checklist.json")
        
        if "ssdf" in standards:
            pack["ssdf_practices"] = [asdict(p) for p in self.map_ssdf_practices()]
            pack["ssdf_assessment_summary"] = {
                "practices_assessed": 5,
                "practices_progressing": 1,
                "practices_partial": 2,
                "practices_weak": 2,
                "overall_maturity": "Partial (avg 2.2/4)",
            }
            pack["artifacts"].append("ssdf_mapping.json")
        
        # Overall attestations
        attestations = [
            ComplianceAttestation(
                standard="SBOM-Minimum",
                assessed_date=datetime.datetime.utcnow().isoformat(),
                attestation_status="Passing",
                coverage_percent=100.0,
                auditor_notes="All NTIA minimum elements present",
            ),
            ComplianceAttestation(
                standard="NIST SSDF",
                assessed_date=datetime.datetime.utcnow().isoformat(),
                attestation_status="Partial",
                coverage_percent=55.0,
                auditor_notes="Practices PO1, PO2, PS2 partially met. PS3, PO3 weak.",
            ),
        ]
        pack["attestations"] = [asdict(a) for a in attestations]
        pack["artifacts"].append("compliance_pack.zip")
        
        return pack
