"""
CHRONOS Module 6: REPORT - Part 6.1: Executive Dashboard Engine
Live, executive-friendly dashboards showing trends, risk posture, and next actions.
"""

import datetime
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from enum import Enum


class RiskLevel(Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


@dataclass
class ReadinessSnapshot:
    """Point-in-time quantum readiness measurement"""
    timestamp: str
    score: int  # 0-1000
    quantum_safe_pct: float
    exposed_assets: int
    mitigated_assets: int


@dataclass
class BusinessRisk:
    """Risk framed in business impact"""
    risk_id: str
    title: str
    business_impact: str
    affected_asset_count: int
    exposure_type: str  # internet-facing, internal, data
    recommended_action: str
    priority_rank: int


@dataclass
class MigrationMetric:
    """PQC migration progress"""
    component_type: str  # crypto, tls, keys, docs
    total: int
    migrated: int
    percent_complete: float
    timeline_days: int


class ExecutiveDashboardEngineSimulatorPart61:
    """Executive dashboard with readiness scores, trends, heatmaps"""
    
    def __init__(self):
        self.snapshots: List[ReadinessSnapshot] = []
        self.top_risks: List[BusinessRisk] = []
        self.migration_progress: List[MigrationMetric] = []
        self.last_generated = None
    
    def generate_readiness_timeline(self, days: int = 90) -> List[ReadinessSnapshot]:
        """Generate readiness score timeline for timeframe"""
        snapshots = []
        base_score = 445
        
        for i in range(days):
            date = (datetime.datetime.utcnow() - datetime.timedelta(days=days-i)).isoformat()
            # Simulate gradual improvement
            score = int(base_score + (i / days) * 42)
            snapshots.append(ReadinessSnapshot(
                timestamp=date,
                score=score,
                quantum_safe_pct=25.0 + (i / days) * 8.5,
                exposed_assets=156 - int(i * 0.5),
                mitigated_assets=int(i * 0.8),
            ))
        
        self.snapshots = snapshots
        return snapshots
    
    def identify_top_business_risks(self) -> List[BusinessRisk]:
        """Identify top risks by business impact"""
        risks = [
            BusinessRisk(
                risk_id="BR-001",
                title="External APIs using RSA/ECC certs (HNDL exposure)",
                business_impact="Customer TLS sessions at harvest-now-decrypt-later risk",
                affected_asset_count=8,
                exposure_type="internet-facing",
                recommended_action="Rotate certs to hybrid PQC, implement cert pinning",
                priority_rank=1,
            ),
            BusinessRisk(
                risk_id="BR-002",
                title="Containers pinned to OpenSSL 1.1.x",
                business_impact="3 critical services running vulnerable OpenSSL in production",
                affected_asset_count=12,
                exposure_type="internet-facing",
                recommended_action="Upgrade to OpenSSL 3.x with FIPS 203 support",
                priority_rank=2,
            ),
            BusinessRisk(
                risk_id="BR-003",
                title="Shadow backups containing PII with RSA wrapping",
                business_impact="1.3TB encrypted customer data exposed if wrapped key is recovered post-quantum",
                affected_asset_count=147,
                exposure_type="data",
                recommended_action="Re-encrypt with ML-KEM, secure key disposal",
                priority_rank=3,
            ),
        ]
        self.top_risks = risks
        return risks
    
    def track_migration_progress(self) -> List[MigrationMetric]:
        """Track PQC migration progress by component"""
        progress = [
            MigrationMetric(
                component_type="cryptographic_libraries",
                total=18,
                migrated=3,
                percent_complete=16.7,
                timeline_days=120,
            ),
            MigrationMetric(
                component_type="tls_certificates",
                total=43,
                migrated=7,
                percent_complete=16.3,
                timeline_days=180,
            ),
            MigrationMetric(
                component_type="key_material",
                total=56,
                migrated=12,
                percent_complete=21.4,
                timeline_days=240,
            ),
            MigrationMetric(
                component_type="documentation",
                total=34,
                migrated=8,
                percent_complete=23.5,
                timeline_days=90,
            ),
        ]
        self.migration_progress = progress
        return progress
    
    def heatmap_data(self) -> Dict:
        """Generate heatmap data: internet-facing vs internal, data sensitivity"""
        return {
            "internet_facing_high_data": 8,
            "internet_facing_medium_data": 15,
            "internet_facing_low_data": 22,
            "internal_high_data": 12,
            "internal_medium_data": 34,
            "internal_low_data": 89,
            "quantum_safe_coverage": {
                "internet_facing_high": 25,
                "internet_facing_medium": 10,
                "internet_facing_low": 32,
                "internal_high": 40,
                "internal_medium": 15,
                "internal_low": 20,
            }
        }
    
    def generate_dashboard(self, timeframe_days: int = 90) -> Dict:
        """Generate complete dashboard snapshot"""
        self.generate_readiness_timeline(timeframe_days)
        risks = self.identify_top_business_risks()
        migration = self.track_migration_progress()
        heatmap = self.heatmap_data()
        
        current_score = self.snapshots[-1].score if self.snapshots else 487
        trend_change = current_score - 445  # vs 90 days ago
        
        self.last_generated = datetime.datetime.utcnow().isoformat()
        
        return {
            "generated_at": self.last_generated,
            "quantum_readiness_score": current_score,
            "score_grade": "C" if current_score < 500 else "B" if current_score < 700 else "A",
            "trend_90d": trend_change,
            "top_business_risks": [asdict(r) for r in risks],
            "migration_progress": [asdict(m) for m in migration],
            "heatmap": heatmap,
            "next_7day_actions": [
                "Rotate internet-facing certs (priority services)",
                "Upgrade base images (highest traffic first)",
                "Contain shadow DB + investigate leakage",
            ],
            "readiness_timeline_sample": [
                asdict(self.snapshots[0]),
                asdict(self.snapshots[-1]),
            ] if self.snapshots else [],
        }
