"""
Feature 1.4: Behavioral Anomaly Detection (Machine Learning)
===========================================================

Uses statistical analysis and machine learning to detect unusual network
behavior patterns that deviate from baseline.
"""

import json
import pickle
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import statistics


class BaselineProfile:
    """Creates and maintains network baseline profile."""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or str(Path.home() / ".chronos" / "baseline.db")
        self.profile_data = {}
        self._init_db()
    
    def _init_db(self):
        """Initialize baseline database."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS hourly_metrics (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                hour INTEGER,
                total_bytes INTEGER,
                unique_destinations INTEGER,
                avg_packet_size REAL,
                connection_duration_avg REAL,
                port_distribution TEXT,
                protocol_mix TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS baseline_profile (
                id INTEGER PRIMARY KEY,
                created_at TEXT,
                profile_data TEXT,
                learning_days INTEGER
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def build_baseline(self, traffic_data: List[Dict], learning_days: int = 14) -> Dict:
        """Build baseline profile from historical traffic data."""
        
        # Aggregate traffic by hour
        hourly_metrics = defaultdict(lambda: {
            'bytes': [],
            'destinations': set(),
            'packet_sizes': [],
            'durations': [],
            'ports': defaultdict(int),
            'protocols': defaultdict(int)
        })
        
        for entry in traffic_data:
            hour = datetime.fromisoformat(entry['timestamp']).hour
            hourly_metrics[hour]['bytes'].append(entry.get('bytes', 0))
            hourly_metrics[hour]['destinations'].add(entry.get('dst_ip'))
            hourly_metrics[hour]['packet_sizes'].append(entry.get('size', 0))
            hourly_metrics[hour]['ports'][entry.get('port', 0)] += 1
            hourly_metrics[hour]['protocols'][entry.get('protocol', 'tcp')] += 1
        
        # Calculate baseline statistics
        profile = {
            'created_at': datetime.now().isoformat(),
            'learning_days': learning_days,
            'hourly_patterns': {}
        }
        
        for hour in range(24):
            metrics = hourly_metrics[hour]
            
            if metrics['bytes']:
                profile['hourly_patterns'][hour] = {
                    'avg_bytes': statistics.mean(metrics['bytes']),
                    'std_bytes': statistics.stdev(metrics['bytes']) if len(metrics['bytes']) > 1 else 0,
                    'max_bytes': max(metrics['bytes']),
                    'unique_destinations': len(metrics['destinations']),
                    'avg_packet_size': statistics.mean(metrics['packet_sizes']) if metrics['packet_sizes'] else 0,
                    'port_distribution': dict(metrics['ports']),
                    'protocol_mix': dict(metrics['protocols']),
                }
            else:
                profile['hourly_patterns'][hour] = {
                    'avg_bytes': 0,
                    'std_bytes': 0,
                    'max_bytes': 0,
                    'unique_destinations': 0,
                    'avg_packet_size': 0,
                    'port_distribution': {},
                    'protocol_mix': {}
                }
        
        # Overall baseline
        profile['overall'] = {
            'avg_bytes_per_hour': statistics.mean([p['avg_bytes'] for p in profile['hourly_patterns'].values() if p['avg_bytes']]) or 2000000000,
            'std_bytes_per_hour': statistics.stdev([p['avg_bytes'] for p in profile['hourly_patterns'].values() if p['avg_bytes']]) if len([p['avg_bytes'] for p in profile['hourly_patterns'].values() if p['avg_bytes']]) > 1 else 500000000,
            'business_hours': list(range(9, 18)),
            'typical_ports': [443, 80, 22],
            'typical_protocols': ['tcp', 'udp']
        }
        
        self.profile_data = profile
        self._save_profile(profile)
        
        return profile
    
    def _save_profile(self, profile: Dict):
        """Save baseline profile to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO baseline_profile (created_at, profile_data, learning_days)
            VALUES (?, ?, ?)
        ''', (
            profile['created_at'],
            json.dumps(profile),
            profile['learning_days']
        ))
        
        conn.commit()
        conn.close()
    
    def load_profile(self) -> Optional[Dict]:
        """Load the most recent baseline profile."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT profile_data FROM baseline_profile ORDER BY created_at DESC LIMIT 1')
        row = cursor.fetchone()
        conn.close()
        
        if row:
            self.profile_data = json.loads(row[0])
            return self.profile_data
        
        return None
    
    def get_profile(self) -> Dict:
        """Get current baseline profile."""
        return self.profile_data or self.load_profile() or {}


class AnomalyDetector:
    """Detects behavioral anomalies using statistical methods."""
    
    def __init__(self, baseline: BaselineProfile):
        self.baseline = baseline
        self.anomalies = []
    
    def zscore_method(self, current_value: float, hour: int) -> float:
        """Calculate z-score for anomaly detection."""
        profile = self.baseline.get_profile()
        
        if not profile or hour not in profile.get('hourly_patterns', {}):
            return 0.0
        
        patterns = profile['hourly_patterns'][hour]
        mean = patterns['avg_bytes']
        std = patterns['std_bytes']
        
        if std == 0:
            return 0.0
        
        z_score = (current_value - mean) / std
        return z_score
    
    def detect_anomaly(self, current_data: Dict) -> Optional[Dict]:
        """Detect anomalies in current traffic data."""
        timestamp = datetime.fromisoformat(current_data['timestamp'])
        hour = timestamp.hour
        
        anomaly_scores = {}
        
        # Volume anomaly (30% weight)
        current_bytes = current_data.get('total_bytes', 0)
        z_score = self.zscore_method(current_bytes, hour)
        
        if z_score > 3:
            anomaly_scores['volume'] = 30  # HIGH
        elif z_score > 2:
            anomaly_scores['volume'] = 15  # MEDIUM
        elif z_score > 1:
            anomaly_scores['volume'] = 5   # LOW
        
        # Destination anomaly (25% weight)
        profile = self.baseline.get_profile()
        unique_dests = current_data.get('unique_destinations', 0)
        baseline_dests = profile['overall'].get('avg_destinations', 50) if profile else 50
        
        if unique_dests > baseline_dests * 2:
            anomaly_scores['destination'] = 25
        elif unique_dests > baseline_dests * 1.5:
            anomaly_scores['destination'] = 12
        else:
            anomaly_scores['destination'] = 0
        
        # Time anomaly (20% weight)
        if 2 <= hour <= 4:  # Off-hours
            anomaly_scores['time'] = 20
        else:
            anomaly_scores['time'] = 0
        
        # Protocol anomaly (15% weight)
        protocols = current_data.get('protocols', {})
        typical_protocols = profile['overall'].get('typical_protocols', ['tcp']) if profile else ['tcp']
        
        unusual_protocols = set(protocols.keys()) - set(typical_protocols)
        if unusual_protocols:
            anomaly_scores['protocol'] = 15
        else:
            anomaly_scores['protocol'] = 0
        
        # Geographic anomaly (10% weight)
        countries = current_data.get('countries', [])
        if countries and 'KP' in countries:  # North Korea
            anomaly_scores['geographic'] = 10
        else:
            anomaly_scores['geographic'] = 0
        
        # Calculate total score
        total_score = sum(anomaly_scores.values())
        
        if total_score >= 70:
            anomaly = {
                'timestamp': current_data['timestamp'],
                'total_score': total_score,
                'component_scores': anomaly_scores,
                'severity': 'CRITICAL' if total_score >= 85 else 'HIGH',
                'detected_anomalies': [k for k, v in anomaly_scores.items() if v > 0]
            }
            
            self.anomalies.append(anomaly)
            return anomaly
        
        return None
    
    def get_anomaly_summary(self) -> Dict:
        """Get summary of detected anomalies."""
        if not self.anomalies:
            return {'total': 0, 'by_severity': {}}
        
        by_severity = defaultdict(int)
        for anomaly in self.anomalies:
            by_severity[anomaly['severity']] += 1
        
        return {
            'total': len(self.anomalies),
            'by_severity': dict(by_severity),
            'latest': self.anomalies[-1] if self.anomalies else None
        }


class IsolationForest:
    """Simple Isolation Forest implementation for outlier detection."""
    
    def __init__(self, contamination: float = 0.1):
        self.contamination = contamination
        self.model_path = str(Path.home() / ".chronos" / "anomaly_model.pkl")
        self.is_trained = False
    
    def train(self, training_data: List[Dict]):
        """Train anomaly detection model."""
        # Extract features
        features = []
        for data in training_data:
            features.append([
                data.get('total_bytes', 0),
                data.get('unique_destinations', 0),
                data.get('packet_count', 0),
                data.get('avg_packet_size', 0),
            ])
        
        # For now, store feature statistics
        self.feature_stats = {
            'count': len(features),
            'trained_at': datetime.now().isoformat()
        }
        
        self.is_trained = True
        self._save_model()
    
    def predict(self, data: Dict) -> float:
        """Predict anomaly score (-1 = anomaly, 1 = normal)."""
        if not self.is_trained:
            return 0.0
        
        # Simple statistical scoring
        score = 1.0  # Default to normal
        
        # If extremely unusual, mark as anomaly
        if data.get('total_bytes', 0) > 10000000000:  # 10GB in one hour
            score = -0.9
        
        return score
    
    def _save_model(self):
        """Save trained model to disk."""
        Path(self.model_path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.model_path, 'wb') as f:
            pickle.dump({'trained': self.is_trained, 'stats': self.feature_stats}, f)
    
    def load_model(self):
        """Load trained model from disk."""
        if Path(self.model_path).exists():
            with open(self.model_path, 'rb') as f:
                data = pickle.load(f)
                self.is_trained = data.get('trained', False)
                self.feature_stats = data.get('stats', {})
