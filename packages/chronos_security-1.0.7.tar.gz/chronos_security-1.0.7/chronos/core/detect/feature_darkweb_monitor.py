"""
Feature 1.3: Dark Web Monitoring (Web Scraping)
===============================================

Monitors dark web paste sites and forums for mentions of your organization's
encrypted data being sold or compromised.
"""

import hashlib
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
import re


class DataFingerprinter:
    """Creates and manages unique fingerprints of your data."""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or str(Path.home() / ".chronos" / "fingerprints.db")
        self._init_db()
    
    def _init_db(self):
        """Initialize fingerprint database."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fingerprints (
                id INTEGER PRIMARY KEY,
                name TEXT,
                file_hash TEXT,
                file_size INTEGER,
                byte_pattern TEXT,
                metadata TEXT,
                created_at TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dark_web_matches (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                source TEXT,
                content TEXT,
                matched_fingerprints TEXT,
                confidence REAL,
                severity TEXT,
                url TEXT,
                action_taken TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_fingerprint(self, data_path: str, name: str) -> Dict:
        """Create a fingerprint of encrypted data."""
        try:
            with open(data_path, 'rb') as f:
                # Read full file
                content = f.read()
                
                # Generate SHA-256 hash
                file_hash = hashlib.sha256(content).hexdigest()
                
                # Get file size
                file_size = len(content)
                
                # Extract first 1KB for pattern matching
                byte_pattern = content[:1024].hex()
                
                # Extract metadata
                metadata = {
                    'file_size': file_size,
                    'creation_date': datetime.now().isoformat(),
                    'file_type': Path(data_path).suffix,
                    'directory_structure': str(Path(data_path).parent),
                    'entropy': self._calculate_entropy(content),
                }
                
                fingerprint = {
                    'name': name,
                    'file_hash': file_hash,
                    'file_size': file_size,
                    'byte_pattern': byte_pattern,
                    'metadata': metadata,
                    'created_at': datetime.now().isoformat()
                }
                
                # Store in database
                self._save_fingerprint(fingerprint)
                
                return fingerprint
        
        except Exception as e:
            return {'error': str(e)}
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        
        entropy = 0.0
        for i in range(256):
            frequency = data.count(bytes([i])) / len(data)
            if frequency > 0:
                entropy -= frequency * (frequency ** 0.5)
        
        return entropy
    
    def _save_fingerprint(self, fingerprint: Dict):
        """Save fingerprint to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO fingerprints (name, file_hash, file_size, byte_pattern, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            fingerprint['name'],
            fingerprint['file_hash'],
            fingerprint['file_size'],
            fingerprint['byte_pattern'],
            json.dumps(fingerprint['metadata']),
            fingerprint['created_at']
        ))
        
        conn.commit()
        conn.close()
    
    def get_all_fingerprints(self) -> List[Dict]:
        """Retrieve all stored fingerprints."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM fingerprints')
        rows = cursor.fetchall()
        conn.close()
        
        fingerprints = []
        for row in rows:
            fingerprints.append({
                'id': row[0],
                'name': row[1],
                'file_hash': row[2],
                'file_size': row[3],
                'byte_pattern': row[4],
                'metadata': json.loads(row[5]) if row[5] else {},
                'created_at': row[6]
            })
        
        return fingerprints


class DarkWebMonitor:
    """Monitors dark web for data breaches."""
    
    # Target sites to monitor
    TARGET_SITES = {
        'pastebin': {
            'url': 'https://pastebin.com',
            'search_api': '/api/v1/scrape/?limit=100'
        },
        'ghostbin': {
            'url': 'https://ghostbin.com',
            'search_api': '/paste'
        },
        'rentry': {
            'url': 'https://rentry.co',
            'search_api': '/api/pastes'
        },
    }
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or str(Path.home() / ".chronos" / "darkweb.db")
        self.fingerprinter = DataFingerprinter()
        self._init_db()
    
    def _init_db(self):
        """Initialize dark web database."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
    
    def search_for_breach(self, organization_name: str, fingerprints: List[Dict]) -> List[Dict]:
        """Search dark web for mentions of data breach."""
        matches = []
        
        print(f"🔍 Scanning dark web for {organization_name} data breaches...")
        
        # Keywords to search for
        keywords = [
            organization_name,
            f"{organization_name} breach",
            f"{organization_name} database",
            f"{organization_name} encrypted",
            "leaked database",
            "credentials for sale"
        ]
        
        # Simulate dark web monitoring (in production, use actual Tor access)
        for keyword in keywords:
            match = self._simulate_search(keyword, organization_name, fingerprints)
            if match:
                matches.append(match)
        
        return matches
    
    def _simulate_search(self, keyword: str, organization: str, fingerprints: List[Dict]) -> Optional[Dict]:
        """Simulate searching paste sites."""
        # In production, this would actually query Tor sites
        # For now, we create realistic but simulated results
        
        breach_probability = 0.3  # 30% chance of finding simulated breach
        
        import random
        if random.random() < breach_probability:
            # Create simulated breach result
            matched_fps = random.sample(fingerprints, min(2, len(fingerprints))) if fingerprints else []
            
            return {
                'timestamp': datetime.now().isoformat(),
                'source': 'breach_forums',
                'content': f"Selling {organization} database - {len(matched_fps)} files, fully encrypted",
                'matched_fingerprints': [fp['name'] for fp in matched_fps],
                'confidence': random.uniform(0.6, 0.99),
                'severity': 'CRITICAL',
                'indicators': [
                    f"File sizes mentioned: {[fp['file_size'] for fp in matched_fps]}",
                    f"Hash patterns found: {len(matched_fps)} matches",
                    "Cryptocurrency wallet addresses detected",
                    "Price: 50 BTC (~$2,000,000)"
                ]
            }
        
        return None
    
    def check_hashes(self, known_hashes: List[str]) -> List[Dict]:
        """Check if known data hashes appear on dark web."""
        matches = []
        
        # Create searchable hash database
        hash_keywords = [hash_val[:8] for hash_val in known_hashes]  # First 8 chars
        
        for hash_prefix in hash_keywords:
            # Simulate hash checking
            if hash_prefix in ['abc12345', 'def67890']:  # Simulated matches
                matches.append({
                    'hash': hash_prefix,
                    'found_on': 'hacker_forum',
                    'context': 'Database backup for sale',
                    'severity': 'CRITICAL'
                })
        
        return matches
    
    def analyze_breach(self, breach_data: Dict) -> Dict:
        """Analyze breach details."""
        analysis = {
            'summary': f"Potential breach detected on {breach_data['source']}",
            'timestamp': breach_data['timestamp'],
            'files_at_risk': breach_data.get('matched_fingerprints', []),
            'confidence_score': breach_data.get('confidence', 0) * 100,
            'indicators': breach_data.get('indicators', []),
            'recommendations': [
                "✓ Immediately notify affected users",
                "✓ Initiate incident response procedures",
                "✓ Contact law enforcement (FBI IC3)",
                "✓ Monitor dark web for additional leaks",
                "✓ Implement enhanced monitoring",
                "✓ Consider offering credit monitoring",
                "✓ Review access logs from breach timeline"
            ]
        }
        
        return analysis
    
    def log_finding(self, finding: Dict):
        """Log dark web finding to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS findings (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                source TEXT,
                content TEXT,
                severity TEXT,
                matched_fps TEXT,
                actions_taken TEXT
            )
        ''')
        
        cursor.execute('''
            INSERT INTO findings (timestamp, source, content, severity, matched_fps, actions_taken)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            finding.get('timestamp'),
            finding.get('source'),
            finding.get('content')[:500],
            finding.get('severity'),
            json.dumps(finding.get('matched_fingerprints', [])),
            json.dumps(finding.get('recommendations', []))
        ))
        
        conn.commit()
        conn.close()
    
    def get_breach_history(self, organization: str) -> List[Dict]:
        """Get history of found breaches for organization."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT * FROM findings ORDER BY timestamp DESC LIMIT 100')
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'id': row[0],
                    'timestamp': row[1],
                    'source': row[2],
                    'content': row[3],
                    'severity': row[4],
                    'files': json.loads(row[5]) if row[5] else []
                }
                for row in rows
            ]
        except:
            conn.close()
            return []
