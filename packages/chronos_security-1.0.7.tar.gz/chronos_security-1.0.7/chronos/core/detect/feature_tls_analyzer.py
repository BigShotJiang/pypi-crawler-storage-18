"""
Feature 1.2: TLS/SSL Cipher Suite Analyzer
==========================================

Analyzes TLS handshakes to identify encryption algorithms and detect
quantum-vulnerable cipher suites.
"""

import ssl
import socket
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CipherSuiteInfo:
    """Information about a cipher suite."""
    cipher_name: str
    key_exchange: str
    encryption: str
    key_size: int
    is_quantum_vulnerable: bool
    severity: str
    break_year: Optional[int] = None


class TLSCipherAnalyzer:
    """Analyzes TLS cipher suites for quantum vulnerabilities."""
    
    # Quantum-vulnerable ciphers
    QUANTUM_VULNERABLE = {
        'RSA': {'severity': 'CRITICAL', 'break_year': 2033},
        'ECDHE': {'severity': 'CRITICAL', 'break_year': 2035},
        'ECDSA': {'severity': 'CRITICAL', 'break_year': 2035},
        'DSS': {'severity': 'CRITICAL', 'break_year': 2032},
    }
    
    # Post-quantum safe algorithms
    QUANTUM_SAFE = {
        'Kyber': {'severity': 'SAFE', 'break_year': None},
        'Dilithium': {'severity': 'SAFE', 'break_year': None},
        'FALCON': {'severity': 'SAFE', 'break_year': None},
        'SPHINCS': {'severity': 'SAFE', 'break_year': None},
    }
    
    # Partial vulnerabilities
    PARTIAL_VULNERABLE = {
        'AES-GCM': {'severity': 'MEDIUM', 'break_year': 2045},  # Grover's attack
    }
    
    def __init__(self):
        self.analyzed_hosts = {}
    
    def analyze_host(self, hostname: str, port: int = 443) -> Optional[Dict]:
        """Analyze TLS configuration of a host."""
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((hostname, port), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    # Get certificate
                    cert = ssock.getpeercert_bin()
                    cert_dict = ssock.getpeercert()
                    
                    # Get cipher info
                    cipher = ssock.cipher()
                    
                    analysis = {
                        'hostname': hostname,
                        'port': port,
                        'tls_version': ssock.version(),
                        'cipher_suite': cipher[0],
                        'protocol_version': cipher[1],
                        'cipher_bits': cipher[2],
                        'certificate_subject': dict(x[0] for x in cert_dict.get('subject', [])) if cert_dict else {},
                        'certificate_issuer': dict(x[0] for x in cert_dict.get('issuer', [])) if cert_dict else {},
                    }
                    
                    # Analyze cipher vulnerability
                    cipher_analysis = self._analyze_cipher(cipher[0], cipher[2])
                    analysis.update(cipher_analysis)
                    
                    self.analyzed_hosts[hostname] = analysis
                    return analysis
        
        except Exception as e:
            return {
                'hostname': hostname,
                'port': port,
                'error': str(e),
                'status': 'UNREACHABLE'
            }
    
    def _analyze_cipher(self, cipher_name: str, key_size: int) -> Dict:
        """Analyze a cipher suite for vulnerabilities."""
        result = {
            'is_quantum_vulnerable': False,
            'severity': 'SAFE',
            'estimated_break_year': None,
            'recommendation': 'No action needed',
            'details': []
        }
        
        cipher_upper = cipher_name.upper()
        
        # Check quantum vulnerable algorithms
        for vuln_algo, info in self.QUANTUM_VULNERABLE.items():
            if vuln_algo in cipher_upper:
                result['is_quantum_vulnerable'] = True
                result['severity'] = info['severity']
                result['estimated_break_year'] = info['break_year']
                result['details'].append(f"Uses {vuln_algo} key exchange - QUANTUM VULNERABLE")
                result['recommendation'] = 'MIGRATE to post-quantum cryptography (Kyber, Dilithium)'
                return result
        
        # Check partial vulnerabilities
        for partial_algo, info in self.PARTIAL_VULNERABLE.items():
            if partial_algo in cipher_upper:
                result['is_quantum_vulnerable'] = True
                result['severity'] = info['severity']
                result['estimated_break_year'] = info['break_year']
                result['details'].append(f"Uses {partial_algo} - vulnerable to Grover's algorithm")
                result['recommendation'] = 'Increase key sizes and plan migration'
                return result
        
        # Check if quantum-safe
        for safe_algo in self.QUANTUM_SAFE.keys():
            if safe_algo in cipher_upper:
                result['severity'] = 'SAFE'
                result['details'].append(f"Uses post-quantum {safe_algo}")
                result['recommendation'] = 'This cipher is quantum-resistant'
                return result
        
        # Check key size adequacy
        if key_size >= 256:
            result['details'].append(f"Key size: {key_size} bits (adequate)")
        elif key_size >= 128:
            result['details'].append(f"Key size: {key_size} bits (minimum acceptable)")
        else:
            result['severity'] = 'HIGH'
            result['details'].append(f"Key size: {key_size} bits (WEAK)")
            result['recommendation'] = 'Increase key size to at least 256 bits'
        
        return result
    
    def get_certificate_info(self, hostname: str, port: int = 443) -> Optional[Dict]:
        """Extract detailed certificate information."""
        analysis = self.analyzed_hosts.get(hostname)
        if not analysis:
            analysis = self.analyze_host(hostname, port)
        
        if 'error' in analysis:
            return None
        
        return {
            'subject': analysis.get('certificate_subject', {}),
            'issuer': analysis.get('certificate_issuer', {}),
            'tls_version': analysis.get('tls_version'),
            'cipher': analysis.get('cipher_suite'),
            'bits': analysis.get('cipher_bits'),
            'quantum_vulnerable': analysis.get('is_quantum_vulnerable'),
        }
    
    def generate_report(self) -> List[Dict]:
        """Generate report of all analyzed hosts."""
        reports = []
        
        for hostname, analysis in self.analyzed_hosts.items():
            if 'error' not in analysis:
                report = {
                    'target': f"{hostname}:443",
                    'cipher': analysis['cipher_suite'],
                    'key_size': f"{analysis['cipher_bits']} bits",
                    'status': '🚨 QUANTUM VULNERABLE' if analysis['is_quantum_vulnerable'] else '✓ SAFE',
                    'estimated_break_year': analysis.get('estimated_break_year'),
                    'recommendation': analysis['recommendation'],
                    'details': ', '.join(analysis['details'])
                }
                reports.append(report)
        
        return reports
    
    def batch_analyze(self, hosts: List[Tuple[str, int]]) -> Dict:
        """Analyze multiple hosts."""
        results = {
            'total': len(hosts),
            'quantum_vulnerable': 0,
            'safe': 0,
            'hosts': []
        }
        
        for hostname, port in hosts:
            analysis = self.analyze_host(hostname, port)
            if analysis and 'error' not in analysis:
                results['hosts'].append(analysis)
                if analysis.get('is_quantum_vulnerable'):
                    results['quantum_vulnerable'] += 1
                else:
                    results['safe'] += 1
        
        return results
