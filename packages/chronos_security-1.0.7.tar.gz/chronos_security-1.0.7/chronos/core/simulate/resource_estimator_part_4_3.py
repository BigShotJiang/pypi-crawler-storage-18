"""
PART 4.3: Quantum Resource Estimator - Complete Standalone Implementation

Features:
  4.3.1: Per-System Calculator
  4.3.2: Hardware Capability Tracker
  4.3.3: Comparison Table Generator
  4.3.4: Cost-Time Tradeoff Calculator

Calculates exact quantum resources needed to break specific cryptographic systems.
"""

import math
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
from datetime import datetime
from enum import Enum


class CryptoAlgorithm(Enum):
    """Supported cryptographic algorithms"""
    RSA_1024 = "RSA-1024"
    RSA_2048 = "RSA-2048"
    RSA_4096 = "RSA-4096"
    ECC_256 = "ECC-256"
    ECC_384 = "ECC-384"
    AES_128 = "AES-128"
    AES_256 = "AES-256"
    KYBER_768 = "Kyber-768"
    KYBER_1024 = "Kyber-1024"
    DILITHIUM_3 = "Dilithium-3"


@dataclass
class AlgorithmSpec:
    """Specification for quantum breaking requirements"""
    algorithm: CryptoAlgorithm
    logical_qubits: int
    physical_qubits: int  # With error correction overhead
    quantum_gates: int
    break_year_optimistic: int
    break_year_realistic: int
    break_year_pessimistic: int
    is_quantum_safe: bool
    risk_level: str  # CRITICAL, HIGH, MEDIUM, LOW, SAFE
    
    def break_year(self, scenario: str = "realistic") -> int:
        """Get break year for scenario"""
        if scenario == "optimistic":
            return self.break_year_optimistic
        elif scenario == "pessimistic":
            return self.break_year_pessimistic
        else:  # realistic
            return self.break_year_realistic


@dataclass
class SystemRequirements:
    """Resources to break a specific system"""
    system_id: str
    system_name: str
    algorithm: CryptoAlgorithm
    algorithm_spec: AlgorithmSpec
    logical_qubits: int
    physical_qubits: int
    gate_count: int
    estimated_time_2024: str  # "IMPOSSIBLE", "100 years", etc.
    estimated_time_2030: str
    estimated_time_2035: str
    break_probability_by_year: Dict[int, float]
    critical_year: int  # When break becomes likely (>50%)
    data_at_risk_usd: float
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON export"""
        return {
            "system_id": self.system_id,
            "system_name": self.system_name,
            "algorithm": self.algorithm.value,
            "logical_qubits": self.logical_qubits,
            "physical_qubits": self.physical_qubits,
            "gate_count": self.gate_count,
            "critical_year": self.critical_year,
            "data_at_risk": self.data_at_risk_usd,
        }


@dataclass
class HardwareCapability:
    """Current quantum computer capability"""
    name: str
    manufacturer: str
    qubits: int
    error_rate: float  # Per-gate error rate
    gate_time_ns: float
    quantum_volume: int
    release_year: int
    technology: str  # "superconducting", "trapped-ion", "photonic", etc.


@dataclass
class MigrationScenario:
    """Cost-time tradeoff for migration"""
    name: str
    duration_months: int
    systems_per_month: int
    team_size: int
    cost_usd: float
    risk_avoided_percent: float
    pros: List[str]
    cons: List[str]
    expected_value: float  # Cost - (Risk × Breach Cost)


class QuantumResourceDatabase:
    """Database of algorithm specifications"""
    
    ALGORITHMS: Dict[CryptoAlgorithm, AlgorithmSpec] = {
        CryptoAlgorithm.RSA_1024: AlgorithmSpec(
            algorithm=CryptoAlgorithm.RSA_1024,
            logical_qubits=2098,
            physical_qubits=2098000,
            quantum_gates=int(1e11),
            break_year_optimistic=2027,
            break_year_realistic=2029,
            break_year_pessimistic=2032,
            is_quantum_safe=False,
            risk_level="🚨 CRITICAL"
        ),
        CryptoAlgorithm.RSA_2048: AlgorithmSpec(
            algorithm=CryptoAlgorithm.RSA_2048,
            logical_qubits=4098,
            physical_qubits=4098000,
            quantum_gates=int(1.2e12),
            break_year_optimistic=2031,
            break_year_realistic=2035,
            break_year_pessimistic=2038,
            is_quantum_safe=False,
            risk_level="🚨 CRITICAL"
        ),
        CryptoAlgorithm.RSA_4096: AlgorithmSpec(
            algorithm=CryptoAlgorithm.RSA_4096,
            logical_qubits=8198,
            physical_qubits=8198000,
            quantum_gates=int(1.2e13),
            break_year_optimistic=2035,
            break_year_realistic=2039,
            break_year_pessimistic=2042,
            is_quantum_safe=False,
            risk_level="⚠️  HIGH"
        ),
        CryptoAlgorithm.ECC_256: AlgorithmSpec(
            algorithm=CryptoAlgorithm.ECC_256,
            logical_qubits=2330,
            physical_qubits=2330000,
            quantum_gates=int(8e11),
            break_year_optimistic=2029,
            break_year_realistic=2032,
            break_year_pessimistic=2035,
            is_quantum_safe=False,
            risk_level="🚨 CRITICAL"
        ),
        CryptoAlgorithm.ECC_384: AlgorithmSpec(
            algorithm=CryptoAlgorithm.ECC_384,
            logical_qubits=3495,
            physical_qubits=3495000,
            quantum_gates=int(1.2e12),
            break_year_optimistic=2033,
            break_year_realistic=2036,
            break_year_pessimistic=2040,
            is_quantum_safe=False,
            risk_level="⚠️  HIGH"
        ),
        CryptoAlgorithm.AES_128: AlgorithmSpec(
            algorithm=CryptoAlgorithm.AES_128,
            logical_qubits=2200,
            physical_qubits=2200000,
            quantum_gates=int(1.8e23),
            break_year_optimistic=2045,
            break_year_realistic=2055,
            break_year_pessimistic=2065,
            is_quantum_safe=False,
            risk_level="⚠️  MEDIUM"
        ),
        CryptoAlgorithm.AES_256: AlgorithmSpec(
            algorithm=CryptoAlgorithm.AES_256,
            logical_qubits=2500,
            physical_qubits=2500000,
            quantum_gates=int(1.8e38),
            break_year_optimistic=2150,
            break_year_realistic=2200,
            break_year_pessimistic=2300,
            is_quantum_safe=True,
            risk_level="✅ SAFE"
        ),
        CryptoAlgorithm.KYBER_768: AlgorithmSpec(
            algorithm=CryptoAlgorithm.KYBER_768,
            logical_qubits=0,
            physical_qubits=0,
            quantum_gates=0,
            break_year_optimistic=2500,
            break_year_realistic=2500,
            break_year_pessimistic=2500,
            is_quantum_safe=True,
            risk_level="✅ SAFE"
        ),
        CryptoAlgorithm.KYBER_1024: AlgorithmSpec(
            algorithm=CryptoAlgorithm.KYBER_1024,
            logical_qubits=0,
            physical_qubits=0,
            quantum_gates=0,
            break_year_optimistic=2500,
            break_year_realistic=2500,
            break_year_pessimistic=2500,
            is_quantum_safe=True,
            risk_level="✅ SAFE"
        ),
        CryptoAlgorithm.DILITHIUM_3: AlgorithmSpec(
            algorithm=CryptoAlgorithm.DILITHIUM_3,
            logical_qubits=0,
            physical_qubits=0,
            quantum_gates=0,
            break_year_optimistic=2500,
            break_year_realistic=2500,
            break_year_pessimistic=2500,
            is_quantum_safe=True,
            risk_level="✅ SAFE"
        ),
    }


class ResourceEstimatorPart43:
    """FEATURE 4.3.1: Per-System Calculator"""
    
    def __init__(self):
        self.db = QuantumResourceDatabase()
    
    def estimate_system_requirements(
        self, 
        system_id: str,
        system_name: str,
        algorithm: CryptoAlgorithm,
        data_at_risk_usd: float = 1e6
    ) -> SystemRequirements:
        """Calculate quantum resources to break a system"""
        
        spec = self.db.ALGORITHMS[algorithm]
        
        # Break probability by year (sigmoid curve)
        break_prob = {}
        for year in range(2024, 2051):
            # Sigmoid function centered at realistic break year
            center = spec.break_year_realistic
            steepness = 0.3
            prob = 1.0 / (1.0 + math.exp(-steepness * (year - center)))
            break_prob[year] = prob
        
        # Find critical year (>50% probability)
        critical_year = next(
            (y for y, p in break_prob.items() if p > 0.5),
            2100
        )
        
        return SystemRequirements(
            system_id=system_id,
            system_name=system_name,
            algorithm=algorithm,
            algorithm_spec=spec,
            logical_qubits=spec.logical_qubits,
            physical_qubits=spec.physical_qubits,
            gate_count=spec.quantum_gates,
            estimated_time_2024="IMPOSSIBLE",
            estimated_time_2030="~1-3 weeks" if critical_year <= 2035 else "N/A",
            estimated_time_2035="~1-3 days" if critical_year <= 2040 else "N/A",
            break_probability_by_year=break_prob,
            critical_year=critical_year,
            data_at_risk_usd=data_at_risk_usd,
        )
    
    def format_system_report(self, req: SystemRequirements) -> str:
        """Format system requirements for display"""
        output = []
        output.append(f"╭─── {req.system_name} (ID: {req.system_id}) ─────────────────╮")
        output.append(f"│ Algorithm: {req.algorithm.value:<50} │")
        output.append("├──────────────────────────────────────────────────────────┤")
        output.append("│ TO BREAK THIS SYSTEM:                                    │")
        output.append(f"│   Logical Qubits: {req.logical_qubits:,}                                    │"[:60] + " │")
        output.append(f"│   Physical Qubits: {req.physical_qubits:,}                              │"[:60] + " │")
        output.append(f"│   Gate Operations: {req.gate_count:.1e}                            │"[:60] + " │")
        output.append(f"│   Time (2024 hardware): {req.estimated_time_2024:<36} │")
        output.append(f"│   Time (2030 hardware): {req.estimated_time_2030:<36} │")
        output.append(f"│   Time (2035 hardware): {req.estimated_time_2035:<36} │")
        output.append("│                                                          │")
        output.append("│ VULNERABILITY TIMELINE:                                  │")
        
        # Show probability timeline
        for year in [2028, 2030, 2033, 2035, 2038]:
            prob = req.break_probability_by_year.get(year, 0)
            marker = " ← CRITICAL" if year == req.critical_year else ""
            output.append(f"│   {year}: {prob*100:>5.0f}% chance{marker:<27} │")
        
        output.append("╰──────────────────────────────────────────────────────────╯")
        return "\n".join(output)


class HardwareTrackerPart432:
    """FEATURE 4.3.2: Hardware Capability Tracker"""
    
    CURRENT_SYSTEMS = [
        HardwareCapability("IBM Condor", "IBM", 1386, 1e-3, 35, 64, 2023, "superconducting"),
        HardwareCapability("Google Willow", "Google", 105, 2e-3, 20, 19, 2024, "superconducting"),
        HardwareCapability("IonQ Harmony", "IonQ", 11, 1e-3, 50, 5, 2021, "trapped-ion"),
        HardwareCapability("Rigetti Aspen", "Rigetti", 80, 5e-3, 40, 8, 2022, "superconducting"),
    ]
    
    @staticmethod
    def format_hardware_status() -> str:
        """Format current hardware capabilities"""
        output = []
        output.append("╭─────────────── Current Quantum Computer Landscape ──────────────╮")
        output.append(f"│ Last Updated: {datetime.now().strftime('%Y-%m-%d'):<50} │")
        output.append("├───────────────────────────────────────────────────────────────────┤")
        
        for hw in HardwareTrackerPart432.CURRENT_SYSTEMS:
            output.append(f"│ {hw.manufacturer:<20} {hw.name:<30} │")
            output.append(f"│   Qubits: {hw.qubits:<35} Error: {hw.error_rate:.0e} │"[:70] + " │")
        
        output.append("├───────────────────────────────────────────────────────────────────┤")
        output.append("│ GROWTH ANALYSIS:                                                  │")
        output.append("│   Qubit Count Doubling: Every 1.5 years (Moore's Law for quantum)│")
        output.append("│   Error Rate Improvement: 10× every 3 years                       │")
        output.append("│                                                                   │")
        output.append("│ PROJECTION FOR RSA-2048 BREAKING:                                │")
        output.append("│   Need: 4M physical qubits + <10^-6 error rate                   │")
        output.append("│   Qubit Milestone: ~2038 (14 years)                              │")
        output.append("│   Error Milestone: ~2031 (7 years)                               │")
        output.append("│   Both Met: ~2035-2038                                           │")
        output.append("│                                                                   │")
        output.append("│   CONSERVATIVE: 2033-2038                                        │")
        output.append("│   OPTIMISTIC: 2030-2033                                          │")
        output.append("│   PESSIMISTIC: 2038-2045                                         │")
        output.append("╰───────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


class ComparisonTablePart433:
    """FEATURE 4.3.3: Comparison Table Generator"""
    
    @staticmethod
    def format_comparison_table() -> str:
        """Format algorithm vulnerability comparison"""
        db = QuantumResourceDatabase()
        
        output = []
        output.append("╭────────────────────────── Algorithm Vulnerability Comparison ───────────────────────────╮")
        output.append("│ Algorithm    │ Key Size │ Logical  │ Physical    │ Operations │ Break Year  │ Risk Level  │")
        output.append("├──────────────┼──────────┼──────────┼─────────────┼────────────┼─────────────┼─────────────┤")
        
        algorithms = [
            (CryptoAlgorithm.RSA_1024, "1024"),
            (CryptoAlgorithm.RSA_2048, "2048"),
            (CryptoAlgorithm.RSA_4096, "4096"),
            (CryptoAlgorithm.ECC_256, "256"),
            (CryptoAlgorithm.ECC_384, "384"),
            (CryptoAlgorithm.AES_128, "128"),
            (CryptoAlgorithm.AES_256, "256"),
            (CryptoAlgorithm.KYBER_768, "768"),
            (CryptoAlgorithm.KYBER_1024, "1024"),
            (CryptoAlgorithm.DILITHIUM_3, "3"),
        ]
        
        for algo, key_size in algorithms:
            spec = db.ALGORITHMS[algo]
            algo_name = algo.value.split("-")[0]
            
            if spec.is_quantum_safe:
                break_year = "Quantum-safe"
                operations = "N/A"
            else:
                break_year = f"~{spec.break_year_realistic}"
                operations = f"{spec.quantum_gates:.0e}"
            
            output.append(f"│ {algo_name:<12} │ {key_size:>8} │ {spec.logical_qubits:>8,} │ {spec.physical_qubits:>11,} │ {operations:>10} │ {break_year:>11} │ {spec.risk_level:>11} │")
        
        output.append("╰────────────────────────────────────────────────────────────────────────────────────────╯")
        
        output.append("\n│ KEY INSIGHTS:")
        output.append("│   • RSA-1024: URGENT - Upgrade immediately")
        output.append("│   • RSA-2048: CRITICAL - Migrate within 3 years")
        output.append("│   • ECC-256: CRITICAL - Similar timeline to RSA-2048")
        output.append("│   • AES-128: CAUTION - Consider upgrading to AES-256")
        output.append("│   • AES-256: SAFE - Quantum-resistant for foreseeable future")
        output.append("│   • Kyber/Dilithium: SAFE - Post-quantum algorithms")
        
        return "\n".join(output)


class CostTimeTradePart434:
    """FEATURE 4.3.4: Cost-Time Tradeoff Calculator"""
    
    SCENARIOS = [
        MigrationScenario(
            name="Aggressive (12 months)",
            duration_months=12,
            systems_per_month=104,
            team_size=15,
            cost_usd=4.5e6,
            risk_avoided_percent=99,
            pros=["Maximum safety", "Done before threat", "No cutting corners"],
            cons=["Very expensive", "Resource intensive", "Unrealistic pace"],
            expected_value=0  # Calculated
        ),
        MigrationScenario(
            name="Balanced (36 months)",
            duration_months=36,
            systems_per_month=35,
            team_size=8,
            cost_usd=2.8e6,
            risk_avoided_percent=95,
            pros=["Reasonable cost", "Sufficient time buffer", "Realistic pace"],
            cons=["Some urgency required", "Medium risk if delayed"],
            expected_value=0  # Calculated
        ),
        MigrationScenario(
            name="Conservative (60 months)",
            duration_months=60,
            systems_per_month=21,
            team_size=5,
            cost_usd=2.1e6,
            risk_avoided_percent=75,
            pros=["Lowest cost", "Manageable pace", "Standard staffing"],
            cons=["Cutting it close to Q-Day", "Higher risk"],
            expected_value=0  # Calculated
        ),
        MigrationScenario(
            name="Delayed (wait until 2030)",
            duration_months=24,
            systems_per_month=52,
            team_size=20,
            cost_usd=6.2e6,
            risk_avoided_percent=40,
            pros=["Delayed spending"],
            cons=["HIGH RISK", "Much more expensive (+121%)", "Emergency staffing"],
            expected_value=0  # Calculated
        ),
    ]
    
    @staticmethod
    def format_migration_analysis(total_systems: int = 1247, breach_cost: float = 400e6) -> str:
        """Format migration cost-time analysis"""
        output = []
        output.append(f"╭─────────────────────── Migration Cost-Time Analysis ─────────────────────╮")
        output.append(f"│ Your Systems: {total_systems:,} (RSA-2048)                               │"[:73] + " │")
        output.append(f"│ Q-Day Estimate: 2033 (±3 years)                                       │")
        output.append("├──────────────────────────────────────────────────────────────────────────┤")
        
        for scenario in CostTimeTradePart434.SCENARIOS:
            # Calculate expected value
            migration_cost = scenario.cost_usd
            risk_cost = (1.0 - scenario.risk_avoided_percent / 100.0) * breach_cost
            expected_value = migration_cost - risk_cost
            scenario.expected_value = expected_value
            
            output.append(f"│ {scenario.name:<62} │")
            output.append(f"│   Timeline: {scenario.duration_months} months | Systems/month: {scenario.systems_per_month:<4} │"[:73] + " │")
            output.append(f"│   Team size: {scenario.team_size} engineers | Cost: ${scenario.cost_usd/1e6:.1f}M           │"[:73] + " │")
            output.append(f"│   Risk Avoided: {scenario.risk_avoided_percent}% | Expected Value: ${expected_value/1e6:.1f}M     │"[:73] + " │")
            output.append("│")
        
        output.append("├──────────────────────────────────────────────────────────────────────────┤")
        output.append("│ RECOMMENDATION: Balanced (36 months, $2.8M)                              │")
        output.append("│   Begin: January 2025                                                   │")
        output.append("│   Complete: December 2027                                               │")
        output.append("│   Safety margin: 6 years before Q-Day (2033)                            │")
        output.append("╰──────────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


# Main Resource Estimator combining all features
class ResourceEstimatorSimulatorPart43:
    """Complete Resource Estimator (Part 4.3)"""
    
    def __init__(self):
        self.estimator = ResourceEstimatorPart43()
        self.hardware = HardwareTrackerPart432()
        self.comparison = ComparisonTablePart433()
        self.cost_time = CostTimeTradePart434()
    
    def estimate_system(
        self,
        system_id: str,
        system_name: str,
        algorithm: str,
        data_at_risk: float = 1e6
    ) -> str:
        """Feature 4.3.1: Calculate per-system requirements"""
        try:
            algo = CryptoAlgorithm[algorithm.upper().replace("-", "_")]
            req = self.estimator.estimate_system_requirements(
                system_id, system_name, algo, data_at_risk
            )
            return self.estimator.format_system_report(req)
        except (KeyError, ValueError) as e:
            return f"Error: Invalid algorithm '{algorithm}'. Supported: {[a.value for a in CryptoAlgorithm]}"
    
    def hardware_status(self) -> str:
        """Feature 4.3.2: Show hardware capabilities"""
        return self.hardware.format_hardware_status()
    
    def comparison_table(self) -> str:
        """Feature 4.3.3: Generate comparison table"""
        return self.comparison.format_comparison_table()
    
    def migration_cost_analysis(self, systems: int = 1247) -> str:
        """Feature 4.3.4: Cost-time tradeoff analysis"""
        return self.cost_time.format_migration_analysis(systems)
