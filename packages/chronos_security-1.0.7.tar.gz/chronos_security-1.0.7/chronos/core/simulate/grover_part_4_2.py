"""
PART 4.2: Grover's Algorithm Simulator - Complete Standalone Implementation

Features:
  4.2.1: Simple Search Demo
  4.2.2: AES Key Search Simulator
  4.2.3: Interactive Oracle Builder
  4.2.4: Amplitude Amplification Visualizer

All features demonstrate quantum speedup for search problems.
"""

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple
import random


@dataclass
class SearchIteration:
    """One iteration of Grover's algorithm"""
    iteration: int
    target_amplitude: float
    other_amplitude: float
    probability: float


@dataclass
class SearchResult:
    """Result of Grover's search"""
    target_item: int
    search_space_size: int
    iterations_quantum: int
    iterations_classical_avg: int
    quantum_advantage: float
    success_probability: float
    amplification_history: List[SearchIteration]


@dataclass
class AESAttackAnalysis:
    """Analysis of quantum attack on AES"""
    aes_bits: int
    key_space: int
    classical_tries: int
    quantum_tries: int
    classical_years: float
    quantum_years: float
    qubits_needed: int
    oracle_gates: int
    total_gates: int
    is_feasible: bool


class GroversSearchDemo:
    """FEATURE 4.2.1: Simple Search Demo"""
    
    @staticmethod
    def _calculate_iterations(n: int) -> int:
        """Calculate optimal iterations: π/4 * √N"""
        return int(math.pi / 4 * math.sqrt(n))
    
    @staticmethod
    def _simulate_amplitude_evolution(n: int, iterations: int, target_idx: int) -> List[SearchIteration]:
        """
        Simulate amplitude amplification over iterations.
        
        Grover's algorithm works by:
        1. Marking target (flip phase)
        2. Amplifying target amplitude via diffusion
        3. Repeating until target dominates
        """
        history = []
        
        # Initial: all amplitudes equal 1/√N
        initial_amplitude = 1.0 / math.sqrt(n)
        target_amp = initial_amplitude
        other_amp = initial_amplitude
        
        for iteration in range(iterations):
            # Phase 1: Oracle marks target (negative phase)
            # Phase 2: Diffusion operator amplifies
            
            # Grover amplitude growth formula
            # Target amplitude grows by 2*sin(θ)
            # where θ ≈ arcsin(1/√N)
            
            theta = math.asin(1.0 / math.sqrt(n))
            angle = (2 * iteration + 1) * theta
            
            target_amp = math.sin((2 * iteration + 3) * theta)
            other_amp = math.cos((2 * iteration + 3) * theta) / math.sqrt(n - 1)
            
            # Probability of measuring target
            probability = target_amp ** 2
            
            history.append(SearchIteration(
                iteration=iteration,
                target_amplitude=target_amp,
                other_amplitude=other_amp,
                probability=probability
            ))
        
        return history
    
    def search(self, search_space_size: int, target_item: Optional[int] = None) -> SearchResult:
        """
        Perform Grover's search on a space of items.
        
        Args:
            search_space_size: Number of items (should be power of 2)
            target_item: Which item to search for (random if None)
        """
        
        # Verify power of 2
        if search_space_size & (search_space_size - 1) != 0:
            raise ValueError("Search space size must be a power of 2")
        
        if target_item is None:
            target_item = random.randint(0, search_space_size - 1)
        
        # Calculate iterations
        iterations_quantum = self._calculate_iterations(search_space_size)
        
        # Classical: average case needs N/2 tries
        iterations_classical_avg = search_space_size // 2
        
        # Simulate amplitude evolution
        amplification_history = self._simulate_amplitude_evolution(
            search_space_size, iterations_quantum, target_item
        )
        
        # Final success probability
        final_iteration = amplification_history[-1] if amplification_history else SearchIteration(0, 0, 0, 0)
        success_probability = min(final_iteration.probability, 0.99)  # Cap at 99%
        
        quantum_advantage = iterations_classical_avg / max(iterations_quantum, 1)
        
        return SearchResult(
            target_item=target_item,
            search_space_size=search_space_size,
            iterations_quantum=iterations_quantum,
            iterations_classical_avg=iterations_classical_avg,
            quantum_advantage=quantum_advantage,
            success_probability=success_probability,
            amplification_history=amplification_history
        )
    
    def format_search_result(self, result: SearchResult) -> str:
        """Format search result for display"""
        output = []
        output.append("╭─────────────── Grover's Search Algorithm ──────────────────╮")
        output.append(f"│ Search Space: {result.search_space_size} items [0-{result.search_space_size-1}]          │"[:65] + " │")
        output.append(f"│ Target: Item #{result.target_item}                                       │"[:65] + " │")
        output.append("├──────────────────────────────────────────────────────────────┤")
        output.append("│ CLASSICAL SEARCH:                                            │")
        output.append("│   Method: Try each item one by one                           │")
        output.append(f"│   Average attempts: {result.iterations_classical_avg}                                  │"[:65] + " │")
        output.append(f"│   Worst case: {result.search_space_size}                                      │"[:65] + " │")
        output.append("├──────────────────────────────────────────────────────────────┤")
        output.append("│ QUANTUM SEARCH (Grover's):                                   │")
        output.append(f"│   Iterations needed: √{result.search_space_size} = {result.iterations_quantum}                              │"[:65] + " │")
        output.append("│                                                              │")
        
        # Show amplitude amplification bars
        max_iterations = min(len(result.amplification_history), 4)
        for i in range(max_iterations):
            iteration = result.amplification_history[i]
            bar_length = int(iteration.probability * 40)
            bar = "█" * bar_length + "░" * (40 - bar_length)
            output.append(f"│   Iteration {i}: {bar} {iteration.probability*100:>5.1f}%  │"[:65] + " │")
        
        output.append("│                                                              │")
        output.append(f"│ Result: Found item #{result.target_item} ✓                                 │"[:65] + " │")
        output.append(f"│ Quantum Advantage: {result.quantum_advantage:.1f}× faster                          │"[:65] + " │")
        output.append(f"│ Success Rate: {result.success_probability*100:.1f}%                                  │"[:65] + " │")
        output.append("╰──────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


class AESQuantumAttack:
    """FEATURE 4.2.2: AES Key Search Simulator"""
    
    # Grover's algorithm reduces key search by √N
    @staticmethod
    def analyze_aes(aes_bits: int) -> AESAttackAnalysis:
        """
        Analyze quantum attack on AES encryption
        
        Args:
            aes_bits: AES key size (128, 192, or 256)
        """
        
        # Key space size
        key_space = 2 ** aes_bits
        
        # Classical brute force: try on average 2^(n-1) keys
        classical_tries = 2 ** (aes_bits - 1)
        
        # Quantum Grover's: need √(2^n) = 2^(n/2) tries
        quantum_tries = 2 ** (aes_bits // 2)
        
        # Time estimates (assuming 10^12 keys/sec for classical, 100ns per gate for quantum)
        classical_seconds = classical_tries / 1e12
        classical_years = classical_seconds / (365.25 * 24 * 3600)
        
        # Quantum: each Grover iteration ~ 10,000 gates
        gates_per_iteration = 10000
        total_gates = quantum_tries * gates_per_iteration
        gate_time = 100e-9  # 100 nanoseconds
        quantum_seconds = total_gates * gate_time
        quantum_years = quantum_seconds / (365.25 * 24 * 3600)
        
        # Resources needed
        qubits_needed = aes_bits + 200  # Buffer for oracle
        oracle_gates = 10000
        
        # Feasibility: with current tech (2024), quantum attacks problematic
        is_feasible = aes_bits <= 128 and quantum_years < 1e6
        
        return AESAttackAnalysis(
            aes_bits=aes_bits,
            key_space=key_space,
            classical_tries=classical_tries,
            quantum_tries=quantum_tries,
            classical_years=classical_years,
            quantum_years=quantum_years,
            qubits_needed=qubits_needed,
            oracle_gates=oracle_gates,
            total_gates=int(total_gates),
            is_feasible=is_feasible
        )
    
    @staticmethod
    def format_analysis(analysis: AESAttackAnalysis) -> str:
        """Format AES attack analysis for display"""
        output = []
        output.append(f"╭────────────── AES-{analysis.aes_bits} Quantum Attack Analysis ──────────────╮")
        output.append("├─────────────────────────────────────────────────────────────────────┤")
        output.append(f"│ TARGET: AES-{analysis.aes_bits} Encryption                                    │"[:70] + " │")
        output.append("├─────────────────────────────────────────────────────────────────────┤")
        output.append("│ CLASSICAL BRUTE FORCE:                                              │")
        output.append(f"│   Key Space: 2^{analysis.aes_bits} = {analysis.key_space:.1e} keys                    │"[:70] + " │")
        output.append(f"│   Tries Needed: 2^{analysis.aes_bits - 1} (average)                            │"[:70] + " │")
        output.append(f"│   At 10^12 keys/sec: {analysis.classical_years:.1e} years                 │"[:70] + " │")
        output.append("│   Status: IMPOSSIBLE ✓                                              │")
        output.append("├─────────────────────────────────────────────────────────────────────┤")
        output.append("│ QUANTUM ATTACK (Grover's):                                          │")
        output.append(f"│   Quantum Speedup: √N = √2^{analysis.aes_bits} = 2^{analysis.aes_bits//2}                   │"[:70] + " │")
        output.append(f"│   Tries Needed: 2^{analysis.aes_bits//2} = {analysis.quantum_tries:.1e}                   │"[:70] + " │")
        output.append("│                                                                       │")
        output.append("│   Resources Required:                                               │")
        output.append(f"│     Qubits: ~{analysis.qubits_needed:,} (for key + oracle)                       │"[:70] + " │")
        output.append(f"│     Oracle Calls: {analysis.quantum_tries:.1e}                                │"[:70] + " │")
        output.append(f"│     Gates per Oracle: ~{analysis.oracle_gates:,}                               │"[:70] + " │")
        output.append(f"│     Total Gates: {analysis.total_gates:.1e}                            │"[:70] + " │")
        output.append("│                                                                       │")
        output.append("│   Time Estimate:                                                    │")
        output.append(f"│     Gate Time: 100 nanoseconds                                       │")
        output.append(f"│     Total: ~{analysis.quantum_years:.0f} years                            │"[:70] + " │")
        
        if analysis.aes_bits > 128:
            output.append("│     Status: SAFE ✓                                                  │")
        else:
            output.append("│     Status: VULNERABLE (upgrade recommended)                       │")
        
        output.append("╰─────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)
    
    @staticmethod
    def format_comparison() -> str:
        """Compare different AES key sizes against quantum attacks"""
        output = []
        output.append("╭──────── AES Quantum Security Comparison ─────────╮")
        output.append("│ AES Size │ Quantum Time │ Status                    │")
        output.append("├──────────┼──────────────┼──────────────────────────┤")
        
        for bits in [128, 192, 256]:
            analysis = AESQuantumAttack.analyze_aes(bits)
            if analysis.quantum_years < 1000:
                status = f"⚠️  VULNERABLE (~{analysis.quantum_years:.0f} years)"
            elif analysis.quantum_years < 1e10:
                status = f"⚠️  RISKY (~{analysis.quantum_years:.0e} years)"
            else:
                status = "✓ SAFE"
            
            output.append(f"│ AES-{bits:<3} │ ~{analysis.quantum_years:<10.1e} │ {status:<24} │")
        
        output.append("├──────────┼──────────────┼──────────────────────────┤")
        output.append("│ Recommendation: Use AES-256 (quantum-resistant)     │")
        output.append("╰──────────┴──────────────┴──────────────────────────╯")
        
        return "\n".join(output)


class OracleBuilder:
    """FEATURE 4.2.3: Interactive Oracle Builder"""
    
    @staticmethod
    def build_oracle(search_problem: str, search_space_size: int) -> str:
        """
        Build a quantum oracle for custom search problem.
        
        This simulates what Grover's oracle would look like.
        """
        output = []
        output.append("╭──────────────── Custom Search Oracle ──────────────────╮")
        output.append(f"│ Problem: {search_problem:<45} │")
        output.append(f"│ Search Space: 2^{search_space_size.bit_length()} items ({search_space_size} total)         │"[:60] + " │")
        output.append("├────────────────────────────────────────────────────────┤")
        output.append("│ Oracle Construction:                                   │")
        output.append("│   1. Encode search criteria as quantum predicate       │")
        output.append("│   2. Apply controlled-NOT gates for matching           │")
        output.append("│   3. Phase flip target items (-1 amplitude)            │")
        output.append("│   4. Uncompute auxiliary qubits                        │")
        output.append("│                                                        │")
        
        # Calculate iterations
        iterations = int(math.pi / 4 * math.sqrt(search_space_size))
        output.append(f"│ Iterations Needed: √{search_space_size} ≈ {iterations}                               │"[:60] + " │")
        output.append(f"│ Speedup vs Classical: ~{search_space_size // max(iterations, 1)}×                               │"[:60] + " │")
        output.append("│                                                        │")
        output.append("│ Oracle Complexity:                                     │")
        output.append(f"│   Qubits: ~{search_space_size.bit_length() + 10}                                        │"[:60] + " │")
        output.append(f"│   Gates per call: ~{100 + search_space_size // 2}                               │"[:60] + " │")
        output.append("│                                                        │")
        output.append("│ Status: Oracle built ✓                                │")
        output.append("╰────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


class AmplificationVisualizer:
    """FEATURE 4.2.4: Amplitude Amplification Visualizer"""
    
    @staticmethod
    def visualize_evolution(search_space_size: int) -> str:
        """Visualize how Grover's algorithm amplifies the target amplitude"""
        
        # Calculate iterations
        iterations = int(math.pi / 4 * math.sqrt(search_space_size))
        iterations = min(iterations, 4)  # Show only first 4 iterations
        
        output = []
        output.append("╭────────────── Amplitude Evolution ─────────────────────╮")
        output.append("│                                                        │")
        
        # Initial state
        output.append("│ Initial State (After Hadamard):                        │")
        output.append("│ │                                                      │")
        bar = "┌─" * (search_space_size // 4) + "┐"
        if len(bar) > 50:
            bar = "┌" + "─" * 48 + "┐"
        output.append(f"│ │  {bar:<47} │ All equal")
        output.append("│ └" + "─" * 48 + "┘")
        output.append("│                                                        │")
        
        # After oracle (mark target)
        output.append("│ After Oracle (Mark Target):                            │")
        output.append("│ │                                                      │")
        space = " " * (search_space_size // 8)
        output.append(f"│ │  ┌──┐┌──┐┌──┐┌──┐┌──┐┌──┐┌──┐                       │")
        output.append(f"│ │  ││││││││││││││││││││││││││││││││││──────── │ One flipped")
        output.append(f"│ │  └──┘└──┘└──┘└──┘└──┘└──┘└──┘└──┘{space}└─┘")
        output.append("│                                                        │")
        
        # After diffusion
        output.append("│ After Diffusion (Amplify):                             │")
        output.append("│ │      ┌────┐                                          │")
        output.append("│ │  ┌┐┌┐│    │┌┐┌┐┌┐┌┐  Target grows!                  │")
        output.append("│ └──┴┴┴┴┴────┴┴┴┴┴┴┴┴┴──────────────                    │")
        output.append("│                                                        │")
        
        # After iterations
        output.append("│ After Optimal Iterations:                              │")
        output.append("│ │             ┌─────┐                                  │")
        output.append("│ │             │     │  Target ~100%                    │")
        output.append("│ └─────────────┴─────┴────────────────                  │")
        output.append("│                                                        │")
        output.append("│ Mathematics Behind Amplification:                      │")
        output.append("│   Phase 1: Oracle flips sign of target                │")
        output.append("│   Phase 2: Diffusion operator (2|s⟩⟨s| - I)            │")
        output.append("│   Result: Target amplitude grows exponentially         │")
        output.append("│   Optimal iterations: π/4 × √N                         │")
        output.append("│                                                        │")
        output.append("╰────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


# Main Grover's Simulator combining all features
class GroverSimulatorPart42:
    """Complete Grover's Algorithm Simulator (Part 4.2)"""
    
    def __init__(self):
        self.search_demo = GroversSearchDemo()
        self.aes_attack = AESQuantumAttack()
        self.oracle = OracleBuilder()
        self.visualizer = AmplificationVisualizer()
    
    def simple_search(self, search_space_size: int) -> str:
        """Feature 4.2.1: Simple search demo"""
        result = self.search_demo.search(search_space_size)
        return self.search_demo.format_search_result(result)
    
    def aes_analysis(self, aes_bits: int) -> str:
        """Feature 4.2.2: AES key search simulator"""
        analysis = self.aes_attack.analyze_aes(aes_bits)
        return self.aes_attack.format_analysis(analysis)
    
    def aes_comparison(self) -> str:
        """Feature 4.2.2: Compare AES sizes"""
        return self.aes_attack.format_comparison()
    
    def build_custom_oracle(self, problem: str, space_size: int) -> str:
        """Feature 4.2.3: Build custom oracle"""
        return self.oracle.build_oracle(problem, space_size)
    
    def visualize_amplification(self, search_space_size: int) -> str:
        """Feature 4.2.4: Visualize amplitude amplification"""
        return self.visualizer.visualize_evolution(search_space_size)
