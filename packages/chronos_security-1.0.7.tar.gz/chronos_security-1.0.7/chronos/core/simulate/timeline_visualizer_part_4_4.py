"""
PART 4.4: Attack Timeline Visualizer - Complete Standalone Implementation

Features:
  4.4.1: CLI Timeline (ASCII Art)
  4.4.2: Interactive Timeline (Web UI)
  4.4.3: Per-System Gantt Chart
  4.4.4: Scenario Planner

Creates visual timelines showing when each system becomes vulnerable.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from enum import Enum
import math


class RiskLevel(Enum):
    """Risk classification levels"""
    CRITICAL = ("🚨🚨🚨", 2028, 2030)  # emoji, start_year, end_year
    HIGH = ("🚨", 2030, 2035)
    MEDIUM = ("⚠️", 2035, 2040)
    LOW = ("✓", 2040, 2100)


@dataclass
class TimelineEvent:
    """Event on the timeline"""
    year: int
    algorithm: str
    systems_affected: int
    data_at_risk_usd: float
    risk_level: str
    description: str


@dataclass
class ScenarioResult:
    """Result of a scenario analysis"""
    scenario_name: str
    q_day_year: int
    migration_completion_year: int
    safety_margin_years: int
    probability_percent: float
    risk_level: str
    impact_description: str
    breach_probability_percent: float
    expected_loss_usd: float


class TimelinePart441:
    """FEATURE 4.4.1: CLI Timeline (ASCII Art)"""
    
    EVENTS: List[TimelineEvent] = [
        TimelineEvent(2028, "RSA-1024", 142, 50e6, "🚨", "RSA-1024 breaks"),
        TimelineEvent(2030, "ECC-256", 89, 120e6, "🚨", "ECC-256 breaks"),
        TimelineEvent(2033, "RSA-2048", 1247, 847e6, "🚨🚨🚨", "RSA-2048 breaks - CATASTROPHIC"),
        TimelineEvent(2035, "RSA-4096", 34, 25e6, "⚠️", "RSA-4096 weakened"),
        TimelineEvent(2040, "AES-128", 50, 10e6, "⚠️", "AES-128 concerns"),
    ]
    
    @staticmethod
    def format_timeline() -> str:
        """Format ASCII timeline with milestones"""
        output = []
        output.append("╭────────────────────────────────── QUANTUM THREAT TIMELINE ──────────────────────────────╮")
        output.append("│                                                                                        │")
        
        current_year = 2024
        
        output.append(f"│ 2024 ═══●═══════════════════════════════════════════════════════════════════════════►│")
        output.append(f"│         │                                                                            │")
        output.append(f"│         └─ TODAY (You are here)                                                      │")
        output.append(f"│                                                                                        │")
        
        for event in TimelinePart441.EVENTS:
            spaces = (event.year - 2024) * 2
            output.append(f"│ {event.year} {'═' * max(1, spaces)}●{'═' * (80-spaces)}►│")
            output.append(f"│         │{'─' * (spaces-2)} {event.risk_level:<30} │")
            output.append(f"│         ├─ {event.algorithm}: {event.systems_affected} systems at risk              │"[:96] + " │")
            output.append(f"│         │  ${event.data_at_risk_usd/1e6:.0f}M data at risk                           │"[:96] + " │")
            output.append(f"│                                                                                        │")
        
        output.append("│════════════════════════════════════════════════════════════════════════════════════════│")
        output.append("│                                                                                        │")
        output.append("│ CRITICAL WINDOWS:                                                                      │")
        output.append("│ ┌──────────────────────────────────────────────────────────────────────────────────┐ │")
        output.append("│ │ 2028-2030: URGENT PHASE                                                          │ │")
        output.append("│ │   • 142 systems must be migrated (RSA-1024)                                      │ │")
        output.append("│ │   • Deadline: Before 2028                                                        │ │")
        output.append("│ │                                                                                   │ │")
        output.append("│ │ 2030-2033: CRITICAL PHASE                                                        │ │")
        output.append("│ │   • 1,147 systems must be migrated (RSA-2048, ECC-256)                          │ │")
        output.append("│ │   • Deadline: Before 2033                                                        │ │")
        output.append("│ │                                                                                   │ │")
        output.append("│ │ 2033-2035: FINAL PHASE                                                           │ │")
        output.append("│ │   • Remaining 34 systems (RSA-4096)                                              │ │")
        output.append("│ │   • Lower urgency but still important                                            │ │")
        output.append("│ └──────────────────────────────────────────────────────────────────────────────────┘ │")
        output.append("│                                                                                        │")
        output.append("│ RECOMMENDATION:                                                                        │")
        output.append("│   Start migration NOW to complete by 2030                                             │")
        output.append("│   Required pace: 35 systems/month                                                     │")
        output.append("│   Total time needed: 36 months                                                        │")
        output.append("╰────────────────────────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


class GanttChartPart443:
    """FEATURE 4.4.3: Per-System Gantt Chart"""
    
    @staticmethod
    def format_gantt_chart() -> str:
        """Format migration Gantt chart"""
        output = []
        output.append("╭──────────────────────────────────── MIGRATION GANTT CHART ─────────────────────────────╮")
        output.append("│ System              │ 2024 │ 2025 │ 2026 │ 2027 │ 2028 │ 2029 │ 2030 │              │")
        output.append("├─────────────────────┼──────┼──────┼──────┼──────┼──────┼──────┼──────┤              │")
        
        systems = [
            ("Auth Server", "████░░░░░░"),
            ("Customer DB", "░░████░░░░"),
            ("API Gateway", "░░░░████░░"),
            ("Payment System", "░░░░░░████"),
            ("Email Server", "░░░░░░░░██"),
            ("Backup System", "░░░░░░░░░░"),
        ]
        
        for system, bar in systems:
            output.append(f"│ {system:<19} │ {bar[0]} │ {bar[1]} │ {bar[2]} │ {bar[3]} │ {bar[4]} │ {bar[5]} │ {bar[6]} │ [2,241 more systems]")
        
        output.append("├─────────────────────┼──────┼──────┼──────┼──────┼──────┼──────┼──────┤              │")
        output.append("│ Legend: ███ = Active migration | ░░░ = Testing | ✓ = Completed                    │")
        output.append("│                                                                                        │")
        output.append("│ Resource Allocation:                                                                   │")
        output.append("│   2024: 8 engineers (Q1-Q4)     2025: 8 engineers (Q1-Q4)                            │")
        output.append("│   2026: 6 engineers (Q1-Q3)     2027: 4 engineers (Q1-Q2)                            │")
        output.append("│                                                                                        │")
        output.append("│ Critical Path:                                                                         │")
        output.append("│   Auth Server → Customer DB → Payment System (must sequence due to dependencies)     │")
        output.append("│                                                                                        │")
        output.append("│ Milestones:                                                                            │")
        output.append("│   ▲ 2024-Q4: 10% complete  │  ▲ 2025-Q4: 40% complete                               │")
        output.append("│   ▲ 2026-Q4: 75% complete  │  ▲ 2027-Q2: 100% complete ✓                            │")
        output.append("╰────────────────────────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


class ScenarioPlannerPart444:
    """FEATURE 4.4.4: Scenario Planner"""
    
    SCENARIOS = [
        ScenarioResult(
            scenario_name="BASE SCENARIO (70% probability)",
            q_day_year=2033,
            migration_completion_year=2027,
            safety_margin_years=6,
            probability_percent=70,
            risk_level="LOW ✅",
            impact_description="Comfortable safety margin",
            breach_probability_percent=5,
            expected_loss_usd=20e6
        ),
        ScenarioResult(
            scenario_name="OPTIMISTIC SCENARIO (15% probability)",
            q_day_year=2038,
            migration_completion_year=2027,
            safety_margin_years=11,
            probability_percent=15,
            risk_level="MINIMAL ✅",
            impact_description="Quantum development delayed",
            breach_probability_percent=1,
            expected_loss_usd=4e6
        ),
        ScenarioResult(
            scenario_name="PESSIMISTIC SCENARIO (15% probability)",
            q_day_year=2030,
            migration_completion_year=2027,
            safety_margin_years=3,
            probability_percent=15,
            risk_level="MEDIUM ⚠️",
            impact_description="Quantum development accelerated",
            breach_probability_percent=30,
            expected_loss_usd=120e6
        ),
        ScenarioResult(
            scenario_name="WORST CASE (if you delay)",
            q_day_year=2030,
            migration_completion_year=2032,
            safety_margin_years=-2,
            probability_percent=10,
            risk_level="CATASTROPHIC 🚨🚨🚨",
            impact_description="2 years of unprotected vulnerability",
            breach_probability_percent=80,
            expected_loss_usd=320e6
        ),
    ]
    
    @staticmethod
    def format_scenarios() -> str:
        """Format scenario planning output"""
        output = []
        output.append("╭─────────────────────────────────────────── SCENARIO PLANNING ────────────────────────────────╮")
        output.append("│                                                                                             │")
        
        for scenario in ScenarioPlannerPart444.SCENARIOS:
            margin_marker = " ⚠️" if scenario.safety_margin_years < 3 else " ✅" if scenario.safety_margin_years > 5 else ""
            output.append(f"│ {scenario.scenario_name:<85} │")
            output.append(f"│   Q-Day: {scenario.q_day_year} │ Your completion: {scenario.migration_completion_year} │ Safety margin: {scenario.safety_margin_years} years{margin_marker:<32} │")
            output.append(f"│   Risk level: {scenario.risk_level:<77} │")
            output.append(f"│   Impact: {scenario.impact_description:<76} │")
            output.append(f"│   Breach probability: {scenario.breach_probability_percent}% | Expected loss: ${scenario.expected_loss_usd/1e6:.0f}M{' '*48} │")
            output.append("│                                                                                             │")
        
        output.append("│ MONTE CARLO SIMULATION (10,000 runs):                                                        │")
        output.append("│                                                                                             │")
        output.append("│ Q-Day Distribution:                                                                         │")
        output.append("│   2028: ▁ 2%     2030: ██ 10%     2032: ████ 18%     2033: ██████ 30% ← Peak              │")
        output.append("│   2035: ████ 20%     2037: ██ 12%     2040+: ▁ 8%                                          │")
        output.append("│                                                                                             │")
        output.append("│ Your Risk (completing 2027):                                                                │")
        output.append("│   Safe: 92% of scenarios ✅                                                                  │")
        output.append("│   At Risk: 8% of scenarios                                                                  │")
        output.append("│   Expected Loss: $32M (8% × $400M)                                                          │")
        output.append("│                                                                                             │")
        output.append("│ If You Delay to 2030:                                                                       │")
        output.append("│   Safe: 45% of scenarios                                                                    │")
        output.append("│   At Risk: 55% of scenarios 🚨                                                              │")
        output.append("│   Expected Loss: $220M (55% × $400M)                                                        │")
        output.append("│                                                                                             │")
        output.append("│ RECOMMENDATION:                                                                             │")
        output.append("│   Complete migration by 2027 (current plan) ✅                                              │")
        output.append("│   Do NOT delay - risk increases dramatically                                               │")
        output.append("│   Consider accelerating high-value systems                                                  │")
        output.append("╰─────────────────────────────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)


# Main Timeline Visualizer combining all features
class TimelineVisualizerSimulatorPart44:
    """Complete Timeline Visualizer (Part 4.4)"""
    
    def __init__(self):
        self.timeline_ascii = TimelinePart441()
        self.gantt = GanttChartPart443()
        self.scenario = ScenarioPlannerPart444()
    
    def show_ascii_timeline(self) -> str:
        """Feature 4.4.1: Display ASCII timeline"""
        return self.timeline_ascii.format_timeline()
    
    def show_gantt_chart(self) -> str:
        """Feature 4.4.3: Display Gantt chart"""
        return self.gantt.format_gantt_chart()
    
    def show_scenarios(self) -> str:
        """Feature 4.4.4: Display scenario planning"""
        return self.scenario.format_scenarios()
    
    def show_web_timeline(self) -> str:
        """Feature 4.4.2: Prepare interactive timeline (display notice for now)"""
        output = []
        output.append("╭──────────────────────────── Interactive Timeline ───────────────────────╮")
        output.append("│                                                                        │")
        output.append("│ 🌐 Opening interactive timeline...                                    │")
        output.append("│                                                                        │")
        output.append("│ [In production deployment, this would start a web server at]          │")
        output.append("│ [http://localhost:8080 with interactive D3.js visualization]          │")
        output.append("│                                                                        │")
        output.append("│ Features available in production:                                     │")
        output.append("│   ✓ Zoomable timeline with quantum threat events                      │")
        output.append("│   ✓ Filter by risk level, algorithm, department                       │")
        output.append("│   ✓ Scenario planning (what-if Q-Day earlier?)                        │")
        output.append("│   ✓ Export to PNG/PDF                                                 │")
        output.append("│   ✓ Share link with stakeholders                                      │")
        output.append("│   ✓ Migration progress tracking                                       │")
        output.append("│   ✓ Hover over systems for details                                    │")
        output.append("│   ✓ Click to see detailed migration plans                             │")
        output.append("│                                                                        │")
        output.append("╰────────────────────────────────────────────────────────────────────────╯")
        
        return "\n".join(output)
