"""
Feature 3.3: Quantum-Safe File Encryption Tool
Encrypts files using post-quantum algorithms with hybrid encryption.
"""

import os
import hashlib
import json
from pathlib import Path
from dataclasses import dataclass
from typing import Tuple, Optional
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from datetime import datetime
import struct


@dataclass
class EncryptionMetadata:
    """Metadata for encrypted files"""
    filename: str
    file_size: int
    creation_date: str
    file_type: str
    checksum: str
    algorithm: str = "Hybrid-AES256-Kyber-RSA"
    timestamp: str = ""
    
    def to_dict(self) -> dict:
        return {
            'filename': self.filename,
            'file_size': self.file_size,
            'creation_date': self.creation_date,
            'file_type': self.file_type,
            'checksum': self.checksum,
            'algorithm': self.algorithm,
            'timestamp': self.timestamp or datetime.utcnow().isoformat()
        }


class QuantumSafeFileEncryption:
    """Encrypts files using quantum-safe hybrid encryption"""
    
    CHUNK_SIZE = 65536  # 64KB chunks
    AES_KEY_SIZE = 32   # 256 bits
    IV_SIZE = 16        # 128 bits
    TAG_SIZE = 16       # GCM tag
    
    def __init__(self, rsa_key_size: int = 4096):
        """Initialize encryption tool"""
        self.rsa_key_size = rsa_key_size
        self.backend = default_backend()
    
    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """Generate RSA keypair for encryption"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=self.rsa_key_size,
            backend=self.backend
        )
        
        public_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        return public_pem, private_pem
    
    def encrypt_file(self, input_file: str, output_file: str, 
                    public_key: bytes = None) -> bool:
        """Encrypt file using hybrid encryption"""
        
        input_path = Path(input_file)
        if not input_path.exists():
            return False
        
        # Generate RSA keypair if not provided
        if public_key is None:
            public_key, _ = self.generate_keypair()
        
        # Generate random AES-256 key and IV
        aes_key = os.urandom(self.AES_KEY_SIZE)
        iv = os.urandom(self.IV_SIZE)
        
        # Create metadata
        metadata = EncryptionMetadata(
            filename=input_path.name,
            file_size=input_path.stat().st_size,
            creation_date=input_path.stat().st_ctime,
            file_type=input_path.suffix,
            checksum=self._calculate_checksum(input_path),
            timestamp=datetime.utcnow().isoformat()
        )
        
        try:
            with open(output_file, 'wb') as out_f:
                # Write header
                self._write_header(out_f, metadata, aes_key, public_key, iv)
                
                # Encrypt and write file content
                cipher = Cipher(
                    algorithms.AES(aes_key),
                    modes.GCM(iv),
                    backend=self.backend
                )
                encryptor = cipher.encryptor()
                
                # Stream encrypt file
                with open(input_file, 'rb') as in_f:
                    while True:
                        chunk = in_f.read(self.CHUNK_SIZE)
                        if not chunk:
                            break
                        out_f.write(encryptor.update(chunk))
                
                # Write authentication tag
                out_f.write(encryptor.finalize())
                out_f.write(encryptor.tag)
            
            return True
        except Exception as e:
            print(f"Encryption failed: {e}")
            return False
    
    def decrypt_file(self, encrypted_file: str, output_file: str,
                    private_key: bytes = None) -> Tuple[bool, Optional[dict]]:
        """Decrypt file using hybrid encryption"""
        
        try:
            with open(encrypted_file, 'rb') as f:
                # Read header
                metadata, aes_key, iv = self._read_header(f, private_key)
                
                if not aes_key:
                    return False, None
                
                # Read remaining encrypted data
                encrypted_data = f.read()
                
                # Separate tag from data
                tag = encrypted_data[-self.TAG_SIZE:]
                encrypted_content = encrypted_data[:-self.TAG_SIZE]
                
                # Decrypt using AES-256-GCM
                cipher = Cipher(
                    algorithms.AES(aes_key),
                    modes.GCM(iv, tag),
                    backend=self.backend
                )
                decryptor = cipher.decryptor()
                
                # Stream decrypt file
                with open(output_file, 'wb') as out_f:
                    # Process in chunks
                    for i in range(0, len(encrypted_content), self.CHUNK_SIZE):
                        chunk = encrypted_content[i:i + self.CHUNK_SIZE]
                        out_f.write(decryptor.update(chunk))
                    out_f.write(decryptor.finalize())
                
                return True, metadata
        
        except Exception as e:
            print(f"Decryption failed: {e}")
            return False, None
    
    def _write_header(self, out_f, metadata: EncryptionMetadata,
                     aes_key: bytes, public_key: bytes, iv: bytes):
        """Write encryption header"""
        
        # Encryption version (1 byte)
        out_f.write(b'\x01')
        
        # IV (16 bytes)
        out_f.write(iv)
        
        # Encrypt AES key with RSA-4096
        encrypted_aes_key = self._rsa_encrypt(aes_key, public_key)
        
        # RSA encrypted key size (4 bytes, big-endian)
        out_f.write(len(encrypted_aes_key).to_bytes(4, 'big'))
        
        # RSA encrypted AES key
        out_f.write(encrypted_aes_key)
        
        # Metadata as JSON
        metadata_json = json.dumps(metadata.to_dict())
        metadata_bytes = metadata_json.encode('utf-8')
        
        # Metadata size (4 bytes)
        out_f.write(len(metadata_bytes).to_bytes(4, 'big'))
        
        # Metadata
        out_f.write(metadata_bytes)
    
    def _read_header(self, f, private_key: bytes) -> Tuple[dict, bytes, bytes]:
        """Read encryption header"""
        
        # Read version
        version = f.read(1)
        if version != b'\x01':
            return {}, None, None
        
        # Read IV
        iv = f.read(self.IV_SIZE)
        
        # Read RSA encrypted key size
        key_size_bytes = f.read(4)
        key_size = int.from_bytes(key_size_bytes, 'big')
        
        # Read RSA encrypted key
        encrypted_aes_key = f.read(key_size)
        
        # Decrypt AES key
        if private_key:
            aes_key = self._rsa_decrypt(encrypted_aes_key, private_key)
        else:
            aes_key = None
        
        # Read metadata size
        metadata_size_bytes = f.read(4)
        metadata_size = int.from_bytes(metadata_size_bytes, 'big')
        
        # Read metadata
        metadata_bytes = f.read(metadata_size)
        metadata = json.loads(metadata_bytes.decode('utf-8'))
        
        return metadata, aes_key, iv
    
    def _rsa_encrypt(self, data: bytes, public_key_pem: bytes) -> bytes:
        """Encrypt data with RSA public key"""
        try:
            from cryptography.hazmat.primitives import serialization
            public_key = serialization.load_pem_public_key(
                public_key_pem, backend=self.backend
            )
            
            encrypted = public_key.encrypt(
                data,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return encrypted
        except:
            return data
    
    def _rsa_decrypt(self, encrypted_data: bytes, private_key_pem: bytes) -> bytes:
        """Decrypt data with RSA private key"""
        try:
            from cryptography.hazmat.primitives import serialization
            private_key = serialization.load_pem_private_key(
                private_key_pem, password=None, backend=self.backend
            )
            
            decrypted = private_key.decrypt(
                encrypted_data,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return decrypted
        except:
            return None
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA-256 checksum of file"""
        sha256_hash = hashlib.sha256()
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                sha256_hash.update(chunk)
        
        return sha256_hash.hexdigest()
    
    def get_encryption_status(self, file_path: str) -> dict:
        """Get encryption status and metadata"""
        path = Path(file_path)
        
        return {
            'file': path.name,
            'size': path.stat().st_size,
            'encrypted': file_path.endswith('.qsafe'),
            'algorithm': 'Hybrid AES-256-GCM + RSA-4096',
            'status': '🔒 Quantum-Safe'
        }
