"""
Feature 3.2: Automated Migration Engine
Automatically rewrites code to replace classical crypto with post-quantum crypto.
"""

import ast
import re
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import shutil
from datetime import datetime


@dataclass
class MigrationRule:
    """Defines how to transform crypto code"""
    name: str
    pattern: str
    replacement: str
    algorithm_from: str
    algorithm_to: str
    priority: int  # Higher = more critical


class MigrationEngine:
    """Automatically migrates code from classical to post-quantum crypto"""
    
    # Transformation rules
    RULES = [
        # RSA to Kyber (Key Encapsulation)
        MigrationRule(
            name="RSA 2048 to Kyber768",
            pattern=r'RSA\.generate\(2048\)',
            replacement='oqs.KeyEncapsulation("Kyber768")',
            algorithm_from='RSA-2048',
            algorithm_to='Kyber768',
            priority=100
        ),
        MigrationRule(
            name="RSA 3072 to Kyber1024",
            pattern=r'RSA\.generate\(3072\)',
            replacement='oqs.KeyEncapsulation("Kyber1024")',
            algorithm_from='RSA-3072',
            algorithm_to='Kyber1024',
            priority=100
        ),
        MigrationRule(
            name="RSA 4096 to Kyber1024",
            pattern=r'RSA\.generate\(4096\)',
            replacement='oqs.KeyEncapsulation("Kyber1024")',
            algorithm_from='RSA-4096',
            algorithm_to='Kyber1024',
            priority=95
        ),
        # ECC to Kyber
        MigrationRule(
            name="ECC P-256 to Kyber768",
            pattern=r"EC\.generate\('prime256v1'\)",
            replacement='oqs.KeyEncapsulation("Kyber768")',
            algorithm_from='ECC-256',
            algorithm_to='Kyber768',
            priority=100
        ),
        # Signatures: RSA to Dilithium
        MigrationRule(
            name="RSA signature to Dilithium",
            pattern=r'rsa_key\.sign\(',
            replacement='signature = oqs.Signature("Dilithium3")\nsignature.sign_message(',
            algorithm_from='RSA-signature',
            algorithm_to='Dilithium3',
            priority=90
        ),
        # Imports
        MigrationRule(
            name="Add OQS import",
            pattern=r'^(from Crypto import|\s*$)',
            replacement='import liboqs as oqs\n\1',
            algorithm_from='import',
            algorithm_to='import',
            priority=80
        ),
    ]
    
    HYBRID_TEMPLATE = '''
def encrypt_hybrid(data, mode="hybrid"):
    """Encrypt with both classical and post-quantum algorithms"""
    if mode == "hybrid":
        # Encrypt with both RSA AND Kyber
        rsa_encrypted = rsa_encrypt(data)
        kyber_encrypted = kyber_encrypt(data)
        return {{
            'classical': rsa_encrypted,
            'pqc': kyber_encrypted,
            'mode': 'hybrid',
            'timestamp': datetime.utcnow().isoformat()
        }}
    elif mode == "pqc_only":
        return kyber_encrypt(data)
    else:
        return rsa_encrypt(data)
'''
    
    def __init__(self, root_path: str):
        self.root_path = Path(root_path)
        self.transformations = []
        self.backups_created = []
        self.files_migrated = 0
        self.total_replacements = 0
    
    def migrate_codebase(self, target_files: List[str] = None, 
                        dry_run: bool = True) -> Dict:
        """Migrate entire codebase or specific files"""
        
        # Discover Python files
        if target_files:
            files = [Path(f) for f in target_files]
        else:
            files = list(self.root_path.rglob('*.py'))
        
        # Skip test and venv files
        files = [f for f in files if not any(
            skip in str(f) for skip in ['test', 'venv', '__pycache__', '.git']
        )]
        
        results = {
            'total_files': len(files),
            'migrated': 0,
            'failed': 0,
            'transformations': [],
            'dry_run': dry_run
        }
        
        for file_path in files:
            result = self._migrate_file(file_path, dry_run=dry_run)
            if result['success']:
                results['migrated'] += 1
                self.files_migrated += 1
            else:
                results['failed'] += 1
            
            if result['transformations']:
                results['transformations'].extend(result['transformations'])
        
        return results
    
    def _migrate_file(self, file_path: Path, dry_run: bool = True) -> Dict:
        """Migrate single file"""
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                original_content = f.read()
        except:
            return {'success': False, 'transformations': []}
        
        new_content = original_content
        transformations = []
        
        # Apply migration rules
        for rule in sorted(self.RULES, key=lambda r: r.priority, reverse=True):
            matches = list(re.finditer(rule.pattern, new_content))
            
            if matches:
                new_content = re.sub(rule.pattern, rule.replacement, new_content)
                
                transformations.append({
                    'rule': rule.name,
                    'from': rule.algorithm_from,
                    'to': rule.algorithm_to,
                    'count': len(matches)
                })
                
                self.total_replacements += len(matches)
        
        # If no changes, return early
        if new_content == original_content:
            return {'success': True, 'transformations': []}
        
        if dry_run:
            # Don't write files in dry-run mode
            return {'success': True, 'transformations': transformations}
        
        # Create backup
        backup_path = file_path.with_suffix('.py.backup')
        if not backup_path.exists():
            shutil.copy2(file_path, backup_path)
            self.backups_created.append(str(backup_path))
        
        # Write migrated code
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            return {'success': True, 'transformations': transformations}
        except:
            # Restore from backup on failure
            if backup_path.exists():
                shutil.copy2(backup_path, file_path)
            return {'success': False, 'transformations': []}
    
    def add_hybrid_mode(self, file_path: Path, function_name: str = "encrypt"):
        """Add hybrid encryption mode to file"""
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Check if already has hybrid
        if 'hybrid' in content:
            return False
        
        # Insert hybrid template
        insert_point = content.find(f'def {function_name}(')
        if insert_point == -1:
            insert_point = len(content)
        
        content = content[:insert_point] + '\n' + self.HYBRID_TEMPLATE + '\n' + content[insert_point:]
        
        with open(file_path, 'w') as f:
            f.write(content)
        
        return True
    
    def update_requirements(self, file_path: Path) -> bool:
        """Update requirements.txt with post-quantum dependencies"""
        
        try:
            with open(file_path, 'r') as f:
                content = f.read()
        except FileNotFoundError:
            content = ""
        
        lines = content.split('\n')
        
        # Remove old crypto libraries
        old_libs = ['pycryptodome', 'rsa', 'ecdsa']
        lines = [l for l in lines if not any(old in l for old in old_libs)]
        
        # Add PQC library
        if 'liboqs-python' not in content:
            lines.append('liboqs-python>=0.10.0')
        
        # Add other recommended libraries
        recommended = [
            'cryptography>=41.0.0',
            'pycryptodome>=3.19.0',  # Still needed for AES
        ]
        
        for lib in recommended:
            if lib.split('>=')[0] not in content:
                lines.append(lib)
        
        new_content = '\n'.join(filter(None, lines))
        
        with open(file_path, 'w') as f:
            f.write(new_content)
        
        return True
    
    def generate_migration_report(self) -> str:
        """Generate migration report"""
        
        lines = [
            "🚀 AUTOMATED MIGRATION REPORT",
            "=" * 60,
            f"\nMIGRATION SUMMARY:",
            f"  Files Processed: {len(self.backups_created)}",
            f"  Files Successfully Migrated: {self.files_migrated}",
            f"  Total Code Transformations: {self.total_replacements}",
            f"  Backup Files Created: {len(self.backups_created)}",
            "\nTRANSFORMATIONS APPLIED:",
        ]
        
        rule_stats = {}
        for trans in self.transformations:
            rule_name = trans.get('rule', 'Unknown')
            count = trans.get('count', 0)
            rule_stats[rule_name] = rule_stats.get(rule_name, 0) + count
        
        for rule, count in sorted(rule_stats.items()):
            lines.append(f"  ✓ {rule}: {count} instances")
        
        lines.extend([
            "\nDEPENDENCY UPDATES:",
            f"  ✓ Added: liboqs-python>=0.10.0",
            f"  ✓ Kept: pycryptodome (for AES)",
            f"  ✓ Added: cryptography>=41.0.0",
            "\nRECOMMENDATIONS:",
            "  1. Review all backups (.py.backup files)",
            "  2. Run unit tests to verify functionality",
            "  3. Test hybrid mode in development first",
            "  4. Deploy to staging environment",
            "  5. Monitor performance and compatibility",
            "\nNEXT STEPS:",
            "  • Replace secrets (hardcoded keys) with secure vaults",
            "  • Update CI/CD pipelines with new dependencies",
            "  • Train team on post-quantum cryptography",
            "  • Schedule progressive rollout (hybrid → PQC-only)"
        ])
        
        return '\n'.join(lines)
    
    def verify_migration(self, file_path: Path) -> Tuple[bool, List[str]]:
        """Verify migrated file works correctly"""
        issues = []
        
        try:
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Parse to AST to check syntax
            ast.parse(content)
            
            # Check for common issues
            if 'import rsa' in content:
                issues.append("⚠️ Old RSA import still present")
            if 'RSA.generate(' in content:
                issues.append("⚠️ Old RSA.generate() still present")
            if 'oqs' in content and 'import oqs' not in content:
                issues.append("❌ oqs used but not imported")
            
            return len(issues) == 0, issues
        
        except SyntaxError as e:
            return False, [f"Syntax error: {e}"]
        except Exception as e:
            return False, [f"Verification failed: {e}"]
