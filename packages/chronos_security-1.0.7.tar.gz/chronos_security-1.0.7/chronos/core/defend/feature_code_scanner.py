"""
Feature 3.1: Automated Code Scanner for Crypto Detection
Scans code to find every crypto usage and identify quantum vulnerabilities.
"""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Set, Tuple
from collections import defaultdict
import json


@dataclass
class CryptoFinding:
    """Represents a crypto operation found in code"""
    algorithm: str
    key_size: str
    location: str  # file:line
    line_number: int
    context: str  # surrounding code
    purpose: str
    status: str  # QUANTUM VULNERABLE, WARNING, OK
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    recommendation: str
    hardcoded: bool = False
    code_snippet: str = ""


@dataclass
class ScanReport:
    """Summary of code scan results"""
    files_scanned: int = 0
    crypto_instances: int = 0
    by_algorithm: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    findings: List[CryptoFinding] = field(default_factory=list)
    total_risk_score: float = 0.0
    auto_fix_available: int = 0
    manual_review_required: int = 0


class CodeCryptoScanner:
    """Scans code for cryptographic operations and detects quantum vulnerabilities"""
    
    # Patterns for crypto detection
    CRYPTO_PATTERNS = {
        'RSA': {
            'imports': [
                r'from\s+Crypto\.PublicKey\s+import\s+RSA',
                r'import\s+rsa',
                r'from\s+cryptography\.hazmat\.primitives\.asymmetric\s+import\s+rsa',
                r'import\s+javax\.crypto',
                r'import\s+java\.security',
                r"require\('rsa'\)",
                r'#include\s+<openssl/rsa\.h>',
            ],
            'operations': [
                (r'RSA\.generate\((\d+)\)', 'key_generation'),
                (r'RSA\.importKey\(', 'key_import'),
                (r'rsa\.encrypt\(', 'encryption'),
                (r'RSA_generate_key\(', 'key_generation'),
                (r'RSA\.sign\(', 'signing'),
            ]
        },
        'AES': {
            'imports': [
                r'from\s+Crypto\.Cipher\s+import\s+AES',
                r'import\s+hashlib',
                r'javax\.crypto\.Cipher',
                r"require\('crypto'\)",
                r'#include\s+<openssl/aes\.h>',
            ],
            'operations': [
                (r'AES\.new\((\d+),', 'encryption'),
                (r'aes-(\d+)-(gcm|cbc|ctr)', 'encryption'),
                (r'Cipher\.AES', 'encryption'),
            ]
        },
        'ECC': {
            'imports': [
                r'import\s+ecdsa',
                r'from\s+cryptography\.hazmat\.primitives\.asymmetric\s+import\s+ec',
                r'elliptic\.Curve',
                r'ECDSA',
            ],
            'operations': [
                (r'ecdsa\.SigningKey', 'signing'),
                (r"EC\.generate\('([^']+)'\)", 'key_generation'),
                (r'prime256v1|P-256|P-384', 'ecc_curve'),
            ]
        },
        'HASH': {
            'imports': [
                r'import\s+hashlib',
                r'from\s+Crypto\.Hash\s+import',
                r'MessageDigest',
            ],
            'operations': [
                (r'hashlib\.md5\(', 'weak_hash'),
                (r'hashlib\.sha1\(', 'weak_hash'),
                (r'hashlib\.sha256\(', 'strong_hash'),
                (r'hashlib\.sha3\(', 'strong_hash'),
            ]
        }
    }
    
    # File extensions to scan
    SCAN_EXTENSIONS = {
        '.py': 'Python',
        '.java': 'Java',
        '.js': 'JavaScript',
        '.ts': 'TypeScript',
        '.c': 'C',
        '.cpp': 'C++',
        '.h': 'C/C++',
        '.go': 'Go',
        '.rs': 'Rust',
        '.php': 'PHP',
        '.rb': 'Ruby',
        '.kt': 'Kotlin',
    }
    
    # Directories to skip
    SKIP_DIRS = {
        'node_modules', '.git', '__pycache__', '.pytest_cache',
        'build', 'dist', '.venv', 'venv', '.env',
        '.tox', 'htmlcov', 'coverage', '.mypy_cache'
    }
    
    # Quantum vulnerability assessment
    QUANTUM_RISK = {
        'RSA-1024': ('🚨 QUANTUM VULNERABLE', 'CRITICAL', '2028-2030', 'Kyber512'),
        'RSA-2048': ('🚨 QUANTUM VULNERABLE', 'CRITICAL', '2033-2035', 'Kyber768'),
        'RSA-3072': ('🚨 QUANTUM VULNERABLE', 'CRITICAL', '2033-2035', 'Kyber1024'),
        'RSA-4096': ('⚠️ WARNING', 'HIGH', '2036-2038', 'Kyber1024'),
        'ECC-256': ('🚨 QUANTUM VULNERABLE', 'CRITICAL', '2030-2032', 'Kyber768'),
        'ECC-384': ('⚠️ WARNING', 'HIGH', '2035-2037', 'Kyber1024'),
        'AES-128': ('⚠️ WARNING', 'MEDIUM', '2040-2045', 'AES-256'),
        'AES-256': ('✓ SAFE', 'LOW', '2050+', 'Keep'),
        'MD5': ('🚨 BROKEN', 'CRITICAL', 'NOW', 'SHA-256'),
        'SHA1': ('🚨 BROKEN', 'CRITICAL', 'NOW', 'SHA-256'),
        'SHA256': ('✓ SAFE', 'LOW', 'Safe', 'Keep'),
    }
    
    def __init__(self, root_path: str):
        """Initialize scanner with root path"""
        self.root_path = Path(root_path)
        self.report = ScanReport()
        self.findings_by_file = defaultdict(list)
    
    def scan(self) -> ScanReport:
        """Scan directory for crypto operations"""
        all_files = self._discover_files()
        
        for file_path in all_files:
            self._scan_file(file_path)
        
        self._calculate_summary()
        return self.report
    
    def _discover_files(self) -> List[Path]:
        """Discover all code files to scan"""
        files = []
        
        for ext in self.SCAN_EXTENSIONS:
            files.extend(self.root_path.rglob(f'*{ext}'))
        
        # Filter out skip directories
        filtered = []
        for f in files:
            skip = False
            for skip_dir in self.SKIP_DIRS:
                if skip_dir in f.parts:
                    skip = True
                    break
            if not skip:
                filtered.append(f)
        
        return filtered
    
    def _scan_file(self, file_path: Path):
        """Scan single file for crypto operations"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')
        except Exception as e:
            return
        
        self.report.files_scanned += 1
        rel_path = file_path.relative_to(self.root_path)
        
        # Scan for each algorithm
        for algo, patterns in self.CRYPTO_PATTERNS.items():
            self._scan_algorithm(
                algo, patterns, lines, str(rel_path), file_path
            )
    
    def _scan_algorithm(self, algo: str, patterns: Dict, lines: List[str], 
                       rel_path: str, file_path: Path):
        """Scan for specific algorithm patterns"""
        
        # Check imports
        has_import = False
        for import_pattern in patterns.get('imports', []):
            for line in lines:
                if re.search(import_pattern, line, re.IGNORECASE):
                    has_import = True
                    break
        
        if not has_import:
            return
        
        # Search for operations
        full_content = '\n'.join(lines)
        
        for op_pattern, op_type in patterns.get('operations', []):
            for match in re.finditer(op_pattern, full_content, re.IGNORECASE):
                line_num = full_content[:match.start()].count('\n') + 1
                
                # Extract context
                start_line = max(0, line_num - 6)
                end_line = min(len(lines), line_num + 5)
                context = '\n'.join(lines[start_line:end_line])
                code_snippet = lines[line_num - 1] if line_num <= len(lines) else ""
                
                # Determine key size if present
                key_size = self._extract_key_size(match.group(), algo)
                
                # Create finding
                finding = self._create_finding(
                    algo, key_size, f"{rel_path}:{line_num}",
                    line_num, context, op_type, code_snippet
                )
                
                if finding:
                    self.findings_by_file[rel_path].append(finding)
                    self.report.findings.append(finding)
                    self.report.crypto_instances += 1
                    
                    # Count by algorithm
                    algo_key = f"{algo}-{key_size}" if key_size else algo
                    self.report.by_algorithm[algo_key] += 1
    
    def _extract_key_size(self, match_str: str, algo: str) -> str:
        """Extract key size from match string"""
        # RSA-2048, RSA-4096, etc.
        size_match = re.search(r'(\d{3,4})', match_str)
        if size_match:
            size = size_match.group(1)
            return size
        
        # Map common names
        if 'prime256v1' in match_str or 'p256' in match_str:
            return '256'
        if 'p384' in match_str:
            return '384'
        
        # Default sizes by algorithm
        if algo == 'RSA':
            return '2048'
        if algo == 'ECC':
            return '256'
        if algo == 'AES':
            return '256'
        
        return ''
    
    def _create_finding(self, algo: str, key_size: str, location: str,
                       line_num: int, context: str, purpose: str,
                       code_snippet: str) -> CryptoFinding:
        """Create a finding object with risk assessment"""
        
        # Determine quantum risk
        algo_key = f"{algo}-{key_size}" if key_size else algo
        
        if algo_key in self.QUANTUM_RISK:
            status, severity, timeline, rec_algo = self.QUANTUM_RISK[algo_key]
            recommendation = f"Replace with: {rec_algo}"
        else:
            # Default assessment
            if algo == 'RSA' and int(key_size or 2048) < 2048:
                status = '🚨 QUANTUM VULNERABLE'
                severity = 'CRITICAL'
                recommendation = 'Increase key size or use Kyber'
            elif algo == 'ECC':
                status = '🚨 QUANTUM VULNERABLE'
                severity = 'CRITICAL'
                recommendation = 'Replace with Kyber'
            elif algo == 'AES':
                status = '⚠️ WARNING'
                severity = 'MEDIUM'
                recommendation = 'Monitor; may need doubling'
            else:
                status = '✓ SAFE'
                severity = 'LOW'
                recommendation = 'No action needed'
        
        # Check for hardcoded keys
        hardcoded = bool(re.search(r'(-----BEGIN|password|secret|key)\s*=\s*["\']', 
                                   context, re.IGNORECASE))
        
        return CryptoFinding(
            algorithm=algo,
            key_size=key_size,
            location=location,
            line_number=line_num,
            context=context,
            purpose=purpose,
            status=status,
            severity=severity,
            recommendation=recommendation,
            hardcoded=hardcoded,
            code_snippet=code_snippet
        )
    
    def _calculate_summary(self):
        """Calculate summary statistics"""
        # Count auto-fixable findings
        for finding in self.report.findings:
            if finding.severity in ['CRITICAL', 'HIGH']:
                if finding.algorithm in ['RSA', 'ECC']:
                    self.report.auto_fix_available += 1
                else:
                    self.report.manual_review_required += 1
            else:
                self.report.manual_review_required += 1
        
        # Calculate risk score
        risk_weights = {
            'CRITICAL': 100,
            'HIGH': 50,
            'MEDIUM': 25,
            'LOW': 5
        }
        
        total_score = sum(
            risk_weights.get(f.severity, 0) for f in self.report.findings
        )
        self.report.total_risk_score = min(total_score, 1000)
    
    def get_report_text(self) -> str:
        """Generate human-readable report"""
        lines = [
            "🔍 CODE CRYPTO SCAN RESULTS",
            "=" * 50,
            f"\nFILES SCANNED: {self.report.files_scanned}",
            f"CRYPTO USAGE FOUND: {self.report.crypto_instances} instances",
            "\nBREAKDOWN BY ALGORITHM:"
        ]
        
        for algo_key, count in sorted(self.report.by_algorithm.items()):
            lines.append(f"  {algo_key}: {count} instances")
        
        # Critical findings
        critical = [f for f in self.report.findings if f.severity == 'CRITICAL']
        if critical:
            lines.extend(["\nCRITICAL FINDINGS:", "-" * 30])
            for i, finding in enumerate(critical[:5], 1):
                lines.extend([
                    f"\n{i}. {finding.location}",
                    f"   Algorithm: {finding.algorithm}-{finding.key_size}",
                    f"   Purpose: {finding.purpose}",
                    f"   Severity: {finding.severity}",
                    f"   Status: {finding.status}",
                    f"   Recommendation: {finding.recommendation}",
                    f"   Code: {finding.code_snippet[:60]}..."
                ])
            if len(critical) > 5:
                lines.append(f"\n... and {len(critical) - 5} more critical findings")
        
        lines.extend([
            f"\n{'=' * 50}",
            f"AUTO-FIX AVAILABLE: {self.report.auto_fix_available}/",
            f"{self.report.crypto_instances} instances",
            f"MANUAL REVIEW REQUIRED: {self.report.manual_review_required} instances",
            f"TOTAL RISK SCORE: {self.report.total_risk_score:.0f}/1000"
        ])
        
        return '\n'.join(lines)
    
    def export_json(self) -> str:
        """Export report as JSON"""
        data = {
            'files_scanned': self.report.files_scanned,
            'crypto_instances': self.report.crypto_instances,
            'by_algorithm': dict(self.report.by_algorithm),
            'total_risk_score': self.report.total_risk_score,
            'auto_fix_available': self.report.auto_fix_available,
            'manual_review_required': self.report.manual_review_required,
            'critical_findings': [
                {
                    'location': f.location,
                    'algorithm': f.algorithm,
                    'key_size': f.key_size,
                    'severity': f.severity,
                    'recommendation': f.recommendation
                }
                for f in self.report.findings[:10] if f.severity == 'CRITICAL'
            ]
        }
        return json.dumps(data, indent=2)
