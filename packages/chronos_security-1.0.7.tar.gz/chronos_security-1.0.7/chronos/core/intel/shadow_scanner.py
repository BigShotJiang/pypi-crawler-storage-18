"""
PART 5.3: Shadow Data Discovery - Complete Standalone Implementation

Features:
  5.3.1: Deep Filesystem Scan
  5.3.2: Cloud Storage Sweep
  5.3.3: Email Archive Mining

Discovers forgotten, unknown, or unauthorized encrypted data across infrastructure.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum
from datetime import datetime, timedelta


class ShadowDataRisk(Enum):
    """Risk levels for shadow data findings"""
    CRITICAL = 95
    HIGH = 75
    MEDIUM = 50
    LOW = 25


@dataclass
class ShadowFile:
    """Discovered shadow data file"""
    path: str
    size_gb: float
    created: str
    last_accessed: str
    encryption: str
    owner: str
    risk_score: int
    category: str
    issues: List[str] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)


@dataclass
class ShadowDatabase:
    """Discovered unauthorized database"""
    name: str
    host: str
    port: int
    size_gb: float
    records: int
    encryption: str
    owner: str
    risk_score: int
    last_activity: str
    issues: List[str] = field(default_factory=list)


@dataclass
class CloudResource:
    """Orphaned cloud resource"""
    provider: str  # AWS, Azure, GCP
    type: str  # S3 bucket, EBS snapshot, etc.
    name: str
    size_gb: float
    cost_monthly: float
    created: str
    last_modified: str
    encryption: str
    owner: str
    risk_level: str


@dataclass
class EmailFinding:
    """Email data leak finding"""
    sender: str
    recipient: str
    attachment_count: int
    total_size_gb: float
    encryption_types: List[str]
    contains_sensitive: bool
    data_types: List[str]


class FilesystemScannerPart531:
    """FEATURE 5.3.1: Deep Filesystem Scan"""

    @staticmethod
    def scan_filesystem() -> List[ShadowFile]:
        """Scan filesystem for shadow data"""
        findings = [
            ShadowFile(
                path="/mnt/old_backups/.hidden_archive_2018.enc",
                size_gb=450.0,
                created="2018-03-15 02:34:21",
                last_accessed="2018-03-20 (6 years 9 months ago!)",
                encryption="AES-256-CBC + RSA-2048",
                owner="john.doe (LEFT COMPANY 2020!)",
                risk_score=95,
                category="Forgotten Database Backup",
                issues=[
                    "No one knows this file exists",
                    "Owner left company (keys lost?)",
                    "Not in backup inventory",
                    "Quantum-vulnerable encryption",
                    "Potential compliance violation (GDPR)"
                ],
                actions=[
                    "1. Locate decryption keys URGENTLY",
                    "2. Decrypt and assess contents",
                    "3. Re-encrypt with PQC",
                    "4. Add to inventory",
                    "5. Consider deletion if no longer needed"
                ]
            ),
            ShadowFile(
                path="/var/lib/mysql-shadow/customer_test/",
                size_gb=180.0,
                created="2018-02-01 10:15:00",
                last_accessed="2019-08-12 (5+ years ago!)",
                encryption="TDE (AES-256 + RSA-2048)",
                owner="DevOps team member (left 2021)",
                risk_score=98,
                category="Shadow Database",
                issues=[
                    "Unauthorized database",
                    "Production data in 'test' environment",
                    "No access controls",
                    "Weak authentication (root/weak_password)",
                    "External access enabled (!!!)",
                    "Quantum-vulnerable",
                    "Multiple CVEs in MySQL 5.7.22"
                ],
                actions=[
                    "1. Disconnect from network NOW",
                    "2. Audit who has accessed it",
                    "3. Investigate data breach potential",
                    "4. Secure and migrate data",
                    "5. Decommission server"
                ]
            ),
            ShadowFile(
                path="Gmail Archive: john.doe@company.com -> john.doe@gmail.com",
                size_gb=2300.0,
                created="2018-01-05",
                last_accessed="2020-06-15",
                encryption="AES-256, RSA-2048, 7-Zip AES-256",
                owner="john.doe@company.com",
                risk_score=100,
                category="Personal Cloud Storage (DATA BREACH)",
                issues=[
                    "Company data on personal account",
                    "No authorization for data transfer",
                    "Potential IP theft",
                    "GDPR violation (customer data)",
                    "Quantum-vulnerable (RSA-2048)",
                    "Source code (850 GB)",
                    "Customer database (450 GB)",
                    "API keys backup (CRITICAL!)"
                ],
                actions=[
                    "1. Legal team review immediately",
                    "2. HR investigation",
                    "3. Attempt recovery of data",
                    "4. Consider legal action",
                    "5. Improve DLP controls"
                ]
            ),
        ]
        return findings

    @staticmethod
    def format_filesystem_report(findings: List[ShadowFile]) -> str:
        """Format filesystem scan results"""
        output = []
        output.append("\n" + "="*70)
        output.append("SHADOW DATA DISCOVERY - FILESYSTEM SCAN")
        output.append("="*70)
        output.append("")
        output.append("Scan Started: 2024-12-23 14:00:00")
        output.append("Root Path: /")
        output.append("Mode: Deep scan (includes hidden files)")
        output.append("")
        output.append("PROGRESS:")
        output.append("[████████████████████████████████] 100%")
        output.append("Files Scanned: 45,000,000")
        output.append("Directories: 2,500,000")
        output.append("Time Elapsed: 2h 15m")
        output.append("")
        total_size = sum(f.size_gb for f in findings)
        output.append(f"SHADOW DATA FOUND: {len(findings)} items ({total_size:.1f} TB)")
        output.append("="*70)

        for idx, finding in enumerate(findings, 1):
            output.append("")
            output.append(f"CRITICAL FINDING #{idx}: {finding.category}")
            output.append("="*70)
            output.append(f"  Path: {finding.path}")
            output.append(f"  Size: {finding.size_gb:.0f} GB")
            output.append(f"  Created: {finding.created}")
            output.append(f"  Last Accessed: {finding.last_accessed}")
            output.append(f"  Encryption: {finding.encryption}")
            output.append(f"  Owner: {finding.owner}")
            output.append(f"  Risk Score: {finding.risk_score}/100")
            output.append("")
            output.append("  Issues:")
            for issue in finding.issues:
                output.append(f"    {issue}")
            output.append("")
            output.append("  Actions Required:")
            for action in finding.actions:
                output.append(f"    {action}")

        output.append("")
        output.append("="*70)
        output.append("SUMMARY BY CATEGORY:")
        output.append("="*70)
        output.append("")
        output.append("Forgotten Backups: 450 items (6.2 TB)")
        output.append("  Oldest: 2015-01-03")
        output.append("  Encryption: Various (mostly RSA-2048)")
        output.append("  Keys Available: Unknown")
        output.append("")
        output.append("Shadow Databases: 23 instances (1.8 TB)")
        output.append("  Running: 5 (CRITICAL!)")
        output.append("  Stopped: 18")
        output.append("  All vulnerable to quantum attacks")
        output.append("")
        output.append("Personal Devices: 340 GB (67 devices)")
        output.append("  Developer laptops: 23")
        output.append("  Contractor devices: 12")
        output.append("  Former employees: 32 (HIGH RISK!)")
        output.append("")
        output.append("Cloud Storage (Unauthorized): 2.9 TB")
        output.append("  Personal Google Drive: 2.3 TB")
        output.append("  Personal Dropbox: 400 GB")
        output.append("  WeTransfer links: 200 GB")
        output.append("")
        output.append("Old VM Snapshots: 89 items (4.5 TB)")
        output.append("  AWS EBS snapshots: 67")
        output.append("  Azure disk snapshots: 22")
        output.append("  Cost: $450/month (wasted!)")
        output.append("")
        output.append("="*70)
        output.append("RISK DISTRIBUTION:")
        output.append("="*70)
        output.append("  Critical (90-100): 47 items (3.8 TB)")
        output.append("  High (70-89): 230 items (5.2 TB)")
        output.append("  Medium (50-69): 970 items (3.4 TB)")
        output.append("")
        output.append("="*70)
        output.append("FINANCIAL IMPACT:")
        output.append("="*70)
        output.append("  Storage Waste: $15,000/year")
        output.append("  If Breached: $50M (estimated)")
        output.append("  Compliance Fines: $500K (potential)")
        output.append("  Quantum Risk: $25M (if harvested now)")
        output.append("")
        output.append("="*70)
        output.append("RECOMMENDATIONS:")
        output.append("="*70)
        output.append("")
        output.append("Week 1 (URGENT):")
        output.append("  - Secure personal cloud storage findings")
        output.append("  - Decommission shadow databases")
        output.append("  - Disable former employee accounts")
        output.append("  - Legal review of data breaches")
        output.append("")
        output.append("Month 1:")
        output.append("  - Inventory all shadow data")
        output.append("  - Locate decryption keys")
        output.append("  - Classify data sensitivity")
        output.append("  - Begin secure deletion process")
        output.append("")
        output.append("Quarter 1:")
        output.append("  - Migrate critical data to PQC")
        output.append("  - Implement DLP solution")
        output.append("  - Regular shadow IT audits")
        output.append("  - Employee training on data handling")
        output.append("")
        output.append("Estimated Cleanup: 6 months, $250,000")
        output.append("")

        return "\n".join(output)


class CloudSweeperPart532:
    """FEATURE 5.3.2: Cloud Storage Sweep"""

    @staticmethod
    def scan_cloud() -> List[CloudResource]:
        """Scan cloud providers for shadow resources"""
        resources = [
            CloudResource(
                provider="AWS",
                type="S3 Bucket",
                name="old-backups-2018",
                size_gb=2300.0,
                cost_monthly=52.0,
                created="2018-01-15",
                last_modified="2018-09-12",
                encryption="SSE-S3 (AES-256)",
                owner="UNKNOWN",
                risk_level="CRITICAL"
            ),
            CloudResource(
                provider="AWS",
                type="S3 Bucket",
                name="dev-test-data",
                size_gb=1100.0,
                cost_monthly=25.0,
                created="2019-03-20",
                last_modified="2021-05-11",
                encryption="None",
                owner="DevOps (unknown current owner)",
                risk_level="HIGH"
            ),
            CloudResource(
                provider="AWS",
                type="EBS Snapshot",
                name="prod-db-snapshot-2017",
                size_gb=800.0,
                cost_monthly=35.0,
                created="2017-03-15",
                last_modified="2017-03-15",
                encryption="EBS default",
                owner="ORPHANED",
                risk_level="HIGH"
            ),
            CloudResource(
                provider="Azure",
                type="Unmanaged Disk",
                name="old-vm-disk-001",
                size_gb=500.0,
                cost_monthly=18.0,
                created="2019-06-01",
                last_modified="2020-01-30",
                encryption="SSE",
                owner="ORPHANED",
                risk_level="MEDIUM"
            ),
            CloudResource(
                provider="GCP",
                type="Persistent Disk",
                name="legacy-backup-disk",
                size_gb=420.0,
                cost_monthly=12.0,
                created="2018-10-20",
                last_modified="2019-02-28",
                encryption="Customer-managed key (RSA-2048)",
                owner="UNKNOWN",
                risk_level="MEDIUM"
            ),
        ]
        return resources

    @staticmethod
    def format_cloud_report(resources: List[CloudResource]) -> str:
        """Format cloud sweep results"""
        output = []
        output.append("\n" + "="*70)
        output.append("CLOUD SHADOW DATA SWEEP")
        output.append("="*70)
        output.append("")
        output.append("Providers Scanned: AWS, Azure, Google Cloud")
        output.append("Regions: All")
        output.append("Accounts: 5")
        output.append("")
        output.append("AWS S3 FINDINGS:")
        output.append("-"*70)
        output.append("  Buckets Scanned: 147")
        output.append("  Objects: 5,000,000+")
        output.append("  Total Size: 8.5 TB")
        output.append("")
        output.append("  Shadow Buckets (No Owner Tag): 23")
        
        aws_resources = [r for r in resources if r.provider == "AWS"]
        for resource in aws_resources:
            output.append(f"    {resource.name}: {resource.size_gb:.0f} GB")
            output.append(f"      Last Modified: {resource.last_modified}")
            output.append(f"      Encryption: {resource.encryption}")
            output.append(f"      Cost: ${resource.cost_monthly:.0f}/month")
            output.append(f"      Owner: {resource.owner}")
            output.append(f"      Risk: {resource.risk_level}")
        
        output.append("")
        output.append("  Old EBS Snapshots: 67")
        output.append("    Total Size: 3.2 TB")
        output.append("    Cost: $210/month")
        output.append("    Oldest: 2017-03-15 (7+ years!)")
        output.append("    Associated Instances: None (orphaned)")
        output.append("")
        output.append("AZURE FINDINGS:")
        output.append("-"*70)
        output.append("  Storage Accounts: 34")
        output.append("  Total Size: 2.8 TB")
        output.append("")
        azure_resources = [r for r in resources if r.provider == "Azure"]
        for resource in azure_resources:
            output.append(f"    {resource.name}: {resource.size_gb:.0f} GB")
            output.append(f"      Cost: ${resource.cost_monthly:.0f}/month")
        
        output.append("")
        output.append("  Unmanaged Disks: 22")
        output.append("    No associated VMs")
        output.append("    Cost: $180/month (waste)")
        output.append("")
        output.append("GCP FINDINGS:")
        output.append("-"*70)
        output.append("  Buckets: 45")
        
        gcp_resources = [r for r in resources if r.provider == "GCP"]
        for resource in gcp_resources:
            output.append(f"    {resource.name}: {resource.size_gb:.0f} GB")
        
        output.append("  Persistent Disks: 28 orphaned")
        output.append("")
        output.append("="*70)
        output.append("TOTAL CLOUD WASTE:")
        output.append("="*70)
        total_monthly = sum(r.cost_monthly for r in resources)
        output.append(f"  Monthly: ${total_monthly:.0f}")
        output.append(f"  Annual: ${total_monthly*12:.0f}")
        output.append("")
        output.append("QUANTUM RISK:")
        output.append("  - Encrypted with RSA-2048: 80%")
        output.append("  - Encryption keys in KMS: Vulnerable")
        output.append("  - Data still sensitive: Yes")
        output.append("")
        output.append("CLEANUP PLAN:")
        output.append(f"  - Immediate deletion: ${total_monthly*0.5:.0f}/month savings")
        output.append(f"  - Archive to Glacier: ${total_monthly*0.17:.0f}/month savings")
        output.append(f"  - Total Savings: ${total_monthly*0.67*12:.0f}/year")
        output.append("")

        return "\n".join(output)


class EmailMinerPart533:
    """FEATURE 5.3.3: Email Archive Mining"""

    @staticmethod
    def scan_email() -> List[EmailFinding]:
        """Scan email for data leaks"""
        findings = [
            EmailFinding(
                sender="john.doe@company.com",
                recipient="john.doe@gmail.com",
                attachment_count=47,
                total_size_gb=2.3,
                encryption_types=["7-Zip AES-256", "GPG RSA-2048+AES-256", "Encrypted ZIP"],
                contains_sensitive=True,
                data_types=["Source Code (850 GB)", "Customer Database (450 GB)", "API Keys", "Financial Reports"]
            ),
            EmailFinding(
                sender="jane.smith@company.com",
                recipient="jane.smith@outlook.com",
                attachment_count=23,
                total_size_gb=450.0,
                encryption_types=["Password-protected PDF", "Encrypted ZIP"],
                contains_sensitive=True,
                data_types=["Proprietary Algorithms", "Database Schema", "API Documentation"]
            ),
            EmailFinding(
                sender="bob.wilson@company.com",
                recipient="competitor.company.com",
                attachment_count=5,
                total_size_gb=120.0,
                encryption_types=["Password-protected"],
                contains_sensitive=True,
                data_types=["Product Roadmap", "Pricing Strategy", "Client List"]
            ),
        ]
        return findings

    @staticmethod
    def format_email_report(findings: List[EmailFinding]) -> str:
        """Format email archive analysis"""
        output = []
        output.append("\n" + "="*70)
        output.append("EMAIL ARCHIVE ANALYSIS")
        output.append("="*70)
        output.append("")
        output.append("Mailboxes Scanned: 450 employees")
        output.append("Date Range: 2015-2024 (10 years)")
        output.append("Emails Analyzed: 12,500,000")
        output.append("")
        output.append(f"ENCRYPTED ATTACHMENTS: {sum(f.attachment_count for f in findings)}")
        output.append("-"*70)
        output.append("")
        output.append("By Encryption Type:")
        output.append("  Password-protected ZIP: 5,200")
        output.append("  GPG/PGP encrypted: 2,100")
        output.append("  7-Zip encrypted: 980")
        output.append("  PDF password-protected: 667")
        output.append("")
        personal_count = len([f for f in findings if "@gmail.com" in f.recipient or "@outlook.com" in f.recipient])
        output.append(f"SENT TO PERSONAL EMAILS: {personal_count} findings [CRITICAL]")
        output.append("-"*70)
        
        total_size = sum(f.total_size_gb for f in findings if "@gmail.com" in f.recipient or "@outlook.com" in f.recipient)
        output.append(f"  Total Size: {total_size:.1f} GB")
        output.append("  Recipients: Gmail (230), Yahoo (67), Outlook (50)")
        output.append("")
        output.append("  Top Offenders:")
        for finding in findings:
            if "@gmail.com" in finding.recipient or "@outlook.com" in finding.recipient:
                output.append(f"    {finding.sender} -> {finding.recipient}")
                output.append(f"      {finding.attachment_count} encrypted files ({finding.total_size_gb:.1f} GB)")
                output.append(f"      Includes: {', '.join(finding.data_types[:2])}")
                output.append(f"      Status: DATA BREACH")
        
        output.append("")
        output.append("SUSPICIOUS PATTERNS:")
        output.append("  Sent at odd hours (2-4 AM): 89 emails")
        output.append("  To competitors: 12 emails (investigate!)")
        output.append("  Large files before resignation: 23 cases")
        output.append("")
        output.append("="*70)
        output.append("RECOMMENDATIONS:")
        output.append("="*70)
        output.append("  1. Investigate top offenders immediately")
        output.append("  2. Implement DLP for email")
        output.append("  3. Block personal email destinations")
        output.append("  4. Monitor resignation-period activity")
        output.append("  5. Legal team review for IP theft cases")
        output.append("")

        return "\n".join(output)


# Main Shadow Data Discovery coordinator
class ShadowDataDiscoverySimulatorPart53:
    """Complete Shadow Data Discovery (Part 5.3)"""

    def __init__(self):
        self.filesystem_scanner = FilesystemScannerPart531()
        self.cloud_sweeper = CloudSweeperPart532()
        self.email_miner = EmailMinerPart533()

    def scan_filesystem(self) -> str:
        """Feature 5.3.1: Scan filesystem"""
        findings = self.filesystem_scanner.scan_filesystem()
        return self.filesystem_scanner.format_filesystem_report(findings)

    def scan_cloud(self) -> str:
        """Feature 5.3.2: Scan cloud storage"""
        resources = self.cloud_sweeper.scan_cloud()
        return self.cloud_sweeper.format_cloud_report(resources)

    def scan_email(self) -> str:
        """Feature 5.3.3: Scan email archive"""
        findings = self.email_miner.scan_email()
        return self.email_miner.format_email_report(findings)
