"""
CLI Commands for MODULE 4: SIMULATE
Integrates all 4 parts:
  Part 4.1: Shor's Algorithm (RSA factoring)
  Part 4.2: Grover's Algorithm (Key search)
  Part 4.3: Resource Estimator
  Part 4.4: Timeline Visualizer
"""

from typing import Optional
import typer
from rich.console import Console
from rich.panel import Panel

from chronos.core.simulate.shor_part_4_1 import ShorSimulatorPart41
from chronos.core.simulate.grover_part_4_2 import GroverSimulatorPart42
from chronos.core.simulate.resource_estimator_part_4_3 import ResourceEstimatorSimulatorPart43
from chronos.core.simulate.timeline_visualizer_part_4_4 import TimelineVisualizerSimulatorPart44

console = Console()
simulate_features_app = typer.Typer(help="🔬 MODULE 4: SIMULATE - Quantum Algorithm Simulation")


# ========== PART 4.1: SHOR'S ALGORITHM ==========

shor_app = typer.Typer(help="Feature 4.1: Shor's Algorithm Simulator")


@shor_app.command("factor")
def shor_factor(
    number: int = typer.Option(15, "--number", "-n", help="Number to factor (15, 21, 35, 33, 77, 91)"),
):
    """Feature 4.1.1: Small Number Factoring Demo - Simulate Shor's algorithm"""
    console.print()
    shor = ShorSimulatorPart41()
    try:
        result = shor.factor_number(number)
        console.print(result)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@shor_app.command("estimate")
def shor_estimate(
    rsa_bits: int = typer.Option(2048, "--rsa", "-r", help="RSA key size (1024, 2048, 4096)"),
):
    """Feature 4.1.2: RSA Resource Calculator - Estimate resources to break RSA"""
    console.print()
    shor = ShorSimulatorPart41()
    try:
        result = shor.estimate_rsa(rsa_bits)
        console.print(result)
        console.print()
        console.print(shor.compare_rsa_sizes())
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@shor_app.command("circuit")
def shor_circuit(
    number: int = typer.Option(15, "--number", "-n", help="Number to factor"),
    format: str = typer.Option("ascii", "--format", "-f", help="Output format (ascii, qasm)"),
):
    """Feature 4.1.3: Circuit Visualizer - Generate quantum circuit representation"""
    console.print()
    shor = ShorSimulatorPart41()
    try:
        qubits = number.bit_length() + 2
        circuit = shor.visualize_circuit(number, qubits, format)
        
        if format == "qasm":
            console.print("[bold cyan]OpenQASM Code:[/bold cyan]")
            console.print("[dim]" + circuit + "[/dim]")
        else:
            console.print("[bold cyan]Quantum Circuit:[/bold cyan]")
            console.print(circuit)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@shor_app.command("explain")
def shor_explain():
    """Feature 4.1.4: Educational Explanation - Understand Shor's algorithm"""
    console.print()
    shor = ShorSimulatorPart41()
    console.print(shor.explain())
    console.print()


# ========== PART 4.2: GROVER'S ALGORITHM ==========

grover_app = typer.Typer(help="Feature 4.2: Grover's Algorithm Simulator")


@grover_app.command("search")
def grover_search(
    space_size: int = typer.Option(16, "--space", "-s", help="Search space size (power of 2)"),
):
    """Feature 4.2.1: Simple Search Demo - Search for item in quantum superposition"""
    console.print()
    grover = GroverSimulatorPart42()
    try:
        result = grover.simple_search(space_size)
        console.print(result)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@grover_app.command("aes")
def grover_aes(
    bits: int = typer.Option(128, "--bits", "-b", help="AES key size (128, 192, 256)"),
):
    """Feature 4.2.2: AES Key Search Simulator - Analyze quantum attack on AES"""
    console.print()
    grover = GroverSimulatorPart42()
    try:
        if bits not in [128, 192, 256]:
            raise ValueError("AES size must be 128, 192, or 256")
        
        result = grover.aes_analysis(bits)
        console.print(result)
        console.print()
        console.print(grover.aes_comparison())
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@grover_app.command("oracle")
def grover_oracle(
    problem: str = typer.Option("Finding a specific hash", "--problem", "-p", help="Search problem"),
    space_size: int = typer.Option(256, "--space", "-s", help="Search space size"),
):
    """Feature 4.2.3: Interactive Oracle Builder - Build custom search oracle"""
    console.print()
    grover = GroverSimulatorPart42()
    try:
        result = grover.build_custom_oracle(problem, space_size)
        console.print(result)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


@grover_app.command("visualize")
def grover_visualize(
    space_size: int = typer.Option(16, "--space", "-s", help="Search space size"),
):
    """Feature 4.2.4: Amplitude Amplification Visualizer - See how quantum amplification works"""
    console.print()
    grover = GroverSimulatorPart42()
    try:
        result = grover.visualize_amplification(space_size)
        console.print(result)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
    console.print()


# ========== MODULE COMMANDS ==========

@simulate_features_app.command("module-status")
def module_status():
    """Show MODULE 4: SIMULATE status and available features"""
    console.print()
    
    # Header
    console.print(Panel(
        "[bold cyan]🔬 MODULE 4: SIMULATE - Quantum Algorithm Simulation[/bold cyan]\n"
        "[cyan]Part 4.1: Shor's Algorithm (RSA Breaking)[/cyan]\n"
        "[cyan]Part 4.2: Grover's Algorithm (Key Search)[/cyan]\n"
        "[cyan]Part 4.3: Resource Estimator[/cyan]\n"
        "[cyan]Part 4.4: Timeline Visualizer[/cyan]",
        expand=False
    ))
    
    console.print("\n[bold]Part 4.1: Shor's Algorithm Features[/bold]")
    console.print("  [cyan]shor factor[/cyan]       - Factor small numbers using Shor's algorithm")
    console.print("  [cyan]shor estimate[/cyan]     - Estimate resources to break RSA keys")
    console.print("  [cyan]shor circuit[/cyan]      - Visualize quantum circuits (ASCII/QASM)")
    console.print("  [cyan]shor explain[/cyan]      - Educational explanation of the algorithm")
    
    console.print("\n[bold]Part 4.2: Grover's Algorithm Features[/bold]")
    console.print("  [cyan]grover search[/cyan]     - Search for items in quantum superposition")
    console.print("  [cyan]grover aes[/cyan]        - Analyze quantum attacks on AES encryption")
    console.print("  [cyan]grover oracle[/cyan]     - Build custom quantum search oracles")
    console.print("  [cyan]grover visualize[/cyan]  - Visualize amplitude amplification")
    
    console.print("\n[bold]Part 4.3: Resource Estimator Features[/bold]")
    console.print("  [cyan]resources system[/cyan]  - Calculate per-system quantum resources")
    console.print("  [cyan]resources hardware[/cyan]- Show current quantum computer landscape")
    console.print("  [cyan]resources compare[/cyan] - Algorithm vulnerability comparison table")
    console.print("  [cyan]resources migration[/cyan]- Cost-time tradeoff analysis")
    
    console.print("\n[bold]Part 4.4: Timeline Visualizer Features[/bold]")
    console.print("  [cyan]timeline ascii[/cyan]    - Display ASCII timeline of quantum threats")
    console.print("  [cyan]timeline gantt[/cyan]    - Show migration Gantt chart")
    console.print("  [cyan]timeline scenarios[/cyan]- Model different Q-Day scenarios")
    console.print("  [cyan]timeline web[/cyan]      - Interactive web timeline (production)")
    
    console.print("\n[bold cyan]Quick Examples:[/bold cyan]")
    console.print("  [dim]chronos simulate shor factor --number 15[/dim]")
    console.print("  [dim]chronos simulate grover search --space 16[/dim]")
    console.print("  [dim]chronos simulate resources migration[/dim]")
    console.print("  [dim]chronos simulate timeline ascii[/dim]")
    
    console.print()


# ========== PART 4.3: RESOURCE ESTIMATOR ==========

resources_app = typer.Typer(help="Feature 4.3: Quantum Resource Estimator")


@resources_app.command("system")
def resources_system(
    system_id: str = typer.Option("SYS-001", "--id", "-i", help="System identifier"),
    system_name: str = typer.Option("Customer Database", "--name", "-n", help="System name"),
    algorithm: str = typer.Option("RSA-2048", "--algo", "-a", help="Cryptographic algorithm"),
    data_risk: float = typer.Option(847e6, "--data", "-d", help="Data at risk (USD)"),
):
    """Feature 4.3.1: Calculate quantum resources to break a specific system"""
    console.print()
    estimator = ResourceEstimatorSimulatorPart43()
    result = estimator.estimate_system(system_id, system_name, algorithm, data_risk)
    console.print(result)
    console.print()


@resources_app.command("hardware")
def resources_hardware():
    """Feature 4.3.2: Show current quantum computer landscape"""
    console.print()
    estimator = ResourceEstimatorSimulatorPart43()
    console.print(estimator.hardware_status())
    console.print()


@resources_app.command("compare")
def resources_compare():
    """Feature 4.3.3: Generate algorithm vulnerability comparison table"""
    console.print()
    estimator = ResourceEstimatorSimulatorPart43()
    console.print(estimator.comparison_table())
    console.print()


@resources_app.command("migration")
def resources_migration(
    systems: int = typer.Option(1247, "--systems", "-s", help="Total systems to migrate"),
):
    """Feature 4.3.4: Calculate migration cost-time tradeoffs"""
    console.print()
    estimator = ResourceEstimatorSimulatorPart43()
    console.print(estimator.migration_cost_analysis(systems))
    console.print()


# ========== PART 4.4: TIMELINE VISUALIZER ==========

timeline_app = typer.Typer(help="Feature 4.4: Attack Timeline Visualizer")


@timeline_app.command("ascii")
def timeline_ascii():
    """Feature 4.4.1: Display ASCII art timeline"""
    console.print()
    visualizer = TimelineVisualizerSimulatorPart44()
    console.print(visualizer.show_ascii_timeline())
    console.print()


@timeline_app.command("gantt")
def timeline_gantt():
    """Feature 4.4.3: Show migration Gantt chart"""
    console.print()
    visualizer = TimelineVisualizerSimulatorPart44()
    console.print(visualizer.show_gantt_chart())
    console.print()


@timeline_app.command("scenarios")
def timeline_scenarios():
    """Feature 4.4.4: Model different Q-Day scenarios"""
    console.print()
    visualizer = TimelineVisualizerSimulatorPart44()
    console.print(visualizer.show_scenarios())
    console.print()


@timeline_app.command("web")
def timeline_web():
    """Feature 4.4.2: Interactive web timeline (production deployment)"""
    console.print()
    visualizer = TimelineVisualizerSimulatorPart44()
    console.print(visualizer.show_web_timeline())
    console.print()


# Register sub-apps
simulate_features_app.add_typer(resources_app, name="resources", help="Part 4.3: Resource Estimator")
simulate_features_app.add_typer(timeline_app, name="timeline", help="Part 4.4: Timeline Visualizer")
