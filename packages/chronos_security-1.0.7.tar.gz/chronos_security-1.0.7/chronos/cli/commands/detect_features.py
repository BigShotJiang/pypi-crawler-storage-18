"""
Integrated DETECT Module Commands - Features 1.1-1.5
===================================================

Unified CLI commands for all detection features:
1.1 Real-Time Network Traffic Monitor
1.2 TLS/SSL Cipher Suite Analyzer  
1.3 Dark Web Monitoring
1.4 Behavioral Anomaly Detection
1.5 Encrypted Data Inventory Scanner
"""

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from pathlib import Path
from typing import Optional, List

# Import all feature modules
from chronos.core.detect.feature_network_monitor import NetworkTrafficMonitor
from chronos.core.detect.feature_tls_analyzer import TLSCipherAnalyzer
from chronos.core.detect.feature_darkweb_monitor import DataFingerprinter, DarkWebMonitor
from chronos.core.detect.feature_anomaly_detection import BaselineProfile, AnomalyDetector
from chronos.core.detect.feature_inventory_scanner import EncryptedDataInventory

console = Console()

detect_features = typer.Typer(
    name="features",
    help="🔬 Advanced detection features (1.1-1.5)",
    no_args_is_help=True,
)


# ============================================================================
# Feature 1.1: Real-Time Network Traffic Monitor
# ============================================================================

@detect_features.command("network-monitor")
def network_monitor_cmd(
    duration: int = typer.Option(60, "--duration", "-d", help="Monitor duration in seconds"),
    baseline_learn: bool = typer.Option(False, "--learn-baseline", help="Learn baseline traffic patterns"),
) -> None:
    """
    📡 Feature 1.1: Real-Time Network Traffic Monitor
    
    Captures and analyzes network packets to detect:
    - HNDL attack patterns
    - Suspicious encrypted transfers
    - Data exfiltration attempts
    - Unusual network behavior
    """
    console.print(Panel("[bold cyan]Feature 1.1: Network Traffic Monitor[/bold cyan]", border_style="cyan"))
    
    monitor = NetworkTrafficMonitor()
    
    if baseline_learn:
        console.print("\n[bold]Phase 1:[/bold] Learning baseline traffic patterns...")
        baseline = monitor.learn_baseline(duration_hours=1)
        console.print("[green]✓[/green] Baseline created:")
        console.print(f"  • Average bytes/hour: {baseline['avg_bytes_per_hour']:,}")
        console.print(f"  • Max destinations: {baseline['max_destinations']}")
        console.print(f"  • Business hours: {baseline['normal_hours']}")
    
    console.print(f"\n[bold]Phase 2:[/bold] Monitoring network traffic ({duration}s)...")
    console.print("[dim]Analyzing packets for anomalies and HNDL attacks...[/dim]\n")
    
    # Simulate packet capture and analysis
    import time
    progress = 0
    while progress < duration:
        progress += 5
        percent = min(100, int((progress / duration) * 100))
        console.print(f"[{'=' * percent}{'.' * (100-percent)}] {percent}%", end="\r")
        time.sleep(0.5)
    
    summary = monitor.get_traffic_summary()
    suspicious = monitor.get_suspicious_ips()
    
    console.print("\n\n[bold cyan]═══ Network Monitor Results ═══[/bold cyan]")
    
    table = Table(title="Traffic Summary", border_style="cyan")
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="white")
    table.add_row("Packets Analyzed", str(summary['total_packets_analyzed']))
    table.add_row("Alerts Generated", str(summary['total_alerts']))
    table.add_row("Baseline Learned", "Yes" if summary['baseline_learned'] else "No")
    console.print(table)
    
    if suspicious:
        console.print("\n[red]🚨 Suspicious IPs Detected:[/red]\n")
        for alert in suspicious[:5]:
            console.print(f"[red]  ✗ {alert['src_ip']} → {alert['dst_ip']}[/red]")
            console.print(f"    Risk Score: {alert['risk_score']:.1f} | Severity: {alert['severity']}")
            console.print(f"    Flags: {', '.join(alert['details'])}\n")
    else:
        console.print("\n[green]✓ No suspicious traffic detected[/green]")


# ============================================================================
# Feature 1.2: TLS/SSL Cipher Suite Analyzer
# ============================================================================

@detect_features.command("tls-analyzer")
def tls_analyzer_cmd(
    hostname: str = typer.Option(None, "--host", "-h", help="Hostname to analyze"),
    port: int = typer.Option(443, "--port", "-p", help="Port to connect to"),
    batch: bool = typer.Option(False, "--batch", help="Run batch analysis on common hosts"),
) -> None:
    """
    🔐 Feature 1.2: TLS/SSL Cipher Suite Analyzer
    
    Analyzes TLS configurations to identify:
    - Quantum-vulnerable cipher suites
    - Weak key sizes
    - Insecure protocols
    - Certificate vulnerabilities
    """
    console.print(Panel("[bold cyan]Feature 1.2: TLS/SSL Cipher Analyzer[/bold cyan]", border_style="cyan"))
    
    analyzer = TLSCipherAnalyzer()
    
    if batch:
        console.print("\n[bold]Running batch analysis on common hosts...[/bold]\n")
        
        hosts = [
            ("google.com", 443),
            ("github.com", 443),
            ("localhost", 443),
        ]
        
        results = analyzer.batch_analyze(hosts)
        
        table = Table(title="TLS Analysis Results", border_style="cyan")
        table.add_column("Host", style="cyan")
        table.add_column("Cipher", style="white")
        table.add_column("Key Size", style="yellow")
        table.add_column("Status", style="white")
        
        for host_data in results['hosts']:
            status = "🚨 VULNERABLE" if host_data.get('is_quantum_vulnerable') else "✓ SAFE"
            table.add_row(
                host_data['hostname'],
                host_data['cipher_suite'][:30],
                f"{host_data['cipher_bits']} bits",
                status
            )
        
        console.print(table)
        console.print(f"\n[bold]Summary:[/bold] {results['quantum_vulnerable']} vulnerable, {results['safe']} safe")
    
    elif hostname:
        console.print(f"\n[bold]Analyzing {hostname}:{port}...[/bold]\n")
        
        analysis = analyzer.analyze_host(hostname, port)
        
        if 'error' not in analysis:
            status = "🚨 QUANTUM VULNERABLE" if analysis['is_quantum_vulnerable'] else "✓ SAFE"
            
            console.print(f"Target: [cyan]{hostname}:{port}[/cyan]")
            console.print(f"Cipher: [yellow]{analysis['cipher_suite']}[/yellow]")
            console.print(f"Key Size: [yellow]{analysis['cipher_bits']} bits[/yellow]")
            console.print(f"Status: [bold]{status}[/bold]")
            
            if analysis['is_quantum_vulnerable']:
                console.print(f"Estimated Break Year: [red]{analysis.get('estimated_break_year')}[/red]")
                console.print(f"Recommendation: [yellow]{analysis['recommendation']}[/yellow]")
        else:
            console.print(f"[red]✗ Error: {analysis['error']}[/red]")
    
    else:
        console.print("\n[yellow]Usage: chronos detect features tls-analyzer --host example.com[/yellow]")
        console.print("       or --batch for batch analysis\n")


# ============================================================================
# Feature 1.3: Dark Web Monitoring
# ============================================================================

@detect_features.command("darkweb-monitor")
def darkweb_monitor_cmd(
    organization: str = typer.Option(None, "--org", "-o", help="Organization name to monitor"),
    fingerprint_path: str = typer.Option(None, "--fingerprint", "-f", help="Path to create data fingerprint"),
) -> None:
    """
    🌑 Feature 1.3: Dark Web Monitoring
    
    Monitors dark web for:
    - Mentions of your company data being sold
    - Hash matches of your encrypted backups
    - Cryptocurrency transactions for stolen data
    - Forum discussions about your organization
    """
    console.print(Panel("[bold cyan]Feature 1.3: Dark Web Monitoring[/bold cyan]", border_style="cyan"))
    
    if fingerprint_path:
        console.print(f"\n[bold]Creating fingerprint of {fingerprint_path}...[/bold]")
        
        fingerprinter = DataFingerprinter()
        try:
            fp = fingerprinter.create_fingerprint(fingerprint_path, Path(fingerprint_path).name)
            console.print(f"[green]✓[/green] Fingerprint created:")
            console.print(f"  Hash: {fp['file_hash'][:16]}...")
            console.print(f"  Size: {fp['file_size']:,} bytes")
            console.print(f"  Entropy: {fp['metadata']['entropy']:.2f}")
        except Exception as e:
            console.print(f"[red]✗[/red] Error: {e}")
            return
    
    if organization:
        console.print(f"\n[bold]Monitoring dark web for {organization} data...[/bold]\n")
        
        monitor = DarkWebMonitor()
        fingerprints = fingerprinter.get_all_fingerprints() if fingerprint_path else []
        
        matches = monitor.search_for_breach(organization, fingerprints)
        
        if matches:
            console.print(f"\n[red]🚨 POTENTIAL BREACH DETECTED: {len(matches)} match(es)[/red]\n")
            
            for match in matches:
                analysis = monitor.analyze_breach(match)
                
                console.print(f"[red]Severity: {analysis['confidence_score']:.0f}% Confidence[/red]")
                console.print(f"Timestamp: {analysis['timestamp']}")
                console.print(f"Source: {match['source']}")
                console.print(f"Files at Risk: {', '.join(analysis['files_at_risk'])}\n")
                
                console.print("[bold]Recommended Actions:[/bold]")
                for action in analysis['recommendations'][:3]:
                    console.print(f"  {action}")
                console.print()
        else:
            console.print("[green]✓[/green] No dark web mentions found")
    else:
        console.print("\n[yellow]Usage: chronos detect features darkweb-monitor --org YourCompany[/yellow]")
        console.print("       Optionally: --fingerprint /path/to/backup.enc\n")


# ============================================================================
# Feature 1.4: Behavioral Anomaly Detection
# ============================================================================

@detect_features.command("anomaly-detection")
def anomaly_detection_cmd(
    build_baseline: bool = typer.Option(False, "--build-baseline", help="Build baseline profile"),
    analyze_current: bool = typer.Option(False, "--analyze", help="Analyze current traffic"),
) -> None:
    """
    🤖 Feature 1.4: Behavioral Anomaly Detection
    
    Uses machine learning to detect:
    - Unusual traffic volume
    - Unexpected destination connections
    - Off-hours data transfers
    - Protocol anomalies
    - Geographic anomalies
    """
    console.print(Panel("[bold cyan]Feature 1.4: Behavioral Anomaly Detection[/bold cyan]", border_style="cyan"))
    
    baseline = BaselineProfile()
    
    if build_baseline:
        console.print("\n[bold]Building baseline from historical data (simulated)...[/bold]\n")
        
        # Simulate historical data
        historical_data = [
            {
                'timestamp': '2025-12-23T10:00:00',
                'total_bytes': 2000000000,
                'unique_destinations': 10,
                'packet_count': 5000,
                'avg_packet_size': 400000,
            }
            for _ in range(100)
        ]
        
        profile = baseline.build_baseline(historical_data, learning_days=14)
        
        console.print(f"[green]✓[/green] Baseline created (14 days of learning):")
        console.print(f"  Average bytes/hour: {profile['overall']['avg_bytes_per_hour']:,.0f}")
        console.print(f"  Std deviation: {profile['overall']['std_bytes_per_hour']:,.0f}")
        console.print(f"  Business hours: {profile['overall']['business_hours']}")
        console.print(f"  Typical ports: {profile['overall']['typical_ports']}")
    
    if analyze_current:
        console.print("\n[bold]Analyzing current network behavior...[/bold]\n")
        
        detector = AnomalyDetector(baseline)
        
        # Simulate current traffic
        current_data = {
            'timestamp': '2025-12-23T14:00:00',
            'total_bytes': 15000000000,  # 15GB - unusual
            'unique_destinations': 50,  # Many destinations
            'packet_count': 30000,
            'avg_packet_size': 500000,
            'protocols': {'tcp': 0.9, 'udp': 0.1},
            'countries': ['US', 'UK', 'DE']
        }
        
        anomaly = detector.detect_anomaly(current_data)
        
        if anomaly:
            console.print(f"[red]🚨 ANOMALY DETECTED: {anomaly['severity']}[/red]\n")
            console.print(f"Timestamp: {anomaly['timestamp']}")
            console.print(f"Total Score: {anomaly['total_score']:.0f}/100\n")
            
            console.print("[bold]Component Scores:[/bold]")
            for component, score in anomaly['component_scores'].items():
                bar = "=" * int(score / 10)
                console.print(f"  {component:15} {score:>3.0f} [{bar}]")
            
            console.print(f"\n[bold]Detected Anomalies:[/bold]")
            for anom in anomaly['detected_anomalies']:
                console.print(f"  ✗ {anom}")
        else:
            console.print("[green]✓[/green] No anomalies detected in current traffic")


# ============================================================================
# Feature 1.5: Encrypted Data Inventory Scanner
# ============================================================================

@detect_features.command("inventory-scanner")
def inventory_scanner_cmd(
    scan_type: str = typer.Option("full", "--type", "-t", help="Scan type: full, files, services, databases, code"),
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Path to scan"),
    export: bool = typer.Option(False, "--export", help="Export report to file"),
) -> None:
    """
    🗂️ Feature 1.5: Encrypted Data Inventory Scanner
    
    Scans infrastructure to find:
    - Encrypted files and their algorithms
    - Network services using TLS/SSL
    - Database connection encryption
    - Cryptographic operations in source code
    - Quantum vulnerability status
    """
    console.print(Panel("[bold cyan]Feature 1.5: Encrypted Data Inventory Scanner[/bold cyan]", border_style="cyan"))
    
    scanner = EncryptedDataInventory()
    
    scan_paths = [path] if path else None
    
    if scan_type in ["full", "files"]:
        console.print("\n[bold]Scanning file system for encrypted data...[/bold]")
        files = scanner.scan_file_system(scan_paths or [Path.home()])
        console.print(f"[green]✓[/green] Found {len(files)} encrypted files")
    
    if scan_type in ["full", "services"]:
        console.print("[bold]Scanning network services...[/bold]")
        services = scanner.scan_network_services()
        console.print(f"[green]✓[/green] Scanned network services")
    
    if scan_type in ["full", "databases"]:
        console.print("[bold]Scanning database connections...[/bold]")
        databases = scanner.scan_database_connections()
        console.print(f"[green]✓[/green] Found {len(databases)} database connections")
    
    if scan_type in ["full", "code"]:
        console.print("[bold]Scanning application code for crypto operations...[/bold]")
        code_assets = scanner.scan_application_code([Path.cwd()])
        console.print(f"[green]✓[/green] Found {len(code_assets)} crypto operations")
    
    # Generate report
    summary = scanner.get_inventory_summary()
    
    console.print("\n[bold cyan]═══ Inventory Summary ═══[/bold cyan]\n")
    
    table = Table(border_style="cyan")
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="white")
    table.add_row("Total Assets", str(summary['total_assets']))
    table.add_row("Quantum Vulnerable", f"[red]{summary['quantum_vulnerable']}[/red]")
    table.add_row("Quantum Safe", f"[green]{summary['quantum_safe']}[/green]")
    table.add_row("Vulnerability %", f"[red]{(summary['quantum_vulnerable']/max(1,summary['total_assets'])*100):.1f}%[/red]")
    table.add_row("Migration Time", f"{summary['estimated_migration_time_months']} months")
    table.add_row("Est. Cost", f"${summary['estimated_migration_cost_usd']:,}")
    console.print(table)
    
    if summary['by_type']:
        console.print("\n[bold]Assets by Type:[/bold]")
        for asset_type, count in summary['by_type'].items():
            console.print(f"  • {asset_type}: {count}")
    
    if export:
        report = scanner.generate_report()
        report_path = Path.cwd() / "inventory_report.txt"
        with open(report_path, 'w') as f:
            f.write(report)
        console.print(f"\n[green]✓[/green] Report exported to {report_path}")
