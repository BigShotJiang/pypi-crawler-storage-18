"""
MODULE 3: DEFEND - Protection & Migration
CLI Commands for all 4 defense features
"""

import typer
from typing import Optional
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from chronos.core.defend.feature_code_scanner import CodeCryptoScanner
from chronos.core.defend.feature_migration_engine import MigrationEngine
from chronos.core.defend.feature_file_encryption import QuantumSafeFileEncryption
from chronos.core.defend.feature_signature_tool import PostQuantumSignature

app = typer.Typer(help="🛡️ Advanced defense and migration features (3.1-3.4)")
console = Console()


# Feature 3.1: Code Scanner
@app.command()
def code_scanner(
    path: str = typer.Option(
        ".",
        "--path", "-p",
        help="Root path to scan for crypto usage"
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON"
    ),
    show_details: bool = typer.Option(
        False,
        "--details",
        help="Show detailed findings"
    )
):
    """🔍 Feature 3.1: Scan code for cryptographic usage and quantum vulnerabilities"""
    
    console.print(Panel.fit(
        "🔍 CODE CRYPTO SCANNER\nDetecting cryptographic operations and quantum risks",
        title="Feature 3.1"
    ))
    
    try:
        scanner = CodeCryptoScanner(path)
        report = scanner.scan()
        
        if json_output:
            console.print(scanner.export_json())
        else:
            console.print(scanner.get_report_text())
            
            if show_details and report.findings:
                console.print("\n[bold cyan]CRITICAL FINDINGS DETAILS:[/bold cyan]")
                
                for i, finding in enumerate(report.findings[:5], 1):
                    table = Table(title=f"Finding {i}")
                    table.add_column("Field", style="cyan")
                    table.add_column("Value", style="green")
                    
                    table.add_row("Location", finding.location)
                    table.add_row("Algorithm", finding.algorithm)
                    table.add_row("Key Size", finding.key_size)
                    table.add_row("Purpose", finding.purpose)
                    table.add_row("Status", finding.status)
                    table.add_row("Severity", finding.severity)
                    table.add_row("Recommendation", finding.recommendation)
                    
                    console.print(table)
    
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


# Feature 3.2: Migration Engine
@app.command()
def migration_engine(
    path: str = typer.Option(
        ".",
        "--path", "-p",
        help="Root path to scan for migration"
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run",
        help="Preview changes without modifying files"
    ),
    add_hybrid: bool = typer.Option(
        False,
        "--hybrid",
        help="Add hybrid encryption mode"
    ),
    update_deps: bool = typer.Option(
        False,
        "--update-deps",
        help="Update requirements.txt with PQC dependencies"
    )
):
    """🚀 Feature 3.2: Automated code migration from classical to post-quantum crypto"""
    
    console.print(Panel.fit(
        "🚀 AUTOMATED MIGRATION ENGINE\nReplace classical crypto with post-quantum algorithms",
        title="Feature 3.2"
    ))
    
    try:
        engine = MigrationEngine(path)
        
        mode_text = "DRY RUN (preview only)" if dry_run else "LIVE MIGRATION"
        console.print(f"\n[yellow]Mode: {mode_text}[/yellow]")
        
        results = engine.migrate_codebase(dry_run=dry_run)
        
        table = Table(title="Migration Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Total Files", str(results['total_files']))
        table.add_row("Successfully Migrated", str(results['migrated']))
        table.add_row("Failed", str(results['failed']))
        table.add_row("Total Transformations", str(len(results['transformations'])))
        
        console.print(table)
        
        if results['transformations']:
            console.print("\n[bold cyan]Transformations Applied:[/bold cyan]")
            for trans in results['transformations']:
                console.print(
                    f"  ✓ {trans['rule']}: "
                    f"{trans['from']} → {trans['to']} ({trans['count']} instances)"
                )
        
        if not dry_run:
            if update_deps:
                req_file = Path(path) / "requirements.txt"
                engine.update_requirements(req_file)
                console.print("\n[green]✓ Updated requirements.txt with PQC dependencies[/green]")
            
            console.print(engine.generate_migration_report())
    
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


# Feature 3.3: File Encryption
@app.command()
def file_encryption(
    action: str = typer.Option(
        "encrypt",
        "--action", "-a",
        help="encrypt or decrypt"
    ),
    input_file: str = typer.Option(
        ...,
        "--input", "-i",
        help="Input file to encrypt/decrypt"
    ),
    output_file: str = typer.Option(
        None,
        "--output", "-o",
        help="Output file path (default: auto-generated)"
    ),
    public_key: str = typer.Option(
        None,
        "--public-key",
        help="Public key file for encryption"
    ),
    private_key: str = typer.Option(
        None,
        "--private-key",
        help="Private key file for decryption"
    )
):
    """🔐 Feature 3.3: Quantum-safe file encryption with hybrid algorithms"""
    
    console.print(Panel.fit(
        "🔐 QUANTUM-SAFE FILE ENCRYPTION\nHybrid AES-256-GCM + RSA-4096 + Post-Quantum",
        title="Feature 3.3"
    ))
    
    try:
        encryptor = QuantumSafeFileEncryption()
        
        if action.lower() == "encrypt":
            if not output_file:
                output_file = f"{input_file}.qsafe"
            
            console.print(f"[cyan]Encrypting: {input_file}[/cyan]")
            success = encryptor.encrypt_file(input_file, output_file)
            
            if success:
                status = encryptor.get_encryption_status(output_file)
                
                table = Table(title="Encryption Complete")
                table.add_column("Property", style="cyan")
                table.add_column("Value", style="green")
                
                for key, value in status.items():
                    table.add_row(key.replace('_', ' ').title(), str(value))
                
                console.print(table)
                console.print(f"\n[green]✓ File encrypted to: {output_file}[/green]")
            else:
                console.print("[red]✗ Encryption failed[/red]")
        
        elif action.lower() == "decrypt":
            if not output_file:
                output_file = input_file.replace('.qsafe', '.decrypted')
            
            console.print(f"[cyan]Decrypting: {input_file}[/cyan]")
            success, metadata = encryptor.decrypt_file(input_file, output_file)
            
            if success and metadata:
                table = Table(title="Decryption Complete")
                table.add_column("Property", style="cyan")
                table.add_column("Value", style="green")
                
                for key, value in metadata.items():
                    table.add_row(key.replace('_', ' ').title(), str(value))
                
                console.print(table)
                console.print(f"\n[green]✓ File decrypted to: {output_file}[/green]")
            else:
                console.print("[red]✗ Decryption failed[/red]")
        
        else:
            console.print("[red]Action must be 'encrypt' or 'decrypt'[/red]")
    
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


# Feature 3.4: Digital Signatures
@app.command()
def signature_tool(
    action: str = typer.Option(
        "sign",
        "--action", "-a",
        help="sign, verify, or info"
    ),
    file: str = typer.Option(
        None,
        "--file", "-f",
        help="File to sign or verify"
    ),
    signature: str = typer.Option(
        None,
        "--signature", "-s",
        help="Signature file (.sig)"
    ),
    algorithm: str = typer.Option(
        "Dilithium3",
        "--algorithm",
        help="PQC algorithm (Dilithium2/3/5, SPHINCS+, Falcon)"
    ),
    signer: str = typer.Option(
        "Unknown",
        "--signer",
        help="Name of the signer"
    ),
    private_key: str = typer.Option(
        None,
        "--private-key",
        help="Private key file for signing"
    ),
    public_key: str = typer.Option(
        None,
        "--public-key",
        help="Public key file for verification"
    )
):
    """✍️ Feature 3.4: Post-quantum digital signatures for documents and code"""
    
    console.print(Panel.fit(
        "✍️ POST-QUANTUM DIGITAL SIGNATURES\nNIST-approved algorithms (Dilithium, SPHINCS+, Falcon)",
        title="Feature 3.4"
    ))
    
    try:
        signer_tool = PostQuantumSignature(algorithm)
        
        if action.lower() == "info":
            report = signer_tool.generate_report()
            console.print(report)
        
        elif action.lower() == "sign":
            if not file:
                console.print("[red]✗ --file required for sign action[/red]")
                return
            
            console.print(f"[cyan]Signing: {file}[/cyan]")
            
            sig_data = signer_tool.sign_file(file, b"key_placeholder", signer)
            
            if sig_data:
                sig_file = f"{file}.sig"
                success = signer_tool.create_signature_file(file, sig_data, sig_file)
                
                if success:
                    table = Table(title="Signature Created")
                    table.add_column("Property", style="cyan")
                    table.add_column("Value", style="green")
                    
                    metadata = sig_data['metadata']
                    table.add_row("Algorithm", metadata['algorithm'])
                    table.add_row("Signer", metadata['signer'])
                    table.add_row("Timestamp", metadata['timestamp'])
                    table.add_row("File Hash", metadata['file_hash'][:32] + "...")
                    
                    console.print(table)
                    console.print(f"\n[green]✓ Signature saved to: {sig_file}[/green]")
            else:
                console.print("[red]✗ Signing failed[/red]")
        
        elif action.lower() == "verify":
            if not file:
                console.print("[red]✗ --file required for verify action[/red]")
                return
            
            if not signature:
                signature = f"{file}.sig"
            
            console.print(f"[cyan]Verifying: {file}[/cyan]")
            
            sig_data = signer_tool.load_signature_file(signature)
            if sig_data:
                valid, message = signer_tool.verify_signature(file, sig_data)
                console.print(message)
            else:
                console.print("[red]✗ Could not load signature file[/red]")
        
        else:
            console.print("[red]Action must be 'sign', 'verify', or 'info'[/red]")
    
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


# Summary command
@app.command()
def module_status():
    """📊 Show MODULE 3 status and capabilities"""
    
    console.print(Panel.fit(
        "🛡️ MODULE 3: DEFEND - Protection & Migration\n"
        "Features 3.1-3.4: Code scanning, migration, encryption, signatures",
        title="MODULE STATUS"
    ))
    
    table = Table(title="Available Features")
    table.add_column("Feature", style="cyan")
    table.add_column("Command", style="magenta")
    table.add_column("Status", style="green")
    
    table.add_row(
        "3.1: Code Scanner",
        "code-scanner",
        "✓ Ready"
    )
    table.add_row(
        "3.2: Migration Engine",
        "migration-engine",
        "✓ Ready"
    )
    table.add_row(
        "3.3: File Encryption",
        "file-encryption",
        "✓ Ready"
    )
    table.add_row(
        "3.4: Digital Signatures",
        "signature-tool",
        "✓ Ready"
    )
    
    console.print(table)
    
    console.print("\n[bold cyan]Quick Examples:[/bold cyan]")
    console.print("  chronos defend features code-scanner --path .")
    console.print("  chronos defend features migration-engine --dry-run")
    console.print("  chronos defend features file-encryption --action encrypt --input file.txt")
    console.print("  chronos defend features signature-tool --action sign --file document.pdf")


if __name__ == "__main__":
    app()
