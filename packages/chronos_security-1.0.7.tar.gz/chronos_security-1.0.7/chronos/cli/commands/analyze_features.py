"""
CLI Commands for MODULE 2: ANALYZE Features
===========================================

Unified command interface for all analysis features:
- Feature 2.1: Cryptographic Debt Calculator
- Feature 2.2: Quantum Readiness Score
- Feature 2.3: Q-Day Timeline Predictor
"""

import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from chronos.core.analyze.feature_crypto_debt import (
    create_debt_analysis,
    DataSensitivityLevel,
    IndustrySector,
)
from chronos.core.analyze.feature_readiness_score import (
    create_readiness_score,
)
from chronos.core.analyze.feature_qday_predictor import (
    create_threat_timeline,
    QuantumAlgorithm,
    get_all_algorithm_estimates,
)

console = Console()
app = typer.Typer(help="🔬 Advanced analysis features (2.1-2.3)")


@app.command(name="crypto-debt")
def crypto_debt_calculator(
    rsa_keys: int = typer.Option(
        1247,
        "--rsa-keys",
        "-r",
        help="Number of RSA keys found (from inventory scan)"
    ),
    sensitivity: str = typer.Option(
        "high",
        "--sensitivity",
        "-s",
        help="Data sensitivity level (high/medium/low)"
    ),
    lifespan: int = typer.Option(
        20,
        "--lifespan",
        "-l",
        help="Data lifespan in years"
    ),
    industry: str = typer.Option(
        "technology",
        "--industry",
        "-i",
        help="Industry sector"
    ),
    revenue: float = typer.Option(
        100_000_000,
        "--revenue",
        "-v",
        help="Annual revenue ($)"
    ),
    systems: int = typer.Option(
        100,
        "--systems",
        help="Number of affected systems"
    ),
    summary: bool = typer.Option(
        False,
        "--summary",
        help="Show summary only"
    ),
):
    """
    💰 Feature 2.1: Cryptographic Debt Calculator
    
    Calculates the financial cost and risk of delaying post-quantum migration.
    Provides ROI analysis for immediate vs. delayed strategies.
    
    Example:
        chronos analyze crypto-debt --rsa-keys 1247 --sensitivity high --lifespan 20
    """
    
    try:
        analysis = create_debt_analysis(
            rsa_keys=rsa_keys,
            data_sensitivity=sensitivity,
            data_lifespan=lifespan,
            industry=industry,
            annual_revenue=revenue,
            num_systems=systems,
        )
        
        console.print()
        console.print(Panel(analysis.format_report(), title="CRYPTOGRAPHIC DEBT ANALYSIS"))
        console.print()
        
    except Exception as e:
        console.print(f"[red]Error calculating debt analysis: {e}[/red]")
        raise typer.Exit(1)


@app.command(name="readiness-score")
def quantum_readiness_score(
    organization: str = typer.Option(
        "MyOrganization",
        "--organization",
        "-o",
        help="Organization name"
    ),
    industry: str = typer.Option(
        "technology",
        "--industry",
        "-i",
        help="Industry sector"
    ),
    inventory_complete: bool = typer.Option(
        False,
        "--inventory",
        help="Is cryptographic inventory complete?"
    ),
    migration_pct: float = typer.Option(
        0.0,
        "--migration",
        "-m",
        help="Migration progress (0.0-1.0)"
    ),
    employees_trained: int = typer.Option(
        0,
        "--trained",
        "-t",
        help="Number of employees trained"
    ),
    has_monitoring: bool = typer.Option(
        False,
        "--monitoring",
        help="Has threat detection monitoring?"
    ),
    has_policy: bool = typer.Option(
        False,
        "--policy",
        "-p",
        help="Has PQC policy documented?"
    ),
    show_roadmap: bool = typer.Option(
        True,
        "--roadmap",
        help="Show improvement roadmap"
    ),
):
    """
    🎯 Feature 2.2: Quantum Readiness Score
    
    Generates a credit-score-like number (0-1000) measuring organizational
    readiness for quantum computing threats.
    
    Grades: A+ (850+), A (750+), B (650+), C (550+), D (450+), F (<450)
    
    Example:
        chronos analyze readiness-score --organization "MyCorp" --industry financial --trained 25
    """
    
    try:
        score = create_readiness_score(
            organization_name=organization,
            industry=industry,
            inventory_complete=inventory_complete,
            migration_percentage=migration_pct,
            employees_trained=employees_trained,
            has_monitoring=has_monitoring,
            has_policy=has_policy,
        )
        
        console.print()
        console.print(Panel(score.format_report(), title="QUANTUM READINESS ASSESSMENT"))
        console.print()
        
    except Exception as e:
        console.print(f"[red]Error calculating readiness score: {e}[/red]")
        raise typer.Exit(1)


@app.command(name="qday-timeline")
def qday_timeline_predictor(
    organization: str = typer.Option(
        "MyOrganization",
        "--organization",
        "-o",
        help="Organization name"
    ),
    rsa_1024_count: int = typer.Option(
        0,
        "--rsa1024",
        help="Number of RSA-1024 systems"
    ),
    rsa_2048_count: int = typer.Option(
        100,
        "--rsa2048",
        help="Number of RSA-2048 systems"
    ),
    rsa_4096_count: int = typer.Option(
        0,
        "--rsa4096",
        help="Number of RSA-4096 systems"
    ),
    ecc_256_count: int = typer.Option(
        50,
        "--ecc256",
        help="Number of ECC-256 systems"
    ),
    ecc_384_count: int = typer.Option(
        0,
        "--ecc384",
        help="Number of ECC-384 systems"
    ),
    aes_128_count: int = typer.Option(
        0,
        "--aes128",
        help="Number of AES-128 systems"
    ),
    aes_256_count: int = typer.Option(
        25,
        "--aes256",
        help="Number of AES-256 systems"
    ),
    data_lifespan: int = typer.Option(
        20,
        "--lifespan",
        "-l",
        help="Data lifespan in years"
    ),
    all_estimates: bool = typer.Option(
        False,
        "--all-algorithms",
        "-a",
        help="Show all algorithm estimates"
    ),
):
    """
    📅 Feature 2.3: Q-Day Timeline Predictor
    
    Predicts when cryptographic algorithms will become breakable by quantum
    computers. Uses exponential growth modeling and industry consensus.
    
    Example:
        chronos analyze qday-timeline --organization "MyBank" --rsa2048 50 --data-lifespan 15
    """
    
    try:
        timeline = create_threat_timeline(organization)
        timeline.data_lifespan_years = data_lifespan
        
        # Add assets
        if rsa_1024_count > 0:
            timeline.add_asset(QuantumAlgorithm.RSA_1024, "RSA-1024 Systems", rsa_1024_count)
        if rsa_2048_count > 0:
            timeline.add_asset(QuantumAlgorithm.RSA_2048, "RSA-2048 Systems", rsa_2048_count)
        if rsa_4096_count > 0:
            timeline.add_asset(QuantumAlgorithm.RSA_4096, "RSA-4096 Systems", rsa_4096_count)
        if ecc_256_count > 0:
            timeline.add_asset(QuantumAlgorithm.ECC_256, "ECC-256 Systems", ecc_256_count)
        if ecc_384_count > 0:
            timeline.add_asset(QuantumAlgorithm.ECC_384, "ECC-384 Systems", ecc_384_count)
        if aes_128_count > 0:
            timeline.add_asset(QuantumAlgorithm.AES_128, "AES-128 Systems", aes_128_count)
        if aes_256_count > 0:
            timeline.add_asset(QuantumAlgorithm.AES_256, "AES-256 Systems", aes_256_count)
        
        # Print timeline report
        console.print()
        console.print(Panel(timeline.format_timeline_report(), title="Q-DAY TIMELINE ANALYSIS"))
        
        # Show detailed algorithm estimates if requested
        if all_estimates:
            console.print()
            console.print("[bold cyan]Detailed Algorithm Breakage Estimates[/bold cyan]")
            
            table = Table(title="All Algorithms - Q-Day Predictions")
            table.add_column("Algorithm", style="cyan")
            table.add_column("Logical Qubits", justify="right")
            table.add_column("Exponential Model", justify="right")
            table.add_column("Expected Year", justify="right", style="yellow")
            table.add_column("Confidence", justify="right")
            table.add_column("Risk", style="red")
            
            estimates = get_all_algorithm_estimates()
            for algo_name in sorted(estimates.keys()):
                est = estimates[algo_name]
                table.add_row(
                    est.algorithm.name_str,
                    str(est.logical_qubits_needed),
                    str(est.exponential_model_year),
                    str(est.expected_breakage_year),
                    f"{est.confidence_range[0]}-{est.confidence_range[1]}",
                    est.risk_level,
                )
            
            console.print(table)
        
        console.print()
        
    except Exception as e:
        console.print(f"[red]Error generating Q-Day timeline: {e}[/red]")
        raise typer.Exit(1)


@app.command(name="all-estimates")
def show_all_estimates():
    """
    📊 Display all algorithm Q-Day estimates
    
    Shows comprehensive breakage predictions for all cryptographic algorithms.
    """
    
    try:
        console.print()
        table = Table(title="Comprehensive Q-Day Estimates for All Algorithms")
        table.add_column("Algorithm", style="cyan", width=15)
        table.add_column("Qubits Needed", justify="right", width=15)
        table.add_column("Exponential Model", justify="right", width=18)
        table.add_column("Expected Year", justify="right", width=16, style="bold yellow")
        table.add_column("Range", justify="right", width=12)
        table.add_column("Risk Level", width=20)
        table.add_column("Action", width=25)
        
        estimates = get_all_algorithm_estimates()
        for algo_name in sorted(estimates.keys()):
            est = estimates[algo_name]
            
            # Determine action based on breakage year
            current_year = 2024
            years_until = est.expected_breakage_year - current_year
            if years_until <= 5:
                action = "MIGRATE IMMEDIATELY"
            elif years_until <= 10:
                action = "START MIGRATION NOW"
            elif years_until <= 15:
                action = "Plan migration roadmap"
            else:
                action = "Monitor & maintain"
            
            table.add_row(
                est.algorithm.name_str,
                str(est.logical_qubits_needed),
                str(est.exponential_model_year),
                str(est.expected_breakage_year),
                f"{est.confidence_range[0]}-{est.confidence_range[1]}",
                est.risk_level,
                action,
            )
        
        console.print(table)
        console.print()
        
    except Exception as e:
        console.print(f"[red]Error displaying estimates: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
