
{
    "version": "2025.12.24",
    "target": "default",
    "variant": "cpu"
}
