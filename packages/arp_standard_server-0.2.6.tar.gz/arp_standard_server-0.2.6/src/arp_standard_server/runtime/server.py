from __future__ import annotations

import inspect
from abc import ABC, abstractmethod

from fastapi import FastAPI

from arp_standard_model import (
    Health,
    RunResult,
    RunStatus,
    RuntimeCancelRunRequest,
    RuntimeCreateRunRequest,
    RuntimeGetRunResultRequest,
    RuntimeGetRunStatusRequest,
    RuntimeHealthRequest,
    RuntimeStreamRunEventsRequest,
    RuntimeVersionRequest,
    VersionInfo,
)

from arp_standard_server.app import build_app
from arp_standard_server.auth import AuthSettings
from .router import create_router


class BaseRuntimeServer(ABC):
    @abstractmethod
    async def cancel_run(self, request: RuntimeCancelRunRequest) -> RunStatus:
        raise NotImplementedError

    @abstractmethod
    async def create_run(self, request: RuntimeCreateRunRequest) -> RunStatus:
        raise NotImplementedError

    @abstractmethod
    async def get_run_result(self, request: RuntimeGetRunResultRequest) -> RunResult:
        raise NotImplementedError

    @abstractmethod
    async def get_run_status(self, request: RuntimeGetRunStatusRequest) -> RunStatus:
        raise NotImplementedError

    @abstractmethod
    async def health(self, request: RuntimeHealthRequest) -> Health:
        raise NotImplementedError

    @abstractmethod
    async def stream_run_events(self, request: RuntimeStreamRunEventsRequest) -> str:
        raise NotImplementedError

    @abstractmethod
    async def version(self, request: RuntimeVersionRequest) -> VersionInfo:
        raise NotImplementedError

    def create_app(
        self,
        *,
        title: str | None = None,
        auth_settings: AuthSettings | None = None,
    ) -> FastAPI:
        if inspect.isabstract(self.__class__):
            raise TypeError(
                "BaseRuntimeServer has unimplemented abstract methods. "
                "Implement all required endpoints before creating the app."
            )
        return build_app(
            router=create_router(self),
            title=title or "ARP Runtime Server",
            auth_settings=auth_settings,
        )
