"""Tests for cli.py module."""

from unittest.mock import patch

import pytest
import typer
from typer.testing import CliRunner

from jps_jira_utils import __version__
from jps_jira_utils.cli import app

runner = CliRunner()


def test_cli_no_args_shows_help():
    """Test that running CLI without args shows help."""
    result = runner.invoke(app, [])
    assert result.exit_code == 0
    assert "jps-jira-utils" in result.stdout.lower()
    assert "add-comment" in result.stdout
    assert "create-issue" in result.stdout
    assert "update-issue" in result.stdout


def test_cli_version():
    """Test --version flag."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout


def test_cli_help():
    """Test --help flag."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "add-comment" in result.stdout
    assert "create-issue" in result.stdout
    assert "update-issue" in result.stdout


def test_cli_add_comment_help():
    """Test add-comment subcommand help."""
    result = runner.invoke(app, ["add-comment", "--help"])
    assert result.exit_code == 0
    assert "Add a comment" in result.stdout or "comment" in result.stdout.lower()


def test_cli_create_issue_help():
    """Test create-issue subcommand help."""
    result = runner.invoke(app, ["create-issue", "--help"])
    assert result.exit_code == 0
    assert "Create" in result.stdout or "issue" in result.stdout.lower()


def test_cli_update_issue_help():
    """Test update-issue subcommand help."""
    result = runner.invoke(app, ["update-issue", "--help"])
    assert result.exit_code == 0
    assert "Update" in result.stdout or "issue" in result.stdout.lower()
