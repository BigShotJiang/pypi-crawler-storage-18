#!/usr/bin/env python3
"""Main CLI entry point for jps-jira-utils.

Provides subcommands for various Jira operations.
"""

import typer

from . import __version__

# Create main app
app = typer.Typer(
    name="jps-jira-utils",
    help="A clean, modular toolkit for Jira power users.",
    add_completion=False,
    no_args_is_help=True,
)


def version_callback(value: bool) -> None:
    """Print version and exit.

    Args:
        value: Whether --version flag was passed.

    Raises:
        Exit: After printing version.
    """
    if value:
        typer.echo(f"jps-jira-utils version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Main entry point for jps-jira-utils CLI.

    Args:
        version: Version flag.
    """
    pass


# Register subcommands
from .add_comment import app as add_comment_app
from .create_issue import app as create_issue_app
from .update_issue import app as update_issue_app

app.add_typer(add_comment_app, name="add-comment", help="Add a comment to a Jira issue")
app.add_typer(create_issue_app, name="create-issue", help="Create a new Jira issue")
app.add_typer(update_issue_app, name="update-issue", help="Update Jira issue fields from config")


if __name__ == "__main__":
    app()
