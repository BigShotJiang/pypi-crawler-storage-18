"""LLM integration for Notte."""
