import re

def normalize_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()

def make_slug(s: str) -> str:
    s = normalize_spaces(s).lower()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    s = s.replace(" ", "-")
    return re.sub(r"-+", "-", s).strip("-")
