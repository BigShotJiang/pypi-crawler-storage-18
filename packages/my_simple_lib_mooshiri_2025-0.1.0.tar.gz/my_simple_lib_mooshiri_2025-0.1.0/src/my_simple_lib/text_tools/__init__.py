from .text import normalize_spaces, make_slug
