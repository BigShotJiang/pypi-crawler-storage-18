# my_simple_lib

Educational Python library with two subpackages:
- `math_tools`
- `text_tools`

## Requirements
- Python 3.10+

## Install
```bash
pip install my-simple-lib-mooshiri-2025
```

## Usage
```python
from my_simple_lib.math_tools import add, mean
from my_simple_lib.text_tools import normalize_spaces, make_slug

print(add(2, 3))                              # 5
print(mean([1, 2, 3]))                        # 2.0
print(normalize_spaces("  hello   world "))   # "hello world"
print(make_slug("Hello, World!"))             # "hello-world"
```

## Run tests (for developers)
```bash
pip install -U pip
pip install pytest
pytest
```

## Build package (for developers)
```bash
pip install build
python -m build
```

## Upload to TestPyPI (for developers)
```bash
pip install twine
twine upload --repository testpypi dist/*
```

## Upload to PyPI (for developers)
```bash
pip install twine
twine upload dist/*
```
