import pytest
from my_simple_lib.math_tools import add, mean

def test_add():
    assert add(2, 3) == 5

def test_mean():
    assert mean([2, 4, 6]) == 4

def test_mean_empty_raises():
    with pytest.raises(ValueError):
        mean([])
