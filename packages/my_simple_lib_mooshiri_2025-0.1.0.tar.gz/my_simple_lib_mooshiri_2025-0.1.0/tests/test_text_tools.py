from my_simple_lib.text_tools import normalize_spaces, make_slug

def test_normalize_spaces():
    assert normalize_spaces("  hello   world ") == "hello world"

def test_make_slug():
    assert make_slug("Hello,   World!") == "hello-world"
