<p align="center">English | <a href="./README_CN.md">中文</a><br></p>

# Tair MCP Server

[![PyPI version](https://badge.fury.io/py/alibabacloud-tair-mcp-server.svg)](https://pypi.org/project/alibabacloud-tair-mcp-server/)
[![Python](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)

MCP server with Redis/Tair command tools and performance benchmark tools for Alibaba Cloud

## Prerequisites
1. Python >=3.12
2. Tair/Redis instance access credentials
3. [Cline](https://github.com/cline/cline) MCP client (recommended) or other MCP-compatible client

## Installation

### Option 1: Install from PyPI
```bash
pip install alibabacloud-tair-mcp-server
```

### Option 2: Install from Source with UV
```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone and install
git clone https://github.com/aliyun/alibabacloud-tair-mcp-server.git
cd alibabacloud-tair-mcp-server/tair_mcp_server
uv venv
source .venv/bin/activate
uv pip install -e .
```

## Quick Start

### Setup with Cline (Recommended)

1. **Install the server** (using PyPI or UV as shown above)

2. **Configure Cline** by adding this to your Cline configuration:

```json
{
  "mcpServers": {
    "tair-mcp-server": {
      "command": "tair-mcp-server",
      "args": [],
      "env": {
        "HOST": "127.0.0.1",
        "PORT": "6379",
        "USERNAME": "your_username",
        "PASSWORD": "your_password",
        "DB": "0",
        "CLUSTER_MODE": "false"
      }
    }
  }
}
```

Replace the connection details with your actual Tair/Redis credentials.

## Available MCP Tools

### Standard Redis Data Structures

#### String Operations
* `set`, `get`, `setnx`, `getex`, `append`, `strlen`, `incr`, `decr`, `incrby`, `incrbyfloat`, `mset`, `mget`

#### Hash Operations
* `hset`, `hget`, `hmset`, `hmget`, `hgetall`, `hdel`, `hexists`, `hlen`, `hkeys`, `hvals`, `hincrby`, `hincrbyfloat`

#### List Operations
* `lpush`, `rpush`, `lpop`, `rpop`, `llen`, `lindex`, `lset`, `linsert`, `lrem`, `ltrim`, `lrange`

#### Set Operations
* `sadd`, `srem`, `smembers`, `sismember`, `scard`, `spop`, `srandmember`, `sunion`, `sinter`, `sdiff`

#### Sorted Set Operations
* `zadd`, `zadd_multi`, `zrem`, `zscore`, `zrank`, `zrevrank`, `zrange`, `zrevrange`, `zrangebyscore`, `zcard`, `zcount`, `zincrby`, `zpopmin`, `zpopmax`

### Tair Extended Data Structures

#### TairHash (exHash) Operations
* `exhset`, `exhget`, `exhmset`, `exhmget`, `exhgetall`, `exhdel`, `exhlen`, `exhexists`, `exhkeys`, `exhvals`, `exhexpire`, `exhpexpire`, `exhttl`, `exhpttl`, `exhver`, `exhsetver`, `exhincrby`, `exhincrbyfloat`

#### TairString (exString) Operations
* `exset`, `exget`, `exsetver`, `exincrby`, `exincrbyfloat`, `excas`, `excad`

### Key Management Operations
* `delete`, `exists`, `expire`, `expireat`, `ttl`, `pttl`, `persist`, `type_of`, `rename`, `renamenx`, `keys`, `dbsize`, `info`, `ping`, `flushdb`

### Performance Benchmarking Tools
* `benchmark_set`, `benchmark_get`, `benchmark_hset`, `benchmark_hget`, `benchmark_lpush`, `benchmark_lpop`, `benchmark_sadd`, `benchmark_spop`, `benchmark_zadd`, `benchmark_zrange`, `benchmark_exhset`, `benchmark_exhget`

## Configuration Options

### Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `HOST` | Tair/Redis host address | `127.0.0.1` | No |
| `PORT` | Tair/Redis port | `6379` | No |
| `USERNAME` | Database username | - | No |
| `PASSWORD` | Database password | - | No |
| `DB` | Database number | `0` | No |
| `CLUSTER_MODE` | Enable cluster mode | `false` | No |
| `TAIR_MCP_LOG_LEVEL` | Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL) | `INFO` | No |
| `TAIR_MCP_LOG_FILE` | Optional log file path | - | No |

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Support

- **Documentation**: [Alibaba Cloud Tair Documentation](https://www.alibabacloud.com/help/en/redis)
- **Issues**: Report issues on [GitHub](https://github.com/aliyun/alibabacloud-tair-mcp-server/issues)
- **MCP Protocol**: [Model Context Protocol](https://modelcontextprotocol.io)

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](../LICENSE) file for details.
