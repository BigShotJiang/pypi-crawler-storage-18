from typing import List, Tuple, Union, Optional

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


@mcp.tool()
async def delete(keys: List[str]) -> Union[int, str]:
    """Delete one or more keys.

    Returns:
        The number of keys deleted.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.delete(*keys))
    except Exception as e:
        return f"Error deleting keys: {str(e)}"


@mcp.tool()
async def exists(keys: List[str]) -> Union[int, str]:
    """Check how many of the given keys exist.

    Returns:
        The number of keys that exist.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.exists(*keys))
    except Exception as e:
        return f"Error checking keys: {str(e)}"


@mcp.tool()
async def expire(key: str, seconds: int) -> bool:
    """Set a timeout on a key in seconds.

    Returns:
        True if timeout was set, False if key doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.expire(key, seconds))
    except Exception:
        return False


@mcp.tool()
async def expireat(key: str, unix_timestamp: int) -> bool:
    """Set an expiration time as a Unix timestamp.

    Returns:
        True if timeout was set, False if key doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.expireat(key, unix_timestamp))
    except Exception:
        return False


@mcp.tool()
async def persist(key: str) -> bool:
    """Remove the expiration from a key.

    Returns:
        True if timeout was removed, False if key doesn't exist or has no timeout.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.persist(key))
    except Exception:
        return False


@mcp.tool()
async def ttl(key: str) -> int:
    """Get the TTL for a key in seconds.

    Returns:
        TTL in seconds, -2 if key doesn't exist, -1 if no expiry.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.ttl(key))
    except Exception:
        return -2


@mcp.tool()
async def pttl(key: str) -> int:
    """Get the TTL for a key in milliseconds.

    Returns:
        TTL in milliseconds, -2 if key doesn't exist, -1 if no expiry.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.pttl(key))
    except Exception:
        return -2


@mcp.tool()
async def type_of(key: str) -> str:
    """Get the type of value stored at key.

    Returns:
        Type string: 'string', 'list', 'set', 'zset', 'hash', 'stream', or 'none'.
    """
    try:
        r = TairClientManager.get_client()
        return r.type(key) or "none"
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
async def rename(key: str, new_key: str) -> Union[bool, str]:
    """Rename a key.

    Returns:
        True if successful.
    """
    try:
        r = TairClientManager.get_client()
        r.rename(key, new_key)
        return True
    except Exception as e:
        return f"Error renaming key: {str(e)}"


@mcp.tool()
async def renamenx(key: str, new_key: str) -> bool:
    """Rename a key only if the new key doesn't exist.

    Returns:
        True if renamed, False if new key already exists.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.renamenx(key, new_key))
    except Exception:
        return False


@mcp.tool()
async def keys(pattern: str = "*") -> Union[List[str], str]:
    """Find all keys matching a pattern.

    WARNING: Use with caution in production - may block the server.
    Consider using SCAN instead for large datasets.

    Args:
        pattern: Glob-style pattern (e.g., 'user:*', '*session*').

    Returns:
        List of matching keys.
    """
    try:
        r = TairClientManager.get_client()
        result = r.keys(pattern)
        return list(result) if result else []
    except Exception as e:
        return f"Error getting keys: {str(e)}"


@mcp.tool()
async def scan(
    cursor: int = 0,
    match: Optional[str] = None,
    count: Optional[int] = None
) -> Union[Tuple[int, List[str]], str]:
    """Iterate keys using SCAN (safer than KEYS for large datasets).

    Args:
        cursor: Scan cursor (start with 0).
        match: Glob-style pattern to filter keys.
        count: Hint for batch size (not a guarantee).

    Returns:
        Tuple of (next_cursor, keys). Cursor 0 means scan complete.
    """
    try:
        r = TairClientManager.get_client()
        kwargs = {}
        if match is not None:
            kwargs["match"] = match
        if count is not None:
            kwargs["count"] = count
        cursor, keys = r.scan(cursor=cursor, **kwargs)
        return (cursor, list(keys))
    except Exception as e:
        return f"Error scanning keys: {str(e)}"


@mcp.tool()
async def dbsize() -> Union[int, str]:
    """Return the number of keys in the current database.

    Returns:
        Number of keys.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.dbsize())
    except Exception as e:
        return f"Error getting dbsize: {str(e)}"


@mcp.tool()
async def info(section: Optional[str] = None) -> Union[dict, str]:
    """Get information and statistics about the server.

    Args:
        section: Optional section name (e.g., 'memory', 'cpu', 'stats').
                If not specified, returns all sections.

    Returns:
        Server information as a dict.
    """
    try:
        r = TairClientManager.get_client()
        if section:
            return r.info(section)
        return r.info()
    except Exception as e:
        return f"Error getting info: {str(e)}"


@mcp.tool()
async def ping() -> str:
    """Ping the server to check connectivity.

    Returns:
        'PONG' if connected successfully.
    """
    try:
        r = TairClientManager.get_client()
        return r.ping()
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
async def flushdb() -> str:
    """WARNING: Remove all keys from the current database.

    This is a destructive operation and cannot be undone.
    """
    try:
        r = TairClientManager.get_client()
        r.flushdb()
        return "Successfully flushed current database."
    except Exception as e:
        return f"Error flushing DB: {str(e)}"


@mcp.tool()
async def flushall() -> str:
    """WARNING: Remove all keys from ALL databases.

    This is a destructive operation and cannot be undone.
    """
    try:
        r = TairClientManager.get_client()
        r.flushall()
        return "Successfully flushed all databases."
    except Exception as e:
        return f"Error flushing all DBs: {str(e)}"
