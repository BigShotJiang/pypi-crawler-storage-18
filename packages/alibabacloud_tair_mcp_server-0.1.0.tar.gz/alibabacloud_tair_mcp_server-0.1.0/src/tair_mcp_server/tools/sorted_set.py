from typing import List, Tuple, Union, Optional

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


@mcp.tool()
async def zadd(
    key: str,
    member: str,
    score: float,
) -> Union[int, str]:
    """Add a member with score to a sorted set.

    If member already exists, update its score.

    Returns:
        1 if new member added, 0 if score updated.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.zadd(key, {member: score}))
    except Exception as e:
        return f"Error ZADD {key}: {str(e)}"


@mcp.tool()
async def zadd_multi(
    key: str,
    members_scores: dict,
) -> Union[int, str]:
    """Add multiple members with scores to a sorted set.

    Args:
        key: The sorted set key.
        members_scores: Dict of {member: score} pairs.

    Returns:
        Number of new members added.
    """
    try:
        r = TairClientManager.get_client()
        # Convert to float scores
        mapping = {m: float(s) for m, s in members_scores.items()}
        return int(r.zadd(key, mapping))
    except Exception as e:
        return f"Error ZADD {key}: {str(e)}"


@mcp.tool()
async def zrem(key: str, members: List[str]) -> Union[int, str]:
    """Remove one or more members from a sorted set.

    Returns:
        Number of members removed.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.zrem(key, *members))
    except Exception as e:
        return f"Error ZREM {key}: {str(e)}"


@mcp.tool()
async def zscore(key: str, member: str) -> Union[float, None, str]:
    """Get the score of a member in a sorted set.

    Returns:
        The score, or None if member doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        score = r.zscore(key, member)
        return float(score) if score is not None else None
    except Exception as e:
        return f"Error ZSCORE {key}: {str(e)}"


@mcp.tool()
async def zrank(key: str, member: str) -> Union[int, None, str]:
    """Get the rank (0-based) of a member in a sorted set (lowest to highest).

    Returns:
        The rank, or None if member doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        rank = r.zrank(key, member)
        return int(rank) if rank is not None else None
    except Exception as e:
        return f"Error ZRANK {key}: {str(e)}"


@mcp.tool()
async def zrevrank(key: str, member: str) -> Union[int, None, str]:
    """Get the rank (0-based) of a member in a sorted set (highest to lowest).

    Returns:
        The rank, or None if member doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        rank = r.zrevrank(key, member)
        return int(rank) if rank is not None else None
    except Exception as e:
        return f"Error ZREVRANK {key}: {str(e)}"


@mcp.tool()
async def zrange(
    key: str,
    start: int = 0,
    stop: int = -1,
    withscores: bool = False,
) -> Union[List[str], List[Tuple[str, float]], str]:
    """Get members in a sorted set by index range (lowest to highest).

    Args:
        key: The sorted set key.
        start: Start index (0-based, inclusive).
        stop: Stop index (-1 means last element, inclusive).
        withscores: If True, return (member, score) tuples.

    Returns:
        List of members or (member, score) tuples.
    """
    try:
        r = TairClientManager.get_client()
        result = r.zrange(key, start, stop, withscores=withscores)
        if withscores and result:
            return [(m, float(s)) for m, s in result]
        return list(result) if result else []
    except Exception as e:
        return f"Error ZRANGE {key}: {str(e)}"


@mcp.tool()
async def zrevrange(
    key: str,
    start: int = 0,
    stop: int = -1,
    withscores: bool = False,
) -> Union[List[str], List[Tuple[str, float]], str]:
    """Get members in a sorted set by index range (highest to lowest).

    Args:
        key: The sorted set key.
        start: Start index (0-based, inclusive).
        stop: Stop index (-1 means last element, inclusive).
        withscores: If True, return (member, score) tuples.

    Returns:
        List of members or (member, score) tuples.
    """
    try:
        r = TairClientManager.get_client()
        result = r.zrevrange(key, start, stop, withscores=withscores)
        if withscores and result:
            return [(m, float(s)) for m, s in result]
        return list(result) if result else []
    except Exception as e:
        return f"Error ZREVRANGE {key}: {str(e)}"


@mcp.tool()
async def zrangebyscore(
    key: str,
    min_score: float,
    max_score: float,
    withscores: bool = False,
    offset: int = 0,
    count: Optional[int] = None,
) -> Union[List[str], List[Tuple[str, float]], str]:
    """Get members in a sorted set by score range (lowest to highest).

    Args:
        key: The sorted set key.
        min_score: Minimum score (inclusive).
        max_score: Maximum score (inclusive).
        withscores: If True, return (member, score) tuples.
        offset: Number of results to skip.
        count: Maximum number of results to return.

    Returns:
        List of members or (member, score) tuples.
    """
    try:
        r = TairClientManager.get_client()
        kwargs = {"withscores": withscores}
        if count is not None:
            kwargs["offset"] = offset
            kwargs["count"] = count

        result = r.zrangebyscore(key, min_score, max_score, **kwargs)
        if withscores and result:
            return [(m, float(s)) for m, s in result]
        return list(result) if result else []
    except Exception as e:
        return f"Error ZRANGEBYSCORE {key}: {str(e)}"


@mcp.tool()
async def zcard(key: str) -> Union[int, str]:
    """Get the number of members in a sorted set.

    Returns:
        The cardinality (number of elements) of the sorted set.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.zcard(key))
    except Exception as e:
        return f"Error ZCARD {key}: {str(e)}"


@mcp.tool()
async def zcount(key: str, min_score: float, max_score: float) -> Union[int, str]:
    """Count members in a sorted set with scores within the given range.

    Args:
        key: The sorted set key.
        min_score: Minimum score (inclusive).
        max_score: Maximum score (inclusive).

    Returns:
        Number of members with scores in the range.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.zcount(key, min_score, max_score))
    except Exception as e:
        return f"Error ZCOUNT {key}: {str(e)}"


@mcp.tool()
async def zincrby(key: str, member: str, increment: float) -> Union[float, str]:
    """Increment the score of a member in a sorted set.

    Args:
        key: The sorted set key.
        member: The member to increment.
        increment: The amount to increment by (can be negative).

    Returns:
        The new score of the member.
    """
    try:
        r = TairClientManager.get_client()
        return float(r.zincrby(key, increment, member))
    except Exception as e:
        return f"Error ZINCRBY {key}: {str(e)}"


@mcp.tool()
async def zpopmin(key: str, count: int = 1) -> Union[List[Tuple[str, float]], str]:
    """Remove and return members with the lowest scores.

    Args:
        key: The sorted set key.
        count: Number of members to pop (default 1).

    Returns:
        List of (member, score) tuples.
    """
    try:
        r = TairClientManager.get_client()
        result = r.zpopmin(key, count)
        if result:
            return [(m, float(s)) for m, s in result]
        return []
    except Exception as e:
        return f"Error ZPOPMIN {key}: {str(e)}"


@mcp.tool()
async def zpopmax(key: str, count: int = 1) -> Union[List[Tuple[str, float]], str]:
    """Remove and return members with the highest scores.

    Args:
        key: The sorted set key.
        count: Number of members to pop (default 1).

    Returns:
        List of (member, score) tuples.
    """
    try:
        r = TairClientManager.get_client()
        result = r.zpopmax(key, count)
        if result:
            return [(m, float(s)) for m, s in result]
        return []
    except Exception as e:
        return f"Error ZPOPMAX {key}: {str(e)}"


