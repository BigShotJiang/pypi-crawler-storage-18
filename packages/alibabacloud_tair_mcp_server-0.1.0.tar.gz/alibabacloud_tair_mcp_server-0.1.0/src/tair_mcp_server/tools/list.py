import json
from typing import List, Union, Optional

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


def _encode_values(values: List) -> List[str]:
    """Encode a list of values for Redis storage."""
    result = []
    for v in values:
        if isinstance(v, (dict, list)):
            result.append(json.dumps(v, ensure_ascii=False))
        else:
            result.append(str(v))
    return result


@mcp.tool()
async def lpush(key: str, values: List[str]) -> Union[int, str]:
    """Prepend one or more values to the head of a list.

    Args:
        key: The list key.
        values: Values to prepend (first value will be at head).

    Returns:
        The length of the list after the push.
    """
    try:
        r = TairClientManager.get_client()
        encoded = _encode_values(values)
        return int(r.lpush(key, *encoded))
    except Exception as e:
        return f"Error lpush: {str(e)}"


@mcp.tool()
async def rpush(key: str, values: List[str]) -> Union[int, str]:
    """Append one or more values to the tail of a list.

    Args:
        key: The list key.
        values: Values to append.

    Returns:
        The length of the list after the push.
    """
    try:
        r = TairClientManager.get_client()
        encoded = _encode_values(values)
        return int(r.rpush(key, *encoded))
    except Exception as e:
        return f"Error rpush: {str(e)}"


@mcp.tool()
async def lpop(key: str, count: Optional[int] = None) -> Union[str, List[str], None, str]:
    """Remove and return element(s) from the head of a list.

    Args:
        key: The list key.
        count: Number of elements to pop (default: 1).

    Returns:
        The popped element(s), or None if list is empty.
    """
    try:
        r = TairClientManager.get_client()
        if count is not None:
            result = r.lpop(key, count)
            return list(result) if result else None
        return r.lpop(key)
    except Exception as e:
        return f"Error lpop: {str(e)}"


@mcp.tool()
async def rpop(key: str, count: Optional[int] = None) -> Union[str, List[str], None, str]:
    """Remove and return element(s) from the tail of a list.

    Args:
        key: The list key.
        count: Number of elements to pop (default: 1).

    Returns:
        The popped element(s), or None if list is empty.
    """
    try:
        r = TairClientManager.get_client()
        if count is not None:
            result = r.rpop(key, count)
            return list(result) if result else None
        return r.rpop(key)
    except Exception as e:
        return f"Error rpop: {str(e)}"


@mcp.tool()
async def lrange(key: str, start: int = 0, stop: int = -1) -> Union[List[str], str]:
    """Get a range of elements from a list.

    Args:
        key: The list key.
        start: Start index (0-based, inclusive).
        stop: Stop index (-1 means last element, inclusive).

    Returns:
        List of elements in the range.
    """
    try:
        r = TairClientManager.get_client()
        result = r.lrange(key, start, stop)
        return list(result) if result else []
    except Exception as e:
        return f"Error lrange: {str(e)}"


@mcp.tool()
async def llen(key: str) -> Union[int, str]:
    """Get the length of a list.

    Args:
        key: The list key.

    Returns:
        The length of the list.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.llen(key))
    except Exception as e:
        return f"Error llen: {str(e)}"


@mcp.tool()
async def lindex(key: str, index: int) -> Union[str, None, str]:
    """Get an element from a list by its index.

    Args:
        key: The list key.
        index: The index (0-based, negative indexes from the end).

    Returns:
        The element at the index, or None if out of range.
    """
    try:
        r = TairClientManager.get_client()
        return r.lindex(key, index)
    except Exception as e:
        return f"Error lindex: {str(e)}"


@mcp.tool()
async def lset(key: str, index: int, value: str) -> Union[bool, str]:
    """Set the value of an element in a list by its index.

    Args:
        key: The list key.
        index: The index to set.
        value: The new value.

    Returns:
        True if successful.
    """
    try:
        r = TairClientManager.get_client()
        r.lset(key, index, value)
        return True
    except Exception as e:
        return f"Error lset: {str(e)}"


@mcp.tool()
async def linsert(
    key: str,
    where: str,
    pivot: str,
    value: str,
) -> Union[int, str]:
    """Insert an element before or after another element in a list.

    Args:
        key: The list key.
        where: 'BEFORE' or 'AFTER'.
        pivot: The existing element to insert relative to.
        value: The value to insert.

    Returns:
        The length of the list after insertion, or -1 if pivot not found.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.linsert(key, where.upper(), pivot, value))
    except Exception as e:
        return f"Error linsert: {str(e)}"


@mcp.tool()
async def lrem(key: str, count: int, value: str) -> Union[int, str]:
    """Remove elements from a list.

    Args:
        key: The list key.
        count: Number of occurrences to remove.
               count > 0: Remove from head to tail.
               count < 0: Remove from tail to head.
               count = 0: Remove all occurrences.
        value: The value to remove.

    Returns:
        The number of elements removed.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.lrem(key, count, value))
    except Exception as e:
        return f"Error lrem: {str(e)}"


@mcp.tool()
async def ltrim(key: str, start: int, stop: int) -> Union[bool, str]:
    """Trim a list to the specified range.

    Args:
        key: The list key.
        start: Start index (inclusive).
        stop: Stop index (inclusive, -1 means last).

    Returns:
        True if successful.
    """
    try:
        r = TairClientManager.get_client()
        r.ltrim(key, start, stop)
        return True
    except Exception as e:
        return f"Error ltrim: {str(e)}"
