import json
from typing import List, Union, Optional

import numpy as np

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


def _encode_value(value: Union[str, int, float, dict, list]) -> str:
    """Encode a value for Redis storage."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


@mcp.tool()
async def hset(
    key: str,
    field: str,
    value: Union[str, int, float, dict],
    expiration: Optional[int] = None,
) -> str:
    """Set a field in a hash.

    Args:
        key: The hash key.
        field: The field name inside the hash.
        value: The value to set. Supports string, number, or dict (auto JSON serialized).
        expiration: Optional expiration for the hash key in seconds.

    Returns:
        Confirmation message or error.
    """
    encoded_value = _encode_value(value)

    try:
        r = TairClientManager.get_client()
        r.hset(key, field, encoded_value)

        if expiration is not None:
            r.expire(key, expiration)

        msg = f"Set field '{field}' in hash '{key}'"
        if expiration:
            msg += f" (expires in {expiration}s)"
        return msg
    except Exception as e:
        return f"Error hset: {str(e)}"


@mcp.tool()
async def hmset(key: str, mapping: dict) -> str:
    """Set multiple fields in a hash at once.

    Args:
        key: The hash key.
        mapping: Dict of field-value pairs.

    Returns:
        Confirmation message or error.
    """
    try:
        r = TairClientManager.get_client()
        encoded = {f: _encode_value(v) for f, v in mapping.items()}
        r.hset(key, mapping=encoded)
        return f"Set {len(mapping)} field(s) in hash '{key}'"
    except Exception as e:
        return f"Error hmset: {str(e)}"


@mcp.tool()
async def hget(key: str, field: str) -> Union[str, None, str]:
    """Get the value of a field in a hash.

    Args:
        key: The hash key.
        field: The field name.

    Returns:
        The field value, or None if not found.
    """
    try:
        r = TairClientManager.get_client()
        return r.hget(key, field)
    except Exception as e:
        return f"Error hget: {str(e)}"


@mcp.tool()
async def hmget(key: str, fields: List[str]) -> Union[List[Union[str, None]], str]:
    """Get values of multiple fields in a hash.

    Args:
        key: The hash key.
        fields: List of field names.

    Returns:
        List of values (None for non-existing fields).
    """
    try:
        r = TairClientManager.get_client()
        return list(r.hmget(key, fields))
    except Exception as e:
        return f"Error hmget: {str(e)}"


@mcp.tool()
async def hgetall(key: str) -> Union[dict, str]:
    """Get all fields and values from a hash.

    Args:
        key: The hash key.

    Returns:
        Dict of all field-value pairs, or empty dict if hash doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        result = r.hgetall(key)
        return dict(result) if result else {}
    except Exception as e:
        return f"Error hgetall: {str(e)}"


@mcp.tool()
async def hdel(key: str, fields: List[str]) -> Union[int, str]:
    """Delete one or more fields from a hash.

    Args:
        key: The hash key.
        fields: List of field names to delete.

    Returns:
        Number of fields deleted.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.hdel(key, *fields))
    except Exception as e:
        return f"Error hdel: {str(e)}"


@mcp.tool()
async def hexists(key: str, field: str) -> bool:
    """Check if a field exists in a hash.

    Args:
        key: The hash key.
        field: The field name.

    Returns:
        True if field exists, False otherwise.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.hexists(key, field))
    except Exception:
        return False


@mcp.tool()
async def hlen(key: str) -> Union[int, str]:
    """Get the number of fields in a hash.

    Args:
        key: The hash key.

    Returns:
        Number of fields in the hash.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.hlen(key))
    except Exception as e:
        return f"Error hlen: {str(e)}"


@mcp.tool()
async def hkeys(key: str) -> Union[List[str], str]:
    """Get all field names in a hash.

    Args:
        key: The hash key.

    Returns:
        List of field names.
    """
    try:
        r = TairClientManager.get_client()
        return list(r.hkeys(key))
    except Exception as e:
        return f"Error hkeys: {str(e)}"


@mcp.tool()
async def hvals(key: str) -> Union[List[str], str]:
    """Get all values in a hash.

    Args:
        key: The hash key.

    Returns:
        List of values.
    """
    try:
        r = TairClientManager.get_client()
        return list(r.hvals(key))
    except Exception as e:
        return f"Error hvals: {str(e)}"


@mcp.tool()
async def hincrby(key: str, field: str, amount: int = 1) -> Union[int, str]:
    """Increment the integer value of a hash field.

    Args:
        key: The hash key.
        field: The field name.
        amount: The amount to increment by (default 1).

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.hincrby(key, field, amount))
    except Exception as e:
        return f"Error hincrby: {str(e)}"


@mcp.tool()
async def hincrbyfloat(key: str, field: str, amount: float) -> Union[float, str]:
    """Increment the float value of a hash field.

    Args:
        key: The hash key.
        field: The field name.
        amount: The float amount to increment by.

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        return float(r.hincrbyfloat(key, field, amount))
    except Exception as e:
        return f"Error hincrbyfloat: {str(e)}"


# ==================== Vector Operations ====================

@mcp.tool()
async def set_vector_in_hash(
    key: str,
    vector: List[float],
    field: str = "vector",
) -> Union[bool, str]:
    """Store a vector as binary blob in a hash field.

    Useful for vector similarity search scenarios.

    Args:
        key: The hash key.
        vector: The vector as a list of floats.
        field: The field name (default: 'vector').

    Returns:
        True if successful.
    """
    try:
        r = TairClientManager.get_client()
        vector_array = np.array(vector, dtype=np.float32)
        binary_blob = vector_array.tobytes()
        r.hset(key, field, binary_blob)
        return True
    except Exception as e:
        return f"Error storing vector: {str(e)}"


@mcp.tool()
async def get_vector_from_hash(
    key: str,
    field: str = "vector",
) -> Union[List[float], str]:
    """Retrieve a vector from a hash field.

    Args:
        key: The hash key.
        field: The field name (default: 'vector').

    Returns:
        The vector as a list of floats.
    """
    try:
        r = TairClientManager.get_client(decode_responses=False)
        binary_blob = r.hget(key, field)

        if binary_blob is None:
            return f"Field '{field}' not found in hash '{key}'"

        vector_array = np.frombuffer(binary_blob, dtype=np.float32)
        return vector_array.tolist()
    except Exception as e:
        return f"Error retrieving vector: {str(e)}"
