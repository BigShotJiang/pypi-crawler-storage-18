"""
Benchmark tools for Redis/Tair performance testing.

Based on Alibaba Cloud's official performance whitepaper:
https://help.aliyun.com/zh/redis/support/performance-whitepaper-of-community-edition-instances

Uses resp-benchmark library for high-performance benchmarking.

Default parameters follow Alibaba Cloud's performance whitepaper:
- Duration: 20 seconds
- Connections: 256 (for load operations), default for benchmark (resp-benchmark auto-scaling)
- Pipeline: 10 (for load operations), 1 (for benchmark, ping-pong mode)
- Key distribution: uniform for reads, sequence for writes

If parameters are not explicitly specified, default values from the whitepaper are used.
"""
from typing import Any, Dict, Optional

from pydantic import Field

from tair_mcp_server.utils.server import mcp
from tair_mcp_server.utils.config import TAIR_CFG
from resp_benchmark import Benchmark


def _run_benchmark(
    command: str,
    host: Optional[str] = None,
    port: Optional[int] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    duration: int = 20,
    connections: int = 0,
    pipeline: int = 1,
    load_command: Optional[str] = None,
    load_count: Optional[int] = None,
) -> Dict[str, Any]:
    """Execute benchmark using resp-benchmark.

    Args:
        command: The command template to benchmark.
        host: Redis host (defaults to config).
        port: Redis port (defaults to config).
        username: Redis username (defaults to config).
        password: Redis password (defaults to config).
        duration: Test duration in seconds.
        connections: Number of concurrent connections.
        pipeline: Pipeline depth.
        load_command: Optional command for pre-loading data.
        load_count: Number of records to pre-load.

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    # Resolve connection parameters
    h = host or TAIR_CFG.get("host") or "127.0.0.1"
    p = port if port is not None else TAIR_CFG.get("port", 6379)
    u = username if username is not None else TAIR_CFG.get("username") or ""
    pw = password if password is not None else TAIR_CFG.get("password") or ""

    try:
        bm = Benchmark(host=h, port=int(p), username=u, password=pw)

        # Pre-load data if specified
        # Use 256 connections and pipeline=10 for load (per Alibaba Cloud whitepaper)
        if load_command and load_count:
            bm.load_data(
                command=load_command,
                count=load_count,
                connections=256,
                pipeline=10,
                quiet=True,
            )

        # Run benchmark
        # connections=0 means auto-scaling (resp-benchmark default)
        # This matches the whitepaper where test commands don't specify -c
        result = bm.bench(
            command=command,
            seconds=duration,
            connections=connections,
            pipeline=pipeline,
            quiet=True,
        )

        return {
            "qps": result.qps,
            "avg_latency_ms": result.avg_latency_ms,
            "p99_latency_ms": result.p99_latency_ms,
            "connections": result.connections,
            "duration_seconds": duration,
            "command": command,
        }
    except Exception as e:
        return {"error": str(e)}


# ==================== String Commands ====================

@mcp.tool()
async def benchmark_set(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=10000000, description="Number of unique keys"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark SET command performance.

    Tests write performance with uniform key distribution.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling)
    - Key count: 10,000,000
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    command = f"SET {{key uniform {key_count}}} {{value {value_size}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
    )


@mcp.tool()
async def benchmark_get(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=10000000, description="Number of unique keys"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark GET command performance.

    Automatically pre-loads data (sequence keys) before testing read performance (uniform keys).

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling) for test, 256 for load
    - Key count: 10,000,000
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    load_cmd = f"SET {{key sequence {key_count}}} {{value {value_size}}}"
    command = f"GET {{key uniform {key_count}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
        load_command=load_cmd, load_count=key_count,
    )


# ==================== Sorted Set Commands ====================

@mcp.tool()
async def benchmark_zadd(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of sorted set keys"),
    field_count: int = Field(default=10000, description="Number of members per key"),
    score_range: int = Field(default=70000, description="Score range for random scores"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark ZADD command performance.

    Tests sorted set write performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling)
    - Key count: 1,000
    - Field count: 10,000 per key
    - Score range: 0-70,000

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    command = f"ZADD {{key uniform {key_count}}} {{rand {score_range}}} {{key uniform {field_count}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
    )


@mcp.tool()
async def benchmark_zscore(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of sorted set keys"),
    field_count: int = Field(default=10007, description="Number of members per key"),
    score_range: int = Field(default=70000, description="Score range"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark ZSCORE command performance.

    Automatically pre-loads data before testing read performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling) for test, 256 for load
    - Key count: 1,000
    - Field count: 10,007 per key
    - Score range: 0-70,000

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    total = key_count * field_count
    load_cmd = f"ZADD {{key sequence {key_count}}} {{rand {score_range}}} {{key sequence {field_count}}}"
    command = f"ZSCORE {{key uniform {key_count}}} {{key uniform {field_count}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
        load_command=load_cmd, load_count=total,
    )


# ==================== Hash Commands ====================

@mcp.tool()
async def benchmark_hset(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of hash keys"),
    field_count: int = Field(default=10000, description="Number of fields per hash"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark HSET command performance.

    Tests hash write performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling)
    - Key count: 1,000
    - Field count: 10,000 per key
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    command = f"HSET {{key uniform {key_count}}} {{key uniform {field_count}}} {{value {value_size}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
    )


@mcp.tool()
async def benchmark_hget(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of hash keys"),
    field_count: int = Field(default=10007, description="Number of fields per hash"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark HGET command performance.

    Automatically pre-loads data before testing read performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling) for test, 256 for load
    - Key count: 1,000
    - Field count: 10,007 per key
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    total = key_count * field_count
    load_cmd = f"HSET {{key sequence {key_count}}} {{key sequence {field_count}}} {{value {value_size}}}"
    command = f"HGET {{key uniform {key_count}}} {{key uniform {field_count}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
        load_command=load_cmd, load_count=total,
    )


# ==================== List Commands ====================

@mcp.tool()
async def benchmark_lpush(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of list keys"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark LPUSH command performance.

    Tests list write performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling)
    - Key count: 1,000
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    command = f"LPUSH {{key uniform {key_count}}} {{value {value_size}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
    )


@mcp.tool()
async def benchmark_lindex(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of list keys"),
    list_size: int = Field(default=10000, description="Number of elements per list"),
    value_size: int = Field(default=64, description="Value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark LINDEX command performance.

    Automatically pre-loads data before testing read performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling) for test, 256 for load
    - Key count: 1,000
    - List size: 10,000 elements per key
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    total = key_count * list_size
    load_cmd = f"LPUSH {{key sequence {key_count}}} {{value {value_size}}}"
    command = f"LINDEX {{key uniform {key_count}}} {{rand {list_size}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
        load_command=load_cmd, load_count=total,
    )


# ==================== Set Commands ====================

@mcp.tool()
async def benchmark_sadd(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of set keys"),
    value_size: int = Field(default=64, description="Member value size in bytes"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark SADD command performance.

    Tests set write performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling)
    - Key count: 1,000
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    command = f"SADD {{key uniform {key_count}}} {{value {value_size}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
    )


@mcp.tool()
async def benchmark_sismember(
    duration: int = Field(default=20, description="Test duration in seconds"),
    connections: int = Field(default=0, description="Number of connections (0=auto-scaling, resp-benchmark default). Default parameters follow Alibaba Cloud performance whitepaper."),
    key_count: int = Field(default=1000, description="Number of set keys"),
    member_count: int = Field(default=10007, description="Number of members per set"),
    host: Optional[str] = Field(default=None, description="Override Tair host"),
    port: Optional[int] = Field(default=None, description="Override Tair port"),
    username: Optional[str] = Field(default=None, description="Override username"),
    password: Optional[str] = Field(default=None, description="Override password"),
) -> Dict[str, Any]:
    """Benchmark SISMEMBER command performance.

    Automatically pre-loads data before testing read performance.

    Default parameters (if not explicitly specified) follow Alibaba Cloud performance whitepaper:
    - Duration: 20 seconds
    - Connections: 0 (auto-scaling) for test, 256 for load
    - Key count: 1,000
    - Member count: 10,007 per key
    - Value size: 64 bytes

    Returns:
        Dict with qps, avg_latency_ms, p99_latency_ms, connections, duration_seconds, command.
    """
    total = key_count * member_count
    load_cmd = f"SADD {{key sequence {key_count}}} {{key sequence {member_count}}}"
    command = f"SISMEMBER {{key uniform {key_count}}} {{key uniform {member_count}}}"
    return _run_benchmark(
        command=command,
        host=host, port=port, username=username, password=password,
        duration=duration, connections=connections,
        load_command=load_cmd, load_count=total,
    )
