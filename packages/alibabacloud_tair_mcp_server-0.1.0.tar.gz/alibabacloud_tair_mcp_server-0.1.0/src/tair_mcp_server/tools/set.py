from typing import List, Union

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


@mcp.tool()
async def sadd(key: str, members: List[str]) -> Union[int, str]:
    """Add one or more members to a set.

    Returns:
        The number of members added (not including already existing members).
    """
    try:
        r = TairClientManager.get_client()
        return int(r.sadd(key, *members))
    except Exception as e:
        return f"Error SADD {key}: {str(e)}"


@mcp.tool()
async def srem(key: str, members: List[str]) -> Union[int, str]:
    """Remove one or more members from a set.

    Returns:
        The number of members removed.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.srem(key, *members))
    except Exception as e:
        return f"Error SREM {key}: {str(e)}"


@mcp.tool()
async def smembers(key: str) -> Union[List[str], str]:
    """Get all members of a set.

    Returns:
        List of all members in the set.
    """
    try:
        r = TairClientManager.get_client()
        members = r.smembers(key)
        return list(members) if members else []
    except Exception as e:
        return f"Error SMEMBERS {key}: {str(e)}"


@mcp.tool()
async def sismember(key: str, member: str) -> Union[bool, str]:
    """Check if a member exists in a set.

    Returns:
        True if the member exists, False otherwise.
    """
    try:
        r = TairClientManager.get_client()
        return bool(r.sismember(key, member))
    except Exception as e:
        return f"Error SISMEMBER {key}: {str(e)}"


@mcp.tool()
async def scard(key: str) -> Union[int, str]:
    """Get the number of members in a set.

    Returns:
        The cardinality (number of elements) of the set.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.scard(key))
    except Exception as e:
        return f"Error SCARD {key}: {str(e)}"


@mcp.tool()
async def spop(key: str, count: int = 1) -> Union[str, List[str], None, str]:
    """Remove and return random member(s) from a set.

    Args:
        key: The set key.
        count: Number of members to pop (default 1).

    Returns:
        The popped member(s), or None if set is empty.
    """
    try:
        r = TairClientManager.get_client()
        result = r.spop(key, count)
        if result is None:
            return None
        if isinstance(result, (list, set)):
            return list(result)
        return result
    except Exception as e:
        return f"Error SPOP {key}: {str(e)}"


@mcp.tool()
async def srandmember(key: str, count: int = 1) -> Union[str, List[str], None, str]:
    """Get random member(s) from a set without removing them.

    Args:
        key: The set key.
        count: Number of members to return (default 1).

    Returns:
        Random member(s) from the set.
    """
    try:
        r = TairClientManager.get_client()
        result = r.srandmember(key, count)
        if result is None:
            return None
        if isinstance(result, list):
            return result
        return result
    except Exception as e:
        return f"Error SRANDMEMBER {key}: {str(e)}"


@mcp.tool()
async def sunion(keys: List[str]) -> Union[List[str], str]:
    """Return the union of multiple sets.

    Args:
        keys: List of set keys to union.

    Returns:
        List of members in the union.
    """
    try:
        r = TairClientManager.get_client()
        result = r.sunion(*keys)
        return list(result) if result else []
    except Exception as e:
        return f"Error SUNION: {str(e)}"


@mcp.tool()
async def sinter(keys: List[str]) -> Union[List[str], str]:
    """Return the intersection of multiple sets.

    Args:
        keys: List of set keys to intersect.

    Returns:
        List of members in the intersection.
    """
    try:
        r = TairClientManager.get_client()
        result = r.sinter(*keys)
        return list(result) if result else []
    except Exception as e:
        return f"Error SINTER: {str(e)}"


@mcp.tool()
async def sdiff(keys: List[str]) -> Union[List[str], str]:
    """Return the difference between the first set and all other sets.

    Args:
        keys: List of set keys. First key is the base set.

    Returns:
        List of members in the difference.
    """
    try:
        r = TairClientManager.get_client()
        result = r.sdiff(*keys)
        return list(result) if result else []
    except Exception as e:
        return f"Error SDIFF: {str(e)}"


