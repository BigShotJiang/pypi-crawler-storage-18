import json
from typing import Union, Optional, List

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


def _encode_value(value: Union[str, int, float, dict, list]) -> str:
    """Encode a value for Redis storage.

    - dict/list: JSON serialized
    - int/float: converted to string
    - str: as-is
    """
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


@mcp.tool()
async def set(
    key: str,
    value: Union[str, int, float, dict],
    expiration: Optional[int] = None,
) -> str:
    """Set a string value with an optional expiration time.

    Args:
        key: The key to set.
        value: The value to store. Supports string, number, or dict (auto JSON serialized).
        expiration: Optional expiration time in seconds.

    Returns:
        Confirmation message or error message.
    """
    encoded_value = _encode_value(value)

    try:
        r = TairClientManager.get_client()
        if expiration:
            r.setex(key, expiration, encoded_value)
        else:
            r.set(key, encoded_value)

        msg = f"Successfully set {key}"
        if expiration:
            msg += f" with expiration {expiration}s"
        return msg
    except Exception as e:
        return f"Error setting key {key}: {str(e)}"


@mcp.tool()
async def setnx(key: str, value: Union[str, int, float, dict]) -> Union[bool, str]:
    """Set a key only if it does not already exist.

    Args:
        key: The key to set.
        value: The value to store.

    Returns:
        True if key was set, False if key already exists.
    """
    encoded_value = _encode_value(value)

    try:
        r = TairClientManager.get_client()
        return bool(r.setnx(key, encoded_value))
    except Exception as e:
        return f"Error setnx {key}: {str(e)}"


@mcp.tool()
async def get(key: str) -> Union[str, None, str]:
    """Get the value of a key.

    Args:
        key: The key to retrieve.

    Returns:
        The value, or None if key does not exist.
    """
    try:
        r = TairClientManager.get_client()
        value = r.get(key)
        return value
    except Exception as e:
        return f"Error getting key {key}: {str(e)}"


@mcp.tool()
async def getex(
    key: str,
    expiration: Optional[int] = None,
    persist: bool = False,
) -> Union[str, None, str]:
    """Get the value of a key and optionally set/remove its expiration.

    Args:
        key: The key to retrieve.
        expiration: Set new expiration in seconds (optional).
        persist: If True, remove the expiration (optional).

    Returns:
        The value, or None if key does not exist.
    """
    try:
        r = TairClientManager.get_client()
        kwargs = {}
        if expiration is not None:
            kwargs["ex"] = expiration
        elif persist:
            kwargs["persist"] = True
        return r.getex(key, **kwargs) if kwargs else r.get(key)
    except Exception as e:
        return f"Error getex {key}: {str(e)}"


@mcp.tool()
async def append(key: str, value: str) -> Union[int, str]:
    """Append a string to the value at key.

    If key doesn't exist, creates it with the given value.

    Args:
        key: The key to append to.
        value: The string to append.

    Returns:
        The new length of the string at key.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.append(key, value))
    except Exception as e:
        return f"Error appending to key {key}: {str(e)}"


@mcp.tool()
async def strlen(key: str) -> Union[int, str]:
    """Get the length of the string value stored at key.

    Args:
        key: The key to check.

    Returns:
        The length of the string, or 0 if key doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return int(r.strlen(key))
    except Exception as e:
        return f"Error strlen {key}: {str(e)}"


@mcp.tool()
async def mget(keys: List[str]) -> Union[List[Union[str, None]], str]:
    """Get the values of multiple keys at once.

    Args:
        keys: List of keys to retrieve.

    Returns:
        List of values (None for keys that don't exist).
    """
    try:
        r = TairClientManager.get_client()
        return list(r.mget(keys))
    except Exception as e:
        return f"Error mget: {str(e)}"


@mcp.tool()
async def mset(mapping: dict) -> str:
    """Set multiple key-value pairs at once.

    Args:
        mapping: Dict of key-value pairs to set.

    Returns:
        Confirmation message.
    """
    try:
        r = TairClientManager.get_client()
        # Encode all values
        encoded = {k: _encode_value(v) for k, v in mapping.items()}
        r.mset(encoded)
        return f"Successfully set {len(mapping)} key(s)."
    except Exception as e:
        return f"Error mset: {str(e)}"


@mcp.tool()
async def incr(key: str, amount: int = 1) -> Union[int, str]:
    """Increment the integer value of a key.

    Args:
        key: The key to increment.
        amount: The amount to increment by (default 1).

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        if amount == 1:
            return int(r.incr(key))
        return int(r.incrby(key, amount))
    except Exception as e:
        return f"Error incr {key}: {str(e)}"


@mcp.tool()
async def decr(key: str, amount: int = 1) -> Union[int, str]:
    """Decrement the integer value of a key.

    Args:
        key: The key to decrement.
        amount: The amount to decrement by (default 1).

    Returns:
        The new value after decrementing.
    """
    try:
        r = TairClientManager.get_client()
        if amount == 1:
            return int(r.decr(key))
        return int(r.decrby(key, amount))
    except Exception as e:
        return f"Error decr {key}: {str(e)}"


@mcp.tool()
async def incrbyfloat(key: str, amount: float) -> Union[float, str]:
    """Increment the float value of a key.

    Args:
        key: The key to increment.
        amount: The float amount to increment by (can be negative).

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        return float(r.incrbyfloat(key, amount))
    except Exception as e:
        return f"Error incrbyfloat {key}: {str(e)}"
