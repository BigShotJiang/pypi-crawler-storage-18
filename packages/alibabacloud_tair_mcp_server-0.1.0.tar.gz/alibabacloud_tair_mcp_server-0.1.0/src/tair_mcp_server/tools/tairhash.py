"""TairHash (exHash) MCP Tools.

TairHash is an extended Hash data structure that supports:
- Per-field expiration time (TTL)
- Per-field versioning
- Active expiration strategy

Reference: https://help.aliyun.com/zh/redis/developer-reference/the-tairhash-command

Prerequisites:
- Tair instance (Memory-optimized or Persistent Memory type)
"""

import json
from typing import List, Union, Optional, Literal

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


def _encode_value(value: Union[str, int, float, dict, list]) -> str:
    """Encode a value for storage."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


# ==================== Basic Operations ====================

@mcp.tool()
async def exhset(
    key: str,
    field: str,
    value: Union[str, int, float, dict],
    ex: Optional[int] = None,
    px: Optional[int] = None,
    nx: bool = False,
    xx: bool = False,
    ver: Optional[int] = None,
    abs_ver: Optional[int] = None,
) -> Union[int, str]:
    """Set a field in a TairHash with optional expiration and version.

    Unlike standard Hash, TairHash supports per-field TTL and versioning.

    Args:
        key: The TairHash key.
        field: The field name.
        value: The value to set. Supports string, number, or dict (auto JSON serialized).
        ex: Expire time in seconds for this field.
        px: Expire time in milliseconds for this field.
        nx: Only set if field does not exist.
        xx: Only set if field already exists.
        ver: Version number for optimistic locking (must match current version).
        abs_ver: Set absolute version number.

    Returns:
        1 if new field created, 0 if field updated, -1 if NX/XX condition not met.
    """
    encoded = _encode_value(value)

    try:
        r = TairClientManager.get_client()
        args = [key, field, encoded]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if nx:
            args.append("NX")
        if xx:
            args.append("XX")
        if ver is not None:
            args.extend(["VER", ver])
        if abs_ver is not None:
            args.extend(["ABS", abs_ver])

        return r.execute_command("EXHSET", *args)
    except Exception as e:
        return f"Error exhset: {str(e)}"


@mcp.tool()
async def exhget(key: str, field: str) -> Union[str, None, str]:
    """Get the value of a field from a TairHash.

    Args:
        key: The TairHash key.
        field: The field name.

    Returns:
        The field value, or None if not found.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHGET", key, field)
    except Exception as e:
        return f"Error exhget: {str(e)}"


@mcp.tool()
async def exhmset(key: str, mapping: dict) -> str:
    """Set multiple fields in a TairHash at once.

    Note: This command does not support per-field expiration. Use exhset for TTL.

    Args:
        key: The TairHash key.
        mapping: Dict of field-value pairs.

    Returns:
        OK on success.
    """
    try:
        r = TairClientManager.get_client()
        args = [key]
        for field, value in mapping.items():
            args.extend([field, _encode_value(value)])

        r.execute_command("EXHMSET", *args)
        return f"Set {len(mapping)} field(s) in TairHash '{key}'"
    except Exception as e:
        return f"Error exhmset: {str(e)}"


@mcp.tool()
async def exhmget(key: str, fields: List[str]) -> Union[List[Union[str, None]], str]:
    """Get values of multiple fields from a TairHash.

    Args:
        key: The TairHash key.
        fields: List of field names.

    Returns:
        List of values (None for non-existing fields).
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXHMGET", key, *fields)
        return list(result) if result else []
    except Exception as e:
        return f"Error exhmget: {str(e)}"


@mcp.tool()
async def exhgetall(key: str) -> Union[dict, str]:
    """Get all fields and values from a TairHash.

    Args:
        key: The TairHash key.

    Returns:
        Dict of all field-value pairs.
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXHGETALL", key)
        if not result:
            return {}
        # Result is a flat list [field1, val1, field2, val2, ...]
        it = iter(result)
        return dict(zip(it, it))
    except Exception as e:
        return f"Error exhgetall: {str(e)}"


@mcp.tool()
async def exhdel(key: str, fields: List[str]) -> Union[int, str]:
    """Delete one or more fields from a TairHash.

    Args:
        key: The TairHash key.
        fields: List of field names to delete.

    Returns:
        Number of fields deleted.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHDEL", key, *fields)
    except Exception as e:
        return f"Error exhdel: {str(e)}"


@mcp.tool()
async def exhlen(key: str) -> Union[int, str]:
    """Get the number of fields in a TairHash.

    Args:
        key: The TairHash key.

    Returns:
        Number of fields.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHLEN", key)
    except Exception as e:
        return f"Error exhlen: {str(e)}"


@mcp.tool()
async def exhexists(key: str, field: str) -> Union[bool, str]:
    """Check if a field exists in a TairHash.

    Args:
        key: The TairHash key.
        field: The field name.

    Returns:
        True if field exists, False otherwise.
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXHEXISTS", key, field)
        return bool(result)
    except Exception as e:
        return f"Error exhexists: {str(e)}"


@mcp.tool()
async def exhkeys(key: str) -> Union[List[str], str]:
    """Get all field names in a TairHash.

    Args:
        key: The TairHash key.

    Returns:
        List of field names.
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXHKEYS", key)
        return list(result) if result else []
    except Exception as e:
        return f"Error exhkeys: {str(e)}"


@mcp.tool()
async def exhvals(key: str) -> Union[List[str], str]:
    """Get all values in a TairHash.

    Args:
        key: The TairHash key.

    Returns:
        List of values.
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXHVALS", key)
        return list(result) if result else []
    except Exception as e:
        return f"Error exhvals: {str(e)}"


# ==================== Field Expiration ====================

@mcp.tool()
async def exhexpire(
    key: str,
    field: str,
    seconds: int,
    ver: Optional[int] = None,
    abs_ver: Optional[int] = None,
) -> Union[int, str]:
    """Set expiration time (in seconds) for a specific field.

    This is the key advantage of TairHash over standard Hash.

    Args:
        key: The TairHash key.
        field: The field name.
        seconds: TTL in seconds.
        ver: Version for optimistic locking.
        abs_ver: Set absolute version.

    Returns:
        1 if successful, 0 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        args = [key, field, seconds]
        if ver is not None:
            args.extend(["VER", ver])
        if abs_ver is not None:
            args.extend(["ABS", abs_ver])

        return r.execute_command("EXHEXPIRE", *args)
    except Exception as e:
        return f"Error exhexpire: {str(e)}"


@mcp.tool()
async def exhpexpire(
    key: str,
    field: str,
    milliseconds: int,
) -> Union[int, str]:
    """Set expiration time (in milliseconds) for a specific field.

    Args:
        key: The TairHash key.
        field: The field name.
        milliseconds: TTL in milliseconds.

    Returns:
        1 if successful, 0 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHPEXPIRE", key, field, milliseconds)
    except Exception as e:
        return f"Error exhpexpire: {str(e)}"


@mcp.tool()
async def exhttl(key: str, field: str) -> Union[int, str]:
    """Get the remaining TTL (in seconds) of a field.

    Args:
        key: The TairHash key.
        field: The field name.

    Returns:
        TTL in seconds. -1 if no TTL, -2 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHTTL", key, field)
    except Exception as e:
        return f"Error exhttl: {str(e)}"


@mcp.tool()
async def exhpttl(key: str, field: str) -> Union[int, str]:
    """Get the remaining TTL (in milliseconds) of a field.

    Args:
        key: The TairHash key.
        field: The field name.

    Returns:
        TTL in milliseconds. -1 if no TTL, -2 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHPTTL", key, field)
    except Exception as e:
        return f"Error exhpttl: {str(e)}"


# ==================== Versioning ====================

@mcp.tool()
async def exhver(key: str, field: str) -> Union[int, str]:
    """Get the version number of a field.

    Args:
        key: The TairHash key.
        field: The field name.

    Returns:
        Version number, -1 if key doesn't exist, -2 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHVER", key, field)
    except Exception as e:
        return f"Error exhver: {str(e)}"


@mcp.tool()
async def exhsetver(key: str, field: str, version: int) -> Union[int, str]:
    """Set the version number of a field.

    Args:
        key: The TairHash key.
        field: The field name.
        version: The version number to set.

    Returns:
        1 if successful, 0 if field doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXHSETVER", key, field, version)
    except Exception as e:
        return f"Error exhsetver: {str(e)}"


# ==================== Increment Operations ====================

@mcp.tool()
async def exhincrby(
    key: str,
    field: str,
    amount: int = 1,
    ex: Optional[int] = None,
    px: Optional[int] = None,
    min_val: Optional[int] = None,
    max_val: Optional[int] = None,
) -> Union[int, str]:
    """Increment an integer value of a field.

    Creates the field with value 0 if it doesn't exist, then increments.

    Args:
        key: The TairHash key.
        field: The field name.
        amount: The amount to increment (can be negative).
        ex: Set expiration in seconds.
        px: Set expiration in milliseconds.
        min_val: Minimum allowed value (increment fails if result < min_val).
        max_val: Maximum allowed value (increment fails if result > max_val).

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        args = [key, field, amount]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if min_val is not None:
            args.extend(["MIN", min_val])
        if max_val is not None:
            args.extend(["MAX", max_val])

        return r.execute_command("EXHINCRBY", *args)
    except Exception as e:
        return f"Error exhincrby: {str(e)}"


@mcp.tool()
async def exhincrbyfloat(
    key: str,
    field: str,
    amount: float,
    ex: Optional[int] = None,
    px: Optional[int] = None,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
) -> Union[float, str]:
    """Increment a float value of a field.

    Creates the field with value 0 if it doesn't exist, then increments.

    Args:
        key: The TairHash key.
        field: The field name.
        amount: The float amount to increment (can be negative).
        ex: Set expiration in seconds.
        px: Set expiration in milliseconds.
        min_val: Minimum allowed value.
        max_val: Maximum allowed value.

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        args = [key, field, amount]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if min_val is not None:
            args.extend(["MIN", min_val])
        if max_val is not None:
            args.extend(["MAX", max_val])

        result = r.execute_command("EXHINCRBYFLOAT", *args)
        return float(result)
    except Exception as e:
        return f"Error exhincrbyfloat: {str(e)}"


