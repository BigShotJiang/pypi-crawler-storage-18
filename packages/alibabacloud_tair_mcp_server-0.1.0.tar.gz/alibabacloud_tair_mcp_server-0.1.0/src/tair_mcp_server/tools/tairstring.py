"""TairString (exString) MCP Tools.

TairString is a String data structure with version control, enabling:
- Optimistic locking via version numbers
- Bounded increment/decrement with MIN/MAX limits

Use cases:
- Distributed locks
- Optimistic locking
- Rate limiters with bounds

Reference: https://help.aliyun.com/zh/redis/developer-reference/tairsting-command

Prerequisites:
- Tair instance (Memory-optimized or Persistent Memory type, version >= 1.2.3)
"""

import json
from typing import List, Union, Optional, Any, Dict

from tair_mcp_server.utils.tair_client import TairClientManager
from tair_mcp_server.utils.server import mcp


def _encode_value(value: Union[str, int, float, dict, list]) -> str:
    """Encode a value for storage."""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


# ==================== Basic Operations ====================

@mcp.tool()
async def exset(
    key: str,
    value: Union[str, int, float, dict],
    ex: Optional[int] = None,
    px: Optional[int] = None,
    nx: bool = False,
    xx: bool = False,
    ver: Optional[int] = None,
    abs_ver: Optional[int] = None,
) -> Union[str, None]:
    """Set a TairString value with optional expiration and version control.

    Unlike standard String, TairString tracks a version number for each key,
    enabling optimistic locking patterns.

    Args:
        key: The TairString key.
        value: The value to set. Supports string, number, or dict (auto JSON serialized).
        ex: Expire time in seconds.
        px: Expire time in milliseconds.
        nx: Only set if key does not exist.
        xx: Only set if key already exists.
        ver: Version for optimistic locking. If key exists and versions match,
             update succeeds and version increments. If mismatch, returns error.
        abs_ver: Set absolute version number (overrides current version).

    Returns:
        'OK' on success, None if NX/XX condition not met.
    """
    encoded = _encode_value(value)

    try:
        r = TairClientManager.get_client()
        args = [key, encoded]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if nx:
            args.append("NX")
        if xx:
            args.append("XX")
        if ver is not None:
            args.extend(["VER", ver])
        if abs_ver is not None:
            args.extend(["ABS", abs_ver])

        return r.execute_command("EXSET", *args)
    except Exception as e:
        return f"Error exset: {str(e)}"


@mcp.tool()
async def exget(key: str) -> Union[Dict[str, Any], str]:
    """Get the value and version of a TairString.

    Args:
        key: The TairString key.

    Returns:
        Dict with 'value' and 'version', or None if key doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXGET", key)
        if result is None:
            return {"value": None, "version": None}
        # Result is [value, version]
        return {"value": result[0], "version": result[1]}
    except Exception as e:
        return f"Error exget: {str(e)}"


@mcp.tool()
async def exsetver(key: str, version: int) -> Union[int, str]:
    """Set the version number of a TairString.

    Args:
        key: The TairString key.
        version: The version number to set.

    Returns:
        1 on success, 0 if key doesn't exist.
    """
    try:
        r = TairClientManager.get_client()
        return r.execute_command("EXSETVER", key, version)
    except Exception as e:
        return f"Error exsetver: {str(e)}"


# ==================== Increment Operations with Bounds ====================

@mcp.tool()
async def exincrby(
    key: str,
    amount: int = 1,
    ex: Optional[int] = None,
    px: Optional[int] = None,
    nx: bool = False,
    xx: bool = False,
    ver: Optional[int] = None,
    abs_ver: Optional[int] = None,
    min_val: Optional[int] = None,
    max_val: Optional[int] = None,
) -> Union[int, str]:
    """Increment an integer value with optional bounds.

    Creates key with value 0 if it doesn't exist, then increments.
    The MIN/MAX bounds prevent overflow - returns error if result would exceed bounds.

    Args:
        key: The TairString key.
        amount: The amount to increment (can be negative for decrement).
        ex: Set expiration in seconds.
        px: Set expiration in milliseconds.
        nx: Only increment if key does not exist.
        xx: Only increment if key exists.
        ver: Version for optimistic locking.
        abs_ver: Set absolute version number.
        min_val: Minimum allowed result value (fails if result < min_val).
        max_val: Maximum allowed result value (fails if result > max_val).

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        args = [key, amount]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if nx:
            args.append("NX")
        if xx:
            args.append("XX")
        if ver is not None:
            args.extend(["VER", ver])
        if abs_ver is not None:
            args.extend(["ABS", abs_ver])
        if min_val is not None:
            args.extend(["MIN", min_val])
        if max_val is not None:
            args.extend(["MAX", max_val])

        return r.execute_command("EXINCRBY", *args)
    except Exception as e:
        return f"Error exincrby: {str(e)}"


@mcp.tool()
async def exincrbyfloat(
    key: str,
    amount: float,
    ex: Optional[int] = None,
    px: Optional[int] = None,
    nx: bool = False,
    xx: bool = False,
    ver: Optional[int] = None,
    abs_ver: Optional[int] = None,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
) -> Union[float, str]:
    """Increment a float value with optional bounds.

    Creates key with value 0 if it doesn't exist, then increments.

    Args:
        key: The TairString key.
        amount: The float amount to increment (can be negative).
        ex: Set expiration in seconds.
        px: Set expiration in milliseconds.
        nx: Only increment if key does not exist.
        xx: Only increment if key exists.
        ver: Version for optimistic locking.
        abs_ver: Set absolute version number.
        min_val: Minimum allowed result value.
        max_val: Maximum allowed result value.

    Returns:
        The new value after incrementing.
    """
    try:
        r = TairClientManager.get_client()
        args = [key, amount]

        if ex is not None:
            args.extend(["EX", ex])
        if px is not None:
            args.extend(["PX", px])
        if nx:
            args.append("NX")
        if xx:
            args.append("XX")
        if ver is not None:
            args.extend(["VER", ver])
        if abs_ver is not None:
            args.extend(["ABS", abs_ver])
        if min_val is not None:
            args.extend(["MIN", min_val])
        if max_val is not None:
            args.extend(["MAX", max_val])

        result = r.execute_command("EXINCRBYFLOAT", *args)
        return float(result)
    except Exception as e:
        return f"Error exincrbyfloat: {str(e)}"


# ==================== CAS Operations (Optimistic Locking) ====================

@mcp.tool()
async def excas(
    key: str,
    new_value: Union[str, int, float, dict],
    version: int,
) -> Dict[str, Any]:
    """Compare-And-Swap: atomically update value if version matches.

    This is the core operation for optimistic locking:
    1. Read key with exget to get current value and version
    2. Process the value locally
    3. Use excas to update only if version hasn't changed

    Args:
        key: The TairString key.
        new_value: The new value to set if version matches.
        version: Expected current version. Update only succeeds if this matches.

    Returns:
        Dict with:
        - success: True if update succeeded
        - value: Current value (new_value if success, old value if failed)
        - version: Current version number
        - message: 'OK' or error description
    """
    encoded = _encode_value(new_value)

    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXCAS", key, encoded, version)

        # Result: ["OK", "", new_version] on success
        # Result: ["ERR update version is stale", old_value, old_version] on failure
        # Result: -1 if key doesn't exist
        if result == -1:
            return {
                "success": False,
                "value": None,
                "version": None,
                "message": "Key does not exist",
            }

        if result[0] == "OK":
            return {
                "success": True,
                "value": encoded,
                "version": result[2],
                "message": "OK",
            }
        else:
            return {
                "success": False,
                "value": result[1],
                "version": result[2],
                "message": "Version mismatch - value was modified by another client",
            }
    except Exception as e:
        return {
            "success": False,
            "value": None,
            "version": None,
            "message": f"Error excas: {str(e)}",
        }


@mcp.tool()
async def excad(key: str, version: int) -> Dict[str, Any]:
    """Compare-And-Delete: delete key only if version matches.

    Useful for releasing locks or cleaning up resources safely.

    Args:
        key: The TairString key.
        version: Expected current version. Delete only succeeds if this matches.

    Returns:
        Dict with:
        - success: True if delete succeeded
        - message: Description of result
    """
    try:
        r = TairClientManager.get_client()
        result = r.execute_command("EXCAD", key, version)

        # 1 = success, 0 = version mismatch, -1 = key doesn't exist
        if result == 1:
            return {"success": True, "message": "Key deleted successfully"}
        elif result == 0:
            return {"success": False, "message": "Version mismatch - key not deleted"}
        else:  # -1
            return {"success": False, "message": "Key does not exist"}
    except Exception as e:
        return {"success": False, "message": f"Error excad: {str(e)}"}


