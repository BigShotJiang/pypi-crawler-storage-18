import importlib
import pkgutil
from mcp.server.fastmcp import FastMCP


def load_tools():
    import tair_mcp_server.tools as tools_pkg

    for _, module_name, _ in pkgutil.iter_modules(tools_pkg.__path__):
        importlib.import_module(
            f"tair_mcp_server.tools.{module_name}"
        )


# Initialize FastMCP server
mcp = FastMCP("Redis MCP Server", dependencies=["valkey", "dotenv", "numpy", "click"])

# Load tools
load_tools()