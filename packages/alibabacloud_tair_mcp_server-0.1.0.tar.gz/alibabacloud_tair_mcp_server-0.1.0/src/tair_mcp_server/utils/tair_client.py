import logging
from typing import Optional, Union

import valkey
from valkey import Valkey
from valkey.cluster import ValkeyCluster

from tair_mcp_server.utils.config import TAIR_CFG

_logger = logging.getLogger(__name__)


class TairClientManager:

    _instance: Optional[Union[Valkey, ValkeyCluster]] = None
    _decode_responses: bool = True

    @classmethod
    def get_client(cls, decode_responses: bool = True) -> Union[Valkey, ValkeyCluster]:
        """Get or create the Tair client instance.

        Returns:
            Valkey or ValkeyCluster client instance.
        """
        # If decode_responses changed, need to recreate client
        if cls._instance is not None and cls._decode_responses != decode_responses:
            cls.reset()

        if cls._instance is None:
            cls._decode_responses = decode_responses
            try:
                if TAIR_CFG.get("cluster_mode"):
                    cls._instance = valkey.ValkeyCluster(
                        host=TAIR_CFG["host"],
                        port=TAIR_CFG["port"],
                        username=TAIR_CFG.get("username") or None,
                        password=TAIR_CFG.get("password") or None,
                        decode_responses=decode_responses,
                    )
                    _logger.info("Connected to Tair cluster at %s:%s",
                                 TAIR_CFG["host"], TAIR_CFG["port"])
                else:
                    cls._instance = valkey.Valkey(
                        host=TAIR_CFG["host"],
                        port=TAIR_CFG["port"],
                        db=TAIR_CFG.get("db", 0),
                        username=TAIR_CFG.get("username") or None,
                        password=TAIR_CFG.get("password") or None,
                        decode_responses=decode_responses,
                    )
                    _logger.info("Connected to Tair at %s:%s db=%s",
                                 TAIR_CFG["host"], TAIR_CFG["port"], TAIR_CFG.get("db", 0))

            except valkey.exceptions.ValkeyError as e:
                _logger.error("Failed to connect to Tair: %s", e)
                raise
            except Exception as e:
                _logger.error("Unexpected error creating connection: %s", e)
                raise

        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the client instance. Call this if config changes."""
        if cls._instance is not None:
            try:
                cls._instance.close()
            except Exception:
                pass
            cls._instance = None
            _logger.info("Tair client connection reset")