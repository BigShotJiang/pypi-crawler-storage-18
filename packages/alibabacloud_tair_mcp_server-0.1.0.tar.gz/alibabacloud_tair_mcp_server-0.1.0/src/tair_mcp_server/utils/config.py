import os
from typing import Any, Dict

from dotenv import load_dotenv


load_dotenv()


def _get_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"true", "1", "t", "yes", "y"}


def _get_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


TAIR_CFG: Dict[str, Any] = {
    "host": os.getenv("HOST", "127.0.0.1"),
    "port": _get_int("PORT", 6379),
    "username": os.getenv("USERNAME", ""),
    "password": os.getenv("PASSWORD", ""),
    "db": _get_int("DB", 0),
    "cluster_mode": _get_bool("CLUSTER_MODE", False),
    "log_level": os.getenv("TAIR_MCP_LOG_LEVEL", "INFO"),
    "log_file": os.getenv("TAIR_MCP_LOG_FILE", None),
}