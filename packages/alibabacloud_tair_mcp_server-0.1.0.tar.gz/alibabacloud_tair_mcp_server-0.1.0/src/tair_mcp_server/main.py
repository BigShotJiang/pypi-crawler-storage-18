import logging
from typing import Any, Dict

import click

from tair_mcp_server.utils.server import mcp
from tair_mcp_server.utils.logging import configure_logging
from tair_mcp_server.utils import config as cfg
from tair_mcp_server.version import __version__


class TairMCPServer:
    def __init__(self, cli_config: Dict[str, Any] = None):
        configure_logging()
        self._logger = logging.getLogger(__name__)

        if cli_config:
            self._apply_cli_config(cli_config)

        self._logger.info("Starting the Tair MCP Server")

    def _apply_cli_config(self, cli_config: Dict[str, Any]):
        for key, value in cli_config.items():
            if value is not None:
                cfg.TAIR_CFG[key] = value

    def run(self):
        mcp.run()


@click.command()
@click.version_option(version=__version__, prog_name="tair-mcp-server")
@click.option("--host", default=None, help="Tair host (default: from env or 127.0.0.1)")
@click.option("--port", default=None, type=int, help="Tair port (default: from env or 6379)")
@click.option("--db", default=None, type=int, help="Tair database number")
@click.option("--username", default=None, help="Tair username")
@click.option("--password", default=None, help="Tair password")
@click.option("--cluster-mode", is_flag=True, default=None, help="Enable cluster mode")
def cli(host, port, db, username, password, cluster_mode):
    """Tair MCP Server - Model Context Protocol server for Tair/Redis."""
    cli_config = {}

    if host is not None:
        cli_config["host"] = host
    if port is not None:
        cli_config["port"] = port
    if db is not None:
        cli_config["db"] = db
    if username is not None:
        cli_config["username"] = username
    if password is not None:
        cli_config["password"] = password
    if cluster_mode is not None:
        cli_config["cluster_mode"] = cluster_mode

    server = TairMCPServer(cli_config=cli_config if cli_config else None)
    server.run()


def main():
    server = TairMCPServer()
    server.run()


if __name__ == "__main__":
    main()