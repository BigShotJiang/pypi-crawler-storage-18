"""
FortiOS CMDB - Cmdb Firewall Proxy Address

Configuration endpoint for managing cmdb firewall proxy address objects.

API Endpoints:
    GET    /cmdb/firewall/proxy_address
    POST   /cmdb/firewall/proxy_address
    GET    /cmdb/firewall/proxy_address
    PUT    /cmdb/firewall/proxy_address/{identifier}
    DELETE /cmdb/firewall/proxy_address/{identifier}

Example Usage:
    >>> from hfortix.FortiOS import FortiOS
    >>> fgt = FortiOS(host="192.168.1.99", token="your-api-token")
    >>>
    >>> # List all items
    >>> items = fgt.api.cmdb.firewall.proxy_address.get()
    >>>
    >>> # Get specific item (if supported)
    >>> item = fgt.api.cmdb.firewall.proxy_address.get(name="item_name")
    >>>
    >>> # Create new item (use POST)
    >>> result = fgt.api.cmdb.firewall.proxy_address.post(
    ...     name="new_item",
    ...     # ... additional parameters
    ... )
    >>>
    >>> # Update existing item (use PUT)
    >>> result = fgt.api.cmdb.firewall.proxy_address.put(
    ...     name="existing_item",
    ...     # ... parameters to update
    ... )
    >>>
    >>> # Delete item
    >>> result = fgt.api.cmdb.firewall.proxy_address.delete(name="item_name")

Important:
    - Use **POST** to create new objects (404 error if already exists)
    - Use **PUT** to update existing objects (404 error if doesn't exist)
    - Use **GET** to retrieve configuration (no changes made)
    - Use **DELETE** to remove objects (404 error if doesn't exist)
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ....http_client_interface import IHTTPClient


class ProxyAddress:
    """
    Proxyaddress Operations.

    Provides CRUD operations for FortiOS proxyaddress configuration.

    Methods:
        get(): Retrieve configuration objects
        post(): Create new configuration objects
        put(): Update existing configuration objects
        delete(): Remove configuration objects

    Important:
        - POST creates new objects (404 if name already exists)
        - PUT updates existing objects (404 if name doesn't exist)
        - GET retrieves objects without making changes
        - DELETE removes objects (404 if name doesn't exist)
    """

    def __init__(self, client: "IHTTPClient"):
        """
        Initialize ProxyAddress endpoint.

        Args:
            client: HTTPClient instance for API communication
        """
        self._client = client

    def get(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        attr: str | None = None,
        skip_to_datasource: dict | None = None,
        acs: int | None = None,
        search: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Select a specific entry from a CLI table.

        Args:
            name: Object identifier (optional for list, required for specific)
            attr: Attribute name that references other table (optional)
            skip_to_datasource: Skip to provided table's Nth entry. E.g {datasource: 'firewall.address', pos: 10, global_entry: false} (optional)
            acs: If true, returned result are in ascending order. (optional)
            search: If present, the objects will be filtered by the search value. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if name:
            endpoint = f"/firewall/proxy-address/{name}"
        else:
            endpoint = "/firewall/proxy-address"
        if attr is not None:
            params["attr"] = attr
        if skip_to_datasource is not None:
            params["skip_to_datasource"] = skip_to_datasource
        if acs is not None:
            params["acs"] = acs
        if search is not None:
            params["search"] = search
        params.update(kwargs)
        return self._client.get(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def put(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        before: str | None = None,
        after: str | None = None,
        uuid: str | None = None,
        type: str | None = None,
        host: str | None = None,
        host_regex: str | None = None,
        path: str | None = None,
        query: str | None = None,
        referrer: str | None = None,
        category: list | None = None,
        method: str | None = None,
        ua: str | None = None,
        ua_min_ver: str | None = None,
        ua_max_ver: str | None = None,
        header_name: str | None = None,
        header: str | None = None,
        case_sensitivity: str | None = None,
        header_group: list | None = None,
        color: int | None = None,
        tagging: list | None = None,
        comment: str | None = None,
        application: list | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Update this specific resource.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            name: Object identifier (required)
            before: If *action=move*, use *before* to specify the ID of the resource that this resource will be moved before. (optional)
            after: If *action=move*, use *after* to specify the ID of the resource that this resource will be moved after. (optional)
            name: Address name. (optional)
            uuid: Universally Unique Identifier (UUID; automatically assigned but can be manually reset). (optional)
            type: Proxy address type. (optional)
            host: Address object for the host. (optional)
            host_regex: Host name as a regular expression. (optional)
            path: URL path as a regular expression. (optional)
            query: Match the query part of the URL as a regular expression. (optional)
            referrer: Enable/disable use of referrer field in the HTTP header to match the address. (optional)
            category: FortiGuard category ID. (optional)
            method: HTTP request methods to be used. (optional)
            ua: Names of browsers to be used as user agent. (optional)
            ua_min_ver: Minimum version of the user agent specified in dotted notation. For example, use 90.0.1 with the ua field set to "chrome" to require Google Chrome's minimum version must be 90.0.1. (optional)
            ua_max_ver: Maximum version of the user agent specified in dotted notation. For example, use 120 with the ua field set to "chrome" to require Google Chrome's maximum version must be 120. (optional)
            header_name: Name of HTTP header. (optional)
            header: HTTP header name as a regular expression. (optional)
            case_sensitivity: Enable to make the pattern case sensitive. (optional)
            header_group: HTTP header group. (optional)
            color: Integer value to determine the color of the icon in the GUI (1 - 32, default = 0, which sets value to 1). (optional)
            tagging: Config object tagging. (optional)
            comment: Optional comments. (optional)
            application: SaaS application. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for put()")
        endpoint = f"/firewall/proxy-address/{name}"
        if before is not None:
            data_payload["before"] = before
        if after is not None:
            data_payload["after"] = after
        if name is not None:
            data_payload["name"] = name
        if uuid is not None:
            data_payload["uuid"] = uuid
        if type is not None:
            data_payload["type"] = type
        if host is not None:
            data_payload["host"] = host
        if host_regex is not None:
            data_payload["host-regex"] = host_regex
        if path is not None:
            data_payload["path"] = path
        if query is not None:
            data_payload["query"] = query
        if referrer is not None:
            data_payload["referrer"] = referrer
        if category is not None:
            data_payload["category"] = category
        if method is not None:
            data_payload["method"] = method
        if ua is not None:
            data_payload["ua"] = ua
        if ua_min_ver is not None:
            data_payload["ua-min-ver"] = ua_min_ver
        if ua_max_ver is not None:
            data_payload["ua-max-ver"] = ua_max_ver
        if header_name is not None:
            data_payload["header-name"] = header_name
        if header is not None:
            data_payload["header"] = header
        if case_sensitivity is not None:
            data_payload["case-sensitivity"] = case_sensitivity
        if header_group is not None:
            data_payload["header-group"] = header_group
        if color is not None:
            data_payload["color"] = color
        if tagging is not None:
            data_payload["tagging"] = tagging
        if comment is not None:
            data_payload["comment"] = comment
        if application is not None:
            data_payload["application"] = application
        data_payload.update(kwargs)
        return self._client.put(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )

    def delete(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Delete this specific resource.

        Args:
            name: Object identifier (required)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for delete()")
        endpoint = f"/firewall/proxy-address/{name}"
        params.update(kwargs)
        return self._client.delete(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def exists(
        self,
        name: str,
        vdom: str | bool | None = None,
    ) -> bool:
        """
        Check if an object exists.

        Args:
            name: Object identifier
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.

        Returns:
            True if object exists, False otherwise

        Example:
            >>> if fgt.api.cmdb.firewall.address.exists("server1"):
            ...     print("Address exists")
        """
        import inspect

        from hfortix.FortiOS.exceptions_forti import ResourceNotFoundError

        # Call get() - returns dict (sync) or coroutine (async)
        result = self.get(name=name, vdom=vdom)

        # Check if async mode
        if inspect.iscoroutine(result):

            async def _async():
                try:
                    await result  # type: ignore[misc]
                    return True
                except ResourceNotFoundError:
                    return False

            return _async()

        # Sync mode - get() already executed, no exception means it exists
        return True

    def post(
        self,
        payload_dict: dict[str, Any] | None = None,
        nkey: str | None = None,
        name: str | None = None,
        uuid: str | None = None,
        type: str | None = None,
        host: str | None = None,
        host_regex: str | None = None,
        path: str | None = None,
        query: str | None = None,
        referrer: str | None = None,
        category: list | None = None,
        method: str | None = None,
        ua: str | None = None,
        ua_min_ver: str | None = None,
        ua_max_ver: str | None = None,
        header_name: str | None = None,
        header: str | None = None,
        case_sensitivity: str | None = None,
        header_group: list | None = None,
        color: int | None = None,
        tagging: list | None = None,
        comment: str | None = None,
        application: list | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Create object(s) in this table.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            nkey: If *action=clone*, use *nkey* to specify the ID for the new resource to be created. (optional)
            name: Address name. (optional)
            uuid: Universally Unique Identifier (UUID; automatically assigned but can be manually reset). (optional)
            type: Proxy address type. (optional)
            host: Address object for the host. (optional)
            host_regex: Host name as a regular expression. (optional)
            path: URL path as a regular expression. (optional)
            query: Match the query part of the URL as a regular expression. (optional)
            referrer: Enable/disable use of referrer field in the HTTP header to match the address. (optional)
            category: FortiGuard category ID. (optional)
            method: HTTP request methods to be used. (optional)
            ua: Names of browsers to be used as user agent. (optional)
            ua_min_ver: Minimum version of the user agent specified in dotted notation. For example, use 90.0.1 with the ua field set to "chrome" to require Google Chrome's minimum version must be 90.0.1. (optional)
            ua_max_ver: Maximum version of the user agent specified in dotted notation. For example, use 120 with the ua field set to "chrome" to require Google Chrome's maximum version must be 120. (optional)
            header_name: Name of HTTP header. (optional)
            header: HTTP header name as a regular expression. (optional)
            case_sensitivity: Enable to make the pattern case sensitive. (optional)
            header_group: HTTP header group. (optional)
            color: Integer value to determine the color of the icon in the GUI (1 - 32, default = 0, which sets value to 1). (optional)
            tagging: Config object tagging. (optional)
            comment: Optional comments. (optional)
            application: SaaS application. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}
        endpoint = "/firewall/proxy-address"
        if nkey is not None:
            data_payload["nkey"] = nkey
        if name is not None:
            data_payload["name"] = name
        if uuid is not None:
            data_payload["uuid"] = uuid
        if type is not None:
            data_payload["type"] = type
        if host is not None:
            data_payload["host"] = host
        if host_regex is not None:
            data_payload["host-regex"] = host_regex
        if path is not None:
            data_payload["path"] = path
        if query is not None:
            data_payload["query"] = query
        if referrer is not None:
            data_payload["referrer"] = referrer
        if category is not None:
            data_payload["category"] = category
        if method is not None:
            data_payload["method"] = method
        if ua is not None:
            data_payload["ua"] = ua
        if ua_min_ver is not None:
            data_payload["ua-min-ver"] = ua_min_ver
        if ua_max_ver is not None:
            data_payload["ua-max-ver"] = ua_max_ver
        if header_name is not None:
            data_payload["header-name"] = header_name
        if header is not None:
            data_payload["header"] = header
        if case_sensitivity is not None:
            data_payload["case-sensitivity"] = case_sensitivity
        if header_group is not None:
            data_payload["header-group"] = header_group
        if color is not None:
            data_payload["color"] = color
        if tagging is not None:
            data_payload["tagging"] = tagging
        if comment is not None:
            data_payload["comment"] = comment
        if application is not None:
            data_payload["application"] = application
        data_payload.update(kwargs)
        return self._client.post(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )
