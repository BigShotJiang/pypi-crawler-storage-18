"""
FortiOS CMDB - Cmdb System Mobile Tunnel

Configuration endpoint for managing cmdb system mobile tunnel objects.

API Endpoints:
    GET    /cmdb/system/mobile_tunnel
    POST   /cmdb/system/mobile_tunnel
    GET    /cmdb/system/mobile_tunnel
    PUT    /cmdb/system/mobile_tunnel/{identifier}
    DELETE /cmdb/system/mobile_tunnel/{identifier}

Example Usage:
    >>> from hfortix.FortiOS import FortiOS
    >>> fgt = FortiOS(host="192.168.1.99", token="your-api-token")
    >>>
    >>> # List all items
    >>> items = fgt.api.cmdb.system.mobile_tunnel.get()
    >>>
    >>> # Get specific item (if supported)
    >>> item = fgt.api.cmdb.system.mobile_tunnel.get(name="item_name")
    >>>
    >>> # Create new item (use POST)
    >>> result = fgt.api.cmdb.system.mobile_tunnel.post(
    ...     name="new_item",
    ...     # ... additional parameters
    ... )
    >>>
    >>> # Update existing item (use PUT)
    >>> result = fgt.api.cmdb.system.mobile_tunnel.put(
    ...     name="existing_item",
    ...     # ... parameters to update
    ... )
    >>>
    >>> # Delete item
    >>> result = fgt.api.cmdb.system.mobile_tunnel.delete(name="item_name")

Important:
    - Use **POST** to create new objects (404 error if already exists)
    - Use **PUT** to update existing objects (404 error if doesn't exist)
    - Use **GET** to retrieve configuration (no changes made)
    - Use **DELETE** to remove objects (404 error if doesn't exist)
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ....http_client_interface import IHTTPClient


class MobileTunnel:
    """
    Mobiletunnel Operations.

    Provides CRUD operations for FortiOS mobiletunnel configuration.

    Methods:
        get(): Retrieve configuration objects
        post(): Create new configuration objects
        put(): Update existing configuration objects
        delete(): Remove configuration objects

    Important:
        - POST creates new objects (404 if name already exists)
        - PUT updates existing objects (404 if name doesn't exist)
        - GET retrieves objects without making changes
        - DELETE removes objects (404 if name doesn't exist)
    """

    def __init__(self, client: "IHTTPClient"):
        """
        Initialize MobileTunnel endpoint.

        Args:
            client: HTTPClient instance for API communication
        """
        self._client = client

    def get(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        attr: str | None = None,
        skip_to_datasource: dict | None = None,
        acs: int | None = None,
        search: str | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Select a specific entry from a CLI table.

        Args:
            name: Object identifier (optional for list, required for specific)
            attr: Attribute name that references other table (optional)
            skip_to_datasource: Skip to provided table's Nth entry. E.g {datasource: 'firewall.address', pos: 10, global_entry: false} (optional)
            acs: If true, returned result are in ascending order. (optional)
            search: If present, the objects will be filtered by the search value. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if name:
            endpoint = f"/system/mobile-tunnel/{name}"
        else:
            endpoint = "/system/mobile-tunnel"
        if attr is not None:
            params["attr"] = attr
        if skip_to_datasource is not None:
            params["skip_to_datasource"] = skip_to_datasource
        if acs is not None:
            params["acs"] = acs
        if search is not None:
            params["search"] = search
        params.update(kwargs)
        return self._client.get(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def put(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        before: str | None = None,
        after: str | None = None,
        status: str | None = None,
        roaming_interface: str | None = None,
        home_agent: str | None = None,
        home_address: str | None = None,
        renew_interval: int | None = None,
        lifetime: int | None = None,
        reg_interval: int | None = None,
        reg_retry: int | None = None,
        n_mhae_spi: int | None = None,
        n_mhae_key_type: str | None = None,
        n_mhae_key: str | None = None,
        hash_algorithm: str | None = None,
        tunnel_mode: str | None = None,
        network: list | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Update this specific resource.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            name: Object identifier (required)
            before: If *action=move*, use *before* to specify the ID of the resource that this resource will be moved before. (optional)
            after: If *action=move*, use *after* to specify the ID of the resource that this resource will be moved after. (optional)
            name: Tunnel name. (optional)
            status: Enable/disable this mobile tunnel. (optional)
            roaming_interface: Select the associated interface name from available options. (optional)
            home_agent: IPv4 address of the NEMO HA (Format: xxx.xxx.xxx.xxx). (optional)
            home_address: Home IP address (Format: xxx.xxx.xxx.xxx). (optional)
            renew_interval: Time before lifetime expiration to send NMMO HA re-registration (5 - 60, default = 60). (optional)
            lifetime: NMMO HA registration request lifetime (180 - 65535 sec, default = 65535). (optional)
            reg_interval: NMMO HA registration interval (5 - 300, default = 5). (optional)
            reg_retry: Maximum number of NMMO HA registration retries (1 to 30, default = 3). (optional)
            n_mhae_spi: NEMO authentication SPI (default: 256). (optional)
            n_mhae_key_type: NEMO authentication key type (ASCII or base64). (optional)
            n_mhae_key: NEMO authentication key. (optional)
            hash_algorithm: Hash Algorithm (Keyed MD5). (optional)
            tunnel_mode: NEMO tunnel mode (GRE tunnel). (optional)
            network: NEMO network configuration. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for put()")
        endpoint = f"/system/mobile-tunnel/{name}"
        if before is not None:
            data_payload["before"] = before
        if after is not None:
            data_payload["after"] = after
        if name is not None:
            data_payload["name"] = name
        if status is not None:
            data_payload["status"] = status
        if roaming_interface is not None:
            data_payload["roaming-interface"] = roaming_interface
        if home_agent is not None:
            data_payload["home-agent"] = home_agent
        if home_address is not None:
            data_payload["home-address"] = home_address
        if renew_interval is not None:
            data_payload["renew-interval"] = renew_interval
        if lifetime is not None:
            data_payload["lifetime"] = lifetime
        if reg_interval is not None:
            data_payload["reg-interval"] = reg_interval
        if reg_retry is not None:
            data_payload["reg-retry"] = reg_retry
        if n_mhae_spi is not None:
            data_payload["n-mhae-spi"] = n_mhae_spi
        if n_mhae_key_type is not None:
            data_payload["n-mhae-key-type"] = n_mhae_key_type
        if n_mhae_key is not None:
            data_payload["n-mhae-key"] = n_mhae_key
        if hash_algorithm is not None:
            data_payload["hash-algorithm"] = hash_algorithm
        if tunnel_mode is not None:
            data_payload["tunnel-mode"] = tunnel_mode
        if network is not None:
            data_payload["network"] = network
        data_payload.update(kwargs)
        return self._client.put(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )

    def delete(
        self,
        name: str | None = None,
        payload_dict: dict[str, Any] | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Delete this specific resource.

        Args:
            name: Object identifier (required)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        params = payload_dict.copy() if payload_dict else {}

        # Build endpoint path
        if not name:
            raise ValueError("name is required for delete()")
        endpoint = f"/system/mobile-tunnel/{name}"
        params.update(kwargs)
        return self._client.delete(
            "cmdb", endpoint, params=params, vdom=vdom, raw_json=raw_json
        )

    def exists(
        self,
        name: str,
        vdom: str | bool | None = None,
    ) -> bool:
        """
        Check if an object exists.

        Args:
            name: Object identifier
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.

        Returns:
            True if object exists, False otherwise

        Example:
            >>> if fgt.api.cmdb.firewall.address.exists("server1"):
            ...     print("Address exists")
        """
        import inspect

        from hfortix.FortiOS.exceptions_forti import ResourceNotFoundError

        # Call get() - returns dict (sync) or coroutine (async)
        result = self.get(name=name, vdom=vdom)

        # Check if async mode
        if inspect.iscoroutine(result):

            async def _async():
                try:
                    await result  # type: ignore[misc]
                    return True
                except ResourceNotFoundError:
                    return False

            return _async()

        # Sync mode - get() already executed, no exception means it exists
        return True

    def post(
        self,
        payload_dict: dict[str, Any] | None = None,
        nkey: str | None = None,
        name: str | None = None,
        status: str | None = None,
        roaming_interface: str | None = None,
        home_agent: str | None = None,
        home_address: str | None = None,
        renew_interval: int | None = None,
        lifetime: int | None = None,
        reg_interval: int | None = None,
        reg_retry: int | None = None,
        n_mhae_spi: int | None = None,
        n_mhae_key_type: str | None = None,
        n_mhae_key: str | None = None,
        hash_algorithm: str | None = None,
        tunnel_mode: str | None = None,
        network: list | None = None,
        vdom: str | bool | None = None,
        raw_json: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Create object(s) in this table.

        Args:
            payload_dict: Optional dictionary of all parameters (can be passed as first positional arg)
            nkey: If *action=clone*, use *nkey* to specify the ID for the new resource to be created. (optional)
            name: Tunnel name. (optional)
            status: Enable/disable this mobile tunnel. (optional)
            roaming_interface: Select the associated interface name from available options. (optional)
            home_agent: IPv4 address of the NEMO HA (Format: xxx.xxx.xxx.xxx). (optional)
            home_address: Home IP address (Format: xxx.xxx.xxx.xxx). (optional)
            renew_interval: Time before lifetime expiration to send NMMO HA re-registration (5 - 60, default = 60). (optional)
            lifetime: NMMO HA registration request lifetime (180 - 65535 sec, default = 65535). (optional)
            reg_interval: NMMO HA registration interval (5 - 300, default = 5). (optional)
            reg_retry: Maximum number of NMMO HA registration retries (1 to 30, default = 3). (optional)
            n_mhae_spi: NEMO authentication SPI (default: 256). (optional)
            n_mhae_key_type: NEMO authentication key type (ASCII or base64). (optional)
            n_mhae_key: NEMO authentication key. (optional)
            hash_algorithm: Hash Algorithm (Keyed MD5). (optional)
            tunnel_mode: NEMO tunnel mode (GRE tunnel). (optional)
            network: NEMO network configuration. (optional)
            vdom: Virtual domain name, or False to skip. Handled by HTTPClient.
            raw_json: If True, return full API response with metadata. If False, return only results.
            **kwargs: Additional query parameters (filter, sort, start, count, format, etc.)

        Common Query Parameters (via **kwargs):
            filter: Filter results (e.g., filter='name==value')
            sort: Sort results (e.g., sort='name,asc')
            start: Starting entry index for paging
            count: Maximum number of entries to return
            format: Fields to return (e.g., format='name|type')
            See FortiOS REST API documentation for full list of query parameters

        Returns:
            Dictionary containing API response
        """
        data_payload = payload_dict.copy() if payload_dict else {}
        params = {}
        endpoint = "/system/mobile-tunnel"
        if nkey is not None:
            data_payload["nkey"] = nkey
        if name is not None:
            data_payload["name"] = name
        if status is not None:
            data_payload["status"] = status
        if roaming_interface is not None:
            data_payload["roaming-interface"] = roaming_interface
        if home_agent is not None:
            data_payload["home-agent"] = home_agent
        if home_address is not None:
            data_payload["home-address"] = home_address
        if renew_interval is not None:
            data_payload["renew-interval"] = renew_interval
        if lifetime is not None:
            data_payload["lifetime"] = lifetime
        if reg_interval is not None:
            data_payload["reg-interval"] = reg_interval
        if reg_retry is not None:
            data_payload["reg-retry"] = reg_retry
        if n_mhae_spi is not None:
            data_payload["n-mhae-spi"] = n_mhae_spi
        if n_mhae_key_type is not None:
            data_payload["n-mhae-key-type"] = n_mhae_key_type
        if n_mhae_key is not None:
            data_payload["n-mhae-key"] = n_mhae_key
        if hash_algorithm is not None:
            data_payload["hash-algorithm"] = hash_algorithm
        if tunnel_mode is not None:
            data_payload["tunnel-mode"] = tunnel_mode
        if network is not None:
            data_payload["network"] = network
        data_payload.update(kwargs)
        return self._client.post(
            "cmdb", endpoint, data=data_payload, vdom=vdom, raw_json=raw_json
        )
