# CVE-2025-55182 – React2Shell 🔥

**React2Shell** is a security research tool that exploits  
**CVE-2025-55182**, a Remote Code Execution (RCE) vulnerability in  
**Next.js React Server Components (RSC)**.

This tool allows authorized security testers to execute system commands
on vulnerable Next.js applications by abusing the RSC action handling
and redirect mechanism.

---

![React2Shell Banner](assets/banner.jpg)

## 📌 Vulnerability Overview

- **CVE ID**: CVE-2025-55182  
- **Affected Technology**: Next.js (React Server Components)
- **Impact**: Remote Code Execution (RCE)
- **Attack Vector**: Crafted multipart RSC action request
- **Severity**: Critical

🔗 NVD Reference:  
https://nvd.nist.gov/vuln/detail/CVE-2025-55182

---

## 🚀 Features

- ✅ Reliable RCE exploitation
- ✅ Clean CLI interface
- ✅ Colored output with execution results
- ✅ Minimal dependencies
- ✅ Easy integration into recon / automation pipelines
- ✅ Designed for security researchers & red teamers

---

## 📦 Installation

```bash
pip install CYBERTECHMIND-CVE-2025-55182
