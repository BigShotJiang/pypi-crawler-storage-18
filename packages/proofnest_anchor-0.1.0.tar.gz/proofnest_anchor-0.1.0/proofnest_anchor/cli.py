"""
PROOFNEST ANCHOR CLI - Git commit for your IP.

Re-exports honest-anchor CLI with proofnest branding.
"""

# Direct re-export from honest-anchor
from honest_anchor.cli import cli

__all__ = ["cli"]
