"""
PROOFNEST ANCHOR - Git commit for your IP.

Timestamp files to Bitcoin in seconds. Prove prior art. Forever.

This is the new name for honest-anchor. Same functionality, new brand.

Usage:
    anchor init           # Initialize .anchor/ directory
    anchor commit <file>  # Timestamp to Bitcoin
    anchor verify <file>  # Verify file hasn't changed
    anchor status         # Show pending/confirmed anchors

Or use the pn-anchor alias:
    pn-anchor commit <file>

Copyright (c) 2025 Stellanium Ltd. All rights reserved.
Licensed under Apache License 2.0.
PROOFNEST is a trademark of Stellanium Ltd.
"""

__version__ = "0.1.0"
__author__ = "Stellanium Ltd"
__email__ = "admin@stellanium.io"
__license__ = "Apache-2.0"

# Re-export honest-anchor CLI
from honest_anchor.cli import cli

__all__ = ["cli", "__version__"]
