#!/usr/bin/env python3
import os
import sys
import time
import shutil
import tempfile
import threading
import traceback
import signal
from datetime import datetime

NAME = "Keltor"
VERSION = "0.1.0"
AUTOSAVE_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "keltor")
AUTOSAVE_FILE = os.path.join(AUTOSAVE_DIR, "autosave.keltor")
ALT_BASE_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "sr")
UNDO_LIMIT = 1000

try:
    import curses
except Exception:
    curses = None

class Editor:
    def __init__(self, stdscr=None, filename=None):
        self.stdscr = stdscr
        self.filename = filename
        self.lines = [""]
        self.cx = 0
        self.cy = 0
        self.offset = 0
        self.msg = f"{NAME} {VERSION}"
        self.dirty = False
        self.undo = []
        self.redo = []
        self.autosave_enabled = True
        self.autosave_interval = 4.0
        self._last_autosave = time.time()
        self._running = True
        self._lock = threading.RLock()
        self._init_dirs()
        self._start_autosave_thread()
        signal.signal(signal.SIGINT, lambda n, f: self._request_quit())
        signal.signal(signal.SIGTERM, lambda n, f: self._request_quit())
        if filename:
            self.open_file(filename)
        else:
            if os.path.exists(AUTOSAVE_FILE):
                try:
                    with open(AUTOSAVE_FILE, "r", encoding="utf-8") as f:
                        data = f.read().splitlines()
                    if data:
                        self.lines = data
                        self.msg = "Recovered from autosave"
                        self.dirty = True
                except Exception:
                    self.msg = "Failed to read autosave"

    def _init_dirs(self):
        try:
            os.makedirs(AUTOSAVE_DIR, exist_ok=True)
        except Exception:
            pass

    def _start_autosave_thread(self):
        def autosave_loop():
            while self._running:
                try:
                    time.sleep(self.autosave_interval)
                    with self._lock:
                        if self.autosave_enabled and self.dirty:
                            self._write_atomic(AUTOSAVE_FILE, "\n".join(self.lines))
                            self._last_autosave = time.time()
                except Exception:
                    pass
        t = threading.Thread(target=autosave_loop, daemon=True)
        t.start()

    def snapshot(self):
        if len(self.undo) >= UNDO_LIMIT:
            self.undo.pop(0)
        self.undo.append((self.lines[:], self.cx, self.cy))
        self.redo.clear()

    def restore(self, stack_from, stack_to):
        if not stack_from:
            return
        stack_to.append((self.lines[:], self.cx, self.cy))
        self.lines, self.cx, self.cy = stack_from.pop()
        self.cx = max(0, min(self.cx, len(self.lines[self.cy])))
        self.dirty = True

    def open_file(self, name):
        try:
            with open(name, "r", encoding="utf-8") as f:
                self.lines = f.read().splitlines()
            if not self.lines:
                self.lines = [""]
            self.filename = name
            self.cx = self.cy = self.offset = 0
            self.dirty = False
            self.msg = f"Opened: {os.path.basename(name)}"
        except Exception:
            self.msg = "Failed to open file"

    def _write_atomic(self, path, text):
        tmp = None
        try:
            d = os.path.dirname(path)
            if d and not os.path.exists(d):
                os.makedirs(d, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".tmp", dir=d or ".")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(text)
            os.replace(tmp, path)
            return True
        except Exception:
            try:
                if tmp and os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            return False

    def save(self):
        if not self.filename:
            name = self._prompt("Save as: ")
            if not name:
                self.msg = "Save canceled"
                return
            self.filename = name
        ok = self._write_atomic(self.filename, "\n".join(self.lines))
        if ok:
            self.dirty = False
            self.msg = "Saved"
            try:
                if os.path.exists(AUTOSAVE_FILE):
                    os.remove(AUTOSAVE_FILE)
            except Exception:
                pass
        else:
            self.msg = "Save failed"

    def export_from_base(self):
        bases = []
        if os.path.isdir(AUTOSAVE_DIR):
            bases.append(AUTOSAVE_DIR)
        if os.path.isdir(ALT_BASE_DIR) and ALT_BASE_DIR not in bases:
            bases.append(ALT_BASE_DIR)
        if not bases:
            self.msg = "No known base dirs found"
            return
        opt = None
        if len(bases) == 1:
            opt = bases[0]
        else:
            idx = self._prompt_choice("Choose base dir", bases)
            if idx is None:
                self.msg = "Export canceled"
                return
            opt = bases[idx]
        entries = []
        try:
            for root, _, files in os.walk(opt):
                for f in files:
                    full = os.path.join(root, f)
                    rel = os.path.relpath(full, opt)
                    entries.append((rel, full))
        except Exception:
            self.msg = "Failed to enumerate base dir"
            return
        if not entries:
            self.msg = "No files to export"
            return
        names = [e[0] for e in entries]
        sel = self._prompt_choice("Choose file to export", names)
        if sel is None:
            self.msg = "Export canceled"
            return
        src = entries[sel][1]
        dest = self._prompt("Export to (absolute path): ")
        if not dest:
            self.msg = "Export canceled"
            return
        try:
            dest_dir = os.path.dirname(dest)
            if dest_dir and not os.path.exists(dest_dir):
                os.makedirs(dest_dir, exist_ok=True)
            shutil.copy2(src, dest)
            self.msg = f"Exported to {dest}"
        except Exception:
            self.msg = "Export failed"

    def autosave_once(self):
        try:
            with self._lock:
                self._write_atomic(AUTOSAVE_FILE, "\n".join(self.lines))
                self._last_autosave = time.time()
        except Exception:
            pass

    def new_file(self):
        self.snapshot()
        self.lines = [""]
        self.filename = None
        self.cx = self.cy = self.offset = 0
        self.dirty = False
        self.msg = "New file"

    def insert(self, ch):
        self.snapshot()
        line = self.lines[self.cy]
        self.lines[self.cy] = line[:self.cx] + ch + line[self.cx:]
        self.cx += len(ch)
        self.dirty = True

    def backspace(self):
        if self.cx == 0 and self.cy == 0:
            return
        self.snapshot()
        if self.cx > 0:
            line = self.lines[self.cy]
            self.lines[self.cy] = line[:self.cx-1] + line[self.cx:]
            self.cx -= 1
        else:
            prev = self.lines[self.cy - 1]
            self.cx = len(prev)
            self.lines[self.cy - 1] = prev + self.lines[self.cy]
            self.lines.pop(self.cy)
            self.cy -= 1
        self.dirty = True

    def delete(self):
        self.snapshot()
        line = self.lines[self.cy]
        if self.cx < len(line):
            self.lines[self.cy] = line[:self.cx] + line[self.cx+1:]
        elif self.cy < len(self.lines) - 1:
            self.lines[self.cy] += self.lines[self.cy + 1]
            self.lines.pop(self.cy + 1)
        self.dirty = True

    def newline(self):
        self.snapshot()
        line = self.lines[self.cy]
        self.lines[self.cy] = line[:self.cx]
        self.lines.insert(self.cy + 1, line[self.cx:])
        self.cy += 1
        self.cx = 0
        self.dirty = True

    def search(self):
        term = self._prompt("Search: ")
        if not term:
            self.msg = "Search canceled"
            return
        for y, line in enumerate(self.lines):
            x = line.find(term)
            if x != -1:
                self.cy = y
                self.cx = x
                if y < self.offset:
                    self.offset = y
                self.msg = f"Found at Ln {y+1}"
                return
        self.msg = "Not found"

    def move(self, dy, dx):
        self.cy = max(0, min(self.cy + dy, len(self.lines) - 1))
        self.cx = max(0, min(self.cx + dx, len(self.lines[self.cy])))

    def scroll(self):
        if not self.stdscr:
            return
        h, _ = self.stdscr.getmaxyx()
        view_h = max(1, h - 3)
        if self.cy < self.offset:
            self.offset = self.cy
        if self.cy >= self.offset + view_h:
            self.offset = self.cy - view_h + 1

    def safe_add(self, y, x, text, attr=0):
        if not self.stdscr:
            return
        h, w = self.stdscr.getmaxyx()
        if y < 0 or y >= h or x >= w:
            return
        try:
            self.stdscr.addstr(y, x, text[:max(0, w - x)], attr)
        except Exception:
            try:
                self.stdscr.addstr(y, x, text[:max(0, w - x)])
            except Exception:
                pass

    def _prompt(self, prompt):
        if not self.stdscr:
            try:
                return input(prompt).strip()
            except Exception:
                return ""
        h, w = self.stdscr.getmaxyx()
        curses.echo()
        try:
            self.stdscr.move(h - 1, 0)
            self.stdscr.clrtoeol()
            self.safe_add(h - 1, 0, prompt)
            self.stdscr.refresh()
            maxlen = max(10, w - len(prompt) - 1)
            s = self.stdscr.getstr(h - 1, len(prompt), maxlen)
            if not s:
                return ""
            return s.decode().strip()
        except Exception:
            return ""
        finally:
            curses.noecho()

    def _prompt_choice(self, prompt, options):
        if not options:
            return None
        if not self.stdscr:
            for i, o in enumerate(options):
                print(f"{i}: {o}")
            try:
                sel = input(f"{prompt} (index): ").strip()
                if not sel:
                    return None
                idx = int(sel)
                if 0 <= idx < len(options):
                    return idx
                return None
            except Exception:
                return None
        h, w = self.stdscr.getmaxyx()
        idx = 0
        start = 0
        while True:
            self.stdscr.erase()
            self.safe_add(0, 0, prompt[:w])
            for i in range(start, min(start + h - 3, len(options))):
                prefix = "-> " if i == idx else "   "
                self.safe_add(1 + i - start, 0, prefix + options[i][:w-4])
            self.safe_add(h - 1, 0, "Enter=select  Esc=cancel  Up/Down=move")
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            if ch in (10, 13):
                return idx
            if ch in (27,):
                return None
            if ch in (curses.KEY_UP,):
                if idx > 0:
                    idx -= 1
                    if idx < start:
                        start = idx
            if ch in (curses.KEY_DOWN,):
                if idx < len(options) - 1:
                    idx += 1
                    if idx >= start + (h - 3):
                        start += 1

    def _draw_bar(self, y, w):
        bar_items = [
            "CTRL+S Save",
            "CTRL+O Open",
            "CTRL+N New",
            "CTRL+Q Quit",
            "CTRL+F Search",
            "CTRL+Z Undo",
            "CTRL+Y Redo",
            "CTRL+E Export"
        ]
        line = ""
        lines = []
        for item in bar_items:
            part = item + " | "
            if len(line) + len(part) > w:
                lines.append(line.rstrip(" |"))
                line = part
            else:
                line += part
        if line:
            lines.append(line.rstrip(" |"))
        for i, l in enumerate(lines):
            if y + i >= 0:
                self.safe_add(y + i, 0, l[:w], curses.A_REVERSE)

    def draw(self):
        if not self.stdscr:
            return
        self.stdscr.erase()
        h, w = self.stdscr.getmaxyx()
        view_h = max(1, h - 3)
        for i in range(view_h):
            li = self.offset + i
            if li >= len(self.lines):
                break
            line_num = f"{li+1:4} "
            self.safe_add(i, 0, line_num, curses.A_BOLD)
            self.safe_add(i, 5, self.lines[li][:max(0, w-6)])
        name = self.filename or "New File"
        status = f"{name}{' *' if self.dirty else ''}  Ln {self.cy+1}, Col {self.cx+1}"
        self.safe_add(h - 3, 0, status[:w], curses.A_REVERSE)
        if self.msg:
            self.safe_add(h - 2, 0, self.msg[:w])
            self.msg = ""
        else:
            self._draw_bar(h - 2, w)
        cy = self.cy - self.offset
        cx = self.cx + 5
        if 0 <= cy < view_h and cx < w:
            try:
                self.stdscr.move(cy, cx)
            except Exception:
                pass
        self.stdscr.refresh()

    def handle_key(self, ch):
        if ch == 17:
            if self.dirty:
                if hasattr(self, "_quit_confirmed") and self._quit_confirmed:
                    self._running = False
                else:
                    self._quit_confirmed = True
                    self.msg = "Unsaved changes - press CTRL+Q again to quit without saving"
            else:
                self._running = False
            return True
        if ch == 19:
            self.save()
            return True
        if ch == 15:
            name = self._prompt("Open file: ")
            if name:
                self.open_file(name)
            return True
        if ch == 14:
            self.new_file()
            return True
        if ch == 6:
            self.search()
            return True
        if ch == 26:
            self.restore(self.undo, self.redo)
            return True
        if ch == 25:
            self.restore(self.redo, self.undo)
            return True
        if ch == 5:
            self.export_from_base()
            return True
        if ch == curses.KEY_UP:
            self.move(-1, 0)
            return True
        if ch == curses.KEY_DOWN:
            self.move(1, 0)
            return True
        if ch == curses.KEY_LEFT:
            self.move(0, -1)
            return True
        if ch == curses.KEY_RIGHT:
            self.move(0, 1)
            return True
        if ch in (curses.KEY_BACKSPACE, 127, 8):
            self.backspace()
            return True
        if ch == curses.KEY_DC:
            self.delete()
            return True
        if ch in (10, 13):
            self.newline()
            return True
        if 32 <= ch <= 126:
            self.insert(chr(ch))
            return True
        return True

    def loop(self):
        if not self.stdscr:
            self._cli_loop()
            return
        self.stdscr.keypad(True)
        try:
            curses.curs_set(1)
        except Exception:
            pass
        while self._running:
            try:
                self.scroll()
                self.draw()
                if self.autosave_enabled and (time.time() - self._last_autosave) > self.autosave_interval:
                    if self.dirty:
                        with self._lock:
                            self._write_atomic(AUTOSAVE_FILE, "\n".join(self.lines))
                            self._last_autosave = time.time()
                ch = self.stdscr.getch()
                self.handle_key(ch)
            except KeyboardInterrupt:
                break
            except Exception:
                self._handle_exception()
                break
        try:
            curses.curs_set(1)
        except Exception:
            pass

    def _cli_loop(self):
        print(f"{NAME} {VERSION} - simple mode")
        while self._running:
            try:
                cmd = input("cmd (open/save/new/insert/lines/export/quit/help): ").strip().lower()
                if cmd == "open":
                    p = input("path: ").strip()
                    if p:
                        self.open_file(p)
                elif cmd == "save":
                    self.save()
                elif cmd == "new":
                    self.new_file()
                elif cmd == "insert":
                    s = input("text: ")
                    for ch in s:
                        self.insert(ch)
                elif cmd == "lines":
                    for i, l in enumerate(self.lines, 1):
                        print(f"{i}: {l}")
                elif cmd == "export":
                    self.export_from_base()
                elif cmd == "quit":
                    if self.dirty:
                        confirm = input("Unsaved changes. quit anyway? (y/n): ").strip().lower()
                        if confirm == "y":
                            break
                    else:
                        break
                elif cmd == "help":
                    print("commands: open save new insert lines export quit")
                else:
                    print("unknown")
            except KeyboardInterrupt:
                break
            except Exception:
                traceback.print_exc()
                break

    def _handle_exception(self):
        tb = traceback.format_exc()
        try:
            logdir = AUTOSAVE_DIR
            os.makedirs(logdir, exist_ok=True)
            logfile = os.path.join(logdir, "keltor_error.log")
            with open(logfile, "a", encoding="utf-8") as f:
                f.write(f"[{datetime.utcnow().isoformat()}]\n")
                f.write(tb + "\n\n")
        except Exception:
            pass
        self.msg = "Internal error - logged"

    def _request_quit(self):
        self._running = False

def main_curses(stdscr):
    editor = Editor(stdscr, sys.argv[1] if len(sys.argv) > 1 else None)
    editor.loop()

def main():
    if curses:
        try:
            curses.wrapper(main_curses)
            return
        except Exception:
            pass
    editor = Editor(None, sys.argv[1] if len(sys.argv) > 1 else None)
    editor.loop()
