# Keltor

Keltor is a cross-platform, terminal-based text editor written in pure Python.
It is built with a strong focus on stability, data safety, and predictable behavior
in real-world terminal environments.

Keltor is designed to work reliably in small terminals, remote shells, and
restricted systems while keeping full control over your files.

---

## Features

- Cross-platform support (Linux, macOS, Windows)
- Terminal user interface (curses-based)
- Automatic background autosave
- Crash recovery
- Atomic file saving
- Undo / Redo system
- Search functionality
- Responsive multi-line status and help bar
- Safe file export to any user-defined path
- Fallback CLI mode if curses is unavailable
- Uses only the Python standard library (except optional curses on Windows)

---

## Design Goals

Keltor follows these core principles:

- Stability over features
- No silent data loss
- Explicit file access
- Predictable behavior
- Minimal external dependencies
- Terminal-first operation

---

## Requirements

### Required
- Python 3.8 or newer

### Optional
- curses  
  - Linux / macOS: included by default  
  - Windows:
    ```bash
    pip install windows-curses
    ```

---

## Installation

Download the script and run it directly:

```bash
python keltor.py