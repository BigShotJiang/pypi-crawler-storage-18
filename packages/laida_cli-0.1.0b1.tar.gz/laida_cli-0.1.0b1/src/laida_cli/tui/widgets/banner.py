"""Banner Widget - LAIDA branding header.

Contract: CNT-TUI-WDG-007
Traceability: UI-002
"""

from textual.widgets import Static


class BannerWidget(Static):
    """Widget displaying LAIDA banner/logo."""

    DEFAULT_CSS = """
    BannerWidget {
        height: 4;
        padding: 0 1;
        background: #1e1b4b;
        color: #a78bfa;
        text-align: center;
    }
    """

    BANNER = """
[bold #a78bfa]╭─────────────────────────────────────╮[/]
[bold #a78bfa]│[/]  [bold #5eead4]LAIDA[/] [#94a3b8]Mission Control[/]  [bold #f59e0b]β0.1.0[/]  [bold #a78bfa]│[/]
[bold #a78bfa]╰─────────────────────────────────────╯[/]"""

    def render(self) -> str:
        return self.BANNER
