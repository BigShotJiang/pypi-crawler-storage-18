"""QuickActionsWidget - Command shortcuts panel.

Contract: CNT-TUI-WDG-006
Traceability: UX-001, UI-002
"""

from textual.widgets import Static


class QuickActionsWidget(Static):
    """Widget displaying available keyboard shortcuts.

    Shows a compact grid of available actions that users
    can trigger with single keystrokes.
    """

    DEFAULT_CSS = """
    QuickActionsWidget {
        border: round #8b5cf6;
        padding: 1 2;
        margin: 0 1 1 1;
        height: auto;
    }
    """

    # Action definitions: (key, label, description)
    ACTIONS = [
        ("R", "Run Next", "Execute next step"),
        ("S", "Status", "Show project status"),
        ("V", "Validate", "Validate artifacts"),
        ("L", "Login", "Claude Code auth"),
        ("Q", "Quit", "Exit TUI"),
        ("?", "Help", "Show help"),
    ]

    def __init__(self, is_executing: bool = False) -> None:
        """Initialize the quick actions panel.

        Args:
            is_executing: Whether an execution is in progress
        """
        super().__init__()
        self._is_executing = is_executing

    def render(self) -> str:
        """Render the quick actions panel."""
        lines = ["[bold #a78bfa]⚡ QUICK ACTIONS[/]", ""]

        if self._is_executing:
            lines.append("[#fbbf24]Execution in progress...[/]")
            lines.append("[#64748b]Actions disabled[/]")
            return "\n".join(lines)

        # Build action grid (2 columns)
        action_pairs = []
        for i in range(0, len(self.ACTIONS), 2):
            pair = self.ACTIONS[i : i + 2]
            action_pairs.append(pair)

        for pair in action_pairs:
            row_parts = []
            for key, label, _ in pair:
                row_parts.append(f"[#5eead4][{key}][/] {label}")
            lines.append("  ".join(row_parts))

        return "\n".join(lines)

    def set_executing(self, is_executing: bool) -> None:
        """Update execution state.

        Args:
            is_executing: Whether execution is in progress
        """
        self._is_executing = is_executing
        self.refresh()
