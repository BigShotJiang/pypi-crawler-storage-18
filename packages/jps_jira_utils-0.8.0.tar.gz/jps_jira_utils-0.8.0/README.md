# jps-jira-utils

![Build & Test](https://github.com/jai-python3/jps-jira-utils/actions/workflows/test.yml/badge.svg)
![Publish to PyPI](https://github.com/jai-python3/jps-jira-utils/actions/workflows/publish-to-pypi.yml/badge.svg)
[![codecov](https://codecov.io/gh/jai-python3/jps-jira-utils/branch/main/graph/badge.svg)](https://codecov.io/gh/jai-python3/jps-jira-utils)
[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue)](#)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](#)

> **A clean, modular, production-grade toolkit for Jira power users**  
> Built with Typer, rich logging, and full test coverage.

## Features

- `add_comment.py` — Add rich comments (with optional file attachments) to any Jira issue
  - Interactive multiline input (ends on two blank lines)
  - Load comment from file (`--comment-file`)
  - Attach files with pre-canned or custom notes (STDOUT, STDERR, log file, README, etc.)
  - Final confirmation table before posting
  - Full logging with structured output
  - Optional custom config file (`--config-file`)
- Secure credential loading via `~/.config/jps-jira-utils/.jira.env` (never in code or CLI)
- Clean, maintainable, fully tested codebase using modern Python best practices
- Zero external runtime dependencies beyond `requests`, `typer`, and `python-dotenv`

## Installation

### From source (recommended for development)

```bash
git clone https://github.com/jai-python3/jps-jira-utils.git
cd jps-jira-utils
make install    # creates .venv and installs in editable mode
```


From PyPI (coming soon)

```bash
pip install jps-jira-utils
```

## Configuration

### Setting up credentials

The tool requires Jira Cloud credentials to authenticate API requests. By default, credentials are loaded from:

```
~/.config/jps-jira-utils/.jira.env
```

#### Auto-create the configuration file

You can automatically create the configuration directory and file with placeholder values:

```bash
mkdir -p ~/.config/jps-jira-utils
cat > ~/.config/jps-jira-utils/.jira.env << 'EOF'
JIRA_BASE_URL=https://your-company.atlassian.net
JIRA_EMAIL=your.email@company.com
JIRA_API_TOKEN=your_api_token_here
EOF
```

Then edit the file with your actual credentials:

```bash
nano ~/.config/jps-jira-utils/.jira.env
# or use your preferred editor
```

#### Manual configuration

Create the configuration directory and file manually:

```bash
mkdir -p ~/.config/jps-jira-utils
```

Then create `~/.config/jps-jira-utils/.jira.env` with your Jira Cloud credentials:

```env
JIRA_BASE_URL=https://your-company.atlassian.net
JIRA_EMAIL=your.email@company.com
JIRA_API_TOKEN=your_api_token_here
```

**Generate your API token at:** https://id.atlassian.com/manage-profile/security/api-tokens

#### Using a custom config file

If you need to use a different location for your configuration file, you can specify it with the `--config-file` option:

```bash
jps-add-comment JPS-1234 --config-file /path/to/custom/.jira.env
```

## Prerequisites

Python 3.11 or higher is required.

## Usage

Add a comment interactively

```bash
jps-add-comment JPS-1234
```

Add a comment from a file + attach a log



```bash
jps-add-comment JPS-1234 \
  --comment-file results.txt \
  --attach-file test-run.log
```


Full help

```bash
jps-add-comment --help
```


## Development
```bash
# Format, lint, and fix everything
make fix
make format
make lint
```

### Run tests with coverage

```bash
make test
```

### Run pre-commit hooks (recommended)

```bash
pre-commit run --all-files
```


## Project Structure
```text
src/jps_jira_utils/
├── add_comment.py        # Typer CLI entrypoint
├── jira_helper.py        # Credential loading
├── logging_helper.py     # Structured logging setup
└── prompt_helper.py      # Interactive input utilities

tests/                    # Includes coverage, darglint-compliant
```


##  Contributing

Contributions are welcome! Please:

Use pre-commit hooks
Write tests for new features
Follow Google-style docstrings
Keep the codebase clean and modular

## License

MIT License © Jaideep Sundaram