# govaitextextract
[![PyPI version](https://badge.fury.io/py/govaitextextract.svg)](https://badge.fury.io/py/govaitextextract)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/govaitextextract)](https://pepy.tech/project/govaitextextract)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


**Extract structured information from government or organizational tech/AI initiatives**

A Python package that processes text inputs (e.g., news headlines, announcements) to extract structured data about government or organizational technology and AI initiatives. It uses a language model to identify key details like entity, initiative name, focus, and more, returning results in a consistent format (JSON/XML-compatible).

---

## 📦 Installation

```bash
pip install govaitextextract
```

---

## 🚀 Usage

### Basic Usage (Default LLM: ChatLLM7)
```python
from govaitextextract import govaitextextract

user_input = "The Ministry of Digital Transformation announces a new AI project with 50 specialists."
response = govaitextextract(user_input)
print(response)
```

### Custom LLM Integration
You can replace the default `ChatLLM7` with any LangChain-compatible LLM (e.g., OpenAI, Anthropic, Google):

#### Using OpenAI:
```python
from langchain_openai import ChatOpenAI
from govaitextextract import govaitextextract

llm = ChatOpenAI()
response = govaitextextract(user_input, llm=llm)
```

#### Using Anthropic:
```python
from langchain_anthropic import ChatAnthropic
from govaitextextract import govaitextextract

llm = ChatAnthropic()
response = govaitextextract(user_input, llm=llm)
```

#### Using Google Generative AI:
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from govaitextextract import govaitextextract

llm = ChatGoogleGenerativeAI()
response = govaitextextract(user_input, llm=llm)
```

---

## 🔧 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | The input text (e.g., news headline) to process. |
| `api_key` | `Optional[str]` | LLM7 API key (defaults to `LLM7_API_KEY` env var). |
| `llm` | `Optional[BaseChatModel]` | Custom LangChain LLM (e.g., `ChatOpenAI`). Falls back to `ChatLLM7`. |

---

## 🔑 API Key & Rate Limits
- **Default LLM**: `ChatLLM7` (from [langchain_llm7](https://pypi.org/project/langchain-llm7/)).
- **Free Tier**: Sufficient for most use cases.
- **Custom Key**: Pass via `api_key` or `LLM7_API_KEY` env var.
- **Get a Key**: [Register at LLM7](https://token.llm7.io/).

---

## 📜 Output Format
The function returns structured data (e.g., JSON-like) extracted from the input text, such as:
```python
{
    "entity": "Ministry of Digital Transformation",
    "initiative_name": "New AI Project",
    "specialists": 50,
    "focus": "AI"
}
```

---

## 📝 Notes
- Uses regex validation for consistency.
- Error handling included for LLM failures.
- Extensible for custom patterns via `pattern` in prompts.

---

## 📢 Issues & Support
Report bugs or feature requests at:
[GitHub Issues](https://github.com/chigwell/govaitextextract/issues)

---

## 👤 Author
**Eugene Evstafev**
📧 [hi@euegne.plus](mailto:hi@euegne.plus)
🔗 [GitHub: chigwell](https://github.com/chigwell)

---