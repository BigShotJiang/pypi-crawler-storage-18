"""
PyLDO - Linked Data Objects for Python

Making RDF as easy as working with plain Python objects.

Example:
    >>> from pyldo import LdoDataset, parse_rdf
    >>> from pyldo.converter import parse_shex, generate_python_types
    >>> 
    >>> # Generate types from ShEx schema
    >>> schema = parse_shex(open("profile.shex").read())
    >>> code = generate_python_types(schema)
    >>> exec(code)  # or save to file and import
    >>> 
    >>> # Create dataset and parse RDF
    >>> dataset = parse_rdf('''
    ...     @prefix foaf: <http://xmlns.com/foaf/0.1/> .
    ...     <#alice> foaf:name "Alice" .
    ... ''', base_iri="https://example.com/")
    >>> 
    >>> # Get typed object
    >>> profile = dataset.using(ProfileShape).from_subject("#alice")
    >>> print(profile.name)  # "Alice"
"""

__version__ = "0.0.9"

# Import main components for convenient access
from .dataset import (
    DatasetEvent,
    EventType,
    RdfGraph,
    SubscribableDataset,
    Transaction,
    TransactionChanges,
)
from .ldo import (
    # Core
    FetchedResource,
    LdoBuilder,
    LdoDataset,
    LdSet,
    LinkedDataObject,
    LinkQuery,
    LinkQueryOptions,
    ResourceBinder,
    ResourceBinding,
    WriteResourceBindingMixin,
    # Helper functions
    change_data,
    commit_data,
    commit_transaction,
    explore_links,
    get_graph,
    get_language_preferences,
    get_subject,
    graph_of,
    languages_of,
    match_object,
    match_subject,
    parse_rdf,
    parse_rdf_async,
    rollback_transaction,
    serialize,
    set_language_preferences,
    set_values,
    start_transaction,
    sync_to_graph,
    to_jsonld,
    to_ntriples,
    to_sparql_update,
    to_turtle,
    transaction_changes,
)
from .solid import (
    FolderData,
    Item,
    SolidAuth,
    SolidClient,
    SolidContainer,
    SolidOidcAuth,
    SolidOidcSession,
    SolidResource,
    SolidSession,
    WebIdProfile,
    fetch_webid_profile,
    # URL utilities
    ensure_trailing_slash,
    get_item_name,
    get_parent_url,
    get_root_url,
    remove_trailing_slash,
)

__all__ = [
    "__version__",
    # Dataset
    "RdfGraph",
    "Transaction",
    "TransactionChanges",
    "SubscribableDataset",
    "DatasetEvent",
    "EventType",
    # LDO Core
    "LdoDataset",
    "LdoBuilder",
    "LinkedDataObject",
    "LdSet",
    # Link Query
    "LinkQuery",
    "LinkQueryOptions",
    "FetchedResource",
    "explore_links",
    # Write Resource Binding
    "ResourceBinder",
    "ResourceBinding",
    "WriteResourceBindingMixin",
    # Parsing
    "parse_rdf",
    "parse_rdf_async",
    # Serialization
    "get_graph",
    "get_subject",
    "graph_of",
    "serialize",
    "to_turtle",
    "to_ntriples",
    "to_jsonld",
    "to_sparql_update",
    # Language support
    "languages_of",
    "set_language_preferences",
    "get_language_preferences",
    # Set helper
    "set_values",
    # Transactions
    "start_transaction",
    "commit_transaction",
    "rollback_transaction",
    "transaction_changes",
    "sync_to_graph",
    # Change pattern
    "change_data",
    "commit_data",
    # Match helpers
    "match_subject",
    "match_object",
    # Solid
    "SolidAuth",
    "SolidSession",
    "SolidOidcAuth",
    "SolidOidcSession",
    "SolidClient",
    "SolidResource",
    "SolidContainer",
    "FolderData",
    "Item",
    "WebIdProfile",
    "fetch_webid_profile",
    # URL utilities
    "get_root_url",
    "get_parent_url",
    "get_item_name",
    "ensure_trailing_slash",
    "remove_trailing_slash",
]
