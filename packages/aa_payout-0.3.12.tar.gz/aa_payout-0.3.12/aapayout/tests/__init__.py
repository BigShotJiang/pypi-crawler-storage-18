"""Initialize the tests"""
