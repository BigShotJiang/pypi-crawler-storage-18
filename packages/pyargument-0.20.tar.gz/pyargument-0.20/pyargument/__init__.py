class PyArgument:
    def __init__(self, skip=False):
        
        self.pyargs = []
        self.skip = skip
        self.attrs = {}
        self.arg_map = {}
        
    def list_all(self):
        return self.attrs
        
    def list_alias(self):
        alias = {}
        for key, value in self.arg_map.items():
            if value not in alias:
                alias[value] = []
            alias[value].append(key)
        return alias
        
    def list_args(self):
        # returning list of existed args.
        return [arg for arg in self.attrs if self.attrs[arg]["exists"]]
    
    def add_arg(self, *names, optarg=False, default=None, required=False):
        if not names:
            raise ValueError("At least one argument name must be provided.")
            
        # Pick the first long name, else first name
        argname = ""
        for arg in names:
            if arg.startswith("--"):
                argname = arg[2::]
                break
                
        if not argname: names[0].lstrip("-")
        argvalue = default # if optarg else False
        
        # Setting argument dict.
        self.attrs[argname] = {
            "value": argvalue,
            "optarg": optarg,
            "required": required,
            "names": names,
            "exists": False
        }
        
        # Map all names to argname.
        for arg in names:
            self.arg_map[arg] = argname
        
        # Setting argument attribute for instenses (object)
        setattr(self, argname, argvalue)
    
    # Parse command line arguments
    def parse_args(self, *args):
        import sys
        # Capture all arguments expect script name.
        nargs = sys.argv[1::]
        
        # Loop throught all command line arguments
        for i, arg in enumerate(nargs):
            
            # Only handle arguments that exists in arg_map.
            if any(name for name in self.arg_map if name in arg):
                internal_name = [name for name in self.arg_map if name in arg][0]
                argstart = arg.lstrip("-")
                
                argtype = 0
                argname = ""
                argvalue = ""
                
                # Extract argument name until the "=" comes.
                for j in range(len(argstart)):
                    if argstart[j] != "=":
                        argname += argstart[j]
                    else:
                        # Break the loop if "=" comes.
                        argtype = 1
                        break
                
                # Extract the value after "=" and start where index of "=".
                for k in range(1, j+len(argstart)):
                    if j+k < len(argstart): # Make sure loop did not go out of index.
                        argvalue += argstart[j+k]
                        
                argname = self.arg_map[internal_name]
                    
                try:
                    argattr = self.attrs[argname] # Gets aegument metadata from dict.
                except:
                    continue
                
                # Check if argument accept value.
                if argattr["optarg"]:
                    # Checks if next value is NOT greater than i+1 index either another flag.
                    if i+1 < len(nargs) and not nargs[i+1].startswith("-"):
                        argvalue = nargs[i+1] # Store next argument.
                else:
                    argvalue = True
                    
                if argvalue: # Updates the argument attribute on argvalue condition.
                    argattr["exists"] = True
                else:
                    argattr["exists"] = False
                    
                if (
                    (argattr["value"] and not argvalue) or
                    (not argattr["value"] and not argvalue)
                ):
                    argvalue = argattr["value"]
                
                # Updates the argument attribute.
                setattr(self, argname, argvalue)
                
                # Updates the argument dict.
                argattr["value"] = argvalue
                
                # Push collected internal args to pyargs.
                if argtype == 0:
                    self.pyargs.append(internal_name)
                    if argvalue is not True:
                        self.pyargs.append(argvalue)
                elif argvalue is not True:
                    self.pyargs.append(arg)
                
        # Check required arguments
        unavailable_args = []
        for k, v in self.attrs.items():
            if v["required"] and not v["value"]:
                unavailable_args.append(f"Required argument {v['names']} not provided.")
        if len(unavailable_args) > 0:
            for args in unavailable_args:
                print(args)
            sys.exit(1)
