from . import PyArgument
import json
import os

def main():
    pwd = os.getcwd()
    parser = PyArgument()
    parser.add_arg("--online")
    parser.add_arg("--input", "-in", optarg=True, required=True)
    parser.add_arg("--dir", "--folder", optarg=True, default=pwd)
    parser.add_arg("--file", optarg=True)
    parser.add_arg("--pwd", "-p", "--cwd", required=True)

    parser.parse_args()
    
    print("Collected args:", parser.pyargs)
    print("Arguments metadata:", json.dumps(parser.list_all(), indent=4))
    print("Arguments provided:", parser.list_args())
    print("Arguments alias:", json.dumps(parser.list_alias(), indent=4))
    print("online:", parser.online)
    print("input:", parser.input)
    print("dir:", parser.dir)
    print("file:", parser.file)
    print("pwd:", parser.pwd)

if __name__ == "__main__":
    main()