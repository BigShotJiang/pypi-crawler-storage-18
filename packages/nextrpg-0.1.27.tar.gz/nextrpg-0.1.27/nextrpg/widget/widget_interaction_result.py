from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Self

from nextrpg.event.user_event import UserEvent
from nextrpg.game.game_state import GameState
from nextrpg.scene.scene import Scene

if TYPE_CHECKING:
    from nextrpg.widget.widget import Widget
    from nextrpg.widget.widget_spec import WidgetSpec


class BaseWidgetInteractionResultVariant(UserEvent):
    # Subclass shall have this member.
    target: Widget | None = None

    def with_target_if_not_set(self, widget: Widget) -> Self:
        if self.target:
            return self
        return replace(self, target=widget)


@dataclass(frozen=True)
class AddChildWidget(BaseWidgetInteractionResultVariant):
    widget_spec: WidgetSpec
    target: Widget | None = None


@dataclass(frozen=True)
class ReplaceByWidget(BaseWidgetInteractionResultVariant):
    widget_spec: WidgetSpec
    target: Widget | None = None


@dataclass(frozen=True)
class ExitWidget(BaseWidgetInteractionResultVariant):
    target: Widget | None = None
    exit_to: Scene | None = None


type WidgetInteractionResultVariant = Scene | BaseWidgetInteractionResultVariant | None
type WidgetInteractionResult = WidgetInteractionResultVariant | tuple[
    WidgetInteractionResultVariant, GameState
]
