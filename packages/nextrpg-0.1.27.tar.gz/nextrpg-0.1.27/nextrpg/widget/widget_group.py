from collections.abc import Collection, Iterable
from dataclasses import KW_ONLY, replace
from functools import cached_property
from itertools import cycle, pairwise
from typing import TYPE_CHECKING, Self, override

from nextrpg.config.config import config
from nextrpg.config.system.key_mapping_config import KeyMappingConfig
from nextrpg.core.dataclass_with_default import (
    dataclass_with_default,
    default,
    private_init_below,
)
from nextrpg.core.time import Millisecond
from nextrpg.drawing.drawing_on_screens import (
    DrawingOnScreens,
    drawing_on_screens,
)
from nextrpg.drawing.sprite import tick_optional
from nextrpg.drawing.sprite_on_screen import (
    SpriteOnScreen,
)
from nextrpg.event.base_event import BaseEvent
from nextrpg.event.io_event import KeyPressDown
from nextrpg.game.game_state import GameState
from nextrpg.geometry.polyline_on_screen import PolylineOnScreen
from nextrpg.scene.scene import Scene
from nextrpg.widget.scroll_direction import ScrollDirection
from nextrpg.widget.widget import Widget
from nextrpg.widget.widget_interaction_result import (
    ReplaceByWidget,
)

if TYPE_CHECKING:
    from nextrpg.widget.widget_group_spec import WidgetGroupSpec
    from nextrpg.widget.widget_spec import WidgetSpec


@dataclass_with_default(frozen=True, kw_only=True)
class WidgetGroup(Widget):
    spec: WidgetGroupSpec
    background: SpriteOnScreen | None = None
    _: KW_ONLY = private_init_below()
    _children: tuple[Widget, ...] = default(
        lambda self: self._init_children(self.spec.children)
    )

    @override
    def on_interact(self, event: BaseEvent) -> Scene:
        match event:
            case ReplaceByWidget():
                children = [
                    (
                        c.on_interact(event)
                        if c.match_metadata(event.target)
                        else c
                    )
                    for c in self._children
                ]
                res = self._with_children(children)
            case _:
                res = self
        return Widget.on_interact(res, event)

    @cached_property
    def children_drawing_on_screens(self) -> DrawingOnScreens:
        return self._children_drawing_on_screens + self._widget_group_border

    @cached_property
    def _widget_group_border(self) -> DrawingOnScreens:
        if not (debug := config().debug) or not (
            color := debug.widget_group_border
        ):
            return DrawingOnScreens()
        return (
            PolylineOnScreen(
                self._children_drawing_on_screens.rectangle_area_on_screen.points
            )
            .fill(color, closed=True, allow_background_in_debug=False)
            .drawing_on_screens
        )

    @cached_property
    def _children_drawing_on_screens(self) -> DrawingOnScreens:
        return drawing_on_screens(
            child._drawing_on_screens_without_parent for child in self._children
        )

    @override
    @cached_property
    def _metadata_drawing_on_screens(self) -> DrawingOnScreens:
        child_metadata_drawing_on_screens = drawing_on_screens(
            child._metadata_drawing_on_screens for child in self._children
        )
        return (
            super()._metadata_drawing_on_screens
            + child_metadata_drawing_on_screens
        )

    def _init_children(
        self, children: WidgetSpec | Collection[WidgetSpec]
    ) -> tuple[Widget, ...]:
        from nextrpg.widget.widget_spec import WidgetSpec

        if not children:
            return ()
        if isinstance(children, WidgetSpec):
            with_parent = (children.with_parent(self),)
        else:
            with_parent = tuple(child.with_parent(self) for child in children)
        if any(child.is_selected for child in with_parent):
            return with_parent
        return (with_parent[0].select,) + with_parent[1:]

    @override
    def _event_after_selected(
        self, event: BaseEvent, state: GameState
    ) -> tuple[Scene, GameState]:
        children: list[Widget] = []
        for child in self._children:
            if child.is_selected and (
                res := child._event_after_selected(event, state)
            ) != (child, state):
                return res
            children.append(child)

        if isinstance(event, KeyPressDown):
            key = (self.spec.scroll_direction, event.key_mapping)
            if (
                is_forward := _SCROLL_AND_KEY_TO_IS_FORWARD.get(key)
            ) is not None:
                stepped = self._step(is_forward)
                return stepped, state
        with_children = self._with_children(children)
        return with_children, state

    @cached_property
    def _selected(self) -> Widget | None:
        for child in self._children:
            if child.is_selected:
                return child
        return None

    @override
    @cached_property
    def _drawing_on_screens_without_parent_and_animation(
        self,
    ) -> DrawingOnScreens:
        if self.background:
            background = self.background.drawing_on_screens
        else:
            background = DrawingOnScreens()
        return background + self.children_drawing_on_screens

    @override
    def _tick_without_parent_and_animation(
        self, time_delta: Millisecond, state: GameState
    ) -> tuple[Self, GameState]:
        children: list[Widget] = []
        for child in self._children:
            if res := child._tick_without_parent(time_delta, state):
                child, state = res
                children.append(child)
        ticked = self._with_children(children)
        background = tick_optional(self.background, time_delta)
        ticked_with_background = replace(ticked, background=background)
        return ticked_with_background, state

    def _step(self, is_forward: bool) -> Self:
        if len(self._children) < 2 or (
            not self.spec.loop
            and (
                (not is_forward and self._selected is self._children[0])
                or (is_forward and self._selected is self._children[-1])
            )
        ):
            return self

        for w1, w2 in pairwise(cycle(self._children)):
            if not is_forward and w2 is self._selected:
                target = w1
                break
            if is_forward and w1 is self._selected:
                target = w2
                break

        children: list[Widget] = []
        for i, child in enumerate(self._children):
            if child is self._selected:
                child = self._selected.deselect
            elif child is target:
                child = target.select
            children.append(child)
        return self._with_children(children)

    def _with_children(self, children: Iterable[Widget]) -> Self:
        children_with_parent = tuple(
            child.with_parent(self) for child in children
        )
        return replace(self, _children=children_with_parent)


_SCROLL_AND_KEY_TO_IS_FORWARD = {
    (ScrollDirection.HORIZONTAL, KeyMappingConfig.left): False,
    (ScrollDirection.HORIZONTAL, KeyMappingConfig.right): True,
    (ScrollDirection.VERTICAL, KeyMappingConfig.up): False,
    (ScrollDirection.VERTICAL, KeyMappingConfig.down): True,
}
