class BaseEvent:
    pass
