import logging
from collections.abc import Callable, Iterable

import pygame
from pygame import Event

from nextrpg.core.logger import Logger
from nextrpg.core.time import Millisecond
from nextrpg.core.util import type_name
from nextrpg.event.base_event import BaseEvent
from nextrpg.game.game_state import GameState

console_logger = logging.getLogger("user_event")
screen_logger = Logger("user_event")


class UserEvent(BaseEvent):
    pass


NEXTRPG_USER_EVENT_ID = pygame.event.custom_type()


def post_user_event(
    *event: UserEvent | Iterable[UserEvent],
    delay: Millisecond | Callable[[GameState], bool] = 0,
) -> None:
    if isinstance(event, UserEvent):
        _post_user_event(event, delay)
    for ev in event:
        if isinstance(ev, UserEvent):
            _post_user_event(ev, delay)
            continue
        for e in ev:
            _post_user_event(e, delay)


def _post_user_event(
    event: UserEvent, delay: Millisecond | Callable[[GameState], bool]
) -> None:
    screen_logger.debug(f"Posting {type_name(event)} {delay=}")
    console_logger.debug(f"Posting {event=} and {delay=}")

    pygame_event = Event(NEXTRPG_USER_EVENT_ID, user_event=event, delay=delay)
    pygame.event.post(pygame_event)
