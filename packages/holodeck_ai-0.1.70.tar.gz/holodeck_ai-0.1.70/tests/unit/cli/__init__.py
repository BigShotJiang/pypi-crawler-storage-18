"""HoloDeck CLI unit tests."""
