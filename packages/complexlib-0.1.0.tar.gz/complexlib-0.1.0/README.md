# complexlib

Небольшая библиотека на Python для работы с комплексными числами: собственный класс `Complex`, базовые операции и разбор строковых литералов вида `3+4i`.

## Возможности

- Класс `Complex(re, im)` с операциями `+ - * /`
- Дополнительные функции:
  - `conj(z)` — сопряжённое
  - `modulus(z)` — модуль
  - `almost_equal(a, b)` — сравнение с допуском
  - `parse("3-4i")` — парсер строк в формат `Complex`

## Требования

- Python 3.9+

Зависимостей нет (используется только стандартная библиотека).

## Установка (локально из исходников)

Из папки `complexlib/`:

```bash
python -m pip install -U pip
python -m pip install -e .
````

## Быстрый пример

```python
from complexlib import Complex, parse, modulus, conj

z1 = Complex(2, 3)
z2 = parse("4-5i")

print(z1 + z2)
print(z1 * z2)
print(conj(z2))
print(modulus(z1))
```

## Запуск тестов

В корне проекта:

```bash
python -m unittest -v
```

Или явно:

```bash
python -m unittest -v tests.test_core tests.test_ops
```

