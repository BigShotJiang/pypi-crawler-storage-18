import unittest
from complexlib.core.complex_number import Complex

class TestComplexCore(unittest.TestCase):
    def test_basic_init(self):
        z = Complex(3, 4)
        self.assertEqual(z.re, 3.0)
        self.assertEqual(z.im, 4.0)

    def test_str(self):
        self.assertEqual(str(Complex(0, 0)), "0")
        self.assertEqual(str(Complex(2, 0)), "2")
        self.assertEqual(str(Complex(0, 2)), "2i")
        self.assertEqual(str(Complex(0, -2)), "-2i")
        self.assertEqual(str(Complex(2, 1)), "2+i")
        self.assertEqual(str(Complex(2, -1)), "2-i")
        self.assertEqual(str(Complex(2, 3)), "2+3i")
        self.assertEqual(str(Complex(2, -3)), "2-3i")

    def test_add_sub(self):
        a = Complex(1, 2)
        b = Complex(3, -5)
        self.assertEqual(a + b, Complex(4, -3))
        self.assertEqual(a - b, Complex(-2, 7))

    def test_mul(self):
        a = Complex(1, 2)
        b = Complex(3, 4)
        self.assertEqual(a * b, Complex(-5, 10))

    def test_div(self):
        a = Complex(1, 2)
        b = Complex(3, 4)
        z = a / b
        self.assertAlmostEqual(z.re, 0.44, places=12)
        self.assertAlmostEqual(z.im, 0.08, places=12)

    def test_div_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            _ = Complex(1, 1) / Complex(0, 0)

    def test_coerce_numbers(self):
        z = Complex(1, 2)
        self.assertEqual(z + 3, Complex(4, 2))
        self.assertEqual(3 + z, Complex(4, 2))
        self.assertEqual(z * 2, Complex(2, 4))
        self.assertEqual(2 * z, Complex(2, 4))
        self.assertEqual(z - 1, Complex(0, 2))
        self.assertEqual(1 - z, Complex(0, -2))

if __name__ == "__main__":
    unittest.main()
