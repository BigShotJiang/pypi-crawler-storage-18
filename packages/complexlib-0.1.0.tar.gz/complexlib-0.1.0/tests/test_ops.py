import unittest
from complexlib import Complex, add, sub, mul, div, conj, modulus, almost_equal, parse

class TestOps(unittest.TestCase):
    def test_algebra_functions(self):
        a = Complex(2, 3)
        b = Complex(4, -1)
        self.assertEqual(add(a, b), Complex(6, 2))
        self.assertEqual(sub(a, b), Complex(-2, 4))
        self.assertEqual(mul(a, b), Complex(11, 10))
        self.assertTrue(almost_equal(div(a, b), a / b))

    def test_conj_modulus(self):
        z = Complex(3, 4)
        self.assertEqual(conj(z), Complex(3, -4))
        self.assertAlmostEqual(modulus(z), 5.0, places=12)

    def test_parse_real(self):
        self.assertEqual(parse("3"), Complex(3, 0))
        self.assertEqual(parse("-2.5"), Complex(-2.5, 0))

    def test_parse_imag(self):
        self.assertEqual(parse("i"), Complex(0, 1))
        self.assertEqual(parse("-i"), Complex(0, -1))
        self.assertEqual(parse("2i"), Complex(0, 2))
        self.assertEqual(parse("-2i"), Complex(0, -2))

    def test_parse_full(self):
        self.assertEqual(parse("3+4i"), Complex(3, 4))
        self.assertEqual(parse("3-4i"), Complex(3, -4))
        self.assertEqual(parse("3+i"), Complex(3, 1))
        self.assertEqual(parse("3-i"), Complex(3, -1))
        self.assertEqual(parse("  3  +  4i  "), Complex(3, 4))

    def test_parse_invalid(self):
        for s in ["", "3++4i", "3i+4", "abc", "3+-i", "+i", "3 i", "3+ i5"]:
            with self.assertRaises(ValueError):
                parse(s)

if __name__ == "__main__":
    unittest.main()
