from __future__ import annotations
from math import hypot, isclose
from complexlib.core.complex_number import Complex

def add(a: Complex, b: Complex) -> Complex:
    return a + b

def sub(a: Complex, b: Complex) -> Complex:
    return a - b

def mul(a: Complex, b: Complex) -> Complex:
    return a * b

def div(a: Complex, b: Complex) -> Complex:
    return a / b

def conj(z: Complex) -> Complex:
    return Complex(z.re, -z.im)

def modulus(z: Complex) -> float:
    return hypot(z.re, z.im)

def almost_equal(a: Complex, b: Complex, *, rel_tol: float = 1e-9, abs_tol: float = 0.0) -> bool:
    return isclose(a.re, b.re, rel_tol=rel_tol, abs_tol=abs_tol) and isclose(a.im, b.im, rel_tol=rel_tol, abs_tol=abs_tol)
