import re
from complexlib.core.complex_number import Complex

_NUM = r"(?:\d+(?:\.\d+)?|\.\d+)"
_RE_ONLY = re.compile(rf"^-?(?:{_NUM})$")
_IM_ONLY = re.compile(rf"^(?P<sign>-)?(?P<coef>{_NUM})?i$")
_FULL = re.compile(rf"^(?P<re>-?(?:{_NUM}))\s*(?P<op>[+-])\s*(?P<im>{_NUM})?i$")


def parse(s: str) -> Complex:
    if not isinstance(s, str):
        raise TypeError("s must be str")

    t = s.strip()
    if t == "":
        raise ValueError(f"Invalid complex literal: {s!r}")

    m = _FULL.match(t)
    if m:
        re_part = float(m.group("re"))
        op = m.group("op")
        im_raw = m.group("im")
        im_part = 1.0 if im_raw is None else float(im_raw)
        if op == "-":
            im_part = -im_part
        return Complex(re_part, im_part)

    m = _IM_ONLY.match(t)
    if m:
        sign = m.group("sign")
        coef_raw = m.group("coef")
        im_part = 1.0 if coef_raw is None else float(coef_raw)
        if sign == "-":
            im_part = -im_part
        return Complex(0.0, im_part)

    if _RE_ONLY.match(t):
        return Complex(float(t), 0.0)

    raise ValueError(f"Invalid complex literal: {s!r}")
