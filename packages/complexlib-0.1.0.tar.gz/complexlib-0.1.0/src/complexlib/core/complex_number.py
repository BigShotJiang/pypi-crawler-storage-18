from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

Number = int | float

@dataclass(frozen=True, slots=True)
class Complex:
    re: float = 0.0
    im: float = 0.0

    def __post_init__(self):
        object.__setattr__(self, "re", float(self.re))
        object.__setattr__(self, "im", float(self.im))
        if not (isfinite(self.re) and isfinite(self.im)):
            raise ValueError("Real and imaginary parts must be finite numbers")

    @staticmethod
    def from_polar(r: Number, phi: Number) -> "Complex":
        from math import cos, sin
        r = float(r)
        phi = float(phi)
        if not (isfinite(r) and isfinite(phi)):
            raise ValueError("Polar coordinates must be finite numbers")
        return Complex(r * cos(phi), r * sin(phi))

    def to_tuple(self) -> tuple[float, float]:
        return (self.re, self.im)

    def __complex__(self) -> complex:
        return complex(self.re, self.im)

    def __iter__(self):
        yield self.re
        yield self.im

    def __repr__(self) -> str:
        return f"Complex(re={self.re}, im={self.im})"

    def __str__(self) -> str:
        if self.im == 0:
            return f"{self.re:g}"
        sign = "+" if self.im >= 0 else "-"
        im_abs = abs(self.im)
        if self.re == 0:
            if self.im == 1:
                return "i"
            if self.im == -1:
                return "-i"
            return f"{self.im:g}i"
        if im_abs == 1:
            return f"{self.re:g}{sign}i"
        return f"{self.re:g}{sign}{im_abs:g}i"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Complex):
            return self.re == other.re and self.im == other.im
        if isinstance(other, (int, float)):
            return self.re == float(other) and self.im == 0.0
        return NotImplemented

    def __neg__(self) -> "Complex":
        return Complex(-self.re, -self.im)

    def __add__(self, other: object) -> "Complex":
        o = _coerce(other)
        return Complex(self.re + o.re, self.im + o.im)

    def __radd__(self, other: object) -> "Complex":
        return self.__add__(other)

    def __sub__(self, other: object) -> "Complex":
        o = _coerce(other)
        return Complex(self.re - o.re, self.im - o.im)

    def __rsub__(self, other: object) -> "Complex":
        o = _coerce(other)
        return Complex(o.re - self.re, o.im - self.im)

    def __mul__(self, other: object) -> "Complex":
        o = _coerce(other)
        a, b, c, d = self.re, self.im, o.re, o.im
        return Complex(a * c - b * d, a * d + b * c)

    def __rmul__(self, other: object) -> "Complex":
        return self.__mul__(other)

    def __truediv__(self, other: object) -> "Complex":
        o = _coerce(other)
        a, b, c, d = self.re, self.im, o.re, o.im
        denom = c * c + d * d
        if denom == 0.0:
            raise ZeroDivisionError("division by zero")
        return Complex((a * c + b * d) / denom, (b * c - a * d) / denom)

    def __rtruediv__(self, other: object) -> "Complex":
        o = _coerce(other)
        return o.__truediv__(self)

def _coerce(value: object) -> Complex:
    if isinstance(value, Complex):
        return value
    if isinstance(value, (int, float)):
        return Complex(float(value), 0.0)
    if isinstance(value, complex):
        return Complex(value.real, value.imag)
    raise TypeError(f"Unsupported type: {type(value).__name__}")
