"""Tests for scad-format."""
