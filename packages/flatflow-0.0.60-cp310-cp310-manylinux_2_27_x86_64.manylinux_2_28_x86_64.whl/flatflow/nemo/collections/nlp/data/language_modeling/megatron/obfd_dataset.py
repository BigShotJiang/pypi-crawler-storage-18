# Adapted from https://github.com/NVIDIA/NeMo/blob/v2.0.0/nemo/collections/nlp/data/language_modeling/megatron/gpt_dataset.py
# Copyright (c) 2025, The FlatFlow Authors.
# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import torch
from nemo.collections.nlp.data.language_modeling.megatron.base_dataset_utils import (
    get_datasets_weights_and_num_samples,
    get_train_valid_test_split_,
)
from nemo.collections.nlp.data.language_modeling.megatron.gpt_dataset import (
    GPTDataset,
    _create_ltor_masks_and_position_ids,
    get_indexed_dataset_,
)
from nemo.collections.nlp.data.language_modeling.megatron.indexed_dataset import deallocate_indexed_dataset_memory
from nemo.utils import logging
from omegaconf.dictconfig import DictConfig

from flatflow.nemo.collections.nlp.data.language_modeling.megatron.blendable_dataset import BlendableDataset

__all__ = ["build_obfd_datasets"]


class OBFDDataset(GPTDataset):
    """Dataset for `Fewer Truncations Improve Language Modeling`.

    You should add the following options to the `data` section in the config file:
      - use_obfd (bool)
      - obfd_token_data_prefix (list)
      - obfd_label_data_prefix (list)
    """

    def __init__(
        self,
        cfg,
        trainer,
        tokenizer,
        name,
        token_data_prefix,
        label_data_prefix,
        documents,
        indexed_token_dataset,
        indexed_label_dataset,
        num_samples,
        seq_length,
        seed,
        drop_last=True,
    ):
        super().__init__(
            cfg,
            trainer,
            tokenizer,
            name,
            token_data_prefix,
            documents,
            indexed_token_dataset,
            num_samples,
            seq_length,
            seed,
            drop_last,
        )
        self.indexed_label_dataset = indexed_label_dataset
        assert np.max(documents) < indexed_label_dataset.sizes.shape[0]
        deallocate_indexed_dataset_memory(self.indexed_label_dataset)

    def create_data_mmap(self):
        super().create_data_mmap()
        self.indexed_label_dataset.create_data_mmap()

    def __getitem__(self, idx):
        tokens = torch.from_numpy(self.indexed_dataset.get(idx).astype(np.int64))
        labels = torch.from_numpy(self.indexed_label_dataset.get(idx).astype(np.int64))

        attention_mask, loss_mask, position_ids = _create_ltor_masks_and_position_ids(
            tokens,
            self.eos_id,
            self.reset_position_ids,
            self.reset_attention_mask,
            self.eod_mask_loss,
        )
        loss_mask[labels == -1] = 0.0
        tokens[tokens == -1] = 0
        labels[labels == -1] = 0

        if idx < 0:
            logging.debug("Got negative index. Masking loss from this sample")
            loss_mask = torch.zeros_like(loss_mask)

        if self.get_attention_mask_from_fusion:
            return {
                "tokens": tokens,
                "labels": labels,
                "loss_mask": loss_mask,
                "position_ids": position_ids,
            }
        else:
            return {
                "tokens": tokens,
                "labels": labels,
                "attention_mask": attention_mask,
                "loss_mask": loss_mask,
                "position_ids": position_ids,
            }

    def __len__(self):
        return len(self.indexed_dataset)


def _build_train_valid_test_datasets(
    cfg,
    trainer,
    token_data_prefix,
    label_data_prefix,
    data_impl,
    splits_string,
    train_valid_test_num_samples,
    seq_length,
    seed,
    skip_warmup,
    tokenizer,
):
    delay_data_mmap = cfg.data.get("delay_data_mmap", False)
    indexed_token_dataset = get_indexed_dataset_(
        token_data_prefix, data_impl, skip_warmup, delay_data_mmap
    )
    indexed_label_dataset = get_indexed_dataset_(
        label_data_prefix, data_impl, skip_warmup, delay_data_mmap
    )

    total_num_of_documents = indexed_token_dataset.sizes.shape[0]  # type: ignore
    splits = get_train_valid_test_split_(splits_string, total_num_of_documents)

    def build_dataset(index, name):
        if splits[index] < splits[index + 1]:
            documents = np.arange(
                start=splits[index], stop=splits[index + 1], step=1, dtype=np.int32
            )
            drop_last = True
            if name == "valid":
                drop_last = cfg.data.get("validation_drop_last", True)
            return OBFDDataset(
                cfg,
                trainer,
                tokenizer,
                name,
                token_data_prefix,
                label_data_prefix,
                documents,
                indexed_token_dataset,
                indexed_label_dataset,
                train_valid_test_num_samples[index],
                seq_length,
                seed,
                drop_last=drop_last,
            )
        return None

    train_dataset = build_dataset(0, "train")
    valid_dataset = build_dataset(1, "valid")
    test_dataset = build_dataset(2, "test")
    return (train_dataset, valid_dataset, test_dataset)


def build_train_valid_test_datasets(
    cfg,
    trainer,
    token_data_prefix,
    label_data_prefix,
    data_impl,
    splits_string,
    train_valid_test_num_samples,
    seq_length,
    seed,
    skip_warmup,
    tokenizer,
):
    assert data_impl != "mock"
    assert not isinstance(token_data_prefix, DictConfig)
    assert not isinstance(label_data_prefix, DictConfig)
    assert len(token_data_prefix) == len(label_data_prefix)

    # Single dataset.
    if len(token_data_prefix) == 1:
        return _build_train_valid_test_datasets(
            cfg,
            trainer,
            token_data_prefix[0],
            label_data_prefix[0],
            data_impl,
            splits_string,
            train_valid_test_num_samples,
            seq_length,
            seed,
            skip_warmup,
            tokenizer,
        )

    # Blending dataset.
    token_output = get_datasets_weights_and_num_samples(
        token_data_prefix, train_valid_test_num_samples
    )
    token_prefixes, _, datasets_train_valid_test_num_samples = token_output

    label_output = get_datasets_weights_and_num_samples(
        label_data_prefix, train_valid_test_num_samples
    )
    label_prefixes, _, _ = label_output

    # Build individual datasets.
    train_datasets = []
    valid_datasets = []
    test_datasets = []
    for i in range(len(token_prefixes)):
        train_ds, valid_ds, test_ds = _build_train_valid_test_datasets(
            cfg,
            trainer,
            token_prefixes[i],
            label_prefixes[i],
            data_impl,
            splits_string,
            datasets_train_valid_test_num_samples[i],
            seq_length,
            seed,
            skip_warmup,
            tokenizer,
        )
        if train_ds:
            train_datasets.append(train_ds)
        if valid_ds:
            valid_datasets.append(valid_ds)
        if test_ds:
            test_datasets.append(test_ds)

    blending_train_dataset = None
    blending_valid_dataset = None
    blending_test_dataset = None
    if train_datasets:
        blending_train_dataset = BlendableDataset(train_datasets)
    if valid_datasets:
        blending_valid_dataset = BlendableDataset(valid_datasets)
    if test_datasets:
        blending_test_dataset = BlendableDataset(test_datasets)
    return (blending_train_dataset, blending_valid_dataset, blending_test_dataset)


def build_obfd_datasets(
    cfg,
    trainer,
    token_data_prefix,
    label_data_prefix,
    data_impl,
    splits_string,
    train_valid_test_num_samples,
    seq_length,
    seed,
    skip_warmup,
    tokenizer,
):
    return build_train_valid_test_datasets(
        cfg,
        trainer,
        token_data_prefix,
        label_data_prefix,
        data_impl,
        splits_string,
        train_valid_test_num_samples,
        seq_length,
        seed,
        skip_warmup,
        tokenizer,
    )
