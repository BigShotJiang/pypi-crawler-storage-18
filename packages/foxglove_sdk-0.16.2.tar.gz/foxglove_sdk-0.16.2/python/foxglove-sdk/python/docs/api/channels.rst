.. automodule:: foxglove.channels
   :members:
