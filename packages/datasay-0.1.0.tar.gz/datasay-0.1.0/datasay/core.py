def explain(data, drop_threshold=0.25):
    if len(data) < 2:
        return "Not enough data to analyze."

    start = data[0]
    end = data[-1]
    peak = max(data)
    trough = min(data)

    events = []

    # Start → End
    if end > start:
        events.append("ended higher than it started")
    elif end < start:
        events.append("ended lower than it started")
    else:
        events.append("ended at the same value it started")

    # Peak
    if peak != start and peak != end:
        events.insert(0, f"rose to a peak of {peak}")

    # Sharp drops
    sharp_drops = []
    for i in range(1, len(data)):
        change = (data[i] - data[i - 1]) / max(abs(data[i - 1]), 1)
        if change <= -drop_threshold:
            sharp_drops.append(data[i])

    if sharp_drops:
        events.append(f"dropped sharply to {min(sharp_drops)}")

    # Plateaus
    plateau_value = None
    count = 1
    for i in range(1, len(data)):
        if data[i] == data[i - 1]:
            count += 1
            plateau_value = data[i]
        else:
            count = 1

    if plateau_value and count >= 3:
        events.append(f"stabilized at {plateau_value} for a while")

    # Final sentence
    sentence = "Data " + ", ".join(events[:-1])
    if len(events) > 1:
        sentence += ", and " + events[-1]
    else:
        sentence += events[0]

    return sentence.capitalize() + "."
