from typing_extensions import Protocol, AsyncIterable, Sequence
from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime

from trading_sdk.market.types import Side
from trading_sdk.util import ChunkedStream

@dataclass
class Trade:
  @dataclass
  class Fee:
    asset: str
    amount: Decimal

  id: str
  price: Decimal
  qty: Decimal
  time: datetime
  side: Side
  fee: Fee | None = None
  maker: bool | None = None

class MyTrades(Protocol):
  def my_trades(
    self, start: datetime, end: datetime,
  ) -> ChunkedStream[Trade]:
    """Fetch your trades."""
    return ChunkedStream(self._my_trades_impl(start=start, end=end))
  
  def _my_trades_impl(
    self, start: datetime, end: datetime,
  ) -> AsyncIterable[Sequence[Trade]]:
    ...