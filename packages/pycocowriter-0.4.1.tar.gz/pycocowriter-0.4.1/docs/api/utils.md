# utilities module

::: pycocowriter.utils
