"""Tests for linecover."""
