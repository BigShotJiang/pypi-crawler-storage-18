"""ChunkOps CLI entry point"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import List

from chunkops_cli.extractor import PDFExtractor, Chunk
from chunkops_cli.deduper import Deduplicator, DuplicateMatch


def find_pdfs(directory: str) -> List[str]:
    """Find all PDF files in a directory"""
    pdf_files = []
    path = Path(directory)
    
    if not path.exists():
        print(f"Error: Directory '{directory}' does not exist", file=sys.stderr)
        sys.exit(1)
    
    if not path.is_dir():
        print(f"Error: '{directory}' is not a directory", file=sys.stderr)
        sys.exit(1)
    
    for file_path in path.rglob("*.pdf"):
        pdf_files.append(str(file_path))
    
    if not pdf_files:
        print(f"Warning: No PDF files found in '{directory}'", file=sys.stderr)
    
    return sorted(pdf_files)


def generate_report(
    duplicates: List[DuplicateMatch],
    total_files: int,
    total_chunks: int
) -> dict:
    """Generate JSON report"""
    exact_count = sum(1 for d in duplicates if d.type == "EXACT_DUPLICATE")
    near_count = sum(1 for d in duplicates if d.type == "NEAR_DUPLICATE")
    
    # Count unique chunks (approximate)
    unique_chunks = total_chunks - exact_count
    
    return {
        "scan_date": datetime.utcnow().isoformat() + "Z",
        "total_files": total_files,
        "total_chunks": total_chunks,
        "duplicates": [
            {
                "type": d.type,
                "file_a": os.path.basename(d.file_a),
                "file_b": os.path.basename(d.file_b),
                "file_a_path": d.file_a,
                "file_b_path": d.file_b,
                "similarity": round(d.similarity, 4),
                "chunk_a_preview": d.chunk_a_preview,
                "chunk_b_preview": d.chunk_b_preview,
            }
            for d in duplicates
        ],
        "summary": {
            "exact_duplicates": exact_count,
            "near_duplicates": near_count,
            "unique_content": unique_chunks
        }
    }


def scan_command(args):
    """Execute the scan command"""
    directory = args.directory
    output_file = args.output
    exact_threshold = args.exact_threshold
    near_threshold = args.threshold
    verbose = args.verbose
    
    if verbose:
        print(f"Scanning directory: {directory}")
        print(f"Exact threshold: {exact_threshold}")
        print(f"Near duplicate threshold: {near_threshold}")
        print()
    
    # Find PDF files
    pdf_files = find_pdfs(directory)
    
    if not pdf_files:
        print("No PDF files found. Exiting.", file=sys.stderr)
        sys.exit(1)
    
    if verbose:
        print(f"Found {len(pdf_files)} PDF file(s)")
        print()
    
    # Extract chunks from all PDFs
    extractor = PDFExtractor()
    all_chunks = []
    
    if verbose:
        print("Extracting text from PDFs...")
    
    for pdf_file in pdf_files:
        try:
            if verbose:
                print(f"  Processing: {os.path.basename(pdf_file)}")
            chunks = extractor.process_file(pdf_file)
            all_chunks.extend(chunks)
        except Exception as e:
            print(f"Error processing {pdf_file}: {e}", file=sys.stderr)
            continue
    
    if not all_chunks:
        print("No content extracted from PDFs. Exiting.", file=sys.stderr)
        sys.exit(1)
    
    if verbose:
        print(f"\nExtracted {len(all_chunks)} chunks total")
        print("\nDetecting duplicates...")
    
    # Detect duplicates
    deduper = Deduplicator(
        exact_threshold=exact_threshold,
        near_threshold=near_threshold
    )
    
    duplicates = deduper.find_duplicates(all_chunks)
    
    if verbose:
        exact_count = sum(1 for d in duplicates if d.type == "EXACT_DUPLICATE")
        near_count = sum(1 for d in duplicates if d.type == "NEAR_DUPLICATE")
        print(f"Found {exact_count} exact duplicate(s) and {near_count} near duplicate(s)")
        print()
    
    # Generate report
    report = generate_report(duplicates, len(pdf_files), len(all_chunks))
    
    # Write output
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"Report saved to: {output_file}")
    print(f"Summary: {report['summary']['exact_duplicates']} exact, "
          f"{report['summary']['near_duplicates']} near duplicates")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="ChunkOps CLI - Detect duplicate content in PDF documents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  chunkops scan ./documents
  chunkops scan ./documents --output report.json
  chunkops scan ./documents --threshold 0.95 --exact-threshold 0.99
        """
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version="chunkops 0.1.0"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Scan command
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a folder of PDFs for duplicates"
    )
    scan_parser.add_argument(
        "directory",
        help="Directory containing PDF files to scan"
    )
    scan_parser.add_argument(
        "-o", "--output",
        default="duplicates_report.json",
        help="Output JSON file path (default: duplicates_report.json)"
    )
    scan_parser.add_argument(
        "--threshold",
        type=float,
        default=0.90,
        help="Similarity threshold for near-duplicates (0.0-1.0, default: 0.90)"
    )
    scan_parser.add_argument(
        "--exact-threshold",
        type=float,
        default=1.0,
        help="Similarity threshold for exact duplicates (default: 1.0)"
    )
    scan_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    if args.command == "scan":
        scan_command(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

