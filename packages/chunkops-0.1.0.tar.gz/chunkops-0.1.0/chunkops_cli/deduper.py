"""Duplicate detection for CLI (standalone, in-memory only)"""

import os
from typing import List, Tuple, Optional
from dataclasses import dataclass
import numpy as np


@dataclass
class DuplicateMatch:
    """Represents a duplicate match"""
    file_a: str
    file_b: str
    chunk_a_id: str
    chunk_b_id: str
    similarity: float
    chunk_a_preview: str
    chunk_b_preview: str
    type: str  # "EXACT_DUPLICATE" or "NEAR_DUPLICATE"


class Deduplicator:
    """In-memory duplicate detector using sentence transformers"""
    
    def __init__(self, exact_threshold: float = 1.0, near_threshold: float = 0.90):
        self.exact_threshold = exact_threshold
        self.near_threshold = near_threshold
        self._embedder = None
        self._embeddings_cache = {}  # Cache embeddings by text hash
    
    def _get_embedder(self):
        """Lazy load the embedding model"""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
                model_name = os.getenv("CHUNKOPS_MODEL", "all-MiniLM-L6-v2")
                self._embedder = SentenceTransformer(model_name)
            except Exception as e:
                raise RuntimeError(f"Failed to load embedding model: {e}")
        return self._embedder
    
    def get_embedding(self, text: str) -> List[float]:
        """Get embedding vector for text"""
        # Use text hash as cache key
        text_hash = hash(text)
        if text_hash in self._embeddings_cache:
            return self._embeddings_cache[text_hash]
        
        embedder = self._get_embedder()
        embedding = embedder.encode(text, normalize_embeddings=True)
        embedding_list = embedding.tolist()
        
        self._embeddings_cache[text_hash] = embedding_list
        return embedding_list
    
    def compute_similarity(self, text_a: str, text_b: str) -> float:
        """Compute cosine similarity between two texts"""
        emb_a = np.array(self.get_embedding(text_a))
        emb_b = np.array(self.get_embedding(text_b))
        
        # Cosine similarity = dot product of normalized vectors
        similarity = float(np.dot(emb_a, emb_b))
        return similarity
    
    def find_duplicates(self, chunks: List) -> List[DuplicateMatch]:
        """
        Find duplicates among chunks.
        Optimized: Only compares chunks from different files.
        
        Args:
            chunks: List of Chunk objects with text, chunk_id, source_filename
        
        Returns:
            List of DuplicateMatch objects
        """
        duplicates = []
        n = len(chunks)
        
        # Group chunks by file for optimization
        chunks_by_file = {}
        for chunk in chunks:
            if chunk.source_filename not in chunks_by_file:
                chunks_by_file[chunk.source_filename] = []
            chunks_by_file[chunk.source_filename].append(chunk)
        
        files = list(chunks_by_file.keys())
        
        # Compare chunks across different files only
        for i, file_a in enumerate(files):
            for file_b in files[i + 1:]:
                for chunk_a in chunks_by_file[file_a]:
                    for chunk_b in chunks_by_file[file_b]:
                        similarity = self.compute_similarity(chunk_a.text, chunk_b.text)
                        
                        if similarity >= self.exact_threshold:
                            duplicates.append(DuplicateMatch(
                                file_a=chunk_a.source_filename,
                                file_b=chunk_b.source_filename,
                                chunk_a_id=chunk_a.chunk_id,
                                chunk_b_id=chunk_b.chunk_id,
                                similarity=similarity,
                                chunk_a_preview=chunk_a.text[:200] + "..." if len(chunk_a.text) > 200 else chunk_a.text,
                                chunk_b_preview=chunk_b.text[:200] + "..." if len(chunk_b.text) > 200 else chunk_b.text,
                                type="EXACT_DUPLICATE"
                            ))
                        elif similarity >= self.near_threshold:
                            duplicates.append(DuplicateMatch(
                                file_a=chunk_a.source_filename,
                                file_b=chunk_b.source_filename,
                                chunk_a_id=chunk_a.chunk_id,
                                chunk_b_id=chunk_b.chunk_id,
                                similarity=similarity,
                                chunk_a_preview=chunk_a.text[:200] + "..." if len(chunk_a.text) > 200 else chunk_a.text,
                                chunk_b_preview=chunk_b.text[:200] + "..." if len(chunk_b.text) > 200 else chunk_b.text,
                                type="NEAR_DUPLICATE"
                            ))
        
        return duplicates

