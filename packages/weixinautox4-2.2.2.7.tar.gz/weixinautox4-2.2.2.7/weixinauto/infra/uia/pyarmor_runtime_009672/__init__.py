# Pyarmor 9.2.0 (basic), 009672, 2025-12-25T16:29:21.522208
from .pyarmor_runtime import __pyarmor__
