"""Project-wide configuration constants for peepfilt."""

from typing import Set

# Detection/model constants
MODEL_NAME: str = "yolov8n.pt"
PERSON_CLASS_ID: int = 0
IMAGE_SIZE: int = 640

# Defaults
DEFAULT_CONF: float = 0.25
DEFAULT_BATCH_SIZE: int = 16

# API server
PORT: int = 8090

# Accepted image extensions (lowercase)
IMAGE_EXTENSIONS: Set[str] = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# Logging
LOG_LEVEL_ENV: str = "PEEPFILT_LOG_LEVEL"
