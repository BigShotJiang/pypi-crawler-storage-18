"""peepfilt: Filter images by detecting human presence using YOLOv8."""

__all__ = [
    "config",
    "detector",
    "batch",
    "cli",
    "api",
    "utils",
]

__version__ = "0.1.0"
