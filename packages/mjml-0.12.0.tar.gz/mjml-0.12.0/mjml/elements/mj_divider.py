
from ..helpers import parse_int, widthParser
from ..lib import merge_dicts
from ._base import BodyComponent


__all__ = ['MjDivider']

class MjDivider(BodyComponent):
    component_name = 'mj-divider'

    @classmethod
    def allowed_attrs(cls):
        return {
            'border-color'    : 'color',
            'border-style'    : 'string',
            'border-width'    : 'unit(px)',
            'container-background-color': 'color',
            'padding'         : 'unit(px,%){1,4}',
            'padding-bottom'  : 'unit(px,%)',
            'padding-left'    : 'unit(px,%)',
            'padding-right'   : 'unit(px,%)',
            'padding-top'     : 'unit(px,%)',
            'width'           : 'unit(px,%)',
            'align'           : 'enum(left,center,right)',
            # hidden / used by MjColumn
            'vertical-align'  : '',
            'css-class'       : '',
        }

    @classmethod
    def default_attrs(cls):
        return {
            'border-color'    : '#000000',
            'border-style'    : 'solid',
            'border-width'    : '4px',
            'padding'         : '10px 25px',
            'width'           : '100%',
            'align'           : 'center',
        }

    def get_styles(self):
        _t = tuple
        border_attrs = _t(map(lambda k: self.get_attr(f'border-{k}'), ['style', 'width', 'color']))
        border_attr_str = ' '.join(border_attrs)
        p = {
            'border-top': border_attr_str,
            'font-size' : '1px',
            'margin'    : '0px auto',
            'width'     : self.getAttribute('width'),
        }
        return {
            'p': p,
            'outlook': merge_dicts(p, {'width': self.getOutlookWidth()}),
        }

    def getOutlookWidth(self):
        this = self
        containerWidth = this.context['containerWidth']
        get_padding = lambda d: self.getShorthandAttrValue('padding', d)
        paddingSize = get_padding('right') + get_padding('left')
        width = this.getAttribute('width')
        parsedWidth, unit = widthParser(width)

        if unit == '%':
            px = (parse_int(containerWidth) * parsedWidth) / 100 - paddingSize
            # we want to render the number as string without decimal digits if possible
            if px == int(px):
                px = int(px)
            return f'{px}px'
        elif unit == 'px':
            return width
        px = parse_int(containerWidth) - paddingSize
        return f'{px}px'

    def renderAfter(self):
        table_attrs = self.html_attrs(
            align       = 'center',
            border      = '0',
            cellpadding = '0',
            cellspacing = '0',
            style       = 'outlook',
            role        = 'presentation',
            width        = self.getOutlookWidth(),
        )
        return f'''
            <!--[if mso | IE]>
            <table {table_attrs} >
                <tr>
                  <td style="height:0;line-height:0;">
                    &nbsp;
                  </td>
                </tr>
              </table>
            <![endif]-->'''

    def render(self):
        return f'''
            <p {self.html_attrs(style='p')} > </p>
            {self.renderAfter()}
        '''
