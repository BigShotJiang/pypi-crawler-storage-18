from setuptools import setup

setup(
    name="encryption_cli",
    version="0.1",
    packages=["encryption_cli"],
    entry_points={
        "console_scripts": [
            "encryption_cli=encryption_cli.main:main"
        ]
    },
    install_requires=[
        "cryptography==46.0.3",
        "InquirerPy==0.3.4",
        "rich==14.2.0"
        ],
    python_requires=">=3.8"
)
