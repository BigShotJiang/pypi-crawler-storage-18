#Imports
from InquirerPy import inquirer
from cryptography.fernet import Fernet
from pathlib import Path
from rich import print
from rich.console import Console
from rich.table import Table

#Credits table stuff
console = Console()
table = Table(title="Credits", style="bold white")
table.add_column("Credited", justify="center", style="bold yellow")
table.add_column("What For", justify="center", style="bold cyan")
table.add_row("Franek Kurzawa", "Programmer")
table.add_row("rich", "Displayment of fancy colored text")
table.add_row("pathlib", "Taking Care of The Paths")
table.add_row("Fernet", "Encrypting/Decrypting Files")
table.add_row("InquirerPy", "Easy Fancy Inputs")

#Encryption function
def encryption():
    #Ask for encryption fernet_key
    fernet_key = inquirer.secret(
        "Enter Your Fernet Key: "
    ).execute()
    fernet_key = str(fernet_key).encode()
    print()
    #Get all files in the directory
    files_path = Path(".")
    files = [file.name for file in files_path.iterdir() if file.is_file()]
    for file in files:
        file_path = files_path / str(file)

        with open(file_path, "rb") as unencrypted_file:
            unencrypted_data = unencrypted_file.read()
        
        encrypted_data = Fernet(fernet_key).encrypt(unencrypted_data)

        with open(file_path, "wb") as encrypted_file:
            encrypted_file.write(encrypted_data)
        
        print(f"[bold][#ff0000]Encrypted[/#ff0000]: {file}[/bold]")

#Decryption function
def decryption():
    #Ask for encryption fernet_key
    fernet_key = inquirer.secret(
        "Enter Your Fernet Key: "
    ).execute()
    fernet_key = str(fernet_key).encode()
    print()
    #Get all files in the directory
    files_path = Path(".")
    files = [file.name for file in files_path.iterdir() if file.is_file()]
    for file in files:
        file_path = files_path / str(file)

        with open(file_path, "rb") as encrypted_file:
            encrypted_data = encrypted_file.read()
        
        decrypted_data = Fernet(fernet_key).decrypt(encrypted_data)

        with open(file_path, "wb") as decrypted_file:
            decrypted_file.write(decrypted_data)
        
        print(f"[bold][#00ff00]Decrypted[/#00ff00]: {file}[/bold]")

#Credits :)
def credits():
    console.print(table)
    print("\n\n")

def generate_keys():
    key = Fernet.generate_key()
    key = key.decode()
    print(f"[grey]Your [white bold italic]Key[white bold italic] is:[/grey] [bold yellow]{key}[/]")

#Main Function
def main():

    #Action Selection
    try:
        option = inquirer.select(
            message="Chose Action: ",
            choices=[
                "Encrypt",
                "Decrypt",
                "Generate Key",
                "Credits"
            ]
        ).execute()
    except KeyboardInterrupt:
        print("\nSee [bold]you[/] later!\n")
        return
    
    if option == "Encrypt":
        encryption()
    elif option == "Decrypt":
        decryption()
    elif option == "Generate Key":
        generate_keys()
    elif option == "Credits":
        credits()
    else:
        print("Idk how but you broke the program. Congratulations!")

if __name__ == "__main__":
    main()
