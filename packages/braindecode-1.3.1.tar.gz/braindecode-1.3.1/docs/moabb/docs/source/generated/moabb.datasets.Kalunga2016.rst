﻿moabb.datasets.Kalunga2016
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Kalunga2016