﻿moabb.datasets.BI2014a
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2014a