﻿moabb.datasets.AlexMI
=====================

.. currentmodule:: moabb.datasets

.. autoclass:: AlexMI