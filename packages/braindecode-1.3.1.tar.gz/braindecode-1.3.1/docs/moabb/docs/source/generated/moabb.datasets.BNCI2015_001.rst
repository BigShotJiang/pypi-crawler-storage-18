﻿moabb.datasets.BNCI2015\_001
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2015_001