﻿moabb.datasets.ErpCore2021\_ERN
===============================

.. currentmodule:: moabb.datasets

.. autoclass:: ErpCore2021_ERN