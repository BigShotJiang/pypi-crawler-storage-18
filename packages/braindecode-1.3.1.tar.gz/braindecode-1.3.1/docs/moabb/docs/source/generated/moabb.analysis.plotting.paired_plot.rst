﻿moabb.analysis.plotting.paired\_plot
====================================

.. currentmodule:: moabb.analysis.plotting

.. autofunction:: paired_plot