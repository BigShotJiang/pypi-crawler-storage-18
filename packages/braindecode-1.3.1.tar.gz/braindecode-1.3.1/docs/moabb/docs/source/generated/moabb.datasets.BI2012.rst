﻿moabb.datasets.BI2012
=====================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2012