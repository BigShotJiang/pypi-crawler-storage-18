﻿moabb.datasets.BNCI2015\_004
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2015_004