﻿moabb.analysis.plotting.dataset\_bubble\_plot
=============================================

.. currentmodule:: moabb.analysis.plotting

.. autofunction:: dataset_bubble_plot