﻿moabb.datasets.BNCI2014\_004
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2014_004