﻿moabb.datasets.MAMEM1
=====================

.. currentmodule:: moabb.datasets

.. autoclass:: MAMEM1