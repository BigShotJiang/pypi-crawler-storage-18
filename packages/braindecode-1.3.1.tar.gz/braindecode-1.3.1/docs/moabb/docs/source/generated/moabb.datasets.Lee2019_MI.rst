﻿moabb.datasets.Lee2019\_MI
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Lee2019_MI