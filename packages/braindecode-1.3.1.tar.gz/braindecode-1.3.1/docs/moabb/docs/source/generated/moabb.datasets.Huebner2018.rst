﻿moabb.datasets.Huebner2018
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Huebner2018