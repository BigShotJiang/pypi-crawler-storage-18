﻿moabb.datasets.Kojima2024B
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Kojima2024B