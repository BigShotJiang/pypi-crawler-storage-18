﻿moabb.datasets.CastillosCVEP40
==============================

.. currentmodule:: moabb.datasets

.. autoclass:: CastillosCVEP40