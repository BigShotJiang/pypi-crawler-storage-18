﻿moabb.datasets.BI2014b
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2014b