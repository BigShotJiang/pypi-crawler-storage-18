﻿moabb.datasets.CastillosBurstVEP40
==================================

.. currentmodule:: moabb.datasets

.. autoclass:: CastillosBurstVEP40