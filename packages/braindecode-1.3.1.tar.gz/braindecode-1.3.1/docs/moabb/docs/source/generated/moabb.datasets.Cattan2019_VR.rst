﻿moabb.datasets.Cattan2019\_VR
=============================

.. currentmodule:: moabb.datasets

.. autoclass:: Cattan2019_VR