﻿moabb.datasets.CastillosBurstVEP100
===================================

.. currentmodule:: moabb.datasets

.. autoclass:: CastillosBurstVEP100