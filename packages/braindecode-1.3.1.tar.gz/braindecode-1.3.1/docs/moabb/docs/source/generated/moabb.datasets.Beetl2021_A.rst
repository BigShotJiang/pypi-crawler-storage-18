﻿moabb.datasets.Beetl2021\_A
===========================

.. currentmodule:: moabb.datasets

.. autoclass:: Beetl2021_A