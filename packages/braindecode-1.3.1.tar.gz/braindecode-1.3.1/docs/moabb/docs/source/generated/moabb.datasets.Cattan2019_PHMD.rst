﻿moabb.datasets.Cattan2019\_PHMD
===============================

.. currentmodule:: moabb.datasets

.. autoclass:: Cattan2019_PHMD