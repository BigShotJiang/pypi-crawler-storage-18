﻿moabb.datasets.Hinss2021
========================

.. currentmodule:: moabb.datasets

.. autoclass:: Hinss2021