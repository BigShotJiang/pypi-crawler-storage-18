﻿moabb.datasets.BI2013a
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2013a