﻿moabb.datasets.Rodrigues2017
============================

.. currentmodule:: moabb.datasets

.. autoclass:: Rodrigues2017