﻿moabb.datasets.Beetl2021\_B
===========================

.. currentmodule:: moabb.datasets

.. autoclass:: Beetl2021_B