﻿moabb.datasets.BNCI2014\_008
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2014_008