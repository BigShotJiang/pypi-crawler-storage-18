﻿moabb.datasets.ErpCore2021\_MMN
===============================

.. currentmodule:: moabb.datasets

.. autoclass:: ErpCore2021_MMN