﻿moabb.analysis.meta\_analysis.collapse\_session\_scores
=======================================================

.. currentmodule:: moabb.analysis.meta_analysis

.. autofunction:: collapse_session_scores