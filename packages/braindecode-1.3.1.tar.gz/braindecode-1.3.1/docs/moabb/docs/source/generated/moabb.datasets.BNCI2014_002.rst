﻿moabb.datasets.BNCI2014\_002
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2014_002