﻿moabb.datasets.Ofner2017
========================

.. currentmodule:: moabb.datasets

.. autoclass:: Ofner2017