﻿moabb.datasets.Huebner2017
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Huebner2017