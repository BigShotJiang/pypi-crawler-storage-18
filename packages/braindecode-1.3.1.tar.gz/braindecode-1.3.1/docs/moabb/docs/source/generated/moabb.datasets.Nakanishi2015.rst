﻿moabb.datasets.Nakanishi2015
============================

.. currentmodule:: moabb.datasets

.. autoclass:: Nakanishi2015