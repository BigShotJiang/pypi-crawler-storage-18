﻿moabb.datasets.BNCI2014\_001
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2014_001