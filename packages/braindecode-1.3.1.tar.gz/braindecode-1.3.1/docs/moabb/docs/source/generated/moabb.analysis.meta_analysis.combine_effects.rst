﻿moabb.analysis.meta\_analysis.combine\_effects
==============================================

.. currentmodule:: moabb.analysis.meta_analysis

.. autofunction:: combine_effects