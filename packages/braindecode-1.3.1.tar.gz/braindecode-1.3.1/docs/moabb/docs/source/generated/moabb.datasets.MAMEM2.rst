﻿moabb.datasets.MAMEM2
=====================

.. currentmodule:: moabb.datasets

.. autoclass:: MAMEM2