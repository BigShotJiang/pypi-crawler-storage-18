﻿moabb.datasets.CastillosCVEP100
===============================

.. currentmodule:: moabb.datasets

.. autoclass:: CastillosCVEP100