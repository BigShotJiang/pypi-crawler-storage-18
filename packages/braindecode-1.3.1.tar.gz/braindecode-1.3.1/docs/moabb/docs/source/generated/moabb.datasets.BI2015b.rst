﻿moabb.datasets.BI2015b
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2015b