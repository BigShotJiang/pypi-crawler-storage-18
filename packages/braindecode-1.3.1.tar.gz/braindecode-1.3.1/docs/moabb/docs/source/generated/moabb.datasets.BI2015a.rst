﻿moabb.datasets.BI2015a
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2015a