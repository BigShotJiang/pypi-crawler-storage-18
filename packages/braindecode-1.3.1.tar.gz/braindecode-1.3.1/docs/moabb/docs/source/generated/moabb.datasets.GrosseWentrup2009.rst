﻿moabb.datasets.GrosseWentrup2009
================================

.. currentmodule:: moabb.datasets

.. autoclass:: GrosseWentrup2009