﻿moabb.datasets.BNCI2015\_003
============================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2015_003