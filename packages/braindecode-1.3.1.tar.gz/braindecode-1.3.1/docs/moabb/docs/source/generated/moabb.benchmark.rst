﻿moabb.benchmark
===============

.. currentmodule:: moabb

.. autofunction:: benchmark