🦀 Koruspy

Koruspy é uma biblioteca ultra-leve que traz a segurança do Rust e a elegância do Kotlin para o ecossistema Python.

Desenvolvida inteiramente via Termux, esta biblioteca elimina a necessidade de verificações manuais de None e blocos try/except repetitivos, utilizando o poder do Pattern Matching (Python 3.10+) e programação funcional.


---

🚀 Diferenciais

Zero NoneErrors: Use Option (Some ou nothing) para lidar com valores ausentes.

Result Pattern: Trate sucessos e falhas como dados, não como exceções que quebram o código.

Estilo Kotlin: Métodos encadeáveis como .map(), .Filter(), .and_then() e o operador de navegação segura .getattr().

Pipeline seguro: option_of agora trata corretamente None e nothing, preservando valores falsy como 0 e False.

Finalização clara: .finalize() encerra pipelines que já têm valor garantido.

Fallback elegante: .unwrap_or(default) e .unwrap_or_else(func) fornecem valores quando necessário.

Terminal Colorido: Substitua o print padrão pelo println com suporte a tipos e cores ANSI.



---

📦 Instalação

Como você está desenvolvendo no Termux ou em ambiente mobile, instale via modo editável:

pip install -e .


---

📝 Exemplos 2.3

```python
from koruspy import Some, nothing, option_of, println

# option_of trata None e nothing, preservando falsy

idade = option_of(0, 18)
println(idade)  # Some(0)

idade2 = option_of(None, 18)
println(idade2)  # Some(18)
```
---
# Pipeline com Filter e finalize
```python
idade_valida = (
    option_of(idade2.get_value(), 0)
    .Filter(lambda x: x >= 18)
    .on_nothing(lambda: println("valor inválido"))
    .finalize()
)
println(idade_valida)
```
---
# Fallbacks
```python
val = option_of(None).unwrap_or(42)
println(val)  # 42

val2 = option_of(None).unwrap_or_else(lambda: 99)
println(val2)  # 99
```