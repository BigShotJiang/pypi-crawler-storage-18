"""
AWS Lightsail Base Standalone Infrastructure Stack
==================================================

This module provides a standalone base class for AWS Lightsail infrastructure
stacks using CDKTF. It avoids AWSArchitectureBase and its compliance bootstrap
resources, while keeping IAM/Secrets/post-apply helpers used by Lightsail stacks.
"""

import os
import json
from enum import Enum
from cdktf import TerraformStack, TerraformOutput

from cdktf_cdktf_provider_aws.provider import AwsProvider
from cdktf_cdktf_provider_aws import (
    iam_group,
    iam_user,
    iam_access_key,
    iam_user_group_membership,
    iam_group_policy,
)

from cdktf_cdktf_provider_random import password
from cdktf_cdktf_provider_random.provider import RandomProvider

from cdktf_cdktf_provider_null.provider import NullProvider
from cdktf_cdktf_provider_null.resource import Resource as NullResource

from cdktf_cdktf_provider_aws.secretsmanager_secret import SecretsmanagerSecret
from cdktf_cdktf_provider_aws.secretsmanager_secret_version import SecretsmanagerSecretVersion
from cdktf_cdktf_provider_aws.data_aws_secretsmanager_secret_version import DataAwsSecretsmanagerSecretVersion


class BaseLightsailArchitectureFlags(Enum):
    """
    Base architecture configuration flags for optional components.

    :param SKIP_DEFAULT_POST_APPLY_SCRIPTS: Skip default post-apply scripts
    :param PRESERVE_EXISTING_SECRETS: Don't overwrite existing secret versions
    :param IGNORE_SECRET_CHANGES: Ignore all changes to secret after initial creation
    """

    SKIP_DEFAULT_POST_APPLY_SCRIPTS = "skip_default_post_apply_scripts"
    PRESERVE_EXISTING_SECRETS = "preserve_existing_secrets"
    IGNORE_SECRET_CHANGES = "ignore_secret_changes"


class LightsailBaseStandalone(TerraformStack):
    """
    Standalone base class for Lightsail stacks without AWSArchitectureBase.
    """

    resources = {}
    default_post_apply_scripts = []

    @staticmethod
    def get_architecture_flags():
        return BaseLightsailArchitectureFlags

    def __init__(self, scope, id, **kwargs):
        self.region = kwargs.get("region", "us-east-1")
        self.environment = kwargs.get("environment", "dev")
        self.project_name = kwargs.get("project_name")
        self.profile = kwargs.get("profile", "default")

        if not self.project_name:
            raise ValueError("project_name is required and cannot be empty")

        super().__init__(scope, id)

        self.flags = kwargs.get("flags", [])
        self.post_apply_scripts = kwargs.get("postApplyScripts", []) or []

        default_secret_name = f"{self.project_name}/{self.environment}/credentials"
        self.secret_name = kwargs.get("secret_name", default_secret_name)
        self.default_signature_version = kwargs.get("default_signature_version", "s3v4")
        self.default_extra_secret_env = kwargs.get("default_extra_secret_env", "SECRET_STRING")

        default_bucket_name = self.properize_s3_bucketname(f"{self.region}-{self.project_name}-tfstate")
        self.state_bucket_name = kwargs.get("state_bucket_name", default_bucket_name)

        self.secrets = {}
        self.post_terraform_messages = []
        self._post_plan_guidance: list[str] = []

        self._initialize_providers()
        self._set_default_post_apply_scripts()
        self._create_infrastructure_components()

    def _initialize_providers(self):
        aws = AwsProvider(self, "aws", region=self.region, profile=self.profile)
        self.resources["aws"] = aws

        RandomProvider(self, "random")
        self.resources["random"] = RandomProvider

        NullProvider(self, "null")
        self.resources["null"] = NullProvider

    def _set_default_post_apply_scripts(self):
        self.default_post_apply_scripts = [
            "echo '============================================='",
            "echo '✅ Deployment Completed Successfully'",
            "echo '============================================='",
            f"echo '🏗️  Project: {self.project_name}'",
            f"echo '🌍 Environment: {self.environment}'",
            f"echo '📍 Region: {self.region}'",
            "echo '============================================='",
            "echo '💻 System Information:'",
            "echo '   - OS: '$(uname -s)",
            "echo '   - Architecture: '$(uname -m)",
            "echo '   - User: '$(whoami)",
            "echo '   - Working Directory: '$(pwd)",
            "echo '============================================='",
            "echo '✅ Post-deployment scripts execution started'",
        ]

        if BaseLightsailArchitectureFlags.SKIP_DEFAULT_POST_APPLY_SCRIPTS.value in self.flags:
            return

        self.post_apply_scripts = self.default_post_apply_scripts + self.post_apply_scripts

    def _create_infrastructure_components(self):
        self.create_iam_resources()
        self.create_lightsail_resources()
        self.create_security_resources()
        self.execute_post_apply_scripts()
        self.create_outputs()

    def create_lightsail_resources(self):
        raise NotImplementedError("create_lightsail_resources must be implemented by subclasses")

    def create_outputs(self):
        raise NotImplementedError("create_outputs must be implemented by subclasses")

    def create_iam_resources(self):
        user_name = f"{self.project_name}-service-user"
        group_name = f"{self.project_name}-group"

        self.service_group = iam_group.IamGroup(self, "service_group", name=group_name)
        self.service_user = iam_user.IamUser(self, "service_user", name=user_name)

        iam_user_group_membership.IamUserGroupMembership(
            self,
            "service_user_group_membership",
            user=self.service_user.name,
            groups=[self.service_group.name],
        )

        self.service_key = iam_access_key.IamAccessKey(
            self, "service_key", user=self.service_user.name
        )

        try:
            self.service_policy = self.create_iam_policy_from_file()
            self.resources["iam_policy"] = self.service_policy
        except FileNotFoundError:
            pass

    def create_iam_policy_from_file(self, file_path="iam_policy.json"):
        file_to_open = os.path.join(os.path.dirname(__file__), file_path)

        with open(file_to_open, "r") as f:
            policy = f.read()

        return iam_group_policy.IamGroupPolicy(
            self,
            f"{self.project_name}-{self.environment}-service-policy",
            name=f"{self.project_name}-{self.environment}-service-policy",
            group=self.service_group.name,
            policy=policy,
        )

    def get_extra_secret_env(self, env_var_name=None):
        if env_var_name is None:
            env_var_name = self.default_extra_secret_env

        extra_secret_env = os.environ.get(env_var_name, None)

        if extra_secret_env:
            try:
                extra_secret_json = json.loads(extra_secret_env)
                for key, value in extra_secret_json.items():
                    if key not in self.secrets:
                        self.secrets[key] = value
            except json.JSONDecodeError:
                pass

    def create_security_resources(self):
        self.secrets_manager_secret = SecretsmanagerSecret(self, self.secret_name, name=f"{self.secret_name}")
        self.resources["secretsmanager_secret"] = self.secrets_manager_secret

        self.secrets.update({
            "service_user_access_key": self.service_key.id,
            "service_user_secret_key": self.service_key.secret,
            "access_key": self.service_key.id,
            "secret_access_key": self.service_key.secret,
            "region_name": self.region,
            "signature_version": self.default_signature_version
        })

        self.get_extra_secret_env()

        if BaseLightsailArchitectureFlags.PRESERVE_EXISTING_SECRETS.value in self.flags:
            self._create_secret_version_conditionally()
        elif BaseLightsailArchitectureFlags.IGNORE_SECRET_CHANGES.value in self.flags:
            self._create_secret_version_with_lifecycle_ignore()
        else:
            SecretsmanagerSecretVersion(
                self,
                self.secret_name + "_version",
                secret_id=self.secrets_manager_secret.id,
                secret_string=(json.dumps(self.secrets, indent=2, sort_keys=True) if self.secrets else None),
            )

    def _create_secret_version_conditionally(self):
        try:
            DataAwsSecretsmanagerSecretVersion(
                self,
                self.secret_name + "_existing_check",
                secret_id=self.secrets_manager_secret.id,
                version_stage="AWSCURRENT"
            )

            conditional_secret = SecretsmanagerSecretVersion(
                self,
                self.secret_name + "_version_conditional",
                secret_id=self.secrets_manager_secret.id,
                secret_string=json.dumps(self.secrets, indent=2, sort_keys=True) if self.secrets else None,
                lifecycle={
                    "ignore_changes": ["secret_string"],
                    "create_before_destroy": False
                }
            )

            conditional_secret.add_override(
                "count",
                "${length(try(jsondecode(data.aws_secretsmanager_secret_version." +
                self.secret_name.replace("/", "_").replace("-", "_") + "_existing_check.secret_string), {})) == 0 ? 1 : 0}"
            )

        except Exception:
            SecretsmanagerSecretVersion(
                self,
                self.secret_name + "_version_fallback",
                secret_id=self.secrets_manager_secret.id,
                secret_string=json.dumps(self.secrets, indent=2, sort_keys=True) if self.secrets else None,
            )

    def _create_secret_version_with_lifecycle_ignore(self):
        secret_version = SecretsmanagerSecretVersion(
            self,
            self.secret_name + "_version_ignored",
            secret_id=self.secrets_manager_secret.id,
            secret_string=json.dumps(self.secrets, indent=2, sort_keys=True) if self.secrets else None,
        )

        secret_version.add_override("lifecycle", {
            "ignore_changes": ["secret_string"]
        })

    def execute_post_apply_scripts(self):
        if not self.post_apply_scripts:
            return

        dependencies = []
        if hasattr(self, "secrets_manager_secret"):
            dependencies.append(self.secrets_manager_secret)

        for i, script in enumerate(self.post_apply_scripts):
            script_resource = NullResource(
                self,
                f"post_apply_script_{i}",
                depends_on=dependencies if dependencies else None
            )

            script_resource.add_override("provisioner", [{
                "local-exec": {
                    "command": script,
                    "on_failure": "continue"
                }
            }])

    def has_flag(self, flag_value):
        return flag_value in self.flags

    def clean_hyphens(self, text):
        return text.replace("-", "_")

    def properize_s3_bucketname(self, bucket_name):
        clean_name = bucket_name.lower().replace("_", "-")
        clean_name = clean_name.strip("-.")
        return clean_name

    def create_iam_outputs(self):
        TerraformOutput(
            self,
            "iam_user_access_key",
            value=self.service_key.id,
            sensitive=True,
            description="IAM user access key ID (sensitive)",
        )

        TerraformOutput(
            self,
            "iam_user_secret_key",
            value=self.service_key.secret,
            sensitive=True,
            description="IAM user secret access key (sensitive)",
        )

        TerraformOutput(
            self,
            "secrets_manager_secret_name",
            value=self.secret_name,
            description="AWS Secrets Manager secret name containing all credentials",
        )
