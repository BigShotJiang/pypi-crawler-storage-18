"""Configuration for the LLM Council."""

import os
import sys
import json
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


# =============================================================================
# ADR-013: Secure API Key Handling
# =============================================================================
# Key resolution priority (per Council recommendation):
# 1. Environment variable (explicit override, CI/CD standard)
# 2. System Keychain/Credential Manager (desktop security)
# 3. .env file (via dotenv - already loaded above)
# 4. Config file (least secure, warn user)

# Track which source the key came from (for diagnostics)
_key_source: Optional[str] = None

# Optional keyring import - may not be installed
keyring = None
try:
    import keyring as _keyring_module
    keyring = _keyring_module
except ImportError:
    pass  # keyring not installed - this is fine


def _is_fail_backend() -> bool:
    """Check if keyring has a fail backend (headless/Docker)."""
    if keyring is None:
        return True
    try:
        from keyring.backends import fail
        return isinstance(keyring.get_keyring(), fail.Keyring)
    except Exception:
        return True


def _get_api_key_from_keychain() -> Optional[str]:
    """Attempt to retrieve API key from system keychain (ADR-013)."""
    if keyring is None:
        return None

    try:
        # Check if we have a real backend (not the fail backend)
        if _is_fail_backend():
            return None

        key = keyring.get_password("llm-council", "openrouter_api_key")
        return key
    except Exception:
        # Keychain access failed (headless, permissions, etc.)
        return None

# OpenRouter API endpoint
OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"

# Default Council members - list of OpenRouter model identifiers
DEFAULT_COUNCIL_MODELS = [
    "openai/gpt-5.2-pro",
    "google/gemini-3-pro-preview",
    "anthropic/claude-opus-4.5",
    "x-ai/grok-4",
]

# =============================================================================
# ADR-022: Tier-Specific Model Pools
# =============================================================================
# Each confidence tier uses models optimized for its latency and capability
# requirements. Quick tier uses fast models, reasoning tier uses deep thinkers.
#
# Environment variable overrides:
#   LLM_COUNCIL_MODELS_QUICK=model1,model2,...
#   LLM_COUNCIL_MODELS_BALANCED=model1,model2,...
#   LLM_COUNCIL_MODELS_HIGH=model1,model2,...
#   LLM_COUNCIL_MODELS_REASONING=model1,model2,...

DEFAULT_TIER_MODEL_POOLS = {
    "quick": [
        "openai/gpt-4o-mini",
        "anthropic/claude-3-5-haiku-20241022",
        "google/gemini-2.0-flash-001",
    ],
    "balanced": [
        "openai/gpt-4o",
        "anthropic/claude-3-5-sonnet-20241022",
        "google/gemini-2.5-pro-preview",  # Fixed: was gemini-1.5-pro (404)
    ],
    "high": [
        "openai/gpt-4o",
        "anthropic/claude-opus-4.5",  # Fixed: was claude-opus-4-5-20250514 (400)
        "google/gemini-3-pro-preview",  # Fixed: was gemini-3-pro (400)
        "x-ai/grok-4",
    ],
    "reasoning": [
        "openai/gpt-5.2-pro",
        "anthropic/claude-opus-4.5",  # Fixed: was claude-opus-4-5-20250514 (400)
        "google/gemini-3-pro-preview",  # Fixed: was o1-preview (404)
        "x-ai/grok-4.1-fast",
    ],
    # Frontier tier: cutting-edge/preview models for testing latest capabilities
    "frontier": [
        "openai/gpt-5.2-pro",
        "anthropic/claude-opus-4.5",
        "google/gemini-3-pro-preview",
        "x-ai/grok-4",
        "deepseek/deepseek-r1",
    ],
}


def get_tier_models(tier: str) -> list:
    """
    Get model pool for a specific tier, with environment variable override.

    Args:
        tier: One of "quick", "balanced", "high", "reasoning"

    Returns:
        List of model identifiers for the tier

    Priority:
        1. Environment variable LLM_COUNCIL_MODELS_<TIER>
        2. Default tier pool
        3. Fall back to "high" tier for unknown tiers
    """
    tier_lower = tier.lower()
    tier_upper = tier.upper()
    env_key = f"LLM_COUNCIL_MODELS_{tier_upper}"

    # Check for per-tier env override
    env_models = os.getenv(env_key)
    if env_models:
        return [m.strip() for m in env_models.split(",")]

    # Fall back to defaults, with unknown tiers using "high"
    return DEFAULT_TIER_MODEL_POOLS.get(tier_lower, DEFAULT_TIER_MODEL_POOLS["high"])


# Computed tier model pools (evaluated at import time)
# These can be overridden per-tier via environment variables
TIER_MODEL_POOLS = {
    tier: get_tier_models(tier)
    for tier in ["quick", "balanced", "high", "reasoning", "frontier"]
}

# Default Chairman model - synthesizes final response
DEFAULT_CHAIRMAN_MODEL = "google/gemini-3-pro-preview"

# Default synthesis mode: "consensus" or "debate"
# - consensus: Chairman synthesizes a single best answer
# - debate: Chairman highlights key disagreements and trade-offs
DEFAULT_SYNTHESIS_MODE = "consensus"

# Whether to exclude self-votes from ranking aggregation
DEFAULT_EXCLUDE_SELF_VOTES = True

# Whether to normalize response styles before peer review (Stage 1.5)
# Options: False (never), True (always), "auto" (when variance detected)
DEFAULT_STYLE_NORMALIZATION = False

# Model to use for style normalization (fast/cheap model recommended)
DEFAULT_NORMALIZER_MODEL = "google/gemini-2.0-flash-001"

# Maximum number of reviewers per response for stratified sampling
# Set to None to have all models review all responses
# Recommended: 3 for councils with > 5 models
DEFAULT_MAX_REVIEWERS = None


def _load_user_config():
    """Load user configuration from config file if it exists."""
    config_dir = Path.home() / ".config" / "llm-council"
    config_file = config_dir / "config.json"
    
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception:
            # If config file is invalid, return empty dict
            return {}
    return {}


def _get_models_from_env():
    """Get models from environment variable if set."""
    models_env = os.getenv("LLM_COUNCIL_MODELS")
    if models_env:
        # Comma-separated list of models
        return [m.strip() for m in models_env.split(",")]
    return None


# Load user configuration
_user_config = _load_user_config()


def _get_api_key() -> Optional[str]:
    """
    Resolve API key with priority (ADR-013, per Council recommendation):
    1. Environment variable (explicit override, CI/CD standard)
    2. System keychain (desktop security)
    3. .env file (via dotenv, already loaded)
    4. Config file (warn if used)

    Returns:
        API key string or None if not found
    """
    global _key_source

    # 1. Environment variable takes priority (CI/CD standard)
    key = os.getenv("OPENROUTER_API_KEY")
    if key:
        _key_source = "environment"
        return key

    # 2. Try keychain (if available)
    key = _get_api_key_from_keychain()
    if key:
        _key_source = "keychain"
        return key

    # 3. .env file would have set the env var, so this is config file fallback
    config_key = _user_config.get("openrouter_api_key")
    if config_key:
        _key_source = "config_file"
        # Emit warning to stderr (suppressible via LLM_COUNCIL_SUPPRESS_WARNINGS)
        if not os.getenv("LLM_COUNCIL_SUPPRESS_WARNINGS"):
            print(
                "Warning: API key loaded from config file. This is insecure. "
                "Consider using environment variables or keychain. "
                "Set LLM_COUNCIL_SUPPRESS_WARNINGS=1 to silence.",
                file=sys.stderr
            )
        return config_key

    # No key found
    _key_source = None
    return None


def get_key_source() -> Optional[str]:
    """Return the source where the API key was loaded from (ADR-013).

    Returns:
        "environment", "keychain", "config_file", or None if no key found
    """
    return _key_source


# OpenRouter API key - resolved via ADR-013 priority chain
OPENROUTER_API_KEY = _get_api_key()

# Council models - priority: env var > config file > defaults
COUNCIL_MODELS = (
    _get_models_from_env() or 
    _user_config.get("council_models") or 
    DEFAULT_COUNCIL_MODELS
)

# Chairman model - priority: env var > config file > defaults
CHAIRMAN_MODEL = (
    os.getenv("LLM_COUNCIL_CHAIRMAN") or
    _user_config.get("chairman_model") or
    DEFAULT_CHAIRMAN_MODEL
)

# Synthesis mode - priority: env var > config file > defaults
SYNTHESIS_MODE = (
    os.getenv("LLM_COUNCIL_MODE") or
    _user_config.get("synthesis_mode") or
    DEFAULT_SYNTHESIS_MODE
)

# Exclude self-votes - priority: env var > config file > defaults
_exclude_self_env = os.getenv("LLM_COUNCIL_EXCLUDE_SELF_VOTES")
EXCLUDE_SELF_VOTES = (
    _exclude_self_env.lower() in ('true', '1', 'yes') if _exclude_self_env else
    _user_config.get("exclude_self_votes", DEFAULT_EXCLUDE_SELF_VOTES)
)

# Style normalization - priority: env var > config file > defaults
# Supports: false (never), true (always), auto (adaptive detection)
_style_norm_env = os.getenv("LLM_COUNCIL_STYLE_NORMALIZATION")
if _style_norm_env:
    _style_norm_env_lower = _style_norm_env.lower()
    if _style_norm_env_lower == "auto":
        STYLE_NORMALIZATION = "auto"
    else:
        STYLE_NORMALIZATION = _style_norm_env_lower in ('true', '1', 'yes')
else:
    STYLE_NORMALIZATION = _user_config.get("style_normalization", DEFAULT_STYLE_NORMALIZATION)

# Normalizer model - priority: env var > config file > defaults
NORMALIZER_MODEL = (
    os.getenv("LLM_COUNCIL_NORMALIZER_MODEL") or
    _user_config.get("normalizer_model") or
    DEFAULT_NORMALIZER_MODEL
)

# Max reviewers for stratified sampling - priority: env var > config file > defaults
_max_reviewers_env = os.getenv("LLM_COUNCIL_MAX_REVIEWERS")
MAX_REVIEWERS = (
    int(_max_reviewers_env) if _max_reviewers_env else
    _user_config.get("max_reviewers", DEFAULT_MAX_REVIEWERS)
)

# Response caching - priority: env var > config file > defaults
DEFAULT_CACHE_ENABLED = False
DEFAULT_CACHE_TTL = 0  # seconds, 0 = infinite (no expiry)
DEFAULT_CACHE_DIR = Path.home() / ".cache" / "llm-council"

_cache_env = os.getenv("LLM_COUNCIL_CACHE")
CACHE_ENABLED = (
    _cache_env.lower() in ('true', '1', 'yes') if _cache_env else
    _user_config.get("cache_enabled", DEFAULT_CACHE_ENABLED)
)

_cache_ttl_env = os.getenv("LLM_COUNCIL_CACHE_TTL")
CACHE_TTL = (
    int(_cache_ttl_env) if _cache_ttl_env else
    _user_config.get("cache_ttl", DEFAULT_CACHE_TTL)
)

_cache_dir_env = os.getenv("LLM_COUNCIL_CACHE_DIR")
CACHE_DIR = (
    Path(_cache_dir_env) if _cache_dir_env else
    Path(_user_config.get("cache_dir", DEFAULT_CACHE_DIR))
)

# =============================================================================
# ADR-020: Triage Layer Configuration
# =============================================================================
# Controls wildcard selection and prompt optimization in the triage layer.


def get_bool_config(env_var: str, default: bool = False) -> bool:
    """Get boolean configuration from environment variable.

    Args:
        env_var: Environment variable name
        default: Default value if not set

    Returns:
        Boolean configuration value
    """
    value = os.getenv(env_var)
    if value is None:
        return default
    return value.lower() in ('true', '1', 'yes')


# Wildcard selection - adds domain specialist to council
DEFAULT_WILDCARD_ENABLED = False
_wildcard_env = os.getenv("LLM_COUNCIL_WILDCARD_ENABLED")
WILDCARD_ENABLED = (
    _wildcard_env.lower() in ('true', '1', 'yes') if _wildcard_env else
    _user_config.get("wildcard_enabled", DEFAULT_WILDCARD_ENABLED)
)

# Prompt optimization - per-model prompt adaptation
DEFAULT_PROMPT_OPTIMIZATION_ENABLED = False
_prompt_opt_env = os.getenv("LLM_COUNCIL_PROMPT_OPTIMIZATION_ENABLED")
PROMPT_OPTIMIZATION_ENABLED = (
    _prompt_opt_env.lower() in ('true', '1', 'yes') if _prompt_opt_env else
    _user_config.get("prompt_optimization_enabled", DEFAULT_PROMPT_OPTIMIZATION_ENABLED)
)

# =============================================================================
# ADR-016: Structured Rubric Scoring Configuration
# =============================================================================
# Multi-dimensional evaluation with accuracy ceiling mechanism.
# When enabled, reviewers score on: accuracy, relevance, completeness,
# conciseness, and clarity instead of a single holistic score.

DEFAULT_RUBRIC_SCORING_ENABLED = False  # Off by default for backwards compatibility
DEFAULT_ACCURACY_CEILING_ENABLED = True  # Use accuracy as ceiling when rubric enabled

# Default rubric weights (post-council review)
DEFAULT_RUBRIC_WEIGHTS = {
    "accuracy": 0.35,
    "relevance": 0.10,
    "completeness": 0.20,
    "conciseness": 0.15,
    "clarity": 0.20,
}

# Rubric scoring enabled - priority: env var > config file > default
_rubric_env = os.getenv("LLM_COUNCIL_RUBRIC_SCORING")
RUBRIC_SCORING_ENABLED = (
    _rubric_env.lower() in ('true', '1', 'yes') if _rubric_env else
    _user_config.get("rubric_scoring", DEFAULT_RUBRIC_SCORING_ENABLED)
)

# Accuracy ceiling enabled - priority: env var > config file > default
_ceiling_env = os.getenv("LLM_COUNCIL_ACCURACY_CEILING")
ACCURACY_CEILING_ENABLED = (
    _ceiling_env.lower() in ('true', '1', 'yes') if _ceiling_env else
    _user_config.get("accuracy_ceiling", DEFAULT_ACCURACY_CEILING_ENABLED)
)

# Rubric weights - priority: env vars > config file > defaults
RUBRIC_WEIGHTS = {
    "accuracy": float(os.getenv("LLM_COUNCIL_WEIGHT_ACCURACY",
                     str(_user_config.get("rubric_weights", {}).get("accuracy", DEFAULT_RUBRIC_WEIGHTS["accuracy"])))),
    "relevance": float(os.getenv("LLM_COUNCIL_WEIGHT_RELEVANCE",
                      str(_user_config.get("rubric_weights", {}).get("relevance", DEFAULT_RUBRIC_WEIGHTS["relevance"])))),
    "completeness": float(os.getenv("LLM_COUNCIL_WEIGHT_COMPLETENESS",
                         str(_user_config.get("rubric_weights", {}).get("completeness", DEFAULT_RUBRIC_WEIGHTS["completeness"])))),
    "conciseness": float(os.getenv("LLM_COUNCIL_WEIGHT_CONCISENESS",
                        str(_user_config.get("rubric_weights", {}).get("conciseness", DEFAULT_RUBRIC_WEIGHTS["conciseness"])))),
    "clarity": float(os.getenv("LLM_COUNCIL_WEIGHT_CLARITY",
                    str(_user_config.get("rubric_weights", {}).get("clarity", DEFAULT_RUBRIC_WEIGHTS["clarity"])))),
}

# Validate rubric weights sum to 1.0
_rubric_weight_sum = sum(RUBRIC_WEIGHTS.values())
if abs(_rubric_weight_sum - 1.0) > 0.01:
    import warnings
    warnings.warn(f"Rubric weights sum to {_rubric_weight_sum}, not 1.0. Results may be unexpected.")


# =============================================================================
# ADR-016: Safety Gate Configuration
# =============================================================================
# Pass/fail safety check before rubric scoring applies.
# Filters harmful content (dangerous instructions, malware, self-harm, PII).
# When enabled, responses failing safety checks are capped at score 0.

DEFAULT_SAFETY_GATE_ENABLED = False  # Off by default for backwards compatibility
DEFAULT_SAFETY_SCORE_CAP = 0.0  # Score cap for failed safety checks

# Safety gate enabled - priority: env var > config file > default
_safety_gate_env = os.getenv("LLM_COUNCIL_SAFETY_GATE")
SAFETY_GATE_ENABLED = (
    _safety_gate_env.lower() in ('true', '1', 'yes') if _safety_gate_env else
    _user_config.get("safety_gate", DEFAULT_SAFETY_GATE_ENABLED)
)

# Safety score cap - priority: env var > config file > default
_safety_cap_env = os.getenv("LLM_COUNCIL_SAFETY_SCORE_CAP")
SAFETY_SCORE_CAP = (
    float(_safety_cap_env) if _safety_cap_env else
    float(_user_config.get("safety_score_cap", DEFAULT_SAFETY_SCORE_CAP))
)


# =============================================================================
# ADR-015: Bias Auditing Configuration
# =============================================================================
# Automatically detect systematic biases in peer review scoring:
# - Length-score correlation (verbosity bias)
# - Position bias (primacy/recency effects)
# - Reviewer calibration (harsh vs generous reviewers)

DEFAULT_BIAS_AUDIT_ENABLED = False  # Off by default for backwards compatibility
DEFAULT_LENGTH_CORRELATION_THRESHOLD = 0.3  # |r| above this = bias detected
DEFAULT_POSITION_VARIANCE_THRESHOLD = 0.5   # Score variance by position

# Bias audit enabled - priority: env var > config file > default
_bias_audit_env = os.getenv("LLM_COUNCIL_BIAS_AUDIT")
BIAS_AUDIT_ENABLED = (
    _bias_audit_env.lower() in ('true', '1', 'yes') if _bias_audit_env else
    _user_config.get("bias_audit", DEFAULT_BIAS_AUDIT_ENABLED)
)

# Length correlation threshold - priority: env var > config file > default
_length_corr_env = os.getenv("LLM_COUNCIL_LENGTH_CORRELATION_THRESHOLD")
LENGTH_CORRELATION_THRESHOLD = (
    float(_length_corr_env) if _length_corr_env else
    float(_user_config.get("length_correlation_threshold", DEFAULT_LENGTH_CORRELATION_THRESHOLD))
)

# Position variance threshold - priority: env var > config file > default
_position_var_env = os.getenv("LLM_COUNCIL_POSITION_VARIANCE_THRESHOLD")
POSITION_VARIANCE_THRESHOLD = (
    float(_position_var_env) if _position_var_env else
    float(_user_config.get("position_variance_threshold", DEFAULT_POSITION_VARIANCE_THRESHOLD))
)


# =============================================================================
# ADR-018: Cross-Session Bias Persistence Configuration
# =============================================================================
# Accumulate bias metrics across sessions for aggregated analysis.
# Stores one record per (session, model, reviewer) combination in JSONL format.
# Only stores one record per (session, model, reviewer) combination.
# JSONL format enables O(N) linear scan aggregation without file I/O hell.
# See: docs/adr/ADR-018-cross-session-bias-aggregation.md

DEFAULT_BIAS_PERSISTENCE_ENABLED = False  # Off for backward compatibility
DEFAULT_BIAS_STORE_PATH = Path.home() / ".llm-council" / "bias_metrics.jsonl"
DEFAULT_BIAS_WINDOW_SESSIONS = 100
DEFAULT_BIAS_WINDOW_DAYS = 30
DEFAULT_MIN_BIAS_SESSIONS = 20
DEFAULT_BIAS_CONSENT_LEVEL = 1  # LOCAL_ONLY

# Bias persistence enabled - priority: env var > config file > default
_bias_persist_env = os.getenv("LLM_COUNCIL_BIAS_PERSISTENCE")
BIAS_PERSISTENCE_ENABLED = (
    _bias_persist_env.lower() in ('true', '1', 'yes') if _bias_persist_env else
    _user_config.get("bias_persistence", DEFAULT_BIAS_PERSISTENCE_ENABLED)
)

# Bias store path - priority: env var > config file > default
_bias_store_env = os.getenv("LLM_COUNCIL_BIAS_STORE")
BIAS_STORE_PATH = (
    Path(_bias_store_env).expanduser() if _bias_store_env else
    Path(_user_config.get("bias_store_path", DEFAULT_BIAS_STORE_PATH)).expanduser()
)

# Rolling window: sessions - priority: env var > config file > default
_bias_window_sessions_env = os.getenv("LLM_COUNCIL_BIAS_WINDOW_SESSIONS")
BIAS_WINDOW_SESSIONS = (
    int(_bias_window_sessions_env) if _bias_window_sessions_env else
    int(_user_config.get("bias_window_sessions", DEFAULT_BIAS_WINDOW_SESSIONS))
)

# Rolling window: days - priority: env var > config file > default
_bias_window_days_env = os.getenv("LLM_COUNCIL_BIAS_WINDOW_DAYS")
BIAS_WINDOW_DAYS = (
    int(_bias_window_days_env) if _bias_window_days_env else
    int(_user_config.get("bias_window_days", DEFAULT_BIAS_WINDOW_DAYS))
)

# Minimum sessions for aggregation - priority: env var > config file > default
_min_bias_sessions_env = os.getenv("LLM_COUNCIL_MIN_BIAS_SESSIONS")
MIN_BIAS_SESSIONS = (
    int(_min_bias_sessions_env) if _min_bias_sessions_env else
    int(_user_config.get("min_bias_sessions", DEFAULT_MIN_BIAS_SESSIONS))
)

# Consent level - priority: env var > config file > default
_bias_consent_env = os.getenv("LLM_COUNCIL_BIAS_CONSENT")
BIAS_CONSENT_LEVEL = (
    int(_bias_consent_env) if _bias_consent_env else
    int(_user_config.get("bias_consent_level", DEFAULT_BIAS_CONSENT_LEVEL))
)

# Hash secret for query hashing (Research consent level only)
BIAS_HASH_SECRET = os.getenv("LLM_COUNCIL_HASH_SECRET", "default-dev-secret-do-not-use-in-prod")


# =============================================================================
# Telemetry Configuration (ADR-001)
# =============================================================================
# Opt-in telemetry for contributing anonymized voting data to the LLM Leaderboard.
# Privacy-first: disabled by default, no query text transmitted at basic levels.
#
# Levels:
#   off      - No telemetry (default)
#   anonymous - Basic voting data (rankings, durations, model counts)
#   debug    - + query_hash for troubleshooting (no actual query content)
#
# Example: export LLM_COUNCIL_TELEMETRY=anonymous

DEFAULT_TELEMETRY_LEVEL = "off"
DEFAULT_TELEMETRY_ENDPOINT = "https://ingest.llmcouncil.ai/v1/events"

# Parse telemetry level from environment
_telemetry_env = os.getenv("LLM_COUNCIL_TELEMETRY", "").lower().strip()
TELEMETRY_LEVEL = _telemetry_env if _telemetry_env in ("off", "anonymous", "debug") else (
    _user_config.get("telemetry_level", DEFAULT_TELEMETRY_LEVEL)
)

# Telemetry enabled if level is not "off"
TELEMETRY_ENABLED = TELEMETRY_LEVEL != "off"

# Telemetry endpoint - can be overridden for self-hosted installations
TELEMETRY_ENDPOINT = (
    os.getenv("LLM_COUNCIL_TELEMETRY_ENDPOINT") or
    _user_config.get("telemetry_endpoint") or
    DEFAULT_TELEMETRY_ENDPOINT
)


# =============================================================================
# ADR-012: Tier-Sovereign Timeout Configuration (Added 2025-12-19)
# =============================================================================
# Configurable timeouts per confidence tier to support reasoning models.
# Each tier has both a total timeout and a per-model timeout.
#
# Tiers:
#   quick     - Fast responses, fewer/simpler models (30s total, 20s per-model)
#   balanced  - Most models respond (90s total, 45s per-model)
#   high      - Full council deliberation (180s total, 90s per-model)
#   reasoning - Deep reasoning models like o1, GPT-5.2-pro (300s total, 150s per-model)
#
# Environment variables:
#   LLM_COUNCIL_TIMEOUT_<TIER>=<seconds>        - Total timeout for tier
#   LLM_COUNCIL_MODEL_TIMEOUT_<TIER>=<seconds>  - Per-model timeout for tier
#   LLM_COUNCIL_TIMEOUT_MULTIPLIER=<float>      - Global multiplier (emergency override)

DEFAULT_TIER_TIMEOUTS = {
    "quick": {"total": 30, "per_model": 20},
    "balanced": {"total": 90, "per_model": 45},
    "high": {"total": 180, "per_model": 90},
    "reasoning": {"total": 600, "per_model": 300},  # 10min total for deep reasoning models
    "frontier": {"total": 600, "per_model": 300},  # ADR-027: Long timeouts for preview/beta models
}

# Models that require the reasoning tier
REASONING_MODELS = {
    "openai/o1",
    "openai/o1-preview",
    "openai/o1-mini",
    "openai/gpt-5.2-pro",
}

# Global timeout multiplier (for emergency adjustments)
_timeout_multiplier_env = os.getenv("LLM_COUNCIL_TIMEOUT_MULTIPLIER")
TIMEOUT_MULTIPLIER = float(_timeout_multiplier_env) if _timeout_multiplier_env else 1.0


def get_tier_timeout(tier: str) -> dict:
    """
    Get timeout configuration for a tier, with environment variable overrides.

    Args:
        tier: One of "quick", "balanced", "high", "reasoning"

    Returns:
        dict with "total" and "per_model" timeout values in seconds
    """
    defaults = DEFAULT_TIER_TIMEOUTS.get(tier, DEFAULT_TIER_TIMEOUTS["high"])
    tier_upper = tier.upper()

    # Check for tier-specific env var overrides
    total_env = os.getenv(f"LLM_COUNCIL_TIMEOUT_{tier_upper}")
    per_model_env = os.getenv(f"LLM_COUNCIL_MODEL_TIMEOUT_{tier_upper}")

    total = int(total_env) if total_env else defaults["total"]
    per_model = int(per_model_env) if per_model_env else defaults["per_model"]

    # Apply global multiplier
    return {
        "total": int(total * TIMEOUT_MULTIPLIER),
        "per_model": int(per_model * TIMEOUT_MULTIPLIER),
    }


def infer_tier_from_models(models: list) -> str:
    """
    Auto-select tier based on the slowest model in the council.

    Args:
        models: List of model identifiers

    Returns:
        Recommended tier name
    """
    if any(m in REASONING_MODELS for m in models):
        return "reasoning"
    return "high"


# =============================================================================
# ADR-023: Gateway Layer Configuration
# =============================================================================
# When enabled, uses the gateway layer for LLM requests instead of direct
# openrouter module calls. This enables circuit breakers, fallback chains,
# and multi-gateway routing.
#
# Environment variables:
#   LLM_COUNCIL_USE_GATEWAY=true|false  - Enable gateway layer (default: false)

_use_gateway_env = os.getenv("LLM_COUNCIL_USE_GATEWAY", "false").lower()
USE_GATEWAY_LAYER = _use_gateway_env in ("true", "1", "yes")


# =============================================================================
# ADR-025: Ollama Local LLM Configuration
# =============================================================================
# Support for local LLM inference via Ollama using LiteLLM as the adapter.
# This enables air-gapped deployments, cost-free testing, and privacy-first
# deployments without external API dependencies.
#
# Environment variables:
#   LLM_COUNCIL_OLLAMA_BASE_URL=http://localhost:11434  - Ollama endpoint
#   LLM_COUNCIL_USE_LITELLM=true|false                  - Enable LiteLLM wrapper
#   LLM_COUNCIL_OLLAMA_TIMEOUT=120.0                    - Default timeout (seconds)
#
# Model format: "ollama/<model-name>" (e.g., "ollama/llama3.2", "ollama/qwen2.5:14b")

DEFAULT_OLLAMA_BASE_URL = "http://localhost:11434"
DEFAULT_OLLAMA_TIMEOUT = 120.0  # Local models can be slow on first load

# Ollama base URL - DEPRECATED: use unified_config.gateways.providers.ollama.base_url
# Kept as _LEGACY_* for backwards compat; access via OLLAMA_BASE_URL triggers __getattr__
_LEGACY_OLLAMA_BASE_URL = os.getenv("LLM_COUNCIL_OLLAMA_BASE_URL", DEFAULT_OLLAMA_BASE_URL)

# LiteLLM wrapper enabled - priority: env var > default
_use_litellm_env = os.getenv("LLM_COUNCIL_USE_LITELLM", "true").lower()
USE_LITELLM = _use_litellm_env in ("true", "1", "yes")

# Ollama timeout - DEPRECATED: use unified_config.gateways.providers.ollama.timeout_seconds
_ollama_timeout_env = os.getenv("LLM_COUNCIL_OLLAMA_TIMEOUT")
_LEGACY_OLLAMA_TIMEOUT = float(_ollama_timeout_env) if _ollama_timeout_env else DEFAULT_OLLAMA_TIMEOUT

# Hardware profiles for deployment guidance (per ADR-025)
# These are recommendations, not enforced requirements
OLLAMA_HARDWARE_PROFILES = {
    "minimum": {
        "description": "8+ core CPU, 16GB RAM, SSD",
        "models": ["7b-q4"],
        "use_case": "Development/testing only",
    },
    "recommended": {
        "description": "Apple M-series Pro/Max, 32GB unified memory",
        "models": ["7b", "13b-q4"],
        "use_case": "Small council (2-3 local models)",
    },
    "professional": {
        "description": "2x RTX 4090/5090, 64GB+ system RAM",
        "models": ["70b-q4", "70b"],
        "use_case": "Production single-tenant",
    },
    "enterprise": {
        "description": "Mac Studio 64GB+ / multi-GPU workstation",
        "models": ["70b concurrent", "multiple 13b"],
        "use_case": "Air-gapped production, multi-model council",
    },
}


# =============================================================================
# ADR-025: Webhook Configuration
# =============================================================================
# Webhook delivery settings for external integrations (n8n, Zapier, etc.).
#
# Environment variables:
#   LLM_COUNCIL_WEBHOOK_TIMEOUT=5.0      - POST timeout in seconds
#   LLM_COUNCIL_WEBHOOK_RETRIES=3        - Max retry attempts
#   LLM_COUNCIL_WEBHOOK_HTTPS_ONLY=true  - Require HTTPS (except localhost)

DEFAULT_WEBHOOK_TIMEOUT = 5.0
DEFAULT_WEBHOOK_MAX_RETRIES = 3
DEFAULT_WEBHOOK_HTTPS_ONLY = True

# Webhook timeout - DEPRECATED: use unified_config.webhooks.timeout_seconds
_webhook_timeout_env = os.getenv("LLM_COUNCIL_WEBHOOK_TIMEOUT")
_LEGACY_WEBHOOK_TIMEOUT = float(_webhook_timeout_env) if _webhook_timeout_env else DEFAULT_WEBHOOK_TIMEOUT

# Webhook max retries - DEPRECATED: use unified_config.webhooks.max_retries
_webhook_retries_env = os.getenv("LLM_COUNCIL_WEBHOOK_RETRIES")
_LEGACY_WEBHOOK_MAX_RETRIES = int(_webhook_retries_env) if _webhook_retries_env else DEFAULT_WEBHOOK_MAX_RETRIES

# Webhook HTTPS only - DEPRECATED: use unified_config.webhooks.https_only
_webhook_https_env = os.getenv("LLM_COUNCIL_WEBHOOK_HTTPS_ONLY", "true").lower()
_LEGACY_WEBHOOK_HTTPS_ONLY = _webhook_https_env in ("true", "1", "yes")


# =============================================================================
# ADR-025a: Deprecation Bridge to UnifiedConfig
# =============================================================================
# Per council recommendation, these constants are deprecated in favor of
# unified_config.py. Access will emit DeprecationWarning while returning
# values from the new configuration system.
#
# Migration:
#   OLD: from llm_council.config import OLLAMA_BASE_URL
#   NEW: from llm_council.unified_config import get_config
#        config = get_config()
#        url = config.gateways.providers["ollama"].base_url

# Track which attributes have already warned (avoid repeated warnings)
_deprecated_warned: set = set()

# Mapping from deprecated names to unified_config paths
_DEPRECATED_ATTRS = {
    "OLLAMA_BASE_URL": "gateways.providers.ollama.base_url",
    "OLLAMA_TIMEOUT": "gateways.providers.ollama.timeout_seconds",
    "WEBHOOK_TIMEOUT": "webhooks.timeout_seconds",
    "WEBHOOK_MAX_RETRIES": "webhooks.max_retries",
    "WEBHOOK_HTTPS_ONLY": "webhooks.https_only",
}


def _get_deprecated_value(attr_name: str):
    """Get value from unified_config for a deprecated attribute."""
    from .unified_config import get_config

    config = get_config()
    path = _DEPRECATED_ATTRS[attr_name]

    # Navigate the path
    obj = config
    for part in path.split("."):
        if hasattr(obj, part):
            obj = getattr(obj, part)
        elif isinstance(obj, dict) and part in obj:
            obj = obj[part]
        else:
            return None
    return obj


def __getattr__(name: str):
    """Module-level __getattr__ for deprecation warnings (PEP 562)."""
    import warnings

    if name in _DEPRECATED_ATTRS:
        # Emit deprecation warning (once per attribute per session)
        if name not in _deprecated_warned:
            _deprecated_warned.add(name)
            new_path = _DEPRECATED_ATTRS[name]
            warnings.warn(
                f"config.{name} is deprecated. Use unified_config: "
                f"get_config().{new_path}",
                DeprecationWarning,
                stacklevel=2,
            )
        # Return value from unified_config
        return _get_deprecated_value(name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
