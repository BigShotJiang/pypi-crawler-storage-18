# core/downloader_subprocess.py

import subprocess
import logging
from pathlib import Path


def ytdlp_subprocess(
    url: str,
    filepath: Path | str,
):
    cmd = [
        "yt-dlp",
        "-q",
        "--progress",
        url,
        "-o",
        filepath,
        "--external-downloader",
        "aria2c",
    ]

    logging.info(f"CMD: {' '.join(cmd)}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logging.error(f"yt-dlp failed to dl vid: {result.stderr}")

    return result.returncode
