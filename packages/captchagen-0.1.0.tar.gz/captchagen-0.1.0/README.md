# CAPTCHA Generator

### Overview
This project provides a **configurable CAPTCHA generator** in Python.  
It supports:
- Multiple font support (TTF files in `fonts/` folder)
- Random text generation with configurable character sets (`digits`, `letters`, `alnum`, or custom)
- Optional character rotation
- Optional noise (dots, lines, or both)
- Random character colors
- Multi-configuration generation in one script

The code is organized into a **class-based structure**:
- `CaptchaConfig`: Holds configuration parameters for CAPTCHA generation.
- `CaptchaGenerator`: Generates CAPTCHA images based on the configuration.

---

### Folder Structure
```
project/
│
├─ fonts/           # Place your .ttf font files here
├─ CaptchaGen.py # CAPTCHA generator class
├─ sample.py      # Script to generate CAPTCHA images with multiple configurations
├─ requirements.txt # Required Python packages
└─ README.md
```

---

### Installation

1. Create a virtual environment (optional but recommended):
```bash
python -m venv venv
source venv/bin/activate  # Linux / macOS
venv\Scripts\activate     # Windows
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

---

### Usage

1. Place your **.ttf fonts** inside the `fonts/` directory.

2. Configure your CAPTCHA settings in `generate.py` using the `CaptchaConfig` class. Example:
```python
from CaptchaGen import CaptchaGenerator, CaptchaConfig

cfg = CaptchaConfig(
    noise=True,
    rotate=True,
    random_color=True,
    text_mode="alnum"
)

gen = CaptchaGenerator("fonts", cfg)
img, label = gen.generate()
img.save(f"captchas/{label}.png")
```

3. Run the multi-configuration generation script:
```bash
python sample.py
```
- This will create `captchas/` folder with images for all configurations.
- Filenames include both the generated text and a unique index to avoid overwriting duplicates.

---

### Notes

- `text_mode` options:
  - `"digits"` → only 0-9
  - `"lower"` → lowercase letters
  - `"upper"` → uppercase letters
  - `"letters"` → lowercase + uppercase
  - `"alnum"` → letters + digits
  - `"custom"` → use `custom_charset` string
- Noise is added **randomly**: dots and lines.
- Character rotation range: ±25 degrees.

---

### Sample CAPTCHA
![Sample CAPTCHA](images/sample.jpg)

---

### توضیحات کلی
این پروژه یک **مولد کپچا قابل تنظیم** در پایتون ارائه می‌دهد.  
ویژگی‌ها:
- پشتیبانی از چند فونت (TTF در پوشه `fonts/`)
- تولید متن تصادفی با مجموعه کاراکتر قابل انتخاب (`digits`، `letters`، `alnum` یا دلخواه)
- امکان چرخش کاراکترها
- امکان افزودن نویز (نقطه، خط یا هر دو)
- رنگ تصادفی برای کاراکترها
- تولید چند نوع کپچا در یک اسکریپت

ساختار کد به شکل **کلاس‌بندی شده** است:
- `CaptchaConfig`: نگه‌دارنده تنظیمات تولید کپچا
- `CaptchaGenerator`: تولید تصویر کپچا بر اساس تنظیمات

---

### ساختار پوشه‌ها
```
project/
│
├─ fonts/           # فایل‌های فونت .ttf در اینجا قرار گیرند
├─ CaptchaGen.py # کلاس تولید کپچا
├─ sample.py      # اسکریپت تولید کپچا با تنظیمات مختلف
├─ requirements.txt # بسته‌های مورد نیاز پایتون
└─ README.md
```

---

### نصب

1. ایجاد محیط مجازی (اختیاری اما توصیه شده):
```bash
python -m venv venv
source venv/bin/activate  # لینوکس / مک
venv\Scripts\activate     # ویندوز
```

2. نصب بسته‌های مورد نیاز:
```bash
pip install -r requirements.txt
```

---

### نحوه استفاده

1. فونت‌های `.ttf` را در پوشه `fonts/` قرار دهید.

2. تنظیمات کپچا را در `generate.py` با استفاده از کلاس `CaptchaConfig` مشخص کنید:
```python
from CaptchaGen import CaptchaGenerator, CaptchaConfig

cfg = CaptchaConfig(
    noise=True,
    rotate=True,
    random_color=True,
    text_mode="alnum"
)

gen = CaptchaGenerator("fonts", cfg)
img, label = gen.generate()
img.save(f"captchas/{label}.png")
```

3. اجرای اسکریپت تولید چند نوع کپچا:
```bash
python sample.py
```
- این دستور پوشه `captchas/` را ایجاد کرده و تصاویر را ذخیره می‌کند.
- نام فایل‌ها شامل متن تولید شده و یک شماره یکتا است تا تصاویر تکراری بازنویسی نشوند.

---

### نکات

- گزینه‌های `text_mode`:
  - `"digits"` → فقط اعداد ۰ تا ۹
  - `"lower"` → حروف کوچک
  - `"upper"` → حروف بزرگ
  - `"letters"` → حروف کوچک + بزرگ
  - `"alnum"` → حروف + اعداد
  - `"custom"` → استفاده از رشته `custom_charset`
- نویز به صورت **تصادفی**: نقطه ای و خطی
- محدوده چرخش کاراکترها: ±۲۵ درجه

---

### Sample CAPTCHA
![Sample CAPTCHA](images/sample.jpg)
