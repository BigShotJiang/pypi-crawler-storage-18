---
spec_version: AFAD-v1
project_version: 0.33.0
context: TYPES
last_updated: 2025-12-24T12:00:00Z
maintainer: claude-opus-4-5
---

# AST Types Reference

---

## `Resource`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Resource:
    entries: tuple[Entry, ...]
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `entries` | `tuple[Entry, ...]` | Y | All top-level entries. |

### Constraints
- Return: Immutable root AST node.
- State: Frozen dataclass.

---

## `Message`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Message:
    id: Identifier
    value: Pattern | None
    attributes: tuple[Attribute, ...]
    comment: Comment | None = None
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Message]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Message identifier. |
| `value` | `Pattern \| None` | Y | Message value pattern. |
| `attributes` | `tuple[Attribute, ...]` | Y | Message attributes. |
| `comment` | `Comment \| None` | N | Associated comment. |
| `span` | `Span \| None` | N | Source position. |

### Constraints
- Return: Immutable message node.
- State: Frozen dataclass.

---

## `Term`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Term:
    id: Identifier
    value: Pattern
    attributes: tuple[Attribute, ...]
    comment: Comment | None = None
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Term]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Term identifier (without - prefix). |
| `value` | `Pattern` | Y | Term value pattern (required). |
| `attributes` | `tuple[Attribute, ...]` | Y | Term attributes. |
| `comment` | `Comment \| None` | N | Associated comment. |
| `span` | `Span \| None` | N | Source position. |

### Constraints
- Return: Immutable term node.
- State: Frozen dataclass.

---

## `Attribute`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Attribute:
    id: Identifier
    value: Pattern
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Attribute name. |
| `value` | `Pattern` | Y | Attribute value pattern. |

### Constraints
- Return: Immutable attribute node.
- State: Frozen dataclass.

---

## `Comment`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Comment:
    content: str
    type: CommentType
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Comment]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `content` | `str` | Y | Comment text. |
| `type` | `CommentType` | Y | SINGLE, GROUP, or RESOURCE. |
| `span` | `Span \| None` | N | Source position. |

### Constraints
- Return: Immutable comment node.
- State: Frozen dataclass.

---

## `Junk`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Junk:
    content: str
    annotations: tuple[Annotation, ...] = ()
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Junk]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `content` | `str` | Y | Unparseable source text. |
| `annotations` | `tuple[Annotation, ...]` | N | Parse error annotations. |
| `span` | `Span \| None` | N | Source position. |

### Constraints
- Return: Immutable junk node.
- State: Frozen dataclass.

---

## `Pattern`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Pattern:
    elements: tuple[PatternElement, ...]
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `elements` | `tuple[PatternElement, ...]` | Y | Text and placeable elements. |

### Constraints
- Return: Immutable pattern node.
- State: Frozen dataclass.

---

## `TextElement`

### Signature
```python
@dataclass(frozen=True, slots=True)
class TextElement:
    value: str

    @staticmethod
    def guard(elem: object) -> TypeIs[TextElement]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `str` | Y | Plain text content. |

### Constraints
- Return: Immutable text element.
- State: Frozen dataclass.

---

## `Placeable`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Placeable:
    expression: Expression

    @staticmethod
    def guard(elem: object) -> TypeIs[Placeable]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `expression` | `Expression` | Y | Contained expression. |

### Constraints
- Return: Immutable placeable node.
- State: Frozen dataclass.

---

## `SelectExpression`

### Signature
```python
@dataclass(frozen=True, slots=True)
class SelectExpression:
    selector: InlineExpression
    variants: tuple[Variant, ...]

    @staticmethod
    def guard(expr: object) -> TypeIs[SelectExpression]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `selector` | `InlineExpression` | Y | Value to select on. |
| `variants` | `tuple[Variant, ...]` | Y | Selection variants. |

### Constraints
- Return: Immutable select expression.
- State: Frozen dataclass.

---

## `Variant`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Variant:
    key: VariantKey
    value: Pattern
    default: bool = False
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `key` | `VariantKey` | Y | Variant key (Identifier or NumberLiteral). |
| `value` | `Pattern` | Y | Variant pattern. |
| `default` | `bool` | N | True for default variant (*). |

### Constraints
- Return: Immutable variant node.
- State: Frozen dataclass.

---

## `StringLiteral`

### Signature
```python
@dataclass(frozen=True, slots=True)
class StringLiteral:
    value: str
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `str` | Y | String content (without quotes). |

### Constraints
- Return: Immutable string literal.
- State: Frozen dataclass.

---

## `NumberLiteral`

### Signature
```python
@dataclass(frozen=True, slots=True)
class NumberLiteral:
    value: int | float
    raw: str

    @staticmethod
    def guard(key: object) -> TypeIs[NumberLiteral]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `value` | `int \| float` | Y | Parsed numeric value. |
| `raw` | `str` | Y | Original source representation. |

### Constraints
- Return: Immutable number literal.
- State: Frozen dataclass.

---

## `VariableReference`

### Signature
```python
@dataclass(frozen=True, slots=True)
class VariableReference:
    id: Identifier

    @staticmethod
    def guard(expr: object) -> TypeIs[VariableReference]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Variable identifier (without $). |

### Constraints
- Return: Immutable variable reference.
- State: Frozen dataclass.

---

## `MessageReference`

### Signature
```python
@dataclass(frozen=True, slots=True)
class MessageReference:
    id: Identifier
    attribute: Identifier | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[MessageReference]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Message identifier. |
| `attribute` | `Identifier \| None` | N | Attribute name if present. |

### Constraints
- Return: Immutable message reference.
- State: Frozen dataclass.

---

## `TermReference`

### Signature
```python
@dataclass(frozen=True, slots=True)
class TermReference:
    id: Identifier
    attribute: Identifier | None = None
    arguments: CallArguments | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[TermReference]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Term identifier (without -). |
| `attribute` | `Identifier \| None` | N | Attribute name if present. |
| `arguments` | `CallArguments \| None` | N | Parameterized term args. |

### Constraints
- Return: Immutable term reference.
- State: Frozen dataclass.

---

## `FunctionReference`

### Signature
```python
@dataclass(frozen=True, slots=True)
class FunctionReference:
    id: Identifier
    arguments: CallArguments

    @staticmethod
    def guard(expr: object) -> TypeIs[FunctionReference]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `Identifier` | Y | Function name (e.g., NUMBER). |
| `arguments` | `CallArguments` | Y | Function arguments. |

### Constraints
- Return: Immutable function reference.
- State: Frozen dataclass.

---

## `CallArguments`

### Signature
```python
@dataclass(frozen=True, slots=True)
class CallArguments:
    positional: tuple[InlineExpression, ...]
    named: tuple[NamedArgument, ...]
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `positional` | `tuple[InlineExpression, ...]` | Y | Positional arguments. |
| `named` | `tuple[NamedArgument, ...]` | Y | Named arguments. |

### Constraints
- Return: Immutable call arguments.
- State: Frozen dataclass.

---

## `NamedArgument`

### Signature
```python
@dataclass(frozen=True, slots=True)
class NamedArgument:
    name: Identifier
    value: InlineExpression
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `name` | `Identifier` | Y | Argument name. |
| `value` | `InlineExpression` | Y | Argument value. |

### Constraints
- Return: Immutable named argument.
- State: Frozen dataclass.

---

## `Identifier`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Identifier:
    name: str

    @staticmethod
    def guard(key: object) -> TypeIs[Identifier]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `name` | `str` | Y | Identifier string. |

### Constraints
- Return: Immutable identifier.
- State: Frozen dataclass.

---

## `Span`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Span:
    start: int
    end: int
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `start` | `int` | Y | Start byte offset (inclusive). |
| `end` | `int` | Y | End byte offset (exclusive). |

### Constraints
- Return: Immutable span.
- Raises: `ValueError` if start < 0 or end < start.
- State: Frozen dataclass.

---

## `Annotation`

### Signature
```python
@dataclass(frozen=True, slots=True)
class Annotation:
    code: str
    message: str
    arguments: dict[str, str] | None = None
    span: Span | None = None
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `code` | `str` | Y | Error code. |
| `message` | `str` | Y | Error message. |
| `arguments` | `dict[str, str] \| None` | N | Additional context. |
| `span` | `Span \| None` | N | Error location. |

### Constraints
- Return: Immutable annotation.
- State: Frozen dataclass.

---

## `ASTVisitor`

### Signature
```python
class ASTVisitor:
    def __init__(self) -> None: ...
    def visit(self, node: ASTNode) -> ASTNode: ...
    def generic_visit(self, node: ASTNode) -> ASTNode: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|

### Constraints
- Return: Visited/transformed node.
- State: Maintains dispatch cache.
- Thread: Not thread-safe (instance state).

---

## `MessageIntrospection`

### Signature
```python
@dataclass(frozen=True, slots=True)
class MessageIntrospection:
    message_id: str
    variables: frozenset[VariableInfo]
    functions: frozenset[FunctionCallInfo]
    references: frozenset[ReferenceInfo]
    has_selectors: bool

    def get_variable_names(self) -> frozenset[str]: ...
    def requires_variable(self, name: str) -> bool: ...
    def get_function_names(self) -> frozenset[str]: ...
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `message_id` | `str` | Y | Message identifier. |
| `variables` | `frozenset[VariableInfo]` | Y | Variable references. |
| `functions` | `frozenset[FunctionCallInfo]` | Y | Function calls. |
| `references` | `frozenset[ReferenceInfo]` | Y | Message/term references. |
| `has_selectors` | `bool` | Y | Uses select expressions. |

### Constraints
- Return: Immutable introspection result.
- State: Frozen dataclass.

---

## Type Aliases

### Signature
```python
type Entry = Message | Term | Comment | Junk
type PatternElement = TextElement | Placeable
type Expression = SelectExpression | InlineExpression
type InlineExpression = (
    StringLiteral | NumberLiteral | VariableReference |
    MessageReference | TermReference | FunctionReference | Placeable
)
type VariantKey = Identifier | NumberLiteral
type ASTNode = Resource | Message | Term | ... # Union of all AST types
```

### Constraints
- PEP 695 type aliases. Cannot use with isinstance().
- Use pattern matching or .guard() methods for runtime checks.

---

## `FluentValue`

### Signature
```python
type FluentValue = str | int | float | bool | Decimal | datetime | date | None
```

### Contract
| Type | Description |
|:-----|:------------|
| `str` | String arguments. |
| `int` | Integer arguments. |
| `float` | Floating-point arguments. |
| `bool` | Boolean arguments. |
| `Decimal` | Precise decimal arguments (currency). |
| `datetime` | Date-time arguments. |
| `date` | Date-only arguments. |
| `None` | Absent/null arguments. |

### Constraints
- PEP 695 type alias. Export: `from ftllexengine import FluentValue`.
- Used for type-hinting resolver arguments: `args: dict[str, FluentValue]`.
- Location: `runtime/resolver.py`, exported from package root.

---

## `VariableInfo`

### Signature
```python
@dataclass(frozen=True, slots=True)
class VariableInfo:
    name: str
    context: VariableContext
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `name` | `str` | Y | Variable name (without $ prefix). |
| `context` | `VariableContext` | Y | Context where variable appears. |

### Constraints
- Return: Immutable variable metadata.
- State: Frozen dataclass.
- Import: `from ftllexengine.introspection import VariableInfo`

---

## `FunctionCallInfo`

### Signature
```python
@dataclass(frozen=True, slots=True)
class FunctionCallInfo:
    name: str
    positional_args: tuple[str, ...]
    named_args: frozenset[str]
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `name` | `str` | Y | Function name (e.g., 'NUMBER'). |
| `positional_args` | `tuple[str, ...]` | Y | Positional argument variable names. |
| `named_args` | `frozenset[str]` | Y | Named argument keys. |

### Constraints
- Return: Immutable function call metadata.
- State: Frozen dataclass.
- Import: `from ftllexengine.introspection import FunctionCallInfo`

---

## `ReferenceInfo`

### Signature
```python
@dataclass(frozen=True, slots=True)
class ReferenceInfo:
    id: str
    kind: ReferenceKind
    attribute: str | None
```

### Contract
| Parameter | Type | Req | Description |
|:----------|:-----|:----|:------------|
| `id` | `str` | Y | Referenced message or term ID. |
| `kind` | `ReferenceKind` | Y | Reference type (MESSAGE or TERM). |
| `attribute` | `str \| None` | N | Attribute name if present. |

### Constraints
- Return: Immutable reference metadata.
- State: Frozen dataclass.
- Import: `from ftllexengine.introspection import ReferenceInfo`

---

## `CommentType`

### Signature
```python
class CommentType(StrEnum):
    COMMENT = "comment"
    GROUP = "group"
    RESOURCE = "resource"
```

### Contract
| Value | Description |
|:------|:------------|
| `COMMENT` | Standalone comment: `# text` |
| `GROUP` | Group comment: `## text` |
| `RESOURCE` | Resource comment: `### text` |

### Constraints
- StrEnum: Members ARE strings. `str(CommentType.COMMENT) == "comment"`
- Import: `from ftllexengine.enums import CommentType`
- Version: Migrated to StrEnum in v0.30.0

---

## `VariableContext`

### Signature
```python
class VariableContext(StrEnum):
    PATTERN = "pattern"
    SELECTOR = "selector"
    VARIANT = "variant"
    FUNCTION_ARG = "function_arg"
```

### Contract
| Value | Description |
|:------|:------------|
| `PATTERN` | Variable in message pattern. |
| `SELECTOR` | Variable in select expression selector. |
| `VARIANT` | Variable in select variant. |
| `FUNCTION_ARG` | Variable in function argument. |

### Constraints
- StrEnum: Members ARE strings. `str(VariableContext.PATTERN) == "pattern"`
- Import: `from ftllexengine.enums import VariableContext`
- Version: Migrated to StrEnum in v0.30.0

---

## `ReferenceKind`

### Signature
```python
class ReferenceKind(StrEnum):
    MESSAGE = "message"
    TERM = "term"
```

### Contract
| Value | Description |
|:------|:------------|
| `MESSAGE` | Reference to a message: `{ message-id }` |
| `TERM` | Reference to a term: `{ -term-id }` |

### Constraints
- StrEnum: Members ARE strings. `str(ReferenceKind.MESSAGE) == "message"`
- Import: `from ftllexengine.enums import ReferenceKind`
- Version: Migrated to StrEnum in v0.30.0

---
