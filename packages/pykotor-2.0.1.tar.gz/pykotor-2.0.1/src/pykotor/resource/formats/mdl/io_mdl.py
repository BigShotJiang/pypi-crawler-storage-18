from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar, cast

from pykotor.common.misc import Color, Game
from pykotor.common.stream import BinaryReader, BinaryWriter
from pykotor.resource.formats.mdl.mdl_data import (
    MDL,
    MDLAnimation,
    MDLBoneVertex,
    MDLController,
    MDLControllerRow,
    MDLEvent,
    MDLFace,
    MDLMesh,
    MDLNode,
    MDLNodeFlags,
    MDLSkin,
)
from pykotor.resource.formats.mdl.mdl_types import MDLControllerType, MDLNodeType
from utility.common.geometry import Vector2, Vector3, Vector4

if TYPE_CHECKING:
    from typing_extensions import Literal  # pyright: ignore[reportMissingModuleSource]

    from pykotor.common.stream import BinaryWriterBytearray
    from pykotor.resource.type import SOURCE_TYPES, TARGET_TYPES


# Fast-loading flags for render-only mode
MDL_FAST_LOAD_FLAGS = {
    "skip_controllers": True,
    "skip_animations": True,
    "minimal_mesh_data": True,
}


class _ModelHeader:
    SIZE: ClassVar[int] = 196

    def __init__(
        self,
    ):
        self.geometry: _GeometryHeader = _GeometryHeader()
        self.model_type: int = 0
        self.unknown0: int = 0  # TODO: what is this?
        self.padding0: int = 0
        self.fog: int = 0
        self.unknown1: int = 0  # TODO: what is this?
        self.offset_to_animations: int = 0
        self.animation_count: int = 0
        self.animation_count2: int = 0
        self.unknown2: int = 0  # TODO: what is this?
        self.bounding_box_min: Vector3 = Vector3.from_null()
        self.bounding_box_max: Vector3 = Vector3.from_null()
        self.radius: float = 0.0
        self.anim_scale: float = 0.0
        self.supermodel: str = ""
        self.offset_to_super_root: int = 0
        self.unknown3: int = 0  # Unknown field from Names array header (cchargin mdl_info.html). Second field after offset_to_super_root. Purpose unknown but preserved for format compatibility.
        self.mdx_size: int = 0
        self.mdx_offset: int = 0
        self.offset_to_name_offsets: int = 0
        self.name_offsets_count: int = 0
        self.name_offsets_count2: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _ModelHeader:
        self.geometry = _GeometryHeader().read(reader)
        self.model_type = reader.read_uint8()
        self.unknown0 = reader.read_uint8()  # TODO: what is this?
        self.padding0 = reader.read_uint8()
        self.fog = reader.read_uint8()
        self.unknown1 = reader.read_uint32()  # TODO: what is this?
        self.offset_to_animations = reader.read_uint32()
        self.animation_count = reader.read_uint32()
        self.animation_count2 = reader.read_uint32()
        self.unknown2 = reader.read_uint32()  # TODO: what is this?
        self.bounding_box_min = reader.read_vector3()
        self.bounding_box_max = reader.read_vector3()
        self.radius = reader.read_single()
        self.anim_scale = reader.read_single()
        self.supermodel = reader.read_terminated_string("\0", 32)
        self.offset_to_super_root = reader.read_uint32()
        self.unknown3 = reader.read_uint32()  # Unknown field from Names array header (cchargin mdl_info.html). Second field after offset_to_super_root. Purpose unknown but preserved for format compatibility.
        self.mdx_size = reader.read_uint32()
        self.mdx_offset = reader.read_uint32()
        self.offset_to_name_offsets = reader.read_uint32()
        self.name_offsets_count = reader.read_uint32()
        self.name_offsets_count2 = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        self.geometry.write(writer)
        writer.write_uint8(self.model_type)
        writer.write_uint8(self.unknown0)
        writer.write_uint8(self.padding0)
        writer.write_uint8(self.fog)
        writer.write_uint32(self.unknown1)
        writer.write_uint32(self.offset_to_animations)
        writer.write_uint32(self.animation_count)
        writer.write_uint32(self.animation_count2)
        writer.write_uint32(self.unknown2)
        writer.write_vector3(self.bounding_box_min)
        writer.write_vector3(self.bounding_box_max)
        writer.write_single(self.radius)
        writer.write_single(self.anim_scale)
        writer.write_string(self.supermodel, string_length=32, encoding="ascii", errors="ignore")
        writer.write_uint32(self.offset_to_super_root)
        writer.write_uint32(self.unknown3)  # Unknown field from Names array header (cchargin mdl_info.html). Second field after offset_to_super_root. Purpose unknown but preserved for format compatibility.
        writer.write_uint32(self.mdx_size)
        writer.write_uint32(self.mdx_offset)
        writer.write_uint32(self.offset_to_name_offsets)
        writer.write_uint32(self.name_offsets_count)
        writer.write_uint32(self.name_offsets_count2)


class _GeometryHeader:
    SIZE = 80

    K1_FUNCTION_POINTER0 = 4273776
    K2_FUNCTION_POINTER0 = 4285200
    K1_ANIM_FUNCTION_POINTER0 = 4273392
    K2_ANIM_FUNCTION_POINTER0 = 4284816

    K1_FUNCTION_POINTER1 = 4216096
    K2_FUNCTION_POINTER1 = 4216320
    K1_ANIM_FUNCTION_POINTER1 = 4451552
    K2_ANIM_FUNCTION_POINTER1 = 4522928

    GEOM_TYPE_ROOT = 2
    GEOM_TYPE_ANIM = 5

    def __init__(
        self,
    ):
        self.function_pointer0: int = 0
        self.function_pointer1: int = 0
        self.model_name: str = ""
        self.root_node_offset: int = 0
        self.node_count: int = 0
        self.unknown0: bytes = b"\x00" * 28
        self.geometry_type: int = 0
        self.padding: bytes = b"\x00" * 3

    def read(
        self,
        reader: BinaryReader,
    ) -> _GeometryHeader:
        self.function_pointer0 = reader.read_uint32()
        self.function_pointer1 = reader.read_uint32()
        self.model_name = reader.read_terminated_string("\0", 32)
        self.root_node_offset = reader.read_uint32()
        self.node_count = reader.read_uint32()
        self.unknown0 = reader.read_bytes(28)
        self.geometry_type = reader.read_uint8()
        self.padding = reader.read_bytes(3)
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint32(self.function_pointer0)
        writer.write_uint32(self.function_pointer1)
        writer.write_string(self.model_name, string_length=32, encoding="ascii")
        writer.write_uint32(self.root_node_offset)
        writer.write_uint32(self.node_count)
        writer.write_bytes(self.unknown0)
        writer.write_uint8(self.geometry_type)
        writer.write_bytes(self.padding)


class _AnimationHeader:
    SIZE = _GeometryHeader.SIZE + 56

    def __init__(
        self,
    ):
        self.geometry: _GeometryHeader = _GeometryHeader()
        self.duration: float = 0.0
        self.transition: float = 0.0
        self.root: str = ""
        self.offset_to_events: int = 0
        self.event_count: int = 0
        self.event_count2: int = 0
        self.unknown0: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _AnimationHeader:
        self.geometry = _GeometryHeader().read(reader)
        self.duration = reader.read_single()
        self.transition = reader.read_single()
        self.root = reader.read_terminated_string("\0", 32)
        self.offset_to_events = reader.read_uint32()
        self.event_count = reader.read_uint32()
        self.event_count2 = reader.read_uint32()
        self.unknown0 = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        self.geometry.write(writer)
        writer.write_single(self.duration)
        writer.write_single(self.transition)
        writer.write_string(self.root, string_length=32, encoding="ascii")
        writer.write_uint32(self.offset_to_events)
        writer.write_uint32(self.event_count)
        writer.write_uint32(self.event_count2)
        writer.write_uint32(self.unknown0)


class _Animation:
    def __init__(
        self,
    ):
        self.header: _AnimationHeader = _AnimationHeader()
        self.events: list[_EventStructure] = []
        self.w_nodes: list[_Node] = []

    def read(
        self,
        reader: BinaryReader,
    ) -> _Animation:
        self.header = _AnimationHeader().read(reader)

        # read events
        return self

    def write(
        self,
        writer: BinaryWriter,
        game: Game,
    ):
        self.header.write(writer)
        for event in self.events:
            event.write(writer)
        for node in self.w_nodes:
            node.write(writer, game)

    def events_offset(self) -> int:
        # Always after header
        return _AnimationHeader.SIZE

    def events_size(self) -> int:
        return _EventStructure.SIZE * len(self.events)

    def nodes_offset(self) -> int:
        """Returns offset of the first node relative to the start of the animation data."""
        # Always after events
        return self.events_offset() + self.events_size()

    def nodes_size(self):
        return sum(node.calc_size(Game.K1) for node in self.w_nodes)

    def size(self) -> int:
        return self.nodes_offset() + self.nodes_size()


class _EventStructure:
    SIZE = 36

    def __init__(self):
        self.activation_time: float = 0.0
        self.event_name: str = ""

    def read(
        self,
        reader: BinaryReader,
    ) -> _EventStructure:
        self.activation_time = reader.read_single()
        self.event_name = reader.read_terminated_string("\0", 32)
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_single(self.activation_time)
        writer.write_string(self.event_name, string_length=32, encoding="ascii")


class _Controller:
    SIZE = 16

    def __init__(self):
        self.type_id: int = 0
        self.unknown0: int = 0xFFFF
        self.row_count: int = 0
        self.key_offset: int = 0
        self.data_offset: int = 0
        self.column_count: int = 0
        self.unknown1: bytes = b"\x00" * 3

    def read(
        self,
        reader: BinaryReader,
    ) -> _Controller:
        self.type_id = reader.read_uint32()
        self.unknown0 = reader.read_uint16()
        self.row_count = reader.read_uint16()
        self.key_offset = reader.read_uint16()
        self.data_offset = reader.read_uint16()
        self.column_count = reader.read_uint8()
        self.unknown1 = reader.read_bytes(3)
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint32(self.type_id)
        writer.write_uint16(self.unknown0)
        writer.write_uint16(self.row_count)
        writer.write_uint16(self.key_offset)
        writer.write_uint16(self.data_offset)
        writer.write_uint8(self.column_count)
        writer.write_bytes(self.unknown1)


class _Node:
    SIZE: ClassVar[int] = 80

    """
    Ordering:
        # Node Header
        # Trimesh Header
        # ...
        # Face indices count array
        # Face indices offset array
        # Faces
        # Vertices
        # Inverted counter array
        # Children
        # Controllers
        # Controller Data
    """

    def __init__(
        self,
    ):
        self.header: _NodeHeader | None = _NodeHeader()
        self.trimesh: _TrimeshHeader | None = None
        self.skin: _SkinmeshHeader | None = None
        self.children_offsets: list[int] = []

        self.w_children = []
        self.w_controllers: list[_Controller] = []
        self.w_controller_data: list[float] = []

    def read(
        self,
        reader: BinaryReader,
        game: Game,
    ) -> _Node:
        self.header = _NodeHeader().read(reader)

        if self.header.type_id & MDLNodeFlags.MESH:
            self.trimesh = _TrimeshHeader().read(reader, game)

        if self.header.type_id & MDLNodeFlags.SKIN:
            self.skin = _SkinmeshHeader().read(reader)

        if self.trimesh:
            self.trimesh.read_extra(reader)
        if self.skin:
            self.skin.read_extra(reader)

        reader.seek(self.header.offset_to_children)
        self.children_offsets = [reader.read_uint32() for _ in range(self.header.children_count)]
        return self

    def write(
        self,
        writer: BinaryWriter,
        game: Game,
    ):
        assert self.header is not None
        self.header.write(writer)

        if self.trimesh:
            self.trimesh.write(writer, game)

        if self.skin:
            self.skin.write(writer)

        if self.trimesh:
            self._write_trimesh_data(writer)
        for child_offset in self.children_offsets:
            writer.write_uint32(child_offset)

        for controller in self.w_controllers:
            controller.write(writer)

        for controller_data in self.w_controller_data:
            writer.write_single(controller_data)

        if len(self.children_offsets) != self.header.children_count:
            msg = f"Number of child offsets in array does not match header count in {self.header.name_id} ({len(self.children_offsets)} vs {self.header.children_count})."
            raise ValueError(msg)

    def _write_trimesh_data(self, writer: BinaryWriter):
        assert self.trimesh is not None
        # NOTE:
        # Real-world K1/K2 MDL nodes store the face structs and vertex array as the core geometry payload.
        # The various index/count tables are not required for successful parsing in this codebase and
        # are not currently consumed by the reader. To keep offsets consistent, we write:
        #   - faces (full _Face structs)
        #   - vertices (Vector3 array)
        for face in self.trimesh.faces:
            face.write(writer)
        for vertex in self.trimesh.vertices:
            writer.write_vector3(vertex)

    def all_headers_size(
        self,
        game: Game,
    ) -> int:
        size = _Node.SIZE
        if self.trimesh:
            size += _TrimeshHeader.K1_SIZE if game == Game.K1 else _TrimeshHeader.K2_SIZE
        if self.skin:
            size += _SkinmeshHeader.SIZE
        return size

    def indices_counts_offset(
        self,
        game: Game,
    ) -> int:
        return self.all_headers_size(game)

    def indices_offsets_offset(
        self,
        game: Game,
    ) -> int:
        offset = self.indices_counts_offset(game)
        if self.trimesh:
            offset += len(self.trimesh.indices_counts) * 4
        return offset

    def inverted_counters_offset(
        self,
        game: Game,
    ) -> int:
        offset = self.indices_offsets_offset(game)
        if self.trimesh:
            offset += len(self.trimesh.indices_offsets) * 4
        return offset

    def indices_offset(
        self,
        game: Game,
    ) -> int:
        offset = self.inverted_counters_offset(game)
        if self.trimesh:
            offset += len(self.trimesh.inverted_counters) * 4
        return offset

    def vertices_offset(
        self,
        game: Game,
    ) -> int:
        # Vertices follow the face struct array.
        offset = self.faces_offset(game)
        if self.trimesh:
            offset += self.trimesh.faces_size()
        return offset

    def faces_offset(
        self,
        game: Game,
    ) -> int:
        # Faces begin immediately after all headers / index tables.
        # (Index tables are currently treated as optional and may be empty.)
        return self.indices_offset(game)

    def children_offsets_offset(
        self,
        game: Game,
    ) -> int:
        # Children offsets follow the vertex array.
        size = self.vertices_offset(game)
        if self.trimesh:
            size += self.trimesh.vertices_size()
        return size

    def children_offsets_size(
        self,
    ) -> int:
        assert self.header is not None
        return 4 * self.header.children_count

    def controllers_offset(
        self,
        game: Game,
    ) -> int:
        return self.children_offsets_offset(game) + self.children_offsets_size()

    def controllers_size(
        self,
    ) -> int:
        return _Controller.SIZE * len(self.w_controllers)

    def controller_data_offset(
        self,
        game: Game,
    ) -> int:
        return self.controllers_offset(game) + self.controllers_size()

    def controller_data_size(
        self,
    ) -> int:
        return len(self.w_controller_data) * 4

    def calc_size(
        self,
        game: Game,
    ) -> int:
        return self.controller_data_offset(game) + self.controller_data_size()


class _NodeHeader:
    SIZE = 80

    def __init__(
        self,
    ):
        self.type_id: int = 1
        self.name_id: int = 0
        self.node_id: int = 0
        self.padding0: int = 0
        self.offset_to_root: int = 0
        self.offset_to_parent: int = 0
        self.position: Vector3 = Vector3.from_null()
        self.orientation: Vector4 = Vector4.from_null()
        self.offset_to_children: int = 0
        self.children_count: int = 0
        self.children_count2: int = 0
        self.offset_to_controllers: int = 0
        self.controller_count: int = 0
        self.controller_count2: int = 0
        self.offset_to_controller_data: int = 0
        self.controller_data_length: int = 0
        self.controller_data_length2: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _NodeHeader:
        self.type_id = reader.read_uint16()
        self.node_id = reader.read_uint16()
        self.name_id = reader.read_uint16()
        self.padding0 = reader.read_uint16()
        self.offset_to_root = reader.read_uint32()
        self.offset_to_parent = reader.read_uint32()
        self.position = reader.read_vector3()
        self.orientation.w = reader.read_single()
        self.orientation.x = reader.read_single()
        self.orientation.y = reader.read_single()
        self.orientation.z = reader.read_single()
        self.offset_to_children = reader.read_uint32()
        self.children_count = reader.read_uint32()
        self.children_count2 = reader.read_uint32()
        self.offset_to_controllers = reader.read_uint32()
        self.controller_count = reader.read_uint32()
        self.controller_count2 = reader.read_uint32()
        self.offset_to_controller_data = reader.read_uint32()
        self.controller_data_length = reader.read_uint32()
        self.controller_data_length2 = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint16(self.type_id)
        writer.write_uint16(self.node_id)
        writer.write_uint16(self.name_id)
        writer.write_uint16(self.padding0)
        writer.write_uint32(self.offset_to_root)
        writer.write_uint32(self.offset_to_parent)
        writer.write_vector3(self.position)
        writer.write_single(self.orientation.w)
        writer.write_single(self.orientation.x)
        writer.write_single(self.orientation.y)
        writer.write_single(self.orientation.z)
        writer.write_uint32(self.offset_to_children)
        writer.write_uint32(self.children_count)
        writer.write_uint32(self.children_count2)
        writer.write_uint32(self.offset_to_controllers)
        writer.write_uint32(self.controller_count)
        writer.write_uint32(self.controller_count2)
        writer.write_uint32(self.offset_to_controller_data)
        writer.write_uint32(self.controller_data_length)
        writer.write_uint32(self.controller_data_length2)


class _MDXDataFlags:
    VERTEX: Literal[0x0001] = 0x0001
    TEXTURE1: Literal[0x0002] = 0x0002
    TEXTURE2: Literal[0x0004] = 0x0004
    NORMAL: Literal[0x0020] = 0x0020
    BUMPMAP: Literal[0x0080] = 0x0080


class _TrimeshHeader:
    # NOTE: These sizes reflect the actual number of bytes written/read by `_TrimeshHeader.write/read`.
    # Historically these constants were out-of-sync, which caused MDLBinaryWriter node offset drift
    # (bad child offsets, OOB seeks) during roundtrips.
    K1_SIZE: Literal[361] = 361
    K2_SIZE: Literal[377] = 377

    K1_FUNCTION_POINTER0: Literal[4216656] = 4216656
    K2_FUNCTION_POINTER0: Literal[4216880] = 4216880
    K1_SKIN_FUNCTION_POINTER0: Literal[4216592] = 4216592
    K2_SKIN_FUNCTION_POINTER0: Literal[4216816] = 4216816
    K1_DANGLY_FUNCTION_POINTER0: Literal[4216640] = 4216640
    K2_DANGLY_FUNCTION_POINTER0: Literal[4216864] = 4216864

    K1_FUNCTION_POINTER1: Literal[4216672] = 4216672
    K2_FUNCTION_POINTER1: Literal[4216896] = 4216896
    K1_SKIN_FUNCTION_POINTER1: Literal[4216608] = 4216608
    K2_SKIN_FUNCTION_POINTER1: Literal[4216832] = 4216832
    K1_DANGLY_FUNCTION_POINTER1: Literal[4216624] = 4216624
    K2_DANGLY_FUNCTION_POINTER1: Literal[4216848] = 4216848

    def __init__(
        self,
    ):
        self.function_pointer0: int = 0
        self.function_pointer1: int = 0
        self.offset_to_faces: int = 0
        self.faces_count: int = 0
        self.faces_count2: int = 0
        self.bounding_box_min: Vector3 = Vector3.from_null()
        self.bounding_box_max: Vector3 = Vector3.from_null()
        self.radius: float = 0.0
        self.average: Vector3 = Vector3.from_null()
        self.diffuse: Vector3 = Vector3.from_null()
        self.ambient: Vector3 = Vector3.from_null()
        self.transparency_hint: int = 0
        self.texture1: str = ""
        self.texture2: str = ""
        self.unknown0: bytes = b"\x00" * 24  # TODO: what is this?
        self.offset_to_indices_counts: int = 0
        self.indices_counts_count: int = 0
        self.indices_counts_count2: int = 0
        self.offset_to_indices_offset: int = 0
        self.indices_offsets_count: int = 0
        self.indices_offsets_count2: int = 0
        self.offset_to_counters: int = 0
        self.counters_count: int = 0
        self.counters_count2: int = 0
        self.unknown1: bytes = b"\xff\xff\xff\xff" + b"\xff\xff\xff\xff" + b"\x00\x00\x00\x00"  # TODO: what is this?
        self.saber_unknowns: bytes = b"\x00" * 8  # TODO: what is this?
        self.unknown2: int = 0  # TODO: what is this?
        self.uv_direction: Vector2 = Vector2.from_null()
        self.uv_jitter: float = 0.0
        self.uv_speed: float = 0.0
        self.mdx_data_size: int = 0
        self.mdx_data_bitmap: int = 0
        self.mdx_vertex_offset: int = 0  # Offset to vertex data in MDX (0x0001 bitmap flag)
        self.mdx_normal_offset: int = 0  # Offset to normal data in MDX (0x0020 bitmap flag)
        self.mdx_color_offset: int = 0xFFFFFFFF  # Offset to color data in MDX (not used in bitmap)
        self.mdx_texture1_offset: int = 0  # Offset to primary UV data in MDX (0x0002 bitmap flag)
        self.mdx_texture2_offset: int = 0  # Offset to secondary UV data in MDX (0x0004 bitmap flag)
        self.mdx_unknown_offset: int = 0xFFFFFFFF  # Offset to unknown data in MDX (always -1)
        self.mdx_uv3_offset: int = 0xFFFFFFFF  # Offset to tertiary UV data in MDX (always -1)
        self.mdx_uv4_offset: int = 0xFFFFFFFF  # Offset to quaternary UV data in MDX (always -1)
        self.mdx_tangent_offset: int = 0xFFFFFFFF  # Offset to tangent/binormal data in MDX (36 bytes, weighted normals)
        self.mdx_unused_struct1_offset: int = 0xFFFFFFFF  # Offset to unused MDX structure 1 (always -1)
        self.mdx_unused_struct2_offset: int = 0xFFFFFFFF  # Offset to unused MDX structure 2 (always -1)
        self.mdx_unused_struct3_offset: int = 0xFFFFFFFF  # Offset to unused MDX structure 3 (always -1)
        self.vertex_count: int = 0
        self.texture_count: int = 1
        self.has_lightmap: int = 0
        self.rotate_texture: int = 0
        self.background: int = 0
        self.has_shadow: int = 0
        self.beaming: int = 0
        self.render: int = 0
        self.dirt_enabled: int = 0
        self.dirt_texture: str = ""
        self.unknown9: int = 0  # TODO: what is this?
        self.dirt_coordinate_space: int = 0  # UV coordinate space for dirt texture overlay
        self.total_area: float = 0.0
        self.unknown11: int = 0  # Reserved field (part of L[3] sequence after total_area) - always 0
        self.unknown12: int = 0  # Reserved field (K2 only, part of L[3] sequence after total_area) - always 0
        self.unknown13: int = 0  # Reserved field (K2 only, part of L[3] sequence after total_area) - always 0
        self.mdx_data_offset: int = 0
        self.vertices_offset: int = 0

        self.faces: list[_Face] = []
        self.vertices: list[Vector3] = []
        self.indices_offsets: list[int] = []
        self.indices_counts: list[int] = []
        self.inverted_counters: list[int] = []

    def read(
        self,
        reader: BinaryReader,
        game: Game,
    ) -> _TrimeshHeader:
        start_pos = reader.position()
        self.function_pointer0 = reader.read_uint32()
        self.function_pointer1 = reader.read_uint32()
        self.offset_to_faces = reader.read_uint32()
        self.faces_count = reader.read_uint32()
        self.faces_count2 = reader.read_uint32()
        self.bounding_box_min = reader.read_vector3()
        self.bounding_box_max = reader.read_vector3()
        self.radius = reader.read_single()
        self.average = reader.read_vector3()
        self.diffuse = reader.read_vector3()
        self.ambient = reader.read_vector3()
        self.transparency_hint = reader.read_uint32()
        self.texture1 = reader.read_terminated_string("\0", 32)
        self.texture2 = reader.read_terminated_string("\0", 32)
        self.unknown0 = reader.read_bytes(24)  # TODO: what is this?
        self.offset_to_indices_counts = reader.read_uint32()
        self.indices_counts_count = reader.read_uint32()
        self.indices_counts_count2 = reader.read_uint32()
        self.offset_to_indices_offset = reader.read_uint32()
        self.indices_offsets_count = reader.read_uint32()
        self.indices_offsets_count2 = reader.read_uint32()
        self.offset_to_counters = reader.read_uint32()
        self.counters_count = reader.read_uint32()
        self.counters_count2 = reader.read_uint32()
        self.unknown1 = reader.read_bytes(12)  # -1 -1 0  TODO: what is this?
        self.saber_unknowns = reader.read_bytes(8)  # 3 0 0 0 0 0 0 0 TODO: what is this?
        self.unknown2 = reader.read_uint32()  # TODO: what is this?
        self.uv_direction = reader.read_vector2()
        self.uv_jitter = reader.read_single()
        self.uv_speed = reader.read_single()
        self.mdx_data_size = reader.read_uint32()
        self.mdx_data_bitmap = reader.read_uint32()
        self.mdx_vertex_offset = reader.read_uint32()
        self.mdx_normal_offset = reader.read_uint32()
        self.mdx_color_offset = reader.read_uint32()
        self.mdx_texture1_offset = reader.read_uint32()
        self.mdx_texture2_offset = reader.read_uint32()
        self.mdx_unknown_offset = reader.read_uint32()  # Offset to unknown data in MDX (always -1)
        self.mdx_uv3_offset = reader.read_uint32()  # Offset to tertiary UV data in MDX (always -1)
        self.mdx_uv4_offset = reader.read_uint32()  # Offset to quaternary UV data in MDX (always -1)
        self.mdx_tangent_offset = reader.read_uint32()  # Offset to tangent/binormal data in MDX (36 bytes, weighted normals)
        # K2 adds two extra u32s here (total +8 bytes) which accounts for K2_SIZE - K1_SIZE.
        self.mdx_unused_struct1_offset = reader.read_uint32()  # Offset to unused MDX structure 1 (often -1)
        if game == Game.K2:
            self.mdx_unused_struct2_offset = reader.read_uint32()  # Offset to unused MDX structure 2 (often -1)
            self.mdx_unused_struct3_offset = reader.read_uint32()  # Offset to unused MDX structure 3 (often -1)
        else:
            self.mdx_unused_struct2_offset = 0xFFFFFFFF
            self.mdx_unused_struct3_offset = 0xFFFFFFFF
        self.vertex_count = reader.read_uint16()
        self.texture_count = reader.read_uint16()
        self.has_lightmap = reader.read_uint8()
        self.rotate_texture = reader.read_uint8()
        self.background = reader.read_uint8()
        self.has_shadow = reader.read_uint8()
        self.beaming = reader.read_uint8()
        self.render = reader.read_uint8()
        self.dirt_enabled = reader.read_uint8()  # Dirt/weathering overlay texture enabled
        self.dirt_texture = reader.read_terminated_string("\0", 32)  # Dirt texture name
        self.unknown9 = reader.read_uint8()  # TODO: what is this?
        self.dirt_coordinate_space = reader.read_uint8()  # UV coordinate space for dirt texture overlay
        self.total_area = reader.read_single()
        self.unknown11 = reader.read_uint32()  # Reserved field (part of L[3] sequence after total_area) - always 0
        # Trimesh header size differs between K1 and K2 by +8 bytes.
        # Use the model's game version (from the file header) rather than volatile function pointers.
        if game == Game.K2:
            self.unknown12 = reader.read_uint32()  # Reserved (K2 only) - usually 0
            self.unknown13 = reader.read_uint32()  # Reserved (K2 only) - usually 0
        self.mdx_data_offset = reader.read_uint32()
        self.vertices_offset = reader.read_uint32()

        # Some node types (notably K1 skin meshes) have layout quirks in the tail of the trimesh header.
        # To keep parsing stable across real-world files, re-read the key tail fields from their fixed
        # K1 offsets, without disturbing the caller's stream position.
        if game == Game.K1:
            end_pos = reader.position()
            # K1 tail layout (K1_SIZE = 332):
            # - vertex_count: u2 @ +304
            # - texture_count: u2 @ +306
            # - mdx_data_offset: u4 @ +324
            # - vertices_offset: u4 @ +328
            reader.seek(start_pos + 304)
            self.vertex_count = reader.read_uint16()
            self.texture_count = reader.read_uint16()
            reader.seek(start_pos + 324)
            self.mdx_data_offset = reader.read_uint32()
            self.vertices_offset = reader.read_uint32()
            reader.seek(end_pos)
        return self

    def read_extra(
        self,
        reader: BinaryReader,
    ):
        # Vertices
        if self.vertices_offset not in (0, 0xFFFFFFFF) and self.vertex_count > 0:
            vertices_bytes = self.vertex_count * 12  # Vector3 of floats
            if self.vertices_offset <= reader.size() and (self.vertices_offset + vertices_bytes) <= reader.size():
                reader.seek(self.vertices_offset)
                self.vertices = [reader.read_vector3() for _ in range(self.vertex_count)]

        # Faces
        if self.offset_to_faces not in (0, 0xFFFFFFFF) and self.faces_count > 0:
            faces_bytes = self.faces_count * _Face.SIZE
            if self.offset_to_faces <= reader.size() and (self.offset_to_faces + faces_bytes) <= reader.size():
                reader.seek(self.offset_to_faces)
                self.faces = [_Face().read(reader) for _ in range(self.faces_count)]

    def write(
        self,
        writer: BinaryWriter,
        game: Game,
    ):
        writer.write_uint32(self.function_pointer0)
        writer.write_uint32(self.function_pointer1)
        writer.write_uint32(self.offset_to_faces)
        writer.write_uint32(self.faces_count)
        writer.write_uint32(self.faces_count2)
        writer.write_vector3(self.bounding_box_min)
        writer.write_vector3(self.bounding_box_max)
        writer.write_single(self.radius)
        writer.write_vector3(self.average)
        writer.write_vector3(self.diffuse)
        writer.write_vector3(self.ambient)
        writer.write_uint32(self.transparency_hint)
        writer.write_string(self.texture1, string_length=32, encoding="ascii")
        writer.write_string(self.texture2, string_length=32, encoding="ascii")
        writer.write_bytes(self.unknown0)  # TODO: what is this?
        writer.write_uint32(self.offset_to_indices_counts)
        writer.write_uint32(self.indices_counts_count)
        writer.write_uint32(self.indices_counts_count2)
        writer.write_uint32(self.offset_to_indices_offset)
        writer.write_uint32(self.indices_offsets_count)
        writer.write_uint32(self.indices_offsets_count2)
        writer.write_uint32(self.offset_to_counters)
        writer.write_uint32(self.counters_count)
        writer.write_uint32(self.counters_count2)
        writer.write_bytes(self.unknown1)  # TODO: what is this?
        writer.write_bytes(self.saber_unknowns)  # TODO: what is this?
        writer.write_uint32(self.unknown2)  # TODO: what is this?
        writer.write_vector2(self.uv_direction)
        writer.write_single(self.uv_jitter)
        writer.write_single(self.uv_speed)
        writer.write_uint32(self.mdx_data_size)
        writer.write_uint32(self.mdx_data_bitmap)
        writer.write_uint32(self.mdx_vertex_offset)
        writer.write_uint32(self.mdx_normal_offset)
        writer.write_uint32(self.mdx_color_offset)
        writer.write_uint32(self.mdx_texture1_offset)
        writer.write_uint32(self.mdx_texture2_offset)
        writer.write_uint32(self.mdx_unknown_offset)  # Offset to unknown data in MDX (always -1)
        writer.write_uint32(self.mdx_uv3_offset)  # Offset to tertiary UV data in MDX (always -1)
        writer.write_uint32(self.mdx_uv4_offset)  # Offset to quaternary UV data in MDX (always -1)
        writer.write_uint32(self.mdx_tangent_offset)  # Offset to tangent/binormal data in MDX (36 bytes, weighted normals)
        writer.write_uint32(self.mdx_unused_struct1_offset)  # Offset to unused MDX structure 1 (often -1)
        if game == Game.K2:
            writer.write_uint32(self.mdx_unused_struct2_offset)  # Offset to unused MDX structure 2 (often -1)
            writer.write_uint32(self.mdx_unused_struct3_offset)  # Offset to unused MDX structure 3 (often -1)
        writer.write_uint16(self.vertex_count)
        writer.write_uint16(self.texture_count)
        writer.write_uint8(self.has_lightmap)
        writer.write_uint8(self.rotate_texture)
        writer.write_uint8(self.background)
        writer.write_uint8(self.has_shadow)
        writer.write_uint8(self.beaming)
        writer.write_uint8(self.render)
        writer.write_uint8(self.dirt_enabled)  # Dirt/weathering overlay texture enabled
        # Dirt texture name: fixed-size 32-byte char array (null-padded).
        writer.write_string(self.dirt_texture, string_length=32, padding="\0")
        writer.write_uint8(self.unknown9)  # TODO: what is this?
        writer.write_uint8(self.dirt_coordinate_space)  # UV coordinate space for dirt texture overlay
        writer.write_single(self.total_area)
        writer.write_uint32(self.unknown11)  # Reserved field (part of L[3] sequence after total_area) - always 0
        if game == Game.K2:
            writer.write_uint32(self.unknown12)  # Reserved field (K2 only, part of L[3] sequence after total_area) - always 0
            writer.write_uint32(self.unknown13)  # Reserved field (K2 only, part of L[3] sequence after total_area) - always 0
        writer.write_uint32(self.mdx_data_offset)
        writer.write_uint32(self.vertices_offset)

    def header_size(
        self,
        game: Game,
    ) -> int:
        return _TrimeshHeader.K1_SIZE if game == Game.K1 else _TrimeshHeader.K2_SIZE

    def faces_size(
        self,
    ) -> int:
        return len(self.faces) * _Face.SIZE

    def vertices_size(
        self,
    ) -> int:
        return len(self.vertices) * 12


class _DanglymeshHeader:
    def __init__(
        self,
    ):
        self.offset_to_contraints: int = 0
        self.constraints_count: int = 0
        self.constraints_count2: int = 0
        self.displacement: float = 0.0
        self.tightness: float = 0.0
        self.period: float = 0.0
        self.unknown0: int = 0  # TODO: what is this?

    def read(
        self,
        reader: BinaryReader,
    ) -> _DanglymeshHeader:
        self.offset_to_contraints = reader.read_uint32()
        self.constraints_count = reader.read_uint32()
        self.constraints_count2 = reader.read_uint32()
        self.displacement = reader.read_single()
        self.tightness = reader.read_single()
        self.period = reader.read_single()
        self.unknown0 = reader.read_uint32()  # TODO: what is this?
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint32(self.offset_to_contraints)
        writer.write_uint32(self.constraints_count)
        writer.write_uint32(self.constraints_count2)
        writer.write_single(self.displacement)
        writer.write_single(self.tightness)
        writer.write_single(self.period)
        writer.write_uint32(self.unknown0)  # TODO: what is this?


class _SkinmeshHeader:
    SIZE: ClassVar[int] = 100

    def __init__(
        self,
    ):
        self.unknown2: int = 0  # TODO: what is this?
        self.unknown3: int = 0  # TODO: what is this?
        self.unknown4: int = 0  # TODO: what is this?
        self.offset_to_mdx_weights: int = 0
        self.offset_to_mdx_bones: int = 0
        self.offset_to_bonemap: int = 0
        self.bonemap_count: int = 0
        self.offset_to_qbones: int = 0
        self.qbones_count: int = 0
        self.qbones_count2: int = 0
        self.offset_to_tbones: int = 0
        self.tbones_count: int = 0
        self.tbones_count2: int = 0
        self.offset_to_unknown0: int = 0
        self.unknown0_count: int = 0  # TODO: what is this?
        self.unknown0_count2: int = 0  # TODO: what is this?
        self.bones: tuple[int, ...] = tuple(-1 for _ in range(16))
        self.unknown1: int = 0  # TODO: what is this?

        self.bonemap: list[int] = []
        self.tbones: list[Vector3] = []
        self.qbones: list[Vector4] = []

    def read(
        self,
        reader: BinaryReader,
    ) -> _SkinmeshHeader:
        self.unknown2 = reader.read_int32()  # TODO: what is this?
        self.unknown3 = reader.read_int32()  # TODO: what is this?
        self.unknown4 = reader.read_int32()  # TODO: what is this?
        self.offset_to_mdx_weights = reader.read_uint32()
        self.offset_to_mdx_bones = reader.read_uint32()
        self.offset_to_bonemap = reader.read_uint32()
        self.bonemap_count = reader.read_uint32()
        self.offset_to_qbones = reader.read_uint32()
        self.qbones_count = reader.read_uint32()
        self.qbones_count2 = reader.read_uint32()
        self.offset_to_tbones = reader.read_uint32()
        self.tbones_count = reader.read_uint32()
        self.tbones_count2 = reader.read_uint32()
        self.offset_to_unknown0 = reader.read_uint32()
        self.unknown0_count = reader.read_uint32()  # TODO: what is this?
        self.unknown0_count2 = reader.read_uint32()  # TODO: what is this?
        self.bones = tuple(reader.read_uint16() for _ in range(16))
        self.unknown1 = reader.read_uint32()  # TODO: what is this?
        return self

    def read_extra(
        self,
        reader: BinaryReader,
    ):
        # All offsets in MDL are relative to the MDL data section. Some models (or partially read headers)
        # may contain invalid offsets; guard against OOB seeks to keep parsing robust.
        if self.offset_to_bonemap not in (0, 0xFFFFFFFF) and self.bonemap_count > 0:
            # bonemap is stored as floats in some implementations; keep current behavior but validate bounds.
            bonemap_bytes = self.bonemap_count * 4
            if self.offset_to_bonemap <= reader.size() and (self.offset_to_bonemap + bonemap_bytes) <= reader.size():
                reader.seek(self.offset_to_bonemap)
                self.bonemap = [reader.read_single() for _ in range(self.bonemap_count)]

        if self.offset_to_tbones not in (0, 0xFFFFFFFF) and self.tbones_count > 0:
            tbones_bytes = self.tbones_count * 12
            if self.offset_to_tbones <= reader.size() and (self.offset_to_tbones + tbones_bytes) <= reader.size():
                reader.seek(self.offset_to_tbones)
                self.tbones = [reader.read_vector3() for _ in range(self.tbones_count)]

        if self.offset_to_qbones not in (0, 0xFFFFFFFF) and self.qbones_count > 0:
            qbones_bytes = self.qbones_count * 16
            if self.offset_to_qbones <= reader.size() and (self.offset_to_qbones + qbones_bytes) <= reader.size():
                reader.seek(self.offset_to_qbones)
                self.qbones = [reader.read_vector4() for _ in range(self.qbones_count)]

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_int32(self.unknown2)  # TODO: what is this?
        writer.write_int32(self.unknown3)  # TODO: what is this?
        writer.write_int32(self.unknown4)  # TODO: what is this?
        writer.write_uint32(self.offset_to_mdx_weights)
        writer.write_uint32(self.offset_to_mdx_bones)
        writer.write_uint32(self.offset_to_bonemap)
        writer.write_uint32(self.bonemap_count)
        writer.write_uint32(self.offset_to_qbones)
        writer.write_uint32(self.qbones_count)
        writer.write_uint32(self.qbones_count2)
        writer.write_uint32(self.offset_to_tbones)
        writer.write_uint32(self.tbones_count)
        writer.write_uint32(self.tbones_count2)
        writer.write_uint32(self.offset_to_unknown0)
        writer.write_uint32(self.unknown0_count)  # TODO: what is this?
        writer.write_uint32(self.unknown0_count2)  # TODO: what is this?
        for i in range(16):
            writer.write_uint16(self.bones[i])
        writer.write_uint32(self.unknown1)  # TODO: what is this?


class _SaberHeader:
    def __init__(
        self,
    ):
        self.offset_to_vertices: int = 0
        self.offset_to_texcoords: int = 0
        self.offset_to_normals: int = 0
        self.unknown0: int = 0  # TODO: what is this?

    def read(
        self,
        reader: BinaryReader,
    ) -> _SaberHeader:
        self.offset_to_vertices = reader.read_uint32()
        self.offset_to_texcoords = reader.read_uint32()
        self.offset_to_normals = reader.read_uint32()
        self.unknown0 = reader.read_uint32()  # TODO: what is this?
        self.unknown1 = reader.read_uint32()  # TODO: what is this?
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint32(self.offset_to_vertices)
        writer.write_uint32(self.offset_to_texcoords)
        writer.write_uint32(self.offset_to_normals)
        writer.write_uint32(self.unknown0)  # TODO: what is this?


class _LightHeader:
    def __init__(
        self,
    ):
        self.offset_to_unknown0: int = 0
        self.unknown0_count: int = 0
        self.unknown0_count2: int = 0
        self.offset_to_flare_sizes: int = 0
        self.flare_sizes_count: int = 0
        self.flare_sizes_count2: int = 0
        self.offset_to_flare_positions: int = 0
        self.flare_positions_count: int = 0
        self.flare_positions_count2: int = 0
        self.offset_to_flare_colors: int = 0
        self.flare_colors_count: int = 0
        self.flare_colors_count2: int = 0
        self.offset_to_flare_textures: int = 0
        self.flare_textures_count: int = 0
        self.flare_radius: float = 0.0
        self.light_priority: int = 0
        self.ambient_only: int = 0
        self.dynamic_type: int = 0
        self.affect_dynamic: int = 0
        self.shadow: int = 0
        self.flare: int = 0
        self.fading_light: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _LightHeader:
        self.offset_to_unknown0 = reader.read_uint32()
        self.unknown0_count = reader.read_uint32()  # TODO: what is this?
        self.unknown0_count2 = reader.read_uint32()  # TODO: what is this?
        self.offset_to_flare_sizes = reader.read_uint32()
        self.flare_sizes_count = reader.read_uint32()
        self.flare_sizes_count2 = reader.read_uint32()
        self.offset_to_flare_positions = reader.read_uint32()
        self.flare_positions_count = reader.read_uint32()
        self.flare_positions_count2 = reader.read_uint32()
        self.offset_to_flare_colors = reader.read_uint32()
        self.flare_colors_count = reader.read_uint32()
        self.flare_colors_count2 = reader.read_uint32()
        self.offset_to_flare_textures = reader.read_uint32()
        self.flare_textures_count = reader.read_uint32()
        self.flare_colors_count2 = reader.read_uint32()
        self.flare_radius = reader.read_single()
        self.light_priority = reader.read_uint32()
        self.ambient_only = reader.read_uint32()
        self.dynamic_type = reader.read_uint32()
        self.affect_dynamic = reader.read_uint32()
        self.shadow = reader.read_uint32()
        self.flare = reader.read_uint32()
        self.fading_light = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_uint32(self.offset_to_unknown0)  # TODO: what is this?
        writer.write_uint32(self.unknown0_count)  # TODO: what is this?
        writer.write_uint32(self.unknown0_count2)  # TODO: what is this?
        writer.write_uint32(self.offset_to_flare_sizes)
        writer.write_uint32(self.flare_sizes_count)
        writer.write_uint32(self.flare_sizes_count2)
        writer.write_uint32(self.offset_to_flare_positions)
        writer.write_uint32(self.flare_positions_count)
        writer.write_uint32(self.flare_positions_count2)
        writer.write_uint32(self.offset_to_flare_colors)
        writer.write_uint32(self.flare_colors_count)
        writer.write_uint32(self.flare_colors_count2)
        writer.write_uint32(self.offset_to_flare_textures)
        writer.write_uint32(self.flare_textures_count)
        writer.write_uint32(self.flare_colors_count2)
        writer.write_single(self.flare_radius)
        writer.write_uint32(self.light_priority)
        writer.write_uint32(self.ambient_only)
        writer.write_uint32(self.dynamic_type)
        writer.write_uint32(self.affect_dynamic)
        writer.write_uint32(self.shadow)
        writer.write_uint32(self.flare)
        writer.write_uint32(self.fading_light)


class _EmitterHeader:
    def __init__(
        self,
    ):
        self.dead_space: float = 0.0
        self.blast_radius: float = 0.0
        self.blast_length: float = 0.0
        self.branch_count: int = 0
        self.smoothing: float = 0.0
        self.grid: Vector2 = Vector2.from_null()
        self.update: str = ""
        self.render: str = ""
        self.blend: str = ""
        self.texture: str = ""
        self.chunk_name: str = ""
        self.twosided_texture: int = 0
        self.loop: int = 0
        self.render_order: int = 0
        self.frame_blending: int = 0
        self.depth_texture: str = ""
        self.unknown0: int = 0
        self.flags: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _EmitterHeader:
        self.dead_space = reader.read_single()
        self.blast_radius = reader.read_single()
        self.blast_length = reader.read_single()
        self.branch_count = reader.read_uint32()
        self.smoothing = reader.read_single()
        self.grid = reader.read_vector2()
        self.update = reader.read_terminated_string("\0", 32)
        self.render = reader.read_terminated_string("\0", 32)
        self.blend = reader.read_terminated_string("\0", 32)
        self.texture = reader.read_terminated_string("\0", 32)
        self.chunk_name = reader.read_terminated_string("\0", 32)
        self.twosided_texture = reader.read_uint32()
        self.loop = reader.read_uint32()
        self.render_order = reader.read_uint32()
        self.frame_blending = reader.read_uint32()
        self.depth_texture = reader.read_terminated_string("\0", 32)
        self.unknown0 = reader.read_uint8()
        self.flags = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_single(self.dead_space)
        writer.write_single(self.blast_radius)
        writer.write_single(self.blast_length)
        writer.write_uint32(self.branch_count)
        writer.write_single(self.smoothing)
        writer.write_vector2(self.grid)
        writer.write_string(self.update, string_length=32, encoding="ascii")
        writer.write_string(self.render, string_length=32, encoding="ascii")
        writer.write_string(self.blend, string_length=32, encoding="ascii")
        writer.write_string(self.texture, string_length=32, encoding="ascii")
        writer.write_string(self.chunk_name, string_length=32, encoding="ascii")
        writer.write_uint32(self.twosided_texture)
        writer.write_uint32(self.loop)
        writer.write_uint32(self.render_order)
        writer.write_uint32(self.frame_blending)
        writer.write_string(self.depth_texture, string_length=32, encoding="ascii")
        writer.write_uint8(self.unknown0)
        writer.write_uint32(self.flags)


class _ReferenceHeader:
    def __init__(
        self,
    ):
        self.model: str = ""
        self.reattachable: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _ReferenceHeader:
        self.model = reader.read_terminated_string("\0", 32)
        self.reattachable = reader.read_uint32()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_string(self.model, string_length=32, encoding="ascii")
        writer.write_uint32(self.reattachable)


class _Face:
    SIZE = 32

    def __init__(
        self,
    ):
        self.normal: Vector3 = Vector3.from_null()
        self.plane_coefficient: float = 0.0
        self.material: int = 0
        self.adjacent1: int = 0
        self.adjacent2: int = 0
        self.adjacent3: int = 0
        self.vertex1: int = 0
        self.vertex2: int = 0
        self.vertex3: int = 0

    def read(
        self,
        reader: BinaryReader,
    ) -> _Face:
        self.normal = reader.read_vector3()
        self.plane_coefficient = reader.read_single()
        self.material = reader.read_uint32()
        self.adjacent1 = reader.read_uint16()
        self.adjacent2 = reader.read_uint16()
        self.adjacent3 = reader.read_uint16()
        self.vertex1 = reader.read_uint16()
        self.vertex2 = reader.read_uint16()
        self.vertex3 = reader.read_uint16()
        return self

    def write(
        self,
        writer: BinaryWriter,
    ):
        writer.write_vector3(self.normal)
        writer.write_single(self.plane_coefficient)
        writer.write_uint32(self.material)
        writer.write_uint16(self.adjacent1)
        writer.write_uint16(self.adjacent2)
        writer.write_uint16(self.adjacent3)
        writer.write_uint16(self.vertex1)
        writer.write_uint16(self.vertex2)
        writer.write_uint16(self.vertex3)


# Geometry calculation utilities
# Reference: vendor/mdlops/MDLOpsM.pm:463-520

def _calculate_face_area(v1: Vector3, v2: Vector3, v3: Vector3) -> float:
    """Calculate a triangle face's surface area using Heron's formula.
    
    Args:
    ----
        v1: First vertex position
        v2: Second vertex position
        v3: Third vertex position
    
    Returns:
    -------
        The surface area of the triangle
    
    References:
    ----------
        vendor/mdlops/MDLOpsM.pm:465-488 - facearea() function
        Formula: Uses Heron's formula with semi-perimeter
    """
    # Calculate edge lengths (mdlops:471-482)
    import math
    
    a = math.sqrt(
        (v1.x - v2.x) ** 2 +
        (v1.y - v2.y) ** 2 +
        (v1.z - v2.z) ** 2
    )
    
    b = math.sqrt(
        (v1.x - v3.x) ** 2 +
        (v1.y - v3.y) ** 2 +
        (v1.z - v3.z) ** 2
    )
    
    c = math.sqrt(
        (v2.x - v3.x) ** 2 +
        (v2.y - v3.y) ** 2 +
        (v2.z - v3.z) ** 2
    )
    
    # Semi-perimeter (mdlops:483)
    s = (a + b + c) / 2.0
    
    # Heron's formula (mdlops:485-487)
    inter = s * (s - a) * (s - b) * (s - c)
    return math.sqrt(inter) if inter > 0.0 else 0.0


def _decompress_quaternion(compressed: int) -> Vector4:
    """Decompress a packed quaternion from a 32-bit integer.
    
    KotOR uses compressed quaternions for orientation controllers to save space.
    The compression packs X, Y, Z components into 11, 11, and 10 bits respectively,
    with W calculated from the constraint that |q| = 1.
    
    Args:
    ----
        compressed: 32-bit packed quaternion value
    
    Returns:
    -------
        Vector4: Decompressed quaternion (x, y, z, w)
    
    References:
    ----------
        vendor/kotorblender/io_scene_kotor/format/mdl/reader.py:850-868
        Formula: X uses bits 0-10 (11 bits), Y uses bits 11-21 (11 bits),
                 Z uses bits 22-31 (10 bits), W computed from magnitude
    
    Notes:
    -----
        The compressed format maps values to [-1, 1] range:
        - X: 11 bits -> [0, 2047] -> mapped to [-1, 1]
        - Y: 11 bits -> [0, 2047] -> mapped to [-1, 1]  
        - Z: 10 bits -> [0, 1023] -> mapped to [-1, 1]
        - W: Computed from sqrt(1 - x² - y² - z²) if mag < 1, else 0
    """
    # Extract components from packed integer (kotorblender:855-858)
    # X component: bits 0-10 (11 bits, mask 0x7FF = 2047)
    x = ((compressed & 0x7FF) / 1023.0) - 1.0
    
    # Y component: bits 11-21 (11 bits, shift 11 then mask 0x7FF)
    y = (((compressed >> 11) & 0x7FF) / 1023.0) - 1.0
    
    # Z component: bits 22-31 (10 bits, shift 22, max value 1023)
    z = ((compressed >> 22) / 511.0) - 1.0
    
    # Calculate W from quaternion unit constraint (kotorblender:859-863)
    mag2 = x * x + y * y + z * z
    if mag2 < 1.0:
        import math
        w = math.sqrt(1.0 - mag2)
    else:
        w = 0.0
    
    return Vector4(x, y, z, w)


def _compress_quaternion(quat: Vector4) -> int:
    """Compress a quaternion into a 32-bit integer.
    
    Inverse of _decompress_quaternion. Packs X, Y, Z components into a single
    32-bit value. The W component is not stored as it can be recomputed from
    the quaternion unit constraint.
    
    Args:
    ----
        quat: Quaternion to compress (x, y, z, w)
    
    Returns:
    -------
        int: 32-bit packed quaternion value
    
    References:
    ----------
        vendor/kotorblender/io_scene_kotor/format/mdl/reader.py:850-868 (decompression)
        Inverse operation derived from decompression algorithm
    
    Notes:
    -----
        Values are clamped to [-1, 1] range before packing to prevent overflow.
    """
    
    # Clamp values to valid range
    x = max(-1.0, min(1.0, quat.x))
    y = max(-1.0, min(1.0, quat.y))
    z = max(-1.0, min(1.0, quat.z))
    
    # Map from [-1, 1] to integer ranges and pack
    # X: [-1, 1] -> [0, 2047] (11 bits)
    x_packed = int((x + 1.0) * 1023.0) & 0x7FF
    
    # Y: [-1, 1] -> [0, 2047] (11 bits)
    y_packed = int((y + 1.0) * 1023.0) & 0x7FF
    
    # Z: [-1, 1] -> [0, 1023] (10 bits)  
    z_packed = int((z + 1.0) * 511.0) & 0x3FF
    
    # Pack into single 32-bit integer
    return x_packed | (y_packed << 11) | (z_packed << 22)


def _calculate_face_normal(v1: Vector3, v2: Vector3, v3: Vector3) -> tuple[Vector3, float]:
    """Calculate a triangle face's normalized normal vector and plane distance.
    
    The normal vector is computed using the cross product of two edge vectors,
    then normalized. The plane distance is the dot product of the normal with
    any vertex position.
    
    Args:
    ----
        v1: First vertex position
        v2: Second vertex position
        v3: Third vertex position
    
    Returns:
    -------
        tuple: (normalized normal vector, plane distance from origin)
    
    References:
    ----------
        vendor/mdlops/MDLOpsM.pm:492-520 - facenormal() function
        Formula: Cross product of edges, then normalize
    """
    import math
    
    # Calculate unnormalized normal using cross product formula (mdlops:497-500)
    # This is the determinant form of cross product: (v2-v3) × (v1-v3)
    normal_x = (
        v1.y * (v2.z - v3.z) +
        v2.y * (v3.z - v1.z) +
        v3.y * (v1.z - v2.z)
    )
    
    normal_y = (
        v1.z * (v2.x - v3.x) +
        v2.z * (v3.x - v1.x) +
        v3.z * (v1.x - v2.x)
    )
    
    normal_z = (
        v1.x * (v2.y - v3.y) +
        v2.x * (v3.y - v1.y) +
        v3.x * (v1.y - v2.y)
    )
    
    # Normalize the normal vector (mdlops:502-509)
    length = math.sqrt(normal_x ** 2 + normal_y ** 2 + normal_z ** 2)
    
    if length > 0.0:
        normal_x /= length
        normal_y /= length
        normal_z /= length
    
    normal = Vector3(normal_x, normal_y, normal_z)
    
    # Calculate plane distance (dot product with vertex) (mdlops:511)
    plane_distance = -(normal_x * v1.x + normal_y * v1.y + normal_z * v1.z)
    
    return normal, plane_distance


def _calculate_tangent_space(
    v0: Vector3,
    v1: Vector3,
    v2: Vector3,
    uv0: tuple[float, float],
    uv1: tuple[float, float],
    uv2: tuple[float, float],
    face_normal: Vector3,
) -> tuple[Vector3, Vector3]:
    """Calculate tangent and bitangent vectors for a triangle face for normal mapping.
    
    This function computes the tangent space basis vectors required for bump/normal mapping.
    The calculation is based on the OpenGL tutorial method with KotOR-specific modifications
    for handedness and texture mirroring.
    
    The tangent space forms a coordinate system at each vertex:
    - Tangent (T): Points along the U texture axis in 3D space
    - Bitangent/Binormal (B): Points along the V texture axis in 3D space  
    - Normal (N): The surface normal
    
    KotOR expects the tangent space to NOT form a right-handed coordinate system,
    meaning dot(cross(N,T), B) should be negative. The function also handles texture
    mirroring by detecting the orientation of the UV triangle.
    
    Args:
    ----
        v0: First vertex position
        v1: Second vertex position  
        v2: Third vertex position
        uv0: First vertex texture coordinates (u, v)
        uv1: Second vertex texture coordinates (u, v)
        uv2: Third vertex texture coordinates (u, v)
        face_normal: The triangle's surface normal vector
    
    Returns:
    -------
        tuple: (tangent vector, bitangent vector) - both normalized
    
    References:
    ----------
        vendor/mdlops/MDLOpsM.pm:5477-5596 - Tangent space calculation
        Based on: http://www.opengl-tutorial.org/intermediate-tutorials/tutorial-13-normal-mapping/
        with key differences for KotOR's coordinate system requirements
        
    Notes:
    -----
        - Handles overlapping texture vertices by using a magic fallback value (mdlops:5510-5512)
        - Fixes zero vectors from degenerate UVs to [1.0, 0.0, 0.0] (mdlops:5536-5539, 5563-5566)
        - Corrects handedness to match KotOR's left-handed tangent space (mdlops:5570-5587)
        - Inverts both vectors when texture is mirrored (mdlops:5588-5596)
    """
    import math
    
    # Calculate position deltas between vertices (mdlops:5491-5492)
    deltaPos1 = Vector3(v1.x - v0.x, v1.y - v0.y, v1.z - v0.z)
    deltaPos2 = Vector3(v2.x - v0.x, v2.y - v0.y, v2.z - v0.z)
    
    # Calculate UV deltas (mdlops:5493-5494)
    deltaUV1 = (uv1[0] - uv0[0], uv1[1] - uv0[1])
    deltaUV2 = (uv2[0] - uv0[0], uv2[1] - uv0[1])
    
    # Calculate texture normal's Z component to detect mirroring (mdlops:5495-5502)
    # This is the Z (or W) component of cross(uv0-uv1, uv2-uv1) in 2D texture space
    tNz = (uv0[0] - uv1[0]) * (uv2[1] - uv1[1]) - (uv0[1] - uv1[1]) * (uv2[0] - uv1[0])
    
    # Calculate the divisor for tangent/bitangent formulas (mdlops:5504)
    r = deltaUV1[0] * deltaUV2[1] - deltaUV1[1] * deltaUV2[0]
    
    # Handle divide-by-zero from overlapping texture vertices (mdlops:5505-5515)
    if abs(r) < 1e-10:  # Near-zero check
        # Magic factor determined algebraically from p_g0t01.mdl analysis (mdlops:5510-5512)
        r = 2406.6388
    else:
        r = 1.0 / r
    
    # Compute face tangent vector (mdlops:5516-5521)
    tangent_x = (deltaPos1.x * deltaUV2[1] - deltaPos2.x * deltaUV1[1]) * r
    tangent_y = (deltaPos1.y * deltaUV2[1] - deltaPos2.y * deltaUV1[1]) * r
    tangent_z = (deltaPos1.z * deltaUV2[1] - deltaPos2.z * deltaUV1[1]) * r
    
    # Normalize tangent vector (mdlops:5522-5534)
    tangent_length = math.sqrt(tangent_x**2 + tangent_y**2 + tangent_z**2)
    if tangent_length > 1e-10:
        tangent_x /= tangent_length
        tangent_y /= tangent_length
        tangent_z /= tangent_length
    
    # Fix zero vectors from degenerate UVs (mdlops:5535-5540)
    if abs(tangent_x) < 1e-10 and abs(tangent_y) < 1e-10 and abs(tangent_z) < 1e-10:
        tangent_x, tangent_y, tangent_z = 1.0, 0.0, 0.0
    
    tangent = Vector3(tangent_x, tangent_y, tangent_z)
    
    # Compute face bitangent vector (mdlops:5543-5548)
    bitangent_x = (deltaPos2.x * deltaUV1[0] - deltaPos1.x * deltaUV2[0]) * r
    bitangent_y = (deltaPos2.y * deltaUV1[0] - deltaPos1.y * deltaUV2[0]) * r
    bitangent_z = (deltaPos2.z * deltaUV1[0] - deltaPos1.z * deltaUV2[0]) * r
    
    # Normalize bitangent vector (mdlops:5549-5561)
    bitangent_length = math.sqrt(bitangent_x**2 + bitangent_y**2 + bitangent_z**2)
    if bitangent_length > 1e-10:
        bitangent_x /= bitangent_length
        bitangent_y /= bitangent_length
        bitangent_z /= bitangent_length
    
    # Fix zero vectors from degenerate UVs (mdlops:5562-5567)
    if abs(bitangent_x) < 1e-10 and abs(bitangent_y) < 1e-10 and abs(bitangent_z) < 1e-10:
        bitangent_x, bitangent_y, bitangent_z = 1.0, 0.0, 0.0
    
    bitangent = Vector3(bitangent_x, bitangent_y, bitangent_z)
    
    # Fix tangent space handedness (mdlops:5570-5587)
    # KotOR wants dot(cross(N,T), B) < 0 (NOT a right-handed system)
    # Calculate cross(normal, tangent) (mdlops:5573-5580)
    cross_nt_x = face_normal.y * tangent.z - face_normal.z * tangent.y
    cross_nt_y = face_normal.z * tangent.x - face_normal.x * tangent.z
    cross_nt_z = face_normal.x * tangent.y - face_normal.y * tangent.x
    
    # Check if dot(cross(N,T), B) > 0, if so flip tangent (mdlops:5581-5587)
    dot_product = cross_nt_x * bitangent.x + cross_nt_y * bitangent.y + cross_nt_z * bitangent.z
    if dot_product > 0.0:
        tangent = Vector3(-tangent.x, -tangent.y, -tangent.z)
    
    # Handle texture mirroring (mdlops:5588-5596)
    # If texture is mirrored (tNz > 0), invert both tangent and bitangent
    if tNz > 0.0:
        tangent = Vector3(-tangent.x, -tangent.y, -tangent.z)
        bitangent = Vector3(-bitangent.x, -bitangent.y, -bitangent.z)
    
    return tangent, bitangent


class MDLBinaryReader:
    """Binary MDL/MDX file reader.

    This class provides loading of MDL (model) and MDX (model extension) files.
    Supports both full loading and fast loading optimized for rendering.

    Args:
    ----
        source: The source of the MDL data
        offset: The byte offset within the source
        size: Size of the data to read
        source_ext: The source of the MDX data
        offset_ext: The byte offset within the MDX source
        size_ext: Size of the MDX data to read
        game: The game version (K1 or K2)
        fast_load: If True, skips animations and controllers for faster loading (optimized for rendering)
    
    References:
    ----------
        vendor/mdlops/MDLOpsM.pm:1649-1778 (Controller structure and bezier detection)
        vendor/mdlops/MDLOpsM.pm:5470-5596 (Tangent space calculation)
        vendor/reone/src/libs/graphics/format/mdlmdxreader.cpp:187-721 (Controller reading)
        vendor/reone/src/libs/graphics/format/mdlmdxreader.cpp:703-723 (Skin bone preparation)
        vendor/kotorblender/format/mdl/reader.py:850-868 (Quaternion decompression)
        vendor/KotOR.js/src/loaders/MDLLoader.ts (Model loading architecture)
    """

    def __init__(
        self,
        source: SOURCE_TYPES,
        offset: int = 0,
        size: int = 0,
        source_ext: SOURCE_TYPES | None = None,
        offset_ext: int = 0,
        size_ext: int = 0,
        game: Game = Game.K2,
        fast_load: bool = False,
    ):
        self._reader: BinaryReader = BinaryReader.from_auto(source, offset)

        self._reader_ext: BinaryReader | None = None if source_ext is None else BinaryReader.from_auto(source_ext, offset_ext)

        # first 12 bytes do not count in offsets used within the file
        self._reader.set_offset(self._reader.offset() + 12)

        self._fast_load: bool = fast_load
        self.game: Game = game

    def load(
        self,
        auto_close: bool = True,  # noqa: FBT002, FBT001
    ) -> MDL:
        """Load the MDL file.

        Args:
        ----
            auto_close: If True, automatically close readers after loading

        Returns:
        -------
            The loaded MDL instance
        """
        self._mdl: MDL = MDL()
        self._names: list[str] = []

        model_header: _ModelHeader = _ModelHeader().read(self._reader)

        # Determine game version from the file header function pointers.
        # This is more reliable than using per-node function pointer values.
        if (
            model_header.geometry.function_pointer0 == _GeometryHeader.K1_FUNCTION_POINTER0
            and model_header.geometry.function_pointer1 == _GeometryHeader.K1_FUNCTION_POINTER1
        ):
            self.game = Game.K1
        elif (
            model_header.geometry.function_pointer0 == _GeometryHeader.K2_FUNCTION_POINTER0
            and model_header.geometry.function_pointer1 == _GeometryHeader.K2_FUNCTION_POINTER1
        ):
            self.game = Game.K2

        self._mdl.name = model_header.geometry.model_name
        self._mdl.supermodel = model_header.supermodel
        self._mdl.fog = bool(model_header.fog)

        self._load_names(model_header)
        self._mdl.root = self._load_node(model_header.geometry.root_node_offset)

        # Skip animations when fast loading (not needed for rendering)
        if not self._fast_load:
            self._reader.seek(model_header.offset_to_animations)
            animation_offsets: list[int] = [self._reader.read_uint32() for _ in range(model_header.animation_count)]
            for animation_offset in animation_offsets:
                anim: MDLAnimation = self._load_anim(animation_offset)
                self._mdl.anims.append(anim)

        if auto_close:
            self._reader.close()
            if self._reader_ext is not None:
                self._reader_ext.close()

        return self._mdl

    def _load_names(
        self,
        model_header: _ModelHeader,
    ):
        self._reader.seek(model_header.offset_to_name_offsets)
        name_offsets: list[int] = [self._reader.read_uint32() for _ in range(model_header.name_offsets_count)]
        for offset in name_offsets:
            self._reader.seek(offset)
            name = self._reader.read_terminated_string("\0")
            self._names.append(name)

    def _load_node(
        self,
        offset: int,
    ) -> MDLNode:
        self._reader.seek(offset)
        bin_node = _Node().read(self._reader, self.game)
        assert bin_node.header is not None

        node = MDLNode()
        node.node_id = bin_node.header.node_id
        node.name = self._names[bin_node.header.name_id]
        node.position = bin_node.header.position
        node.orientation = bin_node.header.orientation
        node.node_type = MDLNodeType.DUMMY

        if bin_node.trimesh is not None:
            node.mesh = MDLMesh()
            node.node_type = MDLNodeType.TRIMESH
            node.mesh.shadow = bool(bin_node.trimesh.has_shadow)
            node.mesh.render = bool(bin_node.trimesh.render)
            node.mesh.background_geometry = bool(bin_node.trimesh.background)
            node.mesh.has_lightmap = bool(bin_node.trimesh.has_lightmap)
            node.mesh.beaming = bool(bin_node.trimesh.beaming)
            node.mesh.dirt_enabled = bool(bin_node.trimesh.dirt_enabled)
            node.mesh.dirt_texture = bin_node.trimesh.dirt_texture
            node.mesh.dirt_coordinate_space = bin_node.trimesh.dirt_coordinate_space
            node.mesh.diffuse = Color.from_bgr_vector3(bin_node.trimesh.diffuse)
            node.mesh.ambient = Color.from_bgr_vector3(bin_node.trimesh.ambient)
            node.mesh.texture_1 = bin_node.trimesh.texture1
            node.mesh.texture_2 = bin_node.trimesh.texture2
            node.mesh.bb_min = bin_node.trimesh.bounding_box_min
            node.mesh.bb_max = bin_node.trimesh.bounding_box_max
            node.mesh.radius = bin_node.trimesh.radius
            node.mesh.average = bin_node.trimesh.average
            node.mesh.area = bin_node.trimesh.total_area
            node.mesh.saber_unknowns = cast("tuple[int, int, int, int, int, int, int, int]", bin_node.trimesh.saber_unknowns)

            # Vertex positions can be stored either in MDL (K1-style) or in MDX blocks.
            # Preserve vertex_count even if the MDL vertex table wasn't readable.
            vcount = bin_node.trimesh.vertex_count
            node.mesh.vertex_positions = []
            if bool(bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.VERTEX) and self._reader_ext:
                mdx_offset: int = bin_node.trimesh.mdx_data_offset
                mdx_block_size: int = bin_node.trimesh.mdx_data_size
                for i in range(vcount):
                    self._reader_ext.seek(mdx_offset + i * mdx_block_size + bin_node.trimesh.mdx_vertex_offset)
                    x, y, z = (
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                    )
                    node.mesh.vertex_positions.append(Vector3(x, y, z))
            else:
                # Prefer the MDL vertex table if present; otherwise fall back to reading it directly.
                if bin_node.trimesh.vertices:
                    node.mesh.vertex_positions = bin_node.trimesh.vertices
                elif vcount > 0 and bin_node.trimesh.vertices_offset not in (0, 0xFFFFFFFF):
                    # `read_extra` might have skipped vertices due to a conservative bounds check;
                    # try again here using the advertised vertex_count.
                    if bin_node.trimesh.vertices_offset + (vcount * 12) <= self._reader.size():
                        self._reader.seek(bin_node.trimesh.vertices_offset)
                        node.mesh.vertex_positions = [self._reader.read_vector3() for _ in range(vcount)]
                if not node.mesh.vertex_positions and vcount > 0:
                    node.mesh.vertex_positions = [Vector3.from_null() for _ in range(vcount)]

            if bool(bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.NORMAL) and self._reader_ext:
                node.mesh.vertex_normals = []
            if bool(bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.TEXTURE1) and self._reader_ext:
                node.mesh.vertex_uv1 = []
            if bool(bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.TEXTURE2) and self._reader_ext:
                node.mesh.vertex_uv2 = []

            mdx_offset: int = bin_node.trimesh.mdx_data_offset
            mdx_block_size: int = bin_node.trimesh.mdx_data_size
            for i in range(vcount):
                if bool(bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.NORMAL) and self._reader_ext:
                    if node.mesh.vertex_normals is None:
                        node.mesh.vertex_normals = []
                    self._reader_ext.seek(mdx_offset + i * mdx_block_size + bin_node.trimesh.mdx_normal_offset)
                    x, y, z = (
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                    )
                    node.mesh.vertex_normals.append(Vector3(x, y, z))

                if bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.TEXTURE1 and self._reader_ext:
                    assert node.mesh.vertex_uv1 is not None
                    self._reader_ext.seek(mdx_offset + i * mdx_block_size + bin_node.trimesh.mdx_texture1_offset)
                    u, v = (
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                    )
                    node.mesh.vertex_uv1.append(Vector2(u, v))

                if bin_node.trimesh.mdx_data_bitmap & _MDXDataFlags.TEXTURE2 and self._reader_ext:
                    assert node.mesh.vertex_uv2 is not None
                    self._reader_ext.seek(
                        mdx_offset + i * mdx_block_size + bin_node.trimesh.mdx_texture2_offset,
                    )
                    u, v = (
                        self._reader_ext.read_single(),
                        self._reader_ext.read_single(),
                    )
                    node.mesh.vertex_uv2.append(Vector2(u, v))

            # If we couldn't load normals (no MDX or no NORMAL flag), keep a sane default.
            if node.mesh.vertex_normals is None:
                node.mesh.vertex_normals = [Vector3.from_null() for _ in range(vcount)]

            for bin_face in bin_node.trimesh.faces:
                face = MDLFace()
                node.mesh.faces.append(face)
                face.v1 = bin_face.vertex1
                face.v2 = bin_face.vertex2
                face.v3 = bin_face.vertex3
                face.a1 = bin_face.adjacent1
                face.a2 = bin_face.adjacent2
                face.a3 = bin_face.adjacent3
                face.normal = bin_face.normal
                face.coefficient = int(bin_face.plane_coefficient)
                face.material = bin_face.material

        if bin_node.skin:
            node.skin = MDLSkin()
            node.skin.bone_indices = bin_node.skin.bones
            node.skin.bonemap = bin_node.skin.bonemap
            node.skin.tbones = bin_node.skin.tbones
            node.skin.qbones = bin_node.skin.qbones

            if self._reader_ext:
                assert bin_node.trimesh is not None
                for i in range(bin_node.trimesh.vertex_count):
                    vertex_bone = MDLBoneVertex()
                    node.skin.vertex_bones.append(vertex_bone)

                    mdx_offset = bin_node.trimesh.mdx_data_offset + i * bin_node.trimesh.mdx_data_size
                    bones_pos = mdx_offset + bin_node.skin.offset_to_mdx_bones
                    if bones_pos + 16 <= self._reader_ext.size():
                        self._reader_ext.seek(bones_pos)
                        t1 = self._reader_ext.read_single()
                        t2 = self._reader_ext.read_single()
                        t3 = self._reader_ext.read_single()
                        t4 = self._reader_ext.read_single()
                        vertex_bone.vertex_indices = (t1, t2, t3, t4)

                    mdx_offset = bin_node.trimesh.mdx_data_offset + i * bin_node.trimesh.mdx_data_size
                    weights_pos = mdx_offset + bin_node.skin.offset_to_mdx_weights
                    if weights_pos + 16 <= self._reader_ext.size():
                        self._reader_ext.seek(weights_pos)
                        w1 = self._reader_ext.read_single()
                        w2 = self._reader_ext.read_single()
                        w3 = self._reader_ext.read_single()
                        w4 = self._reader_ext.read_single()
                        vertex_bone.vertex_weights = (w1, w2, w3, w4)

        for child_offset in bin_node.children_offsets:
            child_node: MDLNode = self._load_node(child_offset)
            node.children.append(child_node)

        # Skip controllers when fast loading (not needed for rendering)
        if not self._fast_load:
            for i in range(bin_node.header.controller_count):
                offset = bin_node.header.offset_to_controllers + i * _Controller.SIZE
                controller: MDLController = self._load_controller(
                    offset,
                    bin_node.header.offset_to_controller_data,
                )
                node.controllers.append(controller)

        return node

    def _load_anim(
        self,
        offset,
    ) -> MDLAnimation:
        self._reader.seek(offset)

        bin_anim: _AnimationHeader = _AnimationHeader().read(self._reader)

        bin_events: list[_EventStructure] = []
        self._reader.seek(bin_anim.offset_to_events)
        for _ in range(bin_anim.event_count):
            bin_event: _EventStructure = _EventStructure().read(self._reader)
            bin_events.append(bin_event)

        anim = MDLAnimation()

        anim.name = bin_anim.geometry.model_name
        anim.root_model = bin_anim.root
        anim.anim_length = bin_anim.duration
        anim.transition_length = bin_anim.transition

        for bin_event in bin_events:
            event = MDLEvent()
            event.name = bin_event.event_name
            event.activation_time = bin_event.activation_time
            anim.events.append(event)

        anim.root = self._load_node(bin_anim.geometry.root_node_offset)

        return anim

    def _load_controller(
        self,
        offset: int,
        data_offset: int,
    ) -> MDLController:
        self._reader.seek(offset)
        bin_controller: _Controller = _Controller().read(self._reader)

        row_count: int = bin_controller.row_count
        column_count: int = bin_controller.column_count

        self._reader.seek(data_offset + bin_controller.key_offset)
        time_keys: list[int] = [self._reader.read_single() for _ in range(row_count)]

        # There are some special cases when reading controller data rows.
        data_pointer: int = data_offset + bin_controller.data_offset
        self._reader.seek(data_pointer)

        # Detect bezier interpolation flag (bit 4 = 0x10) in column count
        # vendor/mdlops/MDLOpsM.pm:1704-1710 - Bezier flag detection
        # vendor/mdlops/MDLOpsM.pm:1749-1756 - Bezier data expansion (3 values per column)
        bezier_flag: int = 0x10
        is_bezier: bool = bool(column_count & bezier_flag)
        
        # Orientation data stored in controllers is sometimes compressed into 4 bytes. We need to check for that and
        # uncompress the quaternion if that is the case.
        # vendor/mdlops/MDLOpsM.pm:1714-1719 - Compressed quaternion detection
        if bin_controller.type_id == MDLControllerType.ORIENTATION and bin_controller.column_count == 2:
            data: list[list[float]] = []
            for _ in range(bin_controller.row_count):
                compressed: int = self._reader.read_uint32()
                decompressed: Vector4 = Vector4.from_compressed(compressed)
                data.append([decompressed.x, decompressed.y, decompressed.z, decompressed.w])
        else:
            # vendor/mdlops/MDLOpsM.pm:1721-1726 - Bezier data reading
            # Bezier controllers store 3 floats per column: (value, in_tangent, out_tangent)
            # Non-bezier controllers store 1 float per column
            if is_bezier:
                base_columns = column_count - bezier_flag
                effective_columns = base_columns * 3
            else:
                effective_columns = column_count
            
            # Ensure we have at least some columns to read
            if effective_columns <= 0:
                effective_columns = column_count & ~bezier_flag  # Strip bezier flag
            
            data = [
                [self._reader.read_single() for _ in range(effective_columns)]
                for _ in range(row_count)
            ]

        controller_type: int = bin_controller.type_id
        rows: list[MDLControllerRow] = [MDLControllerRow(time_keys[i], data[i]) for i in range(row_count)]
        # vendor/mdlops/MDLOpsM.pm:1709 - Store bezier flag with controller
        controller = MDLController(MDLControllerType(controller_type), rows, is_bezier=is_bezier)
        return controller


class MDLBinaryWriter:
    """Binary MDL/MDX file writer.
    
    Writes MDL (model) and MDX (model extension) files from MDL data structures.
    
    References:
    ----------
        vendor/mdlops/MDLOpsM.pm (Binary MDL writing paths)
        vendor/reone/src/libs/graphics/format/mdlmdxwriter.cpp (MDL/MDX writing)
        vendor/kotorblender/format/mdl/writer.py (MDL writing reference)
    """
    def __init__(
        self,
        mdl: MDL,
        target: TARGET_TYPES,
        target_ext: TARGET_TYPES | None,
    ):
        self._mdl: MDL = mdl

        self._target: TARGET_TYPES = target
        self._target_ext: TARGET_TYPES | None = target_ext
        self._writer: BinaryWriterBytearray = BinaryWriter.to_bytearray()
        self._writer_ext: BinaryWriterBytearray = BinaryWriter.to_bytearray()

        self.game: Game = Game.K1

        self._name_offsets: list[int] = []
        self._anim_offsets: list[int] = []
        self._node_offsets: list[int] = []

        self._bin_anim_nodes: dict[str, _Node] = {}
        self._mdl_nodes: list[MDLNode] = []
        self._bin_nodes: list[_Node] = []
        self._bin_anims: list[_Animation] = []
        self._names: list[str] = []
        self._file_header: _ModelHeader = _ModelHeader()

    def write(
        self,
        auto_close: bool = True,
    ):
        self._mdl_nodes: list[MDLNode] = self._mdl.all_nodes()
        self._bin_nodes: list[_Node] = [_Node() for _ in self._mdl_nodes]
        self._bin_anims: list[_Animation] = [_Animation() for _ in self._mdl.anims]
        # Name table must cover *all* nodes referenced by the file: geometry nodes + animation nodes.
        # Some round-trip paths construct animation roots independently, so build this as a de-duped,
        # insertion-ordered list.
        self._names = []
        def _add_name(n: str) -> None:
            if n and n not in self._names:
                self._names.append(n)

        for node in self._mdl_nodes:
            _add_name(node.name)
        for anim in self._mdl.anims:
            for node in anim.all_nodes():
                _add_name(node.name)

        self._anim_offsets: list[int] = [0 for _ in self._bin_anims]
        self._node_offsets: list[int] = [0 for _ in self._bin_nodes]
        self._file_header: _ModelHeader = _ModelHeader()

        self._update_all_data()

        self._calc_top_offsets()
        self._calc_inner_offsets()

        self._write_all()

        if auto_close:
            self._writer.close()
            if self._writer_ext:
                self._writer_ext.close()

    def _update_all_data(
        self,
    ):
        for i, bin_node in enumerate(self._bin_nodes):
            self._update_node(bin_node, self._mdl_nodes[i], node_id_override=i)

        for i, bin_anim in enumerate(self._bin_anims):
            self._update_anim(bin_anim, self._mdl.anims[i])

    def _update_node(
        self,
        bin_node: _Node,
        mdl_node: MDLNode,
        *,
        node_id_override: int | None = None,
    ):
        assert bin_node.header is not None
        bin_node.header.type_id = self._node_type(mdl_node)
        bin_node.header.position = mdl_node.position
        bin_node.header.orientation = mdl_node.orientation
        bin_node.header.children_count = bin_node.header.children_count2 = len(mdl_node.children)
        if mdl_node.name not in self._names:
            self._names.append(mdl_node.name)
        bin_node.header.name_id = self._names.index(mdl_node.name)
        # Node IDs are positional within their node array (geometry or animation), not global by name.
        # When writing, always prefer the caller-provided order.
        bin_node.header.node_id = node_id_override if node_id_override is not None else 0

        # Determine the appropriate function pointer values to write
        if self.game == Game.K1:
            if mdl_node.skin:
                fp0 = _TrimeshHeader.K1_SKIN_FUNCTION_POINTER0
                fp1 = _TrimeshHeader.K1_SKIN_FUNCTION_POINTER1
            elif mdl_node.dangly:
                fp0 = _TrimeshHeader.K1_DANGLY_FUNCTION_POINTER0
                fp1 = _TrimeshHeader.K1_DANGLY_FUNCTION_POINTER1
            else:
                fp0 = _TrimeshHeader.K1_FUNCTION_POINTER0
                fp1 = _TrimeshHeader.K1_FUNCTION_POINTER1
        elif mdl_node.skin:
            fp0 = _TrimeshHeader.K2_SKIN_FUNCTION_POINTER0
            fp1 = _TrimeshHeader.K2_SKIN_FUNCTION_POINTER1
        elif mdl_node.dangly:
            fp0 = _TrimeshHeader.K2_DANGLY_FUNCTION_POINTER0
            fp1 = _TrimeshHeader.K2_DANGLY_FUNCTION_POINTER1
        else:
            fp0 = _TrimeshHeader.K2_FUNCTION_POINTER0
            fp1 = _TrimeshHeader.K2_FUNCTION_POINTER1

        if mdl_node.mesh:
            bin_node.trimesh = _TrimeshHeader()
            bin_node.trimesh.function_pointer0 = fp0
            bin_node.trimesh.function_pointer1 = fp1
            bin_node.trimesh.average = mdl_node.mesh.average
            bin_node.trimesh.radius = mdl_node.mesh.radius
            bin_node.trimesh.bounding_box_max = mdl_node.mesh.bb_max
            bin_node.trimesh.bounding_box_min = mdl_node.mesh.bb_min
            bin_node.trimesh.total_area = mdl_node.mesh.area
            bin_node.trimesh.texture1 = mdl_node.mesh.texture_1
            bin_node.trimesh.texture2 = mdl_node.mesh.texture_2
            bin_node.trimesh.diffuse = mdl_node.mesh.diffuse.bgr_vector3()
            bin_node.trimesh.ambient = mdl_node.mesh.ambient.bgr_vector3()
            bin_node.trimesh.render = mdl_node.mesh.render
            bin_node.trimesh.transparency_hint = mdl_node.mesh.transparency_hint
            bin_node.trimesh.uv_jitter = mdl_node.mesh.uv_jitter
            bin_node.trimesh.uv_speed = mdl_node.mesh.uv_jitter_speed
            bin_node.trimesh.uv_direction.x = mdl_node.mesh.uv_direction_x
            bin_node.trimesh.uv_direction.y = mdl_node.mesh.uv_direction_y
            bin_node.trimesh.has_lightmap = mdl_node.mesh.has_lightmap
            bin_node.trimesh.rotate_texture = mdl_node.mesh.rotate_texture
            bin_node.trimesh.background = mdl_node.mesh.background_geometry
            bin_node.trimesh.has_shadow = mdl_node.mesh.shadow
            bin_node.trimesh.beaming = mdl_node.mesh.beaming
            bin_node.trimesh.render = mdl_node.mesh.render
            bin_node.trimesh.dirt_enabled = mdl_node.mesh.dirt_enabled
            bin_node.trimesh.dirt_texture = mdl_node.mesh.dirt_texture
            bin_node.trimesh.dirt_coordinate_space = mdl_node.mesh.dirt_coordinate_space
            bin_node.trimesh.saber_unknowns = bytes(mdl_node.mesh.saber_unknowns)

            bin_node.trimesh.vertex_count = len(mdl_node.mesh.vertex_positions)
            bin_node.trimesh.vertices = mdl_node.mesh.vertex_positions

            # These index/count tables are not required by the current reader and are intentionally omitted
            # from the written node payload to keep offsets stable across roundtrips.
            bin_node.trimesh.indices_counts = []
            bin_node.trimesh.indices_counts_count = bin_node.trimesh.indices_counts_count2 = 0

            bin_node.trimesh.indices_offsets = []
            bin_node.trimesh.indices_offsets_count = bin_node.trimesh.indices_offsets_count2 = 0

            bin_node.trimesh.inverted_counters = []
            bin_node.trimesh.counters_count = bin_node.trimesh.counters_count2 = 0

            bin_node.trimesh.faces_count = bin_node.trimesh.faces_count2 = len(mdl_node.mesh.faces)
            for face in mdl_node.mesh.faces:
                bin_face = _Face()
                bin_node.trimesh.faces.append(bin_face)
                bin_face.vertex1 = face.v1
                bin_face.vertex2 = face.v2
                bin_face.vertex3 = face.v3
                bin_face.adjacent1 = face.a1
                bin_face.adjacent2 = face.a2
                bin_face.adjacent3 = face.a3
                bin_face.material = face.material
                bin_face.plane_coefficient = face.coefficient
                bin_face.normal = face.normal

        data_offset = 0
        key_offset = 0
        for mdl_controller in mdl_node.controllers:
            bin_controller = _Controller()
            bin_controller.type_id = mdl_controller.controller_type
            bin_controller.row_count = len(mdl_controller.rows)
            bin_controller.column_count = len(mdl_controller.rows[0].data)
            bin_controller.key_offset = key_offset
            data_offset += len(mdl_controller.rows)
            bin_controller.data_offset = data_offset
            bin_node.w_controllers.append(bin_controller)
            data_offset += len(mdl_controller.rows) * len(mdl_controller.rows[0].data)
            key_offset += data_offset

        bin_node.w_controller_data = []
        for controller in mdl_node.controllers:
            for row in controller.rows:
                bin_node.w_controller_data.append(row.time)
            for row in controller.rows:
                bin_node.w_controller_data.extend(row.data)

        bin_node.header.controller_count = bin_node.header.controller_count2 = len(mdl_node.controllers)
        bin_node.header.controller_data_length = bin_node.header.controller_data_length2 = len(bin_node.w_controller_data)

    def _update_anim(
        self,
        bin_anim: _Animation,
        mdl_anim: MDLAnimation,
    ):
        if self.game == Game.K1:
            bin_anim.header.geometry.function_pointer0 = _GeometryHeader.K1_ANIM_FUNCTION_POINTER0
            bin_anim.header.geometry.function_pointer1 = _GeometryHeader.K1_ANIM_FUNCTION_POINTER1
        else:
            bin_anim.header.geometry.function_pointer0 = _GeometryHeader.K2_ANIM_FUNCTION_POINTER0
            bin_anim.header.geometry.function_pointer1 = _GeometryHeader.K2_ANIM_FUNCTION_POINTER1

        bin_anim.header.geometry.geometry_type = 5
        bin_anim.header.geometry.model_name = mdl_anim.name
        bin_anim.header.geometry.node_count = 0
        bin_anim.header.duration = mdl_anim.anim_length
        bin_anim.header.transition = mdl_anim.transition_length
        bin_anim.header.root = mdl_anim.root_model
        bin_anim.header.event_count = bin_anim.header.event_count2 = len(mdl_anim.events)

        for mdl_event in mdl_anim.events:
            bin_event = _EventStructure()
            bin_event.event_name = mdl_event.name
            bin_event.activation_time = mdl_event.activation_time
            bin_anim.events.append(bin_event)

        all_nodes: list[MDLNode] = mdl_anim.all_nodes()
        bin_nodes: list[_Node] = []
        for node_id, mdl_node in enumerate(all_nodes):
            bin_node = _Node()
            self._update_node(bin_node, mdl_node, node_id_override=node_id)
            bin_nodes.append(bin_node)
        bin_anim.w_nodes = bin_nodes

    def _update_mdx(
        self,
        bin_node: _Node,
        mdl_node: MDLNode,
    ):
        assert bin_node.trimesh is not None
        assert mdl_node.mesh is not None

        bin_node.trimesh.mdx_data_offset = self._writer_ext.size()

        bin_node.trimesh.mdx_vertex_offset = 0xFFFFFFFF
        bin_node.trimesh.mdx_normal_offset = 0xFFFFFFFF
        bin_node.trimesh.mdx_texture1_offset = 0xFFFFFFFF
        bin_node.trimesh.mdx_texture2_offset = 0xFFFFFFFF
        bin_node.trimesh.mdx_data_bitmap = 0

        suboffset = 0
        if mdl_node.mesh.vertex_positions:
            bin_node.trimesh.mdx_vertex_offset = suboffset
            bin_node.trimesh.mdx_data_bitmap |= _MDXDataFlags.VERTEX
            suboffset += 12

        if mdl_node.mesh.vertex_normals:
            bin_node.trimesh.mdx_normal_offset = suboffset
            bin_node.trimesh.mdx_data_bitmap |= _MDXDataFlags.NORMAL
            suboffset += 12

        if mdl_node.mesh.vertex_uv1:
            bin_node.trimesh.mdx_texture1_offset = suboffset
            bin_node.trimesh.mdx_data_bitmap |= _MDXDataFlags.TEXTURE1
            suboffset += 8

        if mdl_node.mesh.vertex_uv2:
            bin_node.trimesh.mdx_texture2_offset = suboffset
            bin_node.trimesh.mdx_data_bitmap |= _MDXDataFlags.TEXTURE2
            suboffset += 8

        bin_node.trimesh.mdx_data_size = suboffset

        for i, position in enumerate(mdl_node.mesh.vertex_positions):
            if mdl_node.mesh.vertex_positions:
                self._writer_ext.write_vector3(position)
            if mdl_node.mesh.vertex_normals:
                self._writer_ext.write_vector3(mdl_node.mesh.vertex_normals[i])
            if mdl_node.mesh.vertex_uv1:
                self._writer_ext.write_vector2(mdl_node.mesh.vertex_uv1[i])
            if mdl_node.mesh.vertex_uv2:
                self._writer_ext.write_vector2(mdl_node.mesh.vertex_uv2[i])

        # Why does the mdl/mdx format have this? I have no idea.
        if mdl_node.mesh.vertex_positions:
            self._writer_ext.write_vector3(Vector3(10000000, 10000000, 10000000))
        if mdl_node.mesh.vertex_normals:
            self._writer_ext.write_vector3(Vector3.from_null())
        if mdl_node.mesh.vertex_uv1:
            self._writer_ext.write_vector2(Vector2.from_null())
        if mdl_node.mesh.vertex_uv2:
            self._writer_ext.write_vector2(Vector2.from_null())

    def _calc_top_offsets(
        self,
    ):
        offset_to_name_offsets = _ModelHeader.SIZE

        offset_to_names = offset_to_name_offsets + 4 * len(self._names)
        name_offset = offset_to_names
        for name in self._names:
            self._name_offsets.append(name_offset)
            name_offset += len(name) + 1

        offset_to_anim_offsets = name_offset
        offset_to_anims = name_offset + (4 * len(self._bin_anims))
        anim_offset = offset_to_anims
        for i, anim in enumerate(self._bin_anims):
            self._anim_offsets[i] = anim_offset
            anim_offset += anim.size()

        offset_to_node_offset = anim_offset
        node_offset = offset_to_node_offset
        for i, bin_node in enumerate(self._bin_nodes):
            self._node_offsets[i] = node_offset
            node_offset += bin_node.calc_size(self.game)

        self._file_header.geometry.root_node_offset = offset_to_node_offset
        self._file_header.offset_to_name_offsets = offset_to_name_offsets
        self._file_header.offset_to_super_root = 0
        self._file_header.offset_to_animations = offset_to_anim_offsets

    def _calc_inner_offsets(
        self,
    ):
        for i, bin_anim in enumerate(self._bin_anims):
            bin_anim.header.offset_to_events = self._anim_offsets[i] + bin_anim.events_offset()
            bin_anim.header.geometry.root_node_offset = self._anim_offsets[i] + bin_anim.nodes_offset()

            node_offsets: list[int] = []
            node_offset: int = self._anim_offsets[i] + bin_anim.nodes_offset()
            for bin_node in bin_anim.w_nodes:
                node_offsets.append(node_offset)
                node_offset += bin_node.calc_size(self.game)

            self._calc_node_offsets_for_context(
                bin_nodes=bin_anim.w_nodes,
                bin_offsets=node_offsets,
                mdl_nodes=self._mdl.anims[i].all_nodes(),
            )

        self._calc_node_offsets_for_context(
            bin_nodes=self._bin_nodes,
            bin_offsets=self._node_offsets,
            mdl_nodes=self._mdl_nodes,
        )

    def _calc_node_offsets_for_context(
        self,
        *,
        bin_nodes: list[_Node],
        bin_offsets: list[int],
        mdl_nodes: list[MDLNode],
    ) -> None:
        """Populate per-node child offsets + header offsets for a single node array (geometry OR animation)."""
        if len(bin_nodes) != len(mdl_nodes):
            raise ValueError(f"bin_nodes and mdl_nodes length mismatch ({len(bin_nodes)} vs {len(mdl_nodes)})")

        idx_by_id = {id(n): i for i, n in enumerate(mdl_nodes)}
        parent_by_idx: dict[int, int] = {}
        for parent_idx, parent in enumerate(mdl_nodes):
            for child in parent.children:
                child_idx = idx_by_id.get(id(child))
                if child_idx is not None:
                    parent_by_idx[child_idx] = parent_idx

        for i, (bin_node, mdl_node) in enumerate(zip(bin_nodes, mdl_nodes, strict=False)):
            node_offset = bin_offsets[i]

            # Child offsets from the MDL node tree
            bin_node.children_offsets = []
            for child in mdl_node.children:
                child_idx = idx_by_id.get(id(child))
                if child_idx is not None:
                    bin_node.children_offsets.append(bin_offsets[child_idx])

            assert bin_node.header is not None
            bin_node.header.offset_to_children = node_offset + bin_node.children_offsets_offset(self.game)
            bin_node.header.offset_to_controllers = node_offset + bin_node.controllers_offset(self.game)
            bin_node.header.offset_to_controller_data = node_offset + bin_node.controller_data_offset(self.game)
            bin_node.header.offset_to_root = 0
            parent_idx = parent_by_idx.get(i)
            bin_node.header.offset_to_parent = bin_offsets[parent_idx] if parent_idx is not None else 0

            if bin_node.trimesh:
                self._calc_trimesh_offsets(node_offset, bin_node)

    def _calc_trimesh_offsets(
        self,
        node_offset: int,
        bin_node: _Node,
    ):
        assert bin_node.trimesh is not None
        bin_node.trimesh.offset_to_counters = node_offset + bin_node.inverted_counters_offset(self.game)
        bin_node.trimesh.offset_to_indices_counts = node_offset + bin_node.indices_counts_offset(self.game)
        bin_node.trimesh.offset_to_indices_offset = node_offset + bin_node.indices_offsets_offset(self.game)
        if bin_node.trimesh.indices_offsets_count and bin_node.trimesh.indices_offsets:
            bin_node.trimesh.indices_offsets = [node_offset + bin_node.indices_offset(self.game)]

        bin_node.trimesh.offset_to_faces = node_offset + bin_node.faces_offset(self.game)
        bin_node.trimesh.vertices_offset = node_offset + bin_node.vertices_offset(self.game)


    def _node_type(
        self,
        node: MDLNode,
    ) -> int:
        type_id = 1
        if node.mesh:
            type_id = type_id | MDLNodeFlags.MESH
        # if node.skin: type_id = type_id | MDLNodeFlags.SKIN
        # if node.dangly: type_id = type_id | MDLNodeFlags.DANGLY
        # if node.saber: type_id = type_id | MDLNodeFlags.SABER
        # if node.aabb: type_id = type_id | MDLNodeFlags.AABB
        # if node.emitter: type_id = type_id | MDLNodeFlags.EMITTER
        # if node.light: type_id = type_id | MDLNodeFlags.LIGHT
        # if node.reference: type_id = type_id | MDLNodeFlags.REFERENCE
        return type_id

    def _write_all(
        self,
    ):
        for i, bin_node in enumerate(self._bin_nodes):
            if bin_node.trimesh:
                self._update_mdx(bin_node, self._mdl_nodes[i])

        self._file_header.geometry.function_pointer0 = _GeometryHeader.K1_FUNCTION_POINTER0
        self._file_header.geometry.function_pointer1 = _GeometryHeader.K1_FUNCTION_POINTER1
        self._file_header.geometry.model_name = self._mdl.name
        self._file_header.geometry.node_count = len(self._mdl_nodes)  # TODO: need to include supermodel in count
        self._file_header.geometry.geometry_type = 2
        self._file_header.offset_to_super_root = self._file_header.geometry.root_node_offset
        self._file_header.mdx_size = self._writer_ext.size()

        # Preserve basic model header fields needed for roundtrip tests.
        # `model_type` corresponds to classification in practice.
        self._file_header.model_type = int(self._mdl.classification)
        self._file_header.fog = 1 if self._mdl.fog else 0
        self._file_header.animation_count = self._file_header.animation_count2 = len(self._mdl.anims)
        self._file_header.bounding_box_min = self._mdl.bmin
        self._file_header.bounding_box_max = self._mdl.bmax
        self._file_header.radius = self._mdl.radius
        self._file_header.anim_scale = float(self._mdl.animation_scale)
        self._file_header.supermodel = self._mdl.supermodel
        # TODO self._file_header.mdx_size
        # TODO self._file_header.mdx_offset
        self._file_header.name_offsets_count = self._file_header.name_offsets_count2 = len(self._names)

        self._file_header.write(self._writer)

        for name_offset in self._name_offsets:
            self._writer.write_uint32(name_offset)

        for name in self._names:
            self._writer.write_string(name + "\0", encoding="ascii")

        for anim_offset in self._anim_offsets:
            self._writer.write_uint32(anim_offset)

        for bin_anim in self._bin_anims:
            bin_anim.write(self._writer, self.game)
        for bin_node in self._bin_nodes:
            bin_node.write(self._writer, self.game)

        # Write to MDL
        mdl_writer: BinaryWriter = BinaryWriter.to_auto(self._target)
        mdl_writer.write_uint32(0)
        mdl_writer.write_uint32(self._writer.size())
        mdl_writer.write_uint32(self._writer_ext.size())
        mdl_writer.write_bytes(self._writer.data())

        # Write to MDX
        if self._target_ext is not None:
            BinaryWriter.to_auto(self._target_ext).write_bytes(self._writer_ext.data())
