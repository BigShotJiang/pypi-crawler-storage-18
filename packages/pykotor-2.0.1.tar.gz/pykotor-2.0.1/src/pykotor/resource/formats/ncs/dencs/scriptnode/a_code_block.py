from __future__ import annotations

from pykotor.resource.formats.ncs.dencs.scriptnode.script_root_node import ScriptRootNode  # pyright: ignore[reportMissingImports]


class ACodeBlock(ScriptRootNode):
    def __init__(self, start: int = 0, end: int = 0):
        super().__init__(start, end)

    def __str__(self) -> str:
        buff = []
        buff.append(self.tabs + "{" + self.newline)
        for child in self.children:
            buff.append(str(child))
        buff.append(self.tabs + "}" + self.newline)
        return "".join(buff)

