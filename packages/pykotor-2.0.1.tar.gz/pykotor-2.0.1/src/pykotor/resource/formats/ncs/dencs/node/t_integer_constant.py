from __future__ import annotations

from typing import TYPE_CHECKING

from pykotor.resource.formats.ncs.dencs.node.token import Token  # pyright: ignore[reportMissingImports]

if TYPE_CHECKING:
    from pykotor.resource.formats.ncs.dencs.analysis.analysis_adapter import Analysis  # pyright: ignore[reportMissingImports]

class TIntegerConstant(Token):
    def __init__(self, text: str = "0", line: int = 0, pos: int = 0):
        super().__init__(text)
        self.line = line
        self.pos = pos

    def clone(self) -> Token:
        return TIntegerConstant(self.get_text(), self.get_line(), self.get_pos())

    def apply(self, sw: Analysis):
        sw.case_t_integer_constant(self)

