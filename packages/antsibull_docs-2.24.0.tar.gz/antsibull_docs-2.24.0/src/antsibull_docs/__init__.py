# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or
# https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: 2020, Ansible Project
"""The main antsibull-docs module. Contains versioning information."""

from __future__ import annotations

__version__ = "2.24.0"


__all__ = ("__version__",)
