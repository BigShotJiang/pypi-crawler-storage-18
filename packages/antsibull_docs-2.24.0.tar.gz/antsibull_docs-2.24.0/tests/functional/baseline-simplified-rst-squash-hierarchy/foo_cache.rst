.. Created with antsibull-docs

ns2.col.foo cache -- Foo files :literal:`bar` (`link <#parameter-bar>`_)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

This cache plugin is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

It is not included in ``ansible-core``.
To check whether it is installed, run ``ansible-galaxy collection list``.

To install it, use: :code:`ansible\-galaxy collection install ns2.col`.

To use it in a playbook, specify: ``ns2.col.foo``.

New in ns2.col 1.9.0

.. contents::
   :local:
   :depth: 1


Synopsis
--------

- Cache foo files.








Parameters
----------

.. raw:: html

  <table style="width: 100%;">
  <thead>
    <tr>
    <th><p>Parameter</p></th>
    <th><p>Comments</p></th>
  </tr>
  </thead>
  <tbody>
  <tr>
    <td valign="top">
      <div class="ansibleOptionAnchor" id="parameter-_uri"></div>
      <p style="display: inline;"><strong>_uri</strong></p>
      <a class="ansibleOptionLink" href="#parameter-_uri" title="Permalink to this option"></a>
      <p style="font-size: small; margin-bottom: 0;">
        <span style="color: purple;">path</span>
        / <span style="color: red;">required</span>
      </p>

    </td>
    <td valign="top">
      <p>Path in which the cache plugin will save the foo files.</p>
      <p style="margin-top: 8px;"><b>Configuration:</b></p>
      <ul>
      <li>
        <p>INI entry</p>
        <pre>[defaults]
  fact_caching_connection = VALUE</pre>

      </li>
      <li>
        <p>Environment variable: <code>ANSIBLE_CACHE_PLUGIN_CONNECTION</code></p>

      </li>
      </ul>
    </td>
  </tr>
  <tr>
    <td valign="top">
      <div class="ansibleOptionAnchor" id="parameter-bar"></div>
      <p style="display: inline;"><strong>bar</strong></p>
      <a class="ansibleOptionLink" href="#parameter-bar" title="Permalink to this option"></a>
      <p style="font-size: small; margin-bottom: 0;">
        <span style="color: purple;">string</span>
      </p>

    </td>
    <td valign="top">
      <p>Nothing.</p>
    </td>
  </tr>
  </tbody>
  </table>



.. note::

    Configuration entries listed above for each entry type (Ansible variable, environment variable, and so on) have a low to high priority order.
    For example, a variable that is lower in the list will override a variable that is higher up.
    The entry types are also ordered by precedence from low to high priority order.
    For example, an ansible.cfg entry (further up in the list) is overwritten by an Ansible variable (further down in the list).









Authors
~~~~~~~

- Ansible Core (@ansible-core)


Collection links
~~~~~~~~~~~~~~~~

* `Issue Tracker <https://github.com/ansible\-collections/community.general/issues>`__
* `Homepage <https://github.com/ansible\-collections/community.crypto>`__
* `Repository (Sources) <https://github.com/ansible\-collections/community.internal\_test\_tools>`__
* `Submit a bug report <https://github.com/ansible\-community/antsibull\-docs/issues/new?assignees=&labels=&template=bug\_report.md>`__
