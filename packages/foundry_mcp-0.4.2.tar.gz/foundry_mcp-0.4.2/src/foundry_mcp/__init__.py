"""Foundry MCP - MCP server for SDD toolkit spec management."""

__version__ = "0.4.2"

from foundry_mcp.server import create_server, main

__all__ = ["__version__", "create_server", "main"]
