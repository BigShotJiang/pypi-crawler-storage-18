"""Frozen Cub package.

This package provides tools and utilities for creating and managing
immutable (frozen) data structures in Python.
"""

from frozen_cub._internal.cli import main

from .frozen import FrozenDict, freeze
from .utils import CacheKey, check_conditions, get_cache_key

__all__: list[str] = ["CacheKey", "FrozenDict", "check_conditions", "freeze", "get_cache_key", "main"]
