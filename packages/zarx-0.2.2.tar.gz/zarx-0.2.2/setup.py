from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "ZARX: Advanced Hybrid Transformer Framework with MoE, SSM, and Adaptive Routing"

setup(
    name="ZARX",
    version="0.2.2",
    author="Akik Faraji",
    author_email="akikfaraji@gmail.com",
    description="Advanced Hybrid Transformer Framework with MoE, SSM, and Adaptive Routing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/akikfaraji/zarx",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "torch",
        "transformers",
        "tokenizers",
        "sentencepiece",
        "einops",
        "tqdm",
        "numpy",
        "datasets",
        "accelerate",
        "quanto",
        "pydantic",
        "pyarrow",
        "pandas",
        "psutil",
        "scipy",
    ],
    extras_require={
        "dev": [
            "pytest",
            "black",
            "flake8",
        ],
    },
    include_package_data=True,
    package_data={
        "zarx": [
            "tokenizer/pretrained/*.json",
            "tokenizer/pretrained/metadata.json",
        ],
    },
    zip_safe=False,
)
