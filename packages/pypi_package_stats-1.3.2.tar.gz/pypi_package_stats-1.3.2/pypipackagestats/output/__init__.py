"""Output formatting utilities"""

