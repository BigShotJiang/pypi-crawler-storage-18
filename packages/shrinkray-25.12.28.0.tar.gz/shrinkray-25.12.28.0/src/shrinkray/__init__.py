"""Shrink Ray."""
