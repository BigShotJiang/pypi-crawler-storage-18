
import ast
import io
import re
from contextlib import redirect_stdout


class InlinePython:

    START_TOKEN = "<?py"
    END_TOKEN = "?>"
    PRESERVE_NAMESPACE = True
    _ARG_HANDLERS = []
    DEFAULT_PARAMS = []
    
    @classmethod
    def load_config(cls, config:dict):
        api_keys = config["api_key"]
        env_variables = config["env"]
        if "InlinePython" in config.keys():
            tool_config = config["InlinePython"]
            cls.START_TOKEN = tool_config.get("START_TOKEN", cls.START_TOKEN)
            cls.END_TOKEN = tool_config.get("END_TOKEN", cls.END_TOKEN)
            cls.PRESERVE_NAMESPACE = tool_config.get("PRESERVE_NAMESPACE", cls.PRESERVE_NAMESPACE)
            default_params = tool_config.get("DEFAULT_PARAMS", None)
            if default_params is not None:
                if not isinstance(default_params, dict):
                    raise ValueError("InlinePython DEFAULT_PARAMS must be a dict")
                cls.DEFAULT_PARAMS = []
                cls.set_default_params(default_params)

    @classmethod
    def render(cls, text:str):
        if not isinstance(text, str):
            raise ValueError("Text must be a string")

        namespace = {}
        pattern = re.compile(re.escape(cls.START_TOKEN) + r"(.*?)" + re.escape(cls.END_TOKEN), re.DOTALL)

        rendered_parts = []
        last_end = 0

        for match in pattern.finditer(text):
            start, end = match.span()
            rendered_parts.append(text[last_end:start])

            code_block = match.group(1)
            inline_params, code = cls._parse_block(code_block)
            params = cls._merge_params(inline_params)

            code = cls._apply_arg_handlers(code, params)

            output, namespace = cls._run_block(code, namespace, params)
            if params.get("no_output", False):
                rendered_parts.append("")
            else:
                rendered_parts.append(output)

            last_end = end

        rendered_parts.append(text[last_end:])

        return "".join(rendered_parts)

    @classmethod
    def args(cls, key: str):
        def decorator(func):
            cls._register_arg_handler(key, func)
            return func
        return decorator

    @classmethod
    def set_default_params(cls, default: dict):
        if not isinstance(default, dict):
            raise ValueError("Default params must be a dict")
        for key, value in default.items():
            cls.DEFAULT_PARAMS.append((key, value))

    ### PRIVATE UTILITIES START
    @classmethod
    def _parse_block(cls, code_block: str) -> tuple[dict, str]:
        stripped = code_block.lstrip()
        if stripped.startswith("("):
            closing_index = cls._find_matching_parenthesis(stripped)
            if closing_index is None:
                raise ValueError("Invalid InlinePython parameters: missing closing parenthesis")
            params_text = stripped[1:closing_index].strip()
            code = stripped[closing_index + 1:].strip()
            params = cls._parse_params(params_text) if params_text else {}
            return params, code
        return {}, stripped.strip()

    @classmethod
    def _find_matching_parenthesis(cls, text: str) -> int | None:
        depth = 0
        in_string = False
        string_char = ""
        escaped = False
        for index, char in enumerate(text):
            if escaped:
                escaped = False
                continue
            if in_string:
                if char == "\\":
                    escaped = True
                    continue
                if char == string_char:
                    in_string = False
                continue
            if char in ("'", '"'):
                in_string = True
                string_char = char
                continue
            if char == "(":
                depth += 1
                continue
            if char == ")":
                depth -= 1
                if depth == 0:
                    return index
        return None

    @classmethod
    def _apply_arg_handlers(cls, code: str, params: dict) -> str:
        updated_code = code
        handler_map = {}
        for handler_key, handler in cls._ARG_HANDLERS:
            if handler_key not in handler_map:
                handler_map[handler_key] = handler
        for param_key, param_value in params.items():
            if param_key not in handler_map:
                continue
            updated_code = cls._run_arg_handler(handler_map[param_key], param_value, updated_code)
        return updated_code

    @classmethod
    def _run_arg_handler(cls, handler, value, code: str) -> str:
        result = handler(value, code)
        if not isinstance(result, str):
            raise ValueError("InlinePython arg handler must return a string")
        return result

    @classmethod
    def _run_block(cls, code: str, namespace: dict, params: dict) -> tuple[str, dict]:
        current_namespace = namespace if cls.PRESERVE_NAMESPACE else {}
        current_namespace["PARAMS"] = params
        buffer = io.StringIO()
        try:
            with redirect_stdout(buffer):
                exec(code, current_namespace, current_namespace)
        except Exception as error:
            raise RuntimeError(f"InlinePython execution failed: {error}") from error
        return buffer.getvalue(), current_namespace

    @classmethod
    def _register_arg_handler(cls, key: str, handler) -> None:
        if not isinstance(key, str):
            raise ValueError("InlinePython arg handler key must be a string")
        if not callable(handler):
            raise ValueError("InlinePython arg handler must be callable")
        cls._ARG_HANDLERS.append((key, handler))

    @classmethod
    def _merge_params(cls, inline_params: dict) -> dict:
        merged = {}
        for key, value in cls.DEFAULT_PARAMS:
            if key not in merged:
                merged[key] = value
        for key, value in inline_params.items():
            if key in merged:
                continue
            merged[key] = value
        return merged

    @classmethod
    def _parse_params(cls, params_text: str) -> dict:
        if not params_text.strip():
            return {}
        try:
            expression = ast.parse(f"_f({params_text})", mode="eval")
        except SyntaxError as error:
            raise ValueError(f"Invalid InlinePython parameters: {error.msg}") from error
        if not isinstance(expression.body, ast.Call):
            raise ValueError("Invalid InlinePython parameters")
        call = expression.body
        if call.args:
            raise ValueError("InlinePython parameters must be keyword-only")
        params = {}
        for keyword in call.keywords:
            if keyword.arg is None:
                raise ValueError("InlinePython parameters do not support **expansion")
            params[keyword.arg] = cls._literal_value(keyword.value)
        return params

    @classmethod
    def _literal_value(cls, node: ast.AST):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            name = node.id.lower()
            if name == "true":
                return True
            if name == "false":
                return False
            if name == "null":
                return None
            raise ValueError(f"Unsupported name '{node.id}' in parameters")
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            value = cls._literal_value(node.operand)
            if not isinstance(value, (int, float, complex)):
                raise ValueError("Unary minus only supported for numeric values")
            return -value
        if isinstance(node, ast.Dict):
            keys = [cls._literal_value(k) for k in node.keys]
            values = [cls._literal_value(v) for v in node.values]
            return dict(zip(keys, values))
        if isinstance(node, ast.List):
            return [cls._literal_value(elem) for elem in node.elts]
        if isinstance(node, ast.Tuple):
            return tuple(cls._literal_value(elem) for elem in node.elts)
        raise ValueError("Unsupported parameter value")
    ### PRIVATE UTILITIES END