Code documentation
==================
