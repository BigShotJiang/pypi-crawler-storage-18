import shutil
import subprocess
import uuid
from pathlib import Path

import portpicker
import yaml

from xbow_validation_benchmarks_sdk.models.benchmark import Benchmark
from xbow_validation_benchmarks_sdk.models.benchmark import WinCondition
from xbow_validation_benchmarks_sdk.models.challenge import Challenge
from xbow_validation_benchmarks_sdk.models.challenge import Target


class ChallengeManager:
    def __init__(self, xbow_benchmark_folder: Path, public_accessible_host: str) -> None:
        self.xbow_benchmark_folder = xbow_benchmark_folder
        self.public_accessible_host = public_accessible_host

    def create_challenge(self, benchmark: Benchmark, flag: str) -> Challenge:
        if benchmark.win_condition != WinCondition.FLAG:
            raise ValueError('Benchmark win condition must be FLAG')

        challenge_id = str(uuid.uuid4())
        benchmark_path = self.xbow_benchmark_folder / 'benchmarks' / benchmark.id
        challenge_path = Path('challenges') / benchmark.id / challenge_id
        challenge_path.mkdir(parents=True, exist_ok=True)

        challenge = Challenge(
            id=challenge_id,
            benchmark=benchmark,
            flag=flag,
            targets=[],
        )

        shutil.copytree(benchmark_path, challenge_path)

        challenge_docker_compose_path = challenge_path / 'docker-compose.yml'
        with open(challenge_docker_compose_path) as f:
            challenge_docker_compose_object = yaml.safe_load(f)

        unused_host_ports = []
        for service in challenge_docker_compose_object.get('services', {}).values():
            new_ports = []
            for ports in service.get('ports', []):
                if isinstance(ports, str) and ':' in ports:
                    unused_host_port = portpicker.pick_unused_port()
                    unused_host_ports.append(unused_host_port)
                    parts = ports.split(':')
                    new_ports.append(f"{unused_host_port}:{parts[-1]}")
                else:
                    new_ports.append(ports)
            service['ports'] = new_ports

        with open(challenge_docker_compose_path, 'w') as f:
            yaml.dump(challenge_docker_compose_object, f)

        challenge.targets = [
            Target(
                host=self.public_accessible_host, port=unused_port,
            ) for unused_port in unused_host_ports
        ]

        return challenge

    def destroy_challenge(self, challenge: Challenge):
        shutil.rmtree(
            Path('challenges') /
            challenge.benchmark.id / challenge.id,
        )

    def start_challenge(self, challenge: Challenge):
        subprocess.run(
            [
                'docker-compose', '-f', challenge.path /
                'docker-compose.yml', 'up', '-d',
            ], check=True,
        )

    def stop_challenge(self, challenge: Challenge):
        subprocess.run(
            [
                'docker-compose', '-f', challenge.path /
                'docker-compose.yml', 'down',
            ], check=True,
        )
