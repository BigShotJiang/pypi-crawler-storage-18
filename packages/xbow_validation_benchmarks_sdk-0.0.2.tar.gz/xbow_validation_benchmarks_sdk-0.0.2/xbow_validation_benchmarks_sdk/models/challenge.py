from pydantic import BaseModel
from pydantic import Field

from xbow_validation_benchmarks_sdk.models.benchmark import Benchmark


class Target(BaseModel):
    host: str
    port: int


class Challenge(BaseModel):
    id: str = Field(..., description='The id of the challenge')
    benchmark: Benchmark
    flag: str = Field(..., description='The flag of the challenge')
    targets: list[Target] = Field(
        ...,
        description='The targets of the challenge',
    )
