# pkrbot

Fast poker hand evaluator. Drop-in replacement for eval7, 2-3x faster.

## Install

```bash
pip install pkrbot
```

## Usage

```python
import pkrbot

# Simple evaluation
hand = [pkrbot.Card('As'), pkrbot.Card('Kh'), pkrbot.Card('Qd'), pkrbot.Card('Jc'), pkrbot.Card('Ts')]
result = pkrbot.evaluate(hand)
print(pkrbot.handtype(result))  # "Straight"

# Poker game with Board and Hand
deck = pkrbot.Deck()
deck.shuffle()

player = pkrbot.Hand(deck.deal(2))
board = pkrbot.Board(deck.deal(3))  # Flop
board.push(deck.deal(1)[0])  # Turn
board.push(deck.deal(1)[0])  # River

full_hand = player.cards + board.cards
result = pkrbot.evaluate(full_hand)
print(f"{player} on {board} = {pkrbot.handtype(result)}")
```

## API

**Cards**: `pkrbot.Card('As')` - Ranks: `2-9, T, J, Q, K, A`, Suits: `c, d, h, s`

**Deck**: 
- `deck.shuffle()` - Randomize
- `deck.deal(n)` - Remove and return n cards
- `deck.peek(n)` - View top n cards
- `deck.sample(n)` - Get n random cards

**Evaluate**: `result = pkrbot.evaluate(hand)` - Higher values = better hands

**Hand Type**: `pkrbot.handtype(result)` - Returns: "Straight Flush", "Quads", "Full House", "Flush", "Straight", "Trips", "Two Pair", "Pair", "High Card"

**Board**: Community cards with built-in evaluation
- `board = pkrbot.Board([cards])` - Create board
- `board.push(card)` - Add card (flop/turn/river)
- `board.evaluate()` - Evaluate board
- `board.handtype()` - Get hand type
- `board.get_street()` - Get street

**Hand**: Player's hole cards
- `hand = pkrbot.Hand([cards])` - Create hand
- `hand.remove(card)` - Remove a card
- `hand.get_card(index)` - Get card at index

## Performance

~2-3x faster than eval7. Optimized Cython with aggressive compiler flags.

## License

MIT
