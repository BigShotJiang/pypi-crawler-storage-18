# readable-id

[![License MIT](https://img.shields.io/pypi/l/pyreadable-id.svg?color=green)](https://github.com/Karol-G/readable-id/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/pyreadable-id.svg?color=green)](https://pypi.org/project/pyreadable-id)
[![Python Version](https://img.shields.io/pypi/pyversions/pyreadable-id.svg?color=green)](https://python.org)
[![codecov](https://codecov.io/gh/Karol-G/readable-id/branch/main/graph/badge.svg)](https://codecov.io/gh/Karol-G/readable-id)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-purple.json)](https://github.com/copier-org/copier)

**readable-id** generates short, readable, collision-aware identifiers by combining curated words with optional numeric or hash suffixes—designed for experiments, jobs, filenames, and systems where readability matters.

## Why readable-id?

Traditional IDs (UUIDs, hashes) are:

* hard to read
* hard to remember
* hard to communicate
* unpleasant in logs, filenames, and UIs

**readable-id** produces identifiers like:

```
gentle_river_42
silent_orbit_a9f3c2d1
```

They are:

* readable
* easy to communicate
* deterministic when seeded
* configurable for collision safety

## Features

* Predicate–object word structure for readable IDs
* Deterministic generation from a seed
* Configurable number of words and suffix length
* Optional hash-based suffixes
* Collision-space analysis (`--collision`)
* Word trimming for predictable ID length
* Implementations in **Bash** and **Python**
* No sudo required, HPC-readable

## Installation

### Bash (CLI)

The Bash version installs the `rid` command and wordlists locally (no sudo):

```bash
curl -fsSL "https://raw.githubusercontent.com/Karol-G/readable-id/main/bash/install.sh" | bash
```

This installs:

* Binary: `~/.local/bin/rid`
* Wordlists: `~/.local/share/readable-id/` (copied from the Python package’s canonical lists)

Make sure `~/.local/bin` is on your `$PATH`:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

### Python

Install the Python package (example using pip):

```bash
pip install pyreadable_id
```

Or for local development:

```bash
pip install -e .
```

## Usage

### Bash CLI

Generate a readable ID:

```bash
rid
```

Deterministic ID from a seed:

```bash
rid my-seed
```

Use more words and a hash suffix:

```bash
rid -w 3 -n 8 --hash
```

With a seed, the hash suffix is deterministic; without a seed it is random.

Trim words to enforce predictable length:

```bash
rid -t 4
```

Analyze collision space instead of generating an ID:

```bash
rid --collision
```

### Python API

Basic usage:

```python
from readable_id import generate_rid

generate_rid()
# 'gentle_river_42'
```

Deterministic generation:

```python
generate_rid(seed="my-seed")
```

Custom configuration:

```python
generate_rid(
    seed="experiment-001",
    words=3,
    numbers=8,
    use_hash_suffix=True,
    trim=4,
)
```

## Collision awareness

readable-id explicitly exposes the size of its ID space.

Using `--collision` (or the Python equivalent) reports:

* total number of possible IDs
* approximate number of generated IDs needed for an *expected* collision of 1

This helps choose safe parameters instead of guessing.

## Wordlists

IDs are built from curated wordlists:

* **predicates** (verbs / adjectives)
* **objects** (nouns)

Canonical wordlists live in `python/src/readable_id/data/words/` and ship with the Python package. The Bash installer copies those same files into `~/.local/share/readable-id/` for the CLI. Update the canonical files and rerun the installer (or copy them manually) if you want custom lists.

## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [MIT] license,
"readable-id" is free and open source software

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[@napari]: https://github.com/napari
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[file an issue]: https://github.com/Karol-G/readable-id/issues

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
