import re

import pytest

from readable_id import collision_report_from_files, generate_rid


def _parts(rid: str):
    return rid.split('_')


def test_seeded_digits_default_numbers_are_3():
    rid1 = generate_rid(seed='seed-123')
    rid2 = generate_rid(seed='seed-123')
    assert rid1 == rid2
    parts = _parts(rid1)
    assert len(parts[-1]) == 3 and parts[-1].isdigit()


def test_trim_applies_to_words_only():
    rid = generate_rid(seed='seed-trim', words=3, numbers=3, trim=4)
    parts = _parts(rid)
    words = parts[:-1]
    assert all(len(w) <= 4 for w in words)
    assert len(parts[-1]) == 3  # suffix untouched


def test_seeded_hash_is_deterministic_hex():
    rid1 = generate_rid(seed='hash-seed', numbers=5, use_hash_suffix=True)
    rid2 = generate_rid(seed='hash-seed', numbers=5, use_hash_suffix=True)
    assert rid1 == rid2
    suffix = _parts(rid1)[-1]
    assert len(suffix) == 5
    assert re.fullmatch(r'[0-9a-f]+', suffix)


def test_unseeded_hash_is_random_hex():
    rid1 = generate_rid(numbers=4, use_hash_suffix=True)
    rid2 = generate_rid(numbers=4, use_hash_suffix=True)
    assert rid1 != rid2  # probabilistic but with 16^4 space collision is unlikely
    for suffix in (_parts(rid1)[-1], _parts(rid2)[-1]):
        assert len(suffix) == 4
        assert re.fullmatch(r'[0-9a-f]+', suffix)


@pytest.mark.parametrize(
    'use_hash,numbers',
    [
        (False, 3),
        (True, 4),
    ],
)
def test_collision_report_contains_expected_fields(use_hash: bool, numbers: int):
    report = collision_report_from_files(words_count=2, numbers=numbers, use_hash_suffix=use_hash)
    assert 'combinations_M' in report
    assert 'n_for_Ecollision_1' in report
    if use_hash:
        assert f'suffix:     hex hash length {numbers}' in report
    else:
        assert f'suffix:     digits length {numbers}' in report
