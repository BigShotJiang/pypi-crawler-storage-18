try:
    from ._version import version as __version__
except ImportError:
    __version__ = "unknown"

from .api import RidError, collision_report_from_files, generate_rid, collision_report

__all__ = [
    "__version__",
    "RidError",
    "collision_report_from_files",
    "generate_rid",
    "collision_report",
]
