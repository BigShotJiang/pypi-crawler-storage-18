# Physical Properties (polykin.properties)
