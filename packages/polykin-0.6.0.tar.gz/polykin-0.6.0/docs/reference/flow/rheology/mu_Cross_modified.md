# polykin.flow.rheology

::: polykin.flow.rheology
    options:
        members:
            - mu_Cross_modified
