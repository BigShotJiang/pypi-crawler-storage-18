"""Google Alerts MCP Server"""

__version__ = "0.1.0"