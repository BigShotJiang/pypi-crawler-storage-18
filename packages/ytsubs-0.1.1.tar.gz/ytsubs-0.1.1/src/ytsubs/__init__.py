"""YouTube subscriptions CLI tooling."""
