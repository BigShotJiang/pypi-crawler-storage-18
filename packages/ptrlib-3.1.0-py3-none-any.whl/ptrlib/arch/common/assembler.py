import contextlib
import os
import subprocess
import tempfile
from logging import getLogger
from ptrlib.types import PtrlibArchT, PtrlibBitsT, PtrlibAssemblySyntaxT
from ptrlib.arch.intel import assemble_intel, is_arch_intel, bit_by_arch_intel
from ptrlib.arch.arm   import assemble_arm, is_arch_arm, bit_by_arch_arm
from ptrlib.binary.encoding import *

logger = getLogger(__name__)


def assemble(code: str | bytes,
             bits: PtrlibBitsT = 64,
             arch: PtrlibArchT = 'intel',
             syntax: PtrlibAssemblySyntaxT='intel',
             entry: str | None = None,
             gcc_path: str | None = None,
             objcopy_path: str | None = None) -> bytes | None:
    """Assemble code with GCC

    Args:
      code (str): Assembly code
      bits (int): Architecture bits (32 or 64)
      arch (str): Architecture (Intel, ARM)
      syntax (str): AT&T or Intel (Intel by default)
      entry (str): Symbol of entry point
      gcc_path (str): Path to gcc compiler
      objcopy_path (str): Path to objcopy executable

    Returns:
      bytes: Machine code
    """
    if isinstance(code, str):
        code = str2bytes(code)
    else:
        code = bytes(code)

    if code[-1] != 0x0a:
        code += b'\n'

    if entry is None:
        entry = 'ptrlib_main'
        code = b'.global ptrlib_main\nptrlib_main:\n' + code

    if is_arch_intel(arch):
        if syntax.lower() == 'intel':
            code = b'.intel_syntax noprefix\n' + code
        if bits is None:
            bits = bit_by_arch_intel(arch)
            if bits == -1: bits = 64
        return assemble_intel(code, bits, entry, gcc_path, objcopy_path)

    elif is_arch_arm(arch):
        if bits is None:
            bits = bit_by_arch_arm(arch)
            if bits == -1: bits = 64
        return assemble_arm(code, bits, entry, gcc_path, objcopy_path)

    else:
        raise ValueError("Unknown architecture '{}'".format(arch))


def nasm(code: str | bytes,
         fmt: str='bin',
         bits: int=64,
         org: int | None = None,
         nasm_path: str | None = None):
    """Assemble x86/x86-64 code with NASM

    Args:
      code (str): Assembly code
      fmt (str): Output format (See `nasm -hf` for availabel formats)
      bits (int): Architecture bits (Default is 64)
      org (int): Specify address (ORG instruction)
      nasm_path (str): Path to NASM executable

    Returns:
      bytes: Machine code (or binary data if `fmt` is not "bin")
    """
    from ptrlib.arch.common import which
    if nasm_path is None:
        nasm_path = which('nasm')
        if nasm_path is None:
            raise FileNotFoundError("'nasm' not found.\n"
                                    "You can install it with `apt install nasm`")

    if isinstance(code, str):
        code = str2bytes(code)

    if bits is not None:
        code = 'BITS {}\n'.format(bits).encode() + code
    if org is not None:
        code = 'ORG {}\n'.format(org).encode() + code

    fname_s = os.path.join(tempfile.gettempdir(), os.urandom(24).hex())+'.S'
    fname_o = os.path.join(tempfile.gettempdir(), os.urandom(24).hex())+'.o'
    with open(fname_s, 'wb') as f:
        f.write(code)

    output: bytes | None = None
    with open(fname_o, 'wb+') as f, contextlib.suppress(FileNotFoundError):
        p = subprocess.Popen([nasm_path, "-f{}".format(fmt), fname_s, "-o", fname_o],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if p.wait() != 0:
            _, err = p.communicate()
            logger.error("===== Assemble failed =====")
            logger.error(err.decode())
            logger.error("===== Code =====")
            for i, line in enumerate(code.decode().split('\n')):
                logger.error(f"{i+1:5d}: {line}")
            os.unlink(fname_s)
            raise SyntaxError("Assemble failed")

        f.seek(0)
        output = f.read()

    with contextlib.suppress(FileNotFoundError):
        # Seperate context for Windows
        os.unlink(fname_s)
        os.unlink(fname_o)

    assert output is not None
    return output
