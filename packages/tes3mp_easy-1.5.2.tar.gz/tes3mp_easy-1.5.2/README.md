# 🐉 TES3MP Easy

**The "Easy Button" for playing and hosting Morrowind Multiplayer on Linux.**

A powerful Python CLI tool that automates the installation, configuration, network diagnostics, and **server hosting** for TES3MP (Morrowind via OpenMW).

[![PyPI version](https://badge.fury.io/py/tes3mp-easy.svg)](https://badge.fury.io/py/tes3mp-easy)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features
* **Zero-Hassle Client:** Installs the engine and links your Data Files automatically.
* **Smart Config:** Detected and fixed the "duplicate content files" bug automatically (v1.4.2+).
* **Connection Doctor:** Built-in network diagnostics for Ping and Tailscale tunnels.
* **Server-Only Mode:** Deploy a dedicated server on a VPS (Oracle Cloud, AWS) without graphical dependencies.
* **Tailscale Integration:** Detects, installs, and manages Tailscale tunnels for easy non-port-forwarded hosting.
* **Systemd Generator:** Creates persistent background services for your server with one command (v1.5.0+).

---

## 🚀 Installation

### Option A: The Easy Way (PyPI)
Install the latest stable version:
```bash
pip install tes3mp-easy
```

### Option B: The Developer Way (GitHub)
Install from source:
```bash
pip install git+https://github.com/flywiththetide/TES3MP-Easy.git
```

---

## 🎮 How to Use (Client)
Once installed, simply type this in your terminal:
```bash
tes3mp-easy
```
The interactive menu will guide you through Setup, Server Hosting, and Diagnostics.

---

## 🖥️ Server Hosting (Interactive)
Want to host a server for friends?
1. Run `tes3mp-easy`.
2. Select **Server Settings**.
3. Choose **Install Server**.
4. Follow the prompts to set a name and password.
5. Select **Start Server**.

> **Tailscale Support:** The tool will automatically detect if you have Tailscale. If you do, it will offer to start it and give you your **Tailscale IP** to share with friends, bypassing the need for port forwarding!

---

## 🤖 Advanced Automation (Headless / VPS)
**New in v1.5.0!**

You can deploy a production-ready dedicated server in **one command**. This is perfect for setting up a server on Oracle Cloud, AWS, or DigitalOcean via a startup script.

```bash
tes3mp-easy --server --install --name "MyServer" --password "secret" --service
```

### Breakdown of Flags:
| Flag | Description |
|------|-------------|
| `--server` | **Server-Only Mode.** Skips all graphical checks (Flatpak, Client). Safe for headless VPS. |
| `--install` | **Auto-Install.** Downloads TES3MP and dependencies (libluajit, etc.) automatically without prompts. |
| `--name "X"` | Sets the server name in `tes3mp-server-default.cfg`. |
| `--password "X"` | Sets the server password. |
| `--service` | **Magic Mode.** Generates a `systemd` service file (`/etc/systemd/system/tes3mp.service`), enables it, and starts it. |

**Result:** Your server is installed, configured, and running in the background. It will auto-restart if the server reboots!

---

## 🛠️ Troubleshooting

### "Content files specified more than once"
If you see this error, you likely have duplicate entries in your config files.
**Fix:** Just update to v1.4.2+ and run `tes3mp-easy` once. It automatically scans both your Global (`~/.config/openmw`) and Local (`~/.local/share/tes3mp`) configs and removes duplicates.

### "Texture not found" / "Meshes missing"
Ensure you have pointed the tool to a valid Morrowind `Data Files` directory containing `Morrowind.esm`, `Tribunal.esm`, and `Bloodmoon.esm`.
You can reset the path by running `tes3mp-easy` and selecting **Option 5 (Set Data Files Path)**.

---

## 📂 Requirements
- **OS**: Linux (Ubuntu, Arch, Fedora, SteamOS, etc.)
- **Python**: 3.8 or higher.
- **Game Files**: You must own Morrowind (GOG/Steam) and have the `Data Files` folder.
- **Root/Sudo**: Required only for installing system dependencies (`apt install`) or systemd services.

## 🤝 Contributing
Found a bug?
1. Open an issue on [GitHub](https://github.com/flywiththetide/TES3MP-Easy/issues).
2. Fork the repo and submit a PR.
