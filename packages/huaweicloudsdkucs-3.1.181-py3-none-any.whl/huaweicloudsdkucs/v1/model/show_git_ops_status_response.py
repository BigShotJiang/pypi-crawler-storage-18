# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowGitOpsStatusResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'metadata': 'ListMeta',
        'items': 'list[Pod]'
    }

    attribute_map = {
        'metadata': 'metadata',
        'items': 'items'
    }

    def __init__(self, metadata=None, items=None):
        r"""ShowGitOpsStatusResponse

        The model defined in huaweicloud sdk

        :param metadata: 
        :type metadata: :class:`huaweicloudsdkucs.v1.ListMeta`
        :param items: Pod列表
        :type items: list[:class:`huaweicloudsdkucs.v1.Pod`]
        """
        
        super().__init__()

        self._metadata = None
        self._items = None
        self.discriminator = None

        if metadata is not None:
            self.metadata = metadata
        if items is not None:
            self.items = items

    @property
    def metadata(self):
        r"""Gets the metadata of this ShowGitOpsStatusResponse.

        :return: The metadata of this ShowGitOpsStatusResponse.
        :rtype: :class:`huaweicloudsdkucs.v1.ListMeta`
        """
        return self._metadata

    @metadata.setter
    def metadata(self, metadata):
        r"""Sets the metadata of this ShowGitOpsStatusResponse.

        :param metadata: The metadata of this ShowGitOpsStatusResponse.
        :type metadata: :class:`huaweicloudsdkucs.v1.ListMeta`
        """
        self._metadata = metadata

    @property
    def items(self):
        r"""Gets the items of this ShowGitOpsStatusResponse.

        Pod列表

        :return: The items of this ShowGitOpsStatusResponse.
        :rtype: list[:class:`huaweicloudsdkucs.v1.Pod`]
        """
        return self._items

    @items.setter
    def items(self, items):
        r"""Sets the items of this ShowGitOpsStatusResponse.

        Pod列表

        :param items: The items of this ShowGitOpsStatusResponse.
        :type items: list[:class:`huaweicloudsdkucs.v1.Pod`]
        """
        self._items = items

    def to_dict(self):
        import warnings
        warnings.warn("ShowGitOpsStatusResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowGitOpsStatusResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
