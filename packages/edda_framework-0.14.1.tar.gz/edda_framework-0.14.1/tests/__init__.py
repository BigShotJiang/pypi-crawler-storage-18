"""Tests for Kairo framework."""
