"""
Dynamic element processor that analyzes XML structure and processes elements
"""

import xml.etree.ElementTree as ET
from typing import Optional, Dict, Callable, List, Any
from html import escape
from collections import defaultdict


def get_text(element: Optional[ET.Element]) -> str:
    """Safely get text from an Element, handling None."""
    if element is None:
        return ""
    
    text_parts = []
    if element.text:
        text_parts.append(element.text.strip())
    
    for child in element:
        if child.text:
            text_parts.append(child.text.strip())
        if child.tail:
            text_parts.append(child.tail.strip())
    
    return " ".join(text_parts)


def escape_html(text: str) -> str:
    """Escape HTML special characters."""
    return escape(text)


class ElementProcessor:
    """Dynamic processor that analyzes XML structure and processes elements"""
    
    def __init__(self, config=None):
        self.config = config
        self.processors = {}
        self.element_stats = defaultdict(int)
        
    def analyze_xml_structure(self, root: ET.Element) -> Dict[str, Any]:
        """
        Analyze XML structure to understand element hierarchy and relationships
        
        Returns:
            Dictionary with structure information
        """
        structure = {
            'elements': set(),
            'hierarchy': defaultdict(set),
            'attributes': defaultdict(set),
            'text_elements': set(),
            'container_elements': set(),
        }
        
        def traverse(elem: ET.Element, parent_tag: Optional[str] = None):
            tag = self._clean_tag(elem.tag)
            structure['elements'].add(tag)
            
            if parent_tag:
                structure['hierarchy'][parent_tag].add(tag)
            
            # Collect attributes
            for attr, value in elem.attrib.items():
                structure['attributes'][tag].add(attr)
            
            # Check if element has text content
            if elem.text and elem.text.strip():
                structure['text_elements'].add(tag)
            
            # Check if element has children
            if len(elem) > 0:
                structure['container_elements'].add(tag)
                for child in elem:
                    traverse(child, tag)
        
        traverse(root)
        return structure
    
    def _clean_tag(self, tag: str) -> str:
        """Remove namespace from tag"""
        if self.config and self.config.strip_namespace:
            if '}' in tag:
                return tag.split('}')[1]
        return tag
    
    def register_processor(self, element_name: str, processor: Callable):
        """Register a custom processor for a specific element"""
        self.processors[element_name] = processor
    
    def get_processor(self, element_name: str) -> Callable:
        """Get processor for element, with fallback to default"""
        if element_name in self.processors:
            return self.processors[element_name]
        return self._default_processor
    
    def _default_processor(self, element: ET.Element, context: Dict = None) -> str:
        """Default processor for unknown elements - truly dynamic"""
        if context is None:
            context = {}
        
        tag = self._clean_tag(element.tag)
        text = get_text(element)
        has_children = len(element) > 0
        has_text = text and text.strip()
        
        # Build attributes string
        attrs = []
        for key, value in element.attrib.items():
            # Clean namespace from attribute names
            clean_key = key.split('}')[-1] if '}' in key else key
            attrs.append(f'{clean_key}="{escape_html(str(value))}"')
        attrs_str = ' ' + ' '.join(attrs) if attrs else ''
        
        # Determine HTML tag based on element name patterns and content
        if 'Title' in tag or 'Caption' in tag or 'Heading' in tag:
            level = 1
            if 'Title' in tag:
                # Try to extract level from tag name (e.g., Title1, Title2)
                for i in range(1, 7):
                    if f'Title{i}' in tag or tag.endswith(str(i)):
                        level = i
                        break
            html_tag = f'h{min(level, 6)}'
            return f'<{html_tag} class="{tag.lower()}"{attrs_str}>{escape_html(text)}</{html_tag}>'
        elif 'Sentence' in tag or 'Text' in tag or 'Paragraph' in tag:
            if has_children:
                content = self.process_children(element, context)
                return f'<p class="{tag.lower()}"{attrs_str}>{content}</p>'
            else:
                return f'<p class="{tag.lower()}"{attrs_str}>{escape_html(text)}</p>'
        elif 'Item' in tag or 'List' in tag:
            if has_children:
                content = self.process_children(element, context)
                return f'<li class="{tag.lower()}"{attrs_str}>{content}</li>'
            else:
                return f'<li class="{tag.lower()}"{attrs_str}>{escape_html(text)}</li>'
        elif 'Table' in tag or 'Row' in tag or 'Column' in tag:
            return self._process_table_like(element, context)
        elif 'List' in tag or 'List' in tag.lower():
            content = self.process_children(element, context)
            return f'<ul class="{tag.lower()}"{attrs_str}>{content}</ul>'
        elif 'Section' in tag or 'Chapter' in tag or 'Part' in tag:
            content = self.process_children(element, context)
            title = text if has_text and not has_children else ''
            if title:
                return f'<section class="{tag.lower()}"{attrs_str}><h2>{escape_html(title)}</h2>{content}</section>'
            else:
                return f'<section class="{tag.lower()}"{attrs_str}>{content}</section>'
        else:
            # Generic container - use div or section based on depth
            content = self.process_children(element, context) if has_children else ''
            
            # For important container elements (like MainProvision, Body), always render even if empty initially
            important_containers = ['mainprovision', 'lawbody', 'law', 'body', 'content', 'document']  # law/lawbody for backward compatibility
            is_important = tag.lower() in important_containers
            
            # Clean up empty content, but keep important containers
            if not content.strip() and not has_text:
                if is_important:
                    # Important containers should still be rendered to allow children to be processed
                    return f'<div class="{tag.lower()}"{attrs_str}></div>'
                return ''  # Skip empty non-important elements
            
            # If element has both text and children, wrap text in a paragraph only if meaningful
            if has_text and has_children:
                text_clean = text.strip()
                if text_clean and len(text_clean) > 2:  # Only add paragraph if text is meaningful
                    content = f'<p class="element-text">{escape_html(text_clean)}</p>{content}'
            elif has_text and not has_children:
                text_clean = text.strip()
                if text_clean and len(text_clean) > 2:
                    content = escape_html(text_clean)
                elif not is_important:
                    return ''  # Skip elements with only whitespace (unless important)
            
            # Use semantic HTML when possible
            if tag.lower() in ['header', 'head', 'footer', 'nav', 'main', 'article', 'aside']:
                return f'<{tag.lower()} class="{tag.lower()}"{attrs_str}>{content}</{tag.lower()}>'
            else:
                # Always render if there's content or if it's an important container
                if content.strip() or is_important:
                    return f'<div class="{tag.lower()}"{attrs_str}>{content}</div>'
                return ''
    
    def _process_table_like(self, element: ET.Element, context: Dict = None) -> str:
        """Process table-like structures"""
        if context is None:
            context = {}
        
        tag = self._clean_tag(element.tag)
        
        if 'Row' in tag or 'row' in tag.lower():
            # This is a table row
            html = '<tr>'
            for child in element:
                child_tag = self._clean_tag(child.tag)
                if 'Column' in child_tag or 'Cell' in child_tag or 'col' in child_tag.lower():
                    content = self.process_children(child, context) if len(child) > 0 else escape_html(get_text(child))
                    html += f'<td class="{child_tag.lower()}">{content}</td>'
                else:
                    content = self.process_children(child, context) if len(child) > 0 else escape_html(get_text(child))
                    html += f'<td class="{child_tag.lower()}">{content}</td>'
            html += '</tr>'
            return html
        elif 'Column' in tag or 'Cell' in tag or 'col' in tag.lower():
            # This is a table cell
            content = self.process_children(element, context) if len(element) > 0 else escape_html(get_text(element))
            return f'<td class="{tag.lower()}">{content}</td>'
        else:
            # This is a table container
            html = f'<table class="{tag.lower()}">'
            # Look for rows or process children as rows
            rows = element.findall('.//*[Row]') or element.findall('.//*[row]') or [e for e in element if 'Row' in self._clean_tag(e.tag)]
            if rows:
                for row in rows:
                    html += self._process_table_like(row, context)
            else:
                # Process children as rows
                for child in element:
                    child_tag = self._clean_tag(child.tag)
                    if 'Row' in child_tag or 'row' in child_tag.lower():
                        html += self._process_table_like(child, context)
                    else:
                        # Treat as a row
                        html += '<tr>'
                        content = self.process_children(child, context) if len(child) > 0 else escape_html(get_text(child))
                        html += f'<td class="{child_tag.lower()}">{content}</td>'
                        html += '</tr>'
            html += '</table>'
            return html
    
    def process_children(self, element: ET.Element, context: Dict = None) -> str:
        """Process all children of an element"""
        if context is None:
            context = {}
        
        html_parts = []
        for child in element:
            processor = self.get_processor(self._clean_tag(child.tag))
            html_parts.append(processor(child, context))
        
        return ''.join(html_parts)
    
    def process_element(self, element: ET.Element, context: Dict = None) -> str:
        """Process a single element"""
        if context is None:
            context = {}
        
        tag = self._clean_tag(element.tag)
        self.element_stats[tag] += 1
        
        processor = self.get_processor(tag)
        return processor(element, context)


def get_default_processors() -> Dict[str, Callable]:
    """Get default processors for common XML elements"""
    from .processors import get_all_processors
    return get_all_processors()

