---
title: "Groveで始める仕様駆動開発"
emoji: "🚀"
type: "tech"
topics: ["GitHub", "AI", "開発効率化", "仕様駆動開発", "Grove"]
published: false
---

# はじめに

https://www.amazon.co.jp/dp/B0DQDWM1YK

https://cardene.notion.site/EIP-2a03fa3ea33d43baa9ed82288f98d4a9

https://twitter.com/cardene777

https://zenn.dev/heku

https://cardene.substack.com/

https://mirror.xyz/0xACAc709e21e7a4A5a4458BDeeCCA0fc98A6a8A4D

今回は「**Groveによる仕様駆動開発**」についてまとめていきます。

この記事では、GitHubが公開している **Spec Kit** の拡張版である **Grove** を紹介します。

Spec Kitは、仕様駆動開発を実践するためのオープンソースツールキットです。

Claude Code、GitHub Copilot、Google Geminiなど、17種類以上のAIエージェントに対応しています。

Groveは、各AI Agentごとに特化した形でSpec Kitを使用できるようにした拡張版です。

多言語対応（日本語・英語）、テンプレートシステム、エージェント設定の自動管理、ワークフロー自動化など、開発体験を向上させる機能を追加しています。

https://github.com/github/spec-kit

https://github.com/cardene/grove

## Spec-Driven Developmentとは

**Spec-Driven Development（仕様駆動開発）** は、仕様を実行可能な成果物として扱う開発手法です。
従来の「**コードファースト**」な開発とは異なり、仕様から直接実装を生成します。
仕様は単なるドキュメントではなく、プロジェクトにおける単一の情報源として機能します。
AIエージェントが仕様を読み取ってコードを生成するため、仕様とコードが常に同期した状態を保てます。
実装の品質と一貫性が自動的に保証され、チーム全体で同じ仕様を共有できます。

# Spec Kitとは

### Spec Kitの特徴

**Spec Kit** は、GitHubが公開している仕様駆動開発を実践するためのオープンソースツールキットです。
2024年にGitHubからリリースされ、AIエージェントを活用した開発ワークフローを標準化しています。

https://github.com/github/spec-kit

従来の開発では、仕様書は作成後すぐに陳腐化し、コードと乖離していくという問題がありました。
Spec Kitは、仕様を「**実行可能な成果物**」として扱うことで、この問題を解決します。
AIエージェントが仕様から直接コードを生成するため、仕様とコードが常に同期した状態を保てます。
仕様を更新すれば、それに応じた実装の変更も自動的に反映されます。
AIコーディングエージェントとの連携を前提に設計されており、どんな技術スタックでも使用できます。
組織の制約やコンプライアンス要件も考慮し、エンタープライズ環境でも安心して利用できます。
実装前に複数回仕様をブラッシュアップできるため、手戻りを最小限に抑えられます。
17種類以上のAIエージェントに対応しています。

https://github.com/github/spec-kit/blob/main/AGENTS.md

### Spec Kitの開発フロー

Spec Kitは、以下の5つのステップで開発を進めます。

#### 1. Constitution（憲法作成）

プロジェクトの原則と開発ガイドラインを定義します。
AIエージェントのコマンドを使用して、プロジェクトの憲法を作成します。
コーディング規約、アーキテクチャ原則、品質基準、セキュリティポリシーが定義されます。
この憲法は、プロジェクト全体での開発の指針となり、AIエージェントがコード生成する時に参照します。

#### 2. Specify（仕様作成）

実装したい機能の詳細な仕様を作成します。
AIエージェントのコマンドを使用して、機能仕様を生成します。
ユーザーストーリー、機能要件、技術要件、制約条件が含まれます。
仕様は、実装の設計図として機能し、AIエージェントがこれを基にコードを生成します。

#### 3. Plan（実装計画）

仕様に基づいた実装計画を立てます。
AIエージェントのコマンドを使用して、技術実装計画を生成します。
アーキテクチャ設計、技術選定、ファイル構成、データモデルが定義されます。

#### 4. Tasks（タスク分解）

実装計画を実行可能なタスクに分解します。
AIエージェントのコマンドを使用して、タスクリストを生成します。
優先順位付きタスクリスト、各タスクの実装手順、依存関係、見積もり時間が含まれます。

#### 5. Implement（実装実行）

タスクに基づいて実際に実装を行います。
AIエージェントのコマンドを使用して、実装を開始します。
AIエージェントが仕様、計画、タスクを参照しながら、自動的にコードを生成します。

#### 6. 追加機能

Spec Kitには、開発をサポートする追加機能も用意されています。
**Clarify（明確化）** は、曖昧な部分を質問形式で明確にします。
**Analyze（一貫性検証）** は、憲法、仕様、計画、タスクの整合性をチェックします。
**Checklist（品質確認）** は、実装前の最終確認を行います。

# Groveとは

**Grove** は、オリジナルのSpec Kitに以下の機能を追加した拡張版です。

## Grove の主要機能

### t-wada式TDD統合

Test-Driven Developmentをすべてのタスクで強制します。

```
各タスクごとに:
  Red      → テスト失敗を確認
  Green    → 最小限の実装でテストを通過
  Refactor → テストを維持したまま改善
  Review   → AI自動検証
```

日本のTDD暗黙知をAIが実行可能な形に形式化しています。

### 3層AIレビューシステム

**Implementation → Self Review → Cross Review** の品質保証体制を構築します。

| レイヤー | 実行者 | タイミング | 目的 |
|-------|----------|--------|---------|
| **レイヤー1: Implementation** | AI Agent | 実装中 | TDDワークフローでコード生成 |
| **レイヤー2: Self Review** | 同じAI Agent | 実装直後（バックグラウンド） | 8項目自動検証 + Auto-Fix |
| **レイヤー3: Cross Review** | 異なるAI Agent | 必要に応じて | 異なる視点からの追加検証 |

**Self Review自動化の流れ**:
```
T001完了 → Self Review起動（バックグラウンド）
T002完了 → Self Review起動（バックグラウンド）
T003完了 → Self Review起動（バックグラウンド）
      ↓
全完了 → レポート生成 → Auto-Fix（最大3回試行）
```

**8項目検証チェックリスト**
1. ✅ 仕様との整合性
2. ✅ 技術スタックの遵守
3. ✅ タスク完全性
4. ✅ テストカバレッジ
5. ✅ エラーハンドリング
6. ✅ セキュリティ
7. ✅ パフォーマンス
8. ✅ コード品質

**スコアリング**: 0-100点（Critical: -30点、High: -20点、Medium: -10点、Low: -5点）
**合格基準**: 80点以上

### 3. ⚡ バックグラウンド並列実行

従来のシーケンシャル実行では、実装完了後に検証が終わるまで待機する必要がありました。

```text
実装 → 検証（待機） → 実装 → 検証（待機） → ...
```

Groveでは、検証をバックグラウンドで実行することで、次のタスクにすぐ取り掛かれます。

```text
実装 → 検証（バックグラウンド）
  ↓
実装 → 検証（バックグラウンド）
  ↓
実装 → 検証（バックグラウンド）
  ↓
全完了 → 結果収集 → 修正
```

待機時間を削減し、開発速度を約28%向上させます。

### 4. 🎨 Frontend Design統合

Claude Code Marketplaceの `frontend-design` スキルと統合し、UI/UX仕様を自動生成します。
デザインシステム（colors、typography、spacing）、コンポーネント仕様とコード、レイアウト仕様とコード、レスポンシブブレークポイントを含みます。
`/grove.design` コマンドで、仕様から直接デザイン成果物を生成できます。

### 5. 🌍 多言語サポート

日本語と英語に完全対応し、60以上の翻訳キーでグローバルチームでの利用を支援します。
テンプレートを言語別に管理（`templates/ja/`、`templates/en/`）し、コマンド出力を自動翻訳します。
ドキュメントも多言語に対応しています。

### 6. 🛠️ CLI統合

`grove` コマンドでワークフローを効率化します。

```bash
grove init         # プロジェクト初期化
grove constitution # 憲法作成
grove specify      # 仕様作成
grove design       # デザイン仕様作成
grove plan         # 実装計画作成
grove tasks        # タスク分解
grove implement    # 実装実行
grove review       # AIレビュー
grove fix          # 問題自動修正
```

### 7. 🔄 Constitution自動同期

`.grove/memory/constitution.md` を `.claude/rules/constitution.md` に自動同期し、Claude Code環境でプロジェクト原則をすべてのインタラクションで強制します。

### 8. 📋 統一コマンドシステム

17種類以上のAIエージェントで統一された `/grove.*` コマンドを提供します。
エージェント依存のコマンド差異を吸収し、`.grove/` ディレクトリで統一的な構造を管理します。
エージェント設定は自動的に管理されます。

## Spec KitとGroveの違い

| 項目 | Spec Kit（オリジナル） | Grove（拡張版） |
|------|---------------------|--------------|
| 開発元 | GitHub | cardene |
| リポジトリ | github/spec-kit | cardene/grove |
| ワークフロー | 5ステップ | 6ステップ（**Design追加**） |
| コマンド | (各AIエージェント依存) | `/grove.*` 統一コマンド |
| CLI | なし | `grove` コマンド |
| ディレクトリ | (エージェント依存) | `.grove/` 統一 |
| TDD統合 | ❌ | ✅ t-wada方式 |
| Constitution Sync | ❌ | ✅ `.claude/rules/` 自動同期 |
| Designステップ | ❌ | ✅ UI/UX仕様生成 |
| 多言語サポート | ❌ | ✅ 日本語/英語（60+翻訳キー） |
| テンプレート管理 | 共通 | 言語別分離 + 共通 |
| ファイル存在チェック | Bash | Read tool（確認不要） |
| プロジェクト構造同期 | ❌ | ✅ `grove sync` |
| ワークフロー自動実行 | ❌ | ✅ `grove workflow` |

## Groveの開発フロー

Groveは、Spec Kitの5ステップに **Design（デザイン仕様）** を追加した6ステップで開発を進めます。

**ワークフロー**: Constitution → Specify → **Design** → Plan → Tasks → Implement

以下、各ステップの詳細をGrove固有の機能とともに説明します。

### 1. Constitution（憲法作成）

プロジェクトの原則と開発ガイドラインを定義します。
Claude Codeを起動して `/grove.constitution` を実行するか、CLIから `grove constitution --ai claude` を実行します。
テンプレートファイル（`constitution-template.md` で `enabled: true`）が存在する場合、自動的に読み込まれます。
コマンド実行する時に、AIエージェントが自然言語の要求を読み取り、テンプレートのプレースホルダーを具体的な値に置き換えます。
コーディング規約、アーキテクチャ原則、品質基準、セキュリティポリシーが生成され、`constitution.md` に保存されます。

**Constitution Sync機能（Grove固有）**

`/grove.constitution` 実行する時に、constitution が自動的に `.claude/rules/constitution.md` に同期されます。
これにより、Claude Code環境ではプロジェクト原則がすべてのインタラクションで強制されます。

### 2. Specify（仕様作成）

実装したい機能の詳細な仕様を作成します。
Claude Codeを起動して `/grove.specify` を実行するか、CLIから `grove specify --ai claude` を実行します。
テンプレートファイル（`spec-template.md` で `enabled: true`）が存在する場合、自動的に読み込まれ、ユーザーストーリー、機能要件、技術要件、制約条件が生成されます。
生成された仕様は `spec.md` に保存され、`load-project-context` スキルを通じて参照されます。

### 3. Design（デザイン仕様作成）**← Grove固有機能**

UI/UXデザインの仕様を定義します。
Claude Codeを起動して `/grove.design` を実行するか、CLIから `grove design` を実行します。

**Agent別の出力先**

Claude Code環境では `.claude/skills/design-creator/skill.md` にskillとして実装されます。
その他のagentでは `.grove/design.md` にmarkdownファイルとして保存されます。

**デザインファイルの自動抽出**

`.grove/design/` ディレクトリ内のデザインファイル（PNG, SVG, PDF, Figma, Sketch, Adobe XD等）を配置すると、UIコンポーネント（Button, Card, Input等）、レイアウト・グリッドシステム、デザインシステム（カラーパレット、タイポグラフィ、スペーシング）、インタラクションパターン、アクセシビリティガイドライン、実装ガイダンス（CSS方法論、命名規則等）が自動的に抽出されます。
デザイン仕様は feature ごとではなく、プロジェクト全体で一貫した設計として管理されます。
これにより、実装フェーズでデザイン仕様を参照する時、デザインの意図を正確に実装できます。

### 4. Plan（実装計画）

仕様とデザインに基づいた実装計画を立てます。
Claude Codeを起動して `/grove.plan` を実行するか、CLIから `grove plan --ai claude` を実行します。
アーキテクチャ設計、技術選定、ファイル構成、データモデルが生成されます。

**デザイン仕様の参照（Grove固有）**

`.grove/design/` が存在する場合、デザイン制約を自動的に抽出して技術計画に統合します。
生成された計画は `plan.md` に保存されます。

### 5. Tasks（タスク分解）

実装計画を実行可能なタスクに分解します。
Claude Codeを起動して `/grove.tasks` を実行するか、CLIから `grove tasks --ai claude` を実行します。
優先順位付きタスクリスト、各タスクの実装手順、依存関係、見積もり時間が生成されます。

**TDD対応（Grove固有）**

各タスクに**TDDチェックリスト**が自動的に含まれます。
チェックリスト形式のタスクテンプレートは以下の通りです

```markdown
## Task: [Task Description]

### 対応Spec
- `spec/[filename].md#[section]`

### TDDチェック（task単位）
- [ ] Red（新規テストを追加し、失敗を確認した）
- [ ] Green（最小実装でテストを通した）
- [ ] Refactor（振る舞いを変えず整理した）

### 制約
- Specは変更しない
- このtask以外は触らない
```

このチェックリストは**確認**であって**手順**ではありません。

task完了時に1回だけチェックします。

生成されたタスクは `tasks.md` に保存されます。

### 6. Implement（実装実行）

タスクに基づいて実際に実装を行います。

Claude Codeを起動して以下を実行します。

```
`/grove.implement`
```

または、CLIから実行します。

```bash
grove implement --ai claude
```

AIエージェントが仕様、計画、タスクを参照しながら、自動的にコードを生成します。

**TDDワークフロー統合（Grove固有）**

implementフェーズで**t-wada流のTDDサイクル**が実行されます。

各タスクについて以下のサイクルを回します。

1. **Red**: テストを書く
   - 新規テストケースを追加
   - テストが失敗することを確認（RED状態）
   - デザイン仕様がある場合: `design-system.md`を参照

2. **Green**: 通す（最小実装）
   - テストを通す最小限の実装
   - デザイン仕様がある場合: コンポーネント仕様に従う
   - テストが成功することを確認（GREEN状態）

3. **Refactor**: 整える
   - 構造を改善
   - デザイン仕様がある場合: デザイントークンを適用
   - テストを通したまま整理

4. **Update task checklist**: `tasks.md`のチェックリストを更新
   - [X] Red（新規テストを追加し、失敗を確認した）
   - [X] Green（最小実装でテストを通した）
   - [X] Refactor（振る舞いを変えず整理した）

implementでは何回Red→Green→Refactorを回してもよく、記録はtaskの✔だけです。

**実装完了後の自動仕様更新（Grove固有）**

実装が成功すると、各実装ステップ完了ごとに `grove sync --auto` が自動実行され、プロジェクトドキュメントが最新のソースコード構造で更新されます。

これにより、次の開発サイクルで常に最新の仕様を参照できます。

### 7. 追加コマンド

Groveには、開発をサポートする追加コマンドがあります。
Clarify（明確化）コマンド `/grove.clarify` は、曖昧な部分を質問形式で明確にします。
Analyze（一貫性検証）コマンド `/grove.analyze` は、憲法、仕様、計画、タスクの整合性をチェックします。
Checklist（品質確認）コマンド `/grove.checklist` は、実装前の最終確認を行います。

## 多言語対応（日本語・英語）

日本語と英語の両方に対応しています。
`--lang` オプションで言語を指定すると、バナー表示、メッセージ、生成されるコンテンツが指定した言語で表示されます。

### 言語設定の永続化

`grove init --lang ja` を実行すると、以下のファイルが作成されます。
**`config.json`** は言語設定をJSON形式で保存します

```json:`config.json`
{
  "language": {
    "code": "ja",
    "name": "Japanese (日本語)",
    "set_at": "project_initialization"
  },
  "project": {
    "name": "project-name"
  }
}
```

**`CLAUDE.md`**（プロジェクトルート）は AIエージェントへの指示を含みます。
言語設定の参照（`config.json` から読み込む）、テンプレート使用方法、プロジェクトコンテキストが含まれます。
これにより、Claude Codeなどのエージェントは自動的に指定された言語でコンテンツを生成します。

**ファイル配置**

```
project-root/
├── `CLAUDE.md`                    # プロジェクトルートに配置
└── .grove/
    ├── memory/
    │   └── `config.json`          # 言語設定（JSON形式）
    └── templates/
        └── *-template.md
```

### 実装の仕組み

**I18N辞書**

```python:i18n.py
SUPPORTED_LANGUAGES = ["ja", "en"]

I18N = {
    "ja": {
        "tagline": "仕様駆動開発のためのCLIツール",
        "help_usage": "使用方法：grove <command> [options]",
        # ... 60以上のキー
    },
    "en": {
        "tagline": "CLI tool for Spec-Driven Development",
        "help_usage": "Usage: grove <command> [options]",
        # ...
    }
}

def t(key: str) -> str:
    """翻訳文字列を取得"""
    return I18N[_current_lang].get(key, key)
```

すべてのメッセージが `t("key")` 関数を通じて翻訳されます。

**実装詳細**

グローバル言語設定では `_current_lang` グローバル変数で現在の言語を管理します。
`set_lang()` 関数は各コマンドの最初で呼び出され、言語を設定します。
`t(key)` 関数は翻訳キーから現在の言語の文字列を取得します。
I18N辞書は日本語・英語の翻訳データを格納します（60以上の翻訳キー）。

**完全翻訳対応**

`init` コマンドはすべてのメッセージが完全に翻訳対応しています（エラーメッセージ、警告、プロジェクトセットアップ、次のステップガイド等）。
その他のコマンド（`constitution`, `specify`, `plan`, `tasks`, `implement`）も `set_lang()` を使用して言語設定を適用します。

```mermaid
sequenceDiagram
    participant User
    participant CLI as grove CLI
    participant Lang as set_lang()
    participant I18N as I18N辞書
    participant Output as 出力

    User->>CLI: grove init --ai claude --lang ja
    CLI->>Lang: set_lang("ja")
    Lang->>Lang: _current_lang = "ja"
    CLI->>I18N: t("tagline")
    I18N-->>CLI: "Grove - 仕様駆動開発ツールキット"
    CLI->>Output: 日本語でバナー表示
    CLI->>Output: 日本語でメッセージ表示
```

### 使い方

```bash
# 日本語で初期化
grove init . --ai claude --lang ja

# 英語で初期化
grove init . --ai claude --lang en

# インタラクティブ選択（--langを省略）
grove init . --ai claude
# → [1] English / [2] 日本語 (Japanese) から選択

# その他のコマンドでも指定可能
grove constitution --ai claude --lang ja
grove specify --ai claude --lang en
```

**言語選択**

`--lang` を省略すると、インタラクティブな言語選択UIが表示されます。
`[1] English` / `[2] 日本語 (Japanese)` から選択できます。

:::message
今後他の言語にも対応させていく予定です。
言語追加はI18N辞書に新しいキーを追加するだけで可能です。
:::

spec-kitは英語のみの対応でしたが、Groveでは多言語対応を実装しました。

## 責務分離アーキテクチャ

Groveは、プロジェクトの成果物を明確に分離して管理する「**責務分離アーキテクチャ**」を採用しています。

### ディレクトリ構造

```
.claude/
├── commands/                   # Slash Commands（全エージェント共通）
│   ├── grove.constitution
│   ├── grove.specify
│   ├── grove.design
│   ├── grove.plan
│   ├── grove.tasks
│   ├── grove.implement
│   ├── grove.analyze
│   ├── grove.checklist
│   ├── grove.clarify
│   └── grove.taskstoissues
├── rules/                      # Claude Code Rules
│   └── `constitution.md`         # Constitution auto-synced
└── agents/                     # Subagents（Claude Code専用）
    └── implement-agent.md

.grove/
├── specs/                      # 機能仕様
│   └── {feature-id}/
│       ├── `spec.md`             # 要件とユーザーストーリー
│       ├── `plan.md`             # 技術実装計画
│       ├── `tasks.md`            # タスク分解
│       ├── data-model.md       # データエンティティと関係
│       ├── contracts/          # API仕様
│       ├── quickstart.md       # 統合シナリオ
│       └── research.md         # 技術的決定
├── design/                     # デザイン仕様
│   ├── README.md               # Design overview
│   ├── `design-system.md`        # Design tokens
│   ├── components/             # Component specs & code
│   └── layouts/                # Layout specs & code
└── docs/                       # ソースコードドキュメント（参照用）
    └── {src}/
        ├── index.md            # ディレクトリ構造概要
        ├── README.md           # 詳細仕様
        └── {filename}.md       # 個別ファイルドキュメント
```

### 責務の分類

| 場所 | 目的 | 自動ロード? | 更新方法 |
|------|------|------------|----------|
| Commands | ワークフロー実行（全エージェント共通） | ❌ なし（明示的呼び出し） | `/grove.*` コマンド |
| Rules | プロジェクト原則の強制（Claude Code） | ✅ Claude Codeで自動適用 | `/grove.constitution` |
| Agents | 長時間タスクの独立実行（Claude Code専用） | ❌ なし（Commandから起動） | `grove init` |
| 仕様 | 特定機能の要件、計画、タスク | ❌ なし（機能固有） | `/grove.*` コマンド |
| デザイン | UI/UX仕様、コンポーネント定義 | ❌ なし（plan/implement時に参照） | `/grove.design` |
| ドキュメント | ソースコード構造、パターン、変更履歴 | ❌ なし（Command経由でロード） | `grove sync` |

### 設計原則

**Commandsがワークフローを提供**します。
全エージェント共通のワークフローをCommandsで定義します。
**Rulesがプロジェクト原則を強制**します。
Claude Code環境で自動的に適用されます。
**Agentsが長時間タスクを処理**します。
Claude Code専用のSubagentが独立コンテキストで実行します。
**仕様は機能固有**です。
各機能の仕様は独自ディレクトリに配置されます。
**デザインはプロジェクト全体で統一**されます。
UI/UX仕様はプロジェクト全体で一貫して管理されます。
**ドキュメントは参照材料**です。
ソースコードドキュメントはコードベース構造をミラーリングします。

### ワークフロー統合

すべてのコアコマンド（`/grove.specify`、`/grove.design`、`/grove.plan`、`/grove.implement`）は、既存のプロジェクト構造を理解し、確立されたパターンと規約を特定します。
デザイン仕様を考慮した実装を行い、新しい実装が現在のアーキテクチャに従うことを保証します。
機能間で一貫性を維持します。

## プロジェクト構造の自動同期と階層的ドキュメント管理

Groveは、ソースコード構造を解析して参照ドキュメントを自動的に同期する機能を提供します。

### taskごとのドキュメント自動更新

`grove implement` 実行する時に、taskごとにドキュメントを自動更新する機能を実装しています。
実装完了後の一括更新ではなく、各task完了する時にリアルタイムで更新されるため、大規模な実装でも更新漏れがありません。

**Claude Code使用する時**

非同期subagentがバックグラウンドでファイル変更を監視し、自動的にドキュメントを更新します。

```python
# 非同期subagent起動プロンプト（自動実行）
"""
Spawn async subagent to monitor file changes and update documentation:

Your task is to run in the background and monitor for file changes during implementation.

1. **For new files**
   - Generate documentation in `.grove/docs/` following the project structure
   - Use the same format as existing docs

2. **For modified files**
   - Append change history entry with timestamp and description

3. **For deleted files**
   - Append deletion note to the corresponding documentation
"""
```

**他のエージェント使用する時**

各task完了する時にプロンプトでドキュメント更新を指示します。
更新漏れがあった場合は、フォールバックとして `record_implementation_changes()` が自動的に補完します。

**初回実行する時の自動sync**

`.grove/docs/` が存在しない場合、implement実行前に自動的に `sync` を実行します。
ベースドキュメントを生成してから実装を開始するため、最初から構造化されたドキュメントが利用できます。

**ディレクトリ構造**

```
.grove/
└── docs/
    └── {source_dir}/           # ソースディレクトリ（src, app, lib等を自動検出）
        ├── README.md           # ディレクトリ構造 + 概要
        ├── {filename}.md       # ファイルごとのドキュメント
        └── {subdir}/           # サブディレクトリ（再帰）
            ├── README.md
            └── ...
```

**ファイル名規則**

デフォルトでは `example.py` → `example.md` のように拡張子を削除します。
重複する時のみ `example.py` と `example.ts` → `example.py.md` と `example.ts.md` のように拡張子を残します。

**メリット**

taskごとの更新により、各task完了する時に同期されるため、抜け漏れがありません。
外部依存なしで、Claude Code標準機能を活用します（watchdog等のライブラリ不要）。
すべてのエージェントで動作し、Claude Code以外もプロンプト指示で対応します。
設定不要で自動的に動作し、ユーザーの手間がかかりません。

### `grove sync` コマンド

プロジェクトのソースコード構造を解析し、階層的なドキュメントを自動生成します。
ソースディレクトリは自動検出されます（src, app, lib, pkg, source, code, core など）。

```bash
# 現在のプロジェクトを同期（ソースディレクトリ自動検出）
grove sync

# カスタムソースディレクトリを指定
grove sync --src app

# 全ドキュメントを自動生成（既存を上書き）
grove sync --auto
```

**自動検出の動作**

`src`, `app`, `lib`, `pkg`, `source`, `code`, `core` の中から実際にソースファイルが存在するディレクトリを検出します。
複数検出された場合は最初のものを使用します（別のものを使う場合は `--src` で指定）。
検出されない場合は `--src` オプションで明示的に指定します。

**生成されるファイル**

各ディレクトリに以下の3種類のファイルが生成されます。

**index.md** は、ディレクトリ全体の構造とファイル一覧を提供します。
ディレクトリツリー構造を表示し、各ファイルの役割を一文で説明します。
クイックリファレンスとして機能します。

**README.md** は、ディレクトリの詳細仕様を含みます。
サブディレクトリの役割、ファイル一覧と説明、実装ポイント、変更履歴が記録されます。

**{ファイル名}.md** は、個別ファイルのドキュメントです。
ファイルの概要、主要な関数・クラス、依存関係、使用例が含まれます。

**生成例**

```
docs/
└── src/
    ├── index.md              # src全体の構造とファイル一覧
    ├── README.md             # src全体の仕様
    ├── frontend/
    │   ├── index.md          # frontend全体の構造
    │   ├── README.md         # frontend全体の仕様
    │   └── components/
    │       ├── index.md      # components全体の構造
    │       ├── README.md     # components全体の仕様
    │       ├── Button.md     # Button.tsx のドキュメント
    │       └── Input.md      # Input.tsx のドキュメント
    └── backend/
        ├── index.md
        ├── README.md
        └── api/
            ├── index.md
            ├── README.md
            └── auth.md       # auth.py のドキュメント
```

これらのドキュメントは参照用として生成され、`load-project-context` スキルを通じて必要に応じて読み込まれます。
Claude Codeによる自動読み込み対象ではないため、コンテキストを汚染しません。

### `grove update-doc` コマンド

ソースファイルの変更履歴を簡単に記録できます。

```bash
# TypeScriptコンポーネントの変更履歴を追加
grove update-doc src/frontend/components/Button.tsx "Added hover state animation"

# Python APIファイルの変更履歴を追加
grove update-doc src/backend/api/auth.py "Fixed authentication bug"
```

**実行結果**

```markdown:Button.md
## 変更履歴

### 2025-12-11: Added hover state animation

### 2025-12-10: 初回作成
- 初期実装
```

変更履歴は日付順に管理され、最新の変更が最初に表示されます。

### 自動同期機能のメリット

taskごとの自動更新により、各task完了する時にリアルタイムで同期されます。
大規模な実装でも更新漏れがなく、実装完了後の一括更新よりも確実です。

スキルベースのコンテキストロードでは、`load-project-context` スキルを通じて必要な時にだけドキュメントをロードします。
Claude Codeの自動読み込みによるコンテキスト汚染を防止します。

階層的なドキュメント管理により、ディレクトリ構造に沿って整理されます。
index.md で全体構造を把握し、README.md で詳細仕様を確認できます。

変更履歴の自動記録により、いつ、何を変更したかが明確になります。
チーム全体で変更を追跡可能です。

効率的なコンテキスト制御では、必要な情報だけをスキル経由で読み込みます。
不要な情報でコンテキストを圧迫しません。

外部依存なしで、Claude Code標準機能を活用します。
watchdog等の追加ライブラリが不要で、すべてのエージェントで動作します。

## テンプレート管理の改善

Groveでは、テンプレートを言語別に分離し、より柔軟な管理を実現しています。

### テンプレートの分類

テンプレートは以下の2種類に分類されます。

**言語固有テンプレート** は `templates/{lang}/` から配置されます。
`constitution-template.md` と `spec-template.md` が含まれます。

**共通テンプレート** は `templates/` ルートから配置されます。
`plan-template.md`, `tasks-template.md`, `checklist-template.md`, `agent-file-template.md` が含まれます。

### ファイル存在チェックの改善

すべてのコマンドで、Read tool を使用したファイル存在チェックを実装しています。
これにより、Bash コマンド実行する時のユーザー確認プロンプトが不要になり、スムーズな実行が可能です。

```python
# 従来（Bash使用）
result = subprocess.run(["test", "-f", file_path])

# 新方式（Read tool使用）
try:
    read_file(file_path)
    file_exists = True
except FileNotFoundError:
    file_exists = False
```

## frontend-design skill統合

Groveでは、**Claude Code Marketplaceの専門skill**を活用した統一ワークフローを実装しました。
specify（要件定義）と plan（技術設計）の間に **Design（デザイン仕様）** ステップを追加し、UI/UXの一貫性を保ちます。

### 実装内容

#### 1. design.md更新

Claude Code Marketplaceから `frontend-design` skillをインストールします。
`.grove/spec.md` を自動読み込みし、frontend-design skillを実行してデザインコードを生成します。
生成されたコードを `.grove/design/` に保存します。

**出力構造**

```
.grove/design/
├── README.md              # Design overview
├── `design-system.md`       # Design tokens
├── components/            # Component specs & code
└── layouts/               # Layout specs & code
```

#### 2. `plan.md`更新

`.grove/design/` ディレクトリの存在を確認します。
デザイン制約を抽出します（UI framework（React, Vue等）、CSS methodology（Tailwind, CSS Modules等）、Design tokens（colors, typography, spacing）、Component architecture patterns、Responsive breakpoints、Accessibility requirements）。

**技術計画への統合**

Technical Contextにデザイン制約を統合します。
デザインコンポーネントと技術実装をマッピングします。

#### 3. implement-agent.md更新

`.grove/design/` ディレクトリを読み込みます。
デザイン制約の抽出ロジックを追加します。
UI実装する時にデザイン仕様を参照します（コンポーネント仕様に従った実装、デザインシステムトークンの使用、レイアウトパターンの適用、レスポンシブデザイン実装、アクセシビリティ機能実装）。

### ワークフロー統一

```
1. `/grove.specify`
   ↓ .grove/`spec.md` 生成

2. `/grove.design` (Claude Code only)
   ↓ frontend-design skill実行
   ↓ .grove/design/ 生成

3. `/grove.plan`
   ↓ spec + design 参照
   ↓ .grove/`plan.md` 生成

4. `/grove.implement`
   ↓ plan + design 参照
   ↓ 実装実行
```

### メリット

Marketplaceの専門skillを使用することで、独自skill開発が不要になります（専門性の活用）。
Marketplace更新に自動追従するため、保守性が向上します。
spec → design → plan → implement の統一フローで一貫性を確保します。
デザインからコード生成することで、実装が容易になります（実装ready）。

### Design機能の特徴

#### 1. Claude Code環境専用

デザイン仕様生成は、Claude Code環境でのみ利用可能です。
Claude Code Marketplaceの `frontend-design` skillを使用するため、他のエージェントでは手動でデザイン仕様を作成する必要があります。

#### 2. デザインファイルからの自動抽出

`.grove/design/` ディレクトリ内にデザインファイルを配置すると、以下の情報が自動的に解析・抽出されます。

**対応デザインファイル形式**

ラスター画像（PNG, JPG, JPEG）、ベクター画像（SVG）、ドキュメント（PDF）、デザインツール（Figma, Sketch, Adobe XD）に対応しています。

**抽出される仕様**

1. **デザインシステム**
   - カラーパレット（プライマリ、セカンダリ、アクセント、グレースケール）
   - タイポグラフィ（フォントファミリー、サイズ、ウェイト、行高）
   - スペーシング（マージン、パディング、グリッド）

2. **コンポーネントライブラリ**
   - Button（プライマリ、セカンダリ、アウトライン、テキスト）
   - Card（基本、画像付き、ヘッダー付き）
   - Input（テキスト、パスワード、検索、テキストエリア）
   - その他（Modal, Dropdown, Badge等）

3. **レイアウト・グリッドシステム**
   - グリッドカラム数
   - ガター幅
   - ブレークポイント（モバイル、タブレット、デスクトップ）
   - レイアウトパターン

4. **インタラクションパターン**
   - ホバー状態
   - フォーカス状態
   - アクティブ状態
   - ディセーブル状態
   - ローディング状態

5. **アクセシビリティガイドライン**
   - カラーコントラスト比
   - フォーカスインジケーター
   - ARIAラベル
   - キーボードナビゲーション

6. **実装ガイダンス**
   - CSS方法論（BEM, CSS Modules, Styled Components等）
   - 命名規則
   - レスポンシブ対応
   - アニメーション・トランジション

#### 3. プロジェクト全体での一貫性

デザイン仕様は feature ごとではなく、プロジェクト全体で一貫した設計として管理されます。
すべての機能実装で同じデザインシステムを参照するため、UI/UXの一貫性が自動的に保たれます。

### 使用方法

#### デザインファイルの配置

```bash
# デザインファイル用ディレクトリを作成
mkdir -p .grove/design

# デザインファイルを配置
cp path/to/design.png .grove/design/
cp path/to/wireframe.pdf .grove/design/
```

#### デザイン仕様の生成

**方法1: Claude Code内で実行（推奨）**

```
`/grove.design`
```

**方法2: CLIから実行**

```bash
grove design
```

#### デザイン仕様の参照

実装フェーズ（ `implement` ）で、AIエージェントが自動的にデザイン仕様を参照します。

Claude Code環境では、skillとして読み込まれます。

### デザインワークフローの統合

```
Constitution（プロジェクト原則）
    ↓
Specify（要件定義）
    ↓
Design（デザイン仕様）← ここで UI/UX を定義
    ↓
Plan（技術設計）← デザイン仕様を参照して技術選定
    ↓
Tasks（タスク分解）
    ↓
Implement（実装）← デザイン仕様を参照してコード生成
```

### メリット

プロジェクト全体で統一されたデザインシステムを使用するため、UI/UXの一貫性が保たれます。
デザイン仕様を参照することで、デザイナーの意図を正確に反映できます（デザイン意図の正確な実装）。
定義済みのコンポーネントやスタイルを再利用するため、実装効率が向上します。
デザイン変更する時に仕様を更新すれば実装も追従するため、メンテナンス性が向上します。
ガイドラインに従った実装が自動的に行われるため、アクセシビリティが確保されます。

## t-wada TDDワークフロー統合

Groveでは、**t-wada流のTDDワークフロー**をSpec Kitのフェーズ構造に統合しました。

TDDは `implement` フェーズでのみ実行し、 `task` では「**その task を完了する過程で TDDをきちんと回したか**」をチェックリストで確認します。

### TDDとSpec Kitフェーズの対応

t-wadaのTDDワークフローは、以下のステップで構成されます。

1. **テストリストを書く**（振る舞いの分析）
2. **テストを1つ書く**（Red）
3. **テストを通す**（Green）
4. **必要に応じてリファクタリング**（Refactor）
5. **テストリストが空になるまで繰り返す**

Spec Kitフェーズとの対応は以下の通りです。

| t-wada ワークフロー | Spec Kit フェーズ | 役割 |
|-------------------|------------------|------|
| Step1 テストリスト | **spec / plan / task** | 振る舞いの分析・分解 |
| Step2 テストを書く | **implement** | Red |
| Step3 通す | **implement** | Green |
| Step4 リファクタ | **implement** | Refactor |
| Step5 繰り返し | **task単位で反復** | 進行管理 |

**重要なポイント**

- t-wadaのStep1は `implement` の外にあり、実装ではなく**分析（analysis）**です。
- Step2〜4が **implement内のTDDループ**として実行されます。
- Step5の「**繰り返し**」は、task単位で自然に実現されます。

### TDDチェックの単位

チェックの単位は **taskごとに1回** です。

```
1 task = 1 意味単位 = 1 TDDチェック
```

**チェックのタイミング**

- 全体で1回 ❌
- task内の各コミットごと ❌
- task内の各実装要素ごと ❌
- **task完了時に1回だけ確認** ✅

taskは「**テストリストから、次にやるべき"ひとつ"を選び出した状態**」です。

implementで何回Red→Green→Refactorを回しても、記録はtaskの✔だけになります。

### 実装された機能

#### Tasks（タスク分解）でのTDD対応

`tasks.md` では、TDDチェックリスト形式でタスクが生成されます。

各タスクには以下が含まれます。

- **対応Spec**
  参照先の仕様

- **TDDチェック**
  Red、Green、Refactorの3項目（task単位）

- **制約**
  Spec変更禁止、他タスク触らない

**チェックリストの意味**

- ❌ TDDを実行する手順ではない
- ✅ **実行されたかの確認**

✔が付かなくても失敗ではなく、未達の場合は理由を書きます。

#### Implement（実装実行）でのTDD対応

`implement.md` では、以下の機能が実装されています。

1. **前提条件チェック**

   - `spec.md`, `plan.md`, `tasks.md` の存在確認（必須）
   - .grove/design/ の存在確認（オプション）

2. **TDDサイクル実装**

   - Red→Green→Refactorの明示的な実行手順
   - .grove/design/ 参照機能の統合
   - `tasks.md`のチェックリスト更新機能

3. **進捗管理強化**

   - TDDチェックリスト追跡機能
   - タスク完了時の検証プロセス

implementでは**普通にt-wada流TDDを回すだけ**です。

何回TDDサイクルを回したかは記録せず、task完了時にtaskのチェックリストに✔を付けるだけです。

### 設計の正当性

この設計は、t-wadaのTDD暗黙知を構造化したものです。

1. **混乱しない**: 単位が明確（1 task = 1 TDDチェック）
2. **Spec Kitの思想を壊さない**: 仕様駆動開発の原則を維持
3. **t-wada流TDDを形式知化**: 実行可能な手順として定義
4. **人間にもAI Agentにも適用可能**: どちらでも実行できる
5. **最小から始めて拡張可能**: シンプルな構造
6. **観測可能**: 三層確認で実際にTDDが実行されたか検証できる

## テンプレートシステム（ `enabled` フラグによる制御）

Groveは、YAMLフロントマターの `enabled` フラグでテンプレートを制御する独自のテンプレートシステムを実装しています。

#### テンプレートの配置

**Groveリポジトリ内**（開発時）

```
grove/
└── templates/
    ├── ja/                              # 日本語テンプレート
    │   ├── constitution-template.md
    │   └── spec-template.md
    ├── en/                              # 英語テンプレート
    │   ├── constitution-template.md
    │   └── spec-template.md
    └── common/                          # 共通テンプレート
        ├── plan-template.md
        ├── tasks-template.md
        ├── checklist-template.md
        └── agent-file-template.md
```

**プロジェクト内**（init後）

```
your-project/
└── .grove/
    └── templates/
        ├── constitution-template.md     # enabledフラグ付き
        ├── spec-template.md            # enabledフラグ付き
        ├── plan-template.md            # enabledフラグ付き
        ├── tasks-template.md           # enabledフラグ付き
        └── checklist-template.md       # enabledフラグ付き
```

#### テンプレートのインストール

`grove init` 実行時に、以下の処理が行われます。

1. **GitHubからエージェント設定をダウンロード**（ `github/spec-kit` リポジトリから）
   - スラッシュコマンド定義
   - エージェント設定
   - 古い形式のテンプレート（enabledフラグなし）

2. **ローカルから言語固有のテンプレートをコピー**（ `install_language_templates(project_dir, lang)` 関数）
   - 言語に応じた enabled フラグ付きテンプレートで上書き
   - `--lang ja` の場合（**全テンプレート日本語翻訳完了**）
     - constitution-template.md ✅
     - spec-template.md ✅
   - `--lang en` の場合は英語版を使用
   - フォールバック（指定言語が存在しない場合は英語版を使用）

3. **共通テンプレートをコピー**（ `install_common_templates(project_dir)` 関数）
   - plan-template.md
   - tasks-template.md
   - checklist-template.md
   - agent-file-template.md

```mermaid
flowchart TD
    A[grove init] --> B[GitHubからダウンロード]
    B --> C[github/spec-kit リポジトリ]
    C --> D[スラッシュコマンド]
    C --> E[古い形式テンプレート]

    A --> F[install_language_templates<br/>with lang parameter]
    F --> G{指定された言語}
    G -->|--lang ja| H[templates/ja/<br/>日本語テンプレート]
    G -->|--lang en| I[templates/en/<br/>英語テンプレート]
    H --> K[上書きコピー]
    I --> K

    A --> L[install_common_templates]
    L --> M[templates/common/<br/>共通テンプレート]
    M --> N[コピー]

    D --> O[プロジェクト完成]
    K --> O
    N --> O

    style H fill:#90EE90
    style I fill:#90EE90
    style M fill:#87CEEB
    style K fill:#90EE90
    style N fill:#87CEEB
```

#### テンプレートの有効化

各テンプレートファイルの先頭にYAMLフロントマターがあります。

```yaml:constitution-template.md
---
enabled: true
description: Project constitution template defining core principles and governance
version: 1.0.0
---
```

`enabled: true` の場合、コマンド実行時に自動的にこのテンプレートが読み込まれ、AIエージェントがプレースホルダーを具体的な値に置き換えます。

### 使い方

1. **プロジェクト初期化**
   - 通常は `grove init . --ai claude --lang ja`
   - オフライン/テスト用は `grove init . --ai claude --lang ja --local-only`
   - 自動的に enabled フラグ付きテンプレートがインストールされる

2. **テンプレートの確認** `*-template.md` を確認
   - YAMLフロントマターの `enabled` フラグを確認

3. **必要に応じてカスタマイズ** プレースホルダーやセクション構成を変更
   - テンプレートを無効化したい場合は、 `enabled: false` に変更

4. **コマンド実行** `/grove.*` または `grove *` コマンドを実行
   - 自動的にテンプレートが読み込まれ、AIエージェントが処理

## エージェント設定の自動管理とインストール

Groveは、17種類以上のAIエージェントに対応しており、各エージェント用の設定ファイルを自動的にインストール・管理します。

### サポートされているAIエージェント

https://github.com/github/spec-kit/blob/main/AGENTS.md

Claude Code、GitHub Copilot、Google Gemini、Codex、Cursor、Windsurf、Codyなど、17種類以上のAIエージェントに対応しています。

### エージェント設定ファイル

`grove init` 実行時に、選択したAIエージェント用の設定ファイルが自動的にインストールされます。

#### `CLAUDE.md`（Claude Code専用）

Claude Code専用の設定ファイルです。

プロジェクトルートに配置されます。

```
project-root/
├── `CLAUDE.md`                    # Claude Code専用設定
└── .grove/
    └── memory/
        └── `config.json`          # 言語設定など
```

**`CLAUDE.md`の役割**

- 言語設定の参照（ `config.json` から読み込む）
- テンプレート使用方法の説明
- プロジェクトコンテキストの提供
- Claude Code固有のワークフロー指示

#### AGENTS.md（その他のエージェント共通）

Claude Code以外のAIエージェント（GitHub Copilot、Gemini、Cursorなど）で共通して使用できる設定ファイルです。

**AGENTS.mdの役割**

- 汎用的なプロジェクトガイドライン
- Spec-Driven Developmentワークフローの説明
- テンプレート使用方法
- 各コマンドの使い方

### 自動インストールの仕組み

`grove init` 実行時に以下の処理が行われます。

1. **GitHubから最新設定をダウンロード**（ `github/spec-kit` リポジトリから）
   - スラッシュコマンド定義
   - エージェント設定ファイル（`CLAUDE.md` または AGENTS.md）
   - 古い形式のテンプレート

2. **ローカルから言語固有のテンプレートをコピー**
   - enabled フラグ付きテンプレートで上書き

3. **言語設定を永続化**
   - 言語設定を保存
   - `CLAUDE.md` または AGENTS.md から `config.json` を参照

### 使い方

```bash
# Claude Code用の設定をインストール
grove init . --ai claude --lang ja

# GitHub Copilot用の設定をインストール
grove init . --ai copilot --lang en

# AIエージェントをインタラクティブに選択
grove init . --lang ja
# → [1] Claude Code / [2] GitHub Copilot / ... から選択
```

エージェント設定が未インストールの場合、必要に応じて自動的にダウンロード・インストールされます。

## ワークフローコマンドによる自動実行

`workflow` コマンドを使用すると、constitution → specify → **design** → plan → tasks → implement の全ステップを自動的に実行できます。

### 基本的な使い方

```bash
# プロジェクトの初期化
grove init my-project --ai claude --lang ja
cd my-project

# ワークフロー全体を自動実行
grove workflow "ユーザー認証機能を追加" --ai claude
```

### 実行される処理

`workflow` コマンドは以下を自動的に実行します。

1. **constitution（憲法）の作成**
   - 未作成の場合のみ実行
   - プロジェクトの原則とガイドラインを定義
   - `.claude/rules/constitution.md` に自動同期

2. **specify（仕様）の作成**
   - 機能要件とユーザーストーリーを生成
   - `spec.md` に保存

3. **design（デザイン仕様）の作成**
   - UI/UXデザインの仕様を定義
   - Claude Code: `.claude/skills/design-creator/skill.md` に保存
   - その他: `.grove/design.md` に保存

4. **plan（実装計画）の作成**
   - アーキテクチャ設計と技術選定
   - デザイン仕様を参照して技術選定
   - `plan.md` に保存

5. **tasks（タスク分解）の作成**
   - 実行可能なタスクに分解
   - `tasks.md` に保存

6. **implement（実装）の実行**
   - タスクに基づいて実装を開始
   - デザイン仕様を参照してコード生成
   - AIエージェントが自動的にコードを生成

7. **実装変更の自動記録**
   - `grove sync --auto` を自動実行
   - 最新の状態に更新

### テンプレートの自動読み込み

各ステップでテンプレート（ `enabled: true` のもの）が自動的に読み込まれ、AIエージェントに渡されます。

### メリット

1. **手作業の削減**
   - 各コマンドを個別に実行する必要がない
   - ワークフロー全体を一度に実行

2. **一貫性の確保**
   - すべてのステップが同じコンテキストで実行される
   - 仕様と実装の乖離を防止

3. **自動同期**
   - 実装完了後、自動的にドキュメントを更新
   - 常に最新の仕様を参照可能

4. **時間の節約**
   - 手動でのコマンド実行と比較して大幅に時間を短縮
   - 開発サイクルの高速化

## インストール方法

### 前提条件

- Python 3.11以上
- uv（Pythonパッケージマネージャー）
- AIエージェント（Claude Code推奨）

### Groveのインストール

#### 永続的インストール（推奨）

一度インストールすれば、どこでも使用できます。

```bash
uv tool install grove-cli --from git+https://github.com/cardene/grove.git
```

#### ワンタイム実行

インストールせずに直接実行することも可能です。

```bash
uvx --from git+https://github.com/cardene/grove.git grove init <PROJECT_NAME>
```

**永続的インストールのメリット**

ツールがPATHに追加されて利用可能になり、 `uv tool list` 、 `uv tool upgrade` 、 `uv tool uninstall` で簡単に管理できます。

シェル設定もクリーンに保たれます。

## 使い方

Groveは、ステップごとに実行する方法と、ワークフロー全体を自動実行する方法の2つの使い方があります。

### 方法A: ワークフロー自動実行（推奨）

`workflow` コマンドを使用すると、constitution → specify → plan → tasks → implement の全ステップを自動的に実行できます。

```bash
# 1. プロジェクトの初期化
grove init my-project --ai claude --lang ja
cd my-project

# 2. ワークフロー全体を自動実行
grove workflow "ユーザー認証機能を追加" --ai claude
```

このコマンドは以下を自動的に実行します。

- constitution（憲法）の作成（未作成の場合のみ）
- specify（仕様）の作成
- **design（デザイン仕様）の作成**
- plan（実装計画）の作成
- tasks（タスク分解）の作成
- implement（実装）の実行
- 実装変更の自動記録（ `record_implementation_changes()` ）

各ステップでテンプレートが自動的に読み込まれ、エージェントに渡されます。

### 方法B: ステップごとに実行

より細かく制御したい場合は、各コマンドを個別に実行できます。

#### 1. プロジェクトの初期化

新規プロジェクトを作成する場合は、以下のように実行します。

```bash
grove init my-project --ai claude --lang ja
cd my-project
```

`init` コマンドは、GitHubの `github/spec-kit` リポジトリから最新のテンプレートをダウンロードし、選択したAIエージェント（この場合はClaude Code）用の設定ファイルとスラッシュコマンド（ `/grove.*` ）を自動的にインストールします。

既存プロジェクトに追加する場合は、以下のように実行します。

```bash
cd existing-project
grove init . --ai claude --lang ja
```

#### 2. プロジェクト憲法の作成

プロジェクトの原則と開発ガイドラインを定義します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.constitution`
```

**方法2 CLIから実行**

```bash
# Claude Codeで憲法を作成
grove constitution --ai claude
```

`constitution.md` に生成され、Claude Code環境では `.claude/rules/constitution.md` に自動同期されます。

#### 3. 機能仕様の作成

実装したい機能の仕様を作成します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.specify`
```

**方法2 CLIから実行**

```bash
grove specify --ai claude
```

`spec.md` に生成されます。

:::message
**feature-idの決定方法**

1. **環境変数 `GROVE_FEATURE`** が設定されている場合、その値を使用
2. **gitブランチ名**から自動検出（例 `feature/user-auth` → `001-user-auth` ）
3. 上記のいずれもない場合は `current` を使用

```bash
# 環境変数で指定
export GROVE_FEATURE="002-payment-system"
grove specify --ai claude

# またはgitブランチ名を使用（自動）
git checkout -b feature/user-auth
grove specify --ai claude  # → `spec.md`
```
:::

#### 4. デザイン仕様の作成

UI/UXデザインの仕様を定義します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.design`
```

**方法2 CLIから実行**

```bash
grove design
```

**デザインファイルがある場合**

```bash
# デザインファイル用ディレクトリを作成
mkdir -p .grove/design

# デザインファイルを配置
cp path/to/design.png .grove/design/
cp path/to/wireframe.pdf .grove/design/

# デザイン仕様を生成
grove design
```

デザイン仕様は以下に保存されます。

- **Claude Code環境**
  `.claude/skills/design-creator/skill.md` (skillとして実装)

- **その他のagent**
  `.grove/design.md` (markdownファイル)

#### 5. 実装計画の作成

仕様に基づいた実装計画を生成します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.plan`
```

**方法2 CLIから実行**

```bash
grove plan --ai claude
```

`plan.md` に生成されます。

デザイン仕様を参照して技術選定が行われます。

#### 6. タスク分解

実装計画をタスクに分解します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.tasks`
```

**方法2 CLIから実行**

```bash
grove tasks --ai claude
```

`tasks.md` に生成されます。

#### 7. 実装実行

タスクに基づいて実装を開始します。

**方法1 Claude Code内で実行（推奨）**

Claude Codeを起動して以下を実行します。

```
`/grove.implement`
```

**方法2 CLIから実行**

```bash
grove implement --ai claude
```

実装時、AIエージェントがデザイン仕様を参照してコードを生成します。

実装が完了すると、各実装ステップ完了ごとに自動的に `grove sync --auto` が実行され、最新の状態に更新されます。

## 実装アーキテクチャ

### 単一エージェント実行

`--ai` フラグで特定のエージェントを指定して実行します。

フラグ未指定時はインタラクティブ選択画面が表示されます。

エージェント設定が未インストールの場合、自動的にダウンロード・インストールされます。

### データフロー

```mermaid
graph TD
    A[grove コマンド実行] --> B{コマンド種別}
    B -->|workflow| W[Workflow自動実行]
    B -->|constitution| C[Constitution実行]
    B -->|specify/design/plan/tasks| D[機能仕様実行]

    W --> W1[Constitution確認/作成]
    W1 --> W1S[.claude/rules/に同期]
    W1S --> W2[Specify実行]
    W2 --> W2D[Design実行]
    W2D --> W3[Plan実行]
    W3 --> W4[Tasks実行]
    W4 --> W5[Implement実行]
    W5 --> W6[実装変更記録]

    C --> E[`constitution.md` に保存]
    E --> ES[.claude/rules/`constitution.md` に同期]

    D --> F[仕様ファイルに保存]
    F --> G[実装実行]
    G --> H[grove sync --auto 実行]
    H --> I[最新状態に更新]
```

## オリジナルSpec Kitとの違い

| 機能 | Spec Kit | Grove |
|------|----------|-------|
| 多言語対応 | ❌ | ✅ (日本語・英語、60+翻訳キー) |
| 設定管理 | ❌ | ✅ (`config.json`、言語永続化) |
| テンプレートシステム | ❌ | ✅ (enabledフラグ、自動読み込み) |
| エージェント設定自動管理 | ❌ | ✅ (`CLAUDE.md`、AGENTS.md) |
| ワークフロー自動実行 | ❌ | ✅ ( `workflow` コマンド) |
| 自動エージェントインストール | ❌ | ✅ |
| **Commands統一アーキテクチャ** | ❌ | ✅ (全エージェント共通Commands) |
| 機能別仕様管理 | ❌ | ✅ |
| プロジェクト構造自動同期 | ❌ | ✅ ( `sync` コマンド) |
| 変更履歴自動記録 | ❌ | ✅ ( `update-doc` コマンド) |
| 階層的ドキュメント管理 | ❌ | ✅ (index.md + README.md) |
| **frontend-design skill統合** | ❌ | ✅ (Marketplace skill活用) |
| **t-wada TDDワークフロー統合** | ❌ | ✅ (Spec Kitフェーズ構造に統合) |
| デザインワークフロー統合 | ❌ | ✅ (spec → design → plan → implement) |
| デザインファイル自動抽出 | ❌ | ✅ (PNG, SVG, PDF, Figma等) |
| **Constitution sync to Rules** | ❌ | ✅ (.claude/rules/`constitution.md`) |
| **テンプレート言語別分離** | ❌ | ✅ (templates/{lang}/, templates/common/) |
| **Read tool ファイル存在チェック** | ❌ | ✅ (Bash確認プロンプト不要) |
| **チェックリストベースAIレビュー** | ❌ | ✅ (3層ワークフロー、Self/Cross Review) |
| **自動修正ループ** | ❌ | ✅ (Self Review: 最大3回/項目) |
| **Agent自動判定** | ❌ | ✅ (claude/codex --help による環境検出) |
| **TDDベース自動修正** | ❌ | ✅ ( `/grove.fix` コマンド) |
| **Verification Agent** | ❌ | ✅ (Claude Code: FR-9レポート形式) |
| CLI名 | `specify` | `grove` |
| パッケージ名 | `specify-cli` | `grove-cli` |
| ディレクトリ | `.specify/` | `.grove/` |
| スラッシュコマンド | `/speckit.*` | `/grove.*` |

## 参考リンク

### Spec Kit

- [spec-kit github](https://github.com/github/spec-kit/tree/main)

### Claude

- [Anthropics skills](https://github.com/anthropics/skills)
- [Slash commands](https://code.claude.com/docs/en/slash-commands)

### Articles

- [Claude Code CLI最新4機能で開発効率を2倍にする実践ガイド](https://smartscope.blog/generative-ai/claude/claude-code-cli-update-december-2025/)
- [Claude Codeのユーザー設定プロンプトを使い分けてコンテキスト管理を最適化する (CLAUDE.md, rules, slash commands, skills, subagents)](https://blog.atusy.net/2025/12/15/claude-code-user-config/)
- [Claude Code の AGENTS.md 対応](https://suzumiyaaoba.com/blog/post/2025-09-16-agents-md/#claude-code-%E3%81%AE-agentsmd-%E5%AF%BE%E5%BF%9C)

## 最後に

今回は「**Groveによる複数AIエージェントを活用した仕様駆動開発**」についてまとめてきました。

https://www.amazon.co.jp/dp/B0DQDWM1YK

https://cardene.notion.site/EIP-2a03fa3ea33d43baa9ed82288f98d4a9

https://twitter.com/cardene777

https://zenn.dev/heku

https://cardene.substack.com/

https://mirror.xyz/0xACAc709e21e7a4A5a4458BDeeCCA0fc98A6a8A4D
