"""Tests for limitry.client"""
