from nicegui import ui, app, run
import os, re, apsw
from biblemategui import BIBLEMATEGUI_DATA
from biblemategui.fx.bible import BibleSelector

def fetch_summary(b, c):
    db = os.path.join(BIBLEMATEGUI_DATA, "data", "chapter_summary.data")
    fetch = None
    with apsw.Connection(db) as connn:
        query = "SELECT Content FROM Summary WHERE Book=? AND Chapter=? LIMIT 1"
        cursor = connn.cursor()
        cursor.execute(query, (b, c))
        fetch = cursor.fetchone()
    if not fetch:
        return "No summary available."
    return fetch[0]


def chapter_summary(gui=None, bt=None, b=1, c=1, v=1, area=2, **_):
    # Bible Selection menu
    bible_selector = BibleSelector(version_options=["KJV"])
    def additional_items():
        nonlocal gui, bible_selector, area
        def change_summary_chapter(selection):
            if area == 1:
                _, app.storage.user['bible_book_number'], app.storage.user['bible_chapter_number'], app.storage.user['bible_verse_number'] = selection
                gui.load_area_1_content(title="Summary")
            else:
                _, app.storage.user['tool_book_number'], app.storage.user['tool_chapter_number'], app.storage.user['tool_verse_number'] = selection
                gui.load_area_2_content(title="Summary", sync=False)
        ui.button('Go', on_click=lambda: change_summary_chapter(bible_selector.get_selection()))
    bible_selector.create_ui("KJV", b, c, v, additional_items=additional_items, show_versions=False, show_verses=False)

    # Summary display
    content = ""
    async def load_summary(b, c):
        nonlocal content
        content = await run.io_bound(fetch_summary, b, c)

    n = ui.notification("Loading ...", timeout=None, spinner=True)
    ui.timer(0, lambda: load_summary(b, c), once=True)
    n.dismiss()

    # display
    ui.html(f'<div class="content-text">{content}</div>', sanitize=False)
    