# Text Parser Utils
[![PyPI version](https://badge.fury.io/py/text-parser-utils.svg)](https://badge.fury.io/py/text-parser-utils)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/text-parser-utils)](https://pepy.tech/project/text-parser-utils)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package designed to simplify user interactions by accepting free-text prompts and providing structured, reliable responses. It leverages an underlying pattern-matching system to interpret user inputs and generate consistent outputs, enabling seamless information extraction or task execution without complex processing of media types.

## Installation

```bash
pip install text_parser_utils
```

## Usage

### Basic Usage

```python
from text_parser_utils import text_parser_utils

response = text_parser_utils(user_input="Your input text here")
print(response)
```

### Advanced Usage with Custom LLM

You can use any LLM compatible with LangChain by passing your own LLM instance.

#### Using OpenAI

```python
from langchain_openai import ChatOpenAI
from text_parser_utils import text_parser_utils

llm = ChatOpenAI()
response = text_parser_utils(user_input="Your input text here", llm=llm)
print(response)
```

#### Using Anthropic

```python
from langchain_anthropic import ChatAnthropic
from text_parser_utils import text_parser_utils

llm = ChatAnthropic()
response = text_parser_utils(user_input="Your input text here", llm=llm)
print(response)
```

#### Using Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from text_parser_utils import text_parser_utils

llm = ChatGoogleGenerativeAI()
response = text_parser_utils(user_input="Your input text here", llm=llm)
print(response)
```

### Using LLM7 API Key

By default, the package uses the `ChatLLM7` from `langchain_llm7`. If you want to use your own API key, you can pass it directly or via an environment variable.

#### Passing API Key Directly

```python
from text_parser_utils import text_parser_utils

response = text_parser_utils(user_input="Your input text here", api_key="your_api_key")
print(response)
```

#### Using Environment Variable

```bash
export LLM7_API_KEY="your_api_key"
```

```python
from text_parser_utils import text_parser_utils

response = text_parser_utils(user_input="Your input text here")
print(response)
```

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Rate Limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you need higher rate limits, you can obtain a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/text-parser-utils/issues).

## Author

- **Eugene Evstafev**
  - Email: hi@eugene.plus
  - GitHub: [chigwell](https://github.com/chigwell)