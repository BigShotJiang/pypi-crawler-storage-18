import json
import os
import re
import subprocess
import time
from typing import Any

import requests
import yaml

API_BASE = os.environ["CLAUDE_AGENT_API_BASE"].rstrip("/")
AGENT_TOKEN = os.environ["CLAUDE_AGENT_TOKEN"]
JOB_TYPE = os.environ["JOB_TYPE"]
LINEAR_ISSUE_ID = os.getenv("LINEAR_ISSUE_ID") or ""
LINEAR_PROJECT_ID = os.getenv("LINEAR_PROJECT_ID") or ""
EXTRA_REPOS = os.getenv("EXTRA_REPOS") or ""

HEADERS = {"X-Agent-Token": AGENT_TOKEN}

DEFAULT_CONFIG = {
    "run_dev": "./run-dev",
    "dev_url": "http://127.0.0.1:3000",
    "dev_ready_regex": "Listening|ready|started",
    "browser_test": "",
    "tests": "",
    "precommit": "",
    # PR loop limits
    "max_review_iterations": 3,
    # How many times to attempt auto-fix loops for failing commands
    "max_fix_attempts": 4,
    # CI-aware settings
    "wait_for_ci": True,  # Wait for CI checks and fix failures
    "max_ci_fix_iterations": 3,  # Max attempts to fix CI failures
    "ci_poll_interval": 30,  # Seconds between CI status checks
    "ci_timeout": 1800,  # Max seconds to wait for CI (30 min)
}


def load_config() -> dict[str, Any]:
    for path in (".claude/automation.yml", ".claude/automation.yaml", "claude_automation.yml"):
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            out = dict(DEFAULT_CONFIG)
            out.update(cfg)
            return out
    return dict(DEFAULT_CONFIG)


def agent_post(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    r = requests.post(f"{API_BASE}{path}", headers=HEADERS, json=payload, timeout=60)
    r.raise_for_status()
    return r.json()


def agent_get(path: str) -> dict[str, Any]:
    r = requests.get(f"{API_BASE}{path}", headers=HEADERS, timeout=60)
    r.raise_for_status()
    return r.json()


def stage(entity: str, _id: str, stage_key: str, message: str | None = None, pr_url: str | None = None) -> None:
    agent_post("/agent/stage", {"entity": entity, "id": _id, "stage": stage_key, "message": message, "pr_url": pr_url})


def comment_issue(issue_id: str, body: str) -> None:
    """Post a comment to a Linear issue without changing labels."""
    agent_post("/agent/comment/issue", {"issue_id": issue_id, "body": body})


def run(cmd: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, shell=True, text=True, capture_output=True, check=check)


def detect_claude_capabilities() -> dict[str, bool]:
    """Best-effort capability detection so this runner can survive CLI changes."""
    caps = {
        "output_format_json": False,
        "resume": False,
        "permission_mode": False,
        "dangerous": False,
        "settings": False,
    }
    p = subprocess.run(["claude", "--help"], text=True, capture_output=True)
    help_text = (p.stdout or "") + "\n" + (p.stderr or "")
    # heuristic checks
    caps["output_format_json"] = "--output-format" in help_text
    caps["resume"] = "--resume" in help_text
    caps["permission_mode"] = "--permission-mode" in help_text
    caps["dangerous"] = "--dangerously-skip-permissions" in help_text
    caps["settings"] = "--settings" in help_text
    return caps


def extract_first_json(text: str, default: dict[str, Any] | None = None) -> Any:
    """Extract a JSON object/array from a string.

    Handles:
    - Plain JSON
    - JSON inside markdown code blocks (```json ... ```)
    - JSON with surrounding text

    Args:
        text: The text to extract JSON from
        default: Optional default to return if no JSON found (instead of raising)

    Returns:
        Parsed JSON object/array, or default if provided and no JSON found
    """
    text = text.strip()

    # Direct parse attempt
    try:
        return json.loads(text)
    except Exception:
        pass

    # Try to extract from markdown code blocks first (```json ... ``` or ``` ... ```)
    code_block_match = re.search(r"```(?:json)?\s*\n?([\s\S]*?)\n?```", text)
    if code_block_match:
        try:
            return json.loads(code_block_match.group(1).strip())
        except Exception:
            pass

    # Find first {...} or [...] with greedy matching for nested structures
    # Use a more robust approach: find outermost braces
    brace_match = re.search(r"(\{[\s\S]*\})", text)
    if brace_match:
        try:
            return json.loads(brace_match.group(1))
        except Exception:
            pass

    bracket_match = re.search(r"(\[[\s\S]*\])", text)
    if bracket_match:
        try:
            return json.loads(bracket_match.group(1))
        except Exception:
            pass

    # No valid JSON found
    if default is not None:
        return default
    raise ValueError("No JSON found in output")


def claude_call(
    prompt: str,
    session_id: str | None,
    caps: dict[str, bool],
    permission_mode: str | None = None,
    dangerous: bool = False,
    max_turns: int = 20,
    settings_path: str | None = None,
) -> tuple[str | None, str, dict[str, Any] | None]:
    """Call Claude Code CLI in headless print mode.

    Returns: (new_session_id, result_text, raw_json_if_available)
    """
    cmd = ["claude", "-p", prompt]

    # Use Opus 4.5 model with extended thinking
    cmd += ["--model", "opus"]

    # Always use stream-json to show full thinking process in logs
    cmd += ["--output-format", "stream-json"]
    if caps.get("resume") and session_id:
        cmd += ["--resume", session_id]
    if caps.get("permission_mode") and permission_mode:
        cmd += ["--permission-mode", permission_mode]
    if caps.get("dangerous") and dangerous:
        cmd += ["--dangerously-skip-permissions"]
    if caps.get("settings") and settings_path:
        cmd += ["--settings", settings_path]
    # max-turns isn't always supported; skip unless present
    if "--max-turns" in (subprocess.run(["claude", "--help"], text=True, capture_output=True).stdout or ""):
        cmd += ["--max-turns", str(max_turns)]

    # Log the prompt being sent
    print("\n" + "=" * 60)
    print("CLAUDE PROMPT:")
    print("=" * 60)
    print(prompt[:2000] + ("..." if len(prompt) > 2000 else ""))
    print("=" * 60 + "\n")

    p = subprocess.run(cmd, text=True, capture_output=True)

    # Log raw output - stream-json shows full thinking process
    print("\n" + "-" * 60)
    print("CLAUDE STREAM OUTPUT (full thinking process):")
    print("-" * 60)
    if p.stdout:
        # Show full output - no truncation to see complete thinking
        print(p.stdout)
    if p.stderr:
        print("STDERR:", p.stderr[:2000])
    print("-" * 60 + "\n")

    if p.returncode != 0:
        raise RuntimeError(f"claude failed rc={p.returncode}\nSTDERR:\n{p.stderr}\nSTDOUT:\n{p.stdout}")

    out = p.stdout.strip()

    # Parse stream-json format - each line is a JSON object
    result = ""
    new_session = session_id
    for line in out.split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
            # Extract session_id from init message
            if msg.get("type") == "system" and msg.get("subtype") == "init":
                new_session = msg.get("session_id") or new_session
            # Extract final result
            if msg.get("type") == "result":
                result = msg.get("result", "")
                new_session = msg.get("session_id") or new_session
        except json.JSONDecodeError:
            continue

    print("\n" + "+" * 60)
    print("CLAUDE RESULT:")
    print("+" * 60)
    print(result[:5000] + ("..." if len(result) > 5000 else ""))
    print("+" * 60 + "\n")

    return new_session, result, None


def write_temp_claude_settings(extra_dirs: list[str]) -> str | None:
    if not extra_dirs:
        return None
    settings_obj = {
        "additionalDirectories": extra_dirs,
        "permissions": {
            "deny": [
                "Read(**/.env)",
                "Read(**/.env.*)",
                "Read(**/secrets/**)",
            ]
        },
    }
    path = ".claude-agent-settings.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(settings_obj, f)
    return path


def slugify(s: str) -> str:
    s = s.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s[:40]


def checkout_branch(branch: str, base: str) -> None:
    run("git fetch origin --prune")
    run(f"git checkout -B {branch} origin/{base}")


def commit_and_push(branch: str, message: str) -> None:
    run("git add -A")
    status = run("git status --porcelain").stdout.strip()
    if not status:
        return
    safe_message = message.replace('"', "'")
    run(f'git commit -m "{safe_message}"')
    run(f"git push -u origin {branch}")


def create_pr(base: str, head: str, title: str, body: str) -> str:
    import tempfile

    # Write body to temp file to avoid shell escaping issues
    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write(body)
        body_file = f.name
    try:
        safe_title = title.replace('"', "'")
        p = run(
            f'gh pr create --base "{base}" --head "{head}" --title "{safe_title}" --body-file "{body_file}"',
            check=False,
        )
        if p.returncode != 0:
            # Check if PR already exists
            if "already exists" in p.stderr.lower() or p.returncode == 4:
                # Try to get existing PR URL
                existing = run("gh pr view --json url -q .url", check=False)
                if existing.returncode == 0 and existing.stdout.strip():
                    return existing.stdout.strip()
            # Log the error for debugging
            print(f"gh pr create failed (exit {p.returncode}):")
            print(f"  stdout: {p.stdout}")
            print(f"  stderr: {p.stderr}")
            raise RuntimeError(f"gh pr create failed: {p.stderr or p.stdout}")
        # gh returns url on stdout; take last non-empty line
        lines = [ln.strip() for ln in p.stdout.splitlines() if ln.strip()]
        return lines[-1] if lines else ""
    finally:
        os.remove(body_file)


def pr_number_from_url(url: str) -> str:
    return url.rstrip("/").split("/")[-1]


def wait_for_ci_checks(pr_num: str, poll_interval: int = 30, timeout: int = 1800) -> dict[str, Any]:
    """Wait for CI checks to complete on a PR.

    Returns dict with keys:
        - status: "success" | "failure" | "pending" | "timeout"
        - failed_checks: list of failed check names
        - check_runs: raw check run data
    """
    start_time = time.time()

    while time.time() - start_time < timeout:
        # Get check runs for the PR's head commit
        p = run(
            f'gh pr view {pr_num} --json statusCheckRollup,headRefOid -q "."',
            check=False,
        )
        if p.returncode != 0:
            print(f"Failed to get PR status: {p.stderr}")
            time.sleep(poll_interval)
            continue

        try:
            data = json.loads(p.stdout)
        except json.JSONDecodeError:
            print(f"Failed to parse PR status JSON: {p.stdout}")
            time.sleep(poll_interval)
            continue

        checks = data.get("statusCheckRollup") or []
        if not checks:
            # No checks configured, consider success
            return {"status": "success", "failed_checks": [], "check_runs": []}

        # Analyze check states
        pending = []
        failed = []
        for check in checks:
            name = check.get("name") or check.get("context") or "unknown"
            status = check.get("status", "").upper()
            conclusion = check.get("conclusion", "").upper()

            # Skip our own workflow to avoid infinite loop
            if "claude" in name.lower() and "linear" in name.lower():
                continue

            if status in ("QUEUED", "IN_PROGRESS", "PENDING", "WAITING"):
                pending.append(name)
            elif conclusion in ("FAILURE", "TIMED_OUT", "CANCELLED", "ACTION_REQUIRED"):
                failed.append(name)

        if pending:
            elapsed = int(time.time() - start_time)
            print(f"CI checks still running ({elapsed}s): {', '.join(pending[:3])}...")
            time.sleep(poll_interval)
            continue

        if failed:
            return {"status": "failure", "failed_checks": failed, "check_runs": checks}

        return {"status": "success", "failed_checks": [], "check_runs": checks}

    return {"status": "timeout", "failed_checks": [], "check_runs": []}


def get_failed_ci_logs(pr_num: str, failed_checks: list[str], max_logs_length: int = 50000) -> str:
    """Get logs from failed CI checks.

    Uses gh CLI to fetch workflow run logs.
    """
    logs_parts = []

    # Get the workflow runs for this PR
    p = run(
        f'gh pr view {pr_num} --json headRefOid -q ".headRefOid"',
        check=False,
    )
    if p.returncode != 0:
        return f"Failed to get PR head SHA: {p.stderr}"

    head_sha = p.stdout.strip()

    # List workflow runs for this commit
    p = run(
        f"gh run list --commit {head_sha} --json databaseId,name,conclusion,status --limit 20",
        check=False,
    )
    if p.returncode != 0:
        return f"Failed to list workflow runs: {p.stderr}"

    try:
        runs = json.loads(p.stdout)
    except json.JSONDecodeError:
        return f"Failed to parse workflow runs: {p.stdout}"

    # Find failed runs
    for run_info in runs:
        run_name = run_info.get("name", "")
        conclusion = run_info.get("conclusion", "").upper()
        run_id = run_info.get("databaseId")

        # Skip our own workflow
        if "claude" in run_name.lower() and "linear" in run_name.lower():
            continue

        if conclusion in ("FAILURE", "TIMED_OUT", "CANCELLED"):
            # Get logs for this run
            p_logs = run(f"gh run view {run_id} --log-failed", check=False)
            if p_logs.returncode == 0 and p_logs.stdout.strip():
                logs_parts.append(f"=== {run_name} (Run ID: {run_id}) ===\n{p_logs.stdout}")
            else:
                # Try getting full logs if --log-failed doesn't work
                p_logs = run(f"gh run view {run_id} --log", check=False)
                if p_logs.returncode == 0:
                    # Truncate to last portion which usually has the error
                    log_text = p_logs.stdout[-30000:] if len(p_logs.stdout) > 30000 else p_logs.stdout
                    logs_parts.append(f"=== {run_name} (Run ID: {run_id}) ===\n{log_text}")

    combined = "\n\n".join(logs_parts)
    if len(combined) > max_logs_length:
        combined = combined[-max_logs_length:]

    return combined or "No failure logs found"


def run_with_fix_loop(
    cmd: str, caps: dict[str, bool], session_id: str | None, fix_prompt: str, stage_key: str, max_attempts: int
) -> tuple[str | None, str]:
    """Run a command with auto-fix loop. Returns (session_id, last_output)."""
    last_output = ""
    for attempt in range(1, max_attempts + 1):
        stage("issue", LINEAR_ISSUE_ID, stage_key, message=f"Running: `{cmd}` (attempt {attempt}/{max_attempts})")
        p = run(cmd, check=False)
        last_output = (p.stdout + "\n" + p.stderr).strip()

        if p.returncode == 0:
            return session_id, last_output

        logs = last_output[-12000:]
        session_id, _, _ = claude_call(
            prompt=f"""{fix_prompt}

Command: {cmd}
Exit code: {p.returncode}

Logs:
{logs}
""".strip(),
            session_id=session_id,
            caps=caps,
            permission_mode="bypassPermissions",
            dangerous=True,
            max_turns=25,
        )
    raise RuntimeError(f"Command kept failing after {max_attempts} attempts: {cmd}")


def issue_flow() -> None:
    caps = detect_claude_capabilities()
    cfg = load_config()

    ctx = agent_get(f"/agent/context/issue/{LINEAR_ISSUE_ID}")
    issue = ctx["issue"]
    title = issue["title"]
    description = issue.get("description") or ""
    ident = issue["identifier"]

    stage("issue", LINEAR_ISSUE_ID, "design_doc", message=f"Starting Claude flow for {ident}: {title}")

    # extra repos are cloned into _deps/OWNER__REPO by the workflow
    extra_dirs = []
    if EXTRA_REPOS.strip():
        for r in EXTRA_REPOS.split(","):
            r = r.strip()
            if not r:
                continue
            extra_dirs.append(os.path.abspath(f"_deps/{r.replace('/', '__')}"))
    settings_path = write_temp_claude_settings(extra_dirs)

    base_branch = run("git remote show origin | sed -n '/HEAD branch/s/.*: //p'").stdout.strip() or "main"
    branch = f"claude/{ident.lower()}-{slugify(title)}"
    checkout_branch(branch, base_branch)

    # 2) Design doc (plan)
    design_doc_path = f"docs/claude/{ident}-design.md"
    os.makedirs(os.path.dirname(design_doc_path), exist_ok=True)

    session_id = None
    session_id, design_result, _ = claude_call(
        prompt=f"""You are a Staff Software Architect at a top-tier tech company. You've been assigned to design a solution for the following task.

## Task
{title}

## Description
{description if description else "(No description provided)"}

## Context
- Linear Issue: {issue.get("url")}
- Repository: You have full access to analyze the codebase

## Your Mission
Create a comprehensive technical design document that will guide implementation. This document should be thorough enough that any senior engineer could implement the solution without ambiguity.

## Design Document Requirements

### 1. Problem Statement
- What problem are we solving?
- Why does it matter?
- What's the current state vs desired state?

### 2. Scope & Non-Goals
- What's explicitly in scope?
- What's explicitly OUT of scope?
- What are we NOT trying to solve?

### 3. Technical Analysis
- Analyze the existing codebase thoroughly
- Identify relevant files, modules, and patterns
- Note any dependencies or constraints
- Identify potential risks or challenges

### 4. Proposed Solution
- High-level architecture
- Key components and their responsibilities
- Data flow diagrams (describe in text)
- API contracts if applicable

### 5. Implementation Approach
- Phased rollout if needed
- Key milestones
- Testing strategy

### 6. Trade-offs & Alternatives
- What alternatives did you consider?
- Why did you choose this approach?
- What are the trade-offs?

### 7. Open Questions
- What needs clarification?
- What decisions need stakeholder input?

## Output
Write the design document to {design_doc_path}. Be specific and reference actual file paths and code patterns you discover in the codebase.""",
        session_id=session_id,
        caps=caps,
        permission_mode="plan",
        max_turns=30,
        settings_path=settings_path,
    )

    # Claude's plan mode writes to ~/.claude/plans/. Extract and read the actual plan file.
    design_md = None
    plans_dir = os.path.expanduser("~/.claude/plans")

    # Method 1: Try to find the plan file path in Claude's output
    # Match patterns like: /home/runner/.claude/plans/xxx.md or ~/.claude/plans/xxx.md
    plan_file_patterns = [
        r"(/[^\s\"'`\)\]]+\.md)\b",  # Absolute path with word boundary
        r"(~/.claude/plans/[^\s\"'`\)\]]+\.md)\b",  # Home-relative path
    ]
    for pattern in plan_file_patterns:
        plan_file_match = re.search(pattern, design_result)
        if plan_file_match:
            plan_file_path = plan_file_match.group(1)
            # Strip any trailing punctuation that might have been captured
            plan_file_path = plan_file_path.rstrip(".,;:!?")
            # Expand ~ to home directory
            plan_file_path = os.path.expanduser(plan_file_path)
            print(f"[design_doc] Found plan file path in output: {plan_file_path}")
            if os.path.exists(plan_file_path):
                print(f"[design_doc] Reading plan from: {plan_file_path}")
                with open(plan_file_path, encoding="utf-8") as f:
                    design_md = f.read()
                break
            else:
                print(f"[design_doc] WARNING: Plan file does not exist: {plan_file_path}")

    # Method 2: If regex failed, find the most recently modified .md file in ~/.claude/plans/
    if not design_md and os.path.isdir(plans_dir):
        print(f"[design_doc] Scanning {plans_dir} for recent plan files...")
        md_files = [os.path.join(plans_dir, f) for f in os.listdir(plans_dir) if f.endswith(".md")]
        if md_files:
            # Sort by modification time, newest first
            md_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
            newest_plan = md_files[0]
            # Only use if modified in the last 5 minutes (likely from this session)
            if time.time() - os.path.getmtime(newest_plan) < 300:
                print(f"[design_doc] Using most recent plan file: {newest_plan}")
                with open(newest_plan, encoding="utf-8") as f:
                    design_md = f.read()

    # Method 3: Check if Claude wrote directly to the target path
    if not design_md and os.path.exists(design_doc_path):
        print(f"[design_doc] Reading from target path: {design_doc_path}")
        with open(design_doc_path, encoding="utf-8") as f:
            design_md = f.read()

    # Last resort: use Claude's output (but this is usually just a summary)
    if not design_md:
        print("[design_doc] WARNING: Could not find plan file, using Claude's output as fallback")
        design_md = design_result

    # Write/update the design doc at the target location
    with open(design_doc_path, "w", encoding="utf-8") as f:
        f.write(design_md)

    # Post the FULL design document to Linear as a comment
    design_doc_comment = f"## 📄 Design Document\n\n{design_md}"
    comment_issue(LINEAR_ISSUE_ID, design_doc_comment)

    # 3) Review design doc (edits)
    stage("issue", LINEAR_ISSUE_ID, "design_reviewed", message="Reviewing design doc")
    session_id, _, _ = claude_call(
        prompt=f"""You are a Principal Engineer conducting a design review. Your role is to be a critical but constructive reviewer who ensures technical excellence.

## Your Task
Review and improve the design document at {design_doc_path}.

## Review Checklist

### Completeness
- Does it fully address the original requirements?
- Are all edge cases considered?
- Is the scope clear and appropriate?

### Technical Soundness
- Is the proposed architecture sound?
- Does it follow existing patterns in the codebase?
- Are there any security concerns?
- Are there any performance implications?
- Is error handling addressed?

### Clarity
- Would a new team member understand this?
- Are there ambiguous sections?
- Is the implementation path clear?

### Feasibility
- Is this implementable with reasonable effort?
- Are there any missing dependencies?
- Are the assumptions valid?

## Your Actions
1. Read the design document carefully
2. Identify gaps, issues, or improvements
3. Update the document in-place with your improvements
4. Add any missing sections
5. Clarify any ambiguous parts
6. Ensure the document is actionable

Be thorough but don't over-engineer. The goal is a design that's good enough to implement confidently.""",
        session_id=session_id,
        caps=caps,
        permission_mode="acceptEdits",
        max_turns=20,
        settings_path=settings_path,
    )

    # 4) Implement (dangerous)
    stage("issue", LINEAR_ISSUE_ID, "implementing", message="Implementing feature")
    session_id, _, _ = claude_call(
        prompt=f"""You are a Senior Software Engineer implementing a feature based on a design document. You write clean, production-quality code that follows best practices.

## Your Task
Implement the solution described in the design document: {design_doc_path}

Read the design document carefully - it contains the problem statement, proposed solution, implementation approach, and technical details you need.

## Engineering Standards

### Code Quality
- Write clean, readable code
- Follow existing patterns in the codebase
- Use meaningful variable and function names
- Keep functions focused and small
- Add comments only where the "why" isn't obvious

### Error Handling
- Handle errors gracefully
- Provide useful error messages
- Don't swallow exceptions silently
- Consider edge cases

### Testing
- Add unit tests for new functionality
- Update existing tests if behavior changes
- Aim for meaningful test coverage, not 100%
- Test edge cases and error conditions

### Security
- Validate all inputs
- Don't expose sensitive data in logs
- Follow secure coding practices
- Be careful with user-provided data

## Implementation Process
1. Read and understand the design document thoroughly
2. Break down the work into logical steps
3. Implement each component, verifying it works before moving on
4. Write tests as you go, not at the end
5. If you discover issues with the design, adapt intelligently

## Important Rules
- Do NOT skip steps or take shortcuts
- Do NOT leave TODO comments for later
- Do NOT add features not in the design
- Do NOT refactor unrelated code

Begin implementation now. Be thorough and methodical.""",
        session_id=session_id,
        caps=caps,
        permission_mode="bypassPermissions",
        dangerous=True,
        max_turns=80,
        settings_path=settings_path,
    )

    # 5) De-slop cleanup pass - reduce bloat and consolidate before testing
    stage("issue", LINEAR_ISSUE_ID, "cleanup", message="Running de-slop cleanup pass")
    session_id, cleanup_result, _ = claude_call(
        prompt="""You are a Senior Staff Engineer doing a code cleanup review. Your specialty is eliminating "AI slop" - the bloat, redundancy, and over-engineering that accumulates during AI-assisted development.

## Your Mission
Review the changes made in this session and clean up any:
- Redundant code or files
- Over-engineered abstractions
- Unnecessary indirection
- Dead code or unused imports
- Duplicated logic
- Verbose implementations that could be simpler

## Cleanup Philosophy

### DO:
- Delete code that isn't needed
- Merge duplicate functions/constants
- Simplify overly complex implementations
- Remove unnecessary abstractions
- Consolidate scattered configuration

### DON'T:
- Change working behavior
- Rename things just for style
- Add new abstractions
- "Improve" code that wasn't touched
- Break existing tests

## Process

### 1. Audit (Read-Only)
Scan all changes made in this session:
- List any redundancies found
- Identify over-engineering
- Note duplicated logic
- Find dead code

### 2. Plan
For each issue:
- What needs to change
- Why it's safe to change
- Expected impact (small/medium)

### 3. Execute
Make the cleanup changes:
- One logical change at a time
- Verify nothing breaks
- Keep diffs minimal and reviewable

## Style Rules ("No AI Slop")
- Prefer straightforward functions over meta-abstractions
- Delete dead code, unused helpers, and "maybe future" scaffolding
- Shorten verbose functions when it improves readability (but don't golf code)
- Keep comments only if they add non-obvious value

## Output
Return JSON with keys:
- changes_made (boolean): true if you made any cleanup changes
- summary (string): brief description of what was cleaned up
- items_cleaned (array): list of specific items that were cleaned

If the code is already clean, return changes_made: false.""",
        session_id=session_id,
        caps=caps,
        permission_mode="bypassPermissions",
        dangerous=True,
        max_turns=40,
        settings_path=settings_path,
    )

    # Try to parse cleanup result and post summary
    try:
        cleanup_json = extract_first_json(cleanup_result)
        cleanup_summary = cleanup_json.get("summary", "Cleanup pass completed")
        if cleanup_json.get("changes_made"):
            cleanup_comment = f"## 🧹 De-slop Cleanup\n\n{cleanup_summary}"
            comment_issue(LINEAR_ISSUE_ID, cleanup_comment)
    except Exception:
        # If JSON parsing fails, just continue - cleanup is best-effort
        pass

    # 6) Dev + browser/e2e tests
    if cfg.get("browser_test"):
        stage("issue", LINEAR_ISSUE_ID, "dev_test", message="Running dev + browser/e2e test")
        dev_cmd = (cfg.get("run_dev") or "").strip()
        if dev_cmd:
            srv = subprocess.Popen(dev_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            ready_re = re.compile(cfg.get("dev_ready_regex") or "ready", re.IGNORECASE)
            started = False
            start = time.time()
            while time.time() - start < 180:
                line = srv.stdout.readline() if srv.stdout else ""
                if line and ready_re.search(line):
                    started = True
                    break
                time.sleep(0.2)
            if not started:
                srv.terminate()
                raise RuntimeError("Dev server did not become ready")
            try:
                browser_fix_prompt = """You are debugging a failing browser/E2E test. These tests interact with a real browser and can fail for various reasons.

Common E2E Failure Causes:
- Element not found (wrong selector, timing issue)
- Assertion failed (unexpected UI state)
- Network error (API call failed)
- Timeout (page too slow, waiting too long)
- State pollution (previous test affected state)

Fix Guidelines:
- Read the error message carefully
- Check if the selector is correct
- Add proper waits if it's a timing issue
- Fix the underlying code if UI is wrong
- Do NOT just increase timeouts blindly
- Do NOT skip the test

Fix the actual issue now."""
                session_id, browser_test_output = run_with_fix_loop(
                    cfg["browser_test"],
                    caps,
                    session_id,
                    browser_fix_prompt,
                    "dev_test",
                    cfg["max_fix_attempts"],
                )
            finally:
                srv.terminate()
        else:
            browser_fix_prompt = """You are debugging a failing browser/E2E test. These tests interact with a real browser and can fail for various reasons.

Common E2E Failure Causes:
- Element not found (wrong selector, timing issue)
- Assertion failed (unexpected UI state)
- Network error (API call failed)
- Timeout (page too slow, waiting too long)
- State pollution (previous test affected state)

Fix Guidelines:
- Read the error message carefully
- Check if the selector is correct
- Add proper waits if it's a timing issue
- Fix the underlying code if UI is wrong
- Do NOT just increase timeouts blindly
- Do NOT skip the test

Fix the actual issue now."""
            session_id, browser_test_output = run_with_fix_loop(
                cfg["browser_test"],
                caps,
                session_id,
                browser_fix_prompt,
                "dev_test",
                cfg["max_fix_attempts"],
            )

        # Post browser/e2e test results to Linear
        browser_test_comment = f"## 🌐 Browser/E2E Test Results\n\n```\n{browser_test_output[-8000:]}\n```"
        comment_issue(LINEAR_ISSUE_ID, browser_test_comment)

    # 7) Unit/integration tests
    if cfg.get("tests"):
        stage("issue", LINEAR_ISSUE_ID, "tests", message="Running tests")
        unit_test_fix_prompt = """You are debugging failing unit tests. Your goal is to make tests pass by fixing bugs, not by weakening tests.

Analysis Steps:
1. Identify which test(s) failed
2. Read the assertion error carefully
3. Determine: Is the test wrong or is the code wrong?
4. Fix the appropriate one

Rules:
- If the test expectation is correct: fix the code
- If the test expectation is wrong: fix the test
- Do NOT delete tests to make CI pass
- Do NOT use skip/xfail without explanation
- Do NOT catch exceptions to hide failures

Fix the issue now."""
        session_id, unit_test_output = run_with_fix_loop(
            cfg["tests"],
            caps,
            session_id,
            unit_test_fix_prompt,
            "tests",
            cfg["max_fix_attempts"],
        )

        # Post unit test results to Linear
        unit_test_comment = f"## 🧪 Unit Test Results\n\n```\n{unit_test_output[-8000:]}\n```"
        comment_issue(LINEAR_ISSUE_ID, unit_test_comment)

    # 8) Pre-commit hooks
    if cfg.get("precommit"):
        stage("issue", LINEAR_ISSUE_ID, "precommit", message="Running pre-commit")
        precommit_fix_prompt = """You are fixing pre-commit hook failures. These are typically linting, formatting, or type errors.

Common Issues:
- **Formatting**: Run the formatter, commit changes
- **Linting**: Fix the code smell or violation
- **Type errors**: Add proper types or fix type mismatches
- **Import order**: Let the tool auto-fix or fix manually

Rules:
- Do NOT add # noqa or # type: ignore unless truly necessary
- Do NOT disable rules in config files
- Do NOT reformat the entire codebase, just your changes
- If a rule is genuinely wrong, explain why before disabling

Fix the issues now."""
        session_id, precommit_output = run_with_fix_loop(
            cfg["precommit"],
            caps,
            session_id,
            precommit_fix_prompt,
            "precommit",
            cfg["max_fix_attempts"],
        )

        # Post pre-commit results to Linear
        precommit_comment = f"## ✅ Pre-commit Results\n\n```\n{precommit_output[-8000:]}\n```"
        comment_issue(LINEAR_ISSUE_ID, precommit_comment)

    # 9) Create PR
    stage("issue", LINEAR_ISSUE_ID, "pr_created", message="Creating PR")

    # Ask Claude for PR metadata in strict JSON (best effort)
    session_id, meta_text, _ = claude_call(
        prompt=f"""You are preparing a Pull Request for review. Create clear, professional PR metadata.

## Generate PR Metadata

### Commit Message Guidelines
- Use conventional commit format: type(scope): description
- Types: feat, fix, refactor, docs, test, chore
- Keep the first line under 72 characters
- Be specific about what changed

### PR Title Guidelines
- Include the issue identifier: "{ident}: "
- Be descriptive but concise
- Use imperative mood ("Add feature" not "Added feature")

### PR Body Guidelines
Include:
1. **Summary** - What does this PR do? (2-3 sentences)
2. **Changes** - Bullet list of key changes
3. **Testing** - How was this tested?
4. **Linear Issue** - Link to {issue.get("url")}

## Output
Return STRICT JSON only (no markdown, no code fences):
{{
  "commit_message": "type(scope): concise description",
  "pr_title": "{ident}: Clear description of the change",
  "pr_body": "Full PR description with Summary, Changes, Testing sections"
}}""",
        session_id=session_id,
        caps=caps,
        permission_mode="plan",
        max_turns=10,
        settings_path=settings_path,
    )
    # Parse metadata JSON, with empty default to use fallbacks below
    meta = extract_first_json(meta_text, default={})
    commit_message = meta.get("commit_message") or "feat: implement requested changes"
    pr_title = meta.get("pr_title") or f"{ident}: {title}"
    pr_body = meta.get("pr_body") or f"Implements {ident}: {title}\n\nDesign: {design_doc_path}"

    commit_and_push(branch, commit_message)
    pr_url = create_pr(base_branch, branch, pr_title, pr_body)
    if not pr_url:
        # if PR already exists, fetch it
        pr_url = run("gh pr view --json url -q .url").stdout.strip()

    stage("issue", LINEAR_ISSUE_ID, "pr_created", message="PR created", pr_url=pr_url)

    pr_num = pr_number_from_url(pr_url)

    # 10) PR Review/fix loop
    for i in range(1, int(cfg["max_review_iterations"]) + 1):
        stage(
            "issue", LINEAR_ISSUE_ID, "pr_review", message=f"Self-review iteration {i}/{cfg['max_review_iterations']}"
        )
        diff = run(f"gh pr diff {pr_num}", check=True).stdout

        session_id, review_text, _ = claude_call(
            prompt=f"""You are a meticulous Code Reviewer examining a PR before it goes to human reviewers. Your goal is to ensure the PR is high quality and ready for review.

## PR Diff to Review:
{diff[:120000]}

## Review Criteria

### Must Check:
1. **No obvious bugs** - Logic errors, null refs, race conditions
2. **No security issues** - Injection, XSS, auth bypasses
3. **Tests exist** - New code has appropriate tests
4. **No debug code** - console.logs, print statements, commented code
5. **No secrets** - API keys, passwords, tokens

### Should Check:
1. **Follows patterns** - Consistent with codebase
2. **Readable** - Clear names, good structure
3. **Complete** - No TODO, FIXME, or partial implementations
4. **Documented** - Public APIs have docs

### Nice to Have:
1. **Efficient** - No obvious performance issues
2. **Clean** - No unnecessary complexity

## Your Response
Return STRICT JSON:
{{
  "issues_found": boolean,
  "review_comment": "Summary for PR comment (if issues found)",
  "critical_issues": ["Must-fix before merge"],
  "minor_issues": ["Should fix but not blocking"],
  "fix_plan": "Steps to fix critical issues (empty string if none)"
}}

Be strict on critical issues, lenient on style preferences.""",
            session_id=session_id,
            caps=caps,
            permission_mode="plan",
            max_turns=15,
            settings_path=settings_path,
        )
        # Parse review JSON, with safe default if parsing fails
        review = extract_first_json(review_text, default={"issues_found": False})
        issues_found = bool(review.get("issues_found", False))
        review_comment = (review.get("review_comment") or "").strip()
        fix_plan = (review.get("fix_plan") or "").strip()

        if review_comment:
            # Post as a PR review comment (use subprocess list to avoid shell escaping issues)
            subprocess.run(
                ["gh", "pr", "review", str(pr_num), "--comment", "-b", review_comment],
                check=True,
                text=True,
                capture_output=True,
            )

        if not issues_found or not fix_plan:
            break

        stage("issue", LINEAR_ISSUE_ID, "pr_fixes", message="Applying review fixes")
        session_id, _, _ = claude_call(
            prompt=f"""You are addressing PR review feedback. Make targeted fixes without scope creep.

## Feedback to Address:
{fix_plan}

## Rules
1. Fix ONLY what's requested
2. Keep changes minimal
3. Don't refactor nearby code
4. Verify fixes don't break tests
5. Run pre-commit hooks after changes

Make the fixes now. Be surgical and precise.""",
            session_id=session_id,
            caps=caps,
            permission_mode="bypassPermissions",
            dangerous=True,
            max_turns=40,
            settings_path=settings_path,
        )
        commit_and_push(branch, "chore: address review feedback")

    # 11) CI-aware loop - wait for CI and fix failures
    if cfg.get("wait_for_ci", True):
        max_ci_iterations = int(cfg.get("max_ci_fix_iterations", 3))
        poll_interval = int(cfg.get("ci_poll_interval", 30))
        ci_timeout = int(cfg.get("ci_timeout", 1800))

        for ci_iter in range(1, max_ci_iterations + 1):
            stage(
                "issue",
                LINEAR_ISSUE_ID,
                "pr_review",
                message=f"Waiting for CI checks (iteration {ci_iter}/{max_ci_iterations})...",
            )
            comment_issue(LINEAR_ISSUE_ID, f"⏳ Waiting for CI checks to complete (iteration {ci_iter})...")

            ci_result = wait_for_ci_checks(pr_num, poll_interval=poll_interval, timeout=ci_timeout)
            ci_status = ci_result["status"]
            failed_checks = ci_result.get("failed_checks", [])

            if ci_status == "success":
                comment_issue(LINEAR_ISSUE_ID, "✅ All CI checks passed!")
                break

            if ci_status == "timeout":
                comment_issue(
                    LINEAR_ISSUE_ID,
                    f"⚠️ CI checks timed out after {ci_timeout}s. Please check manually.",
                )
                break

            if ci_status == "failure":
                stage(
                    "issue",
                    LINEAR_ISSUE_ID,
                    "pr_fixes",
                    message=f"CI failed: {', '.join(failed_checks[:3])}. Fetching logs...",
                )

                # Get failure logs
                ci_logs = get_failed_ci_logs(pr_num, failed_checks)
                comment_issue(
                    LINEAR_ISSUE_ID,
                    f"❌ CI checks failed: {', '.join(failed_checks)}\n\nAttempting auto-fix (iteration {ci_iter}/{max_ci_iterations})...",
                )

                # Ask Claude to fix the failures
                failed_checks_str = ", ".join(failed_checks)
                session_id, fix_result, _ = claude_call(
                    prompt=f"""You are a DevOps-savvy Engineer debugging CI failures. Your job is to analyze logs, identify root causes, and fix the actual issues.

## CI Status
Failed Checks: {failed_checks_str}

## CI Logs:
{ci_logs[-80000:]}

## Debugging Process

### 1. Analyze
- Read the error messages carefully
- Identify the ACTUAL failure (not symptoms)
- Trace back to the root cause
- Note the failing file and line number

### 2. Diagnose
Common CI failure causes:
- **Test failures**: Assertion failed, unexpected behavior
- **Lint errors**: Style violations, type errors
- **Build errors**: Missing dependencies, syntax errors
- **Timeout**: Tests or builds taking too long
- **Flaky tests**: Race conditions, external dependencies

### 3. Fix
Based on diagnosis, fix the ACTUAL issue:
- Don't disable tests
- Don't skip linting rules
- Don't add broad try/catch
- Don't suppress warnings

### 4. Verify
After fixing:
- Run the failing test locally if possible
- Check that your fix makes sense
- Ensure you didn't break other things

## Important
- Fix the ROOT CAUSE, not symptoms
- If a test is legitimately flaky, add proper retry logic with a comment explaining why
- If a test is testing the wrong thing, fix the test
- If the code is wrong, fix the code

Make the necessary fixes now.""",
                    session_id=session_id,
                    caps=caps,
                    permission_mode="bypassPermissions",
                    dangerous=True,
                    max_turns=50,
                    settings_path=settings_path,
                )

                # Run pre-commit if configured before pushing
                if cfg.get("precommit"):
                    try:
                        run(cfg["precommit"], check=True)
                    except Exception:
                        # Try to fix pre-commit issues
                        session_id, _, _ = claude_call(
                            prompt="Pre-commit hooks failed. Please fix the issues.",
                            session_id=session_id,
                            caps=caps,
                            permission_mode="bypassPermissions",
                            dangerous=True,
                            max_turns=20,
                            settings_path=settings_path,
                        )

                # Commit and push the fixes
                commit_and_push(branch, f"fix: address CI failures ({', '.join(failed_checks[:2])})")

                # Post update to Linear
                comment_issue(
                    LINEAR_ISSUE_ID,
                    f"🔧 Pushed CI fix (iteration {ci_iter}). Waiting for new CI run...",
                )

        # Check final CI status
        if ci_status == "failure" and ci_iter == max_ci_iterations:
            comment_issue(
                LINEAR_ISSUE_ID,
                f"⚠️ CI still failing after {max_ci_iterations} fix attempts. Manual intervention may be needed.",
            )

    stage("issue", LINEAR_ISSUE_ID, "ready", message="✅ Claude finished. PR is ready for your review.", pr_url=pr_url)


def project_enhance() -> None:
    caps = detect_claude_capabilities()
    ctx = agent_get(f"/agent/context/project/{LINEAR_PROJECT_ID}")
    proj = ctx["project"]

    stage("project", LINEAR_PROJECT_ID, "enhance_queued", message="Enhancing project description")

    extra_dirs = []
    if EXTRA_REPOS.strip():
        for r in EXTRA_REPOS.split(","):
            r = r.strip()
            if not r:
                continue
            extra_dirs.append(os.path.abspath(f"_deps/{r.replace('/', '__')}"))
    settings_path = write_temp_claude_settings(extra_dirs)

    session_id = None
    session_id, desc_md, _ = claude_call(
        prompt=(
            f"You are enhancing a Linear project description.\nProject: {proj['name']}\n\n"
            "Analyze the repository and produce an improved project description: "
            "what it is, architecture, how to run, tests, deploy, key directories.\n"
            "Return markdown suitable for pasting into Linear project description."
        ),
        session_id=session_id,
        caps=caps,
        permission_mode="plan",
        max_turns=25,
        settings_path=settings_path,
    )
    agent_post("/agent/project/description", {"project_id": LINEAR_PROJECT_ID, "description": desc_md})
    stage("project", LINEAR_PROJECT_ID, "enhanced", message="✅ Project enhanced")


def project_create_issues() -> None:
    caps = detect_claude_capabilities()
    ctx = agent_get(f"/agent/context/project/{LINEAR_PROJECT_ID}")
    proj = ctx["project"]

    stage("project", LINEAR_PROJECT_ID, "create_issues", message="Generating issues")

    extra_dirs = []
    if EXTRA_REPOS.strip():
        for r in EXTRA_REPOS.split(","):
            r = r.strip()
            if not r:
                continue
            extra_dirs.append(os.path.abspath(f"_deps/{r.replace('/', '__')}"))
    settings_path = write_temp_claude_settings(extra_dirs)

    session_id = None
    session_id, out_text, _ = claude_call(
        prompt=(
            f"Project: {proj['name']}\n\n"
            "Generate actionable Linear issues for this project. "
            "Return STRICT JSON with keys: team_id (optional string) and issues (array of {title, description}). "
            "Each issue should be small enough to implement in a PR and include acceptance criteria. "
            "JSON only."
        ),
        session_id=session_id,
        caps=caps,
        permission_mode="plan",
        max_turns=25,
        settings_path=settings_path,
    )
    obj = extract_first_json(out_text)
    team_id = obj.get("team_id")
    issues = obj.get("issues") or []
    if not isinstance(issues, list) or not issues:
        raise RuntimeError("Claude did not return a valid issues list JSON.")

    agent_post("/agent/project/create-issues", {"project_id": LINEAR_PROJECT_ID, "team_id": team_id, "issues": issues})
    stage("project", LINEAR_PROJECT_ID, "issues_created", message=f"✅ Created {len(issues)} issues")


def main() -> None:
    if JOB_TYPE == "issue_flow":
        if not LINEAR_ISSUE_ID:
            raise RuntimeError("LINEAR_ISSUE_ID required")
        issue_flow()
    elif JOB_TYPE == "project_enhance":
        if not LINEAR_PROJECT_ID:
            raise RuntimeError("LINEAR_PROJECT_ID required")
        project_enhance()
    elif JOB_TYPE == "project_create_issues":
        if not LINEAR_PROJECT_ID:
            raise RuntimeError("LINEAR_PROJECT_ID required")
        project_create_issues()
    else:
        raise RuntimeError(f"Unknown JOB_TYPE: {JOB_TYPE}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # Best-effort report failure back to Linear
        try:
            if JOB_TYPE == "issue_flow" and LINEAR_ISSUE_ID:
                stage("issue", LINEAR_ISSUE_ID, "blocked", message=f"❌ Claude runner failed: {e}")
            elif JOB_TYPE.startswith("project") and LINEAR_PROJECT_ID:
                stage("project", LINEAR_PROJECT_ID, "blocked", message=f"❌ Claude runner failed: {e}")
        except Exception:
            pass
        raise
