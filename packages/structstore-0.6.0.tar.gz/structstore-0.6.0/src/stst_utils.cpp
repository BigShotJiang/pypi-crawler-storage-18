// This file is part of the StructStore library.
// Copyright (C) 2022-2025 Max Mertens
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License v3.0
// as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU General Lesser Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

#include "structstore/stst_utils.hpp"
#include <thread>
#include <utility>

using namespace structstore;

Log::Level Log::level{Log::Level::WARN};

uint64_t structstore::generate_rnd_seed() {
    auto tid = std::this_thread::get_id();
    auto now = std::chrono::system_clock::now();
    return std::hash<decltype(tid)>{}(tid) ^ now.time_since_epoch().count();
}
