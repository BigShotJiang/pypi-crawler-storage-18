import argparse
from py_wlcommands.commands import Command as Command, register_command as register_command, validate_command_args as validate_command_args
from py_wlcommands.commands.selfcommands.installation_manager import InstallationManager as InstallationManager
from py_wlcommands.commands.selfcommands.local_installer import LocalInstaller as LocalInstaller
from py_wlcommands.commands.selfcommands.pypi_updater import PypiUpdater as PypiUpdater
from py_wlcommands.commands.selfcommands.windows_update import WindowsUpdate as WindowsUpdate

class SelfCommand(Command):
    @property
    def name(self) -> str: ...
    @property
    def help(self) -> str: ...
    def add_arguments(self, parser: argparse.ArgumentParser) -> None: ...
    def execute(self, subcommand: str = 'update', path: str | None = None) -> None: ...
