from py_wlcommands.commands.selfcommands.installation_manager import InstallationManager as InstallationManager

class PypiUpdater:
    def update(self, uv_path: str, env: dict) -> None: ...
