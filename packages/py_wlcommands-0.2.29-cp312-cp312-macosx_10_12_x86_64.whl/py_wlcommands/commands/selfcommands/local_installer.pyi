from py_wlcommands.commands.selfcommands.installation_manager import InstallationManager as InstallationManager
from py_wlcommands.commands.selfcommands.windows_update import WindowsUpdate as WindowsUpdate
from py_wlcommands.utils.logging import log_info as log_info

class LocalInstaller:
    def install(self, uv_path: str, env: dict) -> None: ...
    def run_installation_attempt(self, uv_path: str, env: dict, timeout_duration: int, use_alternative: bool = False) -> bool: ...
