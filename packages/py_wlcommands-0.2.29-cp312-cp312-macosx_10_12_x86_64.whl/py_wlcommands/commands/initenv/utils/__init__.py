"""
Init command utilities.
"""
