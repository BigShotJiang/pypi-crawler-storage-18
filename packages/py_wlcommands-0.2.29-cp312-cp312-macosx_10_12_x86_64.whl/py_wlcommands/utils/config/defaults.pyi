from _typeshed import Incomplete
from py_wlcommands import __version__ as __version__
from typing import Any

DEFAULT_LOG_LEVEL: str
DEFAULT_LOG_FILE: str
DEFAULT_LOG_CONSOLE: bool
DEFAULT_LOG_CONSOLE_FORMAT: str
DEFAULT_LOG_FILE_FORMAT: str
DEFAULT_LOG_MAX_SIZE: Incomplete
DEFAULT_LOG_MAX_BACKUPS: int
DEFAULT_LOG_ROTATE_DAYS: int
DEFAULT_LANGUAGE: str
DEFAULT_ALIASES: Incomplete
DEFAULT_VERSION = __version__

def get_default_config() -> dict[str, Any]: ...
