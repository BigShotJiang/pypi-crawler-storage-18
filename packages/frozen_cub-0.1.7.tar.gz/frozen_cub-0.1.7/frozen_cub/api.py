"""Helper types and constants for frozen_cub package."""

from .dispatcher import Dispatcher
from .frozen import FrozenDict, freeze, is_primitive
from .utils import CacheKey, HashableValues, check_conditions, get_cache_key

NOT_CACHABLE = HashableValues(values=[None], cacheable=False)

type FreezableTypes = dict | list | set
type ThawTypes = FrozenDict | tuple | frozenset

__all__ = [
    "NOT_CACHABLE",
    "CacheKey",
    "Dispatcher",
    "FreezableTypes",
    "FrozenDict",
    "HashableValues",
    "ThawTypes",
    "check_conditions",
    "freeze",
    "get_cache_key",
    "is_primitive",
]
