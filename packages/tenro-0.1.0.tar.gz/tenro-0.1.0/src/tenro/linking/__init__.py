# Copyright 2025 Tenro.ai
# SPDX-License-Identifier: Apache-2.0

"""Linking utilities for agents, LLMs, and tools."""

from __future__ import annotations

from tenro.linking.decorators import link_agent, link_llm, link_tool

__all__ = [
    "link_agent",
    "link_llm",
    "link_tool",
]
