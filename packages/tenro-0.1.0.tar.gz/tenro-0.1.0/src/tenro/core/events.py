# Copyright 2025 Tenro.ai
# SPDX-License-Identifier: Apache-2.0

"""Event models for span tracking.

Immutable events are used to reconstruct spans on read.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Literal

from tenro.core.model_base import BaseModel


class SpanEvent(BaseModel):
    """Immutable event representing a span lifecycle event.

    The Three IDs:
    - trace_id: Groups entire workflow
    - span_id: Groups events of ONE operation
    - parent_span_id: Points to caller (`None` = root)

    These 3 IDs enable reconstruction of hierarchical spans from flat event list.

    Attributes:
        event_id: Unique event identifier.
        trace_id: Trace identifier for the overall workflow.
        span_id: Span identifier for a single operation.
        parent_span_id: Parent span identifier when nested.
        event_type: Lifecycle event type (`start`, `end`, or `error`).
        span_kind: Span category (`AGENT`, `LLM`, or `TOOL`).
        timestamp: Unix timestamp when the event was emitted.
        order_index: Monotonic order within the span stream.
        data: Payload data for the event.
    """

    # Core identifiers
    event_id: str
    trace_id: str
    span_id: str
    parent_span_id: str | None

    # Event metadata
    event_type: Literal["start", "end", "error"]
    span_kind: Literal["AGENT", "LLM", "TOOL"]
    timestamp: float
    order_index: int

    # Polymorphic payload (schema determined by span_kind + event_type)
    data: dict[str, Any]

    @classmethod
    def create_start(
        cls,
        trace_id: str,
        span_id: str,
        parent_span_id: str | None,
        span_kind: Literal["AGENT", "LLM", "TOOL"],
        data: dict[str, Any],
        order_index: int = 0,
    ) -> SpanEvent:
        """Create a start event."""
        return cls(
            event_id=str(uuid.uuid7()),
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=parent_span_id,
            event_type="start",
            span_kind=span_kind,
            timestamp=time.time(),
            order_index=order_index,
            data=data,
        )

    @classmethod
    def create_end(
        cls,
        trace_id: str,
        span_id: str,
        parent_span_id: str | None,
        span_kind: Literal["AGENT", "LLM", "TOOL"],
        data: dict[str, Any],
        order_index: int = 0,
    ) -> SpanEvent:
        """Create an end event."""
        return cls(
            event_id=str(uuid.uuid7()),
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=parent_span_id,
            event_type="end",
            span_kind=span_kind,
            timestamp=time.time(),
            order_index=order_index,
            data=data,
        )

    @classmethod
    def create_error(
        cls,
        trace_id: str,
        span_id: str,
        parent_span_id: str | None,
        span_kind: Literal["AGENT", "LLM", "TOOL"],
        error_message: str,
        order_index: int = 0,
    ) -> SpanEvent:
        """Create an error event."""
        return cls(
            event_id=str(uuid.uuid7()),
            trace_id=trace_id,
            span_id=span_id,
            parent_span_id=parent_span_id,
            event_type="error",
            span_kind=span_kind,
            timestamp=time.time(),
            order_index=order_index,
            data={"message": error_message},
        )
