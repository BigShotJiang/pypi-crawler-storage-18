"""Tests for fastmcp-pdftools"""
