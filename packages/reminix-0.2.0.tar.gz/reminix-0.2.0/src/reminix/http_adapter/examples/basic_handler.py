"""
Basic handler example

This demonstrates a simple single-file handler with agents and tools.

Usage:
    python -m reminix.http_adapter serve examples/basic_handler.py
"""

from typing import Dict, Any
from reminix.sdk.types import AgentHandler, ToolHandler, Context, Request, Response, Message


def chatbot(context: Context, request: Request) -> Response:
    """Simple chatbot agent"""
    last_message = request.messages[-1] if request.messages else None
    user_message = last_message.content if last_message else ""

    # Simple echo response
    return Response(
        messages=[
            Message(
                role="assistant",
                content=f'You said: "{user_message}". This is a basic echo response.',
            )
        ],
        metadata={"model": "basic-echo", "tokensUsed": 0},
    )


def calculator(context: Context, request: Request) -> Response:
    """Simple calculator tool"""
    import re

    last_message = request.messages[-1] if request.messages else None
    user_message = last_message.content if last_message else ""

    # Simple calculator - extract numbers and operation
    match = re.match(r"(\d+)\s*([+\-*/])\s*(\d+)", user_message)

    if not match:
        return Response(
            messages=[
                Message(
                    role="tool",
                    content='Invalid format. Please use: number operator number (e.g., "5 + 3")',
                )
            ],
            metadata={},
        )

    num1_str, operator, num2_str = match.groups()
    num1 = int(num1_str)
    num2 = int(num2_str)

    if operator == "+":
        result: float = num1 + num2
    elif operator == "-":
        result = num1 - num2
    elif operator == "*":
        result = num1 * num2
    elif operator == "/":
        result = num1 / num2
    else:
        result = 0.0

    return Response(
        messages=[
            Message(
                role="tool",
                content=f"{num1} {operator} {num2} = {result}",
            )
        ],
        metadata={"result": result},
    )


# Export agents, tools, and prompts
agents: Dict[str, AgentHandler] = {
    "chatbot": chatbot,
}

tools: Dict[str, ToolHandler] = {
    "calculator": calculator,
}

prompts: Dict[str, Any] = {
    "system": "You are a helpful assistant.",
    "greeting": "Hello! How can I help you today?",
}
