"""
Search tool example

This file is auto-discovered when using directory-based handlers.
"""

from reminix.sdk.types import Context, Request, Response, Message


def search(context: Context, request: Request) -> Response:
    """Search tool"""
    last_message = request.messages[-1] if request.messages else None
    query = last_message.content if last_message else ""

    # Mock search functionality
    mock_results = [
        {"title": "Result 1", "snippet": f"Found results for: {query}"},
        {"title": "Result 2", "snippet": "Additional search result"},
    ]

    results_text = "\n".join(
        f"{i + 1}. {r['title']}: {r['snippet']}" for i, r in enumerate(mock_results)
    )

    return Response(
        messages=[
            Message(
                role="tool",
                content=f'Search results for "{query}":\n{results_text}',
            )
        ],
        metadata={"resultsCount": len(mock_results), "query": query},
    )
