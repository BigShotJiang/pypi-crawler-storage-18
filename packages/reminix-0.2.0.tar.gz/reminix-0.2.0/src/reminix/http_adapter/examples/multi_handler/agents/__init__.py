"""
Agent examples
"""
