"""
System prompts example

This file is auto-discovered when using directory-based handlers.
"""

system = {
    "default": "You are a helpful AI assistant.",
    "professional": "You are a professional assistant. Be concise and accurate.",
    "friendly": "You are a friendly assistant. Be warm and conversational.",
}
