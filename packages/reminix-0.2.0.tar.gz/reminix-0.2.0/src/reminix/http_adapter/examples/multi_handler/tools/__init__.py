"""
Tool examples
"""
