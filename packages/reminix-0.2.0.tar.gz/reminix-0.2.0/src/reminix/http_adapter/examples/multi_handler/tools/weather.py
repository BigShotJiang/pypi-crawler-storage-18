"""
Weather tool example

This file is auto-discovered when using directory-based handlers.
"""

from reminix.sdk.types import Context, Request, Response, Message


def weather(context: Context, request: Request) -> Response:
    """Weather tool"""
    last_message = request.messages[-1] if request.messages else None
    location = last_message.content if last_message else "Unknown"

    # Mock weather data
    mock_weather = {
        "location": location,
        "temperature": "72°F",
        "condition": "Sunny",
        "humidity": "65%",
    }

    return Response(
        messages=[
            Message(
                role="tool",
                content=f"Weather for {location}: {mock_weather['temperature']}, {mock_weather['condition']}, Humidity: {mock_weather['humidity']}",
            )
        ],
        metadata=mock_weather,
    )
