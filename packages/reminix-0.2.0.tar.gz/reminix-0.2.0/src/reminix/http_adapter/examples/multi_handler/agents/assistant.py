"""
Assistant agent example

This file is auto-discovered when using directory-based handlers.
"""

from datetime import datetime
from reminix.sdk.types import Context, Request, Response, Message


def assistant(context: Context, request: Request) -> Response:
    """Assistant agent"""
    last_message = request.messages[-1] if request.messages else None
    user_message = last_message.content if last_message else ""

    # More sophisticated assistant response
    return Response(
        messages=[
            Message(
                role="assistant",
                content=f"I understand you're asking: \"{user_message}\". As your assistant, I'm here to help!",
            )
        ],
        metadata={
            "model": "multi-handler-assistant",
            "timestamp": datetime.now().isoformat(),
        },
    )
