"""
Multi-handler example
"""
