"""
Chatbot agent example

This file is auto-discovered when using directory-based handlers.
"""

from reminix.sdk.types import Context, Request, Response, Message


def chatbot(context: Context, request: Request) -> Response:
    """Chatbot agent"""
    last_message = request.messages[-1] if request.messages else None
    user_message = last_message.content if last_message else ""

    # Access context (memory, knowledge base, etc.)
    chat_id = context.chat_id

    # Simple response with context awareness
    return Response(
        messages=[
            Message(
                role="assistant",
                content=f'[Chat: {chat_id}] You said: "{user_message}". I\'m a chatbot agent from the multi-handler example.',
            )
        ],
        metadata={"model": "multi-handler-chatbot", "chatId": chat_id},
    )
