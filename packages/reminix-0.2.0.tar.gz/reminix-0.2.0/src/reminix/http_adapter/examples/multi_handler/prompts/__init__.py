"""
Prompt examples
"""
