# HTTP Adapter Examples

This directory contains example handlers demonstrating how to use the Reminix HTTP adapter.

## Basic Handler

A single-file handler with agents and tools.

**File:** `basic_handler.py`

**Usage:**

Run from the `src/reminix/http_adapter` directory:

```bash
# Basic handler
poetry run python -m reminix.http_adapter serve examples/basic_handler.py
```

**Features:**
- Single file with `agents`, `tools`, and `prompts` exports
- Simple chatbot agent
- Calculator tool

**Test it:**
```bash
# Health check
curl http://localhost:3000/health

# Invoke chatbot agent
curl -X POST http://localhost:3000/agents/chatbot/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello!"}]}'

# Invoke calculator tool
curl -X POST http://localhost:3000/tools/calculator/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "5 + 3"}]}'
```

## Multi Handler (Directory-based)

A directory-based handler with auto-discovery.

**Directory:** `multi_handler/`

**Usage:**

Run from the `src/reminix/http_adapter` directory:

```bash
# Multi-handler
poetry run python -m reminix.http_adapter serve examples/multi_handler
```

**Structure:**
```
multi_handler/
  agents/
    chatbot.py
    assistant.py
  tools/
    search.py
    weather.py
  prompts/
    system.py
```

**Features:**
- Auto-discovery from directory structure
- Multiple agents and tools
- Organized by type

**Test it:**
```bash
# Health check
curl http://localhost:3000/health

# Invoke chatbot agent
curl -X POST http://localhost:3000/agents/chatbot/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello!"}]}'

# Invoke assistant agent
curl -X POST http://localhost:3000/agents/assistant/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "What can you do?"}]}'

# Invoke search tool
curl -X POST http://localhost:3000/tools/search/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "AI agents"}]}'

# Invoke weather tool
curl -X POST http://localhost:3000/tools/weather/invoke \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "San Francisco"}]}'
```

