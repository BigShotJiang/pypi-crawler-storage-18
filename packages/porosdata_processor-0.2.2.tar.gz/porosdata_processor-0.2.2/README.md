# PorosData-Processor

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/) 	[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**PorosData-Processor** 是一款专为 **AI for Science** 场景打造的深度文本清洗管线，现阶段专注于对文档解析器（**MinerU**）输出的结构化 JSON 数据进行精细化处理，解决科研文献在转化为大模型可读格式时的各种“硬伤”，以期确保学术文档在输入大模型（LLM）前达到格式标准化、Token 最小化和逻辑完整化，

## 📖 项目初衷 (Motivation)

在 AI for Science 领域，高质量的数据预处理是模型理解学术文献的基础。虽然 MinerU 提供了强大的 PDF 解析能力，但其原始输出仍面临以下挑战：

* **公式损毁** ：标准的文本清洗规则常误触 LaTeX 公式，导致科学含义丢失。
* **结构碎片化** ：深层嵌套的 JSON 和非标准引用标记干扰了 RAG系统的索引质量。
* **Token 浪费** ：学术文档中大量的冗余空格和不规范字符增加了 LLM 的推理开销。

## 🌟核心亮点

PorosData-Processor的出现，正是为了在“清洗”与“保护”之间建立完美的平衡。

* **LaTeX 公式保护** ：自动识别并锁定行内 `$ ... $` 和行间 `$$...$$` 公式，避免清洗文本时破坏关键信息。
* **代码块保留** ：保护 Markdown 代码块及行内代码。
* **占位符机制** ：采用固定宽度的智能占位符，防止空格压缩影响布局。
* **学术规范化** ：自动修复希腊字母（**$\alpha, \beta$**）、罗马数字及章节编号。
* **参考文献净化** ：将多样化的引用格式（如 `【 1 】`）统一规范为 `[1]`。
* **Token 优化** ：清理 LaTeX 公式中的冗余空格，降低 LLM 消耗。

### 🛡️ 智能 Shield 保护机制

针对学术文档中的敏感内容，开发了“预处理-清洗-恢复”三段式保护流程，确保核心信息“零损毁”，确保敏感数据在清洗过程中的绝对安全：：

* **预屏蔽 (Pre-Shield)** ：利用正则引擎锁定 LaTeX 公式、代码块等区域，映射至固定宽度的占位符（如 `__CLEANLIT_SHIELD_001__`）。
* **安全清洗 (Safe Cleaning)** ：对占位符之外的“纯文本区域”执行高强度的章节规范和空白压缩。
* **精准恢复 (Post-Shield)** ：清洗完成后，将占位符逆向还原为原始的文献内容。

### 🔌 模块化扩展插件

基于 **Plugin Registry** 架构，开发者可以通过装饰器轻松扩展业务逻辑。这种设计实现了清洗规则与核心管线的完全解耦，支持用户根据不同的语料库动态，及其科研需要组合自己的 Pipeline。

```
@PluginRegistry.register("custom_academic_rule")
def my_rule(text: str) -> str:
    # 针对特定领域（如物理、生物）的自定义清洗逻辑
    return processed_text
```

## 📊 核心功能矩阵

| **功能模块**       | **解决的问题**                | **示例 (输入 -> 输出)**               |
| ------------------------ | ----------------------------------- | ------------------------------------------- |
| **中英文标点修复** | 修复标点混用与多余空格              | `"Hello，world"`-> 标准化输出             |
| **参考文献规范化** | 统一 `【1】`、`[ 2 ]`等引用标记 | `【1】`->`[1]`                          |
| **罗马数字转换**   | 统一数字表示（如 `II`,`III`）   | `Chapter II`->`Chapter 2`               |
| **章节编号标准化** | 修复文档结构编号混乱                | `第1章 1.1节`->`Chapter 1, Section 1.1` |
| **希腊字母转换**   | 将希腊字符转为 LaTeX 学术符号       | `α + β`->`\alpha + \beta`             |
| **空白字符优化**   | 清除多余空格与非法换行              | `Text   with spaces`-> 规范间距           |
| **LaTeX 公式压缩** | 预处理公式内空格，优化 Token 消耗   | `$ \alpha + \beta $`->`$\alpha+\beta$`  |

## ⚙️安装与命名规范

### **⚠️ 重要说明** ：

* **PyPI 安装名** ：`PorosData-Processor` (使用连字符 `-`)
* **Python 导入名** ：`import porosdata_processor` (使用下划线 `_`)
* **命令行工具** ：`porosdata-processor`

```bash
pip install porosdata-processor
```

> **Notice**: 虽然 PyPI 安装包名为 `PorosData-Processor`（带连字符 - ），但在代码中引用时必须使用下划线：`import porosdata_processor`

```bash
python -c "import porosdata_processor; print('porosdata_processor 导入成功')"
```

## 🚀 快速上手 (Quick Start)

```python
from porosdata_processor import TextCleaner

# 方式 1：使用默认管线（推荐）
cleaner = TextCleaner()

# 方式 2：自定义插件组合
cleaner = TextCleaner(pipeline=["patterns_cleaning", "greek_to_latex"])

# 执行清洗
raw_text = "识别 α 粒子在文献 【1】 中的描述。"
cleaned_text = cleaner.clean(raw_text)
```

```
# 启用高级选项：清理公式内部多余空格
cleaner = TextCleaner(clean_options={"clean_latex_math_spaces": True})

# 仅启用特定插件
custom_cleaner = TextCleaner(pipeline=["citation_rules", "greek_to_latex"])
```

## ✅ 可靠性保证

本项目采用严格的单元测试框架，覆盖了以下核心维度：

* **核心注册系统覆盖率** ：100%
* **编码兼容性验证** ：支持 Windows/Linux/MacOS 全平台 UTF-8 免疫处理

## 🗺️ 发展路线 (Roadmap)

* [ ] **领域特定优化** ：针对 arXiv 论文、编程语言特定格式的深度清洗。
* [ ] **AI 模型集成** ：引入轻量级 LLM 辅助识别清洗质量。
