# Jetson NLP Monitor
[![PyPI version](https://badge.fury.io/py/jetson-nlp-monitor.svg)](https://badge.fury.io/py/jetson-nlp-monitor)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/jetson-nlp-monitor)](https://pepy.tech/project/jetson-nlp-monitor)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)

Package for processing user queries about system performance and resource usage on Nvidia Jetson boards.

## Overview
This package processes natural language input regarding system performance and resource usage on Nvidia Jetson boards. It takes user queries, extracts relevant metrics, and returns structured, pattern-verified responses.

## Installation
```bash
pip install jetson_nlp_monitor
```

## Usage
```python
from jetson_nlp_monitor import jetson_nlp_monitor

response = jetson_nlp_monitor(user_input="What's the current GPU utilization?")
print(response)
```

## Function Parameters
- `user_input`: str - the user input text to process
- `llm`: Optional[BaseChatModel] - the langchain llm instance to use, if not provided the default ChatLLM7 will be used.
- `api_key`: Optional[str] - the api key for llm7, if not provided the default ChatLLM7 will be used.

## Default LLM Usage
This package uses the ChatLLM7 from langchain_llm7 by default. You can safely pass your own llm instance (based on https://docs.langchain.com/llm/) if you want to use another LLM, via passing it like `jetson_nlp_monitor(user_input, llm=your_llm_instance)`.

Example usage with different LLMs:
```python
from langchain_openai import ChatOpenAI
from jetson_nlp_monitor import jetson_nlp_monitor
llm = ChatOpenAI()
response = jetson_nlp_monitor(user_input, llm=llm)

from langchain_anthropic import ChatAnthropic
from jetson_nlp_monitor import jetson_nlp_monitor
llm = ChatAnthropic()
response = jetson_nlp_monitor(user_input, llm=llm)

from langchain_google_genai import ChatGoogleGenerativeAI
from jetson_nlp_monitor import jetson_nlp_monitor
llm = ChatGoogleGenerativeAI()
response = jetson_nlp_monitor(user_input, llm=llm)
```

## Rate Limits
The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits for LLM7, you can pass your own api_key via environment variable LLM7_API_KEY or via passing it directly like `jetson_nlp_monitor(user_input, api_key="your_api_key")`.

You can get a free api key by registering at https://token.llm7.io/

## Issues
Report any issues to https://github.com/chigwell/jetson-nlp-monitor

## Author
Eugene Evstafev (eugene@eugene.plus)

## License
Not specified.

## GitHub
https://github.com/chigwell/jetson-nlp-monitor