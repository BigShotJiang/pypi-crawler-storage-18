from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="omniai-lakshya",
    version="1.0.0",
    author="Lakshya Gupta",
    author_email="YOUREMAIL@gmail.com",  # ← Change this
    description="OmniAI ML Automation - Christmas 2025 by Lakshya Gupta",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/YOURUSERNAME/omniai",  # ← Change this
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Free for non-commercial use",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "pandas>=1.0",
        "numpy>=1.19",
    ],
)