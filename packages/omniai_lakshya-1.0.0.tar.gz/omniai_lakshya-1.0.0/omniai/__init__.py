# omniai/__init__.py
from .main import OmniAI

__version__ = "0.1.0"
__all__ = ["OmniAI"]

print("OmniAI package loaded successfully")
