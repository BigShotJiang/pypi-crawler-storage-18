"""
Verify email function - standalone, no database required.
"""

from typing import Dict, Any

from apexsaas.exceptions import ApexValidationError, ApexAuthError


def verify_email(
    token: str,
    stored_token: str,
    email: str = None
) -> Dict[str, Any]:
    """
    Verify email with token.
    
    Args:
        token: Verification token from request
        stored_token: Token stored in database
    
    Returns:
        dict with verification status:
        {
            'verified': bool,
            'message': str
        }
    
    Raises:
        ApexValidationError: If input validation fails
        ApexAuthError: If token is invalid
    """
    if not token:
        raise ApexValidationError("Token is required")
    if not stored_token:
        raise ApexValidationError("stored_token is required")
    
    # Verify token
    if token != stored_token:
        raise ApexAuthError("Invalid verification token")
    
    return {
        'verified': True,
        'email': email or 'user@example.com',  # Should be passed from caller
        'message': 'Email verified successfully'
    }


