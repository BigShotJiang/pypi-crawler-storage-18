"""
ApexSaaS - Lightweight authentication, payments, and email utilities.
"""

__version__ = '1.0.0'

# Auth exports
from apexsaas.auth.signup import signup
from apexsaas.auth.login import login
from apexsaas.auth.logout import logout
from apexsaas.auth.forgot_password import forgot_password
from apexsaas.auth.reset_password import reset_password
from apexsaas.auth.verify_email import verify_email
from apexsaas.auth.verify_token import verify_token
from apexsaas.auth.refresh_token import refresh_access_token

# Payment exports
from apexsaas.payments.create_order import create_order
from apexsaas.payments.capture_order import capture_order
from apexsaas.payments.get_order import get_order
from apexsaas.payments.refund_payment import refund_payment
from apexsaas.payments.create_subscription_plan import create_subscription_plan
from apexsaas.payments.create_subscription import create_subscription
from apexsaas.payments.get_subscription import get_subscription
from apexsaas.payments.cancel_subscription import cancel_subscription

# Email exports
from apexsaas.email.send_verification_email import send_verification_email
from apexsaas.email.send_reset_email import send_reset_email
from apexsaas.email.send_welcome_email import send_welcome_email
from apexsaas.email.send_payment_confirmation import send_payment_confirmation
from apexsaas.email.send_email import send_email

# Exception exports
from apexsaas.exceptions import (
    ApexError,
    ApexAuthError,
    ApexValidationError,
    ApexPaymentError,
    ApexEmailError
)

__all__ = [
    # Auth
    'signup',
    'login',
    'logout',
    'forgot_password',
    'reset_password',
    'verify_email',
    'verify_token',
    'refresh_access_token',
    # Payments
    'create_order',
    'capture_order',
    'get_order',
    'refund_payment',
    'create_subscription_plan',
    'create_subscription',
    'get_subscription',
    'cancel_subscription',
    # Email
    'send_verification_email',
    'send_reset_email',
    'send_welcome_email',
    'send_payment_confirmation',
    'send_email',
    # Exceptions
    'ApexError',
    'ApexAuthError',
    'ApexValidationError',
    'ApexPaymentError',
    'ApexEmailError',
]
