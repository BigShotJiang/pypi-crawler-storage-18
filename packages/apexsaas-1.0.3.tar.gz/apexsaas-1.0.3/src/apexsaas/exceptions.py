"""
Apex package exceptions.
"""


class ApexError(Exception):
    """Base exception for Apex package."""
    pass


class ApexAuthError(ApexError):
    """Authentication related errors."""
    pass


class ApexValidationError(ApexError):
    """Validation errors."""
    pass


class ApexPaymentError(ApexError):
    """Payment processing errors."""
    pass


class ApexEmailError(ApexError):
    """Email sending errors."""
    pass


__all__ = [
    'ApexError',
    'ApexAuthError',
    'ApexValidationError',
    'ApexPaymentError',
    'ApexEmailError',
]


