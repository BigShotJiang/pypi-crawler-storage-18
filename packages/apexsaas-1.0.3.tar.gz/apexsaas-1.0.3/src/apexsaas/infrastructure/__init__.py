"""
Infrastructure adapters - internal use only.
Not part of public API.
"""

from apexsaas.infrastructure.paypal.client import PayPalClient
from apexsaas.infrastructure.paypal.service import PayPalService

__all__ = [
    "PayPalClient",
    "PayPalService",
]


