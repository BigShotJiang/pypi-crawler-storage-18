"""Configuration module for apex package."""

from apexsaas.core.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]

