"""
Email template helper functions (internal).
"""


def get_verification_template(verification_url: str, name: str) -> str:
    """
    Return HTML template for verification email.
    
    Args:
        verification_url: URL for email verification
        name: Recipient name
    
    Returns:
        HTML email template string
    """
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verify Your Email</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
            <h1 style="color: #333; margin-top: 0;">Verify Your Email</h1>
            <p>Hi {name},</p>
            <p>Thank you for signing up! Please verify your email address by clicking the button below:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{verification_url}" style="background-color: #007bff; color: #ffffff; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Verify Email</a>
            </div>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #007bff;">{verification_url}</p>
            <p>If you didn't create an account, you can safely ignore this email.</p>
            <p style="margin-top: 30px; color: #666; font-size: 12px;">This link will expire in 24 hours.</p>
        </div>
    </body>
    </html>
    """


def get_reset_template(reset_url: str, name: str) -> str:
    """
    Return HTML template for password reset email.
    
    Args:
        reset_url: URL for password reset
        name: Recipient name
    
    Returns:
        HTML email template string
    """
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reset Your Password</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
            <h1 style="color: #333; margin-top: 0;">Reset Your Password</h1>
            <p>Hi {name},</p>
            <p>We received a request to reset your password. Click the button below to create a new password:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{reset_url}" style="background-color: #dc3545; color: #ffffff; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Reset Password</a>
            </div>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #007bff;">{reset_url}</p>
            <p>If you didn't request a password reset, you can safely ignore this email. Your password will not be changed.</p>
            <p style="margin-top: 30px; color: #666; font-size: 12px;">This link will expire in 1 hour.</p>
        </div>
    </body>
    </html>
    """


def get_welcome_template(name: str, app_url: str = None) -> str:
    """
    Return HTML template for welcome email.
    
    Args:
        name: Recipient name
        app_url: Optional application URL
    
    Returns:
        HTML email template string
    """
    app_link = ''
    if app_url:
        app_link = f'''
            <div style="text-align: center; margin: 30px 0;">
                <a href="{app_url}" style="background-color: #007bff; color: #ffffff; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Get Started</a>
            </div>
        '''
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to ApexSaaS!</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa;">
        <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #007bff; margin: 0; font-size: 32px;">🎉 Welcome, {name}!</h1>
            </div>
            
            <p style="font-size: 16px; color: #333;">Thank you for joining <strong>ApexSaaS</strong>! We're thrilled to have you on board.</p>
            
            <p style="font-size: 16px; color: #333;">Your account has been successfully created and you're all set to start using our platform.</p>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 25px 0; border-left: 4px solid #007bff;">
                <h2 style="color: #333; margin-top: 0; font-size: 20px;">What's Next?</h2>
                <ul style="color: #555; padding-left: 20px;">
                    <li style="margin: 10px 0;">Complete your profile setup</li>
                    <li style="margin: 10px 0;">Explore our powerful features</li>
                    <li style="margin: 10px 0;">Get started with your first project</li>
                    <li style="margin: 10px 0;">Connect with our community</li>
                </ul>
            </div>
            
            {app_link}
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e0e0e0;">
                <p style="color: #666; font-size: 14px; margin: 0;">If you have any questions or need assistance, our support team is here to help!</p>
                <p style="color: #666; font-size: 14px; margin: 5px 0 0 0;">Just reply to this email or contact us anytime.</p>
            </div>
            
            <p style="margin-top: 30px; color: #333; font-size: 14px;">
                Best regards,<br>
                <strong style="color: #007bff;">The ApexSaaS Team</strong>
            </p>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
            <p>This is an automated email from ApexSaaS. Please do not reply directly to this message.</p>
        </div>
    </body>
    </html>
    """


def get_payment_confirmation_template(
    name: str,
    amount: str,
    currency: str,
    transaction_id: str,
    receipt_url: str = None
) -> str:
    """
    Return HTML template for payment confirmation.
    
    Args:
        name: Recipient name
        amount: Payment amount
        currency: Currency code
        transaction_id: Transaction ID
        receipt_url: Optional receipt URL
    
    Returns:
        HTML email template string
    """
    receipt_link = f'<p><a href="{receipt_url}" style="color: #007bff;">View Receipt</a></p>' if receipt_url else ''
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Confirmation</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
            <h1 style="color: #28a745; margin-top: 0;">Payment Confirmed</h1>
            <p>Hi {name},</p>
            <p>Thank you for your payment! Your transaction has been successfully processed.</p>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #28a745;">
                <p style="margin: 0;"><strong>Amount:</strong> {amount} {currency}</p>
                <p style="margin: 5px 0;"><strong>Transaction ID:</strong> {transaction_id}</p>
                <p style="margin: 5px 0;"><strong>Status:</strong> <span style="color: #28a745;">Completed</span></p>
            </div>
            {receipt_link}
            <p>If you have any questions about this transaction, please contact our support team.</p>
            <p style="margin-top: 30px;">Best regards,<br>The Team</p>
        </div>
    </body>
    </html>
    """


