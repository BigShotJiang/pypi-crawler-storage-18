"""
Paynet payment gateway internal implementation.
This module contains the actual business logic and will be compiled to .so
"""
import logging
from typing import Union

from paytechuz.license import _validate_license_api_key

logger = logging.getLogger(__name__)


class PaynetGatewayInternal:
    """Internal implementation of Paynet gateway logic."""

    def __init__(self, merchant_id: Union[str, int], is_test_mode: bool):
        # Validate license - read PAYTECH_LICENSE_API_KEY from .env (environment variable)
        _validate_license_api_key()

        self.merchant_id = str(merchant_id)
        self.is_test_mode = is_test_mode

    def generate_pay_link(
        self,
        id: Union[int, str],
        amount: Union[int, float, str]
    ) -> str:
        """
        Generate a payment link for Paynet.

        Args:
            id: Unique identifier for the account/payment
            amount: Payment amount in som (Paynet doesn't use amount in URL)

        Returns:
            Paynet payment URL with merchant ID and account ID
        """
        # Paynet URL structure: https://app.paynet.uz/?m={merchant_id}&c={account_id}
        # Note: Amount is not passed in URL, it's configured on Paynet's side
        base_url = "https://app.paynet.uz"
        return f"{base_url}/?m={self.merchant_id}&c={id}"
