"""File organizer module"""
