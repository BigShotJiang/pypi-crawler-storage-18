# Contributing

Contributions are welcome, and they are greatly appreciated! Every little bit helps, and credit will always be given.

You can contribute in many ways:

## Types of Contributions

### Report Bugs

Report bugs at [https://github.com/AlFontal/sdcpy/issues](https://github.com/AlFontal/sdcpy/issues).

If you are reporting a bug, please include:

* Your operating system name and version.
* Any details about your local setup that might be helpful in troubleshooting.
* Detailed steps to reproduce the bug.

### Fix Bugs

Look through the GitHub issues for bugs. Anything tagged with "bug" and "help wanted" is open to whoever wants to implement it.

### Implement Features

Look through the GitHub issues for features. Anything tagged with "enhancement" and "help wanted" is open to whoever wants to implement it.

### Write Documentation

sdcpy could always use more documentation, whether as part of the official sdcpy docs, in docstrings, or even on the web in blog posts, articles, and such.

### Submit Feedback

The best way to send feedback is to file an issue at [https://github.com/AlFontal/sdcpy/issues](https://github.com/AlFontal/sdcpy/issues).

If you are proposing a feature:

* Explain in detail how it would work.
* Keep the scope as narrow as possible, to make it easier to implement.
* Remember that this is a volunteer-driven project, and that contributions are welcome :)

## Get Started!

Ready to contribute? Here's how to set up `sdcpy` for local development.

1. Fork the `sdcpy` repo on GitHub.
2. Clone your fork locally:
   ```bash
   git clone git@github.com:your_name_here/sdcpy.git
   ```
3. Install uv if you don't have it:
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```
4. Install your local copy with uv:
   ```bash
   cd sdcpy/
   uv sync --all-groups
   ```
5. Create a branch for local development:
   ```bash
   git checkout -b name-of-your-bugfix-or-feature
   ```
   Now you can make your changes locally.

6. When you're done making changes, check that your changes pass tests:
   ```bash
   uv run ruff check .
   uv run pytest
   ```

7. Commit your changes and push your branch to GitHub:
   ```bash
   git add .
   git commit -m "Your detailed description of your changes."
   git push origin name-of-your-bugfix-or-feature
   ```

8. Submit a pull request through the GitHub website.

## Pull Request Guidelines

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put your new functionality into a function with a docstring, and add the feature to the list in README.md.
3. The pull request should work for all supported Python versions.

## Tips

To run a subset of tests:
```bash
uv run pytest tests/test_sdcpy.py
```

## Deploying

A reminder for the maintainers on how to deploy.
Make sure all your changes are committed.
Then run:
```bash
bump-my-version bump patch # possible: major / minor / patch
git push
git push --tags
```
GitHub Actions will then build and publish to PyPI via Trusted Publishing.
