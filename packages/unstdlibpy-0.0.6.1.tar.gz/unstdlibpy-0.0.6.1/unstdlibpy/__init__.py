
"""
Initialization file for the unstdlibpy package.
Provides access to various utility modules such as math, random, save, const, algo, and universal.
"""

from . import maths, random, save, const, algo, universal # type: ignore

__version__ = "0.0.6.1"
