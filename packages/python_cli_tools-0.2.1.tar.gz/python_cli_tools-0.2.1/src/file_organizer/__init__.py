"""File organizer module"""
