"""ChunkOps CLI entry point"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import List

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.text import Text
from rich import box

from chunkops_cli.extractor import PDFExtractor, Chunk
from chunkops_cli.deduper import Deduplicator, DuplicateMatch

console = Console()


def find_pdfs(directory: str) -> List[str]:
    """Find all PDF files in a directory"""
    pdf_files = []
    path = Path(directory)
    
    if not path.exists():
        console.print(f"[red]Error:[/red] Directory '{directory}' does not exist")
        sys.exit(1)
    
    if not path.is_dir():
        console.print(f"[red]Error:[/red] '{directory}' is not a directory")
        sys.exit(1)
    
    for file_path in path.rglob("*.pdf"):
        pdf_files.append(str(file_path))
    
    if not pdf_files:
        console.print(f"[yellow]Warning:[/yellow] No PDF files found in '{directory}'")
    
    return sorted(pdf_files)


def generate_report(
    duplicates: List[DuplicateMatch],
    total_files: int,
    total_chunks: int
) -> dict:
    """Generate JSON report"""
    exact_count = sum(1 for d in duplicates if d.type == "EXACT_DUPLICATE")
    near_count = sum(1 for d in duplicates if d.type == "NEAR_DUPLICATE")
    
    # Count unique chunks (approximate)
    unique_chunks = total_chunks - exact_count
    
    return {
        "scan_date": datetime.utcnow().isoformat() + "Z",
        "total_files": total_files,
        "total_chunks": total_chunks,
        "duplicates": [
            {
                "type": d.type,
                "file_a": os.path.basename(d.file_a),
                "file_b": os.path.basename(d.file_b),
                "file_a_path": d.file_a,
                "file_b_path": d.file_b,
                "similarity": round(d.similarity, 4),
                "chunk_a_preview": d.chunk_a_preview,
                "chunk_b_preview": d.chunk_b_preview,
            }
            for d in duplicates
        ],
        "summary": {
            "exact_duplicates": exact_count,
            "near_duplicates": near_count,
            "unique_content": unique_chunks
        }
    }


def display_duplicate(duplicate: DuplicateMatch, index: int):
    """Display a duplicate match with colors"""
    dup_type = duplicate.type
    similarity = duplicate.similarity
    
    if dup_type == "EXACT_DUPLICATE":
        color = "red"
        icon = "🔴"
        title = "Exact Duplicate"
    else:
        color = "yellow"
        icon = "🟡"
        title = "Near Duplicate"
    
    # Create a panel for the duplicate
    content = f"[bold]{icon} {title} Detected[/bold]\n"
    content += f"[dim]Similarity: {similarity:.2%}[/dim]\n\n"
    
    # File comparison
    file_a_name = os.path.basename(duplicate.file_a)
    file_b_name = os.path.basename(duplicate.file_b)
    
    content += f"[red]-[/red] [dim]{file_a_name}:[/dim]\n"
    content += f"  {duplicate.chunk_a_preview[:150]}...\n\n"
    
    content += f"[green]+[/green] [dim]{file_b_name}:[/dim]\n"
    content += f"  {duplicate.chunk_b_preview[:150]}..."
    
    console.print(Panel(
        content,
        title=f"[{color}]{title} #{index + 1}[/{color}]",
        border_style=color,
        box=box.ROUNDED
    ))
    console.print()


def scan_command(args):
    """Execute the scan command"""
    directory = args.directory
    output_file = args.output
    exact_threshold = args.exact_threshold
    near_threshold = args.threshold
    verbose = args.verbose
    
    # Header
    console.print("\n[bold cyan]ChunkOps CLI[/bold cyan] - Duplicate Detection\n")
    
    if verbose:
        console.print(f"[dim]Scanning directory:[/dim] {directory}")
        console.print(f"[dim]Exact threshold:[/dim] {exact_threshold}")
        console.print(f"[dim]Near duplicate threshold:[/dim] {near_threshold}")
        console.print()
    
    # Find PDF files
    with console.status("[bold yellow]🔍[/bold yellow] Finding PDF files...", spinner="dots"):
        pdf_files = find_pdfs(directory)
    
    if not pdf_files:
        console.print("[red]❌[/red] No PDF files found. Exiting.")
        sys.exit(1)
    
    console.print(f"[green]✓[/green] Found [bold]{len(pdf_files)}[/bold] PDF file(s)\n")
    
    # Extract chunks from all PDFs
    extractor = PDFExtractor()
    all_chunks = []
    
    console.print("[bold yellow]⚡[/bold yellow] Analyzing [bold]{}[/bold] documents...".format(len(pdf_files)))
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console
    ) as progress:
        task = progress.add_task("Extracting text from PDFs...", total=len(pdf_files))
        
        for pdf_file in pdf_files:
            try:
                if verbose:
                    progress.update(task, description=f"Processing: {os.path.basename(pdf_file)}")
                chunks = extractor.process_file(pdf_file)
                all_chunks.extend(chunks)
                progress.advance(task)
            except Exception as e:
                console.print(f"[red]✗[/red] Error processing {pdf_file}: [red]{e}[/red]")
                progress.advance(task)
                continue
    
    if not all_chunks:
        console.print("[red]❌[/red] No content extracted from PDFs. Exiting.")
        sys.exit(1)
    
    console.print(f"[green]✓[/green] Extracted [bold]{len(all_chunks)}[/bold] chunks total\n")
    
    # Detect duplicates
    console.print("[bold yellow]🔍[/bold yellow] Extracting semantic claims...")
    
    deduper = Deduplicator(
        exact_threshold=exact_threshold,
        near_threshold=near_threshold
    )
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Detecting duplicates...", total=None)
        duplicates = deduper.find_duplicates(all_chunks)
        progress.update(task, completed=True)
    
    # Display results
    if duplicates:
        exact_count = sum(1 for d in duplicates if d.type == "EXACT_DUPLICATE")
        near_count = sum(1 for d in duplicates if d.type == "NEAR_DUPLICATE")
        
        console.print()
        console.print(Panel(
            f"[bold red]⚠️  Conflict Detected[/bold red]\n\n"
            f"[yellow]Found {exact_count} exact duplicate(s) and {near_count} near duplicate(s)[/yellow]",
            border_style="red",
            box=box.ROUNDED
        ))
        console.print()
        
        # Display each duplicate
        for i, duplicate in enumerate(duplicates):
            display_duplicate(duplicate, i)
    else:
        console.print("[green]✓[/green] [bold]No duplicates found![/bold] All content is unique.\n")
    
    # Generate report
    report = generate_report(duplicates, len(pdf_files), len(all_chunks))
    
    # Write output
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Summary
    exact_count = report['summary']['exact_duplicates']
    near_count = report['summary']['near_duplicates']
    
    summary_table = Table(show_header=False, box=None, padding=(0, 2))
    summary_table.add_column(style="dim")
    summary_table.add_column(style="bold")
    
    summary_table.add_row("📄 Files scanned:", str(len(pdf_files)))
    summary_table.add_row("📝 Total chunks:", str(len(all_chunks)))
    summary_table.add_row("🔴 Exact duplicates:", f"[red]{exact_count}[/red]")
    summary_table.add_row("🟡 Near duplicates:", f"[yellow]{near_count}[/yellow]")
    summary_table.add_row("📊 Report saved:", f"[green]{output_file}[/green]")
    
    console.print("\n[bold]Summary:[/bold]")
    console.print(summary_table)
    console.print()


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="ChunkOps CLI - Detect duplicate content in PDF documents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  chunkops scan ./documents
  chunkops scan ./documents --output report.json
  chunkops scan ./documents --threshold 0.95 --exact-threshold 0.99
        """
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version="chunkops 0.1.0"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Scan command
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a folder of PDFs for duplicates"
    )
    scan_parser.add_argument(
        "directory",
        help="Directory containing PDF files to scan"
    )
    scan_parser.add_argument(
        "-o", "--output",
        default="duplicates_report.json",
        help="Output JSON file path (default: duplicates_report.json)"
    )
    scan_parser.add_argument(
        "--threshold",
        type=float,
        default=0.90,
        help="Similarity threshold for near-duplicates (0.0-1.0, default: 0.90)"
    )
    scan_parser.add_argument(
        "--exact-threshold",
        type=float,
        default=1.0,
        help="Similarity threshold for exact duplicates (default: 1.0)"
    )
    scan_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    if args.command == "scan":
        scan_command(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
