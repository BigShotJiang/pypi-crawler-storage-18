"""Some shared utilities."""
