#!/usr/bin/env python3
# sr.py
"""License & Disclaimer
Copyright © 2025 Viren
This software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, or non-infringement.
By using this software, you agree that Viren Sahti is not responsible for any direct, indirect, incidental, special, exemplary, or consequential damages, including but not limited to damages for loss of data, profits, or any other intangible losses, resulting from:
any misuse of the software
criminal activity, hacking, or any illegal use
any modifications or derivative works
any failure, bug, or security breach
You may use this software only for legitimate purposes. Redistribution, modification, or claiming the code as your own is strictly prohibited. All rights, title, and interest in the software remain with Viren Sahti.
In summary: Any damage, illegal activity, or misuse done with this software is not the responsibility of Viren Sahti. Use at your own risk.
"""    

"""# Secure Run (sr)

Encrypt Python files and run them securely using OpenSSL.

## Install
```bash
pip install secure-run
"""
import os
import sys
import json
import time
import base64
import getpass
import hashlib
import argparse
import subprocess
import tempfile
import traceback
import hmac
import gc
from datetime import datetime
from shutil import which

VERSION = "1.1.0"

def _user_data_dir():
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "sr")
    else:
        return os.path.join(os.path.expanduser("~/.local/share"), "sr")

BASE_DIR = _user_data_dir()
LOCKED_DIR = os.path.join(BASE_DIR, "locked")
CSI = "\033["
GREEN = CSI + "32m"
YELLOW = CSI + "33m"
RED = CSI + "31m"
RESET = CSI + "0m"
BOLD = CSI + "1m"

_runtime_cache = {}

_PBKDF2_ITER = 2_000_000
_DK_LEN = 48

def _ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _info(msg):
    print(f"{GREEN}[{_ts()}] {msg}{RESET}")

def _warn(msg):
    print(f"{YELLOW}[{_ts()}] {msg}{RESET}")

def _err(msg):
    print(f"{RED}[{_ts()}] {msg}{RESET}")

def _ensure_dirs():
    os.makedirs(LOCKED_DIR, exist_ok=True)

def _sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()

def _sr_path(label: str) -> str:
    safe = label.replace("/", "_").replace("..", "_").replace(" ", "_")
    return os.path.join(LOCKED_DIR, f"{safe}.sr")

def _have_openssl() -> bool:
    return which("openssl") is not None

def _derive_key_iv(password: bytes, salt: bytes, iterations: int = _PBKDF2_ITER):
    if iterations <= 0:
        raise ValueError("Invalid PBKDF2 iteration count")
    dk = hashlib.pbkdf2_hmac("sha256", password, salt, iterations, dklen=_DK_LEN)
    key = dk[:32]
    iv = dk[32:48]
    try:
        if isinstance(dk, bytearray):
            for i in range(len(dk)):
                dk[i] = 0
    except Exception:
        pass
    return key, iv

def _openssl_enc(cmd_args, input_bytes: bytes) -> bytes:
    try:
        proc = subprocess.run(cmd_args, input=input_bytes, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError:
        raise RuntimeError("OpenSSL executable not found on PATH.")
    except Exception as e:
        raise RuntimeError(f"Failed to run OpenSSL: {e}")

    if proc.returncode != 0:
        stderr = proc.stderr.decode("utf-8", errors="ignore").strip()
        if "bad decrypt" in stderr.lower():
            raise RuntimeError("OpenSSL reported 'bad decrypt' (wrong key/iv or corrupted ciphertext).")
        raise RuntimeError(f"OpenSSL error: {stderr or 'exit code ' + str(proc.returncode)}")
    return proc.stdout

def _openssl_encrypt(plain: bytes, key: bytes, iv: bytes) -> bytes:
    if not _have_openssl():
        raise RuntimeError("OpenSSL not found on PATH. Install openssl before using sr.py.")
    keyhex = key.hex()
    ivhex = iv.hex()
    cmd = ["openssl", "enc", "-aes-256-cbc", "-K", keyhex, "-iv", ivhex]
    return _openssl_enc(cmd, plain)

def _openssl_decrypt(cipher: bytes, key: bytes, iv: bytes) -> bytes:
    if not _have_openssl():
        raise RuntimeError("OpenSSL not found on PATH. Install openssl before using sr.py.")
    keyhex = key.hex()
    ivhex = iv.hex()
    cmd = ["openssl", "enc", "-d", "-aes-256-cbc", "-K", keyhex, "-iv", ivhex]
    return _openssl_enc(cmd, cipher)

def _zero_bytes(b):
    try:
        if isinstance(b, bytearray):
            for i in range(len(b)):
                b[i] = 0
    except Exception:
        pass

def setup():
    _ensure_dirs()
    _info(f"SR setup done. Version {VERSION}")

def logo():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
{RESET}""")

def logo_with_text():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
  Secure Run
{RESET}""")

def logo_with_version():
    print(f"""{GREEN}{BOLD}
  ███████╗██████╗ 
  ██╔════╝██╔══██╗
  ███████╗██████╔╝
  ╚════██║██╔══██╗
  ███████║██║  ██║
  ╚══════╝╚═╝  ╚═╝
  Secure Run {VERSION}
{RESET}""")

def cls():
    os.system("cls" if os.name == "nt" else "clear")
    logo()
    
def lock(label: str, filepath: str, password: str = None, pbkdf2_iter: int = _PBKDF2_ITER):
    if not filepath.endswith(".py"):
        _err("Only .py files are allowed to be locked.")
        raise ValueError("Only .py files are allowed")

    if password is None:
        try:
            password = getpass.getpass("Enter password to lock:")
        except Exception:
            raise RuntimeError("Password required but not provided (non-interactive).")

    if not os.path.isfile(filepath):
        _err("Input file not found.")
        raise FileNotFoundError(filepath)

    try:
        with open(filepath, "rb") as f:
            raw = f.read()
    except Exception as e:
        _err("Failed to read input file: " + str(e))
        raise

    file_hash = _sha256_bytes(raw)
    salt = os.urandom(16)
    key, iv = _derive_key_iv(password.encode("utf-8"), salt, iterations=int(pbkdf2_iter))

    try:
        ct = _openssl_encrypt(raw, key, iv)
    except Exception as e:
        _err("Encryption failed: " + str(e))
        _zero_bytes(bytearray(key))
        _zero_bytes(bytearray(iv))
        raise

    _zero_bytes(bytearray(key))
    _zero_bytes(bytearray(iv))

    payload = {
        "filename": os.path.basename(filepath),
        "timestamp": _ts(),
        "file_hash": file_hash,
        "salt": base64.b64encode(salt).decode("utf-8"),
        "ciphertext": base64.b64encode(ct).decode("utf-8"),
        "method": "aes-256-cbc",
        "pbkdf2_iter": int(pbkdf2_iter),
    }

    path = _sr_path(label)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

    _info(f"Locked {filepath} as '{label}' -> {path}")
    try:
        _zero_bytes(bytearray(ct))
    except Exception:
        pass
    try:
        del raw
    except Exception:
        pass
    gc.collect()
    return path

def _decrypt_payload(payload: dict, password: str) -> bytes:
    try:
        salt = base64.b64decode(payload["salt"])
        ct = base64.b64decode(payload["ciphertext"])
    except Exception:
        raise ValueError("Malformed sr file (missing salt/ciphertext).")

    iterations = int(payload.get("pbkdf2_iter", _PBKDF2_ITER))
    key, iv = _derive_key_iv(password.encode("utf-8"), salt, iterations)

    try:
        plain = _openssl_decrypt(ct, key, iv)
    except Exception as e:
        _zero_bytes(bytearray(key))
        _zero_bytes(bytearray(iv))
        raise RuntimeError("Decryption failed: " + str(e))

    _zero_bytes(bytearray(key))
    _zero_bytes(bytearray(iv))

    expected = payload.get("file_hash")
    if expected:
        got = _sha256_bytes(plain)
        if not hmac.compare_digest(got, expected):
            try:
                _zero_bytes(bytearray(plain))
            except Exception:
                pass
            raise ValueError("Integrity check failed: file hash mismatch (wrong password or corrupted).")
    return plain

def run(label: str, password: str = None, show_output: bool = True):
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if password is None:
        try:
            password = getpass.getpass("Enter password to run: ")
        except Exception:
            raise RuntimeError("Password required but not provided (non-interactive).")

    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception as e:
        _err("Failed to read locked file: " + str(e))
        raise

    try:
        plain = _decrypt_payload(payload, password)
    except Exception as e:
        _err("Decryption failed: " + str(e))
        raise

    filename = payload.get("filename") or f"{label}.py"
    if not filename.endswith(".py"):
        try:
            _zero_bytes(bytearray(plain))
        except Exception:
            pass
        raise ValueError("Stored filename is not a .py file; refusing to run.")

    header = f"{BOLD}{GREEN}Running ({label}) - {filename}...{RESET}"
    if show_output:
        print(header)
    start = time.time()

    try:
        src = plain.decode("utf-8", errors="replace") if isinstance(plain, (bytes, bytearray)) else str(plain)
        code_obj = compile(src, filename, "exec")
        g = {"__name__": "__main__", "__file__": filename}
        try:
            exec(code_obj, g, g)
        except SystemExit:
            _warn("Script called exit().")
        except Exception as e:
            _err(f"Runtime error in decrypted script: {e}")
            _err(traceback.format_exc())
            raise
    finally:
        elapsed = time.time() - start
        _info(f"Finished running {label} in {elapsed:.2f}s.")
        # wipe plaintext
        try:
            _zero_bytes(bytearray(plain))
            del src
            del code_obj
            gc.collect()
        except Exception:
            pass
    return True

def get(label: str, password: str = None) -> bytes:
    path = _sr_path(label)
    if not os.path.isfile(path):
        _err("Locked item not found.")
        raise FileNotFoundError(path)

    if password is None:
        try:
            password = getpass.getpass("Enter password to get file: ")
        except Exception:
            raise RuntimeError("Password required but not provided (non-interactive).")

    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception as e:
        _err("Failed to read locked file: " + str(e))
        raise

    plain = _decrypt_payload(payload, password)

    filename = payload.get("filename") or f"{label}.py"
    if not filename.endswith(".py"):
        try:
            _zero_bytes(bytearray(plain))
        except Exception:
            pass
        raise ValueError("Stored filename is not a .py file; refusing to write to disk.")

    out_path = os.path.join(BASE_DIR, filename)
    tmp = out_path + ".tmp"
    try:
        # atomic write
        with open(tmp, "wb") as tf:
            if isinstance(plain, (bytes, bytearray)):
                tf.write(plain)
            else:
                tf.write(str(plain).encode("utf-8"))
            tf.flush()
            os.fsync(tf.fileno())
        os.replace(tmp, out_path)
        _info(f"Wrote decrypted file to: {out_path}")
    except Exception as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _zero_bytes(bytearray(plain))
        _err("Failed to write decrypted file: " + str(e))
        raise
    finally:
        try:
            _zero_bytes(bytearray(plain))
            del plain
            gc.collect()
        except Exception:
            pass

    try:
        with open(out_path, "rb") as f:
            data = f.read()
            _runtime_cache[label] = data
    except Exception:
        pass
    return _runtime_cache.get(label)

def delete(label: str):
    path = _sr_path(label)
    if os.path.isfile(path):
        try:
            os.remove(path)
            _info(f"Deleted locked file: {path}")
        except Exception as e:
            _err("Failed to delete file: " + str(e))
            raise
    else:
        _warn("Item not found; nothing to delete.")
    _runtime_cache.pop(label, None)

def flush():
    for k, v in list(_runtime_cache.items()):
        try:
            _zero_bytes(bytearray(v))
        except Exception:
            pass
        _runtime_cache.pop(k, None)
    _info("Runtime cache flushed. All decrypted bytes removed from memory cache (best-effort).")
    gc.collect()

def reset(confirm: bool = False):
    if not confirm:
        _warn("Call reset(confirm=True) to actually wipe all locked data.")
        return
    if os.path.isdir(LOCKED_DIR):
        for fname in os.listdir(LOCKED_DIR):
            if fname.endswith(".sr"):
                try:
                    os.remove(os.path.join(LOCKED_DIR, fname))
                except Exception:
                    pass
    if os.path.isdir(BASE_DIR):
        for fname in os.listdir(BASE_DIR):
            if fname.endswith(".py"):
                try:
                    os.remove(os.path.join(BASE_DIR, fname))
                except Exception:
                    pass
    _runtime_cache.clear()
    _info("FULL reset: removed .sr files and written .py files (where possible) and cleared memory cache.")
    gc.collect()

def exit_sr(force: bool = False):
    _info(f"Exiting (force={force})")
    flush()
    if force:
        os._exit(1)
    else:
        sys.exit(0)

# -----------------------
# CLI wrapper
# -----------------------
def _cli():
    parser = argparse.ArgumentParser(prog="sr", description="Secure-run (sr)")
    sub = parser.add_subparsers(dest="cmd")

    p_lock = sub.add_parser("lock", help="Lock a .py file")
    p_lock.add_argument("label")
    p_lock.add_argument("file")
    p_lock.add_argument("--iter", type=int, default=_PBKDF2_ITER, help="PBKDF2 iterations (default 2_000_000)")

    p_run = sub.add_parser("run", help="Run a locked file")
    p_run.add_argument("label")

    p_get = sub.add_parser("get", help="Decrypt and write file to disk (BASE_DIR)")
    p_get.add_argument("label")

    p_delete = sub.add_parser("delete", help="Delete locked item")
    p_delete.add_argument("label")

    p_flush = sub.add_parser("flush", help="Flush runtime cache")

    p_reset = sub.add_parser("reset", help="Reset (delete .sr files and written .py files)")
    p_reset.add_argument("--confirm", action="store_true")

    p_exit = sub.add_parser("exit", help="Exit program")
    p_exit.add_argument("--force", action="store_true")

    args = parser.parse_args()

    try:
        setup()
        if args.cmd == "lock":
            lock(args.label, args.file, pbkdf2_iter=args.iter)
        elif args.cmd == "run":
            run(args.label)
        elif args.cmd == "get":
            data = get(args.label)
            if data:
                try:
                    sys.stdout.buffer.write(data)
                except Exception:
                    print(data.decode("utf-8", errors="replace"))
        elif args.cmd == "delete":
            delete(args.label)
        elif args.cmd == "flush":
            flush()
        elif args.cmd == "reset":
            reset(confirm=args.confirm)
        elif args.cmd == "exit":
            exit_sr(force=args.force)
        else:
            parser.print_help()
    except Exception as e:
        _err("Operation failed: " + str(e))
        if os.environ.get("SR_DEBUG"):
            traceback.print_exc()
        sys.exit(2)

def main():
    _ensure_dirs()
    if not _have_openssl():
        _err("OpenSSL CLI not found on PATH. Install 'openssl' before using sr.py.")
        sys.exit(1)
    _cli()