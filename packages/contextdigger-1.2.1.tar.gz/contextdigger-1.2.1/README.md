# ContextDigger ⛏️

> **Dig deep into your codebase. Unearth context. Navigate with precision.**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.2.0-green.svg)](https://github.com/ialameh/contextdigger/releases)

**Created by [Sam Alameh](https://github.com/ialameh)** | More tools at [FlowMason.com](https://www.flowmason.com)

---

## TL;DR - Quick Start

```bash
# One-line install (installs Python package + Claude Code skills)
curl -sSL https://raw.githubusercontent.com/ialameh/contextdigger/main/install.sh | bash

# In your project (using Claude Code)
/init-dig         # One-time setup: Discover your codebase structure
/dig backend-api  # Start digging into a specific area
/dig-dashboard    # View overview and suggestions
```

**Alternative - Manual Installation:**
```bash
# Step 1: Install Python package
pip3 install --user git+https://github.com/ialameh/contextdigger.git

# Step 2: Install Claude Code skills
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash
```

**What you get:**
- ⛏️ **Auto-discovery**: Excavates logical code areas from any codebase
- 🗺️ **Smart Navigation**: History, breadcrumbs, snapshots, bookmarks
- 📊 **Deep Analytics**: Test coverage, hotspots, performance profiling
- 🔍 **Advanced Search**: Query across all areas, notes, and context
- 📈 **Dashboard & Insights**: Real-time health checks and statistics
- 🤝 **Team-Ready**: Share knowledge, track activity, collaborate
- 🚀 **40+ Commands**: Complete toolkit for codebase exploration

---

## What is ContextDigger?

Large codebases are like archaeological sites - layers of code, hidden connections, buried context. **ContextDigger helps you excavate understanding** by:

1. **Auto-discovering** logical areas in your codebase
2. **Maintaining context** as you navigate between areas
3. **Tracking exploration** sessions and bookmarks
4. **Working across** any language or framework

### The Problem

🤯 **Context switching kills productivity**
- Lost 15-20 minutes every time you switch areas
- Forget where important code lives
- Can't remember what you were working on

### The Solution

⛏️ **ContextDigger organizes chaos**
- Auto-discovers code areas (frontend, backend, tests, etc.)
- Lets you `/dig` into specific areas with full context
- Marks important spots so you can `/goto-spot` instantly
- Tracks what you explored and when

---

## Key Features

### ⛏️ Auto-Discovery
Automatically excavates code areas from your project:
- Detects languages (Python, JS/TS, Salesforce, etc.)
- Identifies frameworks (Next.js, Astro, React, etc.)
- Groups related files into logical areas
- Generates smart area names and descriptions

### 🗺️ Context Navigation
Navigate with precision:
- `/dig <area>` - Dig into a specific code area
- `/redig` - Interactive area selector
- `/dig-status` - See where you're currently digging
- `/mark-spot` - Bookmark important code locations
- `/goto-spot` - Jump to marked locations

### 📊 Session Tracking
Never lose your place:
- Tracks files you viewed and modified
- Records exploration sessions
- Maintains history per code area
- Helps teams understand who's working where

### 🚀 Minimal Friction
Designed for flow:
- **Zero approval prompts** - Commands run instantly without interruption
- **One-line installation** - Everything in a single command
- Lightweight `.cdg/` directory in each project
- Fast discovery (1-5 seconds for most projects)
- Works offline once installed

---

## Complete Feature Set

**40+ commands across 9 major feature areas:**

### 🗺️ Navigation & Context
- **Browser-like History** - Back/forward/trail navigation through areas
- **Context Snapshots** - Save/restore/compare complete mental state
- **Smart Bookmarks** - Mark spots, jump instantly with context
- **AI Suggestions** - Get recommended areas based on your work

### 👥 Team Collaboration
- **Team Presence** - See who's working where in real-time
- **Knowledge Base** - Notes, documentation, shared insights
- **Activity Tracking** - Team member contributions and focus

### 🔍 Code Intelligence
- **Dependency Analysis** - Import mapping and relationship graphs
- **Impact Analysis** - See what's affected by changes
- **Hot Spots** - Find frequently changed or problematic areas
- **Test Coverage** - Convention-based coverage detection
- **Coverage Gaps** - Identify untested code areas

### ⚡ Performance & Quality
- **Performance Profiling** - Complexity metrics and slow code detection
- **Complexity Analysis** - LOC, imports, file counts
- **Quality Scoring** - Automated code quality assessment

### 🤖 Automation & Search
- **Automation Rules** - Context-aware workflow automation
- **Advanced Search** - Query across all areas, notes, bookmarks
- **Pattern Matching** - Find by regex and patterns
- **Relevance Scoring** - Weighted search results

### 📈 Analytics & Insights
- **Work Analytics** - Time tracking and productivity metrics
- **Productivity Scoring** - Multi-factor performance analysis
- **Time Distribution** - Session-based activity tracking
- **Trend Analysis** - Growth and usage patterns

### 💾 Data Management
- **Export System** - JSON, CSV, HTML formats
- **Backup & Restore** - Complete data preservation with safety
- **Health Checks** - Data integrity validation
- **Cleanup Tools** - Remove old unused data

### 📊 Dashboard & Reporting
- **Overview Dashboard** - Real-time metrics, alerts, suggestions
- **Statistics** - Detailed usage analytics with insights
- **Comprehensive Reports** - Full markdown documentation
- **Visual Analytics** - Tag distributions, activity graphs

---

## Installation

### ⚡ Quick Install (Recommended)

**One command installs everything:**

```bash
curl -sSL https://raw.githubusercontent.com/ialameh/contextdigger/main/install.sh | bash
```

This automatically:
- ✅ Checks Python 3.11+ requirement
- ✅ Installs Python package from GitHub
- ✅ Installs all 37 Claude Code skills
- ✅ Works for both fresh installs and upgrades

**For interactive area picker (recommended for 20+ areas):**

```bash
pip install 'contextdigger[interactive]'
```

This adds fuzzy search and keyboard navigation for large codebases.

### 🔄 Updating

**Use the same command to upgrade:**

```bash
curl -sSL https://raw.githubusercontent.com/ialameh/contextdigger/main/install.sh | bash
```

The installer detects existing installations and upgrades them automatically.

### 📋 Manual Installation (Alternative)

If you prefer step-by-step:

```bash
# Basic installation
pip3 install --user git+https://github.com/ialameh/contextdigger.git

# Full installation with interactive picker (recommended)
pip3 install --user 'git+https://github.com/ialameh/contextdigger.git#egg=contextdigger[interactive]'

# Install Claude Code skills
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash
```

### ✓ Verify Installation

```bash
# Check Python package
contextdigger --version
cdg --version  # short alias

# Check skills in Claude Code (should show 37 files)
ls ~/.claude/commands/*dig*.md | wc -l
```

---

## Quick Start Guide

### 1. Initialize in Your Project

```bash
cd /path/to/your/project
/init-dig
```

**What happens:**
- Scans your project structure
- Detects languages and frameworks
- Discovers logical code areas
- Creates `.cdg/` directory with area definitions

**Example output:**
```
⛏️  Digging through codebase...
   Found languages: python, typescript
   Discovered 4 code areas

✓ Discovered 4 code areas

1. backend-api
   Name: Backend API
   Type: python
   Files: 23

2. frontend-components
   Name: React Components
   Type: typescript
   Files: 45

...
```

### 2. Dig Into an Area

**Interactive Mode (v1.2.0+)** - Navigate with fuzzy search:

```bash
/dig
```

**What you see:**
```
? Select a code area to dig into (type to filter):
> backend-api (23 files) - REST API endpoint handlers
  frontend-components (45 files) - React UI components
  database-models (15 files) - SQLAlchemy ORM models
  authentication (8 files) - User login and session management
  ...

  [Type to filter | ↑↓ to navigate | Enter to select | Ctrl+C to cancel]
```

Just start typing to filter areas instantly. Perfect for codebases with 20+ areas.

**Direct Mode** - Jump straight to a known area:

```bash
/dig backend-api
```

**Shows:**
- Area information
- Files in this area
- Recent exploration history
- Suggested next steps

**Plain List** - Non-interactive list view:

```bash
/dig --list
```

### 3. Mark Important Spots

```bash
/mark-spot auth-handler
```

**Saves:**
- Current file and line number
- Surrounding context
- Your notes

### 4. Navigate Back

```bash
/goto-spot auth-handler
```

**Jumps to:**
- Exact file and line
- Restores context
- Continues your work

---

## Commands Reference

**40+ commands across 9 feature areas:**

### Discovery & Navigation (6 commands)
| Command | Description |
|---------|-------------|
| `/init-dig` | Initialize ContextDigger, discover code areas |
| `/dig` | Interactive fuzzy picker (v1.2.0+) |
| `/dig <area>` | Dig into a specific code area |
| `/dig --list` | Show plain list of all areas |
| `/redig` | Interactive area selector |
| `/dig-status` | Show current dig status |
| `/mark-spot [name]` | Mark current location as bookmark |
| `/goto-spot <name>` | Jump to marked bookmark |

### History & Breadcrumbs (4 commands)
| Command | Description |
|---------|-------------|
| `/dig-history` | View complete exploration history |
| `/dig-back` | Navigate backward in history |
| `/dig-forward` | Navigate forward in history |
| `/dig-trail` | Show breadcrumb trail of visited areas |

### Context Snapshots (4 commands)
| Command | Description |
|---------|-------------|
| `/dig-snapshot [name]` | Save current context state |
| `/dig-snapshots` | List all saved snapshots |
| `/dig-compare <snapshot>` | Compare current state with snapshot |
| `/dig-restore <snapshot>` | Restore saved context snapshot |

### Smart Suggestions (2 commands)
| Command | Description |
|---------|-------------|
| `/dig-suggest` | Get AI-powered area suggestions |
| `/dig-suggest-pattern` | Pattern-based area recommendations |

### Team Collaboration (4 commands)
| Command | Description |
|---------|-------------|
| `/dig-team` | View team activity and presence |
| `/dig-note [title]` | Create note in current area |
| `/dig-notes [area]` | View all notes for area |
| `/dig-knowledge [area]` | Browse knowledge base |

### Dependency Analysis (3 commands)
| Command | Description |
|---------|-------------|
| `/dig-deps [area]` | Show area dependencies |
| `/dig-impact <area>` | Analyze change impact |
| `/dig-graph` | Visualize dependency graph |

### Code Intelligence (5 commands)
| Command | Description |
|---------|-------------|
| `/dig-hotspots` | Find frequently changed code |
| `/dig-coverage [area]` | Show test coverage analysis |
| `/dig-gaps` | Find untested code areas |
| `/dig-perf [area]` | Performance profiling data |
| `/dig-slow` | Find slow/complex code |

### Automation & Search (4 commands)
| Command | Description |
|---------|-------------|
| `/dig-auto <rule>` | Create automation rule |
| `/dig-auto-list` | List all automation rules |
| `/dig-search <query>` | Search all context data |
| `/dig-find <pattern>` | Find by pattern matching |

### Analytics & Insights (2 commands)
| Command | Description |
|---------|-------------|
| `/dig-analytics` | View work analytics and productivity |
| `/dig-report [file]` | Generate comprehensive report |

### Export & Backup (2 commands)
| Command | Description |
|---------|-------------|
| `/dig-export <format>` | Export data (JSON/CSV/HTML) |
| `/dig-backup [action]` | Backup or restore all data |

### Dashboard & Utilities (3 commands)
| Command | Description |
|---------|-------------|
| `/dig-dashboard` | Overview dashboard with alerts |
| `/dig-health` | System health check |
| `/dig-stats` | Detailed statistics |

### CLI (Alternative)
```bash
contextdigger init           # Initialize discovery
contextdigger dig            # Interactive picker (v1.2.0+)
contextdigger dig <area>     # Dig into specific area
contextdigger dig --list     # Plain list of areas
contextdigger list           # List all areas
contextdigger status         # Show current status
cdg --help                   # Short alias
```

---

## Project Structure

After running `/init-dig`:

```
your-project/
└── .cdg/                      # ContextDigger data directory
    ├── config.json            # Project configuration
    ├── .gitignore             # Excludes user-specific data
    ├── areas/                 # Discovered code areas (commit these!)
    │   ├── backend-api.json
    │   ├── frontend-components.json
    │   └── ...
    ├── sessions/              # Exploration history (gitignored)
    │   └── <session-id>.json
    └── bookmarks/             # Marked locations (gitignored)
        └── bookmarks.json
```

**What to commit:**
- ✅ `.cdg/areas/` - Share discovered areas with team
- ❌ `.cdg/sessions/` - Personal exploration history
- ❌ `.cdg/bookmarks/` - Personal bookmarks

---

## Supported Languages & Frameworks

**Auto-detected:**
- Python (pytest, unittest)
- JavaScript/TypeScript (Jest, Vitest, Mocha)
- Salesforce (Apex, LWC)
- Next.js, Astro, React
- Markdown, Shell scripts

**Works with any language!** Auto-detection just provides better area names and metadata.

---

## Real-World Examples

### Example 1: Large Monorepo with Interactive Navigation

```bash
/init-dig
# Discovers: auth-service, payment-api, admin-dashboard, mobile-app, shared-utils
#           user-management, billing, notifications, analytics, ... (200+ areas)

/dig
# Opens interactive picker
# Type "pay" → filters to: payment-api, payment-gateway, payroll-processing
# Select payment-api with Enter

# Context: You're now focused on payment processing
# Shows: Related files, recent changes, dependencies

/mark-spot stripe-integration
# Bookmarks: payments/stripe/webhook_handler.py:45

# Days later...
/goto-spot stripe-integration
# Instantly: Back to payments/stripe/webhook_handler.py:45
```

### Example 2: Bug Investigation

```bash
/dig backend-api
# Focused on backend

/mark-spot bug-location
# Mark the buggy code

/dig frontend-components
# Check how frontend calls this

/goto-spot bug-location
# Back to fix the bug
```

### Example 3: Onboarding New Developer

```bash
# Team member runs:
/init-dig

# Gets same discovered areas as team:
# - authentication
# - user-management
# - billing
# - admin-panel

/dig authentication
# Starts exploring with proper context
```

---

## Advanced Usage

### Custom Area Creation

Create `.cdg/areas/custom-area.json`:

```json
{
  "id": "custom-area",
  "name": "My Custom Area",
  "description": "Special feature module",
  "type": "manual",
  "patterns": {
    "include": ["src/features/custom/**/*.ts"],
    "exclude": ["**/*.test.ts"]
  },
  "metadata": {
    "language": "typescript"
  }
}
```

### Sharing with Team

```bash
# Commit only area definitions
git add .cdg/areas/
git commit -m "Add code area definitions"
git push

# Team members pull and get same structure
git pull
/dig backend-api  # Works immediately!
```

### Exclude Patterns

Edit `.cdg/config.json`:

```json
{
  "settings": {
    "excludePatterns": [
      "**/__pycache__/**",
      "**/node_modules/**",
      "**/.cdg/**",
      "**/your-custom-ignore/**"
    ]
  }
}
```

---

## Troubleshooting

### "ContextDigger not initialized"

```bash
/init-dig
```

### "ModuleNotFoundError: No module named 'contextdigger'"

```bash
# Reinstall package
pip3 install --user --upgrade git+https://github.com/ialameh/contextdigger.git
```

### "/init-dig command not found"

```bash
# Install all skills (40+ commands)
mkdir -p ~/.claude/commands && cd ~/.claude/commands
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash

# Verify installation
ls ~/.claude/commands/*dig*.md | wc -l  # Should show 40+
```

### "Discovery finds 0 areas"

**Causes:**
- Very small project
- Non-standard structure
- Everything excluded by patterns

**Solutions:**
- Create manual area (see Advanced Usage)
- Adjust exclude patterns in `.cdg/config.json`

### "contextdigger: command not found"

```bash
# Add to ~/.bashrc or ~/.zshrc:
export PATH="$HOME/.local/bin:$PATH"

# Reload shell
source ~/.bashrc
```

### "Interactive picker not available"

```bash
# Install with interactive support
pip install 'contextdigger[interactive]'

# Or upgrade existing installation
pip install --upgrade 'contextdigger[interactive]'
```

**Fallback:** If you can't install `inquirer`, use direct mode:
```bash
/dig <area-name>    # Direct navigation
/dig --list         # Show plain list
```

---

## Frequently Asked Questions

**Q: Do I need to install in every project?**
A: No! Install globally once. Each project gets a `.cdg/` directory when you `/init-dig`.

**Q: Will this slow me down?**
A: No! Zero approval prompts. Commands run instantly. Discovery takes 1-5 seconds.

**Q: Can I use without Claude Code?**
A: Yes! Full CLI with all 37 commands: `contextdigger init`, `contextdigger dashboard`, `contextdigger dig <area>`, etc. Claude Code just provides a better UX.

**Q: Does this work with monorepos?**
A: Yes! ContextDigger excels at monorepos - auto-detects multiple projects/modules.

**Q: Is my code sent anywhere?**
A: No! Everything runs locally. Nothing is uploaded or transmitted.

**Q: How do I navigate 200+ areas?**
A: Use interactive mode! Run `/dig` without arguments to launch a fuzzy picker. Just type to filter and press Enter to select. Install with `pip install 'contextdigger[interactive]'` for best experience.

**Q: How do I update?**
```bash
pip3 install --user --upgrade 'git+https://github.com/ialameh/contextdigger.git#egg=contextdigger[interactive]'
```

---

## Why "ContextDigger"?

Because navigating large codebases is like archaeology:
- ⛏️ **Dig** through layers of code
- 🗺️ **Map** the territory
- 💎 **Discover** hidden connections
- 📚 **Maintain** context as you explore

Stop losing your place. **Start digging with purpose.**

---

## Contributing

Contributions welcome!

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

---

## Roadmap

**All Major Features Complete!** 🎉

### ✅ Phase 1: Foundation (v1.0.0)
- ✅ Auto-discovery algorithm
- ✅ Code area definitions
- ✅ Session tracking
- ✅ Bookmark navigation
- ✅ Claude Code skills

### ✅ Phase 2: Navigation & Context
- ✅ **Dig History & Breadcrumbs** - Browser-like back/forward navigation
- ✅ **Context Snapshots** - Save and restore complete mental state
- ✅ **Smart Suggestions** - AI-powered area recommendations

### ✅ Phase 3: Team Collaboration
- ✅ **Team Awareness** - See who's working where
- ✅ **Knowledge Capture** - Notes and institutional knowledge
- ✅ **Dependency Mapping** - Visual code relationship graphs

### ✅ Phase 4: Code Intelligence
- ✅ **Dependency Analysis** - Import tracking and impact analysis
- ✅ **Hot Spots Detection** - Find frequently changed code areas

### ✅ Phase 5: Testing & Performance
- ✅ **Test Coverage Analysis** - Convention-based coverage detection
- ✅ **Performance Profiling** - Complexity and performance tracking

### ✅ Phase 6: Automation & Search
- ✅ **Context-Aware Automation** - Rule-based workflows
- ✅ **Advanced Search** - Query across all context data

### ✅ Phase 7: Analytics & Insights
- ✅ **Work Analytics** - Time tracking and productivity metrics
- ✅ **Reporting** - Comprehensive data reports

### ✅ Phase 8: Export & Integration
- ✅ **Export System** - JSON, CSV, HTML formats
- ✅ **Backup & Restore** - Complete data preservation

### ✅ Phase 9: Dashboard & Utilities
- ✅ **Overview Dashboard** - Real-time metrics and alerts
- ✅ **Health Checks** - Data integrity validation
- ✅ **Statistics** - Detailed usage analytics

**Current Version: v1.2.0** - Interactive navigation + AI context governance!

**Latest Updates:**
- 🎯 v1.2.0 (2025-12-22): Interactive fuzzy picker for large codebases
- 🎯 v1.1.0 (2025-12-22): AI context governance (budgets, refusal mode, exports)
- ✅ v1.0.0 (2024-12-20): Complete feature set with 40+ commands

**Future Possibilities:**
- 🔀 PR Integration - Analyze pull request impact
- 🔄 Migration Assistant - Track refactoring progress
- 🌐 Web UI - Browser-based dashboard
- 🔌 IDE Plugins - VSCode, JetBrains integration

---

## License

MIT License - see LICENSE file for details

---

## Support

- **Website**: [contextdigger.com](https://contextdigger.com)
- **Documentation**: [GitHub README](https://github.com/ialameh/contextdigger#readme)
- **Issues**: [GitHub Issues](https://github.com/ialameh/contextdigger/issues)
- **Discussions**: [GitHub Discussions](https://github.com/ialameh/contextdigger/discussions)

---

## About the Author

**Sam Alameh** is a software engineer passionate about developer productivity and AI-powered tools.

**More projects and tools:** [FlowMason.com](https://www.flowmason.com)

If you find ContextDigger useful:
- ⭐ Star the [repository](https://github.com/ialameh/contextdigger)
- 🐛 [Report issues](https://github.com/ialameh/contextdigger/issues) or suggest features
- 🤝 [Contribute](https://github.com/ialameh/contextdigger/pulls) improvements
- 📢 Share with developers who dig deep into code

---

**ContextDigger** - *Because context switching is hard enough without losing your place.*

🌐 [contextdigger.com](https://contextdigger.com) | 🐙 [GitHub](https://github.com/ialameh/contextdigger) | 🛠️ [FlowMason.com](https://www.flowmason.com)
