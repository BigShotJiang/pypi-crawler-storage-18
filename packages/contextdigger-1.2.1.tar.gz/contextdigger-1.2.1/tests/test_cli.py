"""
Tests for CLI module, including interactive picker functionality.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from contextdigger.cli import _interactive_area_picker, cmd_dig, get_manager
from contextdigger.manager import FocusManager, FocusArea
from pathlib import Path
import tempfile
import sys
from io import StringIO


@pytest.fixture
def temp_project():
    """Create a temporary project directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)

        # Create .cdg directory
        cdg_dir = project_root / ".cdg"
        cdg_dir.mkdir()
        (cdg_dir / "areas").mkdir()
        (cdg_dir / "sessions").mkdir()
        (cdg_dir / "bookmarks").mkdir()

        # Create config.json
        config = {
            "version": "1.0",
            "projectRoot": str(project_root),
            "settings": {
                "excludePatterns": ["**/__pycache__/**", "**/node_modules/**"]
            }
        }
        import json
        with open(cdg_dir / "config.json", "w") as f:
            json.dump(config, f)

        yield project_root


@pytest.fixture
def sample_areas():
    """Create sample focus areas for testing."""
    return [
        FocusArea(
            id="backend-api",
            name="Backend API",
            description="REST API endpoint handlers",
            type="auto-detected",
            patterns={"include": ["api/**/*.py"], "exclude": ["**/__pycache__/**"]},
            metadata={"language": "python"}
        ),
        FocusArea(
            id="frontend-components",
            name="Frontend Components",
            description="React UI components for the application",
            type="auto-detected",
            patterns={"include": ["src/components/**/*.tsx"], "exclude": []},
            metadata={"language": "typescript"}
        ),
        FocusArea(
            id="database-models",
            name="Database Models",
            description="SQLAlchemy ORM models",
            type="auto-detected",
            patterns={"include": ["models/**/*.py"], "exclude": []},
            metadata={"language": "python"}
        ),
    ]


class TestInteractivePicker:
    """Tests for interactive area picker functionality."""

    def test_picker_not_available_without_inquirer(self, temp_project, sample_areas):
        """Test that picker shows helpful message when inquirer is not installed."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas

        # Mock inquirer import to fail
        with patch.dict('sys.modules', {'inquirer': None}):
            with patch('builtins.__import__', side_effect=ImportError("No module named 'inquirer'")):
                with patch('builtins.print') as mock_print:
                    result = _interactive_area_picker(mock_manager)

                    assert result is None
                    # Check that helpful error message was printed
                    assert any("Interactive picker not available" in str(call) for call in mock_print.call_args_list)
                    assert any("pip install" in str(call) for call in mock_print.call_args_list)

    def test_picker_not_in_tty(self, temp_project, sample_areas):
        """Test that picker detects non-TTY environment."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas

        with patch('sys.stdin.isatty', return_value=False):
            with patch('builtins.print') as mock_print:
                result = _interactive_area_picker(mock_manager)

                assert result is None
                assert any("Not in interactive mode" in str(call) for call in mock_print.call_args_list)

    def test_picker_no_areas(self, temp_project):
        """Test picker behavior when no areas exist."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = []

        with patch('sys.stdin.isatty', return_value=True):
            with patch('builtins.print') as mock_print:
                result = _interactive_area_picker(mock_manager)

                assert result is None
                assert any("No areas found" in str(call) for call in mock_print.call_args_list)

    def test_picker_few_areas(self, temp_project, sample_areas):
        """Test that picker skips interactive mode for 1-3 areas."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas[:2]  # Only 2 areas

        with patch('sys.stdin.isatty', return_value=True):
            with patch('contextdigger.cli.cmd_list') as mock_list:
                with patch('builtins.print') as mock_print:
                    result = _interactive_area_picker(mock_manager)

                    assert result is None
                    mock_list.assert_called_once()
                    assert any("Only a few areas" in str(call) for call in mock_print.call_args_list)

    def test_picker_creates_correct_labels(self, temp_project, sample_areas):
        """Test that picker creates labels without accessing non-existent 'files' attribute."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas

        # Mock inquirer to be available
        mock_inquirer = MagicMock()
        mock_inquirer.prompt.return_value = {'area': sample_areas[0]}

        with patch('sys.stdin.isatty', return_value=True):
            with patch.dict('sys.modules', {'inquirer': mock_inquirer}):
                with patch('builtins.print'):
                    result = _interactive_area_picker(mock_manager)

                    # Should not raise AttributeError about 'files'
                    assert result is not None
                    assert result.id == "backend-api"

                    # Verify that List was called with properly formatted choices
                    call_args = mock_inquirer.List.call_args
                    assert call_args is not None

                    # Check that choices were created
                    choices = call_args[1]['choices']
                    assert len(choices) == 3

                    # Verify label format (should have name and description, but NO file count)
                    first_label = choices[0][0]
                    assert "Backend API" in first_label
                    assert "REST API" in first_label
                    assert "files" not in first_label  # Should NOT have file count

    def test_picker_handles_cancellation(self, temp_project, sample_areas):
        """Test that picker handles user cancellation gracefully."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas

        # Mock inquirer to simulate Ctrl+C
        mock_inquirer = MagicMock()
        mock_inquirer.prompt.return_value = None  # User cancelled

        with patch('sys.stdin.isatty', return_value=True):
            with patch.dict('sys.modules', {'inquirer': mock_inquirer}):
                with patch('builtins.print') as mock_print:
                    result = _interactive_area_picker(mock_manager)

                    assert result is None
                    assert any("Cancelled" in str(call) for call in mock_print.call_args_list)

    def test_picker_handles_keyboard_interrupt(self, temp_project, sample_areas):
        """Test that picker handles KeyboardInterrupt gracefully."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas

        # Mock inquirer to raise KeyboardInterrupt
        mock_inquirer = MagicMock()
        mock_inquirer.prompt.side_effect = KeyboardInterrupt()

        with patch('sys.stdin.isatty', return_value=True):
            with patch.dict('sys.modules', {'inquirer': mock_inquirer}):
                with patch('builtins.print') as mock_print:
                    result = _interactive_area_picker(mock_manager)

                    assert result is None
                    assert any("Cancelled" in str(call) for call in mock_print.call_args_list)

    def test_picker_truncates_long_descriptions(self, temp_project):
        """Test that picker truncates very long descriptions."""
        long_desc_area = FocusArea(
            id="test-area",
            name="Test Area",
            description="A" * 100,  # Very long description
            type="auto-detected",
            patterns={"include": ["test/**/*.py"], "exclude": []},
            metadata={}
        )

        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = [long_desc_area] * 5  # 5 areas to trigger picker

        mock_inquirer = MagicMock()
        mock_inquirer.prompt.return_value = {'area': long_desc_area}

        with patch('sys.stdin.isatty', return_value=True):
            with patch.dict('sys.modules', {'inquirer': mock_inquirer}):
                with patch('builtins.print'):
                    result = _interactive_area_picker(mock_manager)

                    # Verify that List was called
                    call_args = mock_inquirer.List.call_args
                    choices = call_args[1]['choices']

                    # Check that description is truncated
                    first_label = choices[0][0]
                    assert len(first_label) < 100  # Should be truncated
                    assert "..." in first_label  # Should have ellipsis


class TestCmdDig:
    """Tests for the dig command."""

    def test_dig_without_args_calls_picker(self, temp_project, sample_areas):
        """Test that dig without arguments calls interactive picker."""
        mock_manager = Mock(spec=FocusManager)
        mock_manager.list_areas.return_value = sample_areas
        mock_manager.get_current_area.return_value = None

        with patch('contextdigger.cli.get_manager', return_value=mock_manager):
            with patch('contextdigger.cli._interactive_area_picker', return_value=None) as mock_picker:
                cmd_dig()

                # Verify picker was called
                mock_picker.assert_called_once_with(mock_manager)

    def test_dig_with_area_name_skips_picker(self, temp_project):
        """Test that dig with area name doesn't call picker."""
        mock_manager = Mock(spec=FocusManager)

        with patch('contextdigger.cli.get_manager', return_value=mock_manager):
            with patch('contextdigger.cli._interactive_area_picker') as mock_picker:
                with patch('builtins.print'):
                    try:
                        cmd_dig("backend-api")
                    except:
                        pass  # May fail due to mock, but that's okay

                # Verify picker was NOT called
                mock_picker.assert_not_called()

    def test_dig_with_list_flag(self, temp_project):
        """Test that dig --list calls cmd_list."""
        with patch('contextdigger.cli.get_manager'):
            with patch('contextdigger.cli.cmd_list') as mock_list:
                cmd_dig("--list")

                # Verify cmd_list was called
                mock_list.assert_called_once()


class TestFocusAreaAttributes:
    """Tests to ensure FocusArea has correct attributes."""

    def test_focus_area_no_files_attribute(self):
        """Verify that FocusArea does NOT have a 'files' attribute."""
        area = FocusArea(
            id="test",
            name="Test",
            description="Test area",
            type="manual",
            patterns={"include": [], "exclude": []}
        )

        # Should NOT have 'files' attribute
        assert not hasattr(area, 'files')

    def test_focus_area_has_expected_attributes(self):
        """Verify that FocusArea has all expected attributes."""
        area = FocusArea(
            id="test",
            name="Test",
            description="Test area",
            type="manual",
            patterns={"include": [], "exclude": []}
        )

        # Should have these attributes
        assert hasattr(area, 'id')
        assert hasattr(area, 'name')
        assert hasattr(area, 'description')
        assert hasattr(area, 'type')
        assert hasattr(area, 'patterns')
        assert hasattr(area, 'metadata')
        assert hasattr(area, 'dependencies')
        assert hasattr(area, 'quickAccess')
        assert hasattr(area, 'created')
        assert hasattr(area, 'lastFocused')
        assert hasattr(area, 'focusCount')


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
