"""CLI for exploring simulation APIs.

Usage:
    plato sims list
    plato sims info <sim_name>
    plato sims endpoints <sim_name> [--spec SPEC_NAME] [--tag TAG]
    plato sims spec <sim_name> [--spec SPEC_NAME]
"""

import json
import sys

from .registry import registry


def format_table(rows: list[list[str]], headers: list[str]) -> str:
    """Format data as a simple text table."""
    if not rows:
        return ""

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # Build table
    lines = []

    # Header
    header_line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    lines.append(header_line)
    lines.append("-" * len(header_line))

    # Rows
    for row in rows:
        line = "  ".join(str(cell).ljust(w) for cell, w in zip(row, widths))
        lines.append(line)

    return "\n".join(lines)


def cmd_list() -> None:
    """List all available sims."""
    sims = registry.list_sims()

    if not sims:
        print("No sims found.")
        return

    print("Available simulation APIs:\n")
    for sim in sims:
        info = registry.get_sim_info(sim)
        print(f"  {sim}")
        print(f"    {info.title} (v{info.version})")
        print(f"    Auth: {info.auth.type}")
        if len(info.specs) > 1:
            print(f"    APIs: {', '.join(info.specs)}")
        print()


def cmd_info(sim_name: str) -> None:
    """Show detailed information about a sim."""
    try:
        info = registry.get_sim_info(sim_name)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"{info.title} (v{info.version})")
    print("=" * 60)

    if info.description:
        print(f"\n{info.description}\n")

    print(f"Name: {info.name}")
    print(f"Auth Type: {info.auth.type}")

    if len(info.specs) > 1:
        print(f"APIs: {', '.join(info.specs)}")

    if info.tags:
        print(f"Tags: {', '.join(info.tags)}")

    print("\nRequired Environment Variables:")
    for var, desc in info.auth.env_vars.items():
        has_default = any(v for v in info.auth.default_values.values() if v)
        default_marker = " (has default for artifacts)" if has_default else ""
        print(f"  {var}: {desc}{default_marker}")

    print("\nUsage:")
    if len(info.specs) == 1 and info.specs[0] == "default":
        print(f"  from plato.sims import {info.name}")
        print(f"  client = await {info.name}.AsyncClient.create(base_url='...')")
    else:
        print(f"  from plato.sims.{info.name} import {', '.join(info.specs)}")
        print(f"  client = await {info.specs[0]}.AsyncClient.create(base_url='...')")

    print("\nExplore API:")
    print(f"  plato sims endpoints {info.name}")


def cmd_endpoints(sim_name: str, spec_name: str | None = None, tag_filter: str | None = None) -> None:
    """List all endpoints in a sim's API."""
    try:
        endpoints = registry.get_endpoints_summary(sim_name, spec_name)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    # Filter by tag if specified
    if tag_filter:
        endpoints = [e for e in endpoints if tag_filter in e["tags"]]

    if not endpoints:
        print("No endpoints found.")
        return

    # Group by tag
    by_tag: dict[str, list[dict]] = {}
    for endpoint in endpoints:
        tags = endpoint["tags"] or ["untagged"]
        for tag in tags:
            by_tag.setdefault(tag, []).append(endpoint)

    info = registry.get_sim_info(sim_name)
    spec_str = f" - {spec_name}" if spec_name else ""
    print(f"{info.title}{spec_str}")
    print("=" * 60)
    print(f"Total endpoints: {len(endpoints)}\n")

    for tag in sorted(by_tag.keys()):
        tag_endpoints = by_tag[tag]
        print(f"\n{tag.upper()} ({len(tag_endpoints)} endpoints)")
        print("-" * 60)

        for endpoint in tag_endpoints:
            method = endpoint["method"].ljust(6)
            path = endpoint["path"]
            summary = endpoint["summary"] or endpoint["description"] or ""
            if len(summary) > 60:
                summary = summary[:57] + "..."
            print(f"  {method} {path}")
            if summary:
                print(f"         {summary}")


def cmd_spec(sim_name: str, spec_name: str | None = None) -> None:
    """Output the full OpenAPI spec as JSON."""
    try:
        spec = registry.get_spec(sim_name, spec_name)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(spec, indent=2))


def main(args: list[str] | None = None) -> None:
    """Main CLI entry point."""
    if args is None:
        args = sys.argv[1:]

    if not args or args[0] in ["-h", "--help", "help"]:
        print(__doc__)
        return

    command = args[0]

    if command == "list":
        cmd_list()

    elif command == "info":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print("Usage: plato sims info <sim_name>", file=sys.stderr)
            sys.exit(1)
        cmd_info(args[1])

    elif command == "endpoints":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print("Usage: plato sims endpoints <sim_name> [--spec SPEC] [--tag TAG]", file=sys.stderr)
            sys.exit(1)

        sim_name = args[1]
        spec_name = None
        tag_filter = None

        # Parse optional flags
        i = 2
        while i < len(args):
            if args[i] == "--spec" and i + 1 < len(args):
                spec_name = args[i + 1]
                i += 2
            elif args[i] == "--tag" and i + 1 < len(args):
                tag_filter = args[i + 1]
                i += 2
            else:
                i += 1

        cmd_endpoints(sim_name, spec_name, tag_filter)

    elif command == "spec":
        if len(args) < 2:
            print("Error: sim name required", file=sys.stderr)
            print("Usage: plato sims spec <sim_name> [--spec SPEC]", file=sys.stderr)
            sys.exit(1)

        sim_name = args[1]
        spec_name = None

        if len(args) > 2 and args[2] == "--spec" and len(args) > 3:
            spec_name = args[3]

        cmd_spec(sim_name, spec_name)

    else:
        print(f"Error: Unknown command '{command}'", file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
