"""Update KnowledgeBaseArticle"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import KnowledgeBaseArticle


def _build_request_args(
    body: KnowledgeBaseArticle,
    x_version_number: str | None = None,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/KnowledgeBaseArticle/{id}"

    headers: dict[str, str] = {}
    if x_version_number is not None:
        headers["X-Version-Number"] = x_version_number

    return {
        "method": "PATCH",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True) if hasattr(body, "model_dump") else body,
        "headers": headers,
    }


def sync(
    client: httpx.Client,
    body: KnowledgeBaseArticle,
    x_version_number: str | None = None,
) -> KnowledgeBaseArticle:
    """Update an existing 'KnowledgeBaseArticle' record."""

    request_args = _build_request_args(
        body=body,
        x_version_number=x_version_number,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return KnowledgeBaseArticle.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: KnowledgeBaseArticle,
    x_version_number: str | None = None,
) -> KnowledgeBaseArticle:
    """Update an existing 'KnowledgeBaseArticle' record."""

    request_args = _build_request_args(
        body=body,
        x_version_number=x_version_number,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return KnowledgeBaseArticle.model_validate(response.json())
