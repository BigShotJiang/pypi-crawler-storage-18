"""Read Contact"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import Contact


def _build_request_args() -> dict[str, Any]:
    """Build request arguments."""
    url = "/Contact/{id}"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
) -> Contact:
    """Read an existing 'Contact' record."""

    request_args = _build_request_args()

    response = client.request(**request_args)
    raise_for_status(response)
    return Contact.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
) -> Contact:
    """Read an existing 'Contact' record."""

    request_args = _build_request_args()

    response = await client.request(**request_args)
    raise_for_status(response)
    return Contact.model_validate(response.json())
