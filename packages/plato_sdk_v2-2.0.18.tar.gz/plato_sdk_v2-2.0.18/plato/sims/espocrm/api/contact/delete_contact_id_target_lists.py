"""Unrelate Contact . targetLists"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status


def _build_request_args() -> dict[str, Any]:
    """Build request arguments."""
    url = "/Contact/{id}/targetLists"

    return {
        "method": "DELETE",
        "url": url,
    }


def sync(
    client: httpx.Client,
) -> Any:
    """Unrelate 'TargetList' record related though the 'targetLists' link."""

    request_args = _build_request_args()

    response = client.request(**request_args)
    raise_for_status(response)
    return response.json()


async def asyncio(
    client: httpx.AsyncClient,
) -> Any:
    """Unrelate 'TargetList' record related though the 'targetLists' link."""

    request_args = _build_request_args()

    response = await client.request(**request_args)
    raise_for_status(response)
    return response.json()
