"""Update Campaign"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import Campaign


def _build_request_args(
    body: Campaign,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/Campaign/{id}"

    return {
        "method": "PATCH",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True) if hasattr(body, "model_dump") else body,
    }


def sync(
    client: httpx.Client,
    body: Campaign,
) -> Campaign:
    """Update an existing 'Campaign' record."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return Campaign.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: Campaign,
) -> Campaign:
    """Update an existing 'Campaign' record."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return Campaign.model_validate(response.json())
