"""Update Call"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import Call


def _build_request_args(
    body: Call,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/Call/{id}"

    return {
        "method": "PATCH",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True) if hasattr(body, "model_dump") else body,
    }


def sync(
    client: httpx.Client,
    body: Call,
) -> Call:
    """Update an existing 'Call' record."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return Call.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: Call,
) -> Call:
    """Update an existing 'Call' record."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return Call.model_validate(response.json())
