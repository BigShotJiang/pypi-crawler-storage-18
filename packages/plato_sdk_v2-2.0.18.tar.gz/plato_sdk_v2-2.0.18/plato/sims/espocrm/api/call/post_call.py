"""Create Call"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import Call, CallCreate


def _build_request_args(
    body: CallCreate,
    x_skip_duplicate_check: str | None = None,
    x_duplicate_source_id: str | None = None,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/Call"

    headers: dict[str, str] = {}
    if x_skip_duplicate_check is not None:
        headers["X-Skip-Duplicate-Check"] = x_skip_duplicate_check
    if x_duplicate_source_id is not None:
        headers["X-Duplicate-Source-Id"] = x_duplicate_source_id

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True) if hasattr(body, "model_dump") else body,
        "headers": headers,
    }


def sync(
    client: httpx.Client,
    body: CallCreate,
    x_skip_duplicate_check: str | None = None,
    x_duplicate_source_id: str | None = None,
) -> Call:
    """Create a new 'Call' record."""

    request_args = _build_request_args(
        body=body,
        x_skip_duplicate_check=x_skip_duplicate_check,
        x_duplicate_source_id=x_duplicate_source_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return Call.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: CallCreate,
    x_skip_duplicate_check: str | None = None,
    x_duplicate_source_id: str | None = None,
) -> Call:
    """Create a new 'Call' record."""

    request_args = _build_request_args(
        body=body,
        x_skip_duplicate_check=x_skip_duplicate_check,
        x_duplicate_source_id=x_duplicate_source_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return Call.model_validate(response.json())
