"""List Account . emailsPrimary"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status
from ...models import WhereItem


def _build_request_args(
    offset: int | None = None,
    max_size: int | None = None,
    order_by: str | None = None,
    order: str | None = None,
    text_filter: str | None = None,
    attribute_select: list[str] | None = None,
    where_group: list[WhereItem] | None = None,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/Account/{id}/emailsPrimary"

    params: dict[str, Any] = {}
    if offset is not None:
        params["offset"] = offset
    if max_size is not None:
        params["maxSize"] = max_size
    if order_by is not None:
        params["orderBy"] = order_by
    if order is not None:
        params["order"] = order
    if text_filter is not None:
        params["textFilter"] = text_filter
    if attribute_select is not None:
        params["attributeSelect"] = attribute_select
    if where_group is not None:
        params["whereGroup"] = where_group

    return {
        "method": "GET",
        "url": url,
        "params": params,
    }


def sync(
    client: httpx.Client,
    offset: int | None = None,
    max_size: int | None = None,
    order_by: str | None = None,
    order: str | None = None,
    text_filter: str | None = None,
    attribute_select: list[str] | None = None,
    where_group: list[WhereItem] | None = None,
) -> dict[str, Any]:
    """List 'Email' records related through the 'emailsPrimary' link."""

    request_args = _build_request_args(
        offset=offset,
        max_size=max_size,
        order_by=order_by,
        order=order,
        text_filter=text_filter,
        attribute_select=attribute_select,
        where_group=where_group,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return response.json()


async def asyncio(
    client: httpx.AsyncClient,
    offset: int | None = None,
    max_size: int | None = None,
    order_by: str | None = None,
    order: str | None = None,
    text_filter: str | None = None,
    attribute_select: list[str] | None = None,
    where_group: list[WhereItem] | None = None,
) -> dict[str, Any]:
    """List 'Email' records related through the 'emailsPrimary' link."""

    request_args = _build_request_args(
        offset=offset,
        max_size=max_size,
        order_by=order_by,
        order=order,
        text_filter=text_filter,
        attribute_select=attribute_select,
        where_group=where_group,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return response.json()
