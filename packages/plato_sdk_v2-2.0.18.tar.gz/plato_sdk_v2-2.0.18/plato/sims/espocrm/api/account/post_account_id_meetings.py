"""Relate Account . meetings"""

from __future__ import annotations

from typing import Any

import httpx

from ...errors import raise_for_status


def _build_request_args() -> dict[str, Any]:
    """Build request arguments."""
    url = "/Account/{id}/meetings"

    return {
        "method": "POST",
        "url": url,
    }


def sync(
    client: httpx.Client,
) -> Any:
    """Relate 'Meeting' record though the 'meetings' link."""

    request_args = _build_request_args()

    response = client.request(**request_args)
    raise_for_status(response)
    return response.json()


async def asyncio(
    client: httpx.AsyncClient,
) -> Any:
    """Relate 'Meeting' record though the 'meetings' link."""

    request_args = _build_request_args()

    response = await client.request(**request_args)
    raise_for_status(response)
    return response.json()
