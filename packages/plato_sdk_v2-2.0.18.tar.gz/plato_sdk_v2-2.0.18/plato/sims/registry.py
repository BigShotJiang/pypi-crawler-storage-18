"""Sims registry for discovering and documenting available simulation APIs.

This module provides a clean interface for code agents and CLI tools to:
- Discover available sims
- Get auth requirements
- Access API documentation from OpenAPI specs
- Create authenticated clients
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

SIMS_DIR = Path(__file__).parent
SPECS_DIR = SIMS_DIR / "specs"


@dataclass
class AuthRequirement:
    """Authentication requirements for a sim."""

    type: str  # oauth, bearer_token, basic, session
    env_prefix: str
    env_vars: dict[str, str]  # env_var_name -> description
    default_values: dict[str, Any]  # Available default values (for artifacts)


@dataclass
class SimInfo:
    """Information about a simulation API."""

    name: str
    title: str
    version: str
    description: str | None
    auth: AuthRequirement
    specs: list[str]  # List of spec names (e.g., ["platform", "storefront"] or ["default"])
    tags: list[str]  # API tags from OpenAPI spec


class SimsRegistry:
    """Registry for discovering and documenting simulation APIs."""

    def __init__(self, specs_dir: Path | None = None):
        self.specs_dir = specs_dir or SPECS_DIR

    def list_sims(self) -> list[str]:
        """List all available sims."""
        sims = []
        for d in self.specs_dir.iterdir():
            if d.is_dir() and (d / "auth.yaml").exists():
                sims.append(d.name)
        return sorted(sims)

    def get_sim_info(self, name: str) -> SimInfo:
        """Get detailed information about a sim."""
        sim_dir = self.specs_dir / name
        auth_path = sim_dir / "auth.yaml"

        if not auth_path.exists():
            raise ValueError(f"Sim '{name}' not found or missing auth.yaml")

        # Load auth config
        with open(auth_path) as f:
            auth_data = yaml.safe_load(f)

        # Parse auth requirements
        auth_type = auth_data["type"]
        env_prefix = auth_data["env_prefix"]
        env_vars = {f"{env_prefix}_BASE_URL": "Base URL for the API"}
        default_values = {}

        if auth_type == "oauth":
            oauth = auth_data.get("oauth", {})
            env_vars[f"{env_prefix}_CLIENT_ID"] = "OAuth client ID"
            env_vars[f"{env_prefix}_CLIENT_SECRET"] = "OAuth client secret"
            default_values["client_id"] = oauth.get("default_client_id")
            default_values["client_secret"] = oauth.get("default_client_secret")
            default_values["token_endpoint"] = oauth.get("token_endpoint")
            default_values["scope"] = oauth.get("scope", "")

        elif auth_type == "bearer_token":
            bt = auth_data.get("bearer_token", {})
            env_vars[f"{env_prefix}_TOKEN"] = "Bearer token / Personal Access Token"
            default_values["token"] = bt.get("default_token")
            default_values["header"] = bt.get("header", "Authorization")
            default_values["prefix"] = bt.get("prefix", "Bearer")

        elif auth_type == "basic":
            basic = auth_data.get("basic", {})
            env_vars[f"{env_prefix}_USERNAME"] = "Username for basic auth"
            env_vars[f"{env_prefix}_PASSWORD"] = "Password for basic auth"
            default_values["username"] = basic.get("default_username")
            default_values["password"] = basic.get("default_password")

        elif auth_type == "session":
            session = auth_data.get("session", {})
            env_vars[f"{env_prefix}_USERNAME"] = "Username for session login"
            env_vars[f"{env_prefix}_PASSWORD"] = "Password for session login"
            default_values["username"] = session.get("default_username")
            default_values["password"] = session.get("default_password")
            default_values["login_endpoint"] = session.get("login_endpoint")

        auth = AuthRequirement(
            type=auth_type,
            env_prefix=env_prefix,
            env_vars=env_vars,
            default_values=default_values,
        )

        # Find spec files
        spec_files = []
        for ext in (".yaml", ".yml", ".json"):
            for f in sim_dir.glob(f"*{ext}"):
                if f.name != "auth.yaml":
                    spec_files.append(f)

        # Load first spec to get title, version, description
        if not spec_files:
            raise ValueError(f"No OpenAPI spec files found for sim '{name}'")

        first_spec = self._load_spec(spec_files[0])
        info = first_spec.get("info", {})

        # Get tags from all specs
        all_tags = set()
        for spec_file in spec_files:
            spec = self._load_spec(spec_file)
            tags = spec.get("tags", [])
            for tag in tags:
                if isinstance(tag, dict):
                    all_tags.add(tag.get("name", ""))
                else:
                    all_tags.add(str(tag))

        spec_names = [f.stem for f in spec_files]

        return SimInfo(
            name=name,
            title=info.get("title", name.title()),
            version=info.get("version", "unknown"),
            description=info.get("description"),
            auth=auth,
            specs=spec_names,
            tags=sorted(all_tags),
        )

    def get_spec(self, name: str, spec_name: str | None = None) -> dict:
        """Get the OpenAPI spec for a sim.

        Args:
            name: Sim name
            spec_name: Specific spec name (e.g., "platform", "storefront"), or None for default

        Returns:
            OpenAPI spec as dict
        """
        sim_dir = self.specs_dir / name

        if spec_name:
            # Look for specific spec
            for ext in (".yaml", ".yml", ".json"):
                spec_path = sim_dir / f"{spec_name}{ext}"
                if spec_path.exists():
                    return self._load_spec(spec_path)
            raise ValueError(f"Spec '{spec_name}' not found for sim '{name}'")

        # Look for default spec
        for ext in (".yaml", ".yml", ".json"):
            spec_path = sim_dir / f"default{ext}"
            if spec_path.exists():
                return self._load_spec(spec_path)

        # If no default, return first available spec
        for ext in (".yaml", ".yml", ".json"):
            for spec_path in sim_dir.glob(f"*{ext}"):
                if spec_path.name != "auth.yaml":
                    return self._load_spec(spec_path)

        raise ValueError(f"No OpenAPI spec found for sim '{name}'")

    def get_endpoints_summary(self, name: str, spec_name: str | None = None) -> list[dict]:
        """Get a summary of all endpoints in a sim's API.

        Returns:
            List of endpoint summaries with method, path, summary, tags
        """
        spec = self.get_spec(name, spec_name)
        endpoints = []

        for path, methods in spec.get("paths", {}).items():
            for method, details in methods.items():
                if method.lower() in ["get", "post", "put", "patch", "delete"]:
                    endpoints.append(
                        {
                            "method": method.upper(),
                            "path": path,
                            "summary": details.get("summary", ""),
                            "description": details.get("description", ""),
                            "tags": details.get("tags", []),
                            "operationId": details.get("operationId", ""),
                        }
                    )

        return endpoints

    def _load_spec(self, spec_path: Path) -> dict:
        """Load an OpenAPI spec file."""
        with open(spec_path) as f:
            if spec_path.suffix == ".json":
                return json.load(f)
            return yaml.safe_load(f)


# Global registry instance
registry = SimsRegistry()
