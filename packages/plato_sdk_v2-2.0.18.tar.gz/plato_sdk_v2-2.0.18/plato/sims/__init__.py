"""Plato simulation clients generated from OpenAPI specs.

This module provides auto-generated API clients for simulation environments.

## Usage

```python
from plato.sims import spree, firefly, espocrm, mattermost

# Spree has multiple APIs (platform, storefront)
client = await spree.platform.AsyncClient.create(base_url="https://...")
products = await client.httpx.get("/api/v2/platform/products")

# Firefly (Bearer token auto-auth)
client = await firefly.AsyncClient.create(base_url="https://...")

# EspoCRM (Basic auth auto-auth)
client = espocrm.Client.create(base_url="https://...")

# Or from environment variables
import os
os.environ["SPREE_BASE_URL"] = "https://..."
client = spree.platform.Client.from_env()
```

## Regenerating Clients

To regenerate clients from OpenAPI specs:
```bash
uv run python -m plato.sims.generate_clients
```
"""


def __getattr__(name: str):
    """Lazy import sim modules."""
    import importlib

    # Allow any submodule to be imported lazily
    try:
        return importlib.import_module(f".{name}", __name__)
    except ImportError:
        raise AttributeError(f"module 'plato.sims' has no attribute '{name}'")
