"""HED validation integration."""
