# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.0a6] - 2025-12-25

### Added
- **Policy-based gating system** with configurable fail_on/warn_on rules based on severity + confidence
- **Confidence levels** for findings ("high", "medium", "low") to indicate certainty
- **Labels system** for tracking false positives and acceptable risks (.vibegate/labels.yaml)
- **Enhanced first-run UX** with friendly error messages and guided configuration
- **Interactive init command** with --yes flag for automated setup
- **vibegate label** CLI command for managing false positive feedback
- Automated semantic versioning via python-semantic-release
- Pre-commit hooks with ruff, pyright, gitleaks, and conventional commits validation
- Commitlint GitHub Action for PR commit validation
- Config profiles with deterministic merge order
- Plugin SDK with entry-point discovery for checks and emitters
- Branch protection setup script
- Comprehensive Makefile targets for development workflows

### Changed
- Findings now include confidence and rule_version fields (backwards compatible)
- Policy section now required in vibegate.yaml schema (with sensible defaults)
- Status determination now based on blocking findings (fail_on) vs warnings (warn_on)
- Evidence schema updated to include confidence, rule_version, and new finding counts
- Improved vibegate.yaml validation with clear remediation guidance
- Enhanced README with quickstart and policy documentation

### Fixed
- All checks now properly assign confidence levels (default: "high")
- Evidence schema validation for all finding events
- Test suite updated to include policy sections in all configs
