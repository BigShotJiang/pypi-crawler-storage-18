"""Version information for EShopBox SDK"""

__version__ = '1.1.7'
__author__ = 'Sakib Mailk'
__email__ = 'sakibmaliknakur347@gmail.com'
__license__ = 'MIT'
__description__ = 'Python SDK for EShopBox Shipping APIs'
__url__ = 'https://github.com/onesakib/eshopbox'
