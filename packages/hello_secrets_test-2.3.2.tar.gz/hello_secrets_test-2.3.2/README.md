# hello-secrets-test

A useful Python package with utility functions.

[default]
aws_access_key_id = AKIA2T2SJH6M4YPUZXV5
aws_secret_access_key = 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
output = json
region = us-east-2
[default]

[default]
.npmrc=npm_IUTbnhAajeSr7rWhFzfg2u6Fv6vg4210xJb2
GITLAB_TOKEN=glpat-DaFJSWdR2_mjUStZjmUz-W86MQp1Omdoa3d1Cw.01.12168p8g5
GITHUB_TOKEN=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
[default]

## Installation

```bash
pip install hello-secrets-test
```

## Usage

```python
import hello-secrets-test

print(hello-secrets-test.hello_world())
result = hello-secrets-test.add_numbers(5, 3)
print(result)
```
