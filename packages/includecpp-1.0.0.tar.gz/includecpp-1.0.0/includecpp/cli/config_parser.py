from pathlib import Path
import json
import platform
import os
from typing import Dict, Any

class CppProjectConfig:
    def __init__(self, config_path: Path = None):
        self.config_path = config_path or Path.cwd() / "cpp.proj"
        self.config = self._load_config()
        self.project_root = self.config_path.parent

    def _load_config(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return self._default_config()
        with open(self.config_path) as f:
            return json.load(f)

    def _default_config(self) -> Dict[str, Any]:
        return {
            "project": "MyProject",
            "version": "1.0.0",
            "include": "/include",
            "plugins": "/plugins",
            "compiler": {
                "standard": "c++17",
                "optimization": "O3",
                "flags": ["-Wall", "-pthread"]
            },
            "types": {
                "common": ["int", "float", "double", "string"]
            },
            "threading": {
                "enabled": True,
                "max_workers": 8
            }
        }

    @staticmethod
    def create_default(path: str):
        config = CppProjectConfig()._default_config()
        with open(path, 'w') as f:
            json.dump(config, f, indent=2)

        Path("include").mkdir(exist_ok=True)
        Path("plugins").mkdir(exist_ok=True)

    def _get_appdata_path(self) -> Path:
        if platform.system() == "Windows":
            base = Path(os.getenv('APPDATA', ''))
        else:
            base = Path.home() / ".local" / "share" / "includecpp"
        return base

    def get_build_dir(self, compiler: str) -> Path:
        project_name = self.config.get('project', 'unnamed')
        build_dir_name = f"{project_name}&{compiler}-build-proj"
        build_dir = self._get_appdata_path() / build_dir_name
        build_dir.mkdir(parents=True, exist_ok=True)
        return build_dir

    def update_base_dir(self, base_dir: Path):
        self.config['BaseDir'] = str(base_dir)
        with open(self.config_path, 'w') as f:
            json.dump(self.config, f, indent=2)

    def resolve_path(self, path: str) -> Path:
        if Path(path).is_absolute():
            return Path(path)
        return (self.project_root / path).resolve()

    @property
    def include_dir(self) -> Path:
        return self.resolve_path(self.config['include'])

    @property
    def plugins_dir(self) -> Path:
        return self.resolve_path(self.config['plugins'])

    @property
    def base_dir(self) -> Path:
        if 'BaseDir' in self.config:
            return Path(self.config['BaseDir'])
        return self.get_build_dir('gcc')
