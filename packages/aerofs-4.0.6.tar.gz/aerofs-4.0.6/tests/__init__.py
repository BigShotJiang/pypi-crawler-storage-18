"""aerofs tests."""
