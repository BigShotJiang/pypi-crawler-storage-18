---
name: Feature / enhancement idea
about: Suggest an idea or improvement
title: ''
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Propose implementation**
For example: Add method `x` for class `y` and then call that in function `z`.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Notes / context**
Any additional context that may help, such as relevant files or functions or screenshots.
