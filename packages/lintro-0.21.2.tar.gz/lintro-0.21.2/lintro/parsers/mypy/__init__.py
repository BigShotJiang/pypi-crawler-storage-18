"""Mypy parser package."""
