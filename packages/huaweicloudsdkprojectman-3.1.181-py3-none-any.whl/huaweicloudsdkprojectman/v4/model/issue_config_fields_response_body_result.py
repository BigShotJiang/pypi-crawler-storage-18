# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class IssueConfigFieldsResponseBodyResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'config_fields': 'list[IssueConfigFieldsResponseBodyResultConfigFields]'
    }

    attribute_map = {
        'config_fields': 'config_fields'
    }

    def __init__(self, config_fields=None):
        r"""IssueConfigFieldsResponseBodyResult

        The model defined in huaweicloud sdk

        :param config_fields: 字段配置
        :type config_fields: list[:class:`huaweicloudsdkprojectman.v4.IssueConfigFieldsResponseBodyResultConfigFields`]
        """
        
        

        self._config_fields = None
        self.discriminator = None

        if config_fields is not None:
            self.config_fields = config_fields

    @property
    def config_fields(self):
        r"""Gets the config_fields of this IssueConfigFieldsResponseBodyResult.

        字段配置

        :return: The config_fields of this IssueConfigFieldsResponseBodyResult.
        :rtype: list[:class:`huaweicloudsdkprojectman.v4.IssueConfigFieldsResponseBodyResultConfigFields`]
        """
        return self._config_fields

    @config_fields.setter
    def config_fields(self, config_fields):
        r"""Sets the config_fields of this IssueConfigFieldsResponseBodyResult.

        字段配置

        :param config_fields: The config_fields of this IssueConfigFieldsResponseBodyResult.
        :type config_fields: list[:class:`huaweicloudsdkprojectman.v4.IssueConfigFieldsResponseBodyResultConfigFields`]
        """
        self._config_fields = config_fields

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, IssueConfigFieldsResponseBodyResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
