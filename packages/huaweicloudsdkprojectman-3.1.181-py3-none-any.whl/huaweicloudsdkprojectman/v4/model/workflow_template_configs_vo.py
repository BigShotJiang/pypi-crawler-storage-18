# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class WorkflowTemplateConfigsVO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'config_value': 'list[dict(str, object)]'
    }

    attribute_map = {
        'config_value': 'configValue'
    }

    def __init__(self, config_value=None):
        r"""WorkflowTemplateConfigsVO

        The model defined in huaweicloud sdk

        :param config_value: 操作项配置
        :type config_value: list[dict(str, object)]
        """
        
        

        self._config_value = None
        self.discriminator = None

        if config_value is not None:
            self.config_value = config_value

    @property
    def config_value(self):
        r"""Gets the config_value of this WorkflowTemplateConfigsVO.

        操作项配置

        :return: The config_value of this WorkflowTemplateConfigsVO.
        :rtype: list[dict(str, object)]
        """
        return self._config_value

    @config_value.setter
    def config_value(self, config_value):
        r"""Sets the config_value of this WorkflowTemplateConfigsVO.

        操作项配置

        :param config_value: The config_value of this WorkflowTemplateConfigsVO.
        :type config_value: list[dict(str, object)]
        """
        self._config_value = config_value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, WorkflowTemplateConfigsVO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
