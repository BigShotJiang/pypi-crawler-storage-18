from .main_code import ImageOCR
__all__ = ['ImageOCR']
__version__ = "0.1.1"
