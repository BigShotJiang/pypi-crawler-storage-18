from .main_code import OCRDataExtractor
__all__ = ['OCRDataExtractor']
__version__ = "0.1.1"
