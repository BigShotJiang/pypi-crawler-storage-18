"""Agent onboarding command (admin-only).

Onboard custom agents to the NCP platform. Unlike deployed agents,
onboarded agents run integrated within the platform (no container isolation)
and are available to users based on role-based CustomAgents permissions.
"""

import click
import requests
import urllib3
import tarfile
import toml
import tempfile
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils import get_platform_and_key

# Disable SSL warnings for localhost development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

console = Console()


def extract_agent_name_from_package(package_path: Path) -> str:
    """Extract agent name from package's ncp.toml.

    Args:
        package_path: Path to .ncp package file

    Returns:
        Agent name from package

    Raises:
        ValueError: If agent name cannot be extracted
    """
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Extract tar.gz
            with tarfile.open(package_path, "r:gz") as tar:
                tar.extractall(temp_path)

            # Find ncp.toml
            ncp_toml_files = list(temp_path.rglob("ncp.toml"))
            if not ncp_toml_files:
                raise ValueError("No ncp.toml found in package")

            # Read agent name from config
            config = toml.load(ncp_toml_files[0])
            agent_name = config.get("project", {}).get("name")

            if not agent_name:
                raise ValueError("No agent name found in ncp.toml")

            return agent_name

    except Exception as e:
        raise ValueError(f"Failed to extract agent name: {str(e)}")


def onboard_agent(package_file: str, platform: str = None, api_key: str = None, update: bool = False):
    """Onboard a custom agent package to the NCP platform (admin-only).

    Unlike deployed agents, onboarded agents:
    - Run integrated within the platform (no container isolation)
    - Are available to users based on role-based CustomAgents permissions
    - Can be assigned to roles via Admin > Roles & Permissions

    Args:
        package_file: Path to .ncp package file
        platform: NCP platform URL
        api_key: Optional API key for authentication
        update: If True, update existing agent with same name
    """
    package_path = Path(package_file)

    if not package_path.exists():
        console.print(f"\n[red]x[/red] Package file not found: {package_file}\n")
        raise click.Abort()

    if not package_path.suffix == ".ncp":
        console.print("[yellow]Warning:[/yellow] File does not have .ncp extension")

    # Extract agent name for update
    update_agent_name = None
    if update:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Extracting agent info...", total=None)
            try:
                update_agent_name = extract_agent_name_from_package(package_path)
            except ValueError as e:
                console.print(f"\n[red]x[/red] {e}\n")
                raise click.Abort()

    # Get platform credentials
    try:
        platform_url, api_key_to_use = get_platform_and_key(platform, api_key)
    except click.UsageError as e:
        console.print(f"\n[red]x[/red] {e}\n")
        raise click.Abort()

    # Show onboarding info
    info_text = f"[cyan]Platform:[/cyan] {platform_url}\n"
    info_text += f"[cyan]Package:[/cyan]  {package_path.name}\n"
    if update_agent_name:
        info_text += f"[cyan]Action:[/cyan]   Update existing custom agent\n"
        info_text += f"[cyan]Agent:[/cyan]    {update_agent_name}\n"
    else:
        info_text += f"[cyan]Action:[/cyan]   Onboard new custom agent (admin-only)\n"
    if api_key_to_use:
        info_text += f"[cyan]Auth:[/cyan]     Authenticated"

    console.print()
    console.print(Panel(info_text, title="[bold]Onboarding Configuration[/bold]", border_style="cyan"))
    console.print()

    try:
        # Prepare the file upload
        with open(package_path, 'rb') as f:
            files = {'file': (package_path.name, f, 'application/gzip')}

            # Prepare headers
            headers = {}
            if api_key_to_use:
                headers['Authorization'] = f'Bearer {api_key_to_use}'

            # Prepare query params
            params = {}
            if update_agent_name:
                params['update'] = update_agent_name

            # Make the API request
            onboard_url = f"{platform_url}/api/v1/custom_agents/onboard"

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Uploading and validating package...", total=None)

                response = requests.post(
                    onboard_url,
                    files=files,
                    headers=headers,
                    params=params,
                    verify=False  # Skip SSL verification for localhost
                )

            # Check response
            if response.status_code == 200:
                result = response.json()

                success_text = f"[green]Agent:[/green]     {result.get('agent_name')}\n"
                success_text += f"[green]Agent ID:[/green]  {result.get('agent_id')}\n"
                success_text += f"[green]Status:[/green]    {result.get('status')}\n\n"
                success_text += f"[dim]The agent is now available to users based on role permissions.[/dim]\n"
                success_text += f"[dim]Assign via Admin > Roles & Permissions > CustomAgents[/dim]\n\n"
                success_text += f"[dim]Next steps:[/dim]\n"
                success_text += f"  - View all custom agents: [cyan]ncp onboard-list[/cyan]\n"
                success_text += f"  - Remove agent:           [cyan]ncp onboard-remove --agent {result.get('agent_name')}[/cyan]"

                console.print(Panel(success_text, title="[bold green]Onboarding Complete[/bold green]", border_style="green"))
                console.print()

            elif response.status_code == 403:
                console.print()
                console.print("[red]x[/red] Admin access required for onboarding")
                console.print("[dim]Only administrators can onboard custom agents[/dim]")
                console.print()
                raise click.Abort()

            elif response.status_code == 409:
                error = response.json()
                console.print()
                console.print(f"[red]x[/red] {error.get('detail', 'Agent already exists')}")
                console.print()

                # Show clear example of how to update
                update_help = (
                    "[yellow]To update the existing agent, run:[/yellow]\n\n"
                    f"  [cyan bold]ncp onboard {package_path.name} --update[/cyan bold]"
                )
                console.print(Panel(
                    update_help,
                    title="[bold yellow]Solution[/bold yellow]",
                    border_style="yellow"
                ))
                console.print()
                raise click.Abort()

            else:
                error = response.json() if response.headers.get('content-type') == 'application/json' else {'detail': response.text}
                console.print()
                console.print(f"[red]x[/red] Onboarding failed: {error.get('detail', 'Unknown error')}")
                console.print()
                raise click.Abort()

    except requests.exceptions.ConnectionError:
        console.print()
        console.print(f"[red]x[/red] Cannot connect to platform: {platform_url}")
        console.print("[dim]Please verify the platform is running and the URL is correct[/dim]")
        console.print()
        raise click.Abort()

    except click.Abort:
        raise

    except Exception as e:
        console.print()
        console.print(f"[red]x[/red] Onboarding failed: {str(e)}")
        console.print()
        raise click.Abort()
