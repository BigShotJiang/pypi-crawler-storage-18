"""Custom agent listing command (admin-only)."""

import click
import requests
import urllib3
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from ..utils import get_platform_and_key

# Disable SSL warnings for localhost development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

console = Console()


def format_datetime(dt_str: str) -> str:
    """Format datetime string to human-readable format."""
    if not dt_str:
        return "N/A"
    try:
        dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        return dt.strftime("%Y-%m-%d %H:%M")
    except:
        return dt_str


def get_status_style(status: str) -> tuple:
    """Get color and display text for agent status."""
    status_styles = {
        "ACTIVE": ("green", "Active"),
        "DISABLED": ("dim", "Disabled"),
        "PENDING": ("yellow", "Pending"),
        "REJECTED": ("red", "Rejected"),
    }
    return status_styles.get(status, ("white", status))


def list_onboarded_agents(platform: str = None, api_key: str = None):
    """List onboarded custom agents on the NCP platform (admin-only).

    Unlike deployed agents, onboarded agents:
    - Run integrated within the platform (no container isolation)
    - Are available to users based on role-based CustomAgents permissions

    Args:
        platform: NCP platform URL
        api_key: Optional API key for authentication
    """
    # Get platform credentials
    try:
        platform_url, api_key_to_use = get_platform_and_key(platform, api_key)
    except click.UsageError as e:
        console.print(f"\n[red]x[/red] {e}\n")
        raise click.Abort()

    # Prepare headers
    headers = {}
    if api_key_to_use:
        headers['Authorization'] = f'Bearer {api_key_to_use}'

    try:
        # Make API request
        list_url = f"{platform_url}/api/v1/custom_agents/list"

        response = requests.get(
            list_url,
            headers=headers,
            verify=False  # Skip SSL verification for localhost
        )

        if response.status_code == 200:
            result = response.json()
            agents = result.get('agents', [])
            total = result.get('total', 0)

            if total == 0:
                console.print()
                console.print(Panel.fit(
                    "[yellow]No custom agents found[/yellow]\n\n"
                    "[dim]Get started by onboarding your first agent:[/dim]\n"
                    "  [cyan]ncp onboard <package-file>.ncp[/cyan]",
                    title="[bold]Custom Agents[/bold]",
                    border_style="yellow"
                ))
                console.print()
                return

            # Create table
            table = Table(title=f"Custom Agents ({total})", show_header=True, header_style="bold cyan")
            table.add_column("Name", style="green", no_wrap=True)
            table.add_column("Description", style="dim", max_width=40)
            table.add_column("Version", style="yellow", justify="center")
            table.add_column("Status", justify="center")
            table.add_column("Onboarded By", style="blue")
            table.add_column("Created", style="blue")

            for agent in agents:
                status = agent.get('status', 'UNKNOWN')
                style, display = get_status_style(status)
                status_text = f"[{style}]{display}[/{style}]"

                description = agent.get('description', '') or ''
                if len(description) > 40:
                    description = description[:37] + '...'

                table.add_row(
                    agent.get('name', 'N/A'),
                    description,
                    agent.get('version', 'N/A'),
                    status_text,
                    agent.get('submitted_by', 'N/A'),
                    format_datetime(agent.get('created_at'))
                )

            console.print()
            console.print(table)
            console.print()
            console.print("[dim]Tip: Assign agents to roles via Admin > Roles & Permissions > CustomAgents[/dim]")
            console.print()

        elif response.status_code == 403:
            console.print()
            console.print("[red]x[/red] Admin access required")
            console.print("[dim]Only administrators can list custom agents[/dim]")
            console.print()
            raise click.Abort()

        elif response.status_code == 401:
            console.print()
            console.print("[red]x[/red] Authentication required")
            console.print("[dim]Run [cyan]ncp authenticate[/cyan] to log in[/dim]")
            console.print()
            raise click.Abort()

        else:
            error = response.json() if response.headers.get('content-type') == 'application/json' else {'detail': response.text}
            console.print()
            console.print(f"[red]x[/red] Failed to retrieve agents: {error.get('detail', 'Unknown error')}")
            console.print()
            raise click.Abort()

    except requests.exceptions.ConnectionError:
        console.print()
        console.print(f"[red]x[/red] Cannot connect to platform: {platform_url}")
        console.print("[dim]Please verify the platform is running and the URL is correct[/dim]")
        console.print()
        raise click.Abort()

    except click.Abort:
        raise

    except Exception as e:
        console.print()
        console.print(f"[red]x[/red] Unexpected error: {str(e)}")
        console.print()
        raise click.Abort()
