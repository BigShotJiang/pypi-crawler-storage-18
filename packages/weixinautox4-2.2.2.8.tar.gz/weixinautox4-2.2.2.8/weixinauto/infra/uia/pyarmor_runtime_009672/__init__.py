# Pyarmor 9.2.0 (basic), 009672, 2025-12-25T18:26:56.473859
from .pyarmor_runtime import __pyarmor__
