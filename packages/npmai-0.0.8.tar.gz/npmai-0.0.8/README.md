npmai

npmai (by Sonu Kumar Ramashish) is a lightweight Python package that seamlessly connects you  with Ollama and other open-source models without any Installation, Login/Signup or API problems.

🚀 Features

Execute prompts on multiple LLMs simultaneously:["LLaMA-3.2","CodeLLaMA-Instruct 7B","Gemma-2-Instruct 9B","Mistral 7B Instruct","Qwen-2.5-Coder 7B","Phi-3 Medium (8B)","Falcon 7B Instruct","Baichuan-2-7B","InternLM-Chat-7B","Vicuna 7B"]

Fully LangChain,CrewAI and other -compatible interface.

Simple and intuitive invoke() API for instant responses.

Support continuous conversation.

Encourages responsible usage.

⚙️ Installation
pip install npmai


Tip: For Python 3.13, make sure to use:

py -3.13 -m pip install npmai

💡 How to Use

Import the models 

from npmai import Ollama


Initialize Ollama:

llm = Ollama()      

prompts=""
model="Llama3.2" you can keep other also

Invoke a prompt and get the response:

response = llm.invoke(prompts,model)
print(response) 

#Latest Update :
version 0.0.8 Here you will get Ollama's 10 model.

⚠️ Important Notes

Designed for educational ,small-scale experimentation, for demo projets and small scale users.

If using at a larger scale, consider supporting the original AI platforms—they invest heavily in research and infrastructure.

use responsibly to help us.

✅ npmai makes it effortless to connect Ollam models with Python, bringing automation, experimentation, and LangChain,Crew AI integration together in a single, easy-to-use package.