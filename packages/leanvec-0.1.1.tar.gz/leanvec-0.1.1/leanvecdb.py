from typing import List, Dict, Any, Optional
import json, uuid, os, leanvec, atexit, gc

class LeanVecDB:
    def __init__(self, storage_folder: str = 'leanvec_db', auto_persist: bool = True):
        self.storage_folder = storage_folder
        self.config_path = os.path.join(storage_folder, 'config.json')
        
        if not os.path.exists(storage_folder):
            os.makedirs(storage_folder)

        self.db = leanvec.LeanDB(storage_folder)
        self.dimension = self._load_dimension()

        # If tests delete the folder, auto_persist should handle it
        if auto_persist:
            atexit.register(self.persist)

    def _load_dimension(self) -> Optional[int]:
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    return json.load(f).get('dimension')
            except Exception:
                return None
        return None

    def _set_dimension(self, dim: int):
        self.dimension = dim
        with open(self.config_path, 'w') as f:
            json.dump({'dimension': dim}, f)

    def store_embedding(self, embedding: List[float], metadata_dict: Dict[str, Any] = {}) -> str:
        return self.store_embeddings_batch([embedding], [metadata_dict])[0]

    def store_embeddings_batch(self, embeddings: List[List[float]], metadatas: Optional[List[Dict[str, Any]]] = None) -> List[str]:
        if not embeddings: return []
        input_dim = len(embeddings[0])
        if self.dimension is None: self._set_dimension(input_dim)
        elif input_dim != self.dimension:
            raise ValueError(f"Dimension Mismatch: DB {self.dimension}, Got {input_dim}")

        if metadatas is None: metadatas = [{} for _ in range(len(embeddings))]
        
        ids = []
        for vec, meta in zip(embeddings, metadatas):
            if "id" in meta: doc_id = str(meta["id"])
            else:
                doc_id = str(uuid.uuid4())
                meta["id"] = doc_id
            ids.append(doc_id)
            self.db.add(doc_id, vec, json.dumps(meta))
        return ids
    
    def delete(self, metadata_filter: Dict[str, Any]) -> int:
        if self.dimension is None: return 0
        return self.db.delete_by_filter(json.dumps(metadata_filter))
    
    def autocut_scores(self, score_list: List[float]) -> List[int]:
        if len(score_list) < 2: return []
        score_changes = []
        for i in range(1, len(score_list)):
            prev = score_list[i-1]
            curr = score_list[i]
            if prev == 0: change = 0 
            else: change = (curr - prev) / prev
            score_changes.append(change)
        if not score_changes: return []
        max_change = max(score_changes)
        if max_change > 0.2:
            cut_index = score_changes.index(max_change) + 1
            return list(range(cut_index, len(score_list)))
        return []

    def search(self, query_embedding: List[float], filters: Optional[Dict[str, Any]] = None, k: int = 5, autocut: bool = False, return_vectors: bool = False) -> List[Dict[str, Any]]:
        if self.dimension is None: return []
        
        filter_str = json.dumps(filters) if filters else None
        raw_results = self.db.search(query_embedding, k, filter_str)
        
        formatted_results = []
        scores = []
        for doc_id, score in raw_results:
            formatted_results.append({"id": doc_id, "score": score})
            scores.append(score)

        if autocut and len(scores) > 1:
            indices_to_remove = self.autocut_scores(scores)
            if indices_to_remove:
                formatted_results = formatted_results[:indices_to_remove[0]]

        return formatted_results

    def persist(self):
        try:
            # Check if directory exists before trying to save
            # This fixes "os error 2" during unit tests tearDown
            if not os.path.exists(self.storage_folder):
                return
            
            gc.collect() 
            self.db.persist()
        except Exception as e:
            # Silence expected errors if file system is gone
            if "No such file" not in str(e):
                print(f"Persist failed: {e}")

    def count(self) -> int:
        return self.db.count()