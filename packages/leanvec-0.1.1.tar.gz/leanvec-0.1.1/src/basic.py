from leanvecdb import LeanVecDB

db = LeanVecDB(storage_folder="example_db", auto_persist=False)

emb1 = [0.1, 0.2, 0.3]
id1 = db.store_embedding(emb1, {"type": "doc", "name": "first"})

embeddings = [
    [0.0, 0.1, 0.2],
    [0.2, 0.1, 0.0],
]
metadatas = [
    {"type": "doc", "name": "second"},
    {"type": "doc", "name": "third"},
]
ids = db.store_embeddings_batch(embeddings, metadatas)

total = db.count()

query = [0.1, 0.2, 0.25]
results = db.search(query_embedding=query, k=3)

filtered_results = db.search(
    query_embedding=query,
    filters={"type": "doc"},
    k=3
)

autocut_results = db.search(
    query_embedding=query,
    k=5,
    autocut=True
)

scores = [0.01, 0.015, 0.04, 0.045]
cut_indices = db.autocut_scores(scores)

deleted_count = db.delete({"name": "second"})

db.persist() # executa ao sair do programa automaticamente caso não seja chamada explicitamente