import gc
import asyncio
import numpy as np
import time
import random
import logging
import shutil
import os
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor

from leanvecdb import LeanVecDB

# --- CONFIGURATION ---
TOTAL_VECTORS = 500_000
DIMENSION = 768
BATCH_SIZE = 1_000
CONCURRENT_WORKERS = 2
DB_PATH = "./benchmark_db_wrapper"
LOG_FILE = "benchmark_wrapper.log"

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler(LOG_FILE), logging.StreamHandler()]
)

class LocalBenchmark:
    def __init__(self):
        # Clean start
        if os.path.exists(DB_PATH):
            shutil.rmtree(DB_PATH)
        
        # Initialize the Wrapper instead of raw DB
        self.db = LeanVecDB(DB_PATH)
        self.results = {}
        self.executor = ThreadPoolExecutor(max_workers=CONCURRENT_WORKERS)
        self.inserted_count = 0
    
    def generate_batch(self, size, offset=0):
        vectors = np.random.rand(size, DIMENSION).astype(np.float32).tolist()
        metadatas = []
        ids = []
        for i in range(size):
            price = random.uniform(10, 1000)
            cat = random.choice(["electronics", "books", "clothing", "home"])
            
            meta = {
                "category": cat,
                "price": price,
                "timestamp": time.time(),
                "indexed_at": offset + i
            }
            metadatas.append(meta)
            ids.append(f"doc_{offset + i}")
            
        return ids, vectors, metadatas
    
    def _insert_batch_sync(self, ids, vecs, metas):
        """
        Helper to map the raw generation to the Wrapper API.
        The wrapper expects IDs to be inside the metadata dict with key 'id'.
        """
        # Inject IDs into metadata
        for i, doc_id in enumerate(ids):
            metas[i]["id"] = doc_id
            
        # Wrapper handles JSON serialization and batching
        self.db.store_embeddings_batch(vecs, metas)
            
    async def run_in_thread(self, func, *args, **kwargs):
        loop = asyncio.get_event_loop()
        # Use lambda to pass kwargs if necessary, though simpler to align args
        return await loop.run_in_executor(self.executor, lambda: func(*args, **kwargs))
    
    # --- SCENARIOS ---
    
    async def scenario_1_bulk_index(self):
        logging.info("SCENARIO 1: Bulk Indexing (Warmup & Load)")
        start_time = time.perf_counter()
        pbar = tqdm(total=TOTAL_VECTORS, desc="Ingesting", unit="vec")
        
        for i in range(0, TOTAL_VECTORS, BATCH_SIZE):
            ids, vecs, metas = self.generate_batch(BATCH_SIZE, i)
            await self.run_in_thread(self._insert_batch_sync, ids, vecs, metas)
            self.inserted_count += len(ids)
            pbar.update(len(vecs))
            
            del ids, vecs, metas  # Free memory promptly
            gc.collect()         # Force garbage collection
            
        pbar.close()
        total_time = time.perf_counter() - start_time
        vps = TOTAL_VECTORS / total_time
        logging.info(f"Complete. VPS: {vps:.2f}")
        self.results["Bulk Indexing (VPS)"] = vps
    
    async def scenario_2_index_while_search(self):
        logging.info("SCENARIO 2: Search Throughput during Indexing")
        duration = 15 
        search_count = 0
        start_time = time.perf_counter()
        
        async def search_worker():
            nonlocal search_count
            while time.perf_counter() - start_time < duration:
                v = np.random.rand(DIMENSION).tolist()
                # Wrapper: search(query, filters=None, k=5)
                await self.run_in_thread(self.db.search, v, None, 5)
                search_count += 1
        
        async def index_worker():
            local_offset = self.inserted_count
            while time.perf_counter() - start_time < duration:
                ids, vecs, metas = self.generate_batch(100, local_offset)
                await self.run_in_thread(self._insert_batch_sync, ids, vecs, metas)
                local_offset += 100
        
        workers = [search_worker() for _ in range(4)] + [index_worker() for _ in range(1)]
        await asyncio.gather(*workers)
        
        qps = search_count / duration
        logging.info(f"Complete. Search QPS under load: {qps:.2f}")
        self.results["Search QPS (under Load)"] = qps
    
    async def scenario_3_filtered_search(self):
        logging.info("SCENARIO 3: Complex Filtered Search")
        
        # Pass native Python dicts. Wrapper handles JSON dumps.
        filters = [
            (None, "No Filter"),
            ({"category": "electronics"}, "Equality"),
            ({"price": {"$lt": 100}}, "Range Filter"),
            ({"$and": [{"category": "clothing"}, {"price": {"$gt": 500}}]}, "Complex AND")
        ]
        
        qps_results = []
        for filt, label in filters:
            requests = 500
            start_time = time.perf_counter()
            
            tasks = []
            for _ in range(requests):
                v = np.random.rand(DIMENSION).tolist()
                # Wrapper: search(query, filters=filt, k=5)
                tasks.append(self.run_in_thread(self.db.search, v, filt, 5))
                
            await asyncio.gather(*tasks)
            
            elapsed = time.perf_counter() - start_time
            qps = requests / elapsed
            qps_results.append(qps)
            print(f" - {label}: {qps:.2f} QPS")
            
        self.results["Search QPS (Filtered Avg)"] = np.mean(qps_results)
    
    async def scenario_4_mixed_load(self):
        logging.info("SCENARIO 4: Mixed Search/Insert/Delete Load")
        duration = 15
        ops = [0]
        start_time = time.perf_counter()
        
        max_id = self.inserted_count
        
        async def worker():
            while time.perf_counter() - start_time < duration:
                choice = random.random()
                
                if choice < 0.7:  # Search
                    # Wrapper handles the dict filter
                    f = {"category": "books"}
                    await self.run_in_thread(self.db.search, np.random.rand(DIMENSION).tolist(), f, 5)
                
                elif choice < 0.9:  # Insert
                    ids, vecs, metas = self.generate_batch(5, max_id + ops[0])
                    await self.run_in_thread(self._insert_batch_sync, ids, vecs, metas)
                
                else:  # Delete
                    target_id = f"doc_{random.randint(0, max_id)}"
                    # Wrapper deletes by filter. We target specific ID via filter.
                    # This implies: Search -> Get ID -> Delete ID
                    await self.run_in_thread(self.db.delete, {"id": target_id})
                
                ops[0] += 1

        await asyncio.gather(*[worker() for _ in range(CONCURRENT_WORKERS * 4)])
        
        total_qps = ops[0] / duration
        logging.info(f"Complete. Mixed Load Operations/sec: {total_qps:.2f}")
        self.results["Mixed Load QPS"] = total_qps
    
    async def scenario_5_pure_read_concurrency(self):
        logging.info("SCENARIO 5: Pure Concurrent Read Performance")
        duration = 10
        search_count = 0
        start_time = time.perf_counter()
        
        async def search_worker():
            nonlocal search_count
            while time.perf_counter() - start_time < duration:
                v = np.random.rand(DIMENSION).tolist()
                
                if random.random() < 0.5:
                    filt = {"category": random.choice(["electronics", "books"])}
                else:
                    filt = None
                    
                await self.run_in_thread(self.db.search, v, filt, 5)
                search_count += 1
                
        workers = [search_worker() for _ in range(CONCURRENT_WORKERS * 3)]
        await asyncio.gather(*workers)
        
        qps = search_count / duration
        logging.info(f"Complete. Pure Read QPS: {qps:.2f}")
        self.results["Pure Read QPS"] = qps
    
    async def run_all(self):
        print(f"Starting Wrapper Benchmark on {DB_PATH}")
        print(f"Target: {TOTAL_VECTORS} vectors, {DIMENSION} dim")
        print("-" * 60)
        
        await self.scenario_1_bulk_index()
        await self.scenario_5_pure_read_concurrency()
        await self.scenario_2_index_while_search()
        await self.scenario_3_filtered_search()
        await self.scenario_4_mixed_load()
        
        print("\n" + "="*60)
        print("BENCHMARK RESULTS SUMMARY (Wrapper)")
        print("="*60)
        for metric, value in self.results.items():
            print(f"{metric:.<45} {value:>10.2f}")
        print("="*60)
        
        logging.info("Persisting DB via Wrapper...")
        self.db.persist()
        logging.info("Done.")
        self.executor.shutdown()
    
if __name__ == "__main__":
    benchmark = LocalBenchmark()
    asyncio.run(benchmark.run_all())