"""
DataWise Jupyter Lab MCP Server
提供远程控制 Jupyter Lab 的 MCP 服务
"""

__version__ = "1.0.0"
__author__ = "DataWiseCenter"
__email__ = "contact@datawisecenter.com"

from .main import mcp

__all__ = ["mcp"]
