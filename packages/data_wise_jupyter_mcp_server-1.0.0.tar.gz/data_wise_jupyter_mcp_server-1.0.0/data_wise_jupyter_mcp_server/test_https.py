"""
HTTPS 功能测试脚本
"""

import sys
import os
import json

# 添加当前目录到 Python 路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import mcp
from jupyter_controller import JupyterController


def test_https_support():
    """测试 HTTPS 支持"""
    print("测试 HTTPS 支持...")
    
    # 测试基本 HTTPS 配置
    print("1. 测试基本 HTTPS 配置...")
    controller = JupyterController(verify_ssl=True)
    print(f"✓ HTTPS 控制器初始化成功，SSL 验证: {controller.verify_ssl}")
    
    # 测试禁用 SSL 验证
    print("\n2. 测试禁用 SSL 验证...")
    controller_no_ssl = JupyterController(verify_ssl=False)
    print(f"✓ 无 SSL 验证控制器初始化成功，SSL 验证: {controller_no_ssl.verify_ssl}")
    
    # 测试自定义证书路径
    print("\n3. 测试自定义证书路径...")
    controller_cert = JupyterController(verify_ssl=True, cert_path="/tmp/test.pem")
    print(f"✓ 自定义证书控制器初始化成功，证书路径: {controller_cert.cert_path}")
    
    return True


def test_ssl_url_detection():
    """测试 SSL URL 检测"""
    print("\n测试 SSL URL 检测...")
    
    test_urls = [
        ("http://localhost:8888", False),
        ("https://localhost:8888", True),
        ("http://example.com", False),
        ("https://example.com", True)
    ]
    
    for url, expected_ssl in test_urls:
        is_ssl = url.startswith('https://')
        status = "✓" if is_ssl == expected_ssl else "✗"
        print(f"{status} {url} -> SSL: {is_ssl} (期望: {expected_ssl})")
    
    return True


def test_mcp_tools_ssl_config():
    """测试 MCP 工具 SSL 配置"""
    print("\n测试 MCP 工具 SSL 配置...")
    
    # 模拟请求对象
    class MockRequest:
        def __init__(self, url="https://localhost:8888", verify_ssl=True, cert_path=None):
            self.url = url
            self.token = "test_token"
            self.verify_ssl = verify_ssl
            self.cert_path = cert_path
    
    # 测试不同配置
    configs = [
        {"url": "http://localhost:8888", "verify_ssl": True},
        {"url": "https://localhost:8888", "verify_ssl": True},
        {"url": "https://localhost:8888", "verify_ssl": False},
        {"url": "https://localhost:8888", "verify_ssl": True, "cert_path": "/tmp/test.pem"}
    ]
    
    for i, config in enumerate(configs, 1):
        mock_request = MockRequest(**config)
        print(f"\n{i}. 配置: {config}")
        print(f"   URL: {mock_request.url}")
        print(f"   SSL 验证: {mock_request.verify_ssl}")
        print(f"   证书路径: {mock_request.cert_path}")
        print(f"   SSL 检测: {mock_request.url.startswith('https://')}")
    
    return True


def test_websocket_ssl_conversion():
    """测试 WebSocket SSL 转换"""
    print("\n测试 WebSocket SSL 转换...")
    
    test_cases = [
        ("http://localhost:8888", "ws://localhost:8888"),
        ("https://localhost:8888", "wss://localhost:8888"),
        ("http://example.com:9999", "ws://example.com:9999"),
        ("https://example.com:9999", "wss://example.com:9999")
    ]
    
    for http_url, expected_ws in test_cases:
        ws_url = http_url.replace('http://', 'ws://').replace('https://', 'wss://')
        status = "✓" if ws_url == expected_ws else "✗"
        print(f"{status} {http_url} -> {ws_url} (期望: {expected_ws})")
    
    return True


def main():
    """主测试函数"""
    print("开始 HTTPS 功能测试...")
    print("=" * 50)
    
    tests = [
        test_https_support,
        test_ssl_url_detection,
        test_mcp_tools_ssl_config,
        test_websocket_ssl_conversion
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                print(f"❌ {test.__name__} 失败")
        except Exception as e:
            print(f"❌ {test.__name__} 异常: {str(e)}")
    
    print("\n" + "=" * 50)
    print(f"测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有 HTTPS 功能测试通过!")
        print("\n✅ 支持的功能:")
        print("   - HTTP/HTTPS URL 自动检测")
        print("   - SSL 证书验证配置")
        print("   - 自定义证书路径支持")
        print("   - WebSocket SSL (WSS) 支持")
        print("   - 灵活的 SSL 安全策略")
    else:
        print("⚠️  部分测试失败，请检查实现。")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
