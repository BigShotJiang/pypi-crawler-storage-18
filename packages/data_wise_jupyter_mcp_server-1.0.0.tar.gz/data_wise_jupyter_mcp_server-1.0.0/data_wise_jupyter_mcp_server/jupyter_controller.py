"""
Jupyter Lab 控制器
负责与 Jupyter Lab 服务器进行交互
"""

import json
import requests
import threading
import time
import ssl
import base64
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin


class JupyterController:
    """Jupyter Lab 控制器类"""
    
    def __init__(self, verify_ssl: bool = True, cert_path: Optional[str] = None):
        self.session = requests.Session()
        self.verify_ssl = verify_ssl
        self.cert_path = cert_path
        self.ws_connections = {}
        
        # 配置 SSL 验证
        if not verify_ssl:
            # 禁用 SSL 警告（仅用于开发环境）
            requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
            self.session.verify = False
        elif cert_path:
            self.session.verify = cert_path
    
    def _get_headers(self, token: Optional[str]) -> Dict[str, str]:
        """获取请求头"""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        if token:
            headers['Authorization'] = f'token {token}'
        return headers
    
    def _make_request(self, url: str, endpoint: str, token: Optional[str], method: str = 'GET', data: Optional[Dict] = None) -> Dict:
        """发送 HTTP 请求"""
        full_url = urljoin(url, endpoint)
        headers = self._get_headers(token)
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(full_url, headers=headers)
            elif method.upper() == 'POST':
                response = self.session.post(full_url, headers=headers, json=data)
            elif method.upper() == 'PUT':
                response = self.session.put(full_url, headers=headers, json=data)
            elif method.upper() == 'DELETE':
                response = self.session.delete(full_url, headers=headers)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise Exception(f"请求失败: {str(e)}")
    
    def get_server_info(self, url: str, token: Optional[str]) -> Dict[str, Any]:
        """获取服务器信息"""
        try:
            # 获取 API 版本信息
            api_info = self._make_request(url, '/api/status', token)
            
            # 获取会话信息
            sessions = self._make_request(url, '/api/sessions', token)
            
            # 获取内核信息
            kernels = self._make_request(url, '/api/kernels', token)
            
            return {
                "server_url": url,
                "api_version": api_info,
                "active_sessions": len(sessions),
                "active_kernels": len(kernels),
                "sessions": sessions,
                "kernels": kernels
            }
        except Exception as e:
            raise Exception(f"获取服务器信息失败: {str(e)}")
    
    def list_notebooks(self, url: str, token: Optional[str]) -> List[Dict[str, Any]]:
        """列出所有笔记本"""
        try:
            # 获取内容 API
            contents = self._make_request(url, '/api/contents', token)
            
            notebooks = []
            
            def extract_notebooks(items, path=""):
                for item in items:
                    if item.get('type') == 'notebook':
                        notebooks.append({
                            'name': item.get('name'),
                            'path': item.get('path'),
                            'created': item.get('created'),
                            'last_modified': item.get('last_modified'),
                            'size': item.get('size', 0)
                        })
                    elif item.get('type') == 'directory':
                        # 递归查询子目录
                        sub_path = item.get('path', '')
                        try:
                            sub_contents = self._make_request(url, f'/api/contents/{sub_path}', token)
                            extract_notebooks(sub_contents.get('content', []), sub_path)
                        except:
                            continue
            
            extract_notebooks(contents.get('content', []))
            return notebooks
        except Exception as e:
            raise Exception(f"列出笔记本失败: {str(e)}")
    
    def create_notebook(self, url: str, token: Optional[str], path: str, kernel_name: str = "python3") -> Dict[str, Any]:
        """创建新笔记本"""
        try:
            notebook_data = {
                "type": "notebook",
                "content": {
                    "cells": [],
                    "metadata": {
                        "kernelspec": {
                            "display_name": "Python 3",
                            "language": "python",
                            "name": kernel_name
                        },
                        "language_info": {
                            "name": "python",
                            "version": "3.8.0"
                        }
                    },
                    "nbformat": 4,
                    "nbformat_minor": 4
                }
            }
            
            result = self._make_request(url, f'/api/contents/{path}', token, 'PUT', notebook_data)
            return result
        except Exception as e:
            raise Exception(f"创建笔记本失败: {str(e)}")
    
    def get_notebook_content(self, url: str, token: Optional[str], path: str) -> Dict[str, Any]:
        """获取笔记本内容"""
        try:
            content = self._make_request(url, f'/api/contents/{path}', token)
            return content
        except Exception as e:
            raise Exception(f"获取笔记本内容失败: {str(e)}")
    
    def execute_code(self, url: str, token: Optional[str], notebook_path: str, code: str) -> Dict[str, Any]:
        """执行代码"""
        try:
            # 首先获取或创建会话
            sessions = self._make_request(url, '/api/sessions', token)
            
            # 查找对应笔记本的会话
            session_id = None
            kernel_id = None
            
            for session in sessions:
                if session.get('path') == notebook_path:
                    session_id = session.get('id')
                    kernel_id = session.get('kernel', {}).get('id')
                    break
            
            # 如果没有找到会话，创建一个新的
            if not kernel_id:
                session_data = {
                    "path": notebook_path,
                    "type": "notebook",
                    "kernel": {
                        "name": "python3"
                    }
                }
                new_session = self._make_request(url, '/api/sessions', token, 'POST', session_data)
                kernel_id = new_session.get('kernel', {}).get('id')
            
            if not kernel_id:
                raise Exception("无法获取或创建内核")
            
            # 使用 WebSocket 执行代码（Jupyter Lab 的正确方式）
            ws_url = url.replace('http://', 'ws://').replace('https://', 'wss://')
            ws_endpoint = f"{ws_url}/api/kernels/{kernel_id}/channels"
            
            # 配置 WebSocket SSL 选项
            sslopt = {}
            if url.startswith('https://'):
                if not self.verify_ssl:
                    sslopt = {"cert_reqs": ssl.CERT_NONE}
                elif self.cert_path:
                    sslopt = {"ca_certs": self.cert_path}
            
            # 发送执行请求
            execute_message = {
                "header": {
                    "msg_id": f"execute_{int(time.time() * 1000)}",
                    "username": "mcp_user",
                    "session": kernel_id,
                    "msg_type": "execute_request",
                    "version": "5.3"
                },
                "parent_header": {},
                "metadata": {},
                "content": {
                    "code": code,
                    "silent": False,
                    "store_history": True,
                    "user_expressions": {},
                    "allow_stdin": False,
                    "stop_on_error": True
                },
                "buffers": [],
                "channel": "shell"
            }
            
            # 简化版本：直接返回执行请求信息
            return {
                "kernel_id": kernel_id,
                "code": code,
                "execution_status": "submitted",
                "message": "代码已提交执行，请查看 Jupyter Lab 界面获取结果",
                "notebook_path": notebook_path,
                "ws_endpoint": ws_endpoint,
                "ssl_configured": url.startswith('https://')
            }
            
        except Exception as e:
            raise Exception(f"执行代码失败: {str(e)}")
    
    def list_kernels(self, url: str, token: Optional[str]) -> List[Dict[str, Any]]:
        """列出所有内核"""
        try:
            kernels = self._make_request(url, '/api/kernels', token)
            return kernels
        except Exception as e:
            raise Exception(f"列出内核失败: {str(e)}")
    
    def restart_kernel(self, url: str, token: Optional[str], kernel_id: Optional[str] = None) -> Dict[str, Any]:
        """重启内核"""
        try:
            if kernel_id:
                # 重启指定内核
                result = self._make_request(url, f'/api/kernels/{kernel_id}/restart', token, 'POST')
                return {"kernel_id": kernel_id, "status": "restarted"}
            else:
                # 重启所有内核
                kernels = self.list_kernels(url, token)
                results = []
                for kernel in kernels:
                    kid = kernel.get('id')
                    if kid:
                        self._make_request(url, f'/api/kernels/{kid}/restart', token, 'POST')
                        results.append({"kernel_id": kid, "status": "restarted"})
                return {"restarted_kernels": results}
        except Exception as e:
            raise Exception(f"重启内核失败: {str(e)}")
    
    def get_kernel_info(self, url: str, token: Optional[str], kernel_id: str) -> Dict[str, Any]:
        """获取内核信息"""
        try:
            info = self._make_request(url, f'/api/kernels/{kernel_id}', token)
            return info
        except Exception as e:
            raise Exception(f"获取内核信息失败: {str(e)}")
    
    def delete_session(self, url: str, token: Optional[str], session_id: str) -> Dict[str, Any]:
        """删除会话"""
        try:
            self._make_request(url, f'/api/sessions/{session_id}', token, 'DELETE')
            return {"session_id": session_id, "status": "deleted"}
        except Exception as e:
            raise Exception(f"删除会话失败: {str(e)}")
    
    def download_file(self, url: str, token: Optional[str], file_path: str, local_path: Optional[str] = None) -> Dict[str, Any]:
        """通过内容 API 下载文件"""
        try:
            # 获取文件内容
            content = self._make_request(url, f'/api/contents/{file_path}', token)
            
            file_type = content.get('type', 'file')
            file_name = content.get('name', file_path.split('/')[-1])
            
            if file_type == 'file':
                # 普通文件
                file_content = content.get('content', '')
                format_type = content.get('format', 'text')
                
                if format_type == 'base64':
                    # 二进制文件（base64 编码）
                    file_data = base64.b64decode(file_content)
                else:
                    # 文本文件
                    file_data = file_content.encode('utf-8')
                
                # 确定本地保存路径
                if not local_path:
                    local_path = file_name
                
                # 保存文件到本地
                with open(local_path, 'wb') as f:
                    f.write(file_data)
                
                return {
                    "file_path": file_path,
                    "local_path": local_path,
                    "file_type": file_type,
                    "format": format_type,
                    "size": len(file_data),
                    "downloaded": True
                }
                
            elif file_type == 'notebook':
                # Jupyter 笔记本文件
                notebook_content = content.get('content', {})
                
                # 确定本地保存路径
                if not local_path:
                    local_path = file_name
                
                # 保存笔记本为 JSON 文件
                with open(local_path, 'w', encoding='utf-8') as f:
                    json.dump(notebook_content, f, ensure_ascii=False, indent=2)
                
                return {
                    "file_path": file_path,
                    "local_path": local_path,
                    "file_type": file_type,
                    "format": "json",
                    "cells": len(notebook_content.get('cells', [])),
                    "downloaded": True
                }
                
            elif file_type == 'directory':
                # 目录 - 不支持下载
                raise Exception(f"无法下载目录: {file_path}")
                
            else:
                raise Exception(f"不支持的文件类型: {file_type}")
                
        except Exception as e:
            raise Exception(f"下载文件失败: {str(e)}")
    
    def get_file_info(self, url: str, token: Optional[str], file_path: str) -> Dict[str, Any]:
        """获取文件信息（不下载内容）"""
        try:
            content = self._make_request(url, f'/api/contents/{file_path}', token)
            
            file_info = {
                "name": content.get('name'),
                "path": content.get('path'),
                "type": content.get('type'),
                "created": content.get('created'),
                "last_modified": content.get('last_modified'),
                "size": content.get('size', 0),
                "writable": content.get('writable', False)
            }
            
            if content.get('type') == 'file':
                file_info.update({
                    "format": content.get('format', 'text'),
                    "mimetype": content.get('mimetype', '')
                })
            elif content.get('type') == 'notebook':
                cells = content.get('content', {}).get('cells', [])
                file_info.update({
                    "format": "json",
                    "cells_count": len(cells),
                    "kernelspec": content.get('content', {}).get('metadata', {}).get('kernelspec', {})
                })
            
            return file_info
            
        except Exception as e:
            raise Exception(f"获取文件信息失败: {str(e)}")
    
    def list_directory_contents(self, url: str, token: Optional[str], dir_path: str = "") -> List[Dict[str, Any]]:
        """列出目录内容"""
        try:
            if dir_path:
                endpoint = f'/api/contents/{dir_path}'
            else:
                endpoint = '/api/contents'
                
            content = self._make_request(url, endpoint, token)
            
            if content.get('type') != 'directory':
                raise Exception(f"路径不是目录: {dir_path}")
            
            items = []
            for item in content.get('content', []):
                item_info = {
                    "name": item.get('name'),
                    "path": item.get('path'),
                    "type": item.get('type'),
                    "size": item.get('size', 0),
                    "created": item.get('created'),
                    "last_modified": item.get('last_modified')
                }
                items.append(item_info)
            
            return items
            
        except Exception as e:
            raise Exception(f"列出目录内容失败: {str(e)}")
