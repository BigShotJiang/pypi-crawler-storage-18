"""
Jupyter Lab MCP Server
提供远程控制 Jupyter Lab 的 MCP 服务
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional
from fastmcp import FastMCP
from pydantic import BaseModel, Field

# 导入 Jupyter 控制器
try:
    from .jupyter_controller import JupyterController
except ImportError:
    from jupyter_controller import JupyterController


# 创建 FastMCP 实例
mcp = FastMCP("Jupyter Lab MCP Server")


class ServerInfoRequest(BaseModel):
    """服务器信息请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class NotebookRequest(BaseModel):
    """笔记本操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    path: str = Field(..., description="笔记本路径")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class CreateNotebookRequest(BaseModel):
    """创建笔记本请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    path: str = Field(..., description="笔记本路径")
    kernel_name: str = Field(default="python3", description="内核名称")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class ExecuteCodeRequest(BaseModel):
    """执行代码请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    notebook_path: str = Field(..., description="笔记本路径")
    code: str = Field(..., description="要执行的代码")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class KernelRequest(BaseModel):
    """内核操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class FileRequest(BaseModel):
    """文件操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    file_path: str = Field(..., description="文件路径")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class DownloadFileRequest(BaseModel):
    """下载文件请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    file_path: str = Field(..., description="要下载的文件路径")
    local_path: Optional[str] = Field(default=None, description="本地保存路径（可选）")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


class DirectoryRequest(BaseModel):
    """目录操作请求"""
    url: str = Field(default="http://localhost:8888", description="Jupyter Lab 服务器地址")
    token: Optional[str] = Field(default=None, description="访问令牌")
    dir_path: str = Field(default="", description="目录路径，空字符串表示根目录")
    verify_ssl: bool = Field(default=True, description="是否验证 SSL 证书")
    cert_path: Optional[str] = Field(default=None, description="自定义证书路径")


# 初始化控制器（使用默认 SSL 配置）
controller = JupyterController()


def get_controller(request):
    """根据请求获取配置好的控制器"""
    return JupyterController(
        verify_ssl=request.verify_ssl,
        cert_path=request.cert_path
    )


@mcp.tool()
def get_server_info(request: ServerInfoRequest) -> str:
    """
    获取 Jupyter Lab 服务器信息
    
    返回服务器的状态、版本、运行会话等信息。
    支持 HTTPS 和自定义 SSL 证书配置。
    
    Args:
        request: 服务器信息请求
        
    Returns:
        JSON格式的服务器信息
    """
    try:
        ctrl = get_controller(request)
        info = ctrl.get_server_info(request.url, request.token)
        
        response = {
            "success": True,
            "server_info": info,
            "ssl_configured": request.url.startswith('https://'),
            "ssl_verified": request.verify_ssl
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def list_notebooks(request: ServerInfoRequest) -> str:
    """
    列出所有笔记本
    
    获取服务器上所有可用的笔记本文件列表。
    支持 HTTPS 和自定义 SSL 证书配置。
    
    Args:
        request: 服务器信息请求
        
    Returns:
        JSON格式的笔记本列表
    """
    try:
        ctrl = get_controller(request)
        notebooks = ctrl.list_notebooks(request.url, request.token)
        
        response = {
            "success": True,
            "notebooks": notebooks,
            "total": len(notebooks),
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def create_notebook(request: CreateNotebookRequest) -> str:
    """
    创建新笔记本
    
    在指定路径创建一个新的 Jupyter 笔记本。
    支持 HTTPS 和自定义 SSL 证书配置。
    
    Args:
        request: 创建笔记本请求
        
    Returns:
        JSON格式的创建结果
    """
    try:
        ctrl = get_controller(request)
        result = ctrl.create_notebook(
            request.url, 
            request.token, 
            request.path, 
            request.kernel_name
        )
        
        response = {
            "success": True,
            "notebook": result,
            "message": f"笔记本 {request.path} 创建成功",
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def get_notebook_content(request: NotebookRequest) -> str:
    """
    获取笔记本内容
    
    返回指定笔记本的完整内容，包括所有单元格。
    
    Args:
        request: 笔记本操作请求
        
    Returns:
        JSON格式的笔记本内容
    """
    try:
        content = controller.get_notebook_content(
            request.url, 
            request.token, 
            request.path
        )
        
        response = {
            "success": True,
            "notebook_content": content,
            "path": request.path
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def execute_code(request: ExecuteCodeRequest) -> str:
    """
    执行代码
    
    在指定笔记本中执行 Python 代码并返回结果。
    
    Args:
        request: 执行代码请求
        
    Returns:
        JSON格式的执行结果
    """
    try:
        result = controller.execute_code(
            request.url,
            request.token,
            request.notebook_path,
            request.code
        )
        
        response = {
            "success": True,
            "execution_result": result,
            "code": request.code,
            "notebook": request.notebook_path
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def list_kernels(request: KernelRequest) -> str:
    """
    列出所有内核
    
    获取服务器上所有可用的内核列表。
    
    Args:
        request: 内核操作请求
        
    Returns:
        JSON格式的内核列表
    """
    try:
        kernels = controller.list_kernels(request.url, request.token)
        
        response = {
            "success": True,
            "kernels": kernels,
            "total": len(kernels)
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def restart_kernel(request: KernelRequest) -> str:
    """
    重启内核
    
    重启指定服务器上的内核。
    
    Args:
        request: 内核操作请求
        
    Returns:
        JSON格式的重启结果
    """
    try:
        ctrl = get_controller(request)
        result = ctrl.restart_kernel(request.url, request.token)
        
        response = {
            "success": True,
            "message": "内核重启成功",
            "result": result,
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def download_file(request: DownloadFileRequest) -> str:
    """
    下载文件
    
    通过 Jupyter Lab 内容 API 下载文件到本地。
    支持文本文件、二进制文件和 Jupyter 笔记本。
    
    Args:
        request: 下载文件请求
        
    Returns:
        JSON格式的下载结果
    """
    try:
        ctrl = get_controller(request)
        result = ctrl.download_file(
            request.url,
            request.token,
            request.file_path,
            request.local_path
        )
        
        response = {
            "success": True,
            "download_result": result,
            "message": f"文件 {request.file_path} 下载成功到 {result.get('local_path')}",
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def get_file_info(request: FileRequest) -> str:
    """
    获取文件信息
    
    获取文件的详细信息，包括大小、类型、修改时间等，但不下载文件内容。
    
    Args:
        request: 文件操作请求
        
    Returns:
        JSON格式的文件信息
    """
    try:
        ctrl = get_controller(request)
        info = ctrl.get_file_info(request.url, request.token, request.file_path)
        
        response = {
            "success": True,
            "file_info": info,
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
def list_directory_contents(request: DirectoryRequest) -> str:
    """
    列出目录内容
    
    列出指定目录下的所有文件和子目录。
    
    Args:
        request: 目录操作请求
        
    Returns:
        JSON格式的目录内容列表
    """
    try:
        ctrl = get_controller(request)
        contents = ctrl.list_directory_contents(
            request.url, 
            request.token, 
            request.dir_path
        )
        
        response = {
            "success": True,
            "directory_path": request.dir_path or "/",
            "contents": contents,
            "total_items": len(contents),
            "ssl_configured": request.url.startswith('https://')
        }
        return json.dumps(response, ensure_ascii=False, indent=2)
    except Exception as e:
        error_response = {
            "success": False,
            "error": str(e),
            "data": None
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    mcp.run()


def main():
    """命令行入口点函数"""
    mcp.run()
