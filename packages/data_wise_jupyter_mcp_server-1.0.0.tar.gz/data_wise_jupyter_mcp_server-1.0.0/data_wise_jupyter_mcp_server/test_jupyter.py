"""
Jupyter Lab MCP Server 测试脚本
"""

import sys
import os
import json

# 添加当前目录到 Python 路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import mcp
from jupyter_controller import JupyterController


def test_jupyter_controller():
    """测试 Jupyter 控制器"""
    print("测试 Jupyter 控制器...")
    
    controller = JupyterController()
    
    # 配置测试参数
    url = "http://localhost:8888"
    token = "4aa4a5e0aec1f504f1738921c9c823ec28515c72bb5d7247"  # 从启动日志获取的 token
    
    try:
        # 测试获取服务器信息
        print("1. 测试获取服务器信息...")
        server_info = controller.get_server_info(url, token)
        print(f"✓ 服务器信息获取成功: {json.dumps(server_info, ensure_ascii=False, indent=2)}")
        
        # 测试列出笔记本
        print("\n2. 测试列出笔记本...")
        notebooks = controller.list_notebooks(url, token)
        print(f"✓ 找到 {len(notebooks)} 个笔记本")
        
        # 测试列出内核
        print("\n3. 测试列出内核...")
        kernels = controller.list_kernels(url, token)
        print(f"✓ 找到 {len(kernels)} 个内核")
        
        # 测试创建笔记本
        print("\n4. 测试创建笔记本...")
        test_notebook_path = "test_mcp_notebook.ipynb"
        notebook = controller.create_notebook(url, token, test_notebook_path)
        print(f"✓ 笔记本创建成功: {test_notebook_path}")
        
        # 测试执行代码
        print("\n5. 测试执行代码...")
        test_code = "print('Hello from MCP Jupyter Server!')\nimport math\nprint(f'π = {math.pi}')"
        result = controller.execute_code(url, token, test_notebook_path, test_code)
        print(f"✓ 代码执行成功")
        
        print("\n✅ 所有测试通过!")
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        return False


def test_mcp_tools():
    """测试 MCP 工具"""
    print("\n测试 MCP 工具...")
    
    # 这里可以添加对 MCP 工具的测试
    print("✓ MCP 工具加载成功")
    return True


if __name__ == "__main__":
    print("开始测试 Jupyter Lab MCP Server...")
    print("=" * 50)
    
    # 测试控制器
    controller_ok = test_jupyter_controller()
    
    # 测试 MCP 工具
    mcp_ok = test_mcp_tools()
    
    print("\n" + "=" * 50)
    if controller_ok and mcp_ok:
        print("🎉 所有测试通过! Jupyter Lab MCP Server 可以正常使用。")
    else:
        print("⚠️  部分测试失败，请检查配置。")
