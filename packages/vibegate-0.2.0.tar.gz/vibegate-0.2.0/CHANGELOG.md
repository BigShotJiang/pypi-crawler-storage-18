# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.2.0] - 2025-12-24

### Added
- **Automated semantic versioning** via python-semantic-release
- Pre-commit hooks with ruff, pyright, gitleaks, and conventional commits validation
- Commitlint GitHub Action for PR commit validation
- Release Drafter workflow for automatic release notes
- Hotfix workflow for emergency releases
- Branch protection setup script
- Comprehensive Makefile targets for development workflows
- Enhanced PR template with detailed checklist

### Changed
- **BREAKING**: Releases now fully automated based on conventional commits
- Deprecated manual prepare_release workflow
- Updated all documentation for automated release process
- Enhanced .gitignore with additional patterns
- Improved README with badges and automation documentation

### Improved
- Python + GitHub Actions dependency tracking via Dependabot
- Branch protection rules configured programmatically
- Complete release automation following industry best practices

## [0.1.0a5] - 2025-12-23

### Changed
- Prep for TestPyPI Trusted Publishing validation
- Documentation sync and CI pipeline stabilization

## [0.1.0a4] - 2025-12-23

### Changed
- Trusted Publishing setup and release workflow updates

## [0.1.0a3] - 2025-02-25

### Added
- Config profiles with deterministic merge order
- Plugin SDK with entry-point discovery for checks and emitters

## [0.1.0a2] - 2025-02-20

### Changed
- Relaxed runtime dependency pins to prevent adopter dependency downgrades
- Added clearer vibegate.yaml schema validation remediation guidance

## [0.1.0a1] - 2025-02-18

### Added
- Initial alpha release of VibeGate with deterministic gating CLI, evidence ledger, and fix pack output
