# funfedi_connect

FunFedi connect represents an unified query and verify code
for the Fediverse applications provided on 
[containers.funfedi.dev](https://containers.funfedi.dev/).
