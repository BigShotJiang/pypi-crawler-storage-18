# Changes

## 0.1.3

* Add repo link to docs [connect#1](https://codeberg.org/funfedidev/funfedi_connect/issues/1)
* Make parsing more reusable [runner#3](https://codeberg.org/funfedidev/funfedi_runner/issues/3)

## 0.1.2

* initial published version