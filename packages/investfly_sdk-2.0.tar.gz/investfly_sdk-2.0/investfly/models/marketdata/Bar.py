from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import TypedDict, List


class BarInterval(str, Enum):
    """ Enum to represent BarInterval """
    ONE_MINUTE = "ONE_MINUTE"
    FIVE_MINUTE = "FIVE_MINUTE"
    FIFTEEN_MINUTE = "FIFTEEN_MINUTE"
    THIRTY_MINUTE = "THIRTY_MINUTE"
    SIXTY_MINUTE = "SIXTY_MINUTE"
    ONE_DAY = "ONE_DAY"

    def getMinutes(self) -> int:
        if self == BarInterval.ONE_MINUTE:
            return 1
        elif self == BarInterval.FIVE_MINUTE:
            return 5
        elif self == BarInterval.FIFTEEN_MINUTE:
            return 15
        elif self == BarInterval.THIRTY_MINUTE:
            return 30
        elif self == BarInterval.SIXTY_MINUTE:
            return 60
        else:
            return 24 * 60


Bar = TypedDict("Bar", {"symbol": str,
                        "barinterval": BarInterval,
                        "date": datetime,
                        "open": float,
                        "close": float,
                        "high": float,
                        "low": float,
                        "volume": int
                        })


class BarsGroup:
    def __init__(self, barInterval: BarInterval):
        self.barInterval = barInterval
        # The bars are expected to be for different symbol but for the same time. This class should not be used
        # to hold bars for one symbol from CSV for differerent times
        self.bars: List[Bar] = []

    def addBars(self, bars: List[Bar]):
        for b in bars:
            self.addBar(b)

    def addBar(self, bar: Bar):
        if bar['barinterval'] != self.barInterval:
            raise Exception(f"BarInterval of this bar {bar['barinterval']} does not match of the group {self.barInterval}")
        self.bars.append(bar)

    def size(self) -> int:
        return len(self.bars)

    def __str__(self) -> str:
        return f'BarInterval={self.barInterval}, Bars={len(self.bars)}'

