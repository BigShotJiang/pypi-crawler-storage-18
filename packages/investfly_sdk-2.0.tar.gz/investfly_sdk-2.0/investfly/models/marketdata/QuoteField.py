from enum import Enum


class QuoteField(str, Enum):
    """ Enum of all valid fields on Quote object """
    # ------ Quote ---
    LASTPRICE = "LASTPRICE"
    DAY_OPEN = "DAY_OPEN"
    DAY_HIGH = "DAY_HIGH"
    DAY_LOW = "DAY_LOW"
    DAY_VOLUME = "DAY_VOLUME"
    PREV_DAY_CLOSE = "PREV_DAY_CLOSE"
    DAY_CHANGE = "DAY_CHANGE"
    DAY_CHANGE_PCT = "DAY_CHANGE_PCT"
    DAY_CHANGE_OPEN = "DAY_CHANGE_OPEN"

