from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any, cast, TYPE_CHECKING

from investfly.models.common.DatedValue import DatedValue
from investfly.models.marketdata.QuoteField import QuoteField

if TYPE_CHECKING:
    from investfly.models.marketdata.Bar import Bar, BarInterval


def parseDatetime(date_str: str) -> datetime:
    from investfly.models.common.ModelUtils import ModelUtils
    return datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S.%f%z').astimezone(ModelUtils.est_zone)


def formatDatetime(dt: datetime) -> str:
    return dt.strftime('%Y-%m-%dT%H:%M:%S.%f%z')


@dataclass
class Quote:
    """ Class representing Price Quote """
    symbol: str
    date: datetime
    lastPrice: float
    prevClose: float | None = None
    todayChange: float | None = None
    todayChangePct: float | None = None
    dayOpen: float | None = None
    dayHigh: float | None = None
    dayLow: float | None = None
    volume: int | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> Quote:
        quote = Quote(jsonDict["symbol"], parseDatetime(jsonDict["date"]), jsonDict["lastPrice"])
        quote.prevClose = jsonDict.get('prevClose')
        quote.todayChange = jsonDict.get("todayChange")
        quote.todayChangePct = jsonDict.get('todayChangePct')
        quote.dayOpen = jsonDict.get('dayOpen')
        quote.dayHigh = jsonDict.get('dayHigh')
        quote.dayLow = jsonDict.get('dayLow')
        quote.volume = jsonDict.get('volume')
        return quote

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        jsonDict["date"] = formatDatetime(self.date)
        return jsonDict

    def toIndicatorValue(self, quoteField: QuoteField) -> DatedValue:
        if quoteField == QuoteField.LASTPRICE:
            return DatedValue(self.date, self.lastPrice)
        elif quoteField == QuoteField.DAY_OPEN:
            if self.dayOpen is None:
                raise Exception("DAY_OPEN price not available in Quote")
            return DatedValue(self.date, self.dayOpen)
        elif quoteField == QuoteField.DAY_HIGH:
            if self.dayHigh is None:
                raise Exception("DAY_HIGH price not available in Quote")
            return DatedValue(self.date, self.dayHigh)
        elif quoteField == QuoteField.DAY_LOW:
            if self.dayLow is None:
                raise Exception("DAY_LOW price not available in Quote")
            return DatedValue(self.date, self.dayLow)
        elif quoteField == QuoteField.PREV_DAY_CLOSE:
            if self.prevClose is None:
                raise Exception("PREV_DAY_CLOSE price not available in Quote")
            return DatedValue(self.date, self.prevClose)
        elif quoteField == QuoteField.DAY_CHANGE:
            if self.todayChange is None:
                raise Exception("DAY_CHANGE not available in Quote")
            return DatedValue(self.date, self.todayChange)
        elif quoteField == QuoteField.DAY_CHANGE_PCT:
            if self.todayChangePct is None:
                raise Exception("DAY_CHANGE_PCT value not available in Quote")
            return DatedValue(self.date, self.todayChangePct)
        elif quoteField == QuoteField.DAY_VOLUME:
            if self.volume is None:
                raise Exception("DAY_VOLUME not available in Quote")
            return DatedValue(self.date, self.volume)
        elif quoteField == QuoteField.DAY_CHANGE_OPEN:
            if self.dayOpen is None or self.lastPrice is None:
                raise Exception("DAY_CHANGE_OPEN not available in Quote")
            return DatedValue(self.date, self.lastPrice - self.dayOpen)
        else:
            raise Exception("Invalid Quote Indicator ID: " + quoteField)

    def toEODBar(self) -> Bar:
        from investfly.models.marketdata.Bar import Bar, BarInterval
        return Bar(
            symbol=self.symbol,
            barinterval=BarInterval.ONE_DAY,
            date=self.date.replace(second=0, microsecond=0),
            open=cast(float, self.dayOpen),
            high=cast(float, self.dayHigh),
            low=cast(float, self.dayLow),
            close=cast(float, self.lastPrice),
            volume=cast(int, self.volume)
        )

