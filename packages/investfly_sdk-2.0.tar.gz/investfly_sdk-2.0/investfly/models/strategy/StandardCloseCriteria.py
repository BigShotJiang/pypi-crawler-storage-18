from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from investfly.models.common.TimeDelta import TimeDelta


@dataclass
class StandardCloseCriteria:
    targetProfit: float | None  # specify in scaled [0 - 100 range]
    stopLoss: float | None  # specify as negative
    trailingStop: float | None  # specify as negative
    timeOut: TimeDelta | None

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> StandardCloseCriteria:
        return StandardCloseCriteria(
            json_dict.get('targetProfit'),
            json_dict.get('stopLoss'),
            json_dict.get('trailingStop'),
            TimeDelta.fromDict(json_dict['timeout']) if 'timeout' in json_dict else None
        )

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        if self.timeOut is not None:
            jsonDict['timeout'] = self.timeOut.toDict()
        return jsonDict

    def defined(self) -> bool:
        return (
            self.targetProfit is not None or
            self.stopLoss is not None or
            self.trailingStop is not None or
            self.timeOut is not None
        )

    def validate(self) -> None:
        if self.targetProfit is not None and self.targetProfit < 0:
            raise Exception("targetProfit must be positive")
        if self.stopLoss is not None and self.stopLoss > 0:
            raise Exception("stopLoss must be negative")
        if self.trailingStop is not None and self.trailingStop > 0:
            raise Exception("trailingStop must be negative")
