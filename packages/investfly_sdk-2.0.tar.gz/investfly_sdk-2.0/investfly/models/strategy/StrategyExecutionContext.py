"""Strategy execution context.

This module defines the StrategyExecutionContext dataclass that provides
deployment-specific context data to strategy instances during execution.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.Portfolio import Portfolio


@dataclass
class StrategyExecutionContext:
    """Execution context for a strategy instance.
    
    The execution context contains per-execution data that is specific to a
    strategy deployment. This context is created by the execution engine and
    injected into strategy instances before their methods are called.

    The context provides deployment-agnostic access to:
    - Portfolio state (positions, balances, performance)
    - Universe securities (resolved list of securities to evaluate)

    Attributes:
        portfolio: The current portfolio state containing:
            - Open and closed positions
            - Account balances (cash, equity, total value)
            - Portfolio performance metrics
        universeSecurities: List of Security objects representing all
            securities in the strategy's trading universe. This is the resolved
            list based on the security universe selector returned by
            `TradingStrategy.getSecurityUniverseSelector()`.

    Example:
        The execution engine creates and injects the context:

        ```python
        context = StrategyExecutionContext(
            portfolio=current_portfolio,
            universeSecurities=resolved_securities
        )
        strategy.setContext(context)
        ```

        Strategies access context data via convenience methods:

        ```python
        portfolio = self.getPortfolio()
        universe = self.getUniverseSecurities()
        ```
    """
    portfolio: Portfolio
    universeSecurities: List[Security]
    currentTime: datetime
