from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from investfly.models.portfolio.Portfolio import Portfolio
from investfly.models.strategy.TradeSignal import TradeSignal
from investfly.models.portfolio.TradeOrder import TradeOrder


class PortfolioSecurityAllocator(ABC):

    @abstractmethod
    def allocatePortfolio(self, portfolio: Portfolio, tradeSignals: List[TradeSignal]) -> List[TradeOrder]:
        pass

