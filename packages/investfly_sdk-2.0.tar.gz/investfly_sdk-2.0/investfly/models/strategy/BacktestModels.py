from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any

from investfly.models.portfolio.PortfolioPerformance import PortfolioPerformance


class BacktestStatus(str, Enum):
    NOT_STARTED = "NOT_STARTED",
    QUEUED = "QUEUED",
    INITIALIZING = "INITIALIZING",
    RUNNING = "RUNNING"
    COMPLETE = "COMPLETE"
    ERROR = "ERROR"


@dataclass
class BacktestResultStatus:
    jobStatus: BacktestStatus
    percentComplete: int

    def toDict(self) -> Dict[str, Any]:
        dict = self.__dict__.copy()
        return dict

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> BacktestResultStatus:
        status = BacktestStatus[json_dict['jobStatus']]
        percentComplete = json_dict['percentComplete']
        return BacktestResultStatus(status, percentComplete)


@dataclass
class BacktestResult:
    status: BacktestResultStatus
    performance: PortfolioPerformance

    def toDict(self) -> Dict[str, Any]:
        dict = self.__dict__.copy()
        dict['performance'] = self.performance.toDict()
        return dict

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> BacktestResult:
        status = BacktestResultStatus.fromDict(json_dict['status'])
        performance = PortfolioPerformance.fromDict(json_dict['performance'])
        return BacktestResult(status, performance)

