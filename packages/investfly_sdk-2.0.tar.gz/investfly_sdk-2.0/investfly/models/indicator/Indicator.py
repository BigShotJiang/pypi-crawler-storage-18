from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from investfly.models.common.DatedValue import DatedValue
from investfly.models.marketdata.Bar import BarInterval
from investfly.models.strategy.DataParams import DataSource, DataParam
from investfly.models.indicator.IndicatorSpec import IndicatorSpec
from investfly.models.indicator.IndicatorParamSpec import IndicatorParamSpec
from investfly.models.indicator.IndicatorEnums import ParamType, IndicatorValueType, StandardParams


class Indicator(ABC):
    """
    The primary class to implement a custom Indicator. A Custom Indicator is like standard indicator (e.g SMA, RSI)
    and can be used in any place that standard indicator can be used (e.g screener, charts, strategy etc)
    Investfly comes with a set of standard indicators. If you find that the indicator you want is not supported
    or you can a small variation (e.g SMA but with using Heikin Ashi Candles), then you can use this function
    """

    @abstractmethod
    def getIndicatorSpec(self) -> IndicatorSpec:
        """Return IndicatorSpec with name, description, required params, and valuetype.
        
        See IndicatorSpec abstract class for more details.
        
        Returns:
            `IndicatorSpec`: The indicator specification object.
        """

        pass

    def getDataSourceType(self) -> DataSource:
        """Return the DataSource that this indicator is based on.
        
        Possible values are:
        - `DataSource.BARS`
        - `DataSource.QUOTE`
        - `DataSource.NEWS`
        - `DataSource.FINANCIAL`
        
        Returns:
            `DataSource`: The data source type for this indicator.
        """

        return DataSource.BARS

    @abstractmethod
    def computeSeries(self, params: Dict[str, Any], data: List[Any]) -> List[DatedValue]:
        """Compute indicator series based on provided input timed data series and parameter values.
        
        This function must return List of indicator values instead of only the most recent single value because indicator
        series is required to plot in the price chart and also to use in backtest.
        
        The timestamps in the `DatedValue` must correspond to timestamps in input data.
        The length of input data depends on context (e.g., is this indicator being evaluated for backtest or screener?)
        and `dataCountToComputeCurrentValue` function below.

        Args:
            params: User supplied indicator parameter values. The keys match the keys from `IndicatorSpec.params`.
            data: List of timed data values as specified in `Indicator.getDataSourceType`.
            
        Returns:
            List of `DatedValue` representing indicator values for each time unit.
        """

        pass

    def dataCountToComputeCurrentValue(self, params: Dict[str, Any]) -> int | None:
        """Determine how many input data points are needed to compute the current indicator value.
        
        When this indicator is used in screener and trading strategy when evaluated in real-time, only
        the "current" value of the indicator is required. The historical values are NOT required. Therefore,
        when the system calls `computeSeries` above with all available data (e.g., 10 years of historical bars),
        then it is unnecessarily slow and wasteful. This function is used to control the size of input data
        that will be passed to `computeSeries` method above.

        The default implementation tries to make the best guess, but override as needed.

        Args:
            params: User supplied input parameter values.
            
        Returns:
            Integer representing how many input data points are required to compute the 'current' indicator value.
            For example, if this was SMA indicator with period=5, then you should return 5.
        """
        total = 0
        for key, value in params.items():
            if isinstance(value, int) and key != StandardParams.COUNT:
                total += value
        return max(total, 1)

    def validateParams(self, paramVals: Dict[str, Any]):
        spec: IndicatorSpec = self.getIndicatorSpec()
        for paramName, paramSpec in spec.params.items():
            paramVal: Any = paramVals.get(paramName)
            expectedParamType = paramSpec.paramType

            if paramVal is not None:
                if expectedParamType == ParamType.INTEGER and not isinstance(paramVal, int):
                    raise Exception(f"Param {paramName} must be of type int. You provided: {paramVal}")
                if expectedParamType == ParamType.FLOAT and not isinstance(paramVal, float) and isinstance(paramVal, int):
                    raise Exception(f"Param {paramName} must be of type float. You provided: {paramVal}")
                if expectedParamType == ParamType.STRING and not isinstance(paramVal, str):
                    raise Exception(f"Param {paramName} must be of type string. You provided: {paramVal}")
                if expectedParamType == ParamType.BOOLEAN and not isinstance(paramVal, bool):
                    raise Exception(f"Param {paramName} must be of type boolean. You provided: {paramVal}")
                if expectedParamType == ParamType.BOOLEAN and not isinstance(paramVal, bool):
                    raise Exception(f"Param {paramName} must be of type boolean. You provided: {paramVal}")
                if expectedParamType == ParamType.BARINTERVAL and not isinstance(paramVal, BarInterval):
                    raise Exception(f"Param {paramName} must be of type BarInterval. You provided: {paramVal}")

                if paramSpec.options is not None:
                    if paramVal not in paramSpec.options:
                        raise Exception(f"Param {paramName} provided value {paramVal} is not one of the allowed value")

    def addStandardParamsToDef(self, indicatorDef: IndicatorSpec):
        from investfly.models.indicator.IndicatorParamSpec import IndicatorParamSpec
        # Note that setting default values for optional params impact alias/key generation for indicator instances (e.g SMA_5_1MIN_1)
        # Hence, its better to leave them as None
        indicatorDef.params[StandardParams.COUNT] = IndicatorParamSpec(ParamType.INTEGER, False, None)
        indicatorDef.params[StandardParams.LOOKBACK] = IndicatorParamSpec(ParamType.INTEGER, False, None, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        indicatorDef.params[StandardParams.SECURITY] = IndicatorParamSpec(ParamType.STRING, False)

        # Add datasource dependent parameters
        dataSource = self.getDataSourceType()
        if dataSource == DataSource.BARS:
            indicatorDef.params[StandardParams.BARINTERVAL] = IndicatorParamSpec(ParamType.BARINTERVAL, True, BarInterval.ONE_MINUTE, [v for v in BarInterval])
        elif dataSource == DataSource.FINANCIAL or dataSource == DataSource.QUOTE:
            # Its optional because in the absense of field, indicator.computeSeries() will be passed full FinancialDict
            indicatorDef.params[StandardParams.FIELD] = IndicatorParamSpec(ParamType.STRING, False)

