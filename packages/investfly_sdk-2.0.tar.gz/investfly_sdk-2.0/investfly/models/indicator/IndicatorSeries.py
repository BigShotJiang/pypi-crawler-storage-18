from __future__ import annotations

from typing import List

from investfly.models.common.DatedValue import DatedValue


class IndicatorSeries:
    """
    Represents a series of indicator values over time.
    Provides methods to access the latest value and detect crossovers.
    """
    
    @property
    def last(self) -> DatedValue:
        """
        Get the most recent indicator value.
        
        Returns:
            DatedValue: The latest indicator value with its timestamp
        """
        raise NotImplementedError("Subclasses must implement last property")
    
    def cross_over(self, other: 'IndicatorSeries') -> bool:
        """
        Check if this indicator series crosses above another indicator series.
        
        Returns True only on the bar/tick where self crosses above other.
        This means:
        - Previous bar: self < other
        - Current bar: self > other
        
        Args:
            other: Another IndicatorSeries to compare against
            
        Returns:
            bool: True if crossover occurred on the current bar/tick, False otherwise
        """
        raise NotImplementedError("Subclasses must implement cross_over method")
    
    def cross_under(self, other: 'IndicatorSeries') -> bool:
        """
        Check if this indicator series crosses below another indicator series.
        
        Returns True only on the bar/tick where self crosses below other.
        This means:
        - Previous bar: self > other
        - Current bar: self < other
        
        Args:
            other: Another IndicatorSeries to compare against
            
        Returns:
            bool: True if crossunder occurred on the current bar/tick, False otherwise
        """
        raise NotImplementedError("Subclasses must implement cross_under method")
    
    def toList(self) -> List[DatedValue]:
        """
        Get all indicator values as a list.
        
        Returns:
            List[DatedValue]: List of all indicator values, ordered from oldest to newest
        """
        raise NotImplementedError("Subclasses must implement toList method")

