from enum import Enum


class ParamType(str, Enum):

    """ Indicator Param Type """

    INTEGER = 'INTEGER'
    FLOAT = 'FLOAT'
    BOOLEAN = 'BOOLEAN'
    STRING = 'STRING'
    BARINTERVAL = 'BARINTERVAL'

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class IndicatorValueType(str, Enum):
    """
    Indicator ValueType can possibly used by Investfly to validate expression and optimize experience for users
    For e.g, all Indicators of same valueType can be plotted in the same y-axis
    """

    PRICE = "PRICE"

    # Values that ranges from 0-100
    PERCENT = "PERCENT"

    # Values that ranges from 0-1
    RATIO = "RATIO"

    # The value must be 0 or 1
    BOOLEAN = "BOOLEAN"

    # For arbitrary numeric value, use NUMBER, which is also the default
    NUMBER = "NUMBER"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class IndicatorId(str, Enum):
    """Technical indicators supported by Investfly.
    
    This enum lists all standard technical indicators that can be used in trading
    strategies for technical analysis. The enum values are string identifiers that
    must be used when calling computeIndicatorSeries() in DataService.
    
    Note: The enum values are strings (not the enum names) to support both standard
    and custom indicators. When using standard indicators, use the .value property
    or the string directly (e.g., "SMA" or StandardIndicatorId.SMA.value).
    """

    # Works by default on DAILY bars
    AVGVOL = "AVGVOLUME"
    HIGH_52_WEEK = "HIGH52WEEK"
    LOW_52_WEEK = "LOW52WEEK"
    LASTBAR = "LASTBAR"

    DRAWDOWN = "DRAWDOWN"
    PERCENTCHANGE = "PRICECHANGEPCT"

    # Moving Averages
    SMA = "SMA"                    # Simple Moving Average
    EMA = "EMA"                    # Exponential Moving Average
    TEMA = "TEMA"                  # Triple Exponential Moving Average
    DEMA = "DEMA"                  # Double Exponential Moving Average
    KAMA = "KAMA"                  # Kaufman Adaptive Moving Average
    MAMA = "MAMA"                  # MESA Adaptive Moving Average
    FAMA = "FAMA"                  # Following Adaptive Moving Average

    # Trend Indicators
    MACD = "MACD"                  # Moving Average Convergence/Divergence
    MACDS = "MACDS"                # MACD Signal Line
    ADX = "ADX"                    # Average Directional Index
    ADXR = "ADXR"                  # Average Directional Movement Index Rating
    PLUS_DI = "PLUS_DI"            # Plus Directional Indicator
    MINUS_DI = "MINUS_DI"          # Minus Directional Indicator
    DX = "DX"                      # Directional Movement Index
    PSAR = "PSAR"                  # Parabolic SAR
    TRIX = "TRIX"                  # Triple Exponential Moving Average Oscillator
    ICHIMOKU = "ICHIMOKU"          # Ichimoku Conversion Line
    KELTNER = "KELTNER"            # Keltner Channel Middle Line

    # Momentum Indicators
    RSI = "RSI"                    # Relative Strength Index
    ROC = "ROC"                    # Rate of Change
    CCI = "CCI"                    # Commodity Channel Index
    CMO = "CMO"                    # Chande Momentum Oscillator
    CMO_SMOOTHED = "CMO_SMOOTHED"  # Smoothed CMO
    PPO = "PPO"                    # Percentage Price Oscillator
    APO = "APO"                    # Absolute Price Oscillator
    ULTIMATE_OSC = "ULTIMATE_OSC"  # Ultimate Oscillator
    BOP = "BOP"                    # Balance of Power

    # Oscillators
    WILLIAM_R = "WILLIAM_R"        # Williams' %R
    STOCHASTICS = "STOCHASTICS"    # Stochastic (composite, for charts only)
    FAST_STOCHASTIC_OSC = "FAST_STOCHASTIC_OSC"  # Fast Stochastic Oscillator
    SLOW_STOCHASTIC_OSC = "SLOW_STOCHASTIC_OSC"  # Slow Stochastic Oscillator
    STOCH = "STOCH"                # Stochastic
    STOCHF = "STOCHF"              # Stochastic Fast
    STOCHRSI = "STOCHRSI"          # Stochastic RSI
    AROONOSC = "AROONOSC"          # Aroon Oscillator
    AROON = "AROON"                # Aroon Up
    AROONDOWN = "AROONDOWN"        # Aroon Down
    MFI = "MFI"                    # Money Flow Index

    # Volatility Indicators
    ATR = "ATR"                    # Average True Range
    STD_DEV = "STD_DEV"            # Standard Deviation
    BBAND = "BBAND"                # Bollinger Bands (composite, for charts only)
    UPPER_BBAND = "UPPER_BBAND"    # Upper Bollinger Band
    LOWER_BBAND = "LOWER_BBAND"    # Lower Bollinger Band
    UPPERBBAND = "UPPERBBAND"      # Upper Bollinger Band (alternative naming)
    LOWERBBAND = "LOWERBBAND"      # Lower Bollinger Band (alternative naming)

    # Volume Indicators
    OBV = "OBV"                    # On Balance Volume
    CMF = "CMF"                    # Chaikin Money Flow
    VWAP = "VWAP"                  # Volume Weighted Average Price
    RVOL = "RVOL"                  # Relative Volume

    # Price Transform
    AVGPRICE = "AVGPRICE"          # Average Price
    MEDIAN_PRICE = "MEDIAN_PRICE"  # Median Price
    MEDPRICE = "MEDPRICE"          # Median Price (alternative naming)
    TYPICAL_PRICE = "TYPICAL_PRICE"  # Typical Price
    TYPPRICE = "TYPPRICE"          # Typical Price (alternative naming)
    WCLPRICE = "WCLPRICE"          # Weighted Close Price
    BARPRICE = "BARPRICE"          # Bar Price (custom)

    # Statistical Functions
    MAX = "MAX"                    # Maximum value over period
    MIN = "MIN"                    # Minimum value over period

    # Candlestick Patterns
    DOJI = "DOJI"                  # Doji
    CDLDOJI = "CDLDOJI"            # Doji (alternative naming)
    HAMMER = "HAMMER"              # Hammer
    CDLHAMMER = "CDLHAMMER"        # Hammer (alternative naming)
    INVERTED_HAMMER = "INVERTED_HAMMER"  # Inverted Hammer
    DRAGONFLY_DOJI = "DRAGONFLY_DOJI"    # Dragonfly Doji
    GRAVESTONE_DOJI = "GRAVESTONE_DOJI"  # Gravestone Doji
    HANGING_MAN = "HANGING_MAN"    # Hanging Man
    CDLENGULFING = "CDLENGULFING"  # Engulfing Pattern
    CDLMORNINGSTAR = "CDLMORNINGSTAR"    # Morning Star
    CDLEVENINGSTAR = "CDLEVENINGSTAR"    # Evening Star
    CDLHARAMI = "CDLHARAMI"        # Harami Pattern
    CDLSHOOTINGSTAR = "CDLSHOOTINGSTAR"  # Shooting Star
    CDL3BLACKCROWS = "CDL3BLACKCROWS"    # Three Black Crows
    CDL3WHITESOLDIERS = "CDL3WHITESOLDIERS"  # Three White Soldiers
    CDLMARUBOZU = "CDLMARUBOZU"   # Marubozu
    BULLISH = "BULLISH"            # Bullish pattern
    BEARISH = "BEARISH"            # Bearish pattern

    # Support/Resistance
    SUPPORT = "SUPPORT"            # Support level
    RESISTANCE = "RESISTANCE"      # Resistance level

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class StandardParams(str, Enum):
    """Standard/common parameters used across multiple indicators.
    
    These parameters are common to many indicators and can be referenced
    using StandardParams instead of indicator-specific parameter enums.
    """
    
    COUNT = "count"
    LOOKBACK = "lookback"
    SECURITY = "security"
    BARINTERVAL = "barinterval"
    FIELD = "field"
    
    def __str__(self):
        return self.value
    
    def __repr__(self):
        return self.value


class IndicatorParam:

    class SMA:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class EMA:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class TEMA:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class DEMA:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class KAMA:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class MAMA:
        FAST_LIMIT = "fast_limit"
        SLOW_LIMIT = "slow_limit"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_limit", "slow_limit", "barinterval"]
    
    class FAMA:
        FAST_LIMIT = "fast_limit"
        SLOW_LIMIT = "slow_limit"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_limit", "slow_limit", "barinterval"]
    
    class UPPERBBAND:
        PERIOD = "period"
        STDDEV = "std_dev"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "std_dev", "barinterval"]
    
    class LOWERBBAND:
        PERIOD = "period"
        STDDEV = "std_dev"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "std_dev", "barinterval"]
    
    class ICHIMOKU:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class KELTNER:
        PERIOD = "period"
        MULTIPLIER = "multiplier"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "multiplier", "barinterval"]
    
    class MACD:
        FAST_PERIOD = "fast_period"
        SLOW_PERIOD = "slow_period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_period", "slow_period", "barinterval"]
    
    class MACDS:
        FAST_PERIOD = "fast_period"
        SLOW_PERIOD = "slow_period"
        SIGNAL_PERIOD = "signal_period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_period", "slow_period", "signal_period", "barinterval"]
    
    class RSI:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class ROC:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class CCI:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class ADX:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class ADXR:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class AROONOSC:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class AROON:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class AROONDOWN:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class MFI:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class CMO:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class STOCH:
        FASTK_PERIOD = "fastk_period"
        SLOWK_PERIOD = "slowk_period"
        SLOWD_PERIOD = "slowd_period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fastk_period", "slowk_period", "slowd_period", "barinterval"]
    
    class STOCHF:
        FASTK_PERIOD = "fastk_period"
        FASTD_PERIOD = "fastd_period"
        FASTD_MATYPE = "fastd_matype"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fastk_period", "fastd_period", "fastd_matype", "barinterval"]
    
    class STOCHRSI:
        TIMEPERIOD = "timeperiod"
        FASTK_PERIOD = "fastk_period"
        FASTD_PERIOD = "fastd_period"
        FASTD_MATYPE = "fastd_matype"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["timeperiod", "fastk_period", "fastd_period", "fastd_matype", "barinterval"]
    
    class APO:
        FAST_PERIOD = "fast_period"
        SLOW_PERIOD = "slow_period"
        MATYPE = "matype"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_period", "slow_period", "matype", "barinterval"]
    
    class PPO:
        FAST_PERIOD = "fast_period"
        SLOW_PERIOD = "slow_period"
        MATYPE = "matype"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["fast_period", "slow_period", "matype", "barinterval"]
    
    class MINUS_DI:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class PLUS_DI:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class DX:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class TRIX:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class CMF:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class AVGVOL:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class VWAP:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class RVOL:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class ATR:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class MAX:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class MIN:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]
    
    class LASTBAR:
        FIELD = "field"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["field", "barinterval"]
    
    class CDLMORNINGSTAR:
        PENETRATION = "penetration"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["penetration", "barinterval"]
    
    class CDLEVENINGSTAR:
        PENETRATION = "penetration"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["penetration", "barinterval"]
    
    class PSAR:
        ACCELERATION = "acceleration"
        MAXIMUM = "maximum"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["acceleration", "maximum", "barinterval"]
    
    class WILLIAMR:
        PERIOD = "period"
        BARINTERVAL = "barinterval"
        ALL_PARAMS = ["period", "barinterval"]

