from __future__ import annotations

from typing import Any, Dict

from investfly.models.indicator.IndicatorEnums import IndicatorValueType
from investfly.models.indicator.IndicatorParamSpec import IndicatorParamSpec


class IndicatorSpec:

    def __init__(self, name: str) -> None:
        # indicatorId is automatically set to clazz name of the indicator implementation
        self.indicatorId: str

        self.name: str = name

        # Description is defaulted to name for simplicity but can be set properly after instantiation
        self.description: str = name

        self.valueType: IndicatorValueType = IndicatorValueType.NUMBER
        self.params: Dict[str, IndicatorParamSpec] = {}

    def addParam(self, paramName: str, paramSpec: IndicatorParamSpec) -> None:
        self.params[paramName] = paramSpec

    def toJsonDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        # IndicatorParamSpec.toDict() must be called
        paramsDict = {}
        for paramName in self.params.keys():
            paramsDict[paramName] = self.params[paramName].toDict()
        jsonDict['params'] = paramsDict
        return jsonDict

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> IndicatorSpec:
        name = json_dict['name']
        indicatorSpec: IndicatorSpec = IndicatorSpec(name)
        indicatorSpec.indicatorId = json_dict['indicatorId']
        indicatorSpec.description = json_dict['description']
        indicatorSpec.valueType = IndicatorValueType[json_dict['valueType']]
        for key, value in json_dict['params'].items():
            indicatorSpec.params[key] = IndicatorParamSpec.fromDict(value)
        return indicatorSpec

    def validate(self) -> None:
        """Validate that required fields are provided and have correct types"""
        if len(self.name) == 0:
            raise Exception("IndicatorSpec.Name is required")
        
        if len(self.description) == 0:
            raise Exception("IndicatorSpec.Description is required")
        
        if self.valueType is None:
            raise Exception("ERROR - IndicatorSpec.valueType is required")
        
        if not isinstance(self.valueType, IndicatorValueType):
            raise Exception("IndicatorSpec.valueType must be of IndicatorValueType enum")
        
        if self.params is None:
            raise Exception("IndicatorSpec.params is required")
        
        if len(self.params) == 0:
            raise Exception("IndicatorSpec.params must have at least one parameter")
        
        if not isinstance(self.params, dict):
            raise Exception("IndicatorSpec.params must be of type dict")
        
        for pname, ptype in self.params.items():
            if not isinstance(pname, str):
                raise Exception("ParamName for " + str(pname) + " must be of type str")
            if not isinstance(ptype, IndicatorParamSpec):
                raise Exception("Param Type for " + pname + " must be of type IndicatorParamSpec")

    def __str__(self):
        return str(self.__dict__)

