from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, ClassVar

from investfly.models.indicator.IndicatorEnums import ParamType


@dataclass
class IndicatorParamSpec:

    """ Class that represents Indicator Parameter Specification """

    paramType: ParamType
    """ Parameter Type (INTEGER, FLOAT, BOOLEAN, STRING, BARINTERVAL) """

    required: bool = True
    """ Whether this parameter is required or optional"""

    # The default value here is just a "hint" to the UI to auto-fill indicator value with reasonable default
    defaultValue: Any | None = None
    """ The default value for the parameter to auto-populate mainly in UI """

    options: List[Any] | None = None
    """ Valid value options (if any). If specified, then in the UI, this parameter renders as a dropdown select list.
    If left as None, parameter renders and freeform input text field. """

    PERIOD_VALUES: ClassVar[List[int]] = [2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15, 20, 24, 26, 30, 40, 50, 60, 70, 80, 90, 100, 120, 130, 140, 150, 180, 200, 250, 300]

    def toDict(self) -> Dict[str, Any]:
        d = self.__dict__.copy()
        return d

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> IndicatorParamSpec:
        paramType = ParamType[json_dict['paramType']]
        required = json_dict['required']
        defaultValue = json_dict.get('defaultValue')
        options = json_dict.get('options')
        return IndicatorParamSpec(paramType, required, defaultValue, options)

