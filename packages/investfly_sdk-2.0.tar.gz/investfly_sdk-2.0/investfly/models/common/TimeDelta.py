from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from enum import Enum
from typing import Any, Dict


class TimeUnit(str, Enum):

    """
    TimeUnit Enum (MINUTES, HOURS, DAYS)
    """

    MINUTES = "MINUTES"
    HOURS = "HOURS"
    DAYS = "DAYS"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


@dataclass
class TimeDelta:
    """ TimeDelta container class similar to python timedelta """
    value: int
    unit: TimeUnit

    def toPyTimeDelta(self) -> timedelta:
        if self.unit == TimeUnit.MINUTES:
            totalMinutes = self.value
        elif self.unit == TimeUnit.HOURS:
            totalMinutes = self.value * 60
        elif self.unit == TimeUnit.DAYS:
            totalMinutes = self.value * 60 * 24
        else:
            raise ValueError(f"Unsupported TimeUnit: {self.unit}")

        return timedelta(minutes=totalMinutes)

    def toDict(self) -> Dict[str, Any]:
        return self.__dict__.copy()

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> TimeDelta:
        return TimeDelta(json_dict['value'], TimeUnit[json_dict['unit']])

