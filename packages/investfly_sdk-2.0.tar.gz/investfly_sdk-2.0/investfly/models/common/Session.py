from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class Session:

    """ Class that represents logged in user session with the Investfly server """

    username: str
    clientId: str
    clientToken: str

    @staticmethod
    def fromJsonDict(json_dict: Dict[str, Any]) -> Session:
        return Session(json_dict['username'], json_dict['clientId'], json_dict['clientToken'])

