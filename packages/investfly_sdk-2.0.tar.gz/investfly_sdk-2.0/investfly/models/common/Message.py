from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any


class MessageType(str, Enum):
    ERROR = "ERROR"
    SUCCESS = "SUCCESS"
    WARN = "WARN"


@dataclass
class Message:
    type: MessageType
    message: str

    def toDict(self) -> Dict[str, Any]:
        return self.__dict__.copy()

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> Message:
        return Message(MessageType[json_dict['type']], json_dict['message'])

