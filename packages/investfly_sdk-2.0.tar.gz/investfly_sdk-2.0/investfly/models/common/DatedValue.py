from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict
from investfly.models.common.ModelUtils import ModelUtils


@dataclass
class DatedValue:
    """
    Data Container class to hold Time,Value for timed numeric values
    """
    date: datetime
    value: float | int

    def toJsonDict(self) -> Dict[str, Any]:
        return {
            'date': ModelUtils.formatDatetime(self.date),
            'value': self.value
        }

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> 'DatedValue':
        return DatedValue(ModelUtils.parseDatetime(json_dict['date']), json_dict['value'])

    def __repr__(self) -> str:
        formatted_date = ModelUtils.formatDateTimeNoMillisecs(self.date)
        return f"DatedValue(date='{formatted_date}', value={self.value})"

    def __str__(self) -> str:
        return self.__repr__()

