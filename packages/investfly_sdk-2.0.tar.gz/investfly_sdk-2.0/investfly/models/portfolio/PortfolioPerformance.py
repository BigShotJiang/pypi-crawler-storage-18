from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List

from investfly.models.common.DatedValue import DatedValue


@dataclass
class PortfolioPerformance:
    netReturn: float | None = None
    annualizedReturn: float | None = None
    profitFactor: float | None = None

    totalTrades: int | None = None
    winRatioPct: float | None = None
    avgProfitPerTradePct: float | None = None
    avgLossPerTradePct: float | None = None

    meanReturnPerTradePct: float | None = None
    sharpeRatioPerTrade: float | None = None

    maxDrawdownPct: float | None = None
    portfolioValues: List[DatedValue] | None = None

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        if self.portfolioValues is not None:
            jsonDict["portfolioValues"] = [dv.toJsonDict() for dv in self.portfolioValues]
        else:
            jsonDict['portfolioValues'] = []
        return jsonDict

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> PortfolioPerformance:
        perf = PortfolioPerformance()
        for key, value in jsonDict.items():
            setattr(perf, key, value)
        if 'portfolioValues' in jsonDict:
            perf.portfolioValues = [DatedValue.fromDict(dv) for dv in jsonDict['portfolioValues']]
        else:
            perf.portfolioValues = []
        return perf

    def __str__(self):
        jsonDict = self.__dict__.copy()
        if 'portfolioValues' in jsonDict:
            del jsonDict['portfolioValues']
        return str(jsonDict)

    def __repr__(self):
        return self.__str__()

