from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class Balances:
    buyingPower: float
    cashBalance: float
    currentValue: float
    initialAmount: float | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> "Balances":
        return Balances(
            jsonDict["buyingPower"],
            jsonDict["cashBalance"],
            jsonDict["currentValue"],
            jsonDict.get("initialAmount")
        )

