from typing import Dict, List, Optional

from investfly.models import *


class StrategyStarterTemplate(TradingStrategy):
    """
    Simple template for creating trading strategies. 
    To create your strategy:
    1. Implement getSecurityUniverseSelector() - define which stocks to trade
    2. Implement one or both of the following:
        - Implement onMarketData() - if your trading logic should be triggerd on new market data
        - Implement onSchedule() - if your trading logic should be triggerd at regular intervals
    4. Optionally implement getStandardCloseCondition() - automatic exit rules
    """

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        """
        Define which securities your strategy will trade.
        """
        
        # ===== STOCK EXAMPLES =====
        
        # Example 1: Single stock
        single_stock = SecurityUniverseSelector.singleStock("AAPL")
        
        # Example 2: Standard stock lists
        sp100 = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.SP_100)
        sp500 = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.SP_500)
        nasdaq100 = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.NASDAQ_100)
        
        # Example 3: Custom stock symbol list
        custom_stock_list = SecurityUniverseSelector.fromSymbols(
            SecurityType.STOCK, ["AAPL", "MSFT", "GOOGL", "TSLA", "AMZN"]
        )
        
        
        # Example 4: Financial query with multiple conditions
        # Find profitable companies with low debt
        value_stocks_query = FinancialQuery()
        value_stocks_query.addCondition(
            FinancialCondition(
                financialField=FinancialField.NET_INCOME,
                operator=ComparisonOperator.GREATER_THAN,
                value="100M"
            )
        )
        value_stocks_query.addCondition(
            FinancialCondition(
                financialField=FinancialField.DEBT_EQUITY_RATIO,
                operator=ComparisonOperator.LESS_THAN,
                value="0.5"
            )
        )
        value_stocks_selector = SecurityUniverseSelector.fromFinancialQuery(value_stocks_query)
        
        # Example 5: Financial query with sector filter
        # Find utilities companies with high market cap
        utilities_query = FinancialQuery()
        utilities_query.addCondition(
            FinancialCondition(
                financialField=FinancialField.MARKET_CAP,
                operator=ComparisonOperator.GREATER_THAN,
                value="1B"
            )
        )
        utilities_query.addSector(Sectors.UTILITIES)
        utilities_selector = SecurityUniverseSelector.fromFinancialQuery(utilities_query)
        
        # ===== CRYPTO EXAMPLES =====
        
        # Example 6: Standard crypto lists
        all_crypto = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_CRYPTO)
        usd_crypto = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.USD_CRYPTO)
        
        # Example 7: Custom crypto symbol list
        custom_crypto_list = SecurityUniverseSelector.fromSymbols(
            SecurityType.CRYPTO, ["BTC-USD", "ETH-USD", "BTC-USDC", "ETH-USDC", "ETH-BTC"]
        )
        
        # Example 8: Single crypto pair using fromSecurity
        btc_usd_security = Security("BTC-USD", SecurityType.CRYPTO)
        single_crypto = SecurityUniverseSelector.fromSecurity(btc_usd_security)
        
        # ===== FOREX EXAMPLES =====
        
        # Example 9: Standard forex list
        all_forex = SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)
        
        # Example 10: Custom forex symbol list
        custom_forex_list = SecurityUniverseSelector.fromSymbols(
            SecurityType.FOREX, ["EUR-USD", "USD-JPY", "GBP-USD", "USD-CHF", "AUD-USD"]
        )
        
        # Example 11: Single forex pair
        eur_usd_security = Security("EUR-USD", SecurityType.FOREX)
        single_forex = SecurityUniverseSelector.fromSecurity(eur_usd_security)
        
        # ===== RETURN ONE OF THE EXAMPLES =====
        # Uncomment the one you want to use:
        return sp100
        # return custom_stock_list
        # return financial_query_selector
        # return value_stocks_selector
        # return all_crypto
        # return custom_crypto_list
        # return all_forex
        # return custom_forex_list

    def _evaluateEntryCondition(self, security: Security, sma_fast: IndicatorSeries, sma_slow: IndicatorSeries) -> Optional[TradeOrder]:
        # Entry condition: fast SMA crosses above slow SMA (golden cross)
        if sma_fast.cross_over(sma_slow):
            return TradeOrder(
                security=security,
                tradeType=TradeType.BUY,
                orderType=OrderType.MARKET_ORDER,
                quantity=20
            )
        return None

    def _evaluateExitCondition(self, security: Security, position: OpenPosition, sma_fast: IndicatorSeries, sma_slow: IndicatorSeries) -> Optional[TradeOrder]:
        # Exit condition: fast SMA crosses under slow SMA (death cross)
        if sma_fast.cross_under(sma_slow):
            trade_type = TradeType.SELL if position.position == PositionType.LONG else TradeType.COVER
            return TradeOrder(
                security=security,
                tradeType=trade_type,
                orderType=OrderType.MARKET_ORDER,
                quantity=position.quantity
            )
        return None

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        """
        This function is called on new market data arrival for all securities in the universe.
        This function must be annotated with @data_trigger to specify what kind of data it is triggered on. Currently, we only support BARS data type with various barIntervals.    
        @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
        """
        orders = []
        
        # Access your portfolio and its data
        portfolio: Portfolio = self.getPortfolio()
        balances: Balances = portfolio.balances
        openPositions: List = portfolio.openPositions
        completedTrades: List = portfolio.completedTrades
        pendingOrders: List = portfolio.pendingOrders
        
        # Process each security with new data
        for security in updatedSecurities:
            try:
                # Example: Compute SMA indicators
                sma_fast: IndicatorSeries = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 10, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                sma_slow: IndicatorSeries = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                # Get the latest quote for the current security (price, volume, etc.)
                quote: Quote = self.dataService.getQuote(security)
                # Retrieve the financial statement data for the security as a dictionary
                financials: Dict[FinancialField, float] = self.dataService.getFinancials(security.symbol)
                # Get the last 20 15-minute bars (historical OHLCV data) for the security
                bars: List[Bar] = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=20)            
                # Check if we already have a position
                position = portfolio.findPosition(security, PositionType.LONG)          
                if position:
                    # Evaluate exit/close logic
                    exit_order = self._evaluateExitCondition(security, position, sma_fast, sma_slow)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    # Evaluate entry/open condition
                    entry_order = self._evaluateEntryCondition(security, sma_fast, sma_slow)
                    if entry_order:
                        orders.append(entry_order)
                
            except NoDataException:
                # Skip this security if data is not available and continue with next security
                continue
        
        return orders if orders else None

    @time_trigger(interval=ScheduleInterval.WEEK)
    def onSchedule(self) -> Optional[List[TradeOrder]]:
        """
        This function is called at regular intervals you specify with @time_trigger. You can do monthly portfolio rebalancing in this method.
        Or if you strategy involves scanning the whole market and making trades at fixed time, you can implement it in this method.
        - @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=10) - Daily at specific hour
        - @time_trigger(interval=ScheduleInterval.WEEK, dayOfWeek=0, hourOfDay=10) - Weekly (Monday at 10 AM)
        - @time_trigger(interval=ScheduleInterval.MONTH, dayOfMonth=1, hourOfDay=10) - Monthly (1st at 10 AM)
        - @time_trigger(interval=ScheduleInterval.HOUR) - Every hour
        - @time_trigger(interval=ScheduleInterval.MINUTE) - Every minute
        - @time_trigger(interval=ScheduleInterval.FIVE_MINUTE) - Every 5 minutes
        """
        orders = []
        portfolio = self.getPortfolio()
        portfolio_value = portfolio.balances.currentValue
        
        # Use runMarketQuery to find top 10 lowest P/E ratio stocks
        # Build filter expression using the builder pattern
        filter_expr = SecurityFilterExpression()
        
        # Add financial parameter for P/E ratio
        pe_param = filter_expr.addFinancialParam(FinancialField.PRICE_TO_EARNINGS_RATIO, "pe_ratio")
        
        # Filter: P/E ratio > 0 (to ensure it exists and is positive)
        filter_expr.newFilterGroup() \
            .newFilterCondition() \
            .addToLeftCondition("pe_ratio") \
            .setOperator(ComparisonOperator.GREATER_THAN) \
            .addToRightCondition("0") \
            .done() \
            .done()
        
        # Create market query request: sort by P/E ratio ascending (lowest first), limit to top 10
        query_request = MarketQueryRequest(
            securityFilterExpression=filter_expr,
            sortBy=SortBySpec(alias="pe_ratio", dataParam=pe_param, order=SortOrder.ASC, limit=10)
        )
        
        # Run the query to get top 10 lowest P/E ratio stocks
        top_10 = self.dataService.runMarketQuery(query_request)

        # Close all positions not in new top 10
        top_10_set = set(top_10)
        for pos in portfolio.openPositions:
            if pos.security not in top_10_set:
                orders.append(TradeOrder(security=pos.security, tradeType=TradeType.SELL if pos.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=pos.quantity))
        
        # Buy missing ones from top 10
        existing_positions = {pos.security for pos in portfolio.openPositions}
        for security in top_10:
            if security not in existing_positions:
                orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=portfolio_value / max(len(top_10), 1)))

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria | None:
        """
        Optional: Define automatic exit rules for all open positions.
        """
        return StandardCloseCriteria(targetProfit=10.0, stopLoss=-5.0, trailingStop=None, timeOut=None)
    
