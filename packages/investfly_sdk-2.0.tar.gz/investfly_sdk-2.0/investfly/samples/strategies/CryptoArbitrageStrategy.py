from typing import List, Optional

from investfly.models import *


class CryptoArbitrageStrategy(TradingStrategy):
    """
    Crypto triangular arbitrage strategy that:
    1. Detects triangular arbitrage opportunities using BTC-USDC, ETH-USDC, and ETH-BTC pairs
    2. Calculates cycle factors for two possible loops
    3. Executes three-leg trades when net edge exceeds threshold
    
    This is a conceptual example for single-venue triangular arbitrage.
    In production, use firm bid/ask, IOC/FOK, inventory controls, and robust error handling.
    """
    
    FEE_PCT_PER_LEG = 0.25
    SLIPPAGE_BUFFER_PCT = 0.25
    MIN_NET_EDGE_PCT = 1.0
    START_USDC = 100.0

    def _find_arbitrage_opportunity(self, p_btc_usdc: float, p_eth_usdc: float, p_eth_btc: float, btc_usdc_security: Security, eth_usdc_security: Security, eth_btc_security: Security) -> Optional[List[TradeOrder]]:
        k1 = p_eth_usdc / (p_btc_usdc * p_eth_btc)
        k2 = (p_btc_usdc * p_eth_btc) / p_eth_usdc
        
        total_cost_pct = 3 * self.FEE_PCT_PER_LEG + self.SLIPPAGE_BUFFER_PCT
        edge1_pct = (k1 - 1.0) * 100.0 - total_cost_pct
        edge2_pct = (k2 - 1.0) * 100.0 - total_cost_pct
        
        best_edge_pct = max(edge1_pct, edge2_pct)
        if best_edge_pct < self.MIN_NET_EDGE_PCT:
            return None
        
        orders = []
        if edge1_pct >= edge2_pct:
            btc_qty = self.START_USDC / p_btc_usdc
            eth_qty = btc_qty / p_eth_btc
            if btc_qty > 0 and eth_qty > 0:
                orders.append(TradeOrder(security=btc_usdc_security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, quantity=btc_qty))
                orders.append(TradeOrder(security=eth_btc_security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, quantity=eth_qty))
                orders.append(TradeOrder(security=eth_usdc_security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=eth_qty))
        else:
            eth_qty = self.START_USDC / p_eth_usdc
            btc_qty = eth_qty * p_eth_btc
            if btc_qty > 0 and eth_qty > 0:
                orders.append(TradeOrder(security=eth_usdc_security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, quantity=eth_qty))
                orders.append(TradeOrder(security=eth_btc_security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=eth_qty))
                orders.append(TradeOrder(security=btc_usdc_security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=btc_qty))
        return orders

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromSymbols(SecurityType.CRYPTO, ["BTC-USDC"])

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        btc_usdc_security = Security("BTC-USDC", SecurityType.CRYPTO)
        eth_usdc_security = Security("ETH-USDC", SecurityType.CRYPTO)
        eth_btc_security = Security("ETH-BTC", SecurityType.CRYPTO)
        
        try:
            quote_btc_usdc = self.dataService.getQuote(btc_usdc_security)
            quote_eth_usdc = self.dataService.getQuote(eth_usdc_security)
            quote_eth_btc = self.dataService.getQuote(eth_btc_security)
            
            if quote_btc_usdc.lastPrice is None or quote_eth_usdc.lastPrice is None or quote_eth_btc.lastPrice is None:
                return None
            
            p_btc_usdc = float(quote_btc_usdc.lastPrice)
            p_eth_usdc = float(quote_eth_usdc.lastPrice)
            p_eth_btc = float(quote_eth_btc.lastPrice)
            
            if p_btc_usdc <= 0 or p_eth_usdc <= 0 or p_eth_btc <= 0:
                return None
            
            cycle_orders = self._find_arbitrage_opportunity(p_btc_usdc, p_eth_usdc, p_eth_btc, btc_usdc_security, eth_usdc_security, eth_btc_security)
            if cycle_orders:
                orders.extend(cycle_orders)
        except NoDataException:
            return None
        
        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria | None:
        return None

