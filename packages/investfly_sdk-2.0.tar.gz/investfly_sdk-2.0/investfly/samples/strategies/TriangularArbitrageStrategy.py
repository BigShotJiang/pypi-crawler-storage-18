from typing import List, Optional

from investfly.models import *


class TriangularArbitrageStrategy(TradingStrategy):
    """
    Triangular arbitrage strategy for cryptocurrency pairs.
    
    Example: BTC → ETH → USD → BTC cycle
    
    Detects triangle pricing inefficiencies and executes instant arbitrage.
    The strategy monitors three trading pairs that form a triangular cycle and
    executes trades when the cycle return exceeds the threshold.
    
    Uses available pairs: ETH-BTC, ETH-USD, BTC-USD
    Cycle: Start with BTC → Buy ETH (via ETH-BTC) → Sell ETH for USD (via ETH-USD) → Buy BTC with USD (via BTC-USD)
    """
    
    BASE = "BTC"
    MID = "ETH"
    QUOTE = "USD"
    THRESHOLD = 0.002  # 0.2% minimum edge

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        # Using available pairs: ETH-BTC, ETH-USD, BTC-USD
        # Note: ETH-BTC is the inverse of BTC-ETH, so we use it for BTC → ETH conversion
        pair1_symbol = f"{self.MID}-{self.BASE}"  # ETH-BTC (to convert BTC → ETH)
        pair2_symbol = f"{self.MID}-{self.QUOTE}"  # ETH-USD (to convert ETH → USD)
        pair3_symbol = f"{self.BASE}-{self.QUOTE}"  # BTC-USD (to convert USD → BTC)
        return SecurityUniverseSelector.fromSymbols(SecurityType.CRYPTO, [pair1_symbol, pair2_symbol, pair3_symbol])

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders: List[TradeOrder] = []

        # Using available pairs from ExecutorApp.DEV_CRYPTO_SYMBOLS
        pair1 = Security(f"{self.MID}-{self.BASE}", SecurityType.CRYPTO)  # ETH-BTC
        pair2 = Security(f"{self.MID}-{self.QUOTE}", SecurityType.CRYPTO)  # ETH-USD
        pair3 = Security(f"{self.BASE}-{self.QUOTE}", SecurityType.CRYPTO)  # BTC-USD

        try:
            quote1 = self.dataService.getQuote(pair1)  # ETH-BTC price (ETH per BTC)
            quote2 = self.dataService.getQuote(pair2)  # ETH-USD price (ETH per USD)
            quote3 = self.dataService.getQuote(pair3)  # BTC-USD price (BTC per USD)
        except NoDataException:
            return orders

        # Calculate cycle return: BTC → ETH → USD → BTC
        # quote1 (ETH-BTC): price of ETH in terms of BTC (e.g., 0.05 means 1 BTC = 20 ETH)
        # quote2 (ETH-USD): price of ETH in USD (e.g., 2000 means 1 ETH = $2000)
        # quote3 (BTC-USD): price of BTC in USD (e.g., 40000 means 1 BTC = $40000)
        # Cycle: Start with 1 BTC → Get ETH (1 / quote1) → Get USD (ETH * quote2) → Get BTC (USD / quote3)
        cycle_return = self._calculate_cycle_return(quote1.lastPrice, quote2.lastPrice, quote3.lastPrice)
        
        if cycle_return > 1 + self.THRESHOLD:
            # Execute triangular arbitrage: BTC → ETH → USD → BTC
            # 1. Buy ETH with BTC (using ETH-BTC pair: BUY ETH, pay with BTC)
            orders.append(TradeOrder(security=pair1, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=1.0))
            # 2. Sell ETH for USD (using ETH-USD pair: SELL ETH, receive USD)
            orders.append(TradeOrder(security=pair2, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, maxAmount=1.0))
            # 3. Buy BTC with USD (using BTC-USD pair: BUY BTC, pay with USD)
            orders.append(TradeOrder(security=pair3, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=1.0))

        return orders

    def _calculate_cycle_return(self, p_eth_btc: float, p_eth_usd: float, p_btc_usd: float) -> float:
        """
        Calculate the return from triangular arbitrage cycle: BTC → ETH → USD → BTC
        
        Args:
            p_eth_btc: Price of ETH in terms of BTC (ETH-BTC pair)
            p_eth_usd: Price of ETH in USD (ETH-USD pair)
            p_btc_usd: Price of BTC in USD (BTC-USD pair)
        
        Returns:
            The return multiplier. If > 1, there's an arbitrage opportunity.
        """
        # Start with 1 BTC
        # Step 1: Convert BTC → ETH using ETH-BTC price
        # If ETH-BTC = 0.05, then 1 BTC = 20 ETH, so we get (1 / p_eth_btc) ETH
        eth_received = 1.0 / p_eth_btc
        
        # Step 2: Convert ETH → USD using ETH-USD price
        # If ETH-USD = 2000, then 1 ETH = $2000, so we get (eth_received * p_eth_usd) USD
        usd_received = eth_received * p_eth_usd
        
        # Step 3: Convert USD → BTC using BTC-USD price
        # If BTC-USD = 40000, then 1 BTC = $40000, so we get (usd_received / p_btc_usd) BTC
        btc_received = usd_received / p_btc_usd
        
        return btc_received

