from typing import List, Optional, Dict, Any

from investfly.models import *


class PairsTradingStrategy(TradingStrategy):
    """
    Pairs trading strategy that:
    1. Identifies highly correlated security pairs
    2. Calculates spread and z-score for signal generation
    3. Implements mean reversion trading logic
    4. Closes positions when spread reverts to mean
    
    This is a market-neutral strategy that profits from temporary
    disequilibria in correlated securities.
    
    Note: This is a simplified version. In production, you would need
    to fetch prices for both securities in each pair simultaneously.
    """
    
    POSITION_SIZE = 0.33  # 33% of portfolio
    
    CORRELATED_PAIRS = {
        "tech_pair_1": {"security1": "AAPL", "security2": "MSFT", "correlation": 0.85},
        "tech_pair_2": {"security1": "GOOG", "security2": "META", "correlation": 0.82},
        "tech_pair_3": {"security1": "NVDA", "security2": "TSLA", "correlation": 0.78},
        "tech_pair_4": {"security1": "AMZN", "security2": "ORCL", "correlation": 0.71}
    }

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        all_symbols = []
        for pair_info in self.CORRELATED_PAIRS.values():
            all_symbols.extend([str(pair_info["security1"]), str(pair_info["security2"])])
        unique_symbols = list(set(all_symbols))
        return SecurityUniverseSelector.fromSymbols(SecurityType.STOCK, unique_symbols)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                pair_info = self._find_security_pair(security.symbol)
                if not pair_info:
                    continue
                
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=60)
                
                current_price = bars[-1]["close"]
                current_volume = bars[-1]["volume"]
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_price)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    pass
            except NoDataException:
                continue

        return orders if orders else None

    def _evaluate_exit(self, position: OpenPosition, current_price: float) -> Optional[TradeOrder]:
        entry_price = position.avgPrice
        price_change = abs(current_price - entry_price) / entry_price if entry_price != 0 else 0
        if price_change > 0.03:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL if position.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _find_security_pair(self, symbol: str) -> Dict[str, Any] | None:
        for pair_id, pair_info in self.CORRELATED_PAIRS.items():
            if pair_info["security1"] == symbol:
                return {"pair_id": pair_id, "other_security": pair_info["security2"], "correlation": pair_info["correlation"]}
            elif pair_info["security2"] == symbol:
                return {"pair_id": pair_id, "other_security": pair_info["security1"], "correlation": pair_info["correlation"]}
        return None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=3.0, stopLoss=-2.0, trailingStop=-1.0, timeOut=TimeDelta(value=7, unit=TimeUnit.DAYS))

