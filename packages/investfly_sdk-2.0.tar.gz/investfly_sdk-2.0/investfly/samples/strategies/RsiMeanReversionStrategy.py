from typing import List, Optional

from investfly.models import *


class RsiMeanReversionStrategy(TradingStrategy):
    """
    RSI-based mean reversion strategy that:
    1. Uses RSI indicator to identify overbought and oversold conditions
    2. Generates buy signals when RSI moves from below 30 (oversold) back above 30
    3. Includes risk management with target profit, stop loss, and time-based exit
    
    This strategy capitalizes on mean reversion by buying oversold securities
    when they show signs of upward reversal.
    """
    
    RSI_PERIOD = 14
    OVERSOLD_THRESHOLD = 30.0
    OVERBOUGHT_THRESHOLD = 70.0
    POSITION_SIZE = 0.05  # 5% of portfolio

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.SP_100)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_DAY)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        oversold_list = self.state.get("oversold_securities", [])
        oversold_securities = set(oversold_list) if isinstance(oversold_list, list) else set()
        
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
            rsi_list = rsi_series.toList()
            if len(rsi_list) < 2:
                continue
            current_rsi = rsi_list[-1].value
            previous_rsi = rsi_list[-2].value
            
            symbol = security.symbol
            
            if previous_rsi < self.OVERSOLD_THRESHOLD:
                oversold_securities.add(symbol)
            elif current_rsi > 50:
                oversold_securities.discard(symbol)
            
            position = portfolio.findPosition(security, PositionType.LONG)
            
            if not position:
                if symbol in oversold_securities and previous_rsi < self.OVERSOLD_THRESHOLD and current_rsi >= self.OVERSOLD_THRESHOLD:
                    orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
        self.state["oversold_securities"] = list(oversold_securities)
        
        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=4.0, stopLoss=-2.0, trailingStop=None, timeOut=TimeDelta(value=5, unit=TimeUnit.DAYS))

