from typing import List, Optional

from investfly.models import *


class SmaCrossOverStrategy(TradingStrategy):
    """
    Short-term SMA crossover scalping strategy that:
    1. Uses very short SMA periods (2 and 3) on 1-minute bars
    2. Enters long position when SMA(2) crosses above SMA(3)
    3. Uses tight stop loss and take profit for scalping
    
    This is a high-frequency scalping strategy designed for quick in-and-out trades.
    """
    
    FAST = 2
    SLOW = 3
    POSITION_SIZE = 0.05  # 5% of portfolio

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.SP_100)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        
        for security in updatedSecurities:
            try:
                sma_fast = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: self.FAST, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                sma_slow = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: self.SLOW, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})

                sma_fast_list = sma_fast.toList()
                sma_slow_list = sma_slow.toList()

                if len(sma_fast_list) < 2 or len(sma_slow_list) < 2:
                    continue
                    
                sma_fast_current = sma_fast_list[-1].value
                sma_fast_previous = sma_fast_list[-2].value
                sma_slow_current = sma_slow_list[-1].value
                sma_slow_previous = sma_slow_list[-2].value

                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    pass
                else:
                    if sma_fast_current > sma_slow_current and sma_fast_previous <= sma_slow_previous:
                        max_amount = portfolio_value * self.POSITION_SIZE
                        orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=max_amount))
            except NoDataException:
                continue

        return orders

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=1.0, stopLoss=-1.0, trailingStop=None, timeOut=TimeDelta(value=60, unit=TimeUnit.MINUTES))
