from typing import List, Optional

from investfly.models import *


class MultiTimeframeRsiStrategy(TradingStrategy):
    """
    Multi-timeframe RSI strategy that:
    1. Analyzes RSI across 1-minute, 5-minute, and 15-minute timeframes
    2. Identifies RSI convergence and divergence patterns
    3. Uses momentum analysis for signal strength
    4. Includes volume confirmation for signal validation
    5. Closes positions when RSI reverses across timeframes
    
    This is a complex momentum strategy that provides comprehensive
    RSI analysis across multiple time horizons.
    """
    
    RSI_PERIOD = 14
    POSITION_SIZE = 0.25  # 25% of portfolio

    def _evaluate_exit(self, position: OpenPosition, rsi_1min: float, rsi_5min: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and rsi_1min > 70 and rsi_5min > 65:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and rsi_1min < 30 and rsi_5min < 35:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, rsi_1min: float, rsi_5min: float, rsi_15min: float, momentum_1min: float, momentum_5min: float, volume_ratio: float, position_amount: float) -> Optional[TradeOrder]:
        if rsi_1min < 30 and rsi_5min < 35 and rsi_15min < 40 and momentum_1min > 0 and momentum_5min > 0 and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if rsi_1min > 70 and rsi_5min > 65 and rsi_15min > 60 and momentum_1min < 0 and momentum_5min < 0 and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if volume_ratio > 1.5:
            if momentum_1min > 10 and momentum_5min > 5 and rsi_1min < 50 and rsi_5min < 50:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            elif momentum_1min < -10 and momentum_5min < -5 and rsi_1min > 50 and rsi_5min > 50:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                rsi_1min_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                rsi_5min_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.FIVE_MINUTE})
                rsi_15min_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.FIFTEEN_MINUTE})
                
                rsi_1min_list = rsi_1min_series.toList()
                rsi_5min_list = rsi_5min_series.toList()
                rsi_15min_list = rsi_15min_series.toList()
                if len(rsi_1min_list) < 5 or len(rsi_5min_list) < 5 or len(rsi_15min_list) < 5:
                    continue
                
                current_rsi_1min = rsi_1min_list[-1].value
                prev_rsi_1min = rsi_1min_list[-2].value
                current_rsi_5min = rsi_5min_list[-1].value
                prev_rsi_5min = rsi_5min_list[-2].value
                current_rsi_15min = rsi_15min_list[-1].value
                rsi_momentum_1min = current_rsi_1min - prev_rsi_1min
                rsi_momentum_5min = current_rsi_5min - prev_rsi_5min
                
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=20)
                volumes = [bar["volume"] for bar in bars]
                volume_ratio = bars[-1]["volume"] / (sum(volumes) / len(volumes)) if volumes else 1
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_rsi_1min, current_rsi_5min)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, current_rsi_1min, current_rsi_5min, current_rsi_15min, rsi_momentum_1min, rsi_momentum_5min, volume_ratio, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=6.0, stopLoss=-3.0, trailingStop=-1.5, timeOut=TimeDelta(value=5, unit=TimeUnit.DAYS))

