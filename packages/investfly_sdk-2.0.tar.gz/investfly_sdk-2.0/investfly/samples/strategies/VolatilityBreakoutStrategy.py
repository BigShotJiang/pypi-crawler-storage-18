from typing import List, Optional

from investfly.models import *


class VolatilityBreakoutStrategy(TradingStrategy):
    """
    Volatility breakout strategy that:
    1. Identifies low volatility consolidation periods
    2. Detects breakouts with expanding volatility (ATR)
    3. Uses Bollinger Bands for signal generation
    4. Includes volume confirmation for breakout validation
    5. Closes positions when volatility contracts or trend reverses
    
    This is a breakout strategy that capitalizes on volatility expansion
    and price breakouts from consolidation periods.
    
    Note: This is more sophisticated than VolatilityBreakoutV2, using
    ATR and Bollinger Bands instead of simple high/low calculations.
    """
    
    POSITION_SIZE = 0.20  # 20% of portfolio

    def _evaluate_exit(self, position: OpenPosition, bb_middle: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and position.avgPrice > bb_middle * 1.02:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and position.avgPrice < bb_middle * 0.98:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, current_price: float, prev_price: float, bb_upper: float, prev_bb_upper: float, bb_lower: float, prev_bb_lower: float, atr_expansion: float, volume_ratio: float, position_amount: float) -> Optional[TradeOrder]:
        if current_price > bb_upper and prev_price <= prev_bb_upper and atr_expansion > 0.1 and volume_ratio > 1.3:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if current_price < bb_lower and prev_price >= prev_bb_lower and atr_expansion > 0.1 and volume_ratio > 1.3:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if atr_expansion > 0.5 and volume_ratio > 1.5:
            price_momentum = (current_price - prev_price) / prev_price * 100 if prev_price != 0 else 0
            if price_momentum > 1.0:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            elif price_momentum < -1.0:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.USD_CRYPTO)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=60)
                
                current_price = bars[-1]["close"]
                prev_price = bars[-2]["close"] if len(bars) >= 2 else current_price
                current_volume = bars[-1]["volume"]
                
                bb_upper_series = self.dataService.computeIndicatorSeries(IndicatorId.UPPERBBAND, security, {IndicatorParam.UPPERBBAND.PERIOD: 20, IndicatorParam.UPPERBBAND.STDDEV: 2, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                bb_lower_series = self.dataService.computeIndicatorSeries(IndicatorId.LOWERBBAND, security, {IndicatorParam.LOWERBBAND.PERIOD: 20, IndicatorParam.LOWERBBAND.STDDEV: 2, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                bb_middle_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                atr_series = self.dataService.computeIndicatorSeries(IndicatorId.ATR, security, {IndicatorParam.ATR.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                
                bb_upper_list = bb_upper_series.toList()
                bb_lower_list = bb_lower_series.toList()
                atr_list = atr_series.toList()
                
                if len(bb_upper_list) < 3 or len(bb_lower_list) < 3 or len(atr_list) < 5:
                    continue
                
                current_bb_upper = bb_upper_list[-1].value
                prev_bb_upper = bb_upper_list[-2].value
                current_bb_lower = bb_lower_list[-1].value
                prev_bb_lower = bb_lower_list[-2].value
                current_bb_middle = bb_middle_series.last.value
                
                current_atr = atr_list[-1].value
                atr_5_periods_ago = atr_list[-5].value if len(atr_list) >= 5 else current_atr
                
                atr_expansion = (current_atr - atr_5_periods_ago) / atr_5_periods_ago if atr_5_periods_ago != 0 else 0
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_bb_middle)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, current_price, prev_price, current_bb_upper, prev_bb_upper, current_bb_lower, prev_bb_lower, atr_expansion, volume_ratio, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=6.0, stopLoss=-3.0, trailingStop=-1.5, timeOut=TimeDelta(value=5, unit=TimeUnit.DAYS))

