from typing import List, Optional, Dict, Any

from investfly.models import *


class ConsecutiveLossStrategy(TradingStrategy):
    """
    Strategy that adjusts position size based on consecutive losing trades.
    
    Features:
    - Tracks consecutive losses in strategy state
    - If 3 or more losses in a row, reduces allocation for next trades
    - Requires state to persist across multiple callback invocations
    
    This strategy demonstrates how to use persistent state in TradingStrategy
    to track performance metrics and adjust trading behavior accordingly.
    """
    
    BASE_ALLOCATION = 100
    REDUCED_ALLOCATION = 50
    LOSS_THRESHOLD = 3
    SYMBOLS = ["AAPL", "MSFT", "ORCL"]

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromSymbols(SecurityType.STOCK, self.SYMBOLS)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []
        
        consecutive_losses_value = self.state.get("consecutive_losses", 0)
        consecutive_losses = int(consecutive_losses_value) if isinstance(consecutive_losses_value, (int, float)) else 0
        
        for security in updatedSecurities:
            try:
                quote = self.dataService.getQuote(security)
                
                if quote.dayOpen is not None and quote.lastPrice > quote.dayOpen:
                    allocation = self.REDUCED_ALLOCATION if consecutive_losses >= self.LOSS_THRESHOLD else self.BASE_ALLOCATION
                    orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=allocation))
                    consecutive_losses = 0
                else:
                    consecutive_losses += 1
            except NoDataException:
                continue
        
        self.state["consecutive_losses"] = int(consecutive_losses)
        
        return orders if orders else None

