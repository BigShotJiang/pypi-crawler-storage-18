from typing import List, Optional

from investfly.models import *


class BollingerBandsMeanReversion(TradingStrategy):
    """
    Bollinger Bands mean reversion strategy that:
    1. Identifies oversold conditions when price touches lower Bollinger Band
    2. Identifies overbought conditions when price touches upper Bollinger Band
    3. Uses volume confirmation to validate signals
    4. Closes positions when price returns to middle band (mean reversion)
    
    This is a contrarian strategy that assumes prices will revert to the mean
    after reaching extreme levels.
    """
    
    PERIOD = 20
    STD_DEV = 2.0
    POSITION_SIZE = 0.20  # 20% of portfolio

    def _evaluate_exit(self, position: OpenPosition, current_price: float, middle_band: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and current_price >= middle_band:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and current_price <= middle_band:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, current_price: float, upper_band: float, lower_band: float, position_amount: float) -> Optional[TradeOrder]:
        if current_price <= lower_band:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        elif current_price >= upper_band:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.USD_CRYPTO)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_DAY)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=50)
                
                current_bar = bars[-1]
                current_price = current_bar["close"]
                current_volume = current_bar["volume"]
                
                bb_upper = self.dataService.computeIndicatorSeries(IndicatorId.UPPERBBAND, security, {IndicatorParam.UPPERBBAND.PERIOD: self.PERIOD, IndicatorParam.UPPERBBAND.STDDEV: self.STD_DEV, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                bb_lower = self.dataService.computeIndicatorSeries(IndicatorId.LOWERBBAND, security, {IndicatorParam.LOWERBBAND.PERIOD: self.PERIOD, IndicatorParam.LOWERBBAND.STDDEV: self.STD_DEV, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                bb_middle = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: self.PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                
                upper_band = bb_upper.last.value
                lower_band = bb_lower.last.value
                middle_band = bb_middle.last.value
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_price, middle_band)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, current_price, upper_band, lower_band, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=3.0, stopLoss=-2.0, trailingStop=-1.0, timeOut=TimeDelta(value=2, unit=TimeUnit.DAYS))

