from typing import List, Optional

from investfly.models import *


class ValueRebalanceStrategy(TradingStrategy):
    """
    Value-based rebalancing strategy that:
    1. Filters stocks based on fundamental metrics (P/E ratio < 20, Market Cap > 10B)
    2. Focuses on Financials and Energy sectors for value opportunities
    3. Equal-weight rebalances portfolio to selected candidates
    4. Uses standard exit conditions (20% profit target, 8% stop loss, 90-day timeout)
    """
    
    MAX_PE_RATIO = 20.0
    MIN_MARKET_CAP = 10_000_000_000
    TARGET_PROFIT = 20.0
    STOP_LOSS = -8.0
    TIMEOUT_DAYS = 90
    REBALANCE_THRESHOLD = 0.01  # 1% of portfolio

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        # Use FinancialQuery to filter by fundamental metrics and sectors
        # Focus on Utilities sector which often has value opportunities
        financial_query = FinancialQuery()
        financial_query.addCondition(
            FinancialCondition(
                financialField=FinancialField.MARKET_CAP,
                operator=ComparisonOperator.GREATER_THAN,
                value="1B"
            )
        )

        financial_query.addSector(Sectors.UTILITIES)

        return SecurityUniverseSelector.fromFinancialQuery(financial_query)

    @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=10)
    def onSchedule(self) -> Optional[List[TradeOrder]]:
        portfolio = self.context.portfolio
        orders = []

        # Use runMarketQuery to find stocks matching our criteria
        # Filter: P/E ratio < 20 AND Market Cap > 10B
        filter_expr = SecurityFilterExpression()
        
        # Add financial data parameters
        pe_param = filter_expr.addFinancialParam(FinancialField.PRICE_TO_EARNINGS_RATIO, "pe_ratio")
        market_cap_param = filter_expr.addFinancialParam(FinancialField.MARKET_CAP, "market_cap")
        max_pe_const = filter_expr.addConstParam(self.MAX_PE_RATIO, alias="max_pe")
        min_market_cap_const = filter_expr.addConstParam(self.MIN_MARKET_CAP, alias="min_market_cap")
        
        # Build filter: pe_ratio < max_pe AND market_cap > min_market_cap
        filter_expr.newFilterGroup() \
            .newFilterCondition() \
            .addToLeftCondition("pe_ratio") \
            .setOperator(ComparisonOperator.LESS_THAN) \
            .addToRightCondition("max_pe") \
            .done() \
            .done()
        
        filter_expr.newFilterGroup() \
            .newFilterCondition() \
            .addToLeftCondition("market_cap") \
            .setOperator(ComparisonOperator.GREATER_THAN) \
            .addToRightCondition("min_market_cap") \
            .done() \
            .done()
        
        # Create market query request
        query_request = MarketQueryRequest(securityFilterExpression=filter_expr)
        
        # Run the query to get matching securities
        matching_securities = self.dataService.runMarketQuery(query_request)
        candidates = [sec.symbol for sec in matching_securities]

        if not candidates:
            for pos in portfolio.openPositions:
                orders.append(TradeOrder(security=pos.security, tradeType=TradeType.SELL if pos.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=pos.quantity))
            return orders
        weight = 1.0 / len(candidates)
        portfolio_value = portfolio.balances.currentValue
        target_amount_per_position = portfolio_value * weight
        for pos in portfolio.openPositions:
            if pos.security.symbol not in candidates:
                orders.append(TradeOrder(security=pos.security, tradeType=TradeType.SELL if pos.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=pos.quantity))
        for symbol in candidates:
            existing_position = None
            for pos in portfolio.openPositions:
                if pos.security.symbol == symbol:
                    existing_position = pos
                    break
            if existing_position:
                current_value = existing_position.currentValue or (existing_position.quantity * (existing_position.currentPrice or 0))
                difference = target_amount_per_position - current_value
                if abs(difference) > portfolio_value * self.REBALANCE_THRESHOLD:
                    if difference > 0:
                        orders.append(TradeOrder(security=Security.createStock(symbol), tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=difference))
                    else:
                        sell_quantity = abs(difference) / (existing_position.currentPrice or 1.0)
                        orders.append(TradeOrder(security=Security.createStock(symbol), tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=sell_quantity))
            else:
                orders.append(TradeOrder(security=Security.createStock(symbol), tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=target_amount_per_position))

        return orders

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=self.TARGET_PROFIT, stopLoss=self.STOP_LOSS, trailingStop=None, timeOut=TimeDelta(value=self.TIMEOUT_DAYS, unit=TimeUnit.DAYS))

