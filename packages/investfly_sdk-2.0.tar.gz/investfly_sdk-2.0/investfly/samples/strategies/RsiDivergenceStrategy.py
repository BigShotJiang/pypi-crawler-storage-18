from typing import List, Optional

from investfly.models import *


class RsiDivergenceStrategy(TradingStrategy):
    """
    RSI divergence strategy that:
    1. Detects bullish divergence (price lower low, RSI higher low) - buy signal
    2. Detects bearish divergence (price higher high, RSI lower high) - sell signal
    3. Uses volume confirmation for signal validation
    4. Closes positions when RSI becomes overbought/oversold
    
    This is a momentum strategy that capitalizes on trend reversals
    when momentum indicators diverge from price action.
    """
    
    RSI_PERIOD = 14
    POSITION_SIZE = 0.33  # 33% of portfolio

    def _evaluate_exit(self, position: OpenPosition, current_rsi: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and current_rsi > 70:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and current_rsi < 30:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, price_lows: List[int], rsi_lows: List[int], price_highs: List[int], rsi_highs: List[int], recent_prices: List[float], recent_rsi: List[float], volume_ratio: float, position_amount: float) -> Optional[TradeOrder]:
        bullish_divergence = self._check_bullish_divergence(price_lows, rsi_lows, recent_prices, recent_rsi)
        bearish_divergence = self._check_bearish_divergence(price_highs, rsi_highs, recent_prices, recent_rsi)
        
        if bullish_divergence and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        elif bearish_divergence and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=20)
                
                rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                
                rsi_list = rsi_series.toList()
                
                if len(rsi_list) < 10:
                    continue
                
                recent_prices = [bar["close"] for bar in bars[-10:]]
                recent_rsi = [rsi.value for rsi in rsi_list[-10:]]
                
                price_highs = self._find_local_extremes(recent_prices, "high")
                price_lows = self._find_local_extremes(recent_prices, "low")
                rsi_highs = self._find_local_extremes(recent_rsi, "high")
                rsi_lows = self._find_local_extremes(recent_rsi, "low")
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                current_volume = bars[-1]["volume"]
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, recent_rsi[-1])
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, price_lows, rsi_lows, price_highs, rsi_highs, recent_prices, recent_rsi, volume_ratio, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def _find_local_extremes(self, data: List[float], extreme_type: str) -> List[int]:
        extremes = []
        for i in range(1, len(data) - 1):
            if extreme_type == "high":
                if data[i] > data[i-1] and data[i] > data[i+1]:
                    extremes.append(i)
            else:
                if data[i] < data[i-1] and data[i] < data[i+1]:
                    extremes.append(i)
        return extremes

    def _check_bullish_divergence(self, price_lows: List[int], rsi_lows: List[int], 
                                 prices: List[float], rsi_values: List[float]) -> bool:
        if len(price_lows) < 2 or len(rsi_lows) < 2:
            return False
        
        latest_price_low_idx = price_lows[-1]
        prev_price_low_idx = price_lows[-2]
        latest_rsi_low_idx = rsi_lows[-1]
        prev_rsi_low_idx = rsi_lows[-2]
        
        price_lower_low = prices[latest_price_low_idx] < prices[prev_price_low_idx]
        rsi_higher_low = rsi_values[latest_rsi_low_idx] > rsi_values[prev_rsi_low_idx]
        rsi_oversold = rsi_values[latest_rsi_low_idx] < 40
        
        return price_lower_low and rsi_higher_low and rsi_oversold

    def _check_bearish_divergence(self, price_highs: List[int], rsi_highs: List[int], 
                                 prices: List[float], rsi_values: List[float]) -> bool:
        if len(price_highs) < 2 or len(rsi_highs) < 2:
            return False
        
        latest_price_high_idx = price_highs[-1]
        prev_price_high_idx = price_highs[-2]
        latest_rsi_high_idx = rsi_highs[-1]
        prev_rsi_high_idx = rsi_highs[-2]
        
        price_higher_high = prices[latest_price_high_idx] > prices[prev_price_high_idx]
        rsi_lower_high = rsi_values[latest_rsi_high_idx] < rsi_values[prev_rsi_high_idx]
        rsi_overbought = rsi_values[latest_rsi_high_idx] > 60
        
        return price_higher_high and rsi_lower_high and rsi_overbought

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=8.0, stopLoss=-4.0, trailingStop=-2.0, timeOut=TimeDelta(value=5, unit=TimeUnit.DAYS))

