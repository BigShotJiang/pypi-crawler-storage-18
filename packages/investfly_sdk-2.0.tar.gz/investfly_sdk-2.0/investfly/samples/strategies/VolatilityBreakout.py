from typing import List, Optional, Dict

from investfly.models import *


class VolatilityBreakout(TradingStrategy):
    """
    Volatility breakout strategy that:
    1. Calculates daily breakout levels based on previous day's high/low range
    2. Enters long positions when price breaks above the calculated level
    3. Uses a volatility multiplier (k) to set breakout threshold
    
    The strategy identifies potential breakouts by setting levels above the
    previous day's high based on the day's volatility range.
    """
    
    K = 0.5  # Volatility multiplier for breakout level
    SYMBOLS = ["BTC-USD", "ETH-USD", "XRP-USD"]
    POSITION_SIZE = 0.02  # 2% of portfolio
    
    # Breakout levels (computed daily, keyed by symbol)
    breakout_levels: Dict[str, float] = {}

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromSymbols(SecurityType.CRYPTO, self.SYMBOLS)

    @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=9)
    def onSchedule(self) -> Optional[List[TradeOrder]]:
        self.breakout_levels = {}
        
        universeSecurities = self.context.universeSecurities
        
        for security in universeSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=1)
                
                latest_bar = bars[-1]
                high = latest_bar["high"]
                low = latest_bar["low"]
                breakout_level = high + self.K * (high - low)
                self.breakout_levels[security.symbol] = breakout_level
            except NoDataException:
                continue
        
        return []

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []
        
        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                symbol = security.symbol
                
                if symbol not in self.breakout_levels:
                    continue
                
                quote = self.dataService.getQuote(security)
                
                current_price = quote.lastPrice
                breakout_level = self.breakout_levels[symbol]
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if not position and current_price > breakout_level:
                    orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            except NoDataException:
                continue
        
        return orders

