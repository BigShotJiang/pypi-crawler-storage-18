from typing import List, Optional

from investfly.models import *


class VolumePriceTrendStrategy(TradingStrategy):
    """
    Volume Price Trend strategy that:
    1. Identifies accumulation patterns (price up + high volume)
    2. Identifies distribution patterns (price down + high volume)
    3. Uses volume-weighted momentum for signal strength
    4. Includes volume trend confirmation
    5. Closes positions when volume dries up
    
    This is a volume-based strategy that capitalizes on institutional
    buying/selling patterns and market sentiment shifts.
    """
    
    VOLUME_THRESHOLD = 1.5
    MOMENTUM_THRESHOLD = 2.0
    POSITION_SIZE = 0.16  # 16% of portfolio

    def _evaluate_exit(self, position: OpenPosition, volume_ratio: float) -> Optional[TradeOrder]:
        if volume_ratio < 0.5:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL if position.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, price_change: float, volume_ratio: float, volume_momentum: float, vw_momentum: float, price_change_pct: float, position_amount: float) -> Optional[TradeOrder]:
        if price_change > 0 and volume_ratio > self.VOLUME_THRESHOLD and volume_momentum > 0.1 and vw_momentum > self.MOMENTUM_THRESHOLD:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if price_change < 0 and volume_ratio > self.VOLUME_THRESHOLD and volume_momentum > 0.1 and vw_momentum < -self.MOMENTUM_THRESHOLD:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if volume_ratio > 2.0 and abs(price_change_pct) > 1.0:
            if price_change > 0:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            elif price_change < 0:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.USD_CRYPTO)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.FIVE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.FIVE_MINUTE, numBars=20)
                
                current_price = bars[-1]["close"]
                prev_price = bars[-2]["close"]
                price_change = current_price - prev_price
                price_change_pct = (price_change / prev_price) * 100 if prev_price != 0 else 0
                
                current_volume = bars[-1]["volume"]
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                if len(volumes) >= 5:
                    recent_volumes = volumes[-5:]
                    volume_momentum = (recent_volumes[-1] - recent_volumes[0]) / recent_volumes[0] if recent_volumes[0] != 0 else 0
                else:
                    volume_momentum = 0
                
                vw_momentum = price_change_pct * volume_ratio
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, volume_ratio)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, price_change, volume_ratio, volume_momentum, vw_momentum, price_change_pct, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=4.0, stopLoss=-2.5, trailingStop=-1.0, timeOut=TimeDelta(value=3, unit=TimeUnit.DAYS))

