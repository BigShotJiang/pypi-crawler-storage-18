"""Library of simple routines."""

from toan.image.witchcoven import Witch
from toan.image.data import Kettle, KettleExternal
from toan.image.victims import Victim

from .options import options



__all__ = ['Victim', 'Witch', 'Kettle', 'KettleExternal', 'options']
