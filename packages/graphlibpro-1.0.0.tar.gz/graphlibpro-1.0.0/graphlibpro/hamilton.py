class HamiltonGraph:
    def __init__(self, n):
        self.n = n
        self.matrix = [[0] * n for _ in range(n)]

    def add_edge(self, u, v):
        self.matrix[u][v] = 1
        self.matrix[v][u] = 1

    def find_cycle(self):
        path = [-1] * self.n
        path[0] = 0

        def is_safe(v, pos):
            if self.matrix[path[pos - 1]][v] == 0:
                return False
            if v in path[:pos]:
                return False
            return True

        def solve(pos):
            if pos == self.n:
                return self.matrix[path[pos - 1]][path[0]] == 1

            for v in range(1, self.n):
                if is_safe(v, pos):
                    path[pos] = v
                    if solve(pos + 1):
                        return True
                    path[pos] = -1

            return False

        if solve(1):
            return path + [path[0]]
        return None