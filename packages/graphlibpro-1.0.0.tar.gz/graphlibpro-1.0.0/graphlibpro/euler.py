class EulerGraph:
    def __init__(self):
        self.graph = {}
    
    def add_edge(self, u, v):
        if u not in self.graph:
            self.graph[u] = []
        if v not in self.graph:
            self.graph[v] = []
        
        self.graph[u].append(v)
        self.graph[v].append(u)
    
    def is_eulerian(self):
        for node in self.graph:
            if len(self.graph[node]) % 2 != 0:
                return False
        return True
    
    def find_cycle(self):
        if not self.is_eulerian():
            return None
        
        stack = []
        path = []
        start = list(self.graph.keys())[0]
        stack.append(start)
        
        temp_graph = {k: v[:] for k, v in self.graph.items()}
        
        while stack:
            v = stack[-1]
            if temp_graph[v]:
                u = temp_graph[v].pop()
                temp_graph[u].remove(v)
                stack.append(u)
            else:
                path.append(stack.pop())
        
        return path[::-1]