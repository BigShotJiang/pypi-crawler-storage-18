"""
GraphLibPro - Библиотека для работы с графами
Включает алгоритмы Эйлера, Дейкстры и Гамильтона
"""

from .euler import EulerGraph
from .dijkstra import DijkstraGraph
from .hamilton import HamiltonGraph

__version__ = "1.0.0"
__author__ = "Дарья"
__all__ = ['EulerGraph', 'DijkstraGraph', 'HamiltonGraph']