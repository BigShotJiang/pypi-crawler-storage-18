from setuptools import setup

setup(
    name="graphlibpro",
    version="1.0.0",
    packages=['graphlibpro'],
)