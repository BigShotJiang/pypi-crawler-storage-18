import unittest
from graphlibpro.hamilton import HamiltonGraph


class TestHamilton(unittest.TestCase):
    def test_hamilton_cycle(self):
        g = HamiltonGraph(4)
        # Делаем полный граф
        for i in range(4):
            for j in range(4):
                if i != j:
                    g.add_edge(i, j)

        cycle = g.find_cycle()
        self.assertIsNotNone(cycle)