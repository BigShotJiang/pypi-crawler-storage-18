import unittest
from graphlibpro.euler import EulerGraph


class TestEuler(unittest.TestCase):
    def test_euler_cycle(self):
        g = EulerGraph()
        g.add_edge(0, 1)
        g.add_edge(1, 2)
        g.add_edge(2, 0)

        self.assertTrue(g.is_eulerian())

    def test_no_euler(self):
        g = EulerGraph()
        g.add_edge(0, 1)
        g.add_edge(0, 2)

        self.assertFalse(g.is_eulerian())