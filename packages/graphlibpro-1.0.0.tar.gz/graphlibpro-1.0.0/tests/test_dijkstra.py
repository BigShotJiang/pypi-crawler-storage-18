import unittest
from graphlibpro.dijkstra import DijkstraGraph


class TestDijkstra(unittest.TestCase):
    def test_shortest_path(self):
        g = DijkstraGraph(4)
        g.add_edge(0, 1, 1)
        g.add_edge(1, 2, 2)
        g.add_edge(0, 2, 4)

        dist = g.shortest_path(0)
        self.assertEqual(dist[2], 3)  # 0->1->2