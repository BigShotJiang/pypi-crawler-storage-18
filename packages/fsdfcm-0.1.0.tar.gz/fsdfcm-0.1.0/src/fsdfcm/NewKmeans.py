import cv2
import matplotlib.pyplot as plt
import numpy as np
import skimage
import os

def seg_kmeans_gray():
    # 读取图片
    img = cv2.imread('gray.png', cv2.IMREAD_GRAYSCALE)
    img = skimage.util.random_noise(img, mode='gaussian', var=0.01)

    # 展平
    img_flat = img.reshape((img.shape[0] * img.shape[1], 1))
    img_flat = np.float32(img_flat)

    # 迭代参数
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TermCriteria_MAX_ITER, 20, 0.5)
    flags = cv2.KMEANS_RANDOM_CENTERS

    # 进行聚类
    compactness, labels, centers = cv2.kmeans(img_flat, 4, None, criteria, 10, flags)

    # 显示结果
    img_output = labels.reshape((img.shape[0], img.shape[1]))
    img_output = cv2.normalize(img_output, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)

    # img_output = img_output * 255
    plt.subplot(121), plt.imshow(img, 'gray'), plt.title('input')
    plt.subplot(122), plt.imshow(img_output, 'gray'), plt.title('kmeans')
    path = 'E:/seg_kmeans/final_pic/INDEX'
    cv2.imwrite(os.path.join(path, 'k_means.png'), img_output)
    plt.show()


if __name__ == '__main__':
    seg_kmeans_gray()