import cv2
from dask.array.tests.test_stats import scipy
import numpy as np

pred_matte = cv2.imread('Result_1_9_1.bmp', cv2.IMREAD_COLOR)
gt_matte = cv2.imread('1_9.bmp', cv2.IMREAD_COLOR)
print('DSFCM')
# error_sad = matte_sad(pred_matte, gt_matte)
# print(error_sad)
# matte_mse(pred_matte, gt_matte)
# matte_grad(pred_matte, gt_matte)

''' Mean Squared Error '''
assert (len(pred_matte.shape) == len(gt_matte.shape))
error_mse = np.mean(np.power(pred_matte - gt_matte, 2))
print('MSE:', error_mse)

''' Error measure with Gradient '''
assert (len(pred_matte.shape) == len(gt_matte.shape))
predict_grad = scipy.ndimage.filters.gaussian_filter(pred_matte, 1.4, order=1)  # alpha matte的归一化梯度，标准差=1.4，1阶高斯导数的卷积
gt_grad = scipy.ndimage.filters.gaussian_filter(gt_matte, 1.4, order=1)
error_grad = np.sum(np.power(predict_grad - gt_grad, 2))
print('Grad:', error_grad)

'''
    Sum of Absolute Differences

    pred_matte : np.array, shape : [h,w]
    gt_matte   : np.array, shape : [h,w]
    '''
assert (len(pred_matte.shape) == len(gt_matte.shape))
error_sad = np.sum(np.abs(pred_matte - gt_matte))
print('sad:', error_sad)
