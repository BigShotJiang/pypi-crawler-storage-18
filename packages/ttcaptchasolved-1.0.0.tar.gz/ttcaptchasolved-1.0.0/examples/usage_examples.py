#!/usr/bin/env python3
"""
Example usage of TikTok CAPTCHA Solver

This script demonstrates the various ways to use the library.
"""

import base64
from pathlib import Path


def example_basic_usage():
    """Basic standalone usage with image files"""
    from tiktok_captcha_solver import TikTokCaptchaSolver
    
    solver = TikTokCaptchaSolver()
    
    # Example: Solve slide captcha
    # Replace with actual captcha images
    print("=== Slide CAPTCHA ===")
    # result = solver.solve_slide("background.png", "piece.png")
    # print(f"Slide distance: {result.x}px")
    # print(f"Confidence: {result.confidence:.2%}")
    
    # Example: Solve rotate captcha
    print("\n=== Rotate CAPTCHA ===")
    # result = solver.solve_rotate("outer.png", "inner.png")
    # print(f"Rotate angle: {result.angle}°")
    # print(f"Confidence: {result.confidence:.2%}")
    
    # Example: Solve shapes captcha
    print("\n=== Shapes CAPTCHA ===")
    # result = solver.solve_shapes("shapes.png")
    # print(f"Point 1: ({result.x1}, {result.y1})")
    # print(f"Point 2: ({result.x2}, {result.y2})")
    # print(f"Confidence: {result.confidence:.2%}")


def example_selenium():
    """Using with Selenium WebDriver"""
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from tiktok_captcha_solver import SeleniumSolver
    except ImportError:
        print("Selenium not installed. Run: pip install selenium")
        return
    
    # Setup Chrome options
    options = Options()
    # options.add_argument("--headless")  # Uncomment for headless mode
    
    print("Starting Selenium example...")
    
    # Create driver
    driver = webdriver.Chrome(options=options)
    
    try:
        # Navigate to TikTok login
        driver.get("https://www.tiktok.com/login/phone-or-email/email")
        
        # Wait for page load
        import time
        time.sleep(3)
        
        # Create solver with callback
        def on_event(event, data):
            print(f"[Selenium] {event}: {data}")
        
        solver = SeleniumSolver(driver, callback=on_event)
        
        # Check for captcha
        captcha_type = solver.detect_captcha_type()
        if captcha_type:
            print(f"Detected {captcha_type} captcha")
            solver.solve_captcha_if_present()
        else:
            print("No captcha detected")
    
    finally:
        driver.quit()


def example_playwright_sync():
    """Using with Playwright (synchronous)"""
    try:
        from playwright.sync_api import sync_playwright
        from tiktok_captcha_solver import PlaywrightSolver
    except ImportError:
        print("Playwright not installed. Run: pip install playwright && playwright install")
        return
    
    print("Starting Playwright (sync) example...")
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        
        try:
            page.goto("https://www.tiktok.com/login/phone-or-email/email")
            page.wait_for_timeout(3000)
            
            def on_event(event, data):
                print(f"[Playwright] {event}: {data}")
            
            solver = PlaywrightSolver(page, callback=on_event)
            
            captcha_type = solver.detect_captcha_type()
            if captcha_type:
                print(f"Detected {captcha_type} captcha")
                solver.solve_captcha_if_present()
            else:
                print("No captcha detected")
        
        finally:
            browser.close()


async def example_playwright_async():
    """Using with Playwright (asynchronous)"""
    try:
        from playwright.async_api import async_playwright
        from tiktok_captcha_solver import AsyncPlaywrightSolver
    except ImportError:
        print("Playwright not installed. Run: pip install playwright && playwright install")
        return
    
    print("Starting Playwright (async) example...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        
        try:
            await page.goto("https://www.tiktok.com/login/phone-or-email/email")
            await page.wait_for_timeout(3000)
            
            def on_event(event, data):
                print(f"[AsyncPlaywright] {event}: {data}")
            
            solver = AsyncPlaywrightSolver(page, callback=on_event)
            
            captcha_type = await solver.detect_captcha_type()
            if captcha_type:
                print(f"Detected {captcha_type} captcha")
                await solver.solve_captcha_if_present()
            else:
                print("No captcha detected")
        
        finally:
            await browser.close()


def example_with_base64():
    """Using with base64 encoded images"""
    from tiktok_captcha_solver import TikTokCaptchaSolver
    
    solver = TikTokCaptchaSolver()
    
    # Example: If you have base64 encoded images
    # bg_base64 = "iVBORw0KGgoAAAANSUhEUgAA..."  # Your base64 background
    # piece_base64 = "iVBORw0KGgoAAAANSUhEUgAA..."  # Your base64 piece
    
    # result = solver.solve_slide(bg_base64, piece_base64)
    # print(f"Slide distance: {result.x}px")
    
    print("Base64 example ready - uncomment with your images")


def example_with_numpy():
    """Using with numpy arrays (OpenCV format)"""
    try:
        import cv2
        import numpy as np
        from tiktok_captcha_solver import TikTokCaptchaSolver
    except ImportError:
        print("OpenCV not installed properly")
        return
    
    solver = TikTokCaptchaSolver()
    
    # Example: If you have numpy arrays
    # bg_array = cv2.imread("background.png")
    # piece_array = cv2.imread("piece.png")
    
    # result = solver.solve_slide(bg_array, piece_array)
    # print(f"Slide distance: {result.x}px")
    
    print("NumPy example ready - uncomment with your images")


def example_individual_solvers():
    """Using individual solver classes for more control"""
    from tiktok_captcha_solver import SlideSolver, RotateSolver, ShapesSolver
    
    # Slide solver with custom settings
    slide_solver = SlideSolver(use_edge_detection=True)
    
    # Rotate solver with custom angle steps
    rotate_solver = RotateSolver(
        angle_step=2.0,      # Initial search step (degrees)
        refine_step=0.1      # Refinement step (degrees)
    )
    
    # Shapes solver
    shapes_solver = ShapesSolver()
    
    print("Individual solvers initialized")
    print(f"- SlideSolver: use_edge_detection=True")
    print(f"- RotateSolver: angle_step=2.0, refine_step=0.1")
    print(f"- ShapesSolver: default settings")


if __name__ == "__main__":
    print("TikTok CAPTCHA Solver Examples")
    print("=" * 40)
    
    # Run basic example
    example_basic_usage()
    
    # Run base64 example
    print("\n" + "=" * 40)
    example_with_base64()
    
    # Run numpy example
    print("\n" + "=" * 40)
    example_with_numpy()
    
    # Run individual solvers example
    print("\n" + "=" * 40)
    example_individual_solvers()
    
    # Uncomment to run browser examples:
    # print("\n" + "=" * 40)
    # example_selenium()
    
    # print("\n" + "=" * 40)
    # example_playwright_sync()
    
    # print("\n" + "=" * 40)
    # import asyncio
    # asyncio.run(example_playwright_async())
