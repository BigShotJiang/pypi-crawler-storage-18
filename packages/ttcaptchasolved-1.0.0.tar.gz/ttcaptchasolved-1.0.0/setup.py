#!/usr/bin/env python3
"""
Setup script for TikTokCaptchaSolver

Install with:
    pip install .
    
Or for development:
    pip install -e .
"""

from setuptools import setup, find_packages

setup(
    name="TTCaptchaSolved",
    version="1.0.0",
    description="Solve TikTok CAPTCHAs locally using OpenCV - supports slide, rotate, and 3D shapes captchas",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="TikTok CAPTCHA Solver",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "opencv-python>=4.5.0",
        "numpy>=1.19.0",
        "Pillow>=8.0.0",
    ],
    extras_require={
        "selenium": ["selenium>=4.0.0"],
        "playwright": ["playwright>=1.20.0"],
        "all": ["selenium>=4.0.0", "playwright>=1.20.0"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="tiktok captcha solver opencv slide puzzle rotate whirl 3d shapes selenium playwright",
)
