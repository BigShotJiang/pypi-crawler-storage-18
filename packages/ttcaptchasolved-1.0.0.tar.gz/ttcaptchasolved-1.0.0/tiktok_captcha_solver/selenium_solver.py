"""
Selenium integration for TikTok CAPTCHA Solver
Automatically detects and solves CAPTCHAs when using Selenium WebDriver
"""

import time
import random
import base64
from typing import Optional, Callable, Any
from io import BytesIO

try:
    from selenium.webdriver.remote.webdriver import WebDriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.action_chains import ActionChains
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import TimeoutException, NoSuchElementException
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False

from .solver import TikTokCaptchaSolver, SlideResult, RotateResult, ShapesResult


# Common TikTok CAPTCHA selectors
CAPTCHA_SELECTORS = {
    # Slide/Puzzle CAPTCHA
    'slide_container': [
        '.captcha_verify_container',
        '.secsdk-captcha-drag-wrapper',
        '#captcha-verify-image',
        '[class*="captcha"]',
    ],
    'slide_background': [
        '.captcha_verify_img--wrapper img',
        '.captcha-verify-image img',
        '#captcha_verify_image',
        '[class*="captcha"] img[class*="bg"]',
    ],
    'slide_piece': [
        '.captcha_verify_slide--slidebar img',
        '.captcha-slider-puzzle img',
        '[class*="captcha"] img[class*="piece"]',
        '[class*="captcha"] img[class*="slide"]',
    ],
    'slide_button': [
        '.secsdk-captcha-drag-icon',
        '.captcha_verify_slide--button',
        '[class*="captcha"] [class*="slider"]',
        '[class*="captcha"] [class*="drag"]',
    ],
    
    # Rotate/Whirl CAPTCHA
    'rotate_container': [
        '.captcha_verify_container--rotate',
        '[class*="rotate"]',
        '[class*="whirl"]',
    ],
    'rotate_outer': [
        '.captcha-rotate-outer img',
        '[class*="rotate"] img:first-child',
    ],
    'rotate_inner': [
        '.captcha-rotate-inner img',
        '[class*="rotate"] img:last-child',
    ],
    
    # 3D Shapes CAPTCHA
    'shapes_container': [
        '.captcha_verify_container--shapes',
        '[class*="shapes"]',
        '[class*="3d"]',
    ],
    'shapes_image': [
        '.captcha-shapes-image img',
        '[class*="shapes"] img',
    ],
}


def _human_like_delay():
    """Add random delay to simulate human behavior"""
    time.sleep(random.uniform(0.1, 0.3))


def _human_like_drag(driver: 'WebDriver', element, distance_x: int, distance_y: int = 0):
    """
    Perform a human-like drag operation with acceleration/deceleration
    """
    action = ActionChains(driver)
    
    # Click and hold
    action.click_and_hold(element)
    action.perform()
    
    _human_like_delay()
    
    # Generate human-like movement path
    steps = random.randint(15, 25)
    
    for i in range(steps):
        # Easing function for human-like movement
        progress = i / steps
        ease = progress * (2 - progress)  # Ease out quad
        
        # Add some randomness
        x_offset = int(ease * distance_x) + random.randint(-2, 2)
        y_offset = int(ease * distance_y) + random.randint(-1, 1)
        
        # Calculate movement delta
        action = ActionChains(driver)
        action.move_by_offset(
            x_offset - (int((i-1)/steps * distance_x) if i > 0 else 0),
            y_offset
        )
        action.perform()
        
        time.sleep(random.uniform(0.01, 0.03))
    
    _human_like_delay()
    
    # Release
    action = ActionChains(driver)
    action.release()
    action.perform()


def _get_element_screenshot_base64(driver: 'WebDriver', element) -> str:
    """Get base64 encoded screenshot of an element"""
    screenshot = element.screenshot_as_png
    return base64.b64encode(screenshot).decode('utf-8')


def _get_image_src_base64(driver: 'WebDriver', element) -> str:
    """Get base64 encoded image from img element's src"""
    src = element.get_attribute('src')
    
    if src.startswith('data:image'):
        # Already base64
        return src.split(',', 1)[1]
    else:
        # Need to fetch the image
        import urllib.request
        with urllib.request.urlopen(src) as response:
            return base64.b64encode(response.read()).decode('utf-8')


def _find_element_by_selectors(driver: 'WebDriver', selectors: list, timeout: float = 5) -> Optional[Any]:
    """Try multiple selectors to find an element"""
    for selector in selectors:
        try:
            element = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )
            return element
        except (TimeoutException, NoSuchElementException):
            continue
    return None


class SeleniumSolver:
    """
    Selenium integration for automatic CAPTCHA solving
    """
    
    def __init__(
        self,
        driver: 'WebDriver',
        max_retries: int = 3,
        retry_delay: float = 1.0,
        callback: Optional[Callable[[str, Any], None]] = None
    ):
        """
        Args:
            driver: Selenium WebDriver instance
            max_retries: Maximum number of retry attempts
            retry_delay: Delay between retries in seconds
            callback: Optional callback function(event_type, data)
        """
        if not SELENIUM_AVAILABLE:
            raise ImportError(
                "Selenium is not installed. Install with: pip install selenium"
            )
        
        self.driver = driver
        self.solver = TikTokCaptchaSolver()
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.callback = callback
    
    def _emit(self, event: str, data: Any = None):
        """Emit callback event"""
        if self.callback:
            self.callback(event, data)
    
    def detect_captcha_type(self) -> Optional[str]:
        """
        Detect which type of CAPTCHA is present
        
        Returns:
            'slide', 'rotate', 'shapes', or None
        """
        # Check for slide captcha
        if _find_element_by_selectors(self.driver, CAPTCHA_SELECTORS['slide_container'], timeout=1):
            return 'slide'
        
        # Check for rotate captcha
        if _find_element_by_selectors(self.driver, CAPTCHA_SELECTORS['rotate_container'], timeout=1):
            return 'rotate'
        
        # Check for shapes captcha
        if _find_element_by_selectors(self.driver, CAPTCHA_SELECTORS['shapes_container'], timeout=1):
            return 'shapes'
        
        return None
    
    def solve_slide_captcha(self) -> bool:
        """
        Solve slide/puzzle CAPTCHA
        
        Returns:
            True if solved successfully
        """
        self._emit('solving', 'slide')
        
        # Find elements
        bg_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['slide_background']
        )
        piece_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['slide_piece']
        )
        slider_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['slide_button']
        )
        
        if not all([bg_element, piece_element, slider_element]):
            self._emit('error', 'Could not find CAPTCHA elements')
            return False
        
        try:
            # Get images
            bg_base64 = _get_image_src_base64(self.driver, bg_element)
            piece_base64 = _get_image_src_base64(self.driver, piece_element)
            
            # Solve
            result = self.solver.solve_slide(bg_base64, piece_base64)
            self._emit('solved', result)
            
            # Perform drag
            _human_like_drag(self.driver, slider_element, result.x, 0)
            
            _human_like_delay()
            return True
            
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_rotate_captcha(self) -> bool:
        """
        Solve rotate/whirl CAPTCHA
        
        Returns:
            True if solved successfully
        """
        self._emit('solving', 'rotate')
        
        # Find elements
        outer_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['rotate_outer']
        )
        inner_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['rotate_inner']
        )
        slider_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['slide_button']  # Often same slider
        )
        
        if not all([outer_element, inner_element, slider_element]):
            self._emit('error', 'Could not find CAPTCHA elements')
            return False
        
        try:
            # Get images
            outer_base64 = _get_image_src_base64(self.driver, outer_element)
            inner_base64 = _get_image_src_base64(self.driver, inner_element)
            
            # Solve
            slider_width = slider_element.size['width'] or 348
            distance = self.solver.rotate_solver.solve_as_distance(
                outer_base64, inner_base64, slider_width
            )
            
            self._emit('solved', {'distance': distance})
            
            # Perform drag
            _human_like_drag(self.driver, slider_element, distance, 0)
            
            _human_like_delay()
            return True
            
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_shapes_captcha(self) -> bool:
        """
        Solve 3D shapes/matching CAPTCHA
        
        Returns:
            True if solved successfully
        """
        self._emit('solving', 'shapes')
        
        # Find image element
        image_element = _find_element_by_selectors(
            self.driver, CAPTCHA_SELECTORS['shapes_image']
        )
        
        if not image_element:
            self._emit('error', 'Could not find CAPTCHA image')
            return False
        
        try:
            # Get image
            image_base64 = _get_image_src_base64(self.driver, image_element)
            
            # Solve
            result = self.solver.solve_shapes(image_base64)
            self._emit('solved', result)
            
            # Get element location for click calculations
            location = image_element.location
            size = image_element.size
            
            # Click first point
            action = ActionChains(self.driver)
            action.move_to_element_with_offset(
                image_element,
                result.x1 - size['width'] // 2,
                result.y1 - size['height'] // 2
            )
            action.click()
            action.perform()
            
            _human_like_delay()
            
            # Click second point
            action = ActionChains(self.driver)
            action.move_to_element_with_offset(
                image_element,
                result.x2 - size['width'] // 2,
                result.y2 - size['height'] // 2
            )
            action.click()
            action.perform()
            
            _human_like_delay()
            return True
            
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_captcha_if_present(self, timeout: float = 5) -> bool:
        """
        Detect and solve any CAPTCHA if present
        
        Args:
            timeout: Time to wait for CAPTCHA to appear
        
        Returns:
            True if CAPTCHA was solved or no CAPTCHA present
        """
        time.sleep(0.5)  # Brief wait for CAPTCHA to fully load
        
        captcha_type = self.detect_captcha_type()
        
        if captcha_type is None:
            return True  # No CAPTCHA present
        
        for attempt in range(self.max_retries):
            self._emit('attempt', attempt + 1)
            
            success = False
            
            if captcha_type == 'slide':
                success = self.solve_slide_captcha()
            elif captcha_type == 'rotate':
                success = self.solve_rotate_captcha()
            elif captcha_type == 'shapes':
                success = self.solve_shapes_captcha()
            
            if success:
                # Check if CAPTCHA is still present
                time.sleep(self.retry_delay)
                if self.detect_captcha_type() is None:
                    self._emit('success', captcha_type)
                    return True
            
            time.sleep(self.retry_delay)
        
        self._emit('failed', captcha_type)
        return False
