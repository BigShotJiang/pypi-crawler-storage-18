"""
License validation for TikTok-Captcha-Solver

This module handles API key validation and usage tracking.
Get your API key at: https://captchasolved.com
"""

import os
import json
import hashlib
import time
import platform
import uuid
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import urllib.request
import urllib.error


# Configuration
LICENSE_SERVER_URL = "https://api.captchasolved.com"
CONFIG_DIR = Path.home() / ".tiktok_captcha_solver"
CONFIG_FILE = CONFIG_DIR / "config.json"
CACHE_FILE = CONFIG_DIR / "license_cache.json"

# Cache validity (hours) - how long before re-validating with server
CACHE_VALIDITY_HOURS = 1  # Check frequently for usage-based limits


class LicenseError(Exception):
    """Raised when license validation fails"""
    pass


class LicenseExpiredError(LicenseError):
    """Raised when license has expired (solves exhausted)"""
    pass


class UsageLimitError(LicenseError):
    """Raised when usage limit exceeded"""
    pass


def _get_machine_id() -> str:
    """Generate a unique machine identifier"""
    identifiers = [
        platform.node(),
        platform.machine(),
        platform.processor(),
    ]
    
    try:
        mac = uuid.getnode()
        identifiers.append(str(mac))
    except:
        pass
    
    combined = "|".join(identifiers)
    return hashlib.sha256(combined.encode()).hexdigest()[:32]


def _load_config() -> Dict[str, Any]:
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}


def _save_config(config: Dict[str, Any]):
    """Save configuration to file"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def _load_cache() -> Dict[str, Any]:
    """Load license cache"""
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}


def _save_cache(cache: Dict[str, Any]):
    """Save license cache"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CACHE_FILE, 'w') as f:
        json.dump(cache, f, indent=2)


def _call_server(endpoint: str, data: dict) -> Dict[str, Any]:
    """Make a request to the license server"""
    json_data = json.dumps(data).encode('utf-8')
    
    try:
        req = urllib.request.Request(
            f"{LICENSE_SERVER_URL}{endpoint}",
            data=json_data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "TikTok-Captcha-Solver/1.0.0"
            },
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read().decode('utf-8'))
            
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        try:
            error_data = json.loads(body)
            message = error_data.get("error", str(e))
        except:
            message = str(e)
        
        if e.code == 401:
            raise LicenseError(f"Invalid API key. Get one at https://captchasolved.com")
        elif e.code == 403:
            raise LicenseExpiredError(message)
        elif e.code == 429:
            raise UsageLimitError(message)
        else:
            raise LicenseError(f"Server error: {message}")
    except urllib.error.URLError as e:
        return None  # Network error
    except Exception as e:
        raise LicenseError(f"Connection error: {str(e)}")


class LicenseManager:
    """
    Manages license validation and usage tracking
    Uses per-solve credits model
    """
    
    _instance = None
    _license_info = None
    _api_key = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def set_api_key(self, api_key: str):
        """
        Set and validate API key
        
        Args:
            api_key: Your API key from captchasolved.com
        
        Raises:
            LicenseError: If key is invalid
        """
        self._api_key = api_key
        self._license_info = None
        
        # Save to config
        config = _load_config()
        config["api_key"] = api_key
        _save_config(config)
        
        # Validate immediately
        self.validate()
    
    def get_api_key(self) -> Optional[str]:
        """Get current API key"""
        if self._api_key:
            return self._api_key
        
        # Try environment variable
        env_key = os.environ.get("CAPTCHA_SOLVER_API_KEY")
        if env_key:
            self._api_key = env_key
            return env_key
        
        # Also check old env var name for compatibility
        env_key = os.environ.get("TIKTOK_CAPTCHA_SOLVER_API_KEY")
        if env_key:
            self._api_key = env_key
            return env_key
        
        # Try config file
        config = _load_config()
        if "api_key" in config:
            self._api_key = config["api_key"]
            return self._api_key
        
        return None
    
    def validate(self) -> Dict[str, Any]:
        """
        Validate the current API key with server
        
        Returns:
            License info dict
        
        Raises:
            LicenseError: If validation fails
        """
        api_key = self.get_api_key()
        
        if not api_key:
            raise LicenseError(
                "No API key set. Get your key at https://captchasolved.com\n"
                "Then set it with: set_api_key('your-key-here')\n"
                "Or set environment variable: CAPTCHA_SOLVER_API_KEY"
            )
        
        result = _call_server("/v1/validate", {
            "api_key": api_key,
            "machine_id": _get_machine_id(),
            "version": "1.0.0",
        })
        
        if result is None:
            # Server unreachable - check cache
            cache = _load_cache()
            if api_key in cache:
                cached = cache[api_key]
                cached_time = datetime.fromisoformat(cached.get("cached_at", "2000-01-01"))
                if datetime.now() - cached_time < timedelta(hours=24):
                    self._license_info = cached.get("license_info", {})
                    return self._license_info
            raise LicenseError("Cannot reach license server. Check your internet connection.")
        
        if not result.get("valid", False):
            raise LicenseError(result.get("error", "Invalid license"))
        
        # Cache the result
        cache = _load_cache()
        cache[api_key] = {
            "cached_at": datetime.now().isoformat(),
            "license_info": result
        }
        _save_cache(cache)
        
        self._license_info = result
        return result
    
    def use_solve(self) -> Dict[str, Any]:
        """
        Record a solve and decrement credits on server
        
        Returns:
            Updated license info with remaining solves
        
        Raises:
            UsageLimitError: If no solves remaining
        """
        api_key = self.get_api_key()
        
        if not api_key:
            raise LicenseError("No API key set. Get one at https://captchasolved.com")
        
        result = _call_server("/v1/use", {
            "api_key": api_key,
            "machine_id": _get_machine_id(),
        })
        
        if result is None:
            raise LicenseError("Cannot reach license server. Check your internet connection.")
        
        if not result.get("success", False):
            error = result.get("error", "Unknown error")
            if "exhausted" in error.lower() or "remaining" in error.lower():
                raise UsageLimitError(
                    f"No solves remaining. Purchase more at https://captchasolved.com"
                )
            raise LicenseError(error)
        
        self._license_info = result
        return result
    
    def get_usage_info(self) -> Dict[str, Any]:
        """Get current usage statistics"""
        if not self._license_info:
            try:
                self.validate()
            except:
                pass
        
        if not self._license_info:
            return {
                "plan": "unknown",
                "total_solves": 0,
                "used_solves": 0,
                "remaining_solves": 0,
            }
        
        return {
            "plan": self._license_info.get("plan", "unknown"),
            "total_solves": self._license_info.get("total_solves", 0),
            "used_solves": self._license_info.get("used_solves", 0),
            "remaining_solves": self._license_info.get("remaining_solves", 0),
        }


# Global license manager instance
_license_manager = LicenseManager()


def set_api_key(api_key: str):
    """
    Set your API key for TikTok-Captcha-Solver
    
    Get your key at: https://captchasolved.com
    
    Args:
        api_key: Your API key
    
    Example:
        from tiktok_captcha_solver import set_api_key
        set_api_key("your-api-key-here")
    """
    _license_manager.set_api_key(api_key)


def get_usage_info() -> Dict[str, Any]:
    """
    Get current usage statistics
    
    Returns:
        Dict with plan, total_solves, used_solves, remaining_solves
    """
    return _license_manager.get_usage_info()


def validate_license():
    """Validate the current license"""
    return _license_manager.validate()


def require_license(func):
    """Decorator to require valid license and record usage before function execution"""
    def wrapper(*args, **kwargs):
        # First validate
        _license_manager.validate()
        # Use a solve credit
        _license_manager.use_solve()
        # Then execute
        return func(*args, **kwargs)
    return wrapper
