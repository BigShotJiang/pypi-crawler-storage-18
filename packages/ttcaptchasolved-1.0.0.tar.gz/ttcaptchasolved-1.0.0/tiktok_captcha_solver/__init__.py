"""
TikTok CAPTCHA Solver
=====================

A Python library for solving TikTok CAPTCHAs locally using OpenCV.
Supports slide/puzzle, rotate/whirl, and 3D shapes CAPTCHAs.

Get your API key at: https://tiktok-captcha-solver.com

Quick Start:
-----------
    from tiktok_captcha_solver import TikTokCaptchaSolver, set_api_key
    
    # Set your API key (get one at https://tiktok-captcha-solver.com)
    set_api_key("your-api-key-here")
    
    solver = TikTokCaptchaSolver()
    
    # Solve slide captcha
    result = solver.solve_slide(background_image, piece_image)
    print(f"Slide distance: {result.x}")

Environment Variable:
--------------------
    You can also set your API key via environment variable:
    export TIKTOK_CAPTCHA_SOLVER_API_KEY="your-api-key-here"

Selenium Usage:
--------------
    from tiktok_captcha_solver import SeleniumSolver, set_api_key
    from selenium import webdriver
    
    set_api_key("your-api-key-here")
    
    driver = webdriver.Chrome()
    solver = SeleniumSolver(driver)
    solver.solve_captcha_if_present()

Playwright Usage:
----------------
    from tiktok_captcha_solver import PlaywrightSolver, set_api_key
    from playwright.sync_api import sync_playwright
    
    set_api_key("your-api-key-here")
    
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        solver = PlaywrightSolver(page)
        solver.solve_captcha_if_present()
"""

__version__ = "1.0.0"
__author__ = "TikTok CAPTCHA Solver"

# License management
from .license import (
    set_api_key,
    get_usage_info,
    validate_license,
    LicenseError,
    LicenseExpiredError,
    UsageLimitError,
)

# Core solvers
from .solver import (
    TikTokCaptchaSolver,
    SlideSolver,
    RotateSolver,
    ShapesSolver,
    SlideResult,
    RotateResult,
    ShapesResult,
)

# Browser integrations (lazy import to avoid hard dependencies)
def __getattr__(name):
    if name == "SeleniumSolver":
        from .selenium_solver import SeleniumSolver
        return SeleniumSolver
    
    if name == "PlaywrightSolver":
        from .playwright_solver import PlaywrightSolver
        return PlaywrightSolver
    
    if name == "AsyncPlaywrightSolver":
        from .playwright_solver import AsyncPlaywrightSolver
        return AsyncPlaywrightSolver
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Version
    "__version__",
    
    # License management
    "set_api_key",
    "get_usage_info",
    "validate_license",
    "LicenseError",
    "LicenseExpiredError",
    "UsageLimitError",
    
    # Core solver
    "TikTokCaptchaSolver",
    
    # Individual solvers
    "SlideSolver",
    "RotateSolver",
    "ShapesSolver",
    
    # Result types
    "SlideResult",
    "RotateResult",
    "ShapesResult",
    
    # Browser integrations
    "SeleniumSolver",
    "PlaywrightSolver",
    "AsyncPlaywrightSolver",
]
