"""
TikTok CAPTCHA Solver - Core solving algorithms using OpenCV
Supports: Slide/Puzzle, Rotate/Whirl, and 3D Shapes CAPTCHAs

Get your API key at: https://tiktok-captcha-solver.com
"""

import cv2
import numpy as np
from io import BytesIO
from PIL import Image
import base64
from typing import Tuple, Optional, Union
from dataclasses import dataclass

from .license import _license_manager, LicenseError, require_license


@dataclass
class SlideResult:
    """Result from slide/puzzle captcha solving"""
    x: int  # X position where piece should be placed
    y: int  # Y position (usually not needed for slide)
    confidence: float  # Match confidence 0-1
    
    @property
    def slide_distance(self) -> int:
        """Alias for x position - distance to slide"""
        return self.x


@dataclass
class RotateResult:
    """Result from rotate/whirl captcha solving"""
    angle: float  # Degrees to rotate
    confidence: float


@dataclass
class ShapesResult:
    """Result from 3D shapes captcha - two points to click"""
    x1: int
    y1: int
    x2: int
    y2: int
    confidence: float


def _load_image(image_input: Union[str, bytes, np.ndarray, Image.Image]) -> np.ndarray:
    """
    Load image from various sources into OpenCV format (BGR numpy array)
    
    Args:
        image_input: Can be:
            - str: file path or base64 encoded string
            - bytes: raw image bytes
            - np.ndarray: already loaded OpenCV image
            - PIL.Image: PIL Image object
    
    Returns:
        np.ndarray: OpenCV image in BGR format
    """
    if isinstance(image_input, np.ndarray):
        return image_input
    
    if isinstance(image_input, Image.Image):
        return cv2.cvtColor(np.array(image_input), cv2.COLOR_RGB2BGR)
    
    if isinstance(image_input, str):
        # Check if it's a file path or base64
        if len(image_input) < 500 and not image_input.startswith('data:'):
            # Likely a file path
            img = cv2.imread(image_input)
            if img is None:
                raise ValueError(f"Could not load image from path: {image_input}")
            return img
        else:
            # Base64 encoded
            if image_input.startswith('data:'):
                # Remove data URL prefix
                image_input = image_input.split(',', 1)[1]
            image_bytes = base64.b64decode(image_input)
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                raise ValueError("Could not decode base64 image")
            return img
    
    if isinstance(image_input, bytes):
        nparr = np.frombuffer(image_input, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            raise ValueError("Could not decode image bytes")
        return img
    
    raise TypeError(f"Unsupported image type: {type(image_input)}")


def _remove_whitespace(image: np.ndarray, threshold: int = 240) -> np.ndarray:
    """
    Remove whitespace/transparent borders from image
    
    Args:
        image: Input image
        threshold: Pixel value threshold for considering as "white"
    
    Returns:
        Cropped image with whitespace removed
    """
    if len(image.shape) == 3 and image.shape[2] == 4:
        # RGBA - use alpha channel
        alpha = image[:, :, 3]
        coords = cv2.findNonZero(alpha)
    else:
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Find non-white pixels
        mask = gray < threshold
        coords = cv2.findNonZero(mask.astype(np.uint8))
    
    if coords is None:
        return image
    
    x, y, w, h = cv2.boundingRect(coords)
    return image[y:y+h, x:x+w]


def _apply_edge_detection(image: np.ndarray, low_threshold: int = 50, high_threshold: int = 150) -> np.ndarray:
    """
    Apply Canny edge detection to image
    
    Args:
        image: Input image (BGR or grayscale)
        low_threshold: Low threshold for Canny
        high_threshold: High threshold for Canny
    
    Returns:
        Edge-detected grayscale image
    """
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Apply Canny edge detection
    edges = cv2.Canny(blurred, low_threshold, high_threshold)
    
    return edges


class SlideSolver:
    """
    Solver for slide/puzzle CAPTCHAs
    
    Works by using template matching to find where the puzzle piece
    fits into the background image.
    """
    
    def __init__(self, use_edge_detection: bool = True):
        """
        Args:
            use_edge_detection: Whether to use edge detection for better matching
        """
        self.use_edge_detection = use_edge_detection
    
    @require_license
    def solve(
        self,
        background: Union[str, bytes, np.ndarray, Image.Image],
        piece: Union[str, bytes, np.ndarray, Image.Image],
        piece_start_x: int = 0
    ) -> SlideResult:
        """
        Find the position where the puzzle piece should be placed
        
        Args:
            background: The background image with the gap
            piece: The puzzle piece to slide
            piece_start_x: Starting X position of the piece (to calculate slide distance)
        
        Returns:
            SlideResult with x position and confidence
        """
        # Load images
        bg_img = _load_image(background)
        piece_img = _load_image(piece)
        
        # Remove whitespace from piece
        piece_clean = _remove_whitespace(piece_img)
        
        if self.use_edge_detection:
            # Apply edge detection for better matching
            bg_edges = _apply_edge_detection(bg_img)
            piece_edges = _apply_edge_detection(piece_clean)
        else:
            # Convert to grayscale
            bg_edges = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)
            piece_edges = cv2.cvtColor(piece_clean, cv2.COLOR_BGR2GRAY)
        
        # Perform template matching with multiple methods
        methods = [
            cv2.TM_CCOEFF_NORMED,
            cv2.TM_CCORR_NORMED,
        ]
        
        best_confidence = 0
        best_location = (0, 0)
        
        for method in methods:
            result = cv2.matchTemplate(bg_edges, piece_edges, method)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            
            if max_val > best_confidence:
                best_confidence = max_val
                best_location = max_loc
        
        x, y = best_location
        
        # Calculate actual slide distance from starting position
        slide_distance = x - piece_start_x
        
        return SlideResult(
            x=slide_distance if slide_distance > 0 else x,
            y=y,
            confidence=best_confidence
        )
    
    def solve_with_ratio(
        self,
        background: Union[str, bytes, np.ndarray, Image.Image],
        piece: Union[str, bytes, np.ndarray, Image.Image],
        target_width: int = 0
    ) -> Tuple[float, float]:
        """
        Solve and return position as ratio (0-1) of image width
        Useful for different screen sizes
        
        Args:
            background: The background image
            piece: The puzzle piece
            target_width: Target width to calculate ratio for (0 = use background width)
        
        Returns:
            Tuple of (x_ratio, y_ratio) between 0 and 1
        """
        bg_img = _load_image(background)
        result = self.solve(background, piece)
        
        width = target_width if target_width > 0 else bg_img.shape[1]
        height = bg_img.shape[0]
        
        return (result.x / width, result.y / height)


class RotateSolver:
    """
    Solver for rotate/whirl CAPTCHAs
    
    Works by rotating the inner image and comparing with the outer
    to find the angle that gives the best match.
    """
    
    def __init__(self, angle_step: float = 1.0, refine_step: float = 0.1):
        """
        Args:
            angle_step: Initial step size for rotation search in degrees
            refine_step: Refinement step size for fine-tuning
        """
        self.angle_step = angle_step
        self.refine_step = refine_step
    
    def _rotate_image(self, image: np.ndarray, angle: float) -> np.ndarray:
        """Rotate image around center"""
        height, width = image.shape[:2]
        center = (width // 2, height // 2)
        matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(image, matrix, (width, height), borderMode=cv2.BORDER_REPLICATE)
        return rotated
    
    def _calculate_similarity(self, img1: np.ndarray, img2: np.ndarray) -> float:
        """Calculate similarity between two images using SSIM-like metric"""
        if img1.shape != img2.shape:
            # Resize to match
            img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
        
        # Convert to grayscale if needed
        if len(img1.shape) == 3:
            img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        if len(img2.shape) == 3:
            img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
        
        # Calculate normalized cross-correlation
        result = cv2.matchTemplate(img1, img2, cv2.TM_CCOEFF_NORMED)
        return float(result[0][0]) if result.size > 0 else 0.0
    
    @require_license
    def solve(
        self,
        outer: Union[str, bytes, np.ndarray, Image.Image],
        inner: Union[str, bytes, np.ndarray, Image.Image],
    ) -> RotateResult:
        """
        Find the angle to rotate the inner image to match the outer
        
        Args:
            outer: The outer/background image
            inner: The inner image to rotate
        
        Returns:
            RotateResult with angle and confidence
        """
        outer_img = _load_image(outer)
        inner_img = _load_image(inner)
        
        # First pass: coarse search
        best_angle = 0
        best_similarity = -1
        
        for angle in np.arange(0, 360, self.angle_step):
            rotated = self._rotate_image(inner_img, angle)
            similarity = self._calculate_similarity(outer_img, rotated)
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_angle = angle
        
        # Second pass: fine refinement around best angle
        for angle in np.arange(
            best_angle - self.angle_step,
            best_angle + self.angle_step,
            self.refine_step
        ):
            rotated = self._rotate_image(inner_img, angle)
            similarity = self._calculate_similarity(outer_img, rotated)
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_angle = angle
        
        return RotateResult(
            angle=best_angle,
            confidence=max(0, min(1, (best_similarity + 1) / 2))  # Normalize to 0-1
        )
    
    def solve_as_distance(
        self,
        outer: Union[str, bytes, np.ndarray, Image.Image],
        inner: Union[str, bytes, np.ndarray, Image.Image],
        slider_width: int = 348
    ) -> int:
        """
        Solve and return as drag distance for a slider
        
        Args:
            outer: The outer image
            inner: The inner image
            slider_width: Width of the slider control in pixels
        
        Returns:
            Distance to drag the slider
        """
        result = self.solve(outer, inner)
        # Convert angle to slider position (360 degrees = full slider width)
        return int((result.angle / 360) * slider_width)


class ShapesSolver:
    """
    Solver for 3D shapes/matching objects CAPTCHAs
    
    Works by detecting similar shapes in the image and finding
    matching pairs using feature matching.
    """
    
    def __init__(self):
        # Initialize ORB detector for feature matching
        self.orb = cv2.ORB_create(nfeatures=500)
        self.bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    
    def _detect_shapes(self, image: np.ndarray) -> list:
        """Detect shape regions in the image"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Adaptive thresholding
        thresh = cv2.adaptiveThreshold(
            blurred, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV, 11, 2
        )
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter and get bounding boxes for significant shapes
        shapes = []
        min_area = image.shape[0] * image.shape[1] * 0.01  # At least 1% of image
        max_area = image.shape[0] * image.shape[1] * 0.25  # At most 25% of image
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if min_area < area < max_area:
                x, y, w, h = cv2.boundingRect(contour)
                shapes.append({
                    'bbox': (x, y, w, h),
                    'center': (x + w // 2, y + h // 2),
                    'area': area,
                    'contour': contour
                })
        
        return shapes
    
    def _compare_shapes(self, img1: np.ndarray, img2: np.ndarray) -> float:
        """Compare two shape images using feature matching"""
        # Detect keypoints and descriptors
        kp1, des1 = self.orb.detectAndCompute(img1, None)
        kp2, des2 = self.orb.detectAndCompute(img2, None)
        
        if des1 is None or des2 is None:
            return 0.0
        
        # Match descriptors
        try:
            matches = self.bf.match(des1, des2)
            if len(matches) == 0:
                return 0.0
            
            # Calculate match score
            matches = sorted(matches, key=lambda x: x.distance)
            good_matches = [m for m in matches if m.distance < 50]
            
            return len(good_matches) / max(len(kp1), len(kp2), 1)
        except:
            return 0.0
    
    @require_license
    def solve(
        self,
        image: Union[str, bytes, np.ndarray, Image.Image],
    ) -> ShapesResult:
        """
        Find two matching shapes in the image
        
        Args:
            image: The captcha image with multiple 3D shapes
        
        Returns:
            ShapesResult with coordinates of the two matching shapes
        """
        img = _load_image(image)
        shapes = self._detect_shapes(img)
        
        if len(shapes) < 2:
            # Fallback: return center points
            h, w = img.shape[:2]
            return ShapesResult(
                x1=w // 4, y1=h // 2,
                x2=3 * w // 4, y2=h // 2,
                confidence=0.0
            )
        
        # Compare all pairs of shapes
        best_match = (0, 1)
        best_score = -1
        
        for i in range(len(shapes)):
            for j in range(i + 1, len(shapes)):
                # Extract shape regions
                x1, y1, w1, h1 = shapes[i]['bbox']
                x2, y2, w2, h2 = shapes[j]['bbox']
                
                region1 = img[y1:y1+h1, x1:x1+w1]
                region2 = img[y2:y2+h2, x2:x2+w2]
                
                # Resize to same size for comparison
                size = (max(w1, w2), max(h1, h2))
                region1 = cv2.resize(region1, size)
                region2 = cv2.resize(region2, size)
                
                score = self._compare_shapes(region1, region2)
                
                if score > best_score:
                    best_score = score
                    best_match = (i, j)
        
        # Get center points of matching shapes
        shape1 = shapes[best_match[0]]
        shape2 = shapes[best_match[1]]
        
        return ShapesResult(
            x1=shape1['center'][0],
            y1=shape1['center'][1],
            x2=shape2['center'][0],
            y2=shape2['center'][1],
            confidence=best_score
        )
    
    def solve_with_ratio(
        self,
        image: Union[str, bytes, np.ndarray, Image.Image],
        target_width: int = 0,
        target_height: int = 0
    ) -> Tuple[Tuple[float, float], Tuple[float, float]]:
        """
        Solve and return positions as ratios (0-1)
        
        Returns:
            Tuple of ((x1_ratio, y1_ratio), (x2_ratio, y2_ratio))
        """
        img = _load_image(image)
        result = self.solve(image)
        
        width = target_width if target_width > 0 else img.shape[1]
        height = target_height if target_height > 0 else img.shape[0]
        
        return (
            (result.x1 / width, result.y1 / height),
            (result.x2 / width, result.y2 / height)
        )


class TikTokCaptchaSolver:
    """
    Main solver class that combines all CAPTCHA types
    """
    
    def __init__(self):
        self.slide_solver = SlideSolver()
        self.rotate_solver = RotateSolver()
        self.shapes_solver = ShapesSolver()
    
    def solve_slide(
        self,
        background: Union[str, bytes, np.ndarray, Image.Image],
        piece: Union[str, bytes, np.ndarray, Image.Image],
        **kwargs
    ) -> SlideResult:
        """Solve slide/puzzle CAPTCHA"""
        return self.slide_solver.solve(background, piece, **kwargs)
    
    def solve_rotate(
        self,
        outer: Union[str, bytes, np.ndarray, Image.Image],
        inner: Union[str, bytes, np.ndarray, Image.Image],
    ) -> RotateResult:
        """Solve rotate/whirl CAPTCHA"""
        return self.rotate_solver.solve(outer, inner)
    
    def solve_shapes(
        self,
        image: Union[str, bytes, np.ndarray, Image.Image],
    ) -> ShapesResult:
        """Solve 3D shapes/matching CAPTCHA"""
        return self.shapes_solver.solve(image)
    
    def solve_puzzle(self, *args, **kwargs) -> SlideResult:
        """Alias for solve_slide"""
        return self.solve_slide(*args, **kwargs)
    
    def solve_whirl(self, *args, **kwargs) -> RotateResult:
        """Alias for solve_rotate"""
        return self.solve_rotate(*args, **kwargs)
