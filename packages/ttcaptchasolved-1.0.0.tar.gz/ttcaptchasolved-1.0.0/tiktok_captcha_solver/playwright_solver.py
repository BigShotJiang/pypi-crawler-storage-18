"""
Playwright integration for TikTok CAPTCHA Solver
Supports both sync and async Playwright
"""

import asyncio
import time
import random
import base64
from typing import Optional, Callable, Any, Union

try:
    from playwright.sync_api import Page as SyncPage
    from playwright.async_api import Page as AsyncPage
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    SyncPage = None
    AsyncPage = None

from .solver import TikTokCaptchaSolver, SlideResult, RotateResult, ShapesResult


# Common TikTok CAPTCHA selectors
CAPTCHA_SELECTORS = {
    'slide_container': '.captcha_verify_container, .secsdk-captcha-drag-wrapper, [class*="captcha"]',
    'slide_background': '.captcha_verify_img--wrapper img, [class*="captcha"] img[class*="bg"]',
    'slide_piece': '.captcha_verify_slide--slidebar img, [class*="captcha"] img[class*="piece"]',
    'slide_button': '.secsdk-captcha-drag-icon, .captcha_verify_slide--button, [class*="captcha"] [class*="slider"]',
    'rotate_container': '[class*="rotate"], [class*="whirl"]',
    'rotate_outer': '[class*="rotate"] img:first-child',
    'rotate_inner': '[class*="rotate"] img:last-child',
    'shapes_container': '[class*="shapes"], [class*="3d"]',
    'shapes_image': '[class*="shapes"] img',
}


async def _async_human_delay():
    """Async human-like delay"""
    await asyncio.sleep(random.uniform(0.1, 0.3))


def _sync_human_delay():
    """Sync human-like delay"""
    time.sleep(random.uniform(0.1, 0.3))


class PlaywrightSolver:
    """
    Synchronous Playwright integration for CAPTCHA solving
    """
    
    def __init__(
        self,
        page: 'SyncPage',
        max_retries: int = 3,
        retry_delay: float = 1.0,
        callback: Optional[Callable[[str, Any], None]] = None
    ):
        """
        Args:
            page: Playwright Page instance
            max_retries: Maximum retry attempts
            retry_delay: Delay between retries
            callback: Optional callback function(event, data)
        """
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError(
                "Playwright is not installed. Install with: pip install playwright && playwright install"
            )
        
        self.page = page
        self.solver = TikTokCaptchaSolver()
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.callback = callback
    
    def _emit(self, event: str, data: Any = None):
        if self.callback:
            self.callback(event, data)
    
    def _get_image_base64(self, selector: str) -> Optional[str]:
        """Get base64 image from selector"""
        try:
            element = self.page.query_selector(selector)
            if not element:
                return None
            
            src = element.get_attribute('src')
            if not src:
                return None
            
            if src.startswith('data:image'):
                return src.split(',', 1)[1]
            else:
                # Fetch the image using page context
                response = self.page.request.get(src)
                return base64.b64encode(response.body()).decode('utf-8')
        except:
            return None
    
    def _human_drag(self, selector: str, distance_x: int, distance_y: int = 0):
        """Perform human-like drag"""
        element = self.page.query_selector(selector)
        if not element:
            return
        
        box = element.bounding_box()
        if not box:
            return
        
        start_x = box['x'] + box['width'] / 2
        start_y = box['y'] + box['height'] / 2
        
        # Move to start position
        self.page.mouse.move(start_x, start_y)
        _sync_human_delay()
        
        # Mouse down
        self.page.mouse.down()
        _sync_human_delay()
        
        # Drag with human-like movement
        steps = random.randint(15, 25)
        for i in range(steps):
            progress = i / steps
            ease = progress * (2 - progress)
            
            current_x = start_x + (ease * distance_x) + random.uniform(-2, 2)
            current_y = start_y + (ease * distance_y) + random.uniform(-1, 1)
            
            self.page.mouse.move(current_x, current_y)
            time.sleep(random.uniform(0.01, 0.03))
        
        _sync_human_delay()
        self.page.mouse.up()
    
    def detect_captcha_type(self) -> Optional[str]:
        """Detect CAPTCHA type"""
        if self.page.query_selector(CAPTCHA_SELECTORS['slide_container']):
            return 'slide'
        if self.page.query_selector(CAPTCHA_SELECTORS['rotate_container']):
            return 'rotate'
        if self.page.query_selector(CAPTCHA_SELECTORS['shapes_container']):
            return 'shapes'
        return None
    
    def solve_slide_captcha(self) -> bool:
        """Solve slide CAPTCHA"""
        self._emit('solving', 'slide')
        
        bg_base64 = self._get_image_base64(CAPTCHA_SELECTORS['slide_background'])
        piece_base64 = self._get_image_base64(CAPTCHA_SELECTORS['slide_piece'])
        
        if not bg_base64 or not piece_base64:
            self._emit('error', 'Could not get CAPTCHA images')
            return False
        
        try:
            result = self.solver.solve_slide(bg_base64, piece_base64)
            self._emit('solved', result)
            
            self._human_drag(CAPTCHA_SELECTORS['slide_button'], result.x)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_rotate_captcha(self) -> bool:
        """Solve rotate CAPTCHA"""
        self._emit('solving', 'rotate')
        
        outer_base64 = self._get_image_base64(CAPTCHA_SELECTORS['rotate_outer'])
        inner_base64 = self._get_image_base64(CAPTCHA_SELECTORS['rotate_inner'])
        
        if not outer_base64 or not inner_base64:
            self._emit('error', 'Could not get CAPTCHA images')
            return False
        
        try:
            element = self.page.query_selector(CAPTCHA_SELECTORS['slide_button'])
            slider_width = element.bounding_box()['width'] if element else 348
            
            distance = self.solver.rotate_solver.solve_as_distance(
                outer_base64, inner_base64, int(slider_width)
            )
            
            self._emit('solved', {'distance': distance})
            self._human_drag(CAPTCHA_SELECTORS['slide_button'], distance)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_shapes_captcha(self) -> bool:
        """Solve shapes CAPTCHA"""
        self._emit('solving', 'shapes')
        
        image_base64 = self._get_image_base64(CAPTCHA_SELECTORS['shapes_image'])
        
        if not image_base64:
            self._emit('error', 'Could not get CAPTCHA image')
            return False
        
        try:
            result = self.solver.solve_shapes(image_base64)
            self._emit('solved', result)
            
            element = self.page.query_selector(CAPTCHA_SELECTORS['shapes_image'])
            box = element.bounding_box()
            
            # Click first point
            self.page.mouse.click(box['x'] + result.x1, box['y'] + result.y1)
            _sync_human_delay()
            
            # Click second point
            self.page.mouse.click(box['x'] + result.x2, box['y'] + result.y2)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    def solve_captcha_if_present(self) -> bool:
        """Detect and solve any CAPTCHA"""
        time.sleep(0.5)
        
        captcha_type = self.detect_captcha_type()
        if not captcha_type:
            return True
        
        for attempt in range(self.max_retries):
            self._emit('attempt', attempt + 1)
            
            success = False
            if captcha_type == 'slide':
                success = self.solve_slide_captcha()
            elif captcha_type == 'rotate':
                success = self.solve_rotate_captcha()
            elif captcha_type == 'shapes':
                success = self.solve_shapes_captcha()
            
            if success:
                time.sleep(self.retry_delay)
                if not self.detect_captcha_type():
                    self._emit('success', captcha_type)
                    return True
            
            time.sleep(self.retry_delay)
        
        self._emit('failed', captcha_type)
        return False


class AsyncPlaywrightSolver:
    """
    Async Playwright integration for CAPTCHA solving
    """
    
    def __init__(
        self,
        page: 'AsyncPage',
        max_retries: int = 3,
        retry_delay: float = 1.0,
        callback: Optional[Callable[[str, Any], None]] = None
    ):
        """
        Args:
            page: Async Playwright Page instance
            max_retries: Maximum retry attempts
            retry_delay: Delay between retries
            callback: Optional callback function(event, data)
        """
        if not PLAYWRIGHT_AVAILABLE:
            raise ImportError(
                "Playwright is not installed. Install with: pip install playwright && playwright install"
            )
        
        self.page = page
        self.solver = TikTokCaptchaSolver()
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.callback = callback
    
    def _emit(self, event: str, data: Any = None):
        if self.callback:
            self.callback(event, data)
    
    async def _get_image_base64(self, selector: str) -> Optional[str]:
        """Get base64 image from selector"""
        try:
            element = await self.page.query_selector(selector)
            if not element:
                return None
            
            src = await element.get_attribute('src')
            if not src:
                return None
            
            if src.startswith('data:image'):
                return src.split(',', 1)[1]
            else:
                response = await self.page.request.get(src)
                return base64.b64encode(await response.body()).decode('utf-8')
        except:
            return None
    
    async def _human_drag(self, selector: str, distance_x: int, distance_y: int = 0):
        """Perform human-like drag"""
        element = await self.page.query_selector(selector)
        if not element:
            return
        
        box = await element.bounding_box()
        if not box:
            return
        
        start_x = box['x'] + box['width'] / 2
        start_y = box['y'] + box['height'] / 2
        
        await self.page.mouse.move(start_x, start_y)
        await _async_human_delay()
        
        await self.page.mouse.down()
        await _async_human_delay()
        
        steps = random.randint(15, 25)
        for i in range(steps):
            progress = i / steps
            ease = progress * (2 - progress)
            
            current_x = start_x + (ease * distance_x) + random.uniform(-2, 2)
            current_y = start_y + (ease * distance_y) + random.uniform(-1, 1)
            
            await self.page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.01, 0.03))
        
        await _async_human_delay()
        await self.page.mouse.up()
    
    async def detect_captcha_type(self) -> Optional[str]:
        """Detect CAPTCHA type"""
        if await self.page.query_selector(CAPTCHA_SELECTORS['slide_container']):
            return 'slide'
        if await self.page.query_selector(CAPTCHA_SELECTORS['rotate_container']):
            return 'rotate'
        if await self.page.query_selector(CAPTCHA_SELECTORS['shapes_container']):
            return 'shapes'
        return None
    
    async def solve_slide_captcha(self) -> bool:
        """Solve slide CAPTCHA"""
        self._emit('solving', 'slide')
        
        bg_base64 = await self._get_image_base64(CAPTCHA_SELECTORS['slide_background'])
        piece_base64 = await self._get_image_base64(CAPTCHA_SELECTORS['slide_piece'])
        
        if not bg_base64 or not piece_base64:
            self._emit('error', 'Could not get CAPTCHA images')
            return False
        
        try:
            result = self.solver.solve_slide(bg_base64, piece_base64)
            self._emit('solved', result)
            
            await self._human_drag(CAPTCHA_SELECTORS['slide_button'], result.x)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    async def solve_rotate_captcha(self) -> bool:
        """Solve rotate CAPTCHA"""
        self._emit('solving', 'rotate')
        
        outer_base64 = await self._get_image_base64(CAPTCHA_SELECTORS['rotate_outer'])
        inner_base64 = await self._get_image_base64(CAPTCHA_SELECTORS['rotate_inner'])
        
        if not outer_base64 or not inner_base64:
            self._emit('error', 'Could not get CAPTCHA images')
            return False
        
        try:
            element = await self.page.query_selector(CAPTCHA_SELECTORS['slide_button'])
            box = await element.bounding_box() if element else None
            slider_width = box['width'] if box else 348
            
            distance = self.solver.rotate_solver.solve_as_distance(
                outer_base64, inner_base64, int(slider_width)
            )
            
            self._emit('solved', {'distance': distance})
            await self._human_drag(CAPTCHA_SELECTORS['slide_button'], distance)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    async def solve_shapes_captcha(self) -> bool:
        """Solve shapes CAPTCHA"""
        self._emit('solving', 'shapes')
        
        image_base64 = await self._get_image_base64(CAPTCHA_SELECTORS['shapes_image'])
        
        if not image_base64:
            self._emit('error', 'Could not get CAPTCHA image')
            return False
        
        try:
            result = self.solver.solve_shapes(image_base64)
            self._emit('solved', result)
            
            element = await self.page.query_selector(CAPTCHA_SELECTORS['shapes_image'])
            box = await element.bounding_box()
            
            await self.page.mouse.click(box['x'] + result.x1, box['y'] + result.y1)
            await _async_human_delay()
            
            await self.page.mouse.click(box['x'] + result.x2, box['y'] + result.y2)
            return True
        except Exception as e:
            self._emit('error', str(e))
            return False
    
    async def solve_captcha_if_present(self) -> bool:
        """Detect and solve any CAPTCHA"""
        await asyncio.sleep(0.5)
        
        captcha_type = await self.detect_captcha_type()
        if not captcha_type:
            return True
        
        for attempt in range(self.max_retries):
            self._emit('attempt', attempt + 1)
            
            success = False
            if captcha_type == 'slide':
                success = await self.solve_slide_captcha()
            elif captcha_type == 'rotate':
                success = await self.solve_rotate_captcha()
            elif captcha_type == 'shapes':
                success = await self.solve_shapes_captcha()
            
            if success:
                await asyncio.sleep(self.retry_delay)
                if not await self.detect_captcha_type():
                    self._emit('success', captcha_type)
                    return True
            
            await asyncio.sleep(self.retry_delay)
        
        self._emit('failed', captcha_type)
        return False
