"""fairyfly-therm conditions."""
