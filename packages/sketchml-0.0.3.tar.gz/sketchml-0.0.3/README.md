# sketchml: Customized and Simplified package for Core Machine Learning Algorithms

## Installation

Create and activate a Python environment, then install the required dependencies.

```bash
conda create -n sketchml python=3.10 -y
conda activate sketchml
pip install -r requirements.txt
```

Or install directly via pip:

```bash
pip install sketchml
```

Note that this package requires **Python 3.8 or higher**, but it is recommended to use Python 3.10 or higher for the best compatibility and performance.

## Usage

The main function to evaluate a Pentagon Copying Test (PCT) image is `eval_pct`. Below is an example of how to use it:

```python
from sketchml.classif.knn import KNN

knn = KNN(input_dimension="<insert_dimension>", k=3)
```
## License

This project is released under the MIT License. See the `LICENSE` file for details.

## Contact
For questions or feedback, feel free to open an issue on the GitHub repository: https://github.com/htdgv/sketchml/issues 