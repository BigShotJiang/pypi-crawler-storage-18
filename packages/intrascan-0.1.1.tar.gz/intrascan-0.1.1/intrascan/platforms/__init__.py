"""Platform-specific Frida scripts"""
