# NumScript — Prototype

Prototype minimal de NumScript.

Fichiers clés:
- `specs/NUMSCRIPT.md` : spécification minimale.
- `src/numscript/interpreter.py` : interpréteur prototype.
- `examples/simple.ns` : exemple simple (2+3 et affichage).
- `run_numscript.py` : script d'exécution.

Exécuter l'exemple :

```bash
python run_numscript.py examples/simple.ns
```
