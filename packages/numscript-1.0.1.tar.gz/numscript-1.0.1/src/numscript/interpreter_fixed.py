"""NumScript interpreter - FIXED VERSION with proper error handling"""

import shlex
import json
import hashlib
import re
import base64
import math
from typing import Dict, List, Optional


class ReturnException(Exception):
    def __init__(self, value):
        self.value = value


class NumScriptInterpreter:
    def __init__(self):
        self.vars: Dict[str, int] = {}
        self.functions: Dict[str, Dict] = {}
        self.arrays: Dict[str, List[int]] = {}
        self.file_handles: Dict[int, object] = {}
        self.next_file_id: int = 1

    def _eval_operand(self, tok: str, local_args: Optional[List[int]] = None):
        if tok is None:
            return 0
        if isinstance(tok, str) and tok.startswith('@'):
            idx = int(tok[1:]) - 1
            if local_args is None or idx < 0 or idx >= len(local_args):
                return 0
            return local_args[idx]
        if isinstance(tok, str) and tok.startswith('r'):
            return self.vars.get(tok, 0)
        try:
            return int(tok)
        except Exception:
            return tok

    def _check_tokens(self, tokens: List[str], current_index: int, required_count: int, opcode: str) -> bool:
        """Check if we have enough tokens for the opcode."""
        if current_index + required_count > len(tokens):
            raise SyntaxError(
                f"❌ Opcode {opcode} requires {required_count} parameters, "
                f"but only {len(tokens) - current_index - 1} provided.\n"
                f"Error at token index {current_index}: {tokens[current_index]}\n"
                f"Total tokens: {len(tokens)}"
            )
        return True

    def run(self, code: str, local_args: Optional[List[int]] = None) -> Optional[int]:
        # Strip comments before tokenizing
        lines = code.split('\n')
        cleaned_lines = []
        for line in lines:
            if '#' in line:
                line = line[:line.index('#')]
            line = line.strip()
            if line:
                cleaned_lines.append(line)
        code = ' '.join(cleaned_lines)
        
        tokens = shlex.split(code)
        i = 0
        
        while i < len(tokens):
            instr = tokens[i]
            
            try:
                if instr == '1':  # ASSIGN
                    self._check_tokens(tokens, i, 2, instr)
                    var = tokens[i + 1]
                    val_tok = tokens[i + 2]
                    val = self._eval_operand(val_tok, local_args)
                    self.vars[var] = val
                    i += 3

                elif instr == '2':  # PRINT
                    self._check_tokens(tokens, i, 1, instr)
                    val = self._eval_operand(tokens[i + 1], local_args)
                    print(val)
                    i += 2

                elif instr == '3':  # IF
                    self._check_tokens(tokens, i, 4, instr)
                    a_tok = tokens[i + 1]
                    op = tokens[i + 2]
                    b_tok = tokens[i + 3]
                    true_len = int(tokens[i + 4])
                    true_body = tokens[i + 5:i + 5 + true_len]
                    j = i + 5 + true_len
                    if j >= len(tokens):
                        raise SyntaxError(f"❌ Conditional (opcode 3): Missing false block")
                    false_len = int(tokens[j])
                    false_body = tokens[j + 1:j + 1 + false_len]

                    a = self._eval_operand(a_tok, local_args)
                    b = self._eval_operand(b_tok, local_args)
                    cond = False
                    if op == '>':
                        cond = a > b
                    elif op == '<':
                        cond = a < b
                    elif op == '==':
                        cond = a == b

                    if cond:
                        self.run(' '.join(true_body), local_args)
                    else:
                        self.run(' '.join(false_body), local_args)
                    i = j + 1 + false_len

                elif instr == '4':  # LOOP
                    self._check_tokens(tokens, i, 2, instr)
                    count = self._eval_operand(tokens[i + 1], local_args)
                    body_len = int(tokens[i + 2])
                    body_tokens = tokens[i + 3:i + 3 + body_len]
                    if len(body_tokens) < body_len:
                        raise SyntaxError(f"❌ Loop (opcode 4): Expected {body_len} body tokens, got {len(body_tokens)}")
                    for _ in range(count):
                        self.run(' '.join(body_tokens), local_args)
                    i += 3 + body_len

                elif instr == '5':  # FUNCTION_DEF
                    self._check_tokens(tokens, i, 3, instr)
                    name = tokens[i + 1].strip('"')
                    nargs = int(tokens[i + 2])
                    body_len = int(tokens[i + 3])
                    body = tokens[i + 4:i + 4 + body_len]
                    if len(body) < body_len:
                        raise SyntaxError(f"❌ Function def (opcode 5): Expected {body_len} body tokens")
                    self.functions[name] = {'nargs': nargs, 'body': body}
                    i += 4 + body_len

                elif instr == '8':  # CALL
                    self._check_tokens(tokens, i, 1, instr)
                    name = tokens[i + 1].strip('"')
                    func = self.functions.get(name)
                    if func is None:
                        raise ValueError(f"❌ Unknown function: '{name}'")
                    nargs = func['nargs']
                    if i + 2 + nargs >= len(tokens):
                        raise SyntaxError(f"❌ Function call '{name}': expects {nargs} args, got insufficient tokens")
                    args_vals = [self._eval_operand(tokens[i + 2 + k], local_args) for k in range(nargs)]
                    target = tokens[i + 2 + nargs]
                    result = self.call_function(name, args_vals)
                    self.vars[target] = result
                    i += 3 + nargs

                elif instr == '10':  # RETURN
                    self._check_tokens(tokens, i, 1, instr)
                    val = self._eval_operand(tokens[i + 1], local_args)
                    raise ReturnException(val)

                # Arithmetic (opcodes 11-14)
                elif instr == '11':  # ADD
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a + b
                    i += 4

                elif instr == '12':  # SUB
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a - b
                    i += 4

                elif instr == '13':  # MUL
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a * b
                    i += 4

                elif instr == '14':  # DIV
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = int(a / b) if b != 0 else 0
                    i += 4

                # Bitwise (opcodes 15-20)
                elif instr == '15':  # AND
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a & b
                    i += 4

                elif instr == '16':  # OR
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a | b
                    i += 4

                elif instr == '17':  # XOR
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a ^ b
                    i += 4

                elif instr == '18':  # NOT
                    self._check_tokens(tokens, i, 2, instr)
                    target, a = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args)
                    self.vars[target] = ~a
                    i += 3

                elif instr == '19':  # LSHIFT
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a << b
                    i += 4

                elif instr == '20':  # RSHIFT
                    self._check_tokens(tokens, i, 3, instr)
                    target, a, b = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a >> b
                    i += 4

                # Arrays (opcodes 21-24)
                elif instr == '21':  # CREATE_ARRAY
                    self._check_tokens(tokens, i, 2, instr)
                    var_name = tokens[i + 1]
                    size = int(self._eval_operand(tokens[i + 2], local_args))
                    self.arrays[var_name] = [0] * size
                    i += 3

                elif instr == '22':  # SET_ARRAY
                    self._check_tokens(tokens, i, 3, instr)
                    var_name, index, value = tokens[i + 1], self._eval_operand(tokens[i + 2], local_args), self._eval_operand(tokens[i + 3], local_args)
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.arrays[var_name][index] = value
                    i += 4

                elif instr == '23':  # GET_ARRAY
                    self._check_tokens(tokens, i, 3, instr)
                    target, var_name, index = tokens[i + 1], tokens[i + 2], self._eval_operand(tokens[i + 3], local_args)
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.vars[target] = self.arrays[var_name][index]
                    else:
                        self.vars[target] = 0
                    i += 4

                elif instr == '24':  # DELETE_ARRAY
                    self._check_tokens(tokens, i, 1, instr)
                    var_name = tokens[i + 1]
                    if var_name in self.arrays:
                        del self.arrays[var_name]
                    i += 2

                # Strings (opcodes 25-27)
                elif instr == '25':  # CONCAT
                    self._check_tokens(tokens, i, 3, instr)
                    str1, str2, target = str(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    self.vars[target] = str1 + str2
                    i += 4

                elif instr == '26':  # STRLEN
                    self._check_tokens(tokens, i, 2, instr)
                    s, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = len(s)
                    i += 3

                elif instr == '27':  # SUBSTR
                    self._check_tokens(tokens, i, 4, instr)
                    s, start, end, target = str(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), int(self._eval_operand(tokens[i + 3], local_args)), tokens[i + 4]
                    self.vars[target] = s[start:end]
                    i += 5

                elif instr == '28':  # RANDOM
                    import random
                    self._check_tokens(tokens, i, 2, instr)
                    max_val, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = random.randint(0, max_val)
                    i += 3

                elif instr == '29':  # INPUT
                    self._check_tokens(tokens, i, 2, instr)
                    prompt_val, target = self._eval_operand(tokens[i + 1], local_args), tokens[i + 2]
                    try:
                        user_input = int(input(str(prompt_val) + " "))
                        self.vars[target] = user_input
                    except (ValueError, EOFError):
                        self.vars[target] = 0
                    i += 3

                elif instr == '30':  # OPEN
                    self._check_tokens(tokens, i, 3, instr)
                    filename, mode, target = str(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    try:
                        fh = open(filename, ['r', 'w', 'a'][mode] if mode < 3 else 'r')
                        file_id = self.next_file_id
                        self.file_handles[file_id] = fh
                        self.vars[target] = file_id
                        self.next_file_id += 1
                    except IOError:
                        self.vars[target] = -1
                    i += 4

                elif instr == '31':  # CLOSE
                    self._check_tokens(tokens, i, 1, instr)
                    file_id = int(self._eval_operand(tokens[i + 1], local_args))
                    if file_id in self.file_handles:
                        try:
                            self.file_handles[file_id].close()
                            del self.file_handles[file_id]
                        except IOError:
                            pass
                    i += 2

                elif instr == '32':  # READ
                    self._check_tokens(tokens, i, 2, instr)
                    file_id, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    if file_id in self.file_handles:
                        try:
                            self.vars[target] = self.file_handles[file_id].read()
                        except IOError:
                            self.vars[target] = ""
                    else:
                        self.vars[target] = ""
                    i += 3

                elif instr == '33':  # WRITE
                    self._check_tokens(tokens, i, 2, instr)
                    file_id, content = int(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args))
                    if file_id in self.file_handles:
                        try:
                            self.file_handles[file_id].write(content)
                        except IOError:
                            pass
                    i += 3

                elif instr == '34':  # EXISTS
                    import os
                    self._check_tokens(tokens, i, 2, instr)
                    filename, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = 1 if os.path.exists(filename) else 0
                    i += 3

                elif instr == '35':  # HTTP_GET
                    self._check_tokens(tokens, i, 2, instr)
                    url, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    try:
                        import urllib.request
                        with urllib.request.urlopen(url, timeout=5) as response:
                            self.vars[target] = response.read().decode('utf-8')
                    except Exception:
                        self.vars[target] = ""
                    i += 3

                elif instr == '36':  # HTTP_POST
                    self._check_tokens(tokens, i, 3, instr)
                    url, data, target = str(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    try:
                        import urllib.request
                        req = urllib.request.Request(url, data=data.encode('utf-8'))
                        with urllib.request.urlopen(req, timeout=5) as response:
                            self.vars[target] = response.read().decode('utf-8')
                    except Exception:
                        self.vars[target] = ""
                    i += 4

                elif instr == '37':  # SOCKET_CONNECT
                    self._check_tokens(tokens, i, 3, instr)
                    host, port, target = str(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    try:
                        import socket
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(5)
                        sock.connect((host, port))
                        sock_id = self.next_file_id
                        self.file_handles[sock_id] = sock
                        self.vars[target] = sock_id
                        self.next_file_id += 1
                    except Exception:
                        self.vars[target] = -1
                    i += 4

                elif instr == '38':  # SOCKET_SEND
                    self._check_tokens(tokens, i, 2, instr)
                    sock_id, data = int(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args))
                    if sock_id in self.file_handles:
                        try:
                            self.file_handles[sock_id].send(data.encode('utf-8'))
                        except Exception:
                            pass
                    i += 3

                elif instr == '39':  # SOCKET_RECV
                    self._check_tokens(tokens, i, 2, instr)
                    sock_id, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    if sock_id in self.file_handles:
                        try:
                            self.vars[target] = self.file_handles[sock_id].recv(1024).decode('utf-8')
                        except Exception:
                            self.vars[target] = ""
                    else:
                        self.vars[target] = ""
                    i += 3

                elif instr == '40':  # SOCKET_CLOSE
                    self._check_tokens(tokens, i, 1, instr)
                    sock_id = int(self._eval_operand(tokens[i + 1], local_args))
                    if sock_id in self.file_handles:
                        try:
                            self.file_handles[sock_id].close()
                            del self.file_handles[sock_id]
                        except Exception:
                            pass
                    i += 2

                elif instr == '41':  # DB_CONNECT
                    import sqlite3
                    target = tokens[i + 1]
                    conn = sqlite3.connect(':memory:')
                    db_id = self.next_file_id
                    self.file_handles[db_id] = conn
                    self.vars[target] = db_id
                    self.next_file_id += 1
                    i += 2

                elif instr == '42':  # DB_QUERY
                    self._check_tokens(tokens, i, 3, instr)
                    db_id, query, target = int(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    if db_id in self.file_handles:
                        try:
                            cursor = self.file_handles[db_id].cursor()
                            cursor.execute(query)
                            result = cursor.fetchall()
                            self.vars[target] = len(result)
                        except Exception:
                            self.vars[target] = -1
                    else:
                        self.vars[target] = -1
                    i += 4

                elif instr == '43':  # DB_CLOSE
                    self._check_tokens(tokens, i, 1, instr)
                    db_id = int(self._eval_operand(tokens[i + 1], local_args))
                    if db_id in self.file_handles:
                        try:
                            self.file_handles[db_id].close()
                            del self.file_handles[db_id]
                        except Exception:
                            pass
                    i += 2

                elif instr == '44':  # COMPRESS
                    self._check_tokens(tokens, i, 2, instr)
                    import zlib
                    data, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    compressed = zlib.compress(data.encode('utf-8'))
                    self.vars[target] = len(compressed)
                    i += 3

                elif instr == '45':  # DECOMPRESS
                    self._check_tokens(tokens, i, 2, instr)
                    import zlib
                    data, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    try:
                        decompressed = zlib.decompress(data.encode('utf-8'))
                        self.vars[target] = len(decompressed)
                    except Exception:
                        self.vars[target] = -1
                    i += 3

                elif instr == '46':  # SYSTEM
                    import os
                    self._check_tokens(tokens, i, 2, instr)
                    cmd, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    result = os.system(cmd)
                    self.vars[target] = result
                    i += 3

                elif instr == '47':  # ENVIRON
                    import os
                    self._check_tokens(tokens, i, 2, instr)
                    var_name, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = os.environ.get(var_name, "")
                    i += 3

                elif instr == '48':  # TIME
                    import time
                    target = tokens[i + 1]
                    self.vars[target] = int(time.time())
                    i += 2

                elif instr == '49':  # SLEEP
                    import time
                    self._check_tokens(tokens, i, 1, instr)
                    seconds = int(self._eval_operand(tokens[i + 1], local_args))
                    time.sleep(seconds)
                    i += 2

                elif instr == '50':  # VERSION
                    target = tokens[i + 1]
                    self.vars[target] = 100
                    i += 2

                # Opcodes 51-70
                elif instr == '51':  # JSON_ENCODE
                    self._check_tokens(tokens, i, 2, instr)
                    data, target = self._eval_operand(tokens[i + 1], local_args), tokens[i + 2]
                    self.vars[target] = json.dumps(data)
                    i += 3

                elif instr == '52':  # JSON_DECODE
                    self._check_tokens(tokens, i, 2, instr)
                    json_str, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    try:
                        self.vars[target] = str(json.loads(json_str))
                    except json.JSONDecodeError:
                        self.vars[target] = ""
                    i += 3

                elif instr == '53':  # HASH_MD5
                    self._check_tokens(tokens, i, 2, instr)
                    data, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = hashlib.md5(data.encode()).hexdigest()
                    i += 3

                elif instr == '54':  # HASH_SHA256
                    self._check_tokens(tokens, i, 2, instr)
                    data, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = hashlib.sha256(data.encode()).hexdigest()
                    i += 3

                elif instr == '55':  # REGEX_MATCH
                    self._check_tokens(tokens, i, 3, instr)
                    pattern, text, target = str(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    try:
                        self.vars[target] = 1 if re.search(pattern, text) else 0
                    except re.error:
                        self.vars[target] = 0
                    i += 4

                elif instr == '56':  # REGEX_REPLACE
                    self._check_tokens(tokens, i, 4, instr)
                    pattern, repl, text, target = str(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), str(self._eval_operand(tokens[i + 3], local_args)), tokens[i + 4]
                    try:
                        self.vars[target] = re.sub(pattern, repl, text)
                    except re.error:
                        self.vars[target] = text
                    i += 5

                elif instr == '57':  # BASE64_ENCODE
                    self._check_tokens(tokens, i, 2, instr)
                    data, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = base64.b64encode(data.encode()).decode()
                    i += 3

                elif instr == '58':  # BASE64_DECODE
                    self._check_tokens(tokens, i, 2, instr)
                    enc, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    try:
                        self.vars[target] = base64.b64decode(enc).decode()
                    except Exception:
                        self.vars[target] = ""
                    i += 3

                elif instr == '59':  # MATH_SQRT
                    self._check_tokens(tokens, i, 2, instr)
                    a, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = int(math.sqrt(a))
                    i += 3

                elif instr == '60':  # MATH_POW
                    self._check_tokens(tokens, i, 3, instr)
                    a, b, target = int(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    self.vars[target] = int(math.pow(a, b))
                    i += 4

                elif instr == '61':  # STRING_LENGTH
                    self._check_tokens(tokens, i, 2, instr)
                    s, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = len(s)
                    i += 3

                elif instr == '62':  # STRING_UPPER
                    self._check_tokens(tokens, i, 2, instr)
                    s, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = s.upper()
                    i += 3

                elif instr == '63':  # STRING_LOWER
                    self._check_tokens(tokens, i, 2, instr)
                    s, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = s.lower()
                    i += 3

                elif instr == '64':  # STRING_REVERSE
                    self._check_tokens(tokens, i, 2, instr)
                    s, target = str(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = s[::-1]
                    i += 3

                elif instr == '65':  # STRING_STARTSWITH
                    self._check_tokens(tokens, i, 3, instr)
                    s, prefix, target = str(self._eval_operand(tokens[i + 1], local_args)), str(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    self.vars[target] = 1 if s.startswith(prefix) else 0
                    i += 4

                elif instr == '66':  # MATH_ABS
                    self._check_tokens(tokens, i, 2, instr)
                    a, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = abs(a)
                    i += 3

                elif instr == '67':  # MATH_MIN
                    self._check_tokens(tokens, i, 3, instr)
                    a, b, target = int(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    self.vars[target] = min(a, b)
                    i += 4

                elif instr == '68':  # MATH_MAX
                    self._check_tokens(tokens, i, 3, instr)
                    a, b, target = int(self._eval_operand(tokens[i + 1], local_args)), int(self._eval_operand(tokens[i + 2], local_args)), tokens[i + 3]
                    self.vars[target] = max(a, b)
                    i += 4

                elif instr == '69':  # MATH_FLOOR
                    self._check_tokens(tokens, i, 2, instr)
                    val, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = math.floor(val)
                    i += 3

                elif instr == '70':  # MATH_CEIL
                    self._check_tokens(tokens, i, 2, instr)
                    val, target = int(self._eval_operand(tokens[i + 1], local_args)), tokens[i + 2]
                    self.vars[target] = math.ceil(val)
                    i += 3

                else:
                    i += 1

            except (IndexError, KeyError, ValueError, TypeError) as e:
                raise SyntaxError(
                    f"\n{'='*60}\n"
                    f"❌ ERROR IN OPCODE {instr}\n"
                    f"{'='*60}\n"
                    f"Position: token index {i}\n"
                    f"Details: {str(e)}\n"
                    f"Total tokens: {len(tokens)}\n"
                    f"Remaining: {len(tokens) - i} tokens\n"
                    f"Fix: Check your opcode syntax and parameter count\n"
                    f"{'='*60}\n"
                )

        return None

    def call_function(self, name: str, args: List[int]) -> int:
        func = self.functions[name]
        try:
            self.run(' '.join(func['body']), local_args=args)
        except ReturnException as r:
            return r.value
        return 0


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Usage: python interpreter.py <file.ns>')
        sys.exit(1)
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8') as f:
        code = f.read()
    interp = NumScriptInterpreter()
    try:
        interp.run(code)
    except SyntaxError as e:
        print(f"❌ SYNTAX ERROR:\n{e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ RUNTIME ERROR:\n{e}")
        sys.exit(1)
