"""NumScript Parser - Parsing using PLY."""

from ply import yacc
from src.numscript.lexer import tokens

# Simple parser that builds an AST
class ASTNode:
    pass

class Program(ASTNode):
    def __init__(self, instructions):
        self.instructions = instructions
    
    def __repr__(self):
        return f"Program({self.instructions})"

class Instruction(ASTNode):
    def __init__(self, opcode, args):
        self.opcode = opcode
        self.args = args
    
    def __repr__(self):
        return f"Instr({self.opcode}, {self.args})"

class Operand(ASTNode):
    def __init__(self, value):
        self.value = value
    
    def __repr__(self):
        return f"Op({self.value})"

# Parser rules
def p_program(p):
    """program : instruction_list"""
    p[0] = Program(p[1])

def p_instruction_list(p):
    """instruction_list : instruction
                        | instruction_list instruction"""
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_instruction(p):
    """instruction : NUMBER operand_list"""
    p[0] = Instruction(p[1], p[2])

def p_operand_list(p):
    """operand_list : 
                    | operand_list operand"""
    if len(p) == 1:
        p[0] = []
    else:
        p[0] = p[1] + [p[2]]

def p_operand(p):
    """operand : NUMBER
               | VARIABLE
               | STRING
               | PLACEHOLDER"""
    p[0] = Operand(p[1])

def p_error(p):
    if p:
        print(f"Syntax error at '{p.value}'")
    else:
        print("Syntax error at EOF")

# Build the parser
parser = yacc.yacc()

if __name__ == '__main__':
    # Test the parser
    from src.numscript.lexer import lexer
    
    test_code = '1 r1 42 2 r1'
    result = parser.parse(test_code, lexer=lexer)
    print("AST:", result)
    print("Instructions:", result.instructions)
    for instr in result.instructions:
        print(f"  Opcode: {instr.opcode}, Args: {[arg.value for arg in instr.args]}")
