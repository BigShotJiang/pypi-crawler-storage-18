"""Hybrid interpreter combining Standard + Numba JIT for optimal performance."""

import sys
import os
from typing import Dict, List, Any
import re

# Add parent directories to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from interpreter import NumScriptInterpreter
from numba_interpreter import NumbaNumScriptInterpreter


class HybridNumScriptInterpreter:
    """Hybrid interpreter that automatically selects Standard or Numba mode."""
    
    def __init__(self, force_mode: str = None):
        """
        Initialize hybrid interpreter.
        
        Args:
            force_mode: Force specific mode ('standard', 'numba', or None for auto)
        """
        self.force_mode = force_mode
        self.standard_interpreter = NumScriptInterpreter()
        self.numba_interpreter = NumbaNumScriptInterpreter()
        self.vars = {}
        self.functions = {}
        self.arrays = {}
        self.selected_mode = None
        self.last_mode = None
    
    def _should_use_numba(self, code: str) -> bool:
        """
        Detect if code contains patterns that benefit from Numba.
        
        Numba is beneficial for:
        - Array operations (opcodes 21-24)
        - Arithmetic loops (opcode 4 + opcodes 11-14)
        - Bitwise operations (opcodes 15-20)
        - Complex computation patterns
        
        Standard is better for:
        - Simple single operations
        - Conditional logic (opcode 3)
        - Function definitions (opcode 5)
        """
        tokens = code.split()
        
        # Count pattern occurrences
        has_loops = '4' in tokens
        has_arrays = any(op in tokens for op in ['21', '22', '23', '24'])
        has_arithmetic = any(op in tokens for op in ['11', '12', '13', '14'])
        has_bitwise = any(op in tokens for op in ['15', '16', '17', '18', '19', '20'])
        
        # Count tokens for complexity analysis
        token_count = len(tokens)
        
        # Numba is beneficial if:
        # 1. Code has loops + arithmetic/arrays (compute-intensive)
        # 2. Code has array operations
        # 3. Code is complex (many tokens)
        
        if has_loops and (has_arithmetic or has_arrays):
            return True  # Loop + arithmetic = Numba
        
        if has_arrays and token_count > 10:
            return True  # Array operations = Numba
        
        if has_bitwise and has_arithmetic:
            return True  # Mixed operations = Numba
        
        # For simple operations, use standard interpreter
        return False
    
    def run(self, code: str) -> None:
        """Execute code using optimal interpreter."""
        if self.force_mode:
            # Force specific mode
            if self.force_mode.lower() == 'numba':
                self.numba_interpreter.run(code)
                self.selected_mode = 'numba'
            elif self.force_mode.lower() == 'standard':
                self.standard_interpreter.run(code)
                self.selected_mode = 'standard'
        else:
            # Auto-detect best mode
            use_numba = self._should_use_numba(code)
            
            if use_numba:
                self.numba_interpreter.run(code)
                self.selected_mode = 'numba'
            else:
                self.standard_interpreter.run(code)
                self.selected_mode = 'standard'
        
        # Sync interpreter states
        self._sync_states()
    
    def _sync_states(self) -> None:
        """Synchronize state between interpreters."""
        # Copy variables from active interpreter
        if self.selected_mode == 'numba':
            self.vars = self.numba_interpreter.vars.copy()
            self.arrays = self.numba_interpreter.arrays.copy()
            self.functions = self.numba_interpreter.functions.copy()
        else:
            self.vars = self.standard_interpreter.vars.copy()
            self.arrays = self.standard_interpreter.arrays.copy()
            self.functions = self.standard_interpreter.functions.copy()
    
    def set_mode(self, mode: str) -> None:
        """Set interpreter mode ('auto', 'standard', or 'numba')."""
        if mode.lower() == 'auto':
            self.force_mode = None
        elif mode.lower() in ('standard', 'numba'):
            self.force_mode = mode.lower()
        else:
            raise ValueError(f"Invalid mode: {mode}. Use 'auto', 'standard', or 'numba'")
    
    def get_mode(self) -> str:
        """Get current execution mode."""
        if self.force_mode:
            return f"forced:{self.force_mode}"
        return f"auto:{self.selected_mode or 'none'}"
    
    def get_stats(self) -> Dict[str, Any]:
        """Get interpreter statistics."""
        return {
            'mode': self.get_mode(),
            'variables': len(self.vars),
            'functions': len(self.functions),
            'arrays': len(self.arrays),
            'total_array_elements': sum(len(arr) for arr in self.arrays.values())
        }
