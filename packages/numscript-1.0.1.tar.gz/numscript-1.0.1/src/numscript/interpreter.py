"""NumScript interpreter implementation."""

import shlex
import json
import hashlib
import re
import base64
import math
from typing import Dict, List, Optional


class ReturnException(Exception):
    def __init__(self, value):
        self.value = value


class NumScriptInterpreter:
    def __init__(self):
        self.vars: Dict[str, int] = {}
        self.functions: Dict[str, Dict] = {}
        self.arrays: Dict[str, List[int]] = {}  # Array storage
        self.file_handles: Dict[int, object] = {}  # File handle storage
        self.next_file_id: int = 1  # File ID counter

    def _eval_operand(self, tok: str, local_args: Optional[List[int]] = None):
        if tok is None:
            return 0
        if isinstance(tok, str) and tok.startswith('@'):
            idx = int(tok[1:]) - 1
            if local_args is None or idx < 0 or idx >= len(local_args):
                return 0
            return local_args[idx]
        if isinstance(tok, str) and tok.startswith('r'):
            return self.vars.get(tok, 0)
        try:
            return int(tok)
        except Exception:
            return tok

    def _check_tokens(self, tokens: List[str], current_index: int, required_count: int, opcode: str) -> bool:
        """Check if we have enough tokens for the opcode."""
        if current_index + required_count > len(tokens):
            raise SyntaxError(
                f"❌ Opcode {opcode} requires {required_count} parameters, "
                f"but only {len(tokens) - current_index - 1} provided.\n"
                f"Error at token index {current_index}: {tokens[current_index]}\n"
                f"Tokens available: {len(tokens)}"
            )
        return True

    def run(self, code: str, local_args: Optional[List[int]] = None) -> Optional[int]:
        # Strip comments before tokenizing
        lines = code.split('\n')
        cleaned_lines = []
        for line in lines:
            # Remove comments (lines starting with # or text after #)
            if '#' in line:
                line = line[:line.index('#')]
            line = line.strip()
            if line:
                cleaned_lines.append(line)
        code = ' '.join(cleaned_lines)
        
        tokens = shlex.split(code)
        i = 0
        while i < len(tokens):
            instr = tokens[i]
            
            try:
                if instr == '1':
                    self._check_tokens(tokens, i, 2, instr)
                    var = tokens[i + 1]
                    val_tok = tokens[i + 2]
                    val = self._eval_operand(val_tok, local_args)
                    self.vars[var] = val
                    i += 3

                elif instr == '11':
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a + b
                    i += 4

                elif instr == '12':
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a - b
                    i += 4

                elif instr == '13':
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a * b
                    i += 4

                elif instr == '14':
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = int(a / b)
                    i += 4

                elif instr == '2':
                    self._check_tokens(tokens, i, 1, instr)
                    val = self._eval_operand(tokens[i + 1], local_args)
                    print(val)
                    i += 2

                elif instr == '3':
                    self._check_tokens(tokens, i, 4, instr)
                    a_tok = tokens[i + 1]
                    op = tokens[i + 2]
                    b_tok = tokens[i + 3]
                    true_len = int(tokens[i + 4])
                    true_body = tokens[i + 5:i + 5 + true_len]
                    j = i + 5 + true_len
                    if j >= len(tokens):
                        raise SyntaxError(f"❌ Conditional (opcode 3): Missing false block length at position {j}")
                    false_len = int(tokens[j])
                    false_body = tokens[j + 1:j + 1 + false_len]

                    a = self._eval_operand(a_tok, local_args)
                    b = self._eval_operand(b_tok, local_args)
                    cond = False
                    if op == '>':
                        cond = a > b
                    elif op == '<':
                        cond = a < b
                    elif op == '==':
                        cond = a == b

                    if cond:
                        self.run(' '.join(true_body), local_args)
                    else:
                        self.run(' '.join(false_body), local_args)
                    i = j + 1 + false_len

                elif instr == '4':
                    self._check_tokens(tokens, i, 2, instr)
                    count = self._eval_operand(tokens[i + 1], local_args)
                    body_len = int(tokens[i + 2])
                    body_tokens = tokens[i + 3:i + 3 + body_len]
                    if len(body_tokens) < body_len:
                        raise SyntaxError(f"❌ Loop (opcode 4): Expected {body_len} tokens in body, got {len(body_tokens)}")
                    for _ in range(count):
                        self.run(' '.join(body_tokens), local_args)
                    i += 3 + body_len

                elif instr == '5':
                    self._check_tokens(tokens, i, 3, instr)
                    name = tokens[i + 1].strip('"')
                    nargs = int(tokens[i + 2])
                    body_len = int(tokens[i + 3])
                    body = tokens[i + 4:i + 4 + body_len]
                    if len(body) < body_len:
                        raise SyntaxError(f"❌ Function definition (opcode 5): Expected {body_len} tokens in body, got {len(body)}")
                    self.functions[name] = {'nargs': nargs, 'body': body}
                    i += 4 + body_len

                elif instr == '8':
                    self._check_tokens(tokens, i, 2, instr)
                    name = tokens[i + 1].strip('"')
                    func = self.functions.get(name)
                    if func is None:
                        raise ValueError(f"❌ Unknown function: '{name}'")
                    nargs = func['nargs']
                    if i + 2 + nargs >= len(tokens):
                        raise SyntaxError(f"❌ Function call (opcode 8): Function '{name}' expects {nargs} arguments, but not enough tokens")
                    args_vals = [self._eval_operand(tokens[i + 2 + k], local_args) for k in range(nargs)]
                    target = tokens[i + 2 + nargs]
                    result = self.call_function(name, args_vals)
                    self.vars[target] = result
                    i += 3 + nargs

                elif instr == '10':
                    self._check_tokens(tokens, i, 1, instr)
                    val = self._eval_operand(tokens[i + 1], local_args)
                    raise ReturnException(val)

                # Bitwise operations (opcodes 15-20)
                elif instr == '15':  # AND
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a & b
                    i += 4

                elif instr == '16':  # OR
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a | b
                    i += 4

                elif instr == '17':  # XOR
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a ^ b
                    i += 4

                elif instr == '18':  # NOT
                    self._check_tokens(tokens, i, 2, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    self.vars[target] = ~a
                    i += 3

                elif instr == '19':  # LEFT_SHIFT
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a << b
                    i += 4

                elif instr == '20':  # RIGHT_SHIFT
                    self._check_tokens(tokens, i, 3, instr)
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = a >> b
                    i += 4

                # Array operations (opcodes 21-24)
                elif instr == '21':  # CREATE_ARRAY
                    self._check_tokens(tokens, i, 2, instr)
                    var_name = tokens[i + 1]
                    size = int(self._eval_operand(tokens[i + 2], local_args))
                    self.arrays[var_name] = [0] * size
                    i += 3

                elif instr == '22':  # SET_ARRAY
                    self._check_tokens(tokens, i, 3, instr)
                    var_name = tokens[i + 1]
                    index = self._eval_operand(tokens[i + 2], local_args)
                    value = self._eval_operand(tokens[i + 3], local_args)
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.arrays[var_name][index] = value
                    i += 4

                elif instr == '23':  # GET_ARRAY
                    self._check_tokens(tokens, i, 3, instr)
                    var_name = tokens[i + 1]
                    index = self._eval_operand(tokens[i + 2], local_args)
                    target = tokens[i + 3]
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.vars[target] = self.arrays[var_name][index]
                    else:
                        self.vars[target] = 0
                    i += 4

                elif instr == '24':  # ARRAY_LENGTH
                    var_name = tokens[i + 1]
                    target = tokens[i + 2]
                    self.vars[target] = len(self.arrays.get(var_name, []))
                    i += 3

                # String operations (opcodes 25-27)
                elif instr == '25':  # CONCAT
                    target = tokens[i + 1]
                    s1 = str(self._eval_operand(tokens[i + 2], local_args))
                    s2 = str(self._eval_operand(tokens[i + 3], local_args))
                    # Convert concatenated string to int if possible
                    try:
                        self.vars[target] = int(s1 + s2)
                    except ValueError:
                        # If not a valid int, store as-is (would need string storage)
                        self.vars[target] = 0
                    i += 4

                elif instr == '26':  # STRING_LENGTH
                    target = tokens[i + 1]
                    s = str(self._eval_operand(tokens[i + 2], local_args))
                    self.vars[target] = len(s)
                    i += 3

                elif instr == '27':  # SUBSTRING
                    target = tokens[i + 1]
                    s = str(self._eval_operand(tokens[i + 2], local_args))
                    start = self._eval_operand(tokens[i + 3], local_args)
                    end = self._eval_operand(tokens[i + 4], local_args)
                    result = s[start:end]
                    try:
                        self.vars[target] = int(result)
                    except ValueError:
                        self.vars[target] = 0
                    i += 5

                elif instr == '28':  # RANDOM
                    import random
                    min_val = self._eval_operand(tokens[i + 1], local_args)
                    max_val = self._eval_operand(tokens[i + 2], local_args)
                    target = tokens[i + 3]
                    self.vars[target] = random.randint(min_val, max_val)
                    i += 4

                elif instr == '29':  # INPUT
                    prompt_val = self._eval_operand(tokens[i + 1], local_args)
                    target = tokens[i + 2]
                    try:
                        user_input = int(input(str(prompt_val) + " "))
                        self.vars[target] = user_input
                    except ValueError:
                        self.vars[target] = 0
                    except EOFError:
                        self.vars[target] = 0
                    i += 3

                elif instr == '30':  # OPEN file
                    filename = str(self._eval_operand(tokens[i + 1], local_args))
                    mode = int(self._eval_operand(tokens[i + 2], local_args))
                    target = tokens[i + 3]
                    fh = None
                    try:
                        if mode == 0:  # read
                            fh = open(filename, 'r')
                        elif mode == 1:  # write
                            fh = open(filename, 'w')
                        elif mode == 2:  # append
                            fh = open(filename, 'a')
                    except Exception:
                        fh = None
                    
                    if fh:
                        file_id = self.next_file_id
                        self.file_handles[file_id] = fh
                        self.vars[target] = file_id
                        self.next_file_id += 1
                    else:
                        self.vars[target] = -1
                    i += 4

                elif instr == '31':  # CLOSE file
                    file_id = int(self._eval_operand(tokens[i + 1], local_args))
                    if file_id in self.file_handles:
                        try:
                            self.file_handles[file_id].close()
                            del self.file_handles[file_id]
                        except IOError:
                            pass
                    i += 2

                elif instr == '32':  # READ from file
                file_id = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                if file_id in self.file_handles:
                    try:
                        line = self.file_handles[file_id].readline()
                        if line:
                            line = line.rstrip('\n')
                            try:
                                self.vars[target] = int(line)
                            except ValueError:
                                self.vars[target] = 0
                        else:
                            self.vars[target] = -1  # EOF
                    except IOError:
                        self.vars[target] = -1
                else:
                    self.vars[target] = -1
                i += 3

            elif instr == '33':  # WRITE to file
                file_id = int(self._eval_operand(tokens[i + 1], local_args))
                value = str(self._eval_operand(tokens[i + 2], local_args))
                if file_id in self.file_handles:
                    try:
                        self.file_handles[file_id].write(value + '\n')
                    except IOError:
                        pass
                i += 3

            elif instr == '34':  # EXISTS - check if file exists
                filename = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                import os
                self.vars[target] = 1 if os.path.exists(filename) else 0
                i += 3

            elif instr == '35':  # HTTP_GET
                url = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import urllib.request
                    with urllib.request.urlopen(url, timeout=5) as response:
                        content = response.read().decode('utf-8')
                        # Try to convert to int, return first number found or 0
                        import re
                        match = re.search(r'-?\d+', content)
                        self.vars[target] = int(match.group()) if match else 0
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '36':  # HTTP_POST
                url = str(self._eval_operand(tokens[i + 1], local_args))
                data = str(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                try:
                    import urllib.request
                    req = urllib.request.Request(url, data=data.encode('utf-8'), method='POST')
                    with urllib.request.urlopen(req, timeout=5) as response:
                        content = response.read().decode('utf-8')
                        import re
                        match = re.search(r'-?\d+', content)
                        self.vars[target] = int(match.group()) if match else 0
                except Exception:
                    self.vars[target] = -1
                i += 4

            elif instr == '37':  # SOCKET_CONNECT
                host = str(self._eval_operand(tokens[i + 1], local_args))
                port = int(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                try:
                    import socket
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.connect((host, port))
                    sock.settimeout(5)
                    socket_id = self.next_file_id
                    self.file_handles[socket_id] = sock
                    self.vars[target] = socket_id
                    self.next_file_id += 1
                except Exception:
                    self.vars[target] = -1
                i += 4

            elif instr == '38':  # SOCKET_SEND
                socket_id = int(self._eval_operand(tokens[i + 1], local_args))
                data = str(self._eval_operand(tokens[i + 2], local_args))
                if socket_id in self.file_handles:
                    try:
                        sock = self.file_handles[socket_id]
                        sock.send(data.encode('utf-8'))
                    except Exception:
                        pass
                i += 3

            elif instr == '39':  # SOCKET_RECV
                socket_id = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    if socket_id in self.file_handles:
                        sock = self.file_handles[socket_id]
                        data = sock.recv(1024).decode('utf-8')
                        if data:
                            import re
                            match = re.search(r'-?\d+', data)
                            self.vars[target] = int(match.group()) if match else 0
                        else:
                            self.vars[target] = -1
                    else:
                        self.vars[target] = -1
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '40':  # SOCKET_CLOSE
                socket_id = int(self._eval_operand(tokens[i + 1], local_args))
                if socket_id in self.file_handles:
                    try:
                        sock = self.file_handles[socket_id]
                        sock.close()
                        del self.file_handles[socket_id]
                    except Exception:
                        pass
                i += 2

            elif instr == '41':  # DB_CONNECT (simulated with SQLite)
                db_name = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import sqlite3
                    conn = sqlite3.connect(db_name)
                    db_id = self.next_file_id
                    self.file_handles[db_id] = conn
                    self.vars[target] = db_id
                    self.next_file_id += 1
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '42':  # DB_QUERY
                db_id = int(self._eval_operand(tokens[i + 1], local_args))
                query = str(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                try:
                    if db_id in self.file_handles:
                        conn = self.file_handles[db_id]
                        cursor = conn.cursor()
                        cursor.execute(query)
                        conn.commit()
                        result = cursor.fetchone()
                        self.vars[target] = result[0] if result else 0
                    else:
                        self.vars[target] = -1
                except Exception:
                    self.vars[target] = -1
                i += 4

            elif instr == '43':  # DB_CLOSE
                db_id = int(self._eval_operand(tokens[i + 1], local_args))
                if db_id in self.file_handles:
                    try:
                        self.file_handles[db_id].close()
                        del self.file_handles[db_id]
                    except Exception:
                        pass
                i += 2

            elif instr == '44':  # COMPRESS
                data = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import zlib
                    compressed = zlib.compress(data.encode('utf-8'))
                    self.vars[target] = len(compressed)
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '45':  # DECOMPRESS (returns decompressed length)
                data = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import zlib
                    # For demo, just return positive value
                    self.vars[target] = len(data) * 2
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '46':  # SYSTEM (execute command, return exit code)
                command = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import subprocess
                    result = subprocess.run(command, shell=True, capture_output=True, timeout=5)
                    self.vars[target] = result.returncode
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '47':  # ENVIRON (get environment variable)
                var_name = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    import os
                    value = os.environ.get(var_name, '')
                    try:
                        self.vars[target] = int(value)
                    except ValueError:
                        self.vars[target] = 0
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '48':  # TIME (get current timestamp)
                target = tokens[i + 1]
                try:
                    import time
                    self.vars[target] = int(time.time())
                except Exception:
                    self.vars[target] = -1
                i += 2

            elif instr == '49':  # SLEEP (pause execution)
                duration = int(self._eval_operand(tokens[i + 1], local_args))
                try:
                    import time
                    time.sleep(duration / 1000.0)  # milliseconds to seconds
                except Exception:
                    pass
                i += 2

            elif instr == '50':  # VERSION (get NumScript version)
                target = tokens[i + 1]
                self.vars[target] = 100  # Version 1.00 = 100
                i += 2

            # Opcodes 51-60: Data processing and crypto
            elif instr == '51':  # JSON_ENCODE - Encode value to JSON string (stored in string var)
                val_tok = tokens[i + 1]
                target = tokens[i + 2]
                val = self._eval_operand(val_tok, local_args)
                try:
                    json_str = json.dumps(val)
                    self.vars[target] = len(json_str)  # Store length for now
                    if not hasattr(self, 'json_strings'):
                        self.json_strings = {}
                    self.json_strings[target] = json_str
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '52':  # JSON_DECODE - Decode JSON string to value
                json_str = tokens[i + 1]
                target = tokens[i + 2]
                try:
                    if not hasattr(self, 'json_strings'):
                        self.json_strings = {}
                    if json_str in self.json_strings:
                        parsed = json.loads(self.json_strings[json_str])
                    else:
                        parsed = json.loads(json_str)
                    self.vars[target] = int(parsed) if isinstance(parsed, (int, float)) else 0
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '53':  # HASH_MD5 - Compute MD5 hash
                val = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    hash_val = hashlib.md5(val.encode()).hexdigest()
                    self.vars[target] = len(hash_val)
                    if not hasattr(self, 'hash_strings'):
                        self.hash_strings = {}
                    self.hash_strings[target] = hash_val
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '54':  # HASH_SHA256 - Compute SHA256 hash
                val = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    hash_val = hashlib.sha256(val.encode()).hexdigest()
                    self.vars[target] = len(hash_val)
                    if not hasattr(self, 'hash_strings'):
                        self.hash_strings = {}
                    self.hash_strings[target] = hash_val
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '55':  # REGEX_MATCH - Check if pattern matches string
                pattern = str(self._eval_operand(tokens[i + 1], local_args))
                text = str(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                try:
                    match = re.search(pattern, text)
                    self.vars[target] = 1 if match else 0
                except Exception:
                    self.vars[target] = -1
                i += 4

            elif instr == '56':  # REGEX_REPLACE - Replace pattern matches
                pattern = str(self._eval_operand(tokens[i + 1], local_args))
                replacement = str(self._eval_operand(tokens[i + 2], local_args))
                text = str(self._eval_operand(tokens[i + 3], local_args))
                target = tokens[i + 4]
                try:
                    result = re.sub(pattern, replacement, text)
                    self.vars[target] = len(result)
                    if not hasattr(self, 'string_results'):
                        self.string_results = {}
                    self.string_results[target] = result
                except Exception:
                    self.vars[target] = -1
                i += 5

            elif instr == '57':  # BASE64_ENCODE - Encode to base64
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    encoded = base64.b64encode(text.encode()).decode()
                    self.vars[target] = len(encoded)
                    if not hasattr(self, 'base64_strings'):
                        self.base64_strings = {}
                    self.base64_strings[target] = encoded
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '58':  # BASE64_DECODE - Decode from base64
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    if not hasattr(self, 'base64_strings'):
                        self.base64_strings = {}
                    if text in self.base64_strings:
                        decoded = base64.b64decode(self.base64_strings[text]).decode()
                    else:
                        decoded = base64.b64decode(text).decode()
                    self.vars[target] = len(decoded)
                    if not hasattr(self, 'string_results'):
                        self.string_results = {}
                    self.string_results[target] = decoded
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '59':  # MATH_SQRT - Square root
                val = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                try:
                    self.vars[target] = int(math.sqrt(val))
                except Exception:
                    self.vars[target] = -1
                i += 3

            elif instr == '60':  # MATH_POW - Power (a^b)
                base = int(self._eval_operand(tokens[i + 1], local_args))
                exp = int(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                try:
                    self.vars[target] = int(math.pow(base, exp))
                except Exception:
                    self.vars[target] = -1
                i += 4

            # Opcodes 61-70: Advanced string and math operations
            elif instr == '61':  # STRING_LENGTH - Get string length
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                self.vars[target] = len(text)
                i += 3

            elif instr == '62':  # STRING_UPPER - Convert to uppercase
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                result = text.upper()
                if not hasattr(self, 'string_results'):
                    self.string_results = {}
                self.string_results[target] = result
                self.vars[target] = len(result)
                i += 3

            elif instr == '63':  # STRING_LOWER - Convert to lowercase
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                result = text.lower()
                if not hasattr(self, 'string_results'):
                    self.string_results = {}
                self.string_results[target] = result
                self.vars[target] = len(result)
                i += 3

            elif instr == '64':  # STRING_REVERSE - Reverse string
                text = str(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                result = text[::-1]
                if not hasattr(self, 'string_results'):
                    self.string_results = {}
                self.string_results[target] = result
                self.vars[target] = len(result)
                i += 3

            elif instr == '65':  # STRING_STARTSWITH - Check if starts with substring
                text = str(self._eval_operand(tokens[i + 1], local_args))
                prefix = str(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                self.vars[target] = 1 if text.startswith(prefix) else 0
                i += 4

            elif instr == '66':  # MATH_ABS - Absolute value
                val = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                self.vars[target] = abs(val)
                i += 3

            elif instr == '67':  # MATH_MIN - Minimum of two values
                a = int(self._eval_operand(tokens[i + 1], local_args))
                b = int(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                self.vars[target] = min(a, b)
                i += 4

            elif instr == '68':  # MATH_MAX - Maximum of two values
                a = int(self._eval_operand(tokens[i + 1], local_args))
                b = int(self._eval_operand(tokens[i + 2], local_args))
                target = tokens[i + 3]
                self.vars[target] = max(a, b)
                i += 4

            elif instr == '69':  # MATH_FLOOR - Floor division
                val = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                self.vars[target] = math.floor(val)
                i += 3

            elif instr == '70':  # MATH_CEIL - Ceiling division
                val = int(self._eval_operand(tokens[i + 1], local_args))
                target = tokens[i + 2]
                self.vars[target] = math.ceil(val)
                i += 3

            else:
                i += 1
        
        except (IndexError, KeyError, ValueError, TypeError) as e:
            raise SyntaxError(f"❌ ERROR IN OPCODE {tokens[i] if i < len(tokens) else 'unknown'}\n"
                            f"Position: token index {i}\n"
                            f"Details: {str(e)}\n"
                            f"Total tokens: {len(tokens)}")
        
        return None

    def call_function(self, name: str, args: List[int]) -> int:
        func = self.functions[name]
        try:
            self.run(' '.join(func['body']), local_args=args)
        except ReturnException as r:
            return r.value
        return 0


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Usage: python interpreter.py <file.ns>')
        sys.exit(1)
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8') as f:
        code = f.read()
    interp = NumScriptInterpreter()
    interp.run(code)
