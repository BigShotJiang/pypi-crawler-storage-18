"""NumScript Lexer - Tokenization using PLY."""

from ply import lex

# List of token names
tokens = (
    'NUMBER',
    'VARIABLE',
    'STRING',
    'PLACEHOLDER',
    'OPERATOR',
)

# Token rules (longer patterns first)
def t_STRING(t):
    r'"[^"]*"'
    t.value = t.value[1:-1]  # Remove quotes
    return t

def t_PLACEHOLDER(t):
    r'@[0-9]+'
    t.value = int(t.value[1:])  # Extract number
    return t

def t_VARIABLE(t):
    r'r[0-9]+'
    return t

def t_NUMBER(t):
    r'[0-9]+'
    t.value = int(t.value)
    return t

t_OPERATOR = r'[><=!&|+\-*/%]+'

# Ignored characters (whitespace)
t_ignore = ' \t\n'

def t_error(t):
    print(f"Illegal character '{t.value[0]}'")
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

if __name__ == '__main__':
    # Test the lexer
    test_code = '1 r1 42 2 r1 3 r1 > 5 2 2 r1 1 2 99'
    lexer.input(test_code)
    
    print("Tokens:")
    for tok in lexer:
        print(f"  {tok.type}: {tok.value}")
