# opcodes_50_59.py - Advanced Opcodes Implementation
# Part of Phase 1: Foundations
# Date: 26 December 2025

"""
Opcodes 50-59: Advanced Features for NumScript
- Try/Catch (opcode 50)
- Async/Await (opcodes 51-52)
- Macros (opcode 53)
- JIT Compilation (opcode 54)
- Optimization (opcode 55)
- Python Interoperability (opcode 56)
- WebAssembly Interoperability (opcode 57)
- Assertions (opcode 58)
- Type Checking (opcode 59)
"""

import sys
import inspect
from typing import Any, Dict, List, Callable, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


# ============================================================================
# OPCODE 50: TRY_CATCH - Exception Handling
# ============================================================================

class NumScriptException(Exception):
    """Base class for NumScript exceptions"""
    pass


class ZeroDivisionError(NumScriptException):
    """Division by zero"""
    pass


class TypeMismatchError(NumScriptException):
    """Type mismatch in operation"""
    pass


class RuntimeError(NumScriptException):
    """General runtime error"""
    pass


@dataclass
class ErrorObject:
    """Error object structure for exceptions"""
    error_type: str
    message: str
    line: int = 0
    stacktrace: List[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.error_type,
            "message": self.message,
            "line": self.line,
            "stacktrace": self.stacktrace or []
        }


def execute_opcode_50(vm, try_block_ref: int, catch_block_ref: int, error_var_ref: int) -> Any:
    """
    Opcode 50: TRY_CATCH - Exception handling
    
    Args:
        vm: Virtual machine instance
        try_block_ref: Variable containing try block code
        catch_block_ref: Variable containing catch block code
        error_var_ref: Variable to store error object
    
    Returns:
        Result from try block or catch block
    
    Example:
        50 1 2 3  # var1=try_block, var2=catch_block, var3=error_var
    """
    try:
        # Execute try block
        try_code = vm.get_variable(try_block_ref)
        result = vm.execute_block(try_code)
        return result
        
    except NumScriptException as e:
        # Create error object
        error_obj = ErrorObject(
            error_type=type(e).__name__,
            message=str(e),
            line=vm.current_line,
            stacktrace=vm.get_stacktrace()
        )
        
        # Store error in variable
        vm.set_variable(error_var_ref, error_obj.to_dict())
        
        # Execute catch block (wrap to catch any errors during catch)
        catch_code = vm.get_variable(catch_block_ref)
        try:
            result = vm.execute_block(catch_code)
            return result
        except Exception:
            # If catch block itself fails, still return result
            return None
        
    except Exception as e:
        # Wrap Python exceptions
        error_obj = ErrorObject(
            error_type="Exception",
            message=str(e),
            line=vm.current_line,
            stacktrace=vm.get_stacktrace()
        )
        vm.set_variable(error_var_ref, error_obj.to_dict())
        
        catch_code = vm.get_variable(catch_block_ref)
        try:
            return vm.execute_block(catch_code)
        except Exception:
            return None


# ============================================================================
# OPCODES 51-52: ASYNC/AWAIT - Asynchronous Operations
# ============================================================================

class Promise:
    """Simple Promise implementation for async operations"""
    
    def __init__(self, executor=None):
        self.state = "pending"  # pending, fulfilled, rejected
        self.value = None
        self.reason = None
        self.callbacks = []
        
        if executor:
            try:
                result = executor()
                self.resolve(result)
            except Exception as e:
                self.reject(e)
    
    def resolve(self, value):
        """Resolve promise with value"""
        if self.state != "pending":
            return
        self.state = "fulfilled"
        self.value = value
        self._notify_callbacks()
    
    def reject(self, reason):
        """Reject promise with reason"""
        if self.state != "pending":
            return
        self.state = "rejected"
        self.reason = reason
        self._notify_callbacks()
    
    def then(self, on_fulfilled=None, on_rejected=None):
        """Register callbacks"""
        self.callbacks.append((on_fulfilled, on_rejected))
        if self.state != "pending":
            self._notify_callbacks()
        return self
    
    def _notify_callbacks(self):
        """Notify all registered callbacks"""
        for on_fulfilled, on_rejected in self.callbacks:
            if self.state == "fulfilled" and on_fulfilled:
                on_fulfilled(self.value)
            elif self.state == "rejected" and on_rejected:
                on_rejected(self.reason)


def execute_opcode_51(vm, func_ref: int, result_var_ref: int) -> Promise:
    """
    Opcode 51: ASYNC - Mark function as asynchronous
    
    Args:
        vm: Virtual machine instance
        func_ref: Reference to function
        result_var_ref: Variable to store promise
    
    Returns:
        Promise object
    
    Example:
        51 0 1  # var0=function, store promise in var1
    """
    func = vm.get_variable(func_ref)
    
    def executor():
        # Execute function asynchronously
        return vm.call_function(func)
    
    promise = Promise(executor=executor)
    vm.set_variable(result_var_ref, promise)
    return promise


def execute_opcode_52(vm, promise_var_ref: int, result_var_ref: int) -> Any:
    """
    Opcode 52: AWAIT - Wait for promise resolution
    
    Args:
        vm: Virtual machine instance
        promise_var_ref: Variable containing promise
        result_var_ref: Variable to store resolved value
    
    Returns:
        Resolved value
    
    Example:
        52 0 1  # var0=promise, store result in var1
    """
    promise = vm.get_variable(promise_var_ref)
    
    if not isinstance(promise, Promise):
        raise TypeMismatchError(f"Expected Promise, got {type(promise).__name__}")
    
    # Wait for promise (blocking)
    max_wait = 30  # seconds
    import time
    start = time.time()
    
    while promise.state == "pending":
        if time.time() - start > max_wait:
            raise RuntimeError("Promise timeout")
        time.sleep(0.01)
    
    if promise.state == "fulfilled":
        vm.set_variable(result_var_ref, promise.value)
        return promise.value
    else:
        raise RuntimeError(f"Promise rejected: {promise.reason}")


# ============================================================================
# OPCODE 53: MACRO - Compile-time macros
# ============================================================================

@dataclass
@dataclass
class Macro:
    """Macro definition"""
    name: str
    params: List[str]
    body: str
    
    def expand(self, args: List[Any]) -> str:
        """Expand macro with arguments"""
        result = self.body
        for param, arg in zip(self.params, args):
            # Simple token replacement: replace $(param) with arg
            result = result.replace(f"$({param})", str(arg))
        return result


def execute_opcode_53(vm, name_var_ref: int, body_var_ref: int) -> Macro:
    """
    Opcode 53: MACRO - Define compile-time macro
    
    Args:
        vm: Virtual machine instance
        name_var_ref: Macro name
        body_var_ref: Macro body
    
    Returns:
        Macro object
    
    Example:
        53 0 1  # var0=name, var1=body
    """
    name = vm.get_variable(name_var_ref)
    body = vm.get_variable(body_var_ref)
    
    # Extract parameters from body (format: "$(param)")
    import re
    params = re.findall(r'\$\((\w+)\)', body)
    
    macro = Macro(name=name, params=list(set(params)), body=body)
    vm.register_macro(macro)
    return macro


# ============================================================================
# OPCODE 54: JIT_COMPILE - Just-in-Time Compilation
# ============================================================================

def execute_opcode_54(vm, code_var_ref: int, result_var_ref: int) -> Callable:
    """
    Opcode 54: JIT_COMPILE - Compile code to machine code
    
    Uses Numba for critical loops, LLVM for general code
    
    Args:
        vm: Virtual machine instance
        code_var_ref: Code to compile
        result_var_ref: Compiled function reference
    
    Returns:
        Compiled function
    
    Example:
        54 0 1  # Compile var0, store in var1
    """
    try:
        from numba import jit
    except ImportError:
        raise RuntimeError("Numba not installed. Install with: pip install numba")
    
    code = vm.get_variable(code_var_ref)
    
    # Compile with Numba
    @jit(nopython=True)
    def compiled_func(*args):
        # Execute compiled code
        return vm.execute_numba_block(code, args)
    
    vm.set_variable(result_var_ref, compiled_func)
    return compiled_func


# ============================================================================
# OPCODE 55: OPTIMIZE - Runtime optimization hints
# ============================================================================

class OptimizationLevel(Enum):
    """Optimization levels"""
    NONE = 0
    BASIC = 1
    AGGRESSIVE = 2
    EXTREME = 3


def execute_opcode_55(vm, var_ref: int, opt_level: int) -> None:
    """
    Opcode 55: OPTIMIZE - Hint optimizer about code
    
    Args:
        vm: Virtual machine instance
        var_ref: Variable/code to optimize
        opt_level: Optimization level (0-3)
    
    Example:
        55 0 2  # Optimize var0 with level 2
    """
    if opt_level < 0 or opt_level > 3:
        raise ValueError(f"Invalid optimization level: {opt_level}")
    
    opt_enum = OptimizationLevel(opt_level)
    vm.set_optimization_level(var_ref, opt_enum)
    
    if opt_enum == OptimizationLevel.AGGRESSIVE:
        # Run JIT compilation
        execute_opcode_54(vm, var_ref, var_ref)
    elif opt_enum == OptimizationLevel.EXTREME:
        # Run JIT + memory pooling
        vm.enable_memory_pooling(var_ref)
        execute_opcode_54(vm, var_ref, var_ref)


# ============================================================================
# OPCODE 56: PY_CALL - Python Interoperability
# ============================================================================

def execute_opcode_56(vm, module_func_str: str, args: List[int], result_var_ref: int) -> Any:
    """
    Opcode 56: PY_CALL - Call Python function from NumScript
    
    Args:
        vm: Virtual machine instance
        module_func_str: "module.function" format
        args: List of variable references (arguments)
        result_var_ref: Variable to store result
    
    Returns:
        Function result
    
    Example:
        56 "math.sin" [0] 1  # math.sin(var0) -> var1
        56 "numpy.add" [0, 1] 2  # numpy.add(var0, var1) -> var2
    """
    # Parse module.function
    if '.' not in module_func_str:
        raise ValueError(f"Expected 'module.function', got '{module_func_str}'")
    
    module_name, func_name = module_func_str.rsplit('.', 1)
    
    # Import module
    try:
        module = __import__(module_name)
        func = getattr(module, func_name)
    except (ImportError, AttributeError) as e:
        raise RuntimeError(f"Cannot import {module_func_str}: {e}")
    
    # Get arguments from variables
    py_args = [vm.get_variable(arg_ref) for arg_ref in args]
    
    # Call Python function
    try:
        result = func(*py_args)
        vm.set_variable(result_var_ref, result)
        return result
    except Exception as e:
        raise RuntimeError(f"Error calling {module_func_str}: {e}")


# ============================================================================
# OPCODE 57: WASM_CALL - WebAssembly Interoperability
# ============================================================================

def execute_opcode_57(vm, module_func_str: str, args: List[int], result_var_ref: int) -> Any:
    """
    Opcode 57: WASM_CALL - Call WebAssembly function
    
    Args:
        vm: Virtual machine instance
        module_func_str: "module.function" format
        args: List of variable references
        result_var_ref: Variable to store result
    
    Returns:
        Function result
    
    Example:
        57 "mymodule.expensive_calc" [0, 1] 2
    """
    try:
        import wasmer
    except (ImportError, ModuleNotFoundError):
        raise RuntimeError("WASM module not found. wasmer not installed. Install with: pip install wasmer")
    
    # Load WASM module
    module_name, func_name = module_func_str.rsplit('.', 1)
    
    # Get WASM module from registry
    wasm_module = vm.get_wasm_module(module_name)
    if not wasm_module:
        raise RuntimeError(f"WASM module '{module_name}' not found")
    
    # Get arguments
    wasm_args = [vm.get_variable(arg_ref) for arg_ref in args]
    
    # Call WASM function
    try:
        result = wasm_module.call(func_name, *wasm_args)
        vm.set_variable(result_var_ref, result)
        return result
    except Exception as e:
        raise RuntimeError(f"Error calling WASM {module_func_str}: {e}")


# ============================================================================
# OPCODE 58: ASSERT - Assertions
# ============================================================================

def execute_opcode_58(vm, condition_var_ref: int, message_var_ref: Optional[int] = None) -> bool:
    """
    Opcode 58: ASSERT - Assertion check
    
    Args:
        vm: Virtual machine instance
        condition_var_ref: Variable containing condition
        message_var_ref: Optional error message variable
    
    Returns:
        True if assertion passes
    
    Raises:
        AssertionError if condition is false
    
    Example:
        58 0 1  # assert(var0) with message var1
        58 0    # assert(var0) without message
    """
    condition = vm.get_variable(condition_var_ref)
    
    if not condition:
        message = "Assertion failed"
        if message_var_ref is not None:
            message = vm.get_variable(message_var_ref)
        
        raise AssertionError(message)
    
    return True


# ============================================================================
# OPCODE 59: TYPE_CHECK - Type Checking & Coercion
# ============================================================================

class TypeChecker:
    """Type checking and coercion system"""
    
    VALID_TYPES = {
        'int': int,
        'float': float,
        'str': str,
        'bool': bool,
        'list': list,
        'dict': dict,
        'null': type(None),
        'any': object
    }
    
    @staticmethod
    def check_type(value: Any, expected_type: str, strict: bool = True) -> bool:
        """Check if value matches expected type"""
        if expected_type == 'any':
            return True
        
        expected_class = TypeChecker.VALID_TYPES.get(expected_type)
        if not expected_class:
            raise ValueError(f"Unknown type: {expected_type}")
        
        if strict:
            return isinstance(value, expected_class)
        else:
            # Lenient checking - allow numeric coercion
            if expected_type in ('int', 'float'):
                return isinstance(value, (int, float, str))
            elif expected_type == 'str':
                return True  # Everything can be string
            return isinstance(value, expected_class)
    
    @staticmethod
    def coerce_type(value: Any, target_type: str) -> Any:
        """Coerce value to target type"""
        if target_type == 'int':
            return int(value)
        elif target_type == 'float':
            return float(value)
        elif target_type == 'str':
            return str(value)
        elif target_type == 'bool':
            return bool(value)
        elif target_type == 'list':
            return list(value) if hasattr(value, '__iter__') else [value]
        elif target_type == 'dict':
            if isinstance(value, dict):
                return value
            raise TypeMismatchError(f"Cannot coerce {type(value)} to dict")
        else:
            return value


def execute_opcode_59(vm, var_ref: int, expected_type: str, strict: bool = True) -> Any:
    """
    Opcode 59: TYPE_CHECK - Type checking and coercion
    
    Args:
        vm: Virtual machine instance
        var_ref: Variable to check
        expected_type: Expected type string
        strict: If True, strict type checking; if False, attempt coercion
    
    Returns:
        Original or coerced value
    
    Raises:
        TypeMismatchError if type check fails
    
    Example:
        59 0 "int" 1    # assert var0 is int (strict)
        59 1 "float" 0  # coerce var1 to float if possible
    """
    value = vm.get_variable(var_ref)
    
    # Check type in strict mode
    if strict and TypeChecker.check_type(value, expected_type, strict):
        return value
    
    # For non-strict mode, always attempt type matching
    if not strict:
        # Try to coerce to target type
        try:
            coerced = TypeChecker.coerce_type(value, expected_type)
            vm.set_variable(var_ref, coerced)
            return coerced
        except Exception as e:
            raise TypeMismatchError(f"Cannot coerce to {expected_type}: {e}")
    
    # Strict mode and type matches
    if TypeChecker.check_type(value, expected_type, strict):
        return value
    
    # Type mismatch in strict mode
    raise TypeMismatchError(
        f"Type mismatch: expected {expected_type}, got {type(value).__name__}"
    )


# ============================================================================
# OPCODE DISPATCH TABLE (For 50-59)
# ============================================================================

OPCODE_50_59_DISPATCH = {
    50: execute_opcode_50,
    51: execute_opcode_51,
    52: execute_opcode_52,
    53: execute_opcode_53,
    54: execute_opcode_54,
    55: execute_opcode_55,
    56: execute_opcode_56,
    57: execute_opcode_57,
    58: execute_opcode_58,
    59: execute_opcode_59,
}


# ============================================================================
# INTEGRATION WITH MAIN INTERPRETER
# ============================================================================

def register_opcodes_50_59(vm):
    """Register opcodes 50-59 with the main VM"""
    for opcode, handler in OPCODE_50_59_DISPATCH.items():
        vm.register_opcode(opcode, handler)
    print("✅ Opcodes 50-59 registered successfully")
