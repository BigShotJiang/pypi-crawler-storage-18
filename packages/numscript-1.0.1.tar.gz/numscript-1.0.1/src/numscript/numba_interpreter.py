"""Numba-optimized NumScript interpreter with JIT compilation for performance."""

import sys
import os
from typing import Dict, List, Any
from numba import jit, njit
import shlex

# Add parent directories to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))


class ReturnException(Exception):
    """Exception for returning from functions."""
    def __init__(self, value):
        self.value = value


# JIT-compiled arithmetic operations for maximum performance
@njit
def _add(a: int, b: int) -> int:
    """JIT-compiled addition."""
    return a + b

@njit
def _subtract(a: int, b: int) -> int:
    """JIT-compiled subtraction."""
    return a - b

@njit
def _multiply(a: int, b: int) -> int:
    """JIT-compiled multiplication."""
    return a * b

@njit
def _divide(a: int, b: int) -> int:
    """JIT-compiled division (integer)."""
    if b == 0:
        raise ValueError("Division by zero")
    return a // b

@njit
def _bitwise_and(a: int, b: int) -> int:
    """JIT-compiled bitwise AND."""
    return a & b

@njit
def _bitwise_or(a: int, b: int) -> int:
    """JIT-compiled bitwise OR."""
    return a | b

@njit
def _bitwise_xor(a: int, b: int) -> int:
    """JIT-compiled bitwise XOR."""
    return a ^ b

@njit
def _bitwise_not(a: int) -> int:
    """JIT-compiled bitwise NOT."""
    return ~a

@njit
def _left_shift(a: int, b: int) -> int:
    """JIT-compiled left shift."""
    return a << b

@njit
def _right_shift(a: int, b: int) -> int:
    """JIT-compiled right shift."""
    return a >> b


class NumbaNumScriptInterpreter:
    """NumScript interpreter optimized with Numba JIT compilation."""
    
    def __init__(self):
        self.vars: Dict[str, int] = {}
        self.functions: Dict[str, Dict] = {}
        self.arrays: Dict[str, List[int]] = {}
        self.output: List[str] = []  # Store output instead of printing for benchmarking
    
    def _eval_operand(self, token: str, local_args: List[int] = None) -> int:
        """Evaluate an operand token (variable or literal)."""
        if local_args is None:
            local_args = []
        
        try:
            return int(token)
        except ValueError:
            # Check if it's a function argument reference
            if token.startswith('@'):
                try:
                    index = int(token[1:]) - 1
                    return local_args[index]
                except (ValueError, IndexError):
                    return 0
            # Otherwise treat as variable name
            return self.vars.get(token, 0)
    
    def run(self, code: str, local_args: List[int] = None) -> None:
        """Execute NumScript code."""
        if local_args is None:
            local_args = []
        
        # Tokenize the code
        try:
            tokens = shlex.split(code)
        except ValueError:
            tokens = code.split()
        
        i = 0
        while i < len(tokens):
            instr = tokens[i].strip()
            
            if not instr or instr.startswith('#'):
                i += 1
                continue
            
            try:
                # Arithmetic operations (opcodes 11-14) - using JIT-compiled functions
                if instr == '11':  # ADD
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _add(a, b)
                    i += 4

                elif instr == '12':  # SUBTRACT
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _subtract(a, b)
                    i += 4

                elif instr == '13':  # MULTIPLY
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _multiply(a, b)
                    i += 4

                elif instr == '14':  # DIVIDE
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _divide(a, b)
                    i += 4

                # Bitwise operations (opcodes 15-20) - JIT-compiled
                elif instr == '15':  # AND
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _bitwise_and(a, b)
                    i += 4

                elif instr == '16':  # OR
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _bitwise_or(a, b)
                    i += 4

                elif instr == '17':  # XOR
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _bitwise_xor(a, b)
                    i += 4

                elif instr == '18':  # NOT
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    self.vars[target] = _bitwise_not(a)
                    i += 3

                elif instr == '19':  # LEFT_SHIFT
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _left_shift(a, b)
                    i += 4

                elif instr == '20':  # RIGHT_SHIFT
                    target = tokens[i + 1]
                    a = self._eval_operand(tokens[i + 2], local_args)
                    b = self._eval_operand(tokens[i + 3], local_args)
                    self.vars[target] = _right_shift(a, b)
                    i += 4

                # Other opcodes (pass through to standard implementation)
                elif instr == '1':  # ASSIGN
                    var_name = tokens[i + 1]
                    val = self._eval_operand(tokens[i + 2], local_args)
                    self.vars[var_name] = val
                    i += 3

                elif instr == '2':  # PRINT
                    val = self._eval_operand(tokens[i + 1], local_args)
                    self.output.append(str(val))
                    i += 2

                elif instr == '4':  # LOOP
                    n = self._eval_operand(tokens[i + 1], local_args)
                    body_len = self._eval_operand(tokens[i + 2], local_args)
                    body_tokens = tokens[i + 3:i + 3 + body_len]
                    for _ in range(n):
                        self.run(' '.join(body_tokens), local_args)
                    i += 3 + body_len

                elif instr == '5':  # FUNCTION_DEF
                    name = tokens[i + 1].strip('"')
                    nargs = self._eval_operand(tokens[i + 2], local_args)
                    body_len = self._eval_operand(tokens[i + 3], local_args)
                    body = tokens[i + 4:i + 4 + body_len]
                    self.functions[name] = {'nargs': nargs, 'body': body}
                    i += 4 + body_len

                elif instr == '8':  # FUNCTION_CALL
                    name = tokens[i + 1].strip('"')
                    func = self.functions.get(name)
                    if func is None:
                        raise ValueError(f"Unknown function: {name}")
                    nargs = func['nargs']
                    args_vals = [self._eval_operand(tokens[i + 2 + k], local_args) for k in range(nargs)]
                    target = tokens[i + 2 + nargs]
                    result = self.call_function(name, args_vals)
                    self.vars[target] = result
                    i += 3 + nargs

                elif instr == '21':  # CREATE_ARRAY
                    var_name = tokens[i + 1]
                    size = self._eval_operand(tokens[i + 2], local_args)
                    self.arrays[var_name] = [0] * size
                    i += 3

                elif instr == '22':  # SET_ARRAY
                    var_name = tokens[i + 1]
                    index = self._eval_operand(tokens[i + 2], local_args)
                    value = self._eval_operand(tokens[i + 3], local_args)
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.arrays[var_name][index] = value
                    i += 4

                elif instr == '23':  # GET_ARRAY
                    target = tokens[i + 1]
                    var_name = tokens[i + 2]
                    index = self._eval_operand(tokens[i + 3], local_args)
                    if var_name in self.arrays and 0 <= index < len(self.arrays[var_name]):
                        self.vars[target] = self.arrays[var_name][index]
                    else:
                        self.vars[target] = 0
                    i += 4

                elif instr == '24':  # ARRAY_LENGTH
                    target = tokens[i + 1]
                    var_name = tokens[i + 2]
                    self.vars[target] = len(self.arrays.get(var_name, []))
                    i += 3

                else:
                    i += 1

            except (IndexError, ValueError) as e:
                raise ValueError(f"Error at instruction {i}: {e}")
        
        return None

    def call_function(self, name: str, args: List[int]) -> int:
        """Call a defined function."""
        func = self.functions[name]
        try:
            self.run(' '.join(func['body']), local_args=args)
        except ReturnException as r:
            return r.value
        return 0
    
    def get_output(self) -> str:
        """Get all printed output."""
        return '\n'.join(self.output)
    
    def clear_output(self) -> None:
        """Clear output buffer."""
        self.output.clear()
