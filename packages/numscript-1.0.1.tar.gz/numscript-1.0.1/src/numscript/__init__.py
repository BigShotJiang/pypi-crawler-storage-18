"""NumScript package (prototype)."""

# Temporarily commented to allow testing opcodes_50_59.py
# from .interpreter import NumScriptInterpreter

__all__ = ["NumScriptInterpreter"]
