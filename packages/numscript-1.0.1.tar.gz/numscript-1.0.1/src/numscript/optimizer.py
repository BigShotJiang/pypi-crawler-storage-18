"""
optimizer.py - Numba-based optimization for critical paths
Part of Phase 1 Week 2: Performance Optimization

Features:
- JIT compilation of critical loops
- Memory optimization
- Type specialization
- Performance benchmarking
"""

import time
from typing import Callable, Any, Dict, List
from functools import wraps
import numba as nb
from numba import jit, types as nb_types


# ============================================================================
# CRITICAL LOOP OPTIMIZATIONS
# ============================================================================

@jit(nopython=True)
def numba_loop_sum(count: int) -> int:
    """Optimized sum loop with Numba JIT"""
    result = 0
    for i in range(count):
        result += i
    return result


@jit(nopython=True)
def numba_loop_multiply(count: int, factor: int) -> int:
    """Optimized multiplication loop"""
    result = 1
    for i in range(1, count):
        result *= factor
    return result


@jit(nopython=True)
def numba_array_sum(arr) -> float:
    """Optimized array sum"""
    total = 0.0
    for val in arr:
        total += val
    return total


@jit(nopython=True)
def numba_array_filter(arr, threshold: float):
    """Optimized array filtering"""
    result = []
    for val in arr:
        if val > threshold:
            result.append(val)
    return result


@jit(nopython=True)
def numba_fibonacci(n: int) -> int:
    """Optimized Fibonacci calculation"""
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(n - 1):
        a, b = b, a + b
    return b


# ============================================================================
# PERFORMANCE DECORATOR
# ============================================================================

class PerformanceMonitor:
    """Monitor and track performance of operations"""
    
    def __init__(self):
        self.measurements: Dict[str, List[float]] = {}
    
    def track(self, name: str):
        """Decorator to track function execution time"""
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                start = time.perf_counter()
                result = func(*args, **kwargs)
                elapsed = (time.perf_counter() - start) * 1000  # ms
                
                if name not in self.measurements:
                    self.measurements[name] = []
                self.measurements[name].append(elapsed)
                
                return result
            return wrapper
        return decorator
    
    def get_stats(self, name: str) -> Dict[str, float]:
        """Get statistics for a tracked function"""
        if name not in self.measurements:
            return {}
        
        times = self.measurements[name]
        return {
            'count': len(times),
            'total_ms': sum(times),
            'avg_ms': sum(times) / len(times),
            'min_ms': min(times),
            'max_ms': max(times),
        }
    
    def report(self):
        """Print performance report"""
        print("\n" + "=" * 70)
        print("PERFORMANCE REPORT")
        print("=" * 70)
        
        for name in self.measurements:
            stats = self.get_stats(name)
            print(f"\n{name}:")
            print(f"  Calls: {stats['count']}")
            print(f"  Total: {stats['total_ms']:.2f}ms")
            print(f"  Avg:   {stats['avg_ms']:.4f}ms")
            print(f"  Min:   {stats['min_ms']:.4f}ms")
            print(f"  Max:   {stats['max_ms']:.4f}ms")


# ============================================================================
# BENCHMARK SUITE
# ============================================================================

class BenchmarkSuite:
    """Run and compare optimized vs non-optimized implementations"""
    
    @staticmethod
    def benchmark_loop_sum():
        """Benchmark: Sum loop optimization"""
        print("\n📊 BENCHMARK: Loop Sum (1000 iterations)")
        print("-" * 60)
        
        # Warm up Numba
        numba_loop_sum(10)
        
        # Python baseline
        start = time.perf_counter()
        for _ in range(100):
            result_py = sum(range(1000))
        time_py = (time.perf_counter() - start) * 1000 / 100
        
        # Numba optimized
        start = time.perf_counter()
        for _ in range(100):
            result_nb = numba_loop_sum(1000)
        time_nb = (time.perf_counter() - start) * 1000 / 100
        
        speedup = time_py / time_nb if time_nb > 0 else float('inf')
        
        print(f"Python:  {time_py:.4f}ms (result={result_py})")
        print(f"Numba:   {time_nb:.4f}ms (result={result_nb})")
        print(f"Speedup: {speedup:.2f}x")
        
        return {'python': time_py, 'numba': time_nb, 'speedup': speedup}
    
    @staticmethod
    def benchmark_fibonacci():
        """Benchmark: Fibonacci optimization"""
        print("\n📊 BENCHMARK: Fibonacci(30)")
        print("-" * 60)
        
        # Warm up Numba
        numba_fibonacci(5)
        
        # Python baseline
        def fib_py(n):
            if n <= 1:
                return n
            a, b = 0, 1
            for _ in range(n - 1):
                a, b = b, a + b
            return b
        
        start = time.perf_counter()
        for _ in range(100):
            result_py = fib_py(30)
        time_py = (time.perf_counter() - start) * 1000 / 100
        
        # Numba optimized
        start = time.perf_counter()
        for _ in range(100):
            result_nb = numba_fibonacci(30)
        time_nb = (time.perf_counter() - start) * 1000 / 100
        
        speedup = time_py / time_nb if time_nb > 0 else float('inf')
        
        print(f"Python:  {time_py:.4f}ms (result={result_py})")
        print(f"Numba:   {time_nb:.4f}ms (result={result_nb})")
        print(f"Speedup: {speedup:.2f}x")
        
        return {'python': time_py, 'numba': time_nb, 'speedup': speedup}
    
    @staticmethod
    def benchmark_array_sum():
        """Benchmark: Array sum optimization"""
        print("\n📊 BENCHMARK: Array Sum (10000 elements)")
        print("-" * 60)
        
        data = list(range(10000))
        
        # Warm up Numba
        numba_array_sum(data[:100])
        
        # Python baseline
        start = time.perf_counter()
        for _ in range(100):
            result_py = sum(data)
        time_py = (time.perf_counter() - start) * 1000 / 100
        
        # Numba optimized
        start = time.perf_counter()
        for _ in range(100):
            result_nb = numba_array_sum(data)
        time_nb = (time.perf_counter() - start) * 1000 / 100
        
        speedup = time_py / time_nb if time_nb > 0 else float('inf')
        
        print(f"Python:  {time_py:.4f}ms (result={int(result_py)})")
        print(f"Numba:   {time_nb:.4f}ms (result={int(result_nb)})")
        print(f"Speedup: {speedup:.2f}x")
        
        return {'python': time_py, 'numba': time_nb, 'speedup': speedup}
    
    @staticmethod
    def run_all():
        """Run all benchmarks"""
        print("\n" + "=" * 70)
        print("NUMBA OPTIMIZATION BENCHMARKS")
        print("=" * 70)
        
        results = {
            'loop_sum': BenchmarkSuite.benchmark_loop_sum(),
            'fibonacci': BenchmarkSuite.benchmark_fibonacci(),
            'array_sum': BenchmarkSuite.benchmark_array_sum(),
        }
        
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        
        total_speedup = sum(r['speedup'] for r in results.values()) / len(results)
        print(f"\nAverage Speedup: {total_speedup:.2f}x")
        print("\n✅ Numba optimization enabled for critical paths")
        
        return results


# ============================================================================
# INTEGRATION WITH INTERPRETER
# ============================================================================

class OptimizedInterpreter:
    """Interpreter with Numba optimization support"""
    
    def __init__(self):
        self.performance_monitor = PerformanceMonitor()
    
    def execute_loop_optimized(self, iterations: int, operation: str) -> Any:
        """Execute loop with optimization"""
        if operation == 'sum':
            return numba_loop_sum(iterations)
        elif operation == 'fibonacci':
            return numba_fibonacci(iterations)
        else:
            raise ValueError(f"Unknown operation: {operation}")
    
    def execute_array_optimized(self, data: list, operation: str) -> Any:
        """Execute array operation with optimization"""
        if operation == 'sum':
            return numba_array_sum(data)
        else:
            raise ValueError(f"Unknown operation: {operation}")


if __name__ == '__main__':
    # Run benchmark suite
    results = BenchmarkSuite.run_all()
    
    # Show individual results
    print("\nDetailed Results:")
    for test_name, result in results.items():
        print(f"\n{test_name.upper()}:")
        print(f"  Speedup: {result['speedup']:.2f}x")
