# FhotoShop

**FhotoShop** is a Python library that converts Python commands directly into JSX for Photoshop, enabling easy automation of layers, groups, filters, and more—without writing JSX manually.

---

## ⚡ Features

- Create **Layers** and **Groups** easily.  
- Control **Translate, Rotate, Resize, Blur, Opacity, BlendMode**.  
- Support for **Duplicate, Merge, MergeVisible**.  
- Manage **Text Layers** and **Smart Objects**.  
- Object-Oriented API for clean, readable scripts.  
- Automatically generates ready-to-run JSX files for Photoshop.

---

## 📦 Installation

```b
# FhotoShop

**FhotoShop** is a Python library that converts Python commands directly into JSX for Photoshop, enabling easy automation of layers, groups, filters, and more—without writing JSX manually.

---

## ⚡ Features

- Create **Layers** and **Groups** easily.  
- Control **Translate, Rotate, Resize, Blur, Opacity, BlendMode**.  
- Support for **Duplicate, Merge, MergeVisible**.  
- Manage **Text Layers** and **Smart Objects**.  
- Object-Oriented API for clean, readable scripts.  
- Automatically generates ready-to-run JSX files for Photoshop.

---

## 📦 Installation

```bash
pip install FhotoShop
