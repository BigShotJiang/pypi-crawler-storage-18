# Django Admin Panel Link
**Django Admin Panel Link** — это простое и удобное Django-приложение, которое добавляет в ваш шаблон ссылку на административную панель Django. Ссылка автоматически отображается только авторизованным пользователям с соответствующими правами (персонал или суперпользователи).

## Установка
Установите пакет через pip:
```shell
pip install django-admin-panel-link
```

## Настройка
#### Добавьте `admin_link` в `INSTALLED_APPS` в вашем `settings.py`:

```python
INSTALLED_APPS = [
    # ...
    'admin_panel_link',
    # ...
]
```

## Использование
В вашем шаблоне добавьте тег там, где должна отображаться ссылка:
```html
{% load admin_link_tags %}
{% admin_link %}
```

### Необязательные настройки
В `settings.py` вы можете определить следующие параметры:
```python
# Показывать ссылку только суперпользователям (по умолчанию: False)
ADMIN_LINK_ONLY_SUPERUSER = True

# Использовать встроенные стили для ссылки (по умолчанию: True)
ADMIN_LINK_USE_STYLES = False
```

### Как это работает
- Если пользователь не авторизован — ссылка не отображается
- Если `ADMIN_LINK_ONLY_SUPERUSER = False` (по умолчанию) — ссылка показывается всем авторизованным пользователям с флагом `is_staff = True`
- Если `ADMIN_LINK_ONLY_SUPERUSER = True` — ссылка показывается только суперпользователям
- Ссылка всегда отображается для суперпользователей

## Кастомизация
### Стили
По умолчанию ссылка имеет зеленый цвет (`color: #0f0`). Вы можете:
1. Отключить встроенные стили (`ADMIN_LINK_USE_STYLES = False`) и задать свои через CSS
2. Переопределить шаблон в вашем проекте

### Локализация
Текст ссылки "Admin panel" переводится через Django-систему переводов. Добавьте переводы в свои файлы локализации при необходимости.

## Совместимость
- **Python:** 3.8, 3.9, 3.10, 3.11, 3.12, 3.13, 3.14
- **Django:** 5.2, 6.0

## Разработка
### Установка для разработки
```shell
git clone https://github.com/magilyasdoma/django-admin-link.git
cd django-admin-link
pip install -e .
```

### Структура проекта
```text
django-admin-link/
├── admin_link/
│   ├── __init__.py
│   ├── admin_link.py      # Основной файл с тегом шаблона
│   ├── apps.py
│   ├── views.py
│   └── templates/
│       └── admin_link/
│           └── includes/
│               └── admin_link.html
├── setup.py
└── requirements.txt
```

## Лицензия
Проект распространяется под лицензией MIT. Подробнее смотрите в файле [LICENSE](https://github.com/MagIlyasDOMA/django-admin-link/blob/main/LICENSE).

## Автор
Маг Ильяс DOMA (MagIlyasDOMA)
📧 Email: magilyas.doma.09@list.ru
🌐 GitHub: [https://github.com/magilyasdoma](https://github.com/magilyasdoma)

## Поддержка
Если у вас возникли проблемы или вопросы:
1. Оставьте issue на [GitHub](https://github.com/MagIlyasDOMA/django-admin-link/issues)
2. Напишите на email автора

---

#### Быстрый старт:

```python
# settings.py
INSTALLED_APPS = ['admin_panel_link', ...]
```
```html
<!-- base.html -->
{% load admin_link_tags %}
{% admin_link %}
```

Готово! Теперь ваши администраторы смогут быстро переходить в админ-панель прямо с сайта.
