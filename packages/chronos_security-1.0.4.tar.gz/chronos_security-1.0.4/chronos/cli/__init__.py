"""
CHRONOS CLI Module
==================

Command-line interface for the CHRONOS quantum security platform.
"""

from chronos.cli.main import app, main

__all__ = ["app", "main"]
