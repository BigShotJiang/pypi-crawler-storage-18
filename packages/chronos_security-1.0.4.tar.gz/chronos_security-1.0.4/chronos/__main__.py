"""
CHRONOS Package Entry Point
===========================

Allows running the package as: python -m chronos
"""

from chronos.cli.main import app

if __name__ == "__main__":
    app()
