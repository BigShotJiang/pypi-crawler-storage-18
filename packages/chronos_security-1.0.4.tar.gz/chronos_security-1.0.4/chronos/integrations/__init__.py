"""
CHRONOS Integrations Module
===========================

External integrations and plugins for the CHRONOS platform.
Supports integration with various security tools and services.
"""

from chronos.integrations.base import BaseIntegration

__all__ = [
    "BaseIntegration",
]
