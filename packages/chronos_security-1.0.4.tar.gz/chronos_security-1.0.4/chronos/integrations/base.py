"""
CHRONOS Base Integration
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BaseIntegration(ABC):
    """Base class for all CHRONOS integrations."""
    
    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None):
        """Initialize the integration.
        
        Args:
            name: Integration name.
            config: Optional configuration dictionary.
        """
        self.name = name
        self.config = config or {}
        self._initialized = False
    
    @abstractmethod
    async def connect(self) -> bool:
        """Establish connection to the external service.
        
        Returns:
            True if connection successful, False otherwise.
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the external service."""
        pass
    
    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the integration is healthy.
        
        Returns:
            True if healthy, False otherwise.
        """
        pass
    
    @property
    def is_initialized(self) -> bool:
        """Check if integration is initialized."""
        return self._initialized
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(name={self.name}, initialized={self._initialized})>"
