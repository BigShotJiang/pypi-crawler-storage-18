"""
CHRONOS Quantum Computing Simulation Module

Provides quantum algorithm simulations for cryptographic analysis,
including Shor's algorithm for RSA factorization and Grover's algorithm
for symmetric key search.
"""

from chronos.core.simulate.shors_algorithm import (
    # Main Classes
    ShorsAlgorithm,
    QuantumPeriodFinder,
    ClassicalPostProcessor,
    QuantumResourceEstimator as ShorsQuantumResourceEstimator,
    QuantumCircuitVisualizer,
    SuccessProbabilityCalculator,
    
    # Data Classes
    Factorization,
    ResourceEstimate as ShorsResourceEstimate,
    QuantumCircuitInfo,
    PeriodFindingResult,
    ShorsExecutionLog,
    
    # Enumerations
    AlgorithmPhase,
    RSAKeySize,
    QubitQuality,
    FactorMethod,
    
    # Factory Functions
    create_shors_algorithm,
)

from chronos.core.simulate.grovers_algorithm import (
    # Main Classes
    GroversAlgorithm,
    SearchOracle,
    SearchSpaceReducer,
    QuantumResourceEstimator as GroversQuantumResourceEstimator,
    AmplificationVisualizer,
    ClassicalBenchmark,
    
    # Data Classes
    OracleInfo,
    AmplificationRound,
    SearchResult,
    QuantumResourceEstimate as GroversQuantumResourceEstimate,
    SearchSpaceInfo,
    GroverExecutionLog,
    
    # Enumerations
    SymmetricKeyType,
    OracleType,
    SearchPhase,
    QuantumSpeedupLevel,
    
    # Factory Functions
    create_grovers_algorithm,
)

__all__ = [
    # Shor's Algorithm Classes
    "ShorsAlgorithm",
    "QuantumPeriodFinder",
    "ClassicalPostProcessor",
    "ShorsQuantumResourceEstimator",
    "QuantumCircuitVisualizer",
    "SuccessProbabilityCalculator",
    
    # Shor's Data Classes
    "Factorization",
    "ShorsResourceEstimate",
    "QuantumCircuitInfo",
    "PeriodFindingResult",
    "ShorsExecutionLog",
    
    # Shor's Enumerations
    "AlgorithmPhase",
    "RSAKeySize",
    "QubitQuality",
    "FactorMethod",
    
    # Shor's Factory
    "create_shors_algorithm",
    
    # Grover's Algorithm Classes
    "GroversAlgorithm",
    "SearchOracle",
    "SearchSpaceReducer",
    "GroversQuantumResourceEstimator",
    "AmplificationVisualizer",
    "ClassicalBenchmark",
    
    # Grover's Data Classes
    "OracleInfo",
    "AmplificationRound",
    "SearchResult",
    "GroversQuantumResourceEstimate",
    "SearchSpaceInfo",
    "GroverExecutionLog",
    
    # Grover's Enumerations
    "SymmetricKeyType",
    "OracleType",
    "SearchPhase",
    "QuantumSpeedupLevel",
    
    # Grover's Factory
    "create_grovers_algorithm",
]

__version__ = "2.0.0"
__author__ = "CHRONOS Quantum Team"
