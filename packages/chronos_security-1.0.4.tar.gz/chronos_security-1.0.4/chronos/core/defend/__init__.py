"""
CHRONOS Defend Module
====================

AST-based cryptographic code scanning and analysis with automated migration planning.
Post-quantum cryptography migration engine with liboqs integration.
Quantum-secure data vault with hybrid encryption and geographic distribution.
"""

from chronos.core.defend.code_scanner import (
    CodeScanner,
    CryptoAlgorithm,
    RiskLevel,
    MigrationSuggestion,
    CodeLocation,
    CryptoUsage,
    Dependency,
    MigrationPlan as CodeScannerMigrationPlan,
    ScanResult,
    DependencyNode,
    CryptoPatternDetector,
    analyze_project,
)

# PQC and Quantum Vault modules are lazy-loaded to avoid forcing liboqs installation
# Import them only when explicitly requested
try:
    from chronos.core.defend.pqc_migrator import (
        PQCAlgorithm,
        ClassicalAlgorithm,
        MigrationMode,
        MigrationStatus,
        PerformanceMetric,
        KeyPair,
        PerformanceBenchmark,
        MigrationSnapshot,
        MigrationPlan as PQCMigrationPlan,
        KyberMigrator,
        DilithiumMigrator,
        HybridMigrator,
        MigrationRollback,
        PQCMigrator,
        analyze_migration_feasibility,
    )
except ImportError:
    # PQC migration requires liboqs - gracefully handle missing library
    PQCAlgorithm = None
    ClassicalAlgorithm = None
    MigrationMode = None
    MigrationStatus = None
    PerformanceMetric = None
    KeyPair = None
    PerformanceBenchmark = None
    MigrationSnapshot = None
    PQCMigrationPlan = None
    KyberMigrator = None
    DilithiumMigrator = None
    HybridMigrator = None
    MigrationRollback = None
    PQCMigrator = None
    analyze_migration_feasibility = None

try:
    from chronos.core.defend.quantum_vault import (
        # Main Classes
        QuantumVault,
        HybridEncryption,
        ShamirSecretSharing,
        TimeLockCryptography,
        CloudShardDistribution,
        AlgorithmAgility,
        VaultAuditingSystem,
        # Enums
        VaultAlgorithm,
        CloudProvider,
        VaultOperationType,
        VaultStatus,
        IntegrityStatus,
        # Data Classes
        KeyPair as VaultKeyPair,
        ShamirShard,
        TimeLock,
        VaultAuditLog,
        EncryptedData,
        VaultMetrics,
        # Utility Functions
        create_vault,
        analyze_vault_security,
    )
except ImportError:
    # Quantum vault requires liboqs - gracefully handle missing library
    QuantumVault = None
    HybridEncryption = None
    ShamirSecretSharing = None
    TimeLockCryptography = None
    CloudShardDistribution = None
    AlgorithmAgility = None
    VaultAuditingSystem = None
    VaultAlgorithm = None
    CloudProvider = None
    VaultOperationType = None
    VaultStatus = None
    IntegrityStatus = None
    VaultKeyPair = None
    ShamirShard = None
    TimeLock = None
    VaultAuditLog = None
    EncryptedData = None
    VaultMetrics = None
    create_vault = None
    analyze_vault_security = None

__all__ = [
    # Code Scanner
    "CodeScanner",
    "CryptoAlgorithm",
    "RiskLevel",
    "MigrationSuggestion",
    "CodeLocation",
    "CryptoUsage",
    "Dependency",
    "CodeScannerMigrationPlan",
    "ScanResult",
    "DependencyNode",
    "CryptoPatternDetector",
    "analyze_project",
    # PQC Migrator
    "PQCAlgorithm",
    "ClassicalAlgorithm",
    "MigrationMode",
    "MigrationStatus",
    "PerformanceMetric",
    "KeyPair",
    "PerformanceBenchmark",
    "MigrationSnapshot",
    "PQCMigrationPlan",
    "KyberMigrator",
    "DilithiumMigrator",
    "HybridMigrator",
    "MigrationRollback",
    "PQCMigrator",
    "analyze_migration_feasibility",
    # Quantum Vault - Main Classes
    "QuantumVault",
    "HybridEncryption",
    "ShamirSecretSharing",
    "TimeLockCryptography",
    "CloudShardDistribution",
    "AlgorithmAgility",
    "VaultAuditingSystem",
    # Quantum Vault - Enums
    "VaultAlgorithm",
    "CloudProvider",
    "VaultOperationType",
    "VaultStatus",
    "IntegrityStatus",
    # Quantum Vault - Data Classes
    "VaultKeyPair",
    "ShamirShard",
    "TimeLock",
    "VaultAuditLog",
    "EncryptedData",
    "VaultMetrics",
    # Quantum Vault - Utilities
    "create_vault",
    "analyze_vault_security",
]
