"""
CHRONOS Performance Optimization Package

This package provides comprehensive tools for measuring, profiling, and
optimizing CHRONOS performance across all subsystems.

Modules:
- profiler: cProfile-based function and network monitoring profiling
- database_optimization: Database indexing and query optimization
- caching: Multi-tier caching (in-memory + Redis)
- async_scanner: Async I/O for concurrent network scanning
- memory_optimization: Memory efficiency for large scans
- benchmarks: Performance benchmarking suite

Usage:
    from chronos.performance import (
        PerformanceProfiler,
        TieredCache,
        AsyncNetworkScanner,
        MemoryMonitor,
        run_all_benchmarks
    )
"""

from chronos.performance.profiler import (
    PerformanceProfiler,
    FunctionTimer,
    MemoryProfiler,
    profile_function,
    profile_network_monitoring,
    PerformanceReport,
    NetworkDetectionProfiler,
)

from chronos.performance.database_optimization import (
    IndexManager,
    OptimizedQueries,
    QueryOptimizer,
    AggregationQueries,
    apply_database_optimizations,
    DATABASE_INDEXES,
)

from chronos.performance.caching import (
    InMemoryCache,
    RedisCache,
    TieredCache,
    CachedFunction,
    cached_result,
    vulnerability_pattern_cache,
    cryptography_cache,
    network_service_cache,
    scan_results_cache,
    invalidate_all_caches,
)

from chronos.performance.async_scanner import (
    AsyncNetworkScanner,
    AsyncHTTPScanner,
    AsyncDarkwebMonitor,
    AsyncHNDLDetector,
    AsyncScanOrchestrator,
    NetworkScanResult,
    run_async_network_scan,
    run_async_http_scan,
    run_async_scan,
)

from chronos.performance.memory_optimization import (
    MemoryMonitor,
    MemoryStats,
    memory_tracking,
    trace_memory_allocations,
    StreamingVulnerabilityProcessor,
    StringPool,
    MemoryEfficientVulnerabilityStorage,
    LazyLoadingScanner,
    optimize_for_large_scan,
    reset_memory_optimization,
    ChunkedFileProcessor,
    estimate_scan_memory,
)

from chronos.performance.benchmarks import (
    BenchmarkSuite,
    BenchmarkResult,
    CodeAnalysisBenchmarks,
    CryptographyBenchmarks,
    NetworkMonitoringBenchmarks,
    DatabaseBenchmarks,
    CachingBenchmarks,
    run_all_benchmarks,
    generate_benchmark_report,
    save_benchmark_results,
    compare_benchmarks,
)

__all__ = [
    # Profiling
    'PerformanceProfiler',
    'FunctionTimer',
    'MemoryProfiler',
    'profile_function',
    'profile_network_monitoring',
    'PerformanceReport',
    'NetworkDetectionProfiler',
    
    # Database Optimization
    'IndexManager',
    'OptimizedQueries',
    'QueryOptimizer',
    'AggregationQueries',
    'apply_database_optimizations',
    'DATABASE_INDEXES',
    
    # Caching
    'InMemoryCache',
    'RedisCache',
    'TieredCache',
    'CachedFunction',
    'cached_result',
    'vulnerability_pattern_cache',
    'cryptography_cache',
    'network_service_cache',
    'scan_results_cache',
    'invalidate_all_caches',
    
    # Async Scanning
    'AsyncNetworkScanner',
    'AsyncHTTPScanner',
    'AsyncDarkwebMonitor',
    'AsyncHNDLDetector',
    'AsyncScanOrchestrator',
    'NetworkScanResult',
    'run_async_network_scan',
    'run_async_http_scan',
    'run_async_scan',
    
    # Memory Optimization
    'MemoryMonitor',
    'MemoryStats',
    'memory_tracking',
    'trace_memory_allocations',
    'StreamingVulnerabilityProcessor',
    'StringPool',
    'MemoryEfficientVulnerabilityStorage',
    'LazyLoadingScanner',
    'optimize_for_large_scan',
    'reset_memory_optimization',
    'ChunkedFileProcessor',
    'estimate_scan_memory',
    
    # Benchmarking
    'BenchmarkSuite',
    'BenchmarkResult',
    'CodeAnalysisBenchmarks',
    'CryptographyBenchmarks',
    'NetworkMonitoringBenchmarks',
    'DatabaseBenchmarks',
    'CachingBenchmarks',
    'run_all_benchmarks',
    'generate_benchmark_report',
    'save_benchmark_results',
    'compare_benchmarks',
]
