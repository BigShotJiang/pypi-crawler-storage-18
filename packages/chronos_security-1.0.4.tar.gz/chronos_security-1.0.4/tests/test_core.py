"""
Tests for CHRONOS Core Module
"""

import pytest
from chronos.core.config import Config
from chronos.core.exceptions import ChronosError, SecurityError, QuantumError


class TestConfig:
    """Tests for Config class."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = Config()
        assert config.get("security_level") == "high"
        assert config.get("quantum_resistant") is True
    
    def test_get_with_default(self):
        """Test getting non-existent key with default."""
        config = Config()
        assert config.get("nonexistent", "default") == "default"
    
    def test_set_config(self):
        """Test setting configuration values."""
        config = Config()
        config.set("custom_key", "custom_value")
        assert config.get("custom_key") == "custom_value"


class TestExceptions:
    """Tests for custom exceptions."""
    
    def test_chronos_error(self):
        """Test ChronosError exception."""
        with pytest.raises(ChronosError) as exc_info:
            raise ChronosError("Test error", "TEST_CODE")
        assert exc_info.value.message == "Test error"
        assert exc_info.value.code == "TEST_CODE"
    
    def test_security_error(self):
        """Test SecurityError exception."""
        with pytest.raises(SecurityError):
            raise SecurityError("Security breach detected")
    
    def test_quantum_error(self):
        """Test QuantumError exception."""
        with pytest.raises(QuantumError):
            raise QuantumError("Quantum decoherence detected")
