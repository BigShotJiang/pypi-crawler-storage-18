"""
CHRONOS CLI Testing Framework

Tests for all implemented commands and workflows.
"""

import pytest
import subprocess
import sys
import tempfile
from pathlib import Path


class TestChronosBasic:
    """Basic CLI tests for CHRONOS."""
    
    def test_version_command(self):
        """Test chronos --version command."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "1.0.2" in result.stdout or "Version" in result.stdout
    
    def test_help_command(self):
        """Test chronos --help command."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "detect" in result.stdout.lower() or "command" in result.stdout.lower()
    
    def test_detect_help(self):
        """Test detect command help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "detect", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "detect" in result.stdout.lower()
    
    def test_analyze_help(self):
        """Test analyze command help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "analyze", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "analyze" in result.stdout.lower()
    
    def test_config_help(self):
        """Test config command help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "config", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "config" in result.stdout.lower()
    
    def test_readiness_help(self):
        """Test readiness command help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "readiness", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0


class TestDetectModule:
    """Tests for the detect command module."""
    
    def test_detect_network_help(self):
        """Test detect network subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "detect", "network", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "network" in result.stdout.lower() or "monitor" in result.stdout.lower()
    
    def test_detect_hndl_help(self):
        """Test detect hndl subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "detect", "hndl", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
    
    def test_detect_darkweb_help(self):
        """Test detect darkweb subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "detect", "darkweb", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0


class TestAnalyzeModule:
    """Tests for the analyze command module."""
    
    def test_analyze_crypto_help(self):
        """Test analyze crypto subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "analyze", "crypto", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert "analyze" in result.stdout.lower() or "crypto" in result.stdout.lower()
    
    def test_analyze_risk_help(self):
        """Test analyze risk subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "analyze", "risk", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0


class TestConfigModule:
    """Tests for the config command module."""
    
    def test_config_show_help(self):
        """Test config show subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "config", "show", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
    
    def test_config_set_help(self):
        """Test config set subcommand help."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "config", "set", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0


class TestOptionalModules:
    """Tests for optional modules (defend, pqc, vault)."""
    
    def test_defend_available(self):
        """Test if defend command is available."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--help"],
            capture_output=True,
            text=True
        )
        # Defend is optional - should not error if unavailable
        assert result.returncode == 0
    
    def test_pqc_available(self):
        """Test if pqc command is available."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--help"],
            capture_output=True,
            text=True
        )
        # PQC is optional - should not error if unavailable
        assert result.returncode == 0
    
    def test_vault_available(self):
        """Test if vault command is available."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--help"],
            capture_output=True,
            text=True
        )
        # Vault is optional - should not error if unavailable
        assert result.returncode == 0


class TestInitCommand:
    """Tests for the init command."""
    
    def test_init_new_project(self):
        """Test initializing a new CHRONOS project."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_path = Path(tmpdir) / "test_project"
            project_path.mkdir()
            
            result = subprocess.run(
                [sys.executable, "-m", "chronos", "init", str(project_path), "--force"],
                capture_output=True,
                text=True
            )
            # Should succeed or indicate config exists
            assert result.returncode == 0 or "initialized" in result.stdout.lower() or "config" in result.stdout.lower()


class TestReadinessAssessment:
    """Tests for quantum readiness assessment."""
    
    def test_readiness_status(self):
        """Test quantum readiness status."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "readiness", "assess"],
            capture_output=True,
            text=True
        )
        # Should either succeed or provide feedback
        assert result.returncode == 0 or result.stdout or result.stderr
    
    def test_readiness_timeline(self):
        """Test readiness timeline."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "readiness", "timeline"],
            capture_output=True,
            text=True
        )
        # Should succeed or be informative
        assert result.returncode == 0 or result.stdout or result.stderr


class TestCommandModules:
    """Integrated tests for command modules."""
    
    def test_all_commands_present(self):
        """Verify all core commands are available."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        output = result.stdout.lower()
        # Verify core commands are listed
        assert "detect" in output
        assert "analyze" in output or "command" in output
    
    def test_banner_display(self):
        """Test banner display."""
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "--banner"],
            capture_output=True,
            text=True,
            env={**subprocess.os.environ, "PYTHONIOENCODING": "utf-8"}
        )
        assert result.returncode == 0


class TestIntegrationWorkflows:
    """Integration tests for complete workflows."""
    
    def test_full_assessment_workflow(self):
        """Test complete assessment workflow."""
        # Step 1: Check readiness
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "readiness", "assess"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 or result.stdout or result.stderr
        
        # Step 2: Get help on detect
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "detect", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        
        # Step 3: Get help on analyze
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "analyze", "--help"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
    
    def test_configuration_workflow(self):
        """Test configuration management workflow."""
        # Show current config
        result = subprocess.run(
            [sys.executable, "-m", "chronos", "config", "show"],
            capture_output=True,
            text=True
        )
        # Should succeed or show config info
        assert result.returncode == 0 or result.stdout or result.stderr


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
