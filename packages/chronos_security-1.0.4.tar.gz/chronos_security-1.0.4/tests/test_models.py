"""
Tests for CHRONOS Models
"""

import pytest
from datetime import datetime
from chronos.models.threat import Threat, ThreatLevel
from chronos.models.security import Vulnerability, SecurityReport, VulnerabilitySeverity


class TestThreat:
    """Tests for Threat model."""
    
    def test_threat_creation(self):
        """Test creating a threat instance."""
        threat = Threat(
            id="THREAT-001",
            name="SQL Injection",
            level=ThreatLevel.HIGH,
            description="SQL injection vulnerability detected",
            source="web_scanner",
        )
        assert threat.id == "THREAT-001"
        assert threat.level == ThreatLevel.HIGH
        assert not threat.is_critical()
    
    def test_critical_threat(self):
        """Test critical threat detection."""
        threat = Threat(
            id="THREAT-002",
            name="Zero Day Exploit",
            level=ThreatLevel.CRITICAL,
            description="Critical zero-day vulnerability",
            source="threat_intel",
        )
        assert threat.is_critical()
    
    def test_quantum_threat(self):
        """Test quantum vulnerability flag."""
        threat = Threat(
            id="THREAT-003",
            name="RSA Decryption Risk",
            level=ThreatLevel.HIGH,
            description="RSA vulnerable to quantum attack",
            source="crypto_analyzer",
            quantum_vulnerable=True,
        )
        assert threat.is_quantum_threat()
    
    def test_threat_to_dict(self):
        """Test threat serialization."""
        threat = Threat(
            id="THREAT-004",
            name="Test Threat",
            level=ThreatLevel.LOW,
            description="Test description",
            source="test",
        )
        data = threat.to_dict()
        assert data["id"] == "THREAT-004"
        assert data["level"] == "low"


class TestSecurityReport:
    """Tests for SecurityReport model."""
    
    def test_empty_report(self):
        """Test creating empty security report."""
        report = SecurityReport(
            id="REPORT-001",
            title="Security Assessment",
        )
        assert report.critical_count == 0
        assert report.high_count == 0
    
    def test_report_with_vulnerabilities(self):
        """Test report with vulnerabilities."""
        vuln1 = Vulnerability(
            id="VULN-001",
            title="Critical Vuln",
            severity=VulnerabilitySeverity.CRITICAL,
            description="Critical vulnerability",
            affected_component="auth",
        )
        vuln2 = Vulnerability(
            id="VULN-002",
            title="High Vuln",
            severity=VulnerabilitySeverity.HIGH,
            description="High severity vulnerability",
            affected_component="api",
        )
        
        report = SecurityReport(
            id="REPORT-002",
            title="Full Assessment",
            vulnerabilities=[vuln1, vuln2],
        )
        
        assert report.critical_count == 1
        assert report.high_count == 1
        assert len(report.vulnerabilities) == 2
