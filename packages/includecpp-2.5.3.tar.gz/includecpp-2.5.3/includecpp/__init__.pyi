"""Type stubs for includecpp package - VSCode IntelliSense support."""

from typing import Any, Dict, Optional, List, Literal, overload
from pathlib import Path

__version__: str

class ModuleWrapper:
    """Wrapper for C++ modules with getInfo() and dynamic attributes."""

    def getInfo(self) -> Dict[str, Any]:
        """Get module metadata including classes, functions, and structs."""
        ...

    def __getattr__(self, name: str) -> Any: ...
    def __dir__(self) -> List[str]: ...

class CppApi:
    """Main API class for including C++ modules with type hints."""

    # Inbuilt module constants
    FileSystem: str
    Crypto: str
    JSON: str
    StringUtils: str
    Networking: str
    DataStructures: str
    Threading: str
    StandardMenus: str

    def __init__(
        self,
        verbose: bool = False,
        auto_update: bool = False,
        config_path: Optional[Path] = None
    ) -> None: ...

    @property
    def Inbuilds(self) -> List[str]:
        """List of available inbuilt modules."""
        ...

    def exists(self, module_name: str) -> bool:
        """Check if a module exists."""
        ...

    # The include() method returns ModuleWrapper with dynamic attributes
    # VSCode will show getInfo() and other attributes set at runtime
    def include(
        self,
        module_name: str,
        auto_update: Optional[bool] = None
    ) -> ModuleWrapper:
        """Include a C++ module.

        Returns a ModuleWrapper instance with:
        - getInfo() method for module metadata
        - Dynamic attributes for classes, functions, and structs

        Example:
            crypto = api.include("crypto")
            crypto.getInfo()  # Get module info
            crypto.Crypto()   # Access Crypto class
            crypto.md5(...)   # Call md5 function

        Args:
            module_name: Name of the module to include
            auto_update: Whether to auto-rebuild if outdated (default: False)

        Returns:
            ModuleWrapper with module-specific attributes
        """
        ...

    def need_update(self, module_name: str) -> bool:
        """Check if module needs rebuild based on source file changes.

        Args:
            module_name: Name of module to check

        Returns:
            True if source files are newer than build
        """
        ...

    def update(self, module_name: str, verbose: Optional[bool] = None) -> None:
        """Rebuild a single module.

        Args:
            module_name: Name of module to rebuild
            verbose: Enable verbose output (default: use instance setting)
        """
        ...

    def rebuild(
        self,
        verbose: bool = False,
        clean: bool = False
    ) -> None:
        """Rebuild C++ modules."""
        ...

    def list_modules(self) -> List[str]:
        """List all available modules."""
        ...

__all__: List[str]
