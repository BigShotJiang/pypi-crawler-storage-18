#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name='souleyez',
    version='0.4.0',
    packages=find_packages(),
    package_data={
        'souleyez.storage': ['schema.sql'],
        '': ['data/wordlists/*.txt', 'data/wordlists/*.md'],
    },
    data_files=[
        ('share/souleyez/wordlists', [
            'data/wordlists/all_users.txt',
            'data/wordlists/api_endpoints.txt',
            'data/wordlists/default_credentials.txt',
            'data/wordlists/soul_pass.txt',
            'data/wordlists/soul_users.txt',
            'data/wordlists/subdomains_common.txt',
            'data/wordlists/top100.txt',
            'data/wordlists/top20_quick.txt',
            'data/wordlists/web_dirs_common.txt',
            'data/wordlists/web_extensions.txt',
            'data/wordlists/web_files_common.txt',
        ]),
    ],
    include_package_data=True,
    install_requires=[
        'click>=8.0.0',
        'psutil>=5.9.0',
        'wcwidth>=0.2.0',
        'cryptography>=3.4.0',
        'ollama>=0.1.0',
        'python-json-logger>=2.0.0',
        'defusedxml>=0.7.0',
        'rich>=13.0.0',
        'impacket>=0.11.0',
        'psycopg2-binary>=2.9.0',  # MSF database access
        'msgpack>=1.0.0',           # MSF RPC API
        'requests>=2.28.0',         # HTTP requests
        'readchar>=4.0.0',          # Interactive keyboard input
    ],
    entry_points={
        'console_scripts': [
            'souleyez=souleyez.main:main',
        ],
    },
    python_requires='>=3.8',
)
