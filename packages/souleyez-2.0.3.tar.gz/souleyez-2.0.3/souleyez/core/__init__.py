"""
Core functionality for SoulIze.
Contains credential management, parser handling, and tool chaining.
"""
