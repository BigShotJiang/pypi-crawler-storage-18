# Wazuh SIEM Integration
from .client import WazuhClient
from .config import WazuhConfig

__all__ = ['WazuhClient', 'WazuhConfig']
