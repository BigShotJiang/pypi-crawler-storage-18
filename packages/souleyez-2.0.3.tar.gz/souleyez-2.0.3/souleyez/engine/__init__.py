"""
Engine module for SoulIze.
Handles background job processing, result parsing, and worker management.
"""
