"""
Database migration scripts for SoulIze.
Handles schema upgrades and data migrations.
"""
