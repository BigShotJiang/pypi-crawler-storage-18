"""
Plugin system for SoulIze.
Contains integrations for security tools (nmap, hydra, metasploit, etc).
"""
