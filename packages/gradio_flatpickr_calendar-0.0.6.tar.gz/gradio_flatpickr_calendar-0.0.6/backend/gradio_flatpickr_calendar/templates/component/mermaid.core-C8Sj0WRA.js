var Zm = Object.defineProperty;
var Km = (e, t, r) => t in e ? Zm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var mt = (e, t, r) => Km(e, typeof t != "symbol" ? t + "" : t, r);
import { g as Qm, c as Jm } from "./Index-Dxzk1Xy0.js";
var ql = {
  name: "mermaid",
  version: "11.12.0",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.1.1",
    "@iconify/utils": "^3.0.1",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.11",
    dayjs: "^1.11.18",
    dompurify: "^3.2.5",
    katex: "^0.16.22",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^16.2.1",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.5",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    canvas: "^3.1.2",
    chokidar: "3.6.0",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.1.0",
    jison: "^0.4.18",
    "js-base64": "^3.7.8",
    jsdom: "^26.1.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.3",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.13",
    "type-fest": "^4.35.0",
    typedoc: "^0.28.12",
    "typedoc-plugin-markdown": "^4.8.1",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.6.4",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, Ch = { exports: {} };
(function(e, t) {
  (function(r, i) {
    e.exports = i();
  })(Jm, function() {
    var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", o = "second", s = "minute", c = "hour", l = "day", h = "week", u = "month", f = "quarter", p = "year", g = "date", m = "Invalid Date", y = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, x = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(M) {
      var L = ["th", "st", "nd", "rd"], B = M % 100;
      return "[" + M + (L[(B - 20) % 10] || L[B] || L[0]) + "]";
    } }, _ = function(M, L, B) {
      var E = String(M);
      return !E || E.length >= L ? M : "" + Array(L + 1 - E.length).join(B) + M;
    }, k = { s: _, z: function(M) {
      var L = -M.utcOffset(), B = Math.abs(L), E = Math.floor(B / 60), A = B % 60;
      return (L <= 0 ? "+" : "-") + _(E, 2, "0") + ":" + _(A, 2, "0");
    }, m: function M(L, B) {
      if (L.date() < B.date()) return -M(B, L);
      var E = 12 * (B.year() - L.year()) + (B.month() - L.month()), A = L.clone().add(E, u), W = B - A < 0, X = L.clone().add(E + (W ? -1 : 1), u);
      return +(-(E + (B - A) / (W ? A - X : X - A)) || 0);
    }, a: function(M) {
      return M < 0 ? Math.ceil(M) || 0 : Math.floor(M);
    }, p: function(M) {
      return { M: u, y: p, w: h, d: l, D: g, h: c, m: s, s: o, ms: a, Q: f }[M] || String(M || "").toLowerCase().replace(/s$/, "");
    }, u: function(M) {
      return M === void 0;
    } }, w = "en", C = {};
    C[w] = b;
    var S = "$isDayjsObject", O = function(M) {
      return M instanceof z || !(!M || !M[S]);
    }, P = function M(L, B, E) {
      var A;
      if (!L) return w;
      if (typeof L == "string") {
        var W = L.toLowerCase();
        C[W] && (A = W), B && (C[W] = B, A = W);
        var X = L.split("-");
        if (!A && X.length > 1) return M(X[0]);
      } else {
        var H = L.name;
        C[H] = L, A = H;
      }
      return !E && A && (w = A), A || !E && w;
    }, R = function(M, L) {
      if (O(M)) return M.clone();
      var B = typeof L == "object" ? L : {};
      return B.date = M, B.args = arguments, new z(B);
    }, $ = k;
    $.l = P, $.i = O, $.w = function(M, L) {
      return R(M, { locale: L.$L, utc: L.$u, x: L.$x, $offset: L.$offset });
    };
    var z = function() {
      function M(B) {
        this.$L = P(B.locale, null, !0), this.parse(B), this.$x = this.$x || B.x || {}, this[S] = !0;
      }
      var L = M.prototype;
      return L.parse = function(B) {
        this.$d = function(E) {
          var A = E.date, W = E.utc;
          if (A === null) return /* @__PURE__ */ new Date(NaN);
          if ($.u(A)) return /* @__PURE__ */ new Date();
          if (A instanceof Date) return new Date(A);
          if (typeof A == "string" && !/Z$/i.test(A)) {
            var X = A.match(y);
            if (X) {
              var H = X[2] - 1 || 0, ut = (X[7] || "0").substring(0, 3);
              return W ? new Date(Date.UTC(X[1], H, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, ut)) : new Date(X[1], H, X[3] || 1, X[4] || 0, X[5] || 0, X[6] || 0, ut);
            }
          }
          return new Date(A);
        }(B), this.init();
      }, L.init = function() {
        var B = this.$d;
        this.$y = B.getFullYear(), this.$M = B.getMonth(), this.$D = B.getDate(), this.$W = B.getDay(), this.$H = B.getHours(), this.$m = B.getMinutes(), this.$s = B.getSeconds(), this.$ms = B.getMilliseconds();
      }, L.$utils = function() {
        return $;
      }, L.isValid = function() {
        return this.$d.toString() !== m;
      }, L.isSame = function(B, E) {
        var A = R(B);
        return this.startOf(E) <= A && A <= this.endOf(E);
      }, L.isAfter = function(B, E) {
        return R(B) < this.startOf(E);
      }, L.isBefore = function(B, E) {
        return this.endOf(E) < R(B);
      }, L.$g = function(B, E, A) {
        return $.u(B) ? this[E] : this.set(A, B);
      }, L.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, L.valueOf = function() {
        return this.$d.getTime();
      }, L.startOf = function(B, E) {
        var A = this, W = !!$.u(E) || E, X = $.p(B), H = function(yt, xt) {
          var vt = $.w(A.$u ? Date.UTC(A.$y, xt, yt) : new Date(A.$y, xt, yt), A);
          return W ? vt : vt.endOf(l);
        }, ut = function(yt, xt) {
          return $.w(A.toDate()[yt].apply(A.toDate("s"), (W ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(xt)), A);
        }, nt = this.$W, gt = this.$M, st = this.$D, at = "set" + (this.$u ? "UTC" : "");
        switch (X) {
          case p:
            return W ? H(1, 0) : H(31, 11);
          case u:
            return W ? H(1, gt) : H(0, gt + 1);
          case h:
            var ct = this.$locale().weekStart || 0, wt = (nt < ct ? nt + 7 : nt) - ct;
            return H(W ? st - wt : st + (6 - wt), gt);
          case l:
          case g:
            return ut(at + "Hours", 0);
          case c:
            return ut(at + "Minutes", 1);
          case s:
            return ut(at + "Seconds", 2);
          case o:
            return ut(at + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, L.endOf = function(B) {
        return this.startOf(B, !1);
      }, L.$set = function(B, E) {
        var A, W = $.p(B), X = "set" + (this.$u ? "UTC" : ""), H = (A = {}, A[l] = X + "Date", A[g] = X + "Date", A[u] = X + "Month", A[p] = X + "FullYear", A[c] = X + "Hours", A[s] = X + "Minutes", A[o] = X + "Seconds", A[a] = X + "Milliseconds", A)[W], ut = W === l ? this.$D + (E - this.$W) : E;
        if (W === u || W === p) {
          var nt = this.clone().set(g, 1);
          nt.$d[H](ut), nt.init(), this.$d = nt.set(g, Math.min(this.$D, nt.daysInMonth())).$d;
        } else H && this.$d[H](ut);
        return this.init(), this;
      }, L.set = function(B, E) {
        return this.clone().$set(B, E);
      }, L.get = function(B) {
        return this[$.p(B)]();
      }, L.add = function(B, E) {
        var A, W = this;
        B = Number(B);
        var X = $.p(E), H = function(gt) {
          var st = R(W);
          return $.w(st.date(st.date() + Math.round(gt * B)), W);
        };
        if (X === u) return this.set(u, this.$M + B);
        if (X === p) return this.set(p, this.$y + B);
        if (X === l) return H(1);
        if (X === h) return H(7);
        var ut = (A = {}, A[s] = i, A[c] = n, A[o] = r, A)[X] || 1, nt = this.$d.getTime() + B * ut;
        return $.w(nt, this);
      }, L.subtract = function(B, E) {
        return this.add(-1 * B, E);
      }, L.format = function(B) {
        var E = this, A = this.$locale();
        if (!this.isValid()) return A.invalidDate || m;
        var W = B || "YYYY-MM-DDTHH:mm:ssZ", X = $.z(this), H = this.$H, ut = this.$m, nt = this.$M, gt = A.weekdays, st = A.months, at = A.meridiem, ct = function(xt, vt, Ht, ge) {
          return xt && (xt[vt] || xt(E, W)) || Ht[vt].slice(0, ge);
        }, wt = function(xt) {
          return $.s(H % 12 || 12, xt, "0");
        }, yt = at || function(xt, vt, Ht) {
          var ge = xt < 12 ? "AM" : "PM";
          return Ht ? ge.toLowerCase() : ge;
        };
        return W.replace(x, function(xt, vt) {
          return vt || function(Ht) {
            switch (Ht) {
              case "YY":
                return String(E.$y).slice(-2);
              case "YYYY":
                return $.s(E.$y, 4, "0");
              case "M":
                return nt + 1;
              case "MM":
                return $.s(nt + 1, 2, "0");
              case "MMM":
                return ct(A.monthsShort, nt, st, 3);
              case "MMMM":
                return ct(st, nt);
              case "D":
                return E.$D;
              case "DD":
                return $.s(E.$D, 2, "0");
              case "d":
                return String(E.$W);
              case "dd":
                return ct(A.weekdaysMin, E.$W, gt, 2);
              case "ddd":
                return ct(A.weekdaysShort, E.$W, gt, 3);
              case "dddd":
                return gt[E.$W];
              case "H":
                return String(H);
              case "HH":
                return $.s(H, 2, "0");
              case "h":
                return wt(1);
              case "hh":
                return wt(2);
              case "a":
                return yt(H, ut, !0);
              case "A":
                return yt(H, ut, !1);
              case "m":
                return String(ut);
              case "mm":
                return $.s(ut, 2, "0");
              case "s":
                return String(E.$s);
              case "ss":
                return $.s(E.$s, 2, "0");
              case "SSS":
                return $.s(E.$ms, 3, "0");
              case "Z":
                return X;
            }
            return null;
          }(xt) || X.replace(":", "");
        });
      }, L.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, L.diff = function(B, E, A) {
        var W, X = this, H = $.p(E), ut = R(B), nt = (ut.utcOffset() - this.utcOffset()) * i, gt = this - ut, st = function() {
          return $.m(X, ut);
        };
        switch (H) {
          case p:
            W = st() / 12;
            break;
          case u:
            W = st();
            break;
          case f:
            W = st() / 3;
            break;
          case h:
            W = (gt - nt) / 6048e5;
            break;
          case l:
            W = (gt - nt) / 864e5;
            break;
          case c:
            W = gt / n;
            break;
          case s:
            W = gt / i;
            break;
          case o:
            W = gt / r;
            break;
          default:
            W = gt;
        }
        return A ? W : $.a(W);
      }, L.daysInMonth = function() {
        return this.endOf(u).$D;
      }, L.$locale = function() {
        return C[this.$L];
      }, L.locale = function(B, E) {
        if (!B) return this.$L;
        var A = this.clone(), W = P(B, E, !0);
        return W && (A.$L = W), A;
      }, L.clone = function() {
        return $.w(this.$d, this);
      }, L.toDate = function() {
        return new Date(this.valueOf());
      }, L.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, L.toISOString = function() {
        return this.$d.toISOString();
      }, L.toString = function() {
        return this.$d.toUTCString();
      }, M;
    }(), D = z.prototype;
    return R.prototype = D, [["$ms", a], ["$s", o], ["$m", s], ["$H", c], ["$W", l], ["$M", u], ["$y", p], ["$D", g]].forEach(function(M) {
      D[M[1]] = function(L) {
        return this.$g(L, M[0], M[1]);
      };
    }), R.extend = function(M, L) {
      return M.$i || (M(L, z, R), M.$i = !0), R;
    }, R.locale = P, R.isDayjs = O, R.unix = function(M) {
      return R(1e3 * M);
    }, R.en = C[w], R.Ls = C, R.p = {}, R;
  });
})(Ch);
var t0 = Ch.exports;
const e0 = /* @__PURE__ */ Qm(t0);
var _h = Object.defineProperty, d = (e, t) => _h(e, "name", { value: t, configurable: !0 }), r0 = (e, t) => {
  for (var r in t)
    _h(e, r, { get: t[r], enumerable: !0 });
}, Ae = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ d((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ d((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ d((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ d((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ d((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ d((...e) => {
  }, "fatal")
}, _o = /* @__PURE__ */ d(function(e = "fatal") {
  let t = Ae.fatal;
  typeof e == "string" ? e.toLowerCase() in Ae && (t = Ae[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= Ae.fatal && (F.fatal = console.error ? console.error.bind(console, ne("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", ne("FATAL"))), t <= Ae.error && (F.error = console.error ? console.error.bind(console, ne("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", ne("ERROR"))), t <= Ae.warn && (F.warn = console.warn ? console.warn.bind(console, ne("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", ne("WARN"))), t <= Ae.info && (F.info = console.info ? console.info.bind(console, ne("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", ne("INFO"))), t <= Ae.debug && (F.debug = console.debug ? console.debug.bind(console, ne("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ne("DEBUG"))), t <= Ae.trace && (F.trace = console.debug ? console.debug.bind(console, ne("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ne("TRACE")));
}, "setLogLevel"), ne = /* @__PURE__ */ d((e) => `%c${e0().format("ss.SSS")} : ${e} : `, "format");
const kn = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return kn.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return kn.hue2rgb(a, n, e) * 255;
      case "b":
        return kn.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), o = (n + a) / 2;
    if (i === "l")
      return o * 100;
    if (n === a)
      return 0;
    const s = n - a, c = o > 0.5 ? s / (2 - n - a) : s / (n + a);
    if (i === "s")
      return c * 100;
    switch (n) {
      case e:
        return ((t - r) / s + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / s + 2) * 60;
      case r:
        return ((e - t) / s + 4) * 60;
      default:
        return -1;
    }
  }
}, i0 = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, n0 = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, it = {
  channel: kn,
  lang: i0,
  unit: n0
}, We = {};
for (let e = 0; e <= 255; e++)
  We[e] = it.unit.dec2hex(e);
const Rt = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class a0 {
  constructor() {
    this.type = Rt.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = Rt.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class s0 {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new a0();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = Rt.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = it.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = it.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = it.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = it.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = it.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = it.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const ba = new s0({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), Or = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(Or.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, o = n > 4, s = o ? 1 : 17, c = o ? 8 : 4, l = a ? 0 : -1, h = o ? 255 : 15;
    return ba.set({
      r: (i >> c * (l + 3) & h) * s,
      g: (i >> c * (l + 2) & h) * s,
      b: (i >> c * (l + 1) & h) * s,
      a: a ? (i & h) * s / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}${We[Math.round(n * 255)]}` : `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}`;
  }
}, nr = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(nr.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return it.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return it.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return it.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return it.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(nr.re);
    if (!r)
      return;
    const [, i, n, a, o, s] = r;
    return ba.set({
      h: nr._hue2deg(i),
      s: it.channel.clamp.s(parseFloat(n)),
      l: it.channel.clamp.l(parseFloat(a)),
      a: o ? it.channel.clamp.a(s ? parseFloat(o) / 100 : parseFloat(o)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%, ${n})` : `hsl(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%)`;
  }
}, Li = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Li.colors[e];
    if (t)
      return Or.parse(t);
  },
  stringify: (e) => {
    const t = Or.stringify(e);
    for (const r in Li.colors)
      if (Li.colors[r] === t)
        return r;
  }
}, bi = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(bi.re);
    if (!r)
      return;
    const [, i, n, a, o, s, c, l, h] = r;
    return ba.set({
      r: it.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: it.channel.clamp.g(o ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: it.channel.clamp.b(c ? parseFloat(s) * 2.55 : parseFloat(s)),
      a: l ? it.channel.clamp.a(h ? parseFloat(l) / 100 : parseFloat(l)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)}, ${it.lang.round(n)})` : `rgb(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)})`;
  }
}, we = {
  /* VARIABLES */
  format: {
    keyword: Li,
    hex: Or,
    rgb: bi,
    rgba: bi,
    hsl: nr,
    hsla: nr
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = Or.parse(e) || bi.parse(e) || nr.parse(e) || Li.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(Rt.HSL) || e.data.r === void 0 ? nr.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? bi.stringify(e) : Or.stringify(e)
}, wh = (e, t) => {
  const r = we.parse(e);
  for (const i in t)
    r[i] = it.channel.clamp[i](t[i]);
  return we.stringify(r);
}, Ai = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return wh(e, { a: t });
  const n = ba.set({
    r: it.channel.clamp.r(e),
    g: it.channel.clamp.g(t),
    b: it.channel.clamp.b(r),
    a: it.channel.clamp.a(i)
  });
  return we.stringify(n);
}, o0 = (e) => {
  const { r: t, g: r, b: i } = we.parse(e), n = 0.2126 * it.channel.toLinear(t) + 0.7152 * it.channel.toLinear(r) + 0.0722 * it.channel.toLinear(i);
  return it.lang.round(n);
}, l0 = (e) => o0(e) >= 0.5, Gi = (e) => !l0(e), kh = (e, t, r) => {
  const i = we.parse(e), n = i[t], a = it.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), we.stringify(i);
}, j = (e, t) => kh(e, "l", t), J = (e, t) => kh(e, "l", -t), T = (e, t) => {
  const r = we.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return wh(e, i);
}, c0 = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: o } = we.parse(e), { r: s, g: c, b: l, a: h } = we.parse(t), u = r / 100, f = u * 2 - 1, p = o - h, m = ((f * p === -1 ? f : (f + p) / (1 + f * p)) + 1) / 2, y = 1 - m, x = i * m + s * y, b = n * m + c * y, _ = a * m + l * y, k = o * u + h * (1 - u);
  return Ai(x, b, _, k);
}, N = (e, t = 100) => {
  const r = we.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, c0(r, e, t);
};
/*! @license DOMPurify 3.2.7 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.7/LICENSE */
const {
  entries: vh,
  setPrototypeOf: Hl,
  isFrozen: h0,
  getPrototypeOf: u0,
  getOwnPropertyDescriptor: f0
} = Object;
let {
  freeze: Xt,
  seal: ae,
  create: Sh
} = Object, {
  apply: ws,
  construct: ks
} = typeof Reflect < "u" && Reflect;
Xt || (Xt = function(t) {
  return t;
});
ae || (ae = function(t) {
  return t;
});
ws || (ws = function(t, r) {
  for (var i = arguments.length, n = new Array(i > 2 ? i - 2 : 0), a = 2; a < i; a++)
    n[a - 2] = arguments[a];
  return t.apply(r, n);
});
ks || (ks = function(t) {
  for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
    i[n - 1] = arguments[n];
  return new t(...i);
});
const hn = Vt(Array.prototype.forEach), p0 = Vt(Array.prototype.lastIndexOf), jl = Vt(Array.prototype.pop), li = Vt(Array.prototype.push), d0 = Vt(Array.prototype.splice), vn = Vt(String.prototype.toLowerCase), es = Vt(String.prototype.toString), rs = Vt(String.prototype.match), ci = Vt(String.prototype.replace), g0 = Vt(String.prototype.indexOf), m0 = Vt(String.prototype.trim), ce = Vt(Object.prototype.hasOwnProperty), jt = Vt(RegExp.prototype.test), hi = y0(TypeError);
function Vt(e) {
  return function(t) {
    t instanceof RegExp && (t.lastIndex = 0);
    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
      i[n - 1] = arguments[n];
    return ws(e, t, i);
  };
}
function y0(e) {
  return function() {
    for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
      r[i] = arguments[i];
    return ks(e, r);
  };
}
function ot(e, t) {
  let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : vn;
  Hl && Hl(e, null);
  let i = t.length;
  for (; i--; ) {
    let n = t[i];
    if (typeof n == "string") {
      const a = r(n);
      a !== n && (h0(t) || (t[i] = a), n = a);
    }
    e[n] = !0;
  }
  return e;
}
function x0(e) {
  for (let t = 0; t < e.length; t++)
    ce(e, t) || (e[t] = null);
  return e;
}
function $e(e) {
  const t = Sh(null);
  for (const [r, i] of vh(e))
    ce(e, r) && (Array.isArray(i) ? t[r] = x0(i) : i && typeof i == "object" && i.constructor === Object ? t[r] = $e(i) : t[r] = i);
  return t;
}
function ui(e, t) {
  for (; e !== null; ) {
    const i = f0(e, t);
    if (i) {
      if (i.get)
        return Vt(i.get);
      if (typeof i.value == "function")
        return Vt(i.value);
    }
    e = u0(e);
  }
  function r() {
    return null;
  }
  return r;
}
const Yl = Xt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), is = Xt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "slot", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), ns = Xt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), b0 = Xt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), as = Xt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), C0 = Xt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Ul = Xt(["#text"]), Gl = Xt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), ss = Xt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Xl = Xt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), un = Xt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), _0 = ae(/\{\{[\w\W]*|[\w\W]*\}\}/gm), w0 = ae(/<%[\w\W]*|[\w\W]*%>/gm), k0 = ae(/\$\{[\w\W]*/gm), v0 = ae(/^data-[\-\w.\u00B7-\uFFFF]+$/), S0 = ae(/^aria-[\-\w]+$/), Th = ae(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), T0 = ae(/^(?:\w+script|data):/i), B0 = ae(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Bh = ae(/^html$/i), L0 = ae(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Vl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: S0,
  ATTR_WHITESPACE: B0,
  CUSTOM_ELEMENT: L0,
  DATA_ATTR: v0,
  DOCTYPE_NAME: Bh,
  ERB_EXPR: w0,
  IS_ALLOWED_URI: Th,
  IS_SCRIPT_OR_DATA: T0,
  MUSTACHE_EXPR: _0,
  TMPLIT_EXPR: k0
});
const fi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, A0 = function() {
  return typeof window > "u" ? null : window;
}, M0 = function(t, r) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const n = "data-tt-policy-suffix";
  r && r.hasAttribute(n) && (i = r.getAttribute(n));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(a, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Zl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Lh() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : A0();
  const t = (Q) => Lh(Q);
  if (t.version = "3.2.7", t.removed = [], !e || !e.document || e.document.nodeType !== fi.document || !e.Element)
    return t.isSupported = !1, t;
  let {
    document: r
  } = e;
  const i = r, n = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: o,
    Node: s,
    Element: c,
    NodeFilter: l,
    NamedNodeMap: h = e.NamedNodeMap || e.MozNamedAttrMap,
    HTMLFormElement: u,
    DOMParser: f,
    trustedTypes: p
  } = e, g = c.prototype, m = ui(g, "cloneNode"), y = ui(g, "remove"), x = ui(g, "nextSibling"), b = ui(g, "childNodes"), _ = ui(g, "parentNode");
  if (typeof o == "function") {
    const Q = r.createElement("template");
    Q.content && Q.content.ownerDocument && (r = Q.content.ownerDocument);
  }
  let k, w = "";
  const {
    implementation: C,
    createNodeIterator: S,
    createDocumentFragment: O,
    getElementsByTagName: P
  } = r, {
    importNode: R
  } = i;
  let $ = Zl();
  t.isSupported = typeof vh == "function" && typeof _ == "function" && C && C.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: z,
    ERB_EXPR: D,
    TMPLIT_EXPR: M,
    DATA_ATTR: L,
    ARIA_ATTR: B,
    IS_SCRIPT_OR_DATA: E,
    ATTR_WHITESPACE: A,
    CUSTOM_ELEMENT: W
  } = Vl;
  let {
    IS_ALLOWED_URI: X
  } = Vl, H = null;
  const ut = ot({}, [...Yl, ...is, ...ns, ...as, ...Ul]);
  let nt = null;
  const gt = ot({}, [...Gl, ...ss, ...Xl, ...un]);
  let st = Object.seal(Sh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), at = null, ct = null, wt = !0, yt = !0, xt = !1, vt = !0, Ht = !1, ge = !0, le = !1, Ua = !1, Ga = !1, kr = !1, nn = !1, an = !1, vl = !0, Sl = !1;
  const qm = "user-content-";
  let Xa = !0, si = !1, vr = {}, Sr = null;
  const Tl = ot({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Bl = null;
  const Ll = ot({}, ["audio", "video", "img", "source", "image", "track"]);
  let Va = null;
  const Al = ot({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), sn = "http://www.w3.org/1998/Math/MathML", on = "http://www.w3.org/2000/svg", Te = "http://www.w3.org/1999/xhtml";
  let Tr = Te, Za = !1, Ka = null;
  const Hm = ot({}, [sn, on, Te], es);
  let ln = ot({}, ["mi", "mo", "mn", "ms", "mtext"]), cn = ot({}, ["annotation-xml"]);
  const jm = ot({}, ["title", "style", "font", "a", "script"]);
  let oi = null;
  const Ym = ["application/xhtml+xml", "text/html"], Um = "text/html";
  let Mt = null, Br = null;
  const Gm = r.createElement("form"), Ml = function(v) {
    return v instanceof RegExp || v instanceof Function;
  }, Qa = function() {
    let v = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Br && Br === v)) {
      if ((!v || typeof v != "object") && (v = {}), v = $e(v), oi = // eslint-disable-next-line unicorn/prefer-includes
      Ym.indexOf(v.PARSER_MEDIA_TYPE) === -1 ? Um : v.PARSER_MEDIA_TYPE, Mt = oi === "application/xhtml+xml" ? es : vn, H = ce(v, "ALLOWED_TAGS") ? ot({}, v.ALLOWED_TAGS, Mt) : ut, nt = ce(v, "ALLOWED_ATTR") ? ot({}, v.ALLOWED_ATTR, Mt) : gt, Ka = ce(v, "ALLOWED_NAMESPACES") ? ot({}, v.ALLOWED_NAMESPACES, es) : Hm, Va = ce(v, "ADD_URI_SAFE_ATTR") ? ot($e(Al), v.ADD_URI_SAFE_ATTR, Mt) : Al, Bl = ce(v, "ADD_DATA_URI_TAGS") ? ot($e(Ll), v.ADD_DATA_URI_TAGS, Mt) : Ll, Sr = ce(v, "FORBID_CONTENTS") ? ot({}, v.FORBID_CONTENTS, Mt) : Tl, at = ce(v, "FORBID_TAGS") ? ot({}, v.FORBID_TAGS, Mt) : $e({}), ct = ce(v, "FORBID_ATTR") ? ot({}, v.FORBID_ATTR, Mt) : $e({}), vr = ce(v, "USE_PROFILES") ? v.USE_PROFILES : !1, wt = v.ALLOW_ARIA_ATTR !== !1, yt = v.ALLOW_DATA_ATTR !== !1, xt = v.ALLOW_UNKNOWN_PROTOCOLS || !1, vt = v.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ht = v.SAFE_FOR_TEMPLATES || !1, ge = v.SAFE_FOR_XML !== !1, le = v.WHOLE_DOCUMENT || !1, kr = v.RETURN_DOM || !1, nn = v.RETURN_DOM_FRAGMENT || !1, an = v.RETURN_TRUSTED_TYPE || !1, Ga = v.FORCE_BODY || !1, vl = v.SANITIZE_DOM !== !1, Sl = v.SANITIZE_NAMED_PROPS || !1, Xa = v.KEEP_CONTENT !== !1, si = v.IN_PLACE || !1, X = v.ALLOWED_URI_REGEXP || Th, Tr = v.NAMESPACE || Te, ln = v.MATHML_TEXT_INTEGRATION_POINTS || ln, cn = v.HTML_INTEGRATION_POINTS || cn, st = v.CUSTOM_ELEMENT_HANDLING || {}, v.CUSTOM_ELEMENT_HANDLING && Ml(v.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (st.tagNameCheck = v.CUSTOM_ELEMENT_HANDLING.tagNameCheck), v.CUSTOM_ELEMENT_HANDLING && Ml(v.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (st.attributeNameCheck = v.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), v.CUSTOM_ELEMENT_HANDLING && typeof v.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (st.allowCustomizedBuiltInElements = v.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Ht && (yt = !1), nn && (kr = !0), vr && (H = ot({}, Ul), nt = [], vr.html === !0 && (ot(H, Yl), ot(nt, Gl)), vr.svg === !0 && (ot(H, is), ot(nt, ss), ot(nt, un)), vr.svgFilters === !0 && (ot(H, ns), ot(nt, ss), ot(nt, un)), vr.mathMl === !0 && (ot(H, as), ot(nt, Xl), ot(nt, un))), v.ADD_TAGS && (H === ut && (H = $e(H)), ot(H, v.ADD_TAGS, Mt)), v.ADD_ATTR && (nt === gt && (nt = $e(nt)), ot(nt, v.ADD_ATTR, Mt)), v.ADD_URI_SAFE_ATTR && ot(Va, v.ADD_URI_SAFE_ATTR, Mt), v.FORBID_CONTENTS && (Sr === Tl && (Sr = $e(Sr)), ot(Sr, v.FORBID_CONTENTS, Mt)), Xa && (H["#text"] = !0), le && ot(H, ["html", "head", "body"]), H.table && (ot(H, ["tbody"]), delete at.tbody), v.TRUSTED_TYPES_POLICY) {
        if (typeof v.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw hi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof v.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw hi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        k = v.TRUSTED_TYPES_POLICY, w = k.createHTML("");
      } else
        k === void 0 && (k = M0(p, n)), k !== null && typeof w == "string" && (w = k.createHTML(""));
      Xt && Xt(v), Br = v;
    }
  }, $l = ot({}, [...is, ...ns, ...b0]), El = ot({}, [...as, ...C0]), Xm = function(v) {
    let I = _(v);
    (!I || !I.tagName) && (I = {
      namespaceURI: Tr,
      tagName: "template"
    });
    const Z = vn(v.tagName), Ct = vn(I.tagName);
    return Ka[v.namespaceURI] ? v.namespaceURI === on ? I.namespaceURI === Te ? Z === "svg" : I.namespaceURI === sn ? Z === "svg" && (Ct === "annotation-xml" || ln[Ct]) : !!$l[Z] : v.namespaceURI === sn ? I.namespaceURI === Te ? Z === "math" : I.namespaceURI === on ? Z === "math" && cn[Ct] : !!El[Z] : v.namespaceURI === Te ? I.namespaceURI === on && !cn[Ct] || I.namespaceURI === sn && !ln[Ct] ? !1 : !El[Z] && (jm[Z] || !$l[Z]) : !!(oi === "application/xhtml+xml" && Ka[v.namespaceURI]) : !1;
  }, me = function(v) {
    li(t.removed, {
      element: v
    });
    try {
      _(v).removeChild(v);
    } catch {
      y(v);
    }
  }, Je = function(v, I) {
    try {
      li(t.removed, {
        attribute: I.getAttributeNode(v),
        from: I
      });
    } catch {
      li(t.removed, {
        attribute: null,
        from: I
      });
    }
    if (I.removeAttribute(v), v === "is")
      if (kr || nn)
        try {
          me(I);
        } catch {
        }
      else
        try {
          I.setAttribute(v, "");
        } catch {
        }
  }, Fl = function(v) {
    let I = null, Z = null;
    if (Ga)
      v = "<remove></remove>" + v;
    else {
      const St = rs(v, /^[\r\n\t ]+/);
      Z = St && St[0];
    }
    oi === "application/xhtml+xml" && Tr === Te && (v = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + v + "</body></html>");
    const Ct = k ? k.createHTML(v) : v;
    if (Tr === Te)
      try {
        I = new f().parseFromString(Ct, oi);
      } catch {
      }
    if (!I || !I.documentElement) {
      I = C.createDocument(Tr, "template", null);
      try {
        I.documentElement.innerHTML = Za ? w : Ct;
      } catch {
      }
    }
    const Dt = I.body || I.documentElement;
    return v && Z && Dt.insertBefore(r.createTextNode(Z), Dt.childNodes[0] || null), Tr === Te ? P.call(I, le ? "html" : "body")[0] : le ? I.documentElement : Dt;
  }, Ol = function(v) {
    return S.call(
      v.ownerDocument || v,
      v,
      // eslint-disable-next-line no-bitwise
      l.SHOW_ELEMENT | l.SHOW_COMMENT | l.SHOW_TEXT | l.SHOW_PROCESSING_INSTRUCTION | l.SHOW_CDATA_SECTION,
      null
    );
  }, Ja = function(v) {
    return v instanceof u && (typeof v.nodeName != "string" || typeof v.textContent != "string" || typeof v.removeChild != "function" || !(v.attributes instanceof h) || typeof v.removeAttribute != "function" || typeof v.setAttribute != "function" || typeof v.namespaceURI != "string" || typeof v.insertBefore != "function" || typeof v.hasChildNodes != "function");
  }, Dl = function(v) {
    return typeof s == "function" && v instanceof s;
  };
  function Be(Q, v, I) {
    hn(Q, (Z) => {
      Z.call(t, v, I, Br);
    });
  }
  const Rl = function(v) {
    let I = null;
    if (Be($.beforeSanitizeElements, v, null), Ja(v))
      return me(v), !0;
    const Z = Mt(v.nodeName);
    if (Be($.uponSanitizeElement, v, {
      tagName: Z,
      allowedTags: H
    }), ge && v.hasChildNodes() && !Dl(v.firstElementChild) && jt(/<[/\w!]/g, v.innerHTML) && jt(/<[/\w!]/g, v.textContent) || v.nodeType === fi.progressingInstruction || ge && v.nodeType === fi.comment && jt(/<[/\w]/g, v.data))
      return me(v), !0;
    if (!H[Z] || at[Z]) {
      if (!at[Z] && Pl(Z) && (st.tagNameCheck instanceof RegExp && jt(st.tagNameCheck, Z) || st.tagNameCheck instanceof Function && st.tagNameCheck(Z)))
        return !1;
      if (Xa && !Sr[Z]) {
        const Ct = _(v) || v.parentNode, Dt = b(v) || v.childNodes;
        if (Dt && Ct) {
          const St = Dt.length;
          for (let Zt = St - 1; Zt >= 0; --Zt) {
            const Le = m(Dt[Zt], !0);
            Le.__removalCount = (v.__removalCount || 0) + 1, Ct.insertBefore(Le, x(v));
          }
        }
      }
      return me(v), !0;
    }
    return v instanceof c && !Xm(v) || (Z === "noscript" || Z === "noembed" || Z === "noframes") && jt(/<\/no(script|embed|frames)/i, v.innerHTML) ? (me(v), !0) : (Ht && v.nodeType === fi.text && (I = v.textContent, hn([z, D, M], (Ct) => {
      I = ci(I, Ct, " ");
    }), v.textContent !== I && (li(t.removed, {
      element: v.cloneNode()
    }), v.textContent = I)), Be($.afterSanitizeElements, v, null), !1);
  }, Il = function(v, I, Z) {
    if (vl && (I === "id" || I === "name") && (Z in r || Z in Gm))
      return !1;
    if (!(yt && !ct[I] && jt(L, I))) {
      if (!(wt && jt(B, I))) {
        if (!nt[I] || ct[I]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Pl(v) && (st.tagNameCheck instanceof RegExp && jt(st.tagNameCheck, v) || st.tagNameCheck instanceof Function && st.tagNameCheck(v)) && (st.attributeNameCheck instanceof RegExp && jt(st.attributeNameCheck, I) || st.attributeNameCheck instanceof Function && st.attributeNameCheck(I, v)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            I === "is" && st.allowCustomizedBuiltInElements && (st.tagNameCheck instanceof RegExp && jt(st.tagNameCheck, Z) || st.tagNameCheck instanceof Function && st.tagNameCheck(Z)))
          ) return !1;
        } else if (!Va[I]) {
          if (!jt(X, ci(Z, A, ""))) {
            if (!((I === "src" || I === "xlink:href" || I === "href") && v !== "script" && g0(Z, "data:") === 0 && Bl[v])) {
              if (!(xt && !jt(E, ci(Z, A, "")))) {
                if (Z)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Pl = function(v) {
    return v !== "annotation-xml" && rs(v, W);
  }, Nl = function(v) {
    Be($.beforeSanitizeAttributes, v, null);
    const {
      attributes: I
    } = v;
    if (!I || Ja(v))
      return;
    const Z = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: nt,
      forceKeepAttr: void 0
    };
    let Ct = I.length;
    for (; Ct--; ) {
      const Dt = I[Ct], {
        name: St,
        namespaceURI: Zt,
        value: Le
      } = Dt, Lr = Mt(St), ts = Le;
      let Et = St === "value" ? ts : m0(ts);
      if (Z.attrName = Lr, Z.attrValue = Et, Z.keepAttr = !0, Z.forceKeepAttr = void 0, Be($.uponSanitizeAttribute, v, Z), Et = Z.attrValue, Sl && (Lr === "id" || Lr === "name") && (Je(St, v), Et = qm + Et), ge && jt(/((--!?|])>)|<\/(style|title|textarea)/i, Et)) {
        Je(St, v);
        continue;
      }
      if (Lr === "attributename" && rs(Et, "href")) {
        Je(St, v);
        continue;
      }
      if (Z.forceKeepAttr)
        continue;
      if (!Z.keepAttr) {
        Je(St, v);
        continue;
      }
      if (!vt && jt(/\/>/i, Et)) {
        Je(St, v);
        continue;
      }
      Ht && hn([z, D, M], (Wl) => {
        Et = ci(Et, Wl, " ");
      });
      const zl = Mt(v.nodeName);
      if (!Il(zl, Lr, Et)) {
        Je(St, v);
        continue;
      }
      if (k && typeof p == "object" && typeof p.getAttributeType == "function" && !Zt)
        switch (p.getAttributeType(zl, Lr)) {
          case "TrustedHTML": {
            Et = k.createHTML(Et);
            break;
          }
          case "TrustedScriptURL": {
            Et = k.createScriptURL(Et);
            break;
          }
        }
      if (Et !== ts)
        try {
          Zt ? v.setAttributeNS(Zt, St, Et) : v.setAttribute(St, Et), Ja(v) ? me(v) : jl(t.removed);
        } catch {
          Je(St, v);
        }
    }
    Be($.afterSanitizeAttributes, v, null);
  }, Vm = function Q(v) {
    let I = null;
    const Z = Ol(v);
    for (Be($.beforeSanitizeShadowDOM, v, null); I = Z.nextNode(); )
      Be($.uponSanitizeShadowNode, I, null), Rl(I), Nl(I), I.content instanceof a && Q(I.content);
    Be($.afterSanitizeShadowDOM, v, null);
  };
  return t.sanitize = function(Q) {
    let v = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, I = null, Z = null, Ct = null, Dt = null;
    if (Za = !Q, Za && (Q = "<!-->"), typeof Q != "string" && !Dl(Q))
      if (typeof Q.toString == "function") {
        if (Q = Q.toString(), typeof Q != "string")
          throw hi("dirty is not a string, aborting");
      } else
        throw hi("toString is not a function");
    if (!t.isSupported)
      return Q;
    if (Ua || Qa(v), t.removed = [], typeof Q == "string" && (si = !1), si) {
      if (Q.nodeName) {
        const Le = Mt(Q.nodeName);
        if (!H[Le] || at[Le])
          throw hi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Q instanceof s)
      I = Fl("<!---->"), Z = I.ownerDocument.importNode(Q, !0), Z.nodeType === fi.element && Z.nodeName === "BODY" || Z.nodeName === "HTML" ? I = Z : I.appendChild(Z);
    else {
      if (!kr && !Ht && !le && // eslint-disable-next-line unicorn/prefer-includes
      Q.indexOf("<") === -1)
        return k && an ? k.createHTML(Q) : Q;
      if (I = Fl(Q), !I)
        return kr ? null : an ? w : "";
    }
    I && Ga && me(I.firstChild);
    const St = Ol(si ? Q : I);
    for (; Ct = St.nextNode(); )
      Rl(Ct), Nl(Ct), Ct.content instanceof a && Vm(Ct.content);
    if (si)
      return Q;
    if (kr) {
      if (nn)
        for (Dt = O.call(I.ownerDocument); I.firstChild; )
          Dt.appendChild(I.firstChild);
      else
        Dt = I;
      return (nt.shadowroot || nt.shadowrootmode) && (Dt = R.call(i, Dt, !0)), Dt;
    }
    let Zt = le ? I.outerHTML : I.innerHTML;
    return le && H["!doctype"] && I.ownerDocument && I.ownerDocument.doctype && I.ownerDocument.doctype.name && jt(Bh, I.ownerDocument.doctype.name) && (Zt = "<!DOCTYPE " + I.ownerDocument.doctype.name + `>
` + Zt), Ht && hn([z, D, M], (Le) => {
      Zt = ci(Zt, Le, " ");
    }), k && an ? k.createHTML(Zt) : Zt;
  }, t.setConfig = function() {
    let Q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Qa(Q), Ua = !0;
  }, t.clearConfig = function() {
    Br = null, Ua = !1;
  }, t.isValidAttribute = function(Q, v, I) {
    Br || Qa({});
    const Z = Mt(Q), Ct = Mt(v);
    return Il(Z, Ct, I);
  }, t.addHook = function(Q, v) {
    typeof v == "function" && li($[Q], v);
  }, t.removeHook = function(Q, v) {
    if (v !== void 0) {
      const I = p0($[Q], v);
      return I === -1 ? void 0 : d0($[Q], I, 1)[0];
    }
    return jl($[Q]);
  }, t.removeHooks = function(Q) {
    $[Q] = [];
  }, t.removeAllHooks = function() {
    $ = Zl();
  }, t;
}
var Yr = Lh(), Ah = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Mi = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, $0 = /\s*%%.*\n/gm, Ir, Mh = (Ir = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, d(Ir, "UnknownDiagramError"), Ir), ur = {}, wo = /* @__PURE__ */ d(function(e, t) {
  e = e.replace(Ah, "").replace(Mi, "").replace($0, `
`);
  for (const [r, { detector: i }] of Object.entries(ur))
    if (i(e, t))
      return r;
  throw new Mh(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), vs = /* @__PURE__ */ d((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    $h(t, r, i);
}, "registerLazyLoadedDiagrams"), $h = /* @__PURE__ */ d((e, t, r) => {
  ur[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), ur[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), E0 = /* @__PURE__ */ d((e) => ur[e].loader, "getDiagramLoader"), Ss = /* @__PURE__ */ d((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => Ss(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = Ss(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), Bt = Ss, Ca = "#ffffff", _a = "#f2f2f2", Yt = /* @__PURE__ */ d((e, t) => t ? T(e, { s: -40, l: 10 }) : T(e, { s: -40, l: -10 }), "mkBorder"), Pr, F0 = (Pr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    var r, i, n, a, o, s, c, l, h, u, f, p, g, m, y, x, b, _, k, w, C;
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || T(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || T(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || Yt(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || Yt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || Yt(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || Yt(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || N(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || N(this.tertiaryColor), this.lineColor = this.lineColor || N(this.background), this.arrowheadColor = this.arrowheadColor || N(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || J(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || N(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || j(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || J(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.darkMode)
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 75);
    else
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 25);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleInv" + S] = this["cScaleInv" + S] || N(this["cScale" + S]);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this.darkMode ? this["cScalePeer" + S] = this["cScalePeer" + S] || j(this["cScale" + S], 10) : this["cScalePeer" + S] = this["cScalePeer" + S] || J(this["cScale" + S], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleLabel" + S] = this["cScaleLabel" + S] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let S = 0; S < 5; S++)
      this["surface" + S] = this["surface" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (5 + S * 3) }), this["surfacePeer" + S] = this["surfacePeer" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (8 + S * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || T(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || T(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || T(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || T(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || T(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: ((r = this.radar) == null ? void 0 : r.axisColor) || this.lineColor,
      axisStrokeWidth: ((i = this.radar) == null ? void 0 : i.axisStrokeWidth) || 2,
      axisLabelFontSize: ((n = this.radar) == null ? void 0 : n.axisLabelFontSize) || 12,
      curveOpacity: ((a = this.radar) == null ? void 0 : a.curveOpacity) || 0.5,
      curveStrokeWidth: ((o = this.radar) == null ? void 0 : o.curveStrokeWidth) || 2,
      graticuleColor: ((s = this.radar) == null ? void 0 : s.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((c = this.radar) == null ? void 0 : c.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((h = this.radar) == null ? void 0 : h.legendBoxSize) || 12,
      legendFontSize: ((u = this.radar) == null ? void 0 : u.legendFontSize) || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((f = this.xyChart) == null ? void 0 : f.backgroundColor) || this.background,
      titleColor: ((p = this.xyChart) == null ? void 0 : p.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((g = this.xyChart) == null ? void 0 : g.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((m = this.xyChart) == null ? void 0 : m.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((y = this.xyChart) == null ? void 0 : y.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((b = this.xyChart) == null ? void 0 : b.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((k = this.xyChart) == null ? void 0 : k.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((w = this.xyChart) == null ? void 0 : w.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((C = this.xyChart) == null ? void 0 : C.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Pr, "Theme"), Pr), O0 = /* @__PURE__ */ d((e) => {
  const t = new F0();
  return t.calculate(e), t;
}, "getThemeVariables"), Nr, D0 = (Nr = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = j(this.primaryColor, 16), this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = N(this.background), this.secondaryBorderColor = Yt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Yt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = j(N("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Ai(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = J("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = J(this.sectionBkgColor, 10), this.taskBorderColor = Ai(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Ai(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || j(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    var t, r, i, n, a, o, s, c, l, h, u, f, p, g, m, y, x, b, _, k, w;
    this.secondBkg = j(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = j(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = j(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || N(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScalePeer" + C] = this["cScalePeer" + C] || j(this["cScale" + C], 10);
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-10 + C * 4) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-7 + C * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((c = this.xyChart) == null ? void 0 : c.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((l = this.xyChart) == null ? void 0 : l.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = j(this.secondaryColor, 20), this.git1 = j(this.pie2 || this.secondaryColor, 20), this.git2 = j(this.pie3 || this.tertiaryColor, 20), this.git3 = j(this.pie4 || T(this.primaryColor, { h: -30 }), 20), this.git4 = j(this.pie5 || T(this.primaryColor, { h: -60 }), 20), this.git5 = j(this.pie6 || T(this.primaryColor, { h: -90 }), 10), this.git6 = j(this.pie7 || T(this.primaryColor, { h: 60 }), 10), this.git7 = j(this.pie8 || T(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || j(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || j(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Nr, "Theme"), Nr), R0 = /* @__PURE__ */ d((e) => {
  const t = new D0();
  return t.calculate(e), t;
}, "getThemeVariables"), zr, I0 = (zr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = T(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = Yt(this.primaryColor, this.darkMode), this.secondaryBorderColor = Yt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Yt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Ai(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    var t, r, i, n, a, o, s, c, l, h, u, f, p, g, m, y, x, b, _, k, w;
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, l: -(7 + C * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || N(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || N(this.labelTextColor);
      for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
        this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = j(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || j(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || T(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((l = this.radar) == null ? void 0 : l.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || J(N(this.git0), 25), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(zr, "Theme"), zr), P0 = /* @__PURE__ */ d((e) => {
  const t = new I0();
  return t.calculate(e), t;
}, "getThemeVariables"), Wr, N0 = (Wr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = j("#cde498", 10), this.primaryBorderColor = Yt(this.primaryColor, this.darkMode), this.secondaryBorderColor = Yt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Yt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.primaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, c, l, h, u, f, p, g, m, y, x, b, _, k, w;
    this.actorBorder = J(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || j(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((l = this.radar) == null ? void 0 : l.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((x = this.xyChart) == null ? void 0 : x.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((w = this.xyChart) == null ? void 0 : w.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = j(this.git0, 25), this.git1 = j(this.git1, 25), this.git2 = j(this.git2, 25), this.git3 = j(this.git3, 25), this.git4 = j(this.git4, 25), this.git5 = j(this.git5, 25), this.git6 = j(this.git6, 25), this.git7 = j(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || N(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || N(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Wr, "Theme"), Wr), z0 = /* @__PURE__ */ d((e) => {
  const t = new N0();
  return t.calculate(e), t;
}, "getThemeVariables"), qr, W0 = (qr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = j(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = Yt(this.primaryColor, this.darkMode), this.secondaryBorderColor = Yt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Yt(this.tertiaryColor, this.darkMode), this.primaryTextColor = N(this.primaryColor), this.secondaryTextColor = N(this.secondaryColor), this.tertiaryTextColor = N(this.tertiaryColor), this.lineColor = N(this.background), this.textColor = N(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || j(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, c, l, h, u, f, p, g, m, y, x, b, _, k, w;
    this.secondBkg = j(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = j(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || N(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this.darkMode ? this["cScalePeer" + C] = this["cScalePeer" + C] || j(this["cScale" + C], 10) : this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = j(this.contrast, 30), this.sectionBkgColor2 = j(this.contrast, 30), this.taskBorderColor = J(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = j(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = J(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? j(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((c = this.xyChart) == null ? void 0 : c.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((l = this.xyChart) == null ? void 0 : l.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((y = this.radar) == null ? void 0 : y.curveStrokeWidth) || 2,
      graticuleColor: ((x = this.radar) == null ? void 0 : x.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((w = this.radar) == null ? void 0 : w.legendFontSize) || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = J(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || T(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || T(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || T(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || T(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || T(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || N(this.git0), this.gitInv1 = this.gitInv1 || N(this.git1), this.gitInv2 = this.gitInv2 || N(this.git2), this.gitInv3 = this.gitInv3 || N(this.git3), this.gitInv4 = this.gitInv4 || N(this.git4), this.gitInv5 = this.gitInv5 || N(this.git5), this.gitInv6 = this.gitInv6 || N(this.git6), this.gitInv7 = this.gitInv7 || N(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ca, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || _a;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(qr, "Theme"), qr), q0 = /* @__PURE__ */ d((e) => {
  const t = new W0();
  return t.calculate(e), t;
}, "getThemeVariables"), Re = {
  base: {
    getThemeVariables: O0
  },
  dark: {
    getThemeVariables: R0
  },
  default: {
    getThemeVariables: P0
  },
  forest: {
    getThemeVariables: z0
  },
  neutral: {
    getThemeVariables: q0
  }
}, ye = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Eh = {
  ...ye,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: Re.default.getThemeVariables(),
  sequence: {
    ...ye.sequence,
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...ye.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...ye.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...ye.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...ye.pie,
    useWidth: 984
  },
  xyChart: {
    ...ye.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...ye.requirement,
    useWidth: void 0
  },
  packet: {
    ...ye.packet
  },
  radar: {
    ...ye.radar
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  }
}, Fh = /* @__PURE__ */ d((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Fh(e[i], "")] : [...r, t + i], []), "keyify"), H0 = new Set(Fh(Eh, "")), Oh = Eh, In = /* @__PURE__ */ d((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => In(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !H0.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), In(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = j0(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r != null && r.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), j0 = /* @__PURE__ */ d((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), Ur = Object.freeze(Oh), Qt = Bt({}, Ur), Pn, fr = [], $i = Bt({}, Ur), wa = /* @__PURE__ */ d((e, t) => {
  let r = Bt({}, e), i = {};
  for (const n of t)
    Ih(n), i = Bt(i, n);
  if (r = Bt(r, i), i.theme && i.theme in Re) {
    const n = Bt({}, Pn), a = Bt(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in Re && (r.themeVariables = Re[r.theme].getThemeVariables(a));
  }
  return $i = r, Ph($i), $i;
}, "updateCurrentConfig"), Y0 = /* @__PURE__ */ d((e) => (Qt = Bt({}, Ur), Qt = Bt(Qt, e), e.theme && Re[e.theme] && (Qt.themeVariables = Re[e.theme].getThemeVariables(e.themeVariables)), wa(Qt, fr), Qt), "setSiteConfig"), U0 = /* @__PURE__ */ d((e) => {
  Pn = Bt({}, e);
}, "saveConfigFromInitialize"), G0 = /* @__PURE__ */ d((e) => (Qt = Bt(Qt, e), wa(Qt, fr), Qt), "updateSiteConfig"), Dh = /* @__PURE__ */ d(() => Bt({}, Qt), "getSiteConfig"), Rh = /* @__PURE__ */ d((e) => (Ph(e), Bt($i, e), Nt()), "setConfig"), Nt = /* @__PURE__ */ d(() => Bt({}, $i), "getConfig"), Ih = /* @__PURE__ */ d((e) => {
  e && (["secure", ...Qt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Ih(e[t]);
  }));
}, "sanitize"), X0 = /* @__PURE__ */ d((e) => {
  var t;
  In(e), e.fontFamily && !((t = e.themeVariables) != null && t.fontFamily) && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), fr.push(e), wa(Qt, fr);
}, "addDirective"), Nn = /* @__PURE__ */ d((e = Qt) => {
  fr = [], wa(e, fr);
}, "reset"), V0 = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, Kl = {}, Z0 = /* @__PURE__ */ d((e) => {
  Kl[e] || (F.warn(V0[e]), Kl[e] = !0);
}, "issueWarning"), Ph = /* @__PURE__ */ d((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Z0("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), XL = /* @__PURE__ */ d(() => {
  let e = {};
  Pn && (e = Bt(e, Pn));
  for (const t of fr)
    e = Bt(e, t);
  return e;
}, "getUserDefinedConfig"), Xi = /<br\s*\/?>/gi, K0 = /* @__PURE__ */ d((e) => e ? Wh(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), Q0 = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Nh(), e = !0);
  };
})();
function Nh() {
  const e = "data-temp-href-target";
  Yr.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), Yr.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
d(Nh, "setupDompurifyHooks");
var zh = /* @__PURE__ */ d((e) => (Q0(), Yr.sanitize(e)), "removeScript"), Ql = /* @__PURE__ */ d((e, t) => {
  var r;
  if (((r = t.flowchart) == null ? void 0 : r.htmlLabels) !== !1) {
    const i = t.securityLevel;
    i === "antiscript" || i === "strict" ? e = zh(e) : i !== "loose" && (e = Wh(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = ry(e));
  }
  return e;
}, "sanitizeMore"), se = /* @__PURE__ */ d((e, t) => e && (t.dompurifyConfig ? e = Yr.sanitize(Ql(e, t), t.dompurifyConfig).toString() : e = Yr.sanitize(Ql(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), J0 = /* @__PURE__ */ d((e, t) => typeof e == "string" ? se(e, t) : e.flat().map((r) => se(r, t)), "sanitizeTextOrArray"), ty = /* @__PURE__ */ d((e) => Xi.test(e), "hasBreaks"), ey = /* @__PURE__ */ d((e) => e.split(Xi), "splitBreaks"), ry = /* @__PURE__ */ d((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Wh = /* @__PURE__ */ d((e) => e.replace(Xi, "#br#"), "breakToPlaceholder"), iy = /* @__PURE__ */ d((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), At = /* @__PURE__ */ d((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), ny = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), ay = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), Jl = /* @__PURE__ */ d(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], o = t[i + 1];
      sy(a, o) && (n = a + "," + o, i++, r.pop());
    }
    r.push(oy(n));
  }
  return r.join("");
}, "parseGenericTypes"), Ts = /* @__PURE__ */ d((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), sy = /* @__PURE__ */ d((e, t) => {
  const r = Ts(e, "~"), i = Ts(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), oy = /* @__PURE__ */ d((e) => {
  const t = Ts(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), tc = /* @__PURE__ */ d(() => window.MathMLElement !== void 0, "isMathMLSupported"), Bs = /\$\$(.*)\$\$/g, Gr = /* @__PURE__ */ d((e) => {
  var t;
  return (((t = e.match(Bs)) == null ? void 0 : t.length) ?? 0) > 0;
}, "hasKatex"), VL = /* @__PURE__ */ d(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await ko(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0";
  const i = document.querySelector("body");
  i == null || i.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), ly = /* @__PURE__ */ d(async (e, t) => {
  if (!Gr(e))
    return e;
  if (!(tc() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(Bs, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./katex-DfcU2jCX.js"), i = t.forceLegacyMathML || !tc() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(Xi).map(
      (n) => Gr(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      Bs,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), ko = /* @__PURE__ */ d(async (e, t) => se(await ly(e, t), t), "renderKatexSanitized"), ti = {
  getRows: K0,
  sanitizeText: se,
  sanitizeTextOrArray: J0,
  hasBreaks: ty,
  splitBreaks: ey,
  lineBreakRegex: Xi,
  removeScript: zh,
  getUrl: iy,
  evaluate: At,
  getMax: ny,
  getMin: ay
}, cy = /* @__PURE__ */ d(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), hy = /* @__PURE__ */ d(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), qh = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = hy(t, r, i);
  cy(e, n);
}, "configureSvgSize"), uy = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, o = n.height;
  F.info(`SVG bounds: ${a}x${o}`, n);
  let s = 0, c = 0;
  F.info(`Graph bounds: ${s}x${c}`, e), s = a + r * 2, c = o + r * 2, F.info(`Calculated bounds: ${s}x${c}`), qh(t, c, s, i);
  const l = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", l);
}, "setupGraphViewbox"), Sn = {}, fy = /* @__PURE__ */ d((e, t, r) => {
  let i = "";
  return e in Sn && Sn[e] ? i = Sn[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), py = /* @__PURE__ */ d((e, t) => {
  t !== void 0 && (Sn[e] = t);
}, "addStylesForDiagram"), dy = fy, Hh = {};
r0(Hh, {
  clear: () => gy,
  getAccDescription: () => by,
  getAccTitle: () => yy,
  getDiagramTitle: () => _y,
  setAccDescription: () => xy,
  setAccTitle: () => my,
  setDiagramTitle: () => Cy
});
var vo = "", So = "", To = "", Bo = /* @__PURE__ */ d((e) => se(e, Nt()), "sanitizeText"), gy = /* @__PURE__ */ d(() => {
  vo = "", To = "", So = "";
}, "clear"), my = /* @__PURE__ */ d((e) => {
  vo = Bo(e).replace(/^\s+/g, "");
}, "setAccTitle"), yy = /* @__PURE__ */ d(() => vo, "getAccTitle"), xy = /* @__PURE__ */ d((e) => {
  To = Bo(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), by = /* @__PURE__ */ d(() => To, "getAccDescription"), Cy = /* @__PURE__ */ d((e) => {
  So = Bo(e);
}, "setDiagramTitle"), _y = /* @__PURE__ */ d(() => So, "getDiagramTitle"), ec = F, wy = _o, ft = Nt, ZL = Rh, KL = Ur, Lo = /* @__PURE__ */ d((e) => se(e, ft()), "sanitizeText"), ky = uy, vy = /* @__PURE__ */ d(() => Hh, "getCommonDb"), zn = {}, Wn = /* @__PURE__ */ d((e, t, r) => {
  var i;
  zn[e] && ec.warn(`Diagram with id ${e} already registered. Overwriting.`), zn[e] = t, r && $h(e, r), py(e, t.styles), (i = t.injectUtils) == null || i.call(
    t,
    ec,
    wy,
    ft,
    Lo,
    ky,
    vy(),
    () => {
    }
  );
}, "registerDiagram"), Ls = /* @__PURE__ */ d((e) => {
  if (e in zn)
    return zn[e];
  throw new Sy(e);
}, "getDiagram"), Hr, Sy = (Hr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, d(Hr, "DiagramNotFoundError"), Hr), Ty = { value: () => {
} };
function jh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Tn(r);
}
function Tn(e) {
  this._ = e;
}
function By(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Tn.prototype = jh.prototype = {
  constructor: Tn,
  on: function(e, t) {
    var r = this._, i = By(e + "", r), n, a = -1, o = i.length;
    if (arguments.length < 2) {
      for (; ++a < o; ) if ((n = (e = i[a]).type) && (n = Ly(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < o; )
      if (n = (e = i[a]).type) r[n] = rc(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = rc(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Tn(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function Ly(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function rc(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = Ty, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var As = "http://www.w3.org/1999/xhtml";
const ic = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: As,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function ka(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), ic.hasOwnProperty(t) ? { space: ic[t], local: e } : e;
}
function Ay(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === As && t.documentElement.namespaceURI === As ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function My(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function Yh(e) {
  var t = ka(e);
  return (t.local ? My : Ay)(t);
}
function $y() {
}
function Ao(e) {
  return e == null ? $y : function() {
    return this.querySelector(e);
  };
}
function Ey(e) {
  typeof e != "function" && (e = Ao(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = new Array(o), c, l, h = 0; h < o; ++h)
      (c = a[h]) && (l = e.call(c, c.__data__, h, a)) && ("__data__" in c && (l.__data__ = c.__data__), s[h] = l);
  return new ie(i, this._parents);
}
function Fy(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function Oy() {
  return [];
}
function Uh(e) {
  return e == null ? Oy : function() {
    return this.querySelectorAll(e);
  };
}
function Dy(e) {
  return function() {
    return Fy(e.apply(this, arguments));
  };
}
function Ry(e) {
  typeof e == "function" ? e = Dy(e) : e = Uh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var o = t[a], s = o.length, c, l = 0; l < s; ++l)
      (c = o[l]) && (i.push(e.call(c, c.__data__, l, o)), n.push(c));
  return new ie(i, n);
}
function Gh(e) {
  return function() {
    return this.matches(e);
  };
}
function Xh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var Iy = Array.prototype.find;
function Py(e) {
  return function() {
    return Iy.call(this.children, e);
  };
}
function Ny() {
  return this.firstElementChild;
}
function zy(e) {
  return this.select(e == null ? Ny : Py(typeof e == "function" ? e : Xh(e)));
}
var Wy = Array.prototype.filter;
function qy() {
  return Array.from(this.children);
}
function Hy(e) {
  return function() {
    return Wy.call(this.children, e);
  };
}
function jy(e) {
  return this.selectAll(e == null ? qy : Hy(typeof e == "function" ? e : Xh(e)));
}
function Yy(e) {
  typeof e != "function" && (e = Gh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], c, l = 0; l < o; ++l)
      (c = a[l]) && e.call(c, c.__data__, l, a) && s.push(c);
  return new ie(i, this._parents);
}
function Vh(e) {
  return new Array(e.length);
}
function Uy() {
  return new ie(this._enter || this._groups.map(Vh), this._parents);
}
function qn(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
qn.prototype = {
  constructor: qn,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Gy(e) {
  return function() {
    return e;
  };
}
function Xy(e, t, r, i, n, a) {
  for (var o = 0, s, c = t.length, l = a.length; o < l; ++o)
    (s = t[o]) ? (s.__data__ = a[o], i[o] = s) : r[o] = new qn(e, a[o]);
  for (; o < c; ++o)
    (s = t[o]) && (n[o] = s);
}
function Vy(e, t, r, i, n, a, o) {
  var s, c, l = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), p;
  for (s = 0; s < h; ++s)
    (c = t[s]) && (f[s] = p = o.call(c, c.__data__, s, t) + "", l.has(p) ? n[s] = c : l.set(p, c));
  for (s = 0; s < u; ++s)
    p = o.call(e, a[s], s, a) + "", (c = l.get(p)) ? (i[s] = c, c.__data__ = a[s], l.delete(p)) : r[s] = new qn(e, a[s]);
  for (s = 0; s < h; ++s)
    (c = t[s]) && l.get(f[s]) === c && (n[s] = c);
}
function Zy(e) {
  return e.__data__;
}
function Ky(e, t) {
  if (!arguments.length) return Array.from(this, Zy);
  var r = t ? Vy : Xy, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Gy(e));
  for (var a = n.length, o = new Array(a), s = new Array(a), c = new Array(a), l = 0; l < a; ++l) {
    var h = i[l], u = n[l], f = u.length, p = Qy(e.call(h, h && h.__data__, l, i)), g = p.length, m = s[l] = new Array(g), y = o[l] = new Array(g), x = c[l] = new Array(f);
    r(h, u, m, y, x, p, t);
    for (var b = 0, _ = 0, k, w; b < g; ++b)
      if (k = m[b]) {
        for (b >= _ && (_ = b + 1); !(w = y[_]) && ++_ < g; ) ;
        k._next = w || null;
      }
  }
  return o = new ie(o, i), o._enter = s, o._exit = c, o;
}
function Qy(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function Jy() {
  return new ie(this._exit || this._groups.map(Vh), this._parents);
}
function tx(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function ex(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, o = Math.min(n, a), s = new Array(n), c = 0; c < o; ++c)
    for (var l = r[c], h = i[c], u = l.length, f = s[c] = new Array(u), p, g = 0; g < u; ++g)
      (p = l[g] || h[g]) && (f[g] = p);
  for (; c < n; ++c)
    s[c] = r[c];
  return new ie(s, this._parents);
}
function rx() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], o; --n >= 0; )
      (o = i[n]) && (a && o.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(o, a), a = o);
  return this;
}
function ix(e) {
  e || (e = nx);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var o = r[a], s = o.length, c = n[a] = new Array(s), l, h = 0; h < s; ++h)
      (l = o[h]) && (c[h] = l);
    c.sort(t);
  }
  return new ie(n, this._parents).order();
}
function nx(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function ax() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function sx() {
  return Array.from(this);
}
function ox() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var o = i[n];
      if (o) return o;
    }
  return null;
}
function lx() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function cx() {
  return !this.node();
}
function hx(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, o = n.length, s; a < o; ++a)
      (s = n[a]) && e.call(s, s.__data__, a, n);
  return this;
}
function ux(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function fx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function px(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function dx(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function gx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function mx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function yx(e, t) {
  var r = ka(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? fx : ux : typeof t == "function" ? r.local ? mx : gx : r.local ? dx : px)(r, t));
}
function Zh(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function xx(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function bx(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function Cx(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function _x(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? xx : typeof t == "function" ? Cx : bx)(e, t, r ?? "")) : Xr(this.node(), e);
}
function Xr(e, t) {
  return e.style.getPropertyValue(t) || Zh(e).getComputedStyle(e, null).getPropertyValue(t);
}
function wx(e) {
  return function() {
    delete this[e];
  };
}
function kx(e, t) {
  return function() {
    this[e] = t;
  };
}
function vx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function Sx(e, t) {
  return arguments.length > 1 ? this.each((t == null ? wx : typeof t == "function" ? vx : kx)(e, t)) : this.node()[e];
}
function Kh(e) {
  return e.trim().split(/^|\s+/);
}
function Mo(e) {
  return e.classList || new Qh(e);
}
function Qh(e) {
  this._node = e, this._names = Kh(e.getAttribute("class") || "");
}
Qh.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function Jh(e, t) {
  for (var r = Mo(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function tu(e, t) {
  for (var r = Mo(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function Tx(e) {
  return function() {
    Jh(this, e);
  };
}
function Bx(e) {
  return function() {
    tu(this, e);
  };
}
function Lx(e, t) {
  return function() {
    (t.apply(this, arguments) ? Jh : tu)(this, e);
  };
}
function Ax(e, t) {
  var r = Kh(e + "");
  if (arguments.length < 2) {
    for (var i = Mo(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? Lx : t ? Tx : Bx)(r, t));
}
function Mx() {
  this.textContent = "";
}
function $x(e) {
  return function() {
    this.textContent = e;
  };
}
function Ex(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Fx(e) {
  return arguments.length ? this.each(e == null ? Mx : (typeof e == "function" ? Ex : $x)(e)) : this.node().textContent;
}
function Ox() {
  this.innerHTML = "";
}
function Dx(e) {
  return function() {
    this.innerHTML = e;
  };
}
function Rx(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function Ix(e) {
  return arguments.length ? this.each(e == null ? Ox : (typeof e == "function" ? Rx : Dx)(e)) : this.node().innerHTML;
}
function Px() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Nx() {
  return this.each(Px);
}
function zx() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Wx() {
  return this.each(zx);
}
function qx(e) {
  var t = typeof e == "function" ? e : Yh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Hx() {
  return null;
}
function jx(e, t) {
  var r = typeof e == "function" ? e : Yh(e), i = t == null ? Hx : typeof t == "function" ? t : Ao(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Yx() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Ux() {
  return this.each(Yx);
}
function Gx() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Xx() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Vx(e) {
  return this.select(e ? Xx : Gx);
}
function Zx(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Kx(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function Qx(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function Jx(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function tb(e, t, r) {
  return function() {
    var i = this.__on, n, a = Kx(t);
    if (i) {
      for (var o = 0, s = i.length; o < s; ++o)
        if ((n = i[o]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function eb(e, t, r) {
  var i = Qx(e + ""), n, a = i.length, o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var c = 0, l = s.length, h; c < l; ++c)
        for (n = 0, h = s[c]; n < a; ++n)
          if ((o = i[n]).type === h.type && o.name === h.name)
            return h.value;
    }
    return;
  }
  for (s = t ? tb : Jx, n = 0; n < a; ++n) this.each(s(i[n], t, r));
  return this;
}
function eu(e, t, r) {
  var i = Zh(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function rb(e, t) {
  return function() {
    return eu(this, e, t);
  };
}
function ib(e, t) {
  return function() {
    return eu(this, e, t.apply(this, arguments));
  };
}
function nb(e, t) {
  return this.each((typeof t == "function" ? ib : rb)(e, t));
}
function* ab() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, o; n < a; ++n)
      (o = i[n]) && (yield o);
}
var ru = [null];
function ie(e, t) {
  this._groups = e, this._parents = t;
}
function Vi() {
  return new ie([[document.documentElement]], ru);
}
function sb() {
  return this;
}
ie.prototype = Vi.prototype = {
  constructor: ie,
  select: Ey,
  selectAll: Ry,
  selectChild: zy,
  selectChildren: jy,
  filter: Yy,
  data: Ky,
  enter: Uy,
  exit: Jy,
  join: tx,
  merge: ex,
  selection: sb,
  order: rx,
  sort: ix,
  call: ax,
  nodes: sx,
  node: ox,
  size: lx,
  empty: cx,
  each: hx,
  attr: yx,
  style: _x,
  property: Sx,
  classed: Ax,
  text: Fx,
  html: Ix,
  raise: Nx,
  lower: Wx,
  append: qx,
  insert: jx,
  remove: Ux,
  clone: Vx,
  datum: Zx,
  on: eb,
  dispatch: nb,
  [Symbol.iterator]: ab
};
function ht(e) {
  return typeof e == "string" ? new ie([[document.querySelector(e)]], [document.documentElement]) : new ie([[e]], ru);
}
function $o(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function iu(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function Zi() {
}
var Oi = 0.7, Hn = 1 / Oi, Dr = "\\s*([+-]?\\d+)\\s*", Di = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", _e = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", ob = /^#([0-9a-f]{3,8})$/, lb = new RegExp(`^rgb\\(${Dr},${Dr},${Dr}\\)$`), cb = new RegExp(`^rgb\\(${_e},${_e},${_e}\\)$`), hb = new RegExp(`^rgba\\(${Dr},${Dr},${Dr},${Di}\\)$`), ub = new RegExp(`^rgba\\(${_e},${_e},${_e},${Di}\\)$`), fb = new RegExp(`^hsl\\(${Di},${_e},${_e}\\)$`), pb = new RegExp(`^hsla\\(${Di},${_e},${_e},${Di}\\)$`), nc = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
$o(Zi, Ri, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: ac,
  // Deprecated! Use color.formatHex.
  formatHex: ac,
  formatHex8: db,
  formatHsl: gb,
  formatRgb: sc,
  toString: sc
});
function ac() {
  return this.rgb().formatHex();
}
function db() {
  return this.rgb().formatHex8();
}
function gb() {
  return nu(this).formatHsl();
}
function sc() {
  return this.rgb().formatRgb();
}
function Ri(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = ob.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? oc(t) : r === 3 ? new te(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? fn(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? fn(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = lb.exec(e)) ? new te(t[1], t[2], t[3], 1) : (t = cb.exec(e)) ? new te(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = hb.exec(e)) ? fn(t[1], t[2], t[3], t[4]) : (t = ub.exec(e)) ? fn(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = fb.exec(e)) ? hc(t[1], t[2] / 100, t[3] / 100, 1) : (t = pb.exec(e)) ? hc(t[1], t[2] / 100, t[3] / 100, t[4]) : nc.hasOwnProperty(e) ? oc(nc[e]) : e === "transparent" ? new te(NaN, NaN, NaN, 0) : null;
}
function oc(e) {
  return new te(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function fn(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new te(e, t, r, i);
}
function mb(e) {
  return e instanceof Zi || (e = Ri(e)), e ? (e = e.rgb(), new te(e.r, e.g, e.b, e.opacity)) : new te();
}
function Ms(e, t, r, i) {
  return arguments.length === 1 ? mb(e) : new te(e, t, r, i ?? 1);
}
function te(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
$o(te, Ms, iu(Zi, {
  brighter(e) {
    return e = e == null ? Hn : Math.pow(Hn, e), new te(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Oi : Math.pow(Oi, e), new te(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new te(cr(this.r), cr(this.g), cr(this.b), jn(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: lc,
  // Deprecated! Use color.formatHex.
  formatHex: lc,
  formatHex8: yb,
  formatRgb: cc,
  toString: cc
}));
function lc() {
  return `#${ar(this.r)}${ar(this.g)}${ar(this.b)}`;
}
function yb() {
  return `#${ar(this.r)}${ar(this.g)}${ar(this.b)}${ar((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function cc() {
  const e = jn(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${cr(this.r)}, ${cr(this.g)}, ${cr(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function jn(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function cr(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function ar(e) {
  return e = cr(e), (e < 16 ? "0" : "") + e.toString(16);
}
function hc(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new he(e, t, r, i);
}
function nu(e) {
  if (e instanceof he) return new he(e.h, e.s, e.l, e.opacity);
  if (e instanceof Zi || (e = Ri(e)), !e) return new he();
  if (e instanceof he) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), o = NaN, s = a - n, c = (a + n) / 2;
  return s ? (t === a ? o = (r - i) / s + (r < i) * 6 : r === a ? o = (i - t) / s + 2 : o = (t - r) / s + 4, s /= c < 0.5 ? a + n : 2 - a - n, o *= 60) : s = c > 0 && c < 1 ? 0 : o, new he(o, s, c, e.opacity);
}
function xb(e, t, r, i) {
  return arguments.length === 1 ? nu(e) : new he(e, t, r, i ?? 1);
}
function he(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
$o(he, xb, iu(Zi, {
  brighter(e) {
    return e = e == null ? Hn : Math.pow(Hn, e), new he(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Oi : Math.pow(Oi, e), new he(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new te(
      os(e >= 240 ? e - 240 : e + 120, n, i),
      os(e, n, i),
      os(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new he(uc(this.h), pn(this.s), pn(this.l), jn(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = jn(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${uc(this.h)}, ${pn(this.s) * 100}%, ${pn(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function uc(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function pn(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function os(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Eo = (e) => () => e;
function au(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function bb(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function QL(e, t) {
  var r = t - e;
  return r ? au(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Eo(isNaN(e) ? t : e);
}
function Cb(e) {
  return (e = +e) == 1 ? su : function(t, r) {
    return r - t ? bb(t, r, e) : Eo(isNaN(t) ? r : t);
  };
}
function su(e, t) {
  var r = t - e;
  return r ? au(e, r) : Eo(isNaN(e) ? t : e);
}
const fc = function e(t) {
  var r = Cb(t);
  function i(n, a) {
    var o = r((n = Ms(n)).r, (a = Ms(a)).r), s = r(n.g, a.g), c = r(n.b, a.b), l = su(n.opacity, a.opacity);
    return function(h) {
      return n.r = o(h), n.g = s(h), n.b = c(h), n.opacity = l(h), n + "";
    };
  }
  return i.gamma = e, i;
}(1);
function qe(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var $s = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, ls = new RegExp($s.source, "g");
function _b(e) {
  return function() {
    return e;
  };
}
function wb(e) {
  return function(t) {
    return e(t) + "";
  };
}
function kb(e, t) {
  var r = $s.lastIndex = ls.lastIndex = 0, i, n, a, o = -1, s = [], c = [];
  for (e = e + "", t = t + ""; (i = $s.exec(e)) && (n = ls.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), s[o] ? s[o] += a : s[++o] = a), (i = i[0]) === (n = n[0]) ? s[o] ? s[o] += n : s[++o] = n : (s[++o] = null, c.push({ i: o, x: qe(i, n) })), r = ls.lastIndex;
  return r < t.length && (a = t.slice(r), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? c[0] ? wb(c[0].x) : _b(t) : (t = c.length, function(l) {
    for (var h = 0, u; h < t; ++h) s[(u = c[h]).i] = u.x(l);
    return s.join("");
  });
}
var pc = 180 / Math.PI, Es = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function ou(e, t, r, i, n, a) {
  var o, s, c;
  return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (c = e * r + t * i) && (r -= e * c, i -= t * c), (s = Math.sqrt(r * r + i * i)) && (r /= s, i /= s, c /= s), e * i < t * r && (e = -e, t = -t, c = -c, o = -o), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * pc,
    skewX: Math.atan(c) * pc,
    scaleX: o,
    scaleY: s
  };
}
var dn;
function vb(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Es : ou(t.a, t.b, t.c, t.d, t.e, t.f);
}
function Sb(e) {
  return e == null || (dn || (dn = document.createElementNS("http://www.w3.org/2000/svg", "g")), dn.setAttribute("transform", e), !(e = dn.transform.baseVal.consolidate())) ? Es : (e = e.matrix, ou(e.a, e.b, e.c, e.d, e.e, e.f));
}
function lu(e, t, r, i) {
  function n(l) {
    return l.length ? l.pop() + " " : "";
  }
  function a(l, h, u, f, p, g) {
    if (l !== u || h !== f) {
      var m = p.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: qe(l, u) }, { i: m - 2, x: qe(h, f) });
    } else (u || f) && p.push("translate(" + u + t + f + r);
  }
  function o(l, h, u, f) {
    l !== h ? (l - h > 180 ? h += 360 : h - l > 180 && (l += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: qe(l, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function s(l, h, u, f) {
    l !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: qe(l, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function c(l, h, u, f, p, g) {
    if (l !== u || h !== f) {
      var m = p.push(n(p) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: qe(l, u) }, { i: m - 2, x: qe(h, f) });
    } else (u !== 1 || f !== 1) && p.push(n(p) + "scale(" + u + "," + f + ")");
  }
  return function(l, h) {
    var u = [], f = [];
    return l = e(l), h = e(h), a(l.translateX, l.translateY, h.translateX, h.translateY, u, f), o(l.rotate, h.rotate, u, f), s(l.skewX, h.skewX, u, f), c(l.scaleX, l.scaleY, h.scaleX, h.scaleY, u, f), l = h = null, function(p) {
      for (var g = -1, m = f.length, y; ++g < m; ) u[(y = f[g]).i] = y.x(p);
      return u.join("");
    };
  };
}
var Tb = lu(vb, "px, ", "px)", "deg)"), Bb = lu(Sb, ", ", ")", ")"), Vr = 0, Ci = 0, pi = 0, cu = 1e3, Yn, _i, Un = 0, pr = 0, va = 0, Ii = typeof performance == "object" && performance.now ? performance : Date, hu = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function Fo() {
  return pr || (hu(Lb), pr = Ii.now() + va);
}
function Lb() {
  pr = 0;
}
function Gn() {
  this._call = this._time = this._next = null;
}
Gn.prototype = uu.prototype = {
  constructor: Gn,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? Fo() : +r) + (t == null ? 0 : +t), !this._next && _i !== this && (_i ? _i._next = this : Yn = this, _i = this), this._call = e, this._time = r, Fs();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Fs());
  }
};
function uu(e, t, r) {
  var i = new Gn();
  return i.restart(e, t, r), i;
}
function Ab() {
  Fo(), ++Vr;
  for (var e = Yn, t; e; )
    (t = pr - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --Vr;
}
function dc() {
  pr = (Un = Ii.now()) + va, Vr = Ci = 0;
  try {
    Ab();
  } finally {
    Vr = 0, $b(), pr = 0;
  }
}
function Mb() {
  var e = Ii.now(), t = e - Un;
  t > cu && (va -= t, Un = e);
}
function $b() {
  for (var e, t = Yn, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : Yn = r);
  _i = e, Fs(i);
}
function Fs(e) {
  if (!Vr) {
    Ci && (Ci = clearTimeout(Ci));
    var t = e - pr;
    t > 24 ? (e < 1 / 0 && (Ci = setTimeout(dc, e - Ii.now() - va)), pi && (pi = clearInterval(pi))) : (pi || (Un = Ii.now(), pi = setInterval(Mb, cu)), Vr = 1, hu(dc));
  }
}
function gc(e, t, r) {
  var i = new Gn();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var Eb = jh("start", "end", "cancel", "interrupt"), Fb = [], fu = 0, mc = 1, Os = 2, Bn = 3, yc = 4, Ds = 5, Ln = 6;
function Sa(e, t, r, i, n, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (r in o) return;
  Ob(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: Eb,
    tween: Fb,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: fu
  });
}
function Oo(e, t) {
  var r = de(e, t);
  if (r.state > fu) throw new Error("too late; already scheduled");
  return r;
}
function ve(e, t) {
  var r = de(e, t);
  if (r.state > Bn) throw new Error("too late; already running");
  return r;
}
function de(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function Ob(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = uu(a, 0, r.time);
  function a(l) {
    r.state = mc, r.timer.restart(o, r.delay, r.time), r.delay <= l && o(l - r.delay);
  }
  function o(l) {
    var h, u, f, p;
    if (r.state !== mc) return c();
    for (h in i)
      if (p = i[h], p.name === r.name) {
        if (p.state === Bn) return gc(o);
        p.state === yc ? (p.state = Ln, p.timer.stop(), p.on.call("interrupt", e, e.__data__, p.index, p.group), delete i[h]) : +h < t && (p.state = Ln, p.timer.stop(), p.on.call("cancel", e, e.__data__, p.index, p.group), delete i[h]);
      }
    if (gc(function() {
      r.state === Bn && (r.state = yc, r.timer.restart(s, r.delay, r.time), s(l));
    }), r.state = Os, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Os) {
      for (r.state = Bn, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (p = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = p);
      n.length = u + 1;
    }
  }
  function s(l) {
    for (var h = l < r.duration ? r.ease.call(null, l / r.duration) : (r.timer.restart(c), r.state = Ds, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === Ds && (r.on.call("end", e, e.__data__, r.index, r.group), c());
  }
  function c() {
    r.state = Ln, r.timer.stop(), delete i[t];
    for (var l in i) return;
    delete e.__transition;
  }
}
function Db(e, t) {
  var r = e.__transition, i, n, a = !0, o;
  if (r) {
    t = t == null ? null : t + "";
    for (o in r) {
      if ((i = r[o]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Os && i.state < Ds, i.state = Ln, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[o];
    }
    a && delete e.__transition;
  }
}
function Rb(e) {
  return this.each(function() {
    Db(this, e);
  });
}
function Ib(e, t) {
  var r, i;
  return function() {
    var n = ve(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var o = 0, s = i.length; o < s; ++o)
        if (i[o].name === t) {
          i = i.slice(), i.splice(o, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function Pb(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ve(this, e), o = a.tween;
    if (o !== i) {
      n = (i = o).slice();
      for (var s = { name: t, value: r }, c = 0, l = n.length; c < l; ++c)
        if (n[c].name === t) {
          n[c] = s;
          break;
        }
      c === l && n.push(s);
    }
    a.tween = n;
  };
}
function Nb(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = de(this.node(), r).tween, n = 0, a = i.length, o; n < a; ++n)
      if ((o = i[n]).name === e)
        return o.value;
    return null;
  }
  return this.each((t == null ? Ib : Pb)(r, e, t));
}
function Do(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ve(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return de(n, i).value[t];
  };
}
function pu(e, t) {
  var r;
  return (typeof t == "number" ? qe : t instanceof Ri ? fc : (r = Ri(t)) ? (t = r, fc) : kb)(e, t);
}
function zb(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Wb(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function qb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttribute(e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Hb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttributeNS(e.space, e.local);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function jb(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), c;
    return s == null ? void this.removeAttribute(e) : (o = this.getAttribute(e), c = s + "", o === c ? null : o === i && c === n ? a : (n = c, a = t(i = o, s)));
  };
}
function Yb(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), c;
    return s == null ? void this.removeAttributeNS(e.space, e.local) : (o = this.getAttributeNS(e.space, e.local), c = s + "", o === c ? null : o === i && c === n ? a : (n = c, a = t(i = o, s)));
  };
}
function Ub(e, t) {
  var r = ka(e), i = r === "transform" ? Bb : pu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Yb : jb)(r, i, Do(this, "attr." + e, t)) : t == null ? (r.local ? Wb : zb)(r) : (r.local ? Hb : qb)(r, i, t));
}
function Gb(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Xb(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Vb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Xb(e, a)), r;
  }
  return n._value = t, n;
}
function Zb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Gb(e, a)), r;
  }
  return n._value = t, n;
}
function Kb(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = ka(e);
  return this.tween(r, (i.local ? Vb : Zb)(i, t));
}
function Qb(e, t) {
  return function() {
    Oo(this, e).delay = +t.apply(this, arguments);
  };
}
function Jb(e, t) {
  return t = +t, function() {
    Oo(this, e).delay = t;
  };
}
function t1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Qb : Jb)(t, e)) : de(this.node(), t).delay;
}
function e1(e, t) {
  return function() {
    ve(this, e).duration = +t.apply(this, arguments);
  };
}
function r1(e, t) {
  return t = +t, function() {
    ve(this, e).duration = t;
  };
}
function i1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? e1 : r1)(t, e)) : de(this.node(), t).duration;
}
function n1(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ve(this, e).ease = t;
  };
}
function a1(e) {
  var t = this._id;
  return arguments.length ? this.each(n1(t, e)) : de(this.node(), t).ease;
}
function s1(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ve(this, e).ease = r;
  };
}
function o1(e) {
  if (typeof e != "function") throw new Error();
  return this.each(s1(this._id, e));
}
function l1(e) {
  typeof e != "function" && (e = Gh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], c, l = 0; l < o; ++l)
      (c = a[l]) && e.call(c, c.__data__, l, a) && s.push(c);
  return new Pe(i, this._parents, this._name, this._id);
}
function c1(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), o = new Array(i), s = 0; s < a; ++s)
    for (var c = t[s], l = r[s], h = c.length, u = o[s] = new Array(h), f, p = 0; p < h; ++p)
      (f = c[p] || l[p]) && (u[p] = f);
  for (; s < i; ++s)
    o[s] = t[s];
  return new Pe(o, this._parents, this._name, this._id);
}
function h1(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function u1(e, t, r) {
  var i, n, a = h1(t) ? Oo : ve;
  return function() {
    var o = a(this, e), s = o.on;
    s !== i && (n = (i = s).copy()).on(t, r), o.on = n;
  };
}
function f1(e, t) {
  var r = this._id;
  return arguments.length < 2 ? de(this.node(), r).on.on(e) : this.each(u1(r, e, t));
}
function p1(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function d1() {
  return this.on("end.remove", p1(this._id));
}
function g1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Ao(e));
  for (var i = this._groups, n = i.length, a = new Array(n), o = 0; o < n; ++o)
    for (var s = i[o], c = s.length, l = a[o] = new Array(c), h, u, f = 0; f < c; ++f)
      (h = s[f]) && (u = e.call(h, h.__data__, f, s)) && ("__data__" in h && (u.__data__ = h.__data__), l[f] = u, Sa(l[f], t, r, f, l, de(h, r)));
  return new Pe(a, this._parents, t, r);
}
function m1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Uh(e));
  for (var i = this._groups, n = i.length, a = [], o = [], s = 0; s < n; ++s)
    for (var c = i[s], l = c.length, h, u = 0; u < l; ++u)
      if (h = c[u]) {
        for (var f = e.call(h, h.__data__, u, c), p, g = de(h, r), m = 0, y = f.length; m < y; ++m)
          (p = f[m]) && Sa(p, t, r, m, f, g);
        a.push(f), o.push(h);
      }
  return new Pe(a, o, t, r);
}
var y1 = Vi.prototype.constructor;
function x1() {
  return new y1(this._groups, this._parents);
}
function b1(e, t) {
  var r, i, n;
  return function() {
    var a = Xr(this, e), o = (this.style.removeProperty(e), Xr(this, e));
    return a === o ? null : a === r && o === i ? n : n = t(r = a, i = o);
  };
}
function du(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function C1(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = Xr(this, e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function _1(e, t, r) {
  var i, n, a;
  return function() {
    var o = Xr(this, e), s = r(this), c = s + "";
    return s == null && (c = s = (this.style.removeProperty(e), Xr(this, e))), o === c ? null : o === i && c === n ? a : (n = c, a = t(i = o, s));
  };
}
function w1(e, t) {
  var r, i, n, a = "style." + t, o = "end." + a, s;
  return function() {
    var c = ve(this, e), l = c.on, h = c.value[a] == null ? s || (s = du(t)) : void 0;
    (l !== r || n !== h) && (i = (r = l).copy()).on(o, n = h), c.on = i;
  };
}
function k1(e, t, r) {
  var i = (e += "") == "transform" ? Tb : pu;
  return t == null ? this.styleTween(e, b1(e, i)).on("end.style." + e, du(e)) : typeof t == "function" ? this.styleTween(e, _1(e, i, Do(this, "style." + e, t))).each(w1(this._id, e)) : this.styleTween(e, C1(e, i, t), r).on("end.style." + e, null);
}
function v1(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function S1(e, t, r) {
  var i, n;
  function a() {
    var o = t.apply(this, arguments);
    return o !== n && (i = (n = o) && v1(e, o, r)), i;
  }
  return a._value = t, a;
}
function T1(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, S1(e, t, r ?? ""));
}
function B1(e) {
  return function() {
    this.textContent = e;
  };
}
function L1(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function A1(e) {
  return this.tween("text", typeof e == "function" ? L1(Do(this, "text", e)) : B1(e == null ? "" : e + ""));
}
function M1(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function $1(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && M1(n)), t;
  }
  return i._value = e, i;
}
function E1(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, $1(e));
}
function F1() {
  for (var e = this._name, t = this._id, r = gu(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, c, l = 0; l < s; ++l)
      if (c = o[l]) {
        var h = de(c, t);
        Sa(c, e, r, l, o, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new Pe(i, this._parents, e, r);
}
function O1() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, o) {
    var s = { value: o }, c = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var l = ve(this, i), h = l.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(s), t._.interrupt.push(s), t._.end.push(c)), l.on = t;
    }), n === 0 && a();
  });
}
var D1 = 0;
function Pe(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function gu() {
  return ++D1;
}
var Me = Vi.prototype;
Pe.prototype = {
  constructor: Pe,
  select: g1,
  selectAll: m1,
  selectChild: Me.selectChild,
  selectChildren: Me.selectChildren,
  filter: l1,
  merge: c1,
  selection: x1,
  transition: F1,
  call: Me.call,
  nodes: Me.nodes,
  node: Me.node,
  size: Me.size,
  empty: Me.empty,
  each: Me.each,
  on: f1,
  attr: Ub,
  attrTween: Kb,
  style: k1,
  styleTween: T1,
  text: A1,
  textTween: E1,
  remove: d1,
  tween: Nb,
  delay: t1,
  duration: i1,
  ease: a1,
  easeVarying: o1,
  end: O1,
  [Symbol.iterator]: Me[Symbol.iterator]
};
function R1(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var I1 = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: R1
};
function P1(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function N1(e) {
  var t, r;
  e instanceof Pe ? (t = e._id, e = e._name) : (t = gu(), (r = I1).time = Fo(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, c, l = 0; l < s; ++l)
      (c = o[l]) && Sa(c, e, t, l, o, r || P1(c, t));
  return new Pe(i, this._parents, e, t);
}
Vi.prototype.interrupt = Rb;
Vi.prototype.transition = N1;
const Rs = Math.PI, Is = 2 * Rs, er = 1e-6, z1 = Is - er;
function mu(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function W1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return mu;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class q1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? mu : W1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, o) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, s = this._y1, c = i - t, l = n - r, h = o - t, u = s - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > er) if (!(Math.abs(u * c - l * h) > er) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = i - o, g = n - s, m = c * c + l * l, y = p * p + g * g, x = Math.sqrt(m), b = Math.sqrt(f), _ = a * Math.tan((Rs - Math.acos((m + f - y) / (2 * x * b))) / 2), k = _ / b, w = _ / x;
      Math.abs(k - 1) > er && this._append`L${t + k * h},${r + k * u}`, this._append`A${a},${a},0,0,${+(u * p > h * g)},${this._x1 = t + w * c},${this._y1 = r + w * l}`;
    }
  }
  arc(t, r, i, n, a, o) {
    if (t = +t, r = +r, i = +i, o = !!o, i < 0) throw new Error(`negative radius: ${i}`);
    let s = i * Math.cos(n), c = i * Math.sin(n), l = t + s, h = r + c, u = 1 ^ o, f = o ? n - a : a - n;
    this._x1 === null ? this._append`M${l},${h}` : (Math.abs(this._x1 - l) > er || Math.abs(this._y1 - h) > er) && this._append`L${l},${h}`, i && (f < 0 && (f = f % Is + Is), f > z1 ? this._append`A${i},${i},0,1,${u},${t - s},${r - c}A${i},${i},0,1,${u},${this._x1 = l},${this._y1 = h}` : f > er && this._append`A${i},${i},0,${+(f >= Rs)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Ar(e) {
  return function() {
    return e;
  };
}
const JL = Math.abs, tA = Math.atan2, eA = Math.cos, rA = Math.max, iA = Math.min, nA = Math.sin, aA = Math.sqrt, xc = 1e-12, Ro = Math.PI, bc = Ro / 2, sA = 2 * Ro;
function oA(e) {
  return e > 1 ? 0 : e < -1 ? Ro : Math.acos(e);
}
function lA(e) {
  return e >= 1 ? bc : e <= -1 ? -bc : Math.asin(e);
}
function H1(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new q1(t);
}
function j1(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function yu(e) {
  this._context = e;
}
yu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Xn(e) {
  return new yu(e);
}
function Y1(e) {
  return e[0];
}
function U1(e) {
  return e[1];
}
function G1(e, t) {
  var r = Ar(!0), i = null, n = Xn, a = null, o = H1(s);
  e = typeof e == "function" ? e : e === void 0 ? Y1 : Ar(e), t = typeof t == "function" ? t : t === void 0 ? U1 : Ar(t);
  function s(c) {
    var l, h = (c = j1(c)).length, u, f = !1, p;
    for (i == null && (a = n(p = o())), l = 0; l <= h; ++l)
      !(l < h && r(u = c[l], l, c)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, l, c), +t(u, l, c));
    if (p) return a = null, p + "" || null;
  }
  return s.x = function(c) {
    return arguments.length ? (e = typeof c == "function" ? c : Ar(+c), s) : e;
  }, s.y = function(c) {
    return arguments.length ? (t = typeof c == "function" ? c : Ar(+c), s) : t;
  }, s.defined = function(c) {
    return arguments.length ? (r = typeof c == "function" ? c : Ar(!!c), s) : r;
  }, s.curve = function(c) {
    return arguments.length ? (n = c, i != null && (a = n(i)), s) : n;
  }, s.context = function(c) {
    return arguments.length ? (c == null ? i = a = null : a = n(i = c), s) : i;
  }, s;
}
class xu {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function bu(e) {
  return new xu(e, !0);
}
function Cu(e) {
  return new xu(e, !1);
}
function Ye() {
}
function Vn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Ta(e) {
  this._context = e;
}
Ta.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Vn(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function An(e) {
  return new Ta(e);
}
function _u(e) {
  this._context = e;
}
_u.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function X1(e) {
  return new _u(e);
}
function wu(e) {
  this._context = e;
}
wu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function V1(e) {
  return new wu(e);
}
function ku(e, t) {
  this._basis = new Ta(e), this._beta = t;
}
ku.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, o = t[r] - n, s = -1, c; ++s <= r; )
        c = s / r, this._basis.point(
          this._beta * e[s] + (1 - this._beta) * (i + c * a),
          this._beta * t[s] + (1 - this._beta) * (n + c * o)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const Z1 = function e(t) {
  function r(i) {
    return t === 1 ? new Ta(i) : new ku(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
}(0.85);
function Zn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function Io(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Io.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        Zn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const vu = function e(t) {
  function r(i) {
    return new Io(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Po(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Po.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const K1 = function e(t) {
  function r(i) {
    return new Po(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function No(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
No.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        Zn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Q1 = function e(t) {
  function r(i) {
    return new No(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function zo(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, o = e._y2;
  if (e._l01_a > xc) {
    var s = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, c = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * s - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / c, n = (n * s - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / c;
  }
  if (e._l23_a > xc) {
    var l = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * l + e._x1 * e._l23_2a - t * e._l12_2a) / h, o = (o * l + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, o, e._x2, e._y2);
}
function Su(e, t) {
  this._context = e, this._alpha = t;
}
Su.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      default:
        zo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Tu = function e(t) {
  function r(i) {
    return t ? new Su(i, t) : new Io(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Bu(e, t) {
  this._context = e, this._alpha = t;
}
Bu.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        zo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const J1 = function e(t) {
  function r(i) {
    return t ? new Bu(i, t) : new Po(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Lu(e, t) {
  this._context = e, this._alpha = t;
}
Lu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        zo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const t2 = function e(t) {
  function r(i) {
    return t ? new Lu(i, t) : new No(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Au(e) {
  this._context = e;
}
Au.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function e2(e) {
  return new Au(e);
}
function Cc(e) {
  return e < 0 ? -1 : 1;
}
function _c(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), o = (r - e._y1) / (n || i < 0 && -0), s = (a * n + o * i) / (i + n);
  return (Cc(a) + Cc(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(s)) || 0;
}
function wc(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function cs(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, o = e._y1, s = (a - i) / 3;
  e._context.bezierCurveTo(i + s, n + s * t, a - s, o - s * r, a, o);
}
function Kn(e) {
  this._context = e;
}
Kn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        cs(this, this._t0, wc(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, cs(this, wc(this, r = _c(this, e, t)), r);
          break;
        default:
          cs(this, this._t0, r = _c(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Mu(e) {
  this._context = new $u(e);
}
(Mu.prototype = Object.create(Kn.prototype)).point = function(e, t) {
  Kn.prototype.point.call(this, t, e);
};
function $u(e) {
  this._context = e;
}
$u.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Eu(e) {
  return new Kn(e);
}
function Fu(e) {
  return new Mu(e);
}
function Ou(e) {
  this._context = e;
}
Ou.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = kc(e), n = kc(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function kc(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), o = new Array(r);
  for (n[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, o[t] -= i * o[t - 1];
  for (n[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (o[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Du(e) {
  return new Ou(e);
}
function Ba(e, t) {
  this._context = e, this._t = t;
}
Ba.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Ru(e) {
  return new Ba(e, 0.5);
}
function Iu(e) {
  return new Ba(e, 0);
}
function Pu(e) {
  return new Ba(e, 1);
}
function wi(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
wi.prototype = {
  constructor: wi,
  scale: function(e) {
    return e === 1 ? this : new wi(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new wi(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
wi.prototype;
var r2 = /* @__PURE__ */ d((e) => {
  var n;
  const { securityLevel: t } = ft();
  let r = ht("body");
  if (t === "sandbox") {
    const o = ((n = ht(`#i${e}`).node()) == null ? void 0 : n.contentDocument) ?? document;
    r = ht(o.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function Wo(e) {
  return typeof e > "u" || e === null;
}
d(Wo, "isNothing");
function Nu(e) {
  return typeof e == "object" && e !== null;
}
d(Nu, "isObject");
function zu(e) {
  return Array.isArray(e) ? e : Wo(e) ? [] : [e];
}
d(zu, "toArray");
function Wu(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
d(Wu, "extend");
function qu(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
d(qu, "repeat");
function Hu(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
d(Hu, "isNegativeZero");
var i2 = Wo, n2 = Nu, a2 = zu, s2 = qu, o2 = Hu, l2 = Wu, Lt = {
  isNothing: i2,
  isObject: n2,
  toArray: a2,
  repeat: s2,
  isNegativeZero: o2,
  extend: l2
};
function qo(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
d(qo, "formatError");
function Zr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = qo(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
d(Zr, "YAMLException$1");
Zr.prototype = Object.create(Error.prototype);
Zr.prototype.constructor = Zr;
Zr.prototype.toString = /* @__PURE__ */ d(function(t) {
  return this.name + ": " + qo(this, t);
}, "toString");
var Jt = Zr;
function Mn(e, t, r, i, n) {
  var a = "", o = "", s = Math.floor(n / 2) - 1;
  return i - t > s && (a = " ... ", t = i - s + a.length), r - i > s && (o = " ...", r = i + s - o.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + o,
    pos: i - t + a.length
    // relative position
  };
}
d(Mn, "getLine");
function $n(e, t) {
  return Lt.repeat(" ", t - e.length) + e;
}
d($n, "padStart");
function ju(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, o = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && o < 0 && (o = i.length - 2);
  o < 0 && (o = i.length - 1);
  var s = "", c, l, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (c = 1; c <= t.linesBefore && !(o - c < 0); c++)
    l = Mn(
      e.buffer,
      i[o - c],
      n[o - c],
      e.position - (i[o] - i[o - c]),
      u
    ), s = Lt.repeat(" ", t.indent) + $n((e.line - c + 1).toString(), h) + " | " + l.str + `
` + s;
  for (l = Mn(e.buffer, i[o], n[o], e.position, u), s += Lt.repeat(" ", t.indent) + $n((e.line + 1).toString(), h) + " | " + l.str + `
`, s += Lt.repeat("-", t.indent + h + 3 + l.pos) + `^
`, c = 1; c <= t.linesAfter && !(o + c >= n.length); c++)
    l = Mn(
      e.buffer,
      i[o + c],
      n[o + c],
      e.position - (i[o] - i[o + c]),
      u
    ), s += Lt.repeat(" ", t.indent) + $n((e.line + c + 1).toString(), h) + " | " + l.str + `
`;
  return s.replace(/\n$/, "");
}
d(ju, "makeSnippet");
var c2 = ju, h2 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], u2 = [
  "scalar",
  "sequence",
  "mapping"
];
function Yu(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
d(Yu, "compileStyleAliases");
function Uu(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (h2.indexOf(r) === -1)
      throw new Jt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = Yu(t.styleAliases || null), u2.indexOf(this.kind) === -1)
    throw new Jt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
d(Uu, "Type$1");
var zt = Uu;
function Ps(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, o) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = o);
    }), r[n] = i;
  }), r;
}
d(Ps, "compileList");
function Gu() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (d(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
d(Gu, "compileMap");
function Qn(e) {
  return this.extend(e);
}
d(Qn, "Schema$1");
Qn.prototype.extend = /* @__PURE__ */ d(function(t) {
  var r = [], i = [];
  if (t instanceof zt)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Jt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof zt))
      throw new Jt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Jt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Jt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof zt))
      throw new Jt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(Qn.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = Ps(n, "implicit"), n.compiledExplicit = Ps(n, "explicit"), n.compiledTypeMap = Gu(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var f2 = Qn, p2 = new zt("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), d2 = new zt("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), g2 = new zt("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), m2 = new f2({
  explicit: [
    p2,
    d2,
    g2
  ]
});
function Xu(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
d(Xu, "resolveYamlNull");
function Vu() {
  return null;
}
d(Vu, "constructYamlNull");
function Zu(e) {
  return e === null;
}
d(Zu, "isNull");
var y2 = new zt("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: Xu,
  construct: Vu,
  predicate: Zu,
  represent: {
    canonical: /* @__PURE__ */ d(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ d(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ d(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function Ku(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
d(Ku, "resolveYamlBoolean");
function Qu(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
d(Qu, "constructYamlBoolean");
function Ju(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
d(Ju, "isBoolean");
var x2 = new zt("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: Ku,
  construct: Qu,
  predicate: Ju,
  represent: {
    lowercase: /* @__PURE__ */ d(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function tf(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
d(tf, "isHexCode");
function ef(e) {
  return 48 <= e && e <= 55;
}
d(ef, "isOctCode");
function rf(e) {
  return 48 <= e && e <= 57;
}
d(rf, "isDecCode");
function nf(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!tf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!ef(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!rf(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
d(nf, "resolveYamlInteger");
function af(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
d(af, "constructYamlInteger");
function sf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !Lt.isNegativeZero(e);
}
d(sf, "isInteger");
var b2 = new zt("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: nf,
  construct: af,
  predicate: sf,
  represent: {
    binary: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ d(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), C2 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function of(e) {
  return !(e === null || !C2.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
d(of, "resolveYamlFloat");
function lf(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
d(lf, "constructYamlFloat");
var _2 = /^[-+]?[0-9]+e/;
function cf(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (Lt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), _2.test(r) ? r.replace("e", ".e") : r;
}
d(cf, "representYamlFloat");
function hf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || Lt.isNegativeZero(e));
}
d(hf, "isFloat");
var w2 = new zt("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: of,
  construct: lf,
  predicate: hf,
  represent: cf,
  defaultStyle: "lowercase"
}), uf = m2.extend({
  implicit: [
    y2,
    x2,
    b2,
    w2
  ]
}), k2 = uf, ff = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), pf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function df(e) {
  return e === null ? !1 : ff.exec(e) !== null || pf.exec(e) !== null;
}
d(df, "resolveYamlTimestamp");
function gf(e) {
  var t, r, i, n, a, o, s, c = 0, l = null, h, u, f;
  if (t = ff.exec(e), t === null && (t = pf.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], o = +t[5], s = +t[6], t[7]) {
    for (c = t[7].slice(0, 3); c.length < 3; )
      c += "0";
    c = +c;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), l = (h * 60 + u) * 6e4, t[9] === "-" && (l = -l)), f = new Date(Date.UTC(r, i, n, a, o, s, c)), l && f.setTime(f.getTime() - l), f;
}
d(gf, "constructYamlTimestamp");
function mf(e) {
  return e.toISOString();
}
d(mf, "representYamlTimestamp");
var v2 = new zt("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: df,
  construct: gf,
  instanceOf: Date,
  represent: mf
});
function yf(e) {
  return e === "<<" || e === null;
}
d(yf, "resolveYamlMerge");
var S2 = new zt("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: yf
}), Ho = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function xf(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Ho;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
d(xf, "resolveYamlBinary");
function bf(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Ho, o = 0, s = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)), o = o << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)) : r === 18 ? (s.push(o >> 10 & 255), s.push(o >> 2 & 255)) : r === 12 && s.push(o >> 4 & 255), new Uint8Array(s);
}
d(bf, "constructYamlBinary");
function Cf(e) {
  var t = "", r = 0, i, n, a = e.length, o = Ho;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]) : n === 2 ? (t += o[r >> 10 & 63], t += o[r >> 4 & 63], t += o[r << 2 & 63], t += o[64]) : n === 1 && (t += o[r >> 2 & 63], t += o[r << 4 & 63], t += o[64], t += o[64]), t;
}
d(Cf, "representYamlBinary");
function _f(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
d(_f, "isBinary");
var T2 = new zt("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: xf,
  construct: bf,
  predicate: _f,
  represent: Cf
}), B2 = Object.prototype.hasOwnProperty, L2 = Object.prototype.toString;
function wf(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, o, s = e;
  for (r = 0, i = s.length; r < i; r += 1) {
    if (n = s[r], o = !1, L2.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (B2.call(n, a))
        if (!o) o = !0;
        else return !1;
    if (!o) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
d(wf, "resolveYamlOmap");
function kf(e) {
  return e !== null ? e : [];
}
d(kf, "constructYamlOmap");
var A2 = new zt("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: wf,
  construct: kf
}), M2 = Object.prototype.toString;
function vf(e) {
  if (e === null) return !0;
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1) {
    if (i = o[t], M2.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
d(vf, "resolveYamlPairs");
function Sf(e) {
  if (e === null) return [];
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1)
    i = o[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
d(Sf, "constructYamlPairs");
var $2 = new zt("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: vf,
  construct: Sf
}), E2 = Object.prototype.hasOwnProperty;
function Tf(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (E2.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
d(Tf, "resolveYamlSet");
function Bf(e) {
  return e !== null ? e : {};
}
d(Bf, "constructYamlSet");
var F2 = new zt("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: Tf,
  construct: Bf
}), Lf = k2.extend({
  implicit: [
    v2,
    S2
  ],
  explicit: [
    T2,
    A2,
    $2,
    F2
  ]
}), Ue = Object.prototype.hasOwnProperty, Jn = 1, Af = 2, Mf = 3, ta = 4, hs = 1, O2 = 2, vc = 3, D2 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, R2 = /[\x85\u2028\u2029]/, I2 = /[,\[\]\{\}]/, $f = /^(?:!|!!|![a-z\-]+!)$/i, Ef = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function Ns(e) {
  return Object.prototype.toString.call(e);
}
d(Ns, "_class");
function fe(e) {
  return e === 10 || e === 13;
}
d(fe, "is_EOL");
function je(e) {
  return e === 9 || e === 32;
}
d(je, "is_WHITE_SPACE");
function Ut(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
d(Ut, "is_WS_OR_EOL");
function sr(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
d(sr, "is_FLOW_INDICATOR");
function Ff(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
d(Ff, "fromHexCode");
function Of(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
d(Of, "escapedHexLen");
function Df(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
d(Df, "fromDecimalCode");
function zs(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
d(zs, "simpleEscapeSequence");
function Rf(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
d(Rf, "charFromCodepoint");
var If = new Array(256), Pf = new Array(256);
for (tr = 0; tr < 256; tr++)
  If[tr] = zs(tr) ? 1 : 0, Pf[tr] = zs(tr);
var tr;
function Nf(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Lf, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
d(Nf, "State$1");
function jo(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = c2(r), new Jt(t, r);
}
d(jo, "generateError");
function K(e, t) {
  throw jo(e, t);
}
d(K, "throwError");
function Pi(e, t) {
  e.onWarning && e.onWarning.call(null, jo(e, t));
}
d(Pi, "throwWarning");
var Sc = {
  YAML: /* @__PURE__ */ d(function(t, r, i) {
    var n, a, o;
    t.version !== null && K(t, "duplication of %YAML directive"), i.length !== 1 && K(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && K(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), o = parseInt(n[2], 10), a !== 1 && K(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = o < 2, o !== 1 && o !== 2 && Pi(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ d(function(t, r, i) {
    var n, a;
    i.length !== 2 && K(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], $f.test(n) || K(t, "ill-formed tag handle (first argument) of the TAG directive"), Ue.call(t.tagMap, n) && K(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Ef.test(a) || K(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      K(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function Ie(e, t, r, i) {
  var n, a, o, s;
  if (t < r) {
    if (s = e.input.slice(t, r), i)
      for (n = 0, a = s.length; n < a; n += 1)
        o = s.charCodeAt(n), o === 9 || 32 <= o && o <= 1114111 || K(e, "expected valid JSON character");
    else D2.test(s) && K(e, "the stream contains non-printable characters");
    e.result += s;
  }
}
d(Ie, "captureSegment");
function Ws(e, t, r, i) {
  var n, a, o, s;
  for (Lt.isObject(r) || K(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), o = 0, s = n.length; o < s; o += 1)
    a = n[o], Ue.call(t, a) || (t[a] = r[a], i[a] = !0);
}
d(Ws, "mergeMappings");
function or(e, t, r, i, n, a, o, s, c) {
  var l, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), l = 0, h = n.length; l < h; l += 1)
      Array.isArray(n[l]) && K(e, "nested arrays are not supported inside keys"), typeof n == "object" && Ns(n[l]) === "[object Object]" && (n[l] = "[object Object]");
  if (typeof n == "object" && Ns(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (l = 0, h = a.length; l < h; l += 1)
        Ws(e, t, a[l], r);
    else
      Ws(e, t, a, r);
  else
    !e.json && !Ue.call(r, n) && Ue.call(t, n) && (e.line = o || e.line, e.lineStart = s || e.lineStart, e.position = c || e.position, K(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
d(or, "storeMappingPair");
function La(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : K(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
d(La, "readLineBreak");
function kt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; je(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (fe(n))
      for (La(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Pi(e, "deficient indentation"), i;
}
d(kt, "skipSeparationSpace");
function Ki(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Ut(r)));
}
d(Ki, "testDocumentSeparator");
function Aa(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += Lt.repeat(`
`, t - 1));
}
d(Aa, "writeFoldedLines");
function zf(e, t, r) {
  var i, n, a, o, s, c, l, h, u = e.kind, f = e.result, p;
  if (p = e.input.charCodeAt(e.position), Ut(p) || sr(p) || p === 35 || p === 38 || p === 42 || p === 33 || p === 124 || p === 62 || p === 39 || p === 34 || p === 37 || p === 64 || p === 96 || (p === 63 || p === 45) && (n = e.input.charCodeAt(e.position + 1), Ut(n) || r && sr(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = o = e.position, s = !1; p !== 0; ) {
    if (p === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Ut(n) || r && sr(n))
        break;
    } else if (p === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Ut(i))
        break;
    } else {
      if (e.position === e.lineStart && Ki(e) || r && sr(p))
        break;
      if (fe(p))
        if (c = e.line, l = e.lineStart, h = e.lineIndent, kt(e, !1, -1), e.lineIndent >= t) {
          s = !0, p = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = o, e.line = c, e.lineStart = l, e.lineIndent = h;
          break;
        }
    }
    s && (Ie(e, a, o, !1), Aa(e, e.line - c), a = o = e.position, s = !1), je(p) || (o = e.position + 1), p = e.input.charCodeAt(++e.position);
  }
  return Ie(e, a, o, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
d(zf, "readPlainScalar");
function Wf(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (Ie(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else fe(r) ? (Ie(e, i, n, !0), Aa(e, kt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && Ki(e) ? K(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  K(e, "unexpected end of the stream within a single quoted scalar");
}
d(Wf, "readSingleQuotedScalar");
function qf(e, t) {
  var r, i, n, a, o, s;
  if (s = e.input.charCodeAt(e.position), s !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (s = e.input.charCodeAt(e.position)) !== 0; ) {
    if (s === 34)
      return Ie(e, r, e.position, !0), e.position++, !0;
    if (s === 92) {
      if (Ie(e, r, e.position, !0), s = e.input.charCodeAt(++e.position), fe(s))
        kt(e, !1, t);
      else if (s < 256 && If[s])
        e.result += Pf[s], e.position++;
      else if ((o = Of(s)) > 0) {
        for (n = o, a = 0; n > 0; n--)
          s = e.input.charCodeAt(++e.position), (o = Ff(s)) >= 0 ? a = (a << 4) + o : K(e, "expected hexadecimal character");
        e.result += Rf(a), e.position++;
      } else
        K(e, "unknown escape sequence");
      r = i = e.position;
    } else fe(s) ? (Ie(e, r, i, !0), Aa(e, kt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && Ki(e) ? K(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  K(e, "unexpected end of the stream within a double quoted scalar");
}
d(qf, "readDoubleQuotedScalar");
function Hf(e, t) {
  var r = !0, i, n, a, o = e.tag, s, c = e.anchor, l, h, u, f, p, g = /* @__PURE__ */ Object.create(null), m, y, x, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, p = !1, s = [];
  else if (b === 123)
    h = 125, p = !0, s = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = s), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (kt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = o, e.anchor = c, e.kind = p ? "mapping" : "sequence", e.result = s, !0;
    r ? b === 44 && K(e, "expected the node content, but found ','") : K(e, "missed comma between flow collection entries"), y = m = x = null, u = f = !1, b === 63 && (l = e.input.charCodeAt(e.position + 1), Ut(l) && (u = f = !0, e.position++, kt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, dr(e, t, Jn, !1, !0), y = e.tag, m = e.result, kt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), kt(e, !0, t), dr(e, t, Jn, !1, !0), x = e.result), p ? or(e, s, g, y, m, x, i, n, a) : u ? s.push(or(e, null, g, y, m, x, i, n, a)) : s.push(m), kt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  K(e, "unexpected end of the stream within a flow collection");
}
d(Hf, "readFlowCollection");
function jf(e, t) {
  var r, i, n = hs, a = !1, o = !1, s = t, c = 0, l = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      hs === n ? n = u === 43 ? vc : O2 : K(e, "repeat of a chomping mode identifier");
    else if ((h = Df(u)) >= 0)
      h === 0 ? K(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : o ? K(e, "repeat of an indentation width identifier") : (s = t + h - 1, o = !0);
    else
      break;
  if (je(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (je(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!fe(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (La(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!o || e.lineIndent < s) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!o && e.lineIndent > s && (s = e.lineIndent), fe(u)) {
      c++;
      continue;
    }
    if (e.lineIndent < s) {
      n === vc ? e.result += Lt.repeat(`
`, a ? 1 + c : c) : n === hs && a && (e.result += `
`);
      break;
    }
    for (i ? je(u) ? (l = !0, e.result += Lt.repeat(`
`, a ? 1 + c : c)) : l ? (l = !1, e.result += Lt.repeat(`
`, c + 1)) : c === 0 ? a && (e.result += " ") : e.result += Lt.repeat(`
`, c) : e.result += Lt.repeat(`
`, a ? 1 + c : c), a = !0, o = !0, c = 0, r = e.position; !fe(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    Ie(e, r, e.position, !1);
  }
  return !0;
}
d(jf, "readBlockScalar");
function qs(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], o, s = !1, c;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), c = e.input.charCodeAt(e.position); c !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), !(c !== 45 || (o = e.input.charCodeAt(e.position + 1), !Ut(o)))); ) {
    if (s = !0, e.position++, kt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), c = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, dr(e, t, Mf, !1, !0), a.push(e.result), kt(e, !0, -1), c = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && c !== 0)
      K(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return s ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
d(qs, "readBlockSequence");
function Yf(e, t, r) {
  var i, n, a, o, s, c, l = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), p = null, g = null, m = null, y = !1, x = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!y && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Ut(i))
      b === 63 ? (y && (or(e, u, f, p, g, null, o, s, c), p = g = m = null), x = !0, y = !0, n = !0) : y ? (y = !1, n = !0) : K(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (o = e.line, s = e.lineStart, c = e.position, !dr(e, r, Af, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); je(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Ut(b) || K(e, "a whitespace character is expected after the key-value separator within a block mapping"), y && (or(e, u, f, p, g, null, o, s, c), p = g = m = null), x = !0, y = !1, n = !1, p = e.tag, g = e.result;
        else if (x)
          K(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = l, e.anchor = h, !0;
      } else if (x)
        K(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = l, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (y && (o = e.line, s = e.lineStart, c = e.position), dr(e, t, ta, !0, n) && (y ? g = e.result : m = e.result), y || (or(e, u, f, p, g, m, o, s, c), p = g = m = null), kt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      K(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return y && or(e, u, f, p, g, null, o, s, c), x && (e.tag = l, e.anchor = h, e.kind = "mapping", e.result = u), x;
}
d(Yf, "readBlockMapping");
function Uf(e) {
  var t, r = !1, i = !1, n, a, o;
  if (o = e.input.charCodeAt(e.position), o !== 33) return !1;
  if (e.tag !== null && K(e, "duplication of a tag property"), o = e.input.charCodeAt(++e.position), o === 60 ? (r = !0, o = e.input.charCodeAt(++e.position)) : o === 33 ? (i = !0, n = "!!", o = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      o = e.input.charCodeAt(++e.position);
    while (o !== 0 && o !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), o = e.input.charCodeAt(++e.position)) : K(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; o !== 0 && !Ut(o); )
      o === 33 && (i ? K(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), $f.test(n) || K(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), o = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), I2.test(a) && K(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Ef.test(a) && K(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    K(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : Ue.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : K(e, 'undeclared tag handle "' + n + '"'), !0;
}
d(Uf, "readTagProperty");
function Gf(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && K(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Ut(r) && !sr(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
d(Gf, "readAnchorProperty");
function Xf(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Ut(i) && !sr(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), Ue.call(e.anchorMap, r) || K(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], kt(e, !0, -1), !0;
}
d(Xf, "readAlias");
function dr(e, t, r, i, n) {
  var a, o, s, c = 1, l = !1, h = !1, u, f, p, g, m, y;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = o = s = ta === r || Mf === r, i && kt(e, !0, -1) && (l = !0, e.lineIndent > t ? c = 1 : e.lineIndent === t ? c = 0 : e.lineIndent < t && (c = -1)), c === 1)
    for (; Uf(e) || Gf(e); )
      kt(e, !0, -1) ? (l = !0, s = a, e.lineIndent > t ? c = 1 : e.lineIndent === t ? c = 0 : e.lineIndent < t && (c = -1)) : s = !1;
  if (s && (s = l || n), (c === 1 || ta === r) && (Jn === r || Af === r ? m = t : m = t + 1, y = e.position - e.lineStart, c === 1 ? s && (qs(e, y) || Yf(e, y, m)) || Hf(e, m) ? h = !0 : (o && jf(e, m) || Wf(e, m) || qf(e, m) ? h = !0 : Xf(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && K(e, "alias node should not have any properties")) : zf(e, m, Jn === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : c === 0 && (h = s && qs(e, y))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && K(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (Ue.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, p = e.typeMap.multi[e.kind || "fallback"], u = 0, f = p.length; u < f; u += 1)
        if (e.tag.slice(0, p[u].tag.length) === p[u].tag) {
          g = p[u];
          break;
        }
    g || K(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && K(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : K(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
d(dr, "composeNode");
function Vf(e) {
  var t = e.position, r, i, n, a = !1, o;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (o = e.input.charCodeAt(e.position)) !== 0 && (kt(e, !0, -1), o = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || o !== 37)); ) {
    for (a = !0, o = e.input.charCodeAt(++e.position), r = e.position; o !== 0 && !Ut(o); )
      o = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && K(e, "directive name must not be less than one character in length"); o !== 0; ) {
      for (; je(o); )
        o = e.input.charCodeAt(++e.position);
      if (o === 35) {
        do
          o = e.input.charCodeAt(++e.position);
        while (o !== 0 && !fe(o));
        break;
      }
      if (fe(o)) break;
      for (r = e.position; o !== 0 && !Ut(o); )
        o = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    o !== 0 && La(e), Ue.call(Sc, i) ? Sc[i](e, i, n) : Pi(e, 'unknown document directive "' + i + '"');
  }
  if (kt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, kt(e, !0, -1)) : a && K(e, "directives end mark is expected"), dr(e, e.lineIndent - 1, ta, !1, !0), kt(e, !0, -1), e.checkLineBreaks && R2.test(e.input.slice(t, e.position)) && Pi(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && Ki(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, kt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    K(e, "end of the stream or a document separator is expected");
  else
    return;
}
d(Vf, "readDocument");
function Yo(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new Nf(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, K(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    Vf(r);
  return r.documents;
}
d(Yo, "loadDocuments");
function P2(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Yo(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
d(P2, "loadAll$1");
function Zf(e, t) {
  var r = Yo(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Jt("expected a single document in the stream, but found more");
  }
}
d(Zf, "load$1");
var N2 = Zf, z2 = {
  load: N2
}, Kf = Object.prototype.toString, Qf = Object.prototype.hasOwnProperty, Uo = 65279, W2 = 9, Ni = 10, q2 = 13, H2 = 32, j2 = 33, Y2 = 34, Hs = 35, U2 = 37, G2 = 38, X2 = 39, V2 = 42, Jf = 44, Z2 = 45, ea = 58, K2 = 61, Q2 = 62, J2 = 63, tC = 64, tp = 91, ep = 93, eC = 96, rp = 123, rC = 124, ip = 125, qt = {};
qt[0] = "\\0";
qt[7] = "\\a";
qt[8] = "\\b";
qt[9] = "\\t";
qt[10] = "\\n";
qt[11] = "\\v";
qt[12] = "\\f";
qt[13] = "\\r";
qt[27] = "\\e";
qt[34] = '\\"';
qt[92] = "\\\\";
qt[133] = "\\N";
qt[160] = "\\_";
qt[8232] = "\\L";
qt[8233] = "\\P";
var iC = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], nC = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function np(e, t) {
  var r, i, n, a, o, s, c;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    o = i[n], s = String(t[o]), o.slice(0, 2) === "!!" && (o = "tag:yaml.org,2002:" + o.slice(2)), c = e.compiledTypeMap.fallback[o], c && Qf.call(c.styleAliases, s) && (s = c.styleAliases[s]), r[o] = s;
  return r;
}
d(np, "compileStyleMap");
function ap(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Jt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + Lt.repeat("0", i - t.length) + t;
}
d(ap, "encodeHex");
var aC = 1, zi = 2;
function sp(e) {
  this.schema = e.schema || Lf, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = Lt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = np(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? zi : aC, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
d(sp, "State");
function js(e, t) {
  for (var r = Lt.repeat(" ", t), i = 0, n = -1, a = "", o, s = e.length; i < s; )
    n = e.indexOf(`
`, i), n === -1 ? (o = e.slice(i), i = s) : (o = e.slice(i, n + 1), i = n + 1), o.length && o !== `
` && (a += r), a += o;
  return a;
}
d(js, "indentString");
function ra(e, t) {
  return `
` + Lt.repeat(" ", e.indent * t);
}
d(ra, "generateNextLine");
function op(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
d(op, "testImplicitResolving");
function Wi(e) {
  return e === H2 || e === W2;
}
d(Wi, "isWhitespace");
function Kr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== Uo || 65536 <= e && e <= 1114111;
}
d(Kr, "isPrintable");
function Ys(e) {
  return Kr(e) && e !== Uo && e !== q2 && e !== Ni;
}
d(Ys, "isNsCharOrWhitespace");
function Us(e, t, r) {
  var i = Ys(e), n = i && !Wi(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== Jf && e !== tp && e !== ep && e !== rp && e !== ip) && e !== Hs && !(t === ea && !n) || Ys(t) && !Wi(t) && e === Hs || t === ea && n
  );
}
d(Us, "isPlainSafe");
function lp(e) {
  return Kr(e) && e !== Uo && !Wi(e) && e !== Z2 && e !== J2 && e !== ea && e !== Jf && e !== tp && e !== ep && e !== rp && e !== ip && e !== Hs && e !== G2 && e !== V2 && e !== j2 && e !== rC && e !== K2 && e !== Q2 && e !== X2 && e !== Y2 && e !== U2 && e !== tC && e !== eC;
}
d(lp, "isPlainSafeFirst");
function cp(e) {
  return !Wi(e) && e !== ea;
}
d(cp, "isPlainSafeLast");
function Fr(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
d(Fr, "codePointAt");
function Go(e) {
  var t = /^\n* /;
  return t.test(e);
}
d(Go, "needIndentIndicator");
var hp = 1, Gs = 2, up = 3, fp = 4, $r = 5;
function pp(e, t, r, i, n, a, o, s) {
  var c, l = 0, h = null, u = !1, f = !1, p = i !== -1, g = -1, m = lp(Fr(e, 0)) && cp(Fr(e, e.length - 1));
  if (t || o)
    for (c = 0; c < e.length; l >= 65536 ? c += 2 : c++) {
      if (l = Fr(e, c), !Kr(l))
        return $r;
      m = m && Us(l, h, s), h = l;
    }
  else {
    for (c = 0; c < e.length; l >= 65536 ? c += 2 : c++) {
      if (l = Fr(e, c), l === Ni)
        u = !0, p && (f = f || // Foldable line = too long, and not more-indented.
        c - g - 1 > i && e[g + 1] !== " ", g = c);
      else if (!Kr(l))
        return $r;
      m = m && Us(l, h, s), h = l;
    }
    f = f || p && c - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !o && !n(e) ? hp : a === zi ? $r : Gs : r > 9 && Go(e) ? $r : o ? a === zi ? $r : Gs : f ? fp : up;
}
d(pp, "chooseScalarStyle");
function dp(e, t, r, i, n) {
  e.dump = function() {
    if (t.length === 0)
      return e.quotingType === zi ? '""' : "''";
    if (!e.noCompatMode && (iC.indexOf(t) !== -1 || nC.test(t)))
      return e.quotingType === zi ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), o = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), s = i || e.flowLevel > -1 && r >= e.flowLevel;
    function c(l) {
      return op(e, l);
    }
    switch (d(c, "testAmbiguity"), pp(
      t,
      s,
      e.indent,
      o,
      c,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case hp:
        return t;
      case Gs:
        return "'" + t.replace(/'/g, "''") + "'";
      case up:
        return "|" + Xs(t, e.indent) + Vs(js(t, a));
      case fp:
        return ">" + Xs(t, e.indent) + Vs(js(gp(t, o), a));
      case $r:
        return '"' + mp(t) + '"';
      default:
        throw new Jt("impossible error: invalid scalar style");
    }
  }();
}
d(dp, "writeScalar");
function Xs(e, t) {
  var r = Go(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
d(Xs, "blockHeader");
function Vs(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
d(Vs, "dropEndingNewline");
function gp(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = function() {
    var l = e.indexOf(`
`);
    return l = l !== -1 ? l : e.length, r.lastIndex = l, Zs(e.slice(0, l), t);
  }(), n = e[0] === `
` || e[0] === " ", a, o; o = r.exec(e); ) {
    var s = o[1], c = o[2];
    a = c[0] === " ", i += s + (!n && !a && c !== "" ? `
` : "") + Zs(c, t), n = a;
  }
  return i;
}
d(gp, "foldString");
function Zs(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, o = 0, s = 0, c = ""; i = r.exec(e); )
    s = i.index, s - n > t && (a = o > n ? o : s, c += `
` + e.slice(n, a), n = a + 1), o = s;
  return c += `
`, e.length - n > t && o > n ? c += e.slice(n, o) + `
` + e.slice(o + 1) : c += e.slice(n), c.slice(1);
}
d(Zs, "foldLine");
function mp(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = Fr(e, n), i = qt[r], !i && Kr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || ap(r);
  return t;
}
d(mp, "escapeString");
function yp(e, t, r) {
  var i = "", n = e.tag, a, o, s;
  for (a = 0, o = r.length; a < o; a += 1)
    s = r[a], e.replacer && (s = e.replacer.call(r, String(a), s)), (ke(e, t, s, !1, !1) || typeof s > "u" && ke(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
d(yp, "writeFlowSequence");
function Ks(e, t, r, i) {
  var n = "", a = e.tag, o, s, c;
  for (o = 0, s = r.length; o < s; o += 1)
    c = r[o], e.replacer && (c = e.replacer.call(r, String(o), c)), (ke(e, t + 1, c, !0, !0, !1, !0) || typeof c > "u" && ke(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += ra(e, t)), e.dump && Ni === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
d(Ks, "writeBlockSequence");
function xp(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), o, s, c, l, h;
  for (o = 0, s = a.length; o < s; o += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), c = a[o], l = r[c], e.replacer && (l = e.replacer.call(r, c, l)), ke(e, t, c, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), ke(e, t, l, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
d(xp, "writeFlowMapping");
function bp(e, t, r, i) {
  var n = "", a = e.tag, o = Object.keys(r), s, c, l, h, u, f;
  if (e.sortKeys === !0)
    o.sort();
  else if (typeof e.sortKeys == "function")
    o.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Jt("sortKeys must be a boolean or a function");
  for (s = 0, c = o.length; s < c; s += 1)
    f = "", (!i || n !== "") && (f += ra(e, t)), l = o[s], h = r[l], e.replacer && (h = e.replacer.call(r, l, h)), ke(e, t + 1, l, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && Ni === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += ra(e, t)), ke(e, t + 1, h, !0, u) && (e.dump && Ni === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
d(bp, "writeBlockMapping");
function Qs(e, t, r) {
  var i, n, a, o, s, c;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, o = n.length; a < o; a += 1)
    if (s = n[a], (s.instanceOf || s.predicate) && (!s.instanceOf || typeof t == "object" && t instanceof s.instanceOf) && (!s.predicate || s.predicate(t))) {
      if (r ? s.multi && s.representName ? e.tag = s.representName(t) : e.tag = s.tag : e.tag = "?", s.represent) {
        if (c = e.styleMap[s.tag] || s.defaultStyle, Kf.call(s.represent) === "[object Function]")
          i = s.represent(t, c);
        else if (Qf.call(s.represent, c))
          i = s.represent[c](t, c);
        else
          throw new Jt("!<" + s.tag + '> tag resolver accepts not "' + c + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
d(Qs, "detectType");
function ke(e, t, r, i, n, a, o) {
  e.tag = null, e.dump = r, Qs(e, r, !1) || Qs(e, r, !0);
  var s = Kf.call(e.dump), c = i, l;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = s === "[object Object]" || s === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), s === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (bp(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (xp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !o && t > 0 ? Ks(e, t - 1, e.dump, n) : Ks(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (yp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object String]")
      e.tag !== "?" && dp(e, e.dump, t, a, c);
    else {
      if (s === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Jt("unacceptable kind of an object to dump " + s);
    }
    e.tag !== null && e.tag !== "?" && (l = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? l = "!" + l : l.slice(0, 18) === "tag:yaml.org,2002:" ? l = "!!" + l.slice(18) : l = "!<" + l + ">", e.dump = l + " " + e.dump);
  }
  return !0;
}
d(ke, "writeNode");
function Cp(e, t) {
  var r = [], i = [], n, a;
  for (ia(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
d(Cp, "getDuplicateReferences");
function ia(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        ia(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        ia(e[i[n]], t, r);
}
d(ia, "inspectNode");
function sC(e, t) {
  t = t || {};
  var r = new sp(t);
  r.noRefs || Cp(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), ke(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
d(sC, "dump$1");
function oC(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
d(oC, "renamed");
var lC = uf, cC = z2.load;
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 4.1.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
var Pt = {
  aggregation: 17.25,
  extension: 17.25,
  composition: 17.25,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
  //arrow_cross: 24,
}, Tc = {
  arrow_point: 9,
  arrow_cross: 12.5,
  arrow_circle: 12.5
};
function ki(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = _t(e), t = _t(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], o = n - r, s = a - i;
  return { angle: Math.atan(s / o), deltaX: o, deltaY: s };
}
d(ki, "calculateDeltaAndAngle");
var _t = /* @__PURE__ */ d((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), hC = /* @__PURE__ */ d((e) => ({
  x: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = _t(i[0]).x < _t(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Pt, e.arrowTypeStart)) {
      const { angle: p, deltaX: g } = ki(i[0], i[1]);
      n = Pt[e.arrowTypeStart] * Math.cos(p) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Pt, e.arrowTypeEnd)) {
      const { angle: p, deltaX: g } = ki(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Pt[e.arrowTypeEnd] * Math.cos(p) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      _t(t).x - _t(i[i.length - 1]).x
    ), s = Math.abs(
      _t(t).y - _t(i[i.length - 1]).y
    ), c = Math.abs(_t(t).x - _t(i[0]).x), l = Math.abs(_t(t).y - _t(i[0]).y), h = Pt[e.arrowTypeStart], u = Pt[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "right" ? -1 : 1, n -= p;
    }
    if (c < h && c > 0 && l < h) {
      let p = h + f - c;
      p *= a === "right" ? -1 : 1, n += p;
    }
    return _t(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = _t(i[0]).y < _t(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Pt, e.arrowTypeStart)) {
      const { angle: p, deltaY: g } = ki(i[0], i[1]);
      n = Pt[e.arrowTypeStart] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Pt, e.arrowTypeEnd)) {
      const { angle: p, deltaY: g } = ki(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Pt[e.arrowTypeEnd] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      _t(t).y - _t(i[i.length - 1]).y
    ), s = Math.abs(
      _t(t).x - _t(i[i.length - 1]).x
    ), c = Math.abs(_t(t).y - _t(i[0]).y), l = Math.abs(_t(t).x - _t(i[0]).x), h = Pt[e.arrowTypeStart], u = Pt[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "up" ? -1 : 1, n -= p;
    }
    if (c < h && c > 0 && l < h) {
      let p = h + f - c;
      p *= a === "up" ? -1 : 1, n += p;
    }
    return _t(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), Xo = /* @__PURE__ */ d(({
  flowchart: e
}) => {
  var n, a;
  const t = ((n = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : n.top) ?? 0, r = ((a = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : a.bottom) ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), uC = /* @__PURE__ */ d((e) => {
  const { handDrawnSeed: t } = ft();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), ei = /* @__PURE__ */ d((e) => {
  const t = fC([
    ...e.cssCompiledStyles || [],
    ...e.cssStyles || [],
    ...e.labelStyle || []
  ]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), fC = /* @__PURE__ */ d((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n == null ? void 0 : n.trim());
  }), t;
}, "styles2Map"), _p = /* @__PURE__ */ d((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), G = /* @__PURE__ */ d((e) => {
  const { stylesArray: t } = ei(e), r = [], i = [], n = [], a = [];
  return t.forEach((o) => {
    const s = o[0];
    _p(s) ? r.push(o.join(":") + " !important") : (i.push(o.join(":") + " !important"), s.includes("stroke") && n.push(o.join(":") + " !important"), s === "fill" && a.push(o.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), U = /* @__PURE__ */ d((e, t) => {
  var c;
  const { themeVariables: r, handDrawnSeed: i } = ft(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: o } = ei(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: o.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: o.get("stroke") || n,
      seed: i,
      strokeWidth: ((c = o.get("stroke-width")) == null ? void 0 : c.replace("px", "")) || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: pC(o.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), pC = /* @__PURE__ */ d((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray"), Vo = {}, $t = {};
Object.defineProperty($t, "__esModule", { value: !0 });
$t.BLANK_URL = $t.relativeFirstCharacters = $t.whitespaceEscapeCharsRegex = $t.urlSchemeRegex = $t.ctrlCharactersRegex = $t.htmlCtrlEntityRegex = $t.htmlEntitiesRegex = $t.invalidProtocolRegex = void 0;
$t.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
$t.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
$t.htmlCtrlEntityRegex = /&(newline|tab);/gi;
$t.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
$t.urlSchemeRegex = /^.+(:|&colon;)/gim;
$t.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
$t.relativeFirstCharacters = [".", "/"];
$t.BLANK_URL = "about:blank";
Object.defineProperty(Vo, "__esModule", { value: !0 });
var wp = Vo.sanitizeUrl = void 0, It = $t;
function dC(e) {
  return It.relativeFirstCharacters.indexOf(e[0]) > -1;
}
function gC(e) {
  var t = e.replace(It.ctrlCharactersRegex, "");
  return t.replace(It.htmlEntitiesRegex, function(r, i) {
    return String.fromCharCode(i);
  });
}
function mC(e) {
  return URL.canParse(e);
}
function Bc(e) {
  try {
    return decodeURIComponent(e);
  } catch {
    return e;
  }
}
function yC(e) {
  if (!e)
    return It.BLANK_URL;
  var t, r = Bc(e.trim());
  do
    r = gC(r).replace(It.htmlCtrlEntityRegex, "").replace(It.ctrlCharactersRegex, "").replace(It.whitespaceEscapeCharsRegex, "").trim(), r = Bc(r), t = r.match(It.ctrlCharactersRegex) || r.match(It.htmlEntitiesRegex) || r.match(It.htmlCtrlEntityRegex) || r.match(It.whitespaceEscapeCharsRegex);
  while (t && t.length > 0);
  var i = r;
  if (!i)
    return It.BLANK_URL;
  if (dC(i))
    return i;
  var n = i.trimStart(), a = n.match(It.urlSchemeRegex);
  if (!a)
    return i;
  var o = a[0].toLowerCase().trim();
  if (It.invalidProtocolRegex.test(o))
    return It.BLANK_URL;
  var s = n.replace(/\\/g, "/");
  if (o === "mailto:" || o.includes("://"))
    return s;
  if (o === "http:" || o === "https:") {
    if (!mC(s))
      return It.BLANK_URL;
    var c = new URL(s);
    return c.protocol = c.protocol.toLowerCase(), c.hostname = c.hostname.toLowerCase(), c.toString();
  }
  return s;
}
wp = Vo.sanitizeUrl = yC;
var kp = typeof global == "object" && global && global.Object === Object && global, xC = typeof self == "object" && self && self.Object === Object && self, Se = kp || xC || Function("return this")(), na = Se.Symbol, vp = Object.prototype, bC = vp.hasOwnProperty, CC = vp.toString, di = na ? na.toStringTag : void 0;
function _C(e) {
  var t = bC.call(e, di), r = e[di];
  try {
    e[di] = void 0;
    var i = !0;
  } catch {
  }
  var n = CC.call(e);
  return i && (t ? e[di] = r : delete e[di]), n;
}
var wC = Object.prototype, kC = wC.toString;
function vC(e) {
  return kC.call(e);
}
var SC = "[object Null]", TC = "[object Undefined]", Lc = na ? na.toStringTag : void 0;
function ri(e) {
  return e == null ? e === void 0 ? TC : SC : Lc && Lc in Object(e) ? _C(e) : vC(e);
}
function xr(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var BC = "[object AsyncFunction]", LC = "[object Function]", AC = "[object GeneratorFunction]", MC = "[object Proxy]";
function Zo(e) {
  if (!xr(e))
    return !1;
  var t = ri(e);
  return t == LC || t == AC || t == BC || t == MC;
}
var us = Se["__core-js_shared__"], Ac = function() {
  var e = /[^.]+$/.exec(us && us.keys && us.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function $C(e) {
  return !!Ac && Ac in e;
}
var EC = Function.prototype, FC = EC.toString;
function br(e) {
  if (e != null) {
    try {
      return FC.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var OC = /[\\^$.*+?()[\]{}|]/g, DC = /^\[object .+?Constructor\]$/, RC = Function.prototype, IC = Object.prototype, PC = RC.toString, NC = IC.hasOwnProperty, zC = RegExp(
  "^" + PC.call(NC).replace(OC, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function WC(e) {
  if (!xr(e) || $C(e))
    return !1;
  var t = Zo(e) ? zC : DC;
  return t.test(br(e));
}
function qC(e, t) {
  return e == null ? void 0 : e[t];
}
function Cr(e, t) {
  var r = qC(e, t);
  return WC(r) ? r : void 0;
}
var qi = Cr(Object, "create");
function HC() {
  this.__data__ = qi ? qi(null) : {}, this.size = 0;
}
function jC(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var YC = "__lodash_hash_undefined__", UC = Object.prototype, GC = UC.hasOwnProperty;
function XC(e) {
  var t = this.__data__;
  if (qi) {
    var r = t[e];
    return r === YC ? void 0 : r;
  }
  return GC.call(t, e) ? t[e] : void 0;
}
var VC = Object.prototype, ZC = VC.hasOwnProperty;
function KC(e) {
  var t = this.__data__;
  return qi ? t[e] !== void 0 : ZC.call(t, e);
}
var QC = "__lodash_hash_undefined__";
function JC(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = qi && t === void 0 ? QC : t, this;
}
function gr(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
gr.prototype.clear = HC;
gr.prototype.delete = jC;
gr.prototype.get = XC;
gr.prototype.has = KC;
gr.prototype.set = JC;
function t_() {
  this.__data__ = [], this.size = 0;
}
function Ma(e, t) {
  return e === t || e !== e && t !== t;
}
function $a(e, t) {
  for (var r = e.length; r--; )
    if (Ma(e[r][0], t))
      return r;
  return -1;
}
var e_ = Array.prototype, r_ = e_.splice;
function i_(e) {
  var t = this.__data__, r = $a(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : r_.call(t, r, 1), --this.size, !0;
}
function n_(e) {
  var t = this.__data__, r = $a(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function a_(e) {
  return $a(this.__data__, e) > -1;
}
function s_(e, t) {
  var r = this.__data__, i = $a(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function ze(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
ze.prototype.clear = t_;
ze.prototype.delete = i_;
ze.prototype.get = n_;
ze.prototype.has = a_;
ze.prototype.set = s_;
var Hi = Cr(Se, "Map");
function o_() {
  this.size = 0, this.__data__ = {
    hash: new gr(),
    map: new (Hi || ze)(),
    string: new gr()
  };
}
function l_(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Ea(e, t) {
  var r = e.__data__;
  return l_(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function c_(e) {
  var t = Ea(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function h_(e) {
  return Ea(this, e).get(e);
}
function u_(e) {
  return Ea(this, e).has(e);
}
function f_(e, t) {
  var r = Ea(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Ve(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ve.prototype.clear = o_;
Ve.prototype.delete = c_;
Ve.prototype.get = h_;
Ve.prototype.has = u_;
Ve.prototype.set = f_;
var p_ = "Expected a function";
function Qi(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(p_);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var o = e.apply(this, i);
    return r.cache = a.set(n, o) || a, o;
  };
  return r.cache = new (Qi.Cache || Ve)(), r;
}
Qi.Cache = Ve;
function d_() {
  this.__data__ = new ze(), this.size = 0;
}
function g_(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function m_(e) {
  return this.__data__.get(e);
}
function y_(e) {
  return this.__data__.has(e);
}
var x_ = 200;
function b_(e, t) {
  var r = this.__data__;
  if (r instanceof ze) {
    var i = r.__data__;
    if (!Hi || i.length < x_ - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Ve(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function ii(e) {
  var t = this.__data__ = new ze(e);
  this.size = t.size;
}
ii.prototype.clear = d_;
ii.prototype.delete = g_;
ii.prototype.get = m_;
ii.prototype.has = y_;
ii.prototype.set = b_;
var aa = function() {
  try {
    var e = Cr(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
}();
function Ko(e, t, r) {
  t == "__proto__" && aa ? aa(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function Js(e, t, r) {
  (r !== void 0 && !Ma(e[t], r) || r === void 0 && !(t in e)) && Ko(e, t, r);
}
function C_(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), o = i(t), s = o.length; s--; ) {
      var c = o[++n];
      if (r(a[c], c, a) === !1)
        break;
    }
    return t;
  };
}
var __ = C_(), Sp = typeof exports == "object" && exports && !exports.nodeType && exports, Mc = Sp && typeof module == "object" && module && !module.nodeType && module, w_ = Mc && Mc.exports === Sp, $c = w_ ? Se.Buffer : void 0, Ec = $c ? $c.allocUnsafe : void 0;
function k_(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Ec ? Ec(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Fc = Se.Uint8Array;
function v_(e) {
  var t = new e.constructor(e.byteLength);
  return new Fc(t).set(new Fc(e)), t;
}
function S_(e, t) {
  var r = t ? v_(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function T_(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Oc = Object.create, B_ = /* @__PURE__ */ function() {
  function e() {
  }
  return function(t) {
    if (!xr(t))
      return {};
    if (Oc)
      return Oc(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
}();
function Tp(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Bp = Tp(Object.getPrototypeOf, Object), L_ = Object.prototype;
function Fa(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || L_;
  return e === r;
}
function A_(e) {
  return typeof e.constructor == "function" && !Fa(e) ? B_(Bp(e)) : {};
}
function Ji(e) {
  return e != null && typeof e == "object";
}
var M_ = "[object Arguments]";
function Dc(e) {
  return Ji(e) && ri(e) == M_;
}
var Lp = Object.prototype, $_ = Lp.hasOwnProperty, E_ = Lp.propertyIsEnumerable, sa = Dc(/* @__PURE__ */ function() {
  return arguments;
}()) ? Dc : function(e) {
  return Ji(e) && $_.call(e, "callee") && !E_.call(e, "callee");
}, oa = Array.isArray, F_ = 9007199254740991;
function Ap(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= F_;
}
function Oa(e) {
  return e != null && Ap(e.length) && !Zo(e);
}
function O_(e) {
  return Ji(e) && Oa(e);
}
function D_() {
  return !1;
}
var Mp = typeof exports == "object" && exports && !exports.nodeType && exports, Rc = Mp && typeof module == "object" && module && !module.nodeType && module, R_ = Rc && Rc.exports === Mp, Ic = R_ ? Se.Buffer : void 0, I_ = Ic ? Ic.isBuffer : void 0, Qo = I_ || D_, P_ = "[object Object]", N_ = Function.prototype, z_ = Object.prototype, $p = N_.toString, W_ = z_.hasOwnProperty, q_ = $p.call(Object);
function H_(e) {
  if (!Ji(e) || ri(e) != P_)
    return !1;
  var t = Bp(e);
  if (t === null)
    return !0;
  var r = W_.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && $p.call(r) == q_;
}
var j_ = "[object Arguments]", Y_ = "[object Array]", U_ = "[object Boolean]", G_ = "[object Date]", X_ = "[object Error]", V_ = "[object Function]", Z_ = "[object Map]", K_ = "[object Number]", Q_ = "[object Object]", J_ = "[object RegExp]", tw = "[object Set]", ew = "[object String]", rw = "[object WeakMap]", iw = "[object ArrayBuffer]", nw = "[object DataView]", aw = "[object Float32Array]", sw = "[object Float64Array]", ow = "[object Int8Array]", lw = "[object Int16Array]", cw = "[object Int32Array]", hw = "[object Uint8Array]", uw = "[object Uint8ClampedArray]", fw = "[object Uint16Array]", pw = "[object Uint32Array]", bt = {};
bt[aw] = bt[sw] = bt[ow] = bt[lw] = bt[cw] = bt[hw] = bt[uw] = bt[fw] = bt[pw] = !0;
bt[j_] = bt[Y_] = bt[iw] = bt[U_] = bt[nw] = bt[G_] = bt[X_] = bt[V_] = bt[Z_] = bt[K_] = bt[Q_] = bt[J_] = bt[tw] = bt[ew] = bt[rw] = !1;
function dw(e) {
  return Ji(e) && Ap(e.length) && !!bt[ri(e)];
}
function gw(e) {
  return function(t) {
    return e(t);
  };
}
var Ep = typeof exports == "object" && exports && !exports.nodeType && exports, Ei = Ep && typeof module == "object" && module && !module.nodeType && module, mw = Ei && Ei.exports === Ep, fs = mw && kp.process, Pc = function() {
  try {
    var e = Ei && Ei.require && Ei.require("util").types;
    return e || fs && fs.binding && fs.binding("util");
  } catch {
  }
}(), Nc = Pc && Pc.isTypedArray, Jo = Nc ? gw(Nc) : dw;
function to(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var yw = Object.prototype, xw = yw.hasOwnProperty;
function bw(e, t, r) {
  var i = e[t];
  (!(xw.call(e, t) && Ma(i, r)) || r === void 0 && !(t in e)) && Ko(e, t, r);
}
function Cw(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, o = t.length; ++a < o; ) {
    var s = t[a], c = void 0;
    c === void 0 && (c = e[s]), n ? Ko(r, s, c) : bw(r, s, c);
  }
  return r;
}
function _w(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var ww = 9007199254740991, kw = /^(?:0|[1-9]\d*)$/;
function Fp(e, t) {
  var r = typeof e;
  return t = t ?? ww, !!t && (r == "number" || r != "symbol" && kw.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var vw = Object.prototype, Sw = vw.hasOwnProperty;
function Tw(e, t) {
  var r = oa(e), i = !r && sa(e), n = !r && !i && Qo(e), a = !r && !i && !n && Jo(e), o = r || i || n || a, s = o ? _w(e.length, String) : [], c = s.length;
  for (var l in e)
    (t || Sw.call(e, l)) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (l == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (l == "offset" || l == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (l == "buffer" || l == "byteLength" || l == "byteOffset") || // Skip index properties.
    Fp(l, c))) && s.push(l);
  return s;
}
function Bw(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var Lw = Object.prototype, Aw = Lw.hasOwnProperty;
function Mw(e) {
  if (!xr(e))
    return Bw(e);
  var t = Fa(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !Aw.call(e, i)) || r.push(i);
  return r;
}
function Op(e) {
  return Oa(e) ? Tw(e, !0) : Mw(e);
}
function $w(e) {
  return Cw(e, Op(e));
}
function Ew(e, t, r, i, n, a, o) {
  var s = to(e, r), c = to(t, r), l = o.get(c);
  if (l) {
    Js(e, r, l);
    return;
  }
  var h = a ? a(s, c, r + "", e, t, o) : void 0, u = h === void 0;
  if (u) {
    var f = oa(c), p = !f && Qo(c), g = !f && !p && Jo(c);
    h = c, f || p || g ? oa(s) ? h = s : O_(s) ? h = T_(s) : p ? (u = !1, h = k_(c, !0)) : g ? (u = !1, h = S_(c, !0)) : h = [] : H_(c) || sa(c) ? (h = s, sa(s) ? h = $w(s) : (!xr(s) || Zo(s)) && (h = A_(c))) : u = !1;
  }
  u && (o.set(c, h), n(h, c, i, a, o), o.delete(c)), Js(e, r, h);
}
function Dp(e, t, r, i, n) {
  e !== t && __(t, function(a, o) {
    if (n || (n = new ii()), xr(a))
      Ew(e, t, o, r, Dp, i, n);
    else {
      var s = i ? i(to(e, o), a, o + "", e, t, n) : void 0;
      s === void 0 && (s = a), Js(e, o, s);
    }
  }, Op);
}
function Rp(e) {
  return e;
}
function Fw(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var zc = Math.max;
function Ow(e, t, r) {
  return t = zc(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = zc(i.length - t, 0), o = Array(a); ++n < a; )
      o[n] = i[t + n];
    n = -1;
    for (var s = Array(t + 1); ++n < t; )
      s[n] = i[n];
    return s[t] = r(o), Fw(e, this, s);
  };
}
function Dw(e) {
  return function() {
    return e;
  };
}
var Rw = aa ? function(e, t) {
  return aa(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: Dw(t),
    writable: !0
  });
} : Rp, Iw = 800, Pw = 16, Nw = Date.now;
function zw(e) {
  var t = 0, r = 0;
  return function() {
    var i = Nw(), n = Pw - (i - r);
    if (r = i, n > 0) {
      if (++t >= Iw)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var Ww = zw(Rw);
function qw(e, t) {
  return Ww(Ow(e, t, Rp), e + "");
}
function Hw(e, t, r) {
  if (!xr(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Oa(r) && Fp(t, r.length) : i == "string" && t in r) ? Ma(r[t], e) : !1;
}
function jw(e) {
  return qw(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, o = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, o && Hw(r[0], r[1], o) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var s = r[i];
      s && e(t, s, i, a);
    }
    return t;
  });
}
var Yw = jw(function(e, t, r) {
  Dp(e, t, r);
}), Uw = "​", Gw = {
  curveBasis: An,
  curveBasisClosed: X1,
  curveBasisOpen: V1,
  curveBumpX: bu,
  curveBumpY: Cu,
  curveBundle: Z1,
  curveCardinalClosed: K1,
  curveCardinalOpen: Q1,
  curveCardinal: vu,
  curveCatmullRomClosed: J1,
  curveCatmullRomOpen: t2,
  curveCatmullRom: Tu,
  curveLinear: Xn,
  curveLinearClosed: e2,
  curveMonotoneX: Eu,
  curveMonotoneY: Fu,
  curveNatural: Du,
  curveStep: Ru,
  curveStepAfter: Pu,
  curveStepBefore: Iu
}, Xw = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Vw = /* @__PURE__ */ d(function(e, t) {
  const r = Ip(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const o = r.map((s) => s.args);
    In(o), i = Bt(i, [...o]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = wo(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Ip = /* @__PURE__ */ d(function(e, t = null) {
  var r, i;
  try {
    const n = new RegExp(
      `[%]{2}(?![{]${Xw.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(n, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let a;
    const o = [];
    for (; (a = Mi.exec(e)) !== null; )
      if (a.index === Mi.lastIndex && Mi.lastIndex++, a && !t || t && ((r = a[1]) != null && r.match(t)) || t && ((i = a[2]) != null && i.match(t))) {
        const s = a[1] ? a[1] : a[2], c = a[3] ? a[3].trim() : a[4] ? JSON.parse(a[4].trim()) : null;
        o.push({ type: s, args: c });
      }
    return o.length === 0 ? { type: e, args: null } : o.length === 1 ? o[0] : o;
  } catch (n) {
    return F.error(
      `ERROR: ${n.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), Zw = /* @__PURE__ */ d(function(e) {
  return e.replace(Mi, "");
}, "removeDirectives"), Kw = /* @__PURE__ */ d(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function tl(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return Gw[r] ?? t;
}
d(tl, "interpolateToCurve");
function Pp(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? wp(r) : r;
}
d(Pp, "formatUrl");
var Qw = /* @__PURE__ */ d((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let o = 0; o < i; o++)
    if (a = a[r[o]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function el(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
d(el, "distance");
function Np(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += el(n, t), t = n;
  });
  const i = r / 2;
  return rl(e, i);
}
d(Np, "traverseEdge");
function zp(e) {
  return e.length === 1 ? e[0] : Np(e);
}
d(zp, "calcLabelPosition");
var Wc = /* @__PURE__ */ d((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), rl = /* @__PURE__ */ d((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = el(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const o = i / a;
        if (o <= 0)
          return r;
        if (o >= 1)
          return { x: n.x, y: n.y };
        if (o > 0 && o < 1)
          return {
            x: Wc((1 - o) * r.x + o * n.x, 5),
            y: Wc((1 - o) * r.y + o * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), Jw = /* @__PURE__ */ d((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = rl(t, 25), a = e ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), s = { x: 0, y: 0 };
  return s.x = Math.sin(o) * a + (t[0].x + n.x) / 2, s.y = -Math.cos(o) * a + (t[0].y + n.y) / 2, s;
}, "calcCardinalityPosition");
function Wp(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = rl(i, n), o = 10 + e * 0.5, s = Math.atan2(i[0].y - a.y, i[0].x - a.x), c = { x: 0, y: 0 };
  return t === "start_left" ? (c.x = Math.sin(s + Math.PI) * o + (i[0].x + a.x) / 2, c.y = -Math.cos(s + Math.PI) * o + (i[0].y + a.y) / 2) : t === "end_right" ? (c.x = Math.sin(s - Math.PI) * o + (i[0].x + a.x) / 2 - 5, c.y = -Math.cos(s - Math.PI) * o + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (c.x = Math.sin(s) * o + (i[0].x + a.x) / 2 - 5, c.y = -Math.cos(s) * o + (i[0].y + a.y) / 2 - 5) : (c.x = Math.sin(s) * o + (i[0].x + a.x) / 2, c.y = -Math.cos(s) * o + (i[0].y + a.y) / 2), c;
}
d(Wp, "calcTerminalLabelPosition");
function qp(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
d(qp, "getStylesFromArray");
var qc = 0, tk = /* @__PURE__ */ d(() => (qc++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + qc), "generateId");
function Hp(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
d(Hp, "makeRandomHex");
var ek = /* @__PURE__ */ d((e) => Hp(e.length), "random"), rk = /* @__PURE__ */ d(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), ik = /* @__PURE__ */ d(function(e, t) {
  const r = t.text.replace(ti.lineBreakRegex, " "), [, i] = Da(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), nk = Qi(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), ti.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((o, s) => {
      const c = Ne(`${o} `, r), l = Ne(a, r);
      if (c > t) {
        const { hyphenatedStrings: f, remainingWord: p } = ak(o, t, "-", r);
        n.push(a, ...f), a = p;
      } else l + c >= t ? (n.push(a), a = o) : a = [a, o].filter(Boolean).join(" ");
      s + 1 === i.length && n.push(a);
    }), n.filter((o) => o !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), ak = Qi(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let o = "";
    return n.forEach((s, c) => {
      const l = `${o}${s}`;
      if (Ne(l, i) >= t) {
        const u = c + 1, f = n.length === u, p = `${l}${r}`;
        a.push(f ? l : p), o = "";
      } else
        o = l;
    }), { hyphenatedStrings: a, remainingWord: o };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function jp(e, t) {
  return il(e, t).height;
}
d(jp, "calculateTextHeight");
function Ne(e, t) {
  return il(e, t).width;
}
d(Ne, "calculateTextWidth");
var il = Qi(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Da(r), o = ["sans-serif", i], s = e.split(ti.lineBreakRegex), c = [], l = ht("body");
    if (!l.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = l.append("svg");
    for (const f of o) {
      let p = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of s) {
        const y = rk();
        y.text = m || Uw;
        const x = ik(h, y).style("font-size", a).style("font-weight", n).style("font-family", f), b = (x._groups || x)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), p = Math.round(b.height), g.height += p, g.lineHeight = Math.round(Math.max(g.lineHeight, p));
      }
      c.push(g);
    }
    h.remove();
    const u = isNaN(c[1].height) || isNaN(c[1].width) || isNaN(c[1].lineHeight) || c[0].height > c[1].height && c[0].width > c[1].width && c[0].lineHeight > c[1].lineHeight ? 0 : 1;
    return c[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), jr, sk = (jr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, d(jr, "InitIDGenerator"), jr), gn, ok = /* @__PURE__ */ d(function(e) {
  return gn = gn || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), gn.innerHTML = e, unescape(gn.textContent);
}, "entityDecode");
function nl(e) {
  return "str" in e;
}
d(nl, "isDetailedError");
var lk = /* @__PURE__ */ d((e, t, r, i) => {
  var a;
  if (!i)
    return;
  const n = (a = e.node()) == null ? void 0 : a.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Da = /* @__PURE__ */ d((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function al(e, t) {
  return Yw({}, e, t);
}
d(al, "cleanAndMerge");
var ue = {
  assignWithDepth: Bt,
  wrapLabel: nk,
  calculateTextHeight: jp,
  calculateTextWidth: Ne,
  calculateTextDimensions: il,
  cleanAndMerge: al,
  detectInit: Vw,
  detectDirective: Ip,
  isSubstringInArray: Kw,
  interpolateToCurve: tl,
  calcLabelPosition: zp,
  calcCardinalityPosition: Jw,
  calcTerminalLabelPosition: Wp,
  formatUrl: Pp,
  getStylesFromArray: qp,
  generateId: tk,
  random: ek,
  runFunc: Qw,
  entityDecode: ok,
  insertTitle: lk,
  isLabelCoordinateInPath: Yp,
  parseFontSize: Da,
  InitIDGenerator: sk
}, ck = /* @__PURE__ */ d(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), _r = /* @__PURE__ */ d(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), cA = /* @__PURE__ */ d((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Wt(e) {
  return e ?? null;
}
d(Wt, "handleUndefinedAttr");
function Yp(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
d(Yp, "isLabelCoordinateInPath");
const hk = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), la = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), Up = Object.freeze({
  ...hk,
  ...la
}), uk = Object.freeze({
  ...Up,
  body: "",
  hidden: !1
}), fk = Object.freeze({
  width: null,
  height: null
}), pk = Object.freeze({
  ...fk,
  ...la
}), dk = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const s = n.pop(), c = n.pop(), l = {
      provider: n.length > 0 ? n[0] : i,
      prefix: c,
      name: s
    };
    return ps(l) ? l : null;
  }
  const a = n[0], o = a.split("-");
  if (o.length > 1) {
    const s = {
      provider: i,
      prefix: o.shift(),
      name: o.join("-")
    };
    return ps(s) ? s : null;
  }
  if (r && i === "") {
    const s = {
      provider: i,
      prefix: "",
      name: a
    };
    return ps(s, r) ? s : null;
  }
  return null;
}, ps = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function gk(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function Hc(e, t) {
  const r = gk(e, t);
  for (const i in uk) i in la ? i in e && !(i in r) && (r[i] = la[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function mk(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(o) {
    if (r[o]) return n[o] = [];
    if (!(o in n)) {
      n[o] = null;
      const s = i[o] && i[o].parent, c = s && a(s);
      c && (n[o] = [s].concat(c));
    }
    return n[o];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function jc(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function o(s) {
    a = Hc(i[s] || n[s], a);
  }
  return o(t), r.forEach(o), Hc(e, a);
}
function yk(e, t) {
  if (e.icons[t]) return jc(e, t, []);
  const r = mk(e, [t])[t];
  return r ? jc(e, t, r) : null;
}
const xk = /(-?[0-9.]*[0-9]+[0-9.]*)/g, bk = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function Yc(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(xk);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), o = bk.test(a);
  for (; ; ) {
    if (o) {
      const s = parseFloat(a);
      isNaN(s) ? n.push(a) : n.push(Math.ceil(s * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    o = !o;
  }
}
function Ck(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const o = e.indexOf(">", a);
    if (o === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(o + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function _k(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function wk(e, t, r) {
  const i = Ck(e);
  return _k(i.defs, t + i.content + r);
}
const kk = (e) => e === "unset" || e === "undefined" || e === "none";
function vk(e, t) {
  const r = {
    ...Up,
    ...e
  }, i = {
    ...pk,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const y = [], x = m.hFlip, b = m.vFlip;
    let _ = m.rotate;
    x ? b ? _ += 2 : (y.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), y.push("scale(-1 1)"), n.top = n.left = 0) : b && (y.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), y.push("scale(1 -1)"), n.top = n.left = 0);
    let k;
    switch (_ < 0 && (_ -= Math.floor(_ / 4) * 4), _ = _ % 4, _) {
      case 1:
        k = n.height / 2 + n.top, y.unshift("rotate(90 " + k.toString() + " " + k.toString() + ")");
        break;
      case 2:
        y.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        k = n.width / 2 + n.left, y.unshift("rotate(-90 " + k.toString() + " " + k.toString() + ")");
        break;
    }
    _ % 2 === 1 && (n.left !== n.top && (k = n.left, n.left = n.top, n.top = k), n.width !== n.height && (k = n.width, n.width = n.height, n.height = k)), y.length && (a = wk(a, '<g transform="' + y.join(" ") + '">', "</g>"));
  });
  const o = i.width, s = i.height, c = n.width, l = n.height;
  let h, u;
  o === null ? (u = s === null ? "1em" : s === "auto" ? l : s, h = Yc(u, c / l)) : (h = o === "auto" ? c : o, u = s === null ? Yc(h, l / c) : s === "auto" ? l : s);
  const f = {}, p = (m, y) => {
    kk(y) || (f[m] = y.toString());
  };
  p("width", h), p("height", u);
  const g = [
    n.left,
    n.top,
    c,
    l
  ];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const Sk = /\sid="(\S+)"/g, Tk = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let Bk = 0;
function Lk(e, t = Tk) {
  const r = [];
  let i;
  for (; i = Sk.exec(e); ) r.push(i[1]);
  if (!r.length) return e;
  const n = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return r.forEach((a) => {
    const o = typeof t == "function" ? t(a) : t + (Bk++).toString(), s = a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + o + n + "$3");
  }), e = e.replace(new RegExp(n, "g"), ""), e;
}
function Ak(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function sl() {
  return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null };
}
var wr = sl();
function Gp(e) {
  wr = e;
}
var Fi = { exec: () => null };
function dt(e, t = "") {
  let r = typeof e == "string" ? e : e.source, i = { replace: (n, a) => {
    let o = typeof a == "string" ? a : a.source;
    return o = o.replace(Gt.caret, "$1"), r = r.replace(n, o), i;
  }, getRegex: () => new RegExp(r, t) };
  return i;
}
var Gt = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceTabs: /^\t+/, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] /, listReplaceTask: /^\[[ xX]\] +/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`), htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i") }, Mk = /^(?:[ \t]*(?:\n|$))+/, $k = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, Ek = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, tn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Fk = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ol = /(?:[*+-]|\d{1,9}[.)])/, Xp = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, Vp = dt(Xp).replace(/bull/g, ol).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Ok = dt(Xp).replace(/bull/g, ol).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), ll = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Dk = /^[^\n]+/, cl = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, Rk = dt(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", cl).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ik = dt(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ol).getRegex(), Ra = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", hl = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Pk = dt("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", hl).replace("tag", Ra).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Zp = dt(ll).replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex(), Nk = dt(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Zp).getRegex(), ul = { blockquote: Nk, code: $k, def: Rk, fences: Ek, heading: Fk, hr: tn, html: Pk, lheading: Vp, list: Ik, newline: Mk, paragraph: Zp, table: Fi, text: Dk }, Uc = dt("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex(), zk = { ...ul, lheading: Ok, table: Uc, paragraph: dt(ll).replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Uc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ra).getRegex() }, Wk = { ...ul, html: dt(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", hl).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: Fi, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: dt(ll).replace("hr", tn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Vp).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }, qk = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Hk = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Kp = /^( {2,}|\\)\n(?!\s*$)/, jk = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ia = /[\p{P}\p{S}]/u, fl = /[\s\p{P}\p{S}]/u, Qp = /[^\s\p{P}\p{S}]/u, Yk = dt(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, fl).getRegex(), Jp = /(?!~)[\p{P}\p{S}]/u, Uk = /(?!~)[\s\p{P}\p{S}]/u, Gk = /(?:[^\s\p{P}\p{S}]|~)/u, Xk = /\[[^\[\]]*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)|`[^`]*?`|<(?! )[^<>]*?>/g, td = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Vk = dt(td, "u").replace(/punct/g, Ia).getRegex(), Zk = dt(td, "u").replace(/punct/g, Jp).getRegex(), ed = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Kk = dt(ed, "gu").replace(/notPunctSpace/g, Qp).replace(/punctSpace/g, fl).replace(/punct/g, Ia).getRegex(), Qk = dt(ed, "gu").replace(/notPunctSpace/g, Gk).replace(/punctSpace/g, Uk).replace(/punct/g, Jp).getRegex(), Jk = dt("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Qp).replace(/punctSpace/g, fl).replace(/punct/g, Ia).getRegex(), tv = dt(/\\(punct)/, "gu").replace(/punct/g, Ia).getRegex(), ev = dt(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), rv = dt(hl).replace("(?:-->|$)", "-->").getRegex(), iv = dt("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", rv).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ca = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`[^`]*`|[^\[\]\\`])*?/, nv = dt(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", ca).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), rd = dt(/^!?\[(label)\]\[(ref)\]/).replace("label", ca).replace("ref", cl).getRegex(), id = dt(/^!?\[(ref)\](?:\[\])?/).replace("ref", cl).getRegex(), av = dt("reflink|nolink(?!\\()", "g").replace("reflink", rd).replace("nolink", id).getRegex(), pl = { _backpedal: Fi, anyPunctuation: tv, autolink: ev, blockSkip: Xk, br: Kp, code: Hk, del: Fi, emStrongLDelim: Vk, emStrongRDelimAst: Kk, emStrongRDelimUnd: Jk, escape: qk, link: nv, nolink: id, punctuation: Yk, reflink: rd, reflinkSearch: av, tag: iv, text: jk, url: Fi }, sv = { ...pl, link: dt(/^!?\[(label)\]\((.*?)\)/).replace("label", ca).getRegex(), reflink: dt(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ca).getRegex() }, eo = { ...pl, emStrongRDelimAst: Qk, emStrongLDelim: Zk, url: dt(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/ }, ov = { ...eo, br: dt(Kp).replace("{2,}", "*").getRegex(), text: dt(eo.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }, mn = { normal: ul, gfm: zk, pedantic: Wk }, gi = { normal: pl, gfm: eo, breaks: ov, pedantic: sv }, lv = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, Gc = (e) => lv[e];
function xe(e, t) {
  if (t) {
    if (Gt.escapeTest.test(e)) return e.replace(Gt.escapeReplace, Gc);
  } else if (Gt.escapeTestNoEncode.test(e)) return e.replace(Gt.escapeReplaceNoEncode, Gc);
  return e;
}
function Xc(e) {
  try {
    e = encodeURI(e).replace(Gt.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function Vc(e, t) {
  var a;
  let r = e.replace(Gt.findPipe, (o, s, c) => {
    let l = !1, h = s;
    for (; --h >= 0 && c[h] === "\\"; ) l = !l;
    return l ? "|" : " |";
  }), i = r.split(Gt.splitPipe), n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !((a = i.at(-1)) != null && a.trim()) && i.pop(), t) if (i.length > t) i.splice(t);
  else for (; i.length < t; ) i.push("");
  for (; n < i.length; n++) i[n] = i[n].trim().replace(Gt.slashPipe, "|");
  return i;
}
function mi(e, t, r) {
  let i = e.length;
  if (i === 0) return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function cv(e, t) {
  if (e.indexOf(t[1]) === -1) return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++) if (e[i] === "\\") i++;
  else if (e[i] === t[0]) r++;
  else if (e[i] === t[1] && (r--, r < 0)) return i;
  return r > 0 ? -2 : -1;
}
function Zc(e, t, r, i, n) {
  let a = t.href, o = t.title || null, s = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  let c = { type: e[0].charAt(0) === "!" ? "image" : "link", raw: r, href: a, title: o, text: s, tokens: i.inlineTokens(s) };
  return i.state.inLink = !1, c;
}
function hv(e, t, r) {
  let i = e.match(r.other.indentCodeCompensation);
  if (i === null) return t;
  let n = i[1];
  return t.split(`
`).map((a) => {
    let o = a.match(r.other.beginningSpace);
    if (o === null) return a;
    let [s] = o;
    return s.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var ha = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "rules");
    mt(this, "lexer");
    this.options = t || wr;
  }
  space(t) {
    let r = this.rules.block.newline.exec(t);
    if (r && r[0].length > 0) return { type: "space", raw: r[0] };
  }
  code(t) {
    let r = this.rules.block.code.exec(t);
    if (r) {
      let i = r[0].replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: r[0], codeBlockStyle: "indented", text: this.options.pedantic ? i : mi(i, `
`) };
    }
  }
  fences(t) {
    let r = this.rules.block.fences.exec(t);
    if (r) {
      let i = r[0], n = hv(i, r[3] || "", this.rules);
      return { type: "code", raw: i, lang: r[2] ? r[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : r[2], text: n };
    }
  }
  heading(t) {
    let r = this.rules.block.heading.exec(t);
    if (r) {
      let i = r[2].trim();
      if (this.rules.other.endingHash.test(i)) {
        let n = mi(i, "#");
        (this.options.pedantic || !n || this.rules.other.endingSpaceChar.test(n)) && (i = n.trim());
      }
      return { type: "heading", raw: r[0], depth: r[1].length, text: i, tokens: this.lexer.inline(i) };
    }
  }
  hr(t) {
    let r = this.rules.block.hr.exec(t);
    if (r) return { type: "hr", raw: mi(r[0], `
`) };
  }
  blockquote(t) {
    let r = this.rules.block.blockquote.exec(t);
    if (r) {
      let i = mi(r[0], `
`).split(`
`), n = "", a = "", o = [];
      for (; i.length > 0; ) {
        let s = !1, c = [], l;
        for (l = 0; l < i.length; l++) if (this.rules.other.blockquoteStart.test(i[l])) c.push(i[l]), s = !0;
        else if (!s) c.push(i[l]);
        else break;
        i = i.slice(l);
        let h = c.join(`
`), u = h.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        n = n ? `${n}
${h}` : h, a = a ? `${a}
${u}` : u;
        let f = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(u, o, !0), this.lexer.state.top = f, i.length === 0) break;
        let p = o.at(-1);
        if ((p == null ? void 0 : p.type) === "code") break;
        if ((p == null ? void 0 : p.type) === "blockquote") {
          let g = p, m = g.raw + `
` + i.join(`
`), y = this.blockquote(m);
          o[o.length - 1] = y, n = n.substring(0, n.length - g.raw.length) + y.raw, a = a.substring(0, a.length - g.text.length) + y.text;
          break;
        } else if ((p == null ? void 0 : p.type) === "list") {
          let g = p, m = g.raw + `
` + i.join(`
`), y = this.list(m);
          o[o.length - 1] = y, n = n.substring(0, n.length - p.raw.length) + y.raw, a = a.substring(0, a.length - g.raw.length) + y.raw, i = m.substring(o.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: n, tokens: o, text: a };
    }
  }
  list(t) {
    let r = this.rules.block.list.exec(t);
    if (r) {
      let i = r[1].trim(), n = i.length > 1, a = { type: "list", raw: "", ordered: n, start: n ? +i.slice(0, -1) : "", loose: !1, items: [] };
      i = n ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = n ? i : "[*+-]");
      let o = this.rules.other.listItemRegex(i), s = !1;
      for (; t; ) {
        let l = !1, h = "", u = "";
        if (!(r = o.exec(t)) || this.rules.block.hr.test(t)) break;
        h = r[0], t = t.substring(h.length);
        let f = r[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (b) => " ".repeat(3 * b.length)), p = t.split(`
`, 1)[0], g = !f.trim(), m = 0;
        if (this.options.pedantic ? (m = 2, u = f.trimStart()) : g ? m = r[1].length + 1 : (m = r[2].search(this.rules.other.nonSpaceChar), m = m > 4 ? 1 : m, u = f.slice(m), m += r[1].length), g && this.rules.other.blankLine.test(p) && (h += p + `
`, t = t.substring(p.length + 1), l = !0), !l) {
          let b = this.rules.other.nextBulletRegex(m), _ = this.rules.other.hrRegex(m), k = this.rules.other.fencesBeginRegex(m), w = this.rules.other.headingBeginRegex(m), C = this.rules.other.htmlBeginRegex(m);
          for (; t; ) {
            let S = t.split(`
`, 1)[0], O;
            if (p = S, this.options.pedantic ? (p = p.replace(this.rules.other.listReplaceNesting, "  "), O = p) : O = p.replace(this.rules.other.tabCharGlobal, "    "), k.test(p) || w.test(p) || C.test(p) || b.test(p) || _.test(p)) break;
            if (O.search(this.rules.other.nonSpaceChar) >= m || !p.trim()) u += `
` + O.slice(m);
            else {
              if (g || f.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || k.test(f) || w.test(f) || _.test(f)) break;
              u += `
` + p;
            }
            !g && !p.trim() && (g = !0), h += S + `
`, t = t.substring(S.length + 1), f = O.slice(m);
          }
        }
        a.loose || (s ? a.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (s = !0));
        let y = null, x;
        this.options.gfm && (y = this.rules.other.listIsTask.exec(u), y && (x = y[0] !== "[ ] ", u = u.replace(this.rules.other.listReplaceTask, ""))), a.items.push({ type: "list_item", raw: h, task: !!y, checked: x, loose: !1, text: u, tokens: [] }), a.raw += h;
      }
      let c = a.items.at(-1);
      if (c) c.raw = c.raw.trimEnd(), c.text = c.text.trimEnd();
      else return;
      a.raw = a.raw.trimEnd();
      for (let l = 0; l < a.items.length; l++) if (this.lexer.state.top = !1, a.items[l].tokens = this.lexer.blockTokens(a.items[l].text, []), !a.loose) {
        let h = a.items[l].tokens.filter((f) => f.type === "space"), u = h.length > 0 && h.some((f) => this.rules.other.anyLine.test(f.raw));
        a.loose = u;
      }
      if (a.loose) for (let l = 0; l < a.items.length; l++) a.items[l].loose = !0;
      return a;
    }
  }
  html(t) {
    let r = this.rules.block.html.exec(t);
    if (r) return { type: "html", block: !0, raw: r[0], pre: r[1] === "pre" || r[1] === "script" || r[1] === "style", text: r[0] };
  }
  def(t) {
    let r = this.rules.block.def.exec(t);
    if (r) {
      let i = r[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = r[2] ? r[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = r[3] ? r[3].substring(1, r[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : r[3];
      return { type: "def", tag: i, raw: r[0], href: n, title: a };
    }
  }
  table(t) {
    var s;
    let r = this.rules.block.table.exec(t);
    if (!r || !this.rules.other.tableDelimiter.test(r[2])) return;
    let i = Vc(r[1]), n = r[2].replace(this.rules.other.tableAlignChars, "").split("|"), a = (s = r[3]) != null && s.trim() ? r[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], o = { type: "table", raw: r[0], header: [], align: [], rows: [] };
    if (i.length === n.length) {
      for (let c of n) this.rules.other.tableAlignRight.test(c) ? o.align.push("right") : this.rules.other.tableAlignCenter.test(c) ? o.align.push("center") : this.rules.other.tableAlignLeft.test(c) ? o.align.push("left") : o.align.push(null);
      for (let c = 0; c < i.length; c++) o.header.push({ text: i[c], tokens: this.lexer.inline(i[c]), header: !0, align: o.align[c] });
      for (let c of a) o.rows.push(Vc(c, o.header.length).map((l, h) => ({ text: l, tokens: this.lexer.inline(l), header: !1, align: o.align[h] })));
      return o;
    }
  }
  lheading(t) {
    let r = this.rules.block.lheading.exec(t);
    if (r) return { type: "heading", raw: r[0], depth: r[2].charAt(0) === "=" ? 1 : 2, text: r[1], tokens: this.lexer.inline(r[1]) };
  }
  paragraph(t) {
    let r = this.rules.block.paragraph.exec(t);
    if (r) {
      let i = r[1].charAt(r[1].length - 1) === `
` ? r[1].slice(0, -1) : r[1];
      return { type: "paragraph", raw: r[0], text: i, tokens: this.lexer.inline(i) };
    }
  }
  text(t) {
    let r = this.rules.block.text.exec(t);
    if (r) return { type: "text", raw: r[0], text: r[0], tokens: this.lexer.inline(r[0]) };
  }
  escape(t) {
    let r = this.rules.inline.escape.exec(t);
    if (r) return { type: "escape", raw: r[0], text: r[1] };
  }
  tag(t) {
    let r = this.rules.inline.tag.exec(t);
    if (r) return !this.lexer.state.inLink && this.rules.other.startATag.test(r[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(r[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(r[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(r[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: r[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: r[0] };
  }
  link(t) {
    let r = this.rules.inline.link.exec(t);
    if (r) {
      let i = r[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(i)) {
        if (!this.rules.other.endAngleBracket.test(i)) return;
        let o = mi(i.slice(0, -1), "\\");
        if ((i.length - o.length) % 2 === 0) return;
      } else {
        let o = cv(r[2], "()");
        if (o === -2) return;
        if (o > -1) {
          let s = (r[0].indexOf("!") === 0 ? 5 : 4) + r[1].length + o;
          r[2] = r[2].substring(0, o), r[0] = r[0].substring(0, s).trim(), r[3] = "";
        }
      }
      let n = r[2], a = "";
      if (this.options.pedantic) {
        let o = this.rules.other.pedanticHrefTitle.exec(n);
        o && (n = o[1], a = o[3]);
      } else a = r[3] ? r[3].slice(1, -1) : "";
      return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(i) ? n = n.slice(1) : n = n.slice(1, -1)), Zc(r, { href: n && n.replace(this.rules.inline.anyPunctuation, "$1"), title: a && a.replace(this.rules.inline.anyPunctuation, "$1") }, r[0], this.lexer, this.rules);
    }
  }
  reflink(t, r) {
    let i;
    if ((i = this.rules.inline.reflink.exec(t)) || (i = this.rules.inline.nolink.exec(t))) {
      let n = (i[2] || i[1]).replace(this.rules.other.multipleSpaceGlobal, " "), a = r[n.toLowerCase()];
      if (!a) {
        let o = i[0].charAt(0);
        return { type: "text", raw: o, text: o };
      }
      return Zc(i, a, i[0], this.lexer, this.rules);
    }
  }
  emStrong(t, r, i = "") {
    let n = this.rules.inline.emStrongLDelim.exec(t);
    if (!(!n || n[3] && i.match(this.rules.other.unicodeAlphaNumeric)) && (!(n[1] || n[2]) || !i || this.rules.inline.punctuation.exec(i))) {
      let a = [...n[0]].length - 1, o, s, c = a, l = 0, h = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, r = r.slice(-1 * t.length + a); (n = h.exec(r)) != null; ) {
        if (o = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !o) continue;
        if (s = [...o].length, n[3] || n[4]) {
          c += s;
          continue;
        } else if ((n[5] || n[6]) && a % 3 && !((a + s) % 3)) {
          l += s;
          continue;
        }
        if (c -= s, c > 0) continue;
        s = Math.min(s, s + c + l);
        let u = [...n[0]][0].length, f = t.slice(0, a + n.index + u + s);
        if (Math.min(a, s) % 2) {
          let g = f.slice(1, -1);
          return { type: "em", raw: f, text: g, tokens: this.lexer.inlineTokens(g) };
        }
        let p = f.slice(2, -2);
        return { type: "strong", raw: f, text: p, tokens: this.lexer.inlineTokens(p) };
      }
    }
  }
  codespan(t) {
    let r = this.rules.inline.code.exec(t);
    if (r) {
      let i = r[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(i), a = this.rules.other.startingSpaceChar.test(i) && this.rules.other.endingSpaceChar.test(i);
      return n && a && (i = i.substring(1, i.length - 1)), { type: "codespan", raw: r[0], text: i };
    }
  }
  br(t) {
    let r = this.rules.inline.br.exec(t);
    if (r) return { type: "br", raw: r[0] };
  }
  del(t) {
    let r = this.rules.inline.del.exec(t);
    if (r) return { type: "del", raw: r[0], text: r[2], tokens: this.lexer.inlineTokens(r[2]) };
  }
  autolink(t) {
    let r = this.rules.inline.autolink.exec(t);
    if (r) {
      let i, n;
      return r[2] === "@" ? (i = r[1], n = "mailto:" + i) : (i = r[1], n = i), { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  url(t) {
    var i;
    let r;
    if (r = this.rules.inline.url.exec(t)) {
      let n, a;
      if (r[2] === "@") n = r[0], a = "mailto:" + n;
      else {
        let o;
        do
          o = r[0], r[0] = ((i = this.rules.inline._backpedal.exec(r[0])) == null ? void 0 : i[0]) ?? "";
        while (o !== r[0]);
        n = r[0], r[1] === "www." ? a = "http://" + r[0] : a = r[0];
      }
      return { type: "link", raw: r[0], text: n, href: a, tokens: [{ type: "text", raw: n, text: n }] };
    }
  }
  inlineText(t) {
    let r = this.rules.inline.text.exec(t);
    if (r) {
      let i = this.lexer.state.inRawBlock;
      return { type: "text", raw: r[0], text: r[0], escaped: i };
    }
  }
}, Oe = class ro {
  constructor(t) {
    mt(this, "tokens");
    mt(this, "options");
    mt(this, "state");
    mt(this, "tokenizer");
    mt(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || wr, this.options.tokenizer = this.options.tokenizer || new ha(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 };
    let r = { other: Gt, block: mn.normal, inline: gi.normal };
    this.options.pedantic ? (r.block = mn.pedantic, r.inline = gi.pedantic) : this.options.gfm && (r.block = mn.gfm, this.options.breaks ? r.inline = gi.breaks : r.inline = gi.gfm), this.tokenizer.rules = r;
  }
  static get rules() {
    return { block: mn, inline: gi };
  }
  static lex(t, r) {
    return new ro(r).lex(t);
  }
  static lexInline(t, r) {
    return new ro(r).inlineTokens(t);
  }
  lex(t) {
    t = t.replace(Gt.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      let i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    var n, a, o;
    for (this.options.pedantic && (t = t.replace(Gt.tabCharGlobal, "    ").replace(Gt.spaceLine, "")); t; ) {
      let s;
      if ((a = (n = this.options.extensions) == null ? void 0 : n.block) != null && a.some((l) => (s = l.call({ lexer: this }, t, r)) ? (t = t.substring(s.raw.length), r.push(s), !0) : !1)) continue;
      if (s = this.tokenizer.space(t)) {
        t = t.substring(s.raw.length);
        let l = r.at(-1);
        s.raw.length === 1 && l !== void 0 ? l.raw += `
` : r.push(s);
        continue;
      }
      if (s = this.tokenizer.code(t)) {
        t = t.substring(s.raw.length);
        let l = r.at(-1);
        (l == null ? void 0 : l.type) === "paragraph" || (l == null ? void 0 : l.type) === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + s.raw, l.text += `
` + s.text, this.inlineQueue.at(-1).src = l.text) : r.push(s);
        continue;
      }
      if (s = this.tokenizer.fences(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.heading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.hr(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.blockquote(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.list(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.html(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.def(t)) {
        t = t.substring(s.raw.length);
        let l = r.at(-1);
        (l == null ? void 0 : l.type) === "paragraph" || (l == null ? void 0 : l.type) === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + s.raw, l.text += `
` + s.raw, this.inlineQueue.at(-1).src = l.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = { href: s.href, title: s.title }, r.push(s));
        continue;
      }
      if (s = this.tokenizer.table(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.lheading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      let c = t;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let l = 1 / 0, h = t.slice(1), u;
        this.options.extensions.startBlock.forEach((f) => {
          u = f.call({ lexer: this }, h), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
        }), l < 1 / 0 && l >= 0 && (c = t.substring(0, l + 1));
      }
      if (this.state.top && (s = this.tokenizer.paragraph(c))) {
        let l = r.at(-1);
        i && (l == null ? void 0 : l.type) === "paragraph" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + s.raw, l.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : r.push(s), i = c.length !== t.length, t = t.substring(s.raw.length);
        continue;
      }
      if (s = this.tokenizer.text(t)) {
        t = t.substring(s.raw.length);
        let l = r.at(-1);
        (l == null ? void 0 : l.type) === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + s.raw, l.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : r.push(s);
        continue;
      }
      if (t) {
        let l = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(l);
          break;
        } else throw new Error(l);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  inlineTokens(t, r = []) {
    var s, c, l, h, u;
    let i = t, n = null;
    if (this.tokens.links) {
      let f = Object.keys(this.tokens.links);
      if (f.length > 0) for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; ) f.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; ) i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; ) i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    i = ((c = (s = this.options.hooks) == null ? void 0 : s.emStrongMask) == null ? void 0 : c.call({ lexer: this }, i)) ?? i;
    let a = !1, o = "";
    for (; t; ) {
      a || (o = ""), a = !1;
      let f;
      if ((h = (l = this.options.extensions) == null ? void 0 : l.inline) != null && h.some((g) => (f = g.call({ lexer: this }, t, r)) ? (t = t.substring(f.raw.length), r.push(f), !0) : !1)) continue;
      if (f = this.tokenizer.escape(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.tag(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.link(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(f.raw.length);
        let g = r.at(-1);
        f.type === "text" && (g == null ? void 0 : g.type) === "text" ? (g.raw += f.raw, g.text += f.text) : r.push(f);
        continue;
      }
      if (f = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.codespan(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.br(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.del(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (f = this.tokenizer.autolink(t)) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      if (!this.state.inLink && (f = this.tokenizer.url(t))) {
        t = t.substring(f.raw.length), r.push(f);
        continue;
      }
      let p = t;
      if ((u = this.options.extensions) != null && u.startInline) {
        let g = 1 / 0, m = t.slice(1), y;
        this.options.extensions.startInline.forEach((x) => {
          y = x.call({ lexer: this }, m), typeof y == "number" && y >= 0 && (g = Math.min(g, y));
        }), g < 1 / 0 && g >= 0 && (p = t.substring(0, g + 1));
      }
      if (f = this.tokenizer.inlineText(p)) {
        t = t.substring(f.raw.length), f.raw.slice(-1) !== "_" && (o = f.raw.slice(-1)), a = !0;
        let g = r.at(-1);
        (g == null ? void 0 : g.type) === "text" ? (g.raw += f.raw, g.text += f.text) : r.push(f);
        continue;
      }
      if (t) {
        let g = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(g);
          break;
        } else throw new Error(g);
      }
    }
    return r;
  }
}, ua = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "parser");
    this.options = t || wr;
  }
  space(t) {
    return "";
  }
  code({ text: t, lang: r, escaped: i }) {
    var o;
    let n = (o = (r || "").match(Gt.notSpaceStart)) == null ? void 0 : o[0], a = t.replace(Gt.endingNewline, "") + `
`;
    return n ? '<pre><code class="language-' + xe(n) + '">' + (i ? a : xe(a, !0)) + `</code></pre>
` : "<pre><code>" + (i ? a : xe(a, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: t }) {
    return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
  }
  html({ text: t }) {
    return t;
  }
  def(t) {
    return "";
  }
  heading({ tokens: t, depth: r }) {
    return `<h${r}>${this.parser.parseInline(t)}</h${r}>
`;
  }
  hr(t) {
    return `<hr>
`;
  }
  list(t) {
    let r = t.ordered, i = t.start, n = "";
    for (let s = 0; s < t.items.length; s++) {
      let c = t.items[s];
      n += this.listitem(c);
    }
    let a = r ? "ol" : "ul", o = r && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + a + o + `>
` + n + "</" + a + `>
`;
  }
  listitem(t) {
    var i;
    let r = "";
    if (t.task) {
      let n = this.checkbox({ checked: !!t.checked });
      t.loose ? ((i = t.tokens[0]) == null ? void 0 : i.type) === "paragraph" ? (t.tokens[0].text = n + " " + t.tokens[0].text, t.tokens[0].tokens && t.tokens[0].tokens.length > 0 && t.tokens[0].tokens[0].type === "text" && (t.tokens[0].tokens[0].text = n + " " + xe(t.tokens[0].tokens[0].text), t.tokens[0].tokens[0].escaped = !0)) : t.tokens.unshift({ type: "text", raw: n + " ", text: n + " ", escaped: !0 }) : r += n + " ";
    }
    return r += this.parser.parse(t.tokens, !!t.loose), `<li>${r}</li>
`;
  }
  checkbox({ checked: t }) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: t }) {
    return `<p>${this.parser.parseInline(t)}</p>
`;
  }
  table(t) {
    let r = "", i = "";
    for (let a = 0; a < t.header.length; a++) i += this.tablecell(t.header[a]);
    r += this.tablerow({ text: i });
    let n = "";
    for (let a = 0; a < t.rows.length; a++) {
      let o = t.rows[a];
      i = "";
      for (let s = 0; s < o.length; s++) i += this.tablecell(o[s]);
      n += this.tablerow({ text: i });
    }
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + r + `</thead>
` + n + `</table>
`;
  }
  tablerow({ text: t }) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t) {
    let r = this.parser.parseInline(t.tokens), i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + r + `</${i}>
`;
  }
  strong({ tokens: t }) {
    return `<strong>${this.parser.parseInline(t)}</strong>`;
  }
  em({ tokens: t }) {
    return `<em>${this.parser.parseInline(t)}</em>`;
  }
  codespan({ text: t }) {
    return `<code>${xe(t, !0)}</code>`;
  }
  br(t) {
    return "<br>";
  }
  del({ tokens: t }) {
    return `<del>${this.parser.parseInline(t)}</del>`;
  }
  link({ href: t, title: r, tokens: i }) {
    let n = this.parser.parseInline(i), a = Xc(t);
    if (a === null) return n;
    t = a;
    let o = '<a href="' + t + '"';
    return r && (o += ' title="' + xe(r) + '"'), o += ">" + n + "</a>", o;
  }
  image({ href: t, title: r, text: i, tokens: n }) {
    n && (i = this.parser.parseInline(n, this.parser.textRenderer));
    let a = Xc(t);
    if (a === null) return xe(i);
    t = a;
    let o = `<img src="${t}" alt="${i}"`;
    return r && (o += ` title="${xe(r)}"`), o += ">", o;
  }
  text(t) {
    return "tokens" in t && t.tokens ? this.parser.parseInline(t.tokens) : "escaped" in t && t.escaped ? t.text : xe(t.text);
  }
}, dl = class {
  strong({ text: t }) {
    return t;
  }
  em({ text: t }) {
    return t;
  }
  codespan({ text: t }) {
    return t;
  }
  del({ text: t }) {
    return t;
  }
  html({ text: t }) {
    return t;
  }
  text({ text: t }) {
    return t;
  }
  link({ text: t }) {
    return "" + t;
  }
  image({ text: t }) {
    return "" + t;
  }
  br() {
    return "";
  }
}, De = class io {
  constructor(t) {
    mt(this, "options");
    mt(this, "renderer");
    mt(this, "textRenderer");
    this.options = t || wr, this.options.renderer = this.options.renderer || new ua(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new dl();
  }
  static parse(t, r) {
    return new io(r).parse(t);
  }
  static parseInline(t, r) {
    return new io(r).parseInline(t);
  }
  parse(t, r = !0) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      let s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        let l = s, h = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (h !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(l.type)) {
          i += h || "";
          continue;
        }
      }
      let c = s;
      switch (c.type) {
        case "space": {
          i += this.renderer.space(c);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(c);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(c);
          continue;
        }
        case "code": {
          i += this.renderer.code(c);
          continue;
        }
        case "table": {
          i += this.renderer.table(c);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(c);
          continue;
        }
        case "list": {
          i += this.renderer.list(c);
          continue;
        }
        case "html": {
          i += this.renderer.html(c);
          continue;
        }
        case "def": {
          i += this.renderer.def(c);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(c);
          continue;
        }
        case "text": {
          let l = c, h = this.renderer.text(l);
          for (; o + 1 < t.length && t[o + 1].type === "text"; ) l = t[++o], h += `
` + this.renderer.text(l);
          r ? i += this.renderer.paragraph({ type: "paragraph", raw: h, text: h, tokens: [{ type: "text", raw: h, text: h, escaped: !0 }] }) : i += h;
          continue;
        }
        default: {
          let l = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent) return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return i;
  }
  parseInline(t, r = this.renderer) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      let s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        let l = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          i += l || "";
          continue;
        }
      }
      let c = s;
      switch (c.type) {
        case "escape": {
          i += r.text(c);
          break;
        }
        case "html": {
          i += r.html(c);
          break;
        }
        case "link": {
          i += r.link(c);
          break;
        }
        case "image": {
          i += r.image(c);
          break;
        }
        case "strong": {
          i += r.strong(c);
          break;
        }
        case "em": {
          i += r.em(c);
          break;
        }
        case "codespan": {
          i += r.codespan(c);
          break;
        }
        case "br": {
          i += r.br(c);
          break;
        }
        case "del": {
          i += r.del(c);
          break;
        }
        case "text": {
          i += r.text(c);
          break;
        }
        default: {
          let l = 'Token with "' + c.type + '" type was not found.';
          if (this.options.silent) return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return i;
  }
}, wn, vi = (wn = class {
  constructor(t) {
    mt(this, "options");
    mt(this, "block");
    this.options = t || wr;
  }
  preprocess(t) {
    return t;
  }
  postprocess(t) {
    return t;
  }
  processAllTokens(t) {
    return t;
  }
  emStrongMask(t) {
    return t;
  }
  provideLexer() {
    return this.block ? Oe.lex : Oe.lexInline;
  }
  provideParser() {
    return this.block ? De.parse : De.parseInline;
  }
}, mt(wn, "passThroughHooks", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"])), mt(wn, "passThroughHooksRespectAsync", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"])), wn), uv = class {
  constructor(...t) {
    mt(this, "defaults", sl());
    mt(this, "options", this.setOptions);
    mt(this, "parse", this.parseMarkdown(!0));
    mt(this, "parseInline", this.parseMarkdown(!1));
    mt(this, "Parser", De);
    mt(this, "Renderer", ua);
    mt(this, "TextRenderer", dl);
    mt(this, "Lexer", Oe);
    mt(this, "Tokenizer", ha);
    mt(this, "Hooks", vi);
    this.use(...t);
  }
  walkTokens(t, r) {
    var n, a;
    let i = [];
    for (let o of t) switch (i = i.concat(r.call(this, o)), o.type) {
      case "table": {
        let s = o;
        for (let c of s.header) i = i.concat(this.walkTokens(c.tokens, r));
        for (let c of s.rows) for (let l of c) i = i.concat(this.walkTokens(l.tokens, r));
        break;
      }
      case "list": {
        let s = o;
        i = i.concat(this.walkTokens(s.items, r));
        break;
      }
      default: {
        let s = o;
        (a = (n = this.defaults.extensions) == null ? void 0 : n.childTokens) != null && a[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((c) => {
          let l = s[c].flat(1 / 0);
          i = i.concat(this.walkTokens(l, r));
        }) : s.tokens && (i = i.concat(this.walkTokens(s.tokens, r)));
      }
    }
    return i;
  }
  use(...t) {
    let r = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((i) => {
      let n = { ...i };
      if (n.async = this.defaults.async || n.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name) throw new Error("extension name required");
        if ("renderer" in a) {
          let o = r.renderers[a.name];
          o ? r.renderers[a.name] = function(...s) {
            let c = a.renderer.apply(this, s);
            return c === !1 && (c = o.apply(this, s)), c;
          } : r.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let o = r[a.level];
          o ? o.unshift(a.tokenizer) : r[a.level] = [a.tokenizer], a.start && (a.level === "block" ? r.startBlock ? r.startBlock.push(a.start) : r.startBlock = [a.start] : a.level === "inline" && (r.startInline ? r.startInline.push(a.start) : r.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (r.childTokens[a.name] = a.childTokens);
      }), n.extensions = r), i.renderer) {
        let a = this.defaults.renderer || new ua(this.defaults);
        for (let o in i.renderer) {
          if (!(o in a)) throw new Error(`renderer '${o}' does not exist`);
          if (["options", "parser"].includes(o)) continue;
          let s = o, c = i.renderer[s], l = a[s];
          a[s] = (...h) => {
            let u = c.apply(a, h);
            return u === !1 && (u = l.apply(a, h)), u || "";
          };
        }
        n.renderer = a;
      }
      if (i.tokenizer) {
        let a = this.defaults.tokenizer || new ha(this.defaults);
        for (let o in i.tokenizer) {
          if (!(o in a)) throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o)) continue;
          let s = o, c = i.tokenizer[s], l = a[s];
          a[s] = (...h) => {
            let u = c.apply(a, h);
            return u === !1 && (u = l.apply(a, h)), u;
          };
        }
        n.tokenizer = a;
      }
      if (i.hooks) {
        let a = this.defaults.hooks || new vi();
        for (let o in i.hooks) {
          if (!(o in a)) throw new Error(`hook '${o}' does not exist`);
          if (["options", "block"].includes(o)) continue;
          let s = o, c = i.hooks[s], l = a[s];
          vi.passThroughHooks.has(o) ? a[s] = (h) => {
            if (this.defaults.async && vi.passThroughHooksRespectAsync.has(o)) return Promise.resolve(c.call(a, h)).then((f) => l.call(a, f));
            let u = c.call(a, h);
            return l.call(a, u);
          } : a[s] = (...h) => {
            let u = c.apply(a, h);
            return u === !1 && (u = l.apply(a, h)), u;
          };
        }
        n.hooks = a;
      }
      if (i.walkTokens) {
        let a = this.defaults.walkTokens, o = i.walkTokens;
        n.walkTokens = function(s) {
          let c = [];
          return c.push(o.call(this, s)), a && (c = c.concat(a.call(this, s))), c;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, r) {
    return Oe.lex(t, r ?? this.defaults);
  }
  parser(t, r) {
    return De.parse(t, r ?? this.defaults);
  }
  parseMarkdown(t) {
    return (r, i) => {
      let n = { ...i }, a = { ...this.defaults, ...n }, o = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1) return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null) return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string") return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      a.hooks && (a.hooks.options = a, a.hooks.block = t);
      let s = a.hooks ? a.hooks.provideLexer() : t ? Oe.lex : Oe.lexInline, c = a.hooks ? a.hooks.provideParser() : t ? De.parse : De.parseInline;
      if (a.async) return Promise.resolve(a.hooks ? a.hooks.preprocess(r) : r).then((l) => s(l, a)).then((l) => a.hooks ? a.hooks.processAllTokens(l) : l).then((l) => a.walkTokens ? Promise.all(this.walkTokens(l, a.walkTokens)).then(() => l) : l).then((l) => c(l, a)).then((l) => a.hooks ? a.hooks.postprocess(l) : l).catch(o);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let l = s(r, a);
        a.hooks && (l = a.hooks.processAllTokens(l)), a.walkTokens && this.walkTokens(l, a.walkTokens);
        let h = c(l, a);
        return a.hooks && (h = a.hooks.postprocess(h)), h;
      } catch (l) {
        return o(l);
      }
    };
  }
  onError(t, r) {
    return (i) => {
      if (i.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
        let n = "<p>An error occurred:</p><pre>" + xe(i.message + "", !0) + "</pre>";
        return r ? Promise.resolve(n) : n;
      }
      if (r) return Promise.reject(i);
      throw i;
    };
  }
}, mr = new uv();
function pt(e, t) {
  return mr.parse(e, t);
}
pt.options = pt.setOptions = function(e) {
  return mr.setOptions(e), pt.defaults = mr.defaults, Gp(pt.defaults), pt;
};
pt.getDefaults = sl;
pt.defaults = wr;
pt.use = function(...e) {
  return mr.use(...e), pt.defaults = mr.defaults, Gp(pt.defaults), pt;
};
pt.walkTokens = function(e, t) {
  return mr.walkTokens(e, t);
};
pt.parseInline = mr.parseInline;
pt.Parser = De;
pt.parser = De.parse;
pt.Renderer = ua;
pt.TextRenderer = dl;
pt.Lexer = Oe;
pt.lexer = Oe.lex;
pt.Tokenizer = ha;
pt.Hooks = vi;
pt.parse = pt;
pt.options;
pt.setOptions;
pt.use;
pt.walkTokens;
pt.parseInline;
De.parse;
Oe.lex;
function nd(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(s, c) {
    var l = c.match(/\n([\t ]+|(?!\s).)/g);
    return l ? s.concat(l.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : s;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(s) {
      return s.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var o = i[0];
  return t.forEach(function(s, c) {
    var l = o.match(/(?:^|\n)( *)$/), h = l ? l[1] : "", u = s;
    typeof s == "string" && s.includes(`
`) && (u = String(s).split(`
`).map(function(f, p) {
      return p === 0 ? f : "" + h + f;
    }).join(`
`)), o += u + i[c + 1];
  }), o;
}
var fv = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, no = /* @__PURE__ */ new Map(), ad = /* @__PURE__ */ new Map(), pv = /* @__PURE__ */ d((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      ad.set(t.name, t.loader);
    else if ("icons" in t)
      no.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), sd = /* @__PURE__ */ d(async (e, t) => {
  const r = dk(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = no.get(i);
  if (!n) {
    const o = ad.get(i);
    if (!o)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await o(), prefix: i }, no.set(i, n);
    } catch (s) {
      throw F.error(s), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = yk(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), dv = /* @__PURE__ */ d(async (e) => {
  try {
    return await sd(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), en = /* @__PURE__ */ d(async (e, t, r) => {
  let i;
  try {
    i = await sd(e, t == null ? void 0 : t.fallbackPrefix);
  } catch (o) {
    F.error(o), i = fv;
  }
  const n = vk(i, t), a = Ak(Lk(n.body), {
    ...n.attributes,
    ...r
  });
  return se(a, Nt());
}, "getIconSVG");
function od(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = nd(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
d(od, "preprocessMarkdown");
function ld(e, t = {}) {
  const r = od(e, t), i = pt.lexer(r), n = [[]];
  let a = 0;
  function o(s, c = "normal") {
    s.type === "text" ? s.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: c });
      });
    }) : s.type === "strong" || s.type === "em" ? s.tokens.forEach((l) => {
      o(l, s.type);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }
  return d(o, "processNode"), i.forEach((s) => {
    var c;
    s.type === "paragraph" ? (c = s.tokens) == null || c.forEach((l) => {
      o(l);
    }) : s.type === "html" ? n[a].push({ content: s.text, type: "normal" }) : n[a].push({ content: s.raw, type: "normal" });
  }), n;
}
d(ld, "markdownToLines");
function cd(e, { markdownAutoWrap: t } = {}) {
  const r = pt.lexer(e);
  function i(n) {
    var a, o, s;
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${(a = n.tokens) == null ? void 0 : a.map(i).join("")}</strong>` : n.type === "em" ? `<em>${(o = n.tokens) == null ? void 0 : o.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${(s = n.tokens) == null ? void 0 : s.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return d(i, "output"), r.map(i).join("");
}
d(cd, "markdownToHTML");
function hd(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
d(hd, "splitTextToChars");
function ud(e, t) {
  const r = hd(t.content);
  return gl(e, [], r, t.type);
}
d(ud, "splitWordToFitWidth");
function gl(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, o = [...t, n];
  return e([{ content: o.join(""), type: i }]) ? gl(e, o, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
d(gl, "splitWordToFitWidthRecursion");
function fd(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return fa(e, t);
}
d(fd, "splitLineToFitWidth");
function fa(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, o = [...i];
  if (n !== "" && o.push({ content: n, type: "normal" }), o.push(a), t(o))
    return fa(e, t, r, o);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [s, c] = ud(t, a);
    r.push([s]), c.content && e.unshift(c);
  }
  return fa(e, t, r);
}
d(fa, "splitLineToFitWidthRecursion");
function ao(e, t) {
  t && e.attr("style", t);
}
d(ao, "applyStyle");
async function pd(e, t, r, i, n = !1, a = Nt()) {
  const o = e.append("foreignObject");
  o.attr("width", `${10 * r}px`), o.attr("height", `${10 * r}px`);
  const s = o.append("xhtml:div"), c = Gr(t.label) ? await ko(t.label.replace(ti.lineBreakRegex, `
`), a) : se(t.label, a), l = t.isNode ? "nodeLabel" : "edgeLabel", h = s.append("span");
  h.html(c), ao(h, t.labelStyle), h.attr("class", `${l} ${i}`), ao(s, t.labelStyle), s.style("display", "table-cell"), s.style("white-space", "nowrap"), s.style("line-height", "1.5"), s.style("max-width", r + "px"), s.style("text-align", "center"), s.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && s.attr("class", "labelBkg");
  let u = s.node().getBoundingClientRect();
  return u.width === r && (s.style("display", "table"), s.style("white-space", "break-spaces"), s.style("width", r + "px"), u = s.node().getBoundingClientRect()), o.node();
}
d(pd, "addHtmlSpan");
function Pa(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
d(Pa, "createTspan");
function dd(e, t, r) {
  const i = e.append("text"), n = Pa(i, 1, t);
  Na(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
d(dd, "computeWidthOfText");
function gv(e, t, r) {
  var o;
  const i = e.append("text"), n = Pa(i, 1, t);
  Na(n, [{ content: r, type: "normal" }]);
  const a = (o = n.node()) == null ? void 0 : o.getBoundingClientRect();
  return a && i.remove(), a;
}
d(gv, "computeDimensionOfText");
function gd(e, t, r, i = !1) {
  const a = t.append("g"), o = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), s = a.append("text").attr("y", "-10.1");
  let c = 0;
  for (const l of r) {
    const h = /* @__PURE__ */ d((f) => dd(a, 1.1, f) <= e, "checkWidth"), u = h(l) ? [l] : fd(l, h);
    for (const f of u) {
      const p = Pa(s, c, 1.1);
      Na(p, f), c++;
    }
  }
  if (i) {
    const l = s.node().getBBox(), h = 2;
    return o.attr("x", l.x - h).attr("y", l.y - h).attr("width", l.width + 2 * h).attr("height", l.height + 2 * h), a.node();
  } else
    return s.node();
}
d(gd, "createFormattedText");
function Na(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
d(Na, "updateTextContentAndStyles");
async function md(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, o) => (r.push(
    (async () => {
      const s = `${a}:${o}`;
      return await dv(s) ? await en(s, void 0, { class: "label-icon" }) : `<i class='${se(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
d(md, "replaceIconSubstring");
var Ze = /* @__PURE__ */ d(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: o = !0,
  width: s = 200,
  addSvgBackground: c = !1
} = {}, l) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    c
  ), a) {
    const h = cd(t, l), u = await md(_r(h), l), f = t.replace(/\\\\/g, "\\"), p = {
      isNode: o,
      label: Gr(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await pd(e, p, s, n, c, l);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = ld(h.replace("<br>", "<br/>"), l), f = gd(
      s,
      e,
      u,
      t ? c : !1
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).attr("style", p);
    } else {
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      ht(f).select("rect").attr("style", p.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function ds(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, o = Math.cos(a), s = Math.sin(a);
    for (const c of e) {
      const [l, h] = c;
      c[0] = (l - i) * o - (h - n) * s + i, c[1] = (l - i) * s + (h - n) * o + n;
    }
  }
}
function mv(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function yv(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), o = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, s = [0, 0];
  if (n) for (const l of o) ds(l, s, n);
  const c = function(l, h, u) {
    const f = [];
    for (const b of l) {
      const _ = [...b];
      mv(_[0], _[_.length - 1]) || _.push([_[0][0], _[0][1]]), _.length > 2 && f.push(_);
    }
    const p = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let _ = 0; _ < b.length - 1; _++) {
      const k = b[_], w = b[_ + 1];
      if (k[1] !== w[1]) {
        const C = Math.min(k[1], w[1]);
        g.push({ ymin: C, ymax: Math.max(k[1], w[1]), x: C === k[1] ? k[0] : w[0], islope: (w[0] - k[0]) / (w[1] - k[1]) });
      }
    }
    if (g.sort((b, _) => b.ymin < _.ymin ? -1 : b.ymin > _.ymin ? 1 : b.x < _.x ? -1 : b.x > _.x ? 1 : b.ymax === _.ymax ? 0 : (b.ymax - _.ymax) / Math.abs(b.ymax - _.ymax)), !g.length) return p;
    let m = [], y = g[0].ymin, x = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let _ = 0; _ < g.length && !(g[_].ymin > y); _++) b = _;
        g.splice(0, b + 1).forEach((_) => {
          m.push({ s: y, edge: _ });
        });
      }
      if (m = m.filter((b) => !(b.edge.ymax <= y)), m.sort((b, _) => b.edge.x === _.edge.x ? 0 : (b.edge.x - _.edge.x) / Math.abs(b.edge.x - _.edge.x)), (u !== 1 || x % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const _ = b + 1;
        if (_ >= m.length) break;
        const k = m[b].edge, w = m[_].edge;
        p.push([[Math.round(k.x), y], [Math.round(w.x), y]]);
      }
      y += u, m.forEach((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      }), x++;
    }
    return p;
  }(o, a, i);
  if (n) {
    for (const l of o) ds(l, s, -n);
    (function(l, h, u) {
      const f = [];
      l.forEach((p) => f.push(...p)), ds(f, h, u);
    })(c, s, -n);
  }
  return c;
}
function rn(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), yv(e, n, i, a || 1);
}
class ml {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = rn(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function za(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class xv extends ml {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = rn(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, o = [], s = 0.5 * i * Math.cos(a), c = 0.5 * i * Math.sin(a);
    for (const [l, h] of n) za([l, h]) && o.push([[l[0] - s, l[1] + c], [...h]], [[l[0] + s, l[1] - c], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(o, r) };
  }
}
class bv extends ml {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class Cv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = rn(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const o = n / 4;
    for (const s of t) {
      const c = za(s), l = c / n, h = Math.ceil(l) - 1, u = c - h * n, f = (s[0][0] + s[1][0]) / 2 - n / 4, p = Math.min(s[0][1], s[1][1]);
      for (let g = 0; g < h; g++) {
        const m = p + u + g * n, y = f - o + 2 * Math.random() * o, x = m - o + 2 * Math.random() * o, b = this.helper.ellipse(y, x, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class _v {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = rn(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach((o) => {
      const s = za(o), c = Math.floor(s / (i + n)), l = (s + n - c * (i + n)) / 2;
      let h = o[0], u = o[1];
      h[0] > u[0] && (h = o[1], u = o[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let p = 0; p < c; p++) {
        const g = p * (i + n), m = g + i, y = [h[0] + g * Math.cos(f) + l * Math.cos(f), h[1] + g * Math.sin(f) + l * Math.sin(f)], x = [h[0] + m * Math.cos(f) + l * Math.cos(f), h[1] + m * Math.sin(f) + l * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], r));
      }
    }), a;
  }
}
class wv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = rn(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach((a) => {
      const o = za(a), s = Math.round(o / (2 * r));
      let c = a[0], l = a[1];
      c[0] > l[0] && (c = a[1], l = a[0]);
      const h = Math.atan((l[1] - c[1]) / (l[0] - c[0]));
      for (let u = 0; u < s; u++) {
        const f = 2 * u * r, p = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [c[0] + f * Math.cos(h), c[1] + f * Math.sin(h)], y = [c[0] + p * Math.cos(h), c[1] + p * Math.sin(h)], x = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], x[0], x[1], i), ...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], i));
      }
    }), n;
  }
}
const Kt = {};
class kv {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const vv = 0, gs = 1, Kc = 2, yn = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function ms(e, t) {
  return e.type === t;
}
function yl(e) {
  const t = [], r = function(o) {
    const s = new Array();
    for (; o !== ""; ) if (o.match(/^([ \t\r\n,]+)/)) o = o.substr(RegExp.$1.length);
    else if (o.match(/^([aAcChHlLmMqQsStTvVzZ])/)) s[s.length] = { type: vv, text: RegExp.$1 }, o = o.substr(RegExp.$1.length);
    else {
      if (!o.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      s[s.length] = { type: gs, text: `${parseFloat(RegExp.$1)}` }, o = o.substr(RegExp.$1.length);
    }
    return s[s.length] = { type: Kc, text: "" }, s;
  }(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !ms(a, Kc); ) {
    let o = 0;
    const s = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return yl("M0,0" + e);
      n++, o = yn[a.text], i = a.text;
    } else ms(a, gs) ? o = yn[i] : (n++, o = yn[a.text], i = a.text);
    if (!(n + o < r.length)) throw new Error("Path data ended short");
    for (let c = n; c < n + o; c++) {
      const l = r[c];
      if (!ms(l, gs)) throw new Error("Param not a number: " + i + "," + l.text);
      s[s.length] = +l.text;
    }
    if (typeof yn[i] != "number") throw new Error("Bad segment: " + i);
    {
      const c = { key: i, data: s };
      t.push(c), n += o, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function yd(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: o, data: s } of e) switch (o) {
    case "M":
      a.push({ key: "M", data: [...s] }), [t, r] = s, [i, n] = s;
      break;
    case "m":
      t += s[0], r += s[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...s] }), [t, r] = s;
      break;
    case "l":
      t += s[0], r += s[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...s] }), t = s[4], r = s[5];
      break;
    case "c": {
      const c = s.map((l, h) => h % 2 ? l + r : l + t);
      a.push({ key: "C", data: c }), t = c[4], r = c[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...s] }), t = s[2], r = s[3];
      break;
    case "q": {
      const c = s.map((l, h) => h % 2 ? l + r : l + t);
      a.push({ key: "Q", data: c }), t = c[2], r = c[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...s] }), t = s[5], r = s[6];
      break;
    case "a":
      t += s[5], r += s[6], a.push({ key: "A", data: [s[0], s[1], s[2], s[3], s[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...s] }), t = s[0];
      break;
    case "h":
      t += s[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...s] }), r = s[0];
      break;
    case "v":
      r += s[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...s] }), t = s[2], r = s[3];
      break;
    case "s": {
      const c = s.map((l, h) => h % 2 ? l + r : l + t);
      a.push({ key: "S", data: c }), t = c[2], r = c[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...s] }), t = s[0], r = s[1];
      break;
    case "t":
      t += s[0], r += s[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function xd(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, o = 0, s = 0, c = 0;
  for (const { key: l, data: h } of e) {
    switch (l) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, o] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], s = h[2], c = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - s), f = n + (n - c)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), s = h[0], c = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let p = 0, g = 0;
        r === "Q" || r === "T" ? (p = i + (i - s), g = n + (n - c)) : (p = i, g = n);
        const m = i + 2 * (p - i) / 3, y = n + 2 * (g - n) / 3, x = u + 2 * (p - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, y, x, b, u, f] }), s = p, c = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, p, g] = h, m = i + 2 * (u - i) / 3, y = n + 2 * (f - n) / 3, x = p + 2 * (u - p) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, y, x, b, p, g] }), s = u, c = f, i = p, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), p = h[2], g = h[3], m = h[4], y = h[5], x = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, y, x, y, x] }), i = y, n = x) : (i !== y || n !== x) && (bd(i, n, y, x, u, f, p, g, m).forEach(function(b) {
          t.push({ key: "C", data: b });
        }), i = y, n = x);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = o;
    }
    r = l;
  }
  return t;
}
function yi(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function bd(e, t, r, i, n, a, o, s, c, l) {
  const h = (u = o, Math.PI * u / 180);
  var u;
  let f = [], p = 0, g = 0, m = 0, y = 0;
  if (l) [p, g, m, y] = l;
  else {
    [e, t] = yi(e, t, -h), [r, i] = yi(r, i, -h);
    const D = (e - r) / 2, M = (t - i) / 2;
    let L = D * D / (n * n) + M * M / (a * a);
    L > 1 && (L = Math.sqrt(L), n *= L, a *= L);
    const B = n * n, E = a * a, A = B * E - B * M * M - E * D * D, W = B * M * M + E * D * D, X = (s === c ? -1 : 1) * Math.sqrt(Math.abs(A / W));
    m = X * n * M / a + (e + r) / 2, y = X * -a * D / n + (t + i) / 2, p = Math.asin(parseFloat(((t - y) / a).toFixed(9))), g = Math.asin(parseFloat(((i - y) / a).toFixed(9))), e < m && (p = Math.PI - p), r < m && (g = Math.PI - g), p < 0 && (p = 2 * Math.PI + p), g < 0 && (g = 2 * Math.PI + g), c && p > g && (p -= 2 * Math.PI), !c && g > p && (g -= 2 * Math.PI);
  }
  let x = g - p;
  if (Math.abs(x) > 120 * Math.PI / 180) {
    const D = g, M = r, L = i;
    g = c && g > p ? p + 120 * Math.PI / 180 * 1 : p + 120 * Math.PI / 180 * -1, f = bd(r = m + n * Math.cos(g), i = y + a * Math.sin(g), M, L, n, a, o, 0, c, [g, D, m, y]);
  }
  x = g - p;
  const b = Math.cos(p), _ = Math.sin(p), k = Math.cos(g), w = Math.sin(g), C = Math.tan(x / 4), S = 4 / 3 * n * C, O = 4 / 3 * a * C, P = [e, t], R = [e + S * _, t - O * b], $ = [r + S * w, i - O * k], z = [r, i];
  if (R[0] = 2 * P[0] - R[0], R[1] = 2 * P[1] - R[1], l) return [R, $, z].concat(f);
  {
    f = [R, $, z].concat(f);
    const D = [];
    for (let M = 0; M < f.length; M += 3) {
      const L = yi(f[M][0], f[M][1], h), B = yi(f[M + 1][0], f[M + 1][1], h), E = yi(f[M + 2][0], f[M + 2][1], h);
      D.push([L[0], L[1], B[0], B[1], E[0], E[1]]);
    }
    return D;
  }
}
const Sv = { randOffset: function(e, t) {
  return rt(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return pa(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = _d(r, i, n);
  return so(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Ge(e, t, r, i, n, !0);
} };
function Cd(e, t, r, i, n) {
  return { type: "path", ops: Ge(e, t, r, i, n) };
}
function En(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Ge(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Ge(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? Cd(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function Tv(e, t, r, i, n) {
  return function(a, o) {
    return En(a, !0, o);
  }([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function Qc(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = xn(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : xn(r[0], 1.5 * (1 + 0.22 * t.roughness), eh(t));
    for (let a = 1; a < r.length; a++) {
      const o = r[a];
      if (o.length) {
        const s = xn(o, 1 * (1 + 0.2 * t.roughness), t), c = t.disableMultiStroke ? [] : xn(o, 1.5 * (1 + 0.22 * t.roughness), eh(t));
        for (const l of s) l.op !== "move" && i.push(l);
        for (const l of c) l.op !== "move" && n.push(l);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function _d(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let o = Math.abs(e / 2), s = Math.abs(t / 2);
  const c = 1 - r.curveFitting;
  return o += rt(o * c, r), s += rt(s * c, r), { increment: a, rx: o, ry: s };
}
function so(e, t, r, i) {
  const [n, a] = rh(i.increment, e, t, i.rx, i.ry, 1, i.increment * pa(0.1, pa(0.4, 1, r), r), r);
  let o = da(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [s] = rh(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), c = da(s, null, r);
    o = o.concat(c);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: o } };
}
function Jc(e, t, r, i, n, a, o, s, c) {
  const l = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += rt(0.01 * u, c), f += rt(0.01 * f, c);
  let p = n, g = a;
  for (; p < 0; ) p += 2 * Math.PI, g += 2 * Math.PI;
  g - p > 2 * Math.PI && (p = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / c.curveStepCount, y = Math.min(m / 2, (g - p) / 2), x = ih(y, l, h, u, f, p, g, 1, c);
  if (!c.disableMultiStroke) {
    const b = ih(y, l, h, u, f, p, g, 1.5, c);
    x.push(...b);
  }
  return o && (s ? x.push(...Ge(l, h, l + u * Math.cos(p), h + f * Math.sin(p), c), ...Ge(l, h, l + u * Math.cos(g), h + f * Math.sin(g), c)) : x.push({ op: "lineTo", data: [l, h] }, { op: "lineTo", data: [l + u * Math.cos(p), h + f * Math.sin(p)] })), { type: "path", ops: x };
}
function th(e, t) {
  const r = xd(yd(yl(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: o, data: s } of r) switch (o) {
    case "M":
      a = [s[0], s[1]], n = [s[0], s[1]];
      break;
    case "L":
      i.push(...Ge(a[0], a[1], s[0], s[1], t)), a = [s[0], s[1]];
      break;
    case "C": {
      const [c, l, h, u, f, p] = s;
      i.push(...Bv(c, l, h, u, f, p, a, t)), a = [f, p];
      break;
    }
    case "Z":
      i.push(...Ge(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function ys(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + rt(n, t), i[0][1] + rt(n, t)] });
      for (let o = 1; o < a; o++) r.push({ op: "lineTo", data: [i[o][0] + rt(n, t), i[o][1] + rt(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function Mr(e, t) {
  return function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Kt[n]) switch (n) {
      case "zigzag":
        Kt[n] || (Kt[n] = new xv(i));
        break;
      case "cross-hatch":
        Kt[n] || (Kt[n] = new bv(i));
        break;
      case "dots":
        Kt[n] || (Kt[n] = new Cv(i));
        break;
      case "dashed":
        Kt[n] || (Kt[n] = new _v(i));
        break;
      case "zigzag-line":
        Kt[n] || (Kt[n] = new wv(i));
        break;
      default:
        n = "hachure", Kt[n] || (Kt[n] = new ml(i));
    }
    return Kt[n];
  }(t, Sv).fillPolygons(e, t);
}
function eh(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function wd(e) {
  return e.randomizer || (e.randomizer = new kv(e.seed || 0)), e.randomizer.next();
}
function pa(e, t, r, i = 1) {
  return r.roughness * i * (wd(r) * (t - e) + e);
}
function rt(e, t, r = 1) {
  return pa(-e, e, t, r);
}
function Ge(e, t, r, i, n, a = !1) {
  const o = a ? n.disableMultiStrokeFill : n.disableMultiStroke, s = oo(e, t, r, i, n, !0, !1);
  if (o) return s;
  const c = oo(e, t, r, i, n, !0, !0);
  return s.concat(c);
}
function oo(e, t, r, i, n, a, o) {
  const s = Math.pow(e - r, 2) + Math.pow(t - i, 2), c = Math.sqrt(s);
  let l = 1;
  l = c < 200 ? 1 : c > 500 ? 0.4 : -16668e-7 * c + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > s && (h = c / 10);
  const u = h / 2, f = 0.2 + 0.2 * wd(n);
  let p = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  p = rt(p, n, l), g = rt(g, n, l);
  const m = [], y = () => rt(u, n, l), x = () => rt(h, n, l), b = n.preserveVertices;
  return o ? m.push({ op: "move", data: [e + (b ? 0 : y()), t + (b ? 0 : y())] }) : m.push({ op: "move", data: [e + (b ? 0 : rt(h, n, l)), t + (b ? 0 : rt(h, n, l))] }), o ? m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + y(), g + t + (i - t) * f + y(), p + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }) : m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + x(), g + t + (i - t) * f + x(), p + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }), m;
}
function xn(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]), i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]), n === e.length - 1 && i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]);
  return da(i, null, r);
}
function da(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], o = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let s = 1; s + 2 < i; s++) {
      const c = e[s];
      a[0] = [c[0], c[1]], a[1] = [c[0] + (o * e[s + 1][0] - o * e[s - 1][0]) / 6, c[1] + (o * e[s + 1][1] - o * e[s - 1][1]) / 6], a[2] = [e[s + 1][0] + (o * e[s][0] - o * e[s + 2][0]) / 6, e[s + 1][1] + (o * e[s][1] - o * e[s + 2][1]) / 6], a[3] = [e[s + 1][0], e[s + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...oo(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function rh(e, t, r, i, n, a, o, s) {
  const c = [], l = [];
  if (s.roughness === 0) {
    e /= 4, l.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      c.push(u), l.push(u);
    }
    l.push([t + i * Math.cos(0), r + n * Math.sin(0)]), l.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = rt(0.5, s) - Math.PI / 2;
    l.push([rt(a, s) + t + 0.9 * i * Math.cos(h - e), rt(a, s) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const p = [rt(a, s) + t + i * Math.cos(f), rt(a, s) + r + n * Math.sin(f)];
      c.push(p), l.push(p);
    }
    l.push([rt(a, s) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * o), rt(a, s) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * o)]), l.push([rt(a, s) + t + 0.98 * i * Math.cos(h + o), rt(a, s) + r + 0.98 * n * Math.sin(h + o)]), l.push([rt(a, s) + t + 0.9 * i * Math.cos(h + 0.5 * o), rt(a, s) + r + 0.9 * n * Math.sin(h + 0.5 * o)]);
  }
  return [l, c];
}
function ih(e, t, r, i, n, a, o, s, c) {
  const l = a + rt(0.1, c), h = [];
  h.push([rt(s, c) + t + 0.9 * i * Math.cos(l - e), rt(s, c) + r + 0.9 * n * Math.sin(l - e)]);
  for (let u = l; u <= o; u += e) h.push([rt(s, c) + t + i * Math.cos(u), rt(s, c) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), da(h, null, c);
}
function Bv(e, t, r, i, n, a, o, s) {
  const c = [], l = [s.maxRandomnessOffset || 1, (s.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = s.disableMultiStroke ? 1 : 2, f = s.preserveVertices;
  for (let p = 0; p < u; p++) p === 0 ? c.push({ op: "move", data: [o[0], o[1]] }) : c.push({ op: "move", data: [o[0] + (f ? 0 : rt(l[0], s)), o[1] + (f ? 0 : rt(l[0], s))] }), h = f ? [n, a] : [n + rt(l[p], s), a + rt(l[p], s)], c.push({ op: "bcurveTo", data: [e + rt(l[p], s), t + rt(l[p], s), r + rt(l[p], s), i + rt(l[p], s), h[0], h[1]] });
  return c;
}
function xi(e) {
  return [...e];
}
function nh(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(xi(e[0]), xi(e[1]), xi(e[2]), xi(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let s = 1; s < e.length; s++) n.push(e[s]), s === e.length - 1 && n.push(e[s]);
    const a = [], o = 1 - t;
    i.push(xi(n[0]));
    for (let s = 1; s + 2 < n.length; s++) {
      const c = n[s];
      a[0] = [c[0], c[1]], a[1] = [c[0] + (o * n[s + 1][0] - o * n[s - 1][0]) / 6, c[1] + (o * n[s + 1][1] - o * n[s - 1][1]) / 6], a[2] = [n[s + 1][0] + (o * n[s][0] - o * n[s + 2][0]) / 6, n[s + 1][1] + (o * n[s][1] - o * n[s + 2][1]) / 6], a[3] = [n[s + 1][0], n[s + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function Fn(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function Lv(e, t, r) {
  const i = Fn(t, r);
  if (i === 0) return Fn(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), Fn(e, rr(t, r, n));
}
function rr(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function lo(e, t, r, i) {
  const n = i || [];
  if (function(s, c) {
    const l = s[c + 0], h = s[c + 1], u = s[c + 2], f = s[c + 3];
    let p = 3 * h[0] - 2 * l[0] - f[0];
    p *= p;
    let g = 3 * h[1] - 2 * l[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - l[0];
    m *= m;
    let y = 3 * u[1] - 2 * f[1] - l[1];
    return y *= y, p < m && (p = m), g < y && (g = y), p + g;
  }(e, t) < r) {
    const s = e[t + 0];
    n.length ? (a = n[n.length - 1], o = s, Math.sqrt(Fn(a, o)) > 1 && n.push(s)) : n.push(s), n.push(e[t + 3]);
  } else {
    const c = e[t + 0], l = e[t + 1], h = e[t + 2], u = e[t + 3], f = rr(c, l, 0.5), p = rr(l, h, 0.5), g = rr(h, u, 0.5), m = rr(f, p, 0.5), y = rr(p, g, 0.5), x = rr(m, y, 0.5);
    lo([c, f, m, x], 0, r, n), lo([x, y, g, u], 0, r, n);
  }
  var a, o;
  return n;
}
function Av(e, t) {
  return ga(e, 0, e.length, t);
}
function ga(e, t, r, i, n) {
  const a = n || [], o = e[t], s = e[r - 1];
  let c = 0, l = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = Lv(e[h], o, s);
    u > c && (c = u, l = h);
  }
  return Math.sqrt(c) > i ? (ga(e, t, l + 1, i, a), ga(e, l, r, i, a)) : (a.length || a.push(o), a.push(s)), a;
}
function xs(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    lo(e, 3 * a, t, i);
  return r && r > 0 ? ga(i, 0, i.length, r) : i;
}
const ee = "none";
class ma {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const o = this._o(a);
    return this._d("line", [Cd(t, r, i, n, o)], o);
  }
  rectangle(t, r, i, n, a) {
    const o = this._o(a), s = [], c = Tv(t, r, i, n, o);
    if (o.fill) {
      const l = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      o.fillStyle === "solid" ? s.push(ys([l], o)) : s.push(Mr([l], o));
    }
    return o.stroke !== ee && s.push(c), this._d("rectangle", s, o);
  }
  ellipse(t, r, i, n, a) {
    const o = this._o(a), s = [], c = _d(i, n, o), l = so(t, r, o, c);
    if (o.fill) if (o.fillStyle === "solid") {
      const h = so(t, r, o, c).opset;
      h.type = "fillPath", s.push(h);
    } else s.push(Mr([l.estimatedPoints], o));
    return o.stroke !== ee && s.push(l.opset), this._d("ellipse", s, o);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [En(t, !1, i)], i);
  }
  arc(t, r, i, n, a, o, s = !1, c) {
    const l = this._o(c), h = [], u = Jc(t, r, i, n, a, o, s, !0, l);
    if (s && l.fill) if (l.fillStyle === "solid") {
      const f = Object.assign({}, l);
      f.disableMultiStroke = !0;
      const p = Jc(t, r, i, n, a, o, !0, !1, f);
      p.type = "fillPath", h.push(p);
    } else h.push(function(f, p, g, m, y, x, b) {
      const _ = f, k = p;
      let w = Math.abs(g / 2), C = Math.abs(m / 2);
      w += rt(0.01 * w, b), C += rt(0.01 * C, b);
      let S = y, O = x;
      for (; S < 0; ) S += 2 * Math.PI, O += 2 * Math.PI;
      O - S > 2 * Math.PI && (S = 0, O = 2 * Math.PI);
      const P = (O - S) / b.curveStepCount, R = [];
      for (let $ = S; $ <= O; $ += P) R.push([_ + w * Math.cos($), k + C * Math.sin($)]);
      return R.push([_ + w * Math.cos(O), k + C * Math.sin(O)]), R.push([_, k]), Mr([R], b);
    }(t, r, i, n, a, o, l));
    return l.stroke !== ee && h.push(u), this._d("arc", h, l);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = Qc(t, i);
    if (i.fill && i.fill !== ee) if (i.fillStyle === "solid") {
      const o = Qc(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(o.ops) });
    } else {
      const o = [], s = t;
      if (s.length) {
        const c = typeof s[0][0] == "number" ? [s] : s;
        for (const l of c) l.length < 3 ? o.push(...l) : l.length === 3 ? o.push(...xs(nh([l[0], l[0], l[1], l[2]]), 10, (1 + i.roughness) / 2)) : o.push(...xs(nh(l), 10, (1 + i.roughness) / 2));
      }
      o.length && n.push(Mr([o], i));
    }
    return i.stroke !== ee && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = En(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(ys([t], i)) : n.push(Mr([t], i))), i.stroke !== ee && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== ee, o = i.stroke !== ee, s = !!(i.simplification && i.simplification < 1), c = function(h, u, f) {
      const p = xd(yd(yl(h))), g = [];
      let m = [], y = [0, 0], x = [];
      const b = () => {
        x.length >= 4 && m.push(...xs(x, u)), x = [];
      }, _ = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: w, data: C } of p) switch (w) {
        case "M":
          _(), y = [C[0], C[1]], m.push(y);
          break;
        case "L":
          b(), m.push([C[0], C[1]]);
          break;
        case "C":
          if (!x.length) {
            const S = m.length ? m[m.length - 1] : y;
            x.push([S[0], S[1]]);
          }
          x.push([C[0], C[1]]), x.push([C[2], C[3]]), x.push([C[4], C[5]]);
          break;
        case "Z":
          b(), m.push([y[0], y[1]]);
      }
      if (_(), !f) return g;
      const k = [];
      for (const w of g) {
        const C = Av(w, f);
        C.length && k.push(C);
      }
      return k;
    }(t, 1, s ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), l = th(t, i);
    if (a) if (i.fillStyle === "solid") if (c.length === 1) {
      const h = th(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(ys(c, i));
    else n.push(Mr(c, i));
    return o && (s ? c.forEach((h) => {
      n.push(En(h, !1, i));
    }) : n.push(l)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map((o) => +o.toFixed(r)) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let o = null;
      switch (a.type) {
        case "path":
          o = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: ee };
          break;
        case "fillPath":
          o = { d: this.opsToPath(a), stroke: ee, strokeWidth: 0, fill: i.fill || ee };
          break;
        case "fillSketch":
          o = this.fillSketch(a, i);
      }
      o && n.push(o);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || ee, strokeWidth: i, fill: ee };
  }
  _mergedShape(t) {
    return t.filter((r, i) => i === 0 || r.op !== "move");
  }
}
class Mv {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new ma(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const o of r) switch (o.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, o, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const s = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, o, a, s), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, o, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const o = typeof i == "number" && i >= 0 ? a.data.map((s) => +s.toFixed(i)) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(o[0], o[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(o[0], o[1], o[2], o[3], o[4], o[5]);
          break;
        case "lineTo":
          t.lineTo(o[0], o[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o), o;
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o), o;
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o), o;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, o, s = !1, c) {
    const l = this.gen.arc(t, r, i, n, a, o, s, c);
    return this.draw(l), l;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const bn = "http://www.w3.org/2000/svg";
class $v {
  constructor(t, r) {
    this.svg = t, this.gen = new ma(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(bn, "g"), o = t.options.fixedDecimalPlaceDigits;
    for (const s of r) {
      let c = null;
      switch (s.type) {
        case "path":
          c = n.createElementNS(bn, "path"), c.setAttribute("d", this.opsToPath(s, o)), c.setAttribute("stroke", i.stroke), c.setAttribute("stroke-width", i.strokeWidth + ""), c.setAttribute("fill", "none"), i.strokeLineDash && c.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && c.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          c = n.createElementNS(bn, "path"), c.setAttribute("d", this.opsToPath(s, o)), c.setAttribute("stroke", "none"), c.setAttribute("stroke-width", "0"), c.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || c.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          c = this.fillSketch(n, s, i);
      }
      c && a.appendChild(c);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(bn, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o);
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o);
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, o, s = !1, c) {
    const l = this.gen.arc(t, r, i, n, a, o, s, c);
    return this.draw(l);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var Y = { canvas: (e, t) => new Mv(e, t), svg: (e, t) => new $v(e, t), generator: (e) => new ma(e), newSeed: () => ma.newSeed() }, et = /* @__PURE__ */ d(async (e, t, r) => {
  var u, f;
  let i;
  const n = t.useHtmlLabels || At((u = ft()) == null ? void 0 : u.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), o = a.insert("g").attr("class", "label").attr("style", Wt(t.labelStyle));
  let s;
  t.label === void 0 ? s = "" : s = typeof t.label == "string" ? t.label : t.label[0];
  const c = await Ze(o, se(_r(s), ft()), {
    useHtmlLabels: n,
    width: t.width || ((f = ft().flowchart) == null ? void 0 : f.wrappingWidth),
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let l = c.getBBox();
  const h = ((t == null ? void 0 : t.padding) ?? 0) / 2;
  if (n) {
    const p = c.children[0], g = ht(c), m = p.getElementsByTagName("img");
    if (m) {
      const y = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...m].map(
          (x) => new Promise((b) => {
            function _() {
              if (x.style.display = "flex", x.style.flexDirection = "column", y) {
                const k = ft().fontSize ? ft().fontSize : window.getComputedStyle(document.body).fontSize, w = 5, [C = Oh.fontSize] = Da(k), S = C * w + "px";
                x.style.minWidth = S, x.style.maxWidth = S;
              } else
                x.style.width = "100%";
              b(x);
            }
            d(_, "setupImage"), setTimeout(() => {
              x.complete && _();
            }), x.addEventListener("error", _), x.addEventListener("load", _);
          })
        )
      );
    }
    l = p.getBoundingClientRect(), g.attr("width", l.width), g.attr("height", l.height);
  }
  return n ? o.attr("transform", "translate(" + -l.width / 2 + ", " + -l.height / 2 + ")") : o.attr("transform", "translate(0, " + -l.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -l.width / 2 + ", " + -l.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: a, bbox: l, halfPadding: h, label: o };
}, "labelHelper"), bs = /* @__PURE__ */ d(async (e, t, r) => {
  var c, l, h, u, f, p;
  const i = r.useHtmlLabels || At((l = (c = ft()) == null ? void 0 : c.flowchart) == null ? void 0 : l.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Ze(n, se(_r(t), ft()), {
    useHtmlLabels: i,
    width: r.width || ((u = (h = ft()) == null ? void 0 : h.flowchart) == null ? void 0 : u.wrappingWidth),
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let o = a.getBBox();
  const s = r.padding / 2;
  if (At((p = (f = ft()) == null ? void 0 : f.flowchart) == null ? void 0 : p.htmlLabels)) {
    const g = a.children[0], m = ht(a);
    o = g.getBoundingClientRect(), m.attr("width", o.width), m.attr("height", o.height);
  }
  return i ? n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : n.attr("transform", "translate(0, " + -o.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: o, halfPadding: s, label: n };
}, "insertLabel"), V = /* @__PURE__ */ d((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), tt = /* @__PURE__ */ d((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function lt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
d(lt, "createPathFromPoints");
function Xe(e, t, r, i, n, a) {
  const o = [], c = r - e, l = i - t, h = c / a, u = 2 * Math.PI / h, f = t + l / 2;
  for (let p = 0; p <= 50; p++) {
    const g = p / 50, m = e + g * c, y = f + n * Math.sin(u * (m - e));
    o.push({ x: m, y });
  }
  return o;
}
d(Xe, "generateFullSineWavePoints");
function ji(e, t, r, i, n, a) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(ji, "generateCirclePoints");
var Ev = /* @__PURE__ */ d((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, o = e.width / 2, s = e.height / 2, c, l;
  return Math.abs(a) * o > Math.abs(n) * s ? (a < 0 && (s = -s), c = a === 0 ? 0 : s * n / a, l = s) : (n < 0 && (o = -o), c = o, l = n === 0 ? 0 : o * a / n), { x: r + c, y: i + l };
}, "intersectRect"), ni = Ev;
function kd(e, t) {
  t && e.attr("style", t);
}
d(kd, "applyStyle");
async function vd(e) {
  const t = ht(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div"), i = ft();
  let n = e.label;
  e.label && Gr(e.label) && (n = await ko(e.label.replace(ti.lineBreakRegex, `
`), i));
  const o = '<span class="' + (e.isNode ? "nodeLabel" : "edgeLabel") + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
  ">" + n + "</span>";
  return r.html(se(o, i)), kd(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
d(vd, "addHtmlLabel");
var Fv = /* @__PURE__ */ d(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), At(ft().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: _r(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (s) => `<i class='${s.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await vd(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let o = [];
    typeof n == "string" ? o = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? o = n : o = [];
    for (const s of o) {
      const c = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      c.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), c.setAttribute("dy", "1em"), c.setAttribute("x", "0"), r ? c.setAttribute("class", "title-row") : c.setAttribute("class", "row"), c.textContent = s.trim(), a.appendChild(c);
    }
    return a;
  }
}, "createLabel"), lr = Fv, Ke = /* @__PURE__ */ d((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), Sd = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: c, borderStyles: l, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = At(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const S = g.children[0], O = ht(g);
    m = S.getBoundingClientRect(), O.attr("width", m.width), O.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = Y.svg(u), O = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 3,
      seed: n
    }), P = S.path(Ke(b, _, y, x, 0), O);
    k = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), k.select("path:nth-child(2)").attr("style", l.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", c).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Xo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ni(t, S);
  }, { cluster: u, labelBBox: m };
}, "rect"), Ov = /* @__PURE__ */ d((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const o = i.node().getBBox();
  return t.width = o.width, t.height = o.height, t.intersect = function(s) {
    return ni(t, s);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), Dv = /* @__PURE__ */ d(async (e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: o, compositeTitleBackground: s, nodeBorder: c } = i, l = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = l.insert("g", ":first-child"), u = l.insert("g").attr("class", "cluster-label");
  let f = l.append("rect");
  const p = u.node().appendChild(await lr(t.label, t.labelStyle, void 0, !0));
  let g = p.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const P = p.children[0], R = ht(p);
    g = P.getBoundingClientRect(), R.attr("width", g.width), R.attr("height", g.height);
  }
  const m = 0 * t.padding, y = m / 2, x = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, _ = t.height + m - g.height - 6, k = t.x - x / 2, w = t.y - b / 2;
  t.width = x;
  const C = t.y - t.height / 2 - y + g.height + 2;
  let S;
  if (t.look === "handDrawn") {
    const P = t.cssClasses.includes("statediagram-cluster-alt"), R = Y.svg(l), $ = t.rx || t.ry ? R.path(Ke(k, w, x, b, 10), {
      roughness: 0.7,
      fill: s,
      fillStyle: "solid",
      stroke: c,
      seed: n
    }) : R.rectangle(k, w, x, b, { seed: n });
    S = l.insert(() => $, ":first-child");
    const z = R.rectangle(k, C, x, _, {
      fill: P ? a : o,
      fillStyle: P ? "hachure" : "solid",
      stroke: c,
      seed: n
    });
    S = l.insert(() => $, ":first-child"), f = l.insert(() => z);
  } else
    S = h.insert("rect", ":first-child"), S.attr("class", "outer").attr("x", k).attr("y", w).attr("width", x).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", k).attr("y", C).attr("width", x).attr("height", _);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${w + 1 - (At(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const O = S.node().getBBox();
  return t.height = O.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(P) {
    return ni(t, P);
  }, { cluster: l, labelBBox: g };
}, "roundedWithTitle"), Rv = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: c, borderStyles: l, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = At(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const S = g.children[0], O = ht(g);
    m = S.getBoundingClientRect(), O.attr("width", m.width), O.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = Y.svg(u), O = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 4,
      seed: n
    }), P = S.path(Ke(b, _, y, x, t.rx), O);
    k = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), k.select("path:nth-child(2)").attr("style", l.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", c).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: w } = Xo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + w})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ni(t, S);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), Iv = /* @__PURE__ */ d((e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, o = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), s = o.insert("g", ":first-child"), c = 0 * t.padding, l = t.width + c;
  t.diff = -t.padding;
  const h = t.height + c, u = t.x - l / 2, f = t.y - h / 2;
  t.width = l;
  let p;
  if (t.look === "handDrawn") {
    const y = Y.svg(o).rectangle(u, f, l, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    p = o.insert(() => y, ":first-child");
  } else
    p = s.insert("rect", ":first-child"), p.attr("class", "divider").attr("x", u).attr("y", f).attr("width", l).attr("height", h).attr("data-look", t.look);
  const g = p.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return ni(t, m);
  }, { cluster: o, labelBBox: {} };
}, "divider"), Pv = Sd, Nv = {
  rect: Sd,
  squareRect: Pv,
  roundedWithTitle: Dv,
  noteGroup: Ov,
  divider: Iv,
  kanbanSection: Rv
}, Td = /* @__PURE__ */ new Map(), zv = /* @__PURE__ */ d(async (e, t) => {
  const r = t.shape || "rect", i = await Nv[r](e, t);
  return Td.set(t.id, i), i;
}, "insertCluster"), gA = /* @__PURE__ */ d(() => {
  Td = /* @__PURE__ */ new Map();
}, "clear");
function Bd(e, t) {
  return e.intersect(t);
}
d(Bd, "intersectNode");
var Wv = Bd;
function Ld(e, t, r, i) {
  var n = e.x, a = e.y, o = n - i.x, s = a - i.y, c = Math.sqrt(t * t * s * s + r * r * o * o), l = Math.abs(t * r * o / c);
  i.x < n && (l = -l);
  var h = Math.abs(t * r * s / c);
  return i.y < a && (h = -h), { x: n + l, y: a + h };
}
d(Ld, "intersectEllipse");
var Ad = Ld;
function Md(e, t, r) {
  return Ad(e, t, t, r);
}
d(Md, "intersectCircle");
var qv = Md;
function $d(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, o = t.x * e.y - e.x * t.y, s = n * r.x + a * r.y + o, c = n * i.x + a * i.y + o, l = 1e-6;
    if (s !== 0 && c !== 0 && co(s, c))
      return;
    const h = i.y - r.y, u = r.x - i.x, f = i.x * r.y - r.x * i.y, p = h * e.x + u * e.y + f, g = h * t.x + u * t.y + f;
    if (Math.abs(p) < l && Math.abs(g) < l && co(p, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const y = Math.abs(m / 2);
    let x = a * f - u * o;
    const b = x < 0 ? (x - y) / m : (x + y) / m;
    x = h * o - n * f;
    const _ = x < 0 ? (x - y) / m : (x + y) / m;
    return { x: b, y: _ };
  }
}
d($d, "intersectLine");
function co(e, t) {
  return e * t > 0;
}
d(co, "sameSign");
var Hv = $d;
function Ed(e, t, r) {
  let i = e.x, n = e.y, a = [], o = Number.POSITIVE_INFINITY, s = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    o = Math.min(o, h.x), s = Math.min(s, h.y);
  }) : (o = Math.min(o, t.x), s = Math.min(s, t.y));
  let c = i - e.width / 2 - o, l = n - e.height / 2 - s;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], p = Hv(
      e,
      r,
      { x: c + u.x, y: l + u.y },
      { x: c + f.x, y: l + f.y }
    );
    p && a.push(p);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, p = h.y - r.y, g = Math.sqrt(f * f + p * p), m = u.x - r.x, y = u.y - r.y, x = Math.sqrt(m * m + y * y);
    return g < x ? -1 : g === x ? 0 : 1;
  }), a[0]) : e;
}
d(Ed, "intersectPolygon");
var jv = Ed, q = {
  node: Wv,
  circle: qv,
  ellipse: Ad,
  polygon: jv,
  rect: ni
};
function Fd(e, t) {
  const { labelStyles: r } = G(t);
  t.labelStyle = r;
  const i = tt(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = 1, { cssStyles: s } = t, c = Y.svg(a), l = U(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (l.roughness = 0);
  const h = c.circle(0, 0, o * 2, l), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Wt(s)), V(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, o, f), q.circle(t, o, f);
  }, a;
}
d(Fd, "anchor");
function ho(e, t, r, i, n, a, o) {
  const c = (e + r) / 2, l = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = c + y * a * Math.sin(h) * (o ? -1 : 1), b = l - y * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - _;
  o && w < 0 && (w += 2 * Math.PI), !o && w > 0 && (w -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const O = S / 19, P = _ + O * w, R = x + n * Math.cos(P), $ = b + a * Math.sin(P);
    C.push({ x: R, y: $ });
  }
  return C;
}
d(ho, "generateArcPoints");
async function Od(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding + 20, s = a.height + t.padding, c = s / 2, l = c / (2.5 + s / 50), { cssStyles: h } = t, u = [
    { x: o / 2, y: -s / 2 },
    { x: -o / 2, y: -s / 2 },
    ...ho(-o / 2, -s / 2, -o / 2, s / 2, l, c, !1),
    { x: o / 2, y: s / 2 },
    ...ho(o / 2, s / 2, o / 2, -s / 2, l, c, !0)
  ], f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(u), m = f.path(g, p), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(${l / 2}, 0)`), V(t, y), t.intersect = function(x) {
    return q.polygon(t, u, x);
  }, n;
}
d(Od, "bowTieRect");
function Qe(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
d(Qe, "insertPolygonShape");
async function Dd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = 12, c = a.width + t.padding + s, l = 0, h = c, u = -o, f = 0, p = [
    { x: l + s, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: l, y: f },
    { x: l, y: u + s },
    { x: l + s, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const y = Y.svg(n), x = U(t, {}), b = lt(p), _ = y.path(b, x);
    g = n.insert(() => _, ":first-child").attr("transform", `translate(${-c / 2}, ${o / 2})`), m && g.attr("style", m);
  } else
    g = Qe(n, c, o, p);
  return i && g.attr("style", i), V(t, g), t.intersect = function(y) {
    return q.polygon(t, p, y);
  }, n;
}
d(Dd, "card");
function Rd(e, t) {
  const { nodeStyles: r } = G(t);
  t.label = "";
  const i = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), o = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], s = Y.svg(i), c = U(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const l = lt(o), h = s.path(l, c), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return q.polygon(t, o, f);
  }, i;
}
d(Rd, "choice");
async function xl(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o, halfPadding: s } = await et(e, t, tt(t)), c = (r == null ? void 0 : r.padding) ?? s, l = o.width / 2 + c;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = Y.svg(a), p = U(t, {}), g = f.circle(0, 0, l * 2, p);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", Wt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", l).attr("cx", 0).attr("cy", 0);
  return V(t, h), t.calcIntersect = function(f, p) {
    const g = f.width / 2;
    return q.circle(f, g, p);
  }, t.intersect = function(f) {
    return F.info("Circle intersect", t, l, f), q.circle(t, l, f);
  }, a;
}
d(xl, "circle");
function Id(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, o = { x: -(i / 2) * t, y: -(i / 2) * r }, s = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${s.x},${s.y}
                   M ${n.x},${n.y} L ${o.x},${o.y}`;
}
d(Id, "createLine");
function Pd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), { cssStyles: o } = t, s = Y.svg(n), c = U(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const l = s.circle(0, 0, a * 2, c), h = Id(a), u = s.path(h, c), f = n.insert(() => l, ":first-child");
  return f.insert(() => u), o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), V(t, f), t.intersect = function(p) {
    return F.info("crossedCircle intersect", t, { radius: a, point: p }), q.circle(t, a, p);
  }, n;
}
d(Pd, "crossedCircle");
function Ee(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(Ee, "generateCirclePoints");
async function Nd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), c = a.height + (t.padding ?? 0), l = Math.max(5, c * 0.1), { cssStyles: h } = t, u = [
    ...Ee(s / 2, -c / 2, l, 30, -90, 0),
    { x: -s / 2 - l, y: l },
    ...Ee(s / 2 + l * 2, -l, l, 20, -180, -270),
    ...Ee(s / 2 + l * 2, l, l, 20, -90, -180),
    { x: -s / 2 - l, y: -c / 2 },
    ...Ee(s / 2, c / 2, l, 20, 0, 90)
  ], f = [
    { x: s / 2, y: -c / 2 - l },
    { x: -s / 2, y: -c / 2 - l },
    ...Ee(s / 2, -c / 2, l, 20, -90, 0),
    { x: -s / 2 - l, y: -l },
    ...Ee(s / 2 + s * 0.1, -l, l, 20, -180, -270),
    ...Ee(s / 2 + s * 0.1, l, l, 20, -90, -180),
    { x: -s / 2 - l, y: c / 2 },
    ...Ee(s / 2, c / 2, l, 20, 0, 90),
    { x: -s / 2, y: c / 2 + l },
    { x: s / 2, y: c / 2 + l }
  ], p = Y.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = p.path(y, g), b = lt(f), _ = p.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => _, ":first-child").attr("stroke-opacity", 0), k.insert(() => x, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${l}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + l - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, k), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(Nd, "curlyBraceLeft");
function Fe(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: p, y: g });
  }
  return o;
}
d(Fe, "generateCirclePoints");
async function zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), c = a.height + (t.padding ?? 0), l = Math.max(5, c * 0.1), { cssStyles: h } = t, u = [
    ...Fe(s / 2, -c / 2, l, 20, -90, 0),
    { x: s / 2 + l, y: -l },
    ...Fe(s / 2 + l * 2, -l, l, 20, -180, -270),
    ...Fe(s / 2 + l * 2, l, l, 20, -90, -180),
    { x: s / 2 + l, y: c / 2 },
    ...Fe(s / 2, c / 2, l, 20, 0, 90)
  ], f = [
    { x: -s / 2, y: -c / 2 - l },
    { x: s / 2, y: -c / 2 - l },
    ...Fe(s / 2, -c / 2, l, 20, -90, 0),
    { x: s / 2 + l, y: -l },
    ...Fe(s / 2 + l * 2, -l, l, 20, -180, -270),
    ...Fe(s / 2 + l * 2, l, l, 20, -90, -180),
    { x: s / 2 + l, y: c / 2 },
    ...Fe(s / 2, c / 2, l, 20, 0, 90),
    { x: s / 2, y: c / 2 + l },
    { x: -s / 2, y: c / 2 + l }
  ], p = Y.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), x = p.path(y, g), b = lt(f), _ = p.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => _, ":first-child").attr("stroke-opacity", 0), k.insert(() => x, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${-l}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, k), t.intersect = function(w) {
    return q.polygon(t, f, w);
  }, n;
}
d(zd, "curlyBraceRight");
function Ft(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(Ft, "generateCirclePoints");
async function Wd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), c = a.height + (t.padding ?? 0), l = Math.max(5, c * 0.1), { cssStyles: h } = t, u = [
    ...Ft(s / 2, -c / 2, l, 30, -90, 0),
    { x: -s / 2 - l, y: l },
    ...Ft(s / 2 + l * 2, -l, l, 20, -180, -270),
    ...Ft(s / 2 + l * 2, l, l, 20, -90, -180),
    { x: -s / 2 - l, y: -c / 2 },
    ...Ft(s / 2, c / 2, l, 20, 0, 90)
  ], f = [
    ...Ft(-s / 2 + l + l / 2, -c / 2, l, 20, -90, -180),
    { x: s / 2 - l / 2, y: l },
    ...Ft(-s / 2 - l / 2, -l, l, 20, 0, 90),
    ...Ft(-s / 2 - l / 2, l, l, 20, -90, 0),
    { x: s / 2 - l / 2, y: -l },
    ...Ft(-s / 2 + l + l / 2, c / 2, l, 30, -180, -270)
  ], p = [
    { x: s / 2, y: -c / 2 - l },
    { x: -s / 2, y: -c / 2 - l },
    ...Ft(s / 2, -c / 2, l, 20, -90, 0),
    { x: -s / 2 - l, y: -l },
    ...Ft(s / 2 + l * 2, -l, l, 20, -180, -270),
    ...Ft(s / 2 + l * 2, l, l, 20, -90, -180),
    { x: -s / 2 - l, y: c / 2 },
    ...Ft(s / 2, c / 2, l, 20, 0, 90),
    { x: -s / 2, y: c / 2 + l },
    { x: s / 2 - l - l / 2, y: c / 2 + l },
    ...Ft(-s / 2 + l + l / 2, -c / 2, l, 20, -90, -180),
    { x: s / 2 - l / 2, y: l },
    ...Ft(-s / 2 - l / 2, -l, l, 20, 0, 90),
    ...Ft(-s / 2 - l / 2, l, l, 20, -90, 0),
    { x: s / 2 - l / 2, y: -l },
    ...Ft(-s / 2 + l + l / 2, c / 2, l, 30, -180, -270)
  ], g = Y.svg(n), m = U(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = lt(u).replace("Z", ""), b = g.path(x, m), k = lt(f).replace("Z", ""), w = g.path(k, m), C = lt(p), S = g.path(C, { ...m }), O = n.insert("g", ":first-child");
  return O.insert(() => S, ":first-child").attr("stroke-opacity", 0), O.insert(() => b, ":first-child"), O.insert(() => w, ":first-child"), O.attr("class", "text"), h && t.look !== "handDrawn" && O.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && O.selectAll("path").attr("style", i), O.attr("transform", `translate(${l - l / 4}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, O), t.intersect = function(P) {
    return q.polygon(t, p, P);
  }, n;
}
d(Wd, "curlyBraces");
async function qd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 80, s = 20, c = Math.max(o, (a.width + (t.padding ?? 0) * 2) * 1.25, (t == null ? void 0 : t.width) ?? 0), l = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / 2, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = c, m = l, y = g - h, x = m / 4, b = [
    { x: y, y: 0 },
    { x, y: 0 },
    { x: 0, y: m / 2 },
    { x, y: m },
    { x: y, y: m },
    ...ji(-y, -m / 2, h, 50, 270, 90)
  ], _ = lt(b), k = f.path(_, p), w = n.insert(() => k, ":first-child");
  return w.attr("class", "basic label-container"), u && t.look !== "handDrawn" && w.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && w.selectChildren("path").attr("style", i), w.attr("transform", `translate(${-c / 2}, ${-l / 2})`), V(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(qd, "curvedTrapezoid");
var Yv = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), Uv = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Gv = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function Hd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + t.padding, t.width ?? 0), c = s / 2, l = c / (2.5 + s / 50), h = Math.max(a.height + l + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = Y.svg(n), g = Uv(0, 0, s, h, c, l), m = Gv(0, l, s, h, c, l), y = p.path(g, U(t, {})), x = p.path(m, U(t, { fill: "none" }));
    u = n.insert(() => x, ":first-child"), u = n.insert(() => y, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const p = Yv(0, 0, s, h, c, l);
    u = n.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container").attr("style", Wt(f)).attr("style", i);
  }
  return u.attr("label-offset-y", l), u.attr("transform", `translate(${-s / 2}, ${-(h / 2 + l)})`), V(t, u), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(p) {
    const g = q.rect(t, p), m = g.x - (t.x ?? 0);
    if (c != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - l)) {
      let y = l * l * (1 - m * m / (c * c));
      y > 0 && (y = Math.sqrt(y)), y = l - y, p.y - (t.y ?? 0) > 0 && (y = -y), g.y += y;
    }
    return g;
  }, n;
}
d(Hd, "cylinder");
async function jd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + t.padding, c = a.height + t.padding, l = c * 0.2, h = -s / 2, u = -c / 2 - l / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + l },
    { x: -h, y: u + l },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + l }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + l + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(jd, "dividedRectangle");
async function Yd(e, t) {
  var f, p;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await et(e, t, tt(t)), c = a.width / 2 + o + 5, l = a.width / 2 + o;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const g = Y.svg(n), m = U(t, { roughness: 0.2, strokeWidth: 2.5 }), y = U(t, { roughness: 0.2, strokeWidth: 1.5 }), x = g.circle(0, 0, c * 2, m), b = g.circle(0, 0, l * 2, y);
    h = n.insert("g", ":first-child"), h.attr("class", Wt(t.cssClasses)).attr("style", Wt(u)), (f = h.node()) == null || f.appendChild(x), (p = h.node()) == null || p.appendChild(b);
  } else {
    h = n.insert("g", ":first-child");
    const g = h.insert("circle", ":first-child"), m = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), g.attr("class", "outer-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0), m.attr("class", "inner-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0);
  }
  return V(t, h), t.intersect = function(g) {
    return F.info("DoubleCircle intersect", t, c, g), q.circle(t, c, g);
  }, n;
}
d(Yd, "doublecircle");
function Ud(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), o = 7, { cssStyles: s } = t, c = Y.svg(a), { nodeBorder: l } = r, h = U(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = c.circle(0, 0, o * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${l} !important;`), s && s.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), V(t, f), t.intersect = function(p) {
    return F.info("filledCircle intersect", t, { radius: o, point: p }), q.circle(t, o, p);
  }, a;
}
d(Ud, "filledCircle");
async function Gd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), c = s + a.height, l = s + a.height, h = [
    { x: 0, y: -c },
    { x: l, y: -c },
    { x: l / 2, y: 0 }
  ], { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(h), m = f.path(g, p), y = n.insert(() => m, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = s, t.height = c, V(t, y), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-c / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(x) {
    return F.info("Triangle intersect", t, h, x), q.polygon(t, h, x);
  }, n;
}
d(Gd, "flippedTriangle");
function Xd(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = G(t);
  t.label = "";
  const o = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: s } = t;
  let c = Math.max(70, (t == null ? void 0 : t.width) ?? 0), l = Math.max(10, (t == null ? void 0 : t.height) ?? 0);
  r === "LR" && (c = Math.max(10, (t == null ? void 0 : t.width) ?? 0), l = Math.max(70, (t == null ? void 0 : t.height) ?? 0));
  const h = -1 * c / 2, u = -1 * l / 2, f = Y.svg(o), p = U(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = f.rectangle(h, u, c, l, p), m = o.insert(() => g, ":first-child");
  s && t.look !== "handDrawn" && m.selectAll("path").attr("style", s), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), V(t, m);
  const y = (i == null ? void 0 : i.padding) ?? 0;
  return t.width && t.height && (t.width += y / 2 || 0, t.height += y / 2 || 0), t.intersect = function(x) {
    return q.rect(t, x);
  }, o;
}
d(Xd, "forkJoin");
async function Vd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: o, bbox: s } = await et(e, t, tt(t)), c = Math.max(n, s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a, s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / 2, { cssStyles: u } = t, f = Y.svg(o), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -c / 2, y: -l / 2 },
    { x: c / 2 - h, y: -l / 2 },
    ...ji(-c / 2 + h, 0, h, 50, 90, 270),
    { x: c / 2 - h, y: l / 2 },
    { x: -c / 2, y: l / 2 }
  ], m = lt(g), y = f.path(m, p), x = o.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), V(t, x), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), q.polygon(t, g, b);
  }, o;
}
d(Vd, "halfRoundedRectangle");
async function Zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + (t.padding ?? 0), s = a.width + (t.padding ?? 0) * 2.5, { cssStyles: c } = t, l = Y.svg(n), h = U(t, {});
  t.look !== "handDrawn" && (h.roughness = 0, h.fillStyle = "solid");
  let u = s / 2;
  const f = u / 6;
  u = u + f;
  const p = o / 2, g = p / 2, m = u - g, y = [
    { x: -m, y: -p },
    { x: 0, y: -p },
    { x: m, y: -p },
    { x: u, y: 0 },
    { x: m, y: p },
    { x: 0, y: p },
    { x: -m, y: p },
    { x: -u, y: 0 }
  ], x = lt(y), b = l.path(x, h), _ = n.insert(() => b, ":first-child");
  return _.attr("class", "basic label-container"), c && t.look !== "handDrawn" && _.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && _.selectChildren("path").attr("style", i), t.width = s, t.height = o, V(t, _), t.intersect = function(k) {
    return q.polygon(t, y, k);
  }, n;
}
d(Zd, "hexagon");
async function Kd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await et(e, t, tt(t)), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), o = Math.max(30, (t == null ? void 0 : t.height) ?? 0), { cssStyles: s } = t, c = Y.svg(n), l = U(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: o },
    { x: a, y: o }
  ], u = lt(h), f = c.path(u, l), p = n.insert(() => f, ":first-child");
  return p.attr("class", "basic label-container"), s && t.look !== "handDrawn" && p.selectChildren("path").attr("style", s), i && t.look !== "handDrawn" && p.selectChildren("path").attr("style", i), p.attr("transform", `translate(${-a / 2}, ${-o / 2})`), V(t, p), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), q.polygon(t, h, g);
  }, n;
}
d(Kd, "hourglass");
async function Qd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), c = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, c ?? 0);
  const { shapeSvg: l, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = t.pos === "t", p = s, g = s, { nodeBorder: m } = r, { stylesMap: y } = ei(t), x = -g / 2, b = -p / 2, _ = t.label ? 8 : 0, k = Y.svg(l), w = U(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const C = k.rectangle(x, b, g, p, w), S = Math.max(g, h.width), O = p + h.height + _, P = k.rectangle(-S / 2, -O / 2, S, O, {
    ...w,
    fill: "transparent",
    stroke: "none"
  }), R = l.insert(() => C, ":first-child"), $ = l.insert(() => P);
  if (t.icon) {
    const z = l.append("g");
    z.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const D = z.node().getBBox(), M = D.width, L = D.height, B = D.x, E = D.y;
    z.attr(
      "transform",
      `translate(${-M / 2 - B},${f ? h.height / 2 + _ / 2 - L / 2 - E : -h.height / 2 - _ / 2 - L / 2 - E})`
    ), z.attr("style", `color: ${y.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -O / 2 : O / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), V(t, $), t.intersect = function(z) {
    if (F.info("iconSquare intersect", t, z), !t.label)
      return q.rect(t, z);
    const D = t.x ?? 0, M = t.y ?? 0, L = t.height ?? 0;
    let B = [];
    return f ? B = [
      { x: D - h.width / 2, y: M - L / 2 },
      { x: D + h.width / 2, y: M - L / 2 },
      { x: D + h.width / 2, y: M - L / 2 + h.height + _ },
      { x: D + g / 2, y: M - L / 2 + h.height + _ },
      { x: D + g / 2, y: M + L / 2 },
      { x: D - g / 2, y: M + L / 2 },
      { x: D - g / 2, y: M - L / 2 + h.height + _ },
      { x: D - h.width / 2, y: M - L / 2 + h.height + _ }
    ] : B = [
      { x: D - g / 2, y: M - L / 2 },
      { x: D + g / 2, y: M - L / 2 },
      { x: D + g / 2, y: M - L / 2 + p },
      { x: D + h.width / 2, y: M - L / 2 + p },
      { x: D + h.width / 2 / 2, y: M + L / 2 },
      { x: D - h.width / 2, y: M + L / 2 },
      { x: D - h.width / 2, y: M - L / 2 + p },
      { x: D - g / 2, y: M - L / 2 + p }
    ], q.polygon(t, B, z);
  }, l;
}
d(Qd, "icon");
async function Jd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), c = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, c ?? 0);
  const { shapeSvg: l, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = 20, p = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: y } = r, { stylesMap: x } = ei(t), b = Y.svg(l), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = x.get("fill");
  _.stroke = k ?? y;
  const w = l.append("g");
  t.icon && w.html(
    `<g>${await en(t.icon, {
      height: s,
      width: s,
      fallbackPrefix: ""
    })}</g>`
  );
  const C = w.node().getBBox(), S = C.width, O = C.height, P = C.x, R = C.y, $ = Math.max(S, O) * Math.SQRT2 + f * 2, z = b.circle(0, 0, $, _), D = Math.max($, h.width), M = $ + h.height + p, L = b.rectangle(-D / 2, -M / 2, D, M, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), B = l.insert(() => z, ":first-child"), E = l.insert(() => L);
  return w.attr(
    "transform",
    `translate(${-S / 2 - P},${g ? h.height / 2 + p / 2 - O / 2 - R : -h.height / 2 - p / 2 - O / 2 - R})`
  ), w.attr("style", `color: ${x.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -M / 2 : M / 2 - h.height})`
  ), B.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + p / 2 : -h.height / 2 - p / 2})`
  ), V(t, E), t.intersect = function(A) {
    return F.info("iconSquare intersect", t, A), q.rect(t, A);
  }, l;
}
d(Jd, "iconCircle");
async function tg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), c = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, c ?? 0);
  const { shapeSvg: l, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ei(t), _ = -m / 2, k = -g / 2, w = t.label ? 8 : 0, C = Y.svg(l), S = U(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const O = b.get("fill");
  S.stroke = O ?? x;
  const P = C.path(Ke(_, k, m, g, 5), S), R = Math.max(m, h.width), $ = g + h.height + w, z = C.rectangle(-R / 2, -$ / 2, R, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), D = l.insert(() => P, ":first-child").attr("class", "icon-shape2"), M = l.insert(() => z);
  if (t.icon) {
    const L = l.append("g");
    L.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = L.node().getBBox(), E = B.width, A = B.height, W = B.x, X = B.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - W},${p ? h.height / 2 + w / 2 - A / 2 - X : -h.height / 2 - w / 2 - A / 2 - X})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -$ / 2 : $ / 2 - h.height})`
  ), D.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), V(t, M), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return q.rect(t, L);
    const B = t.x ?? 0, E = t.y ?? 0, A = t.height ?? 0;
    let W = [];
    return p ? W = [
      { x: B - h.width / 2, y: E - A / 2 },
      { x: B + h.width / 2, y: E - A / 2 },
      { x: B + h.width / 2, y: E - A / 2 + h.height + w },
      { x: B + m / 2, y: E - A / 2 + h.height + w },
      { x: B + m / 2, y: E + A / 2 },
      { x: B - m / 2, y: E + A / 2 },
      { x: B - m / 2, y: E - A / 2 + h.height + w },
      { x: B - h.width / 2, y: E - A / 2 + h.height + w }
    ] : W = [
      { x: B - m / 2, y: E - A / 2 },
      { x: B + m / 2, y: E - A / 2 },
      { x: B + m / 2, y: E - A / 2 + g },
      { x: B + h.width / 2, y: E - A / 2 + g },
      { x: B + h.width / 2 / 2, y: E + A / 2 },
      { x: B - h.width / 2, y: E + A / 2 },
      { x: B - h.width / 2, y: E - A / 2 + g },
      { x: B - m / 2, y: E - A / 2 + g }
    ], q.polygon(t, W, L);
  }, l;
}
d(tg, "iconRounded");
async function eg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), c = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, c ?? 0);
  const { shapeSvg: l, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ei(t), _ = -m / 2, k = -g / 2, w = t.label ? 8 : 0, C = Y.svg(l), S = U(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const O = b.get("fill");
  S.stroke = O ?? x;
  const P = C.path(Ke(_, k, m, g, 0.1), S), R = Math.max(m, h.width), $ = g + h.height + w, z = C.rectangle(-R / 2, -$ / 2, R, $, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), D = l.insert(() => P, ":first-child"), M = l.insert(() => z);
  if (t.icon) {
    const L = l.append("g");
    L.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = L.node().getBBox(), E = B.width, A = B.height, W = B.x, X = B.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - W},${p ? h.height / 2 + w / 2 - A / 2 - X : -h.height / 2 - w / 2 - A / 2 - X})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -$ / 2 : $ / 2 - h.height})`
  ), D.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), V(t, M), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return q.rect(t, L);
    const B = t.x ?? 0, E = t.y ?? 0, A = t.height ?? 0;
    let W = [];
    return p ? W = [
      { x: B - h.width / 2, y: E - A / 2 },
      { x: B + h.width / 2, y: E - A / 2 },
      { x: B + h.width / 2, y: E - A / 2 + h.height + w },
      { x: B + m / 2, y: E - A / 2 + h.height + w },
      { x: B + m / 2, y: E + A / 2 },
      { x: B - m / 2, y: E + A / 2 },
      { x: B - m / 2, y: E - A / 2 + h.height + w },
      { x: B - h.width / 2, y: E - A / 2 + h.height + w }
    ] : W = [
      { x: B - m / 2, y: E - A / 2 },
      { x: B + m / 2, y: E - A / 2 },
      { x: B + m / 2, y: E - A / 2 + g },
      { x: B + h.width / 2, y: E - A / 2 + g },
      { x: B + h.width / 2 / 2, y: E + A / 2 },
      { x: B - h.width / 2, y: E + A / 2 },
      { x: B - h.width / 2, y: E - A / 2 + g },
      { x: B - m / 2, y: E - A / 2 + g }
    ], q.polygon(t, W, L);
  }, l;
}
d(eg, "iconSquare");
async function rg(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = (t == null ? void 0 : t.img) ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: o } = G(t);
  t.labelStyle = o;
  const s = r == null ? void 0 : r.wrappingWidth;
  t.defaultWidth = r == null ? void 0 : r.wrappingWidth;
  const c = Math.max(
    t.label ? s ?? 0 : 0,
    (t == null ? void 0 : t.assetWidth) ?? n
  ), l = t.constraint === "on" && t != null && t.assetHeight ? t.assetHeight * t.imageAspectRatio : c, h = t.constraint === "on" ? l / t.imageAspectRatio : (t == null ? void 0 : t.assetHeight) ?? a;
  t.width = Math.max(l, s ?? 0);
  const { shapeSvg: u, bbox: f, label: p } = await et(e, t, "image-shape default"), g = t.pos === "t", m = -l / 2, y = -h / 2, x = t.label ? 8 : 0, b = Y.svg(u), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = b.rectangle(m, y, l, h, _), w = Math.max(l, f.width), C = h + f.height + x, S = b.rectangle(-w / 2, -C / 2, w, C, {
    ..._,
    fill: "none",
    stroke: "none"
  }), O = u.insert(() => k, ":first-child"), P = u.insert(() => S);
  if (t.img) {
    const R = u.append("image");
    R.attr("href", t.img), R.attr("width", l), R.attr("height", h), R.attr("preserveAspectRatio", "none"), R.attr(
      "transform",
      `translate(${-l / 2},${g ? C / 2 - h : -C / 2})`
    );
  }
  return p.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - x / 2 : h / 2 - f.height / 2 + x / 2})`
  ), O.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + x / 2 : -f.height / 2 - x / 2})`
  ), V(t, P), t.intersect = function(R) {
    if (F.info("iconSquare intersect", t, R), !t.label)
      return q.rect(t, R);
    const $ = t.x ?? 0, z = t.y ?? 0, D = t.height ?? 0;
    let M = [];
    return g ? M = [
      { x: $ - f.width / 2, y: z - D / 2 },
      { x: $ + f.width / 2, y: z - D / 2 },
      { x: $ + f.width / 2, y: z - D / 2 + f.height + x },
      { x: $ + l / 2, y: z - D / 2 + f.height + x },
      { x: $ + l / 2, y: z + D / 2 },
      { x: $ - l / 2, y: z + D / 2 },
      { x: $ - l / 2, y: z - D / 2 + f.height + x },
      { x: $ - f.width / 2, y: z - D / 2 + f.height + x }
    ] : M = [
      { x: $ - l / 2, y: z - D / 2 },
      { x: $ + l / 2, y: z - D / 2 },
      { x: $ + l / 2, y: z - D / 2 + h },
      { x: $ + f.width / 2, y: z - D / 2 + h },
      { x: $ + f.width / 2 / 2, y: z + D / 2 },
      { x: $ - f.width / 2, y: z + D / 2 },
      { x: $ - f.width / 2, y: z - D / 2 + h },
      { x: $ - l / 2, y: z - D / 2 + h }
    ], q.polygon(t, M, R);
  }, u;
}
d(rg, "imageSquare");
async function ig(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: -3 * s / 6, y: -s }
  ];
  let l;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(c), g = u.path(p, f);
    l = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && l.attr("style", h);
  } else
    l = Qe(n, o, s, c);
  return i && l.attr("style", i), t.width = o, t.height = s, V(t, l), t.intersect = function(u) {
    return q.polygon(t, c, u);
  }, n;
}
d(ig, "inv_trapezoid");
async function Wa(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o } = await et(e, t, tt(t)), s = Math.max(o.width + r.labelPaddingX * 2, (t == null ? void 0 : t.width) || 0), c = Math.max(o.height + r.labelPaddingY * 2, (t == null ? void 0 : t.height) || 0), l = -s / 2, h = -c / 2;
  let u, { rx: f, ry: p } = t;
  const { cssStyles: g } = t;
  if (r != null && r.rx && r.ry && (f = r.rx, p = r.ry), t.look === "handDrawn") {
    const m = Y.svg(a), y = U(t, {}), x = f || p ? m.path(Ke(l, h, s, c, f || 0), y) : m.rectangle(l, h, s, c, y);
    u = a.insert(() => x, ":first-child"), u.attr("class", "basic label-container").attr("style", Wt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Wt(f)).attr("ry", Wt(p)).attr("x", l).attr("y", h).attr("width", s).attr("height", c);
  return V(t, u), t.calcIntersect = function(m, y) {
    return q.rect(m, y);
  }, t.intersect = function(m) {
    return q.rect(t, m);
  }, a;
}
d(Wa, "drawRect");
async function ng(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await et(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), V(t, a), t.intersect = function(c) {
    return q.rect(t, c);
  }, r;
}
d(ng, "labelRect");
async function ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = [
    { x: 0, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: -(3 * s) / 6, y: -s }
  ];
  let l;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(c), g = u.path(p, f);
    l = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && l.attr("style", h);
  } else
    l = Qe(n, o, s, c);
  return i && l.attr("style", i), t.width = o, t.height = s, V(t, l), t.intersect = function(u) {
    return q.polygon(t, c, u);
  }, n;
}
d(ag, "lean_left");
async function sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = [
    { x: -3 * s / 6, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: 0, y: -s }
  ];
  let l;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(c), g = u.path(p, f);
    l = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && l.attr("style", h);
  } else
    l = Qe(n, o, s, c);
  return i && l.attr("style", i), t.width = o, t.height = s, V(t, l), t.intersect = function(u) {
    return q.polygon(t, c, u);
  }, n;
}
d(sg, "lean_right");
function og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, o = Math.max(35, (t == null ? void 0 : t.width) ?? 0), s = Math.max(35, (t == null ? void 0 : t.height) ?? 0), c = 7, l = [
    { x: o, y: 0 },
    { x: 0, y: s + c / 2 },
    { x: o - 2 * c, y: s + c / 2 },
    { x: 0, y: 2 * s },
    { x: o, y: s - c / 2 },
    { x: 2 * c, y: s - c / 2 }
  ], h = Y.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = lt(l), p = h.path(f, u), g = n.insert(() => p, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${o / 2},${-s})`), V(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), q.polygon(t, l, m);
  }, n;
}
d(og, "lightningBolt");
var Xv = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), Vv = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), Zv = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), c = s / 2, l = c / (2.5 + s / 50), h = Math.max(a.height + l + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: p } = t;
  if (t.look === "handDrawn") {
    const g = Y.svg(n), m = Vv(0, 0, s, h, c, l, u), y = Zv(0, l, s, h, c, l), x = U(t, {}), b = g.path(m, x), _ = g.path(y, x);
    n.insert(() => _, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), p && f.attr("style", p);
  } else {
    const g = Xv(0, 0, s, h, c, l, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Wt(p)).attr("style", i);
  }
  return f.attr("label-offset-y", l), f.attr("transform", `translate(${-s / 2}, ${-(h / 2 + l)})`), V(t, f), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + l - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = q.rect(t, g), y = m.x - (t.x ?? 0);
    if (c != 0 && (Math.abs(y) < (t.width ?? 0) / 2 || Math.abs(y) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - l)) {
      let x = l * l * (1 - y * y / (c * c));
      x > 0 && (x = Math.sqrt(x)), x = l - x, g.y - (t.y ?? 0) > 0 && (x = -x), m.y += x;
    }
    return m;
  }, n;
}
d(lg, "linedCylinder");
async function cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = c / 4, h = c + l, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: h / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      h / 2,
      s / 2 + s / 2 * 0.1,
      h / 2,
      l,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2, y: -h / 2 },
    { x: -s / 2, y: h / 2 * 1.1 },
    { x: -s / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((x) => [x.x, x.y]),
    p
  ), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(0,${-l / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - l / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, y), t.intersect = function(x) {
    return q.polygon(t, g, x);
  }, n;
}
d(cg, "linedWaveEdgedRect");
async function hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = 5, h = -s / 2, u = -c / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: h - l, y: u + l },
    { x: h - l, y: u + c + l },
    { x: h + s - l, y: u + c + l },
    { x: h + s - l, y: u + c },
    { x: h + s, y: u + c },
    { x: h + s, y: u + c - l },
    { x: h + s + l, y: u + c - l },
    { x: h + s + l, y: u - l },
    { x: h + l, y: u - l },
    { x: h + l, y: u },
    { x: h, y: u },
    { x: h, y: u + l }
  ], y = [
    { x: h, y: u + l },
    { x: h + s - l, y: u + l },
    { x: h + s - l, y: u + c },
    { x: h + s, y: u + c },
    { x: h + s, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = p.path(x, g), _ = lt(y), k = p.path(_, { ...g, fill: "none" }), w = n.insert(() => k, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) - l - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + l - (a.y - (a.top ?? 0))})`
  ), V(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(hg, "multiRect");
async function ug(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = c / 4, h = c + l, u = -s / 2, f = -h / 2, p = 5, { cssStyles: g } = t, m = Xe(
    u - p,
    f + h + p,
    u + s - p,
    f + h + p,
    l,
    0.8
  ), y = m == null ? void 0 : m[m.length - 1], x = [
    { x: u - p, y: f + p },
    { x: u - p, y: f + h + p },
    ...m,
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: y.y - 2 * p },
    { x: u + s + p, y: y.y - 2 * p },
    { x: u + s + p, y: f - p },
    { x: u + p, y: f - p },
    { x: u + p, y: f },
    { x: u, y: f },
    { x: u, y: f + p }
  ], b = [
    { x: u, y: f + p },
    { x: u + s - p, y: f + p },
    { x: u + s - p, y: y.y - p },
    { x: u + s, y: y.y - p },
    { x: u + s, y: f },
    { x: u, y: f }
  ], _ = Y.svg(n), k = U(t, {});
  t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid");
  const w = lt(x), C = _.path(w, k), S = lt(b), O = _.path(S, k), P = n.insert(() => C, ":first-child");
  return P.insert(() => O), P.attr("class", "basic label-container"), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && P.selectAll("path").attr("style", i), P.attr("transform", `translate(0,${-l / 2})`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - p - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + p - l / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, P), t.intersect = function(R) {
    return q.polygon(t, x, R);
  }, n;
}
d(ug, "multiWaveEdgedRectangle");
async function fg(e, t, { config: { themeVariables: r } }) {
  var b;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i, t.useHtmlLabels || ((b = Nt().flowchart) == null ? void 0 : b.htmlLabels) !== !1 || (t.centerLabel = !0);
  const { shapeSvg: o, bbox: s, label: c } = await et(e, t, tt(t)), l = Math.max(s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), h = Math.max(s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), u = -l / 2, f = -h / 2, { cssStyles: p } = t, g = Y.svg(o), m = U(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = g.rectangle(u, f, l, h, m), x = o.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), p && t.look !== "handDrawn" && x.selectAll("path").attr("style", p), n && t.look !== "handDrawn" && x.selectAll("path").attr("style", n), c.attr(
    "transform",
    `translate(${-s.width / 2 - (s.x - (s.left ?? 0))}, ${-(s.height / 2) - (s.y - (s.top ?? 0))})`
  ), V(t, x), t.intersect = function(_) {
    return q.rect(t, _);
  }, o;
}
d(fg, "note");
var Kv = /* @__PURE__ */ d((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, c = o + s, l = 0.5, h = [
    { x: c / 2, y: 0 },
    { x: c, y: -c / 2 },
    { x: c / 2, y: -c },
    { x: 0, y: -c / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = Y.svg(n), g = U(t, {}), m = Kv(0, 0, c), y = p.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2 + l}, ${c / 2})`), f && u.attr("style", f);
  } else
    u = Qe(n, c, c, h), u.attr("transform", `translate(${-c / 2 + l}, ${c / 2})`);
  return i && u.attr("style", i), V(t, u), t.calcIntersect = function(p, g) {
    const m = p.width, y = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], x = q.polygon(p, y, g);
    return { x: x.x - 0.5, y: x.y - 0.5 };
  }, t.intersect = function(p) {
    return this.calcIntersect(t, p);
  }, n;
}
d(pg, "question");
async function dg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = -s / 2, h = -c / 2, u = h / 2, f = [
    { x: l + u, y: h },
    { x: l, y: 0 },
    { x: l + u, y: -h },
    { x: -l, y: -h },
    { x: -l, y: h }
  ], { cssStyles: p } = t, g = Y.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = lt(f), x = g.path(y, m), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container"), p && t.look !== "handDrawn" && b.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), o.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return q.polygon(t, f, _);
  }, n;
}
d(dg, "rect_left_inv_arrow");
async function gg(e, t) {
  var O, P;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = a.insert("g"), s = a.insert("g").attr("class", "label").attr("style", i), c = t.description, l = t.label, h = s.node().appendChild(await lr(l, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (At((P = (O = ft()) == null ? void 0 : O.flowchart) == null ? void 0 : P.htmlLabels)) {
    const R = h.children[0], $ = ht(h);
    u = R.getBoundingClientRect(), $.attr("width", u.width), $.attr("height", u.height);
  }
  F.info("Text 2", c);
  const f = c || [], p = h.getBBox(), g = s.node().appendChild(
    await lr(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], y = ht(g);
  u = m.getBoundingClientRect(), y.attr("width", u.width), y.attr("height", u.height);
  const x = (t.padding || 0) / 2;
  ht(g).attr(
    "transform",
    "translate( " + (u.width > p.width ? 0 : (p.width - u.width) / 2) + ", " + (p.height + x + 5) + ")"
  ), ht(h).attr(
    "transform",
    "translate( " + (u.width < p.width ? 0 : -(p.width - u.width) / 2) + ", 0)"
  ), u = s.node().getBBox(), s.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - x + 3) + ")"
  );
  const b = u.width + (t.padding || 0), _ = u.height + (t.padding || 0), k = -u.width / 2 - x, w = -u.height / 2 - x;
  let C, S;
  if (t.look === "handDrawn") {
    const R = Y.svg(a), $ = U(t, {}), z = R.path(
      Ke(k, w, b, _, t.rx || 0),
      $
    ), D = R.line(
      -u.width / 2 - x,
      -u.height / 2 - x + p.height + x,
      u.width / 2 + x,
      -u.height / 2 - x + p.height + x,
      $
    );
    S = a.insert(() => (F.debug("Rough node insert CXC", z), D), ":first-child"), C = a.insert(() => (F.debug("Rough node insert CXC", z), z), ":first-child");
  } else
    C = o.insert("rect", ":first-child"), S = o.insert("line"), C.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - x).attr("y", -u.height / 2 - x).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), S.attr("class", "divider").attr("x1", -u.width / 2 - x).attr("x2", u.width / 2 + x).attr("y1", -u.height / 2 - x + p.height + x).attr("y2", -u.height / 2 - x + p.height + x);
  return V(t, C), t.intersect = function(R) {
    return q.rect(t, R);
  }, a;
}
d(gg, "rectWithTitle");
function Si(e, t, r, i, n, a, o) {
  const c = (e + r) / 2, l = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = c + y * a * Math.sin(h) * (o ? -1 : 1), b = l - y * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let w = Math.atan2((i - b) / a, (r - x) / n) - _;
  o && w < 0 && (w += 2 * Math.PI), !o && w > 0 && (w -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const O = S / 19, P = _ + O * w, R = x + n * Math.cos(P), $ = b + a * Math.sin(P);
    C.push({ x: R, y: $ });
  }
  return C;
}
d(Si, "generateArcPoints");
async function mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = (t == null ? void 0 : t.padding) ?? 0, s = (t == null ? void 0 : t.padding) ?? 0, c = (t != null && t.width ? t == null ? void 0 : t.width : a.width) + o * 2, l = (t != null && t.height ? t == null ? void 0 : t.height : a.height) + s * 2, h = t.radius || 5, u = t.taper || 5, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.stroke && (g.stroke = t.stroke), t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    // Top edge (left to right)
    { x: -c / 2 + u, y: -l / 2 },
    // Top-left corner start (1)
    { x: c / 2 - u, y: -l / 2 },
    // Top-right corner start (2)
    ...Si(c / 2 - u, -l / 2, c / 2, -l / 2 + u, h, h, !0),
    // Top-left arc (2 to 3)
    // Right edge (top to bottom)
    { x: c / 2, y: -l / 2 + u },
    // Top-right taper point (3)
    { x: c / 2, y: l / 2 - u },
    // Bottom-right taper point (4)
    ...Si(c / 2, l / 2 - u, c / 2 - u, l / 2, h, h, !0),
    // Top-left arc (4 to 5)
    // Bottom edge (right to left)
    { x: c / 2 - u, y: l / 2 },
    // Bottom-right corner start (5)
    { x: -c / 2 + u, y: l / 2 },
    // Bottom-left corner start (6)
    ...Si(-c / 2 + u, l / 2, -c / 2, l / 2 - u, h, h, !0),
    // Top-left arc (4 to 5)
    // Left edge (bottom to top)
    { x: -c / 2, y: l / 2 - u },
    // Bottom-left taper point (7)
    { x: -c / 2, y: -l / 2 + u },
    // Top-left taper point (8)
    ...Si(-c / 2, -l / 2 + u, -c / 2 + u, -l / 2, h, h, !0)
    // Top-left arc (4 to 5)
  ], y = lt(m), x = p.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && b.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && b.selectChildren("path").attr("style", i), V(t, b), t.intersect = function(_) {
    return q.polygon(t, m, _);
  }, n;
}
d(mg, "roundedRect");
async function yg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = (t == null ? void 0 : t.padding) ?? 0, c = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -a.width / 2 - s, u = -a.height / 2 - s, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + c + 8, y: u },
    { x: h + c + 8, y: u + l },
    { x: h - 8, y: u + l },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + l }
  ], y = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container").attr("style", Wt(f)), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-c / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.rect(t, b);
  }, n;
}
d(yg, "shadedProcess");
async function xg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = -s / 2, h = -c / 2, { cssStyles: u } = t, f = Y.svg(n), p = U(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: l, y: h },
    { x: l, y: h + c },
    { x: l + s, y: h + c },
    { x: l + s, y: h - c / 2 }
  ], m = lt(g), y = f.path(m, p), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), x.attr("transform", `translate(0, ${c / 4})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-c / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return q.polygon(t, g, b);
  }, n;
}
d(xg, "slopedRect");
async function bg(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? ((t == null ? void 0 : t.padding) || 0) * 2,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return Wa(e, t, r);
}
d(bg, "squareRect");
async function Cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = a.width + o / 4 + t.padding, c = o / 2, { cssStyles: l } = t, h = Y.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = [
    { x: -s / 2 + c, y: -o / 2 },
    { x: s / 2 - c, y: -o / 2 },
    ...ji(-s / 2 + c, 0, c, 50, 90, 270),
    { x: s / 2 - c, y: o / 2 },
    ...ji(s / 2 - c, 0, c, 50, 270, 450)
  ], p = lt(f), g = h.path(p, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), l && t.look !== "handDrawn" && m.selectChildren("path").attr("style", l), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), V(t, m), t.intersect = function(y) {
    return q.polygon(t, f, y);
  }, n;
}
d(Cg, "stadium");
async function _g(e, t) {
  return Wa(e, t, {
    rx: 5,
    ry: 5
  });
}
d(_g, "state");
function wg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: o, stateBorder: s, nodeBorder: c } = r, l = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = Y.svg(l), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: o,
    strokeWidth: 2
  }), p = s ?? c, g = h.circle(0, 0, 5, {
    ...u,
    fill: p,
    stroke: p,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = l.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), V(t, m), t.intersect = function(y) {
    return q.circle(t, 7, y);
  }, l;
}
d(wg, "stateEnd");
function kg(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const s = Y.svg(n).circle(0, 0, 14, uC(i));
    a = n.insert(() => s), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return V(t, a), t.intersect = function(o) {
    return q.circle(t, 7, o);
  }, n;
}
d(kg, "stateStart");
async function vg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = ((t == null ? void 0 : t.padding) || 0) / 2, s = a.width + t.padding, c = a.height + t.padding, l = -a.width / 2 - o, h = -a.height / 2 - o, u = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s, y: -c },
    { x: 0, y: -c },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: s + 8, y: 0 },
    { x: s + 8, y: -c },
    { x: -8, y: -c },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = Y.svg(n), p = U(t, {}), g = f.rectangle(l - 8, h, s + 16, c, p), m = f.line(l, h, l, h + c, p), y = f.line(l + s, h, l + s, h + c, p);
    n.insert(() => m, ":first-child"), n.insert(() => y, ":first-child");
    const x = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    x.attr("class", "basic label-container").attr("style", Wt(b)), V(t, x);
  } else {
    const f = Qe(n, s, c, u);
    i && f.attr("style", i), V(t, f);
  }
  return t.intersect = function(f) {
    return q.polygon(t, u, f);
  }, n;
}
d(vg, "subroutine");
async function Sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = -o / 2, l = -s / 2, h = 0.2 * s, u = 0.2 * s, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: c - h / 2, y: l },
    { x: c + o + h / 2, y: l },
    { x: c + o + h / 2, y: l + s },
    { x: c - h / 2, y: l + s }
  ], y = [
    { x: c + o - h / 2, y: l + s },
    { x: c + o + h / 2, y: l + s },
    { x: c + o + h / 2, y: l + s - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(m), b = p.path(x, g), _ = lt(y), k = p.path(_, { ...g, fillStyle: "solid" }), w = n.insert(() => k, ":first-child");
  return w.insert(() => b, ":first-child"), w.attr("class", "basic label-container"), f && t.look !== "handDrawn" && w.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), V(t, w), t.intersect = function(C) {
    return q.polygon(t, m, C);
  }, n;
}
d(Sg, "taggedRect");
async function Tg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = c / 4, h = 0.2 * s, u = 0.2 * c, f = c + l, { cssStyles: p } = t, g = Y.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = [
    { x: -s / 2 - s / 2 * 0.1, y: f / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      f / 2,
      s / 2 + s / 2 * 0.1,
      f / 2,
      l,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -f / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -f / 2 }
  ], x = -s / 2 + s / 2 * 0.1, b = -f / 2 - u * 0.4, _ = [
    { x: x + s - h, y: (b + c) * 1.4 },
    { x: x + s, y: b + c - u },
    { x: x + s, y: (b + c) * 0.9 },
    ...Xe(
      x + s,
      (b + c) * 1.3,
      x + s - h,
      (b + c) * 1.5,
      -c * 0.03,
      0.5
    )
  ], k = lt(y), w = g.path(k, m), C = lt(_), S = g.path(C, {
    ...m,
    fillStyle: "solid"
  }), O = n.insert(() => S, ":first-child");
  return O.insert(() => w, ":first-child"), O.attr("class", "basic label-container"), p && t.look !== "handDrawn" && O.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && O.selectAll("path").attr("style", i), O.attr("transform", `translate(0,${-l / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - l / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, O), t.intersect = function(P) {
    return q.polygon(t, y, P);
  }, n;
}
d(Tg, "taggedWaveEdgedRectangle");
async function Bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + t.padding, (t == null ? void 0 : t.width) || 0), s = Math.max(a.height + t.padding, (t == null ? void 0 : t.height) || 0), c = -o / 2, l = -s / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", c).attr("y", l).attr("width", o).attr("height", s), V(t, h), t.intersect = function(u) {
    return q.rect(t, u);
  }, n;
}
d(Bg, "text");
var Qv = /* @__PURE__ */ d((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), Jv = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), tS = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o, halfPadding: s } = await et(
    e,
    t,
    tt(t)
  ), c = t.look === "neo" ? s * 2 : s, l = a.height + c, h = l / 2, u = h / (2.5 + l / 50), f = a.width + u + c, { cssStyles: p } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = Y.svg(n), y = Jv(0, 0, f, l, u, h), x = tS(0, 0, f, l, u, h), b = m.path(y, U(t, {})), _ = m.path(x, U(t, { fill: "none" }));
    g = n.insert(() => _, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), p && g.attr("style", p);
  } else {
    const m = Qv(0, 0, f, l, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Wt(p)).attr("style", i), g.attr("class", "basic label-container"), p && g.selectAll("path").attr("style", p), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${l / 2} )`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, g), t.intersect = function(m) {
    const y = q.rect(t, m), x = y.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(y.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - x * x / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), y.x += b;
    }
    return y;
  }, n;
}
d(Lg, "tiltedCylinder");
async function Ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, c = [
    { x: -3 * s / 6, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: 0, y: -s }
  ];
  let l;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = Y.svg(n), f = U(t, {}), p = lt(c), g = u.path(p, f);
    l = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && l.attr("style", h);
  } else
    l = Qe(n, o, s, c);
  return i && l.attr("style", i), t.width = o, t.height = s, V(t, l), t.intersect = function(u) {
    return q.polygon(t, c, u);
  }, n;
}
d(Ag, "trapezoid");
async function Mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 60, s = 20, c = Math.max(o, a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), { cssStyles: h } = t, u = Y.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const p = [
    { x: -c / 2 * 0.8, y: -l / 2 },
    { x: c / 2 * 0.8, y: -l / 2 },
    { x: c / 2, y: -l / 2 * 0.6 },
    { x: c / 2, y: l / 2 },
    { x: -c / 2, y: l / 2 },
    { x: -c / 2, y: -l / 2 * 0.6 }
  ], g = lt(p), m = u.path(g, f), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), V(t, y), t.intersect = function(x) {
    return q.polygon(t, p, x);
  }, n;
}
d(Mg, "trapezoidalPentagon");
async function $g(e, t) {
  var b;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = At((b = ft().flowchart) == null ? void 0 : b.htmlLabels), c = a.width + (t.padding ?? 0), l = c + a.height, h = c + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -l }
  ], { cssStyles: f } = t, p = Y.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = lt(u), y = p.path(m, g), x = n.insert(() => y, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return f && t.look !== "handDrawn" && x.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = c, t.height = l, V(t, x), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${l / 2 - (a.height + (t.padding ?? 0) / (s ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(_) {
    return F.info("Triangle intersect", t, u, _), q.polygon(t, u, _);
  }, n;
}
d($g, "triangle");
async function Eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = c / 8, h = c + l, { cssStyles: u } = t, p = 70 - s, g = p > 0 ? p / 2 : 0, m = Y.svg(n), y = U(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const x = [
    { x: -s / 2 - g, y: h / 2 },
    ...Xe(
      -s / 2 - g,
      h / 2,
      s / 2 + g,
      h / 2,
      l,
      0.8
    ),
    { x: s / 2 + g, y: -h / 2 },
    { x: -s / 2 - g, y: -h / 2 }
  ], b = lt(x), _ = m.path(b, y), k = n.insert(() => _, ":first-child");
  return k.attr("class", "basic label-container"), u && t.look !== "handDrawn" && k.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(0,${-l / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - l - (a.y - (a.top ?? 0))})`
  ), V(t, k), t.intersect = function(w) {
    return q.polygon(t, x, w);
  }, n;
}
d(Eg, "waveEdgedRectangle");
async function Fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 100, s = 50, c = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / l;
  let u = c, f = l;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, o), f = Math.max(f, s);
  const p = Math.min(f * 0.2, f / 4), g = f + p * 2, { cssStyles: m } = t, y = Y.svg(n), x = U(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Xe(-u / 2, g / 2, u / 2, g / 2, p, 1),
    { x: u / 2, y: -g / 2 },
    ...Xe(u / 2, -g / 2, -u / 2, -g / 2, p, -1)
  ], _ = lt(b), k = y.path(_, x), w = n.insert(() => k, ":first-child");
  return w.attr("class", "basic label-container"), m && t.look !== "handDrawn" && w.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && w.selectAll("path").attr("style", i), V(t, w), t.intersect = function(C) {
    return q.polygon(t, b, C);
  }, n;
}
d(Fg, "waveRectangle");
async function Og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = 5, h = -s / 2, u = -c / 2, { cssStyles: f } = t, p = Y.svg(n), g = U(t, {}), m = [
    { x: h - l, y: u - l },
    { x: h - l, y: u + c },
    { x: h + s, y: u + c },
    { x: h + s, y: u - l }
  ], y = `M${h - l},${u - l} L${h + s},${u - l} L${h + s},${u + c} L${h - l},${u + c} L${h - l},${u - l}
                M${h - l},${u} L${h + s},${u}
                M${h},${u - l} L${h},${u + c}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = p.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("transform", `translate(${l / 2}, ${l / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) + l / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + l / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return q.polygon(t, m, _);
  }, n;
}
d(Og, "windowPane");
async function bl(e, t) {
  var ut, nt, gt, st;
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: at } = Nt(), { background: ct } = at, wt = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${ct}`]
    };
    await bl(e, wt);
  }
  const i = Nt();
  t.useHtmlLabels = i.htmlLabels;
  let n = ((ut = i.er) == null ? void 0 : ut.diagramPadding) ?? 10, a = ((nt = i.er) == null ? void 0 : nt.entityPadding) ?? 6;
  const { cssStyles: o } = t, { labelStyles: s, nodeStyles: c } = G(t);
  if (r.attributes.length === 0 && t.label) {
    const at = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    Ne(t.label, i) + at.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const ct = await Wa(e, t, at);
    if (!At(i.htmlLabels)) {
      const wt = ct.select("text"), yt = (gt = wt.node()) == null ? void 0 : gt.getBBox();
      wt.attr("transform", `translate(${-yt.width / 2}, 0)`);
    }
    return ct;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let l = tt(t);
  l || (l = "node default");
  const h = e.insert("g").attr("class", l).attr("id", t.domId || t.id), u = await Er(h, t.label ?? "", i, 0, 0, ["name"], s);
  u.height += a;
  let f = 0;
  const p = [], g = [];
  let m = 0, y = 0, x = 0, b = 0, _ = !0, k = !0;
  for (const at of r.attributes) {
    const ct = await Er(
      h,
      at.type,
      i,
      0,
      f,
      ["attribute-type"],
      s
    );
    m = Math.max(m, ct.width + n);
    const wt = await Er(
      h,
      at.name,
      i,
      0,
      f,
      ["attribute-name"],
      s
    );
    y = Math.max(y, wt.width + n);
    const yt = await Er(
      h,
      at.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      s
    );
    x = Math.max(x, yt.width + n);
    const xt = await Er(
      h,
      at.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      s
    );
    b = Math.max(b, xt.width + n);
    const vt = Math.max(ct.height, wt.height, yt.height, xt.height) + a;
    g.push({ yOffset: f, rowHeight: vt }), f += vt;
  }
  let w = 4;
  x <= n && (_ = !1, x = 0, w--), b <= n && (k = !1, b = 0, w--);
  const C = h.node().getBBox();
  if (u.width + n * 2 - (m + y + x + b) > 0) {
    const at = u.width + n * 2 - (m + y + x + b);
    m += at / w, y += at / w, x > 0 && (x += at / w), b > 0 && (b += at / w);
  }
  const S = m + y + x + b, O = Y.svg(h), P = U(t, {});
  t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid");
  let R = 0;
  g.length > 0 && (R = g.reduce((at, ct) => at + ((ct == null ? void 0 : ct.rowHeight) ?? 0), 0));
  const $ = Math.max(C.width + n * 2, (t == null ? void 0 : t.width) || 0, S), z = Math.max((R ?? 0) + u.height, (t == null ? void 0 : t.height) || 0), D = -$ / 2, M = -z / 2;
  h.selectAll("g:not(:first-child)").each((at, ct, wt) => {
    const yt = ht(wt[ct]), xt = yt.attr("transform");
    let vt = 0, Ht = 0;
    if (xt) {
      const le = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(xt);
      le && (vt = parseFloat(le[1]), Ht = parseFloat(le[2]), yt.attr("class").includes("attribute-name") ? vt += m : yt.attr("class").includes("attribute-keys") ? vt += m + y : yt.attr("class").includes("attribute-comment") && (vt += m + y + x));
    }
    yt.attr(
      "transform",
      `translate(${D + n / 2 + vt}, ${Ht + M + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (M + a / 2) + ")");
  const L = O.rectangle(D, M, $, z, P), B = h.insert(() => L, ":first-child").attr("style", o.join("")), { themeVariables: E } = Nt(), { rowEven: A, rowOdd: W, nodeBorder: X } = E;
  p.push(0);
  for (const [at, ct] of g.entries()) {
    const yt = (at + 1) % 2 === 0 && ct.yOffset !== 0, xt = O.rectangle(D, u.height + M + (ct == null ? void 0 : ct.yOffset), $, ct == null ? void 0 : ct.rowHeight, {
      ...P,
      fill: yt ? A : W,
      stroke: X
    });
    h.insert(() => xt, "g.label").attr("style", o.join("")).attr("class", `row-rect-${yt ? "even" : "odd"}`);
  }
  let H = O.line(D, u.height + M, $ + D, u.height + M, P);
  h.insert(() => H).attr("class", "divider"), H = O.line(m + D, u.height + M, m + D, z + M, P), h.insert(() => H).attr("class", "divider"), _ && (H = O.line(
    m + y + D,
    u.height + M,
    m + y + D,
    z + M,
    P
  ), h.insert(() => H).attr("class", "divider")), k && (H = O.line(
    m + y + x + D,
    u.height + M,
    m + y + x + D,
    z + M,
    P
  ), h.insert(() => H).attr("class", "divider"));
  for (const at of p)
    H = O.line(
      D,
      u.height + M + at,
      $ + D,
      u.height + M + at,
      P
    ), h.insert(() => H).attr("class", "divider");
  if (V(t, B), c && t.look !== "handDrawn") {
    const at = c.split(";"), ct = (st = at == null ? void 0 : at.filter((wt) => wt.includes("stroke"))) == null ? void 0 : st.map((wt) => `${wt}`).join("; ");
    h.selectAll("path").attr("style", ct ?? ""), h.selectAll(".row-rect-even path").attr("style", c);
  }
  return t.intersect = function(at) {
    return q.rect(t, at);
  }, h;
}
d(bl, "erBox");
async function Er(e, t, r, i = 0, n = 0, a = [], o = "") {
  const s = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", o);
  t !== Jl(t) && (t = Jl(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const c = s.node().appendChild(
    await Ze(
      s,
      t,
      {
        width: Ne(t, r) + 100,
        style: o,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = c.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let l = c.getBBox();
  if (At(r.htmlLabels)) {
    const h = c.children[0];
    h.style.textAlign = "start";
    const u = ht(c);
    l = h.getBoundingClientRect(), u.attr("width", l.width), u.attr("height", l.height);
  }
  return l;
}
d(Er, "addText");
async function Dg(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, o = e.insert("g").attr("class", tt(t)).attr("id", t.domId || t.id);
  let s = null, c = null, l = null, h = null, u = 0, f = 0, p = 0;
  if (s = o.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await Ti(s, { text: `«${b}»` }, 0), u = s.node().getBBox().height;
  }
  c = o.insert("g").attr("class", "label-group text"), await Ti(c, t, 0, ["font-weight: bolder"]);
  const g = c.node().getBBox();
  f = g.height, l = o.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const _ = await Ti(l, b, m, [b.parseClassifier()]);
    m += _ + a;
  }
  p = l.node().getBBox().height, p <= 0 && (p = n / 2), h = o.insert("g").attr("class", "methods-group text");
  let y = 0;
  for (const b of t.methods) {
    const _ = await Ti(h, b, y, [b.parseClassifier()]);
    y += _ + a;
  }
  let x = o.node().getBBox();
  if (s !== null) {
    const b = s.node().getBBox();
    s.attr("transform", `translate(${-b.width / 2})`);
  }
  return c.attr("transform", `translate(${-g.width / 2}, ${u})`), x = o.node().getBBox(), l.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), x = o.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (p ? p + n * 4 : n * 2)})`
  ), x = o.node().getBBox(), { shapeSvg: o, bbox: x };
}
d(Dg, "textHelper");
async function Ti(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Nt();
  let o = "useHtmlLabels" in t ? t.useHtmlLabels : At(a.htmlLabels) ?? !0, s = "";
  "text" in t ? s = t.text : s = t.label, !o && s.startsWith("\\") && (s = s.substring(1)), Gr(s) && (o = !0);
  const c = await Ze(
    n,
    Lo(_r(s)),
    {
      width: Ne(s, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o
    },
    a
  );
  let l, h = 1;
  if (o) {
    const u = c.children[0], f = ht(c);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const p = u.getElementsByTagName("img");
    if (p) {
      const g = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...p].map(
          (m) => new Promise((y) => {
            function x() {
              var b;
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const _ = ((b = a.fontSize) == null ? void 0 : b.toString()) ?? window.getComputedStyle(document.body).fontSize, w = parseInt(_, 10) * 5 + "px";
                m.style.minWidth = w, m.style.maxWidth = w;
              } else
                m.style.width = "100%";
              y(m);
            }
            d(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    l = u.getBoundingClientRect(), f.attr("width", l.width), f.attr("height", l.height);
  } else {
    i.includes("font-weight: bolder") && ht(c).selectAll("tspan").attr("font-weight", ""), h = c.children.length;
    const u = c.children[0];
    (c.textContent === "" || c.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), l = c.getBBox();
  }
  return n.attr("transform", "translate(0," + (-l.height / (2 * h) + r) + ")"), l.height;
}
d(Ti, "addText");
async function Rg(e, t) {
  var P, R;
  const r = ft(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? At(r.htmlLabels) ?? !0, o = t;
  o.annotations = o.annotations ?? [], o.members = o.members ?? [], o.methods = o.methods ?? [];
  const { shapeSvg: s, bbox: c } = await Dg(e, t, r, a, n), { labelStyles: l, nodeStyles: h } = G(t);
  t.labelStyle = l, t.cssStyles = o.styles || "";
  const u = ((P = o.styles) == null ? void 0 : P.join(";")) || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = o.members.length === 0 && o.methods.length === 0 && !((R = r.class) != null && R.hideEmptyMembersBox), p = Y.svg(s), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = c.width;
  let y = c.height;
  o.members.length === 0 && o.methods.length === 0 ? y += n : o.members.length > 0 && o.methods.length === 0 && (y += n * 2);
  const x = -m / 2, b = -y / 2, _ = p.rectangle(
    x - i,
    b - i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    y + 2 * i + (f ? i * 2 : o.members.length === 0 && o.methods.length === 0 ? -i : 0),
    g
  ), k = s.insert(() => _, ":first-child");
  k.attr("class", "basic label-container");
  const w = k.node().getBBox();
  s.selectAll(".text").each(($, z, D) => {
    var W;
    const M = ht(D[z]), L = M.attr("transform");
    let B = 0;
    if (L) {
      const H = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(L);
      H && (B = parseFloat(H[2]));
    }
    let E = B + b + i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0);
    a || (E -= 4);
    let A = x;
    (M.attr("class").includes("label-group") || M.attr("class").includes("annotation-group")) && (A = -((W = M.node()) == null ? void 0 : W.getBBox().width) / 2 || 0, s.selectAll("text").each(function(X, H, ut) {
      window.getComputedStyle(ut[H]).textAnchor === "middle" && (A = 0);
    })), M.attr("transform", `translate(${A}, ${E})`);
  });
  const C = s.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, S = s.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, O = s.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (o.members.length > 0 || o.methods.length > 0 || f) {
    const $ = p.line(
      w.x,
      C + S + b + i,
      w.x + w.width,
      C + S + b + i,
      g
    );
    s.insert(() => $).attr("class", "divider").attr("style", u);
  }
  if (f || o.members.length > 0 || o.methods.length > 0) {
    const $ = p.line(
      w.x,
      C + S + O + b + n * 2 + i,
      w.x + w.width,
      C + S + O + b + i + n * 2,
      g
    );
    s.insert(() => $).attr("class", "divider").attr("style", u);
  }
  if (o.look !== "handDrawn" && s.selectAll("path").attr("style", u), k.select(":nth-child(2)").attr("style", u), s.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? s.selectAll("span").attr("style", t.labelStyle) : s.selectAll("span").attr("style", u), !a) {
    const $ = RegExp(/color\s*:\s*([^;]*)/), z = $.exec(u);
    if (z) {
      const D = z[0].replace("color", "fill");
      s.selectAll("tspan").attr("style", D);
    } else if (l) {
      const D = $.exec(l);
      if (D) {
        const M = D[0].replace("color", "fill");
        s.selectAll("tspan").attr("style", M);
      }
    }
  }
  return V(t, k), t.intersect = function($) {
    return q.rect(t, $);
  }, s;
}
d(Rg, "classBox");
async function Ig(e, t) {
  var C, S;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = t, a = t, o = 20, s = 20, c = "verifyMethod" in t, l = tt(t), h = e.insert("g").attr("class", l).attr("id", t.domId ?? t.id);
  let u;
  c ? u = await be(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await be(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const p = await be(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += p + s, c) {
    const O = await be(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += O;
    const P = await be(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += P;
    const R = await be(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += R, await be(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const O = await be(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += O, await be(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (((C = h.node()) == null ? void 0 : C.getBBox().width) ?? 200) + o, m = (((S = h.node()) == null ? void 0 : S.getBBox().height) ?? 200) + o, y = -g / 2, x = -m / 2, b = Y.svg(h), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = b.rectangle(y, x, g, m, _), w = h.insert(() => k, ":first-child");
  if (w.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((O, P, R) => {
    const $ = ht(R[P]), z = $.attr("transform");
    let D = 0, M = 0;
    if (z) {
      const A = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(z);
      A && (D = parseFloat(A[1]), M = parseFloat(A[2]));
    }
    const L = M - m / 2;
    let B = y + o / 2;
    (P === 0 || P === 1) && (B = D), $.attr("transform", `translate(${B}, ${L + o})`);
  }), f > u + p + s) {
    const O = b.line(
      y,
      x + u + p + s,
      y + g,
      x + u + p + s,
      _
    );
    h.insert(() => O).attr("style", i);
  }
  return V(t, w), t.intersect = function(O) {
    return q.rect(t, O);
  }, h;
}
d(Ig, "requirementBox");
async function be(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = ft(), o = a.htmlLabels ?? !0, s = await Ze(
    n,
    Lo(_r(t)),
    {
      width: Ne(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o,
      style: i
    },
    a
  );
  let c;
  if (o) {
    const l = s.children[0], h = ht(s);
    c = l.getBoundingClientRect(), h.attr("width", c.width), h.attr("height", c.height);
  } else {
    const l = s.children[0];
    for (const h of l.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    c = s.getBBox(), c.height += 6;
  }
  return n.attr("transform", `translate(${-c.width / 2},${-c.height / 2 + r})`), c.height;
}
d(be, "addText");
var eS = /* @__PURE__ */ d((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Pg(e, t, { config: r }) {
  var z, D;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i || "";
  const a = 10, o = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: s,
    bbox: c,
    label: l
  } = await et(e, t, tt(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && ((z = r == null ? void 0 : r.kanban) != null && z.ticketBaseUrl) && (u = (D = r == null ? void 0 : r.kanban) == null ? void 0 : D.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const p = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await bs(
    f,
    "ticket" in t && t.ticket || "",
    p
  ) : { label: g, bbox: m } = await bs(
    s,
    "ticket" in t && t.ticket || "",
    p
  );
  const { label: y, bbox: x } = await bs(
    s,
    "assigned" in t && t.assigned || "",
    p
  );
  t.width = o;
  const b = 10, _ = (t == null ? void 0 : t.width) || 0, k = Math.max(m.height, x.height) / 2, w = Math.max(c.height + b * 2, (t == null ? void 0 : t.height) || 0) + k, C = -_ / 2, S = -w / 2;
  l.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-k - c.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-k + c.height / 2) + ")"
  ), y.attr(
    "transform",
    "translate(" + (h + _ / 2 - x.width - 2 * a) + ", " + (-k + c.height / 2) + ")"
  );
  let O;
  const { rx: P, ry: R } = t, { cssStyles: $ } = t;
  if (t.look === "handDrawn") {
    const M = Y.svg(s), L = U(t, {}), B = P || R ? M.path(Ke(C, S, _, w, P || 0), L) : M.rectangle(C, S, _, w, L);
    O = s.insert(() => B, ":first-child"), O.attr("class", "basic label-container").attr("style", $ || null);
  } else {
    O = s.insert("rect", ":first-child"), O.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", P ?? 5).attr("ry", R ?? 5).attr("x", C).attr("y", S).attr("width", _).attr("height", w);
    const M = "priority" in t && t.priority;
    if (M) {
      const L = s.append("line"), B = C + 2, E = S + Math.floor((P ?? 0) / 2), A = S + w - Math.floor((P ?? 0) / 2);
      L.attr("x1", B).attr("y1", E).attr("x2", B).attr("y2", A).attr("stroke-width", "4").attr("stroke", eS(M));
    }
  }
  return V(t, O), t.height = w, t.intersect = function(M) {
    return q.rect(t, M);
  }, s;
}
d(Pg, "kanbanItem");
async function Ng(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), c = a.width + 10 * o, l = a.height + 8 * o, h = 0.15 * c, { cssStyles: u } = t, f = a.width + 20, p = a.height + 20, g = Math.max(c, f), m = Math.max(l, p);
  s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let y;
  const x = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = Y.svg(n), _ = U(t, {}), k = b.path(x, _);
    y = n.insert(() => k, ":first-child"), y.attr("class", "basic label-container").attr("style", Wt(u));
  } else
    y = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return y.attr("transform", `translate(${-g / 2}, ${-m / 2})`), V(t, y), t.calcIntersect = function(b, _) {
    return q.rect(b, _);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), q.rect(t, b);
  }, n;
}
d(Ng, "bang");
async function zg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), c = a.width + 2 * o, l = a.height + 2 * o, h = 0.15 * c, u = 0.25 * c, f = 0.35 * c, p = 0.2 * c, { cssStyles: g } = t;
  let m;
  const y = `M0 0 
    a${h},${h} 0 0,1 ${c * 0.25},${-1 * c * 0.1}
    a${f},${f} 1 0,1 ${c * 0.4},${-1 * c * 0.1}
    a${u},${u} 1 0,1 ${c * 0.35},${c * 0.2}

    a${h},${h} 1 0,1 ${c * 0.15},${l * 0.35}
    a${p},${p} 1 0,1 ${-1 * c * 0.15},${l * 0.65}

    a${u},${h} 1 0,1 ${-1 * c * 0.25},${c * 0.15}
    a${f},${f} 1 0,1 ${-1 * c * 0.5},0
    a${h},${h} 1 0,1 ${-1 * c * 0.25},${-1 * c * 0.15}

    a${h},${h} 1 0,1 ${-1 * c * 0.1},${-1 * l * 0.35}
    a${p},${p} 1 0,1 ${c * 0.1},${-1 * l * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const x = Y.svg(n), b = U(t, {}), _ = x.path(y, b);
    m = n.insert(() => _, ":first-child"), m.attr("class", "basic label-container").attr("style", Wt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-c / 2}, ${-l / 2})`), V(t, m), t.calcIntersect = function(x, b) {
    return q.rect(x, b);
  }, t.intersect = function(x) {
    return F.info("Cloud intersect", t, x), q.rect(t, x);
  }, n;
}
d(zg, "cloud");
async function Wg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), c = a.width + 8 * o, l = a.height + 2 * o, h = 5, u = `
    M${-c / 2} ${l / 2 - h}
    v${-l + 2 * h}
    q0,-${h} ${h},-${h}
    h${c - 2 * h}
    q${h},0 ${h},${h}
    v${l - 2 * h}
    q0,${h} -${h},${h}
    h${-c + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, f = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -c / 2).attr("y1", l / 2).attr("x2", c / 2).attr("y2", l / 2), s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => s.node()), V(t, f), t.calcIntersect = function(p, g) {
    return q.rect(p, g);
  }, t.intersect = function(p) {
    return q.rect(t, p);
  }, n;
}
d(Wg, "defaultMindmapNode");
async function qg(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return xl(e, t, r);
}
d(qg, "mindmapCircle");
var rS = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: bg
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: mg
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: Cg
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: vg
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: Hd
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: xl
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: Ng
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: zg
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: pg
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: Zd
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: sg
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: ag
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: Ag
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: ig
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: Yd
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Bg
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Dd
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: yg
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: kg
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: wg
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: Xd
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: Kd
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: Nd
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: zd
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: Wd
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: og
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Eg
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: Vd
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Lg
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: lg
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: qd
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: jd
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: $g
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Og
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: Ud
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Mg
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: Gd
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: xg
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: ug
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: hg
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Od
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Pd
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: Tg
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: Sg
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Fg
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: dg
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: cg
  }
], iS = /* @__PURE__ */ d(() => {
  const t = [
    ...Object.entries({
      // States
      state: _g,
      choice: Rd,
      note: fg,
      // Rectangles
      rectWithTitle: gg,
      labelRect: ng,
      // Icons
      iconSquare: eg,
      iconCircle: Jd,
      icon: Qd,
      iconRounded: tg,
      imageSquare: rg,
      anchor: Fd,
      // Kanban diagram
      kanbanItem: Pg,
      //Mindmap diagram
      mindmapCircle: qg,
      defaultMindmapNode: Wg,
      // class diagram
      classBox: Rg,
      // er diagram
      erBox: bl,
      // Requirement diagram
      requirementBox: Ig
    }),
    ...rS.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), Hg = iS();
function nS(e) {
  return e in Hg;
}
d(nS, "isValidShape");
var qa = /* @__PURE__ */ new Map();
async function jg(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? Hg[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let o;
    r.config.securityLevel === "sandbox" ? o = "_top" : t.linkTarget && (o = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", o ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), qa.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
d(jg, "insertNode");
var mA = /* @__PURE__ */ d((e, t) => {
  qa.set(t.id, e);
}, "setNodeElem"), yA = /* @__PURE__ */ d(() => {
  qa.clear();
}, "clear"), xA = /* @__PURE__ */ d((e) => {
  const t = qa.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), aS = /* @__PURE__ */ d((e, t, r, i, n, a) => {
  t.arrowTypeStart && ah(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && ah(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), sS = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, ah = /* @__PURE__ */ d((e, t, r, i, n, a, o) => {
  var u;
  const s = sS[r];
  if (!s) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const c = s.type, h = `${n}_${a}-${c}${t === "start" ? "Start" : "End"}`;
  if (o && o.trim() !== "") {
    const f = o.replace(/[^\dA-Za-z]/g, "_"), p = `${h}_${f}`;
    if (!document.getElementById(p)) {
      const g = document.getElementById(h);
      if (g) {
        const m = g.cloneNode(!0);
        m.id = p, m.querySelectorAll("path, circle, line").forEach((x) => {
          x.setAttribute("stroke", o), s.fill && x.setAttribute("fill", o);
        }), (u = g.parentNode) == null || u.appendChild(m);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${p})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), ya = /* @__PURE__ */ new Map(), Ot = /* @__PURE__ */ new Map(), bA = /* @__PURE__ */ d(() => {
  ya.clear(), Ot.clear();
}, "clear"), Cn = /* @__PURE__ */ d((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), oS = /* @__PURE__ */ d(async (e, t) => {
  let r = At(ft().flowchart.htmlLabels);
  const { labelStyles: i } = G(t);
  t.labelStyle = i;
  const n = await Ze(e, t.label, {
    style: t.labelStyle,
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const a = e.insert("g").attr("class", "edgeLabel"), o = a.insert("g").attr("class", "label").attr("data-id", t.id);
  o.node().appendChild(n);
  let s = n.getBBox();
  if (r) {
    const l = n.children[0], h = ht(n);
    s = l.getBoundingClientRect(), h.attr("width", s.width), h.attr("height", s.height);
  }
  o.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")"), ya.set(t.id, a), t.width = s.width, t.height = s.height;
  let c;
  if (t.startLabelLeft) {
    const l = await lr(
      t.startLabelLeft,
      Cn(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    c = u.node().appendChild(l);
    const f = l.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Ot.get(t.id) || Ot.set(t.id, {}), Ot.get(t.id).startLeft = h, Bi(c, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const l = await lr(
      t.startLabelRight,
      Cn(t.labelStyle)
    ), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    c = h.node().appendChild(l), u.node().appendChild(l);
    const f = l.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), Ot.get(t.id) || Ot.set(t.id, {}), Ot.get(t.id).startRight = h, Bi(c, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const l = await lr(t.endLabelLeft, Cn(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    c = u.node().appendChild(l);
    const f = l.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(l), Ot.get(t.id) || Ot.set(t.id, {}), Ot.get(t.id).endLeft = h, Bi(c, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const l = await lr(t.endLabelRight, Cn(t.labelStyle)), h = e.insert("g").attr("class", "edgeTerminals"), u = h.insert("g").attr("class", "inner");
    c = u.node().appendChild(l);
    const f = l.getBBox();
    u.attr("transform", "translate(" + -f.width / 2 + ", " + -f.height / 2 + ")"), h.node().appendChild(l), Ot.get(t.id) || Ot.set(t.id, {}), Ot.get(t.id).endRight = h, Bi(c, t.endLabelRight);
  }
  return n;
}, "insertEdgeLabel");
function Bi(e, t) {
  ft().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
d(Bi, "setTerminalWidth");
var lS = /* @__PURE__ */ d((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, ya.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = ft(), { subGraphTitleTotalMargin: n } = Xo(i);
  if (e.label) {
    const a = ya.get(e.id);
    let o = e.x, s = e.y;
    if (r) {
      const c = ue.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        o,
        ",",
        s,
        ") to (",
        c.x,
        ",",
        c.y,
        ") abc88"
      ), t.updatedPath && (o = c.x, s = c.y);
    }
    a.attr("transform", `translate(${o}, ${s + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = Ot.get(e.id).startLeft;
    let o = e.x, s = e.y;
    if (r) {
      const c = ue.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      o = c.x, s = c.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.startLabelRight) {
    const a = Ot.get(e.id).startRight;
    let o = e.x, s = e.y;
    if (r) {
      const c = ue.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      o = c.x, s = c.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelLeft) {
    const a = Ot.get(e.id).endLeft;
    let o = e.x, s = e.y;
    if (r) {
      const c = ue.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      o = c.x, s = c.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelRight) {
    const a = Ot.get(e.id).endRight;
    let o = e.x, s = e.y;
    if (r) {
      const c = ue.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      o = c.x, s = c.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
}, "positionEdgeLabel"), cS = /* @__PURE__ */ d((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), o = e.width / 2, s = e.height / 2;
  return n >= o || a >= s;
}, "outsideNode"), hS = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), o = e.width / 2;
  let s = r.x < t.x ? o - a : o + a;
  const c = e.height / 2, l = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * o > Math.abs(i - t.x) * c) {
    let u = r.y < t.y ? t.y - c - n : n - c - t.y;
    s = h * u / l;
    const f = {
      x: r.x < t.x ? r.x + s : r.x - h + s,
      y: r.y < t.y ? r.y + l - u : r.y - l + u
    };
    return s === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), l === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${l}, q ${u}, R ${h}, r ${s}`, f), f;
  } else {
    r.x < t.x ? s = t.x - o - i : s = i - o - t.x;
    let u = l * s / h, f = r.x < t.x ? r.x + h - s : r.x - h + s, p = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${l}, q ${u}, R ${h}, r ${s}`, { _x: f, _y: p }), s === 0 && (f = t.x, p = t.y), h === 0 && (f = t.x), l === 0 && (p = t.y), { x: f, y: p };
  }
}, "intersection"), sh = /* @__PURE__ */ d((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !cS(t, a) && !n) {
      const o = hS(t, i, a);
      F.debug("abc88 inside", a, i, o), F.debug("abc88 intersection", o, t);
      let s = !1;
      r.forEach((c) => {
        s = s || c.x === o.x && c.y === o.y;
      }), r.some((c) => c.x === o.x && c.y === o.y) ? F.warn("abc88 no intersect", o, r) : r.push(o), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function Yg(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], o = e[i + 1];
    (n.x === a.x && a.y === o.y && Math.abs(a.x - o.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === o.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - o.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
d(Yg, "extractCornerPoints");
var oh = /* @__PURE__ */ d(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), o = r / a;
  return { x: t.x - o * i, y: t.y - o * n };
}, "findAdjacentPoint"), uS = /* @__PURE__ */ d(function(e) {
  const { cornerPointPositions: t } = Yg(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], o = e[i], s = oh(n, o, 5), c = oh(a, o, 5), l = c.x - s.x, h = c.y - s.y;
      r.push(s);
      const u = Math.sqrt(2) * 2;
      let f = { x: o.x, y: o.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const p = 5;
        o.x === s.x ? f = {
          x: l < 0 ? s.x - p + u : s.x + p - u,
          y: h < 0 ? s.y - u : s.y + u
        } : f = {
          x: l < 0 ? s.x - u : s.x + u,
          y: h < 0 ? s.y - p + u : s.y + p - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, c);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), fS = /* @__PURE__ */ d((e, t, r) => {
  const i = e - t - r, n = 2, a = 2, o = n + a, s = Math.floor(i / o), c = Array(s).fill(`${n} ${a}`).join(" ");
  return `0 ${t} ${c} ${r}`;
}, "generateDashArray"), pS = /* @__PURE__ */ d(function(e, t, r, i, n, a, o, s = !1) {
  var M;
  const { handDrawnSeed: c } = ft();
  let l = t.points, h = !1;
  const u = n;
  var f = a;
  const p = [];
  for (const L in t.cssCompiledStyles)
    _p(L) || p.push(t.cssCompiledStyles[L]);
  F.debug("UIO intersect check", t.points, f.x, u.x), f.intersect && u.intersect && !s && (l = l.slice(1, t.points.length - 1), l.unshift(u.intersect(l[0])), F.debug(
    "Last point UIO",
    t.start,
    "-->",
    t.end,
    l[l.length - 1],
    f,
    f.intersect(l[l.length - 1])
  ), l.push(f.intersect(l[l.length - 1])));
  const g = btoa(JSON.stringify(l));
  t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), l = sh(t.points, r.get(t.toCluster).node), h = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(l, null, 2)
  ), l = sh(l.reverse(), r.get(t.fromCluster).node).reverse(), h = !0);
  let m = l.filter((L) => !Number.isNaN(L.y));
  m = uS(m);
  let y = An;
  switch (y = Xn, t.curve) {
    case "linear":
      y = Xn;
      break;
    case "basis":
      y = An;
      break;
    case "cardinal":
      y = vu;
      break;
    case "bumpX":
      y = bu;
      break;
    case "bumpY":
      y = Cu;
      break;
    case "catmullRom":
      y = Tu;
      break;
    case "monotoneX":
      y = Eu;
      break;
    case "monotoneY":
      y = Fu;
      break;
    case "natural":
      y = Du;
      break;
    case "step":
      y = Ru;
      break;
    case "stepAfter":
      y = Pu;
      break;
    case "stepBefore":
      y = Iu;
      break;
    default:
      y = An;
  }
  const { x, y: b } = hC(t), _ = G1().x(x).y(b).curve(y);
  let k;
  switch (t.thickness) {
    case "normal":
      k = "edge-thickness-normal";
      break;
    case "thick":
      k = "edge-thickness-thick";
      break;
    case "invisible":
      k = "edge-thickness-invisible";
      break;
    default:
      k = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      k += " edge-pattern-solid";
      break;
    case "dotted":
      k += " edge-pattern-dotted";
      break;
    case "dashed":
      k += " edge-pattern-dashed";
      break;
    default:
      k += " edge-pattern-solid";
  }
  let w, C = t.curve === "rounded" ? Ug(Gg(m, t), 5) : _(m);
  const S = Array.isArray(t.style) ? t.style : [t.style];
  let O = S.find((L) => L == null ? void 0 : L.startsWith("stroke:")), P = !1;
  if (t.look === "handDrawn") {
    const L = Y.svg(e);
    Object.assign([], m);
    const B = L.path(C, {
      roughness: 0.3,
      seed: c
    });
    k += " transition", w = ht(B).select("path").attr("id", t.id).attr("class", " " + k + (t.classes ? " " + t.classes : "")).attr("style", S ? S.reduce((A, W) => A + ";" + W, "") : "");
    let E = w.attr("d");
    w.attr("d", E), e.node().appendChild(w.node());
  } else {
    const L = p.join(";"), B = S ? S.reduce((nt, gt) => nt + gt + ";", "") : "";
    let E = "";
    t.animate && (E = " edge-animation-fast"), t.animation && (E = " edge-animation-" + t.animation);
    const A = (L ? L + ";" + B + ";" : B) + ";" + (S ? S.reduce((nt, gt) => nt + ";" + gt, "") : "");
    w = e.append("path").attr("d", C).attr("id", t.id).attr(
      "class",
      " " + k + (t.classes ? " " + t.classes : "") + (E ?? "")
    ).attr("style", A), O = (M = A.match(/stroke:([^;]+)/)) == null ? void 0 : M[1], P = t.animate === !0 || !!t.animation || L.includes("animation");
    const W = w.node(), X = typeof W.getTotalLength == "function" ? W.getTotalLength() : 0, H = Tc[t.arrowTypeStart] || 0, ut = Tc[t.arrowTypeEnd] || 0;
    if (t.look === "neo" && !P) {
      const gt = `stroke-dasharray: ${t.pattern === "dotted" || t.pattern === "dashed" ? fS(X, H, ut) : `0 ${H} ${X - H - ut} ${ut}`}; stroke-dashoffset: 0;`;
      w.attr("style", gt + w.attr("style"));
    }
  }
  w.attr("data-edge", !0), w.attr("data-et", "edge"), w.attr("data-id", t.id), w.attr("data-points", g), t.showPoints && m.forEach((L) => {
    e.append("circle").style("stroke", "red").style("fill", "red").attr("r", 1).attr("cx", L.x).attr("cy", L.y);
  });
  let R = "";
  (ft().flowchart.arrowMarkerAbsolute || ft().state.arrowMarkerAbsolute) && (R = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, R = R.replace(/\(/g, "\\(").replace(/\)/g, "\\)")), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), aS(w, t, R, o, i, O);
  const $ = Math.floor(l.length / 2), z = l[$];
  ue.isLabelCoordinateInPath(z, w.attr("d")) || (h = !0);
  let D = {};
  return h && (D.updatedPath = l), D.originalPath = t.points, D;
}, "insertEdge");
function Ug(e, t) {
  if (e.length < 2)
    return "";
  let r = "";
  const i = e.length, n = 1e-5;
  for (let a = 0; a < i; a++) {
    const o = e[a], s = e[a - 1], c = e[a + 1];
    if (a === 0)
      r += `M${o.x},${o.y}`;
    else if (a === i - 1)
      r += `L${o.x},${o.y}`;
    else {
      const l = o.x - s.x, h = o.y - s.y, u = c.x - o.x, f = c.y - o.y, p = Math.hypot(l, h), g = Math.hypot(u, f);
      if (p < n || g < n) {
        r += `L${o.x},${o.y}`;
        continue;
      }
      const m = l / p, y = h / p, x = u / g, b = f / g, _ = m * x + y * b, k = Math.max(-1, Math.min(1, _)), w = Math.acos(k);
      if (w < n || Math.abs(Math.PI - w) < n) {
        r += `L${o.x},${o.y}`;
        continue;
      }
      const C = Math.min(t / Math.sin(w / 2), p / 2, g / 2), S = o.x - m * C, O = o.y - y * C, P = o.x + x * C, R = o.y + b * C;
      r += `L${S},${O}`, r += `Q${o.x},${o.y} ${P},${R}`;
    }
  }
  return r;
}
d(Ug, "generateRoundedPath");
function uo(e, t) {
  if (!e || !t)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  const r = t.x - e.x, i = t.y - e.y;
  return { angle: Math.atan2(i, r), deltaX: r, deltaY: i };
}
d(uo, "calculateDeltaAndAngle");
function Gg(e, t) {
  const r = e.map((n) => ({ ...n }));
  if (e.length >= 2 && Pt[t.arrowTypeStart]) {
    const n = Pt[t.arrowTypeStart], a = e[0], o = e[1], { angle: s } = uo(a, o), c = n * Math.cos(s), l = n * Math.sin(s);
    r[0].x = a.x + c, r[0].y = a.y + l;
  }
  const i = e.length;
  if (i >= 2 && Pt[t.arrowTypeEnd]) {
    const n = Pt[t.arrowTypeEnd], a = e[i - 1], o = e[i - 2], { angle: s } = uo(o, a), c = n * Math.cos(s), l = n * Math.sin(s);
    r[i - 1].x = a.x - c, r[i - 1].y = a.y - l;
  }
  return r;
}
d(Gg, "applyMarkerOffsetsToPoints");
var dS = /* @__PURE__ */ d((e, t, r, i) => {
  t.forEach((n) => {
    MS[n](e, r, i);
  });
}, "insertMarkers"), gS = /* @__PURE__ */ d((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), mS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), yS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), xS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), bS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), CS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), _S = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), wS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), kS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), vS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), SS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), TS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), BS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), LS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), AS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), MS = {
  extension: gS,
  composition: mS,
  aggregation: yS,
  dependency: xS,
  lollipop: bS,
  point: CS,
  circle: _S,
  cross: wS,
  barb: kS,
  only_one: vS,
  zero_or_one: SS,
  one_or_more: TS,
  zero_or_more: BS,
  requirement_arrow: LS,
  requirement_contains: AS
}, $S = dS, ES = {
  common: ti,
  getConfig: Nt,
  insertCluster: zv,
  insertEdge: pS,
  insertEdgeLabel: oS,
  insertMarkers: $S,
  insertNode: jg,
  interpolateToCurve: tl,
  labelHelper: et,
  log: F,
  positionEdgeLabel: lS
}, Yi = {}, Xg = /* @__PURE__ */ d((e) => {
  for (const t of e)
    Yi[t.name] = t;
}, "registerLayoutLoaders"), FS = /* @__PURE__ */ d(() => {
  Xg([
    {
      name: "dagre",
      loader: /* @__PURE__ */ d(async () => await import("./dagre-6UL2VRFP-hgO0W6ya.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ d(async () => await import("./cose-bilkent-S5V4N54A-e0U0YOJB.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
FS();
var CA = /* @__PURE__ */ d(async (e, t) => {
  if (!(e.layoutAlgorithm in Yi))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = Yi[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, ES, {
    algorithm: r.algorithm
  });
}, "render"), _A = /* @__PURE__ */ d((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in Yi)
    return e;
  if (t in Yi)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), Vg = "comm", Zg = "rule", Kg = "decl", OS = "@import", DS = "@namespace", RS = "@keyframes", IS = "@layer", Qg = Math.abs, Cl = String.fromCharCode;
function Jg(e) {
  return e.trim();
}
function On(e, t, r) {
  return e.replace(t, r);
}
function PS(e, t, r) {
  return e.indexOf(t, r);
}
function Rr(e, t) {
  return e.charCodeAt(t) | 0;
}
function Qr(e, t, r) {
  return e.slice(t, r);
}
function Ce(e) {
  return e.length;
}
function NS(e) {
  return e.length;
}
function _n(e, t) {
  return t.push(e), e;
}
var Ha = 1, Jr = 1, tm = 0, oe = 0, Tt = 0, ai = "";
function _l(e, t, r, i, n, a, o, s) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: Ha, column: Jr, length: o, return: "", siblings: s };
}
function zS() {
  return Tt;
}
function WS() {
  return Tt = oe > 0 ? Rr(ai, --oe) : 0, Jr--, Tt === 10 && (Jr = 1, Ha--), Tt;
}
function pe() {
  return Tt = oe < tm ? Rr(ai, oe++) : 0, Jr++, Tt === 10 && (Jr = 1, Ha++), Tt;
}
function He() {
  return Rr(ai, oe);
}
function Dn() {
  return oe;
}
function ja(e, t) {
  return Qr(ai, e, t);
}
function Ui(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function qS(e) {
  return Ha = Jr = 1, tm = Ce(ai = e), oe = 0, [];
}
function HS(e) {
  return ai = "", e;
}
function Cs(e) {
  return Jg(ja(oe - 1, fo(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function jS(e) {
  for (; (Tt = He()) && Tt < 33; )
    pe();
  return Ui(e) > 2 || Ui(Tt) > 3 ? "" : " ";
}
function YS(e, t) {
  for (; --t && pe() && !(Tt < 48 || Tt > 102 || Tt > 57 && Tt < 65 || Tt > 70 && Tt < 97); )
    ;
  return ja(e, Dn() + (t < 6 && He() == 32 && pe() == 32));
}
function fo(e) {
  for (; pe(); )
    switch (Tt) {
      case e:
        return oe;
      case 34:
      case 39:
        e !== 34 && e !== 39 && fo(Tt);
        break;
      case 40:
        e === 41 && fo(e);
        break;
      case 92:
        pe();
        break;
    }
  return oe;
}
function US(e, t) {
  for (; pe() && e + Tt !== 57; )
    if (e + Tt === 84 && He() === 47)
      break;
  return "/*" + ja(t, oe - 1) + "*" + Cl(e === 47 ? e : pe());
}
function GS(e) {
  for (; !Ui(He()); )
    pe();
  return ja(e, oe);
}
function XS(e) {
  return HS(Rn("", null, null, null, [""], e = qS(e), 0, [0], e));
}
function Rn(e, t, r, i, n, a, o, s, c) {
  for (var l = 0, h = 0, u = o, f = 0, p = 0, g = 0, m = 1, y = 1, x = 1, b = 0, _ = "", k = n, w = a, C = i, S = _; y; )
    switch (g = b, b = pe()) {
      case 40:
        if (g != 108 && Rr(S, u - 1) == 58) {
          PS(S += On(Cs(b), "&", "&\f"), "&\f", Qg(l ? s[l - 1] : 0)) != -1 && (x = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        S += Cs(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        S += jS(g);
        break;
      case 92:
        S += YS(Dn() - 1, 7);
        continue;
      case 47:
        switch (He()) {
          case 42:
          case 47:
            _n(VS(US(pe(), Dn()), t, r, c), c), (Ui(g || 1) == 5 || Ui(He() || 1) == 5) && Ce(S) && Qr(S, -1, void 0) !== " " && (S += " ");
            break;
          default:
            S += "/";
        }
        break;
      case 123 * m:
        s[l++] = Ce(S) * x;
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            y = 0;
          case 59 + h:
            x == -1 && (S = On(S, /\f/g, "")), p > 0 && (Ce(S) - u || m === 0 && g === 47) && _n(p > 32 ? ch(S + ";", i, r, u - 1, c) : ch(On(S, " ", "") + ";", i, r, u - 2, c), c);
            break;
          case 59:
            S += ";";
          default:
            if (_n(C = lh(S, t, r, l, h, n, s, _, k = [], w = [], u, a), a), b === 123)
              if (h === 0)
                Rn(S, t, C, C, k, a, u, s, w);
              else {
                switch (f) {
                  case 99:
                    if (Rr(S, 3) === 110) break;
                  case 108:
                    if (Rr(S, 2) === 97) break;
                  default:
                    h = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                h ? Rn(e, C, C, i && _n(lh(e, C, C, 0, 0, n, s, _, n, k = [], u, w), w), n, w, u, s, i ? k : w) : Rn(S, C, C, C, [""], w, 0, s, w);
              }
        }
        l = h = p = 0, m = x = 1, _ = S = "", u = o;
        break;
      case 58:
        u = 1 + Ce(S), p = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && WS() == 125)
            continue;
        }
        switch (S += Cl(b), b * m) {
          case 38:
            x = h > 0 ? 1 : (S += "\f", -1);
            break;
          case 44:
            s[l++] = (Ce(S) - 1) * x, x = 1;
            break;
          case 64:
            He() === 45 && (S += Cs(pe())), f = He(), h = u = Ce(_ = S += GS(Dn())), b++;
            break;
          case 45:
            g === 45 && Ce(S) == 2 && (m = 0);
        }
    }
  return a;
}
function lh(e, t, r, i, n, a, o, s, c, l, h, u) {
  for (var f = n - 1, p = n === 0 ? a : [""], g = NS(p), m = 0, y = 0, x = 0; m < i; ++m)
    for (var b = 0, _ = Qr(e, f + 1, f = Qg(y = o[m])), k = e; b < g; ++b)
      (k = Jg(y > 0 ? p[b] + " " + _ : On(_, /&\f/g, p[b]))) && (c[x++] = k);
  return _l(e, t, r, n === 0 ? Zg : s, c, l, h, u);
}
function VS(e, t, r, i) {
  return _l(e, t, r, Vg, Cl(zS()), Qr(e, 2, -2), 0, i);
}
function ch(e, t, r, i, n) {
  return _l(e, t, r, Kg, Qr(e, 0, i), Qr(e, i + 1, -1), i, n);
}
function po(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function ZS(e, t, r, i) {
  switch (e.type) {
    case IS:
      if (e.children.length) break;
    case OS:
    case DS:
    case Kg:
      return e.return = e.return || e.value;
    case Vg:
      return "";
    case RS:
      return e.return = e.value + "{" + po(e.children, i) + "}";
    case Zg:
      if (!Ce(e.value = e.props.join(","))) return "";
  }
  return Ce(r = po(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var KS = Tp(Object.keys, Object), QS = Object.prototype, JS = QS.hasOwnProperty;
function tT(e) {
  if (!Fa(e))
    return KS(e);
  var t = [];
  for (var r in Object(e))
    JS.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var go = Cr(Se, "DataView"), mo = Cr(Se, "Promise"), yo = Cr(Se, "Set"), xo = Cr(Se, "WeakMap"), hh = "[object Map]", eT = "[object Object]", uh = "[object Promise]", fh = "[object Set]", ph = "[object WeakMap]", dh = "[object DataView]", rT = br(go), iT = br(Hi), nT = br(mo), aT = br(yo), sT = br(xo), ir = ri;
(go && ir(new go(new ArrayBuffer(1))) != dh || Hi && ir(new Hi()) != hh || mo && ir(mo.resolve()) != uh || yo && ir(new yo()) != fh || xo && ir(new xo()) != ph) && (ir = function(e) {
  var t = ri(e), r = t == eT ? e.constructor : void 0, i = r ? br(r) : "";
  if (i)
    switch (i) {
      case rT:
        return dh;
      case iT:
        return hh;
      case nT:
        return uh;
      case aT:
        return fh;
      case sT:
        return ph;
    }
  return t;
});
var oT = "[object Map]", lT = "[object Set]", cT = Object.prototype, hT = cT.hasOwnProperty;
function gh(e) {
  if (e == null)
    return !0;
  if (Oa(e) && (oa(e) || typeof e == "string" || typeof e.splice == "function" || Qo(e) || Jo(e) || sa(e)))
    return !e.length;
  var t = ir(e);
  if (t == oT || t == lT)
    return !e.size;
  if (Fa(e))
    return !tT(e).length;
  for (var r in e)
    if (hT.call(e, r))
      return !1;
  return !0;
}
var em = "c4", uT = /* @__PURE__ */ d((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), fT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./c4Diagram-YG6GDRKO-CR2338gf.js");
  return { id: em, diagram: e };
}, "loader"), pT = {
  id: em,
  detector: uT,
  loader: fT
}, dT = pT, rm = "flowchart", gT = /* @__PURE__ */ d((e, t) => {
  var r, i;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" || ((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" ? !1 : /^\s*graph/.test(e);
}, "detector"), mT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-Bk0cE7T_.js");
  return { id: rm, diagram: e };
}, "loader"), yT = {
  id: rm,
  detector: gT,
  loader: mT
}, xT = yT, im = "flowchart-v2", bT = /* @__PURE__ */ d((e, t) => {
  var r, i, n;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-d3" ? !1 : (((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && ((n = t == null ? void 0 : t.flowchart) == null ? void 0 : n.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e));
}, "detector"), CT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-Bk0cE7T_.js");
  return { id: im, diagram: e };
}, "loader"), _T = {
  id: im,
  detector: bT,
  loader: CT
}, wT = _T, nm = "er", kT = /* @__PURE__ */ d((e) => /^\s*erDiagram/.test(e), "detector"), vT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./erDiagram-Q2GNP2WA-ssuy35YL.js");
  return { id: nm, diagram: e };
}, "loader"), ST = {
  id: nm,
  detector: kT,
  loader: vT
}, TT = ST, am = "gitGraph", BT = /* @__PURE__ */ d((e) => /^\s*gitGraph/.test(e), "detector"), LT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-NY62KEGX-BiwV2jlq.js");
  return { id: am, diagram: e };
}, "loader"), AT = {
  id: am,
  detector: BT,
  loader: LT
}, MT = AT, sm = "gantt", $T = /* @__PURE__ */ d((e) => /^\s*gantt/.test(e), "detector"), ET = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./ganttDiagram-LVOFAZNH-X2n6l3PA.js");
  return { id: sm, diagram: e };
}, "loader"), FT = {
  id: sm,
  detector: $T,
  loader: ET
}, OT = FT, om = "info", DT = /* @__PURE__ */ d((e) => /^\s*info/.test(e), "detector"), RT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./infoDiagram-F6ZHWCRC-BoBwoGcr.js");
  return { id: om, diagram: e };
}, "loader"), IT = {
  id: om,
  detector: DT,
  loader: RT
}, lm = "pie", PT = /* @__PURE__ */ d((e) => /^\s*pie/.test(e), "detector"), NT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./pieDiagram-ADFJNKIX-Dj4rg2WN.js");
  return { id: lm, diagram: e };
}, "loader"), zT = {
  id: lm,
  detector: PT,
  loader: NT
}, cm = "quadrantChart", WT = /* @__PURE__ */ d((e) => /^\s*quadrantChart/.test(e), "detector"), qT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./quadrantDiagram-AYHSOK5B-CTgcWfVP.js");
  return { id: cm, diagram: e };
}, "loader"), HT = {
  id: cm,
  detector: WT,
  loader: qT
}, jT = HT, hm = "xychart", YT = /* @__PURE__ */ d((e) => /^\s*xychart(-beta)?/.test(e), "detector"), UT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./xychartDiagram-PRI3JC2R-fRd9JWhF.js");
  return { id: hm, diagram: e };
}, "loader"), GT = {
  id: hm,
  detector: YT,
  loader: UT
}, XT = GT, um = "requirement", VT = /* @__PURE__ */ d((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), ZT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./requirementDiagram-UZGBJVZJ-DAHQzO5i.js");
  return { id: um, diagram: e };
}, "loader"), KT = {
  id: um,
  detector: VT,
  loader: ZT
}, QT = KT, fm = "sequence", JT = /* @__PURE__ */ d((e) => /^\s*sequenceDiagram/.test(e), "detector"), tB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sequenceDiagram-WL72ISMW-D5ziail2.js");
  return { id: fm, diagram: e };
}, "loader"), eB = {
  id: fm,
  detector: JT,
  loader: tB
}, rB = eB, pm = "class", iB = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e);
}, "detector"), nB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-2ON5EDUG-D839WiJy.js");
  return { id: pm, diagram: e };
}, "loader"), aB = {
  id: pm,
  detector: iB,
  loader: nB
}, sB = aB, dm = "classDiagram", oB = /* @__PURE__ */ d((e, t) => {
  var r;
  return /^\s*classDiagram/.test(e) && ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e);
}, "detector"), lB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-v2-WZHVMYZB-D839WiJy.js");
  return { id: dm, diagram: e };
}, "loader"), cB = {
  id: dm,
  detector: oB,
  loader: lB
}, hB = cB, gm = "state", uB = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e);
}, "detector"), fB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-FKZM4ZOC-6SauMkY3.js");
  return { id: gm, diagram: e };
}, "loader"), pB = {
  id: gm,
  detector: uB,
  loader: fB
}, dB = pB, mm = "stateDiagram", gB = /* @__PURE__ */ d((e, t) => {
  var r;
  return !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper");
}, "detector"), mB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-4FDKWEC3-Dvp3jkod.js");
  return { id: mm, diagram: e };
}, "loader"), yB = {
  id: mm,
  detector: gB,
  loader: mB
}, xB = yB, ym = "journey", bB = /* @__PURE__ */ d((e) => /^\s*journey/.test(e), "detector"), CB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./journeyDiagram-XKPGCS4Q-DZywbVHW.js");
  return { id: ym, diagram: e };
}, "loader"), _B = {
  id: ym,
  detector: bB,
  loader: CB
}, wB = _B, kB = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = r2(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), qh(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), xm = { draw: kB }, vB = xm, SB = {
  db: {},
  renderer: xm,
  parser: {
    parse: /* @__PURE__ */ d(() => {
    }, "parse")
  }
}, TB = SB, bm = "flowchart-elk", BB = /* @__PURE__ */ d((e, t = {}) => {
  var r;
  return (
    // If diagram explicitly states flowchart-elk
    /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
    /^\s*(flowchart|graph)/.test(e) && ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "elk" ? (t.layout = "elk", !0) : !1
  );
}, "detector"), LB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-NV44I4VS-Bk0cE7T_.js");
  return { id: bm, diagram: e };
}, "loader"), AB = {
  id: bm,
  detector: BB,
  loader: LB
}, MB = AB, Cm = "timeline", $B = /* @__PURE__ */ d((e) => /^\s*timeline/.test(e), "detector"), EB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./timeline-definition-IT6M3QCI-B89OOMDU.js");
  return { id: Cm, diagram: e };
}, "loader"), FB = {
  id: Cm,
  detector: $B,
  loader: EB
}, OB = FB, _m = "mindmap", DB = /* @__PURE__ */ d((e) => /^\s*mindmap/.test(e), "detector"), RB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./mindmap-definition-VGOIOE7T-B-vKXGj2.js");
  return { id: _m, diagram: e };
}, "loader"), IB = {
  id: _m,
  detector: DB,
  loader: RB
}, PB = IB, wm = "kanban", NB = /* @__PURE__ */ d((e) => /^\s*kanban/.test(e), "detector"), zB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./kanban-definition-3W4ZIXB7-CSIi2vki.js");
  return { id: wm, diagram: e };
}, "loader"), WB = {
  id: wm,
  detector: NB,
  loader: zB
}, qB = WB, km = "sankey", HB = /* @__PURE__ */ d((e) => /^\s*sankey(-beta)?/.test(e), "detector"), jB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sankeyDiagram-TZEHDZUN-BHezr8DR.js");
  return { id: km, diagram: e };
}, "loader"), YB = {
  id: km,
  detector: HB,
  loader: jB
}, UB = YB, vm = "packet", GB = /* @__PURE__ */ d((e) => /^\s*packet(-beta)?/.test(e), "detector"), XB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-S2PKOQOG-D27t29xZ.js");
  return { id: vm, diagram: e };
}, "loader"), VB = {
  id: vm,
  detector: GB,
  loader: XB
}, Sm = "radar", ZB = /* @__PURE__ */ d((e) => /^\s*radar-beta/.test(e), "detector"), KB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-QEK2KX5R-CxESEy3J.js");
  return { id: Sm, diagram: e };
}, "loader"), QB = {
  id: Sm,
  detector: ZB,
  loader: KB
}, Tm = "block", JB = /* @__PURE__ */ d((e) => /^\s*block(-beta)?/.test(e), "detector"), tL = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./blockDiagram-VD42YOAC-CD3bvFgH.js");
  return { id: Tm, diagram: e };
}, "loader"), eL = {
  id: Tm,
  detector: JB,
  loader: tL
}, rL = eL, Bm = "architecture", iL = /* @__PURE__ */ d((e) => /^\s*architecture/.test(e), "detector"), nL = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./architectureDiagram-VXUJARFQ-2GNQaRbI.js");
  return { id: Bm, diagram: e };
}, "loader"), aL = {
  id: Bm,
  detector: iL,
  loader: nL
}, sL = aL, Lm = "treemap", oL = /* @__PURE__ */ d((e) => /^\s*treemap/.test(e), "detector"), lL = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-PSM6KHXK-DFICoa_8.js");
  return { id: Lm, diagram: e };
}, "loader"), cL = {
  id: Lm,
  detector: oL,
  loader: lL
}, mh = !1, Ya = /* @__PURE__ */ d(() => {
  mh || (mh = !0, Wn("error", TB, (e) => e.toLowerCase().trim() === "error"), Wn(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ d(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ d(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ d(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ d(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), vs(MB, PB, sL), vs(
    dT,
    qB,
    hB,
    sB,
    TT,
    OT,
    IT,
    zT,
    QT,
    rB,
    wT,
    xT,
    OB,
    MT,
    xB,
    dB,
    wB,
    jT,
    UB,
    VB,
    XT,
    rL,
    QB,
    cL
  ));
}, "addDiagrams"), hL = /* @__PURE__ */ d(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(ur).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          Ls(r);
        } catch {
          try {
            const { diagram: a, id: o } = await n();
            Wn(o, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete ur[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), uL = "graphics-document document";
function Am(e, t) {
  e.attr("role", uL), t !== "" && e.attr("aria-roledescription", t);
}
d(Am, "setA11yDiagramInfo");
function Mm(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
d(Mm, "addSVGa11yTitleDescription");
var hr, bo = (hr = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    var l, h;
    const i = Nt(), n = wo(t, i);
    t = ck(t) + `
`;
    try {
      Ls(n);
    } catch {
      const u = E0(n);
      if (!u)
        throw new Mh(`Diagram ${n} not found.`);
      const { id: f, diagram: p } = await u();
      Wn(f, p);
    }
    const { db: a, parser: o, renderer: s, init: c } = Ls(n);
    return o.parser && (o.parser.yy = a), (l = a.clear) == null || l.call(a), c == null || c(i), r.title && ((h = a.setDiagramTitle) == null || h.call(a, r.title)), await o.parse(t), new hr(n, t, a, o, s);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, d(hr, "Diagram"), hr), yh = [], fL = /* @__PURE__ */ d(() => {
  yh.forEach((e) => {
    e();
  }), yh = [];
}, "attachFunctions"), pL = /* @__PURE__ */ d((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function $m(e) {
  const t = e.match(Ah);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = cC(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: lC
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
d($m, "extractFrontMatter");
var dL = /* @__PURE__ */ d((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), gL = /* @__PURE__ */ d((e) => {
  const { text: t, metadata: r } = $m(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), mL = /* @__PURE__ */ d((e) => {
  const t = ue.detectInit(e) ?? {}, r = ue.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : (r == null ? void 0 : r.type) === "wrap" && (t.wrap = !0), {
    text: Zw(e),
    directive: t
  };
}, "processDirectives");
function wl(e) {
  const t = dL(e), r = gL(t), i = mL(r.text), n = al(r.config, i.directive);
  return e = pL(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
d(wl, "preprocessDiagram");
function Em(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
d(Em, "toBase64");
var yL = 5e4, xL = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", bL = "sandbox", CL = "loose", _L = "http://www.w3.org/2000/svg", wL = "http://www.w3.org/1999/xlink", kL = "http://www.w3.org/1999/xhtml", vL = "100%", SL = "100%", TL = "border:0;margin:0;", BL = "margin:0", LL = "allow-top-navigation-by-user-activation allow-popups", AL = 'The "iframe" tag is not supported by your browser.', ML = ["foreignobject"], $L = ["dominant-baseline"];
function kl(e) {
  const t = wl(e);
  return Nn(), X0(t.config ?? {}), t;
}
d(kl, "processAndSetConfigs");
async function Fm(e, t) {
  Ya();
  try {
    const { code: r, config: i } = kl(e);
    return { diagramType: (await Dm(r)).type, config: i };
  } catch (r) {
    if (t != null && t.suppressErrors)
      return !1;
    throw r;
  }
}
d(Fm, "parse");
var xh = /* @__PURE__ */ d((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), EL = /* @__PURE__ */ d((e, t = /* @__PURE__ */ new Map()) => {
  var i;
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? ((i = e.flowchart) == null ? void 0 : i.htmlLabels) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((c) => {
      gh(c.styles) || s.forEach((l) => {
        r += xh(c.id, l, c.styles);
      }), gh(c.textStyles) || (r += xh(
        c.id,
        "tspan",
        ((c == null ? void 0 : c.textStyles) || []).map((l) => l.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), FL = /* @__PURE__ */ d((e, t, r, i) => {
  const n = EL(e, r), a = dy(t, n, e.themeVariables);
  return po(XS(`${i}{${a}}`), ZS);
}, "createUserStyles"), OL = /* @__PURE__ */ d((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = _r(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), DL = /* @__PURE__ */ d((e = "", t) => {
  var n, a;
  const r = (a = (n = t == null ? void 0 : t.viewBox) == null ? void 0 : n.baseVal) != null && a.height ? t.viewBox.baseVal.height + "px" : SL, i = Em(`<body style="${BL}">${e}</body>`);
  return `<iframe style="width:${vL};height:${r};${TL}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${LL}">
  ${AL}
</iframe>`;
}, "putIntoIFrame"), bh = /* @__PURE__ */ d((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const o = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", _L);
  return n && o.attr("xmlns:xlink", n), o.append("g"), e;
}, "appendDivSvgG");
function Co(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
d(Co, "sandboxedIframe");
var RL = /* @__PURE__ */ d((e, t, r, i) => {
  var n, a, o;
  (n = e.getElementById(t)) == null || n.remove(), (a = e.getElementById(r)) == null || a.remove(), (o = e.getElementById(i)) == null || o.remove();
}, "removeExistingElements"), IL = /* @__PURE__ */ d(async function(e, t, r) {
  var z, D, M, L, B, E;
  Ya();
  const i = kl(t);
  t = i.code;
  const n = Nt();
  F.debug(n), t.length > ((n == null ? void 0 : n.maxTextSize) ?? yL) && (t = xL);
  const a = "#" + e, o = "i" + e, s = "#" + o, c = "d" + e, l = "#" + c, h = /* @__PURE__ */ d(() => {
    const W = ht(f ? s : l).node();
    W && "remove" in W && W.remove();
  }, "removeTempElements");
  let u = ht("body");
  const f = n.securityLevel === bL, p = n.securityLevel === CL, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const A = Co(ht(r), o);
      u = ht(A.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht(r);
    bh(u, e, c, `font-family: ${g}`, wL);
  } else {
    if (RL(document, e, c, o), f) {
      const A = Co(ht("body"), o);
      u = ht(A.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht("body");
    bh(u, e, c);
  }
  let m, y;
  try {
    m = await bo.fromText(t, { title: i.title });
  } catch (A) {
    if (n.suppressErrorRendering)
      throw h(), A;
    m = await bo.fromText("error"), y = A;
  }
  const x = u.select(l).node(), b = m.type, _ = x.firstChild, k = _.firstChild, w = (D = (z = m.renderer).getClasses) == null ? void 0 : D.call(z, t, m), C = FL(n, b, w, a), S = document.createElement("style");
  S.innerHTML = C, _.insertBefore(S, k);
  try {
    await m.renderer.draw(t, e, ql.version, m);
  } catch (A) {
    throw n.suppressErrorRendering ? h() : vB.draw(t, e, ql.version), A;
  }
  const O = u.select(`${l} svg`), P = (L = (M = m.db).getAccTitle) == null ? void 0 : L.call(M), R = (E = (B = m.db).getAccDescription) == null ? void 0 : E.call(B);
  Rm(b, O, P, R), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", kL);
  let $ = u.select(l).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), $ = OL($, f, At(n.arrowMarkerAbsolute)), f) {
    const A = u.select(l + " svg").node();
    $ = DL($, A);
  } else p || ($ = Yr.sanitize($, {
    ADD_TAGS: ML,
    ADD_ATTR: $L,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (fL(), y)
    throw y;
  return h(), {
    diagramType: b,
    svg: $,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Om(e = {}) {
  var i;
  const t = Bt({}, e);
  t != null && t.fontFamily && !((i = t.themeVariables) != null && i.fontFamily) && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), U0(t), t != null && t.theme && t.theme in Re ? t.themeVariables = Re[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = Re.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? Y0(t) : Dh();
  _o(r.logLevel), Ya();
}
d(Om, "initialize");
var Dm = /* @__PURE__ */ d((e, t = {}) => {
  const { code: r } = wl(e);
  return bo.fromText(r, t);
}, "getDiagramFromText");
function Rm(e, t, r, i) {
  Am(t, e), Mm(t, r, i, t.attr("id"));
}
d(Rm, "addA11yInfo");
var yr = Object.freeze({
  render: IL,
  parse: Fm,
  getDiagramFromText: Dm,
  initialize: Om,
  getConfig: Nt,
  setConfig: Rh,
  getSiteConfig: Dh,
  updateSiteConfig: G0,
  reset: /* @__PURE__ */ d(() => {
    Nn();
  }, "reset"),
  globalReset: /* @__PURE__ */ d(() => {
    Nn(Ur);
  }, "globalReset"),
  defaultConfig: Ur
});
_o(Nt().logLevel);
Nn(Nt());
var PL = /* @__PURE__ */ d((e, t, r) => {
  F.warn(e), nl(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Im = /* @__PURE__ */ d(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await NL(e);
  } catch (t) {
    if (nl(t) && F.error(t.str), re.parseError && re.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), NL = /* @__PURE__ */ d(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = yr.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), (i == null ? void 0 : i.startOnLoad) !== void 0 && (F.debug("Start On Load: " + (i == null ? void 0 : i.startOnLoad)), yr.updateSiteConfig({ startOnLoad: i == null ? void 0 : i.startOnLoad }));
  const a = new ue.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let o;
  const s = [];
  for (const c of Array.from(n)) {
    if (F.info("Rendering diagram: " + c.id), c.getAttribute("data-processed"))
      continue;
    c.setAttribute("data-processed", "true");
    const l = `mermaid-${a.next()}`;
    o = c.innerHTML, o = nd(ue.entityDecode(o)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = ue.detectInit(o);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await Wm(l, o, c);
      c.innerHTML = u, e && await e(l), f && f(c);
    } catch (u) {
      PL(u, s, re.parseError);
    }
  }
  if (s.length > 0)
    throw s[0];
}, "runThrowsErrors"), Pm = /* @__PURE__ */ d(function(e) {
  yr.initialize(e);
}, "initialize"), zL = /* @__PURE__ */ d(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && Pm(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Im(i);
}, "init"), WL = /* @__PURE__ */ d(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Ya(), vs(...e), t === !1 && await hL();
}, "registerExternalDiagrams"), Nm = /* @__PURE__ */ d(function() {
  if (re.startOnLoad) {
    const { startOnLoad: e } = yr.getConfig();
    e && re.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Nm, !1);
var qL = /* @__PURE__ */ d(function(e) {
  re.parseError = e;
}, "setParseErrorHandler"), xa = [], _s = !1, zm = /* @__PURE__ */ d(async () => {
  if (!_s) {
    for (_s = !0; xa.length > 0; ) {
      const e = xa.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    _s = !1;
  }
}, "executeQueue"), HL = /* @__PURE__ */ d(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ d(() => new Promise((a, o) => {
    yr.parse(e, t).then(
      (s) => {
        a(s), r(s);
      },
      (s) => {
        var c;
        F.error("Error parsing", s), (c = re.parseError) == null || c.call(re, s), o(s), i(s);
      }
    );
  }), "performCall");
  xa.push(n), zm().catch(i);
}), "parse"), Wm = /* @__PURE__ */ d((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ d(() => new Promise((o, s) => {
    yr.render(e, t, r).then(
      (c) => {
        o(c), i(c);
      },
      (c) => {
        var l;
        F.error("Error parsing", c), (l = re.parseError) == null || l.call(re, c), s(c), n(c);
      }
    );
  }), "performCall");
  xa.push(a), zm().catch(n);
}), "render"), jL = /* @__PURE__ */ d(() => Object.keys(ur).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), re = {
  startOnLoad: !0,
  mermaidAPI: yr,
  parse: HL,
  render: Wm,
  init: zL,
  run: Im,
  registerExternalDiagrams: WL,
  registerLayoutLoaders: Xg,
  initialize: Pm,
  parseError: void 0,
  contentLoaded: Nm,
  setParseErrorHandler: qL,
  detectType: wo,
  registerIconPacks: pv,
  getRegisteredDiagramsMetadata: jL
}, YL = re;
/*! Check if previously processed */
/*!
 * Wait for document loaded before starting the execution
 */
const wA = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: YL
}, Symbol.toStringTag, { value: "Module" }));
export {
  Hh as $,
  Ai as A,
  r0 as B,
  ky as C,
  al as D,
  Nt as E,
  Oh as F,
  ek as G,
  r2 as H,
  ql as I,
  lC as J,
  P0 as K,
  Gr as L,
  VL as M,
  Da as N,
  iy as O,
  ko as P,
  Jl as Q,
  G1 as R,
  An as S,
  tk as T,
  Xi as U,
  uy as V,
  Gi as W,
  j as X,
  J as Y,
  Uw as Z,
  d as _,
  yy as a,
  te as a$,
  H1 as a0,
  Ro as a1,
  eA as a2,
  nA as a3,
  Ar as a4,
  bc as a5,
  xc as a6,
  sA as a7,
  aA as a8,
  iA as a9,
  qw as aA,
  O_ as aB,
  Dw as aC,
  Zo as aD,
  gh as aE,
  gv as aF,
  j1 as aG,
  XL as aH,
  en as aI,
  pv as aJ,
  fv as aK,
  Eo as aL,
  qe as aM,
  fc as aN,
  kb as aO,
  Ri as aP,
  xr as aQ,
  Hw as aR,
  Op as aS,
  Ma as aT,
  Oa as aU,
  oa as aV,
  Rp as aW,
  Fp as aX,
  bw as aY,
  G as aZ,
  _p as a_,
  JL as aa,
  tA as ab,
  lA as ac,
  rA as ad,
  oA as ae,
  zv as af,
  jg as ag,
  xA as ah,
  hC as ai,
  At as aj,
  Ze as ak,
  Xo as al,
  md as am,
  _r as an,
  qp as ao,
  it as ap,
  we as aq,
  $S as ar,
  yA as as,
  bA as at,
  gA as au,
  V as av,
  mA as aw,
  pS as ax,
  lS as ay,
  oS as az,
  my as b,
  mb as b0,
  $o as b1,
  iu as b2,
  Zi as b3,
  su as b4,
  QL as b5,
  e0 as b6,
  Ww as b7,
  Ow as b8,
  __ as b9,
  jw as bA,
  Fa as bB,
  wA as bC,
  Ko as ba,
  gw as bb,
  Yw as bc,
  Ji as bd,
  ri as be,
  na as bf,
  Tw as bg,
  tT as bh,
  Qi as bi,
  sa as bj,
  Cw as bk,
  Bp as bl,
  v_ as bm,
  S_ as bn,
  ir as bo,
  Pc as bp,
  T_ as bq,
  Qo as br,
  k_ as bs,
  A_ as bt,
  ii as bu,
  Ve as bv,
  Fc as bw,
  Jo as bx,
  Ap as by,
  yo as bz,
  ft as c,
  ht as d,
  qh as e,
  Bt as f,
  by as g,
  Ne as h,
  se as i,
  wp as j,
  ti as k,
  F as l,
  jp as m,
  ZL as n,
  _A as o,
  Cy as p,
  _y as q,
  CA as r,
  xy as s,
  cC as t,
  ue as u,
  nS as v,
  nk as w,
  cA as x,
  gy as y,
  KL as z
};
