# -*- coding: utf-8 -*-

"""Top-level package for InOrbit Python Edge SDK."""

__author__ = "InOrbit"
__email__ = "support@inorbit.ai"
# Do not edit this string manually, always use bumpversion
# Details in CONTRIBUTING.md
__version__ = "2.0.1"


def get_module_version():
    return __version__
