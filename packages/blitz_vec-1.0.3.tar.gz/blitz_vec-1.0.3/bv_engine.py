import numpy as np, os
import datetime
import decimal
import time
import threading

from blitz_vec import BlitzVec

class VectorExp:
    SEP = "|"
    MAX_CHAR = "\xff"

    def __init__(
        self,
        storage_base_path="vectordb_data",
        shards=4,
        max_size_gb=50
    ):
        GB = 1024 * 1024 * 1024
        os.makedirs(storage_base_path, exist_ok=True)

        # Unified storage for Vectors (ID -> Vec) and Inverted Indices (Prefix|ID -> Empty)
        self.storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "index_data"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.8) // shards
        )

        # Separate storage for Metadata Blobs (ID -> Pickle)
        self.meta_storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "meta_blobs"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.2) // shards
        )
        
        self._id_lock = threading.Lock()
        self._last_timestamp = 0
        self._counter = 0

    def _format_for_indexing(self, value):
        if isinstance(value, (datetime.date, datetime.datetime)):
            return value.isoformat()
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            offset = decimal.Decimal(2**63)
            return f"{decimal.Decimal(value) + offset:064.8f}"
        return str(value)

    def _generate_ids(self, count):
        # Sequential IDs
        # Generates IDs that are strictly increasing (Time-Ordered).
        # This turns Random Write I/O -> Sequential Write I/O
        ids = []
        with self._id_lock:
            now = int(time.time() * 1000)
            if now <= self._last_timestamp:
                now = self._last_timestamp
            
            start_idx = self._counter
            self._counter += count
            self._last_timestamp = now
            
            # ID Format: <Timestamp (48 bits)><Counter (16 bits)>
            # This ensures rough time ordering while allowing batch bursts
            base_id = (now << 16)
            for i in range(count):
                ids.append(base_id | ((start_idx + i) & 0xFFFF))
                
        return ids

    def _compile_filter(self, query):
        if not query:
            return None
        
        nodes = []
        for key, value in query.items():
            if key == "$and":
                sub_nodes = [self._compile_filter(q) for q in value]
                nodes.extend([n for n in sub_nodes if n])
                continue
            if key == "$or":
                sub_nodes = [self._compile_filter(q) for q in value]
                valid_subs = [n for n in sub_nodes if n]
                if valid_subs:
                    nodes.append((3, valid_subs))
                continue
            if key == "$not":
                sub = self._compile_filter(value)
                if sub:
                    nodes.append((4, sub))
                continue

            prefix_base = f"idx_{key}:"
            
            if isinstance(value, dict):
                field_nodes = []
                if "$in" in value:
                    or_nodes = []
                    for v in value["$in"]:
                        val_str = self._format_for_indexing(v)
                        or_nodes.append((0, f"{prefix_base}{val_str}"))
                    if or_nodes:
                        field_nodes.append((3, or_nodes))
                        
                if "$ne" in value:
                    val_str = self._format_for_indexing(value["$ne"])
                    field_nodes.append((4, (0, f"{prefix_base}{val_str}")))

                gt = value.get("$gt")
                gte = value.get("$gte")
                lt = value.get("$lt")
                lte = value.get("$lte")
                
                if any(x is not None for x in [gt, gte, lt, lte]):
                    if gte is not None:
                        s = f"{prefix_base}{self._format_for_indexing(gte)}"
                    elif gt is not None:
                        s = f"{prefix_base}{self._format_for_indexing(gt)}{self.MAX_CHAR}"
                    else:
                        s = f"{prefix_base}"
                    
                    if lte is not None:
                        e = f"{prefix_base}{self._format_for_indexing(lte)}{self.MAX_CHAR}"
                    elif lt is not None:
                        e = f"{prefix_base}{self._format_for_indexing(lt)}"
                    else:
                        e = f"{prefix_base}{self.MAX_CHAR}"
                    
                    field_nodes.append((1, s, e))
                
                if field_nodes:
                    if len(field_nodes) == 1:
                        nodes.append(field_nodes[0])
                    else:
                        nodes.append((2, field_nodes))
            else:
                val_str = self._format_for_indexing(value)
                nodes.append((0, f"{prefix_base}{val_str}"))

        if not nodes:
            return None
        if len(nodes) == 1:
            return nodes[0]
        return (2, nodes)

    def store_embeddings_batch(self, vectors, metadata_dicts=None, text_field=None):
        count = len(vectors)
        ids = self._generate_ids(count)
        if metadata_dicts is None:
            metadata_dicts = [{} for _ in range(count)]

        vec_np = np.array(vectors, dtype=np.float32)
        norms = np.linalg.norm(vec_np, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vec_np /= norms
        
        self.storage.store_vectors(vec_np, ids)
        self.meta_storage.store_data(metadata_dicts, ids)

        index_entries = []
        for uid, meta in zip(ids, metadata_dicts):
            for key, value in meta.items():
                if text_field and key == text_field:
                    continue
                val_str = self._format_for_indexing(value)
                prefix = f"idx_{key}:{val_str}"
                index_entries.append((prefix, uid))

        if index_entries:
            self.storage.batch_index_insert(index_entries)
            
        return ids

    def search(self, query_embedding, metadata_filter=None, k=5):
        filter_tree = self._compile_filter(metadata_filter)
        query_np = np.array(query_embedding, dtype=np.float32)
        top_results = self.storage.search_optimized(query_np, filter_tree, k)
        
        if not top_results:
            return []
            
        final_ids = [res[1] for res in top_results]
        scores = [res[0] for res in top_results]
        final_metas = self.meta_storage.get_data(final_ids)
        
        return list(zip(final_ids, scores, final_metas))

    def delete(self, metadata_query):
        filter_tree = self._compile_filter(metadata_query)
        if filter_tree is None:
            return 0
        ids = self.storage.get_ids_from_filter(filter_tree)
        if not ids:
            return 0
        self.delete_by_ids(ids)
        return len(ids)

    def delete_by_ids(self, ids):
        metadatas = self.meta_storage.get_data(ids)
        indices_to_delete = []
        valid_ids = []
        
        for uid, meta in zip(ids, metadatas):
            if meta is None: continue
            valid_ids.append(uid)
            for key, value in meta.items():
                val_str = self._format_for_indexing(value)
                indices_to_delete.append((f"idx_{key}:{val_str}", uid))
                
        if indices_to_delete:
            self.storage.batch_index_delete(indices_to_delete)
            
        self.storage.delete_data(valid_ids)
        self.meta_storage.delete_data(valid_ids)

    def count(self):
        return self.meta_storage.get_data_count()
