#![allow(non_local_definitions)]

use pyo3::prelude::*;
use pyo3::types::{PyList, PyBytes, PyNone, PyTuple, PyAny};
use numpy::{PyReadonlyArray1, PyReadonlyArray2};
use lmdb::{Environment, Transaction, WriteFlags, Database, Cursor, EnvironmentFlags, Error as LmdbError};
use rayon::prelude::*;
use std::sync::{Arc};
use std::path::Path;
use std::fs;
use std::collections::HashSet;
use byteorder::{ByteOrder, LittleEndian};

// OPTIMIZATION 1: Remove MDB_WRITEMAP. 
// On low-RAM systems, WRITEMAP causes aggressive swapping. 
// Standard file I/O allows the OS to buffer writes better when memory is tight.
const MDB_NOTLS: EnvironmentFlags = EnvironmentFlags::NO_TLS;
const MDB_MAPASYNC: EnvironmentFlags = EnvironmentFlags::MAP_ASYNC;
const MDB_SET_RANGE: u32 = 17;
const MDB_NEXT: u32 = 8;

#[inline(always)]
fn fast_dot_product(a: &[f32], b: &[f32]) -> f32 {
    a.iter().zip(b.iter()).map(|(x, y)| x * y).sum()
}

#[derive(Debug)]
enum StorageError { Lmdb(LmdbError), Io(std::io::Error), Py(PyErr) }
impl From<LmdbError> for StorageError { fn from(err: LmdbError) -> Self { StorageError::Lmdb(err) } }
impl From<std::io::Error> for StorageError { fn from(err: std::io::Error) -> Self { StorageError::Io(err) } }
impl From<PyErr> for StorageError { fn from(err: PyErr) -> Self { StorageError::Py(err) } }
impl From<StorageError> for PyErr {
    fn from(err: StorageError) -> PyErr {
        match err {
            StorageError::Lmdb(e) => pyo3::exceptions::PyIOError::new_err(format!("LMDB Error: {}", e)),
            StorageError::Io(e) => pyo3::exceptions::PyIOError::new_err(format!("IO Error: {}", e)),
            StorageError::Py(e) => e,
        }
    }
}

#[derive(Clone)]
struct PreparedKey { shard_idx: usize, key_bytes: [u8; 8] }

#[derive(Debug)]
enum FilterNode { Exact(String), Range(String, String), And(Vec<FilterNode>), Or(Vec<FilterNode>), Not(Box<FilterNode>) }

impl FilterNode {
    fn from_py(obj: &PyAny) -> PyResult<Self> {
        let tuple = obj.downcast::<PyTuple>()?;
        let op_code: u8 = tuple.get_item(0)?.extract()?;
        match op_code {
            0 => Ok(FilterNode::Exact(tuple.get_item(1)?.extract()?)),
            1 => Ok(FilterNode::Range(tuple.get_item(1)?.extract()?, tuple.get_item(2)?.extract()?)),
            2 | 3 => {
                let list: &PyList = tuple.get_item(1)?.downcast()?;
                let nodes = list.iter().map(FilterNode::from_py).collect::<PyResult<Vec<_>>>()?;
                if op_code == 2 { Ok(FilterNode::And(nodes)) } else { Ok(FilterNode::Or(nodes)) }
            },
            4 => Ok(FilterNode::Not(Box::new(FilterNode::from_py(tuple.get_item(1)?)?))),
            _ => Err(pyo3::exceptions::PyValueError::new_err("Invalid OpCode")),
        }
    }
}

#[pyclass(module = "blitz_vec")]
struct BlitzVec {
    shards: Vec<Arc<Environment>>,
    dbs: Vec<Database>,
    num_shards: usize,
    _base_path: String,
    _map_size: usize,
}

impl BlitzVec {
    #[inline]
    fn process_id(id: i64, num_shards: usize) -> PreparedKey {
        let shard_idx = (id.unsigned_abs() as usize) % num_shards;
        let mut key_bytes = [0u8; 8];
        LittleEndian::write_i64(&mut key_bytes, id);
        PreparedKey { shard_idx, key_bytes }
    }

    fn init(base_path: &str, num_shards: usize, map_size: usize) -> Result<(Vec<Arc<Environment>>, Vec<Database>), StorageError> {
        let mut shards = Vec::with_capacity(num_shards);
        let mut dbs = Vec::with_capacity(num_shards);
        for i in 0..num_shards {
            let path_str = format!("{}/shard_{}", base_path, i);
            fs::create_dir_all(&path_str)?;
            let env = Environment::new()
                .set_map_size(map_size).set_max_dbs(1).set_max_readers(2048)
                // Removed MDB_WRITEMAP
                .set_flags(MDB_MAPASYNC | MDB_NOTLS)
                .open(Path::new(&path_str))?;
            let db = env.open_db(None)?;
            shards.push(Arc::new(env));
            dbs.push(db);
        }
        Ok((shards, dbs))
    }

    fn eval_node(&self, node: &FilterNode) -> (HashSet<i64>, bool) {
        match node {
            FilterNode::Exact(key) => {
                let digest = md5::compute(key.as_bytes());
                let hash_int = u128::from_be_bytes(digest.0);
                let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
                let env = &self.shards[shard_idx];
                let db = self.dbs[shard_idx];
                let txn = env.begin_ro_txn().expect("RO txn failed");
                let cursor = txn.open_ro_cursor(db).expect("Cursor failed"); 
                let mut ids = HashSet::new();
                let key_bytes = key.as_bytes();
                if let Ok((Some(mut k), _)) = cursor.get(Some(key_bytes), None, MDB_SET_RANGE) {
                    loop {
                        if k.len() < 8 || !k.starts_with(key_bytes) || k.get(key.len()) != Some(&b'|') { break; }
                        ids.insert(LittleEndian::read_i64(&k[k.len()-8..]));
                        if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { k = next_k; } else { break; }
                    }
                }
                (ids, false)
            },
            FilterNode::Range(start, end) => {
                let sep_idx = start.find(':').map(|i| i + 1).unwrap_or(0);
                let field_prefix = &start[0..sep_idx];
                let start_bytes = start.as_bytes();
                let end_bytes = end.as_bytes();

                let shard_results: Vec<HashSet<i64>> = (0..self.num_shards).into_par_iter().map(|shard_idx| {
                    let mut found = HashSet::new();
                    let env = &self.shards[shard_idx];
                    let db = self.dbs[shard_idx];
                    let txn = env.begin_ro_txn().expect("RO txn failed");
                    let cursor = txn.open_ro_cursor(db).expect("Cursor failed");
                    
                    if let Ok((Some(mut k), _)) = cursor.get(Some(start_bytes), None, MDB_SET_RANGE) {
                        loop {
                            if k >= end_bytes || !k.starts_with(field_prefix.as_bytes()) { break; }
                            if k.len() > 8 { found.insert(LittleEndian::read_i64(&k[k.len()-8..])); }
                            if let Ok((Some(next_k), _)) = cursor.get(None, None, MDB_NEXT) { k = next_k; } else { break; }
                        }
                    }
                    found
                }).collect();

                (shard_results.into_iter().flatten().collect(), false)
            },
            FilterNode::And(nodes) => {
                if nodes.is_empty() { return (HashSet::new(), false); }
                let results: Vec<(HashSet<i64>, bool)> = nodes.par_iter().map(|n| self.eval_node(n)).collect();
                let (mut base_set, mut base_inv) = results[0].clone();

                for (curr_set, curr_inv) in &results[1..] {
                    if !base_inv && !*curr_inv { base_set.retain(|id| curr_set.contains(id)); }
                    else if !base_inv && *curr_inv { base_set.retain(|id| !curr_set.contains(id)); }
                    else if base_inv && !*curr_inv {
                        let mut new_base = curr_set.clone();
                        new_base.retain(|id| !base_set.contains(id));
                        base_set = new_base;
                        base_inv = false;
                    } else { base_set.extend(curr_set.iter()); }
                    if !base_inv && base_set.is_empty() { break; }
                }
                (base_set, base_inv)
            },
            FilterNode::Or(nodes) => {
                if nodes.is_empty() { return (HashSet::new(), false); }
                let results: Vec<(HashSet<i64>, bool)> = nodes.par_iter().map(|n| self.eval_node(n)).collect();
                let mut base_set = HashSet::new();
                for (s, inv) in results { if inv { return (HashSet::new(), true); } else { base_set.extend(s); }}
                (base_set, false)
            },
            FilterNode::Not(node) => { let (s, inv) = self.eval_node(node); (s, !inv) }
        }
    }
}

#[pymethods]
impl BlitzVec {
    #[new] #[pyo3(signature = (base_path, num_shards=5, map_size=200_000_000_000))]
    fn new(base_path: String, num_shards: usize, map_size: usize) -> PyResult<Self> {
        let (shards, dbs) = BlitzVec::init(&base_path, num_shards, map_size)?;
        Ok(BlitzVec { shards, dbs, num_shards, _base_path: base_path, _map_size: map_size })
    }

    fn close(&self) -> PyResult<()> { Ok(()) }

    fn store_vectors<'py>(&self, py: Python<'py>, data: PyReadonlyArray2<'py, f32>, identifiers: Vec<i64>) -> PyResult<()> {
        let vectors = data.as_array();
        let dim = vectors.shape()[1];
        if vectors.shape()[0] != identifiers.len() { return Err(pyo3::exceptions::PyValueError::new_err("Shape mismatch")); }
        let mut buckets: Vec<Vec<([u8; 8], &[u8])>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() {
            let key_info = BlitzVec::process_id(id, self.num_shards);
            let slice = unsafe { std::slice::from_raw_parts(vectors.row(i).as_ptr() as *const u8, dim * 4) };
            buckets[key_info.shard_idx].push((key_info.key_bytes, slice));
        }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, mut batch)| {
                if batch.is_empty() { return; }
                
                // OPTIMIZATION 2: Sort batch by key before insert.
                // This ensures sequential writes to the B-Tree, significantly reducing
                // IOPS and dirty page fragmentation.
                batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));

                let env = &self.shards[shard_idx];
                let mut txn = env.begin_rw_txn().unwrap();
                for (key_bytes, val_bytes) in batch { txn.put(self.dbs[shard_idx], &key_bytes, &val_bytes, WriteFlags::empty()).unwrap(); }
                txn.commit().unwrap();
            });
            Ok(())
        })
    }

    fn batch_index_insert(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        let mut buckets: Vec<Vec<(Vec<u8>, Vec<u8>)>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push((key, Vec::new()));
        }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, mut batch)| {
                if batch.is_empty() { return; }
                
                // OPTIMIZATION: Sort index entries too
                batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));

                let env = &self.shards[shard_idx];
                let mut txn = env.begin_rw_txn().unwrap();
                for (k, v) in batch { txn.put(self.dbs[shard_idx], &k, &v, WriteFlags::empty()).unwrap(); }
                txn.commit().unwrap();
            });
            Ok(())
        })
    }

    fn batch_index_delete(&self, py: Python<'_>, entries: Vec<(String, i64)>) -> PyResult<()> {
        let mut buckets: Vec<Vec<Vec<u8>>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (prefix, id) in entries {
            let digest = md5::compute(prefix.as_bytes());
            let hash_int = u128::from_be_bytes(digest.0);
            let shard_idx = (hash_int % (self.num_shards as u128)) as usize;
            let mut key = prefix.into_bytes();
            key.push(b'|');
            key.extend_from_slice(&id.to_le_bytes());
            buckets[shard_idx].push(key);
        }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, mut keys)| {
                if keys.is_empty() { return; }
                
                // OPTIMIZATION: Sort delete keys
                keys.sort_unstable();

                let env = &self.shards[shard_idx];
                let mut txn = env.begin_rw_txn().unwrap();
                for k in keys { let _ = txn.del(self.dbs[shard_idx], &k, None); }
                txn.commit().unwrap();
            });
            Ok(())
        })
    }

    fn get_ids_from_filter(&self, py: Python<'_>, filter_tree: PyObject) -> PyResult<Vec<i64>> {
        let node = FilterNode::from_py(filter_tree.as_ref(py))?;
        let (ids, inv) = py.allow_threads(|| self.eval_node(&node));
        if inv { Ok(vec![]) } else { Ok(ids.into_iter().collect()) }
    }

#[pyo3(signature = (query_vector, filter_tree=None, k=10))]
    fn search_optimized<'py>(
        &self,
        py: Python<'py>,
        query_vector: PyReadonlyArray1<'py, f32>,
        filter_tree: Option<PyObject>,
        k: usize,
    ) -> PyResult<Vec<(f32, i64)>> {
        let query_slice = query_vector.as_slice()?;
        let dim = query_slice.len();

        // 1. Evaluate the filter tree (if any) to get candidate IDs
        let candidate_ids = if let Some(tree_obj) = filter_tree {
            let node = FilterNode::from_py(tree_obj.as_ref(py))?;
            let (set, inv) = py.allow_threads(|| self.eval_node(&node));
            
            // If we have a positive filter (inv=false) and no IDs found, return early
            if !inv && set.is_empty() {
                return Ok(vec![]);
            }
            Some((set.into_iter().collect::<Vec<i64>>(), inv))
        } else {
            None
        };

        // 2. Perform the search across shards
        let scores: Vec<(f32, i64)> = py.allow_threads(|| {
            match candidate_ids {
                // CASE: Specific IDs to include (Point Lookups)
                Some((ids, false)) => {
                    let mut buckets = vec![Vec::new(); self.num_shards];
                    for id in ids {
                        let shard_idx = (id.unsigned_abs() as usize) % self.num_shards;
                        buckets[shard_idx].push(id);
                    }

                    buckets.into_par_iter().enumerate().flat_map(|(shard_idx, mut batch)| {
                        if batch.is_empty() { return Vec::new(); }

                        // CRITICAL OPTIMIZATION: Sort IDs to ensure sequential disk access
                        // This prevents "random walk" I/O patterns in LMDB.
                        batch.sort_unstable();

                        let env = &self.shards[shard_idx];
                        let db = self.dbs[shard_idx];
                        let txn = env.begin_ro_txn().expect("Failed to begin read txn");
                        
                        batch.into_iter().filter_map(|id| {
                            if let Ok(v_bytes) = txn.get(db, &id.to_le_bytes()) {
                                if v_bytes.len() == dim * 4 {
                                    // Zero-copy access to the vector data
                                    let vec_floats = unsafe {
                                        std::slice::from_raw_parts(v_bytes.as_ptr() as *const f32, dim)
                                    };
                                    return Some((fast_dot_product(query_slice, vec_floats), id));
                                }
                            }
                            None
                        }).collect::<Vec<_>>()
                    }).collect()
                },

                // CASE: IDs to exclude (Scan with filter)
                Some((exclude_ids, true)) => {
                    let exclude_set: HashSet<i64> = exclude_ids.into_iter().collect();
                    self.shards.par_iter().zip(&self.dbs).flat_map(|(env, db)| {
                        let txn = env.begin_ro_txn().expect("Failed to begin read txn");
                        let mut cursor = txn.open_ro_cursor(*db).expect("Failed to open cursor");
                        
                        cursor.iter().filter_map(|(k, v)| {
                            if k.len() != 8 || v.len() != dim * 4 { return None; }
                            let id = LittleEndian::read_i64(k);
                            
                            if exclude_set.contains(&id) { return None; }
                            
                            let vec_floats = unsafe {
                                std::slice::from_raw_parts(v.as_ptr() as *const f32, dim)
                            };
                            Some((fast_dot_product(query_slice, vec_floats), id))
                        }).collect::<Vec<_>>()
                    }).collect()
                },

                // CASE: No filters (Full Parallel Scan)
                None => {
                    self.shards.par_iter().zip(&self.dbs).flat_map(|(env, db)| {
                        let txn = env.begin_ro_txn().expect("Failed to begin read txn");
                        let mut cursor = txn.open_ro_cursor(*db).expect("Failed to open cursor");
                        
                        cursor.iter().filter_map(|(k, v)| {
                            if k.len() != 8 || v.len() != dim * 4 { return None; }
                            let id = LittleEndian::read_i64(k);
                            
                            let vec_floats = unsafe {
                                std::slice::from_raw_parts(v.as_ptr() as *const f32, dim)
                            };
                            Some((fast_dot_product(query_slice, vec_floats), id))
                        }).collect::<Vec<_>>()
                    }).collect()
                }
            }
        });

        // 3. Final Ranking: Sort by score descending and truncate to K
        let mut final_results = scores;
        final_results.sort_unstable_by(|a, b| {
            b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal)
        });
        
        if final_results.len() > k {
            final_results.truncate(k);
        }
        
        Ok(final_results)
    }

    fn store_data<'py>(&self, py: Python<'py>, data: Vec<PyObject>, identifiers: Vec<i64>) -> PyResult<()> {
        if data.len() != identifiers.len() { return Err(pyo3::exceptions::PyValueError::new_err("Length mismatch")); }
        let pickle = PyModule::import(py, "pickle")?;
        let dumps = pickle.getattr("dumps")?;
        let mut buckets: Vec<Vec<([u8; 8], Vec<u8>)>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() {
            let key_info = BlitzVec::process_id(id, self.num_shards);
            let bytes_obj = dumps.call1((&data[i],))?;
            let val_bytes = bytes_obj.extract::<&PyBytes>()?.as_bytes().to_vec();
            buckets[key_info.shard_idx].push((key_info.key_bytes, val_bytes));
        }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, mut batch)| {
                if batch.is_empty() { return; }
                
                // OPTIMIZATION: Sort metadata batch
                batch.sort_unstable_by(|a, b| a.0.cmp(&b.0));

                let env = &self.shards[shard_idx];
                let mut txn = env.begin_rw_txn().unwrap();
                for (key_bytes, val_bytes) in batch { txn.put(self.dbs[shard_idx], &key_bytes, &val_bytes, WriteFlags::empty()).unwrap(); }
                txn.commit().unwrap();
            });
            Ok(())
        })
    }

    fn get_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<&'py PyList> {
        let mut buckets: Vec<Vec<(usize, [u8; 8])>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for (i, &id) in identifiers.iter().enumerate() {
            buckets[(id.unsigned_abs() as usize) % self.num_shards].push((i, id.to_le_bytes()));
        }
        let mut results: Vec<Option<Vec<u8>>> = vec![None; identifiers.len()];
        let result_ptr = results.as_mut_ptr() as usize;
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(move |(shard_idx, reqs)| {
                if reqs.is_empty() { return; }
                let env = &self.shards[shard_idx]; let db = self.dbs[shard_idx];
                let txn = env.begin_ro_txn().unwrap();
                let res_ptr = result_ptr as *mut Option<Vec<u8>>;
                for (orig_idx, key_bytes) in reqs {
                    if let Ok(bytes) = txn.get(db, &key_bytes) {
                        unsafe { std::ptr::write(res_ptr.add(orig_idx), Some(bytes.to_vec())); }
                    }
                }
            });
        });
        let pickle = PyModule::import(py, "pickle")?;
        let loads = pickle.getattr("loads")?;
        let py_list = PyList::empty(py);
        for opt in results {
            let obj = if let Some(bytes) = opt { loads.call1((PyBytes::new(py, &bytes),))? } else { PyNone::get(py).into() };
            py_list.append(obj)?;
        }
        Ok(py_list)
    }

    fn delete_data<'py>(&self, py: Python<'py>, identifiers: Vec<i64>) -> PyResult<()> {
        let mut buckets: Vec<Vec<[u8; 8]>> = (0..self.num_shards).map(|_| Vec::new()).collect();
        for &id in identifiers.iter() {
            buckets[(id.unsigned_abs() as usize) % self.num_shards].push(id.to_le_bytes());
        }
        py.allow_threads(|| {
            buckets.into_par_iter().enumerate().for_each(|(shard_idx, mut keys)| {
                if keys.is_empty() { return; }
                
                // OPTIMIZATION: Sort delete keys
                keys.sort_unstable();

                let env = &self.shards[shard_idx];
                let mut txn = env.begin_rw_txn().unwrap();
                for key in keys { let _ = txn.del(self.dbs[shard_idx], &key, None); }
                txn.commit().unwrap();
            });
            Ok(())
        })
    }

    fn get_data_count(&self) -> PyResult<usize> {
        let total: usize = self.shards.par_iter().map(|env| env.stat().unwrap().entries()).sum();
        Ok(total)
    }
}

#[pymodule]
fn blitz_vec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<BlitzVec>()?;
    Ok(())
}