# Using 115 for hosting image.

## Installation

You can install from [pypi](https://pypi.org/project/p115imghost/)

```console
pip install -U p115imghost
```

## Usage

```console
$ p115imghost -h
usage: p115imghost [-h] [-c COOKIES] [-cp COOKIES_PATH] [-v] [-l] [file ...]

115 图床

positional arguments:
  file                  图片路径

options:
  -h, --help            show this help message and exit
  -c, --cookies COOKIES
                        cookies 字符串，优先级高于 -cp/--cookies-path
  -cp, --cookies-path COOKIES_PATH
                        cookies 文件保存路径，默认为当前工作目录下的 115-cookies.txt
  -v, --version         输出版本号
  -l, --license         输出授权信息
```
