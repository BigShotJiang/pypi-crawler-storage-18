"""Tests for ui module."""
