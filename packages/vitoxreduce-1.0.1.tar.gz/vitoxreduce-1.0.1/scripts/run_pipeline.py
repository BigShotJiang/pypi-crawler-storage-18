#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script chạy pipeline ViToxReduce
"""

import os
import sys
import json
import argparse
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime

# Thêm đường dẫn để import các module
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from vitoxreduce import ViToxReducePipeline

# Import evaluate_predictions từ eval_metrics
try:
    from vitoxreduce.eval_metrics import evaluate_predictions
except ImportError as e:
    # Logger sẽ được setup sau trong main(), nhưng cần log warning ngay
    import warnings
    warnings.warn(f"Không thể import evaluate_predictions từ eval_metrics: {e}. Metrics sẽ không được tính.")
    evaluate_predictions = None

# Import normalize_rewrite_field từ bartpho_span_baseline để đọc rewrites field
try:
    from vitoxreduce.bartpho_span_baseline import normalize_rewrite_field
except ImportError:
    # Fallback function nếu không import được
    def normalize_rewrite_field(rewrites):
        if not rewrites:
            return ""
        if isinstance(rewrites, str):
            return rewrites.strip()
        if isinstance(rewrites, (list, tuple)):
            for candidate in rewrites:
                if isinstance(candidate, str) and candidate.strip():
                    return candidate.strip()
        return ""


def setup_logging(log_dir: str = "./logs"):
    """Thiết lập logging"""
    os.makedirs(log_dir, exist_ok=True)
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    log_file = os.path.join(log_dir, f'vitoxreduce_pipeline_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    
    return logging.getLogger(__name__)


def load_jsonl(path: str) -> List[dict]:
    """Load dữ liệu từ file JSONL"""
    data = []
    if not os.path.exists(path):
        logger.warning(f"File không tồn tại: {path}")
        return data
    
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError as e:
                logger.warning(f"Bỏ qua dòng lỗi JSON: {e}")
    
    return data


def main():
    parser = argparse.ArgumentParser(description="Chạy pipeline ViToxReduce")
    
    # Input/Output
    parser.add_argument(
        "--input",
        type=str,
        default=None,
        help="File input (JSONL với field 'comment' hoặc text file, hoặc text trực tiếp). Nếu không chỉ định, sẽ tự động tìm test set."
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="File output JSON (default: stdout hoặc input_results.json)"
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=["single", "file", "jsonl"],
        default="auto",
        help="Mode xử lý (auto: tự động phát hiện)"
    )
    
    # Model paths
    parser.add_argument(
        "--toxicity_detector_model",
        type=str,
        default=None,
        help="Path đến PhoBERT toxicity classifier (Tầng 1 - Safety Checker)"
    )
    parser.add_argument(
        "--span_locator_model",
        type=str,
        default=None,
        help="Path đến PhoBERT Token Classification model (Tầng 2 - Span Tagger). Nếu không chỉ định, sẽ tự động tìm."
    )
    parser.add_argument(
        "--rewriter_model",
        type=str,
        default=None,
        help="Path đến BARTpho rewriter model (Tầng 3 - Contextual Rewriter). Nếu không chỉ định, sẽ tự động tìm."
    )
    
    # Config
    parser.add_argument(
        "--num_beams",
        type=int,
        default=5,
        help="Số beams cho beam search trong Tầng 3 (default: 5)"
    )
    parser.add_argument(
        "--toxicity_threshold",
        type=float,
        default=0.5,
        help="Ngưỡng phân loại unsafe (default: 0.5)"
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Device (cuda/cpu, default: auto)"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="In chi tiết quá trình xử lý"
    )
    
    args = parser.parse_args()
    
    # Setup logging
    global logger
    logger = setup_logging()
    
    # Kiểm tra các model paths bắt buộc
    if args.rewriter_model is None:
        logger.error("--rewriter_model là tham số bắt buộc! Vui lòng chỉ định đường dẫn đến BARTpho rewriter model.")
        sys.exit(1)
    
    if args.span_locator_model is None:
        logger.error("--span_locator_model là tham số bắt buộc! Vui lòng chỉ định đường dẫn đến PhoBERT span locator model.")
        sys.exit(1)
    
    if args.toxicity_detector_model is None:
        logger.error("--toxicity_detector_model là tham số bắt buộc! Vui lòng chỉ định đường dẫn đến PhoBERT toxicity classifier model.")
        sys.exit(1)
    
    if args.input is None:
        logger.error("--input là tham số bắt buộc! Vui lòng chỉ định file input hoặc text cần xử lý.")
        sys.exit(1)
    
    # Khởi tạo pipeline
    logger.info("Đang khởi tạo pipeline ViToxReduce (3 tầng)...")
    try:
        pipeline = ViToxReducePipeline(
            toxicity_detector_model_path=args.toxicity_detector_model,
            toxicity_threshold=args.toxicity_threshold,
            span_locator_model_path=args.span_locator_model,
            rewriter_model_path=args.rewriter_model,
            num_beams=args.num_beams,
            device=args.device,
        )
    except Exception as e:
        logger.error(f"Lỗi khi khởi tạo pipeline: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Xác định mode
    if args.mode == "auto":
        if os.path.isfile(args.input):
            if args.input.endswith('.jsonl'):
                mode = "jsonl"
            else:
                mode = "file"
        else:
            mode = "single"
    else:
        mode = args.mode
    
    # Xử lý input
    texts = []
    input_data = []  # Lưu toàn bộ data để lấy reference sau
    if mode == "single":
        # Text trực tiếp
        texts = [args.input]
        input_data = [{"comment": args.input}]
    elif mode == "file":
        # File text, mỗi dòng là một câu
        with open(args.input, 'r', encoding='utf-8') as f:
            texts = [line.strip() for line in f if line.strip()]
            input_data = [{"comment": text} for text in texts]
    elif mode == "jsonl":
        # File JSONL
        input_data = load_jsonl(args.input)
        # Lọc và map chỉ các item có comment
        texts = []
        filtered_input_data = []
        for item in input_data:
            comment = item.get('comment', '').strip()
            if comment:
                texts.append(comment)
                filtered_input_data.append(item)
        input_data = filtered_input_data  # Chỉ giữ lại các item có comment
    
    if not texts:
        logger.error("Không có text nào để xử lý!")
        sys.exit(1)
    
    logger.info(f"Đang xử lý {len(texts)} câu...")
    
    # Xử lý
    pipeline_results = pipeline.process_batch(texts, verbose=args.verbose)
    
    # Chuẩn bị cấu trúc kết quả theo format mẫu
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Chuẩn bị dữ liệu để tính metrics
    predictions = []
    references = []
    originals = []
    example_records = []  # Để truyền vào evaluate_predictions
    
    # Chuyển đổi pipeline results sang format mẫu và chuẩn bị dữ liệu cho metrics
    examples = []
    for idx, result in enumerate(pipeline_results):
        original = result.get('original', '')
        prediction = result.get('rewritten', result.get('original', ''))
        
        # Lấy reference từ input_data nếu có
        reference = None
        example_id = idx
        if mode == "jsonl" and idx < len(input_data):
            input_item = input_data[idx]
            if 'id' in input_item:
                example_id = input_item['id']
            # Ưu tiên đọc từ field 'rewrites' (giống baseline)
            if 'rewrites' in input_item:
                reference = normalize_rewrite_field(input_item['rewrites'])
            elif 'reference' in input_item:
                reference = input_item['reference']
            elif 'rewritten' in input_item:
                reference = input_item['rewritten']
        
        # Nếu không có reference, dùng original làm reference (fallback)
        if reference is None or not reference.strip():
            reference = original
        
        example = {
            "index": idx,
            "original": original,
            "prediction": prediction,
            "is_safe": result.get('is_safe', False),
            "toxicity_score": result.get('toxicity_score', 0.0),
            # LƯU Ý: spans và span_texts chỉ có giá trị khi unsafe (tier 2 đã chạy)
            # Với safe: spans = [], span_texts = [] (vì bỏ qua tier 2)
            "spans": result.get('spans', []),  # Character indices từ Tier 2 (chỉ có khi unsafe)
            "span_texts": result.get('span_texts', []),  # Text của spans từ Tier 2 (chỉ có khi unsafe)
            # Kết quả kiểm tra lại sau khi rewrite
            "rewritten_is_safe": result.get('rewritten_is_safe'),  # True nếu câu đã rewrite là safe
            "rewritten_toxicity_score": result.get('rewritten_toxicity_score'),  # Điểm độc hại của câu đã rewrite
            "processing_time": result.get('processing_time', 0.0)
        }
        
        # Thêm reference và id nếu có trong input data (cho JSONL)
        if mode == "jsonl" and idx < len(input_data):
            input_item = input_data[idx]
            if 'id' in input_item:
                example["id"] = input_item['id']
            # Thêm reference nếu có
            if 'reference' in input_item:
                example["reference"] = input_item['reference']
            elif 'rewritten' in input_item:
                example["reference"] = input_item['rewritten']
        
        examples.append(example)
        
        # Chuẩn bị dữ liệu cho metrics (chỉ tính cho các câu có reference)
        predictions.append(prediction)
        references.append(reference)
        originals.append(original)
        example_records.append({
            "id": example_id,
            "original": original,
            "reference": reference,
            "prediction": prediction,
            "spans": result.get('spans', []),
            "span_texts": result.get('span_texts', [])
        })
    
    # Tính metrics nếu có evaluate_predictions
    metrics_result = None
    if evaluate_predictions is not None:
        logger.info("Đang tính các metrics (BLEU, SIM, FL, STA, J-score)...")
        try:
            # Lấy path đến toxicity detector model để tính STA
            phobert_model_path = args.toxicity_detector_model or None
            metrics_result = evaluate_predictions(
                predictions=predictions,
                references=references,
                originals=originals,
                original_items=None,  # Không cần
                example_records=example_records,
                phobert_model_path=phobert_model_path
            )
            logger.info("Đã tính xong các metrics!")
        except Exception as e:
            logger.error(f"Lỗi khi tính metrics: {e}")
            import traceback
            traceback.print_exc()
            metrics_result = None
    
    # Tạo output structure theo format baseline
    output_data = {
        "dataset": args.input if args.input else "stdin",
        "generated_at": timestamp,
        "pipeline": "vitoxreduce_3tier",
        "model_paths": {
            "toxicity_detector": args.toxicity_detector_model or "auto",
            "span_locator": args.span_locator_model or "auto",
            "rewriter": args.rewriter_model or "auto"
        },
        "config": {
            "toxicity_threshold": args.toxicity_threshold,
            "num_beams": args.num_beams,
            "device": args.device or "auto"
        },
        "total_toxic_examples": sum(1 for r in pipeline_results if not r.get('is_safe', True)),
    }
    
    # Thêm result object với metrics (giống baseline)
    if metrics_result is not None:
        # Cập nhật examples trong metrics_result với spans từ pipeline
        # metrics_result["examples"] đã được tạo bởi evaluate_predictions nhưng không có spans
        # Cần merge với examples từ pipeline để có spans
        for idx, example in enumerate(examples):
            if idx < len(metrics_result["examples"]):
                # Thêm spans và các field khác vào example từ metrics_result
                metrics_result["examples"][idx].update({
                    "spans": example.get("spans", []),
                    "span_texts": example.get("span_texts", []),
                    "is_safe": example.get("is_safe", False),
                    "toxicity_score": example.get("toxicity_score", 0.0),
                    "rewritten_is_safe": example.get("rewritten_is_safe"),
                    "rewritten_toxicity_score": example.get("rewritten_toxicity_score"),
                    "processing_time": example.get("processing_time", 0.0)
                })
        output_data["result"] = metrics_result
    else:
        # Nếu không tính được metrics, tạo result object rỗng
        output_data["result"] = {
            "j": 0.0,
            "sta": 0.0,
            "avg_tox_drop": 0.0,
            "avg_tox_drop_on_toxic_only": 0.0,
            "avg_original_toxicity": 0.0,
            "avg_prediction_toxicity": 0.0,
            "toxic_originals": 0,
            "toxic_predictions": 0,
            "reference_based_metrics": {"bleu": {"bleu": 0.0}},
            "reference_free_metrics": {
                "sim": {"sim": 0.0},
                "fl": {"ppl": 0.0, "fl": 0.0}
            },
            "total_examples": len(pipeline_results),
            "examples": examples
        }
    
    # Lưu kết quả
    if args.output:
        output_path = args.output
    elif mode != "single":
        # Tạo folder result nếu chưa có
        result_dir = os.path.join(current_dir, "result")
        os.makedirs(result_dir, exist_ok=True)
        
        # Tạo tên file output với timestamp
        base_name = os.path.basename(args.input)
        base_name_no_ext = os.path.splitext(base_name)[0]
        output_path = os.path.join(result_dir, f"{base_name_no_ext}_results_{timestamp}.json")
    else:
        output_path = None
    
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        logger.info(f"Đã lưu kết quả vào {output_path}")
    else:
        # In ra stdout
        print(json.dumps(output_data, ensure_ascii=False, indent=2))
    
    # Thống kê
    safe_count = sum(1 for r in pipeline_results if r.get('is_safe', False))
    unsafe_count = len(pipeline_results) - safe_count
    rewritten_count = sum(1 for r in pipeline_results if not r.get('is_safe', True) and r.get('rewritten') != r.get('original'))
    avg_time = sum(r.get('processing_time', 0) for r in pipeline_results) / len(pipeline_results) if pipeline_results else 0
    
    # Thống kê hiệu quả rewrite
    # Số câu được rewrite thành công (từ unsafe -> safe)
    successfully_detoxified = sum(1 for r in pipeline_results 
                                  if not r.get('is_safe', True) 
                                  and r.get('rewritten_is_safe') == True)
    # Số câu vẫn còn unsafe sau khi rewrite
    still_unsafe_after_rewrite = sum(1 for r in pipeline_results 
                                     if not r.get('is_safe', True) 
                                     and r.get('rewritten_is_safe') == False)
    # Tính độ giảm độc hại trung bình cho các câu đã rewrite
    toxicity_reductions = []
    for r in pipeline_results:
        if not r.get('is_safe', True) and r.get('rewritten_toxicity_score') is not None:
            original_tox = r.get('toxicity_score', 0.0)
            rewritten_tox = r.get('rewritten_toxicity_score', 0.0)
            toxicity_reductions.append(original_tox - rewritten_tox)
    avg_toxicity_reduction = sum(toxicity_reductions) / len(toxicity_reductions) if toxicity_reductions else 0.0
    success_rate = (successfully_detoxified / unsafe_count * 100) if unsafe_count > 0 else 0.0
    
    logger.info(f"\n{'='*60}")
    logger.info("THỐNG KÊ")
    logger.info(f"{'='*60}")
    logger.info(f"Tổng số câu: {len(pipeline_results)}")
    logger.info(f"Safe (giữ nguyên): {safe_count} ({safe_count/len(pipeline_results)*100:.1f}%)")
    logger.info(f"Unsafe (đã xử lý): {unsafe_count} ({unsafe_count/len(pipeline_results)*100:.1f}%)")
    logger.info(f"Đã viết lại: {rewritten_count} ({rewritten_count/len(pipeline_results)*100:.1f}%)")
    logger.info(f"")
    logger.info(f"HIỆU QUẢ REWRITE:")
    logger.info(f"  - Rewrite thành công (unsafe -> safe): {successfully_detoxified} ({success_rate:.1f}%)")
    still_unsafe_rate = (still_unsafe_after_rewrite/unsafe_count*100) if unsafe_count > 0 else 0.0
    logger.info(f"  - Vẫn còn unsafe sau rewrite: {still_unsafe_after_rewrite} ({still_unsafe_rate:.1f}%)")
    logger.info(f"  - Độ giảm độc hại trung bình: {avg_toxicity_reduction:.3f}")
    
    # In metrics nếu có
    if metrics_result is not None:
        logger.info(f"")
        logger.info(f"METRICS:")
        logger.info(f"  - J-score: {metrics_result.get('j', 0.0):.6f}")
        logger.info(f"  - STA: {metrics_result.get('sta', 0.0):.6f}")
        logger.info(f"  - Avg Tox Drop: {metrics_result.get('avg_tox_drop', 0.0):.6f}")
        logger.info(f"  - BLEU: {metrics_result.get('reference_based_metrics', {}).get('bleu', {}).get('bleu', 0.0):.6f}")
        logger.info(f"  - SIM: {metrics_result.get('reference_free_metrics', {}).get('sim', {}).get('sim', 0.0):.6f}")
        logger.info(f"  - FL: {metrics_result.get('reference_free_metrics', {}).get('fl', {}).get('fl', 0.0):.6f}")
    
    logger.info(f"")
    logger.info(f"Thời gian xử lý trung bình: {avg_time:.3f}s/câu")
    if output_path:
        logger.info(f"Kết quả đã được lưu vào: {output_path}")
    logger.info(f"Đã xử lý thành công!")


if __name__ == "__main__":
    main()
