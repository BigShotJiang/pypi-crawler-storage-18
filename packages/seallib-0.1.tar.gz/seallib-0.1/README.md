# SealLib

Библиотека с алгоритмом Дейкстры и функцией Эйлера.

## Установка

pip install SealLib

## Использование

from algo_utils import dijkstra_path, totient

