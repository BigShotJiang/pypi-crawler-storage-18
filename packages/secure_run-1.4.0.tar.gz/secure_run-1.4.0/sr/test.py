import sr

sr.cli()