# Secure Run (sr)

Encrypt Python files and run them securely

## Install
```bash
pip install secure-run