"""Action types for agent runtime."""

import copy
from typing import Any, Literal

from pydantic import BaseModel, Field


def _make_strict_compatible(schema: dict[str, Any]) -> None:
    """Recursively make schema compatible with OpenAI strict mode.

    OpenAI strict mode requires:
    - additionalProperties: false on all objects
    - All properties must be in 'required' array
    """
    if schema.get("type") == "object" or "properties" in schema:
        schema["additionalProperties"] = False
        # All properties must be required in strict mode
        if "properties" in schema:
            schema["required"] = list(schema["properties"].keys())
            for prop in schema["properties"].values():
                _make_strict_compatible(prop)

    # Handle anyOf, oneOf, allOf
    for key in ("anyOf", "oneOf", "allOf"):
        if key in schema:
            for item in schema[key]:
                _make_strict_compatible(item)

    # Handle items in arrays
    if "items" in schema:
        _make_strict_compatible(schema["items"])


def _build_union_schema(schemas: list[dict[str, Any]]) -> dict[str, Any]:
    """Build a union schema from multiple schemas.

    If there's only one schema, returns it directly.
    If there are multiple, returns an anyOf union.
    If there are none, returns an empty object schema.
    """
    if not schemas:
        return {"type": "object", "properties": {}, "additionalProperties": False}
    if len(schemas) == 1:
        return schemas[0]
    return {"anyOf": schemas}


def build_action_schema(
    output_schema: dict[str, Any],
    tool_schemas: list[dict[str, Any]] | None = None,
    subagent_schemas: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build ActionList JSON schema with agent's schemas embedded.

    Args:
        output_schema: The agent's output schema to embed.
        tool_schemas: List of tool parameter schemas (for arguments field).
        subagent_schemas: List of subagent input schemas (for subagent_input field).

    Returns:
        Complete ActionList schema for structured outputs.
    """
    # Start with the Action schema
    action_schema = copy.deepcopy(Action.model_json_schema())

    # Embed output schema
    action_schema["properties"]["output"] = copy.deepcopy(output_schema)

    # Embed tool argument schemas as union
    if tool_schemas:
        args_schema = _build_union_schema([copy.deepcopy(s) for s in tool_schemas])
        action_schema["properties"]["arguments"] = args_schema

    # Embed subagent input schemas as union
    if subagent_schemas:
        subagent_schema = _build_union_schema(
            [copy.deepcopy(s) for s in subagent_schemas]
        )
        action_schema["properties"]["subagent_input"] = subagent_schema

    # Build the ActionList schema wrapping the action
    schema = {
        "type": "object",
        "properties": {
            "actions": {
                "type": "array",
                "items": action_schema,
            }
        },
        "required": ["actions"],
    }

    # Make schema compatible with OpenAI strict mode
    _make_strict_compatible(schema)

    return schema


class Action(BaseModel):
    """A single agent action."""

    action: Literal["CALL_TOOL", "SPAWN_SUBAGENT", "DONE"] = Field(
        description="The type of action to take"
    )
    tool_name: str | None = Field(
        default=None, description="Name of the MCP tool to call (for CALL_TOOL)"
    )
    arguments: dict[str, Any] = Field(
        default_factory=dict,
        description="Arguments for tool call (for CALL_TOOL)",
    )
    subagent_name: str | None = Field(
        default=None, description="Name of subagent to spawn (for SPAWN_SUBAGENT)"
    )
    subagent_input: dict[str, Any] = Field(
        default_factory=dict,
        description="Input for subagent (for SPAWN_SUBAGENT)",
    )
    output: dict[str, Any] = Field(
        default_factory=dict,
        description="Final output matching schema (for DONE)",
    )


class ActionList(BaseModel):
    """List of actions to execute.

    Actions in the list can potentially be executed in parallel,
    except for DONE which terminates the loop.
    """

    actions: list[Action] = Field(
        description="List of actions to execute (can be parallelized in the future)"
    )
