import dataclasses
import io
import typing as t

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.mixins.shareable import Shareable
from genguardx._internal.mixins.simulatable import Simulatable
from genguardx._internal.mixins.with_notes import WithNotes
from genguardx._internal.mixins.with_python_code import WithPythonCode
from genguardx._internal.mixins.workflowable import Workflowable
from genguardx._internal.models import Model
from genguardx._internal.prompts import Prompt
from genguardx._internal.rags import Rag
from genguardx._internal.resources import GlobalFunction
from genguardx._internal.util import utils
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS
from genguardx._internal.util.lang_utils import cast_value, parse_user_literal


if t.TYPE_CHECKING:
    from genguardx._internal.test_sessions import TestSession


@dataclasses.dataclass(frozen=True)
class InputArgument:
    alias: str
    type: str
    is_mandatory: bool
    default_value: t.Any


@dataclasses.dataclass(frozen=True)
class CustomModelDefinition:
    model_file: io.BytesIO
    initialization_logic: str
    scoring_logic: str


PIPELINE_TYPE_DISPLAY_NAMES = {
    "FreeForm": "Custom Return Type",
    "Chat": "Chat based - OpenAI Spec",
}


class Pipeline(ApiBase, Auditable, WithNotes, Workflowable, Simulatable, Searchable, Shareable, WithPythonCode):
    """Represents an Pipeline that is registered.

    :param name:    The name of the Pipeline to fetch.
    :param version: The version of the Pipeline to fetch. If not provided, the latest approved
                    version is used.
    :param id:      The ID of the Pipeline to fetch. If provided, name and version are not used.

    Examples
    --------
    >>> pipeline_1 = Pipeline('pipeline_1')
    >>> pipeline_1.name
    'pipeline_1'
    >>> pipeline_1.version
    1
    """

    _object_type = Objects.PIPELINE.value
    _LIST_URL = URLS.PIPELINE_PATH.value

    _available_filter_names = {"status", "alias", "name", "type", "contains", "group"}

    def __init__(
        self, alias: str | None = None, name: str | None = None, version: int | None = None, id: int | None = None
    ) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if alias is not None:
            filters["alias"] = alias
        if name is not None:
            filters["name"] = name
        if version is not None:
            filters["version"] = version
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(one=True, **filters)

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: Pipeline)

    @property
    def id(self) -> int:
        """The ID that is unique to every Pipeline."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Pipeline as registered."""
        return self._data["name"]

    @property
    def alias(self) -> str:
        return self._data["alias"]

    @property
    def version(self) -> int:
        """The version of this Pipeline."""
        return self._data["version"]

    @property
    def description(self) -> str:
        """The description registered for the Pipeline."""
        return self._data["description"]

    @property
    def note(self) -> str:
        """The note registered for the Pipeline."""
        return self._data["note"]

    @property
    def group(self) -> str:
        """The group that this Pipeline belongs to."""
        return self._data["group"]

    @property
    def current_status(self) -> str:
        """The current workflow status of the Pipeline."""
        return self._data["currentStatus"]

    @property
    def type(self) -> str:
        return self._data["type"]

    @property
    def interaction_type(self) -> str | None:
        """The data type for interaction for chat based pipeline."""
        return self._data["interactionType"]

    @property
    def context_type(self) -> str | None:
        """The data type for context for chat based pipeline."""
        return self._data["contextType"]

    @property
    def definition(self) -> CustomModelDefinition | None:
        """The definition registered for the Pipeline."""
        if not self._data.get("definition"):
            return None
        file = None
        if (
            "file" in self._data["definition"]
            and self._data["definition"]["file"] is not None
            and "id" in self._data["definition"]["file"]
        ):
            file = utils.get_model_definition("custom", self._data["definition"]["file"]["id"])
        return CustomModelDefinition(
            file,
            self._data["definition"].get("initLogic"),
            self._data["definition"].get("runLogic"),
        )

    @property
    def pipeline_type(self) -> str:
        """The type of the pipeline: Free Form or Chat Based"""
        return PIPELINE_TYPE_DISPLAY_NAMES.get(self._data["pipelineType"])

    @property
    def arguments(self) -> InputArgument:
        return [
            InputArgument(
                inp["alias"],
                inp["inputType"],
                inp["isMandatory"],
                cast_value(
                    parse_user_literal(
                        inp["defaultValue"],
                        inp["inputType"],
                        # Datetime-as-string is fine as cast_value() will cast it to a datetime.datetime
                        datetime_check=False,
                    ),
                    inp["inputType"],
                )
                if inp["isMandatory"] is False
                else None,
            )
            for inp in self._data["functionInputs"]
        ]

    @property
    def permissible_purpose(self) -> list[str]:
        return self._data["permissibleTags"]

    @property
    def input_features(self) -> list[GlobalFunction]:
        return [GlobalFunction(id=i) for i in self._data["featureVersionIds"]]

    @property
    def input_prompts(self) -> list[Prompt]:
        return [Prompt(id=id_) for id_ in self._data["promptVersionIds"]]

    @property
    def input_models(self) -> list[Model]:
        return [Model(id=id_) for id_ in self._data["foundationModelVersionIds"]]

    @property
    def input_rags(self) -> list[Rag]:
        return [Rag(id=id_) for id_ in self._data["ragVersionIds"]]

    @property
    def input_pipelines(self) -> list["Pipeline"]:
        return [Pipeline(id=id_) for id_ in self._data["pipelineVersionIds"]]

    @property
    def examples(self) -> list[dict]:
        """
        Returns pipeline examples as a list of dicts with keys:
        startingInput, context, personName, personDescription, sortOrder
        """
        return self._data.get("examples", [])

    @property
    def chat_sessions(self) -> list["TestSession"]:
        assert self.pipeline_type == PIPELINE_TYPE_DISPLAY_NAMES["Chat"], (
            "Chat Sessions are not supported for this pipeline"
        )

        from genguardx._internal.test_sessions import TestSession

        return [TestSession._from_data(data=item) for item in TestSession._get_data(pipelineVersionId=self._data["id"])]

    @classmethod
    def declare(
        cls,
        *,
        name: str | None = None,  # If not provided, use alias (function name)
        group: str | None = None,  # Optional value
        usecase_type: t.Literal["Question Answering", "Summarization", "Translation"] | None = None,
        task_type: t.Literal[
            "Classification",
            "Templated Responses",
            "Generative Responses",
            "Summarization",
            "Others",
        ]
        | None = None,
        impact: t.Literal["External Facing", "Internal - with external implications", "Internal Only"] | None = None,
        data_usage: t.Sequence[
            t.Literal["No Additional Data", "General Public Data", "Internal Policies/Data", "Customer Specific Data"]
        ] = (),
        pipeline_type: t.Literal[
            "Custom Return Type",
            "Chat based - OpenAI Spec",
        ] = "Chat based - OpenAI Spec",  # Assume OpenAI chat by default
        provider: str | None = None,  # If provided, we know the pipeline is an External Agent
        agent: str | None = None,  # If provided, specifies the agent within the provider
        examples: t.Sequence[dict] = (),  # Pipeline examples
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "group": group,
                "usecase_type": usecase_type,
                "task_type": task_type,
                "impact": impact,
                "data_usage": data_usage,
                "pipeline_type": pipeline_type,
                "provider": provider,
                "agent": agent,
                "examples": examples,
            }
            return func

        return inner

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}", version={self.version}>'
