import json as json_module
import os
import ssl
import typing as t

import httpx
import importlib_metadata

from genguardx._internal import whoami


def ujoin(base: str, url: str) -> str:
    return str(base).rstrip("/") + "/" + str(url).lstrip("/")


class SessionConfig:
    """
    Note that this is only the configs set for the requests Session. So, for example: timeout, user, workspace
    are not kept here.
    - timeout is a request level config, can change for every API call
    - user, workspace is for auth in the request, can change for every API call
    """

    api_url: str
    verify: bool
    ssl_certificate: str | None
    ssl_private_key: str | None
    ssl_ca_bundle: str | None

    @staticmethod
    def get_value(key: str, default: str) -> str:
        return os.environ.get(key, str(default))

    @property
    def api_url(self) -> str:
        # Earlier, we used to need the /corr-api URL as we used to use corridor-api. Now, we just need the corridor
        # instance URL. So, add /corr-api to the URL if it's not already there.
        url = self.get_value("CORRIDOR_API_URL", "http://localhost:5002/corr-api")
        if url.endswith("/corr-api"):
            return url
        return url.rstrip("/") + "/corr-api"

    @api_url.setter
    def api_url(self, val: str) -> None:
        os.environ["CORRIDOR_API_URL"] = val

    @property
    def verify(self) -> bool:
        return self.get_value("CORRIDOR_API_VERIFY_SSL", "TRUE").upper() in ("TRUE", "YES", "1")

    @verify.setter
    def verify(self, val: bool) -> None:
        os.environ["CORRIDOR_API_VERIFY_SSL"] = "1" if val else "0"

    @property
    def ssl_certificate(self) -> str | None:
        certificate = self.get_value("CORRIDOR_API_SSL_CERTIFICATE", "")
        if certificate.upper() in ("", "NONE"):
            return None
        return certificate

    @ssl_certificate.setter
    def ssl_certificate(self, val: str | None) -> None:
        if val in ("", None):
            os.environ.pop("CORRIDOR_API_SSL_CERTIFICATE", None)
        else:
            os.environ["CORRIDOR_API_SSL_CERTIFICATE"] = val

    @property
    def ssl_private_key(self) -> str:
        pkey = self.get_value("CORRIDOR_API_SSL_PRIVATE_KEY", "")
        if pkey.upper() in ("", "NONE"):
            return None
        return pkey

    @ssl_private_key.setter
    def ssl_private_key(self, val: str | None) -> None:
        if val in ("", None):
            os.environ.pop("CORRIDOR_API_SSL_PRIVATE_KEY", None)
        else:
            os.environ["CORRIDOR_API_SSL_PRIVATE_KEY"] = val

    @property
    def ssl_ca_bundle(self) -> str | None:
        ssl_ca_bundle = self.get_value("CORRIDOR_API_SSL_CA_BUNDLE", "")
        if ssl_ca_bundle.upper() in ("", "NONE"):
            return None
        return ssl_ca_bundle

    @ssl_ca_bundle.setter
    def ssl_ca_bundle(self, val: str | None) -> None:
        if val in ("", None):
            os.environ.pop("CORRIDOR_API_SSL_CA_BUNDLE", None)
        else:
            os.environ["CORRIDOR_API_SSL_CA_BUNDLE"] = val


class ApiAuth(httpx.Auth):
    def __init__(self, *args, **kwargs) -> None:
        self.user_api_key = None
        self.workspace = None
        super().__init__(*args, **kwargs)

    def init_user(self, user_api_key: str, workspace: str = "corridor") -> None:
        self.user_api_key = user_api_key
        self.workspace = workspace

    def auth_flow(self, request: httpx.Request) -> t.Generator[httpx.Request, httpx.Response, None]:
        if self.user_api_key is None:
            # Prints that the session is not initialised
            whoami()
        request.headers["x-api-key"] = self.user_api_key
        if self.workspace is not None:
            request.headers["x-workspace-name"] = self.workspace
        yield request


class NetworkSession:
    client: httpx.Client

    def __init__(self) -> None:
        self.client = self._get_default_client()

    @staticmethod
    def _get_default_client(**kwargs) -> httpx.Client:
        config = SessionConfig()

        # Handle SSL settings
        ssl_ctx: ssl.SSLContext | t.Literal[False] = False
        if config.verify is True and config.ssl_ca_bundle is not None:
            ssl_ctx = ssl.create_default_context(cafile=config.ssl_ca_bundle)
            if config.ssl_private_key is not None and config.ssl_certificate is not None:
                ssl_ctx.load_cert_chain(config.ssl_certificate, config.ssl_private_key)

        # Timeout
        timeout = SessionConfig.get_value("CORRIDOR_API_TIMEOUT", "300")
        try:
            timeout = int(timeout)
        except (TypeError, ValueError):
            timeout = 300

        # set default parameter for httpx.Client configuration
        defaults = {
            "base_url": config.api_url,
            "auth": ApiAuth(),
            "verify": ssl_ctx,
            "timeout": timeout,
            "mounts": {},
            "headers": {"user-agent": f"genguardx/{importlib_metadata.version('genguardx')}"},
        }
        for key, val in defaults.items():
            kwargs.setdefault(key, val)

        return httpx.Client(**kwargs)

    @staticmethod
    def _get_response_error_message(resp: httpx.Response) -> str:
        """Show a good error about the failure for the response"""
        msg = f"For {resp.request.method} at {resp.url}\n"
        if resp.is_error:  # Print Status if it is a error status-code
            msg += f"Got Status Code = {resp.status_code} (reason={resp.reason_phrase})\n"
        msg += "Got response:\n"
        try:  # Attempt to get the response as a JSON
            msg += str(resp.json())
        except Exception:
            try:  # Get the text message from the body
                n = 500
                text = resp.text[:n]
                hidden_n = len(resp.text) - n
                msg += text + (f"... {hidden_n} more chars" if hidden_n > 0 else "")
            except Exception:  # Unable to get the response
                msg += "\n"
        return msg

    def response(
        self,
        url: str,
        *,
        out: str = "json",
        params: dict | None = None,
        json: dict | None = None,
        data: dict | None = None,
        files: dict | None = None,
    ) -> str | bytes | dict:
        """
        :param url:    The URL to call
        :param out:    Get the response of the API as:
                       - json: JSON data parsed as a dictionary
                       - bin: Binary data as bytes
                       - text: Text format as a string
        :param params: The query params to use when making the API call
        :param json:   The JSON payload to use when making the API call
        :param data:   The multipart form data to be sent
        :param files:   The files to be sent
        """
        if json is not None:
            assert files is None, "`files` and `json` cannot be provided together"
            assert data is None, "`data` and `json` cannot be provided together"
        if files is not None or data is not None:
            assert json is None, "`json` cannot be provided along with `files` or `data`"

            if data is not None and files is None:  # Get files from the data

                def _extract_files(data: dict | list | tuple, path: str = "") -> tuple[dict, dict]:
                    newjson, newfiles = data, {}
                    if isinstance(data, (list, tuple)):
                        newjson = []
                        for iitem, item in enumerate(data):
                            subpath = f"{path}[{iitem}]"
                            if isinstance(item, bytes):
                                newfiles[subpath] = item
                            else:
                                innerjson, innerfiles = _extract_files(item, subpath)
                                newfiles = {**newfiles, **innerfiles}
                                newjson.append(innerjson)
                    elif isinstance(data, dict):
                        newjson = {}
                        for key, val in data.items():
                            subpath = f"{path}.{key}" if path else key
                            if isinstance(val, (bytes, tuple)):
                                newfiles[subpath] = val
                            else:
                                innerjson, innerfiles = _extract_files(val, subpath)
                                newjson[key] = innerjson
                                newfiles = {**newfiles, **innerfiles}
                    return newjson, newfiles

                json_with_files, files = _extract_files(data)
                data = {"json": json_module.dumps(json_with_files)}

        resp = self.client.request(
            "POST" if json is not None or data is not None or files is not None else "GET",
            url=url,
            params=params,
            json=json,
            data=data,
            follow_redirects=False,
            files=files,
        )

        if out == "json":
            try:
                return resp.json()
            except json_module.JSONDecodeError:
                print(f"Failed to parse JSON from response: {self._get_response_error_message(resp)}")
                raise
        if out == "text":
            return resp.text
        if out == "bin":
            return resp.content
        raise NotImplementedError(f"Unknown out={out}")


api = NetworkSession()
