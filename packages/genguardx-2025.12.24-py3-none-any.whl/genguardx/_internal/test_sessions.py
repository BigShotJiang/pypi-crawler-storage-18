import typing as t
from dataclasses import dataclass
from functools import cached_property

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


if t.TYPE_CHECKING:
    from genguardx._internal.pipelines import Pipeline
    from genguardx._internal.resources import Report


@dataclass(frozen=True)
class Interaction:
    role: t.Literal["system", "user", "assistant", "_internal"]
    content: str
    context: str | None
    error_message: str | None
    comment: str | None
    rating: int | None
    issue_type: str | None
    time_taken: int | None
    # TODO: Handle interaction metrics


@dataclass(frozen=True)
class Rating:
    valid_responses: int
    invalid_responses: int


class TestSession(ApiBase, Auditable, Searchable):
    _object_type = Objects.TEST_SESSION.value
    _LIST_URL = URLS.TEST_SESSION_PATH.value

    _available_filter_names = {"name", "group"}

    def __init__(self, name: str | None = None, id: int | None = None) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if name is not None:
            filters["name"] = name
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(one=True, **filters)

    @property
    def id(self) -> int:
        return self._data["id"]

    @property
    def name(self) -> str:
        return self._data["name"]

    @property
    def description(self) -> str:
        return self._data["description"]

    @property
    def group(self) -> str:
        return self._data["group"]

    @property
    def is_old(self) -> bool:
        return self._data["isOld"]

    @property
    def has_session_ended(self) -> bool:
        return self._data["hasSessionEnded"]

    @property
    def testing_notes(self) -> str:
        return self._data["testingNotes"]

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}">'

    @cached_property
    def pipeline(self) -> "Pipeline":
        from genguardx._internal.pipelines import Pipeline

        return Pipeline(id=self._data["pipelineVersionId"])

    @property
    def interactions(self) -> list[Interaction]:
        return [
            Interaction(
                role=interaction["role"],
                content=interaction["content"],
                context=interaction["context"],
                error_message=interaction["errorMessage"],
                comment=interaction["comment"],
                rating=interaction["rating"],
                issue_type=interaction["issueType"],
                time_taken=interaction["timeTaken"],
            )
            for interaction in self._data["interactions"]
        ]

    @property
    def openai_messages(self) -> list[dict]:
        msg = []
        for interaction in self._data["interactions"]:
            if interaction["role"] == "_internal":
                continue

            if interaction["role"] in {"system", "user", "assistant"}:
                msg.append({"role": interaction["role"], "content": interaction["content"]})

            # TODO: Handle tool calls?
        return msg

    @property
    def rating(self) -> Rating:
        return Rating(
            valid_responses=self._data["rating"]["likeCount"] or 0,
            invalid_responses=self._data["rating"]["dislikeCount"] or 0,
        )

    @cached_property
    def chat_reports(self) -> list["Report"]:
        from genguardx._internal.resources import Report

        return [Report(id=id_) for id_ in (self._data["chatReportIds"] or [])]
