from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import URLS
from genguardx._internal.util.networking import api


class Attachment(ApiBase, Auditable):
    """
    Represents an Attachment that is registered.
    :param id:      The ID of the attachment to fetch.
    """

    _LIST_URL = URLS.ATTACHMENTS_PATH.value

    def __init__(self, id: int) -> None:
        self._data = api.response(f"/api/v1/attachments/{id}", out="bin")

    @property
    def data(self) -> bytes:
        """The contents of the attachment in bytes."""
        return self._data
