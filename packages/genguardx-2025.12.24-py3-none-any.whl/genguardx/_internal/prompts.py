import dataclasses
import io
import typing as t

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.mixins.shareable import Shareable
from genguardx._internal.mixins.simulatable import Simulatable
from genguardx._internal.mixins.with_notes import WithNotes
from genguardx._internal.mixins.with_python_code import WithPythonCode
from genguardx._internal.mixins.workflowable import Workflowable
from genguardx._internal.resources import GlobalFunction
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS
from genguardx._internal.util.lang_utils import cast_value, parse_user_literal


if t.TYPE_CHECKING:
    from genguardx._internal.models import Model
    from genguardx._internal.rags import Rag


@dataclasses.dataclass(frozen=True)
class InputArgument:
    alias: str
    type: str
    is_mandatory: bool
    default_value: t.Any


@dataclasses.dataclass(frozen=True)
class CustomModelDefinition:
    model_file: io.BytesIO
    initialization_logic: str
    scoring_logic: str


class Prompt(ApiBase, Auditable, WithNotes, Workflowable, Searchable, Shareable, Simulatable, WithPythonCode):
    """Represents an Prompt that is registered.

    :param name:   The name of the Prompt to fetch.
    :param version: The version of the Prompt to fetch. If not provided, the latest approved version is used.
    :param id:      The ID of the Prompt to fetch. If provided, name and version are not used.

    Examples
    --------
    >>> prompt_1 = Prompt('prompt_1')
    >>> prompt_1.name
    'prompt_1'
    >>> prompt_1.version
    1
    """

    _object_type = Objects.PROMPT.value
    _LIST_URL = URLS.PROMPT_PATH.value
    _available_filter_names = {"status", "alias", "name", "type", "contains", "group"}

    def __init__(
        self, alias: str | None = None, name: str | None = None, version: int | None = None, id: int | None = None
    ) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if alias is not None:
            filters["alias"] = alias
        if name is not None:
            filters["name"] = name
        if version is not None:
            filters["version"] = version
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(one=True, **filters)

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: Prompt)

    @property
    def id(self) -> int:
        """The ID that is unique to every Prompt. (and is different for every version of the Prompt too.)"""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Prompt as registered."""
        return self._data["name"]

    @property
    def alias(self) -> str:
        return self._data["alias"]

    @property
    def version(self) -> int:
        """The version of this Prompt."""
        return self._data["version"]

    @property
    def description(self) -> str:
        """The description registered for the Prompt."""
        return self._data["description"]

    @property
    def note(self) -> str:
        """The note registered for the Prompt."""
        return self._data["note"]

    @property
    def group(self) -> str:
        """The group that this Prompt belongs to."""
        return self._data["group"]

    @property
    def current_status(self) -> str:
        """The current workflow status of the Prompt."""
        return self._data["currentStatus"]

    @property
    def definition(self) -> CustomModelDefinition | None:
        """The definition registered for the Prompt."""
        if not self._data.get("definition"):
            return None
        file = None
        return CustomModelDefinition(
            file,
            self._data["definition"].get("initLogic"),
            self._data["definition"].get("runLogic"),
        )

    @property
    def template(self) -> str | None:
        if not self._data.get("definition"):
            return None
        return self._data["definition"].get("initLogic")

    @property
    def scoring_logic(self) -> str | None:
        if not self._data.get("definition"):
            return None
        return self._data["definition"].get("runLogic")

    @property
    def arguments(self) -> InputArgument:
        return [
            InputArgument(
                inp["alias"],
                inp["inputType"],
                inp["isMandatory"],
                cast_value(
                    parse_user_literal(
                        inp["defaultValue"],
                        inp["inputType"],
                        # Datetime-as-string is fine as cast_value() will cast it to a datetime.datetime
                        datetime_check=False,
                    ),
                    inp["inputType"],
                )
                if inp["isMandatory"] is False
                else None,
            )
            for inp in self._data["functionInputs"]
        ]

    @property
    def input_features(self) -> list["GlobalFunction"]:
        return [GlobalFunction(id=i) for i in self._data["featureVersionIds"]]

    @property
    def input_prompts(self) -> list["Prompt"]:
        return [Prompt(id=id_) for id_ in self._data["promptVersionIds"]]

    @property
    def input_models(self) -> list["Model"]:
        from genguardx._internal.models import Model

        return [Model(id=id_) for id_ in self._data["foundationModelVersionIds"]]

    @property
    def input_rags(self) -> list["Rag"]:
        from genguardx._internal.rags import Rag

        return [Rag(id=id_) for id_ in self._data["ragVersionIds"]]

    @classmethod
    def declare(
        cls,
        *,
        name: str | None = None,  # If not provided, use alias (function name)
        group: str | None = None,  # Optional value
        task_type: t.Literal[
            "Classification",
            "Question Answering",
            "Information Extraction",
            "Summarization",
            "Code Generation",
            "Transformation",
            "Generation",
            "Others",
        ]
        | None = None,
        prompt_type: t.Literal["System Instruction", "User Prompt", "Others"] | None = None,
        prompt_elements: t.Sequence[
            t.Literal[
                "Persona + Goal",
                "Tone",
                "Task",
                "Constraints",
                "Context",
                "Examples",
                "Reasoning Steps",
                "Output Format",
                "Recap",
            ]
        ] = (),
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "group": group,
                "task_type": task_type,
                "prompt_type": prompt_type,
                "prompt_elements": prompt_elements,
            }
            return func

        return inner

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}", version={self.version}>'
