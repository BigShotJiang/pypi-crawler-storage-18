import datetime

import dateutil.parser


class Auditable:
    """Represents an item that has auditing fields."""

    @property
    def created_date(self) -> datetime.datetime:
        """The date when the item was created."""
        return dateutil.parser.parse(self._data["createdDate"])

    @property
    def created_by(self) -> str:
        """The username of the user that created the item."""
        return self._data["createdBy"]

    @property
    def last_modified_date(self) -> datetime.datetime:
        """The date when the item was last modified."""
        return dateutil.parser.parse(self._data["lastModifiedDate"])

    @property
    def last_modified_by(self) -> str:
        """The username of the user that last modified the item."""
        return self._data["lastModifiedBy"]
