import typing as t

from genguardx._internal.data_tables import DataColumn, DataTable
from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.mixins.simulatable import Simulatable
from genguardx._internal.mixins.with_notes import WithNotes
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


class QualityCheck(ApiBase, Auditable, Simulatable, Searchable, WithNotes):
    """Represents a QualityCheck that is registered.

    :param name:    The name of the QualityCheck to fetch.
    :param id:      The ID of the QualityCheck to fetch. If provided, name is not used.

    Examples
    --------
    >>> check_nulls = QualityCheck('Check Nulls in critical columns')
    >>> check_nulls.name
    'Check Nulls in critical columns'
    """

    _object_type = Objects.QUALITY_CHECK.value
    _LIST_URL = URLS.QUALITY_PROFILE_PATH.value

    _available_filter_names = {"name", "contains", "group"}

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: QualityCheck)

    def __init__(self, name: str | None = None, id: int | None = None) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if name is not None:
            filters["name"] = name
        self._data = self._get_data(one=True, **filters)

    @property
    def id(self) -> int:
        """The ID that is unique to every QualityCheck."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the QualityCheck as registered."""
        return self._data["name"]

    @property
    def description(self) -> str:
        """The description registered for the QualityCheck."""
        return self._data["description"]

    @property
    def note(self) -> str:
        """Any notes added during registration."""
        return self._data["note"]

    @property
    def group(self) -> str:
        """The group that this QualityCheck belongs to."""
        return self._data["group"]

    @property
    def data_columns(self) -> list[DataColumn]:
        """The list of columns from the table that this QualityCheck is going to run on"""
        return [DataColumn(id=i) for i in self._data["inputColumns"]]

    @property
    def data_table(self) -> DataTable:
        """The table that this QualityCheck is going to run on"""
        return DataTable(id=self._data["dataTableId"])

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}">'
