# A I Video Insights
**Extract Relevant Technical Insights from Video Descriptions**
===========================================================

**Overview**
-----------

This package allows users to gain a deeper understanding of AI advancements and supercomputer capabilities by extracting key information from video descriptions.

**Installation**
------------

```bash
pip install ai_video_insights
```

**Usage**
-------

```python
from ai_video_insights import ai_video_insights

response = ai_video_insights(
    user_input="Video description here...",
    llm=None  # Optional langchain llm instance, defaults to ChatLLM7
)
```

**Input Parameters**
-------------------

* `user_input`: `str` - The user input text to process.
* `llm`: `Optional[BaseChatModel]` - The langchain llm instance to use, defaults to ChatLLM7.
* `api_key`: `Optional[str]` - The api key for llm7, defaults to None.

**LLM Support**
------------

This package uses the ChatLLM7 from `langchain_llm7` by default. You can safely pass your own llm instance (based on the langchain `BaseChatModel`) if you want to use another LLM.

**Examples**
---------

```python
# Using ChatLLM7 by default
response = ai_video_insights(user_input="Example video description.")

# Using a custom language model instance
from langchain_openai import ChatOpenAI
llm = ChatOpenAI()
response = ai_video_insights(user_input="Example video description.", llm=llm)

# Using an anthropic language model instance
from langchain_anthropic import ChatAnthropic
llm = ChatAnthropic()
response = ai_video_insights(user_input="Example video description.", llm=llm)

# Using a google language model instance
from langchain_google_genai import ChatGoogleGenerativeAI
llm = ChatGoogleGenerativeAI()
response = ai_video_insights(user_input="Example video description.", llm=llm)
```

**Rate Limits**
------------

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you need higher rate limits, you can pass your own api key via environment variable `LLM7_API_KEY` or via passing it directly.

**API Key Registration**
-----------------------

You can get a free api key by registering at [https://token.llm7.io/](https://token.llm7.io/).

**Contributing**
--------------

This package is hosted on GitHub at [https://github.com/chigwell/ai-video-insights](https://github.com/chigwell/ai-video-insights).

**License**
---------

MIT License

**Author**
---------

Eugene Evstafev (eugene.evstafev@euegne.plus)