"""Mathematical utilities module."""
