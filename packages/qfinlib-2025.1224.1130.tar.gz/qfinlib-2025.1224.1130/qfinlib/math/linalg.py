"""Linear algebra helpers."""
