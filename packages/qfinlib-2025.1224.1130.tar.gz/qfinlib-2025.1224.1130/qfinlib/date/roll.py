"""Roll conventions."""
