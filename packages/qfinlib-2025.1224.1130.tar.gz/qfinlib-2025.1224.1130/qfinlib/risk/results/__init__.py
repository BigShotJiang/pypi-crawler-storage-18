"""Risk results module."""
