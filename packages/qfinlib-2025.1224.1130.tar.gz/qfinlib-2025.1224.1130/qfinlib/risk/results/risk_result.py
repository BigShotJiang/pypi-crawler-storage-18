"""Risk result class."""
