"""Scenario configuration."""
