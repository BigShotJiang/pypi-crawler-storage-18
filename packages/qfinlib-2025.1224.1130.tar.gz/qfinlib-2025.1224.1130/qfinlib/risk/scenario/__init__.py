"""Risk scenario module."""
