"""Scenario generator."""
