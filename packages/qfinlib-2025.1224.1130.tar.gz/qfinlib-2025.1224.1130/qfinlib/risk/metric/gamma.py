"""Gamma metric."""
