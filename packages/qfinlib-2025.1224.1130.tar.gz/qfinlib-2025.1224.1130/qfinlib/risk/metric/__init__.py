"""Risk metric module."""
