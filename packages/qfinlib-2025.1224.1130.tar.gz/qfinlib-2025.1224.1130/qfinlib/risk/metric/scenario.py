"""Scenario analysis metric."""
