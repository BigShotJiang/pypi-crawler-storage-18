"""Carry and roll metric."""
