"""Base risk metric class."""
