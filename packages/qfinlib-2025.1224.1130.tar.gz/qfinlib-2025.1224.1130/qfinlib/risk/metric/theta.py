"""Theta metric."""
