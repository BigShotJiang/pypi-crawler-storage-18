"""Present value metric."""
