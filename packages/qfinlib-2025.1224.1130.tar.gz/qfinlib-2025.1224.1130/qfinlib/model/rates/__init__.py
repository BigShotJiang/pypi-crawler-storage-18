"""Interest rate models module."""
