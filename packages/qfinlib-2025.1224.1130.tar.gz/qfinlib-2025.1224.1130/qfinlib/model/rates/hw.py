"""Hull-White model."""
