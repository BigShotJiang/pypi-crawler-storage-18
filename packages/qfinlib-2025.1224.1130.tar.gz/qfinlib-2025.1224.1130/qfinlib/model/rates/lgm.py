"""Linear Gaussian Model (LGM)."""
