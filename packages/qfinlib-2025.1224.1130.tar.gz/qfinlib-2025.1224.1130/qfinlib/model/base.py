"""Base model class."""
