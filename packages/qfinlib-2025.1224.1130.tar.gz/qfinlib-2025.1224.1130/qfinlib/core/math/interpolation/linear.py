"""Linear interpolation."""
