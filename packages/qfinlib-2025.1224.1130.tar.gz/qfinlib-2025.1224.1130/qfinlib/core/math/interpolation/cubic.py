"""Cubic interpolation."""
