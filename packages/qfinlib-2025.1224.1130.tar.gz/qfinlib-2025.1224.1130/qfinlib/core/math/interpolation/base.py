"""Interpolator base class."""
