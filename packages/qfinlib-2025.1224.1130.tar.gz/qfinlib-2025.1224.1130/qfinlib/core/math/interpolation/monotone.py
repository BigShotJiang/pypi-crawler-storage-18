"""Monotone interpolation."""
