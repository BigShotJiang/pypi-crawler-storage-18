"""Log-linear interpolation."""
