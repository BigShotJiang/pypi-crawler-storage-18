"""Statistics module."""
