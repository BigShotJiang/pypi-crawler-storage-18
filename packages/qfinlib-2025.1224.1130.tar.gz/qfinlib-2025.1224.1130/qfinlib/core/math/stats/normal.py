"""Normal distribution utilities."""
