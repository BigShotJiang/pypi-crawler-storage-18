"""Statistical distributions."""
