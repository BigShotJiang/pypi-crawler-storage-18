"""Reverse-mode AD tape."""
