"""Newton-Raphson solver."""
