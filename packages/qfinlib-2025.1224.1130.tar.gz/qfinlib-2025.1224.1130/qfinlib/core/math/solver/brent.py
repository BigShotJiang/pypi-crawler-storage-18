"""Brent's method solver."""
