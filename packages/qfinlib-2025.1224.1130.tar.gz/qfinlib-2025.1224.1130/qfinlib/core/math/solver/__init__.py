"""Solver module."""
