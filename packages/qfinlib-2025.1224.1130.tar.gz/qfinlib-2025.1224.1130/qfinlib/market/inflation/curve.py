"""Inflation curve."""
