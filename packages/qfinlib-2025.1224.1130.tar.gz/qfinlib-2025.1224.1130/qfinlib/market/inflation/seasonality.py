"""Inflation seasonality."""
