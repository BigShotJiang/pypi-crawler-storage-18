"""Inflation module."""
