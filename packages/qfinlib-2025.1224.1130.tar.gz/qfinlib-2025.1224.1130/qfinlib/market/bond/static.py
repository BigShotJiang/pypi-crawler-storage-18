"""Static bond market data."""
