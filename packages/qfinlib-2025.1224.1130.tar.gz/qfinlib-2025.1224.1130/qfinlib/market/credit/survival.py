"""Survival probability curves."""
