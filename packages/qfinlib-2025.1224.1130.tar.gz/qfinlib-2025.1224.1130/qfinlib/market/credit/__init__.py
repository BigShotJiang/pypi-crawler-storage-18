"""Credit module."""
