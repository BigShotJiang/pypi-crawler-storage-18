"""Rate fixings."""
