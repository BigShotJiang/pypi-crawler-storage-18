"""FX volatility."""
