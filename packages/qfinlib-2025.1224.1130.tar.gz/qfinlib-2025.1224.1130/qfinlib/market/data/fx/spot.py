"""FX spot rates."""
