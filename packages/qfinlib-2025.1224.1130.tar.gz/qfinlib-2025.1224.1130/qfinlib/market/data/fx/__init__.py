"""FX module."""
