"""Rates module."""
