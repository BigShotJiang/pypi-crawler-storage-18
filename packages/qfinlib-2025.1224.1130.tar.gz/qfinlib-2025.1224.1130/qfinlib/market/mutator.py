"""Market scenario mutations."""
