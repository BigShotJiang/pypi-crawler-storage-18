"""Swaption volatility."""
