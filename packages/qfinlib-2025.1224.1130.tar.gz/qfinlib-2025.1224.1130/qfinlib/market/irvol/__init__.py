"""Interest rate volatility module."""
