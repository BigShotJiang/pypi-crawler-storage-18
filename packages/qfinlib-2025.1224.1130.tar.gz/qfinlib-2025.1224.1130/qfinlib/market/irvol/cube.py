"""Volatility cube."""
