"""Base curve class."""
