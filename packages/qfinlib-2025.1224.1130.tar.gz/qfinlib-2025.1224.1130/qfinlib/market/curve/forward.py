"""Forward curve."""
