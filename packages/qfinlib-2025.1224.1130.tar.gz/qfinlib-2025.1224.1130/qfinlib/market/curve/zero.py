"""Zero curve."""
