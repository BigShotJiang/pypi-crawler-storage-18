"""Spread curve."""
