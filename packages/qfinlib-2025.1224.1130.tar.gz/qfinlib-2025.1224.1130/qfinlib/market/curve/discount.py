"""Discount curve."""
