"""MarketObject, MarketObjectData base classes."""
