"""Curve calibration engine."""
