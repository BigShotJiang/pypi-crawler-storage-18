"""Forward curve factory."""
