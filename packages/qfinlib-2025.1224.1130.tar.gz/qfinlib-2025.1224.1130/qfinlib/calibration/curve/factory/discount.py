"""Discount curve factory."""
