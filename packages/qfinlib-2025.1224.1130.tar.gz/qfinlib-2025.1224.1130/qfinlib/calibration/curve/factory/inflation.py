"""Inflation curve factory."""
