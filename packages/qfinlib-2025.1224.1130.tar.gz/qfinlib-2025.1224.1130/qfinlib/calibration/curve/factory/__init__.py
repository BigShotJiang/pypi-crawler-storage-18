"""Curve factory module."""
