"""Curve calibration solver."""
