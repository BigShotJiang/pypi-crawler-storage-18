"""Bond calibration instrument."""
