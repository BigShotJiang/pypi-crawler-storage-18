"""FRA calibration instrument."""
