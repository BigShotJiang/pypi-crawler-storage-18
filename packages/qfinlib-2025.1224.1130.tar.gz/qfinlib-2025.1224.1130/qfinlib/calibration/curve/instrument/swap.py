"""Swap calibration instrument."""
