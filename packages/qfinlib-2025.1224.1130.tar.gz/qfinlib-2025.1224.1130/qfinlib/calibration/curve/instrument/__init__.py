"""Calibration instrument module."""
