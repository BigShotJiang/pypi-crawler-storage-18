"""Base calibration instrument."""
