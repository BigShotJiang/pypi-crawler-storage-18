"""Deposit calibration instrument."""
