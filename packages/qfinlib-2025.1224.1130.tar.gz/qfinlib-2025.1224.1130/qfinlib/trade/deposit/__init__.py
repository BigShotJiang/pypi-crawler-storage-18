"""Deposit module."""
