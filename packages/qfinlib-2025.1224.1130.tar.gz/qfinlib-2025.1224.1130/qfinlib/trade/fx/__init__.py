"""FX trade module."""
