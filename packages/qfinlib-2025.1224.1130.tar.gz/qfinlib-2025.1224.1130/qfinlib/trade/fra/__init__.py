"""FRA module."""
