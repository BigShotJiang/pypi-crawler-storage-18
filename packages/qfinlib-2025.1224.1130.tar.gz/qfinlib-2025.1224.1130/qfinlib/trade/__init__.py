"""Trade module."""
