"""Inflation-linked bond."""
