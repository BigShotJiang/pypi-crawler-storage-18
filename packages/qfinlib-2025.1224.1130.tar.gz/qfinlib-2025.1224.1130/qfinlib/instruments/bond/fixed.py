"""Fixed rate bond."""
