"""Floating rate bond."""
