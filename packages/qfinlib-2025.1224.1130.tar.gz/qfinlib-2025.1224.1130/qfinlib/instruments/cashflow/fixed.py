"""Fixed cashflows."""
