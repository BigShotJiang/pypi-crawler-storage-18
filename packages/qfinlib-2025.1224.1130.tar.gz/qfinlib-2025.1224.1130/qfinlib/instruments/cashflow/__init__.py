"""Cashflow module."""
