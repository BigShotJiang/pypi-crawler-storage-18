"""Base cashflow class."""
