"""Floating cashflows."""
