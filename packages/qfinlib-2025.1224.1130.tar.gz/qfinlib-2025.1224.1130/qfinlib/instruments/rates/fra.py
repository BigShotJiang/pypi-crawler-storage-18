"""Forward rate agreement."""
