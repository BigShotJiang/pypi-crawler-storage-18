"""Interest rate swap."""
