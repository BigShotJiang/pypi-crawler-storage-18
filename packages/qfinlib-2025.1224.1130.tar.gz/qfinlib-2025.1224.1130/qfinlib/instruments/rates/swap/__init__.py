"""Swap module."""
