"""Swap leg."""
