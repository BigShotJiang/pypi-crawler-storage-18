"""Cross-currency swap."""
