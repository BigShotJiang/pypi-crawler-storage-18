"""Zero coupon inflation swap."""
