"""Cap and floor."""
