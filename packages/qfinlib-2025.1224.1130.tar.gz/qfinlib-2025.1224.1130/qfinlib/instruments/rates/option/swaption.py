"""Swaption."""
