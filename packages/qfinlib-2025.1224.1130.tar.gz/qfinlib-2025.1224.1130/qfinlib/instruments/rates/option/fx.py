"""FX option."""
