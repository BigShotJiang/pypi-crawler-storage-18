"""Credit default swap."""
