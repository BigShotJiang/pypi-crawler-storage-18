"""Future pricer."""
