"""Swaption pricer."""
