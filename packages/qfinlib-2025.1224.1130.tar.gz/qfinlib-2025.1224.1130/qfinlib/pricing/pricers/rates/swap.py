"""Swap pricer."""
