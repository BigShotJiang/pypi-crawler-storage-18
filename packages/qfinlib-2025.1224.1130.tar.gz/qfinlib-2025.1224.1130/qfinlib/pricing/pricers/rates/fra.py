"""FRA pricer."""
