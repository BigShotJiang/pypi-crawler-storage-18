"""Deposit pricer."""
