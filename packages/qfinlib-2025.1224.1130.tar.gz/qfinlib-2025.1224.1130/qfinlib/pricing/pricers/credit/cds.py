"""CDS pricer."""
