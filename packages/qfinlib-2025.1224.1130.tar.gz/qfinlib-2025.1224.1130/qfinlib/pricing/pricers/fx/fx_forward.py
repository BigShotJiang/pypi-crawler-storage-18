"""FX forward pricer."""
