"""Priceable module."""
