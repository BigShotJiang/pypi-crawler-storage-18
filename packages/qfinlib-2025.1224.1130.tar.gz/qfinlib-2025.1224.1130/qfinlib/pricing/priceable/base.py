"""Priceable base class."""
