"""Cashflow visitor pattern."""
