"""Cashflow present value calculation."""
