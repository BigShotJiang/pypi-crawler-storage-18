"""Calculator module."""
