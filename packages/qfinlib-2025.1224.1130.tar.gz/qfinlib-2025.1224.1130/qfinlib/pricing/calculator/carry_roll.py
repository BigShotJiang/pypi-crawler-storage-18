"""Carry and roll calculation."""
