"""Yield calculation."""
