"""Forward rate calculation."""
