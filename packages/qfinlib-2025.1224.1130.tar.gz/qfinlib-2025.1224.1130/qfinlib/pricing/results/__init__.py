"""Valuation results module."""
