# d2l_torch


This repository contains PyTorch implementations of the Deep Learning book "Dive into Deep Learning" (D2L). It provides code examples, tutorials, and exercises to help you learn deep learning concepts using PyTorch.


## Installation
```
pip install -U ml_d2l_torch
```

## Code Examples
You can find the code examples in the `re_d2l_torch` package. Here is a simple example of how to use it:

```python
import d2l_torch as d2l

```
