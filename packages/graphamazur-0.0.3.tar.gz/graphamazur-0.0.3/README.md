# Лабораторная работа 4: Алгоритмы на графах

## Описание

### Модуль 1 - базовая работа с графами
1. Создание графа - create_graph()
2. Добавление вершины - add_vertex(graph, name)
3. Добавление ребра - add_edge(graph, v1, v2, weight=1)
4. Подсчёт вершин - count_vertex(graph)
5. Подсчёт рёбер - count_edges(graph)
6. Получение вершин - get_vertices(graph)
7. Получение рёбер - get_edges(graph)
8. Матрица смежности - smejnost_matrix(graph)
9. Печать матрицы смежности - print_smejnost_matrix(graph)
10. Печать рёбер - print_edges(graph)

### Модуль 2 - алгоритмы
1. Алгоритм Прима - prim_algorithm()
2. Алгоритм Краскала - kruskal_algorithm(graph)
3. Алгоритм Дейкстры - dijkstra_algorithm(graph, start_vertex)
4. Вывод результата Прима - show_prim_result(edges)
5. Вывод результата Краскала - show_kruskal_result(edges)
6. Вывод результата Дейкстры - show_dijkstra_result(distances, previous, start)