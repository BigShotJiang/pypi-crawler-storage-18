"""Unit tests for localargo."""
