"""Tests for localargo."""
