"""RxTracer - FastAPI application"""
