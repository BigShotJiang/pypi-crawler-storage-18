"""Parse functionality using ripgrep"""

import logging
import os
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

# Import noop prometheus stub by default (CLI mode)
# Real prometheus is only imported in web.py for server mode
from rx.cli import prometheus as prom
from rx.seekable_index import find_frame_for_line, get_or_build_index
from rx.seekable_zstd import decompress_frame, is_seekable_zstd
from rx.utils import NEWLINE_SYMBOL, NEWLINE_SYMBOL_BYTES


logger = logging.getLogger(__name__)


LINE_SIZE_ASSUMPTION_KB = int(os.getenv('RX_MAX_LINE_SIZE_KB', '8'))  # for context retrieving we assume max avg length
MAX_SUBPROCESSES = int(os.getenv('RX_MAX_SUBPROCESSES', '20'))
MIN_CHUNK_SIZE = int(os.getenv('RX_MIN_CHUNK_SIZE_MB', str(20))) * 1024 * 1024
MAX_FILES = int(os.getenv('RX_MAX_FILES', '1000'))  #


@dataclass
class FileTask:
    """Represents a unit of work for parallel processing"""

    task_id: int
    filepath: str
    offset: int  # Starting byte offset (aligned to newline)
    count: int  # Number of bytes to read

    @property
    def end_offset(self) -> int:
        return self.offset + self.count


def is_text_file(filepath: str, sample_size: int = 8192) -> bool:
    """
    Check if a file is a text file by reading a sample and looking for null bytes.
    Binary files typically contain null bytes, while text files don't.
    """
    try:
        with open(filepath, 'rb') as f:
            sample = f.read(sample_size)
            if b'\x00' in sample:
                return False
            return True
    except Exception:
        return False


def scan_directory_for_text_files(dirpath: str, max_files: int = MAX_FILES) -> tuple[list[str], list[str]]:
    text_files = []
    skipped_files = []

    logger.info(f'[SCAN] Scanning directory recursively: {dirpath}')

    try:
        for root, dirs, files in os.walk(dirpath):
            for filename in files:
                if len(text_files) + len(skipped_files) >= max_files:
                    logger.warning(f'[SCAN] Reached max_files limit ({max_files}), stopping scan')
                    return text_files, skipped_files

                filepath = os.path.join(root, filename)

                # Skip symlinks
                if os.path.islink(filepath):
                    logger.debug(f'[SCAN] Skipping symlink: {filepath}')
                    continue

                # Check if text file
                if is_text_file(filepath):
                    text_files.append(filepath)
                    logger.debug(f'[SCAN] Added text file: {filepath}')
                else:
                    skipped_files.append(filepath)
                    logger.debug(f'[SCAN] Skipped binary file: {filepath}')

        logger.info(f'[SCAN] Completed: {len(text_files)} text files, {len(skipped_files)} skipped')
        return text_files, skipped_files

    except Exception as e:
        logger.error(f'[SCAN] Error scanning directory: {e}')
        raise RuntimeError(f'Directory scan failed: {e}')


def validate_file(filepath: str) -> None:
    """Validate that a file exists and is processable (text or supported compressed format)."""
    from rx.compression import is_compressed

    if not os.path.exists(filepath):
        raise FileNotFoundError(f'File not found: {filepath}')

    if not os.path.isfile(filepath):
        raise ValueError(f'Path is not a file: {filepath}')

    # Accept compressed files (they appear binary but are processable)
    if is_compressed(filepath):
        return

    # Accept seekable zstd files
    if is_seekable_zstd(filepath):
        return

    if not is_text_file(filepath):
        raise ValueError('File appears to be binary, not text')


def find_next_newline(filename: str, offset: int) -> int:
    """
    Find the position of the next newline after the given offset.
    This ensures we split on line boundaries.

    Args:
        filename: Path to the file
        offset: Starting byte offset

    Returns:
        Byte position of next newline, or offset if at end of file
    """
    with open(filename, 'rb') as f:
        f.seek(offset)
        # Read up to 256KB to find next newline
        chunk = f.read(256 * 1024)
        if not chunk:
            return offset

        newline_pos = chunk.find(NEWLINE_SYMBOL_BYTES)
        if newline_pos == -1:
            # No newline found in this chunk, return end of chunk
            return offset + len(chunk)

        return offset + newline_pos + len(NEWLINE_SYMBOL_BYTES)  # Position after the newline


def get_file_offsets(filename: str, file_size_bytes: int) -> list[int]:
    """
    Calculate byte offsets for splitting a file into equal length parallel processing chunks.
    Offsets are aligned to line boundaries to ensure patterns are not split.

    Rules:
    - Each chunk should be at least MIN_CHUNK_SIZE bytes
    - Maximum number of chunks is MAX_SUBPROCESSES
    - Chunks are aligned to line boundaries (newlines)
    - Returns list of starting byte offsets (always starts with 0)

    Args:
        filename: Path to the file

    Returns:
        List of byte offsets where each chunk starts, aligned to line boundaries

    Examples:
        60MB file -> [0] (whole file goes to one worker)
        140MB file -> [0, ~70MB] (2 chunks, aligned to newlines)
        180MB file -> [0, ~60MB, ~120MB] (3 chunks, aligned to newlines)
    """
    logger.debug(
        f'[OFFSETS] Calculating offsets for file_size_bytes={file_size_bytes} bytes ({file_size_bytes / (1024 * 1024):.2f} MB)'
    )

    # Calculate maximum possible number of chunks given MIN_CHUNK_SIZE
    max_chunks_by_size = file_size_bytes // MIN_CHUNK_SIZE
    logger.debug(f'[OFFSETS] max_chunks_by_size={max_chunks_by_size} (file_size_bytes // MIN_CHUNK_SIZE)')

    # Actual number of chunks is limited by both MIN_CHUNK_SIZE and MAX_SUBPROCESSES
    num_chunks = min(max_chunks_by_size, MAX_SUBPROCESSES)
    logger.debug(f'[OFFSETS] num_chunks after min with MAX_SUBPROCESSES={num_chunks}')

    # Ensure at least 1 chunk
    num_chunks = max(1, num_chunks)
    logger.debug(f'[OFFSETS] Final num_chunks={num_chunks}')

    # Calculate chunk size
    chunk_size = file_size_bytes // num_chunks
    logger.debug(f'[OFFSETS] chunk_size={chunk_size} bytes ({chunk_size / (1024 * 1024):.2f} MB)')

    # Generate initial offsets
    raw_offsets = [i * chunk_size for i in range(num_chunks)]
    logger.debug(f'[OFFSETS] Generated raw offsets: {raw_offsets}')

    # Adjust offsets to line boundaries (except first offset which is always 0)
    aligned_offsets = [0]
    for i in range(1, num_chunks):
        aligned_offset = find_next_newline(filename, raw_offsets[i])
        aligned_offsets.append(aligned_offset)
        logger.debug(f'[OFFSETS] Aligned offset[{i}]: {raw_offsets[i]} -> {aligned_offset} (line boundary)')

    logger.debug(f'[OFFSETS] Final line-aligned offsets: {aligned_offsets}')
    return aligned_offsets


def create_file_tasks(filename: str) -> list[FileTask]:
    file_size = os.path.getsize(filename)
    offsets = get_file_offsets(filename, file_size)

    tasks = []
    for i, offset in enumerate(offsets):
        if i == len(offsets) - 1:
            count = file_size - offset
        else:
            count = offsets[i + 1] - offset
        tasks.append(FileTask(task_id=i, filepath=filename, offset=offset, count=count))

    logger.debug(f'[TASKS] Created {len(tasks)} tasks for {filename}')
    return tasks


def _process_task_worker(
    task: FileTask, pattern_ids: dict[str, str], rg_extra_args: list | None = None
) -> tuple[FileTask, list[tuple[int, list[str]]], float]:
    """
    Worker function to process a single FileTask with multiple patterns.
    Runs dd | rg pipeline and returns byte offsets with matched pattern IDs.

    Args:
        task: FileTask to process
        pattern_ids: Dictionary mapping pattern_id -> pattern string
        rg_extra_args: Optional list of extra arguments to pass to ripgrep

    Returns:
        Tuple of (task, list_of_(offset, pattern_ids), execution_time)
    """
    if rg_extra_args is None:
        rg_extra_args = []

    start_time = time.time()
    thread_id = threading.current_thread().name

    # Track active workers
    prom.active_workers.inc()

    logger.debug(
        f'[WORKER {thread_id}] Starting task {task.task_id}: '
        f'file={task.filepath}, offset={task.offset}, count={task.count}'
    )

    try:
        # Calculate dd block parameters
        # We use 1MB blocks for dd to balance performance and memory
        bs = 1024 * 1024  # 1MB block size

        # Split task.offset into complete blocks and remainder bytes
        # Example: task.offset=75,000,000, bs=1,048,576
        #   skip_blocks = 71 (skip 71 complete MB blocks)
        #   skip_remainder = 552,448 bytes (the "extra" bytes into block 72)
        skip_blocks = task.offset // bs
        skip_remainder = task.offset % bs

        # dd actually starts reading at the last complete block boundary
        # This is BEFORE our desired task.offset by skip_remainder bytes
        # Example: actual_dd_offset = 71 * 1,048,576 = 74,448,896
        #   (which is 552,448 bytes before task.offset of 75,000,000)
        actual_dd_offset = skip_blocks * bs

        # Calculate how many blocks dd needs to read to ensure we get all task.count bytes
        # We add skip_remainder because dd starts before task.offset
        # We add (bs - 1) for ceiling division to ensure we read enough
        # Example: if task.count=20MB and skip_remainder=552,448:
        #   count_blocks = ceil((20MB + 552,448) / 1MB) = 21 blocks
        count_blocks = (task.count + skip_remainder + bs - 1) // bs

        logger.debug(f'[WORKER {thread_id}] Task {task.task_id}: dd bs={bs} skip={skip_blocks} count={count_blocks}')

        # Run dd | rg with --byte-offset and multiple -e patterns
        dd_proc = subprocess.Popen(
            ['dd', f'if={task.filepath}', f'bs={bs}', f'skip={skip_blocks}', f'count={count_blocks}', 'status=none'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        # Build ripgrep command with multiple -e patterns
        rg_cmd = ['rg', '--byte-offset', '--no-heading', '--only-matching', '--color=never']

        # Add all patterns with -e flag
        for pattern in pattern_ids.values():
            rg_cmd.extend(['-e', pattern])

        rg_cmd.extend(rg_extra_args)
        rg_cmd.append('-')  # Read from stdin

        # print(' '.join(rg_cmd))
        rg_proc = subprocess.Popen(
            rg_cmd,
            stdin=dd_proc.stdout,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        if dd_proc.stdout is not None:
            dd_proc.stdout.close()

        # Collect output and identify matching patterns
        # Store as list of (offset, [pattern_ids])
        offset_matches = []

        for line in rg_proc.stdout or []:
            line_str = line.decode('utf-8').strip()
            if not line_str:
                continue
            parts = line_str.split(':', 1)
            if not parts[0].isdigit():
                # ripgrep returns byte offset relative to its stdin (dd's output)
                # dd's output starts at actual_dd_offset in the file
                continue
            rg_byte_offset = int(parts[0])
            # print(line_str)
            # Convert to absolute position in the original file
            absolute_byte_offset = actual_dd_offset + rg_byte_offset

            # Critical: Only include matches that fall within THIS task's designated range
            # task.offset is where this task should start (inclusive)
            # task.offset + task.count is where this task should end (exclusive)
            # We read extra bytes (skip_remainder) at the start via dd, so we must filter them out
            # We also read extra bytes at the end (up to bs-1), so we must filter those too
            # This prevents duplicate matches across adjacent tasks
            if task.offset <= absolute_byte_offset < task.offset + task.count:
                # Since ripgrep already matched with all flags (including -i, -w, etc.),
                # we trust its output. For multi-pattern search, we can't reliably determine
                # which specific pattern matched when flags like -i are used, so we record
                # all patterns. This is acceptable since the user is searching for all these
                # patterns anyway.
                matching_pattern_ids = list(pattern_ids.keys())

                offset_matches.append((absolute_byte_offset, matching_pattern_ids))

        rg_proc.wait()
        dd_proc.wait()

        elapsed = time.time() - start_time

        logger.debug(
            f'[WORKER {thread_id}] Task {task.task_id} completed: found {len(offset_matches)} matches in {elapsed:.3f}s'
        )

        # Track task completion
        prom.worker_tasks_completed.inc()
        prom.active_workers.dec()

        return (task, offset_matches, elapsed)

    except Exception as e:
        elapsed = time.time() - start_time
        logger.error(f'[WORKER {thread_id}] Task {task.task_id} failed after {elapsed:.3f}s: {e}')

        # Track task failure
        prom.worker_tasks_failed.inc()
        prom.active_workers.dec()

        return (task, [], elapsed)


def parse_paths(
    paths: list[str], regexps: list[str], max_results: int | None = None, rg_extra_args: list | None = None
) -> dict:
    """
    Parse files or directories for multiple regex patterns using streaming worker pool.
    Returns ID-based structure for efficient response format.

    Args:
        paths: List of file or directory paths to search
        regexps: List of regular expression patterns to search for
        max_results: Optional maximum number of results to find before stopping (applies to all patterns combined)
        rg_extra_args: Optional list of extra arguments to pass to ripgrep

    Returns:
        Dictionary with ID-based structure:
        {
            'patterns': {'p1': 'error', 'p2': 'warning'},
            'files': {'f1': '/path/file.log', 'f2': '/other.log'},
            'matches': [
                {'pattern': 'p1', 'file': 'f1', 'offset': 100},
                {'pattern': 'p2', 'file': 'f1', 'offset': 200}
            ],
            'scanned_files': [...],
            'skipped_files': [...]
        }

    Raises:
        RuntimeError: If parsing fails
        FileNotFoundError: If path doesn't exist
    """
    if rg_extra_args is None:
        rg_extra_args = []

    pattern_ids = {f'p{i + 1}': pattern for i, pattern in enumerate(regexps)}
    logger.info(f'[PARSE] Processing {len(pattern_ids)} pattern(s) across {len(paths)} path(s)')

    # Collect all files to parse from all provided paths
    all_files_to_parse = []
    all_skipped_files = []
    all_scanned_dirs = []

    for path in paths:
        if not os.path.exists(path):
            raise FileNotFoundError(f'Path not found: {path}')

        if os.path.isdir(path):
            logger.info(f"[PARSE] Path '{path}' is directory, scanning for text files...")
            text_files, skipped_files = scan_directory_for_text_files(path)

            if text_files:
                all_files_to_parse.extend(text_files)
                all_scanned_dirs.append(path)
            all_skipped_files.extend(skipped_files)
            logger.info(f"[PARSE] Found {len(text_files)} text file(s) in '{path}'")
        else:
            # Single file - validate and add to list
            try:
                validate_file(path)
                all_files_to_parse.append(path)
                logger.info(f"[PARSE] Added file '{path}'")
            except ValueError as e:
                logger.warning(f"[PARSE] Skipping invalid file '{path}': {e}")
                all_skipped_files.append(path)

    if not all_files_to_parse:
        logger.warning('[PARSE] No valid files found across all paths')
        return {
            'patterns': pattern_ids,
            'files': {},
            'matches': [],
            'scanned_files': [],
            'skipped_files': all_skipped_files,
        }

    # Generate file IDs for all files
    file_ids = {f'f{i + 1}': filepath for i, filepath in enumerate(all_files_to_parse)}

    # Parse all files using unified multi-file approach
    logger.info(f'[PARSE] Parsing {len(all_files_to_parse)} file(s) with {len(pattern_ids)} pattern(s)')
    matches = _parse_multiple_files_multipattern(all_files_to_parse, pattern_ids, file_ids, max_results, rg_extra_args)

    return {
        'patterns': pattern_ids,
        'files': file_ids,
        'matches': matches,
        'scanned_files': all_files_to_parse if all_scanned_dirs else [],
        'skipped_files': all_skipped_files,
    }


def _parse_multiple_files_multipattern(
    filepaths: list[str],
    pattern_ids: dict[str, str],
    file_ids: dict[str, str],
    max_results: int | None = None,
    rg_extra_args: list | None = None,
) -> list[dict]:
    """
    Parse multiple files with multiple patterns and return matches in ID-based format.

    Args:
        filepaths: List of file paths
        pattern_ids: Dictionary mapping pattern_id -> pattern
        file_ids: Dictionary mapping file_id -> filepath
        max_results: Optional maximum number of results
        rg_extra_args: Optional list of extra arguments to pass to ripgrep

    Returns:
        List of match dicts: [{'pattern': 'p1', 'file': 'f1', 'offset': 100}, ...]
    """
    if rg_extra_args is None:
        rg_extra_args = []

    # Validate regex patterns
    for pattern in pattern_ids.values():
        test_proc = subprocess.run(['rg', '--', pattern], input=b'', capture_output=True, timeout=1)
        if test_proc.returncode == 2:
            error_msg = test_proc.stderr.decode('utf-8').strip()
            raise RuntimeError(f'Invalid regex pattern: {error_msg}')

    logger.info(f'[PARSE_MULTI_MULTI] Parsing {len(filepaths)} files with {len(pattern_ids)} patterns')

    # Create reverse mapping: filepath -> file_id
    filepath_to_id = {v: k for k, v in file_ids.items()}

    # Create tasks from all files
    all_tasks = []
    for filepath in filepaths:
        try:
            file_tasks = create_file_tasks(filepath)
            all_tasks.extend(file_tasks)
        except Exception as e:
            logger.warning(f'[PARSE_MULTI_MULTI] Skipping {filepath}: {e}')

    logger.info(f'[PARSE_MULTI_MULTI] Created {len(all_tasks)} tasks from {len(filepaths)} files')

    # Track parallel tasks created
    prom.parallel_tasks_created.observe(len(all_tasks))

    # Process all tasks
    matches = []
    total_time = 0.0

    with ThreadPoolExecutor(max_workers=MAX_SUBPROCESSES, thread_name_prefix='Worker') as executor:
        future_to_task = {
            executor.submit(_process_task_worker, task, pattern_ids, rg_extra_args): task for task in all_tasks
        }

        for future in as_completed(future_to_task):
            task = future_to_task[future]

            try:
                task_result, offset_pattern_list, elapsed = future.result()
                total_time += elapsed

                # Get file_id for this task's filepath
                file_id = filepath_to_id.get(task.filepath, 'f?')

                # Convert to match format
                for offset, pattern_id_list in offset_pattern_list:
                    for pattern_id in pattern_id_list:
                        matches.append({'pattern': pattern_id, 'file': file_id, 'offset': offset})

                logger.debug(
                    f'[PARSE_MULTI_MULTI] Task {task.task_id} ({task.filepath}) contributed {len(offset_pattern_list)} offsets'
                )

                # Check max_results
                if max_results and len(matches) >= max_results:
                    logger.info(f'[PARSE_MULTI_MULTI] Reached max_results={max_results}, cancelling remaining')
                    for f in future_to_task:
                        f.cancel()
                    break

            except Exception as e:
                logger.error(f'[PARSE_MULTI_MULTI] Task failed: {e}')

    # Sort by file, offset, then pattern
    matches.sort(key=lambda m: (m['file'], m['offset'], m['pattern']))

    if max_results and len(matches) > max_results:
        matches = matches[:max_results]

    logger.info(f'[PARSE_MULTI_MULTI] Completed: {len(matches)} matches, total worker time: {total_time:.3f}s')
    return matches


def parse_multiple_files(
    filepaths: list[str], regex: str, max_results: int | None = None, rg_extra_args: list = None
) -> list[dict]:
    """
    Parse multiple files for regex pattern using streaming worker pool.
    Creates tasks from all files and processes them in parallel.

    Args:
        filepaths: List of file paths to parse
        regex: Regular expression pattern to search for
        max_results: Optional maximum number of total results
        rg_extra_args: Optional list of extra arguments to pass to ripgrep

    Returns:
        List of dicts with 'filepath' and 'offset'
    """
    if rg_extra_args is None:
        rg_extra_args = []
    # Validate regex
    test_proc = subprocess.run(['rg', '--', regex], input=b'', capture_output=True, timeout=1)
    if test_proc.returncode == 2:
        error_msg = test_proc.stderr.decode('utf-8').strip()
        raise RuntimeError(f'Invalid regex pattern: {error_msg}')

    logger.info(f'[PARSE_MULTI] Parsing {len(filepaths)} files')

    # Create pattern_ids dict for single pattern
    pattern_ids = {'p1': regex}

    # Create tasks from all files
    all_tasks = []
    for filepath in filepaths:
        try:
            file_tasks = create_file_tasks(filepath)
            all_tasks.extend(file_tasks)
        except Exception as e:
            logger.warning(f'[PARSE_MULTI] Skipping {filepath}: {e}')

    logger.info(f'[PARSE_MULTI] Created {len(all_tasks)} tasks from {len(filepaths)} files')

    # Process all tasks in streaming pool
    matches = []
    total_time = 0.0

    with ThreadPoolExecutor(max_workers=MAX_SUBPROCESSES, thread_name_prefix='Worker') as executor:
        future_to_task = {
            executor.submit(_process_task_worker, task, pattern_ids, rg_extra_args): task for task in all_tasks
        }

        for future in as_completed(future_to_task):
            task = future_to_task[future]

            try:
                task_result, offset_pattern_list, elapsed = future.result()
                total_time += elapsed

                # Add matches with filepath (flatten pattern list since we only have one pattern)
                for offset, _ in offset_pattern_list:
                    matches.append({'filepath': task.filepath, 'offset': offset})

                logger.debug(
                    f'[PARSE_MULTI] Task {task.task_id} ({task.filepath}) contributed {len(offset_pattern_list)} matches'
                )

                # Check max_results
                if max_results and len(matches) >= max_results:
                    logger.info(f'[PARSE_MULTI] Reached max_results={max_results}, cancelling remaining')
                    for f in future_to_task:
                        f.cancel()
                    break

            except Exception as e:
                logger.error(f'[PARSE_MULTI] Task failed: {e}')

    # Sort by filepath, then offset
    matches.sort(key=lambda m: (m['filepath'], m['offset']))

    if max_results and len(matches) > max_results:
        matches = matches[:max_results]

    logger.info(f'[PARSE_MULTI] Completed: {len(matches)} matches, total worker time: {total_time:.3f}s')
    return matches


# TODO: make it more efficient without invoking dd, just opening file in 'rb' and seek + read it many times.
def get_context(
    filename: str, offsets: list[int], before_context: int = 3, after_context: int = 3
) -> dict[int, list[str]]:
    """
    Get lines of context around specified byte offsets in a file.

    Args:
        filename: Path to the file
        offsets: List of byte offsets to get context for
        before_context: Number of lines before each offset (default: 3)
        after_context: Number of lines after each offset (default: 3)

    Returns:
        Dictionary mapping each offset to list of context lines

    Raises:
        ValueError: If file doesn't exist or parameters are invalid
    """
    if not os.path.exists(filename):
        raise ValueError(f'File not found: {filename}')

    if before_context < 0 or after_context < 0:
        raise ValueError('Context values must be non-negative')

    file_size = os.path.getsize(filename)
    result: dict[int, list[str]] = {}

    max_line_length = LINE_SIZE_ASSUMPTION_KB * 1024

    for offset in offsets:
        if offset < 0 or offset >= file_size:
            result[offset] = []
            continue

        # Calculate how much to read before and after the offset
        # We need enough bytes to capture the requested lines
        bytes_before = max_line_length * (before_context + 1)  # +1 for the line containing offset
        bytes_after = max_line_length * (after_context + 1)

        # Calculate read range
        start_pos = max(0, offset - bytes_before)
        end_pos = min(file_size, offset + bytes_after)
        read_size = end_pos - start_pos

        # Read the chunk using dd
        bs = 1024 * 1024  # 1MB block size
        skip_blocks = start_pos // bs
        skip_remainder = start_pos % bs
        count_blocks = (read_size + skip_remainder + bs - 1) // bs

        dd_proc = subprocess.Popen(
            ['dd', f'if={filename}', f'bs={bs}', f'skip={skip_blocks}', f'count={count_blocks}', 'status=none'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        chunk_data, _ = dd_proc.communicate()
        dd_proc.wait()

        # Adjust for remainder bytes we read extra
        chunk_data = chunk_data[skip_remainder : skip_remainder + read_size]

        # Split into lines using \n only (consistent with how we count lines in index)
        # Don't use splitlines() as it treats \r as a line separator too
        text = chunk_data.decode('utf-8', errors='replace')
        lines = text.split('\n')
        # Re-add the \n to each line except the last (to match keepends=True behavior)
        lines = [line + '\n' for line in lines[:-1]] + [lines[-1]] if lines else []

        # Find which line contains our offset
        current_pos = start_pos
        target_line_idx = None

        for idx, line in enumerate(lines):
            line_start = current_pos
            line_end = current_pos + len(line.encode('utf-8'))

            if line_start <= offset < line_end:
                target_line_idx = idx
                break

            current_pos = line_end

        if target_line_idx is None:
            # Offset not found in expected range
            result[offset] = []
            continue

        # Extract context lines
        start_idx = max(0, target_line_idx - before_context)
        end_idx = min(len(lines), target_line_idx + after_context + 1)

        # Strip the configured newline symbol and also \r as fallback
        context_lines = [line.rstrip(NEWLINE_SYMBOL + '\r') for line in lines[start_idx:end_idx]]
        result[offset] = context_lines

    return result


def get_context_by_lines(
    filename: str,
    line_numbers: list[int],
    before_context: int = 3,
    after_context: int = 3,
    use_index: bool = True,
) -> dict[int, list[str]]:
    """
    Get lines of context around specified line numbers in a file.

    For large files (above threshold), uses or creates an index for efficient access.
    For small files, reads the entire file.

    Args:
        filename: Path to the file
        line_numbers: List of 1-based line numbers to get context for
        before_context: Number of lines before each target line (default: 3)
        after_context: Number of lines after each target line (default: 3)
        use_index: Whether to use/create index for large files (default: True)

    Returns:
        Dictionary mapping each line number to list of context lines

    Raises:
        ValueError: If file doesn't exist or parameters are invalid
    """
    from rx.index import (
        create_index_file,
        find_line_offset,
        get_index_path,
        get_large_file_threshold_bytes,
        is_index_valid,
        load_index,
    )

    if not os.path.exists(filename):
        raise ValueError(f'File not found: {filename}')

    if before_context < 0 or after_context < 0:
        raise ValueError('Context values must be non-negative')

    file_size = os.path.getsize(filename)
    threshold = get_large_file_threshold_bytes()
    result: dict[int, list[str]] = {}

    # For small files, just read the entire file
    if file_size < threshold or not use_index:
        return _get_context_by_lines_simple(filename, line_numbers, before_context, after_context)

    # For large files, use index
    index_path = get_index_path(filename)
    if is_index_valid(filename):
        file_index = load_index(index_path)
    else:
        # Create index if it doesn't exist
        logger.info(f'Creating index for large file: {filename}')
        file_index = create_index_file(filename)

    if file_index is None:
        # Fall back to simple method if index creation failed
        logger.warning(f'Index unavailable for {filename}, falling back to simple method')
        return _get_context_by_lines_simple(filename, line_numbers, before_context, after_context)

    line_index = file_index.line_index if file_index.line_index else [[1, 0]]
    total_lines = file_index.analysis.line_count if file_index.analysis else 0

    max_line_length = LINE_SIZE_ASSUMPTION_KB * 1024

    for target_line in line_numbers:
        # Validate line number is within file bounds
        if target_line < 1 or (total_lines > 0 and target_line > total_lines):
            raise ValueError(f'Line {target_line} is out of bounds. File has {total_lines} lines (EOF reached).')

        # Find the closest indexed position before our target
        start_line_needed = max(1, target_line - before_context)
        indexed_line, indexed_offset = find_line_offset(line_index, start_line_needed)

        # Calculate how many lines we need to skip from the indexed position
        lines_to_skip = start_line_needed - indexed_line

        # Calculate how many lines total we need to read
        lines_to_read = before_context + 1 + after_context + lines_to_skip

        # Use average line length from analysis if available, with safety margin
        avg_line_length = file_index.analysis.line_length_avg if file_index.analysis else 100

        # Use a reasonable multiplier on average (4x) rather than adding max line length
        # This handles normal variability without exploding memory for files with outlier long lines
        # We'll read in chunks and expand if needed
        estimated_line_size = int(avg_line_length * 4) + 100  # 4x average + 100 byte buffer
        initial_bytes_to_read = lines_to_read * estimated_line_size

        # Cap initial read to 10MB to avoid memory issues, we can read more if needed
        MAX_INITIAL_READ = 10 * 1024 * 1024
        bytes_to_read = min(initial_bytes_to_read, MAX_INITIAL_READ)

        # Read the chunk, expanding if we don't get enough lines
        lines = []
        total_bytes_read = 0
        MAX_TOTAL_READ = 100 * 1024 * 1024  # Cap at 100MB total to prevent OOM
        remainder = b''  # Track incomplete line from previous read (as bytes)

        try:
            with open(filename, 'rb') as f:
                f.seek(indexed_offset)

                while True:
                    chunk = f.read(bytes_to_read)
                    if not chunk:
                        # EOF - add remainder as last line if not empty
                        if remainder:
                            lines.append(remainder.decode('utf-8', errors='replace'))
                        break

                    total_bytes_read += len(chunk)

                    # Prepend any remainder from previous iteration
                    data = remainder + chunk
                    remainder = b''

                    # Find all complete lines (ending with \n)
                    last_newline = data.rfind(b'\n')
                    if last_newline >= 0:
                        # Split complete lines from remainder
                        complete_data = data[: last_newline + 1]
                        remainder = data[last_newline + 1 :]

                        # Decode and split into lines
                        decoded = complete_data.decode('utf-8', errors='replace')
                        for line in decoded.split('\n')[:-1]:  # Last element is empty after trailing \n
                            lines.append(line + '\n')
                    else:
                        # No complete lines yet, keep accumulating
                        remainder = data

                    # Check if we have enough lines
                    lines_needed = target_line - indexed_line + after_context + 1
                    if len(lines) >= lines_needed:
                        break

                    # Check if we've read too much
                    if total_bytes_read >= MAX_TOTAL_READ:
                        logger.warning(f'Reached max read limit ({MAX_TOTAL_READ} bytes) for line {target_line}')
                        # Add remainder as incomplete line
                        if remainder:
                            lines.append(remainder.decode('utf-8', errors='replace'))
                        break

                    # Read more - double the chunk size for efficiency
                    bytes_to_read = min(bytes_to_read * 2, MAX_TOTAL_READ - total_bytes_read)
                    if bytes_to_read <= 0:
                        break

        except OSError as e:
            logger.error(f'Failed to read file {filename}: {e}')
            result[target_line] = []
            continue

        # Calculate the target line's position within our read chunk
        # target_line is absolute, indexed_line is where we started reading
        lines_from_indexed = len(lines)
        target_offset_in_chunk = target_line - indexed_line

        # Check if we read enough lines to include our target + context
        if target_offset_in_chunk < lines_from_indexed:
            # Calculate context window
            start_idx = max(0, target_offset_in_chunk - before_context)
            end_idx = min(lines_from_indexed, target_offset_in_chunk + after_context + 1)

            context_lines = [line.rstrip(NEWLINE_SYMBOL + '\r') for line in lines[start_idx:end_idx]]
            result[target_line] = context_lines
        else:
            # Didn't read enough lines
            logger.warning(
                f"Didn't read enough lines for line {target_line}, read {lines_from_indexed}, needed {target_offset_in_chunk + after_context + 1})"
            )
            result[target_line] = []

    return result


def _get_context_by_lines_simple(
    filename: str,
    line_numbers: list[int],
    before_context: int,
    after_context: int,
) -> dict[int, list[str]]:
    """
    Simple implementation that reads the file line by line.
    Used for small files or when index is unavailable.
    """
    result: dict[int, list[str]] = {}

    # Read all lines using binary mode to match wc -l behavior
    # Split on \n only, not on \r (which text mode would do)
    try:
        with open(filename, 'rb') as f:
            content = f.read()

        # Decode and split on \n only
        decoded = content.decode('utf-8', errors='replace')
        if '\n' in decoded:
            parts = decoded.split('\n')
            all_lines = [parts[i] + '\n' for i in range(len(parts) - 1)]
            if parts[-1]:
                all_lines.append(parts[-1])
        else:
            all_lines = [decoded] if decoded else []
    except OSError as e:
        logger.error(f'Failed to read file {filename}: {e}')
        for line_num in line_numbers:
            result[line_num] = []
        return result

    total_lines = len(all_lines)

    for target_line in line_numbers:
        # Validate line number is within file bounds
        if target_line < 1 or target_line > total_lines:
            raise ValueError(f'Line {target_line} is out of bounds. File has {total_lines} lines (EOF reached).')

        # Convert to 0-based index
        target_idx = target_line - 1

        start_idx = max(0, target_idx - before_context)
        end_idx = min(total_lines, target_idx + after_context + 1)

        context_lines = [line.rstrip(NEWLINE_SYMBOL + '\r') for line in all_lines[start_idx:end_idx]]
        result[target_line] = context_lines

    return result


def get_context_from_seekable_zstd(
    filepath: str,
    line_numbers: list[int],
    before_context: int = 3,
    after_context: int = 3,
) -> dict[int, list[str]]:
    """
    Get lines of context around specified line numbers from a seekable zstd file.

    This function efficiently retrieves context by:
    1. Looking up which frames contain the requested lines
    2. Decompressing only the necessary frames
    3. Extracting the requested lines with context

    Args:
        filepath: Path to the seekable zstd file
        line_numbers: List of 1-based line numbers to get context for
        before_context: Number of lines before each target line (default: 3)
        after_context: Number of lines after each target line (default: 3)

    Returns:
        Dictionary mapping each line number to list of context lines

    Raises:
        ValueError: If file is not a seekable zstd or parameters are invalid
    """
    if not is_seekable_zstd(filepath):
        raise ValueError(f'Not a seekable zstd file: {filepath}')

    if before_context < 0 or after_context < 0:
        raise ValueError('Context values must be non-negative')

    # Get or build the index
    index = get_or_build_index(filepath)

    result: dict[int, list[str]] = {}

    # Group requested lines by frame to minimize decompression
    from collections import defaultdict

    lines_by_frame: dict[int, list[int]] = defaultdict(list)

    for line_num in line_numbers:
        if line_num < 1 or line_num > index.total_lines:
            raise ValueError(f'Line {line_num} is out of bounds. File has {index.total_lines} lines (EOF reached).')

        # Find which frame contains this line
        frame_idx = find_frame_for_line(index, line_num)
        lines_by_frame[frame_idx].append(line_num)

    # Also include frames needed for context lines
    # This is an optimization - we might need adjacent frames for context
    expanded_frames: set[int] = set()
    for frame_idx, target_lines in lines_by_frame.items():
        expanded_frames.add(frame_idx)

        # Check if we need previous frame for before_context
        if before_context > 0:
            for line_num in target_lines:
                start_line = max(1, line_num - before_context)
                if start_line < index.frames[frame_idx].first_line and frame_idx > 0:
                    expanded_frames.add(frame_idx - 1)

        # Check if we need next frame for after_context
        if after_context > 0:
            for line_num in target_lines:
                end_line = line_num + after_context
                if end_line > index.frames[frame_idx].last_line and frame_idx < index.frame_count - 1:
                    expanded_frames.add(frame_idx + 1)

    # Decompress needed frames and cache their lines
    frame_lines_cache: dict[int, list[str]] = {}

    for frame_idx in sorted(expanded_frames):
        try:
            frame_data = decompress_frame(filepath, frame_idx)
            decoded = frame_data.decode('utf-8', errors='replace')

            # Split on \n only
            if '\n' in decoded:
                parts = decoded.split('\n')
                lines = [parts[i] + '\n' for i in range(len(parts) - 1)]
                if parts[-1]:
                    lines.append(parts[-1])
            else:
                lines = [decoded] if decoded else []

            frame_lines_cache[frame_idx] = lines

            logger.debug(f'[SEEKABLE_CONTEXT] Decompressed frame {frame_idx}: {len(lines)} lines')

        except Exception as e:
            logger.error(f'[SEEKABLE_CONTEXT] Failed to decompress frame {frame_idx}: {e}')
            frame_lines_cache[frame_idx] = []

    # Now extract context for each requested line
    for line_num in line_numbers:
        if line_num < 1 or line_num > index.total_lines:
            continue  # Already set to empty above

        try:
            # Find frame containing this line
            frame_idx = find_frame_for_line(index, line_num)
            frame_info = index.frames[frame_idx]

            # Calculate context window
            start_line = max(1, line_num - before_context)
            end_line = min(index.total_lines, line_num + after_context)

            context_lines = []

            # Iterate through lines in the context window
            current_line = start_line
            while current_line <= end_line:
                # Find which frame contains this line
                ctx_frame_idx = find_frame_for_line(index, current_line)
                ctx_frame_info = index.frames[ctx_frame_idx]

                if ctx_frame_idx not in frame_lines_cache:
                    # Frame not cached (shouldn't happen with expanded_frames logic)
                    current_line += 1
                    continue

                frame_lines = frame_lines_cache[ctx_frame_idx]

                # Calculate index within the frame
                line_in_frame = current_line - ctx_frame_info.first_line

                if 0 <= line_in_frame < len(frame_lines):
                    line_text = frame_lines[line_in_frame].rstrip(NEWLINE_SYMBOL + '\r')
                    context_lines.append(line_text)

                current_line += 1

            result[line_num] = context_lines

        except Exception as e:
            logger.error(f'[SEEKABLE_CONTEXT] Failed to get context for line {line_num}: {e}')
            result[line_num] = []

    return result
