from img.generate import CoverGenerator as CoverGenerator
