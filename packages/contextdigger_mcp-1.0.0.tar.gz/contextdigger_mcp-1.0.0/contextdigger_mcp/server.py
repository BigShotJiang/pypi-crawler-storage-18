"""
Lightweight MCP Server for ContextDigger

Communicates with locally installed contextdigger CLI via subprocess.
Exposes all 50+ CLI commands as MCP tools for AI assistants.
"""

import sys
import json
import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field


# ============================================================================
# MCP Tool Definitions (50+ tools matching CLI commands)
# ============================================================================

MCP_TOOLS = [
    # Core Navigation (7 tools)
    {
        "name": "init_project",
        "description": "Initialize ContextDigger in the project",
        "cli_command": ["init"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "dig_area",
        "description": "Set focus to an area and return governed context",
        "cli_command": ["dig"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier"},
            },
            "required": ["area_id"],
        },
    },
    {
        "name": "list_areas",
        "description": "List all discovered code areas",
        "cli_command": ["list"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "navigate_back",
        "description": "Navigate to previous area in history",
        "cli_command": ["back"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "navigate_forward",
        "description": "Navigate to next area in history",
        "cli_command": ["forward"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_history",
        "description": "Show navigation history",
        "cli_command": ["history"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_status",
        "description": "Show current session status",
        "cli_command": ["status"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Bookmarks (4 tools)
    {
        "name": "create_bookmark",
        "description": "Save current location as bookmark",
        "cli_command": ["mark-spot"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Bookmark name"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "goto_bookmark",
        "description": "Jump to bookmarked area",
        "cli_command": ["goto-spot"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Bookmark name"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "list_bookmarks",
        "description": "List all bookmarks",
        "cli_command": ["list-spots"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "delete_bookmark",
        "description": "Delete a bookmark",
        "cli_command": ["delete-spot"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Bookmark name"},
            },
            "required": ["name"],
        },
    },

    # Context Snapshots (4 tools)
    {
        "name": "save_context",
        "description": "Save current context snapshot",
        "cli_command": ["save-context"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Snapshot name"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "load_context",
        "description": "Load context snapshot",
        "cli_command": ["load-context"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Snapshot name"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "list_contexts",
        "description": "List all saved context snapshots",
        "cli_command": ["list-contexts"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "delete_context",
        "description": "Delete context snapshot",
        "cli_command": ["delete-context"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Snapshot name"},
            },
            "required": ["name"],
        },
    },

    # Notes & Documentation (3 tools)
    {
        "name": "add_note",
        "description": "Add note to current area",
        "cli_command": ["note"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Note content"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "show_notes",
        "description": "View notes for area",
        "cli_command": ["notes"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier (optional)"},
            },
        },
    },
    {
        "name": "generate_wiki",
        "description": "Generate wiki documentation",
        "cli_command": ["wiki"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Analysis & Intelligence (12 tools)
    {
        "name": "show_insights",
        "description": "Generate intelligent insights from usage patterns",
        "cli_command": ["insights"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "suggest_areas",
        "description": "Get AI suggestions for areas to explore",
        "cli_command": ["suggest"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_dependencies",
        "description": "Show dependencies for area",
        "cli_command": ["deps"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier (optional)"},
            },
        },
    },
    {
        "name": "analyze_impact",
        "description": "Analyze impact of changes in area",
        "cli_command": ["impact"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier"},
            },
            "required": ["area_id"],
        },
    },
    {
        "name": "show_map",
        "description": "Generate codebase map",
        "cli_command": ["map"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "find_hotspots",
        "description": "Find frequently changed code hotspots",
        "cli_command": ["hotspots"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "find_gaps",
        "description": "Find coverage gaps",
        "cli_command": ["gaps"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "analyze_performance",
        "description": "Run performance analysis",
        "cli_command": ["perf"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier (optional)"},
            },
        },
    },
    {
        "name": "run_benchmark",
        "description": "Run performance benchmarks",
        "cli_command": ["benchmark"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_trends",
        "description": "Analyze historical trends",
        "cli_command": ["trends"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_predictions",
        "description": "Generate predictive insights based on trends",
        "cli_command": ["predictions"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_remediation",
        "description": "Get automated remediation suggestions",
        "cli_command": ["remediate"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "use_llm": {"type": "boolean", "description": "Use AI enhancement (requires Ollama)"},
            },
        },
    },

    # Search & Query (2 tools)
    {
        "name": "search_all",
        "description": "Search across all areas",
        "cli_command": ["search"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "run_query",
        "description": "Run custom query on codebase data",
        "cli_command": ["query"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Custom query"},
            },
            "required": ["query"],
        },
    },

    # Automation (2 tools)
    {
        "name": "show_automation",
        "description": "Show automation suggestions",
        "cli_command": ["auto"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "list_rules",
        "description": "List automation rules",
        "cli_command": ["rules"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Reports & Export (8 tools)
    {
        "name": "show_analytics",
        "description": "View work analytics",
        "cli_command": ["analytics"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "generate_report",
        "description": "Generate comprehensive report",
        "cli_command": ["report"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "output_file": {"type": "string", "description": "Output file path (optional)"},
            },
        },
    },
    {
        "name": "export_context",
        "description": "Export area context to file",
        "cli_command": ["export"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": ["markdown", "json", "xml", "ai", "claude", "cursor"],
                    "description": "Export format",
                },
            },
            "required": ["format"],
        },
    },
    {
        "name": "create_backup",
        "description": "Create backup of .cdg/ directory",
        "cli_command": ["backup"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_provenance",
        "description": "Show file provenance (why files were loaded)",
        "cli_command": ["provenance"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_dashboard",
        "description": "Show comprehensive dashboard",
        "cli_command": ["dashboard"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "check_health",
        "description": "Run health check",
        "cli_command": ["health"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_stats",
        "description": "Show statistics",
        "cli_command": ["stats"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Team Features (2 tools)
    {
        "name": "show_team_activity",
        "description": "Show team activity",
        "cli_command": ["team"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "show_test_coverage",
        "description": "Show test coverage",
        "cli_command": ["tests"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Sub-Area Management (2 tools)
    {
        "name": "split_area",
        "description": "Split oversized area into sub-areas",
        "cli_command": ["split"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "area_id": {"type": "string", "description": "Area identifier"},
                "strategy": {
                    "type": "string",
                    "enum": ["by-subdirectory", "by-file-type", "by-dependencies", "auto"],
                    "description": "Splitting strategy (optional)",
                },
            },
            "required": ["area_id"],
        },
    },
    {
        "name": "create_subarea",
        "description": "Manually create sub-area",
        "cli_command": ["create-subarea"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "parent_id": {"type": "string", "description": "Parent area identifier"},
                "name": {"type": "string", "description": "Sub-area name"},
                "pattern": {"type": "string", "description": "File pattern"},
            },
            "required": ["parent_id", "name", "pattern"],
        },
    },

    # Budget & Governance (3 tools)
    {
        "name": "check_budget",
        "description": "Check budget compliance against governance policy",
        "cli_command": ["policy"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "manage_policy",
        "description": "Manage budget policies",
        "cli_command": ["policy"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "max_files": {"type": "integer", "description": "Maximum files (optional)"},
                "max_lines": {"type": "integer", "description": "Maximum lines (optional)"},
            },
        },
    },
    {
        "name": "show_audit",
        "description": "Show audit trail",
        "cli_command": ["audit"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },

    # Continuation Contracts (3 tools)
    {
        "name": "continue_work",
        "description": "Resume the active continuation contract",
        "cli_command": ["continue"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "pause_work",
        "description": "Pause current work and save continuation contract",
        "cli_command": ["pause"],
        "inputSchema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "list_contracts",
        "description": "List all work sessions (active and paused)",
        "cli_command": ["contracts"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Number of contracts (default: 10)"},
            },
        },
    },

    # LLM Integration (1 tool)
    {
        "name": "manage_llm",
        "description": "Manage LLM integration (status/enable/disable)",
        "cli_command": ["llm"],
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["status", "enable", "disable"],
                    "description": "LLM action",
                },
            },
            "required": ["action"],
        },
    },
]


# ============================================================================
# MCP Server Implementation
# ============================================================================


class ContextDiggerMCPServer:
    """
    Lightweight MCP server that communicates with contextdigger CLI.

    Exposes all 50+ CLI commands as MCP tools for AI assistants.
    """

    def __init__(self, cli_path: str = "contextdigger"):
        """
        Initialize MCP server.

        Args:
            cli_path: Path to contextdigger CLI executable (default: "contextdigger")
        """
        self.cli_path = cli_path
        self.tools = {tool["name"]: tool for tool in MCP_TOOLS}

    def list_tools(self) -> List[Dict[str, Any]]:
        """List all available MCP tools."""
        return [
            {
                "name": tool["name"],
                "description": tool["description"],
                "inputSchema": tool["inputSchema"],
            }
            for tool in MCP_TOOLS
        ]

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool by calling contextdigger CLI.

        Args:
            tool_name: Name of tool to execute
            arguments: Tool arguments

        Returns:
            Tool result with success status and data
        """
        if tool_name not in self.tools:
            return {
                "success": False,
                "error": f"Unknown tool: {tool_name}",
                "data": None,
            }

        tool = self.tools[tool_name]
        cli_command = [self.cli_path] + tool["cli_command"]

        # Build CLI arguments from tool arguments
        for key, value in arguments.items():
            if isinstance(value, bool):
                if value:
                    cli_command.append(f"--{key}")
            elif value is not None:
                # For positional arguments
                if key in ["area_id", "name", "query", "text", "format", "parent_id", "pattern", "action"]:
                    cli_command.append(str(value))
                else:
                    cli_command.extend([f"--{key}", str(value)])

        # Execute CLI command
        try:
            result = subprocess.run(
                cli_command,
                capture_output=True,
                text=True,
                timeout=60,  # 60 second timeout
            )

            if result.returncode == 0:
                return {
                    "success": True,
                    "data": {
                        "output": result.stdout,
                        "command": " ".join(cli_command),
                    },
                    "error": None,
                }
            else:
                return {
                    "success": False,
                    "error": result.stderr or f"Command failed with exit code {result.returncode}",
                    "data": {"output": result.stdout},
                }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Command timeout (exceeded 60 seconds)",
                "data": None,
            }
        except FileNotFoundError:
            return {
                "success": False,
                "error": f"contextdigger CLI not found at: {self.cli_path}. Please install: pip install contextdigger",
                "data": None,
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "data": None,
            }


# ============================================================================
# JSON-RPC Protocol Handler
# ============================================================================


class MCPProtocolHandler:
    """Handles JSON-RPC protocol for MCP server."""

    def __init__(self, server: ContextDiggerMCPServer):
        """Initialize protocol handler."""
        self.server = server
        self.stdin = sys.stdin
        self.stdout = sys.stdout

    def run(self):
        """Run the JSON-RPC message loop."""
        import logging
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            stream=sys.stderr,
        )
        logger = logging.getLogger(__name__)
        logger.info("ContextDigger MCP Server started")

        try:
            for line in self.stdin:
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    response = self.handle_request(request)

                    if response:
                        self.stdout.write(json.dumps(response) + "\n")
                        self.stdout.flush()

                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON: {e}")
                    error_response = self._error_response(None, -32700, "Parse error")
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

                except Exception as e:
                    logger.error(f"Error handling request: {e}", exc_info=True)
                    error_response = self._error_response(None, -32603, f"Internal error: {str(e)}")
                    self.stdout.write(json.dumps(error_response) + "\n")
                    self.stdout.flush()

        except KeyboardInterrupt:
            logger.info("Server shutdown requested")
        except Exception as e:
            logger.error(f"Fatal error: {e}", exc_info=True)

    def handle_request(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle a JSON-RPC request."""
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")

        try:
            if method == "initialize":
                result = self._handle_initialize(params)
            elif method == "tools/list":
                result = self._handle_list_tools()
            elif method == "tools/call":
                result = self._handle_call_tool(params)
            elif method == "ping":
                result = {"status": "ok"}
            else:
                return self._error_response(request_id, -32601, f"Method not found: {method}")

            if request_id is not None:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result,
                }

            return None

        except Exception as e:
            return self._error_response(request_id, -32603, f"Internal error: {str(e)}")

    def _handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle initialize request."""
        return {
            "protocolVersion": "1.0",
            "serverInfo": {
                "name": "contextdigger-mcp",
                "version": "1.0.0",
            },
            "capabilities": {
                "tools": {},
            },
        }

    def _handle_list_tools(self) -> Dict[str, Any]:
        """Handle tools/list request."""
        return {"tools": self.server.list_tools()}

    def _handle_call_tool(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle tools/call request."""
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        if not tool_name:
            raise ValueError("Missing required parameter: name")

        result = self.server.execute_tool(tool_name, arguments)

        if result["success"]:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": result["data"]["output"] if result["data"] else "Success",
                    }
                ],
                "isError": False,
            }
        else:
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"Error: {result['error']}",
                    }
                ],
                "isError": True,
            }

    def _error_response(self, request_id: Any, code: int, message: str) -> Dict[str, Any]:
        """Create JSON-RPC error response."""
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            },
        }


# ============================================================================
# Entry Point
# ============================================================================


def main():
    """Run MCP server in stdio mode."""
    import logging

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        stream=sys.stderr,
    )

    logger = logging.getLogger(__name__)
    logger.info("Starting ContextDigger MCP Server (Lightweight CLI-based)")

    # Check if contextdigger CLI is installed
    try:
        result = subprocess.run(
            ["contextdigger", "--version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            logger.info(f"Using contextdigger CLI: {result.stdout.strip()}")
        else:
            logger.error("contextdigger CLI not working properly")
            logger.error("Please install: pip install contextdigger")
            sys.exit(1)
    except FileNotFoundError:
        logger.error("contextdigger CLI not found")
        logger.error("Please install: pip install contextdigger")
        sys.exit(1)

    # Initialize server
    server = ContextDiggerMCPServer()
    logger.info(f"Available tools: {len(server.list_tools())}")

    # Run protocol handler
    handler = MCPProtocolHandler(server)
    logger.info("Server ready - waiting for requests...")
    handler.run()

    logger.info("Server shutdown complete")


if __name__ == "__main__":
    main()
