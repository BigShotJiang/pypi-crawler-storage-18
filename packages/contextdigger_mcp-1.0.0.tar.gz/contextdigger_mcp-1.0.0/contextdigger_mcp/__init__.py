"""
ContextDigger MCP Server - Lightweight standalone package

A lightweight Model Context Protocol (MCP) server for ContextDigger that
communicates with the locally installed contextdigger CLI.

This package provides AI tools (Claude Desktop, Cursor, etc.) with access
to ContextDigger's 50+ commands via the MCP protocol.

Architecture:
- Lightweight: Only MCP protocol handling, no service layer duplication
- CLI-based: Calls local `contextdigger` CLI commands via subprocess
- Requires: contextdigger package to be installed separately
- Works with: Any version of contextdigger CLI

Install:
    pip install contextdigger          # Install CLI first
    pip install contextdigger-mcp      # Install MCP server
"""

__version__ = "1.0.0"

from .server import ContextDiggerMCPServer, main

__all__ = ["ContextDiggerMCPServer", "main"]
