import pytest
import numpy as np
from regression_inference import *


models = [
    LinearRegression(),
    LogisticRegression(),
    MultinomialLogisticRegression(),
    OrdinalLogisticRegression(),
]

model_names = [
    "LinearRegression",
    "LogisticRegression",
    "MultinomialLogisticRegression",
    "OrdinalLogisticRegression",
]

@pytest.mark.parametrize("model", models, ids=model_names)

def test_emptyInstance(model):

    for name, value in vars(model).items():

        assert not value, (
            f"{model.__class__.__name__}.{name} "
            f"expected to be empty, got {value!r}"
        )
