"""Main CLI application for cfdfig."""

from pathlib import Path
from typing import Optional, List
import typer
from rich.console import Console
from rich.table import Table
from rich import print as rprint

from .case import Case
from .run import Run
from .config import CaseConfig
from .utils import find_case_root, parse_openfoam_residuals
from .plotting import plot_residuals, compare_residuals, plot_forces

app = typer.Typer(
    name="cfdfig",
    help="Production-grade CLI for CFD visualization and case tracking",
    add_completion=False
)
console = Console()


@app.command()
def init(
    case_name: str = typer.Argument(..., help="Name of the CFD case"),
    path: Optional[Path] = typer.Option(
        None, "--path", "-p", help="Directory to create case in (default: current directory)"
    ),
    description: str = typer.Option("", "--description", "-d", help="Case description"),
):
    """
    Initialize a new CFD case with directory structure and metadata.
    
    Creates:
    - cfdfig.yaml (case metadata)
    - outputs/ (for solver logs and data)
    - figures/ (for generated plots)
    - README.md
    """
    case_path = path or Path.cwd() / case_name
    
    if case_path.exists() and (case_path / "cfdfig.yaml").exists():
        rprint(f"[red]Error: Case already exists at {case_path}[/red]")
        raise typer.Exit(1)
    
    case = Case.create(case_path, case_name, description)
    
    rprint(f"[green]✓[/green] Initialized CFD case: [bold]{case_name}[/bold]")
    rprint(f"  Location: {case_path}")
    rprint(f"\n[dim]Next steps:[/dim]")
    rprint(f"  1. Place solver output files in [cyan]outputs/[/cyan]")
    rprint(f"  2. Add a run: [cyan]cfdfig add-run[/cyan]")
    rprint(f"  3. Generate plots: [cyan]cfdfig plot residuals[/cyan]")


@app.command()
def add_run(
    run_id: str = typer.Option(..., "--id", help="Unique run identifier"),
    solver: str = typer.Option(..., "--solver", help="Solver name (e.g., simpleFoam)"),
    turbulence: str = typer.Option(..., "--turbulence", "-t", help="Turbulence model (e.g., kOmegaSST)"),
    mesh: str = typer.Option(..., "--mesh", "-m", help="Mesh version/identifier"),
    cells: Optional[int] = typer.Option(None, "--cells", help="Number of mesh cells"),
    numerics: Optional[str] = typer.Option(None, "--numerics", help="Numerical schemes info"),
    notes: Optional[str] = typer.Option(None, "--notes", help="Additional notes"),
):
    """
    Register a new CFD run with metadata.
    
    Records solver, turbulence model, mesh information, and other parameters
    to cfdfig.yaml for reproducibility.
    """
    try:
        case_root = find_case_root()
        case = Case(case_root)
        
        # Check if run ID already exists
        if case.get_run(run_id):
            rprint(f"[red]Error: Run '{run_id}' already exists[/red]")
            raise typer.Exit(1)
        
        case.add_run(
            run_id=run_id,
            solver=solver,
            turbulence_model=turbulence,
            mesh_version=mesh,
            mesh_cells=cells,
            numerics=numerics,
            notes=notes
        )
        
        rprint(f"[green]✓[/green] Added run: [bold]{run_id}[/bold]")
        rprint(f"  Solver: {solver}")
        rprint(f"  Turbulence: {turbulence}")
        rprint(f"  Mesh: {mesh}")
        if cells:
            rprint(f"  Cells: {cells:,}")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def list_runs():
    """
    List all runs in the current case.
    """
    try:
        case_root = find_case_root()
        config = CaseConfig(case_root / "cfdfig.yaml")
        runs = config.list_runs()
        
        if not runs:
            rprint("[yellow]No runs found in this case[/yellow]")
            return
        
        table = Table(title=f"CFD Case: {config.case_name}")
        table.add_column("Run ID", style="cyan", no_wrap=True)
        table.add_column("Solver", style="green")
        table.add_column("Turbulence Model", style="blue")
        table.add_column("Mesh", style="magenta")
        table.add_column("Cells", justify="right")
        
        for run in runs:
            cells_str = f"{run.get('mesh_cells', 'N/A'):,}" if run.get('mesh_cells') else "N/A"
            table.add_row(
                run.get('id', 'N/A'),
                run.get('solver', 'N/A'),
                run.get('turbulence_model', 'N/A'),
                run.get('mesh_version', 'N/A'),
                cells_str
            )
        
        console.print(table)
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


plot_app = typer.Typer(help="Generate publication-ready plots")
app.add_typer(plot_app, name="plot")


@plot_app.command("residuals")
def plot_residuals_cmd(
    run_id: Optional[str] = typer.Option(None, "--run", "-r", help="Run ID (optional)"),
    log_file: Optional[Path] = typer.Option(None, "--log", "-l", help="Path to log file"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output filename (without extension)"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Plot title"),
):
    """
    Generate residual convergence plots from solver logs.
    
    Automatically detects log files in outputs/ directory or use --log to specify.
    Saves both PDF (vector) and PNG (raster) formats.
    """
    try:
        case_root = find_case_root()
        case = Case(case_root)
        
        # Find log file
        if log_file:
            log_path = log_file
        else:
            # Look for log files in outputs/
            log_candidates = list(case.outputs_dir.glob("log*"))
            if not log_candidates:
                rprint("[red]Error: No log files found in outputs/[/red]")
                rprint("[dim]Hint: Place solver log in outputs/ or use --log flag[/dim]")
                raise typer.Exit(1)
            log_path = log_candidates[0]
        
        if not log_path.exists():
            rprint(f"[red]Error: Log file not found: {log_path}[/red]")
            raise typer.Exit(1)
        
        rprint(f"[dim]Reading log file: {log_path}[/dim]")
        
        # Parse residuals
        residuals_data = parse_openfoam_residuals(log_path)
        
        if not residuals_data:
            rprint("[red]Error: No residual data found in log file[/red]")
            raise typer.Exit(1)
        
        # Determine output path
        output_name = output or "residuals"
        output_path = case.figures_dir / output_name
        
        # Plot
        plot_residuals(
            residuals_data,
            output_path,
            title=title or f"Residual Convergence - {case.name}",
            run_label=run_id
        )
        
        rprint(f"[green]✓[/green] Generated residual plots in [cyan]figures/[/cyan]")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@plot_app.command("forces")
def plot_forces_cmd(
    force_file: Optional[Path] = typer.Option(None, "--file", "-f", help="Path to force coefficient file"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output filename"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Plot title"),
    x_axis: str = typer.Option("time", "--x-axis", help="X-axis variable (time or iteration)"),
):
    """
    Generate force coefficient plots (Cl, Cd, Cm).
    
    Reads force coefficient data from CSV or OpenFOAM force output files.
    """
    try:
        case_root = find_case_root()
        case = Case(case_root)
        
        # Find force file
        if force_file:
            force_path = force_file
        else:
            force_candidates = list(case.outputs_dir.glob("*force*")) + \
                             list(case.outputs_dir.glob("*coeff*"))
            if not force_candidates:
                rprint("[red]Error: No force files found in outputs/[/red]")
                raise typer.Exit(1)
            force_path = force_candidates[0]
        
        if not force_path.exists():
            rprint(f"[red]Error: Force file not found: {force_path}[/red]")
            raise typer.Exit(1)
        
        rprint(f"[dim]Reading force file: {force_path}[/dim]")
        
        # Parse and plot
        run = Run("default", case.outputs_dir)
        forces_df = run.get_forces_data()
        
        if forces_df is None or forces_df.empty:
            rprint("[red]Error: No force data found[/red]")
            raise typer.Exit(1)
        
        output_name = output or "forces"
        output_path = case.figures_dir / output_name
        
        plot_forces(
            forces_df,
            output_path,
            title=title or f"Force Coefficients - {case.name}",
            x_axis=x_axis
        )
        
        rprint(f"[green]✓[/green] Generated force plots in [cyan]figures/[/cyan]")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def compare(
    field: str = typer.Argument("Ux", help="Field to compare (e.g., Ux, p, k)"),
    runs: List[str] = typer.Argument(..., help="Run IDs to compare"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output filename"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Plot title"),
):
    """
    Compare residuals from multiple runs.
    
    Example: cfdfig compare Ux run1 run2 run3
    """
    try:
        case_root = find_case_root()
        case = Case(case_root)
        
        runs_data = []
        for run_id in runs:
            run_meta = case.get_run(run_id)
            if not run_meta:
                rprint(f"[yellow]Warning: Run '{run_id}' not found in cfdfig.yaml[/yellow]")
                continue
            
            # Try to find log file for this run
            log_candidates = list(case.outputs_dir.glob(f"log*{run_id}*")) or \
                           list(case.outputs_dir.glob("log*"))
            
            if not log_candidates:
                rprint(f"[yellow]Warning: No log file found for run '{run_id}'[/yellow]")
                continue
            
            residuals = parse_openfoam_residuals(log_candidates[0])
            if residuals:
                runs_data.append((run_id, residuals))
        
        if len(runs_data) < 2:
            rprint("[red]Error: Need at least 2 runs with residual data[/red]")
            raise typer.Exit(1)
        
        output_name = output or f"compare_{field}"
        output_path = case.figures_dir / output_name
        
        compare_residuals(
            runs_data,
            output_path,
            title=title,
            field=field
        )
        
        rprint(f"[green]✓[/green] Generated comparison plot in [cyan]figures/[/cyan]")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def export_methods(
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """
    Export a methods section describing the CFD setup.
    
    Generates formatted text suitable for copy-paste into journal papers,
    including solver, turbulence model, mesh, and other run details.
    """
    try:
        case_root = find_case_root()
        config = CaseConfig(case_root / "cfdfig.yaml")
        
        methods_text = config.export_methods_section()
        
        if output:
            with open(output, 'w') as f:
                f.write(methods_text)
            rprint(f"[green]✓[/green] Exported methods section to: {output}")
        else:
            rprint("\n[bold cyan]Methods Section[/bold cyan]")
            rprint("[dim]" + "="*60 + "[/dim]")
            rprint(methods_text)
            rprint("[dim]" + "="*60 + "[/dim]")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def info():
    """
    Display information about the current CFD case.
    """
    try:
        case_root = find_case_root()
        config = CaseConfig(case_root / "cfdfig.yaml")
        case_info = config.get_case_info()
        
        rprint(f"\n[bold cyan]CFD Case Information[/bold cyan]")
        rprint(f"[dim]{'='*60}[/dim]")
        rprint(f"[bold]Name:[/bold] {case_info.get('name', 'N/A')}")
        rprint(f"[bold]Location:[/bold] {case_root}")
        
        if case_info.get('description'):
            rprint(f"[bold]Description:[/bold] {case_info['description']}")
        
        rprint(f"[bold]Created:[/bold] {case_info.get('created', 'N/A')}")
        rprint(f"[bold]Number of Runs:[/bold] {len(config.list_runs())}")
        
        rprint(f"\n[dim]Use 'cfdfig list-runs' to see run details[/dim]")
        
    except FileNotFoundError as e:
        rprint(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
