"""CFD case abstraction."""

from pathlib import Path
from typing import Optional
from .config import CaseConfig
from .utils import ensure_output_dirs


class Case:
    """Represents a CFD case with metadata and runs."""
    
    def __init__(self, root_path: Path):
        """
        Initialize a Case.
        
        Args:
            root_path: Root directory of the case
        """
        self.root = root_path
        self.config_path = root_path / "cfdfig.yaml"
        self.config = CaseConfig(self.config_path)
        
        self.outputs_dir, self.figures_dir = ensure_output_dirs(root_path)
    
    @classmethod
    def create(cls, root_path: Path, case_name: str, description: str = "") -> "Case":
        """
        Create a new CFD case.
        
        Args:
            root_path: Root directory for the case
            case_name: Name of the case
            description: Optional description
            
        Returns:
            New Case instance
        """
        root_path.mkdir(parents=True, exist_ok=True)
        
        case = cls(root_path)
        case.config.initialize_new_case(case_name, description)
        
        # Create directory structure
        (root_path / "outputs").mkdir(exist_ok=True)
        (root_path / "figures").mkdir(exist_ok=True)
        
        # Create a README
        readme_path = root_path / "README.md"
        with open(readme_path, 'w') as f:
            f.write(f"# {case_name}\n\n")
            if description:
                f.write(f"{description}\n\n")
            f.write("## Directory Structure\n\n")
            f.write("- `outputs/`: Place solver output files here (logs, force data, etc.)\n")
            f.write("- `figures/`: Generated plots will be saved here\n")
            f.write("- `cfdfig.yaml`: Case and run metadata\n")
        
        return case
    
    @property
    def name(self) -> str:
        """Get case name."""
        return self.config.case_name
    
    def add_run(
        self,
        run_id: str,
        solver: str,
        turbulence_model: str,
        mesh_version: str,
        mesh_cells: Optional[int] = None,
        numerics: Optional[str] = None,
        notes: Optional[str] = None
    ) -> None:
        """
        Add a new run to the case.
        
        Args:
            run_id: Unique identifier for this run
            solver: Solver name (e.g., simpleFoam, pimpleFoam)
            turbulence_model: Turbulence model (e.g., kOmegaSST, SA)
            mesh_version: Mesh identifier
            mesh_cells: Number of cells in mesh
            numerics: Numerical scheme information
            notes: Additional notes
        """
        run_data = {
            'id': run_id,
            'solver': solver,
            'turbulence_model': turbulence_model,
            'mesh_version': mesh_version,
        }
        
        if mesh_cells is not None:
            run_data['mesh_cells'] = mesh_cells
        if numerics:
            run_data['numerics'] = numerics
        if notes:
            run_data['notes'] = notes
        
        self.config.add_run(run_data)
    
    def get_run(self, run_id: str) -> Optional[dict]:
        """Get run metadata by ID."""
        return self.config.get_run(run_id)
    
    def list_runs(self) -> list[dict]:
        """List all runs in this case."""
        return self.config.list_runs()
