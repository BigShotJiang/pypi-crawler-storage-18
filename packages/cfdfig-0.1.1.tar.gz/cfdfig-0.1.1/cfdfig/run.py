"""CFD run abstraction."""

from pathlib import Path
from typing import Optional
import pandas as pd


class Run:
    """Represents a single CFD run with associated output data."""
    
    def __init__(
        self,
        run_id: str,
        outputs_dir: Path,
        metadata: Optional[dict] = None
    ):
        """
        Initialize a Run.
        
        Args:
            run_id: Unique identifier for this run
            outputs_dir: Directory containing output files
            metadata: Optional metadata dictionary
        """
        self.run_id = run_id
        self.outputs_dir = outputs_dir
        self.metadata = metadata or {}
    
    def find_log_file(self, pattern: str = "log.*") -> Optional[Path]:
        """
        Find log file matching pattern.
        
        Args:
            pattern: Glob pattern for log file
            
        Returns:
            Path to log file or None
        """
        matches = list(self.outputs_dir.glob(pattern))
        if matches:
            return matches[0]
        return None
    
    def find_force_file(self, pattern: str = "*force*") -> Optional[Path]:
        """
        Find force coefficient file.
        
        Args:
            pattern: Glob pattern for force file
            
        Returns:
            Path to force file or None
        """
        matches = list(self.outputs_dir.glob(pattern))
        if matches:
            return matches[0]
        return None
    
    def get_residuals_data(self) -> Optional[dict]:
        """
        Get residuals data from log file.
        
        Returns:
            Dictionary with residual data or None
        """
        from .utils import parse_openfoam_residuals
        
        log_file = self.find_log_file()
        if not log_file:
            return None
        
        return parse_openfoam_residuals(log_file)
    
    def get_forces_data(self) -> Optional[pd.DataFrame]:
        """
        Get force coefficient data.
        
        Returns:
            DataFrame with force data or None
        """
        from .utils import parse_force_coefficients
        
        force_file = self.find_force_file()
        if not force_file:
            return None
        
        data = parse_force_coefficients(force_file)
        return pd.DataFrame(data)
    
    @property
    def solver(self) -> str:
        """Get solver name from metadata."""
        return self.metadata.get('solver', 'unknown')
    
    @property
    def turbulence_model(self) -> str:
        """Get turbulence model from metadata."""
        return self.metadata.get('turbulence_model', 'unknown')
