"""Pressure coefficient (Cp) plotting."""

from pathlib import Path
from typing import Optional
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def setup_plot_style():
    """Apply journal-ready matplotlib style."""
    style_file = Path(__file__).parent.parent / "styles" / "journal.mplstyle"
    if style_file.exists():
        plt.style.use(str(style_file))


def plot_pressure_coefficient(
    cp_df: pd.DataFrame,
    output_path: Path,
    title: Optional[str] = None,
    x_column: str = "x",
    cp_column: str = "Cp"
) -> None:
    """
    Plot pressure coefficient distribution.
    
    Args:
        cp_df: DataFrame with position and Cp data
        output_path: Path to save figure
        title: Optional plot title
        x_column: Column name for x-axis (position)
        cp_column: Column name for Cp values
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Plot Cp distribution
    ax.plot(cp_df[x_column], cp_df[cp_column], 'b-', linewidth=1.5, marker='o', 
            markersize=3, markerfacecolor='white', markeredgewidth=1)
    
    # Invert y-axis (standard for Cp plots)
    ax.invert_yaxis()
    
    # Formatting
    ax.set_xlabel('x/c' if 'c' in x_column.lower() else 'Position')
    ax.set_ylabel('Pressure Coefficient (Cp)')
    ax.set_title(title or 'Pressure Coefficient Distribution')
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.axhline(y=0, color='k', linestyle='-', linewidth=0.8, alpha=0.5)
    
    plt.tight_layout()
    
    # Save both formats
    pdf_path = output_path.parent / f"{output_path.stem}.pdf"
    png_path = output_path.parent / f"{output_path.stem}.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    print(f"✓ Saved Cp plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")


def plot_cp_comparison(
    cp_data_list: list[tuple[str, pd.DataFrame]],
    output_path: Path,
    title: Optional[str] = None,
    x_column: str = "x",
    cp_column: str = "Cp"
) -> None:
    """
    Compare Cp distributions from multiple datasets.
    
    Args:
        cp_data_list: List of (label, DataFrame) tuples
        output_path: Path to save figure
        title: Optional plot title
        x_column: Column name for x-axis
        cp_column: Column name for Cp values
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    colors = plt.cm.tab10(np.linspace(0, 1, len(cp_data_list)))
    
    for (label, cp_df), color in zip(cp_data_list, colors):
        ax.plot(cp_df[x_column], cp_df[cp_column], linewidth=1.5, 
                label=label, color=color)
    
    # Invert y-axis
    ax.invert_yaxis()
    
    # Formatting
    ax.set_xlabel('x/c' if 'c' in x_column.lower() else 'Position')
    ax.set_ylabel('Pressure Coefficient (Cp)')
    ax.set_title(title or 'Pressure Coefficient Comparison')
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.axhline(y=0, color='k', linestyle='-', linewidth=0.8, alpha=0.5)
    ax.legend(loc='best', frameon=True, framealpha=0.9)
    
    plt.tight_layout()
    
    pdf_path = output_path.parent / f"{output_path.stem}_comparison.pdf"
    png_path = output_path.parent / f"{output_path.stem}_comparison.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    print(f"✓ Saved Cp comparison plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")
