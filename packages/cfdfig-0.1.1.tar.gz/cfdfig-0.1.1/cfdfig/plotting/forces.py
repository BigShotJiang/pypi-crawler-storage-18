"""Force coefficient plotting."""

from pathlib import Path
from typing import Optional
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def setup_plot_style():
    """Apply journal-ready matplotlib style."""
    style_file = Path(__file__).parent.parent / "styles" / "journal.mplstyle"
    if style_file.exists():
        plt.style.use(str(style_file))


def plot_forces(
    forces_df: pd.DataFrame,
    output_path: Path,
    title: Optional[str] = None,
    x_axis: str = "time"
) -> None:
    """
    Plot force coefficients (Cl, Cd, Cm) over time or iteration.
    
    Args:
        forces_df: DataFrame with time/iteration and force coefficient columns
        output_path: Path to save figure (without extension)
        title: Optional plot title
        x_axis: Column name for x-axis ('time' or 'iteration')
    """
    setup_plot_style()
    
    fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharex=True)
    
    x_data = forces_df[x_axis]
    
    # Plot Cd (drag coefficient)
    if 'Cd' in forces_df.columns:
        axes[0].plot(x_data, forces_df['Cd'], 'b-', linewidth=1.5, label='Cd')
        axes[0].set_ylabel('Drag Coefficient (Cd)')
        axes[0].grid(True, alpha=0.3, linestyle='--')
        axes[0].legend(loc='best')
    
    # Plot Cl (lift coefficient)
    if 'Cl' in forces_df.columns:
        axes[1].plot(x_data, forces_df['Cl'], 'r-', linewidth=1.5, label='Cl')
        axes[1].set_ylabel('Lift Coefficient (Cl)')
        axes[1].grid(True, alpha=0.3, linestyle='--')
        axes[1].legend(loc='best')
    
    # Plot Cm (moment coefficient)
    if 'Cm' in forces_df.columns:
        axes[2].plot(x_data, forces_df['Cm'], 'g-', linewidth=1.5, label='Cm')
        axes[2].set_ylabel('Moment Coefficient (Cm)')
        axes[2].grid(True, alpha=0.3, linestyle='--')
        axes[2].legend(loc='best')
    
    # X-axis label
    x_label = 'Time (s)' if x_axis == 'time' else 'Iteration'
    axes[2].set_xlabel(x_label)
    
    # Title
    if title:
        fig.suptitle(title, fontsize=14, y=0.995)
    
    plt.tight_layout()
    
    # Save both formats
    pdf_path = output_path.parent / f"{output_path.stem}.pdf"
    png_path = output_path.parent / f"{output_path.stem}.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    print(f"✓ Saved force coefficient plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")
    
    # Print force statistics
    print(f"\n📊 Force Coefficient Summary:")
    if 'Cd' in forces_df.columns:
        cd_mean = forces_df['Cd'].mean()
        cd_std = forces_df['Cd'].std()
        cd_final = forces_df['Cd'].iloc[-1]
        print(f"  Cd: mean={cd_mean:.4f}, std={cd_std:.5f}, final={cd_final:.4f}")
    if 'Cl' in forces_df.columns:
        cl_mean = forces_df['Cl'].mean()
        cl_std = forces_df['Cl'].std()
        cl_final = forces_df['Cl'].iloc[-1]
        print(f"  Cl: mean={cl_mean:.4f}, std={cl_std:.5f}, final={cl_final:.4f}")
    if 'Cm' in forces_df.columns:
        cm_mean = forces_df['Cm'].mean()
        cm_std = forces_df['Cm'].std()
        cm_final = forces_df['Cm'].iloc[-1]
        print(f"  Cm: mean={cm_mean:.4f}, std={cm_std:.5f}, final={cm_final:.4f}")


def plot_forces_combined(
    forces_df: pd.DataFrame,
    output_path: Path,
    title: Optional[str] = None,
    x_axis: str = "time"
) -> None:
    """
    Plot Cl and Cd on the same axes for comparison.
    
    Args:
        forces_df: DataFrame with time/iteration and force coefficient columns
        output_path: Path to save figure
        title: Optional plot title
        x_axis: Column name for x-axis
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    x_data = forces_df[x_axis]
    
    if 'Cd' in forces_df.columns:
        ax.plot(x_data, forces_df['Cd'], 'b-', linewidth=1.5, label='Cd')
    
    if 'Cl' in forces_df.columns:
        ax.plot(x_data, forces_df['Cl'], 'r-', linewidth=1.5, label='Cl')
    
    x_label = 'Time (s)' if x_axis == 'time' else 'Iteration'
    ax.set_xlabel(x_label)
    ax.set_ylabel('Force Coefficient')
    ax.set_title(title or 'Force Coefficients')
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.legend(loc='best', frameon=True, framealpha=0.9)
    
    plt.tight_layout()
    
    pdf_path = output_path.parent / f"{output_path.stem}_combined.pdf"
    png_path = output_path.parent / f"{output_path.stem}_combined.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    print(f"✓ Saved combined force plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")
