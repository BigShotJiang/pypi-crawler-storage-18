"""Residual plotting for CFD convergence analysis."""

from pathlib import Path
from typing import Optional, List
import matplotlib.pyplot as plt
import numpy as np


def setup_plot_style():
    """Apply journal-ready matplotlib style."""
    style_file = Path(__file__).parent.parent / "styles" / "journal.mplstyle"
    if style_file.exists():
        plt.style.use(str(style_file))


def plot_residuals(
    residuals_data: dict,
    output_path: Path,
    title: Optional[str] = None,
    run_label: Optional[str] = None
) -> None:
    """
    Plot residual convergence history.
    
    Args:
        residuals_data: Dictionary with iteration and residual data for each field
        output_path: Path to save figure (without extension, will save both PDF and PNG)
        title: Optional plot title
        run_label: Optional label for this run
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Plot each field
    colors = plt.cm.tab10(np.linspace(0, 1, len(residuals_data)))
    
    for (field, data), color in zip(residuals_data.items(), colors):
        iterations = data['iteration']
        residuals = data['residual']
        
        label = f"{field}"
        if run_label:
            label = f"{run_label} - {field}"
        
        ax.semilogy(iterations, residuals, label=label, color=color, linewidth=1.5)
    
    # Formatting
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Residual')
    ax.set_title(title or 'Residual Convergence History')
    ax.grid(True, which='both', alpha=0.3, linestyle='--')
    ax.legend(loc='best', frameon=True, framealpha=0.9)
    
    # Set y-axis limits with some margin
    ax.set_ylim(bottom=1e-10)
    
    plt.tight_layout()
    
    # Save both PDF (vector) and PNG (raster)
    pdf_path = output_path.parent / f"{output_path.stem}.pdf"
    png_path = output_path.parent / f"{output_path.stem}.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    # Print summary statistics
    print(f"✓ Saved residual plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")
    print(f"\n📊 Convergence Summary:")
    for field, data in residuals_data.items():
        initial = data['residual'][0] if data['residual'] else 0
        final = data['residual'][-1] if data['residual'] else 0
        iterations = len(data['residual'])
        if initial > 0 and final > 0:
            reduction = initial / final
            print(f"  {field:10s}: {initial:.2e} → {final:.2e} ({reduction:.1e}x reduction, {iterations} iterations)")
        else:
            print(f"  {field:10s}: {iterations} iterations")


def compare_residuals(
    runs_data: List[tuple[str, dict]],
    output_path: Path,
    title: Optional[str] = None,
    field: str = "Ux"
) -> None:
    """
    Compare residuals from multiple runs for a specific field.
    
    Args:
        runs_data: List of (run_id, residuals_data) tuples
        output_path: Path to save figure
        title: Optional plot title
        field: Field to compare (e.g., 'Ux', 'p', 'k')
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    colors = plt.cm.tab10(np.linspace(0, 1, len(runs_data)))
    
    for (run_id, residuals_data), color in zip(runs_data, colors):
        if field not in residuals_data:
            print(f"Warning: Field '{field}' not found in run '{run_id}'")
            continue
        
        data = residuals_data[field]
        iterations = data['iteration']
        residuals = data['residual']
        
        ax.semilogy(iterations, residuals, label=run_id, color=color, linewidth=1.5)
    
    # Formatting
    ax.set_xlabel('Iteration')
    ax.set_ylabel(f'{field} Residual')
    ax.set_title(title or f'Residual Comparison: {field}')
    ax.grid(True, which='both', alpha=0.3, linestyle='--')
    ax.legend(loc='best', frameon=True, framealpha=0.9)
    
    ax.set_ylim(bottom=1e-10)
    
    plt.tight_layout()
    
    # Save both formats
    pdf_path = output_path.parent / f"{output_path.stem}.pdf"
    png_path = output_path.parent / f"{output_path.stem}.png"
    
    fig.savefig(pdf_path, dpi=300, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    
    plt.close(fig)
    
    print(f"✓ Saved comparison plots:")
    print(f"  - {pdf_path}")
    print(f"  - {png_path}")
