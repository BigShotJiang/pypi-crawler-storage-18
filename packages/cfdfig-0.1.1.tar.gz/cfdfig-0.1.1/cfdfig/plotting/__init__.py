"""Plotting module initialization."""

from .residuals import plot_residuals, compare_residuals
from .forces import plot_forces
from .cp import plot_pressure_coefficient

__all__ = [
    'plot_residuals',
    'compare_residuals',
    'plot_forces',
    'plot_pressure_coefficient',
]
