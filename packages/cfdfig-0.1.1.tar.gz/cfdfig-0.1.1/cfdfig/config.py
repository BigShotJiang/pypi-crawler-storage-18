"""YAML configuration handling for CFD cases."""

from pathlib import Path
from typing import Any, Optional
from datetime import datetime
import yaml


class CaseConfig:
    """Handles reading and writing cfdfig.yaml configuration files."""
    
    SCHEMA_VERSION = "1.0"
    
    def __init__(self, config_path: Path):
        """
        Initialize configuration handler.
        
        Args:
            config_path: Path to cfdfig.yaml
        """
        self.config_path = config_path
        self._data = {}
        
        if config_path.exists():
            self.load()
    
    def load(self) -> dict:
        """Load configuration from YAML file."""
        with open(self.config_path, 'r') as f:
            self._data = yaml.safe_load(f) or {}
        return self._data
    
    def save(self) -> None:
        """Save configuration to YAML file."""
        with open(self.config_path, 'w') as f:
            yaml.dump(self._data, f, default_flow_style=False, sort_keys=False)
    
    def initialize_new_case(self, case_name: str, description: str = "") -> None:
        """
        Initialize a new case configuration.
        
        Args:
            case_name: Name of the CFD case
            description: Optional case description
        """
        self._data = {
            'schema_version': self.SCHEMA_VERSION,
            'case': {
                'name': case_name,
                'description': description,
                'created': datetime.now().isoformat(),
            },
            'runs': []
        }
        self.save()
    
    def add_run(self, run_data: dict) -> None:
        """
        Add a new run to the case.
        
        Args:
            run_data: Dictionary containing run metadata
        """
        if 'runs' not in self._data:
            self._data['runs'] = []
        
        # Add timestamp
        run_data['added'] = datetime.now().isoformat()
        
        self._data['runs'].append(run_data)
        self.save()
    
    def get_run(self, run_id: str) -> Optional[dict]:
        """
        Get run data by ID.
        
        Args:
            run_id: Run identifier
            
        Returns:
            Run data dictionary or None if not found
        """
        for run in self._data.get('runs', []):
            if run.get('id') == run_id:
                return run
        return None
    
    def list_runs(self) -> list[dict]:
        """Get list of all runs."""
        return self._data.get('runs', [])
    
    @property
    def case_name(self) -> str:
        """Get case name."""
        return self._data.get('case', {}).get('name', 'unknown')
    
    @property
    def case_description(self) -> str:
        """Get case description."""
        return self._data.get('case', {}).get('description', '')
    
    def get_case_info(self) -> dict:
        """Get case-level information."""
        return self._data.get('case', {})
    
    def export_methods_section(self) -> str:
        """
        Generate a methods section describing all runs.
        
        Returns:
            Formatted text suitable for copy-paste into journal papers
        """
        case_info = self.get_case_info()
        runs = self.list_runs()
        
        output = []
        output.append(f"# CFD Case: {case_info.get('name', 'N/A')}")
        output.append("")
        
        if case_info.get('description'):
            output.append(case_info['description'])
            output.append("")
        
        for i, run in enumerate(runs, 1):
            output.append(f"## Run {i}: {run.get('id', 'N/A')}")
            output.append("")
            output.append(f"- **Solver**: {run.get('solver', 'N/A')}")
            output.append(f"- **Turbulence Model**: {run.get('turbulence_model', 'N/A')}")
            output.append(f"- **Mesh**: {run.get('mesh_version', 'N/A')}")
            output.append(f"- **Cells**: {run.get('mesh_cells', 'N/A')}")
            
            if run.get('numerics'):
                output.append(f"- **Numerics**: {run['numerics']}")
            
            if run.get('notes'):
                output.append("")
                output.append(f"Notes: {run['notes']}")
            
            output.append("")
        
        return "\n".join(output)
