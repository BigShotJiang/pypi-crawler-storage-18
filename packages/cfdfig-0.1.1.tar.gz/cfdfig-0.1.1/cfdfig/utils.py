"""Utility functions for cfdfig."""

from pathlib import Path
from typing import Optional
import re


def find_case_root(start_path: Optional[Path] = None) -> Path:
    """
    Find the CFD case root by looking for cfdfig.yaml.
    
    Args:
        start_path: Starting directory (defaults to current directory)
        
    Returns:
        Path to case root directory
        
    Raises:
        FileNotFoundError: If cfdfig.yaml is not found
    """
    current = start_path or Path.cwd()
    
    # Look up the directory tree for cfdfig.yaml
    for parent in [current] + list(current.parents):
        config_file = parent / "cfdfig.yaml"
        if config_file.exists():
            return parent
    
    raise FileNotFoundError(
        "No cfdfig.yaml found. Are you in a CFD case directory?\n"
        "Run 'cfdfig init <case_name>' to initialize a new case."
    )


def parse_openfoam_residuals(log_file: Path) -> dict:
    """
    Parse OpenFOAM residuals from log file.
    
    Args:
        log_file: Path to OpenFOAM log file
        
    Returns:
        Dictionary with iteration and residual data for each field
    """
    residuals = {}
    
    # OpenFOAM residual pattern: "Solving for Ux, Initial residual = 0.123"
    pattern = re.compile(
        r"Solving for (\w+),.*Initial residual = ([0-9.Ee+-]+)"
    )
    
    with open(log_file, 'r') as f:
        iteration = 0
        for line in f:
            # Track iterations (time steps)
            if line.startswith("Time = "):
                iteration += 1
            
            match = pattern.search(line)
            if match:
                field = match.group(1)
                residual = float(match.group(2))
                
                if field not in residuals:
                    residuals[field] = {'iteration': [], 'residual': []}
                
                residuals[field]['iteration'].append(iteration)
                residuals[field]['residual'].append(residual)
    
    return residuals


def parse_force_coefficients(force_file: Path) -> dict:
    """
    Parse force coefficients from CSV or OpenFOAM force output.
    
    Args:
        force_file: Path to force coefficient file
        
    Returns:
        Dictionary with time, Cl, Cd, and Cm data
    """
    import pandas as pd
    
    # Try CSV first
    if force_file.suffix == '.csv':
        df = pd.read_csv(force_file)
        return df.to_dict('list')
    
    # Parse OpenFOAM forceCoeffs output
    data = {'time': [], 'Cd': [], 'Cl': [], 'Cm': []}
    
    with open(force_file, 'r') as f:
        for line in f:
            # Skip comments
            if line.startswith('#') or not line.strip():
                continue
            
            parts = line.split()
            if len(parts) >= 4:
                try:
                    data['time'].append(float(parts[0]))
                    data['Cd'].append(float(parts[1]))
                    data['Cl'].append(float(parts[2]))
                    data['Cm'].append(float(parts[3]))
                except ValueError:
                    continue
    
    return data


def ensure_output_dirs(case_root: Path) -> tuple[Path, Path]:
    """
    Ensure outputs and figures directories exist.
    
    Args:
        case_root: Root directory of the case
        
    Returns:
        Tuple of (outputs_dir, figures_dir)
    """
    outputs_dir = case_root / "outputs"
    figures_dir = case_root / "figures"
    
    outputs_dir.mkdir(exist_ok=True)
    figures_dir.mkdir(exist_ok=True)
    
    return outputs_dir, figures_dir
