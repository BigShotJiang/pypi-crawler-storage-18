"""
cfdfig - A CLI tool for publication-ready CFD plots and case tracking.

Production-grade tool for PhD-level CFD users focused on reproducibility
and academic-quality visualizations.
"""

__version__ = "0.1.0"
__author__ = "CFD Research Team"
