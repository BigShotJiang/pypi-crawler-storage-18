"""Tests for cfdfig utilities."""

import pytest
from pathlib import Path
from cfdfig.utils import parse_openfoam_residuals, parse_force_coefficients


def test_parse_openfoam_residuals(tmp_path):
    """Test parsing OpenFOAM residuals from log file."""
    log_content = """
Time = 1
smoothSolver:  Solving for Ux, Initial residual = 0.1, Final residual = 0.01
smoothSolver:  Solving for Uy, Initial residual = 0.15, Final residual = 0.012

Time = 2
smoothSolver:  Solving for Ux, Initial residual = 0.05, Final residual = 0.005
smoothSolver:  Solving for Uy, Initial residual = 0.08, Final residual = 0.006
"""
    
    log_file = tmp_path / "log.test"
    log_file.write_text(log_content)
    
    residuals = parse_openfoam_residuals(log_file)
    
    assert "Ux" in residuals
    assert "Uy" in residuals
    assert len(residuals["Ux"]["iteration"]) == 2
    assert residuals["Ux"]["residual"][0] == 0.1
    assert residuals["Ux"]["residual"][1] == 0.05


def test_parse_force_coefficients_csv(tmp_path):
    """Test parsing force coefficients from CSV."""
    csv_content = """time,Cd,Cl,Cm
0.0,0.045,0.32,-0.015
1.0,0.044,0.31,-0.014
"""
    
    force_file = tmp_path / "forces.csv"
    force_file.write_text(csv_content)
    
    forces = parse_force_coefficients(force_file)
    
    assert "time" in forces
    assert "Cd" in forces
    assert len(forces["time"]) == 2
    assert forces["Cd"][0] == 0.045


def test_parse_force_coefficients_openfoam(tmp_path):
    """Test parsing OpenFOAM force coefficient format."""
    force_content = """# Time  Cd  Cl  Cm
0.0  0.045  0.320  -0.015
1.0  0.044  0.316  -0.014
2.0  0.043  0.315  -0.013
"""
    
    force_file = tmp_path / "forceCoeffs.dat"
    force_file.write_text(force_content)
    
    forces = parse_force_coefficients(force_file)
    
    assert len(forces["time"]) == 3
    assert forces["Cd"][1] == 0.044
    assert forces["Cl"][2] == 0.315
