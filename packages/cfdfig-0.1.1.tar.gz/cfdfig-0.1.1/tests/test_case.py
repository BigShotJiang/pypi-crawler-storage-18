"""Tests for CFD case functionality."""

import pytest
from pathlib import Path
from cfdfig.case import Case
from cfdfig.config import CaseConfig


def test_create_case(tmp_path):
    """Test creating a new CFD case."""
    case_path = tmp_path / "test_case"
    case = Case.create(case_path, "test_case", "Test description")
    
    assert case_path.exists()
    assert (case_path / "cfdfig.yaml").exists()
    assert (case_path / "outputs").exists()
    assert (case_path / "figures").exists()
    assert (case_path / "README.md").exists()
    
    assert case.name == "test_case"


def test_add_run_to_case(tmp_path):
    """Test adding a run to a case."""
    case_path = tmp_path / "test_case"
    case = Case.create(case_path, "test_case")
    
    case.add_run(
        run_id="run1",
        solver="simpleFoam",
        turbulence_model="kOmegaSST",
        mesh_version="v1",
        mesh_cells=100000,
        notes="Test run"
    )
    
    runs = case.list_runs()
    assert len(runs) == 1
    assert runs[0]["id"] == "run1"
    assert runs[0]["solver"] == "simpleFoam"
    assert runs[0]["mesh_cells"] == 100000


def test_get_run(tmp_path):
    """Test retrieving a specific run."""
    case_path = tmp_path / "test_case"
    case = Case.create(case_path, "test_case")
    
    case.add_run(
        run_id="run1",
        solver="simpleFoam",
        turbulence_model="kOmegaSST",
        mesh_version="v1"
    )
    
    run = case.get_run("run1")
    assert run is not None
    assert run["id"] == "run1"
    
    missing_run = case.get_run("nonexistent")
    assert missing_run is None


def test_config_export_methods(tmp_path):
    """Test exporting methods section."""
    config_path = tmp_path / "cfdfig.yaml"
    config = CaseConfig(config_path)
    
    config.initialize_new_case("test_case", "Test description")
    config.add_run({
        "id": "run1",
        "solver": "simpleFoam",
        "turbulence_model": "kOmegaSST",
        "mesh_version": "v1",
        "mesh_cells": 100000
    })
    
    methods = config.export_methods_section()
    
    assert "test_case" in methods
    assert "simpleFoam" in methods
    assert "kOmegaSST" in methods
    assert "100000" in methods
