"""Tests for plotting functionality."""

import pytest
from pathlib import Path
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for testing

from cfdfig.plotting import plot_residuals, plot_forces, compare_residuals
import pandas as pd


def test_plot_residuals(tmp_path):
    """Test residual plotting."""
    residuals_data = {
        "Ux": {
            "iteration": [1, 2, 3, 4, 5],
            "residual": [0.1, 0.05, 0.01, 0.001, 0.0001]
        },
        "p": {
            "iteration": [1, 2, 3, 4, 5],
            "residual": [0.2, 0.1, 0.05, 0.01, 0.005]
        }
    }
    
    output_path = tmp_path / "residuals"
    plot_residuals(residuals_data, output_path, title="Test Residuals")
    
    # Check that files were created
    assert (tmp_path / "residuals.pdf").exists()
    assert (tmp_path / "residuals.png").exists()


def test_compare_residuals(tmp_path):
    """Test residual comparison plotting."""
    runs_data = [
        ("run1", {
            "Ux": {
                "iteration": [1, 2, 3],
                "residual": [0.1, 0.05, 0.01]
            }
        }),
        ("run2", {
            "Ux": {
                "iteration": [1, 2, 3],
                "residual": [0.15, 0.08, 0.02]
            }
        })
    ]
    
    output_path = tmp_path / "comparison"
    compare_residuals(runs_data, output_path, field="Ux")
    
    assert (tmp_path / "comparison.pdf").exists()
    assert (tmp_path / "comparison.png").exists()


def test_plot_forces(tmp_path):
    """Test force coefficient plotting."""
    forces_df = pd.DataFrame({
        "time": [0.0, 1.0, 2.0, 3.0],
        "Cd": [0.045, 0.044, 0.043, 0.042],
        "Cl": [0.320, 0.316, 0.315, 0.314],
        "Cm": [-0.015, -0.014, -0.013, -0.012]
    })
    
    output_path = tmp_path / "forces"
    plot_forces(forces_df, output_path, title="Test Forces")
    
    assert (tmp_path / "forces.pdf").exists()
    assert (tmp_path / "forces.png").exists()
