"""Init for views (empty)."""
