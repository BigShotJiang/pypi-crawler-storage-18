"""Protocol models and interfaces."""
