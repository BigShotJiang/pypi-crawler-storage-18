"""The wavetrain windower module."""
