"""The wavetrain selector module."""
