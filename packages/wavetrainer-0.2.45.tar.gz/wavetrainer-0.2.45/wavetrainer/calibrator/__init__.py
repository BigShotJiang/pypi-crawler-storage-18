"""The wavetrain calibrator module."""
