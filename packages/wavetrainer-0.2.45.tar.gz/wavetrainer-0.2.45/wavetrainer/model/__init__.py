"""The wavetrain model module."""
