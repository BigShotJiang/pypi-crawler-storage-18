.. _api:

API documentation
=================

.. toctree::
   :maxdepth: 4

   diskmap
