import asyncio
import time
from enum import Enum
from typing import Callable, Generator, Self, Any, Awaitable

import aiohttp


class ResponseState(Enum):
    HARD_FAIL = "HARD_FAIL"
    SOFT_FAIL = "SOFT_FAIL"
    SUCCESS = "SUCCESS"


class Sentinel:
    """Used to signal the progress bar that a task has finished."""

    pass


class DoneSentinel:
    """Used to signal the requesters that the input's exhausted."""

    pass


class SPARPStopSignal(Exception):
    """Base class for expected control-flow stop signals."""

    pass


class HardFailStop(SPARPStopSignal):
    pass


class SoftFailStop(SPARPStopSignal):
    pass


class TimeoutFailStop(SPARPStopSignal):
    pass


class MaxRetriesStop(SPARPStopSignal):
    pass


class ResultQueues:
    """Container for parsed results and retry exhaustion signals."""

    def __init__(self):
        self.success = asyncio.Queue()
        self.failed = asyncio.Queue()
        self.max_retries_soft_reached = asyncio.Queue()
        self.max_retries_timeout_reached = asyncio.Queue()


class StopConditions:
    def __init__(
        self: Self,
        stop_on_soft_fail: bool = False,
        stop_on_hard_fail: bool = False,
        stop_on_max_retries_by_soft_fail_reached: bool = False,
        stop_on_max_retries_by_timeout_reached: bool = False,
        stop_on_timeout: bool = False,
    ) -> None:
        self.stop_on_soft_fail = stop_on_soft_fail
        self.stop_on_hard_fail = stop_on_hard_fail
        self.stop_on_max_retries_by_soft_fail_reached = stop_on_max_retries_by_soft_fail_reached
        self.stop_on_max_retries_by_timeout_reached = stop_on_max_retries_by_timeout_reached
        self.stop_on_timeout = stop_on_timeout


class Callbacks:
    def __init__(
        self: Self,
        on_success: Callable[[dict, Any], None] | None = None,
        on_hard_fail: Callable[[dict, Any], None] | None = None,
        on_soft_fail: Callable[[dict, int], None] | None = None,
        on_timeout: Callable[[dict, int], None] | None = None,
        on_max_retries_by_soft_fail_reached: Callable[[dict], None] | None = None,
        on_max_retries_by_timeout_reached: Callable[[dict], None] | None = None,
    ):
        self.on_success = on_success
        self.on_hard_fail = on_hard_fail
        self.on_soft_fail = on_soft_fail
        self.on_timeout = on_timeout
        self.on_max_retries_by_soft_fail_reached = on_max_retries_by_soft_fail_reached
        self.on_max_retries_by_timeout_reached = on_max_retries_by_timeout_reached


async def default_parse_response(request_dict: dict, response: aiohttp.ClientResponse) -> dict:
    return {
        "input": request_dict,
        "status": response.status,
        "body": await response.json(),
        "text": await response.text(),
        "headers": response.headers,
    }


class SPARP:
    def __init__(
        self: Self,
        input_generator: Generator[dict, None, None],
        inspect_response: Callable[[aiohttp.ClientResponse], ResponseState],
        callbacks: Callbacks = Callbacks(),
        concurrency: int = 100,
        max_retries_by_soft_fail: int = 20,
        max_retries_by_timeout: int = 20,
        parse_response: Callable[[dict, aiohttp.ClientResponse], Awaitable[dict]] = default_parse_response,
        stop_conditions: StopConditions = StopConditions(),
        input_buffer_size: int = 100,
        show_progress_bar: bool = False,
        estimated_input_collection_size: int | None = None,
        timeout_s: float = 30.0,
    ):
        self.seen = 0
        self.concurrency = concurrency
        self.input_queue = asyncio.Queue(maxsize=input_buffer_size)
        self.queues = ResultQueues()

        self.success_count = 0
        self.failed_count = 0
        self.max_retries_soft_reached_count = 0
        self.max_retries_timeout_reached_count = 0

        self.update_bar_queue = asyncio.Queue()
        self.generator_exhausted = asyncio.Event()

        self.callbacks = callbacks
        self.inspect_response = inspect_response
        self.parse_response = parse_response
        self.input_generator = input_generator
        self.max_retries_by_soft_fail = max_retries_by_soft_fail
        self.max_retries_by_timeout = max_retries_by_timeout
        self.stop_conditions = stop_conditions
        self.show_progress_bar = show_progress_bar
        self.retries_by_soft_fail = 0
        self.retries_by_timeout = 0
        self.estimated_input_collection_size = estimated_input_collection_size
        self.start_time = time.time()
        self.timeout_s = timeout_s

    async def _requester(self: Self, session: aiohttp.ClientSession) -> None:
        while True:
            next_request_dict = await self.input_queue.get()
            if isinstance(next_request_dict, DoneSentinel):
                self.input_queue.task_done()
                break
            try:
                soft_retries, timeout_retries = 0, 0
                while True:
                    if self.max_retries_by_soft_fail and soft_retries >= self.max_retries_by_soft_fail:
                        self.max_retries_soft_reached_count += 1
                        await self.queues.max_retries_soft_reached.put(next_request_dict)
                        if self.callbacks.on_max_retries_by_soft_fail_reached:
                            self.callbacks.on_max_retries_by_soft_fail_reached(next_request_dict)
                        if self.stop_conditions.stop_on_max_retries_by_soft_fail_reached:
                            raise MaxRetriesStop("Max soft-fail retries reached.")
                        break
                    if self.max_retries_by_timeout and timeout_retries >= self.max_retries_by_timeout:
                        self.max_retries_timeout_reached_count += 1
                        await self.queues.max_retries_timeout_reached.put(next_request_dict)
                        if self.callbacks.on_max_retries_by_timeout_reached:
                            self.callbacks.on_max_retries_by_timeout_reached(next_request_dict)
                        if self.stop_conditions.stop_on_max_retries_by_timeout_reached:
                            raise MaxRetriesStop("Max timeout retries reached.")
                        break

                    try:
                        async with session.request(**next_request_dict) as response:
                            state = self.inspect_response(response)
                            parsed_response = await self.parse_response(next_request_dict, response)
                            if state == ResponseState.SUCCESS:
                                self.success_count += 1
                                await self.queues.success.put(parsed_response)
                                if self.callbacks.on_success:
                                    self.callbacks.on_success(next_request_dict, response)
                                break
                            elif state == ResponseState.SOFT_FAIL:
                                self.retries_by_soft_fail += 1
                                if self.callbacks.on_soft_fail:
                                    self.callbacks.on_soft_fail(next_request_dict, soft_retries)
                                if self.stop_conditions.stop_on_soft_fail:
                                    raise SoftFailStop("Stop on soft fail.")
                                soft_retries += 1
                                continue
                            elif state == ResponseState.HARD_FAIL:
                                self.failed_count += 1
                                await self.queues.failed.put(parsed_response)
                                if self.callbacks.on_hard_fail:
                                    self.callbacks.on_hard_fail(next_request_dict, response)
                                if self.stop_conditions.stop_on_hard_fail:
                                    raise HardFailStop("Stop on hard fail.")
                                break
                    except asyncio.TimeoutError:
                        self.retries_by_timeout += 1
                        if self.callbacks.on_timeout:
                            self.callbacks.on_timeout(next_request_dict, timeout_retries)
                        if self.stop_conditions.stop_on_timeout:
                            raise TimeoutFailStop("Stop on timeout.")
                        timeout_retries += 1
                        continue
                    except Exception as e:
                        if not isinstance(e, SPARPStopSignal):
                            e.add_note(f"SPARP_REQUEST_DATA: {next_request_dict}")
                        raise
            finally:
                self.input_queue.task_done()
                await self.update_bar_queue.put(Sentinel())

    async def _producer(self: Self) -> None:
        for item in self.input_generator:
            self.seen += 1
            await self.input_queue.put(item)
        for _ in range(self.concurrency):
            await self.input_queue.put(DoneSentinel())
        self.generator_exhausted.set()

    async def _printer(self: Self) -> None:
        if not self.show_progress_bar:
            return
        try:
            while True:
                await self.update_bar_queue.get()
                done = (
                    self.success_count
                    + self.failed_count
                    + self.max_retries_soft_reached_count
                    + self.max_retries_timeout_reached_count
                )

                if self.generator_exhausted.is_set():
                    progress = 100.0 * done / self.seen if self.seen > 0 else 100
                    est = f"{done}/{self.seen} - {progress:.1f}%"
                elif self.estimated_input_collection_size:
                    progress = 100.0 * done / self.estimated_input_collection_size
                    est = f"{done}/{self.estimated_input_collection_size} - {progress:.1f}%"
                else:
                    est = f"{done}/?"

                print(
                    f"SUCCESS: {self.success_count} | HARD_FAIL: {self.failed_count} | "
                    f"TIMEOUT_RETRY: {self.retries_by_timeout} | SOFT_RETRY: {self.retries_by_soft_fail} | "
                    f"TOOK: {time.time() - self.start_time:.2f}s | PROGRESS: {est}",
                    end="\r",
                )
        except asyncio.CancelledError:
            return

    async def _bar_updater(self: Self) -> None:
        try:
            while True:
                await asyncio.sleep(1)
                await self.update_bar_queue.put(Sentinel())
        except asyncio.CancelledError:
            return

    async def _main(self: Self) -> None:
        try:
            timeout = aiohttp.ClientTimeout(total=self.timeout_s)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with asyncio.TaskGroup() as tg:
                    printer_task = tg.create_task(self._printer())
                    updater_task = tg.create_task(self._bar_updater())
                    tg.create_task(self._producer())
                    for _ in range(self.concurrency):
                        tg.create_task(self._requester(session))
                    await self.generator_exhausted.wait()
                    await self.input_queue.join()
                    printer_task.cancel()
                    updater_task.cancel()

        except* SPARPStopSignal:
            pass

    def main(self: Self) -> None:
        asyncio.run(self._main())

    def get_stats(self: Self) -> dict:
        return {
            "success": self.success_count,
            "failed": self.failed_count,
            "soft_retries": self.retries_by_soft_fail,
            "timeout_retries": self.retries_by_timeout,
        }
