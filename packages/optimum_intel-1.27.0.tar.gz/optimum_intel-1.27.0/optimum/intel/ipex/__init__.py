#  Copyright 2024 The HuggingFace Team. All rights reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.


import warnings

from ..utils.import_utils import is_sentence_transformers_available
from .modeling_base import (
    IPEXModel,
    IPEXModelForAudioClassification,
    IPEXModelForCausalLM,
    IPEXModelForImageClassification,
    IPEXModelForMaskedLM,
    IPEXModelForQuestionAnswering,
    IPEXModelForSeq2SeqLM,
    IPEXModelForSequenceClassification,
    IPEXModelForTokenClassification,
)


if is_sentence_transformers_available():
    from .modeling_sentence_transformers import IPEXSentenceTransformer


warnings.warn(
    "`optimum.intel.ipex` is deprecated and will be removed in the next major release of `optimum-intel`.",
    FutureWarning,
    stacklevel=2,
)
