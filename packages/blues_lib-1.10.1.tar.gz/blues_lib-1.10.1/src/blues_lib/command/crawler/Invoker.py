from blues_lib.sele.browser.chrome.ChromeFactory import ChromeFactory   
from blues_lib.crawler.CrawlerFactory import CrawlerFactory
from blues_lib.sele.browser.Browser import Browser
from blues_lib.type.output.STDOut import STDOut
from blues_lib.model.Model import Model

class Invoker():
  
  @classmethod
  def invoke(cls,model:Model,context:dict|None=None)->STDOut:
    browser = cls.get_browser(model.config,context)
    crawler = CrawlerFactory(model,browser).create()
    return crawler.execute()
  
  @classmethod
  def get_browser(cls,config:dict,context:dict|None=None)->Browser:
    if context and context.get('browser'):
      print(f'---> [{cls.__name__}] use the browser from context')
      return context.get('browser')

    browser_conf:dict = config.get('browser') or {}
    driver_config =  browser_conf.get('config') or {} # optional
    driver_options = browser_conf.get('options') or {} # optional
    browser = ChromeFactory(**driver_options).create(driver_config)
    if not browser:
      raise Exception(f'[{self.NAME}] fail to create the browser')
    return browser