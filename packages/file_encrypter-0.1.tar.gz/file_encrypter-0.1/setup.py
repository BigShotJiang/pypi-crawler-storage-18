from setuptools import setup

setup(
    name="file_encrypter",
    version="0.1",
    packages=["file_protector"],
    entry_points={
        "console_scripts": [
            "file-protector=file_protector.main:main"
        ]
    },
    install_requires=[
        "cryptography==46.0.3",
        "InquirerPy==0.3.4",
        "rich==14.2.0"
        ],
    python_requires=">=3.8"
)
