import os
from typing import Any

from fastloop import FastLoop, LoopContext
from fastloop.integrations.whatsapp import (
    WhatsAppActions,
    WhatsAppButton,
    WhatsAppConfig,
    WhatsAppIntegration,
    WhatsAppMedia,
    WhatsAppMessage,
    WhatsAppSetupInput,
)

app = FastLoop(name="whatsappdemo")


class AppContext(LoopContext):
    client: Any


async def resolve_whatsapp_config(setup_input: WhatsAppSetupInput) -> WhatsAppConfig:
    """
    Resolve the WhatsApp config for this phone number.

    In a real app, you would look up credentials from a database
    based on the phone_number_id.

    Example:
        account = await db.get_whatsapp_account(setup_input.phone_number_id)
        return WhatsAppConfig(
            access_token=account.access_token,
            phone_number_id=account.phone_number_id,
            verify_token=account.verify_token,
            app_secret=account.app_secret,
        )
    """
    return WhatsAppConfig(
        access_token=os.getenv("WHATSAPP_ACCESS_TOKEN") or "",
        phone_number_id=os.getenv("WHATSAPP_PHONE_NUMBER_ID") or "",
        verify_token=os.getenv("WHATSAPP_VERIFY_TOKEN") or "",
        app_secret=os.getenv("WHATSAPP_APP_SECRET") or "",
    )


async def handle_selection(context: AppContext):
    button: WhatsAppButton | None = await context.wait_for(WhatsAppButton, timeout=300)
    if not button:
        return

    initial: WhatsAppMessage = await context.get("initial_message")

    if button.payload == "help":
        await WhatsAppActions.send_text(
            context,
            button.wa_id,
            "Here's how I can help:\n\n"
            "• Send me a photo and I'll analyze it\n"
            "• Ask me any question\n"
            "• Type 'menu' to see options",
            reply_to=button.message_id,
        )
    elif button.payload == "info":
        await WhatsAppActions.send_text(
            context,
            button.wa_id,
            f"You first messaged me with: {initial.text}",
        )

    context.switch_to(handle_selection)


async def handle_media(context: AppContext):
    media: WhatsAppMedia | None = await context.wait_for(WhatsAppMedia, timeout=300)
    if not media:
        return

    await WhatsAppActions.mark_read(context, media.message_id)
    await WhatsAppActions.send_reaction(context, media.wa_id, media.message_id, "👀")

    file_bytes = await media.download(context)
    await WhatsAppActions.send_text(
        context,
        media.wa_id,
        f"Got your {media.media_type}! Size: {len(file_bytes)} bytes",
        reply_to=media.message_id,
    )

    context.switch_to(conversation_loop)


async def conversation_loop(context: AppContext):
    msg: WhatsAppMessage | None = await context.wait_for(WhatsAppMessage, timeout=300)
    if not msg:
        return

    await WhatsAppActions.mark_read(context, msg.message_id)

    if msg.text.lower() == "menu":
        await WhatsAppActions.send_buttons(
            context,
            msg.wa_id,
            "What would you like to do?",
            [("help", "Get Help"), ("info", "My Info")],
        )
        context.switch_to(handle_selection)
    else:
        await WhatsAppActions.send_text(
            context,
            msg.wa_id,
            f"You said: {msg.text}",
            reply_to=msg.message_id,
        )
        context.switch_to(conversation_loop)


@app.loop(
    "chatbot",
    integrations=[WhatsAppIntegration(setup=resolve_whatsapp_config)],
)
async def whatsapp_bot(context: AppContext):
    msg: WhatsAppMessage | None = await context.wait_for(WhatsAppMessage, timeout=1)
    if msg:
        await context.set("initial_message", msg)
        await WhatsAppActions.mark_read(context, msg.message_id)
        await WhatsAppActions.send_text(
            context,
            msg.wa_id,
            "Welcome! I'm your assistant. Send me a message or type 'menu' for options.",
        )
        context.switch_to(conversation_loop)
        return

    media: WhatsAppMedia | None = await context.wait_for(WhatsAppMedia, timeout=1)
    if media:
        await context.set("initial_message", media)
        context.switch_to(handle_media)


if __name__ == "__main__":
    app.run(port=8112)

