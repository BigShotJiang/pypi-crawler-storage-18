import hashlib
import hmac
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, cast

from fastapi import HTTPException, Request
from pydantic import Field

from ..integrations import Integration
from ..models import LoopEvent, LoopState
from ..types import IntegrationType

if TYPE_CHECKING:
    from ..context import LoopContext
    from ..fastloop import FastLoop

GRAPH_API = "https://graph.facebook.com/v21.0"


@dataclass
class WhatsAppConfig:
    access_token: str
    phone_number_id: str
    verify_token: str
    app_secret: str


@dataclass
class WhatsAppSetupInput:
    loop_name: str
    phone_number_id: str
    sender_wa_id: str
    payload: dict[str, Any] = field(default_factory=dict)


WhatsAppSetupCallback = Callable[["WhatsAppSetupInput"], Awaitable["WhatsAppConfig"]]


# --- Inbound Events ---


class WhatsAppMessage(LoopEvent):
    type: str = "whatsapp_message"
    wa_id: str
    message_id: str
    text: str = ""
    timestamp: str = ""
    reply_to: str | None = None
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


class WhatsAppMedia(LoopEvent):
    type: str = "whatsapp_media"
    wa_id: str
    message_id: str
    media_type: str
    media_id: str
    mime_type: str | None = None
    caption: str | None = None
    filename: str | None = None
    timestamp: str = ""
    reply_to: str | None = None
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    async def download(self, context: "LoopContext") -> bytes:
        from httpx import AsyncClient

        integration = context.integrations.get(IntegrationType.WHATSAPP)
        if not integration:
            raise ValueError("WhatsApp integration not in context")
        config = integration.get_config_for_context(context)
        headers = {"Authorization": f"Bearer {config.access_token}"}

        async with AsyncClient() as client:
            r = await client.get(f"{GRAPH_API}/{self.media_id}", headers=headers)
            r.raise_for_status()
            url = r.json().get("url")
            if not url:
                raise ValueError(f"No URL for media {self.media_id}")
            r = await client.get(url, headers=headers)
            r.raise_for_status()
            return r.content


class WhatsAppLocation(LoopEvent):
    type: str = "whatsapp_location"
    wa_id: str
    message_id: str
    latitude: float
    longitude: float
    name: str | None = None
    address: str | None = None
    timestamp: str = ""
    reply_to: str | None = None
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


@dataclass
class ContactInfo:
    name: str
    phones: list[str] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)
    org: str | None = None


class WhatsAppContacts(LoopEvent):
    type: str = "whatsapp_contacts"
    wa_id: str
    message_id: str
    contacts: list[dict[str, Any]] = Field(default_factory=list)
    timestamp: str = ""
    reply_to: str | None = None
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


class WhatsAppReaction(LoopEvent):
    type: str = "whatsapp_reaction"
    wa_id: str
    message_id: str
    emoji: str
    target_message_id: str
    timestamp: str = ""
    phone_number_id: str = ""


class WhatsAppButton(LoopEvent):
    type: str = "whatsapp_button"
    wa_id: str
    message_id: str
    payload: str
    title: str | None = None
    timestamp: str = ""
    reply_to: str | None = None
    phone_number_id: str = ""


class WhatsAppOrder(LoopEvent):
    type: str = "whatsapp_order"
    wa_id: str
    message_id: str
    catalog_id: str
    products: list[dict[str, Any]] = Field(default_factory=list)
    text: str = ""
    timestamp: str = ""
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


class WhatsAppStatus(LoopEvent):
    type: str = "whatsapp_status"
    message_id: str
    status: str
    recipient_id: str
    timestamp: str = ""
    phone_number_id: str = ""
    conversation: dict[str, Any] | None = None
    pricing: dict[str, Any] | None = None
    errors: list[dict[str, Any]] = Field(default_factory=list)


class WhatsAppSystem(LoopEvent):
    type: str = "whatsapp_system"
    wa_id: str
    message_id: str
    body: str
    identity: dict[str, Any] | None = None
    new_wa_id: str | None = None
    timestamp: str = ""
    phone_number_id: str = ""


class WhatsAppReferral(LoopEvent):
    type: str = "whatsapp_referral"
    wa_id: str
    message_id: str
    source_url: str
    source_type: str
    source_id: str
    headline: str | None = None
    body: str | None = None
    media_type: str | None = None
    media_url: str | None = None
    timestamp: str = ""
    phone_number_id: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)


# --- Outbound Events ---


class WhatsAppTemplate(LoopEvent):
    type: str = "whatsapp_template"
    wa_id: str
    template_name: str
    language: str = "en"
    components: list[dict[str, Any]] = Field(default_factory=list)
    phone_number_id: str = ""


class WhatsAppInteractive(LoopEvent):
    type: str = "whatsapp_interactive"
    wa_id: str
    interactive_type: str
    header: dict[str, Any] | None = None
    body: str
    footer: str | None = None
    buttons: list[dict[str, Any]] = Field(default_factory=list)
    sections: list[dict[str, Any]] = Field(default_factory=list)
    reply_to: str | None = None
    phone_number_id: str = ""


WHATSAPP_EVENTS: list[type[LoopEvent]] = [
    WhatsAppMessage,
    WhatsAppMedia,
    WhatsAppLocation,
    WhatsAppContacts,
    WhatsAppReaction,
    WhatsAppButton,
    WhatsAppOrder,
    WhatsAppStatus,
    WhatsAppSystem,
    WhatsAppReferral,
    WhatsAppTemplate,
    WhatsAppInteractive,
]


def _verify_sig(body: bytes, sig: str, secret: str) -> bool:
    if not sig.startswith("sha256="):
        return False
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig[7:], expected)


class WhatsAppIntegration(Integration):
    def __init__(self, *, setup: WhatsAppSetupCallback):
        super().__init__()
        self._setup = setup
        self._configs: dict[str, WhatsAppConfig] = {}
        self._fastloop: FastLoop
        self.loop_name: str

    def type(self) -> IntegrationType:
        return IntegrationType.WHATSAPP

    async def _get_config(self, phone_id: str, wa_id: str = "") -> WhatsAppConfig:
        if phone_id and phone_id in self._configs:
            return self._configs[phone_id]
        inp = WhatsAppSetupInput(self.loop_name, phone_id, wa_id)
        cfg = await self._setup(inp)
        if phone_id:
            self._configs[phone_id] = cfg
        return cfg

    async def setup_for_context(self, ctx: "LoopContext", event: LoopEvent) -> None:
        phone_id = getattr(event, "phone_number_id", "")
        wa_id = getattr(event, "wa_id", "")
        cfg = await self._get_config(phone_id, wa_id)
        ctx.set_integration_client(self.type(), cfg)
        ctx.set_integration_client(f"{self.type()}_config", cfg)

    def get_config_for_context(self, ctx: "LoopContext") -> WhatsAppConfig:
        cfg = ctx.get_integration_client(f"{self.type()}_config")
        if not cfg:
            raise ValueError("WhatsApp config not initialized")
        return cast("WhatsAppConfig", cfg)

    def register(self, fastloop: "FastLoop", loop_name: str) -> None:
        fastloop.register_events(WHATSAPP_EVENTS)
        self._fastloop = fastloop
        self._fastloop.add_api_route(
            f"/{loop_name}/whatsapp/events",
            self._webhook,
            methods=["GET", "POST"],
            response_model=None,
        )
        self.loop_name = loop_name

    def events(self) -> list[Any]:
        return list(WHATSAPP_EVENTS)

    async def _webhook(self, request: Request):
        if request.method == "GET":
            return await self._verify(request)

        body = await request.body()
        data = await request.json()

        for entry in data.get("entry", []):
            for change in entry.get("changes", []):
                if change.get("field") != "messages":
                    continue
                val = change.get("value", {})
                meta = val.get("metadata", {})
                phone_id = meta.get("phone_number_id", "")

                cfg = await self._get_config(phone_id)
                sig = request.headers.get("x-hub-signature-256", "")
                if not _verify_sig(body, sig, cfg.app_secret):
                    raise HTTPException(HTTPStatus.FORBIDDEN, "Invalid signature")

                handler = self._fastloop.loop_event_handlers.get(self.loop_name)
                if not handler:
                    continue

                for s in val.get("statuses", []):
                    ev = WhatsAppStatus(
                        message_id=s.get("id", ""),
                        status=s.get("status", ""),
                        recipient_id=s.get("recipient_id", ""),
                        timestamp=s.get("timestamp", ""),
                        phone_number_id=phone_id,
                        conversation=s.get("conversation"),
                        pricing=s.get("pricing"),
                        errors=s.get("errors", []),
                    )
                    await handler(ev.to_dict())

                for msg in val.get("messages", []):
                    ev = self._parse_msg(msg, phone_id)
                    if not ev:
                        continue
                    wa_id = msg.get("from", "")
                    key = f"whatsapp:{phone_id}:{wa_id}"
                    ev.loop_id = await self._fastloop.state_manager.get_loop_mapping(
                        key
                    )
                    loop: LoopState = await handler(ev.to_dict())
                    if loop.loop_id:
                        await self._fastloop.state_manager.set_loop_mapping(
                            key, loop.loop_id
                        )

        return {"status": "ok"}

    async def _verify(self, request: Request) -> str:
        mode = request.query_params.get("hub.mode")
        token = request.query_params.get("hub.verify_token")
        challenge = request.query_params.get("hub.challenge", "")

        if mode != "subscribe" or not token:
            raise HTTPException(HTTPStatus.BAD_REQUEST, "Bad request")

        cfg = await self._get_config("")
        if token != cfg.verify_token:
            raise HTTPException(HTTPStatus.FORBIDDEN, "Bad token")

        return challenge

    def _parse_msg(self, msg: dict[str, Any], phone_id: str) -> LoopEvent | None:
        t = msg.get("type", "")
        wa_id = msg.get("from", "")
        mid = msg.get("id", "")
        ts = msg.get("timestamp", "")
        ctx = msg.get("context", {})
        reply_to = ctx.get("id") if ctx else None
        referral = msg.get("referral")

        if referral:
            return WhatsAppReferral(
                wa_id=wa_id,
                message_id=mid,
                source_url=referral.get("source_url", ""),
                source_type=referral.get("source_type", ""),
                source_id=referral.get("source_id", ""),
                headline=referral.get("headline"),
                body=referral.get("body"),
                media_type=referral.get("media_type"),
                media_url=referral.get("image_url") or referral.get("video_url"),
                timestamp=ts,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t == "text":
            return WhatsAppMessage(
                wa_id=wa_id,
                message_id=mid,
                text=msg.get("text", {}).get("body", ""),
                timestamp=ts,
                reply_to=reply_to,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t in ("image", "video", "audio", "document", "sticker"):
            m = msg.get(t, {})
            return WhatsAppMedia(
                wa_id=wa_id,
                message_id=mid,
                media_type=t,
                media_id=m.get("id", ""),
                mime_type=m.get("mime_type"),
                caption=m.get("caption"),
                filename=m.get("filename"),
                timestamp=ts,
                reply_to=reply_to,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t == "location":
            loc = msg.get("location", {})
            return WhatsAppLocation(
                wa_id=wa_id,
                message_id=mid,
                latitude=loc.get("latitude", 0.0),
                longitude=loc.get("longitude", 0.0),
                name=loc.get("name"),
                address=loc.get("address"),
                timestamp=ts,
                reply_to=reply_to,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t == "contacts":
            return WhatsAppContacts(
                wa_id=wa_id,
                message_id=mid,
                contacts=msg.get("contacts", []),
                timestamp=ts,
                reply_to=reply_to,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t == "reaction":
            r = msg.get("reaction", {})
            return WhatsAppReaction(
                wa_id=wa_id,
                message_id=mid,
                emoji=r.get("emoji", ""),
                target_message_id=r.get("message_id", ""),
                timestamp=ts,
                phone_number_id=phone_id,
            )

        if t == "button":
            b = msg.get("button", {})
            return WhatsAppButton(
                wa_id=wa_id,
                message_id=mid,
                payload=b.get("payload", ""),
                title=b.get("text"),
                timestamp=ts,
                reply_to=reply_to,
                phone_number_id=phone_id,
            )

        if t == "interactive":
            i = msg.get("interactive", {})
            it = i.get("type", "")
            if it == "button_reply":
                r = i.get("button_reply", {})
            elif it == "list_reply":
                r = i.get("list_reply", {})
            elif it == "nfm_reply":
                r = i.get("nfm_reply", {})
            else:
                r = {}
            if r:
                return WhatsAppButton(
                    wa_id=wa_id,
                    message_id=mid,
                    payload=r.get("id", "") or r.get("response_json", ""),
                    title=r.get("title"),
                    timestamp=ts,
                    reply_to=reply_to,
                    phone_number_id=phone_id,
                )

        if t == "order":
            o = msg.get("order", {})
            return WhatsAppOrder(
                wa_id=wa_id,
                message_id=mid,
                catalog_id=o.get("catalog_id", ""),
                products=o.get("product_items", []),
                text=o.get("text", ""),
                timestamp=ts,
                phone_number_id=phone_id,
                raw=msg,
            )

        if t == "system":
            s = msg.get("system", {})
            return WhatsAppSystem(
                wa_id=wa_id,
                message_id=mid,
                body=s.get("body", ""),
                identity=s.get("identity"),
                new_wa_id=s.get("new_wa_id"),
                timestamp=ts,
                phone_number_id=phone_id,
            )

        return None

    async def emit(
        self, event: LoopEvent, context: "LoopContext | None" = None
    ) -> None:
        from httpx import AsyncClient

        if not context:
            raise ValueError("Context required")

        cfg = self.get_config_for_context(context)
        phone_id = getattr(event, "phone_number_id", "") or cfg.phone_number_id
        url = f"{GRAPH_API}/{phone_id}/messages"
        headers = {"Authorization": f"Bearer {cfg.access_token}"}

        async with AsyncClient() as client:
            if isinstance(event, WhatsAppMessage):
                body: dict[str, Any] = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": "text",
                    "text": {"body": event.text},
                }
                if event.reply_to:
                    body["context"] = {"message_id": event.reply_to}
                await client.post(url, headers=headers, json=body)

            elif isinstance(event, WhatsAppMedia):
                media: dict[str, Any] = {}
                if event.media_id:
                    media["id"] = event.media_id
                if event.caption:
                    media["caption"] = event.caption
                if event.filename and event.media_type == "document":
                    media["filename"] = event.filename
                body = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": event.media_type,
                    event.media_type: media,
                }
                if event.reply_to:
                    body["context"] = {"message_id": event.reply_to}
                await client.post(url, headers=headers, json=body)

            elif isinstance(event, WhatsAppLocation):
                body = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": "location",
                    "location": {
                        "latitude": event.latitude,
                        "longitude": event.longitude,
                        "name": event.name or "",
                        "address": event.address or "",
                    },
                }
                await client.post(url, headers=headers, json=body)

            elif isinstance(event, WhatsAppContacts):
                body = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": "contacts",
                    "contacts": event.contacts,
                }
                await client.post(url, headers=headers, json=body)

            elif isinstance(event, WhatsAppReaction):
                await client.post(
                    url,
                    headers=headers,
                    json={
                        "messaging_product": "whatsapp",
                        "to": event.wa_id,
                        "type": "reaction",
                        "reaction": {
                            "message_id": event.target_message_id,
                            "emoji": event.emoji,
                        },
                    },
                )

            elif isinstance(event, WhatsAppTemplate):
                body = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": "template",
                    "template": {
                        "name": event.template_name,
                        "language": {"code": event.language},
                    },
                }
                if event.components:
                    body["template"]["components"] = event.components
                await client.post(url, headers=headers, json=body)

            elif isinstance(event, WhatsAppInteractive):
                interactive: dict[str, Any] = {
                    "type": event.interactive_type,
                    "body": {"text": event.body},
                }
                if event.header:
                    interactive["header"] = event.header
                if event.footer:
                    interactive["footer"] = {"text": event.footer}
                if event.interactive_type == "button":
                    interactive["action"] = {"buttons": event.buttons}
                elif event.interactive_type == "list":
                    interactive["action"] = {
                        "button": event.buttons[0].get("title", "Menu")
                        if event.buttons
                        else "Menu",
                        "sections": event.sections,
                    }
                elif event.interactive_type == "product":
                    interactive["action"] = event.buttons[0] if event.buttons else {}
                elif event.interactive_type == "product_list":
                    interactive["action"] = {
                        "catalog_id": event.buttons[0].get("catalog_id", "")
                        if event.buttons
                        else "",
                        "sections": event.sections,
                    }
                body = {
                    "messaging_product": "whatsapp",
                    "to": event.wa_id,
                    "type": "interactive",
                    "interactive": interactive,
                }
                if event.reply_to:
                    body["context"] = {"message_id": event.reply_to}
                await client.post(url, headers=headers, json=body)

            else:
                raise NotImplementedError(f"{type(event).__name__} emit not supported")


class WhatsAppActions:
    @staticmethod
    def _get(ctx: "LoopContext") -> "WhatsAppIntegration":
        integration = ctx.integrations.get(IntegrationType.WHATSAPP)
        if not integration:
            raise ValueError("WhatsApp integration not configured")
        return cast("WhatsAppIntegration", integration)

    @staticmethod
    async def send_text(
        ctx: "LoopContext", to: str, text: str, reply_to: str | None = None
    ) -> None:
        ev = WhatsAppMessage(wa_id=to, message_id="", text=text, reply_to=reply_to)
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_media(
        ctx: "LoopContext",
        to: str,
        media_type: str,
        media_id: str,
        caption: str | None = None,
        filename: str | None = None,
    ) -> None:
        ev = WhatsAppMedia(
            wa_id=to,
            message_id="",
            media_type=media_type,
            media_id=media_id,
            caption=caption,
            filename=filename,
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_location(
        ctx: "LoopContext",
        to: str,
        latitude: float,
        longitude: float,
        name: str | None = None,
        address: str | None = None,
    ) -> None:
        ev = WhatsAppLocation(
            wa_id=to,
            message_id="",
            latitude=latitude,
            longitude=longitude,
            name=name,
            address=address,
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_reaction(
        ctx: "LoopContext", to: str, message_id: str, emoji: str
    ) -> None:
        ev = WhatsAppReaction(
            wa_id=to, message_id="", emoji=emoji, target_message_id=message_id
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_template(
        ctx: "LoopContext",
        to: str,
        template_name: str,
        language: str = "en",
        components: list[dict[str, Any]] | None = None,
    ) -> None:
        ev = WhatsAppTemplate(
            wa_id=to,
            template_name=template_name,
            language=language,
            components=components or [],
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_buttons(
        ctx: "LoopContext",
        to: str,
        body: str,
        buttons: list[tuple[str, str]],
        header: str | None = None,
        footer: str | None = None,
        reply_to: str | None = None,
    ) -> None:
        btn_list = [
            {"type": "reply", "reply": {"id": bid, "title": title}}
            for bid, title in buttons[:3]
        ]
        ev = WhatsAppInteractive(
            wa_id=to,
            interactive_type="button",
            body=body,
            buttons=btn_list,
            header={"type": "text", "text": header} if header else None,
            footer=footer,
            reply_to=reply_to,
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def send_list(
        ctx: "LoopContext",
        to: str,
        body: str,
        button_text: str,
        sections: list[dict[str, Any]],
        header: str | None = None,
        footer: str | None = None,
        reply_to: str | None = None,
    ) -> None:
        ev = WhatsAppInteractive(
            wa_id=to,
            interactive_type="list",
            body=body,
            buttons=[{"title": button_text}],
            sections=sections,
            header={"type": "text", "text": header} if header else None,
            footer=footer,
            reply_to=reply_to,
        )
        await WhatsAppActions._get(ctx).emit(ev, ctx)

    @staticmethod
    async def mark_read(ctx: "LoopContext", message_id: str) -> None:
        from httpx import AsyncClient

        cfg = WhatsAppActions._get(ctx).get_config_for_context(ctx)
        url = f"{GRAPH_API}/{cfg.phone_number_id}/messages"
        headers = {"Authorization": f"Bearer {cfg.access_token}"}
        async with AsyncClient() as client:
            await client.post(
                url,
                headers=headers,
                json={
                    "messaging_product": "whatsapp",
                    "status": "read",
                    "message_id": message_id,
                },
            )
