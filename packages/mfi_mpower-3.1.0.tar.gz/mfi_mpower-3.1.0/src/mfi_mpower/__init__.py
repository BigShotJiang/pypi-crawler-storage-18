"""This is the mFi mPower module."""

from __future__ import annotations

__version__ = "3.1.0"
