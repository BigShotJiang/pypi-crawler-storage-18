"""
Omium Python SDK

Fault-tolerant operating system for production multi-agent AI systems.
"""

from .agent import agent
from .checkpoint import checkpoint, Checkpoint
from .consensus import consensus, Consensus
from .client import (
    OmiumClient,
    CheckpointError,
    CheckpointNotFoundError,
    CheckpointValidationError,
    ConnectionError
)
from .remote_client import RemoteOmiumClient
from .config import get_config, ConfigManager, OmiumConfig
from .websocket_client import ExecutionWebSocketClient

__version__ = "0.1.5"
__all__ = [
    "agent",
    "checkpoint",
    "Checkpoint",
    "consensus",
    "Consensus",
    "OmiumClient",
    "RemoteOmiumClient",
    "CheckpointError",
    "CheckpointNotFoundError",
    "CheckpointValidationError",
    "ConnectionError",
    "get_config",
    "ConfigManager",
    "OmiumConfig",
    "ExecutionWebSocketClient",
]
