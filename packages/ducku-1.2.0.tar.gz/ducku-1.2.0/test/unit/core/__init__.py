"""Core tests package."""
