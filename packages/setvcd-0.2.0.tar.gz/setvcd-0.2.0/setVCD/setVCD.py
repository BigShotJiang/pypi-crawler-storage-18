"""SetVCD - Convert VCD signals to sets of time points based on conditions."""

import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

import vcdvcd

from .exceptions import (
    ClockSignalError,
    EmptyVCDError,
    InvalidInputError,
    InvalidSignalConditionError,
    SignalNotFoundError,
    VCDFileNotFoundError,
    VCDParseError,
)
from .types import (
    FP,
    AnyValue,
    FPValue,
    Raw,
    RawValue,
    SignalConditionProtocol,
    SignalProtocol,
    String,
    StringValue,
    Time,
    ValueType,
    VCDInput,
    VCDVCDProtocol,
)


def _convert_to_int(value: str) -> Optional[int]:
    """Convert vcdvcd binary string to integer (Raw conversion).

    Args:
        value: Binary string from vcdvcd (e.g., "1010", "xxxx", "z")

    Returns:
        Integer value for valid binary strings, None for x/z or malformed strings.

    Examples:
        >>> _convert_to_int("1010")  # Binary to decimal
        10
        >>> _convert_to_int("xxxx")  # X/Z values
        None
    """
    # Case-insensitive check for unknown/high-impedance
    value_lower = value.lower()
    if "x" in value_lower or "z" in value_lower:
        return None

    # Binary to decimal conversion
    try:
        return int(value, 2)
    except ValueError:
        # Defensive: malformed VCD value
        return None


def _convert_to_string(value: str) -> Optional[str]:
    """Convert vcdvcd string to string (String conversion - passthrough)."""
    # Return as-is, only return None for truly invalid input
    if value is None or value == "":
        return None
    return value


def _convert_to_fp(value: str, frac: int, signed: bool) -> Optional[float]:
    """Convert vcdvcd binary string to fixed-point float (FP conversion)."""
    # Validate frac parameter
    if frac < 0:
        raise ValueError(f"frac must be >= 0, got {frac}")

    # Check for x/z - return NaN per requirements
    value_lower = value.lower()
    if "x" in value_lower or "z" in value_lower:
        return float("nan")

    try:
        # Convert binary string to integer (unsigned initially)
        int_value = int(value, 2)
        total_bits = len(value)

        # Handle signed values (two's complement)
        if signed and total_bits > 0:
            sign_bit = 1 << (total_bits - 1)
            if int_value & sign_bit:
                # Negative number in two's complement
                int_value = int_value - (1 << total_bits)

        # Apply fractional scaling: divide by 2^frac
        float_value = int_value / (1 << frac)

        return float_value

    except ValueError:
        # Malformed binary string
        return float("nan")


def _convert_value(value_str: str, value_type: ValueType) -> AnyValue:
    """Dispatch to appropriate converter based on ValueType."""
    if isinstance(value_type, Raw):
        return _convert_to_int(value_str)
    elif isinstance(value_type, String):
        return _convert_to_string(value_str)
    elif isinstance(value_type, FP):
        return _convert_to_fp(value_str, value_type.frac, value_type.signed)
    else:
        # Should never happen with proper typing
        raise ValueError(f"Unknown ValueType: {type(value_type)}")


class SetVCD:
    """
    Query VCD signals with functionally, and combine them with set theory operators.
    """

    def __init__(self, vcd: VCDInput, clock: str = "clk") -> None:
        """
        Args:
            vcd: Either a filename (str/Path) to a VCD file, or an already-parsed
                vcdvcd.VCDVCD object. If a filename is provided, it will be loaded
                and parsed automatically.
            clock: Exact name of the clock signal to use as time reference. This
                signal's last transition determines the iteration range. Must match
                a signal name exactly (case-sensitive).
        """
        # Load VCD object
        if isinstance(vcd, (str, Path)):
            vcd_path = Path(vcd)
            if not vcd_path.exists():
                raise VCDFileNotFoundError(f"VCD file not found: {vcd_path}")

            try:
                self.wave: VCDVCDProtocol = vcdvcd.VCDVCD(str(vcd_path))
            except Exception as e:
                raise VCDParseError(f"Failed to parse VCD file: {e}") from e
        elif hasattr(vcd, "get_signals") and hasattr(vcd, "__getitem__"):
            # Duck typing check for VCDVCD-like object
            self.wave = vcd
        else:
            raise InvalidInputError(
                f"vcd must be a filename (str/Path) or VCDVCD object, "
                f"got {type(vcd).__name__}"
            )

        # Validate VCD has signals
        try:
            all_signals = self.wave.get_signals()
        except Exception as e:
            raise VCDParseError(f"Failed to retrieve signals from VCD: {e}") from e

        if not all_signals:
            raise EmptyVCDError("VCD file contains no signals")

        # Initialize signal storage
        self.sigs: Dict[str, SignalProtocol] = {}

        # Find clock signal - EXACT match only
        if clock not in all_signals:
            # Provide helpful error message with similar signals using fuzzy matching
            # Split the search term into parts and find signals containing those parts
            search_parts = [p for p in clock.lower().split(".") if p]
            similar = []

            # Score each signal based on how many parts match
            scored_signals = []
            for sig in all_signals:
                sig_lower = sig.lower()
                matches = sum(1 for part in search_parts if part in sig_lower)
                if matches > 0:
                    scored_signals.append((matches, sig))

            # Sort by number of matches (descending) and take top matches
            scored_signals.sort(reverse=True, key=lambda x: x[0])
            similar = [sig for _, sig in scored_signals[:5]]

            error_msg = f"Clock signal '{clock}' not found in VCD."
            if similar:
                error_msg += f" Did you mean one of: {similar}?"
            else:
                error_msg += f" Available signals: {all_signals[:10]}..."
            raise ClockSignalError(error_msg)

        try:
            self.sigs["clock"] = self.wave[clock]
        except Exception as e:
            raise VCDParseError(f"Failed to access clock signal '{clock}': {e}") from e

        # Verify clock has data
        if not self.sigs["clock"].tv:
            raise EmptyVCDError(f"Clock signal '{clock}' has no time/value data")

        # Get last clock timestamp
        try:
            self.last_clock: Time = self.sigs["clock"].tv[-1][0]
        except (IndexError, TypeError) as e:
            raise EmptyVCDError(
                f"Failed to get last timestamp from clock signal: {e}"
            ) from e

    def search(self, search_regex: str = "") -> List[str]:
        """Search for signals matching a regex pattern.

        Args:
            search_regex: Regular expression pattern to match signal names.
                Empty string returns all signals.

        Returns:
            List of signal names matching the pattern.

        Example:
            >>> vs = SetVCD("sim.vcd", clock="TOP.clk")
            >>> output_signals = vs.search("output")
            >>> accelerator_signals = vs.search("Accelerator.*valid")
        """
        signals = self.wave.get_signals()
        searched = [s for s in signals if re.search(search_regex, s)]
        return searched

    def get(
        self,
        signal_name: str,
        signal_condition: Union[
            SignalConditionProtocol[int],
            SignalConditionProtocol[str],
            SignalConditionProtocol[float],
        ],
        value_type: Optional[ValueType] = None,
    ) -> Set[Time]:
        """Filter time points based on signal condition.

        Args:
            signal_name: Exact name of signal (case-sensitive). Must exist in VCD file.
            signal_condition: Function (sm1, s, sp1) -> bool that evaluates signal values.
                The value types passed depend on value_type parameter:
                - Raw(): receives Optional[int] values
                - String(): receives Optional[str] values
                - FP(): receives Optional[float] values
            value_type: Value conversion type (default: Raw() for backward compatibility).
                - Raw(): Binary to int, x/z become None
                - String(): Keep raw strings including x/z as literals
                - FP(frac, signed): Fixed-point to float, x/z become NaN

        Returns:
            Set of timesteps where signal_condition returns True.

        Examples:
            >>> # Integer comparison (default Raw)
            >>> rising = vs.get("clk", lambda sm1, s, sp1: sm1 == 0 and s == 1)
            >>>
            >>> # String matching to detect x/z
            >>> has_x = vs.get("data", lambda sm1, s, sp1: s is not None and 'x' in s,
            ...                value_type=String())
            >>>
            >>> # Fixed-point comparison
            >>> above_threshold = vs.get("temp",
            ...                          lambda sm1, s, sp1: s is not None and s > 25.5,
            ...                          value_type=FP(frac=8, signed=True))
        """
        # Default to Raw() if not specified
        if value_type is None:
            value_type = Raw()

        # Validate signal exists
        try:
            all_signals = self.wave.get_signals()
        except Exception as e:
            raise VCDParseError(f"Failed to retrieve signals: {e}") from e

        if signal_name not in all_signals:
            # Provide helpful error with similar signals using fuzzy matching
            # Split the search term into parts and find signals containing those parts
            search_parts = [p for p in signal_name.lower().split(".") if p]
            similar = []

            # Score each signal based on how many parts match
            scored_signals = []
            for sig in all_signals:
                sig_lower = sig.lower()
                matches = sum(1 for part in search_parts if part in sig_lower)
                if matches > 0:
                    scored_signals.append((matches, sig))

            # Sort by number of matches (descending) and take top matches
            scored_signals.sort(reverse=True, key=lambda x: x[0])
            similar = [sig for _, sig in scored_signals[:5]]

            error_msg = f"Signal '{signal_name}' not found in VCD."
            if similar:
                error_msg += f" Did you mean one of: {similar}?"
            else:
                error_msg += f" Available signals: {all_signals[:10]}..."
            raise SignalNotFoundError(error_msg)

        # Validate signal_condition is callable
        if not callable(signal_condition):
            raise InvalidSignalConditionError(
                f"signal_condition must be callable, got {type(signal_condition).__name__}"
            )

        # Get signal object
        try:
            signal_obj = self.wave[signal_name]
        except Exception as e:
            raise VCDParseError(f"Failed to access signal '{signal_name}': {e}") from e

        # Iterate through ALL time steps (not just deltas)
        out: Set[Time] = set()

        for time in range(0, self.last_clock + 1):
            try:
                # Get raw string values from vcdvcd
                sm1_str: Optional[str] = signal_obj[time - 1] if time > 0 else None
                s_str: str = signal_obj[time]
                sp1_str: Optional[str] = (
                    signal_obj[time + 1] if time < self.last_clock else None
                )

                # Convert values using specified ValueType (None for boundaries)
                sm1: AnyValue = (
                    _convert_value(sm1_str, value_type) if sm1_str is not None else None
                )
                s: AnyValue = _convert_value(s_str, value_type)
                sp1: AnyValue = (
                    _convert_value(sp1_str, value_type) if sp1_str is not None else None
                )

                # Evaluate user's condition
                try:
                    # Tell pyright to ignore this because we have dependent types.
                    check = signal_condition(sm1, s, sp1)  # type: ignore[arg-type]
                except Exception as e:
                    raise InvalidSignalConditionError(
                        f"signal_condition raised exception at time {time}: {e}. "
                        f"Note: signal values can be None (for x/z values or boundaries)."
                    ) from e

                # Add time to result set if condition is True
                if check:
                    out.add(time)

            except InvalidSignalConditionError:
                # Re-raise our own exceptions
                raise
            except Exception as e:
                # Wrap any other errors
                raise VCDParseError(
                    f"Failed to access signal '{signal_name}' at time {time}: {e}"
                ) from e

        return out

    def get_values(
        self,
        signal_name: str,
        timesteps: Set[Time],
        value_type: Optional[ValueType] = None,
    ) -> Union[
        List[Tuple[Time, RawValue]],
        List[Tuple[Time, StringValue]],
        List[Tuple[Time, FPValue]],
    ]:
        """Get signal values at specific timesteps.

        This method takes a set of timesteps (typically from get()) and returns
        the signal values at those times as a sorted list of (time, value) tuples.

        Args:
            signal_name: Exact name of the signal to query (case-sensitive).
                Must exist in the VCD file.
            timesteps: Set of integer timesteps to query. Can be empty.
            value_type: Value conversion type (default: Raw() for backward compatibility).
                - Raw(): Binary to int, x/z become None → List[Tuple[Time, Optional[int]]]
                - String(): Keep raw strings including x/z → List[Tuple[Time, Optional[str]]]
                - FP(frac, signed): Fixed-point to float, x/z → NaN → List[Tuple[Time, Optional[float]]]

        Returns:
            Sorted list of (time, value) tuples. Value type depends on value_type parameter.

        Examples:
            >>> handshakes = valid_times & ready_times
            >>>
            >>> # Get as integers (default)
            >>> int_values = vs.get_values("counter", handshakes)
            >>>
            >>> # Get as strings to see x/z
            >>> str_values = vs.get_values("data_bus", handshakes, String())
            >>>
            >>> # Get as fixed-point floats
            >>> fp_values = vs.get_values("voltage", handshakes, FP(frac=12, signed=False))
        """
        # Default to Raw() if not specified
        if value_type is None:
            value_type = Raw()

        # Validate signal exists
        try:
            all_signals = self.wave.get_signals()
        except Exception as e:
            raise VCDParseError(f"Failed to retrieve signals: {e}") from e

        if signal_name not in all_signals:
            # Provide helpful error with similar signals using fuzzy matching
            search_parts = [p for p in signal_name.lower().split(".") if p]
            similar = []

            # Score each signal based on how many parts match
            scored_signals = []
            for sig in all_signals:
                sig_lower = sig.lower()
                matches = sum(1 for part in search_parts if part in sig_lower)
                if matches > 0:
                    scored_signals.append((matches, sig))

            # Sort by number of matches (descending) and take top matches
            scored_signals.sort(reverse=True, key=lambda x: x[0])
            similar = [sig for _, sig in scored_signals[:5]]

            error_msg = f"Signal '{signal_name}' not found in VCD."
            if similar:
                error_msg += f" Did you mean one of: {similar}?"
            else:
                error_msg += f" Available signals: {all_signals[:10]}..."
            raise SignalNotFoundError(error_msg)

        # Get signal object
        try:
            signal_obj = self.wave[signal_name]
        except Exception as e:
            raise VCDParseError(f"Failed to access signal '{signal_name}': {e}") from e

        # Get values at each timestep and sort by time
        result: List[Tuple[Time, AnyValue]] = []
        for time in timesteps:
            try:
                value_str: str = signal_obj[time]
                value_converted: AnyValue = _convert_value(value_str, value_type)
                result.append((time, value_converted))
            except Exception as e:
                raise VCDParseError(
                    f"Failed to access signal '{signal_name}' at time {time}: {e}"
                ) from e

        # Sort by time
        result.sort(key=lambda x: x[0])

        # Tell pyright to ignore this because we have dependent types.
        return result  # type: ignore[return-value]
