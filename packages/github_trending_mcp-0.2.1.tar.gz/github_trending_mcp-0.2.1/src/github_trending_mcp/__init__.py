"""GitHub Trending MCP Server - Get GitHub trending repositories via MCP protocol.

Supports both stdio and SSE transports.
"""

__version__ = "0.2.1"

from github_trending_mcp.server import main_stdio, main_sse, fetch_trending_repos

__all__ = ["main_stdio", "main_sse", "fetch_trending_repos", "__version__"]

