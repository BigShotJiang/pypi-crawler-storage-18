"""Entry point for python -m github_trending_mcp."""

from github_trending_mcp.server import main_stdio

if __name__ == "__main__":
    main_stdio()

