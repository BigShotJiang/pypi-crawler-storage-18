import os
import sys
import time
import tempfile
import shutil
import threading
import traceback
import locale
from datetime import datetime

try:
    import curses
    import curses.ascii
except Exception:
    curses = None

NAME = "Keltor"
VERSION = "0.1.1"
AUTOSAVE_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "keltorpro")
UNDO_LIMIT = 2000
AUTOSAVE_INTERVAL = 5.0
ENCODING = "utf-8"

class FileManager:
    def __init__(self, autosave_dir):
        self.autosave_dir = autosave_dir
        try:
            os.makedirs(self.autosave_dir, exist_ok=True)
        except Exception:
            pass

    def atomic_write(self, path, text):
        tmp = None
        try:
            d = os.path.dirname(path) or "."
            os.makedirs(d, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".tmp", dir=d)
            with os.fdopen(fd, "w", encoding=ENCODING, newline="\n") as f:
                f.write(text)
            os.replace(tmp, path)
            return True
        except Exception:
            try:
                if tmp and os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            return False

    def read_file(self, path):
        try:
            with open(path, "r", encoding=ENCODING, errors="replace") as f:
                return f.read().splitlines()
        except Exception:
            return None

    def autosave_path(self, session_id):
        try:
            os.makedirs(self.autosave_dir, exist_ok=True)
        except Exception:
            pass
        return os.path.join(self.autosave_dir, f"autosave-{session_id}.keltor")

class UndoManager:
    def __init__(self, limit=UNDO_LIMIT):
        self.limit = limit
        self.stack = []
        self.redo_stack = []

    def snapshot(self, buf):
        if len(self.stack) >= self.limit:
            self.stack.pop(0)
        self.stack.append((list(buf.lines), buf.cx, buf.cy, buf.mode))
        self.redo_stack.clear()

    def undo(self, buf):
        if not self.stack:
            return False
        state = self.stack.pop()
        self.redo_stack.append((list(buf.lines), buf.cx, buf.cy, buf.mode))
        buf.lines, buf.cx, buf.cy, buf.mode = state[0], state[1], state[2], state[3]
        buf.clamp_cursor()
        return True

    def redo(self, buf):
        if not self.redo_stack:
            return False
        state = self.redo_stack.pop()
        self.stack.append((list(buf.lines), buf.cx, buf.cy, buf.mode))
        buf.lines, buf.cx, buf.cy, buf.mode = state[0], state[1], state[2], state[3]
        buf.clamp_cursor()
        return True

class Buffer:
    def __init__(self, filename=None):
        self.filename = filename
        self.lines = [""]
        self.cx = 0
        self.cy = 0
        self.offset = 0
        self.dirty = False
        self.mode = "normal"
        self.message = ""
        self.clipboard = ""
        self.encoding = ENCODING
        if filename:
            self.load(filename)

    def clamp_cursor(self):
        if self.cy < 0:
            self.cy = 0
        if self.cy >= len(self.lines):
            self.cy = max(0, len(self.lines) - 1)
        self.cx = max(0, min(self.cx, len(self.lines[self.cy])))

    def load(self, path):
        fm = FileManager(AUTOSAVE_DIR)
        data = fm.read_file(path)
        if data is None:
            self.message = "Failed to open"
            return False
        self.lines = data or [""]
        self.filename = path
        self.cx = self.cy = self.offset = 0
        self.dirty = False
        self.message = f"Opened {os.path.basename(path)}"
        return True

    def text(self):
        return "\n".join(self.lines)

    def save(self, path=None):
        fm = FileManager(AUTOSAVE_DIR)
        dest = path or self.filename
        if not dest:
            self.message = "No filename"
            return False
        ok = fm.atomic_write(dest, self.text())
        if ok:
            self.dirty = False
            self.message = f"Saved {os.path.basename(dest)}"
            return True
        else:
            self.message = "Save failed"
            return False

    def insert_text(self, s):
        line = self.lines[self.cy]
        left = line[:self.cx]
        right = line[self.cx:]
        new = left + s + right
        self.lines[self.cy] = new
        self.cx += len(s)
        self.dirty = True

    def enter_newline(self):
        line = self.lines[self.cy]
        left = line[:self.cx]
        right = line[self.cx:]
        self.lines[self.cy] = left
        self.lines.insert(self.cy + 1, right)
        self.cy += 1
        self.cx = 0
        self.dirty = True

    def backspace(self):
        if self.cx > 0:
            line = self.lines[self.cy]
            self.lines[self.cy] = line[:self.cx - 1] + line[self.cx:]
            self.cx -= 1
            self.dirty = True
            return
        if self.cy == 0:
            return
        prev = self.lines[self.cy - 1]
        cur = self.lines[self.cy]
        self.cx = len(prev)
        self.lines[self.cy - 1] = prev + cur
        self.lines.pop(self.cy)
        self.cy -= 1
        self.dirty = True

    def delete_char(self):
        line = self.lines[self.cy]
        if self.cx < len(line):
            self.lines[self.cy] = line[:self.cx] + line[self.cx + 1:]
            self.dirty = True
            return
        if self.cy < len(self.lines) - 1:
            self.lines[self.cy] = line + self.lines[self.cy + 1]
            self.lines.pop(self.cy + 1)
            self.dirty = True

    def newline_with_indent(self):
        self.enter_newline()

    def move(self, dy, dx):
        self.cy = max(0, min(self.cy + dy, len(self.lines) - 1))
        self.cx = max(0, min(self.cx + dx, len(self.lines[self.cy])))

    def yank_line(self):
        self.clipboard = self.lines[self.cy]

    def cut_line(self):
        self.clipboard = self.lines[self.cy]
        self.lines.pop(self.cy)
        if self.cy >= len(self.lines):
            self.cy = max(0, len(self.lines) - 1)
        if not self.lines:
            self.lines = [""]
            self.cy = 0
        self.cx = min(self.cx, len(self.lines[self.cy]))
        self.dirty = True

    def paste(self):
        if not self.clipboard:
            return
        line = self.lines[self.cy]
        left = line[:self.cx]
        right = line[self.cx:]
        self.lines[self.cy] = left + self.clipboard + right
        self.cx += len(self.clipboard)
        self.dirty = True

class Editor:
    def __init__(self, stdscr, argv):
        self.stdscr = stdscr
        self.argv = argv
        self.buffers = []
        self.buf_index = 0
        self.running = True
        self.filemgr = FileManager(AUTOSAVE_DIR)
        self.undo = UndoManager()
        self.session_id = f"{int(time.time())}-{os.getpid()}"
        self.autosave_lock = threading.RLock()
        self._init_locale()
        self._init_startup()
        self._start_autosave()
        self.status_message = ""
        self.command = ""
        self.cmd_mode = False
        self.search_term = ""
        self.search_pos = None

    def _init_locale(self):
        try:
            locale.setlocale(locale.LC_ALL, "")
        except Exception:
            pass

    def _init_startup(self):
        fname = None
        if len(self.argv) > 1:
            fname = self.argv[1]
        buf = Buffer(fname)
        if fname:
            buf.load(fname)
        self.buffers.append(buf)

    def current(self):
        return self.buffers[self.buf_index]

    def _start_autosave(self):
        def loop():
            while self.running:
                try:
                    time.sleep(AUTOSAVE_INTERVAL)
                    with self.autosave_lock:
                        buf = self.current()
                        if buf and buf.dirty:
                            path = self.filemgr.autosave_path(self.session_id)
                            self.filemgr.atomic_write(path, buf.text())
                except Exception:
                    pass
        t = threading.Thread(target=loop, daemon=True)
        t.start()

    def run(self):
        if not curses:
            self._cli_fallback()
            return
        try:
            curses.curs_set(1)
        except Exception:
            pass
        self.stdscr.keypad(True)
        while self.running:
            try:
                self._draw()
                ch = self.stdscr.get_wch()
                self._handle_input(ch)
            except KeyboardInterrupt:
                break
            except Exception:
                self._log_exception()
                self.status_message = "Internal error logged"
                time.sleep(0.1)
        try:
            curses.curs_set(1)
        except Exception:
            pass

    def _draw(self):
        try:
            self.stdscr.erase()
            h, w = self.stdscr.getmaxyx()
            buf = self.current()
            view_h = max(1, h - 3)
            for i in range(view_h):
                li = buf.offset + i
                if li >= len(buf.lines):
                    break
                ln = buf.lines[li]
                line_num = f"{li + 1:4d} "
                try:
                    self.stdscr.addstr(i, 0, line_num)
                except Exception:
                    pass
                try:
                    display = ln[:max(0, w - 6)]
                    self.stdscr.addstr(i, 5, display)
                except Exception:
                    pass
            status = self._status_line(w)
            try:
                self.stdscr.addstr(h - 3, 0, status[:w])
            except Exception:
                pass
            if self.cmd_mode:
                cmdline = ":" + self.command
                try:
                    self.stdscr.addstr(h - 2, 0, cmdline[:w])
                except Exception:
                    pass
            else:
                if buf.message:
                    try:
                        self.stdscr.addstr(h - 2, 0, buf.message[:w])
                    except Exception:
                        pass
                    buf.message = ""
                else:
                    helpbar = "CTRL-S save  CTRL-O open  CTRL-Q quit  / search  : commands  i insert  ESC normal  CTRL-Z undo  CTRL-Y redo"
                    try:
                        self.stdscr.addstr(h - 2, 0, helpbar[:w])
                    except Exception:
                        pass
            try:
                self.stdscr.addstr(h - 1, 0, self.status_message[:w])
            except Exception:
                pass
            cy = buf.cy - buf.offset
            cx = buf.cx + 5
            if cy < 0:
                buf.offset = buf.cy
                cy = 0
            h, w = self.stdscr.getmaxyx()
            view_h = max(1, h - 3)
            if buf.cy >= buf.offset + view_h:
                buf.offset = buf.cy - view_h + 1
                cy = buf.cy - buf.offset
            try:
                if 0 <= cy < view_h and cx < w:
                    self.stdscr.move(cy, cx)
            except Exception:
                pass
            self.stdscr.refresh()
        except Exception:
            self._log_exception()

    def _status_line(self, w):
        buf = self.current()
        name = buf.filename or "[NoName]"
        mode = buf.mode
        pos = f"Ln {buf.cy + 1}, Col {buf.cx + 1}"
        dirty = "*" if buf.dirty else ""
        return f"{NAME} {VERSION} - {name}{dirty}  {mode}  {pos}"

    def _handle_input(self, ch):
        buf = self.current()
        if isinstance(ch, str) and ch == ":" and not self.cmd_mode and buf.mode == "normal":
            self.cmd_mode = True
            self.command = ""
            return
        if self.cmd_mode:
            if ch == "\n" or ch == "\r":
                self._execute_command(self.command.strip())
                self.cmd_mode = False
                self.command = ""
                return
            if ch in ("\x1b",):
                self.cmd_mode = False
                self.command = ""
                return
            if isinstance(ch, str):
                if ch == "\x7f":
                    self.command = self.command[:-1]
                else:
                    self.command += ch
            return
        if buf.mode == "insert":
            if ch in (curses.ascii.ESC, "\x1b"):
                buf.mode = "normal"
                return
            if ch in ("\n", "\r"):
                self.undo.snapshot(buf)
                buf.enter_newline()
                return
            if ch in ("\x7f", curses.KEY_BACKSPACE):
                self.undo.snapshot(buf)
                buf.backspace()
                return
            if isinstance(ch, str):
                self.undo.snapshot(buf)
                buf.insert_text(ch)
                return
            if ch == curses.KEY_DC:
                self.undo.snapshot(buf)
                buf.delete_char()
                return
            return
        if buf.mode == "normal":
            if ch in (curses.KEY_DOWN, "j"):
                buf.move(1, 0)
                return
            if ch in (curses.KEY_UP, "k"):
                buf.move(-1, 0)
                return
            if ch in (curses.KEY_LEFT, "h"):
                buf.move(0, -1)
                return
            if ch in (curses.KEY_RIGHT, "l"):
                buf.move(0, 1)
                return
            if ch in ("i",):
                buf.mode = "insert"
                return
            if ch in ("I",):
                buf.cx = 0
                buf.mode = "insert"
                return
            if ch in ("a",):
                buf.cx = min(len(buf.lines[buf.cy]), buf.cx + 1)
                buf.mode = "insert"
                return
            if ch in ("A",):
                buf.cx = len(buf.lines[buf.cy])
                buf.mode = "insert"
                return
            if ch in ("o",):
                self.undo.snapshot(buf)
                line = buf.lines[buf.cy]
                right = line[buf.cx:]
                buf.lines[buf.cy] = line[:buf.cx]
                buf.cy += 1
                buf.lines.insert(buf.cy, right)
                buf.cx = 0
                buf.mode = "insert"
                buf.dirty = True
                return
            if ch in ("\n", "\r"):
                return
            if ch in ("/",):
                self._start_search()
                return
            if ch in (":",):
                self.cmd_mode = True
                self.command = ""
                return
            if ch == "\x13":
                self._cmd_save()
                return
            if ch == "\x0f":
                self._cmd_open_prompt()
                return
            if ch == "\x11":
                self._cmd_quit()
                return
            if ch == "\x1a":
                self.undo.undo(buf)
                return
            if ch == "\x19":
                self.undo.redo(buf)
                return
            if ch == "\x07":
                buf.yank_line()
                buf.message = "Yanked line"
                return
            if ch == "\x0b":
                self.undo.snapshot(buf)
                buf.cut_line()
                return
            if ch == "\x10":
                buf.paste()
                return
            if ch == "\x06":
                self._goto_line_prompt()
                return
            return

    def _start_search(self):
        buf = self.current()
        prompt = "Search: "
        term = self._prompt(prompt)
        if not term:
            buf.message = "Search canceled"
            return
        self.search_term = term
        for y, line in enumerate(buf.lines):
            x = line.find(term)
            if x != -1:
                buf.cy = y
                buf.cx = x
                buf.message = f"Found at Ln {y + 1}"
                return
        buf.message = "Not found"

    def _goto_line_prompt(self):
        s = self._prompt("Goto line: ")
        try:
            n = int(s) - 1
            buf = self.current()
            if 0 <= n < len(buf.lines):
                buf.cy = n
                buf.cx = 0
                buf.message = f"Goto {n + 1}"
            else:
                buf.message = "Out of range"
        except Exception:
            buf.message = "Invalid number"

    def _prompt(self, prompt):
        if not curses:
            try:
                return input(prompt).strip()
            except Exception:
                return ""
        h, w = self.stdscr.getmaxyx()
        try:
            curses.echo()
        except Exception:
            pass
        try:
            self.stdscr.move(h - 2, 0)
            self.stdscr.clrtoeol()
            self.stdscr.addstr(h - 2, 0, prompt)
            self.stdscr.refresh()
            win = curses.newwin(1, max(10, w - len(prompt) - 1), h - 2, len(prompt))
            curses.curs_set(1)
            s = win.getstr().decode(errors="replace")
            try:
                curses.curs_set(1)
            except Exception:
                pass
            return s.strip()
        except Exception:
            try:
                return input(prompt).strip()
            except Exception:
                return ""
        finally:
            try:
                curses.noecho()
            except Exception:
                pass

    def _execute_command(self, cmd):
        parts = cmd.split()
        if not parts:
            return
        name = parts[0]
        args = parts[1:]
        if name in ("w", "write"):
            if args:
                self.current().save(args[0])
            else:
                self._cmd_save()
            return
        if name in ("q", "quit"):
            if self.current().dirty and name != "q!":
                self.current().message = "Unsaved changes"
                return
            self._cmd_quit(force=True)
            return
        if name in ("wq", "x"):
            ok = self._cmd_save()
            if ok:
                self._cmd_quit(force=True)
            return
        if name in ("e", "edit", "open"):
            path = args[0] if args else None
            if path:
                buf = Buffer(path)
                loaded = buf.load(path)
                if loaded:
                    self.buffers[self.buf_index] = buf
                else:
                    self.current().message = "Open failed"
            else:
                self._cmd_open_prompt()
            return
        if name in ("bn", "bnext"):
            self.buf_index = (self.buf_index + 1) % len(self.buffers)
            return
        if name in ("bp", "bprev"):
            self.buf_index = (self.buf_index - 1) % len(self.buffers)
            return
        if name in ("help",):
            self.current().message = "Commands: w q wq e bn bp help"
            return
        self.current().message = f"Unknown command {name}"

    def _cmd_save(self):
        buf = self.current()
        if buf.filename:
            return buf.save()
        name = self._prompt("Save as: ")
        if not name:
            buf.message = "Save canceled"
            return False
        ok = buf.save(name)
        return ok

    def _cmd_open_prompt(self):
        path = self._prompt("Open file: ")
        if not path:
            self.current().message = "Open canceled"
            return
        buf = Buffer(path)
        loaded = buf.load(path)
        if loaded:
            self.buffers[self.buf_index] = buf
        else:
            self.current().message = "Open failed"

    def _cmd_quit(self, force=False):
        buf = self.current()
        if not force and buf.dirty:
            buf.message = "Unsaved changes"
            return
        self.running = False

    def _cli_fallback(self):
        print(f"{NAME} {VERSION} - CLI fallback")
        buf = self.current()
        while True:
            try:
                cmd = input("cmd(open/save/new/quit/lines/insert): ").strip().lower()
                if cmd == "open":
                    p = input("path: ").strip()
                    if p:
                        buf.load(p)
                elif cmd == "save":
                    if not buf.filename:
                        p = input("save as: ").strip()
                        if p:
                            buf.save(p)
                    else:
                        buf.save()
                elif cmd == "new":
                    buf.lines = [""]
                    buf.filename = None
                    buf.cx = buf.cy = buf.offset = 0
                elif cmd == "insert":
                    s = input("text: ")
                    buf.insert_text(s)
                elif cmd == "lines":
                    for i, l in enumerate(buf.lines, 1):
                        print(f"{i}: {l}")
                elif cmd == "quit":
                    if buf.dirty:
                        c = input("Unsaved changes, quit anyway? (y/n): ").strip().lower()
                        if c == "y":
                            break
                    else:
                        break
                else:
                    print("unknown")
            except KeyboardInterrupt:
                break
            except Exception:
                traceback.print_exc()
                break

    def _log_exception(self):
        try:
            logdir = AUTOSAVE_DIR
            os.makedirs(logdir, exist_ok=True)
            logfile = os.path.join(logdir, "keltorpro_error.log")
            with open(logfile, "a", encoding=ENCODING) as f:
                f.write(f"[{datetime.utcnow().isoformat()}]\n")
                f.write(traceback.format_exc() + "\n\n")
        except Exception:
            pass

def main():
    argv = sys.argv
    if curses:
        try:
            curses.wrapper(lambda s: Editor(s, argv).run())
            return
        except Exception:
            traceback.print_exc()
    Editor(None, argv)._cli_fallback()

if __name__ == "__main__":
    main()