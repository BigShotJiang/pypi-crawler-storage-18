"""Data models for Todo CLI."""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional


class Priority(Enum):
    """Task priority levels."""
    P0 = 0  # Critical/Urgent
    P1 = 1  # High priority
    P2 = 2  # Medium priority
    P3 = 3  # Low priority

    def __str__(self) -> str:
        return self.name


class Status(Enum):
    """Task status."""
    TODO = "todo"
    DOING = "doing"
    DONE = "done"

    def __str__(self) -> str:
        return self.value


@dataclass
class Todo:
    """A todo item with time tracking."""
    id: int
    task: str
    priority: Priority = Priority.P2
    status: Status = Status.TODO
    project: Optional[str] = None
    project_id: Optional[int] = None
    tags: list[str] = field(default_factory=list)
    due_date: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    time_spent: timedelta = field(default_factory=lambda: timedelta())
    timer_started: Optional[datetime] = None

    @property
    def is_tracking(self) -> bool:
        """Check if timer is currently running."""
        return self.timer_started is not None

    @property
    def total_time(self) -> timedelta:
        """Get total time including current tracking session."""
        if self.timer_started:
            return self.time_spent + (datetime.now() - self.timer_started)
        return self.time_spent

    def format_time(self) -> str:
        """Format total time as HH:MM:SS."""
        total = self.total_time
        hours, remainder = divmod(int(total.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    @property
    def is_overdue(self) -> bool:
        """Check if task is overdue."""
        if self.due_date and self.status != Status.DONE:
            return datetime.now() > self.due_date
        return False
