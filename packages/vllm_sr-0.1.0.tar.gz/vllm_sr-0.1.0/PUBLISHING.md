# Publishing vllm-sr to PyPI

This guide explains how to publish the `vllm-sr` CLI package to PyPI.

## Prerequisites

### 1. PyPI Account Setup

1. Create accounts on:
   - **PyPI (Production)**: https://pypi.org/account/register/
   - **Test PyPI (Testing)**: https://test.pypi.org/account/register/

2. Enable 2FA (Two-Factor Authentication) on both accounts

3. Create API tokens:
   - **PyPI**: https://pypi.org/manage/account/token/
   - **Test PyPI**: https://test.pypi.org/manage/account/token/

### 2. GitHub Secrets Setup

Add the following secrets to your GitHub repository:
- Go to: `Settings` → `Secrets and variables` → `Actions` → `New repository secret`

Required secrets:
- `PYPI_API_TOKEN`: Your PyPI API token (starts with `pypi-`)
- `TEST_PYPI_API_TOKEN`: Your Test PyPI API token (optional, for testing)

## Publishing Process

### Method 1: Automatic Publishing (Recommended)

This method automatically publishes when you push a version tag.

#### Step 1: Update Version

Edit `src/vllm-sr-cli/pyproject.toml`:

```toml
[project]
name = "vllm-sr"
version = "0.1.0"  # Update this version
```

#### Step 2: Commit and Tag

```bash
cd src/vllm-sr-cli

# Commit version change
git add pyproject.toml
git commit -m "Bump version to 0.1.0"

# Create and push tag
git tag v0.1.0
git push origin main
git push origin v0.1.0
```

#### Step 3: Monitor Workflow

The GitHub Action will automatically:
1. Build the package
2. Verify version matches tag
3. Publish to PyPI
4. Create a GitHub Release

Check progress at: `Actions` → `Publish Python Package to PyPI`

### Method 2: Manual Publishing

For testing or manual control:

#### Step 1: Test on Test PyPI (Optional)

```bash
# Trigger manual workflow
# Go to: Actions → Publish Python Package to PyPI → Run workflow
# Enter version: 0.1.0
# This publishes to Test PyPI
```

Test installation:
```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ vllm-sr==0.1.0
```

#### Step 2: Publish to Production PyPI

Follow the automatic publishing steps above (create tag and push).

### Method 3: Local Publishing (Advanced)

For local testing or emergency publishing:

```bash
cd src/vllm-sr-cli

# Install build tools
pip install build twine

# Build package
python -m build

# Check package
twine check dist/*

# Upload to Test PyPI (optional)
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

## Post-Publishing

### Verify Installation

```bash
# Install from PyPI
pip install vllm-sr==0.1.0

# Verify version
vllm-sr --version

# Test basic functionality
vllm-sr --help
```

### Update Documentation

Update the following files with the new version:
- `README.md` - Installation instructions
- `QUICKSTART.md` - Quick start guide
- Release notes on GitHub

## Version Numbering

Follow [Semantic Versioning](https://semver.org/):

- `MAJOR.MINOR.PATCH` (e.g., `1.2.3`)
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes (backward compatible)

Examples:
- `0.1.0` - Initial release
- `0.1.1` - Bug fix
- `0.2.0` - New feature
- `1.0.0` - First stable release

## Troubleshooting

### Version Mismatch Error

```
Package version (0.1.0) does not match tag version (0.2.0)
```

**Solution**: Update version in `pyproject.toml` to match the tag.

### Authentication Error

```
403 Forbidden: Invalid or non-existent authentication information
```

**Solution**: 
1. Verify `PYPI_API_TOKEN` secret is set correctly
2. Ensure token has upload permissions
3. Check token hasn't expired

### Package Already Exists

```
400 Bad Request: File already exists
```

**Solution**: You cannot overwrite existing versions. Increment the version number.

### Import Error After Installation

```
ModuleNotFoundError: No module named 'cli'
```

**Solution**: Check `[tool.setuptools]` packages configuration in `pyproject.toml`.

## Package Information

- **Package Name**: `vllm-sr`
- **PyPI URL**: https://pypi.org/project/vllm-sr/
- **Source Code**: https://github.com/vllm-project/vllm-semantic-router
- **Documentation**: https://github.com/vllm-project/vllm-semantic-router/blob/main/README.md

## Support

For issues or questions:
- GitHub Issues: https://github.com/vllm-project/vllm-semantic-router/issues
- Discussions: https://github.com/vllm-project/vllm-semantic-router/discussions

