# Quick Start - Local Development

## TL;DR

```bash
cd src/vllm-sr-cli

# 1. Build Docker image + Install CLI
make dev-setup

# 2. Start service
vllm-sr serve vsr_config.yaml

# Done! Service running on http://localhost:8801
```

## Step-by-Step Guide

### Step 1: Build Docker Image

```bash
cd src/vllm-sr-cli
make docker-build
```

This builds the `vllm-sr:dev` Docker image. Takes 5-10 minutes on first build.

### Step 2: Install CLI

```bash
make install
```

This installs the `vllm-sr` command in development mode.

### Step 3: Verify Installation

```bash
vllm-sr --version
```

### Step 4: Start Service

```bash
vllm-sr serve vsr_config.yaml
```

The CLI will:
- ✓ Automatically use `vllm-sr:dev` image
- ✓ Generate router and Envoy configurations
- ✓ Start services in Docker container
- ✓ Listen on port 8801

### Step 5: Test Service

```bash
# In another terminal
curl http://localhost:8801/healthz
```

## Common Commands

### Start Service

```bash
# Default config
vllm-sr serve vsr_config.yaml

# Custom port
vllm-sr serve vsr_config.yaml --port 9000

# Foreground mode (see logs)
vllm-sr serve vsr_config.yaml --foreground

# Custom config
vllm-sr serve ../../examples/test_fact_check.yaml
```

### View Logs

```bash
vllm-sr logs

# Follow logs
vllm-sr logs --follow
```

### Stop Service

```bash
vllm-sr stop
```

### Check Status

```bash
vllm-sr status
```

### Generate Configs Only

```bash
vllm-sr generate vsr_config.yaml
```

### Validate Config

```bash
vllm-sr validate vsr_config.yaml
```

### Show All Configs

```bash
vllm-sr show-config vsr_config.yaml
```

## Using Makefile

### Quick Commands

```bash
# Complete setup (build + install)
make dev-setup

# Start service (builds if needed)
make dev-serve

# Test config generation
make dev-test

# Stop service
make docker-stop

# View logs
make docker-logs
```

### Custom Config

```bash
make dev-serve CONFIG_FILE=../../examples/test_fact_check.yaml
```

### Custom Image

```bash
make docker-build IMAGE_NAME=my-vllm-sr IMAGE_TAG=v1.0
```

## Troubleshooting

### "Docker image not found"

**Problem:**
```
No Docker image found!
```

**Solution:**
```bash
make docker-build
```

### "Port already in use"

**Problem:**
```
port is already allocated
```

**Solution:**
```bash
# Stop existing container
vllm-sr stop

# Or use different port
vllm-sr serve config.yaml --port 9000
```

### "Config file not found"

**Problem:**
```
Config file not found: vsr_config.yaml
```

**Solution:**
```bash
# Use absolute path
vllm-sr serve /path/to/config.yaml

# Or relative path
vllm-sr serve ../../examples/test_fact_check.yaml
```

### Rebuild Image

```bash
# Clean and rebuild
make clean
make docker-build
```

## What Gets Created

When you run `vllm-sr serve`:

```
.vllm-sr/
├── router-config.yaml      # Merged router configuration
├── envoy-config.yaml       # Generated Envoy configuration
└── router-defaults.yaml    # Reference defaults
```

## Docker Container

The service runs in a Docker container named `vllm-sr-container` with:

- **Envoy**: Port 8801 (HTTP proxy)
- **Router**: Port 50051 (gRPC ExtProc)
- **API**: Port 8080 (Router API)
- **Metrics**: Port 9190 (Prometheus)
- **Admin**: Port 9901 (Envoy admin)

## Next Steps

1. **Customize config**: Edit `vsr_config.yaml`
2. **Add models**: Configure your vLLM endpoints
3. **Test routing**: Send requests to port 8801
4. **Monitor**: Check metrics on port 9190

## Full Documentation

- [Development Guide](DEV_GUIDE.md) - Detailed development workflow
- [Configuration Design](../../docs/CONFIG_DESIGN.md) - Config file format
- [Quick Start Guide](../../docs/QUICK_START.md) - Complete guide

