"""Core management functions for vLLM Semantic Router."""

import time
import sys
from cli.utils import getLogger, load_config, wait_for_healthy, get_envoy_port
from cli.consts import (
    VLLM_SR_DOCKER_NAME,
    HEALTH_CHECK_TIMEOUT,
    DEFAULT_API_PORT,
)
from cli.docker_cli import (
    docker_container_status,
    docker_stop_container,
    docker_remove_container,
    docker_start_vllm_sr,
    docker_logs,
)
from cli.logo import print_vllm_logo

log = getLogger(__name__)


def start_vllm_sr(config_file, env_vars=None, foreground=False, image=None, pull_policy=None):
    """
    Start vLLM Semantic Router.

    Args:
        config_file: Path to config.yaml
        env_vars: Environment variables dict (optional)
        foreground: Whether to run in foreground mode
        image: Docker image to use (optional)
        pull_policy: Image pull policy (optional)
    """
    if env_vars is None:
        env_vars = {}

    # Print vLLM logo
    print_vllm_logo()

    # Load config to get listeners
    config = load_config(config_file)
    listeners = config.get('listeners', [])

    if not listeners:
        log.error("No listeners configured in config.yaml")
        sys.exit(1)

    log.info(f"Starting vLLM Semantic Router")
    log.info(f"Config file: {config_file}")
    log.info(f"Configured listeners:")
    for listener in listeners:
        name = listener.get('name', 'unknown')
        port = listener.get('port', 'unknown')
        address = listener.get('address', '0.0.0.0')
        log.info(f"  - {name}: {address}:{port}")

    # Check if container already exists
    status = docker_container_status(VLLM_SR_DOCKER_NAME)
    if status != 'not found':
        log.info(f"Existing container found (status: {status}), cleaning up...")
        docker_stop_container(VLLM_SR_DOCKER_NAME)
        docker_remove_container(VLLM_SR_DOCKER_NAME)

    # Start container
    return_code, stdout, stderr = docker_start_vllm_sr(
        config_file,
        env_vars,
        listeners,
        image=image,
        pull_policy=pull_policy
    )

    if return_code != 0:
        log.error(f"Failed to start container: {stderr}")
        sys.exit(1)

    log.info("✓ Container started successfully")

    # Wait for services to be healthy
    log.info("Waiting for Router to become healthy...")

    # Check Router health endpoint inside container (API server on port 8080)
    # Use docker exec to check health from inside the container
    import time
    start_time = time.time()
    healthy = False
    while time.time() - start_time < HEALTH_CHECK_TIMEOUT:
        from cli.docker_cli import docker_exec
        return_code, stdout, stderr = docker_exec(
            VLLM_SR_DOCKER_NAME,
            ['curl', '-f', '-s', f'http://localhost:{DEFAULT_API_PORT}/health']
        )
        if return_code == 0:
            log.info(f"✓ Router is healthy")
            healthy = True
            break
        time.sleep(2)

    if not healthy:
        log.error("Router failed to become healthy")
        log.info("Showing container logs:")
        docker_logs(VLLM_SR_DOCKER_NAME, follow=False)
        sys.exit(1)
    
    # Check container status
    status = docker_container_status(VLLM_SR_DOCKER_NAME)
    if status == 'exited':
        log.error("Container exited unexpectedly")
        log.info("Showing container logs:")
        docker_logs(VLLM_SR_DOCKER_NAME, follow=False)
        sys.exit(1)
    
    log.info("=" * 60)
    log.info("✓ vLLM Semantic Router is running!")
    log.info("Listeners:")
    for listener in listeners:
        name = listener.get('name', 'unknown')
        port = listener.get('port', 'unknown')
        log.info(f"  - {name}: http://localhost:{port}")
    log.info(f"  Metrics: http://localhost:9190/metrics")
    log.info("=" * 60)
    log.info("")
    log.info("To view logs: vllm-sr logs")
    log.info("To stop: vllm-sr stop")
    log.info("")
    
    # If foreground mode, stream logs
    if foreground:
        log.info("Running in foreground mode. Press Ctrl+C to stop.")
        try:
            docker_logs(VLLM_SR_DOCKER_NAME, follow=True)
        except KeyboardInterrupt:
            log.info("\nStopping vLLM Semantic Router...")
            stop_vllm_sr()


def stop_vllm_sr():
    """Stop vLLM Semantic Router."""
    log.info("Stopping vLLM Semantic Router...")
    
    status = docker_container_status(VLLM_SR_DOCKER_NAME)
    if status == 'not found':
        log.info("Container not found. Nothing to stop.")
        return
    
    if status == 'running':
        docker_stop_container(VLLM_SR_DOCKER_NAME)
    
    docker_remove_container(VLLM_SR_DOCKER_NAME)
    log.info("✓ vLLM Semantic Router stopped")


def show_logs(follow=False):
    """Show logs from vLLM Semantic Router."""
    status = docker_container_status(VLLM_SR_DOCKER_NAME)
    if status == 'not found':
        log.error("Container not found. Is vLLM Semantic Router running?")
        log.info("Start it with: vllm-sr serve <config.yaml>")
        sys.exit(1)
    
    docker_logs(VLLM_SR_DOCKER_NAME, follow=follow)


def show_status():
    """Show status of vLLM Semantic Router."""
    status = docker_container_status(VLLM_SR_DOCKER_NAME)
    
    if status == 'not found':
        log.info("Status: Not running")
        log.info("Start with: vllm-sr serve <config.yaml>")
    elif status == 'running':
        log.info("Status: Running ✓")
        log.info(f"Container: {VLLM_SR_DOCKER_NAME}")
    elif status == 'exited':
        log.info("Status: Exited (error)")
        log.info("View logs with: vllm-sr logs")
    else:
        log.info(f"Status: {status}")

