"""vLLM Semantic Router CLI main entry point."""

import click
import os
import sys
from cli import __version__
from cli.utils import getLogger, find_config_file
from cli.core import start_vllm_sr, stop_vllm_sr, show_logs, show_status
from cli.consts import (
    DEFAULT_ENVOY_PORT,
    VLLM_SR_DOCKER_IMAGE_DEFAULT,
    IMAGE_PULL_POLICY_ALWAYS,
    IMAGE_PULL_POLICY_IF_NOT_PRESENT,
    IMAGE_PULL_POLICY_NEVER,
    DEFAULT_IMAGE_PULL_POLICY,
)
from cli.commands import (
    serve_command,
    generate_command,
    validate_command,
    show_defaults_command,
    show_config_command
)

log = getLogger(__name__)

# ASCII logo
logo = r"""
       _ _     __  __       ____  ____  
__   _| | |_ _|  \/  |     / ___||  _ \ 
\ \ / / | | | | |\/| |_____\___ \| |_) |
 \ V /| | | |_| | |  |_____|___) |  _ < 
  \_/ |_|_|\__,_|_|  |     |____/|_| \_\
                                         
vLLM Semantic Router - Intelligent routing for vLLM
"""


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, help="Show version and exit.")
@click.pass_context
def main(ctx, version):
    """vLLM Semantic Router CLI - Intelligent routing and caching for vLLM endpoints."""
    if version:
        click.echo(f"vllm-sr version: {__version__}")
        ctx.exit()
    
    if ctx.invoked_subcommand is None:
        click.echo(logo)
        click.echo(ctx.get_help())


@click.command()
@click.argument("config_file", required=False)
@click.option(
    "--path",
    default=".",
    help="Path to directory containing config.yaml (if config_file not specified)"
)
@click.option(
    "--foreground",
    is_flag=True,
    help="Run in foreground and stream logs (Ctrl+C to stop)"
)
@click.option(
    "--image",
    default=None,
    help=f"Docker image to use (default: {VLLM_SR_DOCKER_IMAGE_DEFAULT})"
)
@click.option(
    "--image-pull-policy",
    type=click.Choice([IMAGE_PULL_POLICY_ALWAYS, IMAGE_PULL_POLICY_IF_NOT_PRESENT, IMAGE_PULL_POLICY_NEVER], case_sensitive=False),
    default=DEFAULT_IMAGE_PULL_POLICY,
    help=f"Image pull policy: always, ifnotpresent, never (default: {DEFAULT_IMAGE_PULL_POLICY})"
)
def serve(config_file, path, foreground, image, image_pull_policy):
    """
    Start vLLM Semantic Router.

    Ports are configured in config.yaml under 'listeners' section.

    Examples:
        # Basic usage
        vllm-sr serve config.yaml
        vllm-sr serve config.yaml --foreground

        # Custom image
        vllm-sr serve config.yaml --image ghcr.io/vllm-project/semantic-router/vllm-sr:latest
        vllm-sr serve config.yaml --image vllm-sr:dev

        # Pull policy
        vllm-sr serve config.yaml --image-pull-policy always
        vllm-sr serve config.yaml --image-pull-policy ifnotpresent
        vllm-sr serve config.yaml --image-pull-policy never
    """
    try:
        # Find config file
        if not config_file:
            config_file = find_config_file(path)
        else:
            config_file = os.path.abspath(config_file)

        # Check if file exists
        if not os.path.exists(config_file):
            log.error(f"Config file not found: {config_file}")
            sys.exit(1)

        log.info(f"Using config file: {config_file}")

        # Start container
        start_vllm_sr(
            config_file=config_file,
            foreground=foreground,
            image=image,
            pull_policy=image_pull_policy
        )

    except KeyboardInterrupt:
        log.info("\nInterrupted by user")
        sys.exit(0)
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
def stop():
    """
    Stop vLLM Semantic Router.
    
    Examples:
        vllm-sr stop
    """
    try:
        stop_vllm_sr()
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    help="Follow log output (like tail -f)"
)
def logs(follow):
    """
    Show logs from vLLM Semantic Router.
    
    Examples:
        vllm-sr logs
        vllm-sr logs --follow
        vllm-sr logs -f
    """
    try:
        show_logs(follow=follow)
    except KeyboardInterrupt:
        log.info("\nLog streaming stopped")
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
def status():
    """
    Show status of vLLM Semantic Router.
    
    Examples:
        vllm-sr status
    """
    try:
        show_status()
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
@click.argument("config_file")
@click.option(
    "--output-dir",
    default=".vllm-sr",
    help="Output directory for generated configs (default: .vllm-sr)"
)
@click.option(
    "--force",
    is_flag=True,
    help="Force overwrite existing files"
)
def generate(config_file, output_dir, force):
    """
    Generate configurations without starting services.

    Examples:
        vllm-sr generate config.yaml
        vllm-sr generate config.yaml --output-dir ./configs
        vllm-sr generate config.yaml --force
    """
    try:
        generate_command(config_file, output_dir, force)
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
@click.argument("config_file")
def validate(config_file):
    """
    Validate configuration file.

    Examples:
        vllm-sr validate config.yaml
    """
    try:
        validate_command(config_file)
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
@click.option(
    "--output",
    "-o",
    help="Output file path (default: print to stdout)"
)
def show_defaults(output):
    """
    Show embedded default configuration.

    Examples:
        vllm-sr show-defaults
        vllm-sr show-defaults --output defaults.yaml
        vllm-sr show-defaults -o defaults.yaml
    """
    try:
        show_defaults_command(output)
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


@click.command()
@click.argument("config_file")
@click.option(
    "--output-dir",
    default=".vllm-sr",
    help="Output directory for generated configs (default: .vllm-sr)"
)
@click.option(
    "--user-only",
    is_flag=True,
    help="Show only user configuration"
)
@click.option(
    "--router-only",
    is_flag=True,
    help="Show only router configuration"
)
@click.option(
    "--envoy-only",
    is_flag=True,
    help="Show only Envoy configuration"
)
@click.option(
    "--full",
    is_flag=True,
    help="Show full configuration without truncation"
)
def show_config(config_file, output_dir, user_only, router_only, envoy_only, full):
    """
    Show all configurations (user, router, envoy).

    Examples:
        vllm-sr show-config config.yaml
        vllm-sr show-config config.yaml --full
        vllm-sr show-config config.yaml --user-only
        vllm-sr show-config config.yaml --router-only
        vllm-sr show-config config.yaml --envoy-only
    """
    try:
        # Determine what to show
        show_user = True
        show_router = True
        show_envoy = True

        if user_only:
            show_router = False
            show_envoy = False
        elif router_only:
            show_user = False
            show_envoy = False
        elif envoy_only:
            show_user = False
            show_router = False

        show_config_command(
            config_file,
            output_dir,
            show_user,
            show_router,
            show_envoy,
            full
        )
    except Exception as e:
        log.error(f"Error: {e}")
        sys.exit(1)


# Register commands
main.add_command(serve)
main.add_command(stop)
main.add_command(logs)
main.add_command(status)
main.add_command(generate)
main.add_command(validate)
main.add_command(show_defaults)
main.add_command(show_config)


if __name__ == "__main__":
    main()

