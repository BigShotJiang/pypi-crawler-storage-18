# vLLM Semantic Router CLI

Intelligent routing and caching for vLLM endpoints with semantic understanding.

## Features

- 🎯 **Semantic Routing**: Intelligent request routing based on content classification
- 💾 **Semantic Caching**: Cache responses based on semantic similarity
- 🔒 **PII Detection**: Automatic detection and handling of sensitive information
- 🛡️ **Prompt Guard**: Jailbreak detection and prevention
- 📊 **Observability**: Built-in metrics and tracing support
- 🚀 **Easy Deployment**: One-command Docker-based deployment

## Quick Start

### Installation

```bash
# Install from PyPI (when published)
pip install vllm-sr

# Or install from source (development)
cd src/vllm-sr-cli
pip install -e .
```

### Usage

```bash
# Start vLLM Semantic Router
vllm-sr serve config.yaml

# Start with custom port
vllm-sr serve config.yaml --port 8801

# Run in foreground (stream logs)
vllm-sr serve config.yaml --foreground

# View logs
vllm-sr logs
vllm-sr logs --follow

# Check status
vllm-sr status

# Stop
vllm-sr stop
```

## Development

### Build Docker Image

```bash
# From repository root
docker build -t vllm-sr:dev -f src/vllm-sr-cli/Dockerfile .
```

### Install CLI (Development Mode)

```bash
cd src/vllm-sr-cli
pip install -e .
```

### Run

```bash
# The CLI will automatically use vllm-sr:dev if it exists
vllm-sr serve config/config.yaml
```

## Configuration

The CLI uses the same `config.yaml` format as the semantic router. See `config/config.yaml` for a complete example.

Key configuration sections:
- `vllm_endpoints`: Define your vLLM backend endpoints
- `model_config`: Configure model-specific settings
- `semantic_cache`: Enable and configure semantic caching
- `prompt_guard`: Configure jailbreak detection
- `classifier`: Configure domain and PII classification

## Architecture

```
vllm-sr CLI (Python)
    ↓
Docker Container
    ├── supervisord
    │   ├── router (Go ExtProc) :50051
    │   ├── envoy :8801
    │   └── log tailer
    └── Configuration
```

## Ports

- **8801**: Envoy HTTP endpoint (main entry point)
- **50051**: Router gRPC (ExtProc)
- **8080**: Router API (health, metrics, admin)
- **9190**: Prometheus metrics
- **9901**: Envoy admin interface

## Environment Variables

- `VLLM_SR_IMAGE`: Override Docker image (default: auto-detect)
- `ROUTER_CONFIG_FILE`: Router config path (default: `/app/config.yaml`)
- `ENVOY_TEMPLATE_FILE`: Envoy template path (default: `envoy.template.yaml`)
- `ENVOY_CONFIG_FILE`: Envoy output path (default: `/etc/envoy/envoy.yaml`)

## Troubleshooting

### Container won't start

```bash
# Check logs
vllm-sr logs

# Check Docker
docker ps -a | grep vllm-sr
docker logs vllm-sr-container
```

### Port already in use

```bash
# Use a different port
vllm-sr serve config.yaml --port 8802
```

### Image not found

```bash
# Build the image first
docker build -t vllm-sr:dev -f src/vllm-sr-cli/Dockerfile .
```

## License

Apache 2.0

