# MCP Server Demo

A demo Model Context Protocol (MCP) server providing weather information and basic utility tools.

## Features

- **Weather Information**: Get real-time weather data via Amap API.
- **Cat Tool**: A simple demonstration tool.
- **MCP Integration**: Fully compatible with MCP clients like Claude Desktop.

## Installation

```bash
pip install mcp-server-demo-supine
```

## Usage

### Running the server

You can run the server directly using the installed script:

```bash
mcp-server-demo-supine
```

Or via python:

```bash
python server.py
```

### Configuration for Claude Desktop

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mcp-server-demo-supine": {
      "command": "mcp-server-demo-supine"
    }
  }
}
```

## Development

This project uses `uv` for dependency management.

```bash
uv sync
uv build
```

## License

MIT
