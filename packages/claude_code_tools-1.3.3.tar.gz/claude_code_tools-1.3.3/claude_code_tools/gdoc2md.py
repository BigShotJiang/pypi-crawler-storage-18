#!/usr/bin/env python3
"""
gdoc2md: Export Google Docs to Markdown with comments preserved.

Comments are inserted inline as HTML comments: <!-- comment text -->
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Optional

import click

# Google API imports
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
except ImportError:
    click.echo(
        "ERROR: Google API libraries not installed.\n"
        "Run: uv tool install 'claude-code-tools[google]'",
        err=True,
    )
    sys.exit(1)

# OAuth scopes
SCOPES = [
    "https://www.googleapis.com/auth/documents.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
]

# Config directory
CONFIG_DIR = Path.home() / ".gdoc2md"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"
TOKEN_FILE = CONFIG_DIR / "token.json"


def get_credentials() -> Optional[Credentials]:
    """
    Get Google API credentials using OAuth2.

    Returns:
        Credentials object if successful, None if not authenticated.
    """
    if not TOKEN_FILE.exists():
        return None

    creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    # Refresh if expired
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
        # Save refreshed token
        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())

    return creds


def run_oauth_flow() -> Credentials:
    """
    Run the OAuth2 flow to get credentials.

    Returns:
        Credentials object.
    """
    flow = InstalledAppFlow.from_client_secrets_file(str(CREDENTIALS_FILE), SCOPES)
    creds = flow.run_local_server(port=0)

    # Save token for future use
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(TOKEN_FILE, "w") as f:
        f.write(creds.to_json())

    return creds


def extract_doc_id(doc_input: str) -> str:
    """
    Extract document ID from URL or return as-is if already an ID.

    Args:
        doc_input: Google Docs URL or document ID.

    Returns:
        The document ID.
    """
    # Pattern for Google Docs URLs
    url_pattern = r"docs\.google\.com/document/d/([a-zA-Z0-9_-]+)"
    match = re.search(url_pattern, doc_input)
    if match:
        return match.group(1)
    # Assume it's already a document ID
    return doc_input


def fetch_document(service: Any, doc_id: str) -> dict:
    """
    Fetch document content from Google Docs API.

    Args:
        service: Google Docs API service.
        doc_id: Document ID.

    Returns:
        Document data dictionary.
    """
    return service.documents().get(documentId=doc_id).execute()


def fetch_comments(
    drive_service: Any, doc_id: str, include_resolved: bool = False
) -> list[dict]:
    """
    Fetch comments from Google Drive API.

    Args:
        drive_service: Google Drive API service.
        doc_id: Document ID (file ID in Drive).
        include_resolved: Whether to include resolved comments.

    Returns:
        List of comment dictionaries.
    """
    comments = []
    page_token = None

    while True:
        response = (
            drive_service.comments()
            .list(
                fileId=doc_id,
                fields="comments(id,content,quotedFileContent,anchor,resolved,replies)",
                includeDeleted=False,
                pageToken=page_token,
            )
            .execute()
        )

        for comment in response.get("comments", []):
            if include_resolved or not comment.get("resolved", False):
                comments.append(comment)
                # Also add replies as separate comments (flattened)
                for reply in comment.get("replies", []):
                    comments.append(
                        {
                            "id": reply.get("id"),
                            "content": reply.get("content"),
                            "quotedFileContent": comment.get("quotedFileContent"),
                            "anchor": comment.get("anchor"),
                            "is_reply": True,
                        }
                    )

        page_token = response.get("nextPageToken")
        if not page_token:
            break

    return comments


def parse_text_style(style: dict) -> tuple[str, str]:
    """
    Parse text style and return prefix/suffix for Markdown formatting.

    Args:
        style: Text style dictionary from Google Docs API.

    Returns:
        Tuple of (prefix, suffix) strings.
    """
    prefix = ""
    suffix = ""

    if style.get("bold"):
        prefix += "**"
        suffix = "**" + suffix

    if style.get("italic"):
        prefix += "*"
        suffix = "*" + suffix

    if style.get("strikethrough"):
        prefix += "~~"
        suffix = "~~" + suffix

    # Inline code (monospace font)
    if style.get("weightedFontFamily", {}).get("fontFamily") in [
        "Courier New",
        "Consolas",
        "monospace",
    ]:
        prefix += "`"
        suffix = "`" + suffix

    return prefix, suffix


def get_heading_level(paragraph_style: dict) -> Optional[int]:
    """
    Get heading level from paragraph style.

    Args:
        paragraph_style: Paragraph style dictionary.

    Returns:
        Heading level (1-6) or None if not a heading.
    """
    named_style = paragraph_style.get("namedStyleType", "")
    if named_style.startswith("HEADING_"):
        try:
            return int(named_style.split("_")[1])
        except (IndexError, ValueError):
            pass
    return None


def convert_paragraph(paragraph: dict, list_info: Optional[dict] = None) -> str:
    """
    Convert a paragraph to Markdown.

    Args:
        paragraph: Paragraph dictionary from Google Docs API.
        list_info: Optional list information for bullet/numbered lists.

    Returns:
        Markdown string.
    """
    elements = paragraph.get("elements", [])
    paragraph_style = paragraph.get("paragraphStyle", {})

    # Check for heading
    heading_level = get_heading_level(paragraph_style)

    text_parts = []
    for element in elements:
        text_run = element.get("textRun")
        if text_run:
            content = text_run.get("content", "")
            style = text_run.get("textStyle", {})

            # Apply formatting
            prefix, suffix = parse_text_style(style)

            # Handle links
            link = style.get("link", {}).get("url")
            if link:
                # Strip newlines from link text
                link_text = content.rstrip("\n")
                text_parts.append(f"[{prefix}{link_text}{suffix}]({link})")
                # Add back trailing newline if present
                if content.endswith("\n"):
                    text_parts.append("\n")
            else:
                text_parts.append(f"{prefix}{content}{suffix}")

    text = "".join(text_parts)

    # Apply heading prefix
    if heading_level:
        text = "#" * heading_level + " " + text.lstrip()

    # Apply list prefix
    if list_info:
        indent = "  " * list_info.get("nesting_level", 0)
        if list_info.get("ordered"):
            text = f"{indent}1. {text.lstrip()}"
        else:
            text = f"{indent}- {text.lstrip()}"

    return text


def convert_table(table: dict) -> str:
    """
    Convert a table to Markdown.

    Args:
        table: Table dictionary from Google Docs API.

    Returns:
        Markdown table string.
    """
    rows = table.get("tableRows", [])
    if not rows:
        return ""

    md_rows = []
    for i, row in enumerate(rows):
        cells = row.get("tableCells", [])
        cell_texts = []
        for cell in cells:
            # Get cell content
            cell_content = []
            for content in cell.get("content", []):
                para = content.get("paragraph")
                if para:
                    cell_content.append(convert_paragraph(para).strip())
            cell_texts.append(" ".join(cell_content).replace("|", "\\|"))

        md_rows.append("| " + " | ".join(cell_texts) + " |")

        # Add header separator after first row
        if i == 0:
            md_rows.append("| " + " | ".join(["---"] * len(cells)) + " |")

    return "\n".join(md_rows) + "\n"


def document_to_markdown(doc: dict) -> tuple[str, list[dict]]:
    """
    Convert Google Docs document to Markdown.

    Args:
        doc: Document dictionary from Google Docs API.

    Returns:
        Tuple of (markdown_string, paragraphs_info).
        paragraphs_info is a list of dicts with doc_start, doc_end, md_start, md_end.
    """
    body = doc.get("body", {})
    content = body.get("content", [])
    lists = doc.get("lists", {})

    md_parts = []
    paragraphs_info = []  # Track paragraph boundaries in both doc and markdown
    md_pos = 0

    for element in content:
        start_index = element.get("startIndex", 0)
        end_index = element.get("endIndex", 0)

        md_start = md_pos

        if "paragraph" in element:
            para = element["paragraph"]

            # Check if this is a list item
            list_info = None
            bullet = para.get("bullet")
            if bullet:
                list_id = bullet.get("listId")
                nesting_level = bullet.get("nestingLevel", 0)
                list_props = lists.get(list_id, {}).get("listProperties", {})
                nesting_props = list_props.get("nestingLevels", [])
                if nesting_level < len(nesting_props):
                    glyph_type = nesting_props[nesting_level].get("glyphType")
                    ordered = glyph_type in [
                        "DECIMAL",
                        "ALPHA",
                        "ROMAN",
                        "UPPER_ALPHA",
                        "UPPER_ROMAN",
                    ]
                else:
                    ordered = False
                list_info = {"nesting_level": nesting_level, "ordered": ordered}

            md_text = convert_paragraph(para, list_info)
            md_parts.append(md_text)
            md_pos += len(md_text)

            paragraphs_info.append({
                "doc_start": start_index,
                "doc_end": end_index,
                "md_start": md_start,
                "md_end": md_pos,
            })

        elif "table" in element:
            md_text = convert_table(element["table"])
            md_parts.append(md_text)
            md_pos += len(md_text)

            paragraphs_info.append({
                "doc_start": start_index,
                "doc_end": end_index,
                "md_start": md_start,
                "md_end": md_pos,
            })

        elif "sectionBreak" in element:
            md_parts.append("\n---\n\n")
            md_pos += 6

    return "".join(md_parts), paragraphs_info


def parse_anchor_offset(anchor: str) -> Optional[int]:
    """
    Parse the anchor JSON to extract the start offset.

    Google Docs anchor format: {"r":{"s":{"o":123},"e":{"o":456}}}
    where s.o is start offset, e.o is end offset.

    Args:
        anchor: The anchor string from Drive API.

    Returns:
        Start offset, or None if parsing fails.
    """
    if not anchor:
        return None

    try:
        data = json.loads(anchor)
        # Try different anchor formats
        if "r" in data and "s" in data["r"] and "o" in data["r"]["s"]:
            return data["r"]["s"]["o"]
        # Alternative format
        if "a" in data and "co" in data:
            return data["co"]
    except (json.JSONDecodeError, KeyError, TypeError):
        pass

    return None


def insert_comments(
    markdown: str, comments: list[dict], paragraphs_info: list[dict]
) -> str:
    """
    Insert comments into Markdown using footnote notation.

    Comments are inserted as [^N] markers at the end of the relevant text,
    with the footnote content at the end of the paragraph.

    Args:
        markdown: The Markdown string.
        comments: List of comment dictionaries.
        paragraphs_info: List of paragraph boundary info.

    Returns:
        Markdown with comments inserted as footnotes.
    """
    if not comments:
        return markdown

    # Parse comments and find their paragraph
    comment_data = []
    for comment in comments:
        content = comment.get("content", "").strip()
        if not content:
            continue

        quoted = comment.get("quotedFileContent", {}).get("value", "")
        anchor = comment.get("anchor", "")

        # Try to get offset from anchor
        doc_offset = parse_anchor_offset(anchor)

        # Find which paragraph contains this comment
        para_idx = None
        if doc_offset is not None:
            for i, para in enumerate(paragraphs_info):
                if para["doc_start"] <= doc_offset < para["doc_end"]:
                    para_idx = i
                    break

        # Fallback: find by quoted text
        if para_idx is None and quoted:
            idx = markdown.find(quoted)
            if idx != -1:
                for i, para in enumerate(paragraphs_info):
                    if para["md_start"] <= idx < para["md_end"]:
                        para_idx = i
                        break

        if para_idx is not None:
            comment_data.append({
                "para_idx": para_idx,
                "quoted": quoted,
                "content": content,
                "doc_offset": doc_offset,
            })

    if not comment_data:
        return markdown

    # Group comments by paragraph
    from collections import defaultdict
    para_comments: dict[int, list] = defaultdict(list)
    for cd in comment_data:
        para_comments[cd["para_idx"]].append(cd)

    # Sort paragraphs in reverse order for insertion
    sorted_paras = sorted(para_comments.keys(), reverse=True)

    result = markdown
    footnote_num = 1

    for para_idx in sorted_paras:
        para = paragraphs_info[para_idx]
        para_comments_list = para_comments[para_idx]

        # Sort comments within paragraph by offset (reverse for insertion)
        para_comments_list.sort(
            key=lambda x: x["doc_offset"] if x["doc_offset"] else 0,
            reverse=True
        )

        # Find end of paragraph in current result (accounting for previous insertions)
        # We need to find where this paragraph ends
        para_end = para["md_end"]

        # Adjust para_end based on what we've already inserted
        # Since we're going in reverse order, we need to track offset adjustments
        # For simplicity, find the paragraph end by looking for newlines
        # after the paragraph start
        para_start = para["md_start"]

        # Find the actual end of this paragraph line in the result
        # Look for double newline or end of string after para_start
        search_start = para_start
        newline_pos = result.find("\n", search_start)
        if newline_pos == -1:
            newline_pos = len(result)

        # Build footnotes for this paragraph
        footnotes_text = ""
        markers_to_insert = []

        for cd in para_comments_list:
            quoted = cd["quoted"]
            content = cd["content"]

            # Escape special chars in content
            safe_content = content.replace("-->", "--&gt;")

            # Truncate quoted for display
            display_quoted = quoted[:60] + "..." if len(quoted) > 60 else quoted

            # Create footnote
            footnote_marker = f"[^{footnote_num}]"
            footnote_def = f'[^{footnote_num}]: ON "{display_quoted}": {safe_content}'
            footnotes_text = footnote_def + "\n" + footnotes_text

            # Find where to insert the marker (after the quoted text)
            if quoted:
                marker_pos = result.find(quoted, para_start)
                if marker_pos != -1 and marker_pos < newline_pos:
                    markers_to_insert.append((marker_pos + len(quoted), footnote_marker))

            footnote_num += 1

        # Insert markers (in reverse position order)
        markers_to_insert.sort(key=lambda x: x[0], reverse=True)
        for pos, marker in markers_to_insert:
            result = result[:pos] + marker + result[pos:]

        # Recalculate newline position after marker insertions
        newline_pos = result.find("\n", para_start)
        if newline_pos == -1:
            newline_pos = len(result)

        # Insert footnotes after the paragraph
        if footnotes_text:
            result = result[:newline_pos] + "\n\n" + footnotes_text + result[newline_pos:]

    return result


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """
    Export Google Docs to Markdown with comments preserved.

    Commands:
      auth     - Authenticate with Google (one-time setup)
      convert  - Convert a Google Doc to Markdown
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
def auth() -> None:
    """
    Authenticate with Google (one-time setup).

    First run: Shows instructions to get credentials.json from GCP console.
    After credentials.json exists: Opens browser for Google login.
    """
    # Check if credentials.json exists
    if not CREDENTIALS_FILE.exists():
        click.echo(
            f"""
To set up gdoc2md, you need OAuth credentials from Google Cloud Console:

1. Go to https://console.cloud.google.com/apis/credentials
2. Create a project (or select existing)
3. Enable "Google Docs API" and "Google Drive API":
   - Go to "Enabled APIs & services"
   - Click "+ ENABLE APIS AND SERVICES"
   - Search for and enable both APIs
4. Set up OAuth consent screen:
   - Go to "OAuth consent screen"
   - Choose "External" user type
   - Fill in app name (e.g., "gdoc2md") and your email
   - Add scopes: .../auth/documents.readonly and .../auth/drive.readonly
   - Add yourself as a test user
5. Create OAuth 2.0 Client ID:
   - Go to "Credentials"
   - Click "+ CREATE CREDENTIALS" → "OAuth client ID"
   - Choose "Desktop app" as application type
   - Download the JSON file
6. Save the JSON file as: {CREDENTIALS_FILE}
7. Run 'gdoc2md auth' again
"""
        )
        sys.exit(1)

    # credentials.json exists, run OAuth flow
    click.echo("Opening browser for Google authentication...")
    click.echo("(Grant access to Google Docs and Drive when prompted)\n")

    try:
        creds = run_oauth_flow()
        click.echo("\nAuthentication successful! You can now use 'gdoc2md convert'.")
    except Exception as e:
        click.echo(f"\nAuthentication failed: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("document")
@click.option("-o", "--output", help="Output file (default: stdout)")
@click.option(
    "--include-resolved", is_flag=True, help="Include resolved comments"
)
def convert(document: str, output: Optional[str], include_resolved: bool) -> None:
    """
    Convert a Google Doc to Markdown with comments.

    DOCUMENT can be a full Google Docs URL or just the document ID.

    Comments are inserted as HTML comments with the quoted text for context.
    """
    # Get credentials
    creds = get_credentials()
    if not creds:
        click.echo(
            """
ERROR: Not authenticated.

Run 'gdoc2md auth' first to authenticate with Google.
""",
            err=True,
        )
        sys.exit(1)

    # Extract document ID
    doc_id = extract_doc_id(document)

    try:
        # Build services
        docs_service = build("docs", "v1", credentials=creds)
        drive_service = build("drive", "v3", credentials=creds)

        click.echo("Fetching document...", err=True)
        doc = fetch_document(docs_service, doc_id)

        click.echo("Fetching comments...", err=True)
        comments = fetch_comments(drive_service, doc_id, include_resolved)

        click.echo("Converting to Markdown...", err=True)
        markdown, paragraphs_info = document_to_markdown(doc)

        # Insert comments
        if comments:
            click.echo(f"Inserting {len(comments)} comments...", err=True)
            markdown = insert_comments(markdown, comments, paragraphs_info)

        # Output
        if output:
            Path(output).write_text(markdown)
            click.echo(f"Written to {output}", err=True)
        else:
            click.echo(markdown)

    except HttpError as e:
        if e.resp.status == 404:
            click.echo(
                f"ERROR: Document not found: {doc_id}\n"
                "Make sure the document exists and you have access.",
                err=True,
            )
        elif e.resp.status == 403:
            click.echo(
                f"ERROR: Access denied to document: {doc_id}\n"
                "Make sure you have permission to view this document.",
                err=True,
            )
        else:
            click.echo(f"ERROR: Google API error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)


def main() -> None:
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
