"""
Unit tests for essencia.
"""