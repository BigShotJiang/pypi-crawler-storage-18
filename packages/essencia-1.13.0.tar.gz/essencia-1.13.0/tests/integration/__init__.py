"""
Integration tests for essencia.
"""