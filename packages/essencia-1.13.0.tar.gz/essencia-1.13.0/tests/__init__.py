"""
Essencia test suite.
"""