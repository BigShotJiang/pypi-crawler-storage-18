"""Database module for Essencia application."""

from .mongodb import MongoDB
from .redis_client import RedisClient
from .sync_mongodb import Database

# Abstract database interfaces
from .abstract import (
    AbstractDatabase,
    SyncAbstractDatabase,
    AbstractModel,
    DatabaseConfig,
    DatabaseFactory,
    QueryBuilder
)

# Database adapters
from .mongodb_adapter import MongoDBAdapter, SyncMongoDBAdapter

# PostgreSQL adapter is optional (requires sqlalchemy)
try:
    from .postgresql_adapter import PostgreSQLAdapter
    POSTGRESQL_AVAILABLE = True
except ImportError:
    PostgreSQLAdapter = None
    POSTGRESQL_AVAILABLE = False

# Register adapters with factory
DatabaseFactory.register_adapter('mongodb', MongoDBAdapter)
DatabaseFactory.register_adapter('mongodb_sync', SyncMongoDBAdapter)
if POSTGRESQL_AVAILABLE:
    DatabaseFactory.register_adapter('postgresql', PostgreSQLAdapter)

__all__ = [
    # Legacy classes
    "MongoDB", 
    "RedisClient", 
    "Database",
    # Abstract interfaces
    "AbstractDatabase",
    "SyncAbstractDatabase",
    "AbstractModel",
    "DatabaseConfig",
    "DatabaseFactory",
    "QueryBuilder",
    # Adapters
    "MongoDBAdapter",
    "SyncMongoDBAdapter",
]

# Only export PostgreSQLAdapter if available
if POSTGRESQL_AVAILABLE:
    __all__.append("PostgreSQLAdapter")