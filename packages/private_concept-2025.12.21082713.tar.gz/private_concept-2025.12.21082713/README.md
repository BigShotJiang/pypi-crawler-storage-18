# private_concept

![PyPI version](https://img.shields.io/pypi/v/private-concept)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Downloads](https://img.shields.io/pypi/dm/private-concept)
![LinkedIn](https://img.shields.io/badge/LinkedIn-connect-blue)

A Python package for processing and structuring innovative, privacy-focused service ideas into clear, concise summaries using pattern matching and large language models (LLMs).

---

## 📌 Overview
`private_concept` helps users document privacy-focused concepts (e.g., a phone service that doesn’t collect personal data) by converting raw text inputs into structured, well-formatted summaries. It leverages **LLM7** (by default) or any LangChain-compatible LLM to extract and refine key details, ensuring clarity and consistency.

---

## 🚀 Installation
Install via pip:
```bash
pip install private_concept
```

---

## 🔧 Usage

### Basic Usage (Default LLM: **LLM7**)
```python
from private_concept import private_concept

response = private_concept(
    user_input="A phone company that never collects user data, ensuring full privacy."
)
print(response)
```

### Custom LLM Integration
You can replace the default LLM with any LangChain-compatible model (e.g., OpenAI, Anthropic, Google Generative AI):

#### **Using OpenAI**
```python
from langchain_openai import ChatOpenAI
from private_concept import private_concept

llm = ChatOpenAI()
response = private_concept(user_input="My privacy-first app idea...", llm=llm)
```

#### **Using Anthropic**
```python
from langchain_anthropic import ChatAnthropic
from private_concept import private_concept

llm = ChatAnthropic()
response = private_concept(user_input="A service that anonymizes all user interactions.", llm=llm)
```

#### **Using Google Generative AI**
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from private_concept import private_concept

llm = ChatGoogleGenerativeAI()
response = private_concept(user_input="A decentralized messaging platform.", llm=llm)
```

---

## 🔑 API Key Configuration
- **Default**: Uses `LLM7_API_KEY` from environment variables.
- **Manual Override**: Pass the key directly:
  ```python
  from private_concept import private_concept
  response = private_concept(user_input="...", api_key="your_llm7_api_key")
  ```
- **Get a Free Key**: [Register at LLM7](https://token.llm7.io/)

---

## 📝 Parameters
| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | Raw text describing the privacy-focused concept. |
| `api_key` | `Optional[str]` | LLM7 API key (defaults to `LLM7_API_KEY` env var). |
| `llm` | `Optional[BaseChatModel]` | Custom LangChain LLM (e.g., `ChatOpenAI`, `ChatAnthropic`). |

---

## 📊 Default LLM: **LLM7**
The package defaults to **LLM7** (via `langchain_llm7`), a lightweight and efficient LLM. Free-tier rate limits are sufficient for most use cases. For higher limits, use your own API key.

---

## 🔄 Pattern Matching
The package enforces structured output via regex patterns, ensuring responses are consistent and easy to parse.

---

## 📜 License
MIT License. See [LICENSE](https://github.com/chigwell/private-concept/blob/main/LICENSE) for details.

---

## 📢 Support & Issues
For bugs or feature requests, open an issue on [GitHub](https://github.com/chigwell/private-concept/issues).

---

## 👤 Author
**Eugene Evstafev** ([LinkedIn](https://linkedin.com/in/chigwell)) | [hi@euegne.plus](mailto:hi@euegne.plus)