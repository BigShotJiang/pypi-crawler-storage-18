# BugPilot CLI

**AI-Powered Autonomous Penetration Testing CLI**

Industry-level penetration testing tool with multi-agent AI system.

## Features

- **Autonomous Pentesting**: AI-driven security testing
- **Multi-Agent ReAct System**: Planning, execution, analysis, and critique
- **OS-Aware Execution**: Adapts commands for Windows, Linux, macOS
- **Session Management**: Save, load, and resume sessions
- **Multiple Export Formats**: TXT, JSON, Markdown
- **Professional CLI**: Commands like Claude CLI and Gemini CLI
- **Auto-Save**: Never lose progress
- **Real-Time Feedback**: Sequential tool execution with live updates

## Installation

```bash
pip install bugpilot-cli
```

## Usage

```bash
bugpilot
```

## Commands

```
/help              - Show all commands
/save <file>       - Save results
/export <file> <format> - Export session
/sessions          - List all sessions
/load <session_id> - Load previous session
/clear             - Clear screen
/config            - Show configuration
/model <prov> <model> - Switch AI model
/exit              - Exit CLI
```

## Example

```
[!] You: scan http://testphp.vulnweb.com for SQLi

[*] Iteration 1/20
[>>] Thought: First gather HTTP headers
[!] Action: curl -I http://testphp.vulnweb.com
[*] Executing command...
[+] Observation: HTTP/1.1 200 OK
...

[!] You: /save results.txt
[SUCCESS] Results saved
```

## License

MIT License

## Author

LAKSHMIKANTHAN K (letchupkt)
