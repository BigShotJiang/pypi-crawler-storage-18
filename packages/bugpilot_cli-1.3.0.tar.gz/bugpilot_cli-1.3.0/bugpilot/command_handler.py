"""
Command Handler for BugPilot CLI
Professional command system like Claude CLI and Gemini CLI
"""

from typing import Dict, List, Optional, Callable
from pathlib import Path
import json


class CommandHandler:
    """Handles all CLI commands like professional AI CLIs"""
    
    def __init__(self, cli_instance):
        self.cli = cli_instance
        self.commands = self._register_commands()
        self.session_manager = None
        self.file_exporter = None
        
    def _register_commands(self) -> Dict[str, dict]:
        """Register all available commands"""
        return {
            "/help": {
                "handler": self.cmd_help,
                "description": "Show all available commands",
                "usage": "/help [command]"
            },
            "/save": {
                "handler": self.cmd_save,
                "description": "Save results to file",
                "usage": "/save <filename> [format]"
            },
            "/export": {
                "handler": self.cmd_export,
                "description": "Export session to file",
                "usage": "/export <filename> <format>"
            },
            "/sessions": {
                "handler": self.cmd_sessions,
                "description": "List all saved sessions",
                "usage": "/sessions"
            },
            "/load": {
                "handler": self.cmd_load,
                "description": "Load a previous session",
                "usage": "/load <session_id>"
            },
            "/clear": {
                "handler": self.cmd_clear,
                "description": "Clear screen",
                "usage": "/clear"
            },
            "/history": {
                "handler": self.cmd_history,
                "description": "Show command history",
                "usage": "/history"
            },
            "/config": {
                "handler": self.cmd_config,
                "description": "Show/edit configuration",
                "usage": "/config [key] [value]"
            },
            "/model": {
                "handler": self.cmd_model,
                "description": "Switch AI model",
                "usage": "/model <provider> <model>"
            },
            "/output": {
                "handler": self.cmd_output,
                "description": "Set output directory",
                "usage": "/output <path>"
            },
            "/stream": {
                "handler": self.cmd_stream,
                "description": "Toggle streaming mode",
                "usage": "/stream [on|off]"
            },
            "/tokens": {
                "handler": self.cmd_tokens,
                "description": "Show token usage",
                "usage": "/tokens"
            },
            "/reset": {
                "handler": self.cmd_reset,
                "description": "Reset current session",
                "usage": "/reset"
            },
            "/exit": {
                "handler": self.cmd_exit,
                "description": "Exit BugPilot",
                "usage": "/exit"
            },
            "/quit": {
                "handler": self.cmd_exit,
                "description": "Alias for /exit",
                "usage": "/quit"
            }
        }
    
    def handle(self, command: str) -> bool:
        """Handle a command. Returns True if command was handled"""
        if not command.startswith('/'):
            return False
            
        parts = command.split()
        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []
        
        if cmd in self.commands:
            try:
                self.commands[cmd]["handler"](args)
                return True
            except Exception as e:
                self.cli.ui.print_error(f"Command error: {str(e)}")
                return True
        else:
            self.cli.ui.print_error(f"Unknown command: {cmd}. Type /help for available commands.")
            return True
    
    def cmd_help(self, args: List[str]):
        """Show help"""
        if args:
            cmd = args[0] if args[0].startswith('/') else f'/{args[0]}'
            if cmd in self.commands:
                info = self.commands[cmd]
                self.cli.ui.print_panel(
                    f"**{cmd}**\n\n{info['description']}\n\nUsage: `{info['usage']}`",
                    title="Command Help",
                    style="info"
                )
            else:
                self.cli.ui.print_error(f"Unknown command: {cmd}")
        else:
            help_text = "**BugPilot CLI Commands**\n\n"
            for cmd, info in sorted(self.commands.items()):
                help_text += f"**{cmd}** - {info['description']}\n"
            help_text += "\nType `/help <command>` for detailed usage"
            self.cli.ui.print_panel(help_text, title="Help", style="info")
    
    def cmd_save(self, args: List[str]):
        """Save results to file"""
        if not args:
            self.cli.ui.print_error("Usage: /save <filename> [format]")
            return
            
        filename = args[0]
        format_type = args[1] if len(args) > 1 else "txt"
        
        if not self.session_manager or not self.session_manager.current_session:
            self.cli.ui.print_error("No active session to save")
            return
        
        # Export current session
        success = self.session_manager.export_results(filename, format_type)
        if success:
            self.cli.ui.print_success(f"Results saved to: {filename}")
        else:
            self.cli.ui.print_error("Failed to save results")
    
    def cmd_export(self, args: List[str]):
        """Export session"""
        if len(args) < 2:
            self.cli.ui.print_error("Usage: /export <filename> <format>")
            return
        
        filename, format_type = args[0], args[1]
        self.cmd_save([filename, format_type])
    
    def cmd_sessions(self, args: List[str]):
        """List all sessions"""
        if not self.session_manager:
            self.cli.ui.print_error("Session manager not available")
            return
        
        sessions = self.session_manager.list_sessions()
        if not sessions:
            self.cli.ui.print_info("No saved sessions found")
            return
        
        sessions_text = "**Saved Sessions:**\n\n"
        for session in sessions[-10:]:  # Last 10
            sessions_text += f"**{session['id']}**\n"
            sessions_text += f"  Objective: {session['objective'][:60]}...\n"
            sessions_text += f"  Created: {session['created_at']}\n"
            sessions_text += f"  Iterations: {session['iterations']}\n\n"
        
        self.cli.ui.print_panel(sessions_text, title="Sessions", style="info")
    
    def cmd_load(self, args: List[str]):
        """Load a session"""
        if not args:
            self.cli.ui.print_error("Usage: /load <session_id>")
            return
        
        session_id = args[0]
        if self.session_manager:
            session = self.session_manager.load_session(session_id)
            if session:
                self.cli.ui.print_success(f"Loaded session: {session_id}")
            else:
                self.cli.ui.print_error(f"Session not found: {session_id}")
    
    def cmd_clear(self, args: List[str]):
        """Clear screen"""
        import os
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def cmd_history(self, args: List[str]):
        """Show command history"""
        # TODO: Implement command history tracking
        self.cli.ui.print_info("Command history feature coming soon")
    
    def cmd_config(self, args: List[str]):
        """Show/edit configuration"""
        if not args:
            # Show current config
            config_text = f"""**Current Configuration:**

AI Provider: {self.cli.config.provider}
Model: {self.cli.config.model}
Mode: {self.cli.config.mode}
Output Directory: {self.file_exporter.get_output_dir() if self.file_exporter else 'Default'}
"""
            self.cli.ui.print_panel(config_text, title="Configuration", style="info")
        elif len(args) == 2:
            key, value = args
            # TODO: Implement config editing
            self.cli.ui.print_info(f"Set {key} = {value}")
    
    def cmd_model(self, args: List[str]):
        """Switch AI model"""
        if len(args) < 2:
            self.cli.ui.print_error("Usage: /model <provider> <model>")
            return
        
        provider, model = args[0], args[1]
        self.cli.config.provider = provider
        self.cli.config.model = model
        self.cli.config.save()
        self.cli.ui.print_success(f"Switched to: {provider}/{model}")
    
    def cmd_output(self, args: List[str]):
        """Set output directory"""
        if not args:
            if self.file_exporter:
                self.cli.ui.print_info(f"Current output: {self.file_exporter.get_output_dir()}")
            return
        
        path = args[0]
        if self.file_exporter:
            self.file_exporter.set_output_dir(path)
            self.cli.ui.print_success(f"Output directory set to: {path}")
    
    def cmd_stream(self, args: List[str]):
        """Toggle streaming"""
        # TODO: Implement streaming mode
        self.cli.ui.print_info("Streaming mode toggle coming soon")
    
    def cmd_tokens(self, args: List[str]):
        """Show token usage"""
        # TODO: Implement token counting
        self.cli.ui.print_info("Token usage tracking coming soon")
    
    def cmd_reset(self, args: List[str]):
        """Reset session"""
        if self.cli.ui.confirm("Reset current session?"):
            # TODO: Implement session reset
            self.cli.ui.print_success("Session reset")
    
    def cmd_exit(self, args: List[str]):
        """Exit CLI"""
        self.cli.running = False
        self.cli.ui.print_info("Goodbye!")
