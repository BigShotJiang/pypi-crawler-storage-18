

import fire 
from .init.vbox_init import vbi 





def main() -> None:
    try:
        fire.Fire(vbi)
    except KeyboardInterrupt:
        print("\n操作已取消")
        exit(0)
    # except Exception as e:
    #     print(f"\n程序执行出错: {str(e)}")
    #     print("请检查您的输入参数或网络连接")
    #     exit(1)