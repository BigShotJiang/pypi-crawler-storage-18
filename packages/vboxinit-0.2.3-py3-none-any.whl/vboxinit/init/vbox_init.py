import questionary
from fabric import Connection

# 设置远程命令环境变量，使用英文输出避免中文乱码
ENV_LANG_C = {"LANG": "C", "LC_ALL": "C"}


# region 用户输入收集
def collect_server_info() -> dict[str, str] | None:
    """通过交互式问答收集服务器连接信息，用户取消时返回 None"""
    ip = questionary.text("请输入服务器IP地址:").ask()
    if ip is None:
        return None

    username = questionary.text("请输入用户名:", default="vagrant").ask()
    if username is None:
        return None

    password = questionary.password("请输入密码:", default="vagrant").ask()
    if password is None:
        return None

    sudo_password = questionary.password("请输入SUDO密码 (留空则与登录密码相同):").ask()
    if sudo_password is None:
        return None

    return {
        "host": ip,
        "user": username,
        "password": password,
        "sudo_password": sudo_password or password,
    }
# endregion


# region 服务器连接
def create_connection(info: dict[str, str]) -> Connection:
    """根据收集的信息创建 Fabric 连接"""
    return Connection(
        host=info["host"],
        user=info["user"],
        connect_kwargs={"password": info["password"]},
    )
# endregion


# region Debian 初始化任务
def setup_apt_sources(conn: Connection, sudo_pwd: str, source_list: str) -> None:
    """更换软件源"""
    print("\n[任务] 更换软件源")
    # 对 source_list 中的单引号进行转义处理
    # 将 ' 替换为 '\'' (先结束当前单引号，插入转义的单引号，再开启新单引号)
    # 这是 shell 中在单引号字符串内嵌入单引号的标准技巧
    # 例如: "it's" -> "it'\''s" 在 shell 中会被解析为 it's
    escaped = source_list.replace("'", "'\\''")
    # 使用 tee 解决 sudo 重定向权限问题
    conn.sudo(f"bash -c \"echo '{escaped}' | tee /etc/apt/sources.list > /dev/null\"", password=sudo_pwd, hide=True)


def apt_update_upgrade(conn: Connection, sudo_pwd: str) -> None:
    """apt update 和 apt upgrade"""
    print("\n[任务] apt update & upgrade")
    conn.sudo("apt-get update -y", password=sudo_pwd, env=ENV_LANG_C)
    conn.sudo("apt-get upgrade -y", password=sudo_pwd, env=ENV_LANG_C)


def install_base_packages(conn: Connection, sudo_pwd: str) -> None:
    """安装必要的依赖"""
    print("\n[任务] 安装基础依赖软件包")
    conn.sudo("apt-get install -y vim sudo curl wget sshpass", password=sudo_pwd, env=ENV_LANG_C)


def setup_vagrant_user(conn: Connection, sudo_pwd: str) -> None:
    """确保 vagrant 用户存在并配置"""
    print("\n[任务] 配置 vagrant 用户")

    # 创建用户
    conn.sudo(
        "id vagrant || useradd -m -s /bin/bash vagrant",
        password=sudo_pwd, hide=True, warn=True
    )

    # 设置密码
    conn.sudo(
        "bash -c \"echo 'vagrant:vagrant' | chpasswd\"",
        password=sudo_pwd, hide=True
    )

    # 无密码 sudo (使用 tee 解决重定向权限问题)
    conn.sudo(
        "bash -c \"echo 'vagrant ALL=(ALL) NOPASSWD:ALL' | tee /etc/sudoers.d/no-password-sudo > /dev/null\"",
        password=sudo_pwd, hide=True
    )

    # 配置 .ssh 目录
    conn.sudo("mkdir -p /home/vagrant/.ssh", password=sudo_pwd, hide=True)
    conn.sudo("chmod 700 /home/vagrant/.ssh", password=sudo_pwd, hide=True)
    conn.sudo("chown vagrant:vagrant /home/vagrant/.ssh", password=sudo_pwd, hide=True)

    # 添加 vagrant insecure key (使用 tee 解决重定向权限问题)
    insecure_keys = """ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA6NF8iallvQVp22WDkTkyrtvp9eWW6A8YVr+kz4TjGYe7gHzIw+niNltGEFHzD8+v1I2YJ6oXevct1YeS0o9HZyN1Q9qgCgzUFtdOKLv6IedplqoPkcmF0aYet2PkEDo3MlTBckFXPITAMzF8dJSIFo9D8HfdOV0IAdx4O7PtixWKn5y2hMNG0zQPyUecp4pzC6kivAIhyfHilFR61RGL+GPXQ2MWZWFYbAGjyiYJnAmCP3NOTd0jMZEnDkbUvxhMmBYSdETk1rRgm+R4LOzFUGaHqHDLKLX+FIPKcF96hrucXzcWyLbIbEgE98OHlnVYCzRdK8jlqm8tehUc9c9WhQ== vagrant insecure public key
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIN1YdxBpNlzxDqfJyw/QKow1F+wvG9hXGoqiysfJOn5Y vagrant insecure public key"""
    conn.sudo(f"bash -c \"echo '{insecure_keys}' | tee /home/vagrant/.ssh/authorized_keys > /dev/null\"", password=sudo_pwd, hide=True)
    conn.sudo("chmod 600 /home/vagrant/.ssh/authorized_keys", password=sudo_pwd, hide=True)
    conn.sudo("chown vagrant:vagrant /home/vagrant/.ssh/authorized_keys", password=sudo_pwd, hide=True)


def install_kernel_dev_packages(conn: Connection, sudo_pwd: str) -> None:
    """安装内核开发相关包 (用于 VirtualBox Guest Additions)"""
    print("\n[任务] 安装内核开发包")
    # 获取当前内核版本
    result = conn.run("uname -r", hide=True)
    kernel_version = result.stdout.strip()

    conn.sudo("apt-get install -y build-essential dkms", password=sudo_pwd, env=ENV_LANG_C)
    conn.sudo(f"apt-get install -y linux-headers-{kernel_version}", password=sudo_pwd, warn=True, env=ENV_LANG_C)


def install_vbox_guest_additions(conn: Connection, sudo_pwd: str, iso_path: str) -> None:
    """挂载并安装 VirtualBox Guest Additions"""
    print("\n[任务] 安装 VirtualBox Guest Additions")

    # 上传 ISO
    conn.put(iso_path, "/tmp/VBoxGuestAdditions.iso")

    # 挂载
    conn.sudo("mkdir -p /media/VBoxGuestAdditions", password=sudo_pwd, hide=True)
    conn.sudo(
        "mount -o loop,ro /tmp/VBoxGuestAdditions.iso /media/VBoxGuestAdditions",
        password=sudo_pwd, warn=True
    )

    # 执行安装
    try:
        conn.sudo("sh /media/VBoxGuestAdditions/VBoxLinuxAdditions.run --nox11", password=sudo_pwd, warn=True)
    finally:
        # 卸载
        conn.sudo("umount /media/VBoxGuestAdditions", password=sudo_pwd, warn=True)

    # 验证安装
    result = conn.sudo("/sbin/rcvboxadd status", password=sudo_pwd, hide=True, warn=True)
    print(f"  Guest Additions 状态: {result.stdout.strip()}")


def cleanup_debian_network_config(conn: Connection, sudo_pwd: str) -> None:
    """删除 Debian 系统的静态 IP 配置文件"""
    print("\n[任务] 清理网络配置")

    # 查找并删除网络配置文件
    result = conn.sudo(
        "find /etc/network/interfaces.d/ -type f 2>/dev/null || true",
        password=sudo_pwd, hide=True
    )
    files = [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]

    for f in files:
        conn.sudo(f"rm -f {f}", password=sudo_pwd, hide=True)
        print(f"  已删除: {f}")

    # 重启网络服务
    if files:
        conn.sudo("systemctl restart networking", password=sudo_pwd, warn=True)
# endregion


# region 主入口
def vbi() -> None:
    """主函数"""
    info = collect_server_info()
    if info is None:
        print("用户取消，退出")
        return
    if not info["host"]:
        print("未提供服务器地址，退出")
        return

    conn = create_connection(info)
    sudo_pwd = info["sudo_password"]

    try:
        # 基础配置
        apt_update_upgrade(conn, sudo_pwd)
        install_base_packages(conn, sudo_pwd)
        setup_vagrant_user(conn, sudo_pwd)
        install_kernel_dev_packages(conn, sudo_pwd)
        cleanup_debian_network_config(conn, sudo_pwd)

        print("\n所有任务执行完毕")
    finally:
        conn.close()


if __name__ == "__main__":
    vbi()
# endregion
