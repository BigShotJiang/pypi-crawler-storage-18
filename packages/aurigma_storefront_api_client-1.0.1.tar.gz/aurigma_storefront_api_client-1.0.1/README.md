# aurigma-storefront-api-client

Python client library for [Aurigma Storefront API](https://customerscanvas.com/dev/backoffice/api/storefront/overview.html).

## Requirements

- Python 3.9+
- Dependencies:
  - python-dateutil>=2.8.2
  - httpx>=0.28.1
  - pydantic>=2
  - typing-extensions>=4.7.1

## Installation & Usage
### pip install

```sh
pip install aurigma-storefront-api-client
```

Then import the package:
```python
import aurigma.storefront
```

## Getting Started

Please follow the [installation procedure](#installation--usage) and then run the following:

```python

import aurigma.storefront
from aurigma.storefront.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = aurigma.storefront.Configuration(
    host = "http://api.customerscanvashub.com/"
)



# Enter a context with an instance of the API client
async with aurigma.storefront.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = aurigma.storefront.BuildInfoApi(api_client)

    try:
        # Returns an assembly build info.
        api_response = await api_instance.build_info_get_info()
        print("The response of BuildInfoApi->build_info_get_info:\n")
        pprint(api_response)
    except ApiException as e:
        print("Exception when calling BuildInfoApi->build_info_get_info: %s\n" % e)

```

## Documentation for API Endpoints

Depending on the geographical location of your Customer's Canvas Hub instance, the API gateway address may vary: 
 
https://api.customerscanvashub.com/ - United States instance
https://api.eu.customerscanvashub.com/ - European instance
https://api.au.customerscanvashub.com/ - Australian instance


Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*BuildInfoApi* | [**build_info_get_info**](docs/BuildInfoApi.md#build_info_get_info) | **GET** /api/storefront/v1/info | Returns an assembly build info.
*BuildInfoApi* | [**build_info_head_info**](docs/BuildInfoApi.md#build_info_head_info) | **HEAD** /api/storefront/v1/info | Returns an assembly build info.
*ProcessingPipelinesApi* | [**processing_pipelines_get**](docs/ProcessingPipelinesApi.md#processing_pipelines_get) | **GET** /api/storefront/v1/processing-pipelines/{id} | Returns a processing pipeline.
*ProcessingPipelinesApi* | [**processing_pipelines_get_all**](docs/ProcessingPipelinesApi.md#processing_pipelines_get_all) | **GET** /api/storefront/v1/processing-pipelines | Returns all processing pipelines relevant to the specified query parameters.
*ProductBundlesApi* | [**product_bundles_get_all_product_bundles**](docs/ProductBundlesApi.md#product_bundles_get_all_product_bundles) | **GET** /api/storefront/v1/product-bundles | Returns all product bundles, relevant to the specified query parameters.
*ProductBundlesApi* | [**product_bundles_get_personalization_workflow**](docs/ProductBundlesApi.md#product_bundles_get_personalization_workflow) | **GET** /api/storefront/v1/product-bundles/{id}/personalization-workflow | Returns a product bundle personalization workflow description by product bundle identifier.
*ProductBundlesApi* | [**product_bundles_get_product_bundle**](docs/ProductBundlesApi.md#product_bundles_get_product_bundle) | **GET** /api/storefront/v1/product-bundles/{id} | Returns a product bundle by its identifier.
*ProductBundlesApi* | [**product_bundles_get_product_summary**](docs/ProductBundlesApi.md#product_bundles_get_product_summary) | **GET** /api/storefront/v1/product-bundles/{id}/summary | Returns a product bundle summary by product bundle identifier.
*ProductLinksApi* | [**product_links_get_all_product_links**](docs/ProductLinksApi.md#product_links_get_all_product_links) | **GET** /api/storefront/v1/product-links | Returns all product links, relevant to the specified query parameters.
*ProductLinksApi* | [**product_links_get_personalization_workflow**](docs/ProductLinksApi.md#product_links_get_personalization_workflow) | **GET** /api/storefront/v1/product-links/{id}/personalization-workflow | Returns a product link personalization workflow description by product link identifier.
*ProductLinksApi* | [**product_links_get_product_link**](docs/ProductLinksApi.md#product_links_get_product_link) | **GET** /api/storefront/v1/product-links/{id} | Returns a product link by its identifier.
*ProductLinksApi* | [**product_links_get_product_summary**](docs/ProductLinksApi.md#product_links_get_product_summary) | **GET** /api/storefront/v1/product-links/{id}/summary | Returns a product link summary by product link identifier.
*ProductReferencesApi* | [**product_references_get**](docs/ProductReferencesApi.md#product_references_get) | **GET** /api/storefront/v1/product-references/{reference} | Returns a storefront product reference.
*ProductReferencesApi* | [**product_references_get_all**](docs/ProductReferencesApi.md#product_references_get_all) | **GET** /api/storefront/v1/product-references | Returns all storefront product references relevant to the specified query parameters.
*ProductReferencesApi* | [**product_references_get_all_product_bundles**](docs/ProductReferencesApi.md#product_references_get_all_product_bundles) | **GET** /api/storefront/v1/product-references/product-bundles | Returns a list of product bundles associated with storefront product references relevant to the specified query parameters.
*ProductReferencesApi* | [**product_references_get_all_product_links**](docs/ProductReferencesApi.md#product_references_get_all_product_links) | **GET** /api/storefront/v1/product-references/product-links | Returns a list of product links associated with storefront product references relevant to the specified query parameters.
*ProductReferencesApi* | [**product_references_get_all_product_specifications**](docs/ProductReferencesApi.md#product_references_get_all_product_specifications) | **GET** /api/storefront/v1/product-references/product-specifications | Returns a list of product specifications associated with storefront product references relevant to the specified query parameters.
*ProductReferencesApi* | [**product_references_get_all_products**](docs/ProductReferencesApi.md#product_references_get_all_products) | **GET** /api/storefront/v1/product-references/products | Returns a list of products associated with storefront product references relevant to the specified query parameters.
*ProductReferencesApi* | [**product_references_get_personalization_workflow**](docs/ProductReferencesApi.md#product_references_get_personalization_workflow) | **GET** /api/storefront/v1/product-references/{reference}/personalization-workflow | Returns a product personalization workflow.
*ProductReferencesApi* | [**product_references_get_product**](docs/ProductReferencesApi.md#product_references_get_product) | **GET** /api/storefront/v1/product-references/{reference}/product | Returns a product by storefront product reference.
*ProductReferencesApi* | [**product_references_get_product_bundle**](docs/ProductReferencesApi.md#product_references_get_product_bundle) | **GET** /api/storefront/v1/product-references/{reference}/product-bundle | Returns a product bundle by storefront product reference.
*ProductReferencesApi* | [**product_references_get_product_cost_details**](docs/ProductReferencesApi.md#product_references_get_product_cost_details) | **GET** /api/storefront/v1/product-references/{reference}/product-cost-details | Returns a product cost details from ecommerce system.
*ProductReferencesApi* | [**product_references_get_product_link**](docs/ProductReferencesApi.md#product_references_get_product_link) | **GET** /api/storefront/v1/product-references/{reference}/product-link | Returns a product link by storefront product reference.
*ProductReferencesApi* | [**product_references_get_product_specification**](docs/ProductReferencesApi.md#product_references_get_product_specification) | **GET** /api/storefront/v1/product-references/{reference}/product-specification | Returns a product specification by the storefront product reference.
*ProductReferencesApi* | [**product_references_get_product_summary**](docs/ProductReferencesApi.md#product_references_get_product_summary) | **GET** /api/storefront/v1/product-references/{reference}/product-summary | Returns a product summary by storefront product reference.
*ProductSpecificationsApi* | [**product_specifications_get**](docs/ProductSpecificationsApi.md#product_specifications_get) | **GET** /api/storefront/v1/product-specifications/{id} | Returns a product specification by identifier.
*ProductSpecificationsApi* | [**product_specifications_get_all**](docs/ProductSpecificationsApi.md#product_specifications_get_all) | **GET** /api/storefront/v1/product-specifications | Returns all product specifications, relevant to the specified query parameters.
*ProductSpecificationsApi* | [**product_specifications_get_personalization_workflow**](docs/ProductSpecificationsApi.md#product_specifications_get_personalization_workflow) | **GET** /api/storefront/v1/product-specifications/{id}/personalization-workflow | Returns a product personalization workflow description by product specification identifier.
*ProductsApi* | [**products_get_all_product_options**](docs/ProductsApi.md#products_get_all_product_options) | **GET** /api/storefront/v1/products/options | Returns a list of product options for all products.
*ProductsApi* | [**products_get_all_products**](docs/ProductsApi.md#products_get_all_products) | **GET** /api/storefront/v1/products | Returns all products, relevant to the specified query parameters.
*ProductsApi* | [**products_get_available_product_tags**](docs/ProductsApi.md#products_get_available_product_tags) | **GET** /api/storefront/v1/products/available-tags | Returns a list of all available product tags.
*ProductsApi* | [**products_get_personalization_workflow**](docs/ProductsApi.md#products_get_personalization_workflow) | **GET** /api/storefront/v1/products/{id}/personalization-workflow | Returns a product personalization workflow description by product identifier.
*ProductsApi* | [**products_get_product**](docs/ProductsApi.md#products_get_product) | **GET** /api/storefront/v1/products/{id} | Returns a product by identifier.
*ProductsApi* | [**products_get_product_link**](docs/ProductsApi.md#products_get_product_link) | **GET** /api/storefront/v1/products/{id}/links/{productLinkId} | Returns a product link.
*ProductsApi* | [**products_get_product_links**](docs/ProductsApi.md#products_get_product_links) | **GET** /api/storefront/v1/products/{id}/links | Returns a list of product links.
*ProductsApi* | [**products_get_product_options**](docs/ProductsApi.md#products_get_product_options) | **GET** /api/storefront/v1/products/{id}/options | Returns a list of product options.
*ProductsApi* | [**products_get_product_summary**](docs/ProductsApi.md#products_get_product_summary) | **GET** /api/storefront/v1/products/{id}/summary | Returns a product summary by product identifier.
*ProductsApi* | [**products_get_product_variant**](docs/ProductsApi.md#products_get_product_variant) | **GET** /api/storefront/v1/products/{id}/variants/{productVariantId} | Returns a product variant.
*ProductsApi* | [**products_get_product_variant_designs**](docs/ProductsApi.md#products_get_product_variant_designs) | **GET** /api/storefront/v1/products/{id}/variant-designs | Returns a list of product variant designs.
*ProductsApi* | [**products_get_product_variant_documents**](docs/ProductsApi.md#products_get_product_variant_documents) | **GET** /api/storefront/v1/products/{id}/variant-documents | Returns a list of product variant documents.
*ProductsApi* | [**products_get_product_variant_mockups**](docs/ProductsApi.md#products_get_product_variant_mockups) | **GET** /api/storefront/v1/products/{id}/variant-mockups | Returns a list of product variant mockups.
*ProductsApi* | [**products_get_product_variants**](docs/ProductsApi.md#products_get_product_variants) | **GET** /api/storefront/v1/products/{id}/variants | Returns a list of product variants.
*ProductsApi* | [**products_update_product_variant_resources**](docs/ProductsApi.md#products_update_product_variant_resources) | **POST** /api/storefront/v1/products/{id}/update-variant-resources | Updates product variant resources.
*ProjectsApi* | [**projects_attach_data_to_project_order**](docs/ProjectsApi.md#projects_attach_data_to_project_order) | **POST** /api/storefront/v1/projects/{id}/order-data | Attachs the specified data to the project&#39;s order in ecommerce system.
*ProjectsApi* | [**projects_batch_delete**](docs/ProjectsApi.md#projects_batch_delete) | **DELETE** /api/storefront/v1/projects/batch-delete | Deletes specified projects.   These projects will be hide from projects list immediately, but complete projects data cleaning will take some additional time.
*ProjectsApi* | [**projects_change_status**](docs/ProjectsApi.md#projects_change_status) | **POST** /api/storefront/v1/projects/{id}/transitions/{transition} | Changes the project status.
*ProjectsApi* | [**projects_create_by_render_hi_res_scenario**](docs/ProjectsApi.md#projects_create_by_render_hi_res_scenario) | **POST** /api/storefront/v1/projects/by-scenario/render-hires | Creates a new project by &#39;Render HiRes&#39; scenario.
*ProjectsApi* | [**projects_create_by_specific_pipeline_scenario**](docs/ProjectsApi.md#projects_create_by_specific_pipeline_scenario) | **POST** /api/storefront/v1/projects/by-scenario/specific-pipeline | Creates a new project by &#39;Specific Pipeline&#39; scenario.
*ProjectsApi* | [**projects_create_with_multiple_items**](docs/ProjectsApi.md#projects_create_with_multiple_items) | **POST** /api/storefront/v1/projects/with-multiple-items | Creates a new project with multiple items.
*ProjectsApi* | [**projects_create_with_single_item**](docs/ProjectsApi.md#projects_create_with_single_item) | **POST** /api/storefront/v1/projects/with-single-item | Creates a new project with single item.
*ProjectsApi* | [**projects_delete**](docs/ProjectsApi.md#projects_delete) | **DELETE** /api/storefront/v1/projects/{id} | Removes a project by identifier.
*ProjectsApi* | [**projects_force_status**](docs/ProjectsApi.md#projects_force_status) | **POST** /api/storefront/v1/projects/{id}/statuses/{status} | Changes the project status forcibly without a proper transition.
*ProjectsApi* | [**projects_get**](docs/ProjectsApi.md#projects_get) | **GET** /api/storefront/v1/projects/{id} | Returns a project by identifier.
*ProjectsApi* | [**projects_get_all**](docs/ProjectsApi.md#projects_get_all) | **GET** /api/storefront/v1/projects | Returns all projects, relevant to the specified query parameters.
*ProjectsApi* | [**projects_get_all_statuses**](docs/ProjectsApi.md#projects_get_all_statuses) | **GET** /api/storefront/v1/projects/statuses | Returns a list of all existing project statuses.
*ProjectsApi* | [**projects_get_all_transitions**](docs/ProjectsApi.md#projects_get_all_transitions) | **GET** /api/storefront/v1/projects/transitions | Returns a list of all existing project status transitions.
*ProjectsApi* | [**projects_get_available_transitions**](docs/ProjectsApi.md#projects_get_available_transitions) | **GET** /api/storefront/v1/projects/{id}/transitions | Returns all available status transitions for a project.
*ProjectsApi* | [**projects_get_preview**](docs/ProjectsApi.md#projects_get_preview) | **GET** /api/storefront/v1/projects/{id}/preview | Returns a project preview file by project identifier.
*ProjectsApi* | [**projects_get_preview_url**](docs/ProjectsApi.md#projects_get_preview_url) | **GET** /api/storefront/v1/projects/{id}/preview-url | Returns a project preview URL by project identifier.
*ProjectsApi* | [**projects_get_project_order**](docs/ProjectsApi.md#projects_get_project_order) | **GET** /api/storefront/v1/projects/{id}/order | Returns an order description from the ecommerce system for the specified project.
*ProjectsApi* | [**projects_get_project_processing_results**](docs/ProjectsApi.md#projects_get_project_processing_results) | **GET** /api/storefront/v1/projects/{id}/processing-results | Returns a project processing results.
*ProjectsApi* | [**projects_restart_project_processing**](docs/ProjectsApi.md#projects_restart_project_processing) | **POST** /api/storefront/v1/projects/{id}/restart-processing | Restarts a project processing routine.
*ProjectsApi* | [**projects_resume_project_processing**](docs/ProjectsApi.md#projects_resume_project_processing) | **POST** /api/storefront/v1/projects/{id}/resume-processing | Resumes project processing.
*StorefrontUsersApi* | [**storefront_users_create**](docs/StorefrontUsersApi.md#storefront_users_create) | **POST** /api/storefront/v1/storefront-users | Creates a new storefront user.
*StorefrontUsersApi* | [**storefront_users_get**](docs/StorefrontUsersApi.md#storefront_users_get) | **GET** /api/storefront/v1/storefront-users/{id} | Returns a storefront user by identifier.
*StorefrontUsersApi* | [**storefront_users_get_all**](docs/StorefrontUsersApi.md#storefront_users_get_all) | **GET** /api/storefront/v1/storefront-users | Returns all storefront users, relevant to the specified query parameters.
*StorefrontUsersApi* | [**storefront_users_get_token**](docs/StorefrontUsersApi.md#storefront_users_get_token) | **GET** /api/storefront/v1/storefront-users/token | Returns an API access token for the specified storefront user.
*StorefrontUsersApi* | [**storefront_users_merge_anonymous**](docs/StorefrontUsersApi.md#storefront_users_merge_anonymous) | **POST** /api/storefront/v1/storefront-users/merge-anonymous | Transfers all existing data for the anonymous storefront user to the selected regular storefront user account.
*StorefrontUsersApi* | [**storefront_users_register**](docs/StorefrontUsersApi.md#storefront_users_register) | **POST** /api/storefront/v1/storefront-users/register | Registers a storefront user with the specified identifier.
*StorefrontsApi* | [**storefronts_get**](docs/StorefrontsApi.md#storefronts_get) | **GET** /api/storefront/v1/storefronts/{id} | Returns a storefront by identifier.
*StorefrontsApi* | [**storefronts_get_all**](docs/StorefrontsApi.md#storefronts_get_all) | **GET** /api/storefront/v1/storefronts | Returns all storefronts, relevant to the specified query parameters.
*TenantInfoApi* | [**tenant_info_get_applications_info**](docs/TenantInfoApi.md#tenant_info_get_applications_info) | **GET** /api/storefront/v1/tenant-info/applications | Returns an information about the tenant applications.
*TenantInfoApi* | [**tenant_info_get_info**](docs/TenantInfoApi.md#tenant_info_get_info) | **GET** /api/storefront/v1/tenant-info | Returns an information about the tenant.
*TenantInfoApi* | [**tenant_info_get_measure_units_info**](docs/TenantInfoApi.md#tenant_info_get_measure_units_info) | **GET** /api/storefront/v1/tenant-info/measure-units | Returns an information about the tenant measure units.
*TenantInfoApi* | [**tenant_info_get_users_info**](docs/TenantInfoApi.md#tenant_info_get_users_info) | **GET** /api/storefront/v1/tenant-info/users | Returns a list of tenant users.


## Documentation For Models

 - [AppearanceDataDto](docs/AppearanceDataDto.md)
 - [AppearanceDataItemDto](docs/AppearanceDataItemDto.md)
 - [AppearanceDataType](docs/AppearanceDataType.md)
 - [BackOfficeProjectsDtoProjectItemProductSpecifierDto](docs/BackOfficeProjectsDtoProjectItemProductSpecifierDto.md)
 - [BackOfficeProjectsEnumsProjectItemProductType](docs/BackOfficeProjectsEnumsProjectItemProductType.md)
 - [BatchDeleteProjectsInput](docs/BatchDeleteProjectsInput.md)
 - [BuildInfoModel](docs/BuildInfoModel.md)
 - [ConflictType](docs/ConflictType.md)
 - [CreateMultiItemProjectDto](docs/CreateMultiItemProjectDto.md)
 - [CreateProjectByRenderHiResScenarioDto](docs/CreateProjectByRenderHiResScenarioDto.md)
 - [CreateProjectBySpecificPipelineScenarioDto](docs/CreateProjectBySpecificPipelineScenarioDto.md)
 - [CreateSingleItemProjectDto](docs/CreateSingleItemProjectDto.md)
 - [CreateStorefrontUserDto](docs/CreateStorefrontUserDto.md)
 - [DatePeriod](docs/DatePeriod.md)
 - [GeneralConflictDto](docs/GeneralConflictDto.md)
 - [ImageInfo](docs/ImageInfo.md)
 - [ItemPipelineDto](docs/ItemPipelineDto.md)
 - [MergeAnonymousUserDataInput](docs/MergeAnonymousUserDataInput.md)
 - [MicrosoftAspNetCoreMvcProblemDetails](docs/MicrosoftAspNetCoreMvcProblemDetails.md)
 - [OptionType](docs/OptionType.md)
 - [OrderDataItemDto](docs/OrderDataItemDto.md)
 - [OrderDataItemValueType](docs/OrderDataItemValueType.md)
 - [OrderDetailsDto](docs/OrderDetailsDto.md)
 - [PagedOfProcessingPipelineDto](docs/PagedOfProcessingPipelineDto.md)
 - [PagedOfProductBundleDto](docs/PagedOfProductBundleDto.md)
 - [PagedOfProductDto](docs/PagedOfProductDto.md)
 - [PagedOfProductLinkDto](docs/PagedOfProductLinkDto.md)
 - [PagedOfProductOptionDto](docs/PagedOfProductOptionDto.md)
 - [PagedOfProductReferenceDto](docs/PagedOfProductReferenceDto.md)
 - [PagedOfProductSpecificationDto](docs/PagedOfProductSpecificationDto.md)
 - [PagedOfProductVariantDesignDto](docs/PagedOfProductVariantDesignDto.md)
 - [PagedOfProductVariantDocumentDto](docs/PagedOfProductVariantDocumentDto.md)
 - [PagedOfProductVariantDto](docs/PagedOfProductVariantDto.md)
 - [PagedOfProductVariantMockupDto](docs/PagedOfProductVariantMockupDto.md)
 - [PagedOfProjectDto](docs/PagedOfProjectDto.md)
 - [PagedOfProjectStatusDto](docs/PagedOfProjectStatusDto.md)
 - [PagedOfProjectTransitionDto](docs/PagedOfProjectTransitionDto.md)
 - [PagedOfStorefrontDto](docs/PagedOfStorefrontDto.md)
 - [PagedOfStorefrontUserDto](docs/PagedOfStorefrontUserDto.md)
 - [PersonalizationWorkflowDto](docs/PersonalizationWorkflowDto.md)
 - [ProcessingPipelineDto](docs/ProcessingPipelineDto.md)
 - [ProductAttributeDto](docs/ProductAttributeDto.md)
 - [ProductBundleDto](docs/ProductBundleDto.md)
 - [ProductBundleItemDto](docs/ProductBundleItemDto.md)
 - [ProductBundleResourceDto](docs/ProductBundleResourceDto.md)
 - [ProductBundleResourceType](docs/ProductBundleResourceType.md)
 - [ProductCostDetailsDto](docs/ProductCostDetailsDto.md)
 - [ProductDto](docs/ProductDto.md)
 - [ProductFilterOptionDto](docs/ProductFilterOptionDto.md)
 - [ProductLinkDto](docs/ProductLinkDto.md)
 - [ProductLinkResourceDto](docs/ProductLinkResourceDto.md)
 - [ProductLinkResourceType](docs/ProductLinkResourceType.md)
 - [ProductOptionDto](docs/ProductOptionDto.md)
 - [ProductOptionValueDto](docs/ProductOptionValueDto.md)
 - [ProductReferenceDto](docs/ProductReferenceDto.md)
 - [ProductReferenceType](docs/ProductReferenceType.md)
 - [ProductSpecificationDto](docs/ProductSpecificationDto.md)
 - [ProductSummaryDto](docs/ProductSummaryDto.md)
 - [ProductSummaryOptionDto](docs/ProductSummaryOptionDto.md)
 - [ProductSummaryOptionValueDto](docs/ProductSummaryOptionValueDto.md)
 - [ProductVariantDesignDto](docs/ProductVariantDesignDto.md)
 - [ProductVariantDocumentDto](docs/ProductVariantDocumentDto.md)
 - [ProductVariantDto](docs/ProductVariantDto.md)
 - [ProductVariantMockupDto](docs/ProductVariantMockupDto.md)
 - [ProductVariantMockupType](docs/ProductVariantMockupType.md)
 - [ProductVariantOptionDto](docs/ProductVariantOptionDto.md)
 - [ProductVariantResourceDto](docs/ProductVariantResourceDto.md)
 - [ProductVariantResourcePreview](docs/ProductVariantResourcePreview.md)
 - [ProductVariantResourceType](docs/ProductVariantResourceType.md)
 - [ProjectDto](docs/ProjectDto.md)
 - [ProjectItemDto](docs/ProjectItemDto.md)
 - [ProjectItemParametersDto](docs/ProjectItemParametersDto.md)
 - [ProjectItemResourceDto](docs/ProjectItemResourceDto.md)
 - [ProjectItemResourceParametersDto](docs/ProjectItemResourceParametersDto.md)
 - [ProjectItemResourceType](docs/ProjectItemResourceType.md)
 - [ProjectOutputFileDetailsDto](docs/ProjectOutputFileDetailsDto.md)
 - [ProjectProcessingResultsDto](docs/ProjectProcessingResultsDto.md)
 - [ProjectProcessingStatus](docs/ProjectProcessingStatus.md)
 - [ProjectStatusDto](docs/ProjectStatusDto.md)
 - [ProjectTransitionConflictDto](docs/ProjectTransitionConflictDto.md)
 - [ProjectTransitionDto](docs/ProjectTransitionDto.md)
 - [RegisterStorefrontUserInput](docs/RegisterStorefrontUserInput.md)
 - [RenderHiResScenarioDto](docs/RenderHiResScenarioDto.md)
 - [RenderHiResScenarioOutputColorSpace](docs/RenderHiResScenarioOutputColorSpace.md)
 - [RenderHiResScenarioOutputFlipMode](docs/RenderHiResScenarioOutputFlipMode.md)
 - [RenderHiResScenarioOutputFormat](docs/RenderHiResScenarioOutputFormat.md)
 - [RenderHiResScenarioOutputRotateMode](docs/RenderHiResScenarioOutputRotateMode.md)
 - [SimpleOptionValue](docs/SimpleOptionValue.md)
 - [SizeMeasureUnitDto](docs/SizeMeasureUnitDto.md)
 - [SpecificPipelineScenarioDto](docs/SpecificPipelineScenarioDto.md)
 - [StorefrontDto](docs/StorefrontDto.md)
 - [StorefrontType](docs/StorefrontType.md)
 - [StorefrontUserDto](docs/StorefrontUserDto.md)
 - [SurfaceUsageType](docs/SurfaceUsageType.md)
 - [TenantApplicationsInfoDto](docs/TenantApplicationsInfoDto.md)
 - [TenantInfoDto](docs/TenantInfoDto.md)
 - [TenantMeasureUnitsInfoDto](docs/TenantMeasureUnitsInfoDto.md)
 - [TenantUserInfoDto](docs/TenantUserInfoDto.md)
 - [WorkflowType](docs/WorkflowType.md)


<a id="documentation-for-authorization"></a>
## Documentation For Authorization


Authentication schemes defined for the API:
<a id="ApiKey"></a>
### ApiKey

- **Type**: API key
- **API key parameter name**: X-API-Key
- **Location**: HTTP header

<a id="Bearer"></a>
### Bearer

- **Type**: API key
- **API key parameter name**: Authorization
- **Location**: HTTP header

<a id="OAuth2ClientCredentials"></a>
### OAuth2ClientCredentials

- **Type**: OAuth
- **Flow**: application
- **Authorization URL**: 
- **Scopes**: N/A

<a id="OAuth2Implicit"></a>
### OAuth2Implicit

- **Type**: OAuth
- **Flow**: implicit
- **Authorization URL**: https://customerscanvashub.com/connect/authorize
- **Scopes**: 
 - **Projects_full**: Manipulate projects
 - **Projects_read**: Read projects
 - **Templates_full**: Manipulate products
 - **Templates_read**: Read products
 - **Storefronts_full**: Manipulate products
 - **Storefronts_read**: Read products
 - **StorefrontUsers_full**: Manipulate storefront users
 - **StorefrontUsers_read**: Read storefront users
 - **TenantUsers_full**: Manipulate storefront users
 - **TenantUsers_read**: Read storefront users

<a id="oauth2-code"></a>
### oauth2-code

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: https://customerscanvashub.com/connect/authorize
- **Scopes**: 
 - **Projects_full**: Manipulate projects
 - **Projects_read**: Read projects
 - **Templates_full**: Manipulate products
 - **Templates_read**: Read products
 - **Storefronts_full**: Manipulate products
 - **Storefronts_read**: Read products
 - **StorefrontUsers_full**: Manipulate storefront users
 - **StorefrontUsers_read**: Read storefront users
 - **TenantUsers_full**: Manipulate storefront users
 - **TenantUsers_read**: Read storefront users





