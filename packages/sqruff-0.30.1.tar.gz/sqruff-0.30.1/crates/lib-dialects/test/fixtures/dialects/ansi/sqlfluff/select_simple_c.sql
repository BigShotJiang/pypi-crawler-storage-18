select * from foo, bar
