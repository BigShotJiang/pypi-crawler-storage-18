truncate a
