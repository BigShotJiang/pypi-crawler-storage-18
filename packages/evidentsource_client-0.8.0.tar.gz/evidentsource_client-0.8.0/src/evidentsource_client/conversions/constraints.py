"""BatchConstraint type conversions."""

from __future__ import annotations

from evidentsource_core import (
    BatchConstraint,
    MaxConstraint,
    MinConstraint,
    Range,
    RangeConstraint,
)

from evidentsource_client.proto import domain_pb2 as proto

from .error import InvalidRange, MissingField, MissingOneof, NestedConversionError
from .selectors import proto_to_selector, selector_to_proto


# =============================================================================
# Domain -> Proto
# =============================================================================


def constraint_to_proto(constraint: BatchConstraint) -> proto.BatchConstraint:
    """Convert a BatchConstraint to a proto BatchConstraint."""
    if isinstance(constraint, MinConstraint):
        return proto.BatchConstraint(
            min=proto.BatchConstraint.Min(
                selector=selector_to_proto(constraint.selector),
                revision=constraint.revision,
            )
        )
    elif isinstance(constraint, MaxConstraint):
        return proto.BatchConstraint(
            max=proto.BatchConstraint.Max(
                selector=selector_to_proto(constraint.selector),
                revision=constraint.revision,
            )
        )
    elif isinstance(constraint, RangeConstraint):
        return proto.BatchConstraint(
            range=proto.BatchConstraint.Range(
                selector=selector_to_proto(constraint.selector),
                min=constraint.range.min,
                max=constraint.range.max,
            )
        )
    raise TypeError(f"Unknown constraint type: {type(constraint)}")


# =============================================================================
# Proto -> Domain
# =============================================================================


def proto_to_constraint(proto_constraint: proto.BatchConstraint) -> BatchConstraint:
    """Convert a proto BatchConstraint to a BatchConstraint."""
    which = proto_constraint.WhichOneof("constraint")

    if which is None:
        raise MissingOneof("BatchConstraint", "constraint")

    if which == "min":
        min_constraint = proto_constraint.min
        if not min_constraint.HasField("selector"):
            raise MissingField("BatchConstraint.Min", "selector")

        try:
            selector = proto_to_selector(min_constraint.selector)
        except Exception as e:
            raise NestedConversionError("BatchConstraint.Min.selector", e) from e

        return MinConstraint(selector, min_constraint.revision)

    elif which == "max":
        max_constraint = proto_constraint.max
        if not max_constraint.HasField("selector"):
            raise MissingField("BatchConstraint.Max", "selector")

        try:
            selector = proto_to_selector(max_constraint.selector)
        except Exception as e:
            raise NestedConversionError("BatchConstraint.Max.selector", e) from e

        return MaxConstraint(selector, max_constraint.revision)

    elif which == "range":
        range_constraint = proto_constraint.range
        if not range_constraint.HasField("selector"):
            raise MissingField("BatchConstraint.Range", "selector")

        try:
            selector = proto_to_selector(range_constraint.selector)
        except Exception as e:
            raise NestedConversionError("BatchConstraint.Range.selector", e) from e

        try:
            domain_range = Range.new(range_constraint.min, range_constraint.max)
        except Exception:
            raise InvalidRange(range_constraint.min, range_constraint.max)

        return RangeConstraint(selector, domain_range)

    raise MissingOneof("BatchConstraint", "constraint")
