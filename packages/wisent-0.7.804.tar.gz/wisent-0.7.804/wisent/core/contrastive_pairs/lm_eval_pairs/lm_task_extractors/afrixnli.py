from __future__ import annotations

from typing import Any, TYPE_CHECKING

from wisent.core.contrastive_pairs.core.pair import ContrastivePair
from wisent.core.contrastive_pairs.core.response import NegativeResponse, PositiveResponse
from wisent.core.contrastive_pairs.lm_eval_pairs.atoms import LMEvalBenchmarkExtractor
from wisent.core.cli_logger import setup_logger, bind

if TYPE_CHECKING:
    from lm_eval.api.task import ConfigurableTask


__all__ = ["AfrixnliExtractor"]
_LOG = setup_logger(__name__)

task_names = (
    "afrixnli_en_direct_amh",
    "afrixnli_en_direct_eng",
    "afrixnli_en_direct_ewe",
    "afrixnli_en_direct_fra",
    "afrixnli_en_direct_hau",
    "afrixnli_en_direct_ibo",
    "afrixnli_en_direct_kin",
    "afrixnli_en_direct_lin",
    "afrixnli_en_direct_lug",
    "afrixnli_en_direct_orm",
    "afrixnli_en_direct_sna",
    "afrixnli_en_direct_sot",
    "afrixnli_en_direct_swa",
    "afrixnli_en_direct_twi",
    "afrixnli_en_direct_wol",
    "afrixnli_en_direct_xho",
    "afrixnli_en_direct_yor",
    "afrixnli_en_direct_zul",
)

class AfrixnliExtractor(LMEvalBenchmarkExtractor):
    """Extractor for Afrixnli benchmark."""


    evaluator_name = "log_likelihoods"
    def extract_contrastive_pairs(
        self,
        lm_eval_task_data: ConfigurableTask,
        limit: int | None = None,
        preferred_doc: str | None = None,
    ) -> list[ContrastivePair]:
        log = bind(_LOG, task=getattr(lm_eval_task_data, "NAME", "unknown"))
        max_items = self._normalize_limit(limit)
        docs = self.load_docs(lm_eval_task_data, max_items, preferred_doc=preferred_doc)
        pairs: list[ContrastivePair] = []
        log.info("Extracting contrastive pairs", extra={"doc_count": len(docs)})

        for doc in docs:
            pair = self._extract_pair_from_doc(doc)
            if pair is not None:
                pairs.append(pair)
                if max_items is not None and len(pairs) >= max_items:
                    break

        if not pairs:
            task_name = getattr(lm_eval_task_data, "NAME", type(lm_eval_task_data).__name__)
            log.warning("No valid pairs extracted", extra={"task": task_name})

        return pairs

    def _extract_pair_from_doc(self, doc: dict[str, Any]) -> ContrastivePair | None:
        """
        Extract contrastive pair from NLI doc.
        Schema: {'premise': str, 'hypothesis': str, 'label': int}
        Labels: 0=entailment, 1=neutral, 2=contradiction
        """
        log = bind(_LOG, doc_id=doc.get("id", "unknown"))

        try:
            premise = doc.get("premise", "").strip()
            hypothesis = doc.get("hypothesis", "").strip()
            label = doc.get("label")

            if not premise or not hypothesis or label is None:
                log.debug("Skipping doc due to missing/invalid fields", extra={"doc": doc})
                return None

            # Map label to text
            label_map = {
                0: "True",
                1: "Neither",
                2: "False"
            }

            if label not in label_map:
                log.debug(f"Unknown label: {label}", extra={"doc": doc})
                return None

            correct = label_map[label]

            # Pick a different label as incorrect
            incorrect_labels = [l for l in label_map.keys() if l != label]
            if not incorrect_labels:
                return None
            incorrect = label_map[incorrect_labels[0]]

            # Format the NLI prompt
            prompt = f"Premise: {premise}\nHypothesis: {hypothesis}.\nA. {incorrect}\nB. {correct}"

            metadata = {"label": "afrixnli"}

            return self._build_pair(
                question=prompt,
                correct=correct,
                incorrect=incorrect,
                metadata=metadata,
            )

        except Exception as exc:
            log.error("Error extracting pair from doc", exc_info=exc, extra={"doc": doc})
            return None

    @staticmethod
    def _build_pair(
        question: str,
        correct: str,
        incorrect: str,
        metadata: dict[str, Any] | None = None,
    ) -> ContrastivePair:
        positive_response = PositiveResponse(model_response=correct)
        negative_response = NegativeResponse(model_response=incorrect)
        return ContrastivePair(prompt=question, positive_response=positive_response, negative_response=negative_response, label=metadata.get("label"))
