# Open Graph Generator

Open Graph meta tags generator

## Online Tool

Use this tool online at **[DevTools.at](https://devtools.at/tools/open-graph-generator)** - Free, fast, and no registration required!

## Installation

```bash
pip install devtools_open_graph
```

## Usage

```python
from devtools_open_graph import process, encode, decode

# Process input
result = process("your input here")

# Encode
encoded = encode("data to encode")

# Decode
decoded = decode("data to decode")
```

## Features

- Simple, clean API
- No external dependencies
- Works with Python 3.8+

## Online Version

For a full-featured version with a beautiful UI, visit:
**[https://devtools.at/tools/open-graph-generator](https://devtools.at/tools/open-graph-generator)**

## Related Tools

Check out our other developer tools at [DevTools.at](https://devtools.at):
- 100+ free developer tools
- No registration required
- Privacy-focused (client-side processing)

## License

MIT License

---

Made with love by [DevTools.at](https://devtools.at)
