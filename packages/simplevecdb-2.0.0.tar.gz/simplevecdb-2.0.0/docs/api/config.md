# Configuration API

::: simplevecdb.config