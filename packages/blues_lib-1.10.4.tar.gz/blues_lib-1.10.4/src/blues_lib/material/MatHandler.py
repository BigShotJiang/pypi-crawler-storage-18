import re
from copy import deepcopy
from blues_lib.type.chain.AllMatchHandler import AllMatchHandler
from blues_lib.type.output.STDOut import STDOut
from blues_lib.dao.material.MatMutator import MatMutator 

class MatHandler(AllMatchHandler):
  
  _RULE = {
    'fields':{
      "mat_thumb":{
        'image_location':'local', # local or online
        'image_min_width':500,
        'image_max_width':1000,
        'image_min_height':500,
        'image_max_height':1000,
      },
      'mat_title':{
        'min_length':10,
        'max_length':30,
      },
      'mat_paras':{
        'min_length':250,
        'max_length':1000,
        'image_location':'local', # local or online
        'image_min_length':1,
        'image_max_length':8,
        'image_min_width':500,
        'image_max_width':1000,
        'image_min_height':500,
        'image_max_height':1000,
      },
      'mat_texts':{
        'min_length':250,
        'max_length':1000,
      },
      'mat_images':{
        'image_location':'local', # local or online
        'image_min_length':1,
        'image_max_length':16,
        'image_min_width':500,
        'image_max_width':1000,
        'image_min_height':500,
        'image_max_height':1000,
      }
    },
  }
  
  def resolve(self)->STDOut:
    self._entities:list[dict] = self._request.get('entities')
    self._rule:dict = self._request.get('rule') or {}
    
    if not self._entities:
      message:str = "no input entities" 
      return STDOut(200,message,None,None)
    
    return self._calculate()
  
  def _set_entities(self,entities:list[dict])->STDOut:
    self._request['entities'] = entities
    
  def _set_trash(self,rows:list[dict])->STDOut:
    if not self._request.get('trash'):
      self._request['trash'] = []
    if rows:
      self._request['trash'].extend(rows)
    
  def _calculate(self)->STDOut:
    fields = self._rule.get('fields')
    if not fields:
      return STDOut(200,f'{self.__class__.__name__} no fields need to handle')

    valid_entities = []
    trash_entities = []

    for entity in self._entities:
      is_valid,message = self._handle_entity(entity,fields)
      if is_valid:
        entity['mat_stat'] = 'available'
        valid_entities.append(entity)
      else:
        entity['mat_stat'] = 'invalid'
        entity['mat_remark'] = message
        trash_entities.append(entity)

    self._set_entities(valid_entities)
    self._set_trash(trash_entities)
    message:str = f"valid {len(valid_entities)} ; invalid {len(trash_entities)}" 
    return STDOut(200,message,valid_entities,trash_entities)

  def _handle_entity(self,entity:dict,fields:dict)->tuple[bool,str]:
    for field,config in fields.items():
      method = getattr(self,f'_handle_{field}',None)
      if not method:
        continue
      
      defalt_config:dict = self._RULE.get('fields').get(field,{})
      field_config:dict = {**defalt_config,**config} if config else defalt_config
      is_valid,message = method(entity,field_config)
      if not is_valid:
        return (is_valid,message)
    return (True,'ok')

  def _insert_trash(self,rows:list[dict])->STDOut:
    if not rows:
      message:str = "trash rows is empty" 
      return STDOut(200,message,None,None)
    stdout:STDOut = self._insert(rows)
    self._logger.info(f"\n\n{self.__class__.__name__} insert trash output : {stdout}")
    return stdout

  def _insert(self,data:list[dict]|dict)->STDOut:
    if not data:
      message:str = "data is empty" 
      return STDOut(200,message,None,None)

    rows = data if isinstance(data,list) else [data]
    rows:list[dict] = self._get_rule_entities(rows)
    return MatMutator().insert(rows)

  def _get_rule_entities(self,entities:list[dict])->list[dict]:
    extend_entity:dict = self._rule.get('entity') # the merged fields
    inc_fields:list[str] = self._rule.get('inc_fields',[])
    inc_pattern:str = self._rule.get('inc_pattern','')
    exc_fields:list[str] = self._rule.get('dec_fields',[])
    exc_pattern:str = self._rule.get('dec_pattern','')

    sink_entities:list[dict] = []
    
    for entity in entities:
      # must deepcopy to avoid modify the original item (list to string)
      sink_entity:dict = deepcopy(entity)
      # merge the entity
      if extend_entity:
        sink_entity.update(extend_entity)
        
      # include and exclude the fields
      if inc_fields:
        sink_entity = {k:v for k,v in sink_entity.items() if k in inc_fields}

      if inc_pattern:
        sink_entity = {k:v for k,v in sink_entity.items() if re.match(inc_pattern,k)}

      if exc_fields:
        sink_entity = {k:v for k,v in sink_entity.items() if k not in exc_fields}

      if exc_pattern:
        sink_entity = {k:v for k,v in sink_entity.items() if not re.match(exc_pattern,k)}

      sink_entities.append(sink_entity)
    return sink_entities
    

