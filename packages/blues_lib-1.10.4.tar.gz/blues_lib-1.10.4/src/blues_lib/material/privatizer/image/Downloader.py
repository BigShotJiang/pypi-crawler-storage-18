from blues_lib.material.file.MatFile import MatFile
from blues_lib.util.BluesURL import BluesURL
from blues_lib.type.output.STDOut import STDOut

class Downloader():

  @classmethod
  def download_for_paras(cls,entity:dict,config:dict)->tuple[bool,str]:
    paras: list[dict] = entity.get('mat_paras',[])
    image_max_length = config.get('image_max_length')
    if not paras:
      return (False,'no mat_paras')

    image_count = 0
    localized_paras = []
    for para in paras:
      if para['type'] != 'image' and para['value']:
        localized_paras.append(para)
        continue
      
      if not para['value']:
        continue
      
      if image_max_length is not None and image_count >= image_max_length:
        continue
      
      image_url = para['value']
      suffix = f'body-{image_count+1}'
      is_success,local_image = cls.download(entity,image_url,suffix)
      if is_success:
        image_count += 1
        para['value'] = local_image
        localized_paras.append(para)

    if not localized_paras:
      return (False,'no localized_paras')

    entity['mat_paras'] = localized_paras
    return (True,'ok')

  @classmethod
  def download_for_thumb(cls,entity:dict,config:dict)->tuple[bool,str]:
    image_url: str = entity.get('mat_thumb','')
    if not image_url:
      return (False,'no mat_thumb')

    is_success,local_image = cls.download(entity,image_url,'thumb')
    if is_success:
      entity['mat_thumb'] = local_image
    return (is_success,local_image)

  @classmethod
  def download(cls,entity:dict,image_url:str,suffix:str='')->tuple[bool,str]:
    if not BluesURL.is_http_url(image_url):
      return (False,f'not a http url - {image_url}')

    mat_site = entity.get('mat_site')
    mat_id = entity.get('mat_id')
    file_name = f"{mat_id}-{suffix}" if suffix else mat_id

    stdout:STDOut = MatFile.get_download_image(mat_site,file_name,image_url)
    if stdout.code!=200:
      return (False,stdout.message)
    return (True,stdout.data)
