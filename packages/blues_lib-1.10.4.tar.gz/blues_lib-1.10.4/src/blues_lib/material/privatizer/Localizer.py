from blues_lib.material.MatHandler import MatHandler
from blues_lib.material.privatizer.image.Downloader import Downloader
from blues_lib.material.privatizer.image.Formatter import Formatter

class Localizer(MatHandler):

  def _handle_mat_thumb(self,entity:dict,config:dict)->tuple[bool,str]:
    is_success,message = Downloader.download_for_thumb(entity,config)
    if not is_success:
      return (is_success,message)

    return  Formatter.format_for_thumb(entity,config)

  def _handle_mat_paras(self,entity:dict,config:dict)->tuple[bool,str]:
    is_success,message = Downloader.download_for_paras(entity,config)
    if not is_success:
      return (is_success,message)

    return Formatter.format_for_paras(entity,config)