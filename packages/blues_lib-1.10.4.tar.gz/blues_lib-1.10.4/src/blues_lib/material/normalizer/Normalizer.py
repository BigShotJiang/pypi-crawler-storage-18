from blues_lib.material.MatHandler import MatHandler
from blues_lib.type.output.STDOut import STDOut
from blues_lib.util.BluesURL import BluesURL
from blues_lib.util.Algorithm import Algorithm

class Normalizer(MatHandler):

  def _handle_mat_chan(self,entity:dict,config:dict)->tuple[bool,str]:
    entity['mat_chan'] = config.get('value','')

  def _handle_mat_url(self,entity:dict,config:dict)->tuple[bool,str]:
    mat_url:str = entity.get('mat_url','')
    if not mat_url:
      return (False,'no mat_url')
    entity['mat_site'] = BluesURL.get_main_domain(mat_url)
    entity['mat_id'] = Algorithm.md5(mat_url)
    return (True,'ok')

  def _handle_mat_paras(self,entity:dict,config:dict)->tuple[bool,str]:
    rows:list[dict] = entity.get('mat_paras')
    image_min_length = config.get('image_min_length')
    image_max_length = config.get('image_max_length')
    if not rows:
      return (False,'no mat_paras')

    # 如果是llm获取的就是结构化数组无需转换
    paras:list[dict] = []
    if rows[0].get('type'):
      paras = rows
    else:
      image_count:int = 0
      for row in rows:
        image = row.get('image')
        text = row.get('text')
        if image:
          if image_max_length is not None and image_count >= image_max_length:
            continue
          paras.append({'type':'image','value':image})
          image_count += 1
        else:
          paras.append({'type':'text','value':text})

    # set thumb as the first image
    if image_count == 0 and entity.get('mat_thumb'):
      paras.insert(0,{'type':'image','value':entity['mat_thumb']})
    
    # set first image as thumb
    self._set_mat_thumb(entity)

    entity['mat_paras'] = paras
    if image_min_length is not None and image_count < image_min_length:
      return (False,f'mat_paras image is less : {image_count} < {image_min_length}')
    return (True,'ok')
  
  def _set_mat_thumb(self,entity:dict)->None:
    paras:list[dict]|None = entity.get('mat_paras')
    if entity.get('mat_thumb') or not paras:
      return 
    for para in paras:
      if para['type'] == 'image' and para['value']:
        entity['mat_thumb'] = para['value']
        break

  def _handle_mat_images(self,entity:dict,config:dict)->tuple[bool,str]:
    paras:list[dict] = entity.get('mat_images')
    image_min_length = config.get('image_min_length')
    image_max_length = config.get('image_max_length')
    if not paras:
      return (False,'no mat_images')

    image_count:int = len(paras)
    if image_min_length is not None and image_count < image_min_length:
      return (False,f'mat_images image is less : {image_count} < {image_min_length}')

    if image_max_length is not None and image_count > image_max_length:
      entity['mat_images'] = paras[:image_max_length]
    return (True,'ok')
