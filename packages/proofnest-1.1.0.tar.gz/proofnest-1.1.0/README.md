# PROOFNEST

**Proof, not promises.**

Tamper-evident decision logging for AI agents.
Post-quantum cryptography. Bitcoin anchoring. Offline verification.


## Features

- **Post-quantum signatures** - Dilithium3 (NIST ML-DSA)
- **Bitcoin anchoring** - OpenTimestamps for public timestamps
- **Offline verification** - Verify proofs without vendor dependency
- **Agent-first design** - Built for LangChain, LangGraph, CrewAI
- **EU AI Act ready** - Tamper-evident audit trails

## Installation

```bash
pip install proofnest
```

## Quick Start

```python
from proofnest import ProofNest, RiskLevel

# Create decision logger
pn = ProofNest(agent_id="loan-agent")

# Log a decision (automatically signed)
pn.decide(
    action="Approved loan application",
    reasoning="Credit score 750+, DTI < 40%",
    risk_level=RiskLevel.LOW
)

# Verify chain integrity
assert pn.verify()

# Export portable proof bundle
bundle = pn.export()
bundle.to_file("audit_trail.json")
```

## CLI

```bash
# Check version
proofnest --version

# Verify a proof bundle
proofnest verify bundle.json
proofnest verify bundle.json --verbose
```

## Verification

Third-party verification without Stellanium:

```python
from proofnest import verify_proofbundle_standalone
import json

# Anyone can verify with just the public key
bundle_json = open("audit_trail.json").read()
public_key = bytes.fromhex("...")  # From agent's public key
is_valid = verify_proofbundle_standalone(bundle_json, public_key)
```

## Documentation

- [GitHub](https://github.com/proofnest/proofnest)
- [ProofBundle Spec](https://github.com/proofnest/proofnest/blob/main/docs/PROOFBUNDLE_v0.1.md)

## License

Apache-2.0. Copyright (c) 2025 Stellanium Ltd.

PROOFNEST is a trademark of Stellanium Ltd.
