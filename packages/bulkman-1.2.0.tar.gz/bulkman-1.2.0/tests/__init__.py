"""Test suite for bulkman."""
