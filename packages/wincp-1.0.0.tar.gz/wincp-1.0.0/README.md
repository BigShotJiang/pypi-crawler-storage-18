# WinCP

Secure CMP compressor with GUI and CLI.

## CLI examples

Compress:
wincp compress folder output.cmp --password secret --level 9


Extract:


wincp extract archive.cmp output_folder --password secret


GUI:


wincp