import importlib
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import json
from phantomreply.validation import is_valid_email
from termcolor import colored
import sys
from phantomreply.animation import print_ascii_art
from importlib import resources

CONFIG_DIR = os.path.join(os.path.expanduser('~'), '.config', 'phantomreply')

def init_config():
    """
    Initializes the user's configuration directory.
    Copies default assets if they don't exist.
    """
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)

    assets_to_copy = ["config.json", "receivers.txt", "test.txt", "receivers.json"]
    for asset in assets_to_copy:
        user_asset_path = os.path.join(CONFIG_DIR, asset)
        if not os.path.exists(user_asset_path):
            try:
                content = get_file_from_assets(asset)
                if content:
                    with open(user_asset_path, "w", encoding="utf-8") as f:
                        f.write(content)
                    print(colored(f"Created default '{asset}' in {CONFIG_DIR}", 'yellow'))
            except Exception as e:
                print(colored(f"Could not create default asset '{asset}': {e}", 'red'))

class BOT:
    def __init__(self, sender, app_password, server='smtp.gmail.com'):
        self.sender = sender
        self.app_password = app_password
        self.server = server

    def send_email(self, receiver, subject, content, text_subtype='html'):
            msg = MIMEMultipart()
            msg['Subject'] = subject
            msg['From'] = self.sender
            msg['To'] = receiver
            msg.attach(MIMEText(content, text_subtype))

            try:
                conn = smtplib.SMTP(self.server, 587)
                conn.ehlo()
                conn.starttls()
                conn.login(self.sender, self.app_password)
                conn.sendmail(self.sender, receiver, msg.as_string())
                conn.quit()
                print(colored(f"Email sent successfully to {receiver}", 'green'))
            except smtplib.SMTPException as e:
                print(colored(f"Failed to send email to {receiver}. Error: {e}", 'red'))

class FETCHER:
    def __init__(self, config: dict):
        self.config = config

    def extract_details(self):
        if not self.config:
            return {}

        senders = self.config.get('senders', [])
        receivers = self.config.get('groups', {})
        message = self.config.get('message', {})

        return {
            'senders': senders,
            'receivers': receivers,
            'subject': message.get('subject', ''),
            'content': message.get('content', ''),
            'load_file': message.get('load_file'),
            'text_type': message.get('text_type', 'plain'),
            'server': self.config.get('server', 'smtp.gmail.com'),
            'app_password': self.config.get('app_password')
        }




def get_file_from_assets(filename):
    try:
        return importlib.resources.read_text("phantomreply.assets", filename)
    except FileNotFoundError:
        print(colored(f"Asset '{filename}' not found via importlib.resources.", 'red'))
        return None
    except Exception as e:
        print(colored(f"Error reading asset file '{filename}' using importlib: {type(e).__name__}: {e}", 'red'))
        return None

def get_file_from_templates(filename):
    try:
        return importlib.resources.read_text("phantomreply.templates", filename)
    except Exception as e:
        print(colored(f"Error reading template file '{filename}': {e}", 'red'))
        return None


def write_msg():
    print("Enter your message (press Enter for new lines, type 'DONE' on a new line to finish):")
    message = []
    while True:
        try:
            line = input()
            if line.strip().lower() == 'done':
                break
            message.append(line)
        except EOFError:
            break
    return '\n'.join(message)

def get_file_from_static(filename):
    try:
        return importlib.resources.read_text("phantomreply.static", filename)
    except Exception as e:
        print(colored(f"Error reading static asset '{filename}': {e}", 'red'))
        return None


def generate_html_email(template_html, subject, content, button_url):
    if not template_html:
        print("Error: HTML template not found.")
        return None
    css_content = get_file_from_static("styles.css")

    if css_content:
        template_html = f"<style>{css_content}</style>" + template_html

    paragraphs = content.split('\n\n')
    formatted_content = ''.join([f'<p>{p}</p>' for p in paragraphs])
    html_email = template_html.replace("{{subject}}", subject)
    html_email = html_email.replace("{{content}}", formatted_content)
    html_email = html_email.replace("{{button_url}}", button_url)

    return html_email

def load_file(filepath: str) -> str:
    if not filepath:
        return None

    # If the path is not absolute, assume it's in the config directory
    if not os.path.isabs(filepath):
        filepath = os.path.join(CONFIG_DIR, filepath)

    if os.path.exists(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            print(colored(f"Error reading file '{filepath}': {e}", 'red'))
    else:
        print(colored(f"File not found: {filepath}", 'red'))
    
    return None



def load_receivers_from_file(filename: str) -> list:
    if not filename:
        return []

    if not os.path.isabs(filename):
        filepath = os.path.join(CONFIG_DIR, filename)
    else:
        filepath = filename

    if not os.path.exists(filepath):
        print(colored(f"File not found: {filepath}", 'red'))
        return []

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            file_content = f.read()

        receivers = []
        if filename.endswith(".txt"):
            receivers = [line.strip() for line in file_content.splitlines() if line.strip() and is_valid_email(line.strip())]
        elif filename.endswith(".json"):
            data = json.loads(file_content)
            if isinstance(data, list):
                receivers = [email for email in data if isinstance(email, str) and is_valid_email(email)]
        else:
            print(colored("Unsupported file type. Use .txt or .json", 'red'))
            return []

        if not receivers:
            print(colored(f"No valid email addresses found in '{filename}'. Please add emails to the file.", 'yellow'))
        return receivers

    except Exception as e:
        print(colored(f"Error reading receivers file: {e}", 'red'))
        return []


def get_receivers() -> list:
    print(colored("How would you like to provide the receivers?", 'cyan', attrs=['bold']))
    print(colored("1. Enter manually", 'yellow'))
    print(colored("2. Load from file (receivers.json or receivers.txt)", 'yellow'))

    while True:
        choice = input(colored("Enter 1 or 2: ", 'green')).strip()
        if choice == '1':
            receivers_input = input("Enter receiver emails separated by commas: ").strip()
            if not receivers_input:
                print(colored("No receivers entered. Please try again.", 'red'))
                continue
            receivers = [email.strip() for email in receivers_input.split(',') if is_valid_email(email.strip())]
            if not receivers:
                print(colored("No valid email addresses entered. Please try again.", 'red'))
                continue
            return receivers

        elif choice == '2':
            filename = input("Enter the filename (receivers.json or receivers.txt): ").strip()
            receivers = load_receivers_from_file(filename)
            if not receivers:
                print(colored("No valid receivers found in the file. Try again.", 'red'))
                continue
            return receivers
        else:
            print(colored("Invalid choice. Enter 1 or 2.", 'red'))


def main():
    try:
        print_ascii_art()
        init_config()
        config_path = os.path.join(CONFIG_DIR, "config.json")
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config_text = f.read()
        except FileNotFoundError:
            print(colored(f"Configuration file not found at {config_path}", 'red'))
            return
        config = json.loads(config_text)
        fetcher = FETCHER(config)
        details = fetcher.extract_details()

        if not details:
            print(colored("Error: Could not extract details from configuration.", 'red'))
            return

        print(colored("Current Configuration:", 'cyan', attrs=['bold']))
        print(f"Sender Email: {details['senders'][0]}")
        print(f"App Password: {'*****' if details['app_password'] else 'Not set'}")
        print(f"Email Subject: {details['subject']}")
        print(f"Server: {details['server']}")
        if input("Change sender email? (y/n): ").strip().lower() == 'y':
            new_sender = input(colored("New sender email: ", 'green')).strip()
            if not is_valid_email(new_sender):
                print(colored("Invalid email. Exiting.", 'red'))
                return
            details['senders'][0] = new_sender

        if input("Change app password? (y/n): ").strip().lower() == 'y':
            new_password = input(colored("New app password (16 chars): ", 'green')).strip()
            if len(new_password) != 19:
                print(colored("Invalid password length. Exiting.", 'red'))
                return
            details['app_password'] = new_password

        if input("Change email subject? (y/n): ").strip().lower() == 'y':
            details['subject'] = input(colored("New subject: ", 'green')).strip()

        if input("Change email server? (y/n): ").strip().lower() == 'y':
            details['server'] = input(colored("New server (default: smtp.gmail.com): ", 'green')).strip() or 'smtp.gmail.com'

        details['receivers']['group1'] = get_receivers()
        print(colored("How would you like to provide the content?", 'cyan', attrs=['bold']))
        print(colored("1. Manually", 'yellow'))
        print(colored("2. Load from config.json", 'yellow'))
        print(colored("3. Load from a file", 'yellow'))

        while True:
            choice = input(colored("Enter 1, 2, or 3: ", 'green')).strip()
            if choice == '1':
                content_text = write_msg()
                break
            elif choice == '2':
                content_text = details.get('content', '')
                if not content_text:
                    print(colored("No content in config. Enter manually.", 'yellow'))
                    content_text = write_msg()
                break
            elif choice == '3':
                user_path = details.get('load_file')
                if not user_path:
                    user_path = input("Enter file path (or leave empty for default 'test.txt'): ").strip()
                
                if not user_path:
                    user_path = "test.txt"

                content_text = load_file(user_path)
                if not content_text:
                    print(colored(f"Could not load content from '{user_path}'.", 'red'))
                    continue
                break
            else:
                print(colored("Invalid choice. Enter 1, 2, or 3.", 'red'))

        button_url = input("Enter URL to attach (or leave empty for https://github.com): ").strip() or 'https://github.com'

        while True:
            print("\n" + colored("Please review your configuration:", 'cyan', attrs=['bold']))
            print(f"  Sender Email: {details['senders'][0]}")
            print(f"  App Password: {'*****'}")
            print(f"  Email Subject: {details['subject']}")
            print(f"  Server: {details['server']}")
            print(f"  Receivers: {details['receivers']['group1']}")
            print(f"  Button URL: {button_url}")

            # Preview content
            if len(content_text) > 200:
                print(f"  Content: {content_text[:200]}...")
            else:
                print(f"  Content: {content_text}")


            confirm = input(colored("Is this correct? (y/n/back): ", 'green')).strip().lower()
            if confirm == 'y':
                break
            elif confirm == 'n' or confirm == 'back':
                print(colored("Restarting configuration...", 'yellow'))
                main()
                return
            else:
                print(colored("Invalid choice. Please enter 'y', 'n', or 'back'.", 'red'))


        html_template = get_file_from_templates("email_template.html")
        html_email = generate_html_email(html_template, details['subject'], content_text, button_url)
        if html_email is None:
            print(colored("Error generating HTML email.", 'red'))
            return
        bot = BOT(details['senders'][0], details['app_password'], details['server'])
        for receiver in details['receivers'].get('group1', []):
            if receiver and is_valid_email(receiver):
                bot.send_email(receiver, details['subject'], html_email, 'html')
            else:
                print(f"Skipping invalid or empty email: {receiver}")

    except KeyboardInterrupt:
        print(colored("\nExiting gracefully... Bye!", 'blue'))
        sys.exit(0)


if __name__ == '__main__':
    main()

