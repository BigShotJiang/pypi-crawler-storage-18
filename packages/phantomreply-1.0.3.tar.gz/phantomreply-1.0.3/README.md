# PhantomReply  

> **MULTI-ORIGIN TACTICAL DISPATCH SYSTEM**

![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux-green?logo=linux)
![License](https://img.shields.io/badge/License-MIT-yellow)
![Version](https://img.shields.io/badge/Version-1.0.3-orange)
---

## Overview
PhantomReply is a lightweight Python tool for executing multi-origin tactical email deployments through Gmail’s secure SMTP system (App Passwords + 2FA).

It supports:

- HTML or plain-text messages  
- Clean human-styled templates  
- Validation of sender + receiver emails  
- Group emailing via config  
- User-friendly configuration

---

## Gmail Setup (REQUIRED)

### **1. Enable 2FA on your gmail account**
Go to:  
https://myaccount.google.com/security

### **2. Create an App Password**
Required because Gmail blocks normal SMTP passwords.

Go to:  
https://myaccount.google.com/apppasswords

---
# Installation

## Install the package (using PIP)
It is highly recommended to install PhantomReply in a virtual environment.

```bash
# Create and activate a virtual environment
python3 -m venv phantomvenv
source phantomvenv/bin/activate

# Install the package
pip install phantomreply
```

---
# Usage

Once installed, you can run PhantomReply from your terminal:

```bash
phantomreply
```

The application will guide you through the configuration process interactively.

## Configuration Files

When you first run PhantomReply, it will create a configuration directory at `~/.config/phantomreply`. This directory will be populated with the default configuration files:

- `config.json`: Main configuration for senders, groups, and message details.
- `receivers.json`: A list of receiver emails in JSON format.
- `receivers.txt`: A list of receiver emails, one per line.
- `test.txt`: A default email message body.

You can edit these files to customize your experience.

### Loading Receivers and Content

When prompted to load receivers or content from a file, you can provide:
- The name of a file in your configuration directory (e.g., `receivers.txt`).
- An absolute path to a file on your filesystem (e.g., `/path/to/my/receivers.txt`).

### "Go Back" Feature

During the interactive configuration, if you make a mistake, you can easily go back. After you have configured all the options, you will be presented with a summary. If you are not satisfied, you can type `n` or `back` to restart the configuration process.

---
## Features

- Gmail SMTP (secure)
- Email validation for sender & receivers
- HTML template loading
- CSS support
- User-editable configuration files
- Group email support
- Error handling and safe execution
- Interactive configuration with a "go back" option

## License
This project is licensed under the MIT License - see the [LICENSE](https://github.com/cyb2rS2c/PhantomReply/blob/main/LICENSE) file for details.

## Disclaimer
The software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.
