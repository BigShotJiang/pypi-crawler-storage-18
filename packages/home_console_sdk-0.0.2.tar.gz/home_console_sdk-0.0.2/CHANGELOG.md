# Changelog

## [0.0.2] - 2025-12-26

### ✨ Добавлено

#### Dependency Injection для моделей
- **InternalPluginBase**: Добавлен параметр `models` в `__init__()`
  - Плагины теперь получают модели через DI: `self.models = {'Device': Device, ...}`
  - Убирает необходимость импорта `from ...models import Device`
  - Плагины становятся независимыми от кодовой базы core-service
  - Пример: `Device = self.models.get('Device')`
  - Доступные модели: Device, PluginBinding, IntentMapping, Plugin, PluginVersion

#### Router Management
- **InternalPluginBase**: Автоматическое управление жизненным циклом роутов
  - Добавлены свойства `_is_loaded` и `_router_mounted` для отслеживания состояния
  - Добавлен метод `mount_router()` для автоматической регистрации роутов в FastAPI
  - Добавлен метод `unmount_router()` для автоматического удаления роутов при выгрузке плагина
  - Добавлены свойства `is_loaded` и `is_router_mounted` для проверки состояния
  - Роуты автоматически отключаются при ошибке загрузки или вызове `on_unload()`

#### Аутентификация без зависимостей от ядра
- **InternalPluginBase**: Добавлен метод `_get_current_user_id(request: Request) -> str`
  - Полностью изолирован от кодовой базы core-service
  - Использует только Dependency Injection и `request.state` (устанавливается middleware)
  - Поддерживает Bearer токены (Authorization header) и cookie-авторизацию
  - Автоматически получает `get_current_user_fn` из `app.state` (если доступен)
  - Обрабатывает разные форматы: User объекты, dict payload, token payload
  - Может быть переопределен плагинами для кастомной логики
  - Пример использования: `user_id = await self._get_current_user_id(request)`

#### Документация
- **OAUTH_INTEGRATION.md**: Полное руководство по OAuth интеграции
  - Архитектура OAuth в плагинах
  - Пример структуры БД для токенов (YandexAccount)
  - OAuth Flow: получение URL, обработка callback, использование токенов
  - Группировка роутов через APIRouter prefix
  - Безопасность: проверка пользователя, хранение секретов, защита от CSRF
  - Обновление токенов через refresh_token
  - Автоматическая синхронизация после OAuth
  - Checklist для OAuth интеграции
  - Примеры на основе Yandex Smart Home
  - Обновлен пример `_get_current_user_id` - теперь использует встроенный метод SDK

### 📝 Улучшения

- **Router Organization**: Показаны best practices для группировки endpoints
  - Использование `APIRouter(prefix="/scope")` для логической группировки
  - Создание отдельных роутеров для auth, devices, sync, intents
  - Объединение через `router.include_router()`
  - Итоговые пути: `/plugins/{plugin_id}/{scope}/{endpoint}`

### 🔧 Примеры

- Обновлен Yandex Smart Home плагин с использованием prefix:
  - `/auth` scope - OAuth endpoints (start, status, unlink)
  - `/devices` scope - управление устройствами
  - `/action` scope - действия на устройствах
  - `/sync` scope - синхронизация (devices, states, discover)
  - `/intents` scope - голосовые команды Алисы

---

## [0.0.1] - 2025-12-24

### ✨ Добавлено

#### Критические исправления
- **DatabaseClient**: Полная реализация работы с БД
  - Добавлены недостающие импорты (Optional, List, Dict, Type, re, logging)
  - Реализован метод `_validate_table_access()` для проверки доступа к таблицам
  - Реализован метод `get_session()` для управления сессиями
  - Завершена реализация `register_model()` для регистрации SQLAlchemy моделей
  - Добавлена поддержка параметризованных запросов через `Dict[str, Any]`
  - Добавлены методы `close()`, `__aenter__`, `__aexit__` для context manager

- **EventsClient**: Исправлена работа с событиями
  - Добавлена инициализация `_event_bus` в конструкторе
  - Исправлен метод `emit()` - теперь принимает `Dict[str, Any]` вместо `**kwargs`
  - Добавлены методы `subscribe()` и `unsubscribe()`
  - Улучшен декоратор `@on()` с поддержкой async функций
  - Добавлено логирование событий

- **InternalPluginBase**: Интеграция клиентов
  - Добавлены свойства `self.db` (DatabaseClient)
  - Добавлены свойства `self.events` (EventsClient)
  - Добавлены свойства `self.config` (PluginConfig)
  - Добавлены свойства `self.tasks` (TaskManager)
  - Методы `emit_event()` и `subscribe_event()` теперь используют EventsClient

#### Новые модули

- **config.py**: Управление конфигурацией плагинов
  - `PluginConfig` класс для работы с переменными окружения
  - Методы: `get()`, `get_int()`, `get_bool()`, `get_float()`, `get_list()`, `get_dict()`
  - Метод `require()` для обязательных параметров
  - Метод `load_from_model()` для загрузки из Pydantic моделей
  - Поддержка кэширования значений

- **tasks.py**: Фоновые задачи и планировщик
  - `BackgroundTask` класс для фоновых задач
  - `TaskManager` для управления задачами плагина
  - Методы: `add_task()`, `remove_task()`, `schedule_once()`, `schedule_at()`
  - Декораторы: `@background_task()`, `@schedule()`
  - Автоматическая обработка ошибок и логирование

- **auth.py**: Аутентификация и безопасность
  - `PluginAuth` класс для проверки API ключей и токенов
  - FastAPI dependencies: `require_api_key()`, `require_bearer_token()`
  - Поддержка Bearer токенов и API ключей через заголовки
  - Интеграция с переменными окружения

#### Улучшения

- **__init__.py**: Обновлены экспорты
  - Добавлены все новые модули и классы
  - Улучшена организация exports по категориям
  - Сохранена обратная совместимость с `SmartHomeSDKError`

- **README.md**: Полностью переписан
  - Добавлены примеры для всех возможностей SDK
  - Документация по DatabaseClient, EventsClient, PluginConfig, TaskManager
  - Примеры встроенных и внешних плагинов
  - Инструкции по установке и использованию
  - Описание структуры SDK

- **examples.py**: Создан файл с примерами
  - Пример плагина погоды с БД, API, событиями
  - Пример внешнего Telegram бота
  - Примеры конфигурации
  - Примеры фоновых задач
  - Примеры аутентификации
  - Примеры работы с событиями
  - Пример использования HTTP клиента

- **setup.py**: Обновлены зависимости
  - Добавлена `sqlalchemy>=2.0.0`
  - Добавлена секция `extras_require` для dev-зависимостей
  - Обновлена версия до 0.1.0
  - Добавлена поддержка Python 3.12

- **requirements.txt**: Обновлены зависимости
  - Добавлена `sqlalchemy>=2.0.0`
  - Добавлена `fastapi>=0.104.0`

### 🐛 Исправлено

- Импорты в README (было `smarthome_sdk`, стало `home_console_sdk`)
- Отсутствие типизации в критичных местах
- Пустой файл auth.py теперь содержит рабочую реализацию
- Методы InternalPluginBase теперь используют обертки вместо прямого обращения к event_bus

### 🚀 Миграция с 0.0.1

Изменения обратно совместимы, но рекомендуется использовать новые API:

```python
# Старый способ (все еще работает)
await self.event_bus.emit(f"{self.id}.event", data)

# Новый способ (рекомендуется)
await self.emit_event("event", data)
# или напрямую через клиент
await self.events.emit("event", data)

# Работа с БД - теперь через self.db
results = await self.db.query("SELECT * FROM my_plugin_table")

# Конфигурация - теперь через self.config
api_key = self.config.require("API_KEY")

# Фоновые задачи - теперь через self.tasks
self.tasks.add_task("sync", self.sync_func, interval=60.0)
```

## [0.0.1] - 2025-12-XX

### Первоначальный релиз (с проблемами)
- Базовая структура SDK
- PluginBase и InternalPluginBase
- CoreAPIClient
- Базовые модели (User, Device, Plugin)
- Заглушки для DatabaseClient и EventsClient (не работали)
