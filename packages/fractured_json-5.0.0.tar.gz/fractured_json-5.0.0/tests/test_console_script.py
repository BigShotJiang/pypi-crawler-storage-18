import re
from pathlib import Path

import pytest

from fractured_json import (
    __version__ as fractured_json_version,  # pyright: ignore[reportAttributeAccessIssue]
)


def test_version(script_runner):
    ret = script_runner.run(["fractured-json", "--version"], print_result=False)
    assert ret.success
    assert ret.stdout == fractured_json_version + "\n"
    assert ret.stderr == ""


def test_help(script_runner):
    ret = script_runner.run(["fractured-json", "--help"], print_result=False)
    assert ret.success
    assert "Format JSON into compact, human readable form" in ret.stdout
    assert "max-total-line-length N" in ret.stdout
    assert ret.stderr == ""


def test_no_args(script_runner):
    ret = script_runner.run(["fractured-json"], print_result=False)
    assert ret.success
    assert "Format JSON into compact, human readable form" in ret.stdout
    assert "max-total-line-length N" in ret.stdout
    assert ret.stderr == ""


def test_all_args(script_runner, pytestconfig):
    ret = script_runner.run(
        [
            "fractured-json",
            "--allow-trailing-commas",
            "--always-expand-depth=2",
            "--colon-before-prop-name-padding",
            "--colon-padding",
            "--comma-padding",
            "--comment-padding",
            "--comment-policy=PRESERVE",
            "--indent-spaces=2",
            "--json-eol-style=LF",
            "--max-compact-array-complexity=2",
            "--max-inline-complexity=2",
            "--max-prop-name-padding=2",
            "--max-table-row-complexity=2",
            "--max-total-line-length=100",
            "--min-compact-array-row-items=2",
            "--nested-bracket-padding",
            "--number-list-alignment=LEFT",
            "--prefix-string=::",
            "--preserve-blank-lines",
            "--simple-bracket-padding",
            "--table-comma-placement=BEFORE_PADDING_EXCEPT_NUMBERS",
            "--use-tab-to-indent",
            "--east-asian-chars",
            "tests/data/test-comments-0.jsonc",
        ],
        print_result=False,
    )

    ref_output = Path("tests/data/test-comments-0.ref-1.jsonc").read_text()
    if pytestconfig.getoption("test_verbose") and ret.stdout != ref_output:
        json_string_dbg = ">" + re.sub(r"\n", "<\n>", ret.stdout) + "<"
        ref_json_dbg = ">" + re.sub(r"\n", "<\n>", ref_output) + "<"
        print("===== TEST")
        print(json_string_dbg)
        print("===== REF")
        print(ref_json_dbg)
        print("=====")

    assert ret.stderr == ""
    assert ret.success
    assert ret.stdout == ref_output


def test_unicode(script_runner):
    ret = script_runner.run(
        [
            "fractured-json",
            "--east-asian-chars",
            "--json-eol-style=CRLF",
            "tests/data/test-wide-chars.json",
        ],
        print_result=False,
    )
    assert ret.stderr == ""
    assert ret.success
    # Use read_bytes() to get \r
    ref_output = Path("tests/data/test-wide-chars.ref-1.json").read_bytes().decode("utf-8")
    assert ret.stdout == ref_output


@pytest.mark.script_launch_mode("subprocess")
def test_main(script_runner):
    ret = script_runner.run(["python3", "-m", "fractured_json", "--help"])
    assert ret.stderr == ""
    assert ret.success
    assert "[-h] [-V] [--output" in ret.stdout


@pytest.mark.script_launch_mode("subprocess")
def test_stdin(script_runner):
    with open("tests/data/test-bool.json") as fh:
        ret = script_runner.run(["fractured-json", "-"], stdin=fh)
        assert ret.stderr == ""
        assert ret.success
        assert ret.stdout == '{ "bools": {"true": true, "false": false} }\n'


def test_multifile(script_runner):
    ret = script_runner.run(
        ["fractured-json", "tests/data/test-bool.json", "tests/data/test-bool.json"],
    )
    assert ret.stderr == ""
    assert ret.success
    assert ret.stdout == '{ "bools": {"true": true, "false": false} }\n' * 2


def test_output(script_runner, tmp_path):
    tmp_file = tmp_path / "test.json"
    ret = script_runner.run(
        ["fractured-json", "tests/data/test-bool.json", "--output", str(tmp_file)],
    )
    assert ret.stderr == ""
    assert ret.success
    assert tmp_file.read_text() == '{ "bools": {"true": true, "false": false} }\n'


def test_output_mismatched_number_of_files(script_runner):
    ret = script_runner.run(
        [
            "fractured-json",
            "tests/data/test-bool.json",
            "--output",
            "foo",
            "--output",
            "bar",
        ],
    )
    assert ret.stderr == "fractured-json: the numbers of input and output file names do not match\n"
    assert ret.returncode == 1
