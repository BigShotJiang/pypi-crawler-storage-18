import sys
from pathlib import Path

# Add parent directory to path so we can import the package
parent_dir = str(Path(__file__).parent.parent)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from threading import Thread
from time import sleep

import streamlit as st
from streamlit.runtime.scriptrunner import add_script_run_ctx, get_script_run_ctx

from streamlit_fhir_questionnaire import streamlit_fhir_questionnaire

st.set_page_config(layout="wide")

st.title("FHIR Questionnaire Component Example")


st.markdown("---")

if "last_response" not in st.session_state:
    st.session_state["last_response"] = {
        "questionnaire": "test",
        "status": "in-progress",
        "resourceType": "QuestionnaireResponse",
        "item": [
            {
                "linkId": "1",
                "text": "Patient Information",
                "answer": [],
                "item": [
                    {
                        "linkId": "1-1",
                        "text": "What is the patient's name?",
                        "answer": [
                            {
                                "valueString": "The patient name was not provided.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "1-2",
                        "text": "What is the patient's age?",
                        "answer": [
                            {
                                "valueString": None,
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "1-3",
                        "text": "What is the patient's gender?",
                        "answer": [
                            {
                                "valueString": None,
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": {"display": "male", "code": "male"},
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "1-4",
                        "text": "What is the patient's medical history relevant to this procedure?",
                        "answer": [
                            {
                                "valueString": "The patient has a history of scrotal issues, possibly including previous surgeries or conditions affecting the testicles or scrotum. There may be a history of pain, swelling, or other symptoms that led to the decision for bilateral orchiectomy. Additionally, any relevant medical conditions such as diabetes, bleeding disorders, or allergies to anesthesia should be noted, as they could impact the procedure and recovery.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                ],
            },
            {
                "linkId": "2",
                "text": "Procedure Details",
                "answer": [],
                "item": [
                    {
                        "linkId": "2-1",
                        "text": "What was the position of the patient during the procedure?",
                        "answer": [
                            {
                                "valueString": "The patient was placed in the supine position during the procedure.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-2",
                        "text": "What type of anesthesia was administered?",
                        "answer": [
                            {
                                "valueString": "General anesthesia with 0.25% Marcaine for postoperative pain relief.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-3",
                        "text": "Describe the incision made during the procedure.",
                        "answer": [
                            {
                                "valueString": "The incision made during the procedure was a transverse mid scrotal incision.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-4",
                        "text": "What technique was used to achieve hemostasis?",
                        "answer": [
                            {
                                "valueString": "Bovie electrocautery and suture ligation with 0 chromic catgut were used to achieve hemostasis.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-5",
                        "text": "What type of suture was used for ligation of the spermatic cords?",
                        "answer": [
                            {
                                "valueString": "0 chromic catgut",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-6",
                        "text": "What medication was used for postoperative pain relief?",
                        "answer": [
                            {
                                "valueString": "0.25% Marcaine",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-7",
                        "text": "How was the incision closed after the procedure?",
                        "answer": [
                            {
                                "valueString": "The incision was closed in two layers using 4-0 chromic catgut continuous for the dartos and interrupted for the skin.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-8",
                        "text": "What type of dressing was applied postoperatively?",
                        "answer": [
                            {
                                "valueString": "A dry sterile dressing fluff and scrotal support",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                    {
                        "linkId": "2-9",
                        "text": "What was the patient's condition upon transfer to the Recovery Room?",
                        "answer": [
                            {
                                "valueString": "The patient was sent to the Recovery Room in stable condition.",
                                "valueDate": None,
                                "valueDecimal": None,
                                "valueCoding": None,
                                "item": [],
                            }
                        ],
                        "item": [],
                    },
                ],
            },
        ],
    }

questionnaire = {
    "name": "bilateral_scrotal_orchectomy_procedure",
    "title": "Bilateral Scrotal Orchectomy Procedure Questionnaire",
    "item": [
        {
            "linkId": "1",
            "text": "Patient Information",
            "type": "group",
            "item": [
                {
                    "linkId": "1-1",
                    "text": "What is the patient's name?",
                    "type": "string",
                    "code": "359748005",
                },
                {
                    "linkId": "1-2",
                    "text": "What is the patient's age?",
                    "type": "decimal",
                    "code": "370927008",
                },
                {
                    "linkId": "1-3",
                    "text": "What is the patient's gender?",
                    "type": "coding",
                    "answerConstraint": "optionsOnly",
                    "answerOption": [
                        {"valueCoding": {"code": "male", "display": "male"}},
                        {"valueCoding": {"code": "female", "display": "female"}},
                        {"valueCoding": {"code": "other", "display": "other"}},
                    ],
                    "code": "359748005",
                },
                {
                    "linkId": "1-4",
                    "text": "What is the patient's medical history relevant to this procedure?",
                    "type": "text",
                    "code": "314959007",
                    "extension": [
                        {
                            "url": "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
                            "valueCodeableConcept": {
                                "coding": [
                                    {
                                        "system": "http://fhir.tiro.health/CodeSystem/tiro-questionnaire-item-control",
                                        "code": "notes",
                                    }
                                ]
                            },
                        }
                    ],
                },
            ],
            "code": "103313004",
        },
        {
            "linkId": "2",
            "text": "Procedure Details",
            "type": "group",
            "item": [
                {
                    "linkId": "2-1",
                    "text": "What was the position of the patient during the procedure?",
                    "type": "string",
                    "code": "440599001",
                },
                {
                    "linkId": "2-2",
                    "text": "What type of anesthesia was administered?",
                    "type": "string",
                    "code": "398275004",
                },
                {
                    "linkId": "2-3",
                    "text": "Describe the incision made during the procedure.",
                    "type": "text",
                    "code": "8181006",
                    "enableWhen": [
                        {
                            "question": "2-1",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-4",
                    "text": "What technique was used to achieve hemostasis?",
                    "type": "string",
                    "code": "314959007",
                    "enableWhen": [
                        {
                            "question": "2-2",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-5",
                    "text": "What type of suture was used for ligation of the spermatic cords?",
                    "type": "string",
                    "code": "116680003",
                    "enableWhen": [
                        {
                            "question": "2-4",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-6",
                    "text": "What medication was used for postoperative pain relief?",
                    "type": "string",
                    "code": "77880009",
                    "enableWhen": [
                        {
                            "question": "2-5",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-7",
                    "text": "How was the incision closed after the procedure?",
                    "type": "text",
                    "code": "419111009",
                    "enableWhen": [
                        {
                            "question": "2-3",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-8",
                    "text": "What type of dressing was applied postoperatively?",
                    "type": "string",
                    "code": "116680003",
                    "enableWhen": [
                        {
                            "question": "2-7",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
                {
                    "linkId": "2-9",
                    "text": "What was the patient's condition upon transfer to the Recovery Room?",
                    "type": "string",
                    "code": "398161000",
                    "enableWhen": [
                        {
                            "question": "2-6",
                            "operator": "exists",
                            "answerBoolean": True,
                        }
                    ],
                },
            ],
            "code": "71388002",
        },
    ],
    "resourceType": "Questionnaire",
}


# @st.fragment
# def test():
#     name = st.number_input(
#         "Enter the patient's name",
#         min_value=0,
#         max_value=100,
#         value=0,
#         step=1,
#         format="%d",
#     )

#     questionnaire_response["item"][0]["item"][0]["answer"][0]["valueString"] = name
#     streamlit_fhir_questionnaire(
#         questionnaire=questionnaire,
#         questionnaire_response=questionnaire_response,
#         key="atticus",
#     )


# test()
# print("test")
# print("-----------------")


def fetch_response():
    for i in range(10):
        print("Update the questionnaire response")
        prev_qr = st.session_state["last_response"]
        next_qr = {**prev_qr}
        next_qr["item"][0]["item"][0]["answer"][0]["valueString"] = i
        st.session_state["last_response"] = next_qr
        sleep(1)


def callback():
    print("Callback called")
    thread = Thread(target=fetch_response)
    add_script_run_ctx(thread, get_script_run_ctx())
    thread.start()
    # thread.join()


@st.fragment(run_every="1s")
def filler(response):
    print(
        "rerender filler",
        response["item"][0]["item"][0]["answer"][0]["valueString"],
    )
    streamlit_fhir_questionnaire(
        questionnaire=questionnaire,
        questionnaire_response=response,
        key="atticus",
        streaming=True,
    )


# if st.session_state.counter == 0:
#     st.button("Click me", on_click=start)
st.button("Click me", on_click=callback)
print(
    st.session_state["last_response"]["item"][0]["item"][0]["answer"][0]["valueString"]
)


filler(st.session_state["last_response"])
