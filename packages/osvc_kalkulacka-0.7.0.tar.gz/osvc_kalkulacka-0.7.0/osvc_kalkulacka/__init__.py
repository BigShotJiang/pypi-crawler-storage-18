"""OSVC kalkulacka package."""
