from . import main
main()
