"""Connection utilities."""
