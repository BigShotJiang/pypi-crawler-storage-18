# Mai-Tai: Async Human-Agent Collaboration

**When to use these tools:** Whenever the user mentions "mai-tai", "mai tai", "start mai-tai mode",
"enter mai-tai mode", or asks you to communicate via mai-tai channels.

## CRITICAL: How Mai-Tai Mode Works

When mai-tai mode is active, **ALL your responses must go through `chat_with_human`**.
Do NOT respond in the terminal/IDE - the human is watching the mai-tai web app, not your terminal.

**Correct flow:**
1. User says "start mai-tai mode"
2. You call `chat_with_human("Hey! I'm connected and ready. What would you like me to work on?")`
3. Wait for their response (the tool blocks automatically)
4. Do the work they requested
5. Call `chat_with_human("Done! Here's what I did... What's next?")`
6. Repeat

**Wrong:** Printing responses to the terminal. The human won't see them!

## How to Communicate: `chat_with_human`

You have one simple tool for all communication: **`chat_with_human`**

Use it for everything - questions, status updates, progress reports, and check-ins. It always waits for a response so the conversation keeps flowing naturally.

**Examples:**
- Questions: "Hey, should I use Redis or PostgreSQL for the cache?"
- Status updates: "Starting the database migration now... what should I prioritize after?"
- Approval: "I'm about to delete 50 unused files. Cool to proceed?"
- Check-ins: "All done with the auth refactor! What should I tackle next?"

**Parameters:**
- `message` - What you want to say (be clear and conversational)
- `timeout_seconds` - How long to wait for a response (default: 0 = wait forever)

## When You Finish a Task

**Always check in with the human!** This keeps the conversation going so they can give you the next task:
- "All done with the auth refactor! What should I tackle next?"
- "Finished setting up the CI pipeline. Ready for the next task when you are!"
- "Migration complete, all tests passing. What's the next priority?"

This keeps the collaboration flowing naturally, like working with a teammate.

## Mai-Tai Mode - When the Human Steps Away

Mai-tai mode kicks in when the human steps away but wants you to keep working. There are two common patterns:

### Pattern 1: Inline task (most common)

The human gives you the task as they're leaving:

> "Hey, I'm going to lunch. Can you finish the auth refactor and add tests? I'll check in when I'm back."

**Your response:**
1. Acknowledge: "Got it! I'll finish the auth refactor and add tests. I'll ping you with progress."
2. Start working immediately - you already have your marching orders.

### Pattern 2: Formal handoff

The human announces they're stepping away without a specific task:

> "Entering mai-tai mode" or "I'm stepping out for a bit"

**Your response:**
1. Ask what they want you to work on (with a longer timeout like 30 min).
2. Wait for their response - they'll tell you the task before leaving.
3. Acknowledge, then start working.

### While They're Away

- **Keep working autonomously** on the task they gave you.
- **Use longer timeouts** - `timeout_seconds=1800` (30 min) or longer since they're AFK.
- **Send progress updates** at major milestones - it's fine if they don't respond immediately.
- **Batch non-urgent questions** - group smaller questions together when possible.

## Exiting Mai-Tai Mode

When the human says "exit mai-tai mode", "stop mai-tai", "I'm back", or similar:

1. **Stop using mai-tai tools** - no more `chat_with_human` calls
2. **Resume normal conversation** - respond directly in the terminal/IDE as usual
3. **Give a brief summary** of what you accomplished while in mai-tai mode

**Example:**
> Human (in mai-tai): "exit mai-tai mode"
> You (in terminal): "Got it, exiting mai-tai mode! While you were away, I completed the auth refactor and added 12 tests. All passing. What's next?"

## Timeouts

The default timeout is **0 (wait forever)** - the tool will keep polling until the human responds.

You can set a specific timeout if needed:
- `timeout_seconds=300` (5 min) - for quick questions when human is active
- `timeout_seconds=1800` (30 min) - reasonable upper bound for AFK scenarios

### Progress Updates

Keep the human informed, but don't spam them:

- **Major milestones** - "Auth refactor done, starting on tests now. Anything else to prioritize?"
- **When you hit a snag** - "Running into an issue with the DB connection. Any ideas?"
- **When you finish** - Always check in when the task is complete.

**Too quiet:** Human wonders if you're stuck or still working.
**Too chatty:** Human gets notification fatigue and ignores updates.

Find the balance - think "helpful coworker", not "status report bot".

## Other Tools

Beyond `chat_with_human`, you have a few utility tools:

| Tool | When to Use |
|------|-------------|
| `get_messages` | Catch up on channel history. Useful at the start of a long task, after a timeout, or to see what the human said while you were working. |
| `list_channels` | See what channels exist in the project. Useful if you want to post to a specific channel. |
| `get_channel` | Get details about a specific channel (message count, type, etc.). |
| `get_project_info` | See project metadata. Rarely needed, but available. |

## Channels

- By default, `chat_with_human` posts to the project's **first channel**.
- If multiple channels exist (e.g., `general`, `backend`, `frontend`), pick the one that matches your work.
- Use `list_channels` to see what's available.
- When in doubt, use the default - the human will redirect you if needed.

## Error Handling

If a tool returns `"status": "error"`, read the error message and decide:

- **Transient failures** (network timeout, rate limit) - Wait a moment and retry.
- **Missing resource** (channel not found, invalid ID) - Check your inputs or ask the human.
- **Permission denied** - Ask the human for help.

When in doubt, tell the human what happened: "I got an error trying to X - here's what it said: ..."

## Tips

- **Acknowledge, then work** - When you get a task, send a quick "Got it, working on X!" so the human knows you received it, then do the work.
- **Use markdown** - Messages support full markdown including **bold**, `code`, and code blocks:
  ```python
  def example():
      return "syntax highlighted!"
  ```
- **Be conversational** - Write like you're messaging a coworker, not filing a report.
- **Ask early, ask often** - Humans prefer being asked over being surprised.
- **Give context** - Include what you found, what you tried, what options you see.
