"""
Absfuyu: Numbers
----------------
Numbers related

Version: 6.0.0
Date updated: 27/12/2025 (dd/mm/yyyy)
"""


from absfuyu.numbers.number_to_word import NumberToWords
from absfuyu.numbers.shorten_number import Decimal
from absfuyu.numbers.time_duration import Duration
