# DuckDice CLI

A powerful and beautiful CLI application for the DuckDice Bot API. 

## Features

- **Beautiful UI**: Tables, colors, and panels powered by `rich`.
- **Easy Configuration**: Securely store your API key locally.
- **Full Betting Suite**: Original Dice and Range Dice support.
- **Wallet Monitoring**: Check your balances and user stats at a glance.

## Installation

```bash
pip install duckdice-cli
```

## Quick Start

1. **Set your API Key**:
   ```bash
   duckdice config set your_api_key_here
   ```

2. **Check your profile**:
   ```bash
   duckdice user
   ```

3. **Check balances**:
   ```bash
   duckdice balance
   ```

4. **Place a bet**:
   ```bash
   # 50% chance bet on DOGE for 0.1 amount
   duckdice play dice -s DOGE -a 0.1 -c 50 --high
   ```

5. **Place a range bet**:
   ```bash
   # Bet inside [0, 4999] range
   duckdice play range -s DOGE -a 0.1 --min 0 --max 4999 --in
   ```

## License

MIT
