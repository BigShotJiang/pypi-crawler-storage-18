### Metric name constants
## General metrics
METRIC_GENERAL_HALLUCINATION_CHECK = "general_hallucination_check"
METRIC_GENERAL_VALUE_FORMAT_ALIGNMENT = "general_value_format_alignment"
METRIC_GENERAL_CONVERSATION_GROUNDED_CORRECTNESS = (
    "general_conversation_grounded_correctness"
)

## Function selection metrics
METRIC_FUNCTION_SELECTION_APPROPRIATENESS = "function_selection_appropriateness"
METRIC_AGENTIC_CONSTRAINTS_SATISFACTION = "agentic_constraints_satisfaction"

## Parameter metrics
METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT = "parameter_value_format_alignment"
METRIC_PARAMETER_HALLUCINATION_CHECK = "parameter_hallucination_check"

## Metric category mapping
GENERAL_METRICS = [
    METRIC_GENERAL_HALLUCINATION_CHECK,
    METRIC_GENERAL_VALUE_FORMAT_ALIGNMENT,
]

## Tool-spec-free metrics (can run without tool specifications)
TOOL_SPEC_FREE_METRICS = [
    METRIC_GENERAL_CONVERSATION_GROUNDED_CORRECTNESS,
]

FUNCTION_SELECTION_METRICS = [
    METRIC_FUNCTION_SELECTION_APPROPRIATENESS,
    METRIC_AGENTIC_CONSTRAINTS_SATISFACTION,
]

PARAMETER_METRICS = [
    METRIC_PARAMETER_VALUE_FORMAT_ALIGNMENT,
    METRIC_PARAMETER_HALLUCINATION_CHECK,
]
