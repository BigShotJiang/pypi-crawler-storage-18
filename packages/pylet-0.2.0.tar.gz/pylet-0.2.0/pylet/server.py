"""
PyLet Server - FastAPI REST API for the controller.

Provides /instances endpoints for instance management and /workers for worker management.
Implements unified heartbeat protocol with long-poll.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.requests import Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from pylet import config
from pylet.controller import Controller
from pylet.logger import logger
from pylet.schemas import (
    HeartbeatRequest,
    InstanceStatus,
    ResourceSpec,
    WorkerRegistrationResponse,
    get_display_status,
)


# Request/Response models for API
class EndpointReport(BaseModel):
    host: str
    port: int


class InstanceSubmissionRequest(BaseModel):
    """Request to submit a new instance."""
    command: str
    resource_requirements: ResourceSpec
    name: Optional[str] = None


class WorkerRegistrationRequest(BaseModel):
    worker_id: str
    host: str
    resources: ResourceSpec
    boot_id: Optional[str] = None


controller = Controller()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    # Startup
    logger.info("Starting pylet server.")
    await controller.startup()

    # Start background tasks
    liveness_task = asyncio.create_task(controller.liveness_loop())
    scheduler_task = asyncio.create_task(controller.scheduler_loop())

    try:
        yield
    finally:
        # Shutdown
        logger.info("Shutting down pylet server.")
        liveness_task.cancel()
        scheduler_task.cancel()
        try:
            await liveness_task
            await scheduler_task
        except asyncio.CancelledError:
            pass
        await controller.shutdown()


app = FastAPI(lifespan=lifespan)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
):
    logger.error(f"Validation error for request {request.url}: {exc}")
    return JSONResponse(
        status_code=422,
        content=jsonable_encoder({"detail": exc.errors(), "body": exc.body}),
    )


# ========== Instance Endpoints ==========


@app.get("/instances")
async def list_instances(status: Optional[str] = None):
    """
    List all instances, optionally filtered by status.

    Query params:
    - status: Filter by status (e.g., "RUNNING", "PENDING")
    """
    instances = await controller.get_all_instances(status)
    return [
        {
            "instance_id": inst["id"],
            "name": inst["name"],
            "command": inst["command"],
            "status": inst["status"],
            "display_status": get_display_status(
                InstanceStatus(inst["status"]),
                inst.get("cancel_requested_at")
            ),
            "attempt": inst["attempt"],
            "assigned_to": inst["assigned_worker"],
            "endpoint": inst["endpoint"],
            "port": inst["port"],
            "exit_code": inst["exit_code"],
            "failure_reason": inst["failure_reason"],
            "created_at": inst["created_at"],
            "assigned_at": inst["assigned_at"],
            "started_at": inst["started_at"],
            "ended_at": inst["ended_at"],
            "cancellation_requested_at": inst.get("cancel_requested_at"),
        }
        for inst in instances
    ]


@app.post("/instances")
async def submit_instance(request: InstanceSubmissionRequest):
    """Submit a new instance for execution."""
    try:
        instance_id = await controller.submit_instance(
            command=request.command,
            resource_requirements=request.resource_requirements,
            name=request.name,
        )
        logger.info(
            f"Client submitted instance {instance_id} ('{request.name}') "
            f"with requirements: {request.resource_requirements}"
        )
        return {"instance_id": instance_id}
    except ValueError as e:
        logger.error(f"Error submitting instance: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error submitting instance: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/instances/{instance_id}")
async def get_instance_details(instance_id: str):
    """Get instance details by ID."""
    instance = await controller.get_instance(instance_id)
    if not instance:
        logger.warning(f"Client requested non-existent instance {instance_id}.")
        raise HTTPException(status_code=404, detail="Instance not found")

    # Derive display status (shows CANCELLING when cancel requested but not terminal)
    display_status = get_display_status(
        InstanceStatus(instance["status"]),
        instance.get("cancel_requested_at")
    )

    return {
        "instance_id": instance["id"],
        "name": instance["name"],
        "command": instance["command"],
        "status": instance["status"],
        "display_status": display_status,
        "attempt": instance["attempt"],
        "assigned_to": instance["assigned_worker"],
        "endpoint": instance["endpoint"],
        "port": instance["port"],
        "exit_code": instance["exit_code"],
        "failure_reason": instance["failure_reason"],
        "created_at": instance["created_at"],
        "assigned_at": instance["assigned_at"],
        "started_at": instance["started_at"],
        "ended_at": instance["ended_at"],
        "cancellation_requested_at": instance.get("cancel_requested_at"),
    }


@app.get("/instances/by-name/{instance_name}")
async def get_instance_by_name(instance_name: str):
    """Get instance details by name."""
    instance = await controller.get_instance_by_name(instance_name)
    if not instance:
        logger.warning(
            f"Client requested non-existent instance with name '{instance_name}'."
        )
        raise HTTPException(status_code=404, detail="Instance not found")

    # Derive display status
    display_status = get_display_status(
        InstanceStatus(instance["status"]),
        instance.get("cancel_requested_at")
    )

    return {
        "instance_id": instance["id"],
        "name": instance["name"],
        "command": instance["command"],
        "status": instance["status"],
        "display_status": display_status,
        "attempt": instance["attempt"],
        "assigned_to": instance["assigned_worker"],
        "endpoint": instance["endpoint"],
        "port": instance["port"],
        "exit_code": instance["exit_code"],
        "failure_reason": instance["failure_reason"],
        "cancellation_requested_at": instance.get("cancel_requested_at"),
    }


@app.get("/instances/by-name/{instance_name}/endpoint")
async def get_instance_endpoint_by_name(instance_name: str):
    """Get the endpoint (host:port) of an instance by name."""
    instance = await controller.get_instance_by_name(instance_name)
    if not instance:
        raise HTTPException(status_code=404, detail="Instance not found")
    if not instance["endpoint"]:
        raise HTTPException(status_code=404, detail="Instance endpoint not available yet")
    return {"endpoint": instance["endpoint"]}


@app.get("/instances/{instance_id}/endpoint")
async def get_instance_endpoint(instance_id: str):
    """Get the endpoint (host:port) of an instance."""
    instance = await controller.get_instance(instance_id)
    if not instance:
        raise HTTPException(status_code=404, detail="Instance not found")
    if not instance["endpoint"]:
        raise HTTPException(status_code=404, detail="Instance endpoint not available yet")
    return {"endpoint": instance["endpoint"]}


@app.get("/instances/{instance_id}/result")
async def get_instance_result(instance_id: str):
    """Get the result of an instance."""
    instance = await controller.get_instance(instance_id)
    if not instance:
        logger.warning(f"Client requested non-existent instance {instance_id}.")
        raise HTTPException(status_code=404, detail="Instance not found")

    if instance["status"] == "COMPLETED":
        logger.info(f"Client retrieved result for instance {instance_id}.")
        return {"result": {"exit_code": instance["exit_code"]}}
    elif instance["status"] == "FAILED":
        logger.info(f"Client retrieved failure for instance {instance_id}.")
        return {
            "error": {
                "exit_code": instance["exit_code"],
                "failure_reason": instance["failure_reason"],
            }
        }
    elif instance["status"] == "CANCELLED":
        return {"cancelled": True}
    else:
        logger.debug(f"Client requested incomplete instance {instance_id}.")
        raise HTTPException(status_code=202, detail="Instance not yet completed")


@app.post("/instances/{instance_id}/cancel")
async def cancel_instance(instance_id: str):
    """
    Request cancellation of an instance.

    Idempotent - multiple requests return success without error.
    Sets cancellation_requested_at timestamp if not already set.
    """
    instance = await controller.get_instance(instance_id)
    if not instance:
        raise HTTPException(status_code=404, detail="Instance not found")

    if instance["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
        raise HTTPException(
            status_code=400,
            detail=f"Instance already in terminal state: {instance['status']}",
        )

    # Check if already requested (idempotent)
    if instance.get("cancel_requested_at") is not None:
        return {"status": "already_cancelling", "instance_id": instance_id}

    success = await controller.request_cancellation(instance_id)
    if success:
        return {"status": "cancelling", "instance_id": instance_id}
    else:
        raise HTTPException(status_code=400, detail="Failed to cancel instance")


@app.get("/instances/{instance_id}/logs")
async def get_instance_logs(
    instance_id: str,
    offset: int = 0,
    limit: int = 1048576,  # 1MB default
):
    """
    Get instance logs via head proxy.

    Proxies the request to the worker's HTTP server.
    Use this when direct worker access is not available.

    Query params:
    - offset: Global byte offset to start reading from
    - limit: Maximum bytes to return
    """
    instance = await controller.get_instance(instance_id)
    if not instance:
        raise HTTPException(status_code=404, detail="Instance not found")

    # Get worker info
    worker_id = instance.get("assigned_worker")
    if not worker_id:
        raise HTTPException(
            status_code=404,
            detail="Instance not assigned to any worker"
        )

    worker = await controller.get_worker(worker_id)
    if not worker:
        raise HTTPException(status_code=503, detail="Worker not found")

    if worker["status"] == "OFFLINE":
        raise HTTPException(status_code=503, detail="Worker is offline")

    # Proxy to worker HTTP server
    worker_host = worker["ip"]
    worker_port = config.WORKER_HTTP_PORT

    worker_url = (
        f"http://{worker_host}:{worker_port}"
        f"/logs/{instance_id}?offset={offset}&limit={limit}"
    )

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(worker_url)
            response.raise_for_status()
            return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Cannot connect to worker")
    except httpx.TimeoutException:
        raise HTTPException(status_code=503, detail="Worker request timeout")
    except Exception as e:
        logger.error(f"Error proxying log request: {e}")
        raise HTTPException(status_code=503, detail="Worker request failed")


# ========== Worker Endpoints ==========


@app.post("/workers")
async def register_worker(request: WorkerRegistrationRequest):
    """Register a worker node."""
    try:
        token = await controller.register_worker(
            worker_id=request.worker_id,
            host=request.host,
            resources=request.resources,
            boot_id=request.boot_id,
        )
        logger.info(
            f"Worker {request.worker_id} ({request.host}) registered via API."
        )
        return WorkerRegistrationResponse(worker_token=token)
    except ValueError as e:
        logger.warning(f"Worker registration failed for {request.worker_id}: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/workers")
async def get_workers():
    """List all registered workers."""
    workers = await controller.get_all_workers()
    return [
        {
            "worker_id": w["id"],
            "host": w["ip"],
            "status": w["status"],
            "total_resources": {
                "cpu_cores": w["cpu_cores"],
                "gpu_units": w["gpu_units"],
                "memory_mb": w["memory_mb"],
            },
            "available_resources": {
                "cpu_cores": w["available_cpu"],
                "gpu_units": w["available_gpu"],
                "memory_mb": w["available_memory"],
            },
            "last_seen": w["last_heartbeat_at"],
        }
        for w in workers
    ]


@app.get("/workers/{worker_id}")
async def get_worker(worker_id: str):
    """Get worker details."""
    worker = await controller.get_worker(worker_id)
    if not worker:
        logger.warning(f"Requested non-existent worker {worker_id}.")
        raise HTTPException(status_code=404, detail="Worker not found")
    return {
        "worker_id": worker["id"],
        "host": worker["ip"],
        "status": worker["status"],
        "total_resources": {
            "cpu_cores": worker["cpu_cores"],
            "gpu_units": worker["gpu_units"],
            "memory_mb": worker["memory_mb"],
        },
        "available_resources": {
            "cpu_cores": worker["available_cpu"],
            "gpu_units": worker["available_gpu"],
            "memory_mb": worker["available_memory"],
        },
        "last_seen": worker["last_heartbeat_at"],
    }


@app.post("/workers/{worker_id}/heartbeat")
async def worker_heartbeat(worker_id: str, request: Optional[HeartbeatRequest] = None):
    """
    Worker heartbeat endpoint.

    Accepts HeartbeatRequest with token, boot_id, instance reports.
    Returns HeartbeatResponse with generation and desired state.
    """
    try:
        if request and request.worker_token:
            response = await controller.process_heartbeat(worker_id, request)
            return response
        else:
            raise HTTPException(
                status_code=400, detail="HeartbeatRequest with worker_token is required"
            )
    except ValueError as e:
        logger.warning(f"Heartbeat error for worker {worker_id}: {e}")
        raise HTTPException(
            status_code=401 if "token" in str(e).lower() else 404, detail=str(e)
        )
