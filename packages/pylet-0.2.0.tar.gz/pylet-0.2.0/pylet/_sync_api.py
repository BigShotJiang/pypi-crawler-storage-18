"""
PyLet Sync API - Synchronous API functions.

These are the main entry points for the sync-first PyLet API.
"""

import shlex
from typing import List, Optional, Union

import httpx

from pylet._instance import Instance
from pylet._state import (
    _get_client,
    _get_head_address,
    _init_state,
    _is_initialized,
    _shutdown_state,
)
from pylet._worker_info import WorkerInfo
from pylet.errors import NotFoundError, NotInitializedError


def init(address: str = "http://localhost:8000") -> None:
    """
    Initialize connection to PyLet head node.

    Must be called before any other client API.

    Args:
        address: Head node URL. Default "http://localhost:8000"

    Raises:
        ConnectionError: Cannot reach head node

    Example:
        pylet.init()
        pylet.init("http://192.168.1.10:8000")
    """
    _init_state(address)

    # Verify connection by hitting a simple endpoint
    try:
        client = _get_client()
        response = client.get(f"{address}/workers")
        response.raise_for_status()
    except httpx.ConnectError as e:
        _shutdown_state()
        raise ConnectionError(f"Cannot reach head node at {address}") from e
    except Exception as e:
        _shutdown_state()
        raise ConnectionError(f"Failed to connect to head node: {e}") from e


def shutdown() -> None:
    """
    Close connection to head node.

    Optional - called automatically via atexit.
    """
    _shutdown_state()


def is_initialized() -> bool:
    """
    Check if init() has been called.

    Returns:
        True if pylet is initialized, False otherwise.
    """
    return _is_initialized()


def submit(
    command: Union[str, List[str]],
    *,
    name: Optional[str] = None,
    gpu: int = 0,
    cpu: int = 1,
    memory: int = 512,
) -> Instance:
    """
    Submit a new instance.

    Args:
        command: Shell command string, or list of args (auto shell-escaped)
        name: Optional instance name for service discovery
        gpu: GPU units required (default 0)
        cpu: CPU cores required (default 1)
        memory: Memory in MB required (default 512)

    Returns:
        Instance handle

    Raises:
        NotInitializedError: init() not called
        ValueError: Invalid command or resources

    Example:
        instance = pylet.submit("echo hello", cpu=1)
        instance = pylet.submit("vllm serve model --port $PORT", name="vllm", gpu=1, memory=4096)
        instance = pylet.submit(["python", "-c", "print('hello')"], cpu=1)
    """
    client = _get_client()
    address = _get_head_address()

    # Normalize command
    if isinstance(command, list):
        command = shlex.join(command)

    # Submit instance
    response = client.post(
        f"{address}/instances",
        json={
            "command": command,
            "resource_requirements": {
                "cpu_cores": cpu,
                "gpu_units": gpu,
                "memory_mb": memory,
            },
            "name": name,
        },
    )
    response.raise_for_status()

    instance_id = response.json()["instance_id"]

    # Fetch full instance data
    response = client.get(f"{address}/instances/{instance_id}")
    response.raise_for_status()

    return Instance(response.json())


def get(
    name: Optional[str] = None,
    *,
    id: Optional[str] = None,
) -> Instance:
    """
    Get an existing instance by name or ID.

    Args:
        name: Instance name (positional or keyword)
        id: Instance ID (keyword only)

    Returns:
        Instance handle

    Raises:
        NotInitializedError: init() not called
        NotFoundError: Instance not found
        ValueError: Neither name nor id provided

    Example:
        instance = pylet.get("my-vllm")
        instance = pylet.get(id="abc-123-def")
    """
    if name is None and id is None:
        raise ValueError("Either 'name' or 'id' must be provided")

    client = _get_client()
    address = _get_head_address()

    try:
        if id is not None:
            response = client.get(f"{address}/instances/{id}")
        else:
            response = client.get(f"{address}/instances/by-name/{name}")

        response.raise_for_status()
        return Instance(response.json())
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            identifier = id if id else f"name='{name}'"
            raise NotFoundError(f"Instance not found: {identifier}") from e
        raise


def instances(
    *,
    status: Optional[str] = None,
) -> List[Instance]:
    """
    List all instances.

    Args:
        status: Filter by status (e.g., "RUNNING", "PENDING")

    Returns:
        List of Instance handles

    Raises:
        NotInitializedError: init() not called

    Example:
        all_instances = pylet.instances()
        running = pylet.instances(status="RUNNING")
    """
    client = _get_client()
    address = _get_head_address()

    params = {}
    if status:
        params["status"] = status

    response = client.get(f"{address}/instances", params=params)
    response.raise_for_status()

    return [Instance(data) for data in response.json()]


def workers() -> List[WorkerInfo]:
    """
    List all registered workers.

    Returns:
        List of WorkerInfo objects

    Raises:
        NotInitializedError: init() not called
    """
    client = _get_client()
    address = _get_head_address()

    response = client.get(f"{address}/workers")
    response.raise_for_status()

    return [WorkerInfo(data) for data in response.json()]
