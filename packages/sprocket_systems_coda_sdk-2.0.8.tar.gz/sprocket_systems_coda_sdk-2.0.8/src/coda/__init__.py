# The versions below will be replaced automatically in CI.
# You do not need to modify any of the versions below.
__version__ = "2.0.8"
CODA_APP_SUITE_VERSION = "+coda-2.0.13"
FINAL_VERSION = __version__ + CODA_APP_SUITE_VERSION
