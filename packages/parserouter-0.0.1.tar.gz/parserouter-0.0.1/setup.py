from setuptools import setup, find_packages

setup(
    name="parserouter",  # <--- THIS IS THE NAME YOU ARE CLAIMING
    version="0.0.1",
    description="ParseRouter",
    long_description="# ParseRouter\n\nComing soon.",
    long_description_content_type="text/markdown",
    author="ParseRouter Admin",
    author_email="admin@parserouter.com",  # Generic email
    url="https://github.com/ParseRouter", # Okay if this doesn't exist yet
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
