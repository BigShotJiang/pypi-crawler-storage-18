#!/usr/bin/env python3
"""
Context manager example for PNEX Publisher.

This example shows how to use PNEXPublisher as an async context manager
for automatic connection management.
"""

import asyncio
import os
from pnex_publisher import PNEXPublisher


async def publish_sensor_data():
    """
    Example using PNEXPublisher as an async context manager.

    The context manager automatically connects on entry and
    disconnects on exit, even if an error occurs.
    """
    # Configuration - update these with your actual credentials
    config = {
        "device_token": os.getenv("PNEX_DEVICE_TOKEN", "your-device-token-here"),
        "device_id": os.getenv("PNEX_DEVICE_ID", "my_custom_sensor_002"),
        "encryption_key": os.getenv("PNEX_ENCRYPTION_KEY", "your-base64-32-byte-key-here"),
        "host": os.getenv("PNEX_HOST", "localhost:8000"),
    }

    print("PNEX Publisher Context Manager Example")
    print("=" * 50)

    # Use as async context manager
    async with PNEXPublisher(**config) as publisher:
        print(f"✓ Connected as device {publisher.config.device_id}")
        print()

        # Publish some measurements
        measurements = [
            ("temperature", 22.8),
            ("humidity", 68.5),
            ("battery_level", 87),
            ("signal_strength", -45),
        ]

        print("Publishing measurements...")
        for name, value in measurements:
            success = await publisher.publish(name, value)
            status = "✓" if success else "✗"
            print(f"  {status} {name}={value}")

        print("\n✓ All measurements published")

        # Simulate some work
        print("\nSimulating sensor reading for 10 seconds...")
        await asyncio.sleep(10)

    # Publisher automatically disconnects here
    print("\n✓ Disconnected (automatic from context manager)")


async def main():
    """Run the context manager example."""
    try:
        await publish_sensor_data()
    except Exception as e:
        print(f"\n✗ Error: {e}")
        return 1

    print("\nExample completed successfully!")
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)
