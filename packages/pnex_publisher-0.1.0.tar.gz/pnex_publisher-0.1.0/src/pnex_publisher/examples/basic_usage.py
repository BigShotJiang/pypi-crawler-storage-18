#!/usr/bin/env python3
"""
Basic usage example for PNEX Publisher.

This example shows how to use the PNEXPublisher class to publish
sensor data to PNEX Server with ChaCha20 encryption.
"""

import asyncio
import os
from pnex_publisher import PNEXPublisher


async def main():
    """
    Example of publishing sensor data to PNEX Server.

    Before running:
    1. Register your device in the PNEX web interface
    2. Get device token, device ID, and encryption key
    3. Update the configuration below with your credentials
    """

    # Configuration - update these with your actual credentials
    config = {
        "device_token": os.getenv("PNEX_DEVICE_TOKEN", "your-device-token-here"),
        "device_id": os.getenv("PNEX_DEVICE_ID", "my_custom_sensor_001"),
        "encryption_key": os.getenv("PNEX_ENCRYPTION_KEY", "your-base64-32-byte-key-here"),
        "host": os.getenv("PNEX_HOST", "localhost:8000"),
        "use_tls": os.getenv("PNEX_USE_TLS", "false").lower() == "true",
    }

    print("PNEX Publisher Basic Example")
    print("=" * 50)
    print(f"Device ID: {config['device_id']}")
    print(f"Host: {config['host']}")
    print(f"Use TLS: {config['use_tls']}")
    print()

    # Create publisher instance
    publisher = PNEXPublisher(**config)

    try:
        # Connect to server
        print("Connecting to PNEX Server...")
        await publisher.connect()
        print("✓ Connected successfully")
        print()

        # Publish some sensor data
        print("Publishing sensor data...")

        # Single measurement
        success = await publisher.publish("temperature", 23.5)
        print(f"  temperature=23.5: {'✓' if success else '✗'}")

        # Another measurement
        success = await publisher.publish("humidity", 65.2)
        print(f"  humidity=65.2: {'✓' if success else '✗'}")

        # Batch publishing
        measurements = {
            "pressure": 1013.2,
            "light_intensity": 850,
            "soil_moisture": 45.7,
        }

        print("\nBatch publishing...")
        results = await publisher.publish_batch(measurements)
        for name, success in results.items():
            print(f"  {name}={measurements[name]}: {'✓' if success else '✗'}")

        print("\n✓ All measurements published")

        # Keep connection alive for a bit to show heartbeat
        print("\nKeeping connection alive for 15 seconds (showing heartbeat)...")
        print("Press Ctrl+C to exit early")

        try:
            await asyncio.sleep(15)
        except KeyboardInterrupt:
            print("\nInterrupted by user")

    except Exception as e:
        print(f"\n✗ Error: {e}")
    finally:
        # Disconnect from server
        print("\nDisconnecting from server...")
        await publisher.disconnect()
        print("✓ Disconnected")

    print("\nExample completed!")


if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main())
