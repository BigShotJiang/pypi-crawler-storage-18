#!/usr/bin/env python3
"""
Environment configuration example for PNEX Publisher.

This example shows how to configure PNEXPublisher using environment variables
and a .env file, which is recommended for production deployments.
"""

import asyncio
import os
from pnex_publisher import PNEXConfig, PNEXPublisher


async def main():
    """
    Example using environment variables for configuration.

    Set these environment variables before running:
        export PNEX_DEVICE_TOKEN="your-device-token"
        export PNEX_DEVICE_ID="sensor-001"
        export PNEX_ENCRYPTION_KEY="base64-32-byte-key"
        export PNEX_HOST="localhost:8000"
        export PNEX_USE_TLS="false"
        export PNEX_PING_INTERVAL="5"

    Or create a .env file in the same directory:
        PNEX_DEVICE_TOKEN=your-device-token
        PNEX_DEVICE_ID=sensor-001
        PNEX_ENCRYPTION_KEY=base64-32-byte-key
        PNEX_HOST=localhost:8000
        PNEX_USE_TLS=false
        PNEX_PING_INTERVAL=5
    """

    print("PNEX Publisher Environment Configuration Example")
    print("=" * 50)

    # Method 1: Create config from environment variables
    print("\nMethod 1: Using PNEXConfig.from_env()")
    print("-" * 30)

    try:
        config = PNEXConfig.from_env()
        print(f"✓ Loaded configuration from environment:")
        print(f"  Device ID: {config.device_id}")
        print(f"  Host: {config.host}")
        print(f"  Use TLS: {config.use_tls}")
        print(f"  Ping interval: {config.ping_interval}s")
    except Exception as e:
        print(f"✗ Failed to load from environment: {e}")
        print("  Make sure environment variables are set (PNEX_ prefix)")
        config = None

    # Method 2: Create publisher directly (reads env automatically)
    print("\nMethod 2: Creating publisher directly")
    print("-" * 30)

    try:
        # PNEXPublisher will read environment variables automatically
        # when using pydantic-settings BaseSettings
        publisher = PNEXPublisher(
            device_token=os.getenv("PNEX_DEVICE_TOKEN", "dummy"),
            device_id=os.getenv("PNEX_DEVICE_ID", "dummy"),
            encryption_key=os.getenv("PNEX_ENCRYPTION_KEY", "dummy"),
        )

        print(f"✓ Created publisher:")
        print(f"  Device ID: {publisher.config.device_id}")
        print(f"  WebSocket URL: {publisher.config.ws_url}")
        print(f"  Full URL: {publisher.config.full_websocket_url[:80]}...")

        # Show how to access configuration
        print("\nConfiguration details:")
        for key, value in publisher.config.to_dict().items():
            if "key" in key.lower() or "token" in key.lower():
                # Mask sensitive values
                masked = f"{str(value)[:10]}..." if value else "None"
                print(f"  {key}: {masked}")
            else:
                print(f"  {key}: {value}")

    except Exception as e:
        print(f"✗ Failed to create publisher: {e}")

    # Method 3: Manual configuration with overrides
    print("\nMethod 3: Manual configuration with environment fallback")
    print("-" * 30)

    try:
        config_dict = {
            "device_token": os.getenv("PNEX_DEVICE_TOKEN", "manual-token"),
            "device_id": os.getenv("PNEX_DEVICE_ID", "manual-sensor"),
            "encryption_key": os.getenv("PNEX_ENCRYPTION_KEY", "manual-key"),
            "host": os.getenv("PNEX_HOST", "manual-host:8000"),
            "use_tls": os.getenv("PNEX_USE_TLS", "false").lower() == "true",
        }

        config = PNEXConfig.from_dict(config_dict)
        print(f"✓ Created manual configuration:")
        print(f"  Source: Environment variables with manual fallback")
        print(f"  Device ID: {config.device_id}")
        print(f"  Host: {config.host}")

    except Exception as e:
        print(f"✗ Failed to create manual configuration: {e}")

    print("\n" + "=" * 50)
    print("Environment Configuration Tips:")
    print("1. Use .env files for development (python-dotenv)")
    print("2. Use environment variables in production")
    print("3. Never commit .env files to version control")
    print("4. Use different .env files for different environments")
    print("5. Consider using a secrets manager for production")


if __name__ == "__main__":
    asyncio.run(main())
