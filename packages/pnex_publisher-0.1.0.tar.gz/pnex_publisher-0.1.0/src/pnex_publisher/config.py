"""
Configuration management for PNEX Publisher.
"""

import os
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings

from .exceptions import ConfigurationError


class PNEXConfig(BaseSettings):
    """
    Configuration for PNEX Publisher.

    Can be configured via:
    1. Constructor arguments
    2. Environment variables (PNEX_ prefix)
    3. .env file
    """

    # Required credentials
    device_token: str = Field(..., description="Device authentication token")
    device_id: str = Field(..., description="Device identifier")
    encryption_key: str = Field(..., description="Base64-encoded 32-byte encryption key")

    # Optional configuration with defaults
    host: str = Field(
        default="localhost:8000",
        description="PNEX server host and port (format: host:port)"
    )
    use_tls: bool = Field(
        default=False,
        description="Use TLS (wss://) for WebSocket connection"
    )
    predefined_device_type: str = Field(
        default="custom_sensor",
        description="Predefined device type (custom_sensor or custom_device)"
    )

    # Timing configuration
    ping_interval: int = Field(
        default=5,
        ge=1,
        description="Seconds between heartbeat PING messages"
    )
    publish_timeout: float = Field(
        default=5.0,
        gt=0,
        description="Timeout in seconds for publish operations"
    )
    reconnect_delay: int = Field(
        default=5,
        ge=1,
        description="Seconds to wait before reconnecting on failure"
    )
    max_reconnect_attempts: int = Field(
        default=10,
        ge=0,
        description="Maximum reconnection attempts before giving up"
    )

    # Advanced settings
    auto_reconnect: bool = Field(
        default=True,
        description="Automatically reconnect on connection loss"
    )
    enable_heartbeat: bool = Field(
        default=True,
        description="Enable PING/PONG heartbeat for device status tracking"
    )
    validate_key_on_start: bool = Field(
        default=True,
        description="Validate encryption key on initialization"
    )

    class Config:
        env_prefix = "PNEX_"
        case_sensitive = False
        extra = "ignore"

    @field_validator("encryption_key")
    @classmethod
    def validate_encryption_key(cls, v: str) -> str:
        """Validate that encryption key is properly formatted."""
        if not v:
            raise ValueError("Encryption key cannot be empty")

        # Check if it looks like base64 (optional length check)
        # Actual validation happens in crypto module
        return v

    @field_validator("host")
    @classmethod
    def validate_host(cls, v: str) -> str:
        """Validate host format."""
        if "://" in v:
            raise ValueError("Host should not include protocol (e.g., ws://)")

        # Remove trailing slash if present
        v = v.rstrip("/")

        # Ensure port is included
        if ":" not in v:
            v = f"{v}:8000"

        return v

    @property
    def ws_url(self) -> str:
        """Get WebSocket URL based on configuration."""
        protocol = "wss" if self.use_tls else "ws"
        return f"{protocol}://{self.host}/ws/sensor/ingest"

    @property
    def websocket_params(self) -> Dict[str, str]:
        """Get WebSocket connection parameters."""
        import base64

        return {
            "token": base64.b64encode(self.device_token.encode()).decode(),
            "device_id": base64.b64encode(self.device_id.encode()).decode(),
            "pred_dev": base64.b64encode(self.predefined_device_type.encode()).decode(),
        }

    @property
    def full_websocket_url(self) -> str:
        """Get complete WebSocket URL with query parameters."""
        import urllib.parse

        base_url = self.ws_url
        params = urllib.parse.urlencode(self.websocket_params)
        return f"{base_url}?{params}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return self.model_dump()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PNEXConfig":
        """Create configuration from dictionary."""
        return cls(**data)

    @classmethod
    def from_env(cls) -> "PNEXConfig":
        """Create configuration from environment variables."""
        return cls()

    def validate(self) -> None:
        """
        Validate all configuration parameters.

        Raises:
            ConfigurationError: If configuration is invalid
        """
        errors = []

        # Check required fields
        if not self.device_token:
            errors.append("Device token is required")
        if not self.device_id:
            errors.append("Device ID is required")
        if not self.encryption_key:
            errors.append("Encryption key is required")

        # Validate predefined device type
        valid_types = ["custom_sensor", "custom_device"]
        if self.predefined_device_type not in valid_types:
            errors.append(
                f"Predefined device type must be one of: {', '.join(valid_types)}"
            )

        if errors:
            raise ConfigurationError("\n".join(errors))
