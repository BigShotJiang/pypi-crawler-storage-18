#!/usr/bin/env python3
"""
Command-line interface for PNEX Publisher.

Provides a simple CLI for publishing sensor data to PNEX Server.
"""

import asyncio
import argparse
import sys
import json
from typing import Dict, Any

from . import PNEXPublisher
from .config import PNEXConfig


async def publish_single(
    config: PNEXConfig, measurement: str, value: float, timeout: float = 5.0
) -> bool:
    """Publish a single measurement."""
    async with PNEXPublisher(config=config) as publisher:
        print(f"Connected as device {publisher.config.device_id}")
        print(f"Publishing: {measurement}={value}")

        success = await publisher.publish(measurement, value, timeout=timeout)

        if success:
            print(f"✓ Successfully published {measurement}={value}")
        else:
            print(f"✗ Failed to publish {measurement}={value}")

        return success


async def publish_batch(
    config: PNEXConfig, measurements: Dict[str, float], timeout: float = 5.0
) -> Dict[str, bool]:
    """Publish multiple measurements."""
    async with PNEXPublisher(config=config) as publisher:
        print(f"Connected as device {publisher.config.device_id}")
        print(f"Publishing {len(measurements)} measurements...")

        results = await publisher.publish_batch(measurements, timeout=timeout)

        success_count = sum(1 for success in results.values() if success)
        print(f"\nResults: {success_count}/{len(measurements)} successful")

        for measurement, success in results.items():
            status = "✓" if success else "✗"
            print(f"  {status} {measurement}={measurements[measurement]}")

        return results


async def test_connection(config: PNEXConfig) -> bool:
    """Test connection to PNEX Server."""
    try:
        async with PNEXPublisher(config=config) as publisher:
            print(f"✓ Connected to PNEX Server as device {publisher.config.device_id}")
            print(f"  WebSocket URL: {publisher.config.ws_url}")
            print(f"  Using TLS: {publisher.config.use_tls}")
            print(f"  Ping interval: {publisher.config.ping_interval}s")

            # Test with a simple publish
            print("\nTesting publish...")
            success = await publisher.publish("test", 1.0, timeout=2.0)

            if success:
                print("✓ Publish test successful")
            else:
                print("✗ Publish test failed")

            return success
    except Exception as e:
        print(f"✗ Connection test failed: {e}")
        return False


def create_config_from_args(args: argparse.Namespace) -> PNEXConfig:
    """Create PNEXConfig from command-line arguments."""
    config_dict = {
        "device_token": args.device_token,
        "device_id": args.device_id,
        "encryption_key": args.encryption_key,
        "host": args.host,
        "use_tls": args.use_tls,
        "predefined_device_type": args.device_type,
        "ping_interval": args.ping_interval,
        "publish_timeout": args.timeout,
    }

    # Remove None values (use defaults)
    config_dict = {k: v for k, v in config_dict.items() if v is not None}

    return PNEXConfig.from_dict(config_dict)


def parse_measurements(measurements_str: str) -> Dict[str, float]:
    """Parse measurements from string format."""
    measurements = {}

    if measurements_str.startswith("{"):
        # JSON format
        try:
            data = json.loads(measurements_str)
            for key, value in data.items():
                measurements[key] = float(value)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}")
    else:
        # Key=value pairs separated by commas
        pairs = measurements_str.split(",")
        for pair in pairs:
            if "=" not in pair:
                raise ValueError(f"Invalid measurement format: {pair}")

            key, value = pair.split("=", 1)
            measurements[key.strip()] = float(value.strip())

    return measurements


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="PNEX Publisher CLI - Publish sensor data to PNEX Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Publish single measurement
  pnex-publish --token TOKEN --id SENSOR-001 --key KEY temperature 23.5

  # Publish multiple measurements
  pnex-publish --token TOKEN --id SENSOR-001 --key KEY --batch "temperature=23.5,humidity=65.0"

  # Test connection
  pnex-publish --token TOKEN --id SENSOR-001 --key KEY --test

  # Use environment variables (PNEX_ prefix)
  export PNEX_DEVICE_TOKEN=TOKEN
  export PNEX_DEVICE_ID=SENSOR-001
  export PNEX_ENCRYPTION_KEY=KEY
  pnex-publish temperature 23.5

Configuration:
  All parameters can be set via environment variables with PNEX_ prefix.
  For example: PNEX_DEVICE_TOKEN, PNEX_HOST, etc.
        """,
    )

    # Required arguments
    parser.add_argument(
        "measurement",
        nargs="?",
        help="Measurement name (for single publish)",
    )
    parser.add_argument(
        "value",
        nargs="?",
        type=float,
        help="Measurement value (for single publish)",
    )

    # Credentials (can also come from env)
    parser.add_argument(
        "--token", "--device-token",
        dest="device_token",
        help="Device authentication token",
    )
    parser.add_argument(
        "--id", "--device-id",
        dest="device_id",
        help="Device identifier",
    )
    parser.add_argument(
        "--key", "--encryption-key",
        dest="encryption_key",
        help="Base64-encoded 32-byte encryption key",
    )

    # Connection settings
    parser.add_argument(
        "--host",
        default="localhost:8000",
        help="PNEX server host:port (default: localhost:8000)",
    )
    parser.add_argument(
        "--tls", "--use-tls",
        dest="use_tls",
        action="store_true",
        help="Use TLS (wss://) for WebSocket connection",
    )
    parser.add_argument(
        "--device-type",
        dest="device_type",
        default="custom_sensor",
        choices=["custom_sensor", "custom_device"],
        help="Predefined device type (default: custom_sensor)",
    )

    # Timing settings
    parser.add_argument(
        "--ping-interval",
        type=int,
        default=5,
        help="Seconds between heartbeat PING messages (default: 5)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="Timeout in seconds for publish operations (default: 5.0)",
    )

    # Operation modes
    parser.add_argument(
        "--batch",
        help="Publish multiple measurements as JSON or key=value pairs",
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Test connection to PNEX Server",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )

    args = parser.parse_args()

    # Validate arguments
    if args.test:
        # Test mode - just need credentials
        pass
    elif args.batch:
        # Batch mode - need batch string
        if not args.batch:
            parser.error("--batch requires measurement data")
    elif args.measurement and args.value is not None:
        # Single publish mode - have both measurement and value
        pass
    else:
        parser.error("Either specify measurement and value, use --batch, or use --test")

    try:
        # Create configuration
        config = create_config_from_args(args)

        # Run the appropriate command
        if args.test:
            success = asyncio.run(test_connection(config))
            exit_code = 0 if success else 1

        elif args.batch:
            measurements = parse_measurements(args.batch)
            results = asyncio.run(publish_batch(config, measurements, args.timeout))

            if args.json:
                print(json.dumps({
                    "success": all(results.values()),
                    "results": results,
                    "measurements": measurements,
                }))

            exit_code = 0 if all(results.values()) else 1

        else:
            # Single publish
            success = asyncio.run(
                publish_single(config, args.measurement, args.value, args.timeout)
            )
            exit_code = 0 if success else 1

        sys.exit(exit_code)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
