"""
Main publisher class for PNEX Publisher.
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, Union
import websockets
from websockets.exceptions import ConnectionClosed

from .config import PNEXConfig
from .crypto import ChaChaEncryptor
from .exceptions import (
    ConfigurationError,
    EncryptionError,
    ConnectionError,
    PublishError,
)

logger = logging.getLogger(__name__)


class PNEXPublisher:
    """
    Main publisher class for sending sensor data to PNEX Server.

    This class handles:
    - WebSocket connection management
    - ChaCha20 encryption/decryption
    - Heartbeat (PING/PONG) for device status
    - Automatic reconnection
    - Error handling and logging

    Example:
        >>> publisher = PNEXPublisher(
        ...     device_token="your-token",
        ...     device_id="sensor-001",
        ...     encryption_key="base64-key"
        ... )
        >>> await publisher.connect()
        >>> await publisher.publish("temperature", 23.5)
        >>> await publisher.disconnect()
    """

    def __init__(
        self,
        device_token: str,
        device_id: str,
        encryption_key: str,
        host: str = "localhost:8000",
        use_tls: bool = False,
        predefined_device_type: str = "custom_sensor",
        ping_interval: int = 5,
        publish_timeout: float = 5.0,
        reconnect_delay: int = 5,
        max_reconnect_attempts: int = 10,
        auto_reconnect: bool = True,
        enable_heartbeat: bool = True,
        validate_key_on_start: bool = True,
        config: Optional[PNEXConfig] = None,
    ):
        """
        Initialize the publisher.

        Args:
            device_token: Device authentication token
            device_id: Device identifier
            encryption_key: Base64-encoded 32-byte encryption key
            host: PNEX server host and port (format: host:port)
            use_tls: Use TLS (wss://) for WebSocket connection
            predefined_device_type: Predefined device type
            ping_interval: Seconds between heartbeat PING messages
            publish_timeout: Timeout in seconds for publish operations
            reconnect_delay: Seconds to wait before reconnecting on failure
            max_reconnect_attempts: Maximum reconnection attempts
            auto_reconnect: Automatically reconnect on connection loss
            enable_heartbeat: Enable PING/PONG heartbeat
            validate_key_on_start: Validate encryption key on initialization
            config: Optional PNEXConfig instance (overrides other parameters)

        Raises:
            ConfigurationError: If configuration is invalid
        """
        if config:
            self.config = config
        else:
            self.config = PNEXConfig(
                device_token=device_token,
                device_id=device_id,
                encryption_key=encryption_key,
                host=host,
                use_tls=use_tls,
                predefined_device_type=predefined_device_type,
                ping_interval=ping_interval,
                publish_timeout=publish_timeout,
                reconnect_delay=reconnect_delay,
                max_reconnect_attempts=max_reconnect_attempts,
                auto_reconnect=auto_reconnect,
                enable_heartbeat=enable_heartbeat,
                validate_key_on_start=validate_key_on_start,
            )

        # Validate configuration
        self.config.validate()

        # Validate encryption key if requested
        if self.config.validate_key_on_start:
            is_valid, error_msg = ChaChaEncryptor.validate_key(
                self.config.encryption_key
            )
            if not is_valid:
                raise ConfigurationError(f"Invalid encryption key: {error_msg}")

        # Internal state
        self._websocket: Optional[websockets.WebSocketClientProtocol] = None
        self._ping_task: Optional[asyncio.Task] = None
        self._reconnect_attempts = 0
        self._connected = False
        self._shutting_down = False

        # Encryption utility
        self.encryptor = ChaChaEncryptor()

        logger.info(
            f"PNEXPublisher initialized for device {self.config.device_id} "
            f"connecting to {self.config.ws_url}"
        )

    @property
    def connected(self) -> bool:
        """Check if publisher is connected to server."""
        return self._connected and self._websocket is not None

    @property
    def connection_info(self) -> Dict[str, Any]:
        """Get connection information."""
        return {
            "device_id": self.config.device_id,
            "host": self.config.host,
            "use_tls": self.config.use_tls,
            "connected": self.connected,
            "reconnect_attempts": self._reconnect_attempts,
            "websocket_url": self.config.ws_url,
        }

    async def connect(self) -> None:
        """
        Connect to PNEX Server.

        Raises:
            ConnectionError: If connection fails
        """
        if self.connected:
            logger.warning("Already connected to server")
            return

        logger.info(f"Connecting to {self.config.full_websocket_url}")

        try:
            self._websocket = await websockets.connect(
                self.config.full_websocket_url,
                ping_interval=None,  # We handle our own pings
                close_timeout=1.0,
            )

            self._connected = True
            self._reconnect_attempts = 0
            self._shutting_down = False

            # Start heartbeat task if enabled
            if self.config.enable_heartbeat:
                self._ping_task = asyncio.create_task(self._send_ping_loop())

            logger.info(f"Connected to PNEX Server as device {self.config.device_id}")

        except Exception as e:
            self._connected = False
            self._websocket = None
            raise ConnectionError(f"Failed to connect to server: {e}")

    async def disconnect(self) -> None:
        """Disconnect from PNEX Server."""
        self._shutting_down = True

        # Cancel ping task
        if self._ping_task:
            self._ping_task.cancel()
            try:
                await self._ping_task
            except asyncio.CancelledError:
                pass
            self._ping_task = None

        # Close WebSocket connection
        if self._websocket:
            try:
                await self._websocket.close()
                logger.info("Disconnected from PNEX Server")
            except Exception as e:
                logger.warning(f"Error while disconnecting: {e}")
            finally:
                self._websocket = None

        self._connected = False

    async def publish(
        self,
        measurement_name: str,
        value: Union[float, int, str],
        timeout: Optional[float] = None,
    ) -> bool:
        """
        Publish a single measurement to PNEX Server.

        Args:
            measurement_name: Name of the measurement (e.g., "temperature")
            value: Measurement value
            timeout: Optional timeout in seconds (defaults to config.publish_timeout)

        Returns:
            True if published successfully, False otherwise

        Raises:
            PublishError: If publishing fails
        """
        if not self.connected:
            if self.config.auto_reconnect:
                await self._reconnect()
            else:
                raise PublishError("Not connected to server")

        # Convert value to string
        value_str = str(value)

        # Format and encrypt message
        plaintext = f"{measurement_name}={value_str}"
        try:
            encrypted = self.encryptor.encrypt(plaintext, self.config.encryption_key)
        except EncryptionError as e:
            raise PublishError(f"Failed to encrypt measurement: {e}")

        # Send encrypted message
        timeout_val = timeout or self.config.publish_timeout
        try:
            await asyncio.wait_for(self._websocket.send(encrypted), timeout=timeout_val)

            # Wait for acknowledgment
            response_encrypted = await asyncio.wait_for(
                self._websocket.recv(), timeout=timeout_val
            )

            # Decrypt response
            response = self.encryptor.decrypt(
                response_encrypted, self.config.encryption_key
            )

            if response == "ok":
                logger.debug(f"Published: {measurement_name}={value_str}")
                return True
            else:
                logger.warning(
                    f"Server response for {measurement_name}={value_str}: {response}"
                )
                return False

        except asyncio.TimeoutError:
            logger.warning(f"Timeout publishing {measurement_name}={value_str}")
            return False
        except ConnectionClosed as e:
            logger.warning(f"Connection closed while publishing: {e}")
            self._handle_connection_loss()
            return False
        except Exception as e:
            raise PublishError(f"Failed to publish measurement: {e}")

    async def publish_batch(
        self,
        measurements: Dict[str, Union[float, int, str]],
        timeout: Optional[float] = None,
    ) -> Dict[str, bool]:
        """
        Publish multiple measurements to PNEX Server.

        Args:
            measurements: Dictionary of {measurement_name: value}
            timeout: Optional timeout per measurement

        Returns:
            Dictionary of {measurement_name: success_status}
        """
        results = {}
        for name, value in measurements.items():
            try:
                success = await self.publish(name, value, timeout)
                results[name] = success
            except Exception as e:
                logger.error(f"Failed to publish {name}: {e}")
                results[name] = False

        return results

    async def _send_ping_loop(self) -> None:
        """Send periodic PING messages for device status tracking."""
        logger.debug("Starting heartbeat ping loop")

        while not self._shutting_down and self.connected:
            try:
                await asyncio.sleep(self.config.ping_interval)

                if not self.connected or self._shutting_down:
                    break

                # Encrypt and send PING
                ping_encrypted = self.encryptor.encrypt(
                    "PING", self.config.encryption_key
                )
                await self._websocket.send(ping_encrypted)

                # Receive and decrypt response
                response_encrypted = await self._websocket.recv()
                response = self.encryptor.decrypt(
                    response_encrypted, self.config.encryption_key
                )

                if response == "PONG":
                    logger.debug(f"Heartbeat acknowledged at {time.strftime('%H:%M:%S')}")
                else:
                    logger.warning(f"Unexpected ping response: {response}")

            except asyncio.CancelledError:
                break
            except ConnectionClosed:
                logger.debug("Connection closed in ping loop")
                self._handle_connection_loss()
                break
            except Exception as e:
                logger.warning(f"Error in ping loop: {e}")
                if self.connected:
                    self._handle_connection_loss()
                break

        logger.debug("Heartbeat ping loop stopped")

    def _handle_connection_loss(self) -> None:
        """Handle connection loss and update internal state."""
        self._connected = False
        self._websocket = None

        if self._ping_task:
            self._ping_task.cancel()
            self._ping_task = None

        logger.warning("Connection to server lost")

    async def _reconnect(self) -> None:
        """Attempt to reconnect to server."""
        if self._shutting_down:
            return

        while (
            self._reconnect_attempts < self.config.max_reconnect_attempts
            and not self._shutting_down
        ):
            self._reconnect_attempts += 1
            logger.info(
                f"Reconnection attempt {self._reconnect_attempts}/"
                f"{self.config.max_reconnect_attempts}"
            )

            try:
                await self.connect()
                logger.info("Reconnected to server")
                return
            except Exception as e:
                logger.warning(f"Reconnection failed: {e}")

                if self._reconnect_attempts < self.config.max_reconnect_attempts:
                    await asyncio.sleep(self.config.reconnect_delay)

        logger.error(
            f"Maximum reconnection attempts ({self.config.max_reconnect_attempts}) reached"
        )

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    def __repr__(self) -> str:
        """String representation of publisher."""
        status = "connected" if self.connected else "disconnected"
        return (
            f"PNEXPublisher(device_id={self.config.device_id}, "
            f"host={self.config.host}, status={status})"
        )
