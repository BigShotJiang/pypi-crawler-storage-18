"""
ChaCha20 encryption utilities for PNEX Publisher.

This module provides encryption/decryption functions that match the
PNEX Server implementation (crypto_utils.py) and firmware implementation.
"""

import base64
import os
from typing import Tuple, Optional
from Crypto.Cipher import ChaCha20

from .exceptions import EncryptionError


class ChaChaEncryptor:
    """
    ChaCha20 encryption/decryption for PNEX Server communication.

    This implementation matches:
    - Server: pnex-server/src/crypto_utils.py
    - Firmware: iot-firmware/common_libs/crypto/CryptoManager.h

    Message format: Base64([12-byte nonce] + [ChaCha20(ciphertext)])
    Key format: Base64-encoded 32-byte key (44 characters)
    """

    @staticmethod
    def encrypt(plaintext: str, key_b64: str) -> str:
        """
        Encrypt plaintext using ChaCha20 (RFC 7539).

        Args:
            plaintext: String data to encrypt
            key_b64: Base64-encoded 32-byte key (44 characters)

        Returns:
            Base64-encoded string: nonce(12 bytes) + ciphertext

        Raises:
            EncryptionError: If encryption fails
        """
        try:
            # Decode and validate key
            key = base64.b64decode(key_b64)
            if len(key) != 32:
                raise ValueError(f"Invalid key length: {len(key)} bytes (expected 32)")

            # Generate random 12-byte nonce (RFC 7539)
            nonce = os.urandom(12)

            # Convert plaintext to bytes (UTF-8)
            plaintext_bytes = plaintext.encode('utf-8')

            # Encrypt using ChaCha20
            cipher = ChaCha20.new(key=key, nonce=nonce)
            ciphertext = cipher.encrypt(plaintext_bytes)

            # Combine nonce + ciphertext and base64 encode
            combined = nonce + ciphertext
            return base64.b64encode(combined).decode('utf-8')

        except Exception as e:
            raise EncryptionError(f"Encryption error: {e}")

    @staticmethod
    def decrypt(ciphertext_b64: str, key_b64: str) -> str:
        """
        Decrypt ciphertext using ChaCha20 (RFC 7539).

        Args:
            ciphertext_b64: Base64 string containing nonce + ciphertext
            key_b64: Base64-encoded 32-byte key

        Returns:
            Decrypted plaintext string

        Raises:
            EncryptionError: If decryption fails
        """
        try:
            # Decode inputs
            key = base64.b64decode(key_b64)
            combined = base64.b64decode(ciphertext_b64)

            # Validate
            if len(key) != 32:
                raise ValueError(f"Invalid key length: {len(key)} bytes")
            if len(combined) < 12:
                raise ValueError(f"Ciphertext too short: {len(combined)} bytes")

            # Extract nonce (first 12 bytes) and ciphertext
            nonce = combined[:12]
            ciphertext = combined[12:]

            # Decrypt using ChaCha20
            cipher = ChaCha20.new(key=key, nonce=nonce)
            plaintext_bytes = cipher.decrypt(ciphertext)

            # Return decoded string
            return plaintext_bytes.decode('utf-8')

        except Exception as e:
            raise EncryptionError(f"Decryption error: {e}")

    @staticmethod
    def encrypt_sensor_data(measurement_name: str, value: float, key_b64: str) -> str:
        """
        Encrypt a sensor measurement for transmission to PNEX Server.

        Args:
            measurement_name: Name of the measurement (e.g., "temperature")
            value: Measurement value (will be converted to string)
            key_b64: Base64-encoded 32-byte encryption key

        Returns:
            Base64-encoded encrypted message ready for WebSocket transmission

        Example:
            encrypted = encrypt_sensor_data("temperature", 23.5, "base64key...")
            # Send via WebSocket: await websocket.send(encrypted)
        """
        # Format as key=value (matching PNEX sensor data format)
        plaintext = f"{measurement_name}={value}"
        return ChaChaEncryptor.encrypt(plaintext, key_b64)

    @staticmethod
    def validate_key(key_b64: str) -> Tuple[bool, Optional[str]]:
        """
        Validate that a key is properly formatted.

        Args:
            key_b64: Base64-encoded key to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            key_bytes = base64.b64decode(key_b64)
            if len(key_bytes) == 32:
                return True, None
            else:
                return False, f"Key is {len(key_bytes)} bytes (expected 32)"
        except Exception as e:
            return False, f"Invalid base64: {e}"

    @staticmethod
    def generate_key() -> str:
        """Generate a random 32-byte key and return as base64."""
        key_bytes = os.urandom(32)
        return base64.b64encode(key_bytes).decode('utf-8')

    @staticmethod
    def is_valid_key(key_b64: str) -> bool:
        """Check if a key is valid (convenience wrapper)."""
        is_valid, _ = ChaChaEncryptor.validate_key(key_b64)
        return is_valid
