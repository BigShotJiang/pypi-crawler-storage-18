"""
Custom exceptions for the PNEX Publisher package.
"""


class PNEXError(Exception):
    """Base exception for all PNEX Publisher errors."""
    pass


class ConfigurationError(PNEXError):
    """Raised when configuration is invalid or missing."""
    pass


class EncryptionError(PNEXError):
    """Raised when encryption or decryption fails."""
    pass


class ConnectionError(PNEXError):
    """Raised when WebSocket connection fails."""
    pass


class PublishError(PNEXError):
    """Raised when publishing data fails."""
    pass


class ValidationError(PNEXError):
    """Raised when input validation fails."""
    pass
