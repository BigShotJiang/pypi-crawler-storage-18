#!/usr/bin/env python3
"""
Main entry point for py-pnex-publisher.

This provides a convenient way to run the package directly:
    python -m py_pnex_publisher
"""

import sys
from pnex_publisher.cli import main

if __name__ == "__main__":
    sys.exit(main())