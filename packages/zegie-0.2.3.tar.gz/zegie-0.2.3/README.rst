.. image:: https://images.unsplash.com/photo-1720214655750-c400b75fcfa2
  :width: 700
  :alt: Zegie - AI System to Streamlines Content Creation for Marketers and Creators

|

.. image:: https://img.shields.io/pypi/v/zegie.svg
    :alt: PyPI-Server
    :target: https://pypi.org/project/zegie/
.. image:: https://github.com/Clivern/zegie/actions/workflows/ci.yml/badge.svg
    :alt: Build Status
    :target: https://github.com/Clivern/zegie/actions/workflows/ci.yml

|

=====
Zegie
=====

AI SDK to Streamlines Content Creation for Marketers and Creators.
