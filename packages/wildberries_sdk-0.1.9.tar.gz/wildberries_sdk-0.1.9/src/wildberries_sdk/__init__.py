"""Wildberries SDK aggregated package."""
