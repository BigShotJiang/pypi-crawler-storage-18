"""CLI output tests."""
