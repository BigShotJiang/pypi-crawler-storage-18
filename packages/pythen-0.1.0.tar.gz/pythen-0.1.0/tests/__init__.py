"""
Test suite for PYTHEN framework.

Run all tests with:
    python -m unittest discover tests
"""
