"""
PYTHEN Documentation

This directory contains comprehensive documentation for the PYTHEN framework:

- getting_started.md: A beginner's guide to using PYTHEN
- api_reference.md: Detailed API documentation
- rule_syntax.md: Complete guide to the rule syntax
- philosophy.md: The design philosophy behind PYTHEN
"""
