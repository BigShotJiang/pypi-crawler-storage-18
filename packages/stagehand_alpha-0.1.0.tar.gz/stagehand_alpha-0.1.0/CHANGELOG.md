# Changelog

## 0.1.0 (2025-12-23)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/browserbase/stagehand-python/compare/v0.0.1...v0.1.0)

### Features

* [STG-1053] [server] Use fastify-zod-openapi + zod v4 for openapi generation ([405c606](https://github.com/browserbase/stagehand-python/commit/405c6068de29f39d90882b31805cc2785c6b94e0))
* **api:** manual updates ([dde1e8b](https://github.com/browserbase/stagehand-python/commit/dde1e8b312f72179c416baaa8603c4a5da9ce706))
* **api:** manual updates ([577cea0](https://github.com/browserbase/stagehand-python/commit/577cea04ec2814b9ec70e5f18119292991e5b635))
* **api:** manual updates ([0cdb22b](https://github.com/browserbase/stagehand-python/commit/0cdb22be4350e78b49a2c90bb62fbf5fcc0d4a25))
* **api:** manual updates ([fcf7666](https://github.com/browserbase/stagehand-python/commit/fcf7666829c41b7892d708c430a1a16b3ea6097e))
* **api:** manual updates ([8590a04](https://github.com/browserbase/stagehand-python/commit/8590a048dbe8a82b8b298b7345b30b71876b6e10))
* **api:** manual updates ([8d1c5ae](https://github.com/browserbase/stagehand-python/commit/8d1c5ae737a481f22818a4adcaba162d015142ee))
* **api:** manual updates ([638e928](https://github.com/browserbase/stagehand-python/commit/638e92824408754dadebbffab7be6e5f14c0034c))
* **api:** manual updates ([13484f8](https://github.com/browserbase/stagehand-python/commit/13484f87d343a9b02d58027ab17114c07fda5220))
* **api:** manual updates ([722abc9](https://github.com/browserbase/stagehand-python/commit/722abc902c2d7210b6b8c35655b9a8dbd6433ee3))
* **api:** manual updates ([72aa8b8](https://github.com/browserbase/stagehand-python/commit/72aa8b8476bddf351364a1bf161454206eaea3ba))
* **api:** manual updates ([54f3289](https://github.com/browserbase/stagehand-python/commit/54f32894104f60ca81cad4797b19a86903f4ef73))
* **api:** manual updates ([9b9d548](https://github.com/browserbase/stagehand-python/commit/9b9d548fb1a4f8a489d4dd920399d2145f4bd3af))
* **api:** manual updates ([54fb057](https://github.com/browserbase/stagehand-python/commit/54fb05764ac58ad86e9ef4a96aefdda001839fc7))
* **api:** manual updates ([5efd001](https://github.com/browserbase/stagehand-python/commit/5efd001ad8e5dbcea9f5aa7dad31584ade9402ae))
* **api:** manual updates ([19a67fd](https://github.com/browserbase/stagehand-python/commit/19a67fd34a16a0acd72427862bcd0eafd6dab353))
* **api:** manual updates ([80413be](https://github.com/browserbase/stagehand-python/commit/80413be240dd2cdf8c0c95f3e47c5537fbeed017))
* **api:** manual updates ([585015c](https://github.com/browserbase/stagehand-python/commit/585015c998f014040086fd927d91949c7d153b86))
* **api:** manual updates ([f032352](https://github.com/browserbase/stagehand-python/commit/f032352d00c69dd94438500c0ced3a110a7cc521))
* **api:** manual updates ([2dcbe2d](https://github.com/browserbase/stagehand-python/commit/2dcbe2d88a8a35781d42e5bbdcebb44e0ba830dc))
* **api:** tweak branding and fix some config fields ([8526eb4](https://github.com/browserbase/stagehand-python/commit/8526eb4417d0f2b69397294b1aa3d4da5892f2d6))


### Bug Fixes

* use async_to_httpx_files in patch method ([77eb123](https://github.com/browserbase/stagehand-python/commit/77eb1234c04a9aa95cedddb15bef377d644f6c42))


### Chores

* **internal:** add `--fix` argument to lint script ([f7eefb4](https://github.com/browserbase/stagehand-python/commit/f7eefb45344f354cfbdbfa00505f0225ce1ad396))
* **internal:** add missing files argument to base client ([5c05e7b](https://github.com/browserbase/stagehand-python/commit/5c05e7b37ae9aff8e259cc3190998d7e259f0cef))
* speedup initial import ([5aafb83](https://github.com/browserbase/stagehand-python/commit/5aafb83959802f8d2a6d7544f115de28a6495d2e))
* update SDK settings ([b8d1cd3](https://github.com/browserbase/stagehand-python/commit/b8d1cd34b5ee9608e52ea009ff31b7a429cdec62))
* update SDK settings ([4c0b2c8](https://github.com/browserbase/stagehand-python/commit/4c0b2c8045935a5790b668e553c114d82550b85e))


### Documentation

* add more examples ([681e90f](https://github.com/browserbase/stagehand-python/commit/681e90f695f60d3b59ee017da3270bd344cf01f6))


### Refactors

* **internal:** switch from rye to uv ([0eba9d2](https://github.com/browserbase/stagehand-python/commit/0eba9d2e2ba2ff82a412adf06e80866e3dc4b7cb))
