from typing import Any

import duckdb


def q(customer: str, orders: str, **kwargs: Any):
    query_str = f"""
    SELECT
        c_count,
        count(*) AS custdist
    FROM (
        SELECT
            c_custkey,
            count(o_orderkey)
        FROM
            {customer}
        LEFT OUTER JOIN {orders} ON c_custkey = o_custkey
        AND o_comment NOT LIKE '%special%requests%'
    GROUP BY
        c_custkey) AS c_orders (c_custkey,
            c_count)
    GROUP BY
        c_count
    ORDER BY
        custdist DESC,
        c_count DESC;
    """

    return duckdb.sql(query_str)
