"""Input sinks package."""
