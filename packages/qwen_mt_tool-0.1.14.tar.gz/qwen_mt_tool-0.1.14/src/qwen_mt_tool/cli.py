import argparse
import concurrent.futures
import glob
import logging
import os

import colorlog
from openai import OpenAI
import json
import time
import threading
from contextlib import contextmanager

# Dictionary to map model names to their descriptions (optional, for reference)
# Using qwen-mt-plus as default using OpenAI compatible endpoint
DEFAULT_MODEL = "qwen-mt-plus"
MAX_WORKERS = 1

# Setup logging
log_colors = {
    "DEBUG": "cyan",
    "INFO": "green",
    "WARNING": "yellow",
    "ERROR": "red",
    "CRITICAL": "red,bg_white",
}

formatter = colorlog.ColoredFormatter(
    "%(log_color)s%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    reset=True,
    log_colors=log_colors,
)

handler = logging.StreamHandler()
handler.setFormatter(formatter)

logger = logging.getLogger("main")
logger.setLevel(logging.INFO)
logger.addHandler(handler)

# Setup usage logger (configured later if enabled)
usage_logger = logging.getLogger("usage")
usage_logger.setLevel(logging.INFO)


prompt_template = """
# Role
You are a senior software development engineer, proficient in multiple programming languages, including but not limited to Python, Java, C++, Go, JavaScript, and others. You have a deep understanding of professional terminology in the field of software engineering.

# Task
I need you to translate the following English document, which may contain code, into professional, precise, and formal Chinese.

# Translation Requirements
1. **Strictly preserve formatting**: Do not arbitrarily change the formatting, including but not limited to paragraphs, numbering, and code.
2. **Be faithful to the original text**: Translate strictly according to the meaning and intent of the original text, without adding or removing any information.
3. **Use precise terminology**: Use professional terminology from the Chinese software development field. For proper nouns, retain the original text.
4. **Ensure clear sentences**: The translation must be clear, unambiguous, and consistent with the expression conventions of Chinese software development documentation.
5. **Preserve formatting**: Maintain the original text’s paragraphs, numbering, and basic formatting.
6. **Preserve code**: Retain the original text’s code format and content. The content within the code, including but not limited to the code itself and its comments, must remain unchanged.

# Text to translate
{text_to_translate}
"""


class KeyPool:
    """Thread-safe pool of API keys with per-key QPS limiting."""
    def __init__(self, api_keys, qps=1.0):
        self.keys = api_keys
        self.qps = qps
        self.min_interval = 1.0 / qps if qps > 0 else 0
        # last_used: {key: timestamp}
        self.last_used = {key: 0.0 for key in api_keys}
        self._lock = threading.Lock()
        self._index = 0

    def get_key(self):
        """Acquire a key and wait if necessary to respect QPS."""
        if not self.keys:
            return None

        with self._lock:
            # Round-robin selection
            key = self.keys[self._index]
            self._index = (self._index + 1) % len(self.keys)

            now = time.time()
            elapsed = now - self.last_used[key]
            wait_time = self.min_interval - elapsed

            if wait_time > 0:
                time.sleep(wait_time)
                now = time.time()

            self.last_used[key] = now
            return key

    @contextmanager
    def acquire(self):
        key = self.get_key()
        try:
            yield key
        finally:
            pass


translation_options_with_terms = {
    "source_lang": "English",
    "target_lang": "Chinese",
    # "terms": [
    #     {
    #         "source": "生物传感器",
    #         "target": "biological sensor"
    #     },
    #     {
    #         "source": "身体健康状况",
    #         "target": "health status of the body"
    #     }
    # ]
}


def split_text_into_chunks(text, max_chars=8000):
    """
    Split text into chunks by lines to avoid exceeding token limits,
    while trying to preserve code block integrity (do not split inside ```...```).
    """
    lines = text.splitlines(keepends=True)
    current_chunk = []
    current_length = 0
    in_code_block = False
    
    for line in lines:
        # standard markdown code block check
        if line.lstrip().startswith("```"):
            in_code_block = not in_code_block
        
        current_chunk.append(line)
        current_length += len(line)
        
        # Only yield if over limit AND not inside a code block
        # If a single code block is huge (> max_chars), we might still have to yield eventually
        # or risk API error. For now, prefer integrity.
        if current_length > max_chars and not in_code_block:
            yield "".join(current_chunk)
            current_chunk = []
            current_length = 0
            
    if current_chunk:
        yield "".join(current_chunk)


def find_markdown_files(root_dir):
    """Recursively find markdown files, excluding already translated ones."""
    md_files = []
    # glob.glob with recursive=True requires ** pattern
    # search for all .md files
    all_md_files = glob.glob(os.path.join(root_dir, "**", "*.md"), recursive=True)

    for f in all_md_files:
        # Check if it's already a translated file to avoid double translation
        if f.endswith("_zh_cn.md") or f.endswith("_zh_CN.md"):
            continue
        md_files.append(f)

    return md_files


def translate_text(text, api_key_or_pool):
    """Call OpenAI compatible API to translate text."""
    
    api_key = None
    if isinstance(api_key_or_pool, KeyPool):
        api_key = api_key_or_pool.get_key()
    else:
        api_key = api_key_or_pool

    if not api_key:
        logger.error("API Key not provided.")
        return None, None

    # Base URL for Qwen-MT OpenAI compatibility
    # Beijing region: https://dashscope.aliyuncs.com/compatible-mode/v1
    # Singapore region: https://dashscope-intl.aliyuncs.com/compatible-mode/v1
    base_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"

    try:
        client = OpenAI(api_key=api_key, base_url=base_url)

        messages = [{"role": "user", "content": text}]

        # using extra_body to pass translation_options
        completion = client.chat.completions.create(
            model=DEFAULT_MODEL,
            messages=messages,
            extra_body={
                "translation_options": translation_options_with_terms
            }
        )

        # Extract content
        translated_content = completion.choices[0].message.content
        # Extract usage
        usage = completion.usage
        return translated_content, usage

    except Exception as e:
        logger.error(f"Exception during translation: {e}")
        return None, None


def translate_file(file_path, api_key_or_pool):
    """Handle translation of a single file with splitting and skipping logic."""
    # Check if output file already exists
    output_path = f"{file_path[:-3]}_zh_CN.md"
    
    if os.path.exists(output_path):
        logger.info(f"Skipping {file_path}: Translation already exists at {output_path}")
        return file_path, True # Success (skipped)

    logger.info(f"Processing file: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if not content.strip():
            logger.warning(f"File {file_path} is empty, skipping.")
            return file_path, True # Empty considered success/done

        final_translated_content = []
        total_input_tokens = 0
        total_output_tokens = 0
        total_tokens = 0
        
        chunks = list(split_text_into_chunks(content))
        total_chunks = len(chunks)
        
        if total_chunks > 1:
            logger.info(f"File {file_path} split into {total_chunks} chunks.")

        # Determine chunk concurrency
        chunk_workers = 1
        if isinstance(api_key_or_pool, KeyPool):
            chunk_workers = len(api_key_or_pool.keys)
        
        # Parallel chunk translation
        translated_chunks_map = {} # index -> content
        total_input_tokens = 0
        total_output_tokens = 0
        total_tokens = 0
        failure_occurred = False

        def process_chunk(index, chunk_text):
            nonlocal failure_occurred, total_input_tokens, total_output_tokens, total_tokens
            if failure_occurred:
                return None
            
            if total_chunks > 1:
                logger.info(f"[{file_path}] Translating chunk {index}/{total_chunks}...")
            
            res_content, res_usage = translate_text(chunk_text, api_key_or_pool=api_key_or_pool)
            
            if res_content:
                # Thread-safe enough for non-critical aggregate increment in python? 
                # Actually, better be safe with lock if we were doing more complex stuff, 
                # but simple increment is usually fine for stats.
                # However, translate_text itself might sleep due to KeyPool.
                return index, res_content, res_usage
            else:
                logger.error(f"Failed to translate chunk {index} of {file_path}")
                failure_occurred = True
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=chunk_workers) as chunk_executor:
            # chunk index starts at 1
            future_to_chunk = {chunk_executor.submit(process_chunk, i, chunk): i for i, chunk in enumerate(chunks, 1)}
            
            for future in concurrent.futures.as_completed(future_to_chunk):
                result = future.result()
                if result:
                    idx, content, usage = result
                    translated_chunks_map[idx] = content
                    if usage:
                        total_input_tokens += usage.prompt_tokens
                        total_output_tokens += usage.completion_tokens
                        total_tokens += usage.total_tokens
                else:
                    failure_occurred = True

        if failure_occurred:
            return file_path, False

        # Assemble in correct order
        final_translated_content = [translated_chunks_map[i] for i in range(1, total_chunks + 1)]

        # Write output
        full_content = "\n\n".join(final_translated_content)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(full_content)
        
        logger.info(f"Saved translation to {output_path}")
        
        # Log aggregated usage
        # Format: File: {file_path}, Input: {total_input_tokens}, Output: {total_output_tokens}, Total: {total_tokens}
        # But user requested CSV: Time|File Path|Input Token|Output Token|Total Token
        usage_msg_log = f"File: {file_path}, Input: {total_input_tokens}, Output: {total_output_tokens}, Total: {total_tokens}"
        logger.info(f"Translation successful [{file_path}]. Total Usage - {usage_msg_log}")
        
        if usage_logger.hasHandlers():
            # Construct CSV line
            import datetime
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Message: Time,File Path,Input Token,Output Token,Total Token
            # Using , as separator for standard CSV.
            # Handle potential commas in file path by quoting if necessary, but simple approach first.
            if "," in file_path:
                file_path_safe = f'"{file_path}"'
            else:
                file_path_safe = file_path
                
            csv_msg = f"{now},{file_path_safe},{total_input_tokens},{total_output_tokens},{total_tokens}"
            usage_logger.info(csv_msg)
            
        return file_path, True

    except Exception as e:
        logger.error(f"Error processing file {file_path}: {e}")
        return file_path, False


def setup_logging(enable_logging, log_file):
    if not enable_logging:
        return

    # File handler for main logger
    file_handler = logging.FileHandler(log_file)
    file_formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)


def setup_usage_logging(enable_usage_log, usage_log_file):
    if not enable_usage_log:
        return
        
    # Check if file exists to write header
    write_header = not os.path.exists(usage_log_file)
    
    usage_handler = logging.FileHandler(usage_log_file)
    # Plain format
    usage_formatter = logging.Formatter("%(message)s")
    usage_handler.setFormatter(usage_formatter)
    usage_logger.addHandler(usage_handler)
    usage_logger.propagate = False
    
    if write_header:
        usage_logger.info("Time,File Path,Input Token,Output Token,Total Token")


import shutil

def handle_copy(args):
    """Recursively copy translated files from src to dst, removing the suffix."""
    src_dir = os.path.abspath(args.src)
    dst_dir = os.path.abspath(args.dst)

    if not os.path.isdir(src_dir):
        logger.error(f"Source directory does not exist or is not a directory: {src_dir}")
        return

    logger.info(f"Copying translated files from {src_dir} to {dst_dir}...")

    # Pattern for translated files
    patterns = ["**/*._zh_CN.md", "**/*._zh_cn.md"]
    files_to_copy = []
    for pattern in patterns:
        files_to_copy.extend(glob.glob(os.path.join(src_dir, pattern), recursive=True))

    if not files_to_copy:
        logger.info("No translated files found to copy.")
        return

    logger.info(f"Found {len(files_to_copy)} translated files.")
    copy_count = 0

    for src_file in files_to_copy:
        try:
            # Calculate relative path from src_dir
            rel_path = os.path.relpath(src_file, src_dir)
            
            # Remove suffix and rename
            # Handle both _zh_CN.md and _zh_cn.md
            if rel_path.endswith("_zh_CN.md"):
                new_rel_path = rel_path[:-10] + ".md"
            elif rel_path.endswith("_zh_cn.md"):
                new_rel_path = rel_path[:-10] + ".md"
            else:
                continue

            dst_file = os.path.join(dst_dir, new_rel_path)

            # Ensure destination directory exists
            os.makedirs(os.path.dirname(dst_file), exist_ok=True)

            # Copy file
            shutil.copy2(src_file, dst_file)
            logger.info(f"Copied: {rel_path} -> {new_rel_path}")
            copy_count += 1
        except Exception as e:
            logger.error(f"Failed to copy {src_file}: {e}")

    logger.info(f"Successfully copied {copy_count} files.")


def main():
    parser = argparse.ArgumentParser(description="Qwen-MT tool for translating and managing markdown files.")
    subparsers = parser.add_subparsers(dest="command", help="Subcommand to run")

    # Translate subcommand
    translate_parser = subparsers.add_parser("translate", help="Translate markdown files")
    translate_parser.add_argument("path", nargs="?", default=os.getcwd(), help="File or directory path to translate")
    translate_parser.add_argument("--workers", type=int, default=MAX_WORKERS, help=f"Number of concurrent workers (default: {MAX_WORKERS})")
    translate_parser.add_argument("--api-key", type=str, help="DashScope API Key (overrides DASHSCOPE_API_KEY env var)")
    translate_parser.add_argument("--log-enable", action="store_true", help="Enable general logging to file")
    translate_parser.add_argument("--log-file", type=str, default="translation.log", help="Path to log file (default: translation.log)")
    translate_parser.add_argument("--usage-log-enable", action="store_true", help="Enable usage statistics logging to CSV")
    translate_parser.add_argument("--usage-log-file", type=str, default="usage.csv", help="Path to usage log file (default: usage.csv)")

    # Copy subcommand
    copy_parser = subparsers.add_parser("copy", help="Recursively copy translated files to destination")
    copy_parser.add_argument("src", help="Source directory")
    copy_parser.add_argument("dst", help="Destination directory")

    # For backward compatibility: if the first argument is not a command, assume "translate"
    import sys
    if len(sys.argv) > 1 and sys.argv[1] not in ["translate", "copy", "-h", "--help"]:
        # Insert "translate" at the beginning of arguments to make it default
        sys.argv.insert(1, "translate")

    args = parser.parse_args()

    if args.command == "copy":
        handle_copy(args)
    elif args.command == "translate":
        handle_translate(args)
    else:
        parser.print_help()


def handle_translate(args):
    # API Key search order:
    # 1. ~/.qwen.json
    # 2. --api-key argument
    # 3. DASHSCOPE_API_KEY environment variable
    
    api_keys = []
    config_path = os.path.expanduser("~/.qwen.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
                api_keys = config.get("api_keys", [])
                if api_keys:
                    logger.info(f"Loaded {len(api_keys)} API keys from {config_path}")
        except Exception as e:
            logger.warning(f"Failed to load config from {config_path}: {e}")

    # Fallback to single key if pool is empty
    if not api_keys:
        api_key = args.api_key or os.getenv("DASHSCOPE_API_KEY")
        if api_key:
            api_keys = [api_key]

    if not api_keys:
        logger.error(
            "API Key not found. Please provide it via ~/.qwen.json, --api-key argument, or DASHSCOPE_API_KEY environment variable."
        )
        return
    
    # Initialize KeyPool
    api_key_or_pool = KeyPool(api_keys)
    
    # Setup logging based on args
    setup_logging(args.log_enable, args.log_file)
    setup_usage_logging(args.usage_log_enable, args.usage_log_file)
    
    # Hide key in logs for security, print only partial or just presence
    if len(api_keys) > 1:
        logger.info(f"Using API Key Pool with {len(api_keys)} keys")
    elif len(api_keys) == 1:
        key_to_log = api_keys[0]
        logger.info(f"Using API Key: {key_to_log[:4]}...{key_to_log[-4:] if len(key_to_log)>8 else ''}")

    target_path = os.path.abspath(args.path)

    files_to_translate = []

    if os.path.isfile(target_path):
        if target_path.endswith(".md") and not (target_path.endswith("_zh_cn.md") or target_path.endswith("_zh_CN.md")):
            files_to_translate = [target_path]
        else:
            logger.error(f"Invalid file: {target_path}. Must be a .md file and not a translation output.")
            return
    elif os.path.isdir(target_path):
        logger.info(f"Scanning for markdown files in {target_path}...")
        files_to_translate = find_markdown_files(target_path)
    else:
        logger.error(f"Path not found: {target_path}")
        return

    count = len(files_to_translate)
    logger.info(f"Found {count} files to translate.")

    if count == 0:
        logger.info("No files found. Exiting.")
        return

    logger.info(f"Starting translation with {args.workers} workers...")

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        # Submit all tasks
        future_to_file = {executor.submit(translate_file, f, api_key_or_pool): f for f in files_to_translate}
        
        completed_count = 0
        for future in concurrent.futures.as_completed(future_to_file):
            completed_count += 1
            file_path, success = future.result()
            remaining = count - completed_count
            logger.info(f"Progress: [{completed_count}/{count}] Completed. ({remaining} Remaining)")



if __name__ == "__main__":
    main()
