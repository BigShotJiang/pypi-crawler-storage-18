# fc-coder

Command line coding agent with a terminal UI.

## Installation

```bash
# From PyPI
pip install fc-coder

# Or with pipx (recommended for CLI tools)
pipx install fc-coder

# Or from source
git clone https://github.com/dnivra26/fc-coder.git
cd fc-coder
uv sync
```

## Tech Stack

- **Textual** - Terminal UI framework
- **LangGraph** - Agent orchestration (plan-execute workflow)
- **OpenAI or AWS Bedrock** - LLM provider

## Agent Tools

- `read_file` - Read file contents
- `write_file` - Create or overwrite files
- `edit_file` - Replace text in existing files
- `run_shell` - Execute shell commands
- `list_dir` - List directory contents
- `search_files` - Glob pattern file search
- `search_content` - Regex content search inside files

## Model Provider Configuration

fc-coder supports OpenAI and AWS Bedrock. Set `LLM_PROVIDER` to choose:

### OpenAI (default)

```bash
export LLM_PROVIDER=openai
export OPENAI_API_KEY=your-api-key
export MODEL_NAME=gpt-4                            # Optional, defaults to gpt-4
export OPENAI_API_BASE=https://api.openai.com/v1   # Optional, for custom endpoints
```

### AWS Bedrock

```bash
export LLM_PROVIDER=bedrock
export AWS_REGION=us-east-1                        # Optional, defaults to us-east-1
export MODEL_NAME=anthropic.claude-3-5-sonnet-20241022-v2:0  # Optional
```

AWS credentials: environment variables, `~/.aws/credentials`, or IAM role.

**Bedrock models:**
| Model | Model ID |
|-------|----------|
| Claude 3.5 Sonnet v2 | `anthropic.claude-3-5-sonnet-20241022-v2:0` |
| Claude 3.5 Haiku | `anthropic.claude-3-5-haiku-20241022-v1:0` |
| Claude 3 Opus | `anthropic.claude-3-opus-20240229-v1:0` |

## Run

```bash
# If installed via pip/pipx
fc-coder

# If running from source
uv run fc-coder
```

## Workflow

fc-coder uses a two-phase workflow:

1. **Plan Phase** - Agent explores codebase with read-only tools, creates implementation plan
2. **Execute Phase** - Agent implements the plan with full tool access

This ensures the agent understands the codebase before making changes.

## Requirements

- Python 3.12+

## License

Apache 2.0


