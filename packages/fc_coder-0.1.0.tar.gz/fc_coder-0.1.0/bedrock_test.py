#!/usr/bin/env python3
"""Test script to verify Bedrock model integration is working."""

import os
import sys


def test_import():
    """Test that langchain-aws is installed."""
    print("1. Testing imports...")
    try:
        from langchain_aws import ChatBedrockConverse
        print("   ✓ langchain-aws imported successfully")
        return True
    except ImportError as e:
        print(f"   ✗ Import failed: {e}")
        print("   Run: uv sync --extra bedrock")
        return False


def test_client_creation():
    """Test that Bedrock client can be created."""
    print("\n2. Testing client creation...")
    try:
        from fc_coder.llm import get_bedrock_llm
        llm = get_bedrock_llm()
        print(f"   ✓ Client created: {type(llm).__name__}")
        print(f"   ✓ Model ID: {llm.model_id}")
        print(f"   ✓ Region: {llm.region_name}")
        return llm
    except Exception as e:
        print(f"   ✗ Client creation failed: {e}")
        return None


def test_bind_tools(llm):
    """Test that tool binding works."""
    print("\n3. Testing tool binding...")
    try:
        from langchain_core.tools import tool

        @tool
        def add(a: int, b: int) -> int:
            """Add two numbers."""
            return a + b

        llm_with_tools = llm.bind_tools([add])
        print("   ✓ Tool binding successful")
        return llm_with_tools
    except Exception as e:
        print(f"   ✗ Tool binding failed: {e}")
        return None


def test_simple_invoke(llm):
    """Test a simple invocation without tools."""
    print("\n4. Testing simple invocation...")
    try:
        response = llm.invoke("Say 'hello' and nothing else.")
        content = response.content if hasattr(response, 'content') else str(response)
        print(f"   ✓ Response: {content[:100]}")
        return True
    except Exception as e:
        print(f"   ✗ Invocation failed: {e}")
        return False


def test_tool_call(llm_with_tools):
    """Test that tool calls work."""
    print("\n5. Testing tool calling...")
    try:
        response = llm_with_tools.invoke("What is 2 + 3? Use the add tool.")

        if hasattr(response, 'tool_calls') and response.tool_calls:
            print(f"   ✓ Tool calls detected: {len(response.tool_calls)}")
            for tc in response.tool_calls:
                print(f"   ✓ Tool: {tc['name']}, Args: {tc['args']}")
            return True
        else:
            content = response.content if hasattr(response, 'content') else str(response)
            print(f"   ? No tool calls, response: {content[:100]}")
            return False
    except Exception as e:
        print(f"   ✗ Tool call failed: {e}")
        return False


def main():
    print("=" * 50)
    print("Bedrock Integration Test")
    print("=" * 50)

    # Check environment
    print(f"\nEnvironment:")
    print(f"  LLM_PROVIDER: {os.getenv('LLM_PROVIDER', 'not set')}")
    print(f"  AWS_REGION: {os.getenv('AWS_REGION', 'not set')}")
    print(f"  MODEL_NAME: {os.getenv('MODEL_NAME', 'not set')}")
    print(f"  AWS_ACCESS_KEY_ID: {'set' if os.getenv('AWS_ACCESS_KEY_ID') else 'not set'}")
    print(f"  AWS_PROFILE: {os.getenv('AWS_PROFILE', 'not set')}")

    # Run tests
    if not test_import():
        sys.exit(1)

    llm = test_client_creation()
    if not llm:
        sys.exit(1)

    llm_with_tools = test_bind_tools(llm)
    if not llm_with_tools:
        sys.exit(1)

    if not test_simple_invoke(llm):
        sys.exit(1)

    if not test_tool_call(llm_with_tools):
        print("\n⚠ Tool calling may not be working correctly")
        sys.exit(1)

    print("\n" + "=" * 50)
    print("✓ All tests passed! Bedrock is working correctly.")
    print("=" * 50)


if __name__ == "__main__":
    main()
