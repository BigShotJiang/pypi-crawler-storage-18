"""LLM client configuration for OpenAI and AWS Bedrock."""

import os
from typing import Union

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI


def get_model_info() -> dict:
    """Get current model configuration info.

    Returns:
        dict with 'provider', 'model', and optionally 'region'
    """
    provider = os.getenv("LLM_PROVIDER", "openai").lower()

    if provider == "bedrock":
        return {
            "provider": "AWS Bedrock",
            "model": os.getenv("MODEL_NAME", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
            "region": os.getenv("AWS_REGION", "us-east-1"),
        }
    else:
        return {
            "provider": "OpenAI",
            "model": os.getenv("MODEL_NAME", "gpt-4"),
        }


def get_openai_llm() -> ChatOpenAI:
    """Create an OpenAI-compatible LLM client.

    Environment variables:
        OPENAI_API_KEY: API key (required)
        OPENAI_API_BASE: Base URL (optional, for custom endpoints)
        MODEL_NAME: Model to use (default: gpt-4)
    """
    return ChatOpenAI(
        model=os.getenv("MODEL_NAME", "gpt-4"),
        base_url=os.getenv("OPENAI_API_BASE"),
        api_key=os.getenv("OPENAI_API_KEY"),
    )


def get_bedrock_llm() -> BaseChatModel:
    """Create an AWS Bedrock LLM client.

    Environment variables:
        AWS_ACCESS_KEY_ID: AWS access key (or use AWS profile/IAM role)
        AWS_SECRET_ACCESS_KEY: AWS secret key (or use AWS profile/IAM role)
        AWS_REGION: AWS region (default: us-east-1)
        MODEL_NAME: Bedrock model ID (default: anthropic.claude-3-5-sonnet-20241022-v2:0)

    Requires: pip install fc-coder[bedrock]
    """
    try:
        from langchain_aws import ChatBedrockConverse
    except ImportError:
        raise ImportError(
            "langchain-aws is required for Bedrock support. "
            "Install with: pip install fc-coder[bedrock]"
        )

    return ChatBedrockConverse(
        model_id=os.getenv("MODEL_NAME", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
        region_name=os.getenv("AWS_REGION", "us-east-1"),
    )


def get_llm() -> BaseChatModel:
    """Create and return a configured LLM client based on LLM_PROVIDER.

    Environment variables:
        LLM_PROVIDER: Provider to use - "openai" (default) or "bedrock"

    For OpenAI:
        OPENAI_API_KEY: API key (required)
        OPENAI_API_BASE: Base URL (optional)
        MODEL_NAME: Model name (default: gpt-4)

    For Bedrock:
        AWS_ACCESS_KEY_ID: AWS access key (or use AWS profile/IAM role)
        AWS_SECRET_ACCESS_KEY: AWS secret key (or use AWS profile/IAM role)
        AWS_REGION: AWS region (default: us-east-1)
        MODEL_NAME: Bedrock model ID (default: anthropic.claude-3-5-sonnet-20241022-v2:0)
    """
    provider = os.getenv("LLM_PROVIDER", "openai").lower()

    if provider == "bedrock":
        return get_bedrock_llm()
    elif provider == "openai":
        return get_openai_llm()
    else:
        raise ValueError(
            f"Unknown LLM_PROVIDER: {provider}. "
            "Supported values: 'openai', 'bedrock'"
        )
