"""fc-coder: Command line coding agent."""

__version__ = "0.1.0"
