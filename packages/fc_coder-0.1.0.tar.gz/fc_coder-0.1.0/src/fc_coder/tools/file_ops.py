"""File operation tools: read, write, and edit files."""

from pathlib import Path

from langchain_core.tools import tool


@tool
def read_file(path: str) -> str:
    """Read the contents of a file.

    Args:
        path: Path to the file to read.

    Returns:
        The file contents as a string.
    """
    file_path = Path(path).expanduser().resolve()
    if not file_path.exists():
        return f"Error: File not found: {path}"
    if not file_path.is_file():
        return f"Error: Not a file: {path}"
    try:
        return file_path.read_text()
    except Exception as e:
        return f"Error reading file: {e}"


@tool
def write_file(path: str, content: str) -> str:
    """Write content to a file, creating it if it doesn't exist.

    Args:
        path: Path to the file to write.
        content: Content to write to the file.

    Returns:
        Success or error message.
    """
    file_path = Path(path).expanduser().resolve()
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)
        return f"Successfully wrote to {path}"
    except Exception as e:
        return f"Error writing file: {e}"


@tool
def edit_file(path: str, old_text: str, new_text: str) -> str:
    """Edit a file by replacing old_text with new_text.

    Args:
        path: Path to the file to edit.
        old_text: Text to find and replace.
        new_text: Text to replace with.

    Returns:
        Success or error message.
    """
    file_path = Path(path).expanduser().resolve()
    if not file_path.exists():
        return f"Error: File not found: {path}"
    try:
        content = file_path.read_text()
        if old_text not in content:
            return f"Error: Text not found in file: {old_text[:50]}..."
        new_content = content.replace(old_text, new_text, 1)
        file_path.write_text(new_content)
        return f"Successfully edited {path}"
    except Exception as e:
        return f"Error editing file: {e}"
