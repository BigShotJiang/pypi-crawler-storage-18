"""Search and directory listing tools."""

import re
from pathlib import Path

from langchain_core.tools import tool


@tool
def list_dir(path: str = ".") -> str:
    """List contents of a directory.

    Args:
        path: Path to the directory (default: current directory).

    Returns:
        Formatted list of directory contents with file info.
    """
    dir_path = Path(path).expanduser().resolve()
    if not dir_path.exists():
        return f"Error: Directory not found: {path}"
    if not dir_path.is_dir():
        return f"Error: Not a directory: {path}"

    try:
        entries = []
        for item in sorted(dir_path.iterdir()):
            if item.is_dir():
                entries.append(f"[DIR]  {item.name}/")
            else:
                size = item.stat().st_size
                entries.append(f"[FILE] {item.name} ({size} bytes)")
        if not entries:
            return f"Directory {path} is empty"
        return "\n".join(entries)
    except Exception as e:
        return f"Error listing directory: {e}"


@tool
def search_files(pattern: str, path: str = ".") -> str:
    """Search for files matching a glob pattern.

    Args:
        pattern: Glob pattern to match (e.g., "*.py", "**/*.txt").
        path: Directory to search in (default: current directory).

    Returns:
        List of matching file paths.
    """
    search_path = Path(path).expanduser().resolve()
    if not search_path.exists():
        return f"Error: Path not found: {path}"

    try:
        matches = list(search_path.glob(pattern))
        if not matches:
            return f"No files found matching '{pattern}' in {path}"
        return "\n".join(str(m.relative_to(search_path)) for m in sorted(matches)[:100])
    except Exception as e:
        return f"Error searching files: {e}"


@tool
def search_content(
    pattern: str,
    path: str = ".",
    file_glob: str = "**/*",
    max_results: int = 50,
) -> str:
    """Search for text content inside files using regex.

    Args:
        pattern: Regex pattern to search for (e.g., "def.*init", "TODO").
        path: Directory to search in (default: current directory).
        file_glob: Glob pattern to filter files (default: all files).
        max_results: Maximum number of matches to return (default: 50).

    Returns:
        Matching lines with file paths and line numbers.
    """
    search_path = Path(path).expanduser().resolve()
    if not search_path.exists():
        return f"Error: Path not found: {path}"

    try:
        regex = re.compile(pattern, re.IGNORECASE)
    except re.error as e:
        return f"Error: Invalid regex pattern: {e}"

    results = []
    files_searched = 0
    files_with_matches = 0

    try:
        for file_path in search_path.glob(file_glob):
            if not file_path.is_file():
                continue
            # Skip binary files and hidden directories
            if any(part.startswith(".") for part in file_path.parts):
                continue

            files_searched += 1
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                file_matches = []
                for line_num, line in enumerate(content.splitlines(), 1):
                    if regex.search(line):
                        # Truncate long lines
                        display_line = line.strip()[:200]
                        file_matches.append(f"  {line_num}: {display_line}")

                if file_matches:
                    files_with_matches += 1
                    rel_path = file_path.relative_to(search_path)
                    results.append(f"{rel_path}")
                    results.extend(file_matches[:10])  # Max 10 matches per file
                    if len(file_matches) > 10:
                        results.append(f"  ... and {len(file_matches) - 10} more matches")

                    if len(results) >= max_results:
                        break
            except (OSError, UnicodeDecodeError):
                continue

        if not results:
            return f"No matches found for '{pattern}' in {files_searched} files"

        summary = f"Found matches in {files_with_matches} files (searched {files_searched} files):\n\n"
        return summary + "\n".join(results)
    except Exception as e:
        return f"Error searching content: {e}"
