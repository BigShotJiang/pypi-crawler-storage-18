"""Agent tools for file operations, shell execution, and search."""

from fc_coder.tools.file_ops import read_file, write_file, edit_file
from fc_coder.tools.shell import run_shell
from fc_coder.tools.search import list_dir, search_files, search_content

# Tool categorization for plan-execute workflow
READ_ONLY_TOOLS = [
    read_file,
    list_dir,
    search_files,
    search_content,
]

WRITE_TOOLS = [
    write_file,
    edit_file,
    run_shell,
]

ALL_TOOLS = READ_ONLY_TOOLS + WRITE_TOOLS

__all__ = [
    "read_file",
    "write_file",
    "edit_file",
    "run_shell",
    "list_dir",
    "search_files",
    "search_content",
    "READ_ONLY_TOOLS",
    "WRITE_TOOLS",
    "ALL_TOOLS",
]
