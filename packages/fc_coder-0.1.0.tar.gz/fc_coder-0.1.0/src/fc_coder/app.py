"""Textual UI for the coding agent."""

import asyncio

from textual.app import App, ComposeResult
from textual.containers import VerticalScroll
from textual.widgets import Header, Footer, Input, Static, Markdown
from textual.binding import Binding

from fc_coder.agent import create_agent, Phase
from fc_coder.llm import get_model_info

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

LOGO = r"""
 _____ _____  ______ _____    _____          _
|_   _|  __ \|  ____/ ____|  / ____|        | |
  | | | |  | | |__ | |      | |     ___   __| | ___ _ __
  | | | |  | |  __|| |      | |    / _ \ / _` |/ _ \ '__|
 _| |_| |__| | |   | |____  | |___| (_) | (_| |  __/ |
|_____|_____/|_|    \_____|  \_____\___/ \__,_|\___|_|
"""

INTRO = """Your AI-powered coding assistant with direct access to the filesystem.
Ask me to read, write, edit files, run commands, or explore your codebase.

Workflow: [cyan]PLAN[/] (read-only exploration) -> [green]EXECUTE[/] (implementation)"""


class WelcomeBanner(Static):
    """Welcome banner with logo and introduction."""

    def compose(self) -> ComposeResult:
        yield Static(LOGO, classes="logo")
        yield Static(INTRO, classes="intro")

        # Display model info
        info = get_model_info()
        model_text = f"[bold]Model:[/] {info['model']} ([cyan]{info['provider']}[/]"
        if "region" in info:
            model_text += f" / {info['region']}"
        model_text += ")"
        yield Static(model_text, classes="model-info")


class PhaseIndicator(Static):
    """Shows the current workflow phase."""

    def __init__(self, phase: Phase = Phase.PLAN) -> None:
        super().__init__()
        self.phase = phase
        self._update_display()

    def _update_display(self) -> None:
        if self.phase == Phase.PLAN:
            self.update("[bold cyan]PLAN MODE[/] - Exploring codebase (read-only)")
            self.add_class("phase-plan")
            self.remove_class("phase-execute")
        else:
            self.update("[bold green]EXECUTE MODE[/] - Implementing changes")
            self.add_class("phase-execute")
            self.remove_class("phase-plan")

    def set_phase(self, phase: Phase) -> None:
        self.phase = phase
        self._update_display()


class WorkingIndicator(Static):
    """Animated indicator showing the agent is working."""

    def __init__(self, phase: Phase = Phase.PLAN) -> None:
        super().__init__()
        self.frame_index = 0
        self._timer = None
        self.phase = phase

    def on_mount(self) -> None:
        self._timer = self.set_interval(0.1, self._update_spinner)

    def _update_spinner(self) -> None:
        self.frame_index = (self.frame_index + 1) % len(SPINNER_FRAMES)
        spinner = SPINNER_FRAMES[self.frame_index]
        phase_text = "Planning..." if self.phase == Phase.PLAN else "Executing..."
        self.update(f"{spinner} {phase_text}")

    def set_phase(self, phase: Phase) -> None:
        self.phase = phase


class PhaseTransition(Static):
    """Visual indicator for phase transition."""

    def __init__(self) -> None:
        super().__init__()

    def compose(self) -> ComposeResult:
        yield Static(
            "[bold yellow]>>> Transitioning to EXECUTE MODE >>>[/]",
            classes="transition-text",
        )


class Message(Static):
    """A chat message widget."""

    def __init__(self, content: str, role: str = "user") -> None:
        super().__init__()
        self.content = content
        self.role = role

    def compose(self) -> ComposeResult:
        prefix = "You" if self.role == "user" else "Assistant"
        yield Markdown(f"**{prefix}:**\n\n{self.content}")


class ToolCall(Static):
    """A tool call display widget."""

    def __init__(self, tool_name: str, result: str, phase: Phase = Phase.PLAN) -> None:
        super().__init__()
        self.tool_name = tool_name
        self.result = result
        self.phase = phase

    def compose(self) -> ComposeResult:
        truncated = self.result[:500] + "..." if len(self.result) > 500 else self.result
        phase_icon = "[P]" if self.phase == Phase.PLAN else "[E]"
        yield Markdown(f"**{phase_icon} Tool: {self.tool_name}**\n```\n{truncated}\n```")


class IDFCCoder(App):
    """IDFC Coder - AI-powered coding assistant."""

    TITLE = "IDFC Coder"

    CSS = """
    VerticalScroll {
        height: 1fr;
        padding: 1;
        scrollbar-gutter: stable;
    }

    WelcomeBanner {
        padding: 1 2;
        margin-bottom: 1;
    }

    .logo {
        color: $primary;
        text-style: bold;
    }

    .intro {
        color: $text-muted;
        padding-top: 1;
    }

    .model-info {
        color: $text;
        padding-top: 1;
    }

    PhaseIndicator {
        dock: top;
        height: 1;
        padding: 0 1;
        text-style: bold;
    }

    .phase-plan {
        background: $primary-darken-3;
    }

    .phase-execute {
        background: $success-darken-3;
    }

    PhaseTransition {
        height: 1;
        padding: 0 1;
        margin: 1 0;
    }

    .transition-text {
        text-align: center;
    }

    Message {
        margin: 1 0;
        padding: 1;
    }

    ToolCall {
        margin: 0 2;
        padding: 0 1;
        color: $text-muted;
    }

    WorkingIndicator {
        dock: bottom;
        height: 1;
        padding: 0 1;
        color: $warning;
        text-style: bold;
    }

    Input {
        dock: bottom;
        margin: 1;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit"),
        Binding("ctrl+q", "quit", "Quit"),
        Binding("escape", "cancel", "Cancel", show=False),
        Binding("up", "scroll_up", "Scroll Up", show=False),
        Binding("down", "scroll_down", "Scroll Down", show=False),
        Binding("pageup", "page_up", "Page Up", show=False),
        Binding("pagedown", "page_down", "Page Down", show=False),
        Binding("home", "scroll_home", "Scroll Home", show=False),
        Binding("end", "scroll_end", "Scroll End", show=False),
    ]

    def action_scroll_up(self) -> None:
        """Scroll chat log up."""
        self.query_one("#chat-log", VerticalScroll).scroll_up()

    def action_scroll_down(self) -> None:
        """Scroll chat log down."""
        self.query_one("#chat-log", VerticalScroll).scroll_down()

    def action_page_up(self) -> None:
        """Page up in chat log."""
        self.query_one("#chat-log", VerticalScroll).scroll_page_up()

    def action_page_down(self) -> None:
        """Page down in chat log."""
        self.query_one("#chat-log", VerticalScroll).scroll_page_down()

    def action_scroll_home(self) -> None:
        """Scroll to top of chat log."""
        self.query_one("#chat-log", VerticalScroll).scroll_home()

    def action_scroll_end(self) -> None:
        """Scroll to bottom of chat log."""
        self.query_one("#chat-log", VerticalScroll).scroll_end()

    def __init__(self) -> None:
        super().__init__()
        self.agent = create_agent()
        self.messages: list[dict] = []
        self.current_phase: Phase = Phase.PLAN
        self._cancel_requested: bool = False
        self._is_running: bool = False

    def action_cancel(self) -> None:
        """Cancel current agent execution."""
        if self._is_running:
            self._cancel_requested = True

    def action_quit(self) -> None:
        """Quit app, or cancel execution if running."""
        if self._is_running:
            self._cancel_requested = True
        else:
            self.exit()

    def compose(self) -> ComposeResult:
        yield Header()
        yield PhaseIndicator(Phase.PLAN)
        yield VerticalScroll(WelcomeBanner(), id="chat-log")
        yield Input(placeholder="Ask me anything...", id="user-input")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#user-input", Input).focus()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        user_input = event.value.strip()
        if not user_input:
            return

        input_widget = self.query_one("#user-input", Input)
        input_widget.value = ""
        input_widget.disabled = True

        chat_log = self.query_one("#chat-log", VerticalScroll)
        phase_indicator = self.query_one(PhaseIndicator)

        # Reset to plan phase for new tasks
        self.current_phase = Phase.PLAN
        phase_indicator.set_phase(Phase.PLAN)

        # Add user message
        self.messages.append({"role": "user", "content": user_input})
        await chat_log.mount(Message(user_input, "user"))
        chat_log.scroll_end()

        # Show working indicator
        working = WorkingIndicator(self.current_phase)
        await self.mount(working)

        # Reset cancellation state and mark as running
        self._cancel_requested = False
        self._is_running = True

        # Get agent response
        try:
            response_content = ""
            shown_transition = False
            cancelled = False

            async for evt in self.agent.astream_events(
                {
                    "messages": self.messages,
                    "phase": self.current_phase,
                    "plan": "",
                },
                version="v2",
                config={"recursion_limit": 100},
            ):
                # Yield to event loop to process key events
                await asyncio.sleep(0)

                # Check for cancellation
                if self._cancel_requested:
                    cancelled = True
                    break

                kind = evt["event"]

                # Detect phase transitions from node starts
                if kind == "on_chain_start":
                    name = evt.get("name", "")
                    metadata = evt.get("metadata", {})
                    node = metadata.get("langgraph_node", name)

                    # Transition to execute phase when execute node starts
                    if node == "execute" and self.current_phase != Phase.EXECUTE:
                        self.current_phase = Phase.EXECUTE
                        phase_indicator.set_phase(Phase.EXECUTE)
                        working.set_phase(Phase.EXECUTE)

                        if not shown_transition:
                            shown_transition = True
                            await chat_log.mount(PhaseTransition())
                            chat_log.scroll_end()

                if kind == "on_chat_model_stream":
                    chunk = evt["data"]["chunk"]
                    if hasattr(chunk, "content") and chunk.content:
                        content = chunk.content
                        # Handle Bedrock which returns list of content blocks
                        if isinstance(content, list):
                            for block in content:
                                text = None
                                if isinstance(block, dict) and "text" in block:
                                    text = block["text"]
                                elif isinstance(block, str):
                                    text = block
                                # Skip empty or thinking-indicator content
                                if text:
                                    # Remove dots, spaces, newlines, tabs to check for real content
                                    cleaned = text.replace(".", "").replace(" ", "").replace("\n", "").replace("\t", "").replace("\r", "").strip()
                                    if cleaned:  # Has actual content
                                        response_content += text
                        elif isinstance(content, str) and content.strip():
                            response_content += content

                elif kind == "on_tool_end":
                    tool_name = evt["name"]
                    tool_output = str(evt["data"]["output"])
                    await chat_log.mount(
                        ToolCall(tool_name, tool_output, self.current_phase)
                    )
                    chat_log.scroll_end()

            if cancelled:
                await chat_log.mount(Message("*Execution cancelled by user*", "assistant"))
                chat_log.scroll_end()
            elif response_content:
                self.messages.append({"role": "assistant", "content": response_content})
                await chat_log.mount(Message(response_content, "assistant"))
                chat_log.scroll_end()

        except Exception as e:
            await chat_log.mount(Message(f"Error: {e}", "assistant"))
            chat_log.scroll_end()

        # Hide working indicator and reset state
        self._is_running = False
        self._cancel_requested = False
        await working.remove()
        self.current_phase = Phase.PLAN
        phase_indicator.set_phase(Phase.PLAN)

        input_widget.disabled = False
        input_widget.focus()


def main() -> None:
    """Entry point for the application."""
    app = IDFCCoder()
    app.run()


if __name__ == "__main__":
    main()
