"""LangGraph agent for the coding assistant with plan-execute workflow."""

from enum import Enum
from typing import TypedDict, Annotated, Sequence

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import create_react_agent
from langgraph.graph.message import add_messages

from fc_coder.llm import get_llm
from fc_coder.tools import READ_ONLY_TOOLS, ALL_TOOLS


class Phase(str, Enum):
    """Workflow phase enum."""

    PLAN = "plan"
    EXECUTE = "execute"


PLAN_SYSTEM_PROMPT = """You are a helpful coding assistant in PLANNING MODE.

Your task is to explore the codebase and create a detailed implementation plan.

AVAILABLE TOOLS (read-only):
- read_file: Read file contents
- list_dir: List directory contents
- search_files: Search for files by glob pattern
- search_content: Search for text patterns inside files (regex supported)

INSTRUCTIONS:
1. Thoroughly explore the codebase using the available read-only tools
2. Understand the existing architecture, patterns, and conventions
3. Identify files that need to be created or modified
4. Consider edge cases and potential issues

When you have finished exploring, output your plan in this format:

---PLAN---
## Summary
[Brief description of what will be done]

## Files to Modify
- path/to/file.py: [what changes and why]

## Implementation Steps
1. [First step with details]
2. [Second step with details]
...
---END PLAN---

After outputting the plan, the system will automatically transition to execute mode."""


EXECUTE_SYSTEM_PROMPT = """You are a helpful coding assistant in EXECUTION MODE.

You are now executing the plan that was created in the planning phase.

AVAILABLE TOOLS (full access):
- read_file: Read file contents
- write_file: Create or overwrite files
- edit_file: Edit existing files (find and replace)
- run_shell: Execute shell commands (git, npm, python, etc.)
- list_dir: List directory contents
- search_files: Search for files by glob pattern
- search_content: Search for text patterns inside files

INSTRUCTIONS:
1. Follow the plan created in the planning phase
2. Implement changes step by step
3. Verify each change works before moving to the next
4. Report progress and any issues encountered

Be thorough and careful. Explain what you're doing at each step."""


SIMPLE_SYSTEM_PROMPT = """You are a helpful coding assistant with access to the local filesystem.
You can read, write, and edit files, run shell commands, list directories, and search for files and content.

When helping users:
- Use list_dir and search_files to explore the codebase structure
- Use search_content to find text patterns inside files (supports regex)
- Use read_file to understand existing code before making changes
- Use write_file to create new files
- Use edit_file to modify existing files (prefer this over write_file for existing files)
- Use run_shell to execute commands like git, npm, python, etc.

Always explain what you're doing and why. Be concise but thorough."""


class AgentState(TypedDict):
    """State for the plan-execute workflow."""

    messages: Annotated[Sequence[BaseMessage], add_messages]
    phase: Phase
    plan: str


def extract_plan(messages: Sequence[BaseMessage]) -> str | None:
    """Extract the plan from agent messages if present."""
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            if "---PLAN---" in content and "---END PLAN---" in content:
                start = content.find("---PLAN---") + len("---PLAN---")
                end = content.find("---END PLAN---")
                return content[start:end].strip()
    return None


def create_plan_agent():
    """Create the planning phase agent with read-only tools."""
    llm = get_llm()
    return create_react_agent(llm, READ_ONLY_TOOLS, prompt=PLAN_SYSTEM_PROMPT)


def create_execute_agent():
    """Create the execution phase agent with all tools."""
    llm = get_llm()
    return create_react_agent(llm, ALL_TOOLS, prompt=EXECUTE_SYSTEM_PROMPT)


def create_plan_execute_agent():
    """Create the two-phase plan-execute agent workflow.

    Returns a compiled LangGraph that:
    1. Runs planning phase with read-only tools
    2. Automatically detects plan completion
    3. Transitions to execution phase with full tools
    """
    plan_agent = create_plan_agent()
    execute_agent = create_execute_agent()

    async def run_plan_phase(state: AgentState) -> dict:
        """Run the planning agent."""
        result = await plan_agent.ainvoke(
            {"messages": state["messages"]},
            config={"recursion_limit": 50},
        )
        plan = extract_plan(result["messages"])
        return {
            "messages": result["messages"],
            "phase": Phase.PLAN,
            "plan": plan or "",
        }

    async def run_execute_phase(state: AgentState) -> dict:
        """Run the execution agent with the plan context."""
        # Add a transition message with the plan
        transition_msg = HumanMessage(
            content=f"The planning phase is complete. Here is the plan to execute:\n\n{state['plan']}\n\nPlease proceed with the implementation."
        )
        messages = list(state["messages"]) + [transition_msg]

        result = await execute_agent.ainvoke(
            {"messages": messages},
            config={"recursion_limit": 50},
        )
        return {
            "messages": result["messages"],
            "phase": Phase.EXECUTE,
            "plan": state["plan"],
        }

    def should_execute(state: AgentState) -> str:
        """Determine if we should transition to execute phase."""
        if state.get("plan"):
            return "execute"
        return END

    # Build the workflow graph
    workflow = StateGraph(AgentState)

    workflow.add_node("plan", run_plan_phase)
    workflow.add_node("execute", run_execute_phase)

    workflow.set_entry_point("plan")
    workflow.add_conditional_edges("plan", should_execute, {"execute": "execute", END: END})
    workflow.add_edge("execute", END)

    return workflow.compile()


def create_agent():
    """Create the plan-execute workflow agent.

    This is the main entry point that returns the two-phase agent.
    For the old single-phase behavior, use create_simple_agent().
    """
    return create_plan_execute_agent()


def create_simple_agent():
    """Create a simple single-phase agent with all tools.

    This is the original behavior before plan-execute was added.
    """
    llm = get_llm()
    return create_react_agent(llm, ALL_TOOLS, prompt=SIMPLE_SYSTEM_PROMPT)
