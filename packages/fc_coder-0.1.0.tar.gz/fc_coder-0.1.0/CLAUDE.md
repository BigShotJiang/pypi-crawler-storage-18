# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

fc-coder is a command-line coding agent built with:
- **Textual** - Terminal UI framework
- **LangGraph** - Agent orchestration framework (ReAct pattern with plan-execute workflow)
- **OpenAI or AWS Bedrock** - Language model backend

## Development Commands

```bash
# Install dependencies (OpenAI only)
uv sync

# Install with Bedrock support
uv sync --extra bedrock

# Run the application
uv run python main.py
# or via entry point
uv run fc-coder

# Verify imports
uv run python -c "from fc_coder.agent import create_agent"
```

## Environment Variables

### Provider Selection
```bash
LLM_PROVIDER=openai                   # or "bedrock" (default: openai)
```

### OpenAI Configuration
```bash
LLM_PROVIDER=openai
OPENAI_API_KEY=your-key-here          # Required
OPENAI_API_BASE=https://...           # Optional, for custom endpoints
MODEL_NAME=gpt-4                      # Optional, defaults to gpt-4
```

### AWS Bedrock Configuration
```bash
LLM_PROVIDER=bedrock
AWS_ACCESS_KEY_ID=...                 # Or use AWS profile/IAM role
AWS_SECRET_ACCESS_KEY=...             # Or use AWS profile/IAM role
AWS_REGION=us-east-1                  # Optional, defaults to us-east-1
MODEL_NAME=anthropic.claude-3-5-sonnet-20241022-v2:0  # Optional
```

## Architecture

```
src/fc_coder/
├── app.py          # Textual UI (IDFCCoder, PhaseIndicator, Message, ToolCall)
├── agent.py        # LangGraph plan-execute workflow with StateGraph
├── llm.py          # LLM client factory (OpenAI + Bedrock)
└── tools/
    ├── __init__.py # Tool categorization (READ_ONLY_TOOLS, WRITE_TOOLS)
    ├── file_ops.py # read_file, write_file, edit_file
    ├── shell.py    # run_shell
    └── search.py   # list_dir, search_files, search_content
```

**Workflow:** User input → Plan phase (read-only) → Execute phase (full tools) → Response

## Requirements

- Python 3.12+
