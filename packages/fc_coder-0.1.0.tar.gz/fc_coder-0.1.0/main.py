"""fc-coder: Command line coding agent."""

from fc_coder.app import main

if __name__ == "__main__":
    main()
