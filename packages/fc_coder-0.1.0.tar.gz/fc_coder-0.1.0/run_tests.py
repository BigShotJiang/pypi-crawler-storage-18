#!/usr/bin/env python3
"""
Test runner script for fc-coder.

This script sets up the Python path and runs pytest to execute the test suite.
"""

import os
import sys
from pathlib import Path

# Add src directory to Python path so we can import fc_coder modules
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

# Add tests directory to Python path
tests_path = Path(__file__).parent / "tests"
sys.path.insert(0, str(tests_path))

if __name__ == "__main__":
    # Run pytest
    try:
        import pytest
    except ImportError:
        print("Error: pytest not found. Please install it with:")
        print("  uv sync --extra dev")
        sys.exit(1)
    
    # Run pytest with the tests directory
    sys.exit(pytest.main(["-v", str(tests_path)]))