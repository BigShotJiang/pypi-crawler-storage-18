"""Pytest configuration and fixtures."""

import sys
from pathlib import Path

# Add src directory to Python path so we can import fc_coder modules
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

# This file is used to configure pytest and define fixtures
# It's automatically discovered by pytest