"""Tests for the LLM module."""

import os
from unittest.mock import patch, MagicMock

import pytest

from fc_coder.llm import get_bedrock_llm, get_model_info, get_llm, get_openai_llm


class TestGetBedrockLLM:
    """Tests for the get_bedrock_llm function."""

    def test_get_bedrock_llm_default_params(self, mocker):
        """Test get_bedrock_llm with default parameters."""
        # Clear any existing environment variables that might interfere
        mocker.patch.dict(os.environ, {}, clear=True)
        
        # Mock the import of ChatBedrockConverse from langchain_aws
        mock_bedrock = MagicMock()
        mock_bedrock_class = MagicMock(return_value=mock_bedrock)
        mocker.patch('fc_coder.llm.ChatBedrockConverse', mock_bedrock_class)
        
        # Call the function
        result = get_bedrock_llm()
        
        # Assertions
        assert result == mock_bedrock
        mock_bedrock_class.assert_called_once_with(
            model_id="anthropic.claude-3-5-sonnet-20241022-v2:0",
            region_name="us-east-1"
        )

    def test_get_bedrock_llm_custom_params(self, mocker):
        """Test get_bedrock_llm with custom parameters from environment variables."""
        # Set custom environment variables
        mocker.patch.dict(os.environ, {
            'MODEL_NAME': 'anthropic.claude-3-5-haiku-20241022-v1:0',
            'AWS_REGION': 'us-west-2'
        }, clear=True)
        
        # Mock the import of ChatBedrockConverse from langchain_aws
        mock_bedrock = MagicMock()
        mock_bedrock_class = MagicMock(return_value=mock_bedrock)
        mocker.patch('fc_coder.llm.ChatBedrockConverse', mock_bedrock_class)
        
        # Call the function
        result = get_bedrock_llm()
        
        # Assertions
        assert result == mock_bedrock
        mock_bedrock_class.assert_called_once_with(
            model_id="anthropic.claude-3-5-haiku-20241022-v1:0",
            region_name="us-west-2"
        )

    def test_get_bedrock_llm_import_error(self, mocker):
        """Test get_bedrock_llm handles ImportError correctly."""
        # Clear environment and set up clean state
        mocker.patch.dict(os.environ, {}, clear=True)
        
        # Mock the import statement to raise ImportError when importing langchain_aws
        def mock_import_error(name, *args, **kwargs):
            if name.endswith('ChatBedrockConverse'):
                raise NameError("name 'ChatBedrockConverse' is not defined")
            # For other imports, we need to allow them to work normally
            import importlib
            return importlib.import_module(name)
        
        # Instead of mocking __import__, let's mock the specific import inside the function
        mocker.patch('fc_coder.llm.ChatBedrockConverse', 
                    side_effect=ImportError("langchain-aws not installed"))
        
        # Check that the correct exception is raised
        with pytest.raises(ImportError) as exc_info:
            get_bedrock_llm()
        
        assert "langchain-aws is required for Bedrock support" in str(exc_info.value)
        assert "pip install fc-coder[bedrock]" in str(exc_info.value)


class TestGetModelInfo:
    """Tests for the get_model_info function."""
    
    def test_get_model_info_bedrock_default(self, mocker):
        """Test get_model_info with Bedrock provider and default values."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'bedrock'
        }, clear=True)
        
        # Call the function
        result = get_model_info()
        
        # Assertions
        assert result == {
            "provider": "AWS Bedrock",
            "model": "anthropic.claude-3-5-sonnet-20241022-v2:0",
            "region": "us-east-1",
        }

    def test_get_model_info_bedrock_custom(self, mocker):
        """Test get_model_info with Bedrock provider and custom values."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'bedrock',
            'MODEL_NAME': 'custom-model-id',
            'AWS_REGION': 'eu-west-1'
        }, clear=True)
        
        # Call the function
        result = get_model_info()
        
        # Assertions
        assert result == {
            "provider": "AWS Bedrock",
            "model": "custom-model-id",
            "region": "eu-west-1",
        }
        
    def test_get_model_info_openai_default(self, mocker):
        """Test get_model_info with OpenAI provider and default values."""
        # LLM_PROVIDER defaults to openai if not set
        mocker.patch.dict(os.environ, {}, clear=True)
        
        # Call the function
        result = get_model_info()
        
        # Assertions
        assert result == {
            "provider": "OpenAI",
            "model": "gpt-4",
        }
        
    def test_get_model_info_openai_custom(self, mocker):
        """Test get_model_info with OpenAI provider and custom values."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'openai',
            'MODEL_NAME': 'gpt-4-turbo',
        }, clear=True)
        
        # Call the function
        result = get_model_info()
        
        # Assertions
        assert result == {
            "provider": "OpenAI",
            "model": "gpt-4-turbo",
        }


class TestGetOpenAILLM:
    """Tests for the get_openai_llm function."""
    
    def test_get_openai_llm_default_params(self, mocker):
        """Test get_openai_llm with default parameters."""
        # Clear any existing environment variables that might interfere
        mocker.patch.dict(os.environ, {}, clear=True)
        
        # Mock the ChatOpenAI class
        mock_openai = MagicMock()
        mock_openai_class = MagicMock(return_value=mock_openai)
        mocker.patch('fc_coder.llm.ChatOpenAI', mock_openai_class)
        
        # Call the function
        result = get_openai_llm()
        
        # Assertions
        assert result == mock_openai
        mock_openai_class.assert_called_once_with(
            model="gpt-4",
            base_url=None,
            api_key=None
        )
        
    def test_get_openai_llm_custom_params(self, mocker):
        """Test get_openai_llm with custom parameters from environment variables."""
        # Set custom environment variables
        mocker.patch.dict(os.environ, {
            'MODEL_NAME': 'gpt-4-turbo',
            'OPENAI_API_BASE': 'https://custom.openai.endpoint/v1',
            'OPENAI_API_KEY': 'sk-custom-key'
        }, clear=True)
        
        # Mock the ChatOpenAI class
        mock_openai = MagicMock()
        mock_openai_class = MagicMock(return_value=mock_openai)
        mocker.patch('fc_coder.llm.ChatOpenAI', mock_openai_class)
        
        # Call the function
        result = get_openai_llm()
        
        # Assertions
        assert result == mock_openai
        mock_openai_class.assert_called_once_with(
            model="gpt-4-turbo",
            base_url="https://custom.openai.endpoint/v1",
            api_key="sk-custom-key"
        )


class TestGetLLM:
    """Tests for the get_llm function that selects provider based on LLM_PROVIDER."""
    
    def test_get_llm_bedrock_provider(self, mocker):
        """Test get_llm with bedrock provider."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'bedrock'
        }, clear=True)
        
        # Mock the bedrock LLM
        mock_bedrock = MagicMock()
        mocker.patch('fc_coder.llm.get_bedrock_llm', return_value=mock_bedrock)
        
        # Call the function
        result = get_llm()
        
        # Assertions
        assert result == mock_bedrock
        from fc_coder.llm import get_bedrock_llm
        get_bedrock_llm.assert_called_once()
        
    def test_get_llm_openai_provider(self, mocker):
        """Test get_llm with openai provider."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'openai'
        }, clear=True)
        
        # Mock the openai LLM
        mock_openai = MagicMock()
        mocker.patch('fc_coder.llm.get_openai_llm', return_value=mock_openai)
        
        # Call the function
        result = get_llm()
        
        # Assertions
        assert result == mock_openai
        from fc_coder.llm import get_openai_llm
        get_openai_llm.assert_called_once()
        
    def test_get_llm_invalid_provider(self, mocker):
        """Test get_llm with invalid provider raises ValueError."""
        # Set environment variables
        mocker.patch.dict(os.environ, {
            'LLM_PROVIDER': 'invalid-provider'
        }, clear=True)
        
        # Check that the correct exception is raised
        with pytest.raises(ValueError) as exc_info:
            get_llm()
            
        assert "Unknown LLM_PROVIDER: invalid-provider" in str(exc_info.value)