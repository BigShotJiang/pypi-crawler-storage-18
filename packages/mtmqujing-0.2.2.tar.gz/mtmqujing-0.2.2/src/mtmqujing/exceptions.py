class QujingInvokeError(Exception):
    pass
