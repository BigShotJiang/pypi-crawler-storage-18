"""
ARIA Tailscale Mesh v1.0.0

HTTP-based mesh network over Tailscale VPN for PC ↔ Phone communication.

Usage:
  # On PC (horus)
  aria tailscale serve --name horus
  
  # On Phone (Termux)
  aria tailscale serve --name phone
  aria tailscale connect 100.109.42.106  # PC's Tailscale IP
"""

import asyncio
import json
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from urllib.request import urlopen, Request
from urllib.error import URLError
import os

# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_PORT = 8765
MESH_DIR = Path.home() / ".aria" / "tailscale-mesh"
HEARTBEAT_INTERVAL = 10.0
MESSAGE_TIMEOUT = 60.0


# =============================================================================
# DATA STRUCTURES
# =============================================================================

class MessageType(str, Enum):
    """Message types for mesh communication"""
    HELLO = "hello"
    HEARTBEAT = "heartbeat"
    MESSAGE = "message"
    COMMAND = "command"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    FILE_SYNC = "file_sync"
    DISCONNECT = "disconnect"


@dataclass
class MeshNode:
    """A node in the Tailscale mesh"""
    node_id: str
    name: str
    ip: str
    port: int = DEFAULT_PORT
    last_seen: float = 0.0
    is_local: bool = False
    tailscale_ip: str = ""
    device_type: str = "unknown"  # pc, phone, server
    capabilities: List[str] = field(default_factory=list)
    
    @property
    def is_alive(self) -> bool:
        return time.time() - self.last_seen < HEARTBEAT_INTERVAL * 3
    
    @property
    def endpoint(self) -> str:
        return f"http://{self.tailscale_ip or self.ip}:{self.port}"
    
    def to_dict(self) -> Dict:
        return {
            "node_id": self.node_id,
            "name": self.name,
            "ip": self.ip,
            "port": self.port,
            "tailscale_ip": self.tailscale_ip,
            "device_type": self.device_type,
            "capabilities": self.capabilities,
            "last_seen": self.last_seen,
        }


@dataclass
class MeshMessage:
    """A message in the mesh network"""
    msg_id: str
    msg_type: MessageType
    source: str
    target: str  # node_id or "broadcast"
    payload: Any
    timestamp: float = field(default_factory=time.time)
    ttl: int = 10  # max hops
    
    def to_dict(self) -> Dict:
        return {
            "msg_id": self.msg_id,
            "msg_type": self.msg_type.value if isinstance(self.msg_type, MessageType) else self.msg_type,
            "source": self.source,
            "target": self.target,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "MeshMessage":
        return cls(
            msg_id=data["msg_id"],
            msg_type=MessageType(data["msg_type"]) if isinstance(data["msg_type"], str) else data["msg_type"],
            source=data["source"],
            target=data["target"],
            payload=data["payload"],
            timestamp=data.get("timestamp", time.time()),
            ttl=data.get("ttl", 10),
        )


# =============================================================================
# HTTP MESSAGE HANDLER
# =============================================================================

class MeshRequestHandler(BaseHTTPRequestHandler):
    """HTTP handler for mesh messages"""
    
    mesh: "TailscaleMesh" = None  # Set by server
    
    def log_message(self, format, *args):
        """Suppress default logging"""
        pass
    
    def _send_cors_headers(self):
        """Send CORS headers to allow cross-origin requests"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()
    
    def do_GET(self):
        """Handle GET requests - status and discovery"""
        if self.path == "/":
            self._send_json({"status": "ok", "node": self.mesh.local_node.to_dict()})
        elif self.path == "/ui":
            self._send_ui()
        elif self.path == "/nodes":
            self._send_json({"nodes": [n.to_dict() for n in self.mesh.nodes.values()]})
        elif self.path == "/status":
            self._send_json({
                "node": self.mesh.local_node.to_dict(),
                "peers": len(self.mesh.nodes) - 1,
                "messages_sent": self.mesh.stats.get("sent", 0),
                "messages_received": self.mesh.stats.get("received", 0),
            })
        else:
            self.send_error(404)
    
    def _send_ui(self):
        """Serve the mobile web UI"""
        html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>ARIA Mesh</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff; min-height: 100vh; padding: 15px;
        }
        .container { max-width: 500px; margin: 0 auto; }
        h1 { text-align: center; font-size: 22px; margin-bottom: 15px;
            background: linear-gradient(90deg, #00d4ff, #7b2cbf);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .card { background: rgba(255,255,255,0.1); border-radius: 14px;
            padding: 15px; margin-bottom: 12px; backdrop-filter: blur(10px); }
        .card h3 { font-size: 14px; margin-bottom: 10px; opacity: 0.8; }
        .dot { display: inline-block; width: 10px; height: 10px;
            border-radius: 50%; margin-right: 6px; }
        .online { background: #00ff88; box-shadow: 0 0 8px #00ff88; }
        .offline { background: #ff4757; }
        input, button, textarea { width: 100%; padding: 12px;
            border: none; border-radius: 10px; font-size: 15px; margin-bottom: 8px; }
        input, textarea { background: rgba(255,255,255,0.15); color: #fff; }
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.5); }
        button { background: linear-gradient(90deg, #00d4ff, #7b2cbf);
            color: #fff; font-weight: 600; cursor: pointer; }
        button:active { transform: scale(0.98); }
        .btn2 { background: rgba(255,255,255,0.2); }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .node { display: flex; justify-content: space-between;
            padding: 10px; background: rgba(255,255,255,0.08);
            border-radius: 8px; margin-bottom: 6px; font-size: 13px; }
        .log { max-height: 150px; overflow-y: auto; background: rgba(0,0,0,0.3);
            border-radius: 10px; padding: 10px; font-family: monospace; font-size: 12px; }
        .msg { margin-bottom: 6px; padding: 6px; border-radius: 5px; }
        .sent { background: rgba(0,212,255,0.2); text-align: right; }
        .rcv { background: rgba(123,44,191,0.2); }
        .ts { font-size: 9px; opacity: 0.5; }
    </style>
</head>
<body>
<div class="container">
    <h1>🌐 ARIA Mesh</h1>
    <div class="card">
        <h3><span class="dot" id="dot"></span>Status</h3>
        <div id="status">Connecting...</div>
    </div>
    <div class="card">
        <h3>📡 Nodes</h3>
        <div id="nodes"><div style="opacity:0.5">Loading...</div></div>
        <button class="btn2" onclick="loadNodes()">Refresh</button>
    </div>
    <div class="card">
        <h3>💬 Send</h3>
        <textarea id="msg" rows="2" placeholder="Message or command..."></textarea>
        <div class="grid">
            <button onclick="send('message')">Message</button>
            <button onclick="send('command')">Command</button>
        </div>
    </div>
    <div class="card">
        <h3>⚡ Quick</h3>
        <div class="grid">
            <button class="btn2" onclick="quick('aria status')">Status</button>
            <button class="btn2" onclick="quick('hostname')">Hostname</button>
            <button class="btn2" onclick="quick('dir')">Files</button>
            <button class="btn2" onclick="quick('date')">Date</button>
        </div>
    </div>
    <div class="card">
        <h3>📨 Log</h3>
        <div class="log" id="log"><div style="opacity:0.5">Ready</div></div>
    </div>
</div>
<script>
const BASE = location.origin;
const nodeId = 'phone-' + Math.random().toString(36).substr(2,6);
let connected = false;

async function init() {
    try {
        const r = await fetch(BASE + '/connect', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                node_id: nodeId, name: 'Phone', ip: '0.0.0.0', port: 0,
                tailscale_ip: '', device_type: 'phone', capabilities: ['message']
            })
        });
        const d = await r.json();
        if (d.status === 'connected') {
            connected = true;
            document.getElementById('dot').className = 'dot online';
            document.getElementById('status').textContent = 'Connected to ' + d.node.name;
            log('✓ Connected to ' + d.node.name);
            loadNodes();
        }
    } catch(e) {
        document.getElementById('dot').className = 'dot offline';
        document.getElementById('status').textContent = 'Failed: ' + e.message;
    }
}

async function loadNodes() {
    try {
        const r = await fetch(BASE + '/nodes');
        const d = await r.json();
        document.getElementById('nodes').innerHTML = d.nodes.map(n =>
            '<div class="node"><span>' + n.name + '</span><span style="opacity:0.6">' + 
            (n.tailscale_ip || n.ip) + '</span></div>'
        ).join('');
    } catch(e) {}
}

async function send(type) {
    const txt = document.getElementById('msg').value;
    if (!txt) return;
    try {
        await fetch(BASE + '/message', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                msg_id: Math.random().toString(36).substr(2,8),
                msg_type: type, source: nodeId, target: 'horus',
                payload: type === 'command' ? {command: txt} : {text: txt},
                timestamp: Date.now()/1000, ttl: 10
            })
        });
        log('➤ ' + txt, 'sent');
        document.getElementById('msg').value = '';
    } catch(e) { log('✗ ' + e.message); }
}

function quick(cmd) {
    document.getElementById('msg').value = cmd;
    send('command');
}

function log(m, cls='') {
    const el = document.getElementById('log');
    if (el.querySelector('div[style]')) el.innerHTML = '';
    el.innerHTML += '<div class="msg ' + cls + '">' + m + 
        '<div class="ts">' + new Date().toLocaleTimeString() + '</div></div>';
    el.scrollTop = el.scrollHeight;
}

init();
setInterval(loadNodes, 10000);
</script>
</body>
</html>'''
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def do_POST(self):
        """Handle POST requests - receive messages"""
        if self.path == "/message":
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                msg = MeshMessage.from_dict(data)
                self.mesh._handle_message(msg)
                self._send_json({"status": "ok", "msg_id": msg.msg_id})
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        elif self.path == "/connect":
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                node = MeshNode(
                    node_id=data["node_id"],
                    name=data["name"],
                    ip=data.get("ip", self.client_address[0]),
                    port=data.get("port", DEFAULT_PORT),
                    tailscale_ip=data.get("tailscale_ip", ""),
                    device_type=data.get("device_type", "unknown"),
                    capabilities=data.get("capabilities", []),
                    last_seen=time.time(),
                )
                self.mesh.nodes[node.node_id] = node
                self._send_json({"status": "connected", "node": self.mesh.local_node.to_dict()})
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        else:
            self.send_error(404)
    
    def _send_json(self, data: Dict, status: int = 200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self._send_cors_headers()  # Allow cross-origin requests from iPhone
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))


# =============================================================================
# TAILSCALE MESH
# =============================================================================

class TailscaleMesh:
    """
    Tailscale Mesh Network
    
    HTTP-based mesh over Tailscale VPN for PC ↔ Phone communication.
    """
    
    def __init__(
        self,
        name: str = None,
        port: int = DEFAULT_PORT,
        device_type: str = "pc",
    ):
        self.node_id = str(uuid.uuid4())[:8]
        self.name = name or socket.gethostname()
        self.port = port
        self.device_type = device_type
        
        # Get IPs
        self.local_ip = self._get_local_ip()
        self.tailscale_ip = self._get_tailscale_ip()
        
        # Local node
        self.local_node = MeshNode(
            node_id=self.node_id,
            name=self.name,
            ip=self.local_ip,
            port=self.port,
            tailscale_ip=self.tailscale_ip,
            device_type=self.device_type,
            is_local=True,
            last_seen=time.time(),
            capabilities=["message", "command", "file_sync", "q-symbolic"],
        )
        
        # Nodes registry
        self.nodes: Dict[str, MeshNode] = {self.node_id: self.local_node}
        
        # Message handlers
        self.handlers: Dict[MessageType, List[Callable]] = {mt: [] for mt in MessageType}
        
        # Stats
        self.stats = {"sent": 0, "received": 0, "errors": 0}
        
        # Server
        self.server: Optional[HTTPServer] = None
        self._running = False
        self._server_thread: Optional[threading.Thread] = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        
        # Storage
        MESH_DIR.mkdir(parents=True, exist_ok=True)
        self._save_node_info()
    
    def _get_local_ip(self) -> str:
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def _get_tailscale_ip(self) -> str:
        """Get Tailscale IP if available"""
        try:
            import subprocess
            # Try to get Tailscale IP from interface
            if os.name == 'nt':
                # Windows - try multiple paths
                tailscale_paths = [
                    "tailscale",
                    r"C:\Program Files\Tailscale\tailscale.exe",
                    r"C:\Program Files (x86)\Tailscale\tailscale.exe",
                ]
                for ts_path in tailscale_paths:
                    try:
                        result = subprocess.run(
                            [ts_path, "ip", "-4"],
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0 and result.stdout.strip():
                            return result.stdout.strip()
                    except:
                        continue
            else:
                # Linux/Android - check for Tailscale interface
                result = subprocess.run(
                    ["ip", "addr", "show", "tailscale0"],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if 'inet ' in line and '100.' in line:
                            return line.split()[1].split('/')[0]
                
                # Try tailscale CLI
                try:
                    result = subprocess.run(
                        ["tailscale", "ip", "-4"],
                        capture_output=True, text=True, timeout=5
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except:
                    pass
        except:
            pass
        return ""
    
    def _save_node_info(self):
        """Save local node info to file"""
        info_file = MESH_DIR / "local_node.json"
        with open(info_file, 'w') as f:
            json.dump(self.local_node.to_dict(), f, indent=2)
    
    def start(self):
        """Start the mesh server"""
        if self._running:
            return
        
        # Create HTTP server
        MeshRequestHandler.mesh = self
        self.server = HTTPServer(('0.0.0.0', self.port), MeshRequestHandler)
        self._running = True
        
        # Start server thread
        self._server_thread = threading.Thread(target=self._run_server, daemon=True)
        self._server_thread.start()
        
        # Start heartbeat thread
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()
        
        return self
    
    def _run_server(self):
        """Run the HTTP server"""
        while self._running:
            self.server.handle_request()
    
    def _heartbeat_loop(self):
        """Send heartbeats to known peers"""
        while self._running:
            time.sleep(HEARTBEAT_INTERVAL)
            for node in list(self.nodes.values()):
                if node.node_id != self.node_id:
                    try:
                        self._send_to_node(node, MeshMessage(
                            msg_id=str(uuid.uuid4())[:8],
                            msg_type=MessageType.HEARTBEAT,
                            source=self.node_id,
                            target=node.node_id,
                            payload={"timestamp": time.time()},
                        ))
                    except:
                        pass
    
    def stop(self):
        """Stop the mesh server"""
        self._running = False
        if self.server:
            self.server.shutdown()
    
    def connect(self, target_ip: str, target_port: int = DEFAULT_PORT) -> Optional[MeshNode]:
        """Connect to a peer node"""
        try:
            # Handle case where port is already in the IP string
            if ":" in target_ip:
                parts = target_ip.rsplit(":", 1)
                target_ip = parts[0]
                try:
                    target_port = int(parts[1])
                except ValueError:
                    pass  # Keep default port
            
            # Send connection request
            url = f"http://{target_ip}:{target_port}/connect"
            data = json.dumps(self.local_node.to_dict()).encode('utf-8')
            req = Request(url, data=data, headers={'Content-Type': 'application/json'})
            
            with urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get("status") == "connected":
                    node_data = result.get("node", {})
                    node = MeshNode(
                        node_id=node_data["node_id"],
                        name=node_data["name"],
                        ip=node_data.get("ip", target_ip),
                        port=node_data.get("port", target_port),
                        tailscale_ip=node_data.get("tailscale_ip", target_ip),
                        device_type=node_data.get("device_type", "unknown"),
                        capabilities=node_data.get("capabilities", []),
                        last_seen=time.time(),
                    )
                    self.nodes[node.node_id] = node
                    print(f"✅ Connected to {node.name} ({node.tailscale_ip or node.ip})")
                    return node
        except Exception as e:
            print(f"❌ Failed to connect to {target_ip}:{target_port}: {e}")
        return None
    
    def send(self, target: str, payload: Any, msg_type: MessageType = MessageType.MESSAGE) -> bool:
        """Send a message to a target node"""
        # Find target node
        target_node = None
        for node in self.nodes.values():
            if node.node_id == target or node.name.lower() == target.lower():
                target_node = node
                break
        
        if not target_node:
            print(f"❌ Target node not found: {target}")
            return False
        
        msg = MeshMessage(
            msg_id=str(uuid.uuid4())[:8],
            msg_type=msg_type,
            source=self.node_id,
            target=target_node.node_id,
            payload=payload,
        )
        
        return self._send_to_node(target_node, msg)
    
    def broadcast(self, payload: Any, msg_type: MessageType = MessageType.BROADCAST) -> int:
        """Broadcast a message to all nodes"""
        count = 0
        for node in self.nodes.values():
            if node.node_id != self.node_id:
                msg = MeshMessage(
                    msg_id=str(uuid.uuid4())[:8],
                    msg_type=msg_type,
                    source=self.node_id,
                    target="broadcast",
                    payload=payload,
                )
                if self._send_to_node(node, msg):
                    count += 1
        return count
    
    def _send_to_node(self, node: MeshNode, msg: MeshMessage) -> bool:
        """Send a message to a specific node"""
        try:
            url = f"{node.endpoint}/message"
            data = json.dumps(msg.to_dict()).encode('utf-8')
            req = Request(url, data=data, headers={'Content-Type': 'application/json'})
            
            with urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get("status") == "ok":
                    self.stats["sent"] += 1
                    return True
        except Exception as e:
            self.stats["errors"] += 1
        return False
    
    def _handle_message(self, msg: MeshMessage):
        """Handle an incoming message"""
        self.stats["received"] += 1
        
        # Update sender's last_seen
        if msg.source in self.nodes:
            self.nodes[msg.source].last_seen = time.time()
        
        # Handle by type
        if msg.msg_type == MessageType.HEARTBEAT:
            pass  # Just update last_seen
        elif msg.msg_type == MessageType.MESSAGE:
            self._on_message(msg)
        elif msg.msg_type == MessageType.COMMAND:
            self._on_command(msg)
        
        # Call registered handlers
        for handler in self.handlers.get(msg.msg_type, []):
            try:
                handler(msg)
            except Exception as e:
                print(f"Handler error: {e}")
    
    def _on_message(self, msg: MeshMessage):
        """Handle a data message"""
        source = self.nodes.get(msg.source)
        source_name = source.name if source else msg.source
        print(f"\n📨 Message from {source_name}: {msg.payload}")
    
    def _on_command(self, msg: MeshMessage):
        """Handle a command message"""
        source = self.nodes.get(msg.source)
        source_name = source.name if source else msg.source
        print(f"\n⚡ Command from {source_name}: {msg.payload}")
        
        # Execute command and send response
        cmd = msg.payload.get("command", "")
        if cmd:
            try:
                import subprocess
                result = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True, timeout=30
                )
                response = {
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "returncode": result.returncode,
                }
            except Exception as e:
                response = {"error": str(e)}
            
            # Send response back
            if source:
                self.send(source.node_id, response, MessageType.RESPONSE)
    
    def on(self, msg_type: MessageType, handler: Callable):
        """Register a message handler"""
        self.handlers[msg_type].append(handler)
    
    def status(self) -> Dict:
        """Get mesh status"""
        return {
            "local": self.local_node.to_dict(),
            "peers": [n.to_dict() for n in self.nodes.values() if n.node_id != self.node_id],
            "stats": self.stats,
        }
    
    def list_nodes(self) -> List[MeshNode]:
        """List all known nodes"""
        return list(self.nodes.values())


# =============================================================================
# CLI FUNCTIONS
# =============================================================================

def create_mesh(name: str = None, port: int = DEFAULT_PORT, device_type: str = "pc") -> TailscaleMesh:
    """Create and start a Tailscale mesh node"""
    mesh = TailscaleMesh(name=name, port=port, device_type=device_type)
    mesh.start()
    return mesh


def demo():
    """Run a demo of the Tailscale mesh"""
    print("=" * 60)
    print("🌐 TAILSCALE MESH NETWORK DEMO")
    print("=" * 60)
    
    mesh = create_mesh(name="demo-node")
    
    print(f"\n📡 Local Node:")
    print(f"   ID: {mesh.node_id}")
    print(f"   Name: {mesh.name}")
    print(f"   Local IP: {mesh.local_ip}")
    print(f"   Tailscale IP: {mesh.tailscale_ip or 'Not connected'}")
    print(f"   Port: {mesh.port}")
    print(f"   Endpoint: http://{mesh.tailscale_ip or mesh.local_ip}:{mesh.port}")
    
    print(f"\n✅ Mesh server running!")
    print(f"\nConnect from another device:")
    print(f"   aria tailscale connect {mesh.tailscale_ip or mesh.local_ip}")
    
    return mesh


if __name__ == "__main__":
    demo()
    input("\nPress Enter to stop...")
