"""
ARIA CLI v1.0.0 - Natural Language Quantum AI Command Line Interface

Full Q0-Q38 Cognitive Architecture with LLM Integration + Q-Mesh Distributed Compute

The Q-System is a 39-layer recursive cognitive architecture:
- Q0-Q9: Foundation layers (perception, memory, attention)
- Q10-Q19: Reasoning layers (logic, inference, hypothesis)
- Q20-Q29: Action layers (planning, execution, feedback)
- Q30-Q38: Meta-cognitive layers (self-reflection, adaptation, transcendence)

New in v1.0.0:
- Q-Mesh distributed terminal communication
- Chained pipeline parallel compute
- Multi-platform binary distribution
- Docker containerization
"""

__version__ = "1.0.2"
__author__ = "Universal Crown Prime"
__description__ = "ARIA CLI - Natural Language Quantum AI with Q0-Q38 System & F1/M1 Cycles"

from .q_system import (
    QSystem,
    QLayer,
    QOperator,
    QCommand,
)

from .nlp_engine import (
    NLPEngine,
    Intent,
    Entity,
    ParsedInput,
)

from .llm_connector import (
    LLMConnector,
    LLMProvider,
    LLMConfig,
    LLMResponse,
)

from .aria_connector import (
    AriaConnector,
    SyncMode,
    AriaPlugin,
    PluginManager,
)

from .q38_connector import (
    Q38Connector,
    Q38Config,
    Q38Response,
)

from .knowledge_connector import (
    KnowledgeConnector,
    KnowledgeResult,
    ARIAConnector,  # Legacy alias
)

from .auth import (
    AuthManager,
    AuthProvider,
    AuthStatus,
    User,
    Session,
    CredentialStore,
    get_auth,
)

from .ssh_router import (
    SSHRouter,
    SSHHost,
    SSHConnection,
    SSHAuthMethod,
    ConnectionStatus,
    CommandResult,
    get_router,
)

from .aria_space import (
    AriaSpace,
    Workspace,
    SyncFile,
    SyncResult,
    SyncDirection,
    SyncStrategy,
    FileStatus,
    get_space,
)

from .termux_setup import (
    TermuxSetup,
    TermuxDevice,
    get_termux_setup,
)

from .agents import (
    AriaAgent,
    AgentRegistry,
    AgentSwarm,
    AgentMessage,
    MessageType,
    MessagePriority,
    AgentCapability,
    AgentState,
    AgentStatus,
    TaskAgent,
    ReasoningAgent,
    CoordinatorAgent,
    GeneratorAgent,
    create_agent,
    get_registry,
)

from .agent_channels import (
    ChannelManager,
    DirectChannel,
    BroadcastChannel,
    StreamChannel,
    PersistentChannel,
    ChannelType,
    ChannelState,
    get_channel_manager,
)

from .file_manager import (
    AriaFileManager,
    FileManager,
    FileBrowser,
    FileOperations,
    FileTransfer,
    FileRouter,
    Environment,
    FileEntry,
    OperationResult,
    Platform,
    FileType,
    FileLocation,
    OperationType,
    EnvironmentDetector,
    get_file_manager,
    get_manager,
)

from .infinite_storage import (
    InfiniteStorage,
    StorageConfig,
    StorageResult,
    StorageBackend,
    CompressionLevel,
    LRUCache,
    PersistentCache,
    get_storage,
)

from .github_automation import (
    GitHubCLI,
    GitHubAutomation,
    GitHubResult,
    F1CycleEngine,
    F1CycleResult,
    M1MasterOrchestrator,
    M1MasterCycle,
    F1Phase,
    CycleStatus,
    SystemType,
    get_github_cli,
    get_github_automation,
    quick_status,
)

from .terminal_f1_mesh import (
    F1TerminalMesh,
    TerminalNode,
    TerminalIdentity,
    TerminalSnapshot,
    TerminalState,
    MeshTopology,
    MeshConnection,
    F1Improvement,
    ImprovementType,
    F1TerminalAnalyzer,
    F1TerminalImprover,
    F1TerminalValidator,
    get_mesh,
    create_terminal,
    run_f1_between,
)

# CLI imports (may fail if typer/rich not installed)
try:
    from .cli import (
        AriaCLI,
        main,
    )
except ImportError:
    AriaCLI = None
    def main():
        print("ARIA CLI v1.0.1 - Install typer and rich for full CLI: pip install typer rich")
        print("Core modules available: from aria_cli import QSystem, NLPEngine, LLMConnector")

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__description__",
    # Q-System
    "QSystem",
    "QLayer", 
    "QOperator",
    "QCommand",
    # NLP
    "NLPEngine",
    "Intent",
    "Entity",
    "ParsedInput",
    # LLM
    "LLMConnector",
    "LLMProvider",
    "LLMConfig",
    "LLMResponse",
    # Connector
    "AriaConnector",
    "SyncMode",
    "AriaPlugin",
    "PluginManager",
    # Q38 Native Integration
    "Q38Connector",
    "Q38Config",
    "Q38Response",
    # Knowledge Base (SQLite)
    "KnowledgeConnector",
    "KnowledgeResult",
    "ARIAConnector",  # Legacy alias
    # Authentication
    "AuthManager",
    "AuthProvider",
    "AuthStatus",
    "User",
    "Session",
    "CredentialStore",
    "get_auth",
    # SSH Router
    "SSHRouter",
    "SSHHost",
    "SSHConnection",
    "SSHAuthMethod",
    "ConnectionStatus",
    "CommandResult",
    "get_router",
    # AriaSpace - Personal Codespace
    "AriaSpace",
    "Workspace",
    "SyncFile",
    "SyncResult",
    "SyncDirection",
    "SyncStrategy",
    "FileStatus",
    "get_space",
    # Termux Integration
    "TermuxSetup",
    "TermuxDevice",
    "get_termux_setup",
    # Agents
    "AriaAgent",
    "AgentRegistry",
    "AgentSwarm",
    "AgentMessage",
    "MessageType",
    "MessagePriority",
    "AgentCapability",
    "AgentState",
    "AgentStatus",
    "TaskAgent",
    "ReasoningAgent",
    "CoordinatorAgent",
    "GeneratorAgent",
    "create_agent",
    "get_registry",
    # Agent Channels
    "ChannelManager",
    "DirectChannel",
    "BroadcastChannel",
    "StreamChannel",
    "PersistentChannel",
    "ChannelType",
    "ChannelState",
    "get_channel_manager",
    # File Manager
    "AriaFileManager",
    "FileManager",
    "FileBrowser",
    "FileOperations",
    "FileTransfer",
    "FileRouter",
    "Environment",
    "FileEntry",
    "OperationResult",
    "Platform",
    "FileType",
    "FileLocation",
    "OperationType",
    "EnvironmentDetector",
    "get_file_manager",
    "get_manager",
    # Infinite Storage
    "InfiniteStorage",
    "StorageConfig",
    "StorageResult",
    "StorageBackend",
    "CompressionLevel",
    "LRUCache",
    "PersistentCache",
    "get_storage",
    # GitHub Automation (F1/M1 Cycles)
    "GitHubCLI",
    "GitHubAutomation",
    "GitHubResult",
    "F1CycleEngine",
    "F1CycleResult",
    "M1MasterOrchestrator",
    "M1MasterCycle",
    "F1Phase",
    "CycleStatus",
    "SystemType",
    "get_github_cli",
    "get_github_automation",
    "quick_status",
    # Terminal F1 Mesh
    "F1TerminalMesh",
    "TerminalNode",
    "TerminalIdentity",
    "TerminalSnapshot",
    "TerminalState",
    "MeshTopology",
    "MeshConnection",
    "F1Improvement",
    "ImprovementType",
    "F1TerminalAnalyzer",
    "F1TerminalImprover",
    "F1TerminalValidator",
    "get_mesh",
    "create_terminal",
    "run_f1_between",
    # CLI
    "AriaCLI",
    "main",
]
