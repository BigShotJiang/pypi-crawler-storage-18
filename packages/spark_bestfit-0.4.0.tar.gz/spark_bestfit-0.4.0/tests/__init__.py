"""Tests for spark-bestfit."""
