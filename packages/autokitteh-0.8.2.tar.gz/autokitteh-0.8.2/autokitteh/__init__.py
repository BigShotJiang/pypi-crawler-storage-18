"""AutoKitteh Python SDK."""

# Modules imported here should use only the standard library.
# We don't want people installing everything just to use autokitteh in testing

from . import errors
from .activities import activity, inhibit_activities, register_no_activity
from .attr_dict import AttrDict
from .errors import AutoKittehError
from .event import Event
from .events import next_event, start, subscribe, unsubscribe
from .outcomes import http_outcome, outcome
from .signals import Signal, next_signal, signal
from .store import (
    add_values,
    check_and_set_value,
    del_value,
    get_store_public_url,
    get_value,
    list_values_keys,
    mutate_value,
    publish_value,
    set_value,
    store,
    unpublish_value,
)
from .triggers import get_webhook_url

__all__ = [
    "AttrDict",
    "AutoKittehError",
    "errors",
    "get_webhook_url",
    "http_outcome",
    "outcome",
    "start",
    # Activities
    "activity",
    "inhibit_activities",
    "register_no_activity",
    # Events
    "Event",
    "next_event",
    "subscribe",
    "unsubscribe",
    # Signals
    "next_signal",
    "signal",
    "Signal",
    # Values
    "add_values",
    "check_and_set_value",
    "del_value",
    "get_store_public_url",
    "get_value",
    "list_values_keys",
    "mutate_value",
    "publish_value",
    "set_value",
    "store",
    "unpublish_value",
]
