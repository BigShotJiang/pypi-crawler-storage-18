# promptfn/__init__.py
# SPDX-License-Identifier: MIT

# imports
import litellm
import logging

from promptfn.api import prompt
from promptfn.logger import Logger
from promptfn.models import LLMConfig
from promptfn.defaults import LLMConfigPreset


# get logger instance
_logger = Logger.get()

# drop params
litellm.drop_params = True


def enable_debug_mode() -> None:
    """Enable debug mode."""
    _logger.setLevel(logging.DEBUG)


def disable_debug_mode() -> None:
    """Disable debug mode."""
    _logger.setLevel(logging.WARNING)


__all__ = [
    "prompt",
    "LLMConfig",
    "LLMConfigPreset",
    "enable_debug_mode",
    "disable_debug_mode"
]

# current version
__version__ = "0.1.0"
