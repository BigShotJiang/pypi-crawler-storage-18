# promptfn/defaults.py
# SPDX-License-Identifier: MIT

# imports
from promptfn.models import LLMConfig


class LLMConfigPreset:
    """Pre-configured LLM settings for common use cases."""
    DEFAULT = LLMConfig(temperature=0.7)
    CREATIVE = LLMConfig(temperature=0.9, top_p=0.95)
    PRECISE = LLMConfig(temperature=0.3, top_p=0.9)
    DETERMINISTIC = LLMConfig(temperature=0.0, top_p=1.0)
