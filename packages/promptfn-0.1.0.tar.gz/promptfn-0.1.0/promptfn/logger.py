# promptfn/logger.py
# SPDX-License-Identifier: MIT

# imports
import logging


class Logger:

    @staticmethod
    def get(name: str = "promptfn"):
        """Get Logger instance."""
        ref = logging.getLogger(name)

        if not ref.handlers:
            handler = logging.StreamHandler()

            # set formatter
            handler.setFormatter(
                logging.Formatter(
                    "[%(asctime)s] [%(name)s] [%(levelname)s]: %(message)s",
                    datefmt="%H:%M:%S"
                )
            )

            ref.addHandler(handler)
            ref.setLevel(logging.WARNING)

        return ref
