# promptfn/client.py
# SPDX-License-Identifier: MIT

# imports
import litellm

from typing import Any
from promptfn.logger import Logger
from promptfn.models import LLMConfig


class LLMClient:

    def __init__(self, model: str, config: LLMConfig | None) -> None:
        """LLMClient class."""
        self._model = model
        self._logger = Logger.get()
        self._config = self._normalize_config(config)

    def _normalize_config(self, config: LLMConfig | None) -> dict[str, Any]:
        """Normalize config."""
        if config:
            return config.model_dump(
                exclude_none=True,
                exclude={
                    "extra"
                }
            ) | (config.extra or {})

        return {}

    def _normalize_return_type(self, return_type: Any) -> str:
        """Normalize return type."""
        return return_type.__name__ if isinstance(return_type, type) else str(return_type)

    def _get_schema(self, return_type: Any) -> dict[str, Any]:
        """Get schema."""
        schema = return_type.model_json_schema()

        schema.update({
            # disallow additional properties (strict mode)
            "additionalProperties": False
        })

        return schema

    def _get_response_format(self, return_type: Any) -> dict[str, Any]:
        """Get response format."""
        if not hasattr(return_type, "model_json_schema"):
            # handle non-Pydantic return types
            return None

        return {
            "type": "json_schema",
            "json_schema": {
                "schema": self._get_schema(return_type),
                "name": return_type.__name__,
                "strict": True
            }
        }

    def _make_response(self, content: str, return_type: Any) -> Any:
        """Make response."""
        try:
            return return_type.model_validate_json(content)

        except AttributeError:
            # not a Pydantic model (e.g., str, int) - return raw content
            return content

    def _validate_response(self, result: Any) -> str:
        """Validate response."""
        if not result.choices:
            raise ValueError("LLM returned no choices in response")

        content = result.choices[0].message.content
        finish_reason = result.choices[0].finish_reason

        if not content or content.strip() == "":
            reasoning_tokens = getattr(
                getattr(result.usage, 'completion_tokens_details', None),
                'reasoning_tokens',
                0
            )

            if finish_reason == "length" and reasoning_tokens > 0:
                # reasoning model used all tokens for thinking
                raise ValueError(
                    "reasoning model used all tokens for thinking, no content was generated"
                )
            elif finish_reason == "length":
                # regular model hit max tokens limit
                raise ValueError(
                    "model hit max tokens limit, no content was generated"
                )
            else:
                # unknown finish reason
                raise ValueError(
                    f"model finished without content (finish reason: {finish_reason})"
                )

        if finish_reason == "length":
            self._logger.warning(
                "response was truncated, probably due to max tokens limit."
            )

        return content

    def run(self, messages: list[dict[str, str]], return_type: Any) -> Any:
        """Run LLM synchronously."""
        self._logger.debug(
            f"""
            running LLMClient.run(
                model={self._model},
                messages={messages},
                return_type={self._normalize_return_type(return_type)},
                config={self._config}
            )"""
        )

        result = litellm.completion(
            model=self._model,
            messages=messages,
            response_format=self._get_response_format(return_type),
            **self._config
        )

        return self._make_response(
            self._validate_response(result),
            return_type
        )

    async def run_async(self, messages: list[dict[str, str]], return_type: Any) -> Any:
        """Run LLM asynchronously."""
        self._logger.debug(
            f"""
            running LLMClient.run_async(
                model={self._model},
                messages={messages},
                return_type={self._normalize_return_type(return_type)},
                config={self._config}
            )"""
        )

        result = await litellm.acompletion(
            model=self._model,
            messages=messages,
            response_format=self._get_response_format(return_type),
            **self._config
        )

        return self._make_response(
            self._validate_response(result),
            return_type
        )
