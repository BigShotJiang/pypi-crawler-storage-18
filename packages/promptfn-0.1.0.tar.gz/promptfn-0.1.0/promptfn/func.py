# promptfn/func.py
# SPDX-License-Identifier: MIT

# imports
import inspect

from typing import Any
from typing import Callable


class Func:

    def __init__(self, func: Callable) -> None:
        """Func class."""
        self._func = func
        self._name = func.__name__
        self._doc = inspect.getdoc(func)
        self._signature = inspect.signature(func)
        self._is_async = inspect.iscoroutinefunction(func)
        self._return_type = self._signature.return_annotation or str

        if not self._doc:
            raise ValueError(
                f"{self._name} docstring is required"
            )

    @property
    def name(self) -> str:
        """Get function name."""
        return self._name

    @property
    def signature(self) -> inspect.Signature:
        """Get function signature."""
        return self._signature

    @property
    def doc(self) -> str:
        """Get function docstring."""
        return self._doc

    @property
    def return_type(self) -> Any:
        """Get function return type."""
        return self._return_type

    @property
    def is_async(self) -> bool:
        """Check if function is async."""
        return self._is_async
