# promptfn/api.py
# SPDX-License-Identifier: MIT

# imports
import yaml
import inspect

from typing import Callable
from functools import wraps
from jinja2 import BaseLoader
from jinja2 import Environment
from promptfn.func import Func
from promptfn.models import LLMConfig
from promptfn.client import LLMClient


# API
def prompt(
    model: str = "gpt-4o-mini",
    on_complete: Callable | None = None,
    config: LLMConfig | None = None
) -> Callable:
    """Turn functions into LLM-powered prompts.

    Args:
        model: LLM model (litellm compatible)
        on_complete: Callback function invoked with the LLM result
        config: LLM generation parameters (see LLMConfig)

    Example:
        @prompt("openai/gpt-4o-mini")
        def summarize(text: str) -> str:
            '''Summarize: {{ text }}'''
    """
    # init llm client
    llm_client = LLMClient(model, config)

    def decorator(func):
        _func = Func(func)
        parsed = yaml.safe_load(_func.doc)

        if not isinstance(parsed, list):
            raise ValueError(
                f"{_func.name} docstring is not valid: {parsed}"
            )

        # init jinja2 environment
        env = Environment(
            trim_blocks=True,
            loader=BaseLoader(),
            lstrip_blocks=True
        )

        def _build_messages(args):
            """Build messages from docstring."""
            messages = []

            try:
                for message in parsed:
                    template = env.from_string(message["content"])
                    messages.append({
                        "role": message["role"],
                        "content": template.render(**args)
                    })

                return messages

            except KeyError as e:
                raise ValueError(
                    f"{_func.name} docstring is not valid: {e}"
                ) from e

            except Exception as e:
                raise ValueError(
                    f"{_func.name} building messages, failed: {e}"
                ) from e

        if _func.is_async:
            @wraps(func)
            async def wrapper(*args, **kwargs):
                bound = _func.signature.bind(*args, **kwargs)
                bound.apply_defaults()

                result = await llm_client.run_async(
                    _build_messages(bound.arguments),
                    _func.return_type  # response model
                )

                if on_complete:
                    # trigger callback with result
                    if not inspect.iscoroutinefunction(on_complete):
                        raise TypeError("trying to use sync with async function")
                    return await on_complete(result)

                return result
            return wrapper
        else:
            @wraps(func)
            def wrapper(*args, **kwargs):
                bound = _func.signature.bind(*args, **kwargs)
                bound.apply_defaults()

                result = llm_client.run(
                    _build_messages(bound.arguments),
                    _func.return_type  # response model
                )

                if on_complete:
                    if inspect.iscoroutinefunction(on_complete):
                        raise TypeError("trying to use async with sync function")
                    return on_complete(result)

                return result
            return wrapper

    return decorator
