# promptfn/models.py
# SPDX-License-Identifier: MIT

# imports
from typing import Any
from pydantic import Field
from pydantic import BaseModel


class LLMConfig(BaseModel):
    max_tokens: int | None = Field(None, ge=0)
    temperature: float | None = Field(None, ge=0.0, le=2.0)
    top_p: float | None = Field(None, ge=0.0, le=1.0)
    stop: list[str] | None = None
    extra: dict[str, Any] | None = Field(None, extra="provider-specific")
