"""AgentsFeature for Artificer CLI integration."""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

import click
from artificer.cli.feature import ArtificerFeature  # type: ignore[import-untyped]

from .agent import Agent

if TYPE_CHECKING:
    from artificer.cli.config import ArtificerConfig  # type: ignore[import-untyped]


class AgentsFeature(ArtificerFeature):  # type: ignore[misc]
    """Feature providing CLI commands for agent management."""

    @classmethod
    def register(cls, cli: click.Group, config: "ArtificerConfig") -> None:
        """Register agent commands with the CLI."""
        cls._import_agent_modules(config)

        @cli.group()
        def agents() -> None:
            """Manage and run agents."""
            pass

        @agents.command(name="list")
        def list_cmd() -> None:
            """List all available agents."""
            if not Agent._agent_registry:
                click.echo("No agents registered.")
                return

            click.echo("Available agents:")
            for name, agent in Agent._agent_registry.items():
                click.echo(f"  {name}")
                click.echo(f"    Tools: {', '.join(agent.tools) or '(all)'}")

        @agents.command(name="describe")
        @click.argument("agent_name")
        def describe_cmd(agent_name: str) -> None:
            """Show detailed information about an agent."""
            agent = Agent._agent_registry.get(agent_name)
            if agent is None:
                available = list(Agent._agent_registry.keys())
                click.echo(f"Unknown agent: {agent_name}", err=True)
                if available:
                    click.echo(f"Available: {', '.join(available)}", err=True)
                raise SystemExit(1)

            click.echo(f"Agent: {agent.name}")
            click.echo(f"Model: {agent.model}")
            click.echo(f"MCP Client: {agent.mcp_client}")
            click.echo(f"Max Iterations: {agent.max_iterations}")
            click.echo(f"Tools: {', '.join(agent.tools) or '(all)'}")
            click.echo()
            click.echo("System Prompt:")
            click.echo(agent.system_prompt)
            click.echo()
            click.echo("Input Schema:")
            click.echo(json.dumps(agent._input_schema.model_json_schema(), indent=2))
            click.echo()
            click.echo("Output Schema:")
            click.echo(json.dumps(agent._output_schema.model_json_schema(), indent=2))

            if agent.subagents:
                click.echo()
                click.echo("Subagents:")
                for sub in agent.subagents:
                    click.echo(f"  - {sub.name}")

        @agents.command(name="run")
        @click.argument("agent_name")
        @click.argument("input_json")
        def run_cmd(
            agent_name: str,
            input_json: str,
        ) -> None:
            """Run an agent with the given input.

            INPUT_JSON should be a JSON object matching the agent's input schema.
            """
            agent_or_cls = Agent._agent_registry.get(agent_name)
            if agent_or_cls is None:
                available = list(Agent._agent_registry.keys())
                click.echo(f"Unknown agent: {agent_name}", err=True)
                if available:
                    click.echo(f"Available: {', '.join(available)}", err=True)
                raise SystemExit(1)

            # Get or create agent instance
            if isinstance(agent_or_cls, type):
                agent = agent_or_cls()
            else:
                agent = agent_or_cls

            # Parse input
            try:
                input_data = json.loads(input_json)
            except json.JSONDecodeError as e:
                click.echo(f"Invalid JSON input: {e}", err=True)
                raise SystemExit(1)

            # Validate input against schema
            try:
                validated_input = agent._input_schema.model_validate(input_data)
            except Exception as e:
                click.echo(f"Input validation failed: {e}", err=True)
                raise SystemExit(1)

            # Run the agent
            result = asyncio.run(cls._run_agent(agent, validated_input))

            # Output result
            if isinstance(result, dict) and "error" in result:
                click.echo(f"Error: {result['error']}", err=True)
                raise SystemExit(1)

            click.echo(json.dumps(result))

    @classmethod
    async def _run_agent(
        cls,
        agent: Agent,
        input_data: Any,
    ) -> dict[str, Any] | None:
        """Run an agent and return the result."""
        from .runtime import RunResult, run_agent

        try:
            result: RunResult = await run_agent(agent, input_data)
            # Cleanup MCP client if present
            if agent.mcp_client:
                await agent.mcp_client.close()
            return result.output.model_dump() if result.output else None
        except Exception as e:
            return {"error": str(e)}

    @classmethod
    def _import_agent_modules(cls, config: "ArtificerConfig") -> None:
        """Import agent modules to register agents."""
        if sys.version_info >= (3, 11):
            import tomllib
        else:
            import tomli as tomllib

        pyproject_path = Path.cwd() / "pyproject.toml"
        if not pyproject_path.exists():
            return

        with open(pyproject_path, "rb") as f:
            pyproject: dict[str, Any] = tomllib.load(f)

        agents_config: dict[str, Any] = (
            pyproject.get("tool", {}).get("artificer", {}).get("agents", {})
        )

        # Add cwd to path so local agent modules can be imported
        cwd = str(Path.cwd())
        if cwd not in sys.path:
            sys.path.insert(0, cwd)

        agent_modules: list[str] = agents_config.get("agents", [])
        for module_path in agent_modules:
            try:
                importlib.import_module(module_path)
            except ImportError as e:
                click.echo(
                    f"Warning: Could not import agent module '{module_path}': {e}",
                    err=True,
                )
