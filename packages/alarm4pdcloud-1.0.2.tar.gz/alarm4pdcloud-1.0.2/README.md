# alarm4pdcloud
Python Package alarm4pdcloud by 4pd

## Installation
```bash
pip install alarm4pdcloud
```

## how to use
```python
from alarm4pdcloud import Sender
sender = Sender(robot_endpoint="https://",
                robot_ak="")

sender.send_robot_with_at(group_id=[1], message="message\n", at_user_ids=["user"])
sender.call_ali("phone", "message")
```
