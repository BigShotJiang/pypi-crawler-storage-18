# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class FefferyListenScroll(Component):
    """A FefferyListenScroll component.
滚动条监听组件FefferyListenScroll

Keyword arguments:

- id (string; optional):
    组件唯一id.

- key (string; optional):
    对当前组件的`key`值进行更新，可实现强制重绘当前组件的效果.

- target (string; optional):
    设置滚动条监听目标元素`id`，默认为整个页面.

- position (dict; optional):
    监听目标滚动条的水平及竖直方向上的像素偏移量."""
    _children_props: typing.List[str] = []
    _base_nodes = ['children']
    _namespace = 'feffery_utils_components'
    _type = 'FefferyListenScroll'


    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        key: typing.Optional[str] = None,
        target: typing.Optional[str] = None,
        position: typing.Optional[dict] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'key', 'target', 'position']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'key', 'target', 'position']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(FefferyListenScroll, self).__init__(**args)

setattr(FefferyListenScroll, "__init__", _explicitize_args(FefferyListenScroll.__init__))
