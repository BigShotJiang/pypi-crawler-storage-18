from setuptools import setup
import os

# Read the README.md for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ovaltinepy",
    version="0.1.0",
    author="ghoste12125",
    author_email="anonymosmauros@gmail.com",
    description="A versatile command-line tool for encoding, decoding, hashing, and string manipulation.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ghoste12125/ovaltinepy",
    py_modules=["ovaltine"],
    python_requires='>=3.8',
    entry_points={
        'console_scripts': [
            'ovaltine=ovaltine:main',
        ],
    },
)
