# Ovaltine: The Versatile Encoder/Decoder/Hasher Tool

## Project Description
Ovaltine is a powerful and versatile command-line tool designed for a wide range of encoding, decoding, hashing, and string manipulation tasks. Whether you're a security professional, a developer, or just someone who needs to quickly transform data, Ovaltine provides a comprehensive suite of functionalities accessible via an interactive menu or direct command-line arguments.

## Features
-   **Extensive Encoding/Decoding:** Support for common formats like Base64, Hexadecimal, URL, HTML Entities, ASCII, Punycode, XML, JSON, YAML, and various UTF encodings.
-   **Classic Ciphers:** Implementations of ROT13, Caesar, Atbash, Vigenère, XOR, Morse Code, A1Z26, Baconian, Polybius Square, Affine, Playfair, Hill, Rail Fence, and Scytale ciphers.
-   **Hashing Algorithms:** Generate MD5, SHA-1, SHA256, SHA512, CRC32, Adler-32, SHA3, BLAKE2b, and BLAKE2s hashes. Includes hash analysis and verification.
-   **String Manipulation:** Functions for reversing, changing case (uppercase, lowercase, capitalize, title case, swap case), and Leet (1337) speak.
-   **Numeric System Conversions:** Convert between Decimal, Hex, Octal, IP Address to Integer, Integer to IP Address, Roman Numerals, Binary Coded Decimal (BCD), Base36, and Base62.
-   **Miscellaneous Tools:** Quoted-Printable, UUencoding, XXencoding, Hexlify, EBCDIC, Luhn Algorithm, Geohash, UUID generation/parsing, Raw Hex Dump, Brainfuck, and Pig Latin.
-   **Compression/Decompression:** Zlib, Gzip, Bzip2, LZMA, Deflate, and Zstandard compression (input/output handled as Base64).
-   **Interactive Menu:** User-friendly interactive mode for easy navigation and operation selection.
-   **Command-Line Interface (CLI):** Execute operations directly from the command line for scripting and automation.
-   **Operation History:** Keep track of your past operations.
-   **Mobile-Friendly Display:** A dedicated single-column menu display for smaller terminals.

## Installation

### Prerequisites
-   Python 3.x
-   `pip` (Python package installer)

### From PyPI (Recommended)
```bash
pip install ovaltinepy
```

### From Source
1.  Clone the repository:
    ```bash
    git clone https://github.com/ghoste12125/ovaltinepy.git
    cd ovaltinepy
    ```
2.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

## Usage

### Interactive Mode
Run the script without any arguments to enter interactive mode:
```bash
python ovaltine.py
```
A menu will be displayed, allowing you to choose from various operations. Follow the prompts to input text, select encode/decode options, and provide any necessary extra parameters (like shift values or keys).

### Command-Line Mode
You can perform operations directly from the command line using arguments.

**General Usage:**
```bash
python ovaltine.py [OPTIONS]
```

**Options:**
-   `-h, --help`: Show the main help message and exit.
-   `-op, --operation <value>`: Specify the operation to perform (e.g., `Base64`, `MD5`).
-   `-c, --choice <string>`: Specify sub-choice for operation (e.g., `1` for encode/encrypt, `2` for decode/decrypt).
-   `-i, --input <value>`: Input string for the operation.
-   `-if, --input-file <value>`: Read input from a specified file.
-   `-of, --output-file <value>`: Write output to a specified file.
-   `-k, --key <value>`: Key for ciphers (e.g., Vigenère, XOR).
-   `--shift <int>`: Shift value for Caesar cipher.
-   `--rails <int>`: Number of rails for Rail Fence cipher.
-   `--diameter <int>`: Diameter for Scytale cipher.
-   `--key_a <int>`: Key "a" for Affine cipher.
-   `--key_b <int>`: Key "b" for Affine cipher.
-   `--key_matrix_str <value>`: Key matrix string for Hill cipher (e.g., "2 3,1 4").
-   `--ht, --hash-type <value>`: Hash type for Verify Hash (e.g., `md5`, `sha256`).
-   `--eh, --expected-hash <value>`: Expected hash for Verify Hash.
-   `--history`: Display operation history.
-   `--clear-history`: Clear operation history.
-   `-m, --mobile-display`: Use mobile-friendly single-column menu display (runs `ovaltine_v2.py`).
-   `-ts, --test-suite`: Run the test suite (`test_suite.py` and `test_prompts.py`).

**Examples:**
-   **Encode "Hello" to Base64:**
    ```bash
    python ovaltine.py -op Base64 -c 1 -i "Hello"
    ```
-   **Decode a Base64 string:**
    ```bash
    python ovaltine.py -op Base64 -c 2 -i "SGVsbG8="
    ```
-   **Calculate SHA256 hash of "test":**
    ```bash
    python ovaltine.py -op SHA256 -i "test"
    ```
-   **Caesar Cipher encryption with shift 3:**
    ```bash
    python ovaltine.py -op "Caesar Cipher" -c 1 -i "abc" --shift 3
    ```
-   **Read input from file and write output to file (Base64 encode):**
    ```bash
    echo "secret" > input.txt
    python ovaltine.py -op Base64 -c 1 -if input.txt -of output.txt
    ```
-   **Display operation history:**
    ```bash
    python ovaltine.py --history
    ```
-   **Run the test suite:**
    ```bash
    python ovaltine.py --test-suite
    ```

## Supported Operations (Detailed)

### Common Encodings
-   Binary, Hexadecimal, Base64, URL (Percent) Encoding, HTML Entities, ASCII Values, Punycode, XML, JSON, YAML, ISO-8859-1 (Latin-1), Shift-JIS, UTF-7, UTF-8, UTF-16, UTF-32, Base32, Base58, Base85, Base91.

### Classic Ciphers
-   ROT13, Caesar Cipher, Atbash Cipher, Morse Code, A1Z26 Cipher, Vigenère Cipher, Baconian Cipher, Polybius Square, Affine Cipher, Playfair Cipher, Hill Cipher, Rail Fence Cipher, Scytale Cipher, XOR Cipher.

### String Manipulation
-   Reverse String, Uppercase, Lowercase, Capitalize, Title Case, Swap Case, Leet (1337).

### Hashing (One-Way)
-   Analyze Hash, Verify Hash, MD5, SHA-1, SHA256, SHA512, CRC32, Adler-32, SHA3-224, SHA3-256, SHA3-384, SHA3-512, BLAKE2b, BLAKE2s.

### Numeric Systems
-   Decimal to Hex, Hex to Decimal, Decimal to Octal, Octal to Decimal, IP Address to Integer, Integer to IP Address, Roman Numerals, Binary Coded Decimal (BCD), Base36, Base62.

### Miscellaneous
-   Quoted-Printable, UUencoding, XXencoding, Hexlify, EBCDIC, Luhn Algorithm, Geohash, UUID (Generate/Parse), Raw Hex Dump, Brainfuck, Pig Latin.

### Compression
-   Zlib Compress, Gzip Compress, Bzip2 Compress, LZMA Compress, Deflate, Zstandard Compress.

## Testing
To run the full test suite, including both functional tests and prompt verification tests:
```bash
python ovaltine.py --test-suite
```

## Contributing
Contributions are welcome! Please feel free to submit issues, pull requests, or suggest new features.

## License
This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Contact
For questions or feedback, please contact [anonymosmauros@gmail.com](mailto:anonymosmauros@gmail.com).
