"""Mirage Protocol test suite"""
