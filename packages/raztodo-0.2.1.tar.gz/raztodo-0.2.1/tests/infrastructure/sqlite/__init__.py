"""SQLite repositories tests."""
