"""Tests for ECS Monitor."""
