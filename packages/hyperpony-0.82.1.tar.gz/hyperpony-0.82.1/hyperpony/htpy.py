import functools
import inspect
import json
from inspect import Signature
from typing import (
    Any,
    Callable,
    Concatenate,
    Generic,
    ParamSpec,
    Tuple,
    Type,
    TypeVar,
)

from django.http import HttpRequest, HttpResponse, QueryDict
from django.views import View
from htpy import Node, fragment

from hyperpony import ViewUtilsMixin

R = TypeVar("R")
T = TypeVar("T")
P = ParamSpec("P")


class ViewActionDescriptor(Generic[T, P, R]):
    is_view_action: bool
    view: View

    def __init__(self, func: Callable[Concatenate[T, P], R]):
        self.func = func
        self.is_view_action = True

        functools.update_wrapper(self, func)

    def __call__(
        self,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> R:
        return self.func(self.view, *args, **kwargs)

    def action(self, *args: P.args, **kwargs: P.kwargs) -> dict[str, Any]:
        path = self.view.path if hasattr(self.view, "path") else self.view.request.path

        params = json.dumps(dict(a=args, k=kwargs))
        return {
            "hx-patch": path,
            **hx_vals(
                __hp_action=self.func.__name__,
                params=params,
            ),
        }

    def __get__(
        self, instance: T | None, owner: Type[T] | None = None
    ) -> "ViewActionDescriptor[T, P, R]":
        # Called on the instance (e.g., my_view_instance.action_toggle)
        if instance is not None:
            self.view = instance

        return self


def view_action(func: Callable[Concatenate[T, P], R]) -> ViewActionDescriptor[T, P, R]:
    return ViewActionDescriptor(func)


def _check_view_action_and_return_with_signature(
    view_action_fn: Any,
) -> Tuple[Callable[..., Any], Signature]:
    fn = view_action_fn
    if not getattr(fn, "is_view_action", False):
        raise Exception(
            f"The provided action function '{fn.__name__}' is not decorated with @view_action."
        )

    return fn, inspect.signature(fn)


class HtpyView(ViewUtilsMixin, View):
    # noinspection PyUnusedLocal
    def get(self, request, *args, **kwargs):
        return HttpResponse(fragment[self.render(request, *args, **kwargs)])

    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def render(self, request: HttpRequest, *args, **kwargs) -> Node:
        raise NotImplementedError()

    def create_hx_get(self, **hx_vals_params) -> dict[str, Any]:
        return {"hx-get": self.path, **hx_vals(**hx_vals_params)}

    def create_hx_patch(self, **hx_vals_params) -> dict[str, Any]:
        return {"hx-patch": self.path, **hx_vals(**hx_vals_params)}

    def create_hx_post(self, **hx_vals_params) -> dict[str, Any]:
        return {"hx-post": self.path, **hx_vals(**hx_vals_params)}

    def create_hx_put(self, **hx_vals_params) -> dict[str, Any]:
        return {"hx-put": self.path, **hx_vals(**hx_vals_params)}

    def patch(self, request: HttpRequest, *args, **kwargs):
        qd = QueryDict(request.body, encoding=request.encoding)
        if (action := qd.get("__hp_action")) is not None:
            action_fn = getattr(self, action, None)
            method, signature = _check_view_action_and_return_with_signature(action_fn)

            params = qd["params"]
            params_obj = json.loads(params)
            action_args = params_obj["a"]
            action_kwargs = params_obj["k"]

            # response = method() if len(signature.parameters) == 0 else method(request)
            response = method(*action_args, **action_kwargs)
            if response is not None:
                return response
            return self.get(request, *args, **kwargs)

        # noinspection PyUnresolvedReferences
        return super().patch(request, *args, **kwargs)


def hx_vals(**kwargs) -> dict[str, Any]:
    return {"hx-vals": json.dumps({str(k): v for k, v in kwargs.items()})}
