import os
import random
import re
import json
import numpy as np


def objects_to_txt():
    curdir = "/".join(__file__.split("/")[:-1])

    with open(os.path.join(curdir, "pickupables_prior.json")) as f:
        pickupable_prior = json.load(f)
    with open(os.path.join(curdir, "receptacles_prior.json")) as f:
        receptacle_prior = json.load(f)

    def split_camel_preserve_acronyms(name):
        # Insert space between lowercase → uppercase
        # OR between acronym → normal word
        s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name)
        s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", s)
        return s.lower()

    objects = set(pickupable_prior.keys()) | set(receptacle_prior.keys())
    objects = {split_camel_preserve_acronyms(obj) for obj in objects}

    # Save to txt file
    with open(os.path.join(curdir, "objects.txt"), "w") as f:
        for obj in sorted(objects):
            f.write(f"{obj}\n")


def seed_everything(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    # Make hashing deterministic
    os.environ["PYTHONHASHSEED"] = str(seed)

def is_sublevel(name: str) -> str:
    # Check if receptacle is a sublevel one by looking for '___' pattern
    return bool(re.search(r"___", name))

def format_receptacle(name: str) -> str:
    # Extract all digit sequences and join them
    numbers = "".join(re.findall(r"\d+", name))

    # Remove everything after last non-digit separator, then strip trailing '|' or whitespace
    label = re.split(r"\d+", name)[0].rstrip("| ").strip()

    return f"{label} # {numbers}" if numbers else label


if __name__ == "__main__":
    objects_to_txt()
