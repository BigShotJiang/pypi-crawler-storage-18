import itertools
import logging
from itertools import chain
from typing import Generic, Type, TypeVar

from pydantic import ConfigDict, Field
from tdm import TalismanDocument
from tdm.datamodel.facts import PropertyFact
from typing_extensions import Self

from tie_domain.domain._synthetic._category import RUBRIC_ID
from tie_rubricator.datamodel import Rubric, Rubricator
from tie_rubricator.processor.abstract import AbstractRubricatorConfig, AbstractRubricatorProcessor
from tie_rubricator.provider import AbstractRubricatorProviderConfig
from tp_interfaces.abstract import AbstractDocumentProcessor
from tp_interfaces.abstract.processor.wrapper import AbstractProcessorWrapper, WrapperConfig

_Processor = TypeVar('_Processor', bound=AbstractDocumentProcessor)
logger = logging.getLogger(__name__)


class RubricatorConfig(WrapperConfig):
    rubricator: str = Field(title="Идентификатор рубрикатора")
    model_config = ConfigDict(title="")


class RubricatorWrapper(
    AbstractProcessorWrapper[_Processor, RubricatorConfig],
    AbstractRubricatorProcessor[RubricatorConfig],
    Generic[_Processor]
):
    """
    Class for config's rubricator correctness validation with further processing by a domain-free rubricator model.
    """
    def __init__(self, model: _Processor, provider_config: AbstractRubricatorProviderConfig):
        AbstractRubricatorProcessor.__init__(self, provider_config=provider_config)
        AbstractProcessorWrapper.__init__(self, model)
        self._config_type: type[RubricatorConfig] | None = None
        self._rubrics_mapping: dict[str, dict] = {}

    async def __aenter__(self) -> Self:
        await AbstractRubricatorProcessor.__aenter__(self)
        await AbstractProcessorWrapper.__aenter__(self)
        return self

    async def __aexit__(self, exc_type, exc_value, traceback, /):
        await AbstractProcessorWrapper.__aexit__(self, exc_type, exc_value, traceback)
        await AbstractRubricatorProcessor.__aexit__(self, exc_type, exc_value, traceback)
        self._rubrics_mapping = {}

    async def process_doc(self, document: TalismanDocument, config: RubricatorConfig) -> TalismanDocument:
        # 1 - rubricator should exist in the domain
        domain_rubricator = self._transformator_id2rubric.get(config.rubricator)
        if domain_rubricator is None:
            raise ValueError(f"Rubricator with id {config.rubricator} wasn't found in domain")

        # 2 - at least one model rubric should exist in the domain rubricator
        model_rubricator: Rubricator = self._model.rubricator
        intersection_ids = {r.transformator_id for r in domain_rubricator.rubrics} & {r.transformator_id for r in model_rubricator.rubrics}
        if len(intersection_ids) == 0:
            raise ValueError("There are no common rubrics for model and domain rubricators")

        # 3 - check rubric hierarchy
        rubric_mapping = self._get_rubrics_mapping(domain_rubricator, model_rubricator)
        if not self._compatible_rubricators(domain_rubricator, model_rubricator, intersection_ids, rubric_mapping):
            raise ValueError("Structures of model and domain rubricators are not compatible")

        processed = await self._model.process_doc(document, config.get_processor_config())
        rubrics = set()
        for rubric_id_fact in processed.get_facts(PropertyFact, filter_=PropertyFact.type_id_filter(RUBRIC_ID.id)):
            rubric: Rubric | None = rubric_mapping.get(rubric_id_fact.target.most_confident_value.value)
            if rubric:
                rubrics.add(rubric)
            else:
                logger.warning(f"Rubric `{rubric_id_fact.target.most_confident_value.value}` not found in domain - skipping")

        filtered_rubrics = domain_rubricator.remove_intermediate_rubrics(rubrics)
        logger.info(f"Found {len(tuple(filtered_rubrics))} rubrics for the document")
        new_facts = chain.from_iterable(rubric.as_facts for rubric in filtered_rubrics)
        return document.with_facts(new_facts, update=True)

    def _compatible_rubricators(
            self,
            domain_rubricator: Rubricator,
            model_rubricator: Rubricator,
            intersection_ids: set[str],
            rubric_mapping: dict[str, Rubric]
    ) -> bool:
        """
        Check compatibility of `domain_rubricator` and `model_rubricator` using the following rule:
            for each model rubrics (P, C) and domain rubrics (P1, C1): if (P -> ... -> C) => (P1 -> ... -> C1)
            where "A -> B" means "B is a child rubric for A"

        :param domain_rubricator: domain rubricator
        :param model_rubricator: model rubricator
        :param intersection_ids: transformator identifiers of rubrics that exist in both domain and model rubricators
        :param rubric_mapping: mapping model_rubric_transformator_id -> domain_rubric
        :return: True if rubricators are compatible, False otherwise.
        """
        compatible = True
        rubrics = [model_rubricator.rubric(transformator_id=rubric_id) for rubric_id in intersection_ids]
        for r1, r2 in itertools.combinations(rubrics, 2):
            domain_r1, domain_r2 = rubric_mapping.get(r1.transformator_id), rubric_mapping.get(r2.transformator_id)
            if domain_r1 is None or domain_r2 is None:
                continue

            if model_rubricator.ancestor(r1.id, r2.id):
                if domain_rubricator.ancestor(domain_r1.id, domain_r2.id):
                    continue
                logger.warning(f"{r1.transformator_id} -> ... -> {r2.transformator_id} in model rubricator; not in domain")
                compatible = False
            elif model_rubricator.ancestor(r2.id, r1.id):
                if domain_rubricator.ancestor(domain_r2.id, domain_r1.id):
                    continue
                logger.warning(f"{r2.transformator_id} -> ... -> {r1.transformator_id} in model rubricator; not in domain")
                compatible = False

        return compatible

    def _get_rubrics_mapping(self, domain_rubricator: Rubricator, model_rubricator: Rubricator) -> dict[str, Rubric]:
        if domain_rubricator.transformator_id in self._rubrics_mapping:
            return self._rubrics_mapping[domain_rubricator.transformator_id]

        rubrics_mapping: dict[str, Rubric] = {}
        roots = {} if len(model_rubricator.roots) > 1 else model_rubricator.roots
        for model_rubric in model_rubricator.rubrics:
            current_model_rubric = model_rubric
            while current_model_rubric and current_model_rubric.id not in roots:
                try:
                    domain_rubric = domain_rubricator.rubric(transformator_id=current_model_rubric.transformator_id)
                except KeyError:
                    logger.warning(
                        f"Rubric `{current_model_rubric.transformator_id}` not found in domain, try to use parent rubric instead"
                    )
                    current_model_rubric = current_model_rubric.parent
                else:
                    rubrics_mapping[model_rubric.transformator_id] = domain_rubric
                    break

        self._rubrics_mapping[domain_rubricator.transformator_id] = rubrics_mapping
        return rubrics_mapping

    async def _generate_runtime_config(self):
        return self._generate_wrapper_config(RubricatorConfig, self._model.config_type, check_intersection=False)

    @property
    def config_type(self) -> Type[RubricatorConfig]:
        if self._config_type is None:
            raise AttributeError
        return self._config_type

    @staticmethod
    def parse_config(config: dict) -> dict:
        config = AbstractRubricatorConfig.model_validate(config['rubricator'])
        return {'provider_config': config.provider}
