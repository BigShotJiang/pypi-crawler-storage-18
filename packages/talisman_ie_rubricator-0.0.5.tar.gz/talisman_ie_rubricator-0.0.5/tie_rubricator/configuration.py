from typing import Type

from tp_interfaces.abstract import AbstractDocumentProcessor, ModelTypeFactory


def _get_wrapper() -> Type[AbstractDocumentProcessor]:
    from tie_rubricator.processor.wrapper import RubricatorWrapper
    return RubricatorWrapper


WRAPPERS = ModelTypeFactory({
    "rubricator_wrapper": _get_wrapper
})
