"""Tests for pyml-cli."""
