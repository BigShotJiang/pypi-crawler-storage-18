from django.db import models
from libsv1.utils.base import BaseUtils

class OptimizationQuerySet(models.QuerySet):
    def with_details(self):
        return self.prefetch_related(
            *self.model.get_prefetch_relations()
        ).select_related(
            *self.model.get_select_relations()
        )

class OptimizationManager(models.Manager):
    def get_queryset(self) -> 'OptimizationQuerySet':
        return OptimizationQuerySet(self.model, using=self._db)

    def with_details(self):
        return self.get_queryset().with_details()

class ModelOptimizationMixin:
    _prefetch_relations = []
    _select_relations = []

    objects = OptimizationManager()

    @classmethod
    def get_prefetch_relations(cls, add_relations=None, exclude_relations=None):
        relations = list(cls._prefetch_relations)
        return BaseUtils.change_list_fields(relations, add_relations, exclude_relations)

    @classmethod
    def get_select_relations(cls, add_relations=None, exclude_relations=None):
        relations = list(cls._select_relations)
        return BaseUtils.change_list_fields(relations, add_relations, exclude_relations)