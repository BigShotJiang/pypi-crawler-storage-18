## [1.6.1] - 2025-12-24

### CI
- Upgrade gh plugin versions ([2738e42](https://github.com/experimaestro/experimaestro-python/commit/2738e42760d8531573844ec6cfedfebd4565ed97))

