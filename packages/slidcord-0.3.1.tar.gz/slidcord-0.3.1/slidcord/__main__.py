# DO NOT EDIT
# Generated from .copier-answers.yml

from slidcord import main

main()
