# slidcord

A
[feature-rich](https://slidge.im/docs/slidcord/main/user/features.html)
[Discord](https://discord.com/) to
[XMPP](https://xmpp.org/) puppeteering
[gateway](https://xmpp.org/extensions/xep-0100.html), based on
[slidge](https://slidge.im) and
[discord.py-self](https://discordpy-self.readthedocs.io).

[![CI pipeline status](https://ci.codeberg.org/api/badges/14067/status.svg)](https://ci.codeberg.org/repos/14067)
[![Chat](https://rooms.slidge.im:5281/muc_badge/support@rooms.slidge.im)](https://slidge.im/xmpp-web/#/guest?join=support@rooms.slidge.im)
[![PyPI package version](https://badge.fury.io/py/slidcord.svg)](https://pypi.org/project/slidcord/)




slidcord lets you chat with users of Discord without leaving your favorite XMPP client.

## Quickstart

```sh
docker run codeberg.org/slidge/slidcord \  # works with podman too
    --jid discord.example.org \  # can be whatever you want it to be
    --secret some-secret \  # must match your XMPP server config
    --home-dir /somewhere/writeable  # for data persistence
```

Use the `:latest` tag for the latest release, `:vX.X.X` for release X.X.X, and `:main`
for the bleeding edge.

If you do not like containers, other installation methods are detailed
[in the docs](https://slidge.im/docs/slidcord/main/admin/install.html).

## Documentation

Hosted on [codeberg pages](https://slidge.im/docs/slidcord/main/).

## Contributing

Contributions are **very** welcome, and we tried our best to make it easy
to start hacking on slidcord. See [CONTRIBUTING.md](./CONTRIBUTING.md).


## Related projects

- [xmpp-discord-bridge](https://git.linux.ucla.edu/jshiffer/xmpp-discord-bridge) uses a discord bot to mirror a discord
  channel in a MUC
