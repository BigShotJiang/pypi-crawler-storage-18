# collabinsightextractor

[![PyPI version](https://img.shields.io/pypi/v/collabinsightextractor.svg)](https://pypi.org/project/collabinsightextractor/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/chigwell/collabinsightextractor/blob/main/LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/collabinsightextractor.svg)](https://pypi.org/project/collabinsightextractor/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue.svg)](https://www.linkedin.com/in/chigwell)

## Overview

`collabinsightextractor` is a lightweight Python package that extracts **structured insights about remote‑team collaboration** from free‑form text such as blog posts, articles, or personal notes.  
The extractor uses a large language model (LLM) to analyze the input and returns takeaways organized into categories like:

- Communication strategies  
- Trust‑building techniques  
- Common challenges  

The results are wrapped in a consistent XML‑like format, making them easy to embed in reports, dashboards, or team‑guideline documents.

## Installation

```bash
pip install collabinsightextractor
```

## Quick Start

```python
from collabinsightextractor import collabinsightextractor

# Example text you want to analyse
text = """
Remote teams often struggle with time‑zone differences and informal communication.
Setting up regular video stand‑ups and using async tools like Slack can bridge the gap.
Trust grows when you give teammates ownership of their tasks and celebrate small wins.
"""

# Use the default LLM (ChatLLM7) with environment variable LLM7_API_KEY or the free tier key
insights = collabinsightextractor(user_input=text)

print(insights)
```

## Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | The raw text (blog post, article, notes, …) to be processed. |
| `llm` | `Optional[BaseChatModel]` | A LangChain‑compatible chat model. If omitted, the package creates a default `ChatLLM7` instance. |
| `api_key` | `Optional[str]` | API key for the LLM7 service. If omitted, the value is read from the environment variable `LLM7_API_KEY`. The free tier key can be obtained at <https://token.llm7.io/>. |

## Using a Custom LLM

You can supply any LangChain chat model that follows the `BaseChatModel` interface.

### OpenAI

```python
from langchain_openai import ChatOpenAI
from collabinsightextractor import collabinsightextractor

llm = ChatOpenAI()
insights = collabinsightextractor(user_input=text, llm=llm)
```

### Anthropic

```python
from langchain_anthropic import ChatAnthropic
from collabinsightextractor import collabinsightextractor

llm = ChatAnthropic()
insights = collabinsightextractor(user_input=text, llm=llm)
```

### Google Gemini

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from collabinsightextractor import collabinsightextractor

llm = ChatGoogleGenerativeAI()
insights = collabinsightextractor(user_input=text, llm=llm)
```

## Rate Limits & API Keys

- The **free tier of LLM7** provides sufficient quota for typical usage of this extractor.  
- For higher throughput, set your own API key via the `LLM7_API_KEY` environment variable or pass it directly:

```python
insights = collabinsightextractor(user_input=text, api_key="your_llm7_api_key")
```

You can obtain a free API key by registering at <https://token.llm7.io/>.

## Contributing & Support

- **Issues & feature requests:** <https://github.com/chigwell/collabinsightextractor/issues>  
- **Pull requests** are welcome! Please follow the existing code style and include tests for new functionality.

## License

This project is licensed under the **MIT License**.

## Author

**Eugene Evstafev** – [hi@euegne.plus](mailto:hi@euegne.plus) – <https://github.com/chigwell>

---

*Happy extracting!*