# Internal core astronomical logic

