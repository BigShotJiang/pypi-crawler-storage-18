#pragma once
#include <string>
#include <vector>
#include <cstdint>

namespace includecpp {
namespace inbuilds {

class Crypto {
public:
    // Hashing
    static std::string md5(const std::string& data);
    static std::string sha256(const std::string& data);
    static std::string sha1(const std::string& data);

    // Encoding/Decoding
    static std::string base64_encode(const std::string& data);
    static std::string base64_decode(const std::string& encoded);
    static std::string hex_encode(const std::string& data);
    static std::string hex_decode(const std::string& hex);

    // Random
    static std::string random_bytes(int length);
    static std::string random_hex(int length);
    static int random_int(int min, int max);

    // Utility
    static bool constant_time_compare(const std::string& a, const std::string& b);
};

// Free functions
std::string hash_password(const std::string& password);
bool verify_password(const std::string& password, const std::string& hash);

} // namespace inbuilds
} // namespace includecpp
