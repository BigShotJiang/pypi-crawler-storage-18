SOURCE(crypto.cpp) && HEADER(crypto.h) crypto
PUBLIC(
    crypto CLASS(Crypto) {
        METHOD(md5)
        METHOD(sha256)
        METHOD(sha1)
        METHOD(base64_encode)
        METHOD(base64_decode)
        METHOD(hex_encode)
        METHOD(hex_decode)
        METHOD(random_bytes)
        METHOD(random_hex)
        METHOD(random_int)
        METHOD(constant_time_compare)
    }
    crypto FUNC(hash_password)
    crypto FUNC(verify_password)
)
