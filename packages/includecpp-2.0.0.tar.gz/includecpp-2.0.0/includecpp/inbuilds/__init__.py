"""IncludeCPP Inbuilt Modules

Pre-built, production-ready C++ libraries included with IncludeCPP.

Available Inbuilds:
- filesystem: File and directory operations
- crypto: Hashing, encoding, encryption
- json: JSON parsing and serialization
- string_utils: Advanced string manipulation
- networking: HTTP, TCP, UDP networking

Usage:
    import includecpp

    cpp = includecpp.CppApi()

    # List all available inbuilds
    print(cpp.Inbuilds)

    # Use an inbuild module
    fs = cpp.include(cpp.FileSystem)
    fs.FileSystem.write_file("test.txt", "Hello World")

    # Get module info
    info = fs.getInfo()
    print(info)
"""

__all__ = []
