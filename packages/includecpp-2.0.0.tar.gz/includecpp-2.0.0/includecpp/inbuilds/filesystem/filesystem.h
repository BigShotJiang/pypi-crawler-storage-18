#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <filesystem>

namespace includecpp {
namespace inbuilds {

class FileSystem {
public:
    // File Operations
    static bool exists(const std::string& path);
    static bool is_file(const std::string& path);
    static bool is_directory(const std::string& path);
    static std::string read_file(const std::string& path);
    static bool write_file(const std::string& path, const std::string& content);
    static bool append_file(const std::string& path, const std::string& content);
    static bool delete_file(const std::string& path);
    static bool copy_file(const std::string& src, const std::string& dst);
    static bool move_file(const std::string& src, const std::string& dst);
    static long long file_size(const std::string& path);

    // Directory Operations
    static bool create_directory(const std::string& path);
    static bool remove_directory(const std::string& path);
    static std::vector<std::string> list_directory(const std::string& path);
    static std::vector<std::string> list_files(const std::string& path, const std::string& extension = "");
    static std::vector<std::string> list_subdirectories(const std::string& path);

    // Path Operations
    static std::string get_absolute_path(const std::string& path);
    static std::string get_filename(const std::string& path);
    static std::string get_extension(const std::string& path);
    static std::string get_parent_path(const std::string& path);
    static std::string join_paths(const std::string& p1, const std::string& p2);

    // File Info
    static std::string get_current_directory();
    static bool set_current_directory(const std::string& path);
};

// Free functions for common operations
std::string read_text(const std::string& path);
bool write_text(const std::string& path, const std::string& content);
std::vector<std::string> read_lines(const std::string& path);
bool write_lines(const std::string& path, const std::vector<std::string>& lines);

} // namespace inbuilds
} // namespace includecpp
