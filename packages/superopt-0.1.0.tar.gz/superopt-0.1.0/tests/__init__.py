"""Tests for SuperOpt."""
