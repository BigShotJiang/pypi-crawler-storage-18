"""Tests for comparison framework."""
