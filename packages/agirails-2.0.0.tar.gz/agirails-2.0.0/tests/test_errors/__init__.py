"""Tests for error module."""
