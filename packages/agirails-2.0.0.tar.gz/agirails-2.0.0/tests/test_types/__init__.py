"""Tests for SDK types."""
