# 📚 OMU-UBYS

<div align="center">

**Unofficial Python client for OMU UBYS (University Information Management System)**

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/omu-ubys.svg)](https://badge.fury.io/py/omu-ubys)

</div>

---

> ⚠️ **DISCLAIMER**: This is an **UNOFFICIAL** project and is **NOT** affiliated with, endorsed by, or connected to Ondokuz Mayıs University in any way. This library is for **EDUCATIONAL and TESTING purposes only**. Use at your own risk. The authors assume no responsibility for any misuse or consequences arising from the use of this software.

---

## 🚀 Installation

```bash
pip install omu-ubys
```

## 📖 Quick Start

```python
from omu_ubys import UBYSClient

# Create client and login
client = UBYSClient()
client.login("student_number", "password")

# Get your profile
profile = client.get_profile()
print(f"Welcome, {profile.name}!")

# Get your grades
grades = client.get_grades()
for semester in grades:
    print(f"\n📚 {semester.name}:")
    for course in semester.courses:
        print(f"  • {course.code}: {course.letter_grade}")

# Don't forget to close!
client.close()
```

### Using Context Manager

```python
from omu_ubys import UBYSClient

with UBYSClient("student_number", "password") as client:
    grades = client.get_grades()
    schedule = client.get_weekly_schedule()
```

---

## 📋 API Reference

### `UBYSClient`

Main client class for interacting with UBYS.

#### Methods

| Method                             | Description                | Returns                   |
| ---------------------------------- | -------------------------- | ------------------------- |
| `login(username, password)`        | Login to UBYS              | `bool`                    |
| `get_profile()`                    | Get student profile        | `UserProfile`             |
| `get_advisor()`                    | Get advisor info           | `Advisor` or `None`       |
| `get_grades(include_history=True)` | Get course grades          | `list[Semester]`          |
| `get_transcript()`                 | Get academic transcript    | `list[Semester]`          |
| `get_weekly_schedule()`            | Get weekly schedule        | `list[ScheduleItem]`      |
| `get_class_details(class_id)`      | Get detailed class info    | `dict`                    |
| `get_cafeteria_menu()`             | Get today's menu (no auth) | `CafeteriaMenu` or `None` |
| `close()`                          | Close the session          | `None`                    |

---

## 🔍 Detailed Usage

### Getting Grades

```python
grades = client.get_grades()

for semester in grades:
    print(f"\n=== {semester.name} ===")
    for course in semester.courses:
        print(f"{course.code} - {course.name}")
        print(f"  Grade: {course.letter_grade} ({course.status})")

        # Exam details
        for exam in course.exams:
            print(f"  {exam.exam_type}: {exam.score}")
```

**Response:** `list[Semester]`

```python
Semester(
    name="2024-2025 Güz",
    gpa=3.45,
    courses=(
        Course(
            code="BİL101",
            name="Programlamaya Giriş",
            credit=4.0,
            letter_grade="AA",
            status="Başarılı",
            exams=(
                Exam(exam_type="Vize", score=85.0),
                Exam(exam_type="Final", score=90.0),
            )
        ),
        ...
    )
)
```

### Getting Weekly Schedule

```python
schedule = client.get_weekly_schedule()

for item in schedule:
    print(f"{item.day} {item.start_time}-{item.end_time}")
    print(f"  📖 {item.course_name}")
    print(f"  📍 {item.classroom}")
```

**Response:** `list[ScheduleItem]`

```python
ScheduleItem(
    day="Pazartesi",
    start_time="09:00",
    end_time="09:45",
    course_name="Veri Yapıları",
    course_code="BİL201",
    classroom="D-201",
    instructor="Prof. Dr. ..."
)
```

### Getting Transcript

```python
transcript = client.get_transcript()

for semester in transcript:
    print(f"\n{semester.name} - GPA: {semester.gpa}")
    for course in semester.courses:
        print(f"  {course.code}: {course.letter_grade}")
```

### Getting Advisor Info

```python
advisor = client.get_advisor()

if advisor:
    print(f"Advisor: {advisor.name}")
    print(f"Email: {advisor.email}")
```

### Getting Cafeteria Menu (No Login Required!)

```python
# This works without authentication
client = UBYSClient()
menu = client.get_cafeteria_menu()

if menu:
    print(f"🍽️ Menu for {menu.date}:")
    for item in menu.items:
        print(f"  • {item.name}")
```

---

## ⚠️ Error Handling

```python
from omu_ubys import (
    UBYSClient,
    LoginError,
    SessionExpiredError,
    ParseError,
    NetworkError
)

try:
    client = UBYSClient()
    client.login("student_number", "wrong_password")
except LoginError as e:
    print(f"Login failed: {e}")
except NetworkError as e:
    print(f"Connection error: {e}")
except SessionExpiredError as e:
    print("Session expired, please login again")
except ParseError as e:
    print(f"Failed to parse response: {e}")
```

---

## 📦 Data Models

All models are immutable dataclasses:

| Model           | Fields                                                                                   |
| --------------- | ---------------------------------------------------------------------------------------- |
| `UserProfile`   | `name`, `student_number`, `faculty`, `department`, `sap_id`, `db_student_id`             |
| `Advisor`       | `name`, `email`                                                                          |
| `Course`        | `code`, `name`, `credit`, `letter_grade`, `status`, `class_id`, `exams`                  |
| `Exam`          | `exam_type`, `name`, `date`, `score`, `average`, `ranking`                               |
| `Semester`      | `name`, `gpa`, `courses`                                                                 |
| `ScheduleItem`  | `day`, `start_time`, `end_time`, `course_name`, `course_code`, `classroom`, `instructor` |
| `CafeteriaMenu` | `date`, `items`                                                                          |
| `MenuItem`      | `name`, `calories`                                                                       |

---

## 🔧 Requirements

- Python 3.9+
- httpx
- beautifulsoup4
- lxml

---

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

**Remember**: This is an unofficial, educational project. Use responsibly!

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

<div align="center">
Made with ❤️ for OMU students
</div>
