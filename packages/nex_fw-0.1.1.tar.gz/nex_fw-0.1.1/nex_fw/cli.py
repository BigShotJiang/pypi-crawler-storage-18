"""
NexFramework CLI - 命令行工具
"""
import click
import os
import json


@click.group()
@click.version_option(version="0.1.0", prog_name="nex")
def cli():
    """NexFramework 命令行工具"""
    pass


@cli.command()
@click.option('--port', '-p', default=8000, help='API 服务端口')
@click.option('--host', '-h', default='0.0.0.0', help='监听地址')
@click.option('--dir', '-d', default='.', help='工作目录')
def serve(port, host, dir):
    """启动 API 服务"""
    os.chdir(os.path.abspath(dir))
    import uvicorn
    from .api import app
    click.echo(f"🚀 启动 NexFramework API http://{host}:{port}")
    click.echo(f"📁 工作目录: {os.getcwd()}")
    uvicorn.run(app, host=host, port=port)


@cli.command()
@click.option('--dir', '-d', default='.', help='工作目录')
def console(dir):
    """启动控制台"""
    os.chdir(os.path.abspath(dir))
    from .server import main
    main()


@cli.command()
@click.option('--dir', '-d', default='.', help='项目目录')
def init(dir):
    """初始化工作目录"""
    dir = os.path.abspath(dir)
    os.makedirs(dir, exist_ok=True)
    tools_dir = os.path.join(dir, 'tools')
    os.makedirs(tools_dir, exist_ok=True)
    
    # 创建模型配置
    models_file = os.path.join(dir, 'model_config.json')
    if not os.path.exists(models_file):
        with open(models_file, 'w', encoding='utf-8') as f:
            json.dump({
                "default": {
                    "name": "默认模型",
                    "api_key": "your-api-key",
                    "base_url": "https://api.openai.com/v1",
                    "model": "gpt-4o"
                }
            }, f, ensure_ascii=False, indent=2)
        click.echo(f"✅ 创建 model_config.json")
    else:
        click.echo(f"⏭️  跳过 model_config.json (已存在)")
    
    # 创建提示词
    prompt_file = os.path.join(dir, 'prompt_config.txt')
    if not os.path.exists(prompt_file):
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write("You are a helpful assistant.")
        click.echo(f"✅ 创建 prompt_config.txt")
    else:
        click.echo(f"⏭️  跳过 prompt_config.txt (已存在)")
    
    # 创建示例工具
    example_tool = os.path.join(tools_dir, 'example.json')
    if not os.path.exists(example_tool):
        with open(example_tool, 'w', encoding='utf-8') as f:
            json.dump({
                "name": "example_tool",
                "description": "示例工具，可删除此文件",
                "parameters": {
                    "type": "object",
                    "properties": {"param": {"type": "string"}},
                    "required": []
                }
            }, f, ensure_ascii=False, indent=2)
        click.echo(f"✅ 创建 tools/example.json")
    
    click.echo(f"\n🎉 初始化完成！目录: {dir}")
    click.echo("📝 请编辑 model_config.json 配置 API Key")
    click.echo("🚀 然后运行 nex console 或 nex serve")


def main():
    cli()


if __name__ == '__main__':
    main()
