"""
NexFramework - AI 对话框架
支持多模型切换、工具调用、流式输出
"""
from .framework import NexFramework

__version__ = "0.1.0"
__author__ = "3w4e"
__all__ = ['NexFramework']
