# NexFramework

AI 对话框架，支持多模型切换、工具调用、流式输出。

## 安装

```bash
pip install nex-fw        # 基础安装
pip install nex-fw[api]   # 包含 API 服务
pip install nex-fw[all]   # 完整安装
```

## 快速开始

```bash
# 初始化工作目录
nex init

# 编辑 model_config.json 配置 API Key

# 启动控制台
nex console

# 或启动 API 服务
nex serve --port 8000
```

## 工作目录结构

```
your_project/
├── model_config.json     # 模型配置
├── prompt_config.txt     # 系统提示词
├── chat_history.json     # 对话历史（自动生成）
└── tools/                # 自定义工具目录
    └── example.json      # 工具定义文件
```

## 配置文件

### model_config.json

```json
{
  "default": {
    "name": "GPT-4",
    "api_key": "sk-xxx",
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4o"
  },
  "deepseek": {
    "name": "DeepSeek",
    "api_key": "sk-xxx",
    "base_url": "https://api.deepseek.com/v1",
    "model": "deepseek-chat"
  }
}
```

### 自定义工具 (tools/*.json)

```json
{
  "name": "get_weather",
  "description": "获取天气信息",
  "parameters": {
    "type": "object",
    "properties": {
      "city": {"type": "string", "description": "城市名"}
    },
    "required": ["city"]
  }
}
```

## 代码使用

```python
from nex_fw import NexFramework

# 指定工作目录初始化
nex = NexFramework(work_dir="./my_project")

# 对话
reply = nex.chat("user1", "你好")

# 流式对话
for chunk in nex.chat_stream("user1", "讲个故事"):
    print(chunk, end="", flush=True)

# 切换模型
nex.switch_model("deepseek")

# 注册运行时工具
nex.register_tool(
    name="calc",
    description="计算器",
    parameters={"type": "object", "properties": {"expr": {"type": "string"}}},
    handler=lambda args: str(eval(args['expr']))
)
```

## CLI 命令

| 命令 | 说明 |
|------|------|
| `nex init` | 初始化工作目录 |
| `nex console` | 启动控制台 |
| `nex serve` | 启动 API 服务 |

所有命令支持 `--dir` 指定工作目录。

## 控制台命令

| 命令 | 说明 |
|------|------|
| /start [port] | 启动 API 服务 |
| /stop | 停止 API 服务 |
| /status | 查看状态 |
| /models | 查看模型列表 |
| /use \<key\> | 切换模型 |
| /history [n] | 查看历史 |
| /clear | 清空历史 |
| /quit | 退出 |

## License

MIT
