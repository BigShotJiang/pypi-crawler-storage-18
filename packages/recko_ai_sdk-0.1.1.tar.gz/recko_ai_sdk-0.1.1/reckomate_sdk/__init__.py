"""
Reckomate SDK
~~~~~~~~~~~~~

Python SDK for interacting with Reckomate backend services.
"""

from .client import ReckomateClient
from .services.admin import AdminService
from .services.users import UserService
from .services.user_ingest import UserIngestService


class ReckomateSDK:
    """
    Main SDK entry point.

    Example:
        sdk = ReckomateSDK(
            base_url="http://localhost:8000",
            token="JWT_TOKEN"
        )
    """

    def __init__(self, base_url: str, token: str | None = None):
        self._client = ReckomateClient(base_url=base_url, token=token)

        # Service bindings
        self.admin = AdminService(self._client)
        self.users = UserService(self._client)
        self.user_ingest = UserIngestService(self._client)

    def set_token(self, token: str):
        """
        Update auth token dynamically (after login).
        """
        self._client.set_token(token)


__all__ = [
    "ReckomateSDK",
    "ReckomateClient",
    "AdminService",
    "UserService",
    "UserIngestService",
]
