# Copyright 2022-2025 ScaleVector
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

FIRST_DAY_OF_MILLENNIUM = "2000-01-01"
DEFAULT_API_VERSION = "2023-10"
DEFAULT_ITEMS_PER_PAGE = 250

DEFAULT_PARTNER_API_VERSION = "2024-01"
