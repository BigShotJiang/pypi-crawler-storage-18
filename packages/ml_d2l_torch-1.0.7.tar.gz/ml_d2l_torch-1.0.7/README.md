# ml_d2l_torch

This repository contains PyTorch implementations of the Deep Learning book "Dive into Deep Learning" (D2L).   
It provides code examples, tutorials, and exercises to help you learn deep learning concepts using PyTorch.

## Installation

```
pip install -U ml_d2l_torch
```

## Code Examples

You can find the code examples in the `ml_d2l_torch` package. Here is a simple example of how to use it:

```python
from ml_d2l_torch import d2l_torch as d2l


```


## Build & upload to pypi
prerequirement: twine is installed. If not, run the following command to install it:
```bash
pip install -U twine
```

build and upload:
```bash
python setup.py sdist

twine upload dist/*
```
