"""
qry-doc: Motor de análisis generativo para consultas en lenguaje natural.

qry-doc transforma el lenguaje natural en código ejecutable, visualizaciones
y reportes PDF profesionales. Simplifica radicalmente la interacción con
archivos CSV y bases de datos SQL.

Example:
    ```python
    from qry_doc import QryDoc, ReportTemplate
    from pandasai.llm import OpenAI
    
    # Inicializar con datos y LLM
    llm = OpenAI(api_token="your-api-key")
    qry = QryDoc("ventas.csv", llm=llm)
    
    # Hacer preguntas en lenguaje natural
    respuesta = qry.ask("¿Cuál fue el total de ventas en 2023?")
    print(respuesta)
    
    # Exportar resultados a CSV
    qry.extract_to_csv("Top 10 clientes por ventas", "top_clientes.csv")
    
    # Generar reporte PDF
    template = ReportTemplate(
        logo_path="logo.png",
        primary_color="#003366"
    )
    qry.generate_report(
        "Análisis de tendencias de ventas",
        "reporte_ventas.pdf",
        template=template
    )
    ```
"""
from importlib import metadata

# Version from package metadata
try:
    __version__ = metadata.version("qry-doc")
except metadata.PackageNotFoundError:
    __version__ = "0.1.0"

# Main entry point
from qry_doc.core import QryDoc

# Templates
from qry_doc.report_template import (
    ReportTemplate,
    DEFAULT_TEMPLATE,
    CORPORATE_TEMPLATE,
    MINIMAL_TEMPLATE,
    A4_TEMPLATE,
)

# Exceptions
from qry_doc.exceptions import (
    QryDocError,
    QueryError,
    ExportError,
    ReportError,
    DataSourceError,
    ValidationError,
)

# Public API
__all__ = [
    # Version
    "__version__",
    # Main class
    "QryDoc",
    # Templates
    "ReportTemplate",
    "DEFAULT_TEMPLATE",
    "CORPORATE_TEMPLATE",
    "MINIMAL_TEMPLATE",
    "A4_TEMPLATE",
    # Exceptions
    "QryDocError",
    "QueryError",
    "ExportError",
    "ReportError",
    "DataSourceError",
    "ValidationError",
]
