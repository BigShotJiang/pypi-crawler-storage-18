class SDKException(Exception):
    pass
