# BifrostAI Python SDK

Official Python SDK for BifrostAPI — one API for all AI models.

## Installation

```bash
pip install bifrost-ai
```

## Quick Start

```python
from bifrost import BifrostAI

client = BifrostAI(
    api_key="bfr-xxxxx",
    openai_key="sk-xxxxx"
)

response = client.chat("conv1", "Hello!", model="gpt-4")
print(response.content)
```

## Streaming

```python
for chunk in client.chat_stream("conv1", "Count 1 to 5", model="gpt-4"):
    print(chunk.content, end="", flush=True)
```

## File Upload

```python
from bifrost import FileAttachment

file = FileAttachment.from_file("document.pdf")
response = client.chat_with_files(
    "conv1",
    "Summarize this",
    files=[file],
    model="gpt-4-turbo"
)
print(response.content)
```

## License

MIT
