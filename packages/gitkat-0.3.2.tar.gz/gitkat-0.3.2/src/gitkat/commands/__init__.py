"""Command implementations for GitKat."""
