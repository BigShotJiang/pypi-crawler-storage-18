# Repeatable

Python package to create generator-like objects that can be iterated over more
than once.

Repeatable also provides `itertools` alternatives that handle thase iterables
with far better memory efficients, even accepting infinite iterables.

## Installation

```
pip install repeatable
```

## Usage

Creating a repeatable Fibonacci-number generator:

```py
from repeatable import repeatable

@repeatable
def fibonacci(max_value = 5):
    a, b, = 0, 1
    while a <= max_value:
        yield a
        a, b = b, a + b

repeatable_fibonacci = fibonacci()

for x in repeatable_fib:
    print(x)

repeatable_fibonacci.restart()

for y in repeatable_fib:
    print(y)

"""
0
1
1
2
3
5
0
1
1
2
3
5
"""
```

You can also use repeatable itertools on infinite generators:

```py
from repeatable import repeatable, product

@repeatable
def fibonacci():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

repeatable_fibonacci = fibonacci()

for p in product(repeatable_fibonacci, range(2)):
    print(p)

"""
(0, 0)
(0, 1)
(1, 0)
(1, 1)
(1, 0)
(1, 1)
(2, 0)
(2, 1)
(3, 0)
(3, 1)
(5, 0)
(5, 1)
...
"""
```
