import ast
import random
import string

class ConstantFolder(ast.NodeTransformer):
    def visit_BinOp(self, node):
        self.generic_visit(node)
        if isinstance(node.left, ast.Constant) and isinstance(node.right, ast.Constant):
            try:
                op = node.op
                l = node.left.value
                r = node.right.value
                res = None
                if isinstance(op, ast.Add): res = l + r
                elif isinstance(op, ast.Sub): res = l - r
                elif isinstance(op, ast.Mult): res = l * r
                elif isinstance(op, ast.Div): res = l / r
                elif isinstance(op, ast.FloorDiv): res = l // r
                elif isinstance(op, ast.Mod): res = l % r
                elif isinstance(op, ast.Pow): res = l ** r
                elif isinstance(op, ast.LShift): res = l << r
                elif isinstance(op, ast.RShift): res = l >> r
                elif isinstance(op, ast.BitAnd): res = l & r
                elif isinstance(op, ast.BitOr): res = l | r
                elif isinstance(op, ast.BitXor): res = l ^ r
                # MatMult cannot be safely folded for constants usually (requires numpy arrays)

                if res is not None:
                    return ast.Constant(value=res)
            except:
                pass
        return node

    def visit_UnaryOp(self, node):
        self.generic_visit(node)
        if isinstance(node.operand, ast.Constant):
            try:
                op = node.op
                v = node.operand.value
                res = None
                if isinstance(op, ast.UAdd): res = +v
                elif isinstance(op, ast.USub): res = -v
                elif isinstance(op, ast.Not): res = not v
                elif isinstance(op, ast.Invert): res = ~v

                if res is not None:
                    return ast.Constant(value=res)
            except:
                pass
        return node

class CGenerator(ast.NodeVisitor):
    def __init__(self, mod_name, turbo=False):
        self.mod_name = mod_name
        self.turbo = turbo
        self.functions = []
        self.c_code = []
        self.indent = 0
        self.temp_count = 0
        self.temp_types = {}
        self.buffer_views = {}
        self.error_label = None # Label to jump to on error (if inside try)
        self.cleanup_stack = [] # Stack of cleanup code for returns/breaks inside with. Tuple: (code, loop_depth)
        self.loop_depth = 0

    def _add_line(self, text):
        self.c_code.append("    " * self.indent + text)

    def _get_temp(self, is_obj=True):
        self.temp_count += 1
        name = f"tmp_{self.temp_count}"
        self.temp_types[name] = "PyObject*" if is_obj else "double"
        return name

    def generate(self, func_node, original_name=None):
        # Apply constant folding first
        func_node = ConstantFolder().visit(func_node)

        func_name = original_name if original_name else func_node.name
        self.functions.append(func_name)
        
        self._add_line(f"static PyObject* bcc_{func_name}(PyObject* self, PyObject* args, PyObject* kwargs) {{")
        self.indent += 1
        
        arg_names = [arg.arg for arg in func_node.args.args]
        format_str = "O" * len(arg_names)
        keywords_init = ", ".join([f'"{name}"' for name in arg_names] + ["NULL"])
        self._add_line(f"static char *kwlist[] = {{{keywords_init}}};")
        
        for name in arg_names:
            self._add_line(f"PyObject* py_{name} = NULL;")
            if self.turbo:
                if not ("arr" in name.lower() or "data" in name.lower()):
                     self._add_line(f"double {name} = 0;")
        
        self.raw_types = {}
        if self.turbo:
            for name in arg_names:
                if "arr" in name.lower() or "data" in name.lower():
                    self.raw_types[name] = "double*"
                else:
                    self.raw_types[name] = "double"

        class VarScanner(ast.NodeVisitor):
            def __init__(self, arg_names, turbo):
                self.found_double = set()
                self.found_long = set()
                self.found_obj = set()
                self.args = set(arg_names)
                self.turbo = turbo
            def _check_val(self, target, val):
                if not isinstance(target, ast.Name) or target.id in self.args: return
                # Heuristic: if value is a Call (not math), List, Tuple, or Name known as obj
                is_obj = False
                is_int = False
                if isinstance(val, ast.Constant):
                     if isinstance(val.value, int): is_int = True
                     elif isinstance(val.value, float): pass
                     else: is_obj = True
                elif isinstance(val, (ast.List, ast.Tuple, ast.Dict, ast.Set)): is_obj = True
                elif isinstance(val, ast.Call):
                     if isinstance(val.func, ast.Name) and val.func.id in ('len', 'range', 'int', 'abs', 'min', 'max'):
                         # These likely return numbers, potentially ints
                         if val.func.id in ('len', 'int', 'range'): is_int = True
                     else: is_obj = True
                
                if self.turbo and not is_obj:
                    if is_int: self.found_long.add(target.id)
                    else: self.found_double.add(target.id)
                else: self.found_obj.add(target.id)

            def visit_Assign(self, node):
                for target in node.targets:
                    self._check_val(target, node.value)
                self.generic_visit(node)
            def visit_AugAssign(self, node):
                self._check_val(node.target, node.value)
                self.generic_visit(node)
            def visit_For(self, node):
                if isinstance(node.target, ast.Name) and node.target.id not in self.args:
                    # For loops over range usually mean ints
                    if isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) and node.iter.func.id == 'range':
                         self.found_long.add(node.target.id)
                    else:
                         self.found_double.add(node.target.id)
                self.generic_visit(node)
            def visit_While(self, node): self.generic_visit(node)
            def visit_If(self, node): self.generic_visit(node)

        scanner = VarScanner(arg_names, self.turbo)
        scanner.visit(func_node)
        
        for name in scanner.found_double:
            if name not in scanner.found_obj and name not in scanner.found_long:
                self._add_line(f"double {name} = 0;")
                self.raw_types[name] = "double"
            elif name not in scanner.found_obj:
                # Conflict resolution: if marked as both, default to double? or check usage?
                # Let's prefer double if mixed to be safe, or long if only int seen.
                # Actually, if it was seen as double ever, make it double.
                self._add_line(f"double {name} = 0;")
                self.raw_types[name] = "double"
            else:
                self._add_line(f"PyObject* py_{name} = NULL;")
        
        for name in scanner.found_long:
             if name not in scanner.found_double and name not in scanner.found_obj:
                 self._add_line(f"long {name} = 0;")
                 self.raw_types[name] = "long"

        for name in scanner.found_obj:
             self._add_line(f"PyObject* py_{name} = NULL;")

        if arg_names:
            p_args = ", ".join([f"&py_{name}" for name in arg_names])
            self._add_line(f"if (!PyArg_ParseTupleAndKeywords(args, kwargs, \"{format_str}\", kwlist, {p_args})) return NULL;")
        else:
            self._add_line(f"if (!PyArg_ParseTupleAndKeywords(args, kwargs, \"\", kwlist)) return NULL;")

        self.locals = set(arg_names)
        self.buffer_views = {}
        self.returned = False
        self.error_label = None # Label to jump to on error (if inside try)
        self.cleanup_stack = [] # Stack of cleanup code for returns/breaks inside with. Tuple: (code, loop_depth)
        self.loop_depth = 0

        if self.turbo:
            self._add_line("PyThreadState* _save = NULL;")
            for name in arg_names:
                if "arr" in name.lower() or "data" in name.lower():
                    vn = f"view_{name}"
                    self._add_line(f"Py_buffer {vn};")
                    self._add_line(f"if (PyObject_GetBuffer(py_{name}, &{vn}, PyBUF_WRITABLE) < 0) return NULL;")
                    self.buffer_views[name] = vn
                else:
                    self._add_line(f"if (PyFloat_Check(py_{name})) {name} = PyFloat_AsDouble(py_{name}); else {name} = (double)PyLong_AsLong(py_{name});")
            self._add_line("if (!_save) _save = PyEval_SaveThread();")

        for stmt in func_node.body:
            self.visit(stmt)

        if not self.returned:
            if self.turbo:
                self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                for name, view in self.buffer_views.items():
                    self._add_line(f"PyBuffer_Release(&{view});")
            self._add_line("Py_RETURN_NONE;")
        self.indent -= 1
        self._add_line("}\n")

    def visit_Pass(self, node):
        self._add_line("/* pass */")

    def visit_Assert(self, node):
        test = self._visit_expr(node.test)
        msg = "Assertion failed"
        if node.msg and isinstance(node.msg, ast.Constant): msg = str(node.msg.value).replace('"', '\\"').replace('\n', '\\n')

        if not self._is_raw_val(test):
             # Ensure we're in Python mode if needed for PyObject_IsTrue
             if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
             t = self._get_temp(is_obj=False)
             self._add_line(f"int {t} = PyObject_IsTrue({test});")
             if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
             test = t

        self._add_line(f"if (!({test})) {{")
        self.indent += 1
        if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
        self._add_line(f'PyErr_SetString(PyExc_AssertionError, "{msg}");')
        self._add_line("return NULL;")
        self.indent -= 1
        self._add_line("}")

    def visit_Raise(self, node):
        if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
        if node.exc:
            val = self._visit_expr(node.exc)
            if self._is_raw_val(val): val = f"PyFloat_FromDouble((double){val})"
            self._add_line(f"PyErr_SetObject(PyExc_Exception, {val});")
        else:
            # Check if exception is active, if so allow propagate (return NULL).
            # If not, raise RuntimeError
            self._add_line("if (PyErr_Occurred()) return NULL;")
            self._add_line("PyErr_SetString(PyExc_RuntimeError, \"No active exception to reraise\");")
        self._add_line("return NULL;")

    def visit_Return(self, node):
        val = self._visit_expr(node.value) if node.value else "Py_None"
        # Handle cleanups if inside with - return exits ALL scopes
        if self.cleanup_stack:
            for cleanup, _ in reversed(self.cleanup_stack):
                self._add_line(cleanup)

        if self.turbo:
            self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            for name, view in self.buffer_views.items():
                self._add_line(f"PyBuffer_Release(&{view});")
        if val == "Py_None": self._add_line("Py_RETURN_NONE;")
        elif self._is_raw_val(val):
            self._add_line(f"PyObject* final_ret = PyFloat_FromDouble((double){val}); return final_ret;")
        else:
            self._add_line(f"Py_XINCREF({val}); return {val};")
        self.returned = True

    def visit_Assign(self, node):
        val = self._visit_expr(node.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                if target.id in self.raw_types:
                    # Target is a raw type (double or long)
                    rtype = self.raw_types[target.id]
                    if not self._is_raw_val(val):
                         self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                         t = self._get_temp(is_obj=False)
                         self.temp_types[t] = rtype
                         if rtype == "double":
                             self._add_line(f"double {t} = (PyFloat_Check({val}) ? PyFloat_AsDouble({val}) : (double)PyLong_AsLong({val}));")
                         else:
                             self._add_line(f"long {t} = PyLong_AsLong({val});")
                         self._add_line("if (!_save) _save = PyEval_SaveThread();")
                         val = t
                    self._add_line(f"{target.id} = ({rtype}){val};")
                else:
                    # Target is a PyObject* (py_...)
                    if self.turbo and self._is_raw_val(val):
                        self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                        # We don't know if raw val is int or float easily here, unless we track temp types better
                        # Heuristic: if val looks like integer, use PyLong_FromLong
                        # But simplest is to check if it has a decimal point or came from double op
                        is_float = (val in self.temp_types and self.temp_types[val] == "double") or "." in val
                        if is_float:
                            self._add_line(f"py_{target.id} = PyFloat_FromDouble((double){val});")
                        else:
                            self._add_line(f"py_{target.id} = PyLong_FromLong((long){val});")
                        self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    else:
                        self._add_line(f"py_{target.id} = {val};")
            elif isinstance(target, ast.Subscript):
                arr_name = target.value.id
                idx = self._visit_expr(target.slice)
                if self.turbo and not self._is_raw_val(idx):
                     self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                     t = self._get_temp(is_obj=False)
                     self._add_line(f"long {t} = PyLong_AsLong({idx});")
                     self._add_line("if (!_save) _save = PyEval_SaveThread();")
                     idx = t
                if arr_name in self.buffer_views:
                    v = self.buffer_views[arr_name]
                    v_raw = val if self._is_raw_val(val) else f"(PyFloat_Check({val}) ? PyFloat_AsDouble({val}) : (double)PyLong_AsLong({val}))"
                    if self.turbo and not self._is_raw_val(val):
                        self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                        self._add_line(f"((double*){v}.buf)[(long){idx}] = (double){v_raw};")
                        self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    else:
                        self._add_line(f"((double*){v}.buf)[(long){idx}] = (double){v_raw};")
                else:
                    if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    i_obj = idx if not self._is_raw_val(idx) else f"PyLong_FromLong((long){idx})"
                    v_obj = val if not self._is_raw_val(val) else f"PyFloat_FromDouble((double){val})"
                    self._add_line(f"PyObject_SetItem(py_{arr_name}, {i_obj}, {v_obj});")
                    if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")

    def visit_For(self, node):
        self.loop_depth += 1
        if isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) and node.iter.func.id == 'range':
            limit = self._visit_expr(node.iter.args[0])
            if self.turbo and not self._is_raw_val(limit):
                self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                t = self._get_temp(is_obj=False)
                self._add_line(f"long {t} = PyLong_AsLong({limit});")
                self._add_line("if (!_save) _save = PyEval_SaveThread();")
                limit = t
            elif not self.turbo and not self._is_raw_val(limit):
                t = self._get_temp(is_obj=False)
                self._add_line(f"long {t} = PyLong_AsLong({limit});")
                limit = t
            iv = node.target.id
            tx = self._get_temp(is_obj=False)
            self._add_line(f"for (long {tx} = 0; {tx} < (long){limit}; {tx}++) {{")
            self.indent += 1
            if iv in self.raw_types: self._add_line(f"{iv} = (double){tx};")
            else: self._add_line(f"py_{iv} = PyLong_FromLong({tx});")
            for s in node.body: self.visit(s)
            self.indent -= 1
            self._add_line("}")
        self.loop_depth -= 1

    def visit_If(self, node):
        test = self._visit_expr(node.test)
        if self.turbo and not self._is_raw_val(test):
            self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=False)
            self._add_line(f"int {t} = PyObject_IsTrue({test});")
            self._add_line("if (!_save) _save = PyEval_SaveThread();")
            test = t
        self._add_line(f"if ({test}) {{")
        self.indent += 1
        for s in node.body: self.visit(s)
        self.indent -= 1
        if node.orelse:
            self._add_line("} else {")
            self.indent += 1
            for s in node.orelse: self.visit(s)
            self.indent -= 1
        self._add_line("}")

    def visit_While(self, node):
        self.loop_depth += 1
        self._add_line(f"while (1) {{")
        self.indent += 1
        test = self._visit_expr(node.test)
        if self.turbo and not self._is_raw_val(test):
            self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=False)
            self._add_line(f"int {t} = PyObject_IsTrue({test});")
            self._add_line("if (!_save) _save = PyEval_SaveThread();")
            test = t
        self._add_line(f"if (!({test})) break;")
        for s in node.body: self.visit(s)
        self.indent -= 1
        self._add_line("}")
        self.loop_depth -= 1

    def visit_Break(self, node):
        # Handle cleanups if inside with. Break exits the current loop.
        # Cleanup any 'with' blocks that were entered inside THIS loop (depth >= current)
        if self.cleanup_stack:
            for cleanup, depth in reversed(self.cleanup_stack):
                if depth >= self.loop_depth:
                    self._add_line(cleanup)
                else:
                    break
        self._add_line("break;")

    def visit_Continue(self, node):
        # Continue jumps to start of current loop.
        # Cleanup 'with' blocks entered inside THIS loop.
        if self.cleanup_stack:
             for cleanup, depth in reversed(self.cleanup_stack):
                 if depth >= self.loop_depth:
                     self._add_line(cleanup)
                 else:
                     break
        self._add_line("continue;")

    def visit_Try(self, node):
        # Improved Try/Except with goto labels and exception binding
        label_id = self.temp_count
        self.temp_count += 1
        except_label = f"except_{label_id}"
        end_label = f"end_try_{label_id}"

        prev_error_label = self.error_label
        self.error_label = except_label

        self._add_line(f"// try {label_id}")
        for stmt in node.body:
             self.visit(stmt)

        self.error_label = prev_error_label
        self._add_line(f"goto {end_label};")

        self._add_line(f"{except_label}:")
        self._add_line("if (PyErr_Occurred()) {")
        self.indent += 1

        # We assume handlers are checked in order
        for handler in node.handlers:
            if handler.type:
                # Check type
                type_node = self._visit_expr(handler.type)
                self._add_line(f"if (PyErr_ExceptionMatches({type_node})) {{")
                self.indent += 1

                # If name is present, we must bind it
                if handler.name:
                    # To bind, we must fetch the exception
                    # Note: PyErr_Fetch clears the exception state!
                    self._add_line("PyObject *etype, *evalue, *etrace;")
                    self._add_line("PyErr_Fetch(&etype, &evalue, &etrace);")
                    self._add_line("PyErr_NormalizeException(&etype, &evalue, &etrace);")
                    # Bind to python variable
                    # bcc usually uses py_varname for PyObject*
                    self._add_line(f"PyObject* py_{handler.name} = evalue;")
                    self._add_line(f"Py_INCREF(py_{handler.name});")
                    # Cleanup fetched refs
                    self._add_line("Py_XDECREF(etype); Py_XDECREF(evalue); Py_XDECREF(etrace);")
                else:
                    self._add_line("PyErr_Clear();") # Just consume it

                for stmt in handler.body:
                    self.visit(stmt)
                self.indent -= 1
                self._add_line("} else")
            else:
                # Catch all
                self._add_line("{")
                self.indent += 1
                self._add_line("PyErr_Clear();")
                for stmt in handler.body:
                    self.visit(stmt)
                self.indent -= 1
                self._add_line("}")

        # If no handler matched, we fall through here.
        # If we didn't clear the exception, it propagates naturally!
        # C-API: If PyErr_Occurred() is true and we return NULL, it propagates.
        # But wait, we emitted "if (PyErr_Occurred()) { ... }".
        # If no handler matched, we exit that block.
        # Then we hit `end_label`.
        # At `end_label`, if PyErr_Occurred() is still true, we should return NULL to propagate.
        self._add_line("{ /* If not handled, we fall through with exception set */ }")

        self.indent -= 1
        self._add_line("}")
        self._add_line(f"if (PyErr_Occurred()) return NULL;") # Propagate unhandled
        self._add_line(f"{end_label}: ;")

    def visit_With(self, node):
        for item in node.items:
            ctx_expr = self._visit_expr(item.context_expr)
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")

            mgr_name = self._get_temp(is_obj=True)
            self._add_line(f"PyObject* {mgr_name} = {ctx_expr};")

            # Error check
            if self.error_label: self._add_line(f"if (!{mgr_name}) goto {self.error_label};")
            else: self._add_line(f"if (!{mgr_name}) return NULL;")

            # __enter__
            enter_res = self._get_temp(is_obj=True)
            self._add_line(f"PyObject* {enter_res} = PyObject_CallMethod({mgr_name}, \"__enter__\", NULL);")
            if self.error_label: self._add_line(f"if (!{enter_res}) goto {self.error_label};")
            else: self._add_line(f"if (!{enter_res}) return NULL;")

            if item.optional_vars:
                 if isinstance(item.optional_vars, ast.Name):
                     target_id = item.optional_vars.id
                     if target_id in self.raw_types:
                          rtype = self.raw_types[target_id]
                          if rtype == "double":
                              self._add_line(f"{target_id} = PyFloat_AsDouble({enter_res});")
                          else:
                              self._add_line(f"{target_id} = PyLong_AsLong({enter_res});")
                     else:
                          self._add_line(f"py_{target_id} = {enter_res};")
                          self._add_line(f"Py_INCREF(py_{target_id});")

            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")

            # Register cleanup
            cleanup_code = f"PyObject* exit_res_{mgr_name} = PyObject_CallMethod({mgr_name}, \"__exit__\", \"OOO\", Py_None, Py_None, Py_None); Py_XDECREF(exit_res_{mgr_name}); Py_DECREF({mgr_name}); Py_DECREF({enter_res});"
            self.cleanup_stack.append((cleanup_code, self.loop_depth))

            # Body
            for stmt in node.body:
                self.visit(stmt)

            # Pop cleanup and execute
            self.cleanup_stack.pop()
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            self._add_line(cleanup_code)
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")

    def visit_AugAssign(self, node):
        val = self._visit_expr(node.value)
        target = node.target
        if isinstance(target, ast.Name):
            op_map = {'Add':'+=','Sub':'-=','Mult':'*=','Div':'/=', 'BitAnd':'&=', 'BitOr':'|=', 'BitXor':'^=', 'LShift':'<<=', 'RShift':'>>=', 'Pow':'**=', 'FloorDiv':'//=', 'Mod':'%='}
            op = op_map.get(node.op.__class__.__name__, '+=')
            if target.id in self.raw_types:
                rtype = self.raw_types[target.id]
                if not self._is_raw_val(val):
                     self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                     t = self._get_temp(is_obj=False)
                     self.temp_types[t] = rtype
                     if rtype == "double":
                         self._add_line(f"double {t} = (PyFloat_Check({val}) ? PyFloat_AsDouble({val}) : (double)PyLong_AsLong({val}));")
                     else:
                         self._add_line(f"long {t} = PyLong_AsLong({val});")
                     self._add_line("if (!_save) _save = PyEval_SaveThread();")
                     val = t
                self._add_line(f"{target.id} {op} ({rtype}){val};")
            else:
                if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                t_obj = f"py_{target.id}"
                # Guess type of val for conversion back to object
                is_float = (val in self.temp_types and self.temp_types[val] == "double") or "." in val
                v_obj = val
                if self._is_raw_val(val):
                     v_obj = f"PyFloat_FromDouble((double){val})" if is_float else f"PyLong_FromLong((long){val})"

                api_op = {'Add':'PyNumber_InPlaceAdd','Sub':'PyNumber_InPlaceSubtract','Mult':'PyNumber_InPlaceMultiply','Div':'PyNumber_InPlaceTrueDivide', 'MatMult': 'PyNumber_InPlaceMatrixMultiply'}.get(node.op.__class__.__name__, 'PyNumber_InPlaceAdd')
                self._add_line(f"py_{target.id} = {api_op}({t_obj}, {v_obj});")
                if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
        elif isinstance(target, ast.Subscript):
            arr_name = target.value.id
            idx = self._visit_expr(target.slice)
            if arr_name in self.buffer_views:
                op_map = {'Add':'+=','Sub':'-=','Mult':'*=','Div':'/=', 'BitAnd':'&=', 'BitOr':'|=', 'BitXor':'^=', 'LShift':'<<=', 'RShift':'>>=', 'Pow':'**=', 'FloorDiv':'//=', 'Mod':'%='}
                op = op_map.get(node.op.__class__.__name__, '+=')
                v = self.buffer_views[arr_name]
                v_raw = val if self._is_raw_val(val) else f"(PyFloat_Check({val}) ? PyFloat_AsDouble({val}) : (double)PyLong_AsLong({val}))"
                if self.turbo and not self._is_raw_val(val):
                    self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    self._add_line(f"((double*){v}.buf)[(long){idx}] {op} (double){v_raw};")
                    self._add_line("if (!_save) _save = PyEval_SaveThread();")
                else:
                    self._add_line(f"((double*){v}.buf)[(long){idx}] {op} (double){v_raw};")

    def _is_raw_val(self, val):
        if val in self.raw_types: return True
        if val in self.temp_types and self.temp_types[val] in ("double", "long"): return True
        if val.replace(".","").replace("-","").isdigit(): return True
        # Track bitwise, comparison, math and logical ops as raw if they don't contain "Py"
        raw_markers = ['+', '-', '*', '/', '<', '>', '=', '&', '|', '^', '!', 'fabs', 'pow', '~', '%', '&&', '||',
                       'sin', 'cos', 'tan', 'sinh', 'cosh', 'tanh', 'exp', 'log', 'log10', 'sqrt', 'ceil', 'floor']
        if ("(" in val and ")" in val and any(op in val for op in raw_markers)) and "Py" not in val: return True
        return False

    def _visit_expr(self, node):
        if isinstance(node, ast.Constant):
            if isinstance(node.value, int): return str(node.value) if self.turbo else f"PyLong_FromLong({node.value})"
            if isinstance(node.value, float): return str(node.value) if self.turbo else f"PyFloat_FromDouble({node.value})"
            return "Py_None" if node.value is None else f"PyUnicode_FromString(\"{node.value}\")"
        elif isinstance(node, ast.Name): return node.id if node.id in self.raw_types else f"py_{node.id}"
        elif isinstance(node, ast.BinOp):
            l = self._visit_expr(node.left); r = self._visit_expr(node.right)
            op_name = node.op.__class__.__name__
            if self.turbo and self._is_raw_val(l) and self._is_raw_val(r):
                op_map = {'Add':'+','Sub':'-','Mult':'*','Div':'/', 'BitAnd':'&', 'BitOr':'|', 'BitXor':'^', 'LShift':'<<', 'RShift':'>>', 'Mod':'%', 'FloorDiv':'/'}
                if op_name in op_map:
                    op = op_map[op_name]
                    if op_name == 'Pow':
                        return f"pow((double){l}, (double){r})"
                    if op_name == 'FloorDiv':
                        return f"floor((double){l} / (double){r})"
                    if op_name in ('BitAnd', 'BitOr', 'BitXor', 'LShift', 'RShift', 'Mod'):
                        return f"((long){l} {op} (long){r})"
                    return f"({l} {op} {r})"
                # Fallthrough if op not supported in raw mode (e.g. MatMult)

            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=True)
            ops = {
                'Add':'PyNumber_Add', 'Sub':'PyNumber_Subtract', 'Mult':'PyNumber_Multiply',
                'Div':'PyNumber_TrueDivide', 'Pow':'PyNumber_Power', 'FloorDiv':'PyNumber_FloorDivide',
                'Mod':'PyNumber_Remainder', 'MatMult': 'PyNumber_MatrixMultiply',
                'BitAnd': 'PyNumber_And', 'BitOr': 'PyNumber_Or', 'BitXor': 'PyNumber_Xor',
                'LShift': 'PyNumber_Lshift', 'RShift': 'PyNumber_Rshift'
            }
            api_func = ops.get(op_name, 'PyNumber_Add')
            lo = l if not self._is_raw_val(l) else f"PyFloat_FromDouble((double){l})"
            ro = r if not self._is_raw_val(r) else f"PyFloat_FromDouble((double){r})"
            if api_func == 'PyNumber_Power': self._add_line(f"PyObject* {t} = {api_func}({lo}, {ro}, Py_None);")
            else: self._add_line(f"PyObject* {t} = {api_func}({lo}, {ro});")
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return t
        elif isinstance(node, ast.UnaryOp):
            v = self._visit_expr(node.operand)
            if self.turbo and self._is_raw_val(v):
                op_map = {'USub':'-', 'UAdd':'+', 'Not':'!', 'Invert':'~'}
                op = op_map.get(node.op.__class__.__name__, '-')
                if op == '~': return f"(~((long){v}))"
                return f"({op}{v})"
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=True)
            vo = v if not self._is_raw_val(v) else f"PyFloat_FromDouble((double){v})"
            ops = {'USub':'PyNumber_Negative', 'UAdd':'PyNumber_Positive', 'Not':'PyObject_Not', 'Invert':'PyNumber_Invert'}.get(node.op.__class__.__name__, 'PyNumber_Negative')
            if ops == 'PyObject_Not': self._add_line(f"PyObject* {t} = {ops}({vo}) ? Py_True : Py_False; Py_XINCREF({t});")
            else: self._add_line(f"PyObject* {t} = {ops}({vo});")
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return t
        elif isinstance(node, ast.BoolOp):
            # Short-circuiting is hard in C expressions, so we use temp vars
            t = self._get_temp(is_obj=self.turbo) # Use obj for bool op result if not handled as raw
            op = "&&" if isinstance(node.op, ast.And) else "||"
            vals = [self._visit_expr(v) for v in node.values]
            if self.turbo and all(self._is_raw_val(v) for v in vals):
                return "(" + f" {op} ".join([f"(int)({v})" for v in vals]) + ")"
            # Fallback to PyObject approach if any is complex
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            rt = self._get_temp(is_obj=True)
            self._add_line(f"PyObject* {rt} = {vals[0] if not self._is_raw_val(vals[0]) else f'PyFloat_FromDouble((double){vals[0]})'};")
            for v in vals[1:]:
                cond = f"PyObject_IsTrue({rt})"
                if isinstance(node.op, ast.And): self._add_line(f"if ({cond}) {{ {rt} = {v if not self._is_raw_val(v) else f'PyFloat_FromDouble((double){v})'}; }}")
                else: self._add_line(f"if (!{cond}) {{ {rt} = {v if not self._is_raw_val(v) else f'PyFloat_FromDouble((double){v})'}; }}")
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return rt
        elif isinstance(node, ast.Compare):
            l = self._visit_expr(node.left); r = self._visit_expr(node.comparators[0])
            op_name = node.ops[0].__class__.__name__
            if self.turbo and self._is_raw_val(l) and self._is_raw_val(r):
                op_map = {'Lt':'<', 'LtE':'<=', 'Gt':'>', 'GtE':'>=', 'Eq':'==', 'NotEq':'!='}
                if op_name in op_map:
                    op = op_map[op_name]
                    return f"({l} {op} {r})"

            # Object comparison
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=False)
            lo = l if not self._is_raw_val(l) else f"PyFloat_FromDouble((double){l})"
            ro = r if not self._is_raw_val(r) else f"PyFloat_FromDouble((double){r})"

            if op_name == 'In':
                self._add_line(f"int {t} = PySequence_Contains({ro}, {lo});") # Note: In(a, b) -> b contains a
            elif op_name == 'NotIn':
                self._add_line(f"int {t} = !PySequence_Contains({ro}, {lo});")
            elif op_name == 'Is':
                self._add_line(f"int {t} = ({lo} == {ro});")
            elif op_name == 'IsNot':
                self._add_line(f"int {t} = ({lo} != {ro});")
            else:
                op_map = {'Lt':'Py_LT', 'LtE':'Py_LE', 'Gt':'Py_GT', 'GtE':'Py_GE', 'Eq':'Py_EQ', 'NotEq':'Py_NE'}
                op = op_map.get(op_name, 'Py_EQ')
                self._add_line(f"int {t} = PyObject_RichCompareBool({lo}, {ro}, {op});")

            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return t
        elif isinstance(node, ast.Subscript):
            an = node.value.id; idx = self._visit_expr(node.slice)
            if an in self.buffer_views:
                if self.turbo and not self._is_raw_val(idx):
                    self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }"); t = self._get_temp(is_obj=False)
                    self._add_line(f"long {t} = PyLong_AsLong({idx})"); self._add_line("if (!_save) _save = PyEval_SaveThread();"); idx = t
                return f"((double*){self.buffer_views[an]}.buf)[(long){idx}]"
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=True); io = idx if not self._is_raw_val(idx) else f"PyLong_FromLong((long){idx})"
            self._add_line(f"PyObject* {t} = PyObject_GetItem(py_{an}, {io});")
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return t
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id == 'len':
                    an = node.args[0].id
                    if an in self.buffer_views: return f"(double)({self.buffer_views[an]}.len / sizeof(double))"
                    if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    tx = self._get_temp(is_obj=False)
                    self._add_line(f"long {tx} = PyObject_Length(py_{an});")
                    if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    return tx if self.turbo else f"PyLong_FromLong({tx})"
                elif node.func.id in ('int', 'float', 'abs'):
                    arg = self._visit_expr(node.args[0])
                    if self.turbo and self._is_raw_val(arg):
                        if node.func.id == 'abs': return f"fabs((double){arg})"
                        return arg
                    if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    t = self._get_temp(is_obj=True)
                    ao = arg if not self._is_raw_val(arg) else f"PyFloat_FromDouble((double){arg})"
                    if node.func.id == 'abs': self._add_line(f"PyObject* {t} = PyNumber_Absolute({ao});")
                    elif node.func.id == 'int': self._add_line(f"PyObject* {t} = PyNumber_Long({ao});")
                    elif node.func.id == 'float': self._add_line(f"PyObject* {t} = PyNumber_Float({ao});")
                    if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    return t
                elif node.func.id in ('min', 'max') and len(node.args) == 2:
                    l = self._visit_expr(node.args[0]); r = self._visit_expr(node.args[1])
                    if self.turbo and self._is_raw_val(l) and self._is_raw_val(r):
                        op = ">" if node.func.id == 'max' else "<"
                        return f"(({l} {op} {r}) ? {l} : {r})"
                    if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    t = self._get_temp(is_obj=True)
                    lo = l if not self._is_raw_val(l) else f"PyFloat_FromDouble((double){l})"
                    ro = r if not self._is_raw_val(r) else f"PyFloat_FromDouble((double){r})"
                    # min/max of two args is just a comparison
                    cmp_op = 'Py_GT' if node.func.id == 'max' else 'Py_LT'
                    self._add_line(f"PyObject* {t} = PyObject_RichCompareBool({lo}, {ro}, {cmp_op}) ? {lo} : {ro}; Py_XINCREF({t});")
                    if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    return t
            elif isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'math':
                # Handle math.xxx(arg)
                func_name = node.func.attr
                # Map to standard C math functions
                # Allowed: sin, cos, tan, asin, acos, atan, sinh, cosh, tanh, exp, log, log10, sqrt, ceil, floor, fabs
                if func_name in ('sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh', 'exp', 'log', 'log10', 'sqrt', 'ceil', 'floor', 'fabs'):
                    arg = self._visit_expr(node.args[0])
                    if self.turbo and self._is_raw_val(arg):
                         return f"{func_name}((double){arg})"
                    if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
                    t = self._get_temp(is_obj=True)
                    ao = arg if not self._is_raw_val(arg) else f"PyFloat_FromDouble((double){arg})"
                    self._add_line(f"double v_arg = PyFloat_AsDouble({ao});")
                    self._add_line(f"double v_res = {func_name}(v_arg);")
                    self._add_line(f"PyObject* {t} = PyFloat_FromDouble(v_res);")
                    if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
                    return t
        elif isinstance(node, (ast.List, ast.Tuple)):
            is_list = isinstance(node, ast.List)
            if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
            t = self._get_temp(is_obj=True)
            self._add_line(f"PyObject* {t} = {'PyList_New' if is_list else 'PyTuple_New'}({len(node.elts)});")
            for i, e in enumerate(node.elts):
                v = self._visit_expr(e); vo = v if not self._is_raw_val(v) else f"PyFloat_FromDouble((double){v})"
                self._add_line(f"{'PyList_SetItem' if is_list else 'PyTuple_SetItem'}({t}, {i}, {vo});")
            if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
            return t
        elif isinstance(node, ast.Dict):
             if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
             t = self._get_temp(is_obj=True)
             self._add_line(f"PyObject* {t} = PyDict_New();")
             for k, v in zip(node.keys, node.values):
                 if k:
                     ko = self._visit_expr(k); vo = self._visit_expr(v)
                     if self._is_raw_val(ko): ko = f"PyFloat_FromDouble((double){ko})"
                     if self._is_raw_val(vo): vo = f"PyFloat_FromDouble((double){vo})"
                     self._add_line(f"PyDict_SetItem({t}, {ko}, {vo});")
                     self._add_line(f"Py_DECREF({ko}); Py_DECREF({vo});")
             if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
             return t
        elif isinstance(node, ast.Set):
             if self.turbo: self._add_line("if (_save) { PyEval_RestoreThread(_save); _save = NULL; }")
             t = self._get_temp(is_obj=True)
             self._add_line(f"PyObject* {t} = PySet_New(NULL);")
             for e in node.elts:
                 v = self._visit_expr(e)
                 if self._is_raw_val(v): v = f"PyFloat_FromDouble((double){v})"
                 self._add_line(f"PySet_Add({t}, {v});")
                 self._add_line(f"Py_DECREF({v});")
             if self.turbo: self._add_line("if (!_save) _save = PyEval_SaveThread();")
             return t
        return "Py_None"

def generate_c_source(module_name, functions, turbo=False):
    gen = CGenerator(module_name, turbo=turbo); gen.c_code.append("#define PY_SSIZE_T_CLEAN\n#include <Python.h>\n#include <math.h>")
    for f in functions:
        if isinstance(f, tuple): gen.generate(f[1], original_name=f[0])
        else: gen.generate(f)
    ml = [f'{{"{fn}", (PyCFunction)bcc_{fn}, METH_VARARGS | METH_KEYWORDS, NULL}}' for fn in gen.functions]
    gen.c_code.append("static PyMethodDef BCCMethods[] = {\n    " + ",\n    ".join(ml) + ",\n    {NULL, NULL, 0, NULL}\n};\n")
    gen.c_code.append(f"static struct PyModuleDef bcc_m = {{PyModuleDef_HEAD_INIT, \"{module_name}\", NULL, -1, BCCMethods}};\nPyMODINIT_FUNC PyInit_{module_name}(void) {{return PyModule_Create(&bcc_m);}}")
    return "\n".join(gen.c_code)
