"""Glyphs Plugins management module"""
