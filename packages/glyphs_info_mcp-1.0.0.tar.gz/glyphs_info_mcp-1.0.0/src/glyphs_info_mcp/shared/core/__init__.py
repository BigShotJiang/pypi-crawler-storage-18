"""
Shared Core Library
"""
