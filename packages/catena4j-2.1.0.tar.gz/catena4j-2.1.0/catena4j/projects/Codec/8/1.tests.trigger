org.apache.commons.codec.binary.Base64InputStreamTest::testCodec105
