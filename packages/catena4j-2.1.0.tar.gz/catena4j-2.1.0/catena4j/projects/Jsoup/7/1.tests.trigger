org.jsoup.nodes.DocumentTest::testNormalisesStructure
