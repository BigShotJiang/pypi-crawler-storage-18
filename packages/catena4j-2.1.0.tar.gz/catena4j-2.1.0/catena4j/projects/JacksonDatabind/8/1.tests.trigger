com.fasterxml.jackson.databind.deser.TestJdkTypes::testStringBuilder
