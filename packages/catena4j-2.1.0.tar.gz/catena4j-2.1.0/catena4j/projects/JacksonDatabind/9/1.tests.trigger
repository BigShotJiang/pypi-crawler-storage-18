com.fasterxml.jackson.databind.ser.TestMapSerialization::testClassKey
