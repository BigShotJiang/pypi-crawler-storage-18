com.fasterxml.jackson.databind.deser.TestJDKAtomicTypes::testEmpty1256
