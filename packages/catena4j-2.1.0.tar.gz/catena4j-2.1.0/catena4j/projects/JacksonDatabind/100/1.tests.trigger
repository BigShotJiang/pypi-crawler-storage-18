com.fasterxml.jackson.databind.node.TestConversions::testBase64Text$catena_4
