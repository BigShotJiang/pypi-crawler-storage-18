org.apache.commons.cli.ParseRequiredTest::testReuseOptionsTwice
