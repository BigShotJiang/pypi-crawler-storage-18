org.apache.commons.cli.bug.BugCLI266Test::testOptionComparatorInsertedOrder
