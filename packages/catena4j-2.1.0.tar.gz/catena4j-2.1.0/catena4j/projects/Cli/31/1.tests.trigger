org.apache.commons.cli.HelpFormatterTest::testDefaultArgName
