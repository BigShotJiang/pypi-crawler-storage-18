org.apache.commons.cli.BasicParserTest::testOptionGroupLong
org.apache.commons.cli.GnuParserTest::testOptionGroupLong
org.apache.commons.cli.PosixParserTest::testOptionGroupLong
