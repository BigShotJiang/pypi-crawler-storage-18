org.apache.commons.jxpath.ri.compiler.JXPath149Test::testComplexOperationWithVariables
