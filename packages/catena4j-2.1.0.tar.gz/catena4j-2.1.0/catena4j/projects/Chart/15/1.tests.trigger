org.jfree.chart.plot.junit.PiePlot3DTests::testDrawWithNullDataset
