# Arzule MVP

## **Core Mission**

> Turn broken multi-agent traces into corrected trajectories that agents can learn from — including missing steps.
> 

Not observability.

Not dashboards.

Not consulting.

A **Correction Loop that outputs training data.**

---

# 🎯 **PRODUCT COMPONENTS (V1)**

### **1️⃣ Ingestion SDK (Ear)**

**Goal:** Capture only what’s needed to reconstruct & correct reasoning.

**Build:**

- Python + TS wrapper around LLM/tool calls
- Hooks for agent → agent handoffs
- Minimal state snapshots (tool I/O, key variables)
- Provenance metadata: “who believed what, when”

**Captures:**

- Prompt → Output
- Tool/DB/API response
- Environment snapshot (only accessed keys)
- Handoff lineage (sender/recipient state)

**Deliverable:**

```tsx
import { arzule }from"arzule";
arzule.wrap(agent).run(task);

```

**Design for insertion:** store each step as a `node`, not just a log line.

---

### **2️⃣ Forensic Engine (Brain)**

**Goal:** Identify *where* the workflow broke and *what type of failure it is.*

**Detects 8 failure classes:**

- HandoffMismatch
- ContextDrift
- StaleAssumption
- CircularDelegation
- BrokenVerificationGate
- StateDesync
- MissingOwnership
- InvalidToolHandoff

**Output:**

```json
{
"break_node":"n14",
"failure_type":"HandoffMismatch",
"root_cause":"Agent B relied on unverified state from Agent A"
}

```

---

### **3️⃣ Patch Architect (Fix Factory)**

**Goal:** Generate a “Golden Trace” — including insertion of missing steps.

Supports these ops:

- `INSERT_BEFORE`
- `INSERT_AFTER`
- `MODIFY_NODE`
- (later) `DELETE_NODE`, `SPLIT_NODE`

**Example:**

```json
{
"trace_id":"abc123",
"operations":[
{
"op":"INSERT_BEFORE",
"target_node_id":"n14",
"new_node":{
"id":"n13_5",
"type":"agent_call",
"role":"VerifierAgent",
"synthetic":true,
"description":"Verify customer_id exists before delegation",
"input_state":"state_after_n13",
"output_state":"verified_state"
}
},
{
"op":"MODIFY_NODE",
"target_node_id":"n14",
"patch":{
"expected_input_state":"verified_state"
}
}
]
}

```

**This is the leap:**

Not advice → **corrected, runnable training data.**

---

### **4️⃣ Confirmation Loop UI (Data Moat)**

**Goal:** Human approves → it becomes supervised training signal.

**UI Actions:**

- See broken vs patched
- Approve / Edit / Reject
- Each approval = new labeled example

This is how Arzule becomes the “New Mercor”:

**every correction becomes proprietary data.**

---

# 🧩 **ARCHITECTURE SUMMARY**

```
[SDK: Ear]
     ↓
[Forensics: Brain]
     ↓
[Patch Architect: Fix Factory]
     ↓
[Confirmation UI: Human Loop]
     ↓
[Golden Trace → Training Asset]
          ↑
   Continuous Feedback

```

This is the entire company.

---

# 💰 **HOW TO PRICE IT**

**Don’t sell seats. Don’t sell logs. Sell improved behavior.**

| Tier | What They Pay For |
| --- | --- |
| Pilot ($30K–$75K) | 50–250 corrected trajectories |
| Platform ($150K–$400K/yr) | Unlimited ingestion + SFT export + support |
| Per Correction ($1.50–$12) | Usage pricing tied to *corrected, approved patches* |

This makes you look like **Mercor/Scale**, not Datadog.

---

# 🎯 **ICP — WHO TO SELL FIRST**

**Target: Teams who *feel* coordination pain.**

| Buyer Segment | Why They Pay |
| --- | --- |
| AI labs w/ agent orchestration | Need reliability + fix failure surfaces |
| Enterprise automation teams | Compliance, repeatability, handoff clarity |
| RPA replacements | Scripts → agents → breakage → liability |
| Agent infra startups | Want defensibility + differentiation |

**Do NOT sell to:** single-agent projects, prompt tools, hobbyists.

---

# 🗣️ **POSITIONING & MESSAGING**

### One-Liner

> Arzule turns agent failures into corrective training data.
Failure In → Golden Trace Out.
> 

### Cold Outbound Opener

> “You are throwing away the most valuable data you have.
> 
> 
> Arzule converts failed agent runs into synthetic training data that prevents the same failure twice.”
> 

### Homepage Hero

> Your agents are failing.
Arzule turns those failures into fuel.
> 

---

# 🚀 **6-WEEK EXECUTION PLAN**

### **Wk 1–2**

- Ship SDK (wrap calls + capture state snapshots)
- Define JSON schema for `Node` + `PatchOperation`
- Ingest open-source traces to validate detection

### **Wk 3–4**

- Forensic Engine v1 (classification + break_node detection)
- Patch Architect w/ `INSERT_*` support for missing steps
- Basic UI for approve/edit → store supervised examples

### **Wk 5**

- Run 1 design partner
- Aim for 100+ corrected trajectories
- Iterate taxonomy based on real failure patterns

### **Wk 6**

- Finalize pricing
- Outreach to 20 target enterprise accounts
- Publish “Correction Loop” demo + case study

Now you are selling **real outcomes**, not “we’re building something.”

---

# 🏁 **TAGLINE**

> Arzule: The Correction Loop for Multi-Agent Systems.
Not observability. Not evals. Corrections.
>