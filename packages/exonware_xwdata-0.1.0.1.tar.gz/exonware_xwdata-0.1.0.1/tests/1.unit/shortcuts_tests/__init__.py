"""
Shortcuts tests package.
"""

