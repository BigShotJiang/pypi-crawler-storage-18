"""
Metadata tests package.
"""

