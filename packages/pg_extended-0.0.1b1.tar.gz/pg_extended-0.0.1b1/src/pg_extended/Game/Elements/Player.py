
class Player:
  pass
