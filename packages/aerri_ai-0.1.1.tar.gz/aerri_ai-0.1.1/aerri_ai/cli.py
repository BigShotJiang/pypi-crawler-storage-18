import os
import subprocess
import json
from pathlib import Path
from datetime import datetime
from langchain_groq import ChatGroq
from langchain.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from typing import Annotated, TypedDict
import operator

import random
import time
import threading
import sys

# Loading animation
class LoadingAnimation:
    def __init__(self, message="Processing"):
        self.message = message
        self.running = False
        self.thread = None
        
    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._animate)
        self.thread.start()
        
    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        print(f"\r{' ' * 50}\r", end="")  # Clear line
        
    def _animate(self):
        chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while self.running:
            print(f"\r{PURPLE}{chars[i % len(chars)]} {self.message}...{RESET}", end="", flush=True)
            time.sleep(0.1)
            i += 1

# Fun messages and jokes
TOOL_MESSAGES = [
    "🔍 Looking for files like a detective...",
    "📝 Writing code faster than you can say 'bug'...",
    "🗑️ Deleting files (don't worry, I'm careful)...",
    "🏃‍♂️ Running code at lightning speed...",
    "📂 Listing files like a librarian...",
    "🧠 Accessing my memory banks...",
    "🔧 Explaining changes like a professor..."
]

JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
    "How many programmers does it take to change a light bulb? None, that's a hardware problem! 💡",
    "Why do Java developers wear glasses? Because they can't C# 👓",
    "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?' 🍺",
    "Why did the programmer quit his job? He didn't get arrays! 📊"
]

def get_tool_message(tool_name):
    messages = {
        "read_file": "🔍 Reading file contents...",
        "write_file": "📝 Writing magical code...",
        "delete_file": "🗑️ Deleting file (carefully!)...",
        "run_code": "🏃‍♂️ Executing code...",
        "list_files": "📂 Scanning directory...",
        "get_memory": "🧠 Accessing memory...",
        "explain_changes": "🔧 Analyzing changes..."
    }
    return messages.get(tool_name, f"🔧 Using {tool_name}...")

# ANSI color codes for purple styling
PURPLE = '\033[95m'
BOLD = '\033[1m'
RESET = '\033[0m'
CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'

def print_purple(text):
    print(f"{PURPLE}{BOLD}{text}{RESET}")

def print_cyan(text):
    print(f"{CYAN}{text}{RESET}")

def print_green(text):
    print(f"{GREEN}{text}{RESET}")

def print_yellow(text):
    print(f"{YELLOW}{text}{RESET}")

# Memory functions
MEMORY_FILE = ".copilot_memory.json"

def load_memory():
    """Load workspace memory from file."""
    if Path(MEMORY_FILE).exists():
        return json.loads(Path(MEMORY_FILE).read_text())
    return {"sessions": [], "files_modified": {}}

def save_memory(memory):
    """Save workspace memory to file."""
    Path(MEMORY_FILE).write_text(json.dumps(memory, indent=2))

def add_to_memory(task, files_touched):
    """Add current session to memory."""
    memory = load_memory()
    memory["sessions"].append({
        "timestamp": datetime.now().isoformat(),
        "task": task,
        "files": files_touched
    })
    for file in files_touched:
        memory["files_modified"][file] = datetime.now().isoformat()
    save_memory(memory)

# Initialize LLM
llm = ChatGroq(
    api_key=os.environ.get("GROQ_API_KEY"),
    model="openai/gpt-oss-120b",
    temperature=0.1
)

# Tools
@tool
def read_file(file_path: str) -> str:
    """Read content of a file."""
    try:
        return Path(file_path).read_text()
    except Exception as e:
        return f"Error reading file: {e}"

@tool
def write_file(file_path: str, content: str) -> str:
    """Create or overwrite a file with content."""
    try:
        # Check if file exists to compare changes
        old_content = ""
        if Path(file_path).exists():
            old_content = Path(file_path).read_text()
        
        Path(file_path).write_text(content)
        
        # Auto-explain line changes if file was modified
        if old_content and old_content != content:
            old_lines = old_content.splitlines()
            new_lines = content.splitlines()
            
            changes = []
            max_lines = max(len(old_lines), len(new_lines))
            
            for i in range(max_lines):
                old_line = old_lines[i] if i < len(old_lines) else ""
                new_line = new_lines[i] if i < len(new_lines) else ""
                
                if old_line != new_line:
                    if not old_line:
                        changes.append(f"+ Line {i+1}: {new_line}")
                    elif not new_line:
                        changes.append(f"- Line {i+1}: {old_line}")
                    else:
                        changes.append(f"~ Line {i+1}: {old_line} → {new_line}")
            
            change_summary = "\n".join(changes[:5])  # Show first 5 changes
            if len(changes) > 5:
                change_summary += f"\n... and {len(changes)-5} more changes"
                
            return f"✅ File '{file_path}' updated successfully\n\n📝 Changes made:\n{change_summary}"
        else:
            return f"✅ File '{file_path}' created successfully"
    except Exception as e:
        return f"Error writing file: {e}"

@tool
def explain_changes(file_path: str) -> str:
    """Explain what changes were made to a file and why."""
    memory = load_memory()
    if not memory["sessions"]:
        return "No previous changes found in memory."
    
    # Find recent sessions that modified this file
    recent_changes = []
    for session in reversed(memory["sessions"][-5:]):  # Last 5 sessions
        if file_path in session.get("files", []):
            recent_changes.append(f"• {session['timestamp'][:16]}: {session['task']}")
    
    if recent_changes:
        return f"📝 Recent changes to {file_path}:\n" + "\n".join(recent_changes) + "\n\n💡 Ask me 'why did you change X?' for specific explanations"
    else:
        return f"No recent changes found for {file_path}"

@tool
def get_memory() -> str:
    """Get workspace memory of previous sessions and file modifications."""
    memory = load_memory()
    if not memory["sessions"]:
        return "No previous sessions found."
    
    recent = memory["sessions"][-3:]  # Last 3 sessions
    result = "📝 Recent workspace activity:\n"
    for session in recent:
        result += f"• {session['timestamp'][:16]}: {session['task']}\n"
        if session['files']:
            result += f"  Files: {', '.join(session['files'])}\n"
    return result

@tool
def delete_file(file_path: str) -> str:
    """Delete a file."""
    try:
        Path(file_path).unlink()
        return f"✅ File '{file_path}' deleted successfully"
    except Exception as e:
        return f"Error deleting file: {e}"

@tool
def run_code(file_path: str) -> str:
    """Execute Python file and return output or errors."""
    try:
        result = subprocess.run(['python3', file_path], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"✅ Output:\n{result.stdout}"
        else:
            return f"❌ Error detected:\n{result.stderr}\n🔧 Auto-fixing enabled - will attempt repair"
    except Exception as e:
        return f"Execution error: {e}"

@tool
def list_files(directory: str = ".") -> str:
    """List files in directory."""
    try:
        files = [f.name for f in Path(directory).iterdir() if f.is_file()]
        return f"Files: {', '.join(files)}"
    except Exception as e:
        return f"Error listing files: {e}"

tools = [read_file, write_file, delete_file, run_code, list_files, get_memory, explain_changes]
llm_with_tools = llm.bind_tools(tools)

# State
class CopilotState(TypedDict):
    messages: Annotated[list[BaseMessage], operator.add]
    task: str
    files_touched: list

# Agent
def copilot_agent(state: CopilotState):
    try:
        memory = load_memory()
        context = ""
        if memory["sessions"]:
            context = f"\n\nWorkspace context: Recently worked on {len(memory['sessions'])} tasks. Use get_memory() for details."
        
        system_msg = SystemMessage(content=(
            "You are Aerri-AI - an advanced AI coding assistant. "
            "I can read, write, edit, delete files and fix errors. "
            "I explain each step I take and why. "
            "When I see runtime errors, I automatically analyze and fix them. "
            "After editing files, I automatically explain what changed and why. "
            "I have persistent memory of previous sessions - check get_memory() when relevant. "
            "Task: " + state['task'] + context
        ))
        
        if not state.get("messages"):
            user_msg = HumanMessage(content=state['task'])
            msgs = [system_msg, user_msg]
        else:
            msgs = [system_msg] + state["messages"]
        
        response = llm_with_tools.invoke(msgs)
        
        # Track files touched
        files_touched = state.get("files_touched", [])
        if response.tool_calls:
            for call in response.tool_calls:
                if call.get("name") in ["write_file", "delete_file", "run_code"]:
                    try:
                        args = json.loads(call.get("args", "{}"))
                        file_path = args.get("file_path")
                        if file_path and file_path not in files_touched:
                            files_touched.append(file_path)
                    except:
                        pass
        
        return {"messages": [response], "files_touched": files_touched}
        
    except Exception as e:
        error_msg = str(e).lower()
        
        if "rate limit" in error_msg or "quota" in error_msg:
            error_response = HumanMessage(content="⚠️ I've reached my API rate limit. Please wait a moment and try again, or consider upgrading your plan for higher limits.")
        elif "token" in error_msg and ("limit" in error_msg or "exceeded" in error_msg):
            error_response = HumanMessage(content="⚠️ The conversation has become too long for me to process. Please start a new session or try a shorter request.")
        elif "connection" in error_msg or "timeout" in error_msg:
            error_response = HumanMessage(content="⚠️ I'm having trouble connecting to my AI service. Please check your internet connection and try again.")
        elif "authentication" in error_msg or "api key" in error_msg:
            error_response = HumanMessage(content="⚠️ There's an issue with my API credentials. Please check the configuration and try again.")
        else:
            error_response = HumanMessage(content=f"⚠️ I encountered an unexpected error: {str(e)[:100]}... Please try again or restart the session.")
        
        return {"messages": [error_response], "files_touched": state.get("files_touched", [])}

tool_node = ToolNode(tools)

# Graph
def should_continue(state: CopilotState):
    last_msg = state["messages"][-1]
    if last_msg.tool_calls:
        return "tools"
    # Check if last tool result contains error and auto-fix
    if len(state["messages"]) >= 2:
        tool_result = state["messages"][-1]
        if hasattr(tool_result, 'content') and "❌ Error detected:" in str(tool_result.content):
            return "agent"  # Continue to agent for auto-fix
    return END

workflow = StateGraph(CopilotState)
workflow.add_node("agent", copilot_agent)
workflow.add_node("tools", tool_node)
workflow.set_entry_point("agent")
workflow.add_conditional_edges("agent", should_continue)
workflow.add_edge("tools", "agent")

app = workflow.compile()

def main():
    try:
        print_purple("""
 █████╗ ███████╗██████╗ ██████╗ ██╗      █████╗ ██╗
██╔══██╗██╔════╝██╔══██╗██╔══██╗██║     ██╔══██╗██║
███████║█████╗  ██████╔╝██████╔╝██║     ███████║██║
██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║     ██╔══██║██║
██║  ██║███████╗██║  ██║██║  ██║██║     ██║  ██║██║
╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝
        """)
        print_cyan("        Advanced AI Coding Assistant")
        print_cyan("    I can create, edit, delete files and fix errors!")
        print_cyan("    💡 Tip: Ask 'why' or 'how' after any action for explanations")
        print_purple("=" * 60)
        
        while True:
            try:
                task = input(f"\n{PURPLE}{BOLD}What would you like me to do?{RESET} (or 'quit' to exit): ")
                
                if task.lower() in ['quit', 'exit', 'q']:
                    break
                    
                initial_state = {"task": task, "messages": [], "files_touched": []}
                
                print_yellow("\n--- Working ---\n")
                
                files_touched = []
                last_action = ""
                
                # Start thinking animation
                thinking = LoadingAnimation("🧠 Thinking")
                thinking.start()
                
                try:
                    for output in app.stream(initial_state):
                        thinking.stop()  # Stop thinking when we get output
                        
                        try:
                            for key, value in output.items():
                                if key == "agent" and "messages" in value:
                                    msg = value["messages"][-1]
                                    if hasattr(msg, 'content') and msg.content:
                                        print_purple(f"🤖 Aerri-AI: {msg.content}")
                                        last_action = msg.content
                                    # Show tool calls with fun messages and loading
                                    if hasattr(msg, 'tool_calls') and msg.tool_calls:
                                        for call in msg.tool_calls:
                                            tool_name = call.get('function', {}).get('name', 'unknown')
                                            print_yellow(f"🔧 {get_tool_message(tool_name)}")
                                            
                                            # Start tool loading animation
                                            tool_loading = LoadingAnimation(f"Executing {tool_name}")
                                            tool_loading.start()
                                            time.sleep(0.5)  # Brief pause for effect
                                            tool_loading.stop()
                                            
                                            if random.random() < 0.3:  # 30% chance for joke
                                                print_cyan(f"😄 {random.choice(JOKES)}")
                                    if "files_touched" in value:
                                        files_touched = value["files_touched"]
                                elif key == "tools" and "messages" in value:
                                    msg = value["messages"][-1]
                                    print_green(f"✅ {msg.content}")
                                    if random.random() < 0.2:  # 20% chance for celebration
                                        print_cyan("🎉 Another task conquered!")
                                    
                                    # Start thinking again for next iteration
                                    thinking = LoadingAnimation("🧠 Processing results")
                                    thinking.start()
                        except KeyboardInterrupt:
                            thinking.stop()
                            print_purple("\n\n👋 Goodbye from Aerri-AI!")
                            exit(0)
                    
                    thinking.stop()  # Make sure to stop final animation
                except KeyboardInterrupt:
                    thinking.stop()
                    print_purple("\n\n👋 Goodbye from Aerri-AI!")
                    exit(0)
                
                # Save to memory
                if files_touched:
                    add_to_memory(task, files_touched)
                
                print_green("\n✅ Task completed!")
                
                # Interactive follow-up
                while True:
                    try:
                        follow_up = input(f"\n{CYAN}❓ Ask 'why', 'how', or continue with new task (press Enter): {RESET}").strip()
                        
                        if not follow_up:
                            break
                        elif follow_up.lower() in ['why', 'how', 'explain']:
                            explanation_state = {
                                "task": f"Explain {follow_up} you performed the previous action: {last_action}",
                                "messages": [],
                                "files_touched": []
                            }
                            
                            print_yellow("\n--- Explaining ---\n")
                            
                            explaining = LoadingAnimation("🤔 Analyzing")
                            explaining.start()
                            
                            try:
                                for output in app.stream(explanation_state):
                                    explaining.stop()
                                    try:
                                        for key, value in output.items():
                                            if key == "agent" and "messages" in value:
                                                msg = value["messages"][-1]
                                                if hasattr(msg, 'content') and msg.content:
                                                    print_purple(f"🤖 Explanation: {msg.content}")
                                            elif key == "tools" and "messages" in value:
                                                msg = value["messages"][-1]
                                                print_green(f"✅ {msg.content}")
                                            explaining = LoadingAnimation("🤔 Continuing analysis")
                                            explaining.start()
                                    except KeyboardInterrupt:
                                        explaining.stop()
                                        raise
                                explaining.stop()
                            except KeyboardInterrupt:
                                explaining.stop()
                                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                                exit(0)
                        else:
                            # Treat as new task directly
                            new_state = {"task": follow_up, "messages": [], "files_touched": []}
                            print_yellow("\n--- Working ---\n")
                            
                            working = LoadingAnimation("🧠 Processing new task")
                            working.start()
                            
                            try:
                                for output in app.stream(new_state):
                                    working.stop()
                                    try:
                                        for key, value in output.items():
                                            if key == "agent" and "messages" in value:
                                                msg = value["messages"][-1]
                                                if hasattr(msg, 'content') and msg.content:
                                                    print_purple(f"🤖 Aerri-AI: {msg.content}")
                                                    last_action = msg.content
                                                if hasattr(msg, 'tool_calls') and msg.tool_calls:
                                                    for call in msg.tool_calls:
                                                        tool_name = call.get('function', {}).get('name', 'unknown')
                                                        print_yellow(f"🔧 {get_tool_message(tool_name)}")
                                                        
                                                        tool_loading = LoadingAnimation(f"Executing {tool_name}")
                                                        tool_loading.start()
                                                        time.sleep(0.3)
                                                        tool_loading.stop()
                                                        
                                                        if random.random() < 0.3:
                                                            print_cyan(f"😄 {random.choice(JOKES)}")
                                                if "files_touched" in value:
                                                    files_touched.extend(value["files_touched"])
                                            elif key == "tools" and "messages" in value:
                                                msg = value["messages"][-1]
                                                print_green(f"✅ {msg.content}")
                                            working = LoadingAnimation("🧠 Continuing work")
                                            working.start()
                                    except KeyboardInterrupt:
                                        working.stop()
                                        raise
                                working.stop()
                                print_green("\n✅ Task completed!")
                            except KeyboardInterrupt:
                                working.stop()
                                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                                exit(0)
                            
                            # Save new task to memory
                            if files_touched:
                                add_to_memory(follow_up, files_touched)
                    except KeyboardInterrupt:
                        print_purple("\n\n👋 Goodbye from Aerri-AI!")
                        exit(0)
                        
            except KeyboardInterrupt:
                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                exit(0)
            except Exception as e:
                print_yellow(f"\n❌ Error: {e}")
                continue
        
        print_purple("\n👋 Goodbye from Aerri-AI!")
        
    except KeyboardInterrupt:
        print_purple("\n\n👋 Goodbye from Aerri-AI!")
    except Exception as e:
        print_yellow(f"\n❌ Unexpected error: {e}")
        print_purple("👋 Goodbye from Aerri-AI!")

if __name__ == "__main__":
    main()
