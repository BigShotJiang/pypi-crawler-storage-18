# Aerri-AI

Aerri-AI is an advanced AI coding assistant CLI tool.  
It can read, write, edit, delete files, and fix errors using LLMs like Groq.
