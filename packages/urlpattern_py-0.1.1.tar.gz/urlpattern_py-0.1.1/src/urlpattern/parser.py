"""
Tokenizer for URL Pattern strings.

This module converts raw pattern strings into a stream of tokens
following the WHATWG URL Pattern Standard specification.
"""

from typing import List, NamedTuple


class Token(NamedTuple):
    """
    Represents a single lexical token in a URL pattern.

    Attributes:
        type: Token type identifier following WHATWG spec:
            - 'open': { character
            - 'close': } character
            - 'regexp': (<regexp>) pattern
            - 'name': :<name> pattern
            - 'char': regular character
            - 'escaped-char': backslash-escaped character
            - 'other-modifier': ? or + modifier
            - 'asterisk': * wildcard/modifier
            - 'end': end of pattern
            - 'invalid-char': invalid character
        value: The actual string content of the token
        index: Position in the original pattern string
    """

    type: str
    value: str
    index: int


def _is_valid_name_code_point(char: str, is_first: bool) -> bool:
    """
    Check if a character is valid in a name token.

    Names can contain alphanumeric characters, underscores, '$',
    and Unicode characters (codepoints > 127).
    The first character cannot be a digit.

    Args:
        char: Character to check
        is_first: Whether this is the first character of the name

    Returns:
        True if the character is valid in a name
    """
    if not char:
        return False

    # Allow alphanumeric, underscore, dollar sign, or non-ASCII characters
    # (Checking > 127 is a safe approximation for "Unicode identifier start/part"
    # in the context of keeping this pure Python and reasonably fast)
    return (char.isalnum() or char in ("_", "$") or ord(char) > 127) and (
        not is_first or not char.isdigit()
    )


def tokenize(pattern_string: str, policy: str = "lenient") -> List[Token]:
    """
    Convert a URL pattern string into a list of tokens.

    Implements the WHATWG URL Pattern tokenization algorithm.

    Args:
        pattern_string: The pattern string to tokenize (e.g., "/users/:id")
        policy: Tokenization policy ('strict' or 'lenient'). Default 'lenient'.

    Returns:
        List of Token objects representing the parsed pattern

    Raises:
        ValueError: If the pattern contains invalid syntax in strict mode

    Examples:
        >>> tokenize("/users/:id")
        [Token(type='char', value='/', index=0),
         Token(type='char', value='u', index=1), ...]
    """
    tokens = []
    index = 0
    length = len(pattern_string)

    while index < length:
        char = pattern_string[index]

        # Asterisk: * wildcard or modifier
        if char == "*":
            tokens.append(Token(type="asterisk", value="*", index=index))
            index += 1
            continue

        # Other modifiers: + or ?
        if char in ("+", "?"):
            tokens.append(Token(type="other-modifier", value=char, index=index))
            index += 1
            continue

        # Escaped character: \X
        if char == "\\":
            if index + 1 >= length:
                if policy == "strict":
                    raise ValueError(f"Incomplete escape sequence at index {index}")
                tokens.append(Token(type="invalid-char", value="\\", index=index))
                index += 1
                continue

            escaped_char = pattern_string[index + 1]
            tokens.append(Token(type="escaped-char", value=escaped_char, index=index))
            index += 2
            continue

        # Open brace: {
        if char == "{":
            tokens.append(Token(type="open", value="{", index=index))
            index += 1
            continue

        # Close brace: }
        if char == "}":
            tokens.append(Token(type="close", value="}", index=index))
            index += 1
            continue

        # Named group: :name
        if char == ":":
            name_start = index + 1
            name_end = name_start

            # Collect valid name characters
            while name_end < length:
                name_char = pattern_string[name_end]
                is_first = name_end == name_start

                if not _is_valid_name_code_point(name_char, is_first):
                    break

                name_end += 1

            # Check if we collected any name characters
            if name_end > name_start:
                name_value = pattern_string[name_start:name_end]
                tokens.append(Token(type="name", value=name_value, index=index))
                index = name_end
            else:
                # No valid name after colon
                tokens.append(Token(type="char", value=":", index=index))
                index += 1

            continue

        # Regexp group: (...)
        if char == "(":
            # Find matching closing parenthesis
            depth = 1
            regexp_start = index + 1
            regexp_end = regexp_start
            is_valid_ascii = True

            while regexp_end < length and depth > 0:
                regexp_char = pattern_string[regexp_end]

                # Check for non-ASCII characters
                if not regexp_char.isascii():
                    is_valid_ascii = False
                    break

                # Handle escaped characters in regexp
                if regexp_char == "\\":
                    if regexp_end + 1 < length:
                        # Check escaped char for ASCII too
                        if not pattern_string[regexp_end + 1].isascii():
                            is_valid_ascii = False
                            break
                        regexp_end += 2
                        continue
                    else:
                        break

                if regexp_char == "(":
                    depth += 1
                elif regexp_char == ")":
                    depth -= 1

                regexp_end += 1

            if not is_valid_ascii:
                if policy == "strict":
                    raise ValueError(
                        f"Non-ASCII character in regular expression at index {regexp_end}"
                    )
                tokens.append(Token(type="invalid-char", value="(", index=index))
                index += 1
                continue

            # Check if we found matching parenthesis
            if depth == 0:
                regexp_value = pattern_string[regexp_start : regexp_end - 1]
                tokens.append(Token(type="regexp", value=regexp_value, index=index))
                index = regexp_end
            else:
                # Unmatched opening parenthesis
                if policy == "strict":
                    raise ValueError(f"Unmatched opening parenthesis at index {index}")
                tokens.append(Token(type="invalid-char", value="(", index=index))
                index += 1

            continue

        # Regular character
        tokens.append(Token(type="char", value=char, index=index))
        index += 1

    # Add end token
    tokens.append(Token(type="end", value="", index=length))

    return tokens
