"""
urlpattern: Pure Python WHATWG URL Pattern implementation.

This library provides URL pattern matching following the WHATWG URL Pattern Standard,
enabling isomorphic routing between Python backends and JavaScript frontends.

Package name: urlpattern
PyPI name: urlpattern-py
"""

import re
import urllib.parse
from dataclasses import dataclass
from enum import IntEnum
from typing import Callable, Dict, List, Optional
from urllib.parse import urljoin, urlparse

from .compiler import compile_tokens_to_regex
from .normalizer import (
    escape_pattern_syntax,
    merge_adjacent_text,
)
from .parser import tokenize

__version__ = "0.1.0"

# Special schemes and their default ports
SPECIAL_SCHEMES = {
    "ftp": 21,
    "file": None,
    "http": 80,
    "https": 443,
    "ws": 80,
    "wss": 443,
}

_CONTROL_WHITESPACE_STRIP = str.maketrans("", "", "\t\n\r")

_COMPONENTS = [
    "protocol",
    "username",
    "password",
    "hostname",
    "port",
    "pathname",
    "search",
    "hash",
]


class Modifier(IntEnum):
    "Ordering mirrors the URLPattern comparator expectations."

    ZERO_OR_MORE = 0
    OPTIONAL = 1
    ONE_OR_MORE = 2
    NONE = 3


class PartType(IntEnum):
    "Ordering mirrors the URLPattern comparator expectations."

    FULL_WILDCARD = 0
    SEGMENT_WILDCARD = 1
    REGEX = 2
    FIXED = 3


@dataclass(frozen=True)
class Part:
    type: PartType
    name: object
    prefix: str
    value: str
    suffix: str
    modifier: Modifier

    def has_custom_name(self) -> bool:
        return self.name != "" and not isinstance(self.name, int)


def _protocol_encode_callback(value: str) -> str:
    """Validate and canonicalize protocol patterns."""
    if value == "":
        return value
    if re.fullmatch(r"[-+.A-Za-z0-9]*", value):
        return value.lower()
    raise TypeError(f"Invalid protocol '{value}'.")


def _username_encode_callback(value: str) -> str:
    """Percent-encode username while preserving allowed delimiters."""
    return _quote_component(value, safe="!$&'()*+,;=%")


def _password_encode_callback(value: str) -> str:
    """Percent-encode password while preserving allowed delimiters."""
    return _quote_component(value, safe="!$&'()*+,;=%")


def _hostname_encode_callback(value: str) -> str:
    """Canonicalize hostname patterns using URL rules."""
    if value == "":
        return value
    return _canonicalize_component(value, "hostname", for_pattern=True)


def _ipv6_hostname_encode_callback(value: str) -> str:
    """Canonicalize IPv6 hostname patterns with IPv6 rules applied."""
    if value == "":
        return value
    return _canonicalize_component(
        value, "hostname", is_ipv6_context=True, for_pattern=True
    )


def _port_encode_callback(value: str) -> str:
    """Normalize a port pattern into its numeric prefix."""
    if value == "":
        return value
    cleaned = _strip_control_whitespace(value)
    digits = []
    for char in cleaned:
        if char.isdigit():
            digits.append(char)
        else:
            break
    if not digits:
        raise TypeError(f"Invalid port '{value}'.")
    port_value = "".join(digits)
    if int(port_value) > 65535:
        raise TypeError(f"Invalid port '{value}'.")
    return port_value


def _standard_url_pathname_encode_callback(value: str) -> str:
    """Canonicalize and percent-encode a hierarchical pathname pattern."""
    if value == "":
        return value
    value = _replace_surrogates(value)
    canonical = _canonicalize_component(
        value, "pathname", protocol="http", for_pattern=True
    )
    safe_chars = "/-._~!$&'()*+,;=:@%"
    return urllib.parse.quote(canonical, safe=safe_chars)


def _path_url_pathname_encode_callback(value: str) -> str:
    """Preserve opaque pathnames without encoding."""
    if value == "":
        return value
    return value


def _search_encode_callback(value: str) -> str:
    """Percent-encode search patterns with WHATWG-safe characters."""
    return _quote_component(value, safe="!$&'()*+,;=:@/?%{}=", replace_surrogates=True)


def _hash_encode_callback(value: str) -> str:
    """Percent-encode hash patterns with WHATWG-safe characters."""
    return _quote_component(value, safe="!$&'()*+,;=:@/?%{}=", replace_surrogates=True)


_COMPONENT_OPTIONS = {
    "protocol": {
        "delimiter": "",
        "prefixes": "",
        "encode_part": _protocol_encode_callback,
    },
    "username": {
        "delimiter": "",
        "prefixes": "",
        "encode_part": _username_encode_callback,
    },
    "password": {
        "delimiter": "",
        "prefixes": "",
        "encode_part": _password_encode_callback,
    },
    "port": {"delimiter": "", "prefixes": "", "encode_part": _port_encode_callback},
    "search": {"delimiter": "", "prefixes": "", "encode_part": _search_encode_callback},
    "hash": {"delimiter": "", "prefixes": "", "encode_part": _hash_encode_callback},
}


def _build_groups(group_names, match):
    """Build the groups dict, de-duplicating names with numeric suffixes."""
    groups_dict = {}
    all_groups = match.groups()
    groupdict = match.groupdict()
    for i, name in enumerate(group_names):
        if i < len(all_groups):
            value = all_groups[i]
            if name in groups_dict:
                suffix = 1
                while f"{name}_{suffix}" in groupdict:
                    suffix_val = groupdict.get(f"{name}_{suffix}")
                    if suffix_val is not None:
                        groups_dict[name] = suffix_val
                        break
                    suffix += 1
            else:
                groups_dict[name] = value
    return groups_dict


def _quote_component(value: str, safe: str, replace_surrogates: bool = False) -> str:
    """Percent-encode a URL component with a configurable safe set."""
    if value == "":
        return value
    if replace_surrogates:
        value = _replace_surrogates(value)
    return urllib.parse.quote(value, safe=safe)


def _replace_surrogates(value: str) -> str:
    """Replace surrogate code points with the Unicode replacement char."""
    return "".join("\ufffd" if 0xD800 <= ord(ch) <= 0xDFFF else ch for ch in value)


def _strip_control_whitespace(value: str) -> str:
    """Remove ASCII tab/newline/carriage returns per URL parsing rules."""
    return value.translate(_CONTROL_WHITESPACE_STRIP)


def _parse_pattern_to_parts(
    pattern_string: str,
    *,
    delimiter: str = "",
    prefixes: str = "",
    encode_part: Callable[[str], str] = None,
):
    """Parse a component pattern into Part objects for matching/generation."""
    tokens = tokenize(pattern_string, policy="strict")

    if delimiter:
        escaped = re.escape(delimiter)
        segment_wildcard_regex = f"[^{escaped}]+?"
    else:
        segment_wildcard_regex = ".+?"

    result = []
    key = 0
    i = 0
    name_set = set()
    pending_fixed: List[str] = []

    def encode(value: str) -> str:
        if encode_part:
            return encode_part(value)
        return value

    def try_consume(token_type: str):
        nonlocal i
        if i < len(tokens) and tokens[i].type == token_type:
            value = tokens[i].value
            i += 1
            return value
        return None

    def try_consume_modifier():
        return try_consume("other-modifier") or try_consume("asterisk")

    def must_consume(token_type: str):
        value = try_consume(token_type)
        if value is not None:
            return value
        next_type = tokens[i].type if i < len(tokens) else "end"
        index = tokens[i].index if i < len(tokens) else len(pattern_string)
        raise TypeError(f"Unexpected {next_type} at {index}, expected {token_type}")

    def consume_text():
        result_value = []
        while True:
            value = try_consume("char") or try_consume("escaped-char")
            if value is None:
                break
            result_value.append(value)
        return "".join(result_value)

    def append_pending(value: str):
        if value:
            pending_fixed.append(value)

    def flush_pending():
        if pending_fixed:
            result.append(
                Part(
                    PartType.FIXED,
                    "",
                    "",
                    encode("".join(pending_fixed)),
                    "",
                    Modifier.NONE,
                )
            )
            pending_fixed.clear()

    def add_part(prefix, name_token, regex_or_wildcard_token, suffix, modifier_token):
        nonlocal key
        modifier = Modifier.NONE
        if modifier_token == "?":
            modifier = Modifier.OPTIONAL
        elif modifier_token == "*":
            modifier = Modifier.ZERO_OR_MORE
        elif modifier_token == "+":
            modifier = Modifier.ONE_OR_MORE

        if not name_token and not regex_or_wildcard_token and modifier == Modifier.NONE:
            append_pending(prefix)
            return

        flush_pending()

        if not name_token and not regex_or_wildcard_token:
            if not prefix:
                return
            result.append(Part(PartType.FIXED, "", "", encode(prefix), "", modifier))
            return

        if not regex_or_wildcard_token:
            regex_value = segment_wildcard_regex
        elif regex_or_wildcard_token == "*":
            regex_value = ".*"
        else:
            regex_value = regex_or_wildcard_token

        part_type = PartType.REGEX
        if regex_value == segment_wildcard_regex:
            part_type = PartType.SEGMENT_WILDCARD
            regex_value = ""
        elif regex_value == ".*":
            part_type = PartType.FULL_WILDCARD
            regex_value = ""

        if name_token:
            name = name_token
        elif regex_or_wildcard_token:
            name = key
            key += 1
        else:
            name = ""

        if name in name_set:
            raise TypeError(f"Duplicate name '{name}'.")
        name_set.add(name)

        result.append(
            Part(
                part_type,
                name,
                encode(prefix),
                regex_value,
                encode(suffix),
                modifier,
            )
        )

    while i < len(tokens):
        char_token = try_consume("char")
        name_token = try_consume("name")
        regex_or_wildcard_token = try_consume("regexp")

        if not name_token and not regex_or_wildcard_token:
            regex_or_wildcard_token = try_consume("asterisk")

        if name_token or regex_or_wildcard_token:
            prefix = char_token or ""
            if prefix not in prefixes:
                append_pending(prefix)
                prefix = ""

            flush_pending()

            modifier_token = try_consume_modifier()
            add_part(prefix, name_token, regex_or_wildcard_token, "", modifier_token)
            continue

        value = char_token or try_consume("escaped-char")
        if value:
            append_pending(value)
            continue

        open_token = try_consume("open")
        if open_token:
            prefix = consume_text()
            name_token = try_consume("name")
            regex_or_wildcard_token = try_consume("regexp")
            if not name_token and not regex_or_wildcard_token:
                regex_or_wildcard_token = try_consume("asterisk")
            suffix = consume_text()
            must_consume("close")
            modifier_token = try_consume_modifier()
            add_part(
                prefix, name_token, regex_or_wildcard_token, suffix, modifier_token
            )
            continue

        flush_pending()
        must_consume("end")

    return result


def _parse_options_for_component(
    component: str, protocol_pattern: str, component_pattern: str
):
    """Return parsing/encoding options for a component pattern."""
    default_options = _COMPONENT_OPTIONS.get(component)
    if default_options is not None:
        return default_options
    if component == "hostname":
        if _is_ipv6_hostname(component_pattern):
            encode_part = _ipv6_hostname_encode_callback
        else:
            encode_part = _hostname_encode_callback
        return {"delimiter": ".", "prefixes": "", "encode_part": encode_part}
    if component == "port":
        return _COMPONENT_OPTIONS[component]
    if component == "pathname":
        if _is_special_scheme_pattern(protocol_pattern, None):
            return {
                "delimiter": "/",
                "prefixes": "/",
                "encode_part": _standard_url_pathname_encode_callback,
            }
        return {
            "delimiter": "",
            "prefixes": "",
            "encode_part": _path_url_pathname_encode_callback,
        }
    if component in ("search", "hash"):
        return _COMPONENT_OPTIONS[component]
    raise TypeError(f"Invalid component '{component}'.")


def _modifier_to_string(modifier: Modifier) -> str:
    """Serialize a modifier enum to its pattern character."""
    if modifier == Modifier.ZERO_OR_MORE:
        return "*"
    if modifier == Modifier.OPTIONAL:
        return "?"
    if modifier == Modifier.ONE_OR_MORE:
        return "+"
    return ""


def _is_identifier_part_char(value: str) -> bool:
    """Return True if char can appear in URLPattern identifier position."""
    return bool(value) and (
        value.isalnum() or value in ("_", "$") or ord(value) in (0x200C, 0x200D)
    )


def _parts_to_pattern(parts, options) -> str:
    """Serialize Part objects back into a URLPattern component string."""
    delimiter = options.get("delimiter", "")
    prefixes = options.get("prefixes", "")

    if delimiter:
        segment_wildcard_regex = f"[^{re.escape(delimiter)}]+?"
    else:
        segment_wildcard_regex = ".+?"

    chunks = []
    for i, part in enumerate(parts):
        if part.type == PartType.FIXED:
            if part.modifier == Modifier.NONE:
                chunks.append(escape_pattern_syntax(part.value))
            else:
                chunks.append("{")
                chunks.append(escape_pattern_syntax(part.value))
                chunks.append("}")
                chunks.append(_modifier_to_string(part.modifier))
            continue

        custom_name = part.has_custom_name()
        needs_grouping = bool(part.suffix) or (
            bool(part.prefix) and (len(part.prefix) != 1 or part.prefix not in prefixes)
        )

        last_part = parts[i - 1] if i > 0 else None
        next_part = parts[i + 1] if i < len(parts) - 1 else None

        if (
            not needs_grouping
            and custom_name
            and part.type == PartType.SEGMENT_WILDCARD
            and part.modifier == Modifier.NONE
            and next_part
            and not next_part.prefix
            and not next_part.suffix
        ):
            if next_part.type == PartType.FIXED:
                code = next_part.value[0] if next_part.value else ""
                needs_grouping = _is_identifier_part_char(code)
            else:
                needs_grouping = not next_part.has_custom_name()

        if (
            not needs_grouping
            and not part.prefix
            and last_part
            and last_part.type == PartType.FIXED
        ):
            code = last_part.value[-1] if last_part.value else ""
            needs_grouping = code in prefixes

        if needs_grouping:
            chunks.append("{")

        chunks.append(escape_pattern_syntax(part.prefix))

        if custom_name:
            chunks.append(f":{part.name}")

        if part.type == PartType.REGEX:
            chunks.append(f"({part.value})")
        elif part.type == PartType.SEGMENT_WILDCARD:
            if not custom_name:
                chunks.append(f"({segment_wildcard_regex})")
        elif part.type == PartType.FULL_WILDCARD:
            if not custom_name and (
                not last_part
                or last_part.type == PartType.FIXED
                or last_part.modifier != Modifier.NONE
                or needs_grouping
                or part.prefix != ""
            ):
                chunks.append("*")
            else:
                chunks.append("(.*)")

        if (
            part.type == PartType.SEGMENT_WILDCARD
            and custom_name
            and part.suffix
            and _is_identifier_part_char(part.suffix[0])
        ):
            chunks.append("\\")

        chunks.append(escape_pattern_syntax(part.suffix))

        if needs_grouping:
            chunks.append("}")

        if part.modifier != Modifier.NONE:
            chunks.append(_modifier_to_string(part.modifier))

    return "".join(chunks)


def _is_ipv6_hostname(value: str) -> bool:
    """Check if a hostname pattern represents an IPv6 address per spec."""
    if len(value) < 2:
        return False
    if value.startswith("["):
        return True
    if value.startswith("{["):
        return True
    if value.startswith("\\["):
        return True
    return False


def _has_surrogates(value: str) -> bool:
    """Check whether a string contains surrogate code points."""
    return any(0xD800 <= ord(char) <= 0xDFFF for char in value)


def _canonicalize_component(
    value: str,
    component: str,
    protocol: str = None,
    is_ipv6_context: bool = False,
    for_pattern: bool = False,
) -> str:
    """
    Canonicalize a URL component value according to spec.
    """
    if not value:
        return value

    if _has_surrogates(value):
        if for_pattern and component == "hostname":
            raise TypeError(f"Invalid character in {component} pattern")
        value = value.encode("utf-8", errors="replace").decode("utf-8")

    if component == "protocol":
        if not value:
            return value
        try:
            test_url = f"{value}://dummy.invalid/"
            parsed = urlparse(test_url)
            if not parsed.scheme or parsed.scheme.lower() != value.lower():
                return ""
            return parsed.scheme
        except Exception:
            return ""

    if component == "hostname":
        # Remove tabs and newlines per URL standard
        value = _strip_control_whitespace(value)

        if is_ipv6_context:
            # Canonicalize IPv6 hostname: lowercase and validate chars
            # Spec: If not hex digit, not [, not ], not : -> throw TypeError.
            import string

            valid_chars = string.hexdigits + "[]:"
            result = []
            for char in value:
                if char in valid_chars:
                    result.append(char.lower())
                else:
                    raise TypeError(f"Invalid character in IPv6 hostname: {char!r}")
            return "".join(result)

        # Simulate URL parser hostname state: stop at /, ?, #
        for i, char in enumerate(value):
            if char in "/?#\\":
                value = value[:i]
                break

        forbidden_host_chars = set(" #%:@[]<>^|%")
        for char in value:
            if char <= " " or char == "\x7f" or char in forbidden_host_chars:
                raise TypeError(f"Invalid character in hostname: {char!r}")

        try:
            # IDNA encoding for international domains
            return value.encode("idna").decode("ascii")
        except UnicodeError:
            # Fallback to ASCII lowercasing
            return value.lower()

    if component == "port":
        # Canonicalize port per WHATWG spec
        # Per URL spec: tabs (U+0009) and newlines (U+000A, U+000D) are removed
        # Then parse ASCII digits until first non-digit
        # Examples: "80x" -> "80", "8\t0" -> "80", "invalid80" -> ""
        if not value:
            return value

        # Remove tabs and newlines per URL standard
        cleaned = _strip_control_whitespace(value)

        # Extract numeric prefix (ASCII digits only)
        port_digits = []
        for char in cleaned:
            if char.isdigit():
                port_digits.append(char)
            else:
                # Stop at first non-digit
                break
        port_str = "".join(port_digits)

        # If no valid digits found, return empty string
        if not port_str:
            return ""

        try:
            port_num = int(port_str)
        except ValueError:
            return ""

        if port_num > 65535:
            raise TypeError("Port number out of range")

        # Check if this is a default port for the protocol
        if protocol and protocol in SPECIAL_SCHEMES:
            default = SPECIAL_SCHEMES[protocol]
            if default is not None and port_num == default:
                return ""  # Default ports are represented as empty string

        return port_str

    if component in ("username", "password"):
        # Percent encode (UTF-8)
        # Include '%' in safe chars to prevent double-encoding if value is already encoded
        return urllib.parse.quote(value, safe="!$&'()*+,;=%")

    if component == "pathname":
        if not value:
            return value

        # Check for opaque pathname
        is_opaque = False
        if protocol:
            if protocol.lower() not in SPECIAL_SCHEMES:
                is_opaque = True

        if is_opaque:
            return value

        import posixpath

        # Spec algorithm for canonicalize a pathname:
        # 1. leading_slash = value.startswith('/')
        # 2. modified_value = "/-" + value if not leading_slash else value
        # 3. Use URL parser on modified_value
        # 4. Result is serialized path, with /- prefix removed if leading_slash was false

        leading_slash = value.startswith("/")
        has_trailing_slash = value.endswith("/")

        modified_value = value
        if not leading_slash:
            modified_value = "/-" + value

        # Normalize the path
        normalized_path = posixpath.normpath(modified_value)

        # Restore trailing slash if it was present
        if has_trailing_slash and not normalized_path.endswith("/"):
            normalized_path += "/"

        # Remove the /- prefix if we added it
        if not leading_slash:
            # normalized_path starts with /-
            if normalized_path.startswith("/-"):
                normalized_path = normalized_path[2:]
            elif normalized_path.startswith("-"):  # if leading / was collapsed?
                normalized_path = normalized_path[1:]

        # Now percent-encode
        encoded_path = urllib.parse.quote(normalized_path, safe="/:@!$&'()*+,;=%")

        return encoded_path

    if component == "search":
        # Percent-encode search component
        # Use quote with safe characters for query strings
        # URL standard: query percent-encode set does not include { or }
        return urllib.parse.quote(value, safe="!$&'()*+,/:;=?@%{}")

    if component == "hash":
        # Percent-encode hash component
        # Use quote with safe characters for fragments
        # URL standard: fragment percent-encode set does not include { or }
        return urllib.parse.quote(value, safe="!$&'()*+,/:;=?@%{}")

    return value


def _validate_no_nested_groups(tokens):
    """Raise if a token stream contains nested group braces."""
    depth = 0
    for token in tokens:
        if token.type == "open":
            if depth > 0:
                raise TypeError(f"Nested groups are not allowed at index {token.index}")
            depth += 1
        elif token.type == "close":
            if depth > 0:
                depth -= 1


def _validate_port_pattern(component_pattern: str, tokens):
    """Validate that a port pattern is numeric and in range when literal."""
    cleaned = _strip_control_whitespace(component_pattern)
    if not cleaned:
        return
    if any(token.type not in ("char", "escaped-char", "end") for token in tokens):
        return
    if any(not token.value.isdigit() for token in tokens if token.type != "end"):
        return
    port_num = int(cleaned)
    if port_num > 65535:
        raise TypeError("Port number out of range")


def _normalize_hostname_escapes(value: str) -> str:
    """Normalize hostname escapes to match URLPattern parsing rules."""
    special = set(".*+?^${}()|[]:\\")
    normalized = []
    i = 0
    while i < len(value):
        char = value[i]
        if char == "\\" and i + 1 < len(value):
            next_char = value[i + 1]
            if (
                next_char.isalnum() or next_char in ("_", "$") or ord(next_char) > 127
            ) and next_char not in special:
                normalized.append("\\\\")
                normalized.append(next_char)
                i += 2
                continue
            normalized.append(char)
            normalized.append(next_char)
            i += 2
            continue
        normalized.append(char)
        i += 1
    return "".join(normalized)


def _find_unescaped_char(s: str, char: str, start: int = 0) -> int:
    """
    Find the first unescaped occurrence of char in string s.

    An unescaped character is one not preceded by a backslash.

    Args:
        s: String to search
        char: Character to find
        start: Starting position

    Returns:
        Index of first unescaped occurrence, or -1 if not found
    """
    pos = start
    while pos < len(s):
        idx = s.find(char, pos)
        if idx == -1:
            return -1

        # Check if it's escaped by counting preceding backslashes
        num_backslashes = 0
        check_pos = idx - 1
        while check_pos >= 0 and s[check_pos] == "\\":
            num_backslashes += 1
            check_pos -= 1

        # If even number of backslashes (including 0), char is not escaped
        if num_backslashes % 2 == 0:
            return idx

        # Odd number of backslashes means char is escaped, continue search
        pos = idx + 1

    return -1


def _find_char_outside_braces(s: str, char: str, start: int = 0) -> int:
    """
    Find the first occurrence of char outside of brace groups.

    Args:
        s: String to search
        char: Character to find
        start: Starting position

    Returns:
        Index of first occurrence outside braces, or -1 if not found
    """
    depth = 0
    pos = start

    while pos < len(s):
        c = s[pos]

        # Track brace depth
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == char and depth == 0:
            return pos

        pos += 1

    return -1


def _parse_pattern_string(pattern: str) -> Dict[str, str]:
    """
    Parse a URL pattern string into components using the WHATWG spec algorithm.
    """
    tokens = tokenize(pattern, policy="lenient")
    result = {}

    token_index = 0
    component_start_token_index = 0
    state = "init"
    group_depth = 0
    ipv6_depth = 0
    protocol_matches_special = False

    def apply_pathname_search_defaults(next_state: str):
        if next_state in ("search", "hash"):
            if "pathname" not in result:
                result["pathname"] = "/" if protocol_matches_special else ""
        if next_state == "hash" and "search" not in result:
            result["search"] = ""

    def get_component_string(start_idx, end_idx):
        if start_idx >= len(tokens) or start_idx >= end_idx:
            return ""
        start_pos = tokens[start_idx].index
        end_pos = tokens[end_idx].index if end_idx < len(tokens) else len(pattern)
        return pattern[start_pos:end_pos]

    def is_search_prefix(idx):
        if idx >= len(tokens):
            return False
        t = tokens[idx]
        if t.value != "?":
            return False
        if t.type in ("char", "escaped-char", "invalid-char"):
            return True
        if idx == 0:
            return True
        prev = tokens[idx - 1]
        if prev.type in ("name", "regexp", "close", "asterisk"):
            return False
        return True

    def is_hash_prefix(idx):
        if idx >= len(tokens):
            return False
        t = tokens[idx]
        return t.value == "#" and t.type in ("char", "escaped-char", "invalid-char")

    def is_pathname_start(idx):
        if idx >= len(tokens):
            return False
        t = tokens[idx]
        return t.value == "/" and t.type in ("char", "escaped-char", "invalid-char")

    while token_index < len(tokens):
        token = tokens[token_index]
        token_increment = 1

        if token.type == "end":
            if state == "init":
                # Relative URL check
                if is_hash_prefix(component_start_token_index):
                    state = "hash"
                    token_index = component_start_token_index + 1
                    component_start_token_index = token_index
                elif is_search_prefix(component_start_token_index):
                    state = "search"
                    token_index = component_start_token_index + 1
                    component_start_token_index = token_index
                else:
                    state = "pathname"
                    token_index = component_start_token_index
                token_increment = 0
                continue
            elif state == "authority":
                state = "hostname"
                token_index = component_start_token_index
                token_increment = 0
                continue
            else:
                if state not in ("init", "authority", "done"):
                    result[state] = get_component_string(
                        component_start_token_index, token_index
                    )
                state = "done"
                break

        if token.type == "open":
            group_depth += 1
            token_index += token_increment
            continue
        elif token.type == "close":
            if group_depth > 0:
                group_depth -= 1
            token_index += token_increment
            continue

        if group_depth > 0:
            token_index += token_increment
            continue

        # State machine
        if state == "init":
            if (
                token.type == "char" or token.type == "escaped-char"
            ) and token.value == ":":
                state = "protocol"
                token_index = component_start_token_index
                token_increment = 0
            # else: continue to end to check for relative

        elif state == "protocol":
            if (
                token.type == "char" or token.type == "escaped-char"
            ) and token.value == ":":
                protocol_val = get_component_string(
                    component_start_token_index, token_index
                )
                result["protocol"] = protocol_val

                # Check if it's a special scheme
                protocol_matches_special = _is_special_scheme_pattern(
                    protocol_val, raise_on_error=True
                )
                is_special = protocol_matches_special

                if (
                    token_index + 2 < len(tokens)
                    and tokens[token_index + 1].value == "/"
                    and tokens[token_index + 2].value == "/"
                ):
                    state = "authority"
                    token_index += 3
                    component_start_token_index = token_index
                elif is_special:
                    state = "authority"
                    token_index += 1
                    component_start_token_index = token_index
                else:
                    state = "pathname"
                    token_index += 1
                    component_start_token_index = token_index
                token_increment = 0

        elif state == "authority":
            if (
                token.type == "char" or token.type == "escaped-char"
            ) and token.value == "@":
                # Split username:password within authority
                pass_token_idx = -1
                temp_depth = 0
                for j in range(component_start_token_index, token_index):
                    t = tokens[j]
                    if t.type == "open":
                        temp_depth += 1
                    elif t.type == "close":
                        if temp_depth > 0:
                            temp_depth -= 1
                    elif (
                        temp_depth == 0
                        and (t.type == "char" or t.type == "escaped-char")
                        and t.value == ":"
                    ):
                        pass_token_idx = j
                        break

                if pass_token_idx != -1:
                    result["username"] = get_component_string(
                        component_start_token_index, pass_token_idx
                    )
                    result["password"] = get_component_string(
                        pass_token_idx + 1, token_index
                    )
                else:
                    result["username"] = get_component_string(
                        component_start_token_index, token_index
                    )

                state = "hostname"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0
            elif (
                is_pathname_start(token_index)
                or is_search_prefix(token_index)
                or is_hash_prefix(token_index)
            ):
                state = "hostname"
                token_index = component_start_token_index
                token_increment = 0

        elif state == "hostname":
            if (
                token.type == "char" or token.type == "escaped-char"
            ) and token.value == "[":
                ipv6_depth += 1
            elif (
                token.type == "char" or token.type == "escaped-char"
            ) and token.value == "]":
                if ipv6_depth > 0:
                    ipv6_depth -= 1

            if (
                (token.type == "char" or token.type == "escaped-char")
                and token.value == ":"
                and ipv6_depth == 0
            ):
                result["hostname"] = get_component_string(
                    component_start_token_index, token_index
                )
                state = "port"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0
            elif is_pathname_start(token_index) and ipv6_depth == 0:
                result["hostname"] = get_component_string(
                    component_start_token_index, token_index
                )
                state = "pathname"
                component_start_token_index = token_index
                token_increment = 0
            elif is_search_prefix(token_index):
                result["hostname"] = get_component_string(
                    component_start_token_index, token_index
                )
                apply_pathname_search_defaults("search")
                state = "search"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0
            elif is_hash_prefix(token_index):
                result["hostname"] = get_component_string(
                    component_start_token_index, token_index
                )
                apply_pathname_search_defaults("hash")
                state = "hash"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0

        elif state == "port":
            if is_pathname_start(token_index):
                result["port"] = get_component_string(
                    component_start_token_index, token_index
                )
                state = "pathname"
                component_start_token_index = token_index
                token_increment = 0
            elif is_search_prefix(token_index):
                result["port"] = get_component_string(
                    component_start_token_index, token_index
                )
                apply_pathname_search_defaults("search")
                state = "search"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0
            elif is_hash_prefix(token_index):
                result["port"] = get_component_string(
                    component_start_token_index, token_index
                )
                apply_pathname_search_defaults("hash")
                state = "hash"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0

        elif state == "pathname":
            if is_search_prefix(token_index):
                result["pathname"] = get_component_string(
                    component_start_token_index, token_index
                )
                state = "search"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0
            elif is_hash_prefix(token_index):
                result["pathname"] = get_component_string(
                    component_start_token_index, token_index
                )
                apply_pathname_search_defaults("hash")
                state = "hash"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0

        elif state == "search":
            if is_hash_prefix(token_index):
                result["search"] = get_component_string(
                    component_start_token_index, token_index
                )
                state = "hash"
                token_index += 1
                component_start_token_index = token_index
                token_increment = 0

        token_index += token_increment

    # Default port logic
    if "hostname" in result and "port" not in result:
        result["port"] = ""

    return result


def _is_absolute_pathname_base(value: str, allow_non_url: bool) -> bool:
    """Return True if pathname is absolute, with optional non-URL rules."""
    if not value:
        return False
    if value.startswith("/"):
        return True
    if not allow_non_url:
        return False
    if len(value) < 2:
        return False
    if value[0] == "\\" and value[1] == "/":
        return True
    if value[0] == "{" and value[1] == "/":
        return True
    return False


def _is_absolute_pathname(value: str) -> bool:
    """Check if a pathname pattern is absolute per spec."""
    return _is_absolute_pathname_base(value, allow_non_url=True)


def _is_absolute_pathname_for_type(value: str, type_: str) -> bool:
    """Check if a pathname is absolute per spec, with type awareness."""
    return _is_absolute_pathname_base(value, allow_non_url=type_ != "url")


def _is_special_scheme_pattern(
    pattern_string: str, options: Dict = None, raise_on_error: bool = False
) -> bool:
    """
    Check if a protocol pattern matches any special scheme.
    Used to determine if pathname should be treated as special (hierarchical) or opaque.
    """
    if not pattern_string:
        return True  # Empty/Wildcard matches special schemes

    # Fast path for exact matches
    if pattern_string.lower() in SPECIAL_SCHEMES:
        return True

    # Compile regex to check
    try:
        tokens = tokenize(pattern_string)
        regex, _ = compile_tokens_to_regex(tokens, context="protocol")
        flags = re.IGNORECASE if options and options.get("ignoreCase") else 0
        regex_obj = re.compile(f"^{regex}$", flags)

        for scheme in SPECIAL_SCHEMES:
            if regex_obj.match(scheme):
                return True
    except Exception:
        # If compilation fails, optionally raise (constructor parser needs this)
        if raise_on_error:
            raise
        # Otherwise, assume it doesn't match special schemes
        return False

    return False


def _process_base_url_string(value: str, type_: str) -> str:
    """Return escaped base URL fields when building patterns."""
    if type_ != "pattern":
        return value
    return escape_pattern_syntax(value)


def _serialize_base_hostname(parsed_base) -> str:
    """Serialize base hostname, preserving IPv6 brackets."""
    hostname = parsed_base.hostname or ""
    if hostname and ":" in hostname and not hostname.startswith("["):
        hostname = f"[{hostname}]"
    return hostname


def _serialize_base_path(parsed_base) -> str:
    """Serialize base path, defaulting to a root slash."""
    return parsed_base.path or "/"


def _process_urlpattern_init(
    init: Dict[str, str],
    type_: str,
    protocol: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    hostname: Optional[str] = None,
    port: Optional[str] = None,
    pathname: Optional[str] = None,
    search: Optional[str] = None,
    hash_value: Optional[str] = None,
) -> Dict[str, str]:
    """Normalize URLPatternInit fields against a base URL and type."""
    result: Dict[str, str] = {}

    for key, value in (
        ("protocol", protocol),
        ("username", username),
        ("password", password),
        ("hostname", hostname),
        ("port", port),
        ("pathname", pathname),
        ("search", search),
        ("hash", hash_value),
    ):
        if value is not None:
            result[key] = value

    base_url = init.get("baseURL") if isinstance(init, dict) else None
    parsed_base = None
    if base_url is not None:
        if base_url == "":
            raise TypeError("Base URL must not be empty")
        parsed_base = urlparse(base_url)
        if not parsed_base.scheme:
            raise TypeError("Invalid base URL")

    contains = {key for key, value in init.items() if value is not None}

    if parsed_base:
        if "protocol" not in contains:
            result["protocol"] = _process_base_url_string(parsed_base.scheme, type_)

        if (
            type_ != "pattern"
            and not {"protocol", "hostname", "port", "username"} & contains
        ):
            if parsed_base.username:
                result["username"] = _process_base_url_string(
                    parsed_base.username, type_
                )

        if (
            type_ != "pattern"
            and not {"protocol", "hostname", "port", "username", "password"} & contains
        ):
            if parsed_base.password:
                result["password"] = _process_base_url_string(
                    parsed_base.password, type_
                )

        if not {"protocol", "hostname"} & contains:
            result["hostname"] = _process_base_url_string(
                _serialize_base_hostname(parsed_base), type_
            )

        if not {"protocol", "hostname", "port"} & contains:
            if parsed_base.port is None:
                result["port"] = ""
            else:
                result["port"] = str(parsed_base.port)

        if not {"protocol", "hostname", "port", "pathname"} & contains:
            result["pathname"] = _process_base_url_string(
                _serialize_base_path(parsed_base), type_
            )

        if not {"protocol", "hostname", "port", "pathname", "search"} & contains:
            if parsed_base.query:
                result["search"] = _process_base_url_string(parsed_base.query, type_)

        if (
            not {
                "protocol",
                "hostname",
                "port",
                "pathname",
                "search",
                "hash",
            }
            & contains
        ):
            if parsed_base.fragment:
                result["hash"] = _process_base_url_string(parsed_base.fragment, type_)

    def process_protocol(value: str) -> str:
        stripped = value[:-1] if value.endswith(":") else value
        if type_ == "pattern":
            return stripped
        canonicalized = _canonicalize_component(stripped, "protocol")
        if stripped and not canonicalized:
            raise TypeError("Invalid protocol")
        return canonicalized

    def process_component(value: str, component: str) -> str:
        if type_ == "pattern":
            return value
        if component == "hostname" and _is_ipv6_hostname(value):
            return _canonicalize_component(value, component, is_ipv6_context=True)
        return _canonicalize_component(value, component)

    def process_port_value(value: str, protocol_value: str) -> str:
        if type_ == "pattern":
            return value
        if value:
            cleaned = _strip_control_whitespace(value)
            if cleaned and not cleaned[0].isdigit():
                raise TypeError("Invalid port")
        return _canonicalize_component(value, "port", protocol_value)

    def process_pathname_value(value: str, protocol_value: str) -> str:
        if type_ == "pattern":
            return value
        if protocol_value in SPECIAL_SCHEMES or protocol_value == "":
            return _canonicalize_component(value, "pathname", protocol_value)
        return _canonicalize_component(value, "pathname", protocol_value)

    def process_search(value: str) -> str:
        stripped = value[1:] if value.startswith("?") else value
        if type_ == "pattern":
            return stripped
        return _canonicalize_component(stripped, "search")

    def process_hash(value: str) -> str:
        stripped = value[1:] if value.startswith("#") else value
        if type_ == "pattern":
            return stripped
        return _canonicalize_component(stripped, "hash")

    if "protocol" in contains:
        result["protocol"] = process_protocol(init["protocol"])

    if "username" in contains:
        result["username"] = process_component(init["username"], "username")

    if "password" in contains:
        result["password"] = process_component(init["password"], "password")

    if "hostname" in contains:
        result["hostname"] = process_component(init["hostname"], "hostname")

    result_protocol = result.get("protocol", "")

    if "port" in contains:
        result["port"] = process_port_value(init["port"], result_protocol)

    if "pathname" in contains:
        result["pathname"] = init["pathname"]
        if parsed_base and not {"protocol", "hostname", "port"} & contains:
            if not _is_absolute_pathname_for_type(result["pathname"], type_):
                base_path = _serialize_base_path(parsed_base)
                slash_index = base_path.rfind("/")
                if slash_index != -1:
                    result["pathname"] = (
                        base_path[: slash_index + 1] + result["pathname"]
                    )
        result["pathname"] = process_pathname_value(result["pathname"], result_protocol)

    if "search" in contains:
        result["search"] = process_search(init["search"])

    if "hash" in contains:
        result["hash"] = process_hash(init["hash"])

    return result


class URLPattern:
    """
    URLPattern provides pattern matching for URLs following the WHATWG URL Pattern Standard.

    Examples:
        >>> pattern = URLPattern("/users/:id")
        >>> result = pattern.exec("https://example.com/users/123")
        >>> result['pathname']['groups']['id']
        '123'

        >>> pattern = URLPattern("/posts/*")
        >>> pattern.test("https://example.com/posts/2024/hello")
        True
    """

    def __init__(self, pattern=None, base_url=None, options=None):
        """
        Initialize a URLPattern.

        Args:
            pattern: Pattern string or dict defining the URL pattern.
                    Examples: "/users/:id", "https://*.example.com/*"
                    If None or empty, creates a wildcard pattern matching all URLs.
            base_url: Optional base URL for resolving relative patterns.
                     Example: "https://example.com"
            options: Optional dict with configuration.
                    Supported keys:
                    - ignoreCase (bool): Enable case-insensitive matching

        Raises:
            TypeError: If pattern or base_url have invalid types
        """
        # Handle overloaded constructor:
        # new URLPattern(input_dict, options_dict)
        # new URLPattern(input_string, options_dict)
        if options is None and isinstance(base_url, dict):
            options = base_url
            base_url = None

        self.pattern = pattern
        self.base_url = base_url
        self.options = options or {}
        self._has_regexp_groups = False

        # Validate types
        if pattern is not None and not isinstance(pattern, (str, dict)):
            raise TypeError(
                f"Pattern must be string or dict, got {type(pattern).__name__}"
            )

        if base_url is not None and not isinstance(base_url, str):
            raise TypeError(f"Base URL must be string, got {type(base_url).__name__}")
        if base_url == "":
            raise TypeError("Base URL must not be empty")

        # Compile the pattern
        self._compiled_components = {}
        self._pattern_components = (
            set()
        )  # Track which components are in the original pattern

        # Handle empty pattern
        if pattern is None or pattern == "" or pattern == {}:
            self._compile_empty_pattern()
        elif isinstance(pattern, dict):
            self._compile_dict_pattern(pattern, base_url)
        else:
            self._compile_pattern(pattern, base_url)

    def _compile_components(
        self,
        pattern_components: Dict[str, str],
        is_special_protocol: bool,
        protocol: Optional[str],
        opaque_defaults: bool = False,
    ):
        """Unified compilation logic for components."""
        flags = re.IGNORECASE if self.options.get("ignoreCase") else 0
        for component_name in _COMPONENTS:
            component_pattern = pattern_components.get(component_name)

            # If component not specified, default to '*'
            if component_pattern is None:
                if opaque_defaults and component_name in (
                    "hostname",
                    "port",
                    "pathname",
                ):
                    component_pattern = ""
                else:
                    component_pattern = "*"

            # Strip component delimiters
            if component_name == "protocol" and component_pattern.endswith(":"):
                component_pattern = component_pattern[:-1]
            elif component_name == "search" and component_pattern.startswith("?"):
                component_pattern = component_pattern[1:]
            elif component_name == "hash" and component_pattern.startswith("#"):
                component_pattern = component_pattern[1:]

            # Canonicalize port patterns: if port matches default for protocol, make it empty
            if component_name == "port" and component_pattern and protocol:
                if protocol in SPECIAL_SCHEMES:
                    default = SPECIAL_SCHEMES[protocol]
                    cleaned = _strip_control_whitespace(component_pattern)
                    if cleaned.isdigit() and default is not None:
                        try:
                            if int(cleaned) == default:
                                component_pattern = ""
                        except ValueError:
                            pass

            # Skip empty components (after delimiter stripping)
            if component_pattern == "":
                if component_name == "pathname" and is_special_protocol:
                    component_pattern = "/"
                else:
                    component_pattern = ""

            # Determine context and delimiter for wildcard compilation
            context = component_name
            delimiter = None
            if component_name == "pathname":
                delimiter = "/" if is_special_protocol else ""
            elif component_name == "hostname":
                delimiter = "."

            # Check if this is an IPv6 hostname pattern for canonicalization purposes
            is_ipv6_hostname_pattern = False
            if component_name == "hostname" and _is_ipv6_hostname(component_pattern):
                is_ipv6_hostname_pattern = True

            # Tokenize and compile
            normalized_pattern = component_pattern
            if component_name == "hostname":
                normalized_pattern = _normalize_hostname_escapes(component_pattern)

            tokens = tokenize(normalized_pattern)
            _validate_no_nested_groups(tokens)
            if component_name == "port":
                _validate_port_pattern(component_pattern, tokens)
            tokens = merge_adjacent_text(tokens)
            has_regexp_groups = any(token.type == "regexp" for token in tokens)

            # Apply canonicalization to fixed text tokens
            for i, token in enumerate(tokens):
                if token.type in ("char", "escaped-char"):
                    if component_name == "port":
                        continue

                    proto_arg = protocol
                    if component_name == "pathname":
                        proto_arg = "http" if is_special_protocol else "data"

                    try:
                        canon_val = _canonicalize_component(
                            token.value,
                            component_name,
                            proto_arg,
                            is_ipv6_hostname_pattern,
                            for_pattern=True,
                        )
                        tokens[i] = token._replace(value=canon_val)
                    except UnicodeEncodeError:
                        raise TypeError(
                            f"Invalid character in {component_name} pattern"
                        )

            regex, groups = compile_tokens_to_regex(
                tokens, context=context, delimiter=delimiter
            )

            self._compiled_components[component_name] = {
                "regex": re.compile(f"^{regex}$", flags),
                "groups": groups,
                "pattern": component_pattern,
                "has_regexp_groups": has_regexp_groups,
            }
            if has_regexp_groups:
                self._has_regexp_groups = True

    def _compile_dict_pattern(self, pattern: Dict[str, str], base_url: Optional[str]):
        """Compile a dict-based pattern into regex components."""
        # Use the dict components directly
        input_dict = pattern.copy()

        # Check if pattern dict has baseURL key
        if "baseURL" in input_dict:
            if base_url is not None:
                raise TypeError(
                    "Cannot provide both a dictionary pattern and a baseURL argument"
                )
            base_url = input_dict.pop("baseURL")
            if base_url == "":
                raise TypeError("Base URL must not be empty")
        elif base_url is not None:
            raise TypeError(
                "Cannot provide baseURL argument when input is a dictionary"
            )

        # Extract only valid components and validate they are strings
        pattern_components = {}
        for comp_name in _COMPONENTS:
            if comp_name in input_dict:
                val = input_dict[comp_name]
                if val is not None:
                    if not isinstance(val, str):
                        raise TypeError(
                            f"Pattern component '{comp_name}' must be a string, got {type(val).__name__}"
                        )
                    pattern_components[comp_name] = val
                    self._pattern_components.add(comp_name)

        # Handle base URL if provided
        if base_url:
            base_components = _parse_pattern_string(base_url)
            # Inheritance logic per spec
            if "protocol" not in pattern_components:
                if "protocol" in base_components:
                    pattern_components["protocol"] = escape_pattern_syntax(
                        base_components["protocol"]
                    )

                if "hostname" not in pattern_components:
                    if "hostname" in base_components:
                        pattern_components["hostname"] = escape_pattern_syntax(
                            base_components["hostname"]
                        )

                    if "port" not in pattern_components:
                        if "port" in base_components:
                            pattern_components["port"] = escape_pattern_syntax(
                                base_components["port"]
                            )

                        if "pathname" not in pattern_components:
                            if "pathname" in base_components:
                                # Pathname is special, already escaped if needed?
                                # No, spec says escape it.
                                pattern_components["pathname"] = escape_pattern_syntax(
                                    base_components["pathname"]
                                )

                            if "search" not in pattern_components:
                                if "search" in base_components:
                                    pattern_components["search"] = (
                                        escape_pattern_syntax(base_components["search"])
                                    )

                                if "hash" not in pattern_components:
                                    if "hash" in base_components:
                                        pattern_components["hash"] = (
                                            escape_pattern_syntax(
                                                base_components["hash"]
                                            )
                                        )

            # Resolve relative pathname against base URL
            if "pathname" in pattern_components:
                pathname_pattern = pattern_components["pathname"]
                if not _is_absolute_pathname(pathname_pattern) and base_url:
                    try:
                        parsed_base = urlparse(base_url)
                        if not (
                            parsed_base.scheme
                            and parsed_base.scheme not in SPECIAL_SCHEMES
                        ):
                            base_path = parsed_base.path or "/"
                            slash_index = base_path.rfind("/")
                            if slash_index != -1:
                                pattern_components["pathname"] = (
                                    base_path[: slash_index + 1] + pathname_pattern
                                )
                    except Exception:
                        pass

        # Get protocol for port canonicalization
        protocol = pattern_components.get("protocol")
        raw_protocol = protocol
        if protocol:
            protocol = _canonicalize_component(protocol, "protocol")

        # Check if protocol pattern matches a special scheme
        is_special_protocol = _is_special_scheme_pattern(raw_protocol, self.options)
        opaque_defaults = False

        self._compile_components(
            pattern_components,
            is_special_protocol,
            protocol,
            opaque_defaults=opaque_defaults,
        )

    def _compile_pattern(self, pattern: str, base_url: Optional[str]):
        """Compile a pattern string into regex components."""

        # Parse the pattern into components
        pattern_components = _parse_pattern_string(pattern)

        # Track original pattern components
        for comp_name in pattern_components.keys():
            self._pattern_components.add(comp_name)

        # SPEC FIX: If baseURL is null and init["protocol"] does not exist, then throw a TypeError.
        if base_url is None and "protocol" not in pattern_components:
            raise TypeError(
                "Invalid pattern: missing protocol and no base URL provided."
            )

        # Handle relative patterns with base URL
        if base_url:
            base_components = _parse_pattern_string(base_url)

            if pattern.startswith("?"):
                for comp in [
                    "protocol",
                    "hostname",
                    "port",
                    "pathname",
                    "username",
                    "password",
                ]:
                    if comp not in pattern_components and comp in base_components:
                        pattern_components[comp] = escape_pattern_syntax(
                            base_components[comp]
                        )
            elif pattern.startswith("#"):
                for comp in [
                    "protocol",
                    "hostname",
                    "port",
                    "pathname",
                    "username",
                    "password",
                    "search",
                ]:
                    if comp not in pattern_components and comp in base_components:
                        pattern_components[comp] = escape_pattern_syntax(
                            base_components[comp]
                        )
                if "search" not in pattern_components:
                    pattern_components["search"] = ""
            elif pattern.startswith("/"):
                for comp in ["protocol", "hostname", "port", "username", "password"]:
                    if comp not in pattern_components and comp in base_components:
                        pattern_components[comp] = escape_pattern_syntax(
                            base_components[comp]
                        )
            else:
                # Absolute pattern string with baseURL
                if "protocol" not in pattern_components and base_components.get(
                    "protocol"
                ):
                    for comp in [
                        "protocol",
                        "hostname",
                        "port",
                        "username",
                        "password",
                    ]:
                        if comp not in pattern_components and comp in base_components:
                            pattern_components[comp] = escape_pattern_syntax(
                                base_components[comp]
                            )

                    if "pathname" in pattern_components:
                        pathname_pattern = pattern_components["pathname"]
                        if not _is_absolute_pathname(pathname_pattern):
                            base_path = base_components.get("pathname", "/")
                            slash_index = base_path.rfind("/")
                            if slash_index != -1:
                                pattern_components["pathname"] = (
                                    escape_pattern_syntax(base_path[: slash_index + 1])
                                    + pathname_pattern
                                )

        # Get protocol for port canonicalization
        protocol = pattern_components.get("protocol")
        raw_protocol = protocol
        if protocol:
            protocol = _canonicalize_component(protocol, "protocol")

        # Check if protocol pattern matches a special scheme
        is_special_protocol = _is_special_scheme_pattern(raw_protocol, self.options)

        opaque_defaults = (
            not is_special_protocol
            and "hostname" not in pattern_components
            and "port" not in pattern_components
            and "username" not in pattern_components
            and "password" not in pattern_components
        )

        self._compile_components(
            pattern_components,
            is_special_protocol,
            protocol,
            opaque_defaults=opaque_defaults,
        )

    def _compile_empty_pattern(self):
        """
        Compile an empty pattern that matches all URLs with wildcard components.

        Empty pattern (no arguments or empty string/dict) creates a pattern that matches
        any URL, capturing all components as anonymous groups.
        """
        flags = re.IGNORECASE if self.options.get("ignoreCase") else 0
        wildcard_regex = re.compile(r"^(.*)$", flags)
        for component in _COMPONENTS:
            self._compiled_components[component] = {
                "regex": wildcard_regex,
                "groups": ["0"],
                "pattern": "*",
            }

    def test(self, input_url, base_url=None):
        """
        Test if the pattern matches the input URL.

        Args:
            input_url: URL string or dict to test.
                      Examples: "https://example.com/users/123", {"pathname": "/users/123"}
            base_url: Optional base URL for resolving relative URLs.

        Returns:
            bool: True if the pattern matches, False otherwise.

        Examples:
            >>> pattern = URLPattern("/users/:id")
            >>> pattern.test("https://example.com/users/123")
            True
            >>> pattern.test("https://example.com/posts/123")
            False
        """
        result = self.exec(input_url, base_url)
        return result is not None

    def exec(self, input_url=None, base_url=None):
        """
        Execute the pattern against the input URL and return match details.

        Args:
            input_url: URL string or dict to match. If None (no input provided),
                      returns {'inputs': [{}]} for empty patterns.
                      Examples: "https://example.com/users/123"
            base_url: Optional base URL for resolving relative URLs.

        Returns:
            dict: Match result with the following structure:
                {
                    'inputs': [<original input>],
                    'protocol': {'input': '...', 'groups': {...}},
                    'hostname': {'input': '...', 'groups': {...}},
                    'pathname': {'input': '...', 'groups': {...}},
                    'search': {'input': '...', 'groups': {...}},
                    'hash': {'input': '...', 'groups': {...}},
                    ...
                }
                Returns None if no match.

        Examples:
            >>> pattern = URLPattern("/users/:id")
            >>> result = pattern.exec("https://example.com/users/123")
            >>> result['pathname']['groups']['id']
            '123'
        """
        # Handle no input (empty pattern with no input)
        if input_url is None:
            if self.pattern is None or self.pattern == "" or self.pattern == {}:
                url_components = {name: "" for name in _COMPONENTS}
                result = {"inputs": [{}]}
                for component_name in _COMPONENTS:
                    comp = self._compiled_components[component_name]
                    match = comp["regex"].match(url_components[component_name])
                    if not match:
                        return None
                    result[component_name] = {
                        "input": url_components[component_name],
                        "groups": _build_groups(comp["groups"], match),
                    }
                return result
            return None

        original_input = input_url
        original_base_url = base_url

        # Handle dict input
        if isinstance(input_url, dict):
            # SPEC FIX: If input is a URLPatternInit then: If baseURLString was given, throw a TypeError.
            if base_url is not None:
                raise TypeError(
                    "Cannot provide both a dictionary input and a baseURL argument to exec()"
                )
            try:
                processed = _process_urlpattern_init(
                    input_url,
                    "url",
                    protocol="",
                    username="",
                    password="",
                    hostname="",
                    port="",
                    pathname="",
                    search="",
                    hash_value="",
                )
            except Exception:
                return None

            url_components = {
                "protocol": processed.get("protocol", ""),
                "username": processed.get("username", ""),
                "password": processed.get("password", ""),
                "hostname": processed.get("hostname", ""),
                "port": processed.get("port", ""),
                "pathname": processed.get("pathname", ""),
                "search": processed.get("search", ""),
                "hash": processed.get("hash", ""),
            }
        else:
            # Parse the input URL string
            try:
                if base_url:
                    # Validate base_url is absolute per spec
                    base_parsed = urlparse(base_url)
                    if not base_parsed.scheme:
                        return None

                    # If base_url has an opaque path, relative resolution fails
                    # (Simplified check for opaque path: no // after scheme: and not a special scheme)
                    is_opaque_base = (
                        base_parsed.scheme not in SPECIAL_SCHEMES
                        and not base_url.startswith(f"{base_parsed.scheme}://")
                    )
                    if is_opaque_base:
                        # But wait, urljoin might still work if input_url is absolute
                        # If input_url is relative, it fails.
                        input_parsed = urlparse(input_url)
                        if not input_parsed.scheme:
                            return None

                    input_url = urljoin(base_url, input_url)

                # Special case: if input is a special scheme URL without //,
                # urlparse will treat it as opaque. We should manually fix it
                # to support matching hierarchical components per spec match algorithm.
                temp_parsed = urlparse(input_url)
                if temp_parsed.scheme in SPECIAL_SCHEMES and not input_url.startswith(
                    f"{temp_parsed.scheme}://"
                ):
                    # Add // for parsing purposes
                    fixed_url = input_url.replace(
                        f"{temp_parsed.scheme}:", f"{temp_parsed.scheme}://", 1
                    )
                    parsed = urlparse(fixed_url)
                else:
                    parsed = urlparse(input_url)

                if not parsed.scheme and not base_url:
                    # If no scheme and no base_url, it's not a valid absolute URL
                    # but it might be matched as a relative one?
                    # Actually, the spec says "Let url be the result of running the basic URL parser on input with baseURL."
                    # If it fails, return null.
                    # A string without scheme and no base_url fails basic URL parser.
                    if not input_url.startswith("/"):
                        return None
            except Exception:
                return None

            # Extract URL components
            # For IPv6 addresses, parsed.hostname strips brackets, but patterns may include them
            hostname = parsed.hostname or ""
            # Check if this is an IPv6 address and add brackets if needed
            if hostname and ":" in hostname and not hostname.startswith("["):
                hostname = f"[{hostname}]"

            pathname = parsed.path
            if not pathname and parsed.scheme in SPECIAL_SCHEMES:
                pathname = "/"

            url_components = {
                "protocol": parsed.scheme,
                "username": parsed.username or "",
                "password": parsed.password or "",
                "hostname": hostname,
                "port": str(parsed.port) if parsed.port is not None else "",
                "pathname": pathname,
                "search": parsed.query or "",
                "hash": parsed.fragment or "",
            }

        # Canonicalize input components before matching (string inputs only)
        if not isinstance(input_url, dict):
            protocol = url_components.get("protocol", "").lower()  # Get protocol first
            for name, value in url_components.items():
                original_value = value

                # Check for invalid port input
                # Per WHATWG spec and WPT tests, a port string that is not empty
                # but does not start with a digit is invalid and should cause a match failure.
                # Example: "invalid80" -> fail, but "80x" -> 80 (valid)
                if name == "port" and value:
                    cleaned = _strip_control_whitespace(value)
                    if cleaned and not cleaned[0].isdigit():
                        return None

                try:
                    is_ipv6_context = False
                    if name == "hostname" and _is_ipv6_hostname(value):
                        is_ipv6_context = True
                    canonicalized = _canonicalize_component(
                        value, name, protocol, is_ipv6_context
                    )
                except TypeError:
                    return None

                # Check for canonicalization failures
                # If we had a non-empty value but canonicalization returned empty, it's invalid
                if name == "protocol" and original_value and not canonicalized:
                    # Invalid protocol (e.g., contains non-ASCII characters)
                    return None

                url_components[name] = canonicalized

        # Match each component
        if isinstance(original_input, dict):
            inputs = [original_input]
        elif original_base_url is not None:
            inputs = [original_input, original_base_url]
        else:
            inputs = [original_input]

        result = {"inputs": inputs}

        for component_name in _COMPONENTS:
            comp = self._compiled_components.get(component_name)
            if not comp:
                continue

            url_value = url_components.get(component_name, "")
            match = comp["regex"].match(url_value)
            if not match:
                return None

            result[component_name] = {
                "input": url_value,
                "groups": _build_groups(comp["groups"], match),
            }

        return result

    def _raw_component_pattern(self, component: str) -> str:
        comp = self._compiled_components.get(component)
        if not comp:
            return ""
        return comp.get("pattern", "")

    def _component_parts_and_options(self, component: str):
        component_pattern = self._raw_component_pattern(component)
        protocol_pattern = self._raw_component_pattern("protocol")
        options = _parse_options_for_component(
            component, protocol_pattern, component_pattern
        )
        parts = _parse_pattern_to_parts(component_pattern, **options)
        return parts, options

    def _component_pattern(self, component: str) -> str:
        parts, options = self._component_parts_and_options(component)
        return _parts_to_pattern(parts, options)

    @staticmethod
    def compare_component(component: str, left, right) -> int:
        if component not in _COMPONENTS:
            raise TypeError(f"Invalid component '{component}'.")

        left_pattern = left._raw_component_pattern(component)
        right_pattern = right._raw_component_pattern(component)

        def compare_part(left_part, right_part):
            for attr in ("type", "modifier", "prefix", "value", "suffix"):
                left_value = getattr(left_part, attr)
                right_value = getattr(right_part, attr)
                if left_value < right_value:
                    return -1
                if left_value > right_value:
                    return 1
            return 0

        empty_fixed = Part(PartType.FIXED, "", "", "", "", Modifier.NONE)
        wildcard_only = Part(PartType.FULL_WILDCARD, "", "", "", "", Modifier.NONE)

        def compare_part_list(left_parts, right_parts):
            for i in range(min(len(left_parts), len(right_parts))):
                result = compare_part(left_parts[i], right_parts[i])
                if result:
                    return result
            if len(left_parts) == len(right_parts):
                return 0
            i = min(len(left_parts), len(right_parts))
            left_next = left_parts[i] if i < len(left_parts) else empty_fixed
            right_next = right_parts[i] if i < len(right_parts) else empty_fixed
            return compare_part(left_next, right_next)

        if not left_pattern and not right_pattern:
            return 0

        left_parts, _ = left._component_parts_and_options(component)
        right_parts, _ = right._component_parts_and_options(component)

        if left_pattern and not right_pattern:
            return compare_part_list(left_parts, [wildcard_only])
        if not left_pattern and right_pattern:
            return compare_part_list([wildcard_only], right_parts)
        return compare_part_list(left_parts, right_parts)

    def generate(self, component: str, groups: dict):
        if component not in _COMPONENTS:
            raise TypeError(f"Invalid component '{component}'.")
        if not isinstance(groups, dict):
            raise TypeError("Groups must be a dictionary")

        parts, options = self._component_parts_and_options(component)
        delimiter = options["delimiter"]
        encode_part = options["encode_part"]
        result = ""

        for part in parts:
            if part.type == PartType.FIXED:
                if part.modifier != Modifier.NONE:
                    raise TypeError("Cannot generate from modified fixed text")
                result += part.value
                continue

            if part.modifier != Modifier.NONE:
                raise TypeError("Cannot generate from modified groups")

            if part.type in (PartType.REGEX, PartType.FULL_WILDCARD):
                raise TypeError("Cannot generate from regex or wildcard groups")

            name = part.name
            if name not in groups:
                raise TypeError(f"Missing group '{name}'.")

            value = groups[name]
            if not isinstance(value, str):
                value = str(value)

            if (
                part.type == PartType.SEGMENT_WILDCARD
                and delimiter
                and delimiter in value
            ):
                raise TypeError("Segment value contains a delimiter")

            encoded = encode_part(value) if encode_part else value
            result += f"{part.prefix}{encoded}{part.suffix}"

        return result

    @property
    def protocol(self):
        """Get the protocol component pattern string."""
        return self._component_pattern("protocol")

    @property
    def username(self):
        """Get the username component pattern string."""
        return self._component_pattern("username")

    @property
    def password(self):
        """Get the password component pattern string."""
        return self._component_pattern("password")

    @property
    def hostname(self):
        """Get the hostname component pattern string."""
        return self._component_pattern("hostname")

    @property
    def port(self):
        """Get the port component pattern string."""
        return self._component_pattern("port")

    @property
    def pathname(self):
        """Get the pathname component pattern string."""
        return self._component_pattern("pathname")

    @property
    def search(self):
        """Get the search component pattern string."""
        return self._component_pattern("search")

    @property
    def hash(self):
        """Get the hash component pattern string."""
        return self._component_pattern("hash")

    @property
    def hasRegExpGroups(self):
        """Check if pattern contains regexp groups."""
        return self._has_regexp_groups


__all__ = ["URLPattern"]
