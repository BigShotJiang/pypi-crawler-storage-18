"""
Compiler for converting tokens into Python regular expressions.

This module takes the token stream from the parser and converts it
into a valid Python `re` regex pattern.
"""

import re
from typing import Dict, List, Optional, Tuple

from .normalizer import escape_pattern_string, normalize_regex_pattern
from .parser import Token


def _get_segment_wildcard_pattern(context: str, separator: Optional[str] = None) -> str:
    """
    Get the regex pattern for segment wildcards based on context and separator.
    """
    if separator:
        escaped = escape_pattern_string(separator)
        return f"[^{escaped}]+?"

    # Default patterns if no separator provided
    patterns = {
        "pathname": "[^/]+?",
        "hostname": "[^.]+?",
        "protocol": "[^:/?#]+?",
        "username": "[^:/?#@]+?",
        "password": "[^:/?#@]+?",
        "port": "\\d*",
        "search": "[^#]*?",
        "hash": ".*?",
    }
    return patterns.get(context, "[^/]+?")


def _get_full_wildcard_pattern() -> str:
    """
    Get the regex pattern for full wildcards.

    Per spec: "full-wildcard" greedily matches all code points.
    This is used for standalone * wildcards.

    Returns:
        Regex pattern string for matching everything
    """
    return ".*"


def _split_simple_group_tokens(tokens: List[Token]) -> Optional[Dict[str, object]]:
    """Return components for a trivial {prefix:name:suffix} group or None."""
    prefix_tokens = []
    idx = 0
    while idx < len(tokens) and tokens[idx].type in ("char", "escaped-char"):
        prefix_tokens.append(tokens[idx].value)
        idx += 1

    if idx >= len(tokens):
        return None

    unit_token = tokens[idx]
    if unit_token.type not in ("name", "regexp", "asterisk"):
        return None
    idx += 1

    unit_regexp = None
    if unit_token.type == "name" and idx < len(tokens) and tokens[idx].type == "regexp":
        unit_regexp = tokens[idx]
        idx += 1

    suffix_tokens = tokens[idx:]
    if any(token.type not in ("char", "escaped-char") for token in suffix_tokens):
        return None

    return {
        "prefix": "".join(prefix_tokens),
        "unit_token": unit_token,
        "unit_regexp": unit_regexp,
        "suffix": "".join(token.value for token in suffix_tokens),
    }


def compile_tokens_to_regex(
    tokens: List[Token],
    context: str = "pathname",
    _state: Optional[Dict] = None,
    delimiter: Optional[str] = None,
) -> Tuple[str, List[str]]:
    """
    Compile URL pattern tokens into a Python regex string.

    Args:
        tokens: List of tokens from the parser
        context: URL component context ('pathname', 'hostname', 'protocol', etc.)
                Affects how wildcards are compiled.
        _state: Internal state for recursive calls
        delimiter: The separator character for segments (e.g. '/' for pathname)

    Returns:
        Tuple of (regex_string, group_names)
    """
    if not tokens:
        return ("", [])

    if _state is None:
        _state = {"anonymous_group_count": 0, "seen_names": {}}

    regex_parts = []
    group_names = []

    # Use provided delimiter or default based on context.
    separator = delimiter
    if separator is None:
        if context == "pathname":
            separator = "/"
        elif context == "hostname":
            separator = "."

    escaped_separator = escape_pattern_string(separator) if separator else None

    i = 0
    while i < len(tokens):
        token = tokens[i]

        # End token - stop processing
        if token.type == "end":
            break

        # CHAR token - literal text
        elif token.type == "char":
            regex_parts.append(escape_pattern_string(token.value))
            i += 1

        # ESCAPED_CHAR token - literal character (already unescaped)
        elif token.type == "escaped-char":
            regex_parts.append(escape_pattern_string(token.value))
            i += 1

        # Modifiable Units: NAME, REGEXP, ASTERISK, OPEN
        elif token.type in ("name", "regexp", "asterisk", "open"):
            # --- Consume the Unit and determine its Pattern ---

            unit_pattern = ""
            unit_group_name = ""
            is_capturing = False  # Does this unit create a capture group?
            is_name_token = token.type == "name"
            is_asterisk_token = token.type == "asterisk"
            open_group_tokens = None
            open_group_simple = None

            # Helper to track where we should continue after this unit
            next_idx = i + 1

            if token.type == "name":
                name = token.value
                is_capturing = True

                # Check for custom regexp following name (e.g., :id(\d+))
                if next_idx < len(tokens) and tokens[next_idx].type == "regexp":
                    unit_pattern = normalize_regex_pattern(tokens[next_idx].value)
                    next_idx += 1
                else:
                    unit_pattern = _get_segment_wildcard_pattern(context, separator)

                # Deduplicate name
                if name in _state["seen_names"]:
                    raise TypeError(f"Duplicate group name: {name}")
                else:
                    _state["seen_names"][name] = 0
                    unit_group_name = name
                group_names.append(name)

            elif token.type == "regexp":
                # Standalone regexp group (e.g., (\d+))
                unit_pattern = normalize_regex_pattern(token.value)
                unit_group_name = str(_state["anonymous_group_count"])
                group_names.append(unit_group_name)
                _state["anonymous_group_count"] += 1
                is_capturing = True

            elif token.type == "asterisk":
                # Standalone wildcard *
                unit_pattern = _get_full_wildcard_pattern()
                unit_group_name = str(_state["anonymous_group_count"])
                group_names.append(unit_group_name)
                _state["anonymous_group_count"] += 1
                is_capturing = True

            elif token.type == "open":
                # Nested group { ... }
                # Find matching close brace
                depth = 1
                group_start = i + 1
                group_end = group_start

                while group_end < len(tokens) and depth > 0:
                    if tokens[group_end].type == "open":
                        depth += 1
                    elif tokens[group_end].type == "close":
                        depth -= 1
                    group_end += 1

                if depth != 0:
                    raise ValueError(f"Unclosed group starting at index {token.index}")

                group_tokens = tokens[group_start : group_end - 1]

                # Check for nested groups (disallowed by spec)
                for t in group_tokens:
                    if t.type == "open":
                        raise TypeError(
                            f"Nested groups are not allowed at index {t.index}"
                        )

                open_group_tokens = group_tokens
                open_group_simple = _split_simple_group_tokens(group_tokens)

                next_idx = group_end
                # Open groups are non-capturing containers (inner logic handles capturing)
                is_capturing = False

            # --- Lookahead for Modifier ---

            modifier = None
            if next_idx < len(tokens):
                next_token = tokens[next_idx]
                if next_token.type == "other-modifier":
                    # ? or +
                    modifier = next_token.value
                    next_idx += 1
                elif next_token.type == "asterisk":
                    # Asterisk appearing immediately after a unit acts as a modifier (*)
                    modifier = "*"
                    next_idx += 1

            if (
                token.type == "open"
                and modifier in ("*", "+")
                and open_group_simple is not None
                and open_group_simple["unit_token"].type == "name"
            ):
                name_token = open_group_simple["unit_token"]
                name = name_token.value
                if name in _state["seen_names"]:
                    raise TypeError(f"Duplicate group name: {name}")
                _state["seen_names"][name] = 0
                group_names.append(name)

                if open_group_simple["unit_regexp"] is not None:
                    unit_pattern = normalize_regex_pattern(
                        open_group_simple["unit_regexp"].value
                    )
                else:
                    unit_pattern = _get_segment_wildcard_pattern(context, separator)

                prefix_regex = escape_pattern_string(open_group_simple["prefix"])
                suffix_regex = escape_pattern_string(open_group_simple["suffix"])
                joiner = f"{suffix_regex}{prefix_regex}"
                if joiner:
                    core = f"{unit_pattern}(?:{joiner}{unit_pattern})*"
                else:
                    core = f"{unit_pattern}(?:{unit_pattern})*"

                if modifier == "*":
                    if prefix_regex or suffix_regex:
                        regex_parts.append(
                            f"(?:{prefix_regex}(?P<{name}>{core}){suffix_regex})?"
                        )
                    else:
                        regex_parts.append(f"(?P<{name}>{core})?")
                else:
                    if prefix_regex or suffix_regex:
                        regex_parts.append(
                            f"{prefix_regex}(?P<{name}>{core}){suffix_regex}"
                        )
                    else:
                        regex_parts.append(f"(?P<{name}>{core})")

                i = next_idx
                continue

            if token.type == "open":
                group_regex, group_group_names = compile_tokens_to_regex(
                    open_group_tokens, context, _state, separator
                )

                unit_pattern = group_regex
                group_names.extend(group_group_names)

            # --- Check for Preceding Separator (Segment Awareness) ---

            # If the regex built so far ends with the context separator (e.g. '/'),
            # we might need to consume it to make it part of the optional/repeated structure.
            has_preceding_separator = False
            if separator and token.type != "open" and regex_parts:
                if regex_parts[-1].endswith(escaped_separator):
                    has_preceding_separator = True

            # --- Construct the Regex Fragment ---

            # Determine the basic group regex (without modifiers yet)
            if is_capturing:
                if is_name_token:
                    group_regex = f"(?P<{unit_group_name}>{unit_pattern})"
                else:
                    # Anonymous capturing group
                    group_regex = f"({unit_pattern})"
            else:
                # Non-capturing (used for OPEN group results)
                group_regex = f"(?:{unit_pattern})"

            # Determine the unit regex (non-capturing)
            # This is the raw pattern for the unit, wrapped in non-capturing group if needed
            # to ensure modifiers apply to the whole unit
            atom = f"(?:{unit_pattern})"

            if modifier == "?":
                if has_preceding_separator:
                    # Case: /:foo? -> (?:/(?P<foo>...))?
                    # Pop the separator from the previous part
                    last_part = regex_parts.pop()
                    prefix = last_part[: -len(escaped_separator)]
                    if prefix:
                        regex_parts.append(prefix)

                    # Wrap the separator + capture group
                    if is_capturing:
                        if is_name_token:
                            regex_parts.append(
                                f"(?:{escaped_separator}(?P<{unit_group_name}>{unit_pattern}))?"
                            )
                        else:
                            regex_parts.append(
                                f"(?:{escaped_separator}({unit_pattern}))?"
                            )
                    else:
                        regex_parts.append(f"(?:{escaped_separator}{unit_pattern})?")
                else:
                    # Standard optional
                    actual_pattern = unit_pattern
                    # Hack: Python re matches (.*)? as "" instead of None when empty.
                    # Change to (.+)? to force None when empty, aligning with JS behavior.
                    if unit_pattern == ".*":
                        actual_pattern = ".+"

                    if is_capturing:
                        if is_name_token:
                            regex_parts.append(
                                f"(?P<{unit_group_name}>{actual_pattern})?"
                            )
                        else:
                            regex_parts.append(f"({actual_pattern})?")
                    else:
                        regex_parts.append(f"{atom}?")

            elif modifier == "+":
                should_repeat_separator = (
                    separator and token.type != "open" and not is_asterisk_token
                )

                if should_repeat_separator:
                    # Complex pattern: atom (?: separator atom )*
                    complex_pattern = (
                        f"{unit_pattern}(?:{escaped_separator}{unit_pattern})*"
                    )

                    if is_name_token:
                        regex_parts.append(f"(?P<{unit_group_name}>{complex_pattern})")
                    elif is_capturing:
                        regex_parts.append(f"({complex_pattern})")
                    else:
                        regex_parts.append(f"(?:{complex_pattern})")
                else:
                    # Standard repetition: ((?:unit)+)
                    # We wrap the repetition inside the capture group to catch the full match
                    repeated_atom = f"{atom}+"

                    if is_name_token:
                        regex_parts.append(f"(?P<{unit_group_name}>{repeated_atom})")
                    elif is_capturing:
                        regex_parts.append(f"({repeated_atom})")
                    else:
                        regex_parts.append(repeated_atom)

            elif modifier == "*":
                should_repeat_separator = (
                    separator and token.type != "open" and not is_asterisk_token
                )

                if has_preceding_separator:
                    # Pop separator
                    last_part = regex_parts.pop()
                    prefix = last_part[: -len(escaped_separator)]
                    if prefix:
                        regex_parts.append(prefix)

                    # Complex optional repeating with separator
                    if should_repeat_separator:
                        # (?: separator (unit (?: separator unit)* ) )?
                        core_pattern = (
                            f"{unit_pattern}(?:{escaped_separator}{unit_pattern})*"
                        )
                    else:
                        # (?: separator (unit+) )?
                        core_pattern = f"{atom}+"

                    if is_name_token:
                        regex_parts.append(
                            f"(?:{escaped_separator}(?P<{unit_group_name}>{core_pattern}))?"
                        )
                    elif is_capturing:
                        regex_parts.append(f"(?:{escaped_separator}({core_pattern}))?")
                    else:
                        regex_parts.append(f"(?:{escaped_separator}{core_pattern})?")
                else:
                    # Standard *
                    if should_repeat_separator:
                        # (?: unit (?: separator unit)* )?
                        # Note: This is 0 or more, so we wrap the 1+ logic in optional
                        # But wait, if it matches 0, the capture group should probably be empty/None?
                        # Spec usually implies the named group wraps the whole thing.
                        core_pattern = (
                            f"{unit_pattern}(?:{escaped_separator}{unit_pattern})*"
                        )
                        if is_name_token:
                            regex_parts.append(
                                f"(?P<{unit_group_name}>{core_pattern})?"
                            )
                        elif is_capturing:
                            regex_parts.append(f"({core_pattern})?")
                        else:
                            regex_parts.append(f"(?:{core_pattern})?")
                    else:
                        # ((?:unit)*)
                        repeated_atom = f"{atom}*"
                        if is_name_token:
                            regex_parts.append(
                                f"(?P<{unit_group_name}>{repeated_atom})"
                            )
                        elif is_capturing:
                            regex_parts.append(f"({repeated_atom})")
                        else:
                            regex_parts.append(repeated_atom)

            else:
                # No modifier
                if is_capturing:
                    if is_name_token:
                        regex_parts.append(f"(?P<{unit_group_name}>{unit_pattern})")
                    else:
                        regex_parts.append(f"({unit_pattern})")
                else:
                    regex_parts.append(atom)

            # Update loop index
            i = next_idx

        # Dangling modifier tokens (should have been consumed by lookahead)
        elif token.type == "other-modifier":
            raise ValueError(
                f"Modifier '{token.value}' at index {token.index} has no preceding group"
            )

        # CLOSE token - should be handled by OPEN processing
        elif token.type == "close":
            raise ValueError(f"Unmatched close brace at index {token.index}")

        # INVALID_CHAR token
        elif token.type == "invalid-char":
            raise ValueError(
                f"Invalid character '{token.value}' at index {token.index}"
            )

        else:
            # Unknown token type, skip or error
            # (original code had error handling here, keeping it same)
            if token.type == "other-modifier":
                raise ValueError(
                    f"Modifier '{token.value}' at index {token.index} has no preceding group"
                )
            elif token.type == "close":
                raise ValueError(f"Unmatched close brace at index {token.index}")
            elif token.type == "invalid-char":
                raise ValueError(
                    f"Invalid character '{token.value}' at index {token.index}"
                )
            else:
                i += 1

    regex_string = "".join(regex_parts)

    # Validate the generated regex
    try:
        re.compile(regex_string)
    except re.error as e:
        raise ValueError(f"Generated invalid regex: {regex_string}\nError: {e}")

    return (regex_string, group_names)
