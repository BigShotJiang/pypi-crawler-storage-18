"""
Tests for confee package.
"""

