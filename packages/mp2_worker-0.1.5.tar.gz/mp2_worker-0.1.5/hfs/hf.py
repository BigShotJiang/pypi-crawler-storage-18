"""HuggingFace API 封装（按 v2 设计文档）"""
from huggingface_hub import HfApi, SpaceHardware
from typing import Optional, Dict, List
import random
import tempfile
import os


# Docker 模板列表
DOCKER_TEMPLATES = [
    'SpacesExamples/Gradio-Docker-Template',
]


def create_space(space_id: str, token: str, template: str = None) -> Optional[Dict]:
    """创建 HuggingFace Space
    
    Args:
        space_id: Space ID（不含用户名前缀）
        token: HF token
        template: Docker 模板（可选，默认随机选择）
    
    Returns:
        Space 信息字典，失败返回 None
    """
    api = HfApi()
    
    try:
        # 获取用户名
        user_info = api.whoami(token=token)
        username = user_info['name']
        
        # 完整 Space ID
        full_space_id = f"{username}/{space_id}"
        
        # 随机选择模板
        if not template:
            template = random.choice(DOCKER_TEMPLATES)
        
        # 创建 Space（从模板复制）
        space = api.duplicate_space(
            from_id=template,
            to_id=full_space_id,
            token=token,
            exist_ok=False,
            private=True,  # 必须私有
            hardware=SpaceHardware.CPU_BASIC
        )
        
        # 修改 README title（避免显示模板名）
        try:
            readme = f"""---
title: {space_id}
emoji: 🚀
colorFrom: blue
colorTo: purple
sdk: docker
pinned: false
---
"""
            api.upload_file(
                path_or_fileobj=readme.encode(),
                path_in_repo="README.md",
                repo_id=full_space_id,
                repo_type="space",
                token=token
            )
        except:
            pass  # 忽略 README 更新失败
        
        return {
            'id': full_space_id,
            'url': f"https://huggingface.co/spaces/{full_space_id}",
            'template': template
        }
    
    except Exception as e:
        print(f"[HF] Create space failed: {e}")
        return None


def get_space_status(space_id: str, token: str = None) -> Optional[Dict]:
    """查询 Space 状态
    
    Args:
        space_id: 完整 Space ID（username/space-name）
        token: HF token（可选）
    
    Returns:
        Space 状态字典，失败返回 None
    """
    api = HfApi()
    
    try:
        space_info = api.space_info(space_id, token=token)
        
        return {
            'id': space_info.id,
            'status': space_info.runtime.stage if space_info.runtime else 'unknown',
            'hardware': space_info.runtime.hardware if space_info.runtime else None
        }
    
    except Exception as e:
        print(f"[HF] Get space status failed for {space_id}: {e}", flush=True)
        return None


def delete_space(space_id: str, token: str) -> bool:
    """删除 Space"""
    api = HfApi()
    try:
        api.delete_repo(space_id, token=token, repo_type='space')
        return True
    except Exception as e:
        print(f"[HF] Delete space failed: {e}")
        return False


def deploy_worker(space_id: str, token: str, redis_url: str,
                  project_id: str = None, node_id: str = None) -> bool:
    """通过 git clone/push 部署完整 hfs/ 包到 Space"""
    import subprocess
    import shutil
    
    api = HfApi()
    
    try:
        user_info = api.whoami(token=token)
        username = user_info['name']
    except:
        print('[HF] Failed to get username')
        return False
    
    # 找到 hfs/ 源码目录
    hfs_src = os.path.join(os.path.dirname(__file__))
    if not os.path.exists(os.path.join(hfs_src, 'worker.py')):
        print('[HF] Cannot find hfs source')
        return False
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 1. Git clone
        print(f'[HF] Cloning {space_id}...', flush=True)
        clone_url = f"https://{username}:{token}@huggingface.co/spaces/{space_id}"
        result = subprocess.run(['git', 'clone', clone_url, tmpdir],
                               capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            print(f'[HF] Git clone failed: {result.stderr[:100]}', flush=True)
            return False
        
        # 2. 配置 git
        subprocess.run(['git', 'config', 'user.email', 'hfs@example.com'], cwd=tmpdir)
        subprocess.run(['git', 'config', 'user.name', 'HFS'], cwd=tmpdir)
        
        # 3. 复制完整 hfs/ 包（先删除旧的）
        print(f'[HF] Copying code...', flush=True)
        hfs_dst = os.path.join(tmpdir, 'hfs')
        if os.path.exists(hfs_dst):
            shutil.rmtree(hfs_dst)
        shutil.copytree(hfs_src, hfs_dst, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        
        # 4. 创建启动脚本（带错误捕获）
        main_py = f'''#!/usr/bin/env python3
"""HFS Worker Entry Point"""
import os, sys, json, time, traceback

REDIS_URL = "{redis_url}"
SPACE_ID = "{space_id}"

def log_to_redis(msg, level='INFO'):
    try:
        import redis
        from urllib.parse import urlparse
        p = urlparse(REDIS_URL)
        db = int(p.path.lstrip('/')) if p.path else 0
        r = redis.Redis(host=p.hostname, port=p.port or 6379, password=p.password, db=db, decode_responses=True)
        entry = {{'ts': int(time.time()), 'space': SPACE_ID, 'level': level, 'msg': msg}}
        r.lpush('hfs:boot:logs', json.dumps(entry))
        r.ltrim('hfs:boot:logs', 0, 999)
    except: pass

log_to_redis('main.py starting')

try:
    os.environ['HFS_REDIS_URL'] = REDIS_URL
    os.environ['HFS_SPACE_ID'] = SPACE_ID
    os.environ['HFS_PROJECT_ID'] = "{project_id or ''}"
    os.environ['HFS_NODE_ID'] = "{node_id or ''}"
    
    log_to_redis('importing hfs.worker')
    from hfs.worker import Worker
    
    log_to_redis('creating Worker')
    worker = Worker(
        redis_url=REDIS_URL,
        space_id=SPACE_ID,
        project_id=os.environ.get('HFS_PROJECT_ID') or None,
        node_id=os.environ.get('HFS_NODE_ID') or None
    )
    
    log_to_redis('starting Worker.run()')
    worker.run()
except Exception as e:
    err = traceback.format_exc()
    log_to_redis(f'CRASH: {{err}}', 'ERROR')
    print(f'CRASH: {{err}}', file=sys.stderr)
    raise
'''
        with open(os.path.join(tmpdir, 'main.py'), 'w') as f:
            f.write(main_py)
        
        # 5. 创建 Dockerfile
        dockerfile = '''FROM python:3.11-slim
WORKDIR /app
RUN apt-get update && apt-get install -y git && rm -rf /var/lib/apt/lists/*
RUN pip install redis huggingface_hub
COPY hfs/ ./hfs/
COPY main.py .
CMD ["python", "main.py"]
'''
        with open(os.path.join(tmpdir, 'Dockerfile'), 'w') as f:
            f.write(dockerfile)
        
        # 6. Git add, commit, push
        print(f'[HF] Pushing...', flush=True)
        subprocess.run(['git', 'add', '.'], cwd=tmpdir)
        subprocess.run(['git', 'commit', '-m', 'Deploy HFS worker'],
                      cwd=tmpdir, capture_output=True)
        
        result = subprocess.run(['git', 'push'], cwd=tmpdir,
                               capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            print(f'[HF] Git push failed: {result.stderr[:100]}', flush=True)
            return False
        
        print(f'[HF] Worker deployed to {space_id}', flush=True)
        return True


def pause_space(space_id: str, token: str) -> bool:
    """暂停 Space 容器释放资源"""
    try:
        api = HfApi()
        api.pause_space(repo_id=space_id, token=token)
        return True
    except Exception as e:
        print(f'[HF] Pause space failed: {e}')
        return False


def deploy_worker_pip(space_id: str, token: str, redis_url: str,
                      project_id: str = None, node_id: str = None,
                      hfs_version: str = None) -> bool:
    """通过 pip 安装方式部署 Worker（轻量级）
    
    只推送 main.py 和 Dockerfile，Worker 代码通过 pip install 获取
    """
    import subprocess
    
    api = HfApi()
    
    try:
        user_info = api.whoami(token=token)
        username = user_info['name']
    except:
        print('[HF] Failed to get username')
        return False
    
    pip_pkg = f'mp2-worker=={hfs_version}' if hfs_version else 'mp2-worker'
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 1. Git clone
        print(f'[HF] Cloning {space_id}...', flush=True)
        clone_url = f"https://{username}:{token}@huggingface.co/spaces/{space_id}"
        result = subprocess.run(['git', 'clone', clone_url, tmpdir],
                               capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            print(f'[HF] Git clone failed: {result.stderr[:100]}', flush=True)
            return False
        
        # 2. 配置 git
        subprocess.run(['git', 'config', 'user.email', 'hfs@example.com'], cwd=tmpdir)
        subprocess.run(['git', 'config', 'user.name', 'HFS'], cwd=tmpdir)
        
        # 3. 创建 main.py（pip 安装版）
        print(f'[HF] Creating main.py (pip mode)...', flush=True)
        main_py = f'''#!/usr/bin/env python3
"""HFS Worker Entry Point (pip install mode)"""
import os
import subprocess
import sys

# 安装 hfs-worker
subprocess.check_call([sys.executable, '-m', 'pip', 'install', '{pip_pkg}'])

# 启动 Worker
from hfs.worker import Worker

worker = Worker(
    redis_url="{redis_url}",
    space_id="{space_id}",
    project_id="{project_id or ''}",
    node_id="{node_id or ''}",
)
worker.run()
'''
        with open(os.path.join(tmpdir, 'main.py'), 'w') as f:
            f.write(main_py)
        
        # 4. 创建 Dockerfile（更简洁）
        dockerfile = '''FROM python:3.11-slim
WORKDIR /app
COPY main.py .
CMD ["python", "main.py"]
'''
        with open(os.path.join(tmpdir, 'Dockerfile'), 'w') as f:
            f.write(dockerfile)
        
        # 5. 删除旧的 hfs/ 目录（如果存在）
        hfs_dir = os.path.join(tmpdir, 'hfs')
        if os.path.exists(hfs_dir):
            import shutil
            shutil.rmtree(hfs_dir)
        
        # 6. Git add, commit, push
        print(f'[HF] Pushing...', flush=True)
        subprocess.run(['git', 'add', '.'], cwd=tmpdir)
        subprocess.run(['git', 'commit', '-m', 'Deploy HFS worker (pip mode)'],
                      cwd=tmpdir, capture_output=True)
        
        result = subprocess.run(['git', 'push'], cwd=tmpdir,
                               capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            print(f'[HF] Git push failed: {result.stderr[:100]}', flush=True)
            return False
        
        print(f'[HF] Worker deployed to {space_id} (pip mode)', flush=True)
        return True


def wait_for_build(space_id: str, token: str, timeout: int = 300, redis_client=None) -> str:
    """等待 Space 构建完成
    
    优先检查 Worker 心跳（更可靠），HF stage 作为辅助判断
    
    Returns:
        最终状态 ('RUNNING', 'PAUSED', 'STOPPED') 或 None 表示失败/超时
    """
    import time
    import json
    api = HfApi(token=token)
    start = time.time()
    last_stage = None
    
    while time.time() - start < timeout:
        try:
            # 优先检查 Worker 心跳
            if redis_client:
                space_data = redis_client.get(f'hfs:space:{space_id}')
                if space_data:
                    space = json.loads(space_data)
                    if space.get('status') == 'running':
                        last_hb = space.get('last_heartbeat', 0)
                        if time.time() - last_hb < 60:
                            print(f'[HF] Worker running (heartbeat ok)', flush=True)
                            return 'RUNNING'
            
            # 检查 HF stage
            runtime = api.get_space_runtime(space_id)
            stage = runtime.stage
            
            if stage in ('RUNNING', 'PAUSED', 'STOPPED'):
                print(f'[HF] Build completed: {stage}', flush=True)
                return stage
            
            # RUNTIME_ERROR 可能是旧代码错误，部署新代码后会重新构建
            # 继续等待，除非连续多次都是 RUNTIME_ERROR
            if stage == 'RUNTIME_ERROR':
                if last_stage == 'RUNTIME_ERROR':
                    # 连续两次 RUNTIME_ERROR，可能是新代码也有问题
                    elapsed = time.time() - start
                    if elapsed > 60:  # 等待至少 60 秒
                        print(f'[HF] Build failed: persistent RUNTIME_ERROR', flush=True)
                        return None
            
            last_stage = stage
            print(f'[HF] Building... stage={stage}', flush=True)
            time.sleep(5)
        except Exception as e:
            print(f'[HF] Check build status failed: {e}', flush=True)
            time.sleep(5)
    
    print(f'[HF] Build timeout after {timeout}s', flush=True)
    return None


def restart_space(space_id: str, token: str) -> bool:
    """重启 Space 容器"""
    try:
        api = HfApi()
        api.restart_space(repo_id=space_id, token=token)
        return True
    except Exception as e:
        print(f'[HF] Restart space failed: {e}')
        return False

