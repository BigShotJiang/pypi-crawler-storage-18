"""Tests for frontmatter-mcp."""
