# Security Policy

## Supported Versions

| Version       | Supported          |
| ------------- | ------------------ |
| 2.0           | :white_check_mark: |
| < 2.0         | :x:                |

## Reporting a Vulnerability

Please report security vulnerabilities by email to [info@pyrgg.site](mailto:info@pyrgg.site "info@pyrgg.site").

If the security vulnerability is accepted, a dedicated bugfix release will be issued as soon as possible (depending on the complexity of the fix).