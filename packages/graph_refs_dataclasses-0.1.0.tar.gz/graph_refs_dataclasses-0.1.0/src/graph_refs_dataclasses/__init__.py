"""
graph-refs-dataclasses: Dataclass runtime machinery for declarative DSLs.

This package provides the runtime machinery to build declarative DSLs using
dataclasses with the graph-refs type marker library. It enables the "no-parens"
pattern where references are expressed as class names rather than function calls.

The No-Parens Pattern:
    # Traditional (with parentheses)
    parent = get_ref(Object1)
    parent_id = get_attr(Object1, "Id")

    # No-parens (cleaner, declarative)
    parent = Object1
    parent_id = Object1.Id

Architecture layer:
    graph-refs              (type markers: Ref[T], Attr[T, "name"])
        |
        v
    graph-refs-dataclasses  (dataclass machinery: decorator, registry, ordering)
        |
        v
    domain packages         (your application-specific implementation)

Example:
    >>> from graph_refs_dataclasses import create_decorator, ResourceRegistry
    >>>
    >>> # Create domain-specific decorator
    >>> registry = ResourceRegistry()
    >>> refs = create_decorator(registry=registry)
    >>>
    >>> @refs
    ... class Object1:
    ...     name: str = "object-1"
    ...
    >>> @refs
    ... class Object2:
    ...     parent = Object1          # No-parens class reference
    ...     parent_id = Object1.Id    # No-parens attribute reference
    ...
    >>> @refs
    ... class Object3:
    ...     dependency = Object2      # Depends on Object2
    ...
    >>> # Get dependencies
    >>> deps = get_dependencies(Object3)
    >>> Object2 in deps
    True
    >>>
    >>> # Topological ordering (dependencies first)
    >>> order = get_creation_order([Object3, Object2, Object1])
    >>> [c.__name__ for c in order]
    ['Object1', 'Object2', 'Object3']
"""

from __future__ import annotations

# Version
__version__ = "0.1.0"

# Runtime marker for attribute references
# Re-export graph-refs types for convenience
from graph_refs import (
    Attr,
    ContextRef,
    Ref,
    RefDict,
    RefInfo,
    RefList,
    get_dependencies,
    get_refs,
)

from graph_refs_dataclasses._attr_ref import AttrRef

# Decorator factory
from graph_refs_dataclasses._decorator import create_decorator

# Loader for multi-file packages
from graph_refs_dataclasses._loader import (
    find_class_definitions as find_class_definitions_in_source,
)
from graph_refs_dataclasses._loader import (
    find_refs_in_source,
    setup_resources,
)

# Metaclass for no-parens pattern
from graph_refs_dataclasses._metaclass import RefMeta

# Dependency ordering utilities
from graph_refs_dataclasses._ordering import (
    detect_cycles,
    get_all_dependencies,
    get_creation_order,
    get_deletion_order,
    get_dependency_graph,
    topological_sort,
)

# Provider ABC for serialization
from graph_refs_dataclasses._provider import Provider

# Registry for tracking decorated classes
from graph_refs_dataclasses._registry import ResourceRegistry

# Stub generation for IDE support
from graph_refs_dataclasses._stubs import (
    StubConfig,
    find_class_definitions,
    find_resource_packages,
    generate_stub_file,
    generate_stubs_for_path,
)

# Template base class
from graph_refs_dataclasses._template import Template

# Helper functions
from graph_refs_dataclasses._utils import (
    DEFAULT_MARKER,
    apply_metaclass,
    get_ref_target,
    is_attr_ref,
    is_class_ref,
)

__all__ = [
    # Version
    "__version__",
    # Runtime markers
    "AttrRef",
    # Metaclass
    "RefMeta",
    # Decorator factory
    "create_decorator",
    # Registry
    "ResourceRegistry",
    # Ordering utilities
    "get_all_dependencies",
    "topological_sort",
    "get_creation_order",
    "get_deletion_order",
    "detect_cycles",
    "get_dependency_graph",
    # Provider
    "Provider",
    # Template
    "Template",
    # Loader
    "setup_resources",
    "find_refs_in_source",
    "find_class_definitions_in_source",
    # Stubs
    "StubConfig",
    "generate_stub_file",
    "find_class_definitions",
    "find_resource_packages",
    "generate_stubs_for_path",
    # Helpers
    "is_attr_ref",
    "is_class_ref",
    "get_ref_target",
    "apply_metaclass",
    "DEFAULT_MARKER",
    # Re-exported from graph-refs
    "Ref",
    "Attr",
    "RefList",
    "RefDict",
    "ContextRef",
    "RefInfo",
    "get_refs",
    "get_dependencies",
]
