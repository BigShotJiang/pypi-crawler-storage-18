# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-12-27

### Added

- Initial release
- `AttrRef` - Runtime marker for attribute references (no-parens pattern)
- `RefMeta` - Metaclass enabling no-parens attribute interception
- `create_decorator()` - Factory for creating domain-specific decorators
- `ResourceRegistry` - Thread-safe registry for decorated classes
- Dependency ordering utilities:
  - `get_all_dependencies()` - Get all dependencies of a class
  - `topological_sort()` - Sort classes by dependency order
  - `get_creation_order()` - Get creation order (dependencies first)
  - `get_deletion_order()` - Get deletion order (dependents first)
  - `detect_cycles()` - Detect circular dependencies
  - `get_dependency_graph()` - Build dependency graph
- `Provider` - Abstract base class for serialization
- `Template` - Base class for resource aggregation
- `setup_resources()` - Import modules in dependency order for `from . import *`
- Stub generation for IDE support:
  - `StubConfig` - Configuration for stub generation
  - `generate_stub_file()` - Generate `.pyi` files
- Helper utilities:
  - `is_attr_ref()` - Check if object is AttrRef
  - `is_class_ref()` - Check if object is decorated class
  - `get_ref_target()` - Extract target from reference
  - `apply_metaclass()` - Apply metaclass to existing class
- Re-exports from graph-refs for convenience
