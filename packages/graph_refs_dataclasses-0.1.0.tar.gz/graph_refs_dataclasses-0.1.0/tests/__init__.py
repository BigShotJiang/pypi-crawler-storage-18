# Tests for graph-refs-dataclasses
