# BHH - A Library for You

## Version: 0.3.9

## Developer: Aria

---

## License

This project is licensed under the BHAP License - see the [LICENSE](LICENSE.txt) file for details.

### License:

BHAP License (c) 2025 Aria

The bhh project is an open-source project.

This license allows you to:

- Modify the code

- Redistribute it

- Publish it

- Use the hashing formula or other formulas from this project in your own projects

Conditions for redistribution and release:

1. Your name must be included in the redistributed version.

2. The BHAP License must be included with the project.

3. The project must remain open-source.

This software is provided "as is", without any warranty of any kind. The author shall not be held

liable for any damages arising from the use of this software.

---

## Features:

🎮 Create your own simple games

🔒 Hash your passwords with both random and chosen salts

🌐 Add a search engine to your app

🌐 Bind ports to serve static files with a simple HTTP server

💻 Install libraries from PyPI

---

## Installation:

pip install bhh

---

### Requirements

- requests >= 2.0.0  

- Pillow >= 10.0.0  

---

## Usage:

```python

import bhh

print(bhh.hash_password("mypassword"))
print(bhh.verify_password("mypassword", "stored_hash"))
print(bhh.hash_password_with_salt("mypassword", mysalt)) # ⚠️ Note: The format is salt bytes ⚠️
print(bhh.install_from_pypi("requests"))
print(bhh.search_web("Python Tkinter", "YOUR_BING_API_KEY", 5))
print(bhh.create_game_window("up.png", "down.png", "left.png", "right.png", "circle.png", "My Game", "white"))
print(bhh.apos("my service folder path", 1234, "ip", "homepage")) # ⚠️ Note: 1234 is Port ⚠️