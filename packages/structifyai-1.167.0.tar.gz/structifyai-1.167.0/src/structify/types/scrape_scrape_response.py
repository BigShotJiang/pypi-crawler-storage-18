# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["ScrapeScrapeResponse"]


class ScrapeScrapeResponse(BaseModel):
    """Response body"""

    job_id: str
