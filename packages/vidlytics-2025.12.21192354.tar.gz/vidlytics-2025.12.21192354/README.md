# Vidlytics
[![PyPI version](https://badge.fury.io/py/vidlytics.svg)](https://badge.fury.io/py/vidlytics)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/vidlytics)](https://pepy.tech/project/vidlytics)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


Vidlytics is a Python package designed to extract and process information from multimedia content descriptions, such as videos or other structured data, by utilizing advanced language models. It simplifies understanding complex multimedia materials by generating concise, domain-specific summaries or insights based on the provided textual descriptions, captions, or processed data. This enables users to quickly grasp key themes and ideas without directly analyzing the multimedia content itself.

## Features

- Utilizes language models to interpret multimedia descriptions
- Flexible with different LLM backends (OpenAI, Anthropic, Google, etc.)
- Simple interface for extracting structured insights
- Built-in support for pattern matching and validation

## Installation

Install Vidlytics via pip:

```bash
pip install vidlytics
```

## Usage

Here's a sample usage demonstrating how to invoke the package:

```python
from vidlytics import vidlytics

# Example user input
user_input = "Describe the main topics in the multimedia content."

# Calling with default LLM (ChatLLM7)
response = vidlytics(user_input)

# Using a custom LLM instance, e.g., OpenAI's ChatOpenAI
from langchain_openai import ChatOpenAI

llm = ChatOpenAI()
response = vidlytics(user_input, llm=llm)
```

## Parameters

- **user_input** (str): The textual description or summary of the multimedia content to process.
- **llm** (Optional[BaseChatModel]): An instance of a language model. Defaults to `ChatLLM7` if not provided.
- **api_key** (Optional[str]): API key for LLM7. If not provided, the package checks the environment variable `LLM7_API_KEY`. A free API key can be obtained at [https://token.llm7.io/](https://token.llm7.io/).

## Underlying Technology

- Uses `ChatLLM7` from the [`langchain_llm7`](https://pypi.org/project/langchain-llm7/) package by default.
- Supports integration with different language model providers, including OpenAI, Anthropic, Google Generative AI, and others, by passing custom `llm` instances.

## Additional Notes

- The package is designed for flexibility; users can provide their own language model instances to match their preferred providers and configurations.
- Rate limits for the free tier of LLM7 are generally sufficient for typical use cases. Higher limits are available via API keys.

## License

This project is maintained by Eugene Evstafev. For issues, feature requests, or contributions, please open an issue on GitHub.

## Author

- Eugene Evstafev  
- Email: hi@euegne.plus  
- GitHub: [chigwell](https://github.com/chigwell)

## License

MIT License