from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="webtable2json",
    version="1.1.0",
    author="Raja CSP Raman",
    author_email="raja.r.csp@gmail.com",
    description="Extract HTML tables from webpages and convert them to JSON format",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/webtable2json",
    py_modules=["webtable2json"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Markup :: HTML",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    keywords="html table json web scraping beautifulsoup",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/webtable2json/issues",
        "Source": "https://github.com/yourusername/webtable2json",
    },
)