"""
DAP4MKB CLI - Точка входа командной строки
Запуск: dap4mkb start | init | config
"""

import os
import sys
import click
from pathlib import Path

# Директория конфигурации: ~/.dap
DAP_HOME = Path.home() / ".dap"


@click.group()
@click.version_option(version="0.1.1", prog_name="dap4mkb")
def main():
    """DataAudit Platform - аудит и аналитика данных для МКБ"""
    pass


@main.command()
@click.option("--force", is_flag=True, help="Перезаписать существующую конфигурацию")
def init(force: bool):
    """Инициализация DAP: создание ~/.dap, базы данных, конфигурации"""
    import subprocess
    
    click.echo("Инициализация DAP Platform...")
    
    # Создаём директорию
    if DAP_HOME.exists() and not force:
        click.echo(f"Директория {DAP_HOME} уже существует. Используйте --force для перезаписи.")
        return
    
    DAP_HOME.mkdir(exist_ok=True)
    click.echo(f"OK Создана директория: {DAP_HOME}")
    
    # Создаём конфиг DAP UI
    config_file = DAP_HOME / "config.env"
    if not config_file.exists() or force:
        config_content = """# DAP Platform Configuration
# Режим разработки (без LDAP)
DAP_DEV_MODE=true

# Сервер (хост и порты)
DAP_HOST=127.0.0.1
DAP_UI_PORT=8000
DAP_BI_PORT=8088

# База данных (SQLite по умолчанию)
DAP_DATABASE_URL=sqlite:///${DAP_HOME}/dap.db

# LDAP (для production)
# LDAP_SERVER=ldaps://ad.mcb.ru:636
# LDAP_BASE_DN=DC=mcb,DC=ru
# LDAP_BIND_USER=
# LDAP_BIND_PASSWORD=

# SMTP (для уведомлений)
# SMTP_SERVER=mail.mcb.ru
# SMTP_PORT=587
# SMTP_USER=
# SMTP_PASSWORD=
"""
        config_file.write_text(config_content, encoding="utf-8")
        click.echo(f"OK Создан конфиг: {config_file}")
    
    # Создаём директорию и конфиг Superset
    superset_dir = DAP_HOME / "superset"
    superset_dir.mkdir(exist_ok=True)
    superset_config = superset_dir / "superset_config.py"
    
    if not superset_config.exists() or force:
        superset_config_content = '''"""
DAP BI (Superset) - Standalone configuration
SQLite database, no Redis, minimal setup
"""
import os
from pathlib import Path

# Paths
DAP_HOME = Path.home() / ".dap"
SUPERSET_HOME = DAP_HOME / "superset"

# SQLite database
SQLALCHEMY_DATABASE_URI = f"sqlite:///{SUPERSET_HOME}/superset.db"

# Secret key
SECRET_KEY = os.environ.get("SUPERSET_SECRET_KEY", "dap-bi-standalone-secret-key-change-me")

# Disable features that need Redis/Celery
RESULTS_BACKEND = None
CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
DATA_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
FILTER_STATE_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
EXPLORE_FORM_DATA_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}

# Disable async queries (no Celery)
SQLLAB_ASYNC_TIME_LIMIT_SEC = 0

# Dev mode settings
DEBUG = True
FLASK_ENV = "development"

# Disable CSRF for local development
WTF_CSRF_ENABLED = False

# Allow embedding
SESSION_COOKIE_SAMESITE = "Lax"
ENABLE_CORS = True

# Russian locale
BABEL_DEFAULT_LOCALE = "ru"

# Feature flags
FEATURE_FLAGS = {
    "ENABLE_TEMPLATE_PROCESSING": True,
}

# DAP Branding
APP_NAME = "DAP Analytics"
APP_ICON = "/static/assets/images/dap_logo.png"
FAVICONS = [{"href": "/static/assets/images/dap_favicon.png"}]
LOGO_TOOLTIP = "DAP Analytics"
LOGO_RIGHT_TEXT = ""
'''
        superset_config.write_text(superset_config_content, encoding="utf-8")
        click.echo(f"OK Создан конфиг Superset: {superset_config}")
    
    # Настраиваем окружение для Superset
    bi_env = os.environ.copy()
    bi_env["FLASK_APP"] = "superset"
    bi_env["SUPERSET_CONFIG_PATH"] = str(superset_config)
    
    # Проверяем, установлен ли dap-bi
    try:
        import superset
        click.echo("OK DAP BI (Superset) найден")
    except ImportError:
        click.echo("DAP BI не установлен. Установите: pip install dap-bi")
        click.echo("")
        click.echo("DAP UI готов к запуску!")
        click.echo("   Запустите: python -m dap4mkb.cli start --no-bi")
        return
    
    # Инициализируем базу данных Superset
    superset_db = superset_dir / "superset.db"
    if not superset_db.exists() or force:
        click.echo("Инициализация базы данных Superset...")
        
        bi_cmd = [sys.executable, "-m", "superset.cli.main", "db", "upgrade"]
        result = subprocess.run(bi_cmd, env=bi_env, capture_output=True, text=True)
        if result.returncode == 0:
            click.echo("OK База данных Superset создана")
        else:
            click.echo(f"Ошибка DB: {result.returncode}")
            return
        
        # Создаём admin пользователя
        click.echo("Создание пользователя admin...")
        admin_cmd = [
            sys.executable, "-m", "superset.cli.main", "fab", "create-admin",
            "--username", "admin",
            "--firstname", "Admin",
            "--lastname", "User",
            "--email", "admin@dap.local",
            "--password", "admin123"
        ]
        result = subprocess.run(admin_cmd, env=bi_env, capture_output=True, text=True)
        if result.returncode == 0:
            click.echo("OK Пользователь admin создан (пароль: admin123)")
        else:
            click.echo(f"Ошибка admin: {result.returncode}")
        
        # Инициализируем роли
        click.echo("Инициализация ролей...")
        init_cmd = [sys.executable, "-m", "superset.cli.main", "init"]
        result = subprocess.run(init_cmd, env=bi_env, capture_output=True, text=True)
        if result.returncode == 0:
            click.echo("OK Роли инициализированы")
        else:
            click.echo(f"Ошибка init: {result.returncode}")
    else:
        click.echo(f"OK База данных Superset уже существует: {superset_db}")
    
    click.echo("")
    click.echo("DAP Platform готов к запуску!")
    click.echo("   Запустите: python -m dap4mkb.cli start")


@main.command()
@click.option("--host", default="127.0.0.1", help="Хост для запуска")
@click.option("--port", default=8000, help="Порт DAP UI")
@click.option("--bi-port", default=8088, help="Порт DAP BI")
@click.option("--no-bi", is_flag=True, help="Запустить только UI без BI")
@click.option("--reload", is_flag=True, help="Авто-перезагрузка при изменениях (dev)")
def start(host: str, port: int, bi_port: int, no_bi: bool, reload: bool):
    """Запуск DAP Platform (UI + BI)"""
    import subprocess
    import time
    
    # Загружаем конфиг
    config_file = DAP_HOME / "config.env"
    if config_file.exists():
        from dotenv import load_dotenv
        load_dotenv(config_file)
    
    # Устанавливаем переменные
    os.environ.setdefault("DAP_DEV_MODE", "true")
    os.environ.setdefault("DAP_HOME", str(DAP_HOME))
    
    # Superset config
    superset_config = DAP_HOME / "superset" / "superset_config.py"
    if superset_config.exists():
        os.environ["SUPERSET_CONFIG_PATH"] = str(superset_config)
    os.environ["FLASK_APP"] = "superset"
    
    click.echo("=" * 50)
    click.echo("  DAP Platform")
    click.echo("=" * 50)
    click.echo(f"  UI:  http://{host}:{port}")
    if not no_bi:
        click.echo(f"  BI:  http://{host}:{bi_port}")
    click.echo("=" * 50)
    click.echo("")
    click.echo("  Login: admin / admin123")
    click.echo("  Ctrl+C to stop")
    click.echo("")
    
    processes = []
    
    try:
        # Запускаем DAP BI (Superset)
        if not no_bi:
            bi_env = os.environ.copy()
            bi_env["FLASK_APP"] = "superset"
            if superset_config.exists():
                bi_env["SUPERSET_CONFIG_PATH"] = str(superset_config)
            
            bi_cmd = [sys.executable, "-m", "superset.cli.main", "run", "-h", host, "-p", str(bi_port)]
            bi_process = subprocess.Popen(bi_cmd, env=bi_env)
            processes.append(bi_process)
            click.echo(f"[BI] Started on port {bi_port}")
            time.sleep(3)
        
        # Запускаем DAP UI (FastAPI)
        import uvicorn
        click.echo(f"[UI] Starting on port {port}...")
        uvicorn.run(
            "dap4mkb.server:app",
            host=host,
            port=port,
            reload=reload,
        )
        
    except KeyboardInterrupt:
        click.echo("\n\nStopping services...")
    finally:
        for proc in processes:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        click.echo("All services stopped.")


@main.group()
def config():
    """Управление конфигурацией"""
    pass


@config.command("show")
def config_show():
    """Показать текущую конфигурацию"""
    config_file = DAP_HOME / "config.env"
    
    if not config_file.exists():
        click.echo("Config not found. Run: python -m dap4mkb.cli init")
        return
    
    click.echo(f"File: {config_file}")
    click.echo("-" * 40)
    click.echo(config_file.read_text(encoding="utf-8"))


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Установить параметр конфигурации"""
    config_file = DAP_HOME / "config.env"
    
    if not config_file.exists():
        click.echo("Config not found. Run: python -m dap4mkb.cli init")
        return
    
    lines = config_file.read_text(encoding="utf-8").splitlines()
    key_upper = key.upper()
    found = False
    
    for i, line in enumerate(lines):
        if line.startswith(f"{key_upper}=") or line.startswith(f"# {key_upper}="):
            lines[i] = f"{key_upper}={value}"
            found = True
            break
    
    if not found:
        lines.append(f"{key_upper}={value}")
    
    config_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    click.echo(f"OK {key_upper}={value}")


if __name__ == "__main__":
    main()