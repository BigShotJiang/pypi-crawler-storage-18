"""Frozen Cub package.

This package provides tools and utilities for creating and managing
immutable (frozen) data structures in Python.
"""

from frozen_cub._internal.cli import main
from frozen_cub.utils import CacheKey, HashableValues, check_conditions, get_cache_key

from .dispatcher import Dispatcher
from .frozen import FrozenDict, freeze, is_primitive, thaw

NOT_CACHABLE = HashableValues(values=[None], cacheable=False)

type FreezableTypes = dict | list | set
type ThawTypes = FrozenDict | tuple | frozenset

__all__: list[str] = [
    "NOT_CACHABLE",
    "CacheKey",
    "Dispatcher",
    "FreezableTypes",
    "FrozenDict",
    "HashableValues",
    "ThawTypes",
    "check_conditions",
    "freeze",
    "get_cache_key",
    "is_primitive",
    "main",
    "thaw",
]
