# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

- None.

## [0.1.2]

- Add Home-page metadata for pip show.

## [0.1.1]

- Add package author metadata.

## [0.1.0]

- Initial release.
- Standardize packaging metadata, tooling, CI, and release automation.
