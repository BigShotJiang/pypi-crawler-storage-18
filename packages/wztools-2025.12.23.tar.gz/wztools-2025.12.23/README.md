
## [v0.2.3] 
- 2025-10-29
- ✨ 添加 load_toml
- 修改 readme.md 格式

## [v2025.12.01]
- ✨ 增加 datalake 
    - 本地简单数据库
    - 方便统一新文件名
    - 创建新文件，获取对应时间的文件

## [v2025.12.03]
- 🧹  把固定的 parquet 后缀改成通用后缀

## [v2025.12.17]
- 🐛 datalake get_data_paths fix

## [v2025.12.23]
- 🧹 优化 error_line()