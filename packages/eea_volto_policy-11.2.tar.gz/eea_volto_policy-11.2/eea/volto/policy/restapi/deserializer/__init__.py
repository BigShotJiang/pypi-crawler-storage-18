"""RestAPI deserializer"""
