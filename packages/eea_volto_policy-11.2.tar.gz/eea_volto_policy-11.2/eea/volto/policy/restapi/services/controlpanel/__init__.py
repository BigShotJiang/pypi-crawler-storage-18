"""RestAPI controlpanel services"""
