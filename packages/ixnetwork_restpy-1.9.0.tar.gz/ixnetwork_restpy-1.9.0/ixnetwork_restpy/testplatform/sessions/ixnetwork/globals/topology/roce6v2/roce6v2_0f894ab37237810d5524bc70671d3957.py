# MIT LICENSE
#
# Copyright 1997 - 2020 by IXIA Keysight
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class Roce6v2(Base):
    """RoCEv2 Port Specific Data
    The Roce6v2 class encapsulates a required roce6v2 resource which will be retrieved from the server every time the property is accessed.
    """

    __slots__ = ()
    _SDM_NAME = "roce6v2"
    _SDM_ATT_MAP = {
        "AckEcnVal": "ackEcnVal",
        "AckNth": "ackNth",
        "AckPriorityType": "ackPriorityType",
        "AckPriorityValue": "ackPriorityValue",
        "AckRequestMode": "ackRequestMode",
        "AckTimeout": "ackTimeout",
        "CnpDelayTimer": "cnpDelayTimer",
        "CnpEcnVal": "cnpEcnVal",
        "CnpPriorityType": "cnpPriorityType",
        "CnpPriorityValue": "cnpPriorityValue",
        "Count": "count",
        "DescriptiveName": "descriptiveName",
        "EnableACKTimeout": "enableACKTimeout",
        "NakEcnVal": "nakEcnVal",
        "NakPriorityType": "nakPriorityType",
        "NakPriorityValue": "nakPriorityValue",
        "Name": "name",
        "ReTxOnRNR": "reTxOnRNR",
        "RetransRetryCount": "retransRetryCount",
        "RnrRetryCount": "rnrRetryCount",
        "RnrRetryMode": "rnrRetryMode",
        "RoceDGCount": "roceDGCount",
        "RowNames": "rowNames",
        "SuppressHandshakeWithNoDataXchg": "suppressHandshakeWithNoDataXchg",
    }
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(Roce6v2, self).__init__(parent, list_op)

    @property
    def StartRate(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.topology.ethernet.startrate.startrate_2bc83a4fb9730935e8259bdb40af2dc0.StartRate): An instance of the StartRate class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.topology.ethernet.startrate.startrate_2bc83a4fb9730935e8259bdb40af2dc0 import (
            StartRate,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("StartRate", None) is not None:
                return self._properties.get("StartRate")
        return StartRate(self)._select()

    @property
    def StopRate(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.topology.ethernet.stoprate.stoprate_4ea9a1b38960d2b21012777131469a04.StopRate): An instance of the StopRate class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.topology.ethernet.stoprate.stoprate_4ea9a1b38960d2b21012777131469a04 import (
            StopRate,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("StopRate", None) is not None:
                return self._properties.get("StopRate")
        return StopRate(self)._select()

    @property
    def AckEcnVal(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): ACK ECN Value
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["AckEcnVal"]))

    @property
    def AckNth(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): This specifies the number of transmitted RoCEv2 verb packets after which the ACK Request bit will be turned on.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["AckNth"]))

    @property
    def AckPriorityType(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority type to be used for generating ACK packets.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["AckPriorityType"])
        )

    @property
    def AckPriorityValue(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority Value for the given priority type.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["AckPriorityValue"])
        )

    @property
    def AckRequestMode(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Select if A bit is set only in the last packet or every nth packet and last packet of the burst.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["AckRequestMode"])
        )

    @property
    def AckTimeout(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Amount of time to wait before attempting to retransmit on non receipt of ACK.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["AckTimeout"]))

    @property
    def CnpDelayTimer(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Amount of time to wait between the generation of successive CNP packets.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["CnpDelayTimer"]))

    @property
    def CnpEcnVal(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): CNP ECN Value
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["CnpEcnVal"]))

    @property
    def CnpPriorityType(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority type to be used for generating CNP packets.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["CnpPriorityType"])
        )

    @property
    def CnpPriorityValue(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority Value for the given priority type.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["CnpPriorityValue"])
        )

    @property
    def Count(self):
        # type: () -> int
        """
        Returns
        -------
        - number: Number of elements inside associated multiplier-scaled container object, e.g. number of devices inside a Device Group.
        """
        return self._get_attribute(self._SDM_ATT_MAP["Count"])

    @property
    def DescriptiveName(self):
        # type: () -> str
        """
        Returns
        -------
        - str: Longer, more descriptive name for element. It's not guaranteed to be unique like -name-, but may offer more context.
        """
        return self._get_attribute(self._SDM_ATT_MAP["DescriptiveName"])

    @property
    def EnableACKTimeout(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Enable Retransmission on ACK Timeout.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["EnableACKTimeout"])
        )

    @property
    def NakEcnVal(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): NAK ECN Value
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["NakEcnVal"]))

    @property
    def NakPriorityType(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority type to be used for generating NAK packets.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["NakPriorityType"])
        )

    @property
    def NakPriorityValue(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Priority Value for the given priority type.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["NakPriorityValue"])
        )

    @property
    def Name(self):
        # type: () -> str
        """
        Returns
        -------
        - str: Name of NGPF element, guaranteed to be unique in Scenario
        """
        return self._get_attribute(self._SDM_ATT_MAP["Name"])

    @Name.setter
    def Name(self, value):
        # type: (str) -> None
        self._set_attribute(self._SDM_ATT_MAP["Name"], value)

    @property
    def ReTxOnRNR(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): If Enabled, retransmission of the flow on a QP will take place on receipt of RNR.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["ReTxOnRNR"]))

    @property
    def RetransRetryCount(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Number of times to retry retransmission before giving up on non receipt of ACK.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self, self._get_attribute(self._SDM_ATT_MAP["RetransRetryCount"])
        )

    @property
    def RnrRetryCount(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): This specifies the number of times retransmission of the verb on a given QP will take place due to receipt of RNRs.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["RnrRetryCount"]))

    @property
    def RnrRetryMode(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Determines if there will be fixed number of retransmission retries or infinite number of retries on receipt of RNR.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(self, self._get_attribute(self._SDM_ATT_MAP["RnrRetryMode"]))

    @property
    def RoceDGCount(self):
        # type: () -> int
        """
        Returns
        -------
        - number: RoCE DG Count
        """
        return self._get_attribute(self._SDM_ATT_MAP["RoceDGCount"])

    @RoceDGCount.setter
    def RoceDGCount(self, value):
        # type: (int) -> None
        self._set_attribute(self._SDM_ATT_MAP["RoceDGCount"], value)

    @property
    def RowNames(self):
        # type: () -> List[str]
        """
        Returns
        -------
        - list(str): Name of rows
        """
        return self._get_attribute(self._SDM_ATT_MAP["RowNames"])

    @property
    def SuppressHandshakeWithNoDataXchg(self):
        # type: () -> 'Multivalue'
        """
        Returns
        -------
        - obj(ixnetwork_restpy.multivalue.Multivalue): Suppress Handshake For Connections With No Data Exchange.
        """
        from ixnetwork_restpy.multivalue import Multivalue

        return Multivalue(
            self,
            self._get_attribute(self._SDM_ATT_MAP["SuppressHandshakeWithNoDataXchg"]),
        )

    def update(self, Name=None, RoceDGCount=None):
        # type: (str, int) -> Roce6v2
        """Updates roce6v2 resource on the server.

        This method has some named parameters with a type: obj (Multivalue).
        The Multivalue class has documentation that details the possible values for those named parameters.

        Args
        ----
        - Name (str): Name of NGPF element, guaranteed to be unique in Scenario
        - RoceDGCount (number): RoCE DG Count

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._update(self._map_locals(self._SDM_ATT_MAP, locals()))

    def find(
        self,
        Count=None,
        DescriptiveName=None,
        Name=None,
        RoceDGCount=None,
        RowNames=None,
    ):
        # type: (int, str, str, int, List[str]) -> Roce6v2
        """Finds and retrieves roce6v2 resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve roce6v2 resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all roce6v2 resources from the server.

        Args
        ----
        - Count (number): Number of elements inside associated multiplier-scaled container object, e.g. number of devices inside a Device Group.
        - DescriptiveName (str): Longer, more descriptive name for element. It's not guaranteed to be unique like -name-, but may offer more context.
        - Name (str): Name of NGPF element, guaranteed to be unique in Scenario
        - RoceDGCount (number): RoCE DG Count
        - RowNames (list(str)): Name of rows

        Returns
        -------
        - self: This instance with matching roce6v2 resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of roce6v2 data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the roce6v2 resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)

    def get_device_ids(
        self,
        PortNames=None,
        AckEcnVal=None,
        AckNth=None,
        AckPriorityType=None,
        AckPriorityValue=None,
        AckRequestMode=None,
        AckTimeout=None,
        CnpDelayTimer=None,
        CnpEcnVal=None,
        CnpPriorityType=None,
        CnpPriorityValue=None,
        EnableACKTimeout=None,
        NakEcnVal=None,
        NakPriorityType=None,
        NakPriorityValue=None,
        ReTxOnRNR=None,
        RetransRetryCount=None,
        RnrRetryCount=None,
        RnrRetryMode=None,
        SuppressHandshakeWithNoDataXchg=None,
    ):
        """Base class infrastructure that gets a list of roce6v2 device ids encapsulated by this object.

        Use the optional regex parameters in the method to refine the list of device ids encapsulated by this object.

        Args
        ----
        - PortNames (str): optional regex of port names
        - AckEcnVal (str): optional regex of ackEcnVal
        - AckNth (str): optional regex of ackNth
        - AckPriorityType (str): optional regex of ackPriorityType
        - AckPriorityValue (str): optional regex of ackPriorityValue
        - AckRequestMode (str): optional regex of ackRequestMode
        - AckTimeout (str): optional regex of ackTimeout
        - CnpDelayTimer (str): optional regex of cnpDelayTimer
        - CnpEcnVal (str): optional regex of cnpEcnVal
        - CnpPriorityType (str): optional regex of cnpPriorityType
        - CnpPriorityValue (str): optional regex of cnpPriorityValue
        - EnableACKTimeout (str): optional regex of enableACKTimeout
        - NakEcnVal (str): optional regex of nakEcnVal
        - NakPriorityType (str): optional regex of nakPriorityType
        - NakPriorityValue (str): optional regex of nakPriorityValue
        - ReTxOnRNR (str): optional regex of reTxOnRNR
        - RetransRetryCount (str): optional regex of retransRetryCount
        - RnrRetryCount (str): optional regex of rnrRetryCount
        - RnrRetryMode (str): optional regex of rnrRetryMode
        - SuppressHandshakeWithNoDataXchg (str): optional regex of suppressHandshakeWithNoDataXchg

        Returns
        -------
        - list(int): A list of device ids that meets the regex criteria provided in the method parameters

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._get_ngpf_device_ids(locals())
