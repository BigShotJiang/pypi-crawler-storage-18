# MIT LICENSE
#
# Copyright 1997 - 2020 by IXIA Keysight
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
import sys
from ixnetwork_restpy.base import Base
from ixnetwork_restpy.files import Files

if sys.version_info >= (3, 5):
    from typing import List, Any, Union


class Patterns(Base):
    """Meshing patterns
    The Patterns class encapsulates a required patterns resource which will be retrieved from the server every time the property is accessed.
    """

    __slots__ = ()
    _SDM_NAME = "patterns"
    _SDM_ATT_MAP = {}
    _SDM_ENUM_MAP = {}

    def __init__(self, parent, list_op=False):
        super(Patterns, self).__init__(parent, list_op)

    @property
    def MeshPatternAll2All(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternall2all.meshpatternall2all.MeshPatternAll2All): An instance of the MeshPatternAll2All class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternall2all.meshpatternall2all import (
            MeshPatternAll2All,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("MeshPatternAll2All", None) is not None:
                return self._properties.get("MeshPatternAll2All")
        return MeshPatternAll2All(self)

    @property
    def MeshPatternAll2One(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternall2one.meshpatternall2one.MeshPatternAll2One): An instance of the MeshPatternAll2One class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternall2one.meshpatternall2one import (
            MeshPatternAll2One,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("MeshPatternAll2One", None) is not None:
                return self._properties.get("MeshPatternAll2One")
        return MeshPatternAll2One(self)

    @property
    def MeshPatternOne2All(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternone2all.meshpatternone2all.MeshPatternOne2All): An instance of the MeshPatternOne2All class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternone2all.meshpatternone2all import (
            MeshPatternOne2All,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("MeshPatternOne2All", None) is not None:
                return self._properties.get("MeshPatternOne2All")
        return MeshPatternOne2All(self)

    @property
    def MeshPatternRing(self):
        """
        Returns
        -------
        - obj(ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternring.meshpatternring.MeshPatternRing): An instance of the MeshPatternRing class

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        from ixnetwork_restpy.testplatform.sessions.ixnetwork.globals.meshing.patterns.meshpatternring.meshpatternring import (
            MeshPatternRing,
        )

        if len(self._object_properties) > 0:
            if self._properties.get("MeshPatternRing", None) is not None:
                return self._properties.get("MeshPatternRing")
        return MeshPatternRing(self)

    def find(self):
        """Finds and retrieves patterns resources from the server.

        All named parameters are evaluated on the server using regex. The named parameters can be used to selectively retrieve patterns resources from the server.
        To retrieve an exact match ensure the parameter value starts with ^ and ends with $
        By default the find method takes no parameters and will retrieve all patterns resources from the server.

        Returns
        -------
        - self: This instance with matching patterns resources retrieved from the server available through an iterator or index

        Raises
        ------
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._select(self._map_locals(self._SDM_ATT_MAP, locals()))

    def read(self, href):
        """Retrieves a single instance of patterns data from the server.

        Args
        ----
        - href (str): An href to the instance to be retrieved

        Returns
        -------
        - self: This instance with the patterns resources from the server available through an iterator or index

        Raises
        ------
        - NotFoundError: The requested resource does not exist on the server
        - ServerError: The server has encountered an uncategorized error condition
        """
        return self._read(href)
