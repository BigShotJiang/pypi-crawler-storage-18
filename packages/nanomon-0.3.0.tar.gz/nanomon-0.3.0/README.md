# Nanomon

LLM observability for DSPy applications.

## What is Nanomon?

Nanomon is an observability platform for LLM applications built with DSPy. It automatically tracks token usage, costs, and tool calls across your DSPy program runs, giving you full visibility into your AI workflows.

## Features

- Automatic LLM token usage tracking
- Cost calculation and analytics
- Tool call tracking with the `@nanomon` decorator
- DSPy integration (Predict, ReAct, ChainOfThought)
- Run context management for grouping related calls
- Multiple storage backends (API, SQLite)

## Quick Start

```python
import dspy
from nanomon import NanomonRunContext, configure_nanomon

# 1. Create context and configure tool tracking
context = NanomonRunContext(default_tags=["production"])
configure_nanomon(context._sink)

# 2. Instrument your LM
lm = dspy.LM(model="openai/gpt-4o-mini")
lm = context.instrument_lm(lm)
dspy.configure(lm=lm)

# 3. Track runs - DSPy callbacks are auto-configured
with context.run(tags=["my-task"], metadata={"version": "1.0"}):
    predictor = dspy.Predict(MySignature)
    result = await predictor.acall(input="Hello")
    # Each DSPy module call is automatically tracked as a separate run
```

> **Note**: Use `.acall()` for async DSPy module calls to ensure proper callback integration.

## Tool Discovery

Nanomon can automatically discover and sync all `@nanomon` decorated functions in your codebase:

```python
with context.run(discover_tools=True, tags=["my-task"]):
    # Prints discovered tools and syncs them to nanomon API
    result = await predictor.acall(input="Hello")
```

Output:
```
🔍 Discovered @nanomon tools:
  - tools.filesystem.read_file
  - tools.filesystem.write_file
  - tools.web.search_web
✓ Synced 3 tools to nanomon
```

## Tool Tracking

Use the `@nanomon` decorator to track tool calls within your workflows:

```python
from nanomon import nanomon

@nanomon(name="search_web")
def search_web(query: str) -> str:
    """Search the web for information."""
    # Your implementation
    return results

@nanomon(name="read_file")
async def read_file(path: str) -> str:
    """Read a file from disk."""
    # Your implementation
    return content
```

Tool calls are automatically recorded with timing and success/error status when executed within a `context.run()` scope.

## Links

- **Website**: https://nanomon.ai
- **Dashboard**: https://app.nanomon.ai
- **Documentation**: https://docs.nanomon.ai

## License

MIT
