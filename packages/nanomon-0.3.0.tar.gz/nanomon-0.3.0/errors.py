"""Custom exceptions for nanomon."""

from __future__ import annotations


class NanomonError(Exception):
    """Base exception for all nanomon errors."""


class SinkWriteError(NanomonError):
    """Raised when a sink fails to write a run."""

    def __init__(self, message: str, response_body: str | None = None) -> None:
        super().__init__(message)
        self.response_body = response_body


class RunPayloadValidationError(NanomonError):
    """Raised when a run payload fails validation before sending to sink."""

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.errors = errors or []


class ExtractorError(NanomonError):
    """Raised when usage extraction fails unexpectedly."""
