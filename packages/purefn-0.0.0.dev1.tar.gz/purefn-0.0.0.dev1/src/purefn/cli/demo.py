from __future__ import annotations

import json

import typer

from purefn.games.cards import engine

demo_app = typer.Typer(
    help="Guided demos for PUREFN; start with 'purefn demo cards'.",
)


@demo_app.command()
def cards(seed: str = typer.Argument("demo", metavar="SEED")) -> None:
    """Walk through a small cards scenario for exploration."""
    print(f"# PUREFN cards demo (seed={seed})")

    # Step 1: new deck
    deck_result = engine.create_deck(seed)
    deck = deck_result.deck
    print("\n## Step 1 – new deck")
    print(f"$ purefn cards deck {seed}")
    print(json.dumps({"deck": deck}, indent=2))

    # Step 2: deal to alice and bob
    print("\n## Step 2 – deal to alice and bob")
    alice_result = engine.deal(deck, "alice", 5)
    deck = alice_result.deck
    print("$ purefn cards deal <DECK> alice 5")
    print(json.dumps({"deck": deck, "hand": alice_result.hand}, indent=2))

    bob_result = engine.deal(deck, "bob", 5)
    deck = bob_result.deck
    print("$ purefn cards deal <DECK> bob 5")
    print(json.dumps({"deck": deck, "hand": bob_result.hand}, indent=2))

    # Step 3: view public state
    print("\n## Step 3 – public state")
    public = engine.view_public(deck)
    print("$ purefn cards view public <DECK>")
    print(json.dumps(public, indent=2))
