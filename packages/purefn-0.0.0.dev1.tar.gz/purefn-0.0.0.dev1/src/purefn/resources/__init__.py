from __future__ import annotations

from importlib import resources


def load_text(name: str) -> str:
    """Load a UTF-8 text resource from the purefn.resources package."""
    package = __package__ or "purefn.resources"
    path = resources.files(package).joinpath(name)
    return path.read_text(encoding="utf-8")
