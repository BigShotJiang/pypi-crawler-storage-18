PUREFN {version} - game engines for cards, chess, and protocol.

Pick a game:
- `purefn cards`
- `purefn chess`
- `purefn protocol`

Next steps:
- `purefn <game> --help` for commands and examples
- `purefn demo cards` for a guided cards walkthrough
- `./demos/run_all.sh` (see `demos/README.md`)
- `docs/cards.md`, `docs/chess.md`, `docs/protocol.md`

Agents:
- `purefn run --help` for the JSON envelope API
