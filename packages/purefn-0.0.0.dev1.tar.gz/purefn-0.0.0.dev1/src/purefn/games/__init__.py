"""Game implementations: cards, chess, checkers, grid games."""
