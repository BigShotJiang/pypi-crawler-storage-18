"""Chess game module."""
