"""Cards game: multi-deck, jokers, hands, discard, trade."""
