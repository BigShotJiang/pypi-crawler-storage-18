"""PROTOCOL game engine - Distributed protocol inference under drift.

A deterministic CLI game where teams of agents must infer a hidden
cryptographic-style rule from partial observations.
"""

from purefn.games.protocol.channels import apply_channel_from_station
from purefn.games.protocol.drift import (
    DriftEvent,
    DriftParam,
    DriftSchedule,
    apply_drift_event,
    generate_drift_schedule,
    get_pending_drift_events,
)
from purefn.games.protocol.engine import (
    PROFILE_CONFIGS,
    Profile,
    ProtocolCore,
    ProtocolEngine,
    create_protocol_core,
    create_protocol_core_at_turn,
)
from purefn.games.protocol.map import generate_map, is_gate_blocking_movement
from purefn.games.protocol.prng import DomainPRNG
from purefn.games.protocol.resources import (
    apply_all_credit_regeneration,
    check_expedition_failed,
    check_expedition_success,
    check_gate_attempts,
    check_probe_credits,
    consume_gate_attempt,
    consume_probe_credit,
    hamming_distance,
    unlock_gate,
)
from purefn.games.protocol.templates import TemplateType

__all__ = [
    "DomainPRNG",
    "DriftEvent",
    "DriftParam",
    "DriftSchedule",
    "PROFILE_CONFIGS",
    "Profile",
    "ProtocolCore",
    "ProtocolEngine",
    "TemplateType",
    "apply_all_credit_regeneration",
    "apply_channel_from_station",
    "apply_drift_event",
    "check_expedition_failed",
    "check_expedition_success",
    "check_gate_attempts",
    "check_probe_credits",
    "consume_gate_attempt",
    "consume_probe_credit",
    "create_protocol_core",
    "create_protocol_core_at_turn",
    "generate_drift_schedule",
    "generate_map",
    "get_pending_drift_events",
    "hamming_distance",
    "is_gate_blocking_movement",
    "unlock_gate",
]
