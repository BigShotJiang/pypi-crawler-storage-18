"""Profile definitions for PROTOCOL.

This module contains the Profile enum and ProfileConfig dataclass,
which are used by multiple modules to avoid circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from purefn.games.protocol.templates import TemplateType


class Profile(Enum):
    """Difficulty profile."""

    TINY = "TINY"
    DEV = "DEV"
    STANDARD = "STANDARD"
    HARD = "HARD"


@dataclass
class ProfileConfig:
    """Configuration derived from a profile."""

    allowed_templates: set[TemplateType]
    drift_min: int
    drift_max: int
    gate_attempts: int  # Fixed for DEV/STANDARD; sampled for HARD
    gate_attempts_sampled: bool  # Whether to sample per-gate
    turn_limit_min: int
    turn_limit_max: int
    gate_count_min: int
    gate_count_max: int
    probe_cap: int
    probe_regen_every: int


PROFILE_CONFIGS: dict[Profile, ProfileConfig] = {
    Profile.TINY: ProfileConfig(
        allowed_templates={TemplateType.T1},
        drift_min=0,
        drift_max=1,
        gate_attempts=2,
        gate_attempts_sampled=False,
        turn_limit_min=30,
        turn_limit_max=30,
        gate_count_min=1,
        gate_count_max=1,
        probe_cap=6,
        probe_regen_every=3,
    ),
    Profile.DEV: ProfileConfig(
        allowed_templates={TemplateType.T1, TemplateType.T2},
        drift_min=1,
        drift_max=2,
        gate_attempts=2,
        gate_attempts_sampled=False,
        turn_limit_min=80,
        turn_limit_max=80,
        gate_count_min=3,
        gate_count_max=4,
        probe_cap=6,
        probe_regen_every=3,
    ),
    Profile.STANDARD: ProfileConfig(
        allowed_templates={TemplateType.T1, TemplateType.T2, TemplateType.T3},
        drift_min=3,
        drift_max=5,
        gate_attempts=2,
        gate_attempts_sampled=False,
        turn_limit_min=80,
        turn_limit_max=80,
        gate_count_min=4,
        gate_count_max=5,
        probe_cap=6,
        probe_regen_every=5,
    ),
    Profile.HARD: ProfileConfig(
        allowed_templates={TemplateType.T1, TemplateType.T2, TemplateType.T3},
        drift_min=4,
        drift_max=6,
        gate_attempts=2,  # Will be sampled 1-2 per gate
        gate_attempts_sampled=True,
        turn_limit_min=80,
        turn_limit_max=100,
        gate_count_min=5,
        gate_count_max=6,
        probe_cap=5,
        probe_regen_every=6,
    ),
}
