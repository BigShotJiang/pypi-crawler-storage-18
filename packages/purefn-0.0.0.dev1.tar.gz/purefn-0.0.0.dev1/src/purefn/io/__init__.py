"""JSON I/O utilities for stdin/stdout."""
