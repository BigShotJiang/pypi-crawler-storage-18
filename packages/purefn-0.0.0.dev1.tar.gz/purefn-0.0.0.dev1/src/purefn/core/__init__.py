"""Core utilities for PUREFN: PRNG and codecs."""
