"""Codec utilities for canonical JSON and hashing."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json(obj: Any) -> bytes:
    """Convert object to canonical JSON bytes.

    Uses stable ordering and compact formatting for hashing/commits.

    Args:
        obj: JSON-serializable object

    Returns:
        UTF-8 encoded JSON bytes with sorted keys
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def commit_hash(data: bytes) -> str:
    """Compute SHA256 hash of data.

    Args:
        data: Bytes to hash

    Returns:
        Hex-encoded SHA256 digest
    """
    return hashlib.sha256(data).hexdigest()
