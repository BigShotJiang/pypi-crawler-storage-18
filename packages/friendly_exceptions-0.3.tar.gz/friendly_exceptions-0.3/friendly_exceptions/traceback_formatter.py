"""
Beautiful structured traceback formatter

Usage:
    from friendly_exceptions.traceback_formatter import format_traceback, install_formatter

    # Install globally
    install_formatter()

    # Or format manually
    try:
        risky_code()
    except Exception as e:
        print(format_traceback(e))
"""

import sys
import traceback
import linecache
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from pathlib import Path


# ANSI colors for terminal
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"
    BG_RED = "\033[41m"
    BG_YELLOW = "\033[43m"


@dataclass
class FrameInfo:
    """Information about a stack frame"""
    filename: str
    lineno: int
    function: str
    code: str
    locals: Dict[str, Any]
    is_user_code: bool
    context_before: List[str]
    context_after: List[str]


def is_user_code(filename: str) -> bool:
    """Check if file is user code (not stdlib/site-packages)"""
    filename = str(filename)
    stdlib_paths = [
        'site-packages',
        'dist-packages',
        '/usr/lib/python',
        '/usr/local/lib/python',
        '<frozen',
        '<string>',
    ]
    return not any(p in filename for p in stdlib_paths)


def get_code_context(filename: str, lineno: int, context: int = 3) -> tuple:
    """Get lines of code around the error line"""
    before = []
    after = []

    try:
        for i in range(max(1, lineno - context), lineno):
            line = linecache.getline(filename, i)
            if line:
                before.append((i, line.rstrip()))

        for i in range(lineno + 1, lineno + context + 1):
            line = linecache.getline(filename, i)
            if line:
                after.append((i, line.rstrip()))
    except:
        pass

    return before, after


def get_local_vars(frame) -> Dict[str, str]:
    """Get formatted local variables from frame"""
    result = {}
    if frame is None:
        return result

    try:
        for name, value in frame.f_locals.items():
            if name.startswith('__'):
                continue
            try:
                val_str = repr(value)
                if len(val_str) > 100:
                    val_str = val_str[:100] + '...'
                result[name] = val_str
            except:
                result[name] = '<unable to repr>'
    except:
        pass

    return result


def extract_frames(exc_info=None) -> List[FrameInfo]:
    """Extract frame information from exception"""
    if exc_info is None:
        exc_info = sys.exc_info()

    _, _, tb = exc_info
    frames = []

    while tb is not None:
        frame = tb.tb_frame
        lineno = tb.tb_lineno
        filename = frame.f_code.co_filename
        function = frame.f_code.co_name

        # Get the code line
        code = linecache.getline(filename, lineno).strip()

        # Get context
        context_before, context_after = get_code_context(filename, lineno)

        # Get locals
        local_vars = get_local_vars(frame)

        frames.append(FrameInfo(
            filename=filename,
            lineno=lineno,
            function=function,
            code=code,
            locals=local_vars,
            is_user_code=is_user_code(filename),
            context_before=context_before,
            context_after=context_after
        ))

        tb = tb.tb_next

    return frames


def format_traceback(
    exc: Exception = None,
    exc_info=None,
    show_locals: bool = True,
    show_context: bool = True,
    context_lines: int = 3,
    color: bool = True,
    collapse_stdlib: bool = True
) -> str:
    """
    Format exception with beautiful traceback

    Args:
        exc: Exception instance
        exc_info: sys.exc_info() tuple
        show_locals: Show local variables
        show_context: Show code context around error
        context_lines: Number of context lines
        color: Use ANSI colors
        collapse_stdlib: Collapse standard library frames

    Returns:
        Formatted traceback string
    """
    if exc_info is None:
        if exc is not None:
            exc_info = (type(exc), exc, exc.__traceback__)
        else:
            exc_info = sys.exc_info()

    exc_type, exc_value, _ = exc_info
    frames = extract_frames(exc_info)

    c = Colors if color else type('NoColors', (), {k: '' for k in dir(Colors) if not k.startswith('_')})()

    lines = []

    # Header
    lines.append(f"\n{c.RED}{c.BOLD}{'═' * 60}{c.RESET}")
    lines.append(f"{c.RED}{c.BOLD}❌ EXCEPTION: {exc_type.__name__}{c.RESET}")
    lines.append(f"{c.YELLOW}{str(exc_value)}{c.RESET}")
    lines.append(f"{c.RED}{'═' * 60}{c.RESET}\n")

    # Traceback header
    lines.append(f"{c.CYAN}{c.BOLD}📍 TRACEBACK (most recent call last):{c.RESET}\n")

    # Count stdlib frames for collapsing
    stdlib_count = 0

    for i, frame in enumerate(frames):
        # Collapse stdlib frames
        if collapse_stdlib and not frame.is_user_code:
            stdlib_count += 1
            if i < len(frames) - 1 and not frames[i + 1].is_user_code:
                continue  # Skip, will show count later
            if stdlib_count > 1:
                lines.append(f"{c.GRAY}   ... {stdlib_count} stdlib frames ...{c.RESET}\n")
            stdlib_count = 0
            if not frame.is_user_code and i < len(frames) - 1:
                continue

        # Frame header
        short_path = frame.filename
        try:
            short_path = str(Path(frame.filename).relative_to(Path.cwd()))
        except:
            pass

        frame_color = c.WHITE if frame.is_user_code else c.GRAY
        marker = "→" if i == len(frames) - 1 else "│"

        lines.append(f"{frame_color}{c.BOLD}{marker} {short_path}:{frame.lineno}{c.RESET}")
        lines.append(f"{frame_color}  in {c.CYAN}{frame.function}(){c.RESET}")

        # Code context
        if show_context and frame.is_user_code:
            lines.append("")
            for ln, code in frame.context_before:
                lines.append(f"{c.GRAY}  {ln:4} │ {code}{c.RESET}")

            # Error line (highlighted)
            lines.append(f"{c.RED}{c.BOLD}  {frame.lineno:4} │ {frame.code}{c.RESET}")

            for ln, code in frame.context_after:
                lines.append(f"{c.GRAY}  {ln:4} │ {code}{c.RESET}")
        else:
            lines.append(f"{frame_color}       {frame.code}{c.RESET}")

        # Local variables
        if show_locals and frame.locals and frame.is_user_code:
            lines.append(f"\n{c.MAGENTA}  📦 Local variables:{c.RESET}")
            for name, value in list(frame.locals.items())[:10]:
                lines.append(f"{c.GRAY}     {name} = {c.GREEN}{value}{c.RESET}")

        lines.append("")

    # Footer with exception details
    lines.append(f"{c.RED}{'─' * 60}{c.RESET}")
    lines.append(f"{c.RED}{c.BOLD}{exc_type.__name__}: {exc_value}{c.RESET}")
    lines.append(f"{c.RED}{'═' * 60}{c.RESET}\n")

    return '\n'.join(lines)


def format_traceback_simple(exc_info=None) -> str:
    """Simple one-line traceback format"""
    if exc_info is None:
        exc_info = sys.exc_info()

    exc_type, exc_value, tb = exc_info
    frames = extract_frames(exc_info)

    if frames:
        last_frame = frames[-1]
        return f"{exc_type.__name__}: {exc_value} at {last_frame.filename}:{last_frame.lineno} in {last_frame.function}()"

    return f"{exc_type.__name__}: {exc_value}"


def format_traceback_json(exc_info=None) -> dict:
    """Format traceback as JSON-serializable dict"""
    if exc_info is None:
        exc_info = sys.exc_info()

    exc_type, exc_value, _ = exc_info
    frames = extract_frames(exc_info)

    return {
        'exception_type': exc_type.__name__,
        'exception_message': str(exc_value),
        'frames': [
            {
                'filename': f.filename,
                'lineno': f.lineno,
                'function': f.function,
                'code': f.code,
                'is_user_code': f.is_user_code,
                'locals': f.locals
            }
            for f in frames
        ]
    }


class BeautifulExceptHook:
    """Exception hook that formats tracebacks beautifully"""

    def __init__(
        self,
        show_locals: bool = True,
        show_context: bool = True,
        color: bool = True,
        output_file: str = None
    ):
        self.show_locals = show_locals
        self.show_context = show_context
        self.color = color
        self.output_file = output_file
        self._original_hook = sys.excepthook

    def __call__(self, exc_type, exc_value, exc_tb):
        formatted = format_traceback(
            exc_info=(exc_type, exc_value, exc_tb),
            show_locals=self.show_locals,
            show_context=self.show_context,
            color=self.color
        )

        print(formatted, file=sys.stderr)

        if self.output_file:
            # Write without colors to file
            plain = format_traceback(
                exc_info=(exc_type, exc_value, exc_tb),
                show_locals=self.show_locals,
                show_context=self.show_context,
                color=False
            )
            with open(self.output_file, 'a', encoding='utf-8') as f:
                from datetime import datetime
                f.write(f"\n[{datetime.now()}]\n{plain}\n")


def install_formatter(
    show_locals: bool = True,
    show_context: bool = True,
    color: bool = True,
    output_file: str = None
):
    """
    Install beautiful traceback formatter globally

    Args:
        show_locals: Show local variables
        show_context: Show code context
        color: Use ANSI colors
        output_file: Also log to file
    """
    sys.excepthook = BeautifulExceptHook(
        show_locals=show_locals,
        show_context=show_context,
        color=color,
        output_file=output_file
    )


def uninstall_formatter():
    """Restore original exception hook"""
    if hasattr(sys.excepthook, '_original_hook'):
        sys.excepthook = sys.excepthook._original_hook
