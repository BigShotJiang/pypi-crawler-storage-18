"""
Git blame integration - show who wrote the buggy code

Usage:
    from friendly_exceptions.git_blame import get_blame_info, format_blame

    # Get blame for specific file:line
    blame = get_blame_info("src/app.py", 42)
    print(blame)  # {'author': 'John', 'date': '2024-01-15', 'commit': 'abc123', ...}

    # Format for display
    print(format_blame("src/app.py", 42))
"""

import subprocess
import os
from typing import Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from functools import lru_cache


@dataclass
class BlameInfo:
    """Git blame information for a line"""
    author: str
    author_email: str
    date: datetime
    commit_hash: str
    commit_short: str
    commit_message: str
    filename: str
    lineno: int
    code: str
    is_uncommitted: bool = False


def is_git_repo(path: str = ".") -> bool:
    """Check if path is in a git repository"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=path,
            capture_output=True,
            text=True
        )
        return result.returncode == 0
    except:
        return False


def get_repo_root(path: str = ".") -> Optional[str]:
    """Get git repository root directory"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=path,
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except:
        pass
    return None


@lru_cache(maxsize=100)
def get_blame_info(filename: str, lineno: int) -> Optional[BlameInfo]:
    """
    Get git blame information for a specific line

    Args:
        filename: Path to file
        lineno: Line number (1-based)

    Returns:
        BlameInfo or None if not available
    """
    if not os.path.exists(filename):
        return None

    file_dir = os.path.dirname(os.path.abspath(filename)) or "."

    if not is_git_repo(file_dir):
        return None

    try:
        # Get blame info with porcelain format
        result = subprocess.run(
            [
                "git", "blame",
                "-L", f"{lineno},{lineno}",
                "--porcelain",
                filename
            ],
            cwd=file_dir,
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode != 0:
            return None

        lines = result.stdout.strip().split('\n')
        if not lines:
            return None

        # Parse porcelain output
        info = {}
        code = ""

        for line in lines:
            if line.startswith('\t'):
                code = line[1:]  # Remove tab prefix
            elif ' ' in line:
                key, value = line.split(' ', 1)
                info[key] = value
            elif len(line) == 40:  # Commit hash
                info['commit'] = line.split()[0]

        # Check if uncommitted
        is_uncommitted = info.get('commit', '').startswith('0000000')

        # Parse date
        timestamp = info.get('author-time', '0')
        try:
            date = datetime.fromtimestamp(int(timestamp))
        except:
            date = datetime.now()

        # Get commit message
        commit_msg = ""
        if not is_uncommitted and 'commit' in info:
            try:
                msg_result = subprocess.run(
                    ["git", "log", "-1", "--format=%s", info['commit']],
                    cwd=file_dir,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if msg_result.returncode == 0:
                    commit_msg = msg_result.stdout.strip()
            except:
                pass

        return BlameInfo(
            author=info.get('author', 'Unknown'),
            author_email=info.get('author-mail', '').strip('<>'),
            date=date,
            commit_hash=info.get('commit', ''),
            commit_short=info.get('commit', '')[:7],
            commit_message=commit_msg,
            filename=filename,
            lineno=lineno,
            code=code,
            is_uncommitted=is_uncommitted
        )

    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def get_blame_for_traceback(frames: list) -> Dict[str, BlameInfo]:
    """
    Get blame info for all frames in traceback

    Args:
        frames: List of frame info dicts with 'filename' and 'lineno'

    Returns:
        Dict mapping "filename:lineno" to BlameInfo
    """
    result = {}

    for frame in frames:
        filename = frame.get('filename') or frame.filename
        lineno = frame.get('lineno') or frame.lineno

        blame = get_blame_info(filename, lineno)
        if blame:
            result[f"{filename}:{lineno}"] = blame

    return result


def format_blame(filename: str, lineno: int, color: bool = True) -> str:
    """
    Format blame info for display

    Args:
        filename: Path to file
        lineno: Line number
        color: Use ANSI colors

    Returns:
        Formatted string
    """
    blame = get_blame_info(filename, lineno)

    if blame is None:
        return "  (git blame not available)"

    if color:
        GRAY = "\033[90m"
        CYAN = "\033[96m"
        YELLOW = "\033[93m"
        RESET = "\033[0m"
    else:
        GRAY = CYAN = YELLOW = RESET = ""

    if blame.is_uncommitted:
        return f"{GRAY}  👤 Uncommitted changes{RESET}"

    date_str = blame.date.strftime("%Y-%m-%d")

    lines = [
        f"{GRAY}  ┌─ Git Blame ───────────────────{RESET}",
        f"{GRAY}  │ 👤 Author: {CYAN}{blame.author}{RESET}",
        f"{GRAY}  │ 📅 Date:   {YELLOW}{date_str}{RESET}",
        f"{GRAY}  │ 🔗 Commit: {blame.commit_short}{RESET}",
    ]

    if blame.commit_message:
        msg = blame.commit_message[:50]
        if len(blame.commit_message) > 50:
            msg += "..."
        lines.append(f"{GRAY}  │ 📝 \"{msg}\"{RESET}")

    lines.append(f"{GRAY}  └────────────────────────────────{RESET}")

    return '\n'.join(lines)


def format_blame_short(filename: str, lineno: int) -> str:
    """Short one-line blame format"""
    blame = get_blame_info(filename, lineno)

    if blame is None:
        return ""

    if blame.is_uncommitted:
        return "(uncommitted)"

    date_str = blame.date.strftime("%Y-%m-%d")
    return f"by {blame.author} on {date_str} ({blame.commit_short})"


def get_blame_summary(frames: list) -> Dict[str, int]:
    """
    Get summary of who wrote the most error-prone code

    Args:
        frames: List of frame info

    Returns:
        Dict mapping author name to count
    """
    authors = {}

    for frame in frames:
        filename = frame.get('filename', getattr(frame, 'filename', ''))
        lineno = frame.get('lineno', getattr(frame, 'lineno', 0))

        if not filename or not lineno:
            continue

        blame = get_blame_info(filename, lineno)
        if blame and not blame.is_uncommitted:
            authors[blame.author] = authors.get(blame.author, 0) + 1

    return dict(sorted(authors.items(), key=lambda x: -x[1]))


class BlameEnhancedHook:
    """Exception hook that includes git blame information"""

    def __init__(self, original_hook=None, show_blame: bool = True):
        self.original_hook = original_hook
        self.show_blame = show_blame

    def __call__(self, exc_type, exc_value, exc_tb):
        # Call original hook first
        if self.original_hook:
            self.original_hook(exc_type, exc_value, exc_tb)

        if not self.show_blame:
            return

        # Get the last frame (where error occurred)
        import traceback
        tb_frames = traceback.extract_tb(exc_tb)

        if tb_frames:
            last_frame = tb_frames[-1]
            blame_text = format_blame(last_frame.filename, last_frame.lineno)
            if blame_text:
                print(blame_text, file=__import__('sys').stderr)


def install_blame_hook(show_blame: bool = True):
    """Install exception hook with git blame"""
    import sys
    current_hook = sys.excepthook
    sys.excepthook = BlameEnhancedHook(current_hook, show_blame)
