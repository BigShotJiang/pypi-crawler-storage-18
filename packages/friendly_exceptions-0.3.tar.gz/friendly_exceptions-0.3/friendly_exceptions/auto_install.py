"""
Auto-install friendly exceptions for all detected libraries.

Just import friendly_exceptions and everything works:
    import friendly_exceptions

Server mode (Django runserver, uvicorn, gunicorn, etc.):
    - Logs to fe.log file

Script mode:
    - Prints to console
"""

import sys
import os
import logging
from pathlib import Path
from typing import Optional

# ============================================================
# Server Detection & Logging
# ============================================================

IS_SERVER = any(x in sys.argv for x in [
    'runserver', 'gunicorn', 'uvicorn', 'daphne', 'uwsgi',
    'hypercorn', 'waitress', 'manage.py'
]) or os.environ.get('SERVER_SOFTWARE') or os.environ.get('DJANGO_SETTINGS_MODULE')

LOG_FILE = Path("fe.log")
_fe_logger = None


def get_logger():
    global _fe_logger
    if _fe_logger is None:
        _fe_logger = logging.getLogger("friendly_exceptions.server")
        _fe_logger.setLevel(logging.INFO)
        if IS_SERVER and not _fe_logger.handlers:
            handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s | %(message)s'))
            _fe_logger.addHandler(handler)
    return _fe_logger


def log_friendly(message: str):
    """Log friendly error message - file for server, console for script"""
    if IS_SERVER:
        get_logger().info(message.replace('\n', '\n    '))
    else:
        # Console mode - already handled by core.py excepthook
        pass


# ============================================================
# Library-Specific Patches (for additional Django/FastAPI error catching)
# ============================================================

def patch_django():
    """Patch Django to catch request errors"""
    try:
        from django.core.signals import got_request_exception
        from .core import explain_exception

        def on_request_exception(sender, request=None, **kwargs):
            exc_info = sys.exc_info()
            if exc_info[1]:
                explanation = explain_exception(exc_info[1])
                path = request.path if request else "unknown"
                log_friendly(f"Request: {path}\n{explanation}")

        got_request_exception.connect(on_request_exception)
    except:
        pass


def patch_fastapi():
    """Patch FastAPI to catch validation errors"""
    try:
        from fastapi import FastAPI
        from fastapi.exceptions import RequestValidationError
        from .core import explain_exception

        original_init = FastAPI.__init__

        def patched_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)

            @self.exception_handler(RequestValidationError)
            async def validation_handler(request, exc):
                explanation = explain_exception(exc)
                log_friendly(f"Request: {request.url.path}\n{explanation}")
                raise exc

        FastAPI.__init__ = patched_init
    except:
        pass


def patch_logging():
    """Capture logged exceptions and explain them"""
    try:
        from .core import explain_exception

        class FriendlyLoggingHandler(logging.Handler):
            def emit(self, record):
                if record.exc_info and record.exc_info[1]:
                    explanation = explain_exception(record.exc_info[1])
                    log_friendly(explanation)

        # Add to server loggers
        if IS_SERVER:
            for name in ['django', 'django.request', 'uvicorn.error', 'gunicorn.error']:
                try:
                    logger = logging.getLogger(name)
                    logger.addHandler(FriendlyLoggingHandler())
                except:
                    pass
    except:
        pass


# ============================================================
# Load Integrations
# ============================================================

def _load_integrations():
    """Load all available integrations (skip if library not installed)"""
    integration_modules = [
        'pydantic_int', 'django_int', 'openai', 'telegram', 'dotenv',
        'pillow', 'requests_http', 'aws', 'stripe_pay', 'firebase',
        'redis_cache', 'sqlalchemy_db', 'mongodb', 'pandas_data',
        'numpy_arr', 'pytest_test', 'discord_bot', 'selenium_web',
        'subprocess_cmd', 'asyncio_async'
    ]

    for module_name in integration_modules:
        try:
            __import__(f'friendly_exceptions.integrations.{module_name}')
        except ImportError:
            pass  # Library not installed - skip
        except Exception:
            pass  # Other error - skip silently


# ============================================================
# Install
# ============================================================

_installed = False


def install():
    """Install additional integrations (core.py already handles excepthook)"""
    global _installed
    if _installed:
        return
    _installed = True

    # Load all integrations (each handles its own ImportError)
    _load_integrations()

    # Patch libraries for server-side error logging
    if IS_SERVER:
        patch_django()
        patch_fastapi()
        patch_logging()
        get_logger().info(f"Friendly Exceptions: server mode, logging to {LOG_FILE}")


# Auto-install
install()
