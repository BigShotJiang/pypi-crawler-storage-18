"""
Обработчик для ProcessLookupError
ProcessLookupError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class ProcessLookupErrorHandler(BaseHandler):
    """Обработчик для ProcessLookupError - ошибок поиска процесса
    Handler for ProcessLookupError - process lookup errors"""

    def explain(self, exception: ProcessLookupError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        error_msg = str(exception)

        if lang == "ru":
            explanation = f"🔍 Процесс не найден: {error_msg}"
        elif lang == "en":
            explanation = f"🔍 Process not found: {error_msg}"
        elif lang == "de":
            explanation = f"🔍 Prozess nicht gefunden: {error_msg}"
        elif lang == "fr":
            explanation = f"🔍 Processus non trouvé: {error_msg}"
        elif lang == "es":
            explanation = f"🔍 Proceso no encontrado: {error_msg}"
        elif lang == "zh":
            explanation = f"🔍 进程未找到: {error_msg}"
        elif lang == "ja":
            explanation = f"🔍 プロセスが見つかりません: {error_msg}"
        else:
            explanation = f"🔍 Process not found: {error_msg}"

        # Дополнительная информация
        if lang == "ru":
            explanation += "\n\n💡 Это происходит когда:"
            explanation += "\n• Процесс уже завершился"
            explanation += "\n• Указан неверный PID"
            explanation += "\n• Нет прав для доступа к процессу"
        else:
            explanation += "\n\n💡 This happens when:"
            explanation += "\n• Process has already terminated"
            explanation += "\n• Invalid PID specified"
            explanation += "\n• No permissions to access the process"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: ProcessLookupError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Проверьте, что процесс все еще существует: os.kill(pid, 0)",
                "Сохраняйте объект Popen и используйте его методы",
                "Используйте subprocess для управления дочерними процессами",
                "Обрабатывайте ProcessLookupError в try-except"
            ]
        else:
            return [
                "Check if process still exists: os.kill(pid, 0)",
                "Keep Popen object and use its methods",
                "Use subprocess for managing child processes",
                "Handle ProcessLookupError in try-except"
            ]
