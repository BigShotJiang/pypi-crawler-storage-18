"""
Обработчик для InterruptedError
InterruptedError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class InterruptedErrorHandler(BaseHandler):
    """Обработчик для InterruptedError - ошибок прерывания системных вызовов
    Handler for InterruptedError - system call interruption errors"""

    def explain(self, exception: InterruptedError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        if lang == "ru":
            explanation = "⚡ Системный вызов был прерван сигналом"
        elif lang == "en":
            explanation = "⚡ System call was interrupted by a signal"
        elif lang == "de":
            explanation = "⚡ Systemaufruf wurde durch ein Signal unterbrochen"
        elif lang == "fr":
            explanation = "⚡ L'appel système a été interrompu par un signal"
        elif lang == "es":
            explanation = "⚡ La llamada al sistema fue interrumpida por una señal"
        elif lang == "zh":
            explanation = "⚡ 系统调用被信号中断"
        elif lang == "ja":
            explanation = "⚡ システムコールがシグナルによって中断されました"
        else:
            explanation = "⚡ System call was interrupted by a signal"

        # Типичные сценарии
        if lang == "ru":
            explanation += "\n\n💡 Часто возникает при:"
            explanation += "\n• Нажатии Ctrl+C во время длительной операции"
            explanation += "\n• Получении сигнала SIGINT, SIGTERM и др."
            explanation += "\n• Таймаутах и прерываниях I/O операций"
        else:
            explanation += "\n\n💡 Often occurs when:"
            explanation += "\n• Pressing Ctrl+C during a long operation"
            explanation += "\n• Receiving SIGINT, SIGTERM signals"
            explanation += "\n• I/O operation timeouts and interrupts"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: InterruptedError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Повторите операцию в цикле при получении InterruptedError",
                "Используйте signal.signal() для обработки сигналов",
                "Оберните длительные операции в try-except",
                "Используйте контекстные менеджеры для корректного завершения"
            ]
        else:
            return [
                "Retry operation in a loop when getting InterruptedError",
                "Use signal.signal() to handle signals",
                "Wrap long operations in try-except",
                "Use context managers for proper cleanup"
            ]
