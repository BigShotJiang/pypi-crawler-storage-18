"""
ImportError handler with PyPI package suggestions
"""

import difflib
import json
from typing import Optional, Any, List
from .base import BaseHandler

# Cache for PyPI search results
_pypi_cache = {}


def search_pypi(query: str, limit: int = 3) -> List[dict]:
    """
    Search PyPI for packages similar to query

    Returns list of dicts with 'name' and 'summary' keys
    """
    if query in _pypi_cache:
        return _pypi_cache[query]

    results = []
    try:
        import urllib.request
        import urllib.parse

        # PyPI simple search API
        url = f"https://pypi.org/pypi/{urllib.parse.quote(query)}/json"

        try:
            # Try exact match first
            req = urllib.request.Request(url, headers={'User-Agent': 'friendly-exceptions/0.2'})
            with urllib.request.urlopen(req, timeout=2) as response:
                data = json.loads(response.read().decode())
                results.append({
                    'name': data['info']['name'],
                    'summary': data['info']['summary'] or '',
                    'exact': True
                })
        except:
            pass

        # Search for similar packages using PyPI search
        if len(results) < limit:
            search_url = f"https://pypi.org/search/?q={urllib.parse.quote(query)}&o="
            try:
                req = urllib.request.Request(search_url, headers={'User-Agent': 'friendly-exceptions/0.2'})
                with urllib.request.urlopen(req, timeout=3) as response:
                    html = response.read().decode()
                    # Simple HTML parsing for package names
                    import re
                    # Find package names in search results
                    matches = re.findall(r'<span class="package-snippet__name">([^<]+)</span>', html)
                    for name in matches[:limit]:
                        name = name.strip()
                        if name and not any(r['name'].lower() == name.lower() for r in results):
                            results.append({'name': name, 'summary': '', 'exact': False})
                        if len(results) >= limit:
                            break
            except:
                pass

    except Exception:
        pass

    # Cache results
    _pypi_cache[query] = results[:limit]
    return results[:limit]


def get_similar_packages(module_name: str, limit: int = 3) -> List[str]:
    """
    Find similar package names that might be what user meant

    Combines PyPI search with local popular packages list
    """
    results = []

    # Common module name -> package name mappings
    NAME_MAPPINGS = {
        'cv2': 'opencv-python',
        'cv': 'opencv-python',
        'opencv': 'opencv-python',
        'sklearn': 'scikit-learn',
        'skimage': 'scikit-image',
        'PIL': 'Pillow',
        'pil': 'Pillow',
        'yaml': 'PyYAML',
        'bs4': 'beautifulsoup4',
        'dotenv': 'python-dotenv',
        'jwt': 'PyJWT',
        'crypto': 'pycryptodome',
        'Crypto': 'pycryptodome',
        'serial': 'pyserial',
        'usb': 'pyusb',
        'dateutil': 'python-dateutil',
        'magic': 'python-magic',
        'gi': 'PyGObject',
        'wx': 'wxPython',
        'tk': 'tk',
        'pg': 'psycopg2',
        'postgres': 'psycopg2',
        'mysql': 'mysql-connector-python',
        'pymysql': 'PyMySQL',
        'mongo': 'pymongo',
        'redis': 'redis',
        'memcache': 'python-memcached',
        'elasticsearch': 'elasticsearch',
        'kafka': 'kafka-python',
        'boto': 'boto3',
        'aws': 'boto3',
        's3': 'boto3',
        'gcp': 'google-cloud',
        'azure': 'azure-core',
    }

    # Check direct mapping first
    if module_name in NAME_MAPPINGS:
        results.append(NAME_MAPPINGS[module_name])

    # Check lowercase mapping
    if module_name.lower() in NAME_MAPPINGS:
        pkg = NAME_MAPPINGS[module_name.lower()]
        if pkg not in results:
            results.append(pkg)

    # Popular packages for fuzzy matching
    POPULAR = [
        'numpy', 'pandas', 'matplotlib', 'requests', 'flask', 'django',
        'tensorflow', 'torch', 'pytorch', 'scikit-learn', 'opencv-python',
        'pillow', 'beautifulsoup4', 'selenium', 'scrapy', 'fastapi',
        'uvicorn', 'gunicorn', 'sqlalchemy', 'psycopg2', 'pymongo',
        'redis', 'celery', 'pytest', 'black', 'flake8', 'mypy',
        'click', 'typer', 'rich', 'tqdm', 'colorama', 'pyyaml',
        'pydantic', 'httpx', 'aiohttp', 'websockets', 'cryptography',
        'paramiko', 'fabric', 'ansible', 'boto3', 'google-cloud',
        'transformers', 'huggingface-hub', 'openai', 'langchain',
        'streamlit', 'gradio', 'plotly', 'seaborn', 'scipy',
        'sympy', 'networkx', 'nltk', 'spacy', 'gensim',
    ]

    # Fuzzy match against popular packages
    similar = difflib.get_close_matches(module_name.lower(), [p.lower() for p in POPULAR], n=limit, cutoff=0.5)
    for s in similar:
        # Find original case
        for p in POPULAR:
            if p.lower() == s and p not in results:
                results.append(p)
                break

    # Try PyPI search if we don't have enough results
    if len(results) < limit:
        try:
            pypi_results = search_pypi(module_name, limit - len(results))
            for r in pypi_results:
                if r['name'] not in results:
                    results.append(r['name'])
        except:
            pass

    return results[:limit]


class ImportErrorHandler(BaseHandler):
    """Handler for ImportError with PyPI suggestions"""

    def explain(self, exception: ImportError, traceback_obj: Optional[Any] = None) -> str:
        error_message = str(exception)
        lang = self._get_language()

        # Get module name from error
        module_name = None
        if "No module named" in error_message and "'" in error_message:
            module_name = error_message.split("'")[1]
            # Handle submodule imports like 'package.submodule'
            if '.' in module_name:
                module_name = module_name.split('.')[0]

        # Build explanation
        if module_name:
            if lang == "ru":
                explanation = f"📦 Module '{module_name}' not found"
            else:
                explanation = f"📦 Module '{module_name}' not found"

            # Get similar packages
            similar = get_similar_packages(module_name, 3)

            if similar:
                explanation += "\n\n💡 Did you mean to install:"
                for pkg in similar:
                    explanation += f"\n   pip install {pkg}"

        elif "cannot import name" in error_message:
            explanation = self._explain_cannot_import(error_message, lang)
        elif "attempted relative import" in error_message:
            explanation = self._explain_relative_import(lang)
        else:
            if lang == "ru":
                explanation = f"📦 Import error: {error_message}"
            else:
                explanation = f"📦 Import error: {error_message}"

        # Add suggestions
        suggestions = self.get_suggestions(exception, module_name)
        if suggestions:
            explanation += "\n\n🔧 How to fix:"
            for i, s in enumerate(suggestions, 1):
                explanation += f"\n{i}. {s}"

        return explanation

    def _explain_cannot_import(self, error_message: str, lang: str) -> str:
        if "from" in error_message and "'" in error_message:
            parts = error_message.split("'")
            if len(parts) >= 4:
                name = parts[1]
                module = parts[3]
                return f"📦 Cannot import '{name}' from '{module}'"
        return "📦 Cannot import the specified name from module"

    def _explain_relative_import(self, lang: str) -> str:
        return "📦 Relative import error. Run as module: python -m package.module"

    def get_suggestions(self, exception: ImportError, module_name: str = None) -> List[str]:
        error_message = str(exception)
        lang = self._get_language()

        if "No module named" in error_message:
            suggestions = []
            if module_name:
                suggestions.append(f"pip install {module_name}")
                suggestions.append(f"Check spelling of '{module_name}'")
            suggestions.append("Activate your virtual environment")
            suggestions.append("Check PYTHONPATH")
            return suggestions

        elif "cannot import name" in error_message:
            return [
                "Check if name exists: dir(module)",
                "Module version might have changed",
                "Try: import module (without from)",
            ]

        elif "attempted relative import" in error_message:
            return [
                "Use absolute import instead",
                "Run as module: python -m package.module",
                "Check __init__.py files",
            ]

        return [
            "Check import syntax",
            "Verify module is installed",
            "Try restarting Python",
        ]
