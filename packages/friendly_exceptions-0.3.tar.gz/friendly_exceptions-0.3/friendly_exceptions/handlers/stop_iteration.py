"""
Обработчик для StopIteration
StopIteration handler
"""

from typing import Optional, Any
from .base import BaseHandler


class StopIterationHandler(BaseHandler):
    """Обработчик для StopIteration - ошибок исчерпания итератора
    Handler for StopIteration - iterator exhaustion errors"""

    def explain(self, exception: StopIteration, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        if lang == "ru":
            explanation = "🔄 Итератор исчерпан - больше нет элементов для возврата"
        elif lang == "en":
            explanation = "🔄 Iterator exhausted - no more elements to return"
        elif lang == "de":
            explanation = "🔄 Iterator erschöpft - keine weiteren Elemente verfügbar"
        elif lang == "fr":
            explanation = "🔄 Itérateur épuisé - plus d'éléments à retourner"
        elif lang == "es":
            explanation = "🔄 Iterador agotado - no hay más elementos para devolver"
        elif lang == "zh":
            explanation = "🔄 迭代器已耗尽 - 没有更多元素可返回"
        elif lang == "ja":
            explanation = "🔄 イテレータが使い果たされました - 返す要素がありません"
        else:
            explanation = "🔄 Iterator exhausted - no more elements to return"

        # Анализ контекста
        if traceback_obj:
            func_name = context.get('function_name', '')
            if 'next' in func_name.lower():
                if lang == "ru":
                    explanation += "\n💡 Вы вызвали next() на пустом или исчерпанном итераторе"
                else:
                    explanation += "\n💡 You called next() on an empty or exhausted iterator"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: StopIteration) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Используйте цикл for вместо next() для безопасной итерации",
                "Проверяйте наличие элементов перед вызовом next()",
                "Используйте next(iterator, default_value) с значением по умолчанию",
                "Оберните вызов next() в try-except StopIteration"
            ]
        else:
            return [
                "Use for loop instead of next() for safe iteration",
                "Check for elements before calling next()",
                "Use next(iterator, default_value) with a default value",
                "Wrap next() call in try-except StopIteration"
            ]
