"""
Обработчик для EOFError
EOFError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class EOFErrorHandler(BaseHandler):
    """Обработчик для EOFError - ошибок неожиданного конца ввода
    Handler for EOFError - unexpected end of input errors"""

    def explain(self, exception: EOFError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        if lang == "ru":
            explanation = "📄 Неожиданный конец ввода - данные закончились раньше, чем ожидалось"
        elif lang == "en":
            explanation = "📄 Unexpected end of input - data ended earlier than expected"
        elif lang == "de":
            explanation = "📄 Unerwartetes Eingabeende - Daten endeten früher als erwartet"
        elif lang == "fr":
            explanation = "📄 Fin d'entrée inattendue - les données se sont terminées plus tôt que prévu"
        elif lang == "es":
            explanation = "📄 Fin de entrada inesperado - los datos terminaron antes de lo esperado"
        elif lang == "zh":
            explanation = "📄 意外的输入结束 - 数据比预期更早结束"
        elif lang == "ja":
            explanation = "📄 予期しない入力終了 - データが予想より早く終了しました"
        else:
            explanation = "📄 Unexpected end of input - data ended earlier than expected"

        # Анализ контекста
        func_name = context.get('function_name', '')
        if 'input' in func_name.lower() or 'read' in func_name.lower():
            if lang == "ru":
                explanation += "\n💡 Функция ожидала ввод, но достигла конца потока данных"
            else:
                explanation += "\n💡 Function expected input but reached end of data stream"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: EOFError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Проверьте источник данных - файл может быть пустым или поврежденным",
                "Убедитесь, что пользователь вводит данные перед нажатием Ctrl+D/Ctrl+Z",
                "Обрабатывайте EOFError в блоке try-except",
                "Используйте проверку перед чтением: if sys.stdin.isatty()"
            ]
        else:
            return [
                "Check data source - file might be empty or corrupted",
                "Make sure user provides input before pressing Ctrl+D/Ctrl+Z",
                "Handle EOFError in try-except block",
                "Use check before reading: if sys.stdin.isatty()"
            ]
