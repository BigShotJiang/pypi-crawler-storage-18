"""
Обработчик для BrokenPipeError
BrokenPipeError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class BrokenPipeErrorHandler(BaseHandler):
    """Обработчик для BrokenPipeError - ошибок разорванного канала связи
    Handler for BrokenPipeError - broken pipe errors"""

    def explain(self, exception: BrokenPipeError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        if lang == "ru":
            explanation = "🔌 Разорванный канал связи - получатель данных закрыл соединение"
        elif lang == "en":
            explanation = "🔌 Broken pipe - the data receiver closed the connection"
        elif lang == "de":
            explanation = "🔌 Unterbrochene Pipe - der Datenempfänger hat die Verbindung geschlossen"
        elif lang == "fr":
            explanation = "🔌 Tube brisé - le récepteur de données a fermé la connexion"
        elif lang == "es":
            explanation = "🔌 Tubería rota - el receptor de datos cerró la conexión"
        elif lang == "zh":
            explanation = "🔌 管道断开 - 数据接收方关闭了连接"
        elif lang == "ja":
            explanation = "🔌 パイプが壊れました - データ受信側が接続を閉じました"
        else:
            explanation = "🔌 Broken pipe - the data receiver closed the connection"

        # Анализ контекста
        func_name = context.get('function_name', '')
        if any(x in func_name.lower() for x in ['write', 'send', 'print']):
            if lang == "ru":
                explanation += "\n💡 Вы пытались записать данные, но приёмник уже закрыт"
            else:
                explanation += "\n💡 You tried to write data, but the receiver is already closed"

        # Типичный сценарий
        if lang == "ru":
            explanation += "\n\n📝 Часто возникает при:"
            explanation += "\n• Выводе в pipe (cmd | head), когда head прекращает чтение"
            explanation += "\n• Отправке данных в закрытый сокет"
            explanation += "\n• Записи в subprocess, который завершился"
        else:
            explanation += "\n\n📝 Often occurs when:"
            explanation += "\n• Outputting to pipe (cmd | head), when head stops reading"
            explanation += "\n• Sending data to a closed socket"
            explanation += "\n• Writing to a subprocess that has terminated"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: BrokenPipeError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Обрабатывайте BrokenPipeError в try-except блоке",
                "Проверяйте статус соединения перед записью",
                "Используйте signal.signal(signal.SIGPIPE, signal.SIG_DFL) для скриптов",
                "Закрывайте соединения корректно на обеих сторонах"
            ]
        else:
            return [
                "Handle BrokenPipeError in try-except block",
                "Check connection status before writing",
                "Use signal.signal(signal.SIGPIPE, signal.SIG_DFL) for scripts",
                "Close connections properly on both sides"
            ]
