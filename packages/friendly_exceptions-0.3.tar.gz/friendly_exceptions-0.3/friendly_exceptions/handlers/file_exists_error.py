"""
Обработчик для FileExistsError
FileExistsError handler
"""

from typing import Optional, Any
from .base import BaseHandler
import os


class FileExistsErrorHandler(BaseHandler):
    """Обработчик для FileExistsError - ошибок при создании существующего файла
    Handler for FileExistsError - errors when creating an existing file"""

    def explain(self, exception: FileExistsError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        # Извлекаем путь из исключения
        path = ""
        if exception.filename:
            path = exception.filename
        elif len(exception.args) > 0:
            path = str(exception.args[0])

        if lang == "ru":
            explanation = f"📁 Файл или директория уже существует: '{path}'"
        elif lang == "en":
            explanation = f"📁 File or directory already exists: '{path}'"
        elif lang == "de":
            explanation = f"📁 Datei oder Verzeichnis existiert bereits: '{path}'"
        elif lang == "fr":
            explanation = f"📁 Le fichier ou répertoire existe déjà: '{path}'"
        elif lang == "es":
            explanation = f"📁 El archivo o directorio ya existe: '{path}'"
        elif lang == "zh":
            explanation = f"📁 文件或目录已存在: '{path}'"
        elif lang == "ja":
            explanation = f"📁 ファイルまたはディレクトリは既に存在します: '{path}'"
        else:
            explanation = f"📁 File or directory already exists: '{path}'"

        # Дополнительная информация
        if path and os.path.exists(path):
            if os.path.isdir(path):
                if lang == "ru":
                    explanation += "\n📂 Это директория"
                else:
                    explanation += "\n📂 This is a directory"
            else:
                try:
                    size = os.path.getsize(path)
                    if lang == "ru":
                        explanation += f"\n📄 Это файл размером {size} байт"
                    else:
                        explanation += f"\n📄 This is a file of {size} bytes"
                except:
                    pass

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: FileExistsError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Удалите существующий файл/директорию перед созданием",
                "Используйте другое имя файла/директории",
                "Для mkdir() используйте exist_ok=True: os.makedirs(path, exist_ok=True)",
                "Проверяйте существование перед созданием: if not os.path.exists(path)",
                "Используйте режим 'x' (exclusive) осознанно при открытии файла"
            ]
        else:
            return [
                "Delete the existing file/directory before creating",
                "Use a different file/directory name",
                "For mkdir() use exist_ok=True: os.makedirs(path, exist_ok=True)",
                "Check existence before creating: if not os.path.exists(path)",
                "Use 'x' (exclusive) mode consciously when opening file"
            ]
