"""
Обработчик для BlockingIOError
BlockingIOError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class BlockingIOErrorHandler(BaseHandler):
    """Обработчик для BlockingIOError - ошибок блокирующего ввода-вывода
    Handler for BlockingIOError - blocking I/O errors"""

    def explain(self, exception: BlockingIOError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        if lang == "ru":
            explanation = "⏳ Блокирующая операция ввода-вывода на неблокирующем ресурсе"
        elif lang == "en":
            explanation = "⏳ Blocking I/O operation on non-blocking resource"
        elif lang == "de":
            explanation = "⏳ Blockierende I/O-Operation auf nicht-blockierender Ressource"
        elif lang == "fr":
            explanation = "⏳ Opération E/S bloquante sur ressource non-bloquante"
        elif lang == "es":
            explanation = "⏳ Operación de E/S bloqueante en recurso no bloqueante"
        elif lang == "zh":
            explanation = "⏳ 非阻塞资源上的阻塞 I/O 操作"
        elif lang == "ja":
            explanation = "⏳ ノンブロッキングリソースでのブロッキング I/O 操作"
        else:
            explanation = "⏳ Blocking I/O operation on non-blocking resource"

        # Дополнительное объяснение
        if lang == "ru":
            explanation += "\n\n💡 Это происходит, когда:"
            explanation += "\n• Ресурс (сокет, файл) настроен как неблокирующий"
            explanation += "\n• Операция чтения/записи не может быть выполнена немедленно"
            explanation += "\n• Данные еще не готовы или буфер заполнен"
        else:
            explanation += "\n\n💡 This happens when:"
            explanation += "\n• Resource (socket, file) is configured as non-blocking"
            explanation += "\n• Read/write operation cannot complete immediately"
            explanation += "\n• Data is not ready yet or buffer is full"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: BlockingIOError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Используйте select/poll/epoll для ожидания готовности ресурса",
                "Переключитесь на асинхронный ввод-вывод (asyncio)",
                "Обрабатывайте BlockingIOError и повторяйте попытку позже",
                "Используйте блокирующий режим, если немедленность не критична"
            ]
        else:
            return [
                "Use select/poll/epoll to wait for resource readiness",
                "Switch to async I/O (asyncio)",
                "Handle BlockingIOError and retry later",
                "Use blocking mode if immediacy is not critical"
            ]
