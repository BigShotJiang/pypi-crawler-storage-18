"""
Обработчик для ChildProcessError
ChildProcessError handler
"""

from typing import Optional, Any
from .base import BaseHandler


class ChildProcessErrorHandler(BaseHandler):
    """Обработчик для ChildProcessError - ошибок дочерних процессов
    Handler for ChildProcessError - child process errors"""

    def explain(self, exception: ChildProcessError, traceback_obj: Optional[Any] = None) -> str:
        context = self.get_context_info(traceback_obj)
        lang = self._get_language()

        error_msg = str(exception)

        if lang == "ru":
            explanation = f"👶 Ошибка дочернего процесса: {error_msg}"
        elif lang == "en":
            explanation = f"👶 Child process error: {error_msg}"
        elif lang == "de":
            explanation = f"👶 Kindprozessfehler: {error_msg}"
        elif lang == "fr":
            explanation = f"👶 Erreur du processus enfant: {error_msg}"
        elif lang == "es":
            explanation = f"👶 Error del proceso hijo: {error_msg}"
        elif lang == "zh":
            explanation = f"👶 子进程错误: {error_msg}"
        elif lang == "ja":
            explanation = f"👶 子プロセスエラー: {error_msg}"
        else:
            explanation = f"👶 Child process error: {error_msg}"

        # Дополнительная информация
        if lang == "ru":
            explanation += "\n\n💡 Это ошибка операций с дочерними процессами, например:"
            explanation += "\n• wait() или waitpid() на несуществующий процесс"
            explanation += "\n• Отправка сигнала завершённому процессу"
            explanation += "\n• Ошибки в работе subprocess"
        else:
            explanation += "\n\n💡 This is an error in child process operations, such as:"
            explanation += "\n• wait() or waitpid() on non-existent process"
            explanation += "\n• Sending signal to terminated process"
            explanation += "\n• Errors in subprocess operations"

        suggestions = self.get_suggestions(exception)
        if suggestions:
            if lang == "ru":
                explanation += "\n\n🔧 Как исправить:"
            else:
                explanation += "\n\n🔧 How to fix:"
            for i, suggestion in enumerate(suggestions, 1):
                explanation += f"\n{i}. {suggestion}"

        return explanation

    def get_suggestions(self, exception: ChildProcessError) -> list[str]:
        lang = self._get_language()

        if lang == "ru":
            return [
                "Проверяйте существование процесса перед операциями",
                "Используйте subprocess.run() для простых случаев",
                "Обрабатывайте ChildProcessError в try-except",
                "Проверяйте returncode после завершения процесса"
            ]
        else:
            return [
                "Check process existence before operations",
                "Use subprocess.run() for simple cases",
                "Handle ChildProcessError in try-except",
                "Check returncode after process completion"
            ]
