"""
Friendly Exceptions - библиотека для человеко-читаемых исключений
Friendly Exceptions - library for human-readable exceptions

Поддерживаемые языки / Supported languages (15):
    ru - Русский, en - English, de - Deutsch, fr - Français, es - Español,
    it - Italiano, pt - Português, zh - 中文, ja - 日本語, ko - 한국어,
    pl - Polski, uk - Українська, ar - العربية, hi - हिन्दी, tr - Türkçe

Использование / Usage:
    import friendly_exceptions
    friendly_exceptions.set_language('en')  # Switch to English
    friendly_exceptions.set_language('de')  # Switch to German

    # Or use the t() function for translations
    from friendly_exceptions import t
    print(t('common.explanation'))
"""

from .core import (
    explain,
    explain_exception,
    explain_many,
    collect_errors,
    ErrorCollector,
    MultiFileCollector,
    ErrorInfo,
    get_error_location,
    FriendlyException,
    set_language,
    get_language,
    list_languages
)
from .i18n import (
    t,
    get_i18n,
    get_flag,
    get_supported_languages,
    SUPPORTED_LANGUAGES,
    LANGUAGE_FLAGS
)
from .handlers import (
    BaseHandler,
    KeyErrorHandler,
    ValueErrorHandler,
    TypeErrorHandler,
    AttributeErrorHandler,
    IndexErrorHandler,
    FileNotFoundErrorHandler,
    ImportErrorHandler,
    ZeroDivisionErrorHandler,
    OSErrorHandler,
    PermissionErrorHandler,
    IsADirectoryErrorHandler,
    ConnectionErrorHandler,
    TimeoutErrorHandler,
    JSONDecodeErrorHandler,
    UnicodeErrorHandler,
    OverflowErrorHandler,
    RecursionErrorHandler,
    MemoryErrorHandler,
    SyntaxErrorHandler,
    IndentationErrorHandler,
    NameErrorHandler,
    AssertionErrorHandler,
    RuntimeErrorHandler,
    NotImplementedErrorHandler,
    SystemErrorHandler,
    StopIterationHandler,
    EOFErrorHandler,
    FileExistsErrorHandler,
    BrokenPipeErrorHandler,
    BlockingIOErrorHandler,
    ChildProcessErrorHandler,
    InterruptedErrorHandler,
    ProcessLookupErrorHandler,
    get_handler_for_exception
)

# Автоматически устанавливаем глобальный обработчик при импорте
from .core import _setup_global_handler
_setup_global_handler()

# Auto-install для всех библиотек (Django, Pydantic, httpx, PyTorch, etc.)
from . import auto_install

__version__ = "0.3"
__all__ = [
    # Core functions
    "explain",
    "explain_exception",
    "explain_many",
    "collect_errors",
    "ErrorCollector",
    "MultiFileCollector",
    "ErrorInfo",
    "get_error_location",
    "FriendlyException",
    "set_language",
    "get_language",
    "list_languages",
    # i18n
    "t",
    "get_i18n",
    "get_flag",
    "get_supported_languages",
    "SUPPORTED_LANGUAGES",
    "LANGUAGE_FLAGS",
    # Handlers
    "BaseHandler",
    "KeyErrorHandler",
    "ValueErrorHandler",
    "TypeErrorHandler",
    "AttributeErrorHandler",
    "IndexErrorHandler",
    "FileNotFoundErrorHandler",
    "ImportErrorHandler",
    "ZeroDivisionErrorHandler",
    "OSErrorHandler",
    "PermissionErrorHandler",
    "IsADirectoryErrorHandler",
    "ConnectionErrorHandler",
    "TimeoutErrorHandler",
    "JSONDecodeErrorHandler",
    "UnicodeErrorHandler",
    "OverflowErrorHandler",
    "RecursionErrorHandler",
    "MemoryErrorHandler",
    "SyntaxErrorHandler",
    "IndentationErrorHandler",
    "NameErrorHandler",
    "AssertionErrorHandler",
    "RuntimeErrorHandler",
    "NotImplementedErrorHandler",
    "SystemErrorHandler",
    "StopIterationHandler",
    "EOFErrorHandler",
    "FileExistsErrorHandler",
    "BrokenPipeErrorHandler",
    "BlockingIOErrorHandler",
    "ChildProcessErrorHandler",
    "InterruptedErrorHandler",
    "ProcessLookupErrorHandler",
    "get_handler_for_exception"
]
