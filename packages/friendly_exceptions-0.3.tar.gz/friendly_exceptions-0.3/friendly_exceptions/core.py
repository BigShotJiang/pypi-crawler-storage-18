"""
Основной модуль для перехвата и обработки исключений
Core module for intercepting and handling exceptions
"""

import sys
import traceback
import time
import os
from typing import Optional, Dict, Any, List
from pathlib import Path
from .handlers import BaseHandler, get_handler_for_exception
from .config import get_config, set_config, get_config_value
from .logging import setup_logging, get_logger, log_exception, log_handler_performance, log_language_switch
from .i18n import (
    get_i18n, t, get_flag,
    set_language as i18n_set_language,
    get_language as i18n_get_language,
    get_supported_languages,
    SUPPORTED_LANGUAGES,
    LANGUAGE_FLAGS
)

# Инициализируем логирование
setup_logging()
logger = get_logger()


class FriendlyException(Exception):
    """Exception with human-readable message"""

    def __init__(self, original_exception: Exception, friendly_message: str):
        self.original_exception = original_exception
        self.friendly_message = friendly_message
        super().__init__(friendly_message)


class ErrorInfo:
    """Stores error with location info"""

    def __init__(self, exception: Exception, tb=None):
        self.exception = exception
        self.exc_type = type(exception).__name__
        self.message = str(exception)
        self.file = None
        self.line = None
        self.function = None
        self.code = None

        # Extract location from traceback
        if tb is None:
            tb = exception.__traceback__

        if tb:
            # Get the deepest frame (where error actually happened)
            while tb.tb_next:
                tb = tb.tb_next

            frame = tb.tb_frame
            self.file = frame.f_code.co_filename
            self.line = tb.tb_lineno
            self.function = frame.f_code.co_name

            # Try to get source code line
            try:
                import linecache
                self.code = linecache.getline(self.file, self.line).strip()
            except:
                pass

    @property
    def filename(self) -> str:
        """Returns just the filename without path"""
        if self.file:
            return os.path.basename(self.file)
        return "<unknown>"

    @property
    def location(self) -> str:
        """Returns file:line format"""
        if self.file and self.line:
            return f"{self.filename}:{self.line}"
        return "<unknown>"

    def __repr__(self):
        return f"ErrorInfo({self.exc_type} at {self.location})"


def get_error_location(exception: Exception) -> dict:
    """
    Extracts file and line info from exception

    Returns:
        dict with 'file', 'line', 'function', 'code' keys
    """
    info = ErrorInfo(exception)
    return {
        'file': info.file,
        'filename': info.filename,
        'line': info.line,
        'function': info.function,
        'code': info.code,
        'location': info.location
    }


def explain() -> None:
    """
    Перехватывает последнее исключение и выводит его в человеко-читаемом виде
    Intercepts the last exception and displays it in human-readable format
    """
    exc_type, exc_value, exc_traceback = sys.exc_info()

    if exc_type is None:
        print(f"❌ {t('common.no_active_exceptions')}")
        return

    # Получаем обработчик для данного типа исключения
    handler = get_handler_for_exception(exc_type)

    if handler:
        try:
            friendly_message = handler.explain(exc_value, exc_traceback)
            print(f"🔍 {friendly_message}")

            # Показываем оригинальную трассировку для отладки
            print(f"\n📋 {t('common.original_error')}:")
            traceback.print_exception(exc_type, exc_value, exc_traceback)

        except Exception as e:
            print(f"❌ {t('common.error_processing')}: {e}")
            traceback.print_exception(exc_type, exc_value, exc_traceback)
    else:
        print(f"❓ {t('common.unknown_exception', exception_type=exc_type.__name__)}")
        print(f"💬 {t('common.message')}: {exc_value}")
        traceback.print_exception(exc_type, exc_value, exc_traceback)


def explain_exception(exception: Exception) -> str:
    """
    Объясняет переданное исключение и возвращает человеко-читаемое сообщение
    Explains the given exception and returns a human-readable message

    Args:
        exception: Исключение для объяснения / Exception to explain

    Returns:
        Человеко-читаемое сообщение об ошибке / Human-readable error message
    """
    handler = get_handler_for_exception(type(exception))

    if handler:
        return handler.explain(exception, None)
    else:
        return f"❓ {t('common.unknown_exception', exception_type=type(exception).__name__)}: {exception}"


def explain_many(exceptions: list, print_output: bool = True) -> list:
    """
    Объясняет список исключений сразу
    Explains multiple exceptions at once

    Args:
        exceptions: Список исключений для объяснения / List of exceptions to explain
        print_output: Выводить ли результат в консоль / Whether to print output

    Returns:
        Список объяснений / List of explanations

    Example:
        errors = []
        try:
            d = {}['key']
        except Exception as e:
            errors.append(e)
        try:
            x = 1 / 0
        except Exception as e:
            errors.append(e)
        try:
            int('abc')
        except Exception as e:
            errors.append(e)

        explain_many(errors)
    """
    explanations = []
    total = len(exceptions)

    if total == 0:
        if print_output:
            print(f"❌ {t('common.no_active_exceptions')}")
        return explanations

    lang = i18n_get_language()

    if print_output:
        print(f"\n{'='*60}")
        print(f"📋 {t('common.analysis_of_errors', count=total)}")
        print(f"{'='*60}\n")

    for i, exc in enumerate(exceptions, 1):
        explanation = explain_exception(exc)
        info = ErrorInfo(exc)

        explanations.append({
            'index': i,
            'type': info.exc_type,
            'message': info.message,
            'file': info.file,
            'line': info.line,
            'function': info.function,
            'code': info.code,
            'location': info.location,
            'explanation': explanation
        })

        if print_output:
            # Show location if available
            if info.file and info.line:
                print(f"[{i}/{total}] ❌ {info.exc_type} @ {info.location}")
                if info.function and info.function != '<module>':
                    print(f"    📍 in {info.function}()")
                if info.code:
                    print(f"    📝 {info.code}")
            else:
                print(f"[{i}/{total}] ❌ {info.exc_type}")

            print(f"    💬 {exc}")
            print(f"    🔍 {explanation}")
            print()

    if print_output:
        print(f"{'='*60}")
        print(f"✅ {t('common.errors_analyzed', count=total)}")
        print(f"{'='*60}")

    return explanations


def collect_errors(func, *args, **kwargs) -> tuple:
    """
    Запускает функцию и собирает все ошибки
    Runs a function and collects all errors

    Args:
        func: Функция для выполнения
        *args, **kwargs: Аргументы функции

    Returns:
        (result, errors) - результат и список ошибок
    """
    errors = []
    result = None

    try:
        result = func(*args, **kwargs)
    except Exception as e:
        errors.append(e)
        # Проверяем цепочку исключений
        cause = e.__cause__ or e.__context__
        while cause:
            errors.append(cause)
            cause = cause.__cause__ or cause.__context__

    return result, errors


class ErrorCollector:
    """
    Контекстный менеджер для сбора ошибок без остановки выполнения
    Context manager for collecting errors without stopping execution

    Example:
        with ErrorCollector() as collector:
            collector.try_run(lambda: 1/0)
            collector.try_run(lambda: int('abc'))
            collector.try_run(lambda: {}['key'])

        collector.explain_all()
    """

    def __init__(self):
        self.errors = []
        self.results = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Не подавляем исключения, возникшие вне try_run
        return False

    def try_run(self, func, *args, **kwargs):
        """
        Выполняет функцию и собирает ошибку, если она возникла
        Executes function and collects error if it occurs
        """
        try:
            result = func(*args, **kwargs)
            self.results.append(result)
            return result
        except Exception as e:
            self.errors.append(e)
            self.results.append(None)
            return None

    def add_error(self, exception: Exception):
        """Добавляет ошибку в коллектор / Adds error to collector"""
        self.errors.append(exception)

    def explain_all(self, print_output: bool = True) -> list:
        """
        Объясняет все собранные ошибки
        Explains all collected errors
        """
        return explain_many(self.errors, print_output)

    def has_errors(self) -> bool:
        """Есть ли ошибки / Are there any errors"""
        return len(self.errors) > 0

    def clear(self):
        """Очищает список ошибок / Clears error list"""
        self.errors.clear()
        self.results.clear()

    def __len__(self):
        return len(self.errors)


class MultiFileCollector:
    """
    Collects and groups errors from multiple files

    Example:
        collector = MultiFileCollector()

        # Scan Python files for import/syntax errors
        collector.scan_files(['app.py', 'utils.py', 'models.py'])

        # Or collect errors manually with file context
        try:
            exec(open('script.py').read())
        except Exception as e:
            collector.add_error(e, file='script.py')

        collector.explain_all()
    """

    def __init__(self):
        self.errors: List[ErrorInfo] = []

    def add_error(self, exception: Exception, file: str = None, line: int = None):
        """Add error with optional file/line override"""
        info = ErrorInfo(exception)
        if file:
            info.file = file
        if line:
            info.line = line
        self.errors.append(info)

    def scan_file(self, filepath: str) -> List[ErrorInfo]:
        """
        Scans a Python file for syntax/import errors

        Returns list of errors found
        """
        filepath = str(Path(filepath).resolve())
        found_errors = []

        # Check syntax
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                source = f.read()
            compile(source, filepath, 'exec')
        except SyntaxError as e:
            info = ErrorInfo(e)
            info.file = filepath
            info.line = e.lineno
            if e.text:
                info.code = e.text.strip()
            self.errors.append(info)
            found_errors.append(info)
        except Exception as e:
            info = ErrorInfo(e)
            info.file = filepath
            self.errors.append(info)
            found_errors.append(info)

        return found_errors

    def scan_files(self, filepaths: List[str]) -> Dict[str, List[ErrorInfo]]:
        """
        Scans multiple files for errors

        Returns dict mapping filepath to list of errors
        """
        results = {}
        for fp in filepaths:
            errors = self.scan_file(fp)
            if errors:
                results[fp] = errors
        return results

    def scan_directory(self, directory: str, pattern: str = "*.py") -> Dict[str, List[ErrorInfo]]:
        """
        Scans all matching files in directory

        Args:
            directory: Path to directory
            pattern: Glob pattern (default: *.py)

        Returns dict mapping filepath to list of errors
        """
        from glob import glob

        dir_path = Path(directory)
        files = list(dir_path.rglob(pattern))

        return self.scan_files([str(f) for f in files])

    def group_by_file(self) -> Dict[str, List[ErrorInfo]]:
        """Groups collected errors by file"""
        groups = {}
        for info in self.errors:
            file = info.file or '<unknown>'
            if file not in groups:
                groups[file] = []
            groups[file].append(info)
        return groups

    def explain_all(self, print_output: bool = True, group_by_file: bool = True) -> List[dict]:
        """
        Explains all collected errors

        Args:
            print_output: Whether to print to console
            group_by_file: Whether to group errors by file
        """
        if not self.errors:
            if print_output:
                print(f"✅ No errors found")
            return []

        results = []
        total = len(self.errors)

        if print_output:
            print(f"\n{'='*60}")
            print(f"📋 {t('common.analysis_of_errors', count=total)}")
            print(f"{'='*60}\n")

        if group_by_file:
            groups = self.group_by_file()

            for filepath, errors in groups.items():
                if print_output:
                    filename = os.path.basename(filepath) if filepath != '<unknown>' else filepath
                    print(f"📁 {filename}")
                    if filepath != '<unknown>' and filepath != filename:
                        print(f"   {filepath}")
                    print()

                for info in errors:
                    explanation = explain_exception(info.exception)

                    results.append({
                        'type': info.exc_type,
                        'message': info.message,
                        'file': info.file,
                        'line': info.line,
                        'function': info.function,
                        'code': info.code,
                        'explanation': explanation
                    })

                    if print_output:
                        if info.line:
                            print(f"  ❌ Line {info.line}: {info.exc_type}")
                        else:
                            print(f"  ❌ {info.exc_type}")

                        if info.code:
                            print(f"     📝 {info.code}")
                        print(f"     💬 {info.message}")
                        print(f"     🔍 {explanation}")
                        print()

                if print_output:
                    print()
        else:
            # Flat list without grouping
            for i, info in enumerate(self.errors, 1):
                explanation = explain_exception(info.exception)

                results.append({
                    'type': info.exc_type,
                    'message': info.message,
                    'file': info.file,
                    'line': info.line,
                    'explanation': explanation
                })

                if print_output:
                    print(f"[{i}/{total}] ❌ {info.exc_type} @ {info.location}")
                    if info.code:
                        print(f"    📝 {info.code}")
                    print(f"    💬 {info.message}")
                    print(f"    🔍 {explanation}")
                    print()

        if print_output:
            print(f"{'='*60}")
            print(f"✅ {t('common.errors_analyzed', count=total)}")

            # Summary by file
            groups = self.group_by_file()
            if len(groups) > 1:
                print(f"\n📊 Summary by file:")
                for filepath, errors in groups.items():
                    filename = os.path.basename(filepath) if filepath != '<unknown>' else filepath
                    print(f"   {filename}: {len(errors)} error(s)")

            print(f"{'='*60}")

        return results

    def has_errors(self) -> bool:
        return len(self.errors) > 0

    def clear(self):
        self.errors.clear()

    def __len__(self):
        return len(self.errors)


def _setup_global_handler() -> None:
    """
    Автоматически устанавливает глобальный обработчик исключений при импорте
    Automatically sets up global exception handler on import
    """
    def friendly_excepthook(exc_type, exc_value, exc_traceback):
        if exc_type is not None:
            # Логируем исключение
            log_exception(exc_value)

            # Показываем обычный traceback, если включено в конфигурации
            if get_config_value("show_original_traceback", True):
                traceback.print_exception(exc_type, exc_value, exc_traceback)

            # Затем добавляем человеческое объяснение
            handler = get_handler_for_exception(exc_type)
            if handler:
                try:
                    start_time = time.time()
                    friendly_message = handler.explain(exc_value, exc_traceback)
                    execution_time = time.time() - start_time

                    # Логируем производительность обработчика
                    log_handler_performance(handler.__class__.__name__, execution_time)

                    print(f"\n💡 {t('common.explanation')}: {friendly_message}")
                except Exception as e:
                    logger.error(f"Error in handler {handler.__class__.__name__}: {e}")
                    print(f"\n❌ {t('common.error_creating_explanation')}: {e}")
            else:
                logger.warning(f"No handler found for exception type: {exc_type.__name__}")
                print(f"\n❓ {t('common.unknown_exception', exception_type=exc_type.__name__)}")

    # Сохраняем оригинальный excepthook для возможности восстановления
    _original_excepthook = sys.excepthook
    sys.excepthook = friendly_excepthook


def set_global_handler() -> None:
    """
    Устанавливает глобальный обработчик исключений (для совместимости)
    Sets up global exception handler (for compatibility)
    """
    _setup_global_handler()


def set_language(language: str) -> None:
    """
    Устанавливает язык для сообщений об ошибках
    Sets the language for error messages

    Args:
        language: Код языка (ru, en, de, fr, es, it, pt, zh, ja, ko, pl, uk, ar, hi, tr)

    Поддерживаемые языки / Supported languages:
        ru - Русский, en - English, de - Deutsch, fr - Français, es - Español,
        it - Italiano, pt - Português, zh - 中文, ja - 日本語, ko - 한국어,
        pl - Polski, uk - Українська, ar - العربية, hi - हिन्दी, tr - Türkçe
    """
    old_language = i18n_get_language()

    if i18n_set_language(language):
        new_language = i18n_get_language()

        # Обновляем конфигурацию
        set_config("language", new_language)

        # Логируем переключение
        log_language_switch(old_language, new_language)

        # Показываем сообщение на новом языке
        flag = get_flag(new_language)
        lang_name = SUPPORTED_LANGUAGES.get(new_language, new_language)
        print(f"{flag} {t('common.language_set')}: {lang_name}")
    else:
        current = i18n_get_language()
        supported = ", ".join(SUPPORTED_LANGUAGES.keys())
        if current == "ru":
            print(f"❌ Поддерживаемые языки: {supported}")
        else:
            print(f"❌ Supported languages: {supported}")


def get_language() -> str:
    """
    Возвращает текущий язык
    Returns current language

    Returns:
        Текущий язык / Current language
    """
    return i18n_get_language()


def list_languages() -> Dict[str, str]:
    """
    Возвращает словарь поддерживаемых языков
    Returns dictionary of supported languages

    Returns:
        Dict с кодами и названиями языков
    """
    return get_supported_languages()
