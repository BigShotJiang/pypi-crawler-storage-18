"""
FastAPI integration for friendly_exceptions

Usage:
    from fastapi import FastAPI
    from friendly_exceptions.fastapi import add_friendly_exceptions

    app = FastAPI()
    add_friendly_exceptions(app)

    # Or with file output:
    add_friendly_exceptions(app, output_file="errors.txt")
"""

from datetime import datetime
from typing import Optional, Callable
import json
import traceback

# Lazy imports to avoid requiring fastapi
_fastapi = None
_Request = None
_JSONResponse = None


def _import_fastapi():
    global _fastapi, _Request, _JSONResponse
    if _fastapi is None:
        try:
            from fastapi import FastAPI, Request
            from fastapi.responses import JSONResponse
            _fastapi = FastAPI
            _Request = Request
            _JSONResponse = JSONResponse
        except ImportError:
            raise ImportError("FastAPI not installed. Run: pip install fastapi")


def add_friendly_exceptions(
    app,
    output_file: Optional[str] = None,
    include_in_response: bool = False,
    lang: str = "en"
):
    """
    Add friendly_exceptions to FastAPI app

    Args:
        app: FastAPI application instance
        output_file: Optional file to log errors to
        include_in_response: Include friendly message in JSON response
        lang: Language for error messages
    """
    _import_fastapi()

    import friendly_exceptions
    from friendly_exceptions import explain_exception, ErrorInfo

    friendly_exceptions.set_language(lang)

    def write_to_file(content: str):
        if output_file:
            with open(output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}] {content}\n")

    # Handle validation errors (Pydantic)
    try:
        from fastapi.exceptions import RequestValidationError

        @app.exception_handler(RequestValidationError)
        async def validation_exception_handler(request, exc):
            errors = exc.errors()
            friendly_errors = []

            for error in errors:
                loc = " -> ".join(str(l) for l in error.get("loc", []))
                msg = error.get("msg", "")
                error_type = error.get("type", "")

                friendly_msg = f"Field '{loc}': {msg}"
                friendly_errors.append({
                    "field": loc,
                    "message": msg,
                    "type": error_type
                })

            log_msg = f"ValidationError @ {request.url.path}: {friendly_errors}"
            write_to_file(log_msg)

            response = {
                "error": "Validation Error",
                "details": friendly_errors
            }

            if include_in_response:
                response["friendly_message"] = "Check your request data"

            return _JSONResponse(status_code=422, content=response)

    except ImportError:
        pass

    # Handle HTTP exceptions
    try:
        from fastapi import HTTPException

        @app.exception_handler(HTTPException)
        async def http_exception_handler(request, exc):
            log_msg = f"HTTPException {exc.status_code} @ {request.url.path}: {exc.detail}"
            write_to_file(log_msg)

            response = {
                "error": exc.detail,
                "status_code": exc.status_code
            }

            return _JSONResponse(status_code=exc.status_code, content=response)

    except ImportError:
        pass

    # Handle all other exceptions
    @app.exception_handler(Exception)
    async def general_exception_handler(request, exc):
        info = ErrorInfo(exc)
        explanation = explain_exception(exc)

        # Log full details
        log_lines = [
            f"{'='*60}",
            f"❌ {type(exc).__name__} @ {request.url.path}",
            f"📍 {info.location}",
        ]
        if info.code:
            log_lines.append(f"📝 {info.code}")
        log_lines.extend([
            f"💬 {exc}",
            f"🔍 {explanation}",
            f"{'='*60}",
        ])

        log_msg = "\n".join(log_lines)
        write_to_file(log_msg)

        # Print to console
        print(log_msg)

        response = {
            "error": "Internal Server Error",
            "type": type(exc).__name__,
        }

        if include_in_response:
            response["friendly_message"] = explanation
            response["location"] = info.location

        return _JSONResponse(status_code=500, content=response)


class FriendlyExceptionsMiddleware:
    """
    ASGI Middleware for friendly_exceptions

    Usage:
        from friendly_exceptions.fastapi import FriendlyExceptionsMiddleware
        app.add_middleware(FriendlyExceptionsMiddleware, output_file="errors.txt")
    """

    def __init__(self, app, output_file: Optional[str] = None, lang: str = "en"):
        self.app = app
        self.output_file = output_file
        self.lang = lang

        import friendly_exceptions
        friendly_exceptions.set_language(lang)

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        try:
            await self.app(scope, receive, send)
        except Exception as exc:
            from friendly_exceptions import explain_exception, ErrorInfo

            info = ErrorInfo(exc)
            explanation = explain_exception(exc)

            path = scope.get("path", "/")
            log_msg = f"[{datetime.now()}] {type(exc).__name__} @ {path}: {explanation}"

            if self.output_file:
                with open(self.output_file, 'a', encoding='utf-8') as f:
                    f.write(log_msg + "\n")

            print(log_msg)
            raise
