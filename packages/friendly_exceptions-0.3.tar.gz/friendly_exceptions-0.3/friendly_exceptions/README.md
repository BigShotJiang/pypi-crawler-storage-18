# Friendly Exceptions

Human-readable error messages for Python. Just import and everything works.

## Installation

```bash
pip install friendly-exceptions
```

## Quick Start

```python
import friendly_exceptions

# That's it! All errors now have friendly explanations
d = {}
d['missing']  # KeyError with helpful message
```

## Features

- **Zero configuration** - just import and it works
- **15 languages** - ru, en, de, fr, es, it, pt, zh, ja, ko, pl, uk, ar, hi, tr
- **30+ built-in handlers** - KeyError, TypeError, ValueError, FileNotFoundError, etc.
- **20+ integrations** - Django, Pydantic, FastAPI, SQLAlchemy, Redis, MongoDB, AWS, Stripe, etc.
- **Web console** - visual error dashboard with Supabase sync
- **CLI** - global install for any Python project

## Language Support

```python
import friendly_exceptions

friendly_exceptions.set_language('ru')  # Русский
friendly_exceptions.set_language('de')  # Deutsch
friendly_exceptions.set_language('zh')  # 中文
friendly_exceptions.set_language('ja')  # 日本語
```

## Integrations

All integrations load automatically if the library is installed:

| Category | Libraries |
|----------|-----------|
| Web | Django, FastAPI, Pydantic |
| Database | SQLAlchemy, MongoDB, Redis |
| HTTP | Requests, httpx, aiohttp |
| Cloud | AWS/boto3, Firebase, Stripe |
| Data | Pandas, NumPy, Pillow |
| Bots | Telegram, Discord |
| Testing | Pytest |
| Other | OpenAI, Selenium, Subprocess, Asyncio |

## Server Mode

When running as a server (Django runserver, uvicorn, gunicorn), errors are logged to `fe.log`:

```python
# settings.py or manage.py
import friendly_exceptions

# Errors now logged to fe.log instead of console
```

## Web Console

```bash
python -m friendly_exceptions web-console run -p 8080
```

Features:
- Visual error dashboard
- Supabase authentication
- Cloud sync for errors and settings
- Notification settings (Slack, Telegram, Discord, Email)

## CLI

Global install for any project:

```bash
# Install globally
friendly-exceptions install

# Check status
friendly-exceptions status

# Uninstall
friendly-exceptions uninstall
```

## API

```python
from friendly_exceptions import (
    explain,              # Explain last exception
    explain_exception,    # Explain specific exception
    set_language,         # Set language
    get_language,         # Get current language
    list_languages,       # List available languages
    ErrorCollector,       # Collect multiple errors
)
```

## Example Output

```
Exception: KeyError: 'user_id'
Traceback (most recent call last):
  File "app.py", line 10, in get_user
    return data['user_id']
KeyError: 'user_id'

💡 Explanation: 🔑 Dictionary does not contain key 'user_id'
📋 Dictionary 'data' contains keys: ['name', 'email']

🔧 How to fix:
1. Check the spelling of the key
2. Use .get() method: dict.get('key', default_value)
3. Check if key exists: 'key' in dict
```

## License

MIT
