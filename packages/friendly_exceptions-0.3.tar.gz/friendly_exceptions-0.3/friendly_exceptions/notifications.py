"""
Error notifications to Slack, Telegram, Discord, Email

Usage:
    from friendly_exceptions.notifications import NotificationManager, install_notifications

    # Configure notifications
    notifications = NotificationManager()
    notifications.add_slack(webhook_url="https://hooks.slack.com/...")
    notifications.add_telegram(bot_token="...", chat_id="...")
    notifications.add_discord(webhook_url="https://discord.com/api/webhooks/...")
    notifications.add_email(smtp_host="smtp.gmail.com", ...)

    # Install globally
    install_notifications(notifications)

    # Or send manually
    notifications.send("Error occurred!", level="error")
"""

import json
import urllib.request
import urllib.error
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import sys
import threading
import traceback


class NotificationLevel(Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class NotificationConfig:
    """Base notification configuration"""
    enabled: bool = True
    min_level: NotificationLevel = NotificationLevel.ERROR
    rate_limit_seconds: int = 60  # Don't send same error more than once per minute


@dataclass
class SlackConfig(NotificationConfig):
    webhook_url: str = ""
    channel: str = ""
    username: str = "Friendly Exceptions"
    icon_emoji: str = ":warning:"


@dataclass
class TelegramConfig(NotificationConfig):
    bot_token: str = ""
    chat_id: str = ""
    parse_mode: str = "HTML"


@dataclass
class DiscordConfig(NotificationConfig):
    webhook_url: str = ""
    username: str = "Friendly Exceptions"
    avatar_url: str = ""


@dataclass
class EmailConfig(NotificationConfig):
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    from_email: str = ""
    to_emails: List[str] = field(default_factory=list)
    use_tls: bool = True
    subject_prefix: str = "[Error]"


class NotificationManager:
    """Manage and send notifications to multiple channels"""

    def __init__(self):
        self.slack: Optional[SlackConfig] = None
        self.telegram: Optional[TelegramConfig] = None
        self.discord: Optional[DiscordConfig] = None
        self.email: Optional[EmailConfig] = None
        self._sent_hashes: Dict[str, datetime] = {}
        self._lock = threading.Lock()

    def add_slack(
        self,
        webhook_url: str,
        channel: str = "",
        username: str = "Friendly Exceptions",
        min_level: str = "error",
        rate_limit: int = 60
    ):
        """Add Slack notification channel"""
        self.slack = SlackConfig(
            webhook_url=webhook_url,
            channel=channel,
            username=username,
            min_level=NotificationLevel(min_level),
            rate_limit_seconds=rate_limit
        )
        return self

    def add_telegram(
        self,
        bot_token: str,
        chat_id: str,
        min_level: str = "error",
        rate_limit: int = 60
    ):
        """Add Telegram notification channel"""
        self.telegram = TelegramConfig(
            bot_token=bot_token,
            chat_id=chat_id,
            min_level=NotificationLevel(min_level),
            rate_limit_seconds=rate_limit
        )
        return self

    def add_discord(
        self,
        webhook_url: str,
        username: str = "Friendly Exceptions",
        min_level: str = "error",
        rate_limit: int = 60
    ):
        """Add Discord notification channel"""
        self.discord = DiscordConfig(
            webhook_url=webhook_url,
            username=username,
            min_level=NotificationLevel(min_level),
            rate_limit_seconds=rate_limit
        )
        return self

    def add_email(
        self,
        smtp_host: str,
        smtp_port: int,
        smtp_user: str,
        smtp_password: str,
        from_email: str,
        to_emails: List[str],
        use_tls: bool = True,
        min_level: str = "error",
        rate_limit: int = 300  # 5 minutes for email
    ):
        """Add Email notification channel"""
        self.email = EmailConfig(
            smtp_host=smtp_host,
            smtp_port=smtp_port,
            smtp_user=smtp_user,
            smtp_password=smtp_password,
            from_email=from_email,
            to_emails=to_emails,
            use_tls=use_tls,
            min_level=NotificationLevel(min_level),
            rate_limit_seconds=rate_limit
        )
        return self

    def _should_send(self, config: NotificationConfig, message: str, level: NotificationLevel) -> bool:
        """Check if notification should be sent (rate limiting + level check)"""
        if not config.enabled:
            return False

        # Check level
        levels = list(NotificationLevel)
        if levels.index(level) < levels.index(config.min_level):
            return False

        # Check rate limit
        msg_hash = hash(message)
        with self._lock:
            now = datetime.now()
            if msg_hash in self._sent_hashes:
                last_sent = self._sent_hashes[msg_hash]
                if (now - last_sent).total_seconds() < config.rate_limit_seconds:
                    return False
            self._sent_hashes[msg_hash] = now

        return True

    def _send_slack(self, title: str, message: str, level: NotificationLevel):
        """Send notification to Slack"""
        if not self.slack or not self._should_send(self.slack, message, level):
            return

        color_map = {
            NotificationLevel.DEBUG: "#808080",
            NotificationLevel.INFO: "#2196F3",
            NotificationLevel.WARNING: "#FFC107",
            NotificationLevel.ERROR: "#F44336",
            NotificationLevel.CRITICAL: "#9C27B0",
        }

        payload = {
            "username": self.slack.username,
            "icon_emoji": self.slack.icon_emoji,
            "attachments": [{
                "color": color_map.get(level, "#F44336"),
                "title": title,
                "text": message[:3000],
                "footer": "Friendly Exceptions",
                "ts": int(datetime.now().timestamp())
            }]
        }

        if self.slack.channel:
            payload["channel"] = self.slack.channel

        self._post_json(self.slack.webhook_url, payload)

    def _send_telegram(self, title: str, message: str, level: NotificationLevel):
        """Send notification to Telegram"""
        if not self.telegram or not self._should_send(self.telegram, message, level):
            return

        emoji_map = {
            NotificationLevel.DEBUG: "🔍",
            NotificationLevel.INFO: "ℹ️",
            NotificationLevel.WARNING: "⚠️",
            NotificationLevel.ERROR: "❌",
            NotificationLevel.CRITICAL: "🚨",
        }

        emoji = emoji_map.get(level, "❌")
        text = f"{emoji} <b>{title}</b>\n\n<pre>{message[:4000]}</pre>"

        url = f"https://api.telegram.org/bot{self.telegram.bot_token}/sendMessage"
        payload = {
            "chat_id": self.telegram.chat_id,
            "text": text,
            "parse_mode": self.telegram.parse_mode
        }

        self._post_json(url, payload)

    def _send_discord(self, title: str, message: str, level: NotificationLevel):
        """Send notification to Discord"""
        if not self.discord or not self._should_send(self.discord, message, level):
            return

        color_map = {
            NotificationLevel.DEBUG: 0x808080,
            NotificationLevel.INFO: 0x2196F3,
            NotificationLevel.WARNING: 0xFFC107,
            NotificationLevel.ERROR: 0xF44336,
            NotificationLevel.CRITICAL: 0x9C27B0,
        }

        payload = {
            "username": self.discord.username,
            "embeds": [{
                "title": title,
                "description": f"```\n{message[:4000]}\n```",
                "color": color_map.get(level, 0xF44336),
                "timestamp": datetime.utcnow().isoformat(),
                "footer": {"text": "Friendly Exceptions"}
            }]
        }

        if self.discord.avatar_url:
            payload["avatar_url"] = self.discord.avatar_url

        self._post_json(self.discord.webhook_url, payload)

    def _send_email(self, title: str, message: str, level: NotificationLevel):
        """Send notification via Email"""
        if not self.email or not self._should_send(self.email, message, level):
            return

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = f"{self.email.subject_prefix} {title}"
            msg["From"] = self.email.from_email
            msg["To"] = ", ".join(self.email.to_emails)

            # Plain text
            text_part = MIMEText(message, "plain")
            msg.attach(text_part)

            # HTML
            html = f"""
            <html>
            <body>
            <h2 style="color: #F44336;">{title}</h2>
            <pre style="background: #f5f5f5; padding: 10px; border-radius: 5px;">{message}</pre>
            <p style="color: #888; font-size: 12px;">Sent by Friendly Exceptions</p>
            </body>
            </html>
            """
            html_part = MIMEText(html, "html")
            msg.attach(html_part)

            # Send
            context = ssl.create_default_context()

            if self.email.use_tls:
                with smtplib.SMTP(self.email.smtp_host, self.email.smtp_port) as server:
                    server.starttls(context=context)
                    server.login(self.email.smtp_user, self.email.smtp_password)
                    server.sendmail(
                        self.email.from_email,
                        self.email.to_emails,
                        msg.as_string()
                    )
            else:
                with smtplib.SMTP_SSL(self.email.smtp_host, self.email.smtp_port, context=context) as server:
                    server.login(self.email.smtp_user, self.email.smtp_password)
                    server.sendmail(
                        self.email.from_email,
                        self.email.to_emails,
                        msg.as_string()
                    )
        except Exception as e:
            print(f"Failed to send email: {e}", file=sys.stderr)

    def _post_json(self, url: str, data: dict):
        """POST JSON to URL"""
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(data).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                return response.read()
        except Exception as e:
            print(f"Failed to send notification: {e}", file=sys.stderr)

    def send(
        self,
        message: str,
        title: str = "Error",
        level: str = "error",
        async_send: bool = True
    ):
        """
        Send notification to all configured channels

        Args:
            message: Error message/details
            title: Short title
            level: Notification level (debug, info, warning, error, critical)
            async_send: Send in background thread
        """
        lvl = NotificationLevel(level)

        def do_send():
            if self.slack:
                self._send_slack(title, message, lvl)
            if self.telegram:
                self._send_telegram(title, message, lvl)
            if self.discord:
                self._send_discord(title, message, lvl)
            if self.email:
                self._send_email(title, message, lvl)

        if async_send:
            thread = threading.Thread(target=do_send, daemon=True)
            thread.start()
        else:
            do_send()

    def send_exception(
        self,
        exc_info=None,
        title: str = None,
        level: str = "error",
        include_traceback: bool = True
    ):
        """
        Send exception notification

        Args:
            exc_info: sys.exc_info() tuple or None for current exception
            title: Custom title (default: exception type)
            level: Notification level
            include_traceback: Include full traceback
        """
        if exc_info is None:
            exc_info = sys.exc_info()

        exc_type, exc_value, exc_tb = exc_info

        if title is None:
            title = f"{exc_type.__name__}: {str(exc_value)[:50]}"

        if include_traceback:
            message = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
        else:
            message = str(exc_value)

        self.send(message, title, level)

    def to_dict(self) -> dict:
        """Export configuration as dict"""
        config = {}

        if self.slack:
            config['slack'] = {
                'webhook_url': self.slack.webhook_url,
                'channel': self.slack.channel,
                'username': self.slack.username,
                'min_level': self.slack.min_level.value,
                'rate_limit': self.slack.rate_limit_seconds
            }

        if self.telegram:
            config['telegram'] = {
                'bot_token': self.telegram.bot_token,
                'chat_id': self.telegram.chat_id,
                'min_level': self.telegram.min_level.value,
                'rate_limit': self.telegram.rate_limit_seconds
            }

        if self.discord:
            config['discord'] = {
                'webhook_url': self.discord.webhook_url,
                'username': self.discord.username,
                'min_level': self.discord.min_level.value,
                'rate_limit': self.discord.rate_limit_seconds
            }

        if self.email:
            config['email'] = {
                'smtp_host': self.email.smtp_host,
                'smtp_port': self.email.smtp_port,
                'from_email': self.email.from_email,
                'to_emails': self.email.to_emails,
                'min_level': self.email.min_level.value,
                'rate_limit': self.email.rate_limit_seconds
            }

        return config

    @classmethod
    def from_dict(cls, config: dict) -> 'NotificationManager':
        """Create from dict configuration"""
        manager = cls()

        if 'slack' in config:
            c = config['slack']
            manager.add_slack(
                webhook_url=c.get('webhook_url', ''),
                channel=c.get('channel', ''),
                username=c.get('username', 'Friendly Exceptions'),
                min_level=c.get('min_level', 'error'),
                rate_limit=c.get('rate_limit', 60)
            )

        if 'telegram' in config:
            c = config['telegram']
            manager.add_telegram(
                bot_token=c.get('bot_token', ''),
                chat_id=c.get('chat_id', ''),
                min_level=c.get('min_level', 'error'),
                rate_limit=c.get('rate_limit', 60)
            )

        if 'discord' in config:
            c = config['discord']
            manager.add_discord(
                webhook_url=c.get('webhook_url', ''),
                username=c.get('username', 'Friendly Exceptions'),
                min_level=c.get('min_level', 'error'),
                rate_limit=c.get('rate_limit', 60)
            )

        if 'email' in config:
            c = config['email']
            manager.add_email(
                smtp_host=c.get('smtp_host', ''),
                smtp_port=c.get('smtp_port', 587),
                smtp_user=c.get('smtp_user', ''),
                smtp_password=c.get('smtp_password', ''),
                from_email=c.get('from_email', ''),
                to_emails=c.get('to_emails', []),
                use_tls=c.get('use_tls', True),
                min_level=c.get('min_level', 'error'),
                rate_limit=c.get('rate_limit', 300)
            )

        return manager


class NotificationExceptHook:
    """Exception hook that sends notifications"""

    def __init__(self, manager: NotificationManager, original_hook=None):
        self.manager = manager
        self.original_hook = original_hook

    def __call__(self, exc_type, exc_value, exc_tb):
        # Send notification
        self.manager.send_exception(
            exc_info=(exc_type, exc_value, exc_tb),
            level="error"
        )

        # Call original hook
        if self.original_hook:
            self.original_hook(exc_type, exc_value, exc_tb)
        else:
            sys.__excepthook__(exc_type, exc_value, exc_tb)


def install_notifications(manager: NotificationManager):
    """Install notification hook globally"""
    sys.excepthook = NotificationExceptHook(manager, sys.excepthook)


# Global manager instance
_global_manager: Optional[NotificationManager] = None


def get_global_manager() -> NotificationManager:
    """Get or create global notification manager"""
    global _global_manager
    if _global_manager is None:
        _global_manager = NotificationManager()
    return _global_manager


def configure_global(config: dict):
    """Configure global notification manager"""
    global _global_manager
    _global_manager = NotificationManager.from_dict(config)
    return _global_manager
