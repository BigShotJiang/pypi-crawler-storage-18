#!/usr/bin/env python3
"""
friendly_exceptions CLI

Commands:
    python -m friendly_exceptions enable [path]   - Enable for folder
    python -m friendly_exceptions disable [path]  - Disable for folder
    python -m friendly_exceptions install         - Install globally
    python -m friendly_exceptions uninstall       - Uninstall global hook
    python -m friendly_exceptions status          - Show status
    python -m friendly_exceptions --test          - Test library

Web Console (auth required by default):
    python -m friendly_exceptions web-console run -p 8080    - Run web console
    python -m friendly_exceptions web-console run --no-auth  - Run without auth
    python -m friendly_exceptions web-console export -o errors.json  - Export
    python -m friendly_exceptions web-console stats          - Show statistics
"""

import sys
import os
import site
from pathlib import Path
from typing import Optional

MARKER_FILE = ".friendly_exceptions"
PTH_FILE = "friendly_exceptions_autoload.pth"


def get_site_packages() -> Optional[Path]:
    """Gets path to site-packages"""
    user_site = site.getusersitepackages()
    if user_site:
        user_path = Path(user_site)
        user_path.mkdir(parents=True, exist_ok=True)
        if os.access(user_path, os.W_OK):
            return user_path

    if hasattr(site, 'getsitepackages'):
        for p in site.getsitepackages():
            if os.path.isdir(p) and os.access(p, os.W_OK):
                return Path(p)

    return None


def find_marker_in_parents(start_path: Path) -> Optional[Path]:
    """Finds .friendly_exceptions marker in current and parent folders"""
    current = start_path.resolve()

    while current != current.parent:
        marker = current / MARKER_FILE
        if marker.exists():
            return marker
        current = current.parent

    return None


def cmd_enable(path: str = None):
    """Enables friendly_exceptions for folder"""
    target = Path(path) if path else Path.cwd()
    target = target.resolve()

    if not target.is_dir():
        print(f"Error: Folder does not exist: {target}")
        return False

    marker = target / MARKER_FILE
    marker.touch()

    print(f"friendly_exceptions enabled for: {target}")
    print(f"   Marker created: {marker}")

    site_packages = get_site_packages()
    if site_packages:
        pth_path = site_packages / PTH_FILE
        if not pth_path.exists():
            print()
            print("Note: Global install required:")
            print("   python -m friendly_exceptions install")

    return True


def cmd_disable(path: str = None):
    """Disables friendly_exceptions for folder"""
    target = Path(path) if path else Path.cwd()
    target = target.resolve()

    marker = target / MARKER_FILE

    if marker.exists():
        marker.unlink()
        print(f"friendly_exceptions disabled for: {target}")
    else:
        print(f"Marker not found in: {target}")

    return True


def cmd_install():
    """Installs global hook to site-packages"""
    site_packages = get_site_packages()

    if not site_packages:
        print("Error: Could not find writable site-packages")
        print("   Try running with sudo or in virtualenv")
        return False

    pth_path = site_packages / PTH_FILE

    loader_path = site_packages / "friendly_exceptions_loader.py"
    loader_content = '''"""Auto-loader for friendly_exceptions"""
import os
p = os.getcwd()
while p != os.path.dirname(p):
    if os.path.exists(os.path.join(p, ".friendly_exceptions")):
        try:
            import friendly_exceptions
        except ImportError:
            pass
        break
    p = os.path.dirname(p)
'''

    pth_content = "import friendly_exceptions_loader\n"

    try:
        loader_path.write_text(loader_content)
        pth_path.write_text(pth_content)
        print(f"Global hook installed!")
        print(f"   File: {pth_path}")
        print()
        print("Now use:")
        print("   cd /path/to/project")
        print("   python -m friendly_exceptions enable")
        print("   python script.py  # friendly_exceptions works automatically!")
        return True
    except PermissionError:
        print(f"Error: No write permission for: {site_packages}")
        print("   Try: sudo python -m friendly_exceptions install")
        return False


def cmd_uninstall():
    """Removes global hook"""
    removed = False
    loader_file = "friendly_exceptions_loader.py"

    user_site = site.getusersitepackages()
    if user_site:
        for fname in [PTH_FILE, loader_file]:
            fpath = Path(user_site) / fname
            if fpath.exists():
                try:
                    fpath.unlink()
                    print(f"Removed: {fpath}")
                    removed = True
                except PermissionError:
                    print(f"Error: No permission to remove: {fpath}")

    if hasattr(site, 'getsitepackages'):
        for p in site.getsitepackages():
            for fname in [PTH_FILE, loader_file]:
                fpath = Path(p) / fname
                if fpath.exists():
                    try:
                        fpath.unlink()
                        print(f"Removed: {fpath}")
                        removed = True
                    except PermissionError:
                        print(f"Error: No permission to remove: {fpath}")

    if not removed:
        print("Global hook was not installed")

    return True


def cmd_status():
    """Shows status"""
    print("friendly_exceptions status")
    print("=" * 50)

    installed = False

    user_site = site.getusersitepackages()
    if user_site:
        pth_path = Path(user_site) / PTH_FILE
        if pth_path.exists():
            print(f"[OK] Global hook (user): {pth_path}")
            installed = True

    if hasattr(site, 'getsitepackages'):
        for p in site.getsitepackages():
            pth_path = Path(p) / PTH_FILE
            if pth_path.exists():
                print(f"[OK] Global hook (system): {pth_path}")
                installed = True

    if not installed:
        print("[--] Global hook: not installed")
        print("   Install: python -m friendly_exceptions install")

    print()

    cwd = Path.cwd()
    marker = find_marker_in_parents(cwd)

    if marker:
        print(f"[OK] Active for current folder")
        print(f"   Marker: {marker}")
    else:
        print(f"[--] Not active for: {cwd}")
        print(f"   Enable: python -m friendly_exceptions enable")


def cmd_test():
    """Tests the library"""
    from .core import explain_exception

    print("friendly_exceptions test")
    print("=" * 50)

    tests = [
        ("KeyError", lambda: {}["missing"]),
        ("ZeroDivisionError", lambda: 1/0),
        ("ValueError", lambda: int("abc")),
        ("IndexError", lambda: [1,2,3][10]),
    ]

    for name, func in tests:
        print(f"\n{name}:")
        try:
            func()
        except Exception as e:
            result = explain_exception(e)
            print(f"  {result[:80]}...")

    print("\n[OK] Test complete!")


def cmd_web_console(args: list):
    """Run web console"""
    import argparse

    parser = argparse.ArgumentParser(
        prog="friendly-exceptions web-console",
        description="Friendly Exceptions Web Console"
    )

    subparsers = parser.add_subparsers(dest="action", help="Action")

    # Run subcommand
    run_parser = subparsers.add_parser("run", help="Run web console server")
    run_parser.add_argument("-p", "--port", type=int, default=8080, help="Port (default: 8080)")
    run_parser.add_argument("-H", "--host", default="0.0.0.0", help="Host (default: 0.0.0.0)")
    run_parser.add_argument("-d", "--db", default="friendly_exceptions.db", help="Database path")
    run_parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    run_parser.add_argument("--no-auth", action="store_true", help="Disable authentication (not recommended)")

    # Export subcommand
    export_parser = subparsers.add_parser("export", help="Export errors")
    export_parser.add_argument("-f", "--format", choices=["json", "csv"], default="json", help="Export format")
    export_parser.add_argument("-o", "--output", required=True, help="Output file")
    export_parser.add_argument("-d", "--db", default="friendly_exceptions.db", help="Database path")

    # Stats subcommand
    stats_parser = subparsers.add_parser("stats", help="Show error statistics")
    stats_parser.add_argument("-d", "--db", default="friendly_exceptions.db", help="Database path")
    stats_parser.add_argument("--days", type=int, default=7, help="Days to analyze")

    parsed = parser.parse_args(args)

    if parsed.action == "run":
        try:
            from .web_console import run_server

            run_server(
                host=parsed.host,
                port=parsed.port,
                db_path=parsed.db,
                reload=parsed.reload,
                require_auth=not parsed.no_auth
            )
        except ImportError as e:
            print(f"Error: {e}")
            print("Install required packages: pip install fastapi uvicorn")
            return 1

    elif parsed.action == "export":
        from .storage import ErrorStorage
        storage = ErrorStorage(parsed.db)

        if parsed.format == "json":
            storage.export_json(parsed.output)
        else:
            storage.export_csv(parsed.output)

        print(f"Exported to: {parsed.output}")

    elif parsed.action == "stats":
        from .storage import ErrorStorage
        storage = ErrorStorage(parsed.db)
        stats = storage.get_stats(days=parsed.days)

        print(f"\nError Statistics (last {parsed.days} days)")
        print("=" * 50)
        print(f"Total errors:       {stats['total_errors']}")
        print(f"Unresolved:         {stats['unresolved']}")
        print(f"Recent occurrences: {stats['recent_occurrences']}")

        if stats['by_type']:
            print("\nTop error types:")
            for item in stats['by_type'][:5]:
                print(f"  {item['error_type']}: {item['count']}")

        if stats['top_files']:
            print("\nTop files with errors:")
            for item in stats['top_files'][:5]:
                print(f"  {item['filename']}: {item['count']}")

    else:
        parser.print_help()
        return 1

    return 0


def main():
    """Main CLI function"""
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__)
        print()
        cmd_status()
        return 0

    command = args[0].lower()
    path = args[1] if len(args) > 1 else None

    if command == "enable":
        cmd_enable(path)
    elif command == "disable":
        cmd_disable(path)
    elif command == "install":
        cmd_install()
    elif command == "uninstall":
        cmd_uninstall()
    elif command == "status":
        cmd_status()
    elif command in ("test", "--test", "-t"):
        cmd_test()
    elif command in ("--version", "-v"):
        from . import __version__
        print(f"friendly_exceptions {__version__}")
    elif command in ("web-console", "web_console", "console"):
        return cmd_web_console(args[1:])
    else:
        print(f"Error: Unknown command: {command}")
        print(__doc__)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
