#!/usr/bin/env python3
"""
Uvicorn wrapper with friendly_exceptions support

Usage:
    python -m friendly_exceptions.uvicorn app:app --f_excps
    python -m friendly_exceptions.uvicorn app:app --f_excps -o errors.txt
    python -m friendly_exceptions.uvicorn app:app --f_excps -o errors.txt --lang ru

Or use the shortcut:
    f_uvicorn app:app --f_excps -o errors.txt
"""

import sys
import os
import argparse
import logging
from datetime import datetime
from typing import Optional
from pathlib import Path


class FriendlyExceptionsHandler(logging.Handler):
    """Custom logging handler that writes friendly exceptions to file"""

    def __init__(self, output_file: Optional[str] = None):
        super().__init__()
        self.output_file = output_file
        self._file_handle = None

        if output_file:
            # Create/open file for appending
            self._file_handle = open(output_file, 'a', encoding='utf-8')
            self._write_header()

    def _write_header(self):
        if self._file_handle:
            self._file_handle.write(f"\n{'='*60}\n")
            self._file_handle.write(f"friendly_exceptions log started: {datetime.now()}\n")
            self._file_handle.write(f"{'='*60}\n\n")
            self._file_handle.flush()

    def emit(self, record):
        try:
            msg = self.format(record)

            # Write to file if specified
            if self._file_handle:
                self._file_handle.write(f"{msg}\n")
                self._file_handle.flush()

        except Exception:
            self.handleError(record)

    def close(self):
        if self._file_handle:
            self._file_handle.close()
        super().close()


def setup_exception_hook(output_file: Optional[str] = None):
    """Setup global exception hook with optional file output"""
    import friendly_exceptions
    from friendly_exceptions import explain_exception, ErrorInfo

    original_hook = sys.excepthook

    def friendly_hook(exc_type, exc_value, exc_tb):
        # Get friendly explanation
        try:
            info = ErrorInfo(exc_value, exc_tb)
            explanation = explain_exception(exc_value)

            output = []
            output.append(f"\n{'='*60}")
            output.append(f"❌ {exc_type.__name__} @ {info.location}")
            if info.code:
                output.append(f"📝 {info.code}")
            output.append(f"💬 {exc_value}")
            output.append(f"🔍 {explanation}")
            output.append(f"{'='*60}\n")

            message = '\n'.join(output)

            # Print to stderr
            print(message, file=sys.stderr)

            # Write to file if specified
            if output_file:
                with open(output_file, 'a', encoding='utf-8') as f:
                    f.write(f"[{datetime.now()}]\n")
                    f.write(message)
                    f.write('\n')

        except Exception as e:
            print(f"friendly_exceptions error: {e}", file=sys.stderr)

        # Call original hook for traceback
        original_hook(exc_type, exc_value, exc_tb)

    sys.excepthook = friendly_hook


def setup_uvicorn_logging(output_file: Optional[str] = None):
    """Setup uvicorn logging with friendly exceptions"""
    # Add handler to uvicorn error logger
    logger = logging.getLogger("uvicorn.error")
    handler = FriendlyExceptionsHandler(output_file)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)


def run():
    """Main entry point for uvicorn wrapper"""
    # Parse our custom args first
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--f_excps', action='store_true', help='Enable friendly exceptions')
    parser.add_argument('-o', '--output', type=str, help='Output file for errors')
    parser.add_argument('--lang', type=str, default='en', help='Language (en, ru, de, etc.)')

    args, remaining = parser.parse_known_args()

    if args.f_excps:
        # Import and setup friendly_exceptions
        import friendly_exceptions
        friendly_exceptions.set_language(args.lang)

        # Setup exception hook
        setup_exception_hook(args.output)

        # Setup uvicorn logging
        setup_uvicorn_logging(args.output)

        if args.output:
            print(f"✅ friendly_exceptions enabled, logging to: {args.output}")
        else:
            print(f"✅ friendly_exceptions enabled")

    # Now run uvicorn with remaining args
    try:
        import uvicorn
        from uvicorn.main import main as uvicorn_main

        # Pass remaining args to uvicorn
        sys.argv = [sys.argv[0]] + remaining
        uvicorn_main()

    except ImportError:
        print("❌ uvicorn not installed. Run: pip install uvicorn")
        sys.exit(1)


if __name__ == "__main__":
    run()
