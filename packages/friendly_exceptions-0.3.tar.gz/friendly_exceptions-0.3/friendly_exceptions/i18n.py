"""
Система интернационализации для Friendly Exceptions
Internationalization system for Friendly Exceptions
"""

import json
import os
from typing import Dict, Any, Optional
from pathlib import Path

# Поддерживаемые языки
SUPPORTED_LANGUAGES = {
    'ru': 'Русский',
    'en': 'English',
    'de': 'Deutsch',
    'fr': 'Français',
    'es': 'Español',
    'it': 'Italiano',
    'pt': 'Português',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어',
    'pl': 'Polski',
    'uk': 'Українська',
    'ar': 'العربية',
    'hi': 'हिन्दी',
    'tr': 'Türkçe',
}

# Флаги для языков
LANGUAGE_FLAGS = {
    'ru': '🇷🇺',
    'en': '🇺🇸',
    'de': '🇩🇪',
    'fr': '🇫🇷',
    'es': '🇪🇸',
    'it': '🇮🇹',
    'pt': '🇧🇷',
    'zh': '🇨🇳',
    'ja': '🇯🇵',
    'ko': '🇰🇷',
    'pl': '🇵🇱',
    'uk': '🇺🇦',
    'ar': '🇸🇦',
    'hi': '🇮🇳',
    'tr': '🇹🇷',
}

class I18n:
    """Класс для управления переводами / Translation management class"""

    _instance = None
    _translations: Dict[str, Dict[str, Any]] = {}
    _current_language: str = 'en'
    _fallback_language: str = 'en'

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_all_translations()
        return cls._instance

    def _load_all_translations(self) -> None:
        """Загружает все доступные переводы / Loads all available translations"""
        locales_dir = Path(__file__).parent / 'locales'

        for lang_code in SUPPORTED_LANGUAGES.keys():
            lang_file = locales_dir / f'{lang_code}.json'
            if lang_file.exists():
                try:
                    with open(lang_file, 'r', encoding='utf-8') as f:
                        self._translations[lang_code] = json.load(f)
                except (json.JSONDecodeError, IOError) as e:
                    print(f"Warning: Could not load translation file for {lang_code}: {e}")
                    self._translations[lang_code] = {}
            else:
                self._translations[lang_code] = {}

    def reload_translations(self) -> None:
        """Перезагружает переводы / Reloads translations"""
        self._translations.clear()
        self._load_all_translations()

    def set_language(self, language: str) -> bool:
        """
        Устанавливает текущий язык / Sets current language

        Args:
            language: Код языка (ru, en, de, etc.)

        Returns:
            True если язык поддерживается, False иначе
        """
        lang = language.lower()
        if lang in SUPPORTED_LANGUAGES:
            self._current_language = lang
            return True
        return False

    def get_language(self) -> str:
        """Возвращает текущий язык / Returns current language"""
        return self._current_language

    def get_supported_languages(self) -> Dict[str, str]:
        """Возвращает словарь поддерживаемых языков / Returns dict of supported languages"""
        return SUPPORTED_LANGUAGES.copy()

    def t(self, key: str, **kwargs) -> str:
        """
        Получает перевод по ключу / Gets translation by key

        Args:
            key: Ключ перевода в формате "section.subsection.key"
            **kwargs: Параметры для форматирования строки

        Returns:
            Переведенная строка или ключ, если перевод не найден
        """
        # Пробуем получить перевод для текущего языка
        translation = self._get_nested_value(self._translations.get(self._current_language, {}), key)

        # Если не найден, пробуем fallback язык
        if translation is None:
            translation = self._get_nested_value(self._translations.get(self._fallback_language, {}), key)

        # Если всё ещё не найден, возвращаем ключ
        if translation is None:
            return key

        # Форматируем строку с параметрами
        if kwargs:
            try:
                return translation.format(**kwargs)
            except KeyError:
                return translation

        return translation

    def _get_nested_value(self, data: Dict, key: str) -> Optional[str]:
        """
        Получает значение по вложенному ключу / Gets value by nested key

        Args:
            data: Словарь с данными
            key: Ключ в формате "a.b.c"

        Returns:
            Значение или None
        """
        keys = key.split('.')
        value = data

        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return None

        return value if isinstance(value, str) else None

    def get_flag(self, language: str = None) -> str:
        """Возвращает флаг для языка / Returns flag for language"""
        lang = language or self._current_language
        return LANGUAGE_FLAGS.get(lang, '🌐')


# Глобальный экземпляр / Global instance
_i18n = None

def get_i18n() -> I18n:
    """Возвращает глобальный экземпляр I18n / Returns global I18n instance"""
    global _i18n
    if _i18n is None:
        _i18n = I18n()
    return _i18n

def t(key: str, **kwargs) -> str:
    """Сокращенная функция для перевода / Shortcut function for translation"""
    return get_i18n().t(key, **kwargs)

def set_language(language: str) -> bool:
    """Устанавливает язык / Sets language"""
    return get_i18n().set_language(language)

def get_language() -> str:
    """Возвращает текущий язык / Returns current language"""
    return get_i18n().get_language()

def get_supported_languages() -> Dict[str, str]:
    """Возвращает поддерживаемые языки / Returns supported languages"""
    return get_i18n().get_supported_languages()

def get_flag(language: str = None) -> str:
    """Возвращает флаг языка / Returns language flag"""
    return get_i18n().get_flag(language)
