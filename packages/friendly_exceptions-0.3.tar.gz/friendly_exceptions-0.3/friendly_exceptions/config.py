"""
Configuration system for friendly_exceptions
Supports: exceptions.yaml, .friendly_exceptions.json, environment variables
"""

import os
import json
from typing import Dict, Any, Optional
from pathlib import Path


def _load_yaml(filepath: Path) -> dict:
    """Load YAML file (with fallback if PyYAML not installed)"""
    try:
        import yaml
        with open(filepath, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        # PyYAML not installed - try simple parsing
        result = {}
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip()
                        value = value.strip()
                        # Parse basic types
                        if value.lower() in ('true', 'yes', 'on'):
                            result[key] = True
                        elif value.lower() in ('false', 'no', 'off'):
                            result[key] = False
                        elif value.isdigit():
                            result[key] = int(value)
                        elif value.startswith('"') and value.endswith('"'):
                            result[key] = value[1:-1]
                        elif value.startswith("'") and value.endswith("'"):
                            result[key] = value[1:-1]
                        else:
                            result[key] = value
        except:
            pass
        return result


class Config:
    """Configuration management class"""

    # Default values
    DEFAULTS = {
        "language": "en",
        "show_original_traceback": True,
        "show_suggestions": True,
        "max_suggestions": 5,
        "verbose": False,  # Minimal output by default
        "show_code": True,  # Show source code line
        "show_location": True,  # Show file:line
        "group_by_file": True,  # Group errors by file
        "enable_colors": True,
        "log_level": "WARNING",
        "log_file": None,
    }

    def __init__(self):
        self._config = self.DEFAULTS.copy()
        self._config_file = self._find_config_file()
        self._load_config()

    def _find_config_file(self) -> Optional[Path]:
        """Finds config file in current or parent directories"""
        # Check files in order of priority
        config_names = [
            "exceptions.yaml",
            "exceptions.yml",
            ".friendly_exceptions.yaml",
            ".friendly_exceptions.json",
        ]

        # Search from cwd up to root
        current = Path.cwd()
        while current != current.parent:
            for name in config_names:
                config_path = current / name
                if config_path.exists():
                    return config_path
            current = current.parent

        # Check home directory
        for name in config_names:
            home_path = Path.home() / name
            if home_path.exists():
                return home_path

        return None

    def _load_config(self):
        """Loads config from file"""
        if self._config_file and self._config_file.exists():
            try:
                if self._config_file.suffix in ('.yaml', '.yml'):
                    file_config = _load_yaml(self._config_file)
                else:
                    with open(self._config_file, 'r', encoding='utf-8') as f:
                        file_config = json.load(f)
                self._config.update(file_config)
            except Exception:
                pass

        # Override with environment variables
        self._load_from_env()

    def _load_from_env(self):
        """Loads settings from environment variables"""
        env_mapping = {
            "FRIENDLY_EXCEPTIONS_LANGUAGE": "language",
            "FRIENDLY_EXCEPTIONS_SHOW_TRACEBACK": "show_original_traceback",
            "FRIENDLY_EXCEPTIONS_SHOW_SUGGESTIONS": "show_suggestions",
            "FRIENDLY_EXCEPTIONS_VERBOSE": "verbose",
            "FRIENDLY_EXCEPTIONS_LOG_LEVEL": "log_level",
        }

        for env_var, config_key in env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                if config_key in ["show_original_traceback", "show_suggestions", "verbose", "show_code", "show_location"]:
                    self._config[config_key] = value.lower() in ("true", "1", "yes", "on")
                elif config_key == "max_suggestions":
                    try:
                        self._config[config_key] = int(value)
                    except ValueError:
                        pass
                else:
                    self._config[config_key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Gets config value"""
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        """Sets config value"""
        self._config[key] = value

    def save(self, filepath: str = None):
        """Saves config to file"""
        save_path = Path(filepath) if filepath else (self._config_file or Path.cwd() / "exceptions.yaml")
        try:
            if save_path.suffix in ('.yaml', '.yml'):
                try:
                    import yaml
                    with open(save_path, 'w', encoding='utf-8') as f:
                        yaml.dump(self._config, f, default_flow_style=False, allow_unicode=True)
                except ImportError:
                    # Fallback: simple YAML-like format
                    with open(save_path, 'w', encoding='utf-8') as f:
                        for key, value in self._config.items():
                            if isinstance(value, bool):
                                f.write(f"{key}: {str(value).lower()}\n")
                            elif value is None:
                                f.write(f"{key}: null\n")
                            else:
                                f.write(f"{key}: {value}\n")
            else:
                with open(save_path, 'w', encoding='utf-8') as f:
                    json.dump(self._config, f, indent=2, ensure_ascii=False)
        except IOError:
            pass

    def reset(self):
        """Resets config to defaults"""
        self._config = self.DEFAULTS.copy()

    def to_dict(self) -> Dict[str, Any]:
        """Returns config as dictionary"""
        return self._config.copy()

    def update(self, config_dict: Dict[str, Any]):
        """Updates config from dictionary"""
        self._config.update(config_dict)

    def reload(self):
        """Reloads config from file"""
        self._config = self.DEFAULTS.copy()
        self._config_file = self._find_config_file()
        self._load_config()


# Global config instance
_config = None


def get_config() -> Config:
    """Gets global config"""
    global _config
    if _config is None:
        _config = Config()
    return _config


def set_config(key: str, value: Any):
    """Sets config value"""
    get_config().set(key, value)


def get_config_value(key: str, default: Any = None) -> Any:
    """Gets config value"""
    return get_config().get(key, default)


def save_config(filepath: str = None):
    """Saves config"""
    get_config().save(filepath)


def reset_config():
    """Resets config"""
    get_config().reset()


def reload_config():
    """Reloads config from file"""
    get_config().reload()
