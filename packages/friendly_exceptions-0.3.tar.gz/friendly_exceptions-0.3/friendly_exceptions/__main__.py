"""Позволяет запускать: python -m friendly_exceptions"""
from .cli import main
main()
