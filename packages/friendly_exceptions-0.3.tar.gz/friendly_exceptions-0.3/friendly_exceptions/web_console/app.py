"""
Web Console FastAPI Application with Supabase Auth
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

try:
    from fastapi import FastAPI, HTTPException, Request, Query, Depends, Cookie
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, RedirectResponse
    from pydantic import BaseModel
except ImportError:
    raise ImportError("FastAPI not installed. Run: pip install fastapi uvicorn")

from ..storage import ErrorStorage, get_global_storage, StoredError
from ..notifications import NotificationManager, get_global_manager
from ..git_blame import get_blame_info, format_blame_short

# Auth imports
try:
    from .auth import SupabaseAuth, run_auth_server, UserSession, SUPABASE_URL, SUPABASE_ANON_KEY
    from .supabase_storage import SupabaseStorage, get_cloud_storage
except ImportError:
    SupabaseAuth = None
    SUPABASE_URL = None
    SUPABASE_ANON_KEY = None
    SupabaseStorage = None


# Pydantic models
class NotificationConfig(BaseModel):
    slack: Optional[Dict[str, Any]] = None
    telegram: Optional[Dict[str, Any]] = None
    discord: Optional[Dict[str, Any]] = None
    email: Optional[Dict[str, Any]] = None


class LoginRequest(BaseModel):
    email: str
    password: str


class SignUpRequest(BaseModel):
    email: str
    password: str


class ResetPasswordRequest(BaseModel):
    email: str


class ResolveRequest(BaseModel):
    notes: str = ""


class TestNotificationRequest(BaseModel):
    channel: str
    message: str = "Test notification from Friendly Exceptions"


# Config file path
CONFIG_FILE = Path.home() / ".friendly_exceptions" / "config.json"


def load_config() -> dict:
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}


def save_config(config: dict):
    """Save configuration to file"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def create_app(
    db_path: str = "friendly_exceptions.db",
    config_path: str = None,
    require_auth: bool = False
) -> FastAPI:
    """Create FastAPI application"""

    app = FastAPI(
        title="Friendly Exceptions Console",
        description="Web console for error monitoring and configuration",
        version="0.2.0"
    )

    # Initialize storage
    storage = ErrorStorage(db_path)

    # Initialize notifications
    config = load_config()
    notifications = NotificationManager()
    if 'notifications' in config:
        notifications = NotificationManager.from_dict(config['notifications'])

    # Initialize auth with hardcoded credentials
    auth: Optional[SupabaseAuth] = None
    if SupabaseAuth:
        auth = SupabaseAuth()  # Uses hardcoded SUPABASE_URL and SUPABASE_ANON_KEY

    def get_current_user() -> Optional[UserSession]:
        """Get current user session"""
        if not auth:
            return None
        session = auth.get_local_session()
        print(f"get_current_user: session={session.email if session else None}")
        return session

    def get_cloud_storage_for_user() -> Optional[SupabaseStorage]:
        """Get cloud storage for current user"""
        session = get_current_user()
        if session and SupabaseStorage:
            return SupabaseStorage(session)
        return None

    def require_user():
        """Dependency to require authentication"""
        if not require_auth:
            return None
        user = get_current_user()
        if not user:
            raise HTTPException(status_code=401, detail="Not authenticated")
        return user

    # Static files
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # ==================== Auth Endpoints ====================

    @app.get("/login", response_class=HTMLResponse)
    async def login_page():
        """Login page"""
        return HTMLResponse(get_login_html())

    @app.post("/api/auth/login")
    async def api_login(req: LoginRequest):
        """Login with email/password"""
        print(f"Login attempt: email='{req.email}' password_len={len(req.password) if req.password else 0}")
        if not auth:
            raise HTTPException(status_code=400, detail="Auth not configured")
        if not req.email or not req.password:
            raise HTTPException(status_code=400, detail="Email and password required")
        session = auth.sign_in(req.email, req.password)
        if session:
            return {"status": "ok", "email": session.email}
        raise HTTPException(status_code=401, detail="Invalid credentials")

    @app.post("/api/auth/signup")
    async def api_signup(req: SignUpRequest):
        """Sign up with email/password"""
        if not auth:
            raise HTTPException(status_code=400, detail="Auth not configured")
        result = auth.sign_up(req.email, req.password)
        if "error" in result:
            error = result["error"]
            # Handle different error formats from Supabase
            if isinstance(error, dict):
                msg = error.get("message") or error.get("msg") or str(error)
            else:
                msg = str(error)
            raise HTTPException(status_code=400, detail=msg)
        # Check if user was created (Supabase returns user object on success)
        if result.get("id") or result.get("user"):
            return {"status": "ok", "message": "Check email for confirmation"}
        return {"status": "ok", "message": "Registration submitted"}

    @app.post("/api/auth/reset-password")
    async def api_reset_password(req: ResetPasswordRequest):
        """Request password reset"""
        if not auth:
            raise HTTPException(status_code=400, detail="Auth not configured")
        if auth.reset_password(req.email):
            return {"status": "ok", "message": "Reset email sent"}
        raise HTTPException(status_code=400, detail="Failed to send reset email")

    @app.get("/api/auth/logout")
    async def api_logout():
        """Logout"""
        if auth:
            auth.logout()
        return {"status": "ok"}

    @app.get("/api/auth/me")
    async def api_me():
        """Get current user"""
        user = get_current_user()
        if user:
            return {"email": user.email, "user_id": user.user_id}
        return {"email": None}

    @app.get("/api/auth/providers")
    async def api_providers():
        """Get OAuth provider URLs"""
        if not auth:
            return {"providers": {}}
        return {
            "providers": {
                "google": auth.get_login_url("google"),
                "github": auth.get_login_url("github"),
            }
        }

    # ==================== Pages ====================

    @app.get("/", response_class=HTMLResponse)
    async def index():
        """Main dashboard page"""
        # Check auth if required
        if require_auth and auth:
            user = get_current_user()
            if not user:
                return RedirectResponse("/login")

        html_file = static_dir / "index.html"
        if html_file.exists():
            return FileResponse(html_file)
        return HTMLResponse(get_embedded_html())

    # ==================== Errors API ====================

    @app.get("/api/errors")
    async def get_errors(
        limit: int = Query(100, ge=1, le=1000),
        offset: int = Query(0, ge=0),
        include_resolved: bool = Query(False)
    ):
        """Get list of errors"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            # Use cloud storage
            errors = cloud.get_errors(limit=limit, include_resolved=include_resolved)
            return {
                "errors": [
                    {
                        "id": e.get("id"),
                        "timestamp": e.get("first_seen"),
                        "error_type": e.get("error_type"),
                        "error_message": (e.get("error_message") or "")[:200],
                        "filename": e.get("filename"),
                        "lineno": e.get("lineno"),
                        "function": e.get("function_name"),
                        "count": e.get("count", 1),
                        "first_seen": e.get("first_seen"),
                        "last_seen": e.get("last_seen"),
                        "resolved": e.get("resolved", False)
                    }
                    for e in errors
                ],
                "total": len(errors),
                "storage": "cloud"
            }
        else:
            # Fallback to local storage
            errors = storage.get_recent(limit=limit, offset=offset, include_resolved=include_resolved)
            return {
                "errors": [
                    {
                        "id": e.id,
                        "timestamp": e.timestamp,
                        "error_type": e.error_type,
                        "error_message": e.error_message[:200],
                        "filename": e.filename,
                        "lineno": e.lineno,
                        "function": e.function,
                        "count": e.count,
                        "first_seen": e.first_seen,
                        "last_seen": e.last_seen,
                        "resolved": e.resolved
                    }
                    for e in errors
                ],
                "total": len(errors),
                "storage": "local"
            }

    @app.get("/api/errors/{error_id}")
    async def get_error(error_id: int):
        """Get single error details"""
        cloud = get_cloud_storage_for_user()

        if cloud:
            error = cloud.get_error(error_id)
            if not error:
                raise HTTPException(status_code=404, detail="Error not found")

            # Get git blame
            blame_info = None
            filename = error.get("filename")
            lineno = error.get("lineno")
            if filename and lineno:
                blame = get_blame_info(filename, lineno)
                if blame:
                    blame_info = {
                        "author": blame.author,
                        "date": blame.date.isoformat(),
                        "commit": blame.commit_short,
                        "message": blame.commit_message
                    }

            return {
                "id": error.get("id"),
                "timestamp": error.get("first_seen"),
                "error_type": error.get("error_type"),
                "error_message": error.get("error_message"),
                "filename": filename,
                "lineno": lineno,
                "function": error.get("function_name"),
                "traceback": error.get("traceback"),
                "count": error.get("count", 1),
                "first_seen": error.get("first_seen"),
                "last_seen": error.get("last_seen"),
                "resolved": error.get("resolved", False),
                "notes": error.get("notes", ""),
                "blame": blame_info,
                "storage": "cloud"
            }
        else:
            error = storage.get_by_id(error_id)
            if not error:
                raise HTTPException(status_code=404, detail="Error not found")

            # Get git blame
            blame_info = None
            if error.filename and error.lineno:
                blame = get_blame_info(error.filename, error.lineno)
                if blame:
                    blame_info = {
                        "author": blame.author,
                        "date": blame.date.isoformat(),
                        "commit": blame.commit_short,
                        "message": blame.commit_message
                    }

            return {
                "id": error.id,
                "timestamp": error.timestamp,
                "error_type": error.error_type,
                "error_message": error.error_message,
                "filename": error.filename,
                "lineno": error.lineno,
                "function": error.function,
                "traceback": error.traceback,
                "count": error.count,
                "first_seen": error.first_seen,
                "last_seen": error.last_seen,
                "resolved": error.resolved,
                "notes": error.notes,
                "blame": blame_info,
                "storage": "local"
            }

    @app.post("/api/errors/{error_id}/resolve")
    async def resolve_error(error_id: int, req: ResolveRequest):
        """Mark error as resolved"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            cloud.resolve_error(error_id, req.notes)
        else:
            storage.resolve(error_id, req.notes)
        return {"status": "ok"}

    @app.post("/api/errors/{error_id}/unresolve")
    async def unresolve_error(error_id: int):
        """Mark error as unresolved"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            cloud.unresolve_error(error_id)
        else:
            storage.unresolve(error_id)
        return {"status": "ok"}

    @app.delete("/api/errors/{error_id}")
    async def delete_error(error_id: int):
        """Delete error"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            cloud.delete_error(error_id)
        else:
            storage.delete(error_id)
        return {"status": "ok"}

    @app.post("/api/errors/clear-old")
    async def clear_old_errors(days: int = Query(30, ge=1, le=365)):
        """Clear errors older than N days"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            count = cloud.clear_old_errors(days=days)
        else:
            count = storage.clear_old(days=days)
        return {"status": "ok", "deleted": count}

    @app.get("/api/errors/search")
    async def search_errors(q: str = Query(..., min_length=1)):
        """Search errors"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            errors = cloud.search_errors(q)
            return {
                "errors": [
                    {
                        "id": e.get("id"),
                        "error_type": e.get("error_type"),
                        "error_message": (e.get("error_message") or "")[:200],
                        "filename": e.get("filename"),
                        "count": e.get("count", 1),
                        "last_seen": e.get("last_seen")
                    }
                    for e in errors
                ]
            }
        else:
            errors = storage.search(q)
            return {
                "errors": [
                    {
                        "id": e.id,
                        "error_type": e.error_type,
                        "error_message": e.error_message[:200],
                        "filename": e.filename,
                        "count": e.count,
                        "last_seen": e.last_seen
                    }
                    for e in errors
                ]
            }

    # ==================== Stats API ====================

    @app.get("/api/stats")
    async def get_stats(days: int = Query(7, ge=1, le=365)):
        """Get error statistics"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            return cloud.get_stats(days=days)
        return storage.get_stats(days=days)

    @app.get("/api/stats/top")
    async def get_top_errors(limit: int = Query(10, ge=1, le=100), days: int = Query(7)):
        """Get top errors"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            return {"errors": cloud.get_top_errors(limit=limit, days=days)}
        return {"errors": storage.get_top_errors(limit=limit, days=days)}

    @app.get("/api/stats/timeline")
    async def get_timeline(hours: int = Query(24, ge=1, le=168)):
        """Get error timeline"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            return {"timeline": cloud.get_timeline(hours=hours)}
        return {"timeline": storage.get_timeline(hours=hours)}

    # ==================== Export API ====================

    @app.get("/api/export/json")
    async def export_json():
        """Export errors as JSON"""
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            storage.export_json(f.name)
            return FileResponse(
                f.name,
                media_type="application/json",
                filename=f"errors_{datetime.now().strftime('%Y%m%d')}.json"
            )

    @app.get("/api/export/csv")
    async def export_csv():
        """Export errors as CSV"""
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            storage.export_csv(f.name)
            return FileResponse(
                f.name,
                media_type="text/csv",
                filename=f"errors_{datetime.now().strftime('%Y%m%d')}.csv"
            )

    # ==================== Notifications API ====================

    @app.get("/api/notifications/config")
    async def get_notifications_config():
        """Get notifications configuration"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            settings = cloud.get_settings()
            return settings.get("notifications", {})
        return notifications.to_dict()

    @app.post("/api/notifications/config")
    async def save_notifications_config(config: NotificationConfig):
        """Save notifications configuration"""
        nonlocal notifications

        config_dict = config.dict(exclude_none=True)
        notifications = NotificationManager.from_dict(config_dict)

        cloud = get_cloud_storage_for_user()
        if cloud:
            # Save to cloud
            settings = cloud.get_settings()
            settings["notifications"] = config_dict
            cloud.save_settings(settings)
        else:
            # Save to file
            full_config = load_config()
            full_config['notifications'] = config_dict
            save_config(full_config)

        return {"status": "ok"}

    @app.post("/api/notifications/test")
    async def test_notification(req: TestNotificationRequest):
        """Send test notification"""
        try:
            notifications.send(
                message=req.message,
                title="Test Notification",
                level="info",
                async_send=False
            )
            return {"status": "ok"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    # ==================== Settings API ====================

    @app.get("/api/settings")
    async def get_settings():
        """Get all settings"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            cloud_settings = cloud.get_settings()
            return {
                "db_path": db_path,
                "notifications": cloud_settings.get("notifications", {}),
                "features": cloud_settings.get("features", {}),
                "storage": "cloud"
            }
        config = load_config()
        return {
            "db_path": db_path,
            "notifications": notifications.to_dict(),
            "features": config.get('features', {}),
            "storage": "local"
        }

    @app.post("/api/settings")
    async def save_settings(settings: dict):
        """Save settings"""
        cloud = get_cloud_storage_for_user()
        if cloud:
            # Get existing and merge
            existing = cloud.get_settings()
            existing.update(settings)
            cloud.save_settings(existing)
        else:
            config = load_config()
            config.update(settings)
            save_config(config)
        return {"status": "ok"}

    # ==================== Health ====================

    @app.get("/api/health")
    async def health():
        """Health check"""
        return {
            "status": "ok",
            "timestamp": datetime.now().isoformat(),
            "version": "0.2.0"
        }

    return app


def get_embedded_html() -> str:
    """Return embedded HTML if static files not available"""
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Friendly Exceptions Console</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #1a1a2e; color: #eee; }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        header { display: flex; justify-content: space-between; align-items: center; padding: 20px 0; border-bottom: 1px solid #333; }
        h1 { color: #f85149; }
        nav { display: flex; align-items: center; gap: 20px; }
        nav a { color: #58a6ff; text-decoration: none; }
        #user-info { margin-left: 20px; padding-left: 20px; border-left: 1px solid #333; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .stat-card { background: #16213e; padding: 20px; border-radius: 10px; text-align: center; }
        .stat-value { font-size: 2.5em; color: #f85149; }
        .stat-label { color: #888; margin-top: 5px; }
        .errors-list { background: #16213e; border-radius: 10px; overflow: hidden; }
        .error-item { padding: 15px 20px; border-bottom: 1px solid #333; cursor: pointer; }
        .error-item:hover { background: #1f3460; }
        .error-type { color: #f85149; font-weight: bold; }
        .error-msg { color: #ccc; font-size: 0.9em; margin-top: 5px; }
        .error-meta { color: #666; font-size: 0.8em; margin-top: 5px; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 0.75em; }
        .badge-count { background: #f85149; color: white; }
        .badge-resolved { background: #238636; color: white; }
        .tabs { display: flex; gap: 10px; margin: 20px 0; }
        .tab { padding: 10px 20px; background: #16213e; border: none; color: #888; cursor: pointer; border-radius: 5px; }
        .tab.active { background: #f85149; color: white; }
        .modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 100; }
        .modal-content { background: #16213e; max-width: 800px; margin: 50px auto; padding: 30px; border-radius: 10px; max-height: 80vh; overflow-y: auto; }
        .modal-close { float: right; font-size: 1.5em; cursor: pointer; color: #888; }
        pre { background: #0d1117; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 0.85em; }
        input, select { background: #0d1117; border: 1px solid #333; color: white; padding: 10px; border-radius: 5px; width: 100%; }
        input[type="checkbox"] { width: auto; margin-right: 8px; }
        button { background: #f85149; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin: 5px 5px 5px 0; }
        button:hover { background: #da3633; }
        .btn-primary { background: #238636; }
        .btn-primary:hover { background: #2ea043; }
        .btn-danger { background: #da3633; }
        .btn-danger:hover { background: #b62324; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #888; }
        .settings-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .settings-section { background: #16213e; padding: 20px; border-radius: 10px; }
        .settings-section h2 { color: #58a6ff; margin-bottom: 15px; font-size: 1.2em; }
        .settings-actions { margin: 20px 0; text-align: center; }
        .settings-actions button { padding: 15px 40px; font-size: 1.1em; }
        .export-buttons { display: flex; gap: 10px; }
        .chart { height: 200px; background: #0d1117; border-radius: 10px; margin: 20px 0; display: flex; align-items: flex-end; padding: 20px; gap: 5px; }
        .bar { background: #f85149; min-width: 20px; border-radius: 3px 3px 0 0; transition: height 0.3s; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #238636; color: white; padding: 15px 25px; border-radius: 8px; z-index: 1000; animation: slideIn 0.3s; }
        .toast.error { background: #da3633; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Friendly Exceptions</h1>
            <nav>
                <a href="#" onclick="showTab('dashboard')">Dashboard</a>
                <a href="#" onclick="showTab('errors')">Errors</a>
                <a href="#" onclick="showTab('settings')">Settings</a>
                <span id="user-info"></span>
            </nav>
        </header>

        <div id="dashboard" class="tab-content">
            <div class="stats" id="stats-cards"></div>
            <h2>Error Timeline (24h)</h2>
            <div class="chart" id="timeline-chart"></div>
            <h2>Top Errors</h2>
            <div class="errors-list" id="top-errors"></div>
        </div>

        <div id="errors" class="tab-content" style="display:none;">
            <div class="tabs">
                <button class="tab active" onclick="loadErrors(false)">Unresolved</button>
                <button class="tab" onclick="loadErrors(true)">All</button>
            </div>
            <div class="errors-list" id="errors-list"></div>
        </div>

        <div id="settings" class="tab-content" style="display:none;">
            <div class="settings-grid">
                <div class="settings-section">
                    <h2>Slack</h2>
                    <div class="form-group">
                        <label>Webhook URL</label>
                        <input type="text" id="slack-webhook" placeholder="https://hooks.slack.com/services/...">
                    </div>
                    <div class="form-group">
                        <label>Channel (optional)</label>
                        <input type="text" id="slack-channel" placeholder="#errors">
                    </div>
                    <div class="form-group">
                        <label>Username (optional)</label>
                        <input type="text" id="slack-username" placeholder="ErrorBot">
                    </div>
                    <button onclick="testChannel('slack')">Test Slack</button>
                </div>

                <div class="settings-section">
                    <h2>Telegram</h2>
                    <div class="form-group">
                        <label>Bot Token</label>
                        <input type="text" id="telegram-token" placeholder="123456:ABC-DEF...">
                    </div>
                    <div class="form-group">
                        <label>Chat ID</label>
                        <input type="text" id="telegram-chat" placeholder="-100123456789">
                    </div>
                    <div class="form-group">
                        <label>Parse Mode</label>
                        <select id="telegram-parse-mode">
                            <option value="HTML">HTML</option>
                            <option value="Markdown">Markdown</option>
                        </select>
                    </div>
                    <button onclick="testChannel('telegram')">Test Telegram</button>
                </div>

                <div class="settings-section">
                    <h2>Discord</h2>
                    <div class="form-group">
                        <label>Webhook URL</label>
                        <input type="text" id="discord-webhook" placeholder="https://discord.com/api/webhooks/...">
                    </div>
                    <div class="form-group">
                        <label>Username (optional)</label>
                        <input type="text" id="discord-username" placeholder="ErrorBot">
                    </div>
                    <div class="form-group">
                        <label>Avatar URL (optional)</label>
                        <input type="text" id="discord-avatar" placeholder="https://...">
                    </div>
                    <button onclick="testChannel('discord')">Test Discord</button>
                </div>

                <div class="settings-section">
                    <h2>Email (SMTP)</h2>
                    <div class="form-group">
                        <label>SMTP Host</label>
                        <input type="text" id="email-host" placeholder="smtp.gmail.com">
                    </div>
                    <div class="form-group">
                        <label>SMTP Port</label>
                        <input type="number" id="email-port" placeholder="587" value="587">
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" id="email-username" placeholder="your@email.com">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="email-password" placeholder="App password">
                    </div>
                    <div class="form-group">
                        <label>From Address</label>
                        <input type="text" id="email-from" placeholder="errors@yourapp.com">
                    </div>
                    <div class="form-group">
                        <label>To Addresses (comma-separated)</label>
                        <input type="text" id="email-to" placeholder="dev@company.com, team@company.com">
                    </div>
                    <button onclick="testChannel('email')">Test Email</button>
                </div>
            </div>

            <div class="settings-actions">
                <button onclick="saveAllSettings()" class="btn-primary">Save All Settings</button>
            </div>

            <div class="settings-section" style="margin-top: 30px;">
                <h2>General Settings</h2>
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="setting-rate-limit" checked>
                        Enable rate limiting (1 notification per error per 5 min)
                    </label>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="setting-include-traceback" checked>
                        Include traceback in notifications
                    </label>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="setting-git-blame">
                        Include git blame info
                    </label>
                </div>
                <div class="form-group">
                    <label>Min severity level</label>
                    <select id="setting-min-level">
                        <option value="debug">Debug (all)</option>
                        <option value="info">Info</option>
                        <option value="warning" selected>Warning</option>
                        <option value="error">Error</option>
                        <option value="critical">Critical only</option>
                    </select>
                </div>
            </div>

            <div class="settings-section" style="margin-top: 30px;">
                <h2>Export Data</h2>
                <div class="export-buttons">
                    <button onclick="location.href='/api/export/json'">Export JSON</button>
                    <button onclick="location.href='/api/export/csv'">Export CSV</button>
                </div>
            </div>

            <div class="settings-section" style="margin-top: 30px;">
                <h2>Danger Zone</h2>
                <button onclick="clearOldErrors()" class="btn-danger">Clear errors older than 30 days</button>
            </div>
        </div>
    </div>

    <div class="modal" id="error-modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal()">&times;</span>
            <div id="error-details"></div>
        </div>
    </div>

    <script>
        async function api(path) {
            const res = await fetch('/api' + path);
            return res.json();
        }

        function showTab(name) {
            document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
            document.getElementById(name).style.display = 'block';
            if (name === 'dashboard') loadDashboard();
            if (name === 'errors') loadErrors();
            if (name === 'settings') loadSettings();
        }

        async function loadDashboard() {
            const stats = await api('/stats');
            document.getElementById('stats-cards').innerHTML = `
                <div class="stat-card"><div class="stat-value">${stats.total_errors}</div><div class="stat-label">Total Errors</div></div>
                <div class="stat-card"><div class="stat-value">${stats.unresolved}</div><div class="stat-label">Unresolved</div></div>
                <div class="stat-card"><div class="stat-value">${stats.recent_occurrences}</div><div class="stat-label">Last 7 Days</div></div>
            `;

            const timeline = await api('/stats/timeline');
            const maxCount = Math.max(...timeline.timeline.map(t => t.count), 1);
            document.getElementById('timeline-chart').innerHTML = timeline.timeline.map(t =>
                `<div class="bar" style="height: ${(t.count/maxCount)*100}%" title="${t.hour}: ${t.count}"></div>`
            ).join('');

            const top = await api('/stats/top');
            document.getElementById('top-errors').innerHTML = top.errors.map(e => `
                <div class="error-item">
                    <span class="error-type">${e.error_type}</span>
                    <span class="badge badge-count">${e.occurrence_count}x</span>
                    <div class="error-msg">${e.error_message?.substring(0,100) || ''}</div>
                    <div class="error-meta">${e.filename}:${e.lineno}</div>
                </div>
            `).join('');
        }

        async function loadErrors(includeResolved = false) {
            const data = await api('/errors?include_resolved=' + includeResolved);
            document.getElementById('errors-list').innerHTML = data.errors.map(e => `
                <div class="error-item" onclick="showError(${e.id})">
                    <span class="error-type">${e.error_type}</span>
                    <span class="badge badge-count">${e.count}x</span>
                    ${e.resolved ? '<span class="badge badge-resolved">Resolved</span>' : ''}
                    <div class="error-msg">${e.error_message}</div>
                    <div class="error-meta">${e.filename}:${e.lineno} in ${e.function}() - ${e.last_seen}</div>
                </div>
            `).join('');
        }

        async function showError(id) {
            const e = await api('/errors/' + id);
            document.getElementById('error-details').innerHTML = `
                <h2>${e.error_type}</h2>
                <p>${e.error_message}</p>
                <p><strong>File:</strong> ${e.filename}:${e.lineno}</p>
                <p><strong>Function:</strong> ${e.function}()</p>
                <p><strong>Count:</strong> ${e.count} occurrences</p>
                <p><strong>First seen:</strong> ${e.first_seen}</p>
                <p><strong>Last seen:</strong> ${e.last_seen}</p>
                ${e.blame ? `<p><strong>Author:</strong> ${e.blame.author} (${e.blame.date})</p>` : ''}
                <h3>Traceback</h3>
                <pre>${e.traceback}</pre>
                <button onclick="resolveError(${e.id})">${e.resolved ? 'Unresolve' : 'Resolve'}</button>
                <button onclick="deleteError(${e.id})" style="background:#666">Delete</button>
            `;
            document.getElementById('error-modal').style.display = 'block';
        }

        function closeModal() { document.getElementById('error-modal').style.display = 'none'; }

        async function resolveError(id) {
            await fetch('/api/errors/' + id + '/resolve', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}' });
            closeModal();
            loadErrors();
        }

        async function deleteError(id) {
            if (confirm('Delete this error?')) {
                await fetch('/api/errors/' + id, { method: 'DELETE' });
                closeModal();
                loadErrors();
            }
        }

        async function loadSettings() {
            const config = await api('/notifications/config');
            const settings = await api('/settings');

            // Slack
            if (config.slack) {
                document.getElementById('slack-webhook').value = config.slack.webhook_url || '';
                document.getElementById('slack-channel').value = config.slack.channel || '';
                document.getElementById('slack-username').value = config.slack.username || '';
            }

            // Telegram
            if (config.telegram) {
                document.getElementById('telegram-token').value = config.telegram.bot_token || '';
                document.getElementById('telegram-chat').value = config.telegram.chat_id || '';
                document.getElementById('telegram-parse-mode').value = config.telegram.parse_mode || 'HTML';
            }

            // Discord
            if (config.discord) {
                document.getElementById('discord-webhook').value = config.discord.webhook_url || '';
                document.getElementById('discord-username').value = config.discord.username || '';
                document.getElementById('discord-avatar').value = config.discord.avatar_url || '';
            }

            // Email
            if (config.email) {
                document.getElementById('email-host').value = config.email.smtp_host || '';
                document.getElementById('email-port').value = config.email.smtp_port || 587;
                document.getElementById('email-username').value = config.email.username || '';
                document.getElementById('email-from').value = config.email.from_addr || '';
                document.getElementById('email-to').value = (config.email.to_addrs || []).join(', ');
            }

            // General settings
            if (settings.features) {
                document.getElementById('setting-rate-limit').checked = settings.features.rate_limit !== false;
                document.getElementById('setting-include-traceback').checked = settings.features.include_traceback !== false;
                document.getElementById('setting-git-blame').checked = settings.features.git_blame === true;
                if (settings.features.min_level) {
                    document.getElementById('setting-min-level').value = settings.features.min_level;
                }
            }
        }

        function showToast(message, isError = false) {
            const toast = document.createElement('div');
            toast.className = 'toast' + (isError ? ' error' : '');
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }

        async function saveAllSettings() {
            const config = {};

            // Slack
            const slackWebhook = document.getElementById('slack-webhook').value;
            if (slackWebhook) {
                config.slack = {
                    webhook_url: slackWebhook,
                    channel: document.getElementById('slack-channel').value || null,
                    username: document.getElementById('slack-username').value || null
                };
            }

            // Telegram
            const tgToken = document.getElementById('telegram-token').value;
            const tgChat = document.getElementById('telegram-chat').value;
            if (tgToken && tgChat) {
                config.telegram = {
                    bot_token: tgToken,
                    chat_id: tgChat,
                    parse_mode: document.getElementById('telegram-parse-mode').value
                };
            }

            // Discord
            const discordWebhook = document.getElementById('discord-webhook').value;
            if (discordWebhook) {
                config.discord = {
                    webhook_url: discordWebhook,
                    username: document.getElementById('discord-username').value || null,
                    avatar_url: document.getElementById('discord-avatar').value || null
                };
            }

            // Email
            const emailHost = document.getElementById('email-host').value;
            const emailTo = document.getElementById('email-to').value;
            if (emailHost && emailTo) {
                config.email = {
                    smtp_host: emailHost,
                    smtp_port: parseInt(document.getElementById('email-port').value) || 587,
                    username: document.getElementById('email-username').value,
                    password: document.getElementById('email-password').value || null,
                    from_addr: document.getElementById('email-from').value,
                    to_addrs: emailTo.split(',').map(s => s.trim()).filter(s => s)
                };
            }

            // Save notifications config
            await fetch('/api/notifications/config', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(config)
            });

            // Save general settings
            const features = {
                rate_limit: document.getElementById('setting-rate-limit').checked,
                include_traceback: document.getElementById('setting-include-traceback').checked,
                git_blame: document.getElementById('setting-git-blame').checked,
                min_level: document.getElementById('setting-min-level').value
            };

            await fetch('/api/settings', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ features })
            });

            showToast('Settings saved successfully!');
        }

        async function testChannel(channel) {
            try {
                const res = await fetch('/api/notifications/test', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ channel, message: `Test from Friendly Exceptions (${channel})!` })
                });
                if (res.ok) {
                    showToast(`Test sent to ${channel}!`);
                } else {
                    const data = await res.json();
                    showToast(data.detail || 'Test failed', true);
                }
            } catch (e) {
                showToast('Connection error', true);
            }
        }

        async function clearOldErrors() {
            if (confirm('Delete all errors older than 30 days?')) {
                await fetch('/api/errors/clear-old', { method: 'POST' });
                showToast('Old errors cleared');
                loadDashboard();
            }
        }

        async function loadUser() {
            try {
                const res = await fetch('/api/auth/me');
                const data = await res.json();
                if (data.email) {
                    document.getElementById('user-info').innerHTML = `
                        <span style="color:#888">${data.email}</span>
                        <a href="#" onclick="logout()" style="color:#f85149">Logout</a>
                    `;
                }
            } catch (e) {}
        }

        async function logout() {
            await fetch('/api/auth/logout');
            window.location.href = '/login';
        }

        // Initial load
        loadUser();
        loadDashboard();
    </script>
</body>
</html>"""


def get_login_html() -> str:
    """Return login page HTML"""
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Friendly Exceptions</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #1a1a2e; color: #eee; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-box { background: #16213e; padding: 40px; border-radius: 15px; width: 100%; max-width: 400px; }
        h1 { color: #f85149; margin-bottom: 30px; text-align: center; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; color: #888; }
        input { background: #0d1117; border: 1px solid #333; color: white; padding: 12px 15px; border-radius: 8px; width: 100%; font-size: 16px; }
        input:focus { outline: none; border-color: #f85149; }
        button { background: #f85149; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; width: 100%; font-size: 16px; margin-top: 10px; }
        button:hover { background: #da3633; }
        button.secondary { background: #333; }
        button.secondary:hover { background: #444; }
        .tabs { display: flex; gap: 10px; margin-bottom: 25px; }
        .tab { flex: 1; padding: 10px; background: transparent; border: none; color: #666; cursor: pointer; border-bottom: 2px solid transparent; }
        .tab.active { color: #f85149; border-bottom-color: #f85149; }
        .error { background: #f8514922; color: #f85149; padding: 10px; border-radius: 5px; margin-bottom: 15px; display: none; }
        .success { background: #23863622; color: #238636; padding: 10px; border-radius: 5px; margin-bottom: 15px; display: none; }
        .divider { text-align: center; color: #666; margin: 20px 0; position: relative; }
        .divider::before, .divider::after { content: ''; position: absolute; top: 50%; width: 40%; height: 1px; background: #333; }
        .divider::before { left: 0; }
        .divider::after { right: 0; }
        .oauth-buttons { display: flex; gap: 10px; }
        .oauth-buttons button { flex: 1; }
        a { color: #58a6ff; text-decoration: none; }
        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 14px; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>Friendly Exceptions</h1>

        <div class="tabs">
            <button class="tab active" onclick="showTab('login')">Login</button>
            <button class="tab" onclick="showTab('signup')">Sign Up</button>
            <button class="tab" onclick="showTab('reset')">Reset</button>
        </div>

        <div class="error" id="error"></div>
        <div class="success" id="success"></div>

        <div id="login-form">
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="login-email" placeholder="you@example.com">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="login-password" placeholder="Password">
            </div>
            <button onclick="login()">Login</button>
        </div>

        <div id="signup-form" style="display:none;">
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="signup-email" placeholder="you@example.com">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="signup-password" placeholder="Min 6 characters">
            </div>
            <button onclick="signup()">Create Account</button>
        </div>

        <div id="reset-form" style="display:none;">
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="reset-email" placeholder="you@example.com">
            </div>
            <button onclick="resetPassword()">Send Reset Link</button>
        </div>

        <div class="divider">or</div>

        <div class="oauth-buttons" id="oauth-buttons"></div>

        <div class="footer">
            <a href="/">Back to Console</a>
        </div>
    </div>

    <script>
        function showTab(tab) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelector(`.tab:nth-child(${tab === 'login' ? 1 : tab === 'signup' ? 2 : 3})`).classList.add('active');
            document.getElementById('login-form').style.display = tab === 'login' ? 'block' : 'none';
            document.getElementById('signup-form').style.display = tab === 'signup' ? 'block' : 'none';
            document.getElementById('reset-form').style.display = tab === 'reset' ? 'block' : 'none';
            hideMessages();
        }

        function showError(msg) {
            document.getElementById('error').textContent = msg;
            document.getElementById('error').style.display = 'block';
            document.getElementById('success').style.display = 'none';
        }

        function showSuccess(msg) {
            document.getElementById('success').textContent = msg;
            document.getElementById('success').style.display = 'block';
            document.getElementById('error').style.display = 'none';
        }

        function hideMessages() {
            document.getElementById('error').style.display = 'none';
            document.getElementById('success').style.display = 'none';
        }

        async function login() {
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            try {
                const res = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({email, password})
                });
                const data = await res.json();
                if (res.ok) {
                    window.location.href = '/';
                } else {
                    showError(data.detail || 'Login failed');
                }
            } catch (e) {
                showError('Connection error');
            }
        }

        async function signup() {
            const email = document.getElementById('signup-email').value;
            const password = document.getElementById('signup-password').value;
            try {
                const res = await fetch('/api/auth/signup', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({email, password})
                });
                const data = await res.json();
                if (res.ok) {
                    showSuccess('Check your email for confirmation link!');
                } else {
                    showError(data.detail || 'Signup failed');
                }
            } catch (e) {
                showError('Connection error');
            }
        }

        async function resetPassword() {
            const email = document.getElementById('reset-email').value;
            try {
                const res = await fetch('/api/auth/reset-password', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({email})
                });
                const data = await res.json();
                if (res.ok) {
                    showSuccess('Check your email for reset link!');
                } else {
                    showError(data.detail || 'Reset failed');
                }
            } catch (e) {
                showError('Connection error');
            }
        }

        // Load OAuth providers
        async function loadProviders() {
            try {
                const res = await fetch('/api/auth/providers');
                const data = await res.json();
                const container = document.getElementById('oauth-buttons');
                if (data.providers.google) {
                    container.innerHTML += `<button class="secondary" onclick="location.href='${data.providers.google}'">Google</button>`;
                }
                if (data.providers.github) {
                    container.innerHTML += `<button class="secondary" onclick="location.href='${data.providers.github}'">GitHub</button>`;
                }
            } catch (e) {}
        }
        loadProviders();

        // Enter key to submit
        document.addEventListener('keypress', e => {
            if (e.key === 'Enter') {
                if (document.getElementById('login-form').style.display !== 'none') login();
                else if (document.getElementById('signup-form').style.display !== 'none') signup();
                else resetPassword();
            }
        });
    </script>
</body>
</html>"""


def run_server(
    host: str = "0.0.0.0",
    port: int = 8080,
    db_path: str = "friendly_exceptions.db",
    reload: bool = False,
    require_auth: bool = True
):
    """Run the web console server"""
    try:
        import uvicorn
    except ImportError:
        raise ImportError("uvicorn not installed. Run: pip install uvicorn")

    # Start auth callback server (uses hardcoded Supabase credentials)
    try:
        from .auth import SupabaseAuth, run_auth_server
        auth = SupabaseAuth(main_port=port)  # Uses hardcoded credentials
        run_auth_server(auth, port)
    except Exception as e:
        print(f"   Warning: Auth server failed: {e}")

    app = create_app(
        db_path=db_path,
        require_auth=require_auth
    )

    print(f"\n Friendly Exceptions Console")
    print(f"   Running on http://{host}:{port}")
    print(f"   Database: {db_path}")
    print(f"   Auth: Supabase enabled")
    print(f"   Auth callback: http://localhost:2223")
    print()

    uvicorn.run(app, host=host, port=port, reload=reload)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Friendly Exceptions Web Console")
    parser.add_argument("-p", "--port", type=int, default=8080, help="Port")
    parser.add_argument("-H", "--host", default="0.0.0.0", help="Host")
    parser.add_argument("-d", "--db", default="friendly_exceptions.db", help="Database path")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    args = parser.parse_args()
    run_server(host=args.host, port=args.port, db_path=args.db, reload=args.reload)
