"""
Supabase Cloud Storage for Settings and Errors

Syncs user settings and error data with Supabase database.
"""

import json
import urllib.request
import urllib.error
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict

from .auth import SUPABASE_URL, SUPABASE_ANON_KEY, UserSession


class SupabaseStorage:
    """Cloud storage using Supabase"""

    def __init__(self, session: UserSession = None):
        self.base_url = f"{SUPABASE_URL}/rest/v1"
        self.session = session

    def _headers(self) -> Dict[str, str]:
        """Get headers for Supabase API"""
        headers = {
            "apikey": SUPABASE_ANON_KEY,
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        if self.session:
            headers["Authorization"] = f"Bearer {self.session.access_token}"
        return headers

    def _request(self, method: str, endpoint: str, data: dict = None) -> Optional[Any]:
        """Make request to Supabase REST API"""
        url = f"{self.base_url}/{endpoint}"

        body = None
        if data:
            body = json.dumps(data).encode()

        req = urllib.request.Request(url, data=body, headers=self._headers(), method=method)

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                result = resp.read()
                if result:
                    return json.loads(result)
                return None
        except urllib.error.HTTPError as e:
            try:
                error = json.loads(e.read())
                print(f"Supabase error: {error}")
            except:
                print(f"Supabase error: {e}")
            return None
        except Exception as e:
            print(f"Supabase request error: {e}")
            return None

    # ==================== Settings ====================

    def get_settings(self) -> Dict[str, Any]:
        """Get user settings from Supabase"""
        if not self.session:
            return {}

        result = self._request(
            "GET",
            f"user_settings?user_id=eq.{self.session.user_id}&select=settings"
        )

        if result and len(result) > 0:
            return result[0].get("settings", {})
        return {}

    def save_settings(self, settings: Dict[str, Any]) -> bool:
        """Save user settings to Supabase"""
        if not self.session:
            return False

        data = {
            "user_id": self.session.user_id,
            "settings": settings,
            "updated_at": datetime.now().isoformat()
        }

        # Try upsert
        result = self._request(
            "POST",
            "user_settings?on_conflict=user_id",
            data
        )

        return result is not None

    # ==================== Errors ====================

    def get_errors(self, limit: int = 100, include_resolved: bool = False) -> List[Dict]:
        """Get errors from Supabase"""
        if not self.session:
            return []

        query = f"errors?user_id=eq.{self.session.user_id}&order=last_seen.desc&limit={limit}"
        if not include_resolved:
            query += "&resolved=eq.false"

        result = self._request("GET", query)
        return result or []

    def get_error(self, error_id: int) -> Optional[Dict]:
        """Get single error by ID"""
        if not self.session:
            return None

        result = self._request(
            "GET",
            f"errors?id=eq.{error_id}&user_id=eq.{self.session.user_id}"
        )

        if result and len(result) > 0:
            return result[0]
        return None

    def store_error(
        self,
        error_type: str,
        error_message: str,
        error_hash: str,
        filename: str = "",
        lineno: int = 0,
        function_name: str = "",
        traceback: str = "",
        extra_data: dict = None
    ) -> Optional[int]:
        """Store or update error in Supabase"""
        if not self.session:
            return None

        now = datetime.now().isoformat()

        # Check if error exists
        existing = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&error_hash=eq.{error_hash}&select=id,count"
        )

        if existing and len(existing) > 0:
            # Update existing
            error_id = existing[0]["id"]
            new_count = existing[0]["count"] + 1

            self._request(
                "PATCH",
                f"errors?id=eq.{error_id}",
                {
                    "count": new_count,
                    "last_seen": now,
                    "error_message": error_message,
                    "traceback": traceback
                }
            )
        else:
            # Insert new
            result = self._request(
                "POST",
                "errors",
                {
                    "user_id": self.session.user_id,
                    "error_type": error_type,
                    "error_message": error_message,
                    "error_hash": error_hash,
                    "filename": filename,
                    "lineno": lineno,
                    "function_name": function_name,
                    "traceback": traceback,
                    "first_seen": now,
                    "last_seen": now,
                    "extra_data": extra_data or {}
                }
            )
            if result and len(result) > 0:
                error_id = result[0]["id"]
            else:
                return None

        # Store occurrence
        self._request(
            "POST",
            "error_occurrences",
            {
                "error_id": error_id,
                "user_id": self.session.user_id,
                "timestamp": now,
                "extra_data": extra_data or {}
            }
        )

        return error_id

    def resolve_error(self, error_id: int, notes: str = "") -> bool:
        """Mark error as resolved"""
        if not self.session:
            return False

        result = self._request(
            "PATCH",
            f"errors?id=eq.{error_id}&user_id=eq.{self.session.user_id}",
            {"resolved": True, "notes": notes}
        )
        return result is not None

    def unresolve_error(self, error_id: int) -> bool:
        """Mark error as unresolved"""
        if not self.session:
            return False

        result = self._request(
            "PATCH",
            f"errors?id=eq.{error_id}&user_id=eq.{self.session.user_id}",
            {"resolved": False}
        )
        return result is not None

    def delete_error(self, error_id: int) -> bool:
        """Delete error"""
        if not self.session:
            return False

        # Delete occurrences first
        self._request(
            "DELETE",
            f"error_occurrences?error_id=eq.{error_id}&user_id=eq.{self.session.user_id}"
        )

        # Delete error
        result = self._request(
            "DELETE",
            f"errors?id=eq.{error_id}&user_id=eq.{self.session.user_id}"
        )
        return True

    def search_errors(self, query: str, limit: int = 50) -> List[Dict]:
        """Search errors"""
        if not self.session:
            return []

        # Search in error_type, error_message, filename
        result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&or=(error_type.ilike.*{query}*,error_message.ilike.*{query}*,filename.ilike.*{query}*)&order=last_seen.desc&limit={limit}"
        )
        return result or []

    # ==================== Stats ====================

    def get_stats(self, days: int = 7) -> Dict[str, Any]:
        """Get error statistics"""
        if not self.session:
            return {}

        # Total errors
        total_result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&select=count"
        )
        total = len(total_result) if total_result else 0

        # Unresolved
        unresolved_result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&resolved=eq.false&select=count"
        )
        unresolved = len(unresolved_result) if unresolved_result else 0

        # By type
        by_type_result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&select=error_type"
        )
        by_type = {}
        if by_type_result:
            for e in by_type_result:
                t = e["error_type"]
                by_type[t] = by_type.get(t, 0) + 1
        by_type_list = [{"error_type": k, "count": v} for k, v in sorted(by_type.items(), key=lambda x: -x[1])][:10]

        # Top files
        top_files_result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&select=filename"
        )
        top_files = {}
        if top_files_result:
            for e in top_files_result:
                f = e.get("filename", "")
                if f:
                    top_files[f] = top_files.get(f, 0) + 1
        top_files_list = [{"filename": k, "count": v} for k, v in sorted(top_files.items(), key=lambda x: -x[1])][:10]

        return {
            "total_errors": total,
            "unresolved": unresolved,
            "recent_occurrences": total,  # Simplified
            "by_type": by_type_list,
            "by_day": [],  # Would need date aggregation
            "top_files": top_files_list,
            "period_days": days
        }

    def get_top_errors(self, limit: int = 10, days: int = 7) -> List[Dict]:
        """Get most frequent errors"""
        if not self.session:
            return []

        result = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&resolved=eq.false&order=count.desc&limit={limit}"
        )

        if result:
            return [
                {
                    "error_type": e["error_type"],
                    "error_message": e.get("error_message", ""),
                    "filename": e.get("filename", ""),
                    "lineno": e.get("lineno", 0),
                    "function": e.get("function_name", ""),
                    "occurrence_count": e.get("count", 1),
                    "last_occurrence": e.get("last_seen", "")
                }
                for e in result
            ]
        return []

    def get_timeline(self, hours: int = 24) -> List[Dict]:
        """Get error timeline"""
        if not self.session:
            return []

        # Get recent occurrences
        result = self._request(
            "GET",
            f"error_occurrences?user_id=eq.{self.session.user_id}&order=timestamp.desc&limit=500"
        )

        if not result:
            return []

        # Aggregate by hour
        timeline = {}
        for occ in result:
            ts = occ.get("timestamp", "")
            if ts:
                hour = ts[:13] + ":00"  # YYYY-MM-DDTHH:00
                timeline[hour] = timeline.get(hour, 0) + 1

        return [{"hour": k, "count": v} for k, v in sorted(timeline.items())][-hours:]

    def clear_old_errors(self, days: int = 30) -> int:
        """Delete errors older than N days"""
        if not self.session:
            return 0

        from datetime import timedelta
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        # Get old error IDs
        old_errors = self._request(
            "GET",
            f"errors?user_id=eq.{self.session.user_id}&last_seen=lt.{cutoff}&select=id"
        )

        if not old_errors:
            return 0

        count = len(old_errors)
        for e in old_errors:
            self.delete_error(e["id"])

        return count


def get_cloud_storage(session: UserSession = None) -> SupabaseStorage:
    """Get cloud storage instance"""
    return SupabaseStorage(session)
