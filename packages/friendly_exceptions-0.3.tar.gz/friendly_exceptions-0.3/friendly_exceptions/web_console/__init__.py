"""
Friendly Exceptions Web Console

Run with:
    python -m friendly_exceptions web-console run -p 8080

Auth is pre-configured with Supabase.
All data syncs to cloud when logged in.
"""

from .app import create_app, run_server
from .auth import SUPABASE_URL, SUPABASE_ANON_KEY, SupabaseAuth
from .supabase_storage import SupabaseStorage, get_cloud_storage

__all__ = [
    'create_app', 'run_server',
    'SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SupabaseAuth',
    'SupabaseStorage', 'get_cloud_storage'
]
