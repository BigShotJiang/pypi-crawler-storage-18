"""
Supabase Authentication for Web Console

Flow:
1. User opens console -> check local session
2. No session -> redirect to Supabase login
3. Supabase redirects to :2223/callback with token
4. Save session locally -> redirect to main console
"""

import os
import json
import sqlite3
import hashlib
import secrets
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from dataclasses import dataclass
import threading

# Hardcoded Supabase credentials
SUPABASE_URL = "https://lgalqfeivdpqihtjkpuh.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxnYWxxZmVpdmRwcWlodGprcHVoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY1MjY2MjcsImV4cCI6MjA4MjEwMjYyN30.lb-uj_hau8cqQuBU_e-LWBFEjkp8lN8IHEPCq75Hc6o"

# Local session database path
AUTH_DB_PATH = Path(__file__).parent / "auth_sessions.db"


@dataclass
class UserSession:
    user_id: str
    email: str
    access_token: str
    refresh_token: str
    expires_at: str
    created_at: str


class SupabaseAuth:
    """Supabase authentication handler"""

    def __init__(
        self,
        supabase_url: str = None,
        supabase_anon_key: str = None,
        redirect_port: int = 2223,
        main_port: int = 8080
    ):
        self.supabase_url = (supabase_url or SUPABASE_URL).rstrip('/')
        self.anon_key = supabase_anon_key or SUPABASE_ANON_KEY
        self.redirect_port = redirect_port
        self.main_port = main_port
        self.redirect_uri = f"http://localhost:{redirect_port}/callback"

        self._init_db()

    def _init_db(self):
        """Initialize local session database"""
        conn = sqlite3.connect(str(AUTH_DB_PATH))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY,
                user_id TEXT UNIQUE,
                email TEXT,
                access_token TEXT,
                refresh_token TEXT,
                expires_at TEXT,
                created_at TEXT
            )
        """)
        conn.commit()
        conn.close()

    def get_login_url(self, provider: str = None) -> str:
        """Get Supabase login URL"""
        if provider:
            # OAuth provider (google, github, etc)
            return f"{self.supabase_url}/auth/v1/authorize?provider={provider}&redirect_to={self.redirect_uri}"
        else:
            # Email login - redirect to Supabase hosted UI
            return f"{self.supabase_url}/auth/v1/authorize?redirect_to={self.redirect_uri}"

    def get_magic_link_url(self) -> str:
        """Get URL for magic link auth page"""
        return f"{self.supabase_url}/auth/v1/magiclink"

    def exchange_code_for_session(self, code: str) -> Optional[UserSession]:
        """Exchange auth code for session tokens"""
        try:
            url = f"{self.supabase_url}/auth/v1/token?grant_type=authorization_code"
            data = json.dumps({
                "code": code,
                "redirect_uri": self.redirect_uri
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
                return self._save_session(result)
        except Exception as e:
            print(f"Auth error: {e}")
            return None

    def verify_token(self, access_token: str) -> Optional[Dict]:
        """Verify access token with Supabase"""
        try:
            url = f"{self.supabase_url}/auth/v1/user"
            req = urllib.request.Request(
                url,
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except:
            return None

    def refresh_session(self, refresh_token: str) -> Optional[UserSession]:
        """Refresh expired session"""
        try:
            url = f"{self.supabase_url}/auth/v1/token?grant_type=refresh_token"
            data = json.dumps({
                "refresh_token": refresh_token
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
                return self._save_session(result)
        except:
            return None

    def _save_session(self, auth_result: Dict) -> Optional[UserSession]:
        """Save session to local DB"""
        try:
            user = auth_result.get('user', {})
            session = UserSession(
                user_id=user.get('id', ''),
                email=user.get('email', ''),
                access_token=auth_result.get('access_token', ''),
                refresh_token=auth_result.get('refresh_token', ''),
                expires_at=datetime.now().isoformat(),
                created_at=datetime.now().isoformat()
            )

            conn = sqlite3.connect(str(AUTH_DB_PATH))
            conn.execute("""
                INSERT OR REPLACE INTO sessions
                (user_id, email, access_token, refresh_token, expires_at, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                session.user_id,
                session.email,
                session.access_token,
                session.refresh_token,
                session.expires_at,
                session.created_at
            ))
            conn.commit()
            conn.close()

            return session
        except Exception as e:
            print(f"Save session error: {e}")
            return None

    def get_local_session(self) -> Optional[UserSession]:
        """Get session from local DB"""
        try:
            conn = sqlite3.connect(str(AUTH_DB_PATH))
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT * FROM sessions ORDER BY created_at DESC LIMIT 1")
            row = cur.fetchone()
            conn.close()

            if row:
                row_dict = dict(row)
                row_dict.pop('id', None)  # Remove id column
                session = UserSession(**row_dict)
                print(f"Found local session: {session.email}")
                # Verify token is still valid
                user = self.verify_token(session.access_token)
                if user:
                    print(f"Token valid for: {session.email}")
                    return session
                print(f"Token invalid, trying refresh...")
                # Try refresh
                if session.refresh_token:
                    refreshed = self.refresh_session(session.refresh_token)
                    if refreshed:
                        print(f"Refreshed session: {refreshed.email}")
                        return refreshed
                print("Refresh failed")
            else:
                print("No local session found")
            return None
        except Exception as e:
            print(f"get_local_session error: {e}")
            return None

    def logout(self):
        """Clear local session"""
        try:
            conn = sqlite3.connect(str(AUTH_DB_PATH))
            conn.execute("DELETE FROM sessions")
            conn.commit()
            conn.close()
        except:
            pass

    def sign_up(self, email: str, password: str) -> Dict:
        """Sign up with email/password"""
        try:
            url = f"{self.supabase_url}/auth/v1/signup"
            data = json.dumps({
                "email": email,
                "password": password
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
                print(f"Signup result: {result}")
                return result
        except urllib.error.HTTPError as e:
            try:
                error_body = json.loads(e.read())
                print(f"Signup error: {error_body}")
                return {"error": error_body}
            except:
                return {"error": {"message": str(e)}}
        except Exception as e:
            print(f"Signup exception: {e}")
            return {"error": {"message": str(e)}}

    def sign_in(self, email: str, password: str) -> Optional[UserSession]:
        """Sign in with email/password"""
        try:
            url = f"{self.supabase_url}/auth/v1/token?grant_type=password"
            data = json.dumps({
                "email": email,
                "password": password
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
                print(f"Login success: {email}")
                return self._save_session(result)
        except urllib.error.HTTPError as e:
            try:
                error_body = json.loads(e.read())
                print(f"Login error: {error_body}")
            except:
                print(f"Login error: {e}")
            return None
        except Exception as e:
            print(f"Login exception: {e}")
            return None

    def reset_password(self, email: str) -> bool:
        """Send password reset email"""
        try:
            url = f"{self.supabase_url}/auth/v1/recover"
            data = json.dumps({
                "email": email,
                "redirect_to": self.redirect_uri
            }).encode()

            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "apikey": self.anon_key
                }
            )

            with urllib.request.urlopen(req, timeout=10) as resp:
                return True
        except:
            return False


def create_auth_callback_server(auth: SupabaseAuth, main_port: int):
    """Create callback server on port 2223"""
    from http.server import HTTPServer, BaseHTTPRequestHandler
    import webbrowser

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)

            if parsed.path == "/callback":
                # Handle OAuth callback
                if "code" in params:
                    code = params["code"][0]
                    session = auth.exchange_code_for_session(code)
                    if session:
                        self._redirect(f"http://localhost:{main_port}/")
                        return

                # Handle token in hash (client-side flow)
                if "access_token" in params:
                    # This shouldn't happen with server-side flow
                    pass

                # Error
                self._send_html("<h1>Auth Error</h1><p>Try again</p>")

            elif parsed.path == "/login":
                # Redirect to Supabase
                self._redirect(auth.get_login_url())

            elif parsed.path == "/logout":
                auth.logout()
                self._redirect(f"http://localhost:{main_port}/")

            else:
                self._send_html("<h1>Auth Server</h1>")

        def _redirect(self, url: str):
            self.send_response(302)
            self.send_header("Location", url)
            self.end_headers()

        def _send_html(self, html: str):
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(html.encode())

        def log_message(self, format, *args):
            pass  # Suppress logging

    server = HTTPServer(("localhost", 2223), CallbackHandler)
    return server


def run_auth_server(auth: SupabaseAuth, main_port: int):
    """Run auth callback server in background"""
    server = create_auth_callback_server(auth, main_port)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"   Auth callback server on http://localhost:2223")
    return server
