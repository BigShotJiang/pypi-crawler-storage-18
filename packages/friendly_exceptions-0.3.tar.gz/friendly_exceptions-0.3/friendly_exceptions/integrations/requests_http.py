"""
requests/httpx error handling

Usage:
    from friendly_exceptions.integrations.requests_http import friendly_request, explain_http_error

    # Wrapper for requests
    response = friendly_request("https://api.example.com/data")

    # Or wrap session
    from friendly_exceptions.integrations.requests_http import FriendlySession
    session = FriendlySession()
    response = session.get("https://api.example.com")
"""

from typing import Optional, Dict, Any, Tuple, List
from functools import wraps
from datetime import datetime


STATUS_MESSAGES = {
    400: ("Bad Request", "Check request parameters and body format"),
    401: ("Unauthorized", "Check API key or authentication token"),
    403: ("Forbidden", "You don't have permission. Check API key scope"),
    404: ("Not Found", "Check URL path. Resource may not exist"),
    405: ("Method Not Allowed", "Use correct HTTP method (GET/POST/PUT/DELETE)"),
    408: ("Request Timeout", "Server took too long. Try again"),
    409: ("Conflict", "Resource conflict. Check if already exists"),
    410: ("Gone", "Resource was deleted permanently"),
    413: ("Payload Too Large", "Reduce request body size"),
    415: ("Unsupported Media Type", "Check Content-Type header"),
    422: ("Unprocessable Entity", "Validation failed. Check data format"),
    429: ("Too Many Requests", "Rate limited. Wait and retry"),
    500: ("Internal Server Error", "Server error. Try again later"),
    502: ("Bad Gateway", "Server/proxy issue. Try again"),
    503: ("Service Unavailable", "Server overloaded. Try again later"),
    504: ("Gateway Timeout", "Server timeout. Try again"),
}

ERROR_MESSAGES = {
    "connection": {
        "en": "Cannot connect to server",
        "ru": "Не удаётся подключиться к серверу"
    },
    "timeout": {
        "en": "Request timed out",
        "ru": "Превышено время ожидания"
    },
    "ssl": {
        "en": "SSL certificate error",
        "ru": "Ошибка SSL сертификата"
    },
    "dns": {
        "en": "Cannot resolve hostname",
        "ru": "Не удаётся разрешить имя хоста"
    },
    "proxy": {
        "en": "Proxy connection error",
        "ru": "Ошибка подключения через прокси"
    },
}


def get_message(key: str, lang: str = "en") -> str:
    msgs = ERROR_MESSAGES.get(key, {})
    return msgs.get(lang, msgs.get("en", key))


def explain_http_error(error, url: str = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze HTTP error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__
    suggestions = []

    # Connection errors
    if "connection" in error_str or "connect" in error_type.lower():
        if "refused" in error_str:
            msg = f"{get_message('connection', lang)}: Connection refused"
            suggestions = [
                "Check server is running",
                "Verify host and port",
                "Check firewall settings"
            ]
        elif "reset" in error_str:
            msg = f"{get_message('connection', lang)}: Connection reset"
            suggestions = [
                "Server closed connection unexpectedly",
                "Check server logs",
                "Try again"
            ]
        else:
            msg = get_message("connection", lang)
            suggestions = [
                "Check internet connection",
                "Verify URL is correct",
                "Check if server is accessible"
            ]

    # Timeout
    elif "timeout" in error_str or "timed out" in error_str:
        msg = get_message("timeout", lang)
        suggestions = [
            "Increase timeout: requests.get(url, timeout=30)",
            "Check network latency",
            "Server may be slow/overloaded"
        ]

    # SSL errors
    elif "ssl" in error_str or "certificate" in error_str:
        msg = get_message("ssl", lang)
        if "verify" in error_str or "self-signed" in error_str:
            suggestions = [
                "For testing: requests.get(url, verify=False)",
                "Add CA certificate: verify='/path/to/cert.pem'",
                "Update certifi: pip install --upgrade certifi"
            ]
        elif "expired" in error_str:
            suggestions = [
                "Server certificate has expired",
                "Contact server administrator",
                "Check system date/time"
            ]
        else:
            suggestions = [
                "Check SSL certificate is valid",
                "Update CA certificates",
                "Try: pip install --upgrade certifi"
            ]

    # DNS errors
    elif "getaddrinfo" in error_str or "name or service not known" in error_str or "nodename" in error_str:
        msg = get_message("dns", lang)
        suggestions = [
            "Check URL spelling",
            "Verify domain exists",
            "Check DNS settings",
            "Try using IP address directly"
        ]

    # Proxy errors
    elif "proxy" in error_str:
        msg = get_message("proxy", lang)
        suggestions = [
            "Check proxy settings",
            "Verify proxy credentials",
            "Try without proxy: proxies=None"
        ]

    # Too many redirects
    elif "redirect" in error_str:
        msg = "Too many redirects"
        suggestions = [
            "Check URL for redirect loop",
            "Set max redirects: allow_redirects=False",
            "Check cookies/session"
        ]

    # JSON decode error
    elif "json" in error_str and "decode" in error_str:
        msg = "Invalid JSON response"
        suggestions = [
            "Check response.text first",
            "Server may return HTML error page",
            "Verify Content-Type header"
        ]

    # Chunked encoding
    elif "chunked" in error_str or "incomplete" in error_str:
        msg = "Incomplete response received"
        suggestions = [
            "Connection was interrupted",
            "Try again",
            "Check server health"
        ]

    else:
        msg = f"HTTP Error: {error}"
        suggestions = [
            "Check URL and parameters",
            "Verify network connection",
            "Check server status"
        ]

    if url:
        suggestions.insert(0, f"URL: {url[:50]}...")

    return msg, suggestions


def explain_status_code(status_code: int, response_text: str = None) -> Tuple[str, List[str]]:
    """Explain HTTP status code"""
    if status_code < 400:
        return f"Success: {status_code}", []

    status_info = STATUS_MESSAGES.get(status_code, ("Error", "Unknown error"))
    msg = f"HTTP {status_code}: {status_info[0]}"
    suggestions = [status_info[1]]

    # Add specific suggestions based on status
    if status_code == 401:
        suggestions.extend([
            "Check Authorization header",
            "Token may be expired",
            "Verify API key is correct"
        ])
    elif status_code == 403:
        suggestions.extend([
            "Check API key permissions",
            "IP may be blocked",
            "Check rate limits"
        ])
    elif status_code == 404:
        suggestions.extend([
            "Check URL path spelling",
            "Resource may have been deleted",
            "Check API version"
        ])
    elif status_code == 429:
        suggestions.extend([
            "Wait before retrying",
            "Check Retry-After header",
            "Implement rate limiting"
        ])
    elif status_code >= 500:
        suggestions.extend([
            "Server-side error",
            "Wait and retry",
            "Check service status page"
        ])

    # Try to extract error from response
    if response_text:
        try:
            import json
            data = json.loads(response_text)
            if "error" in data:
                error_msg = data.get("error", {})
                if isinstance(error_msg, dict):
                    error_msg = error_msg.get("message", str(error_msg))
                suggestions.insert(0, f"Server says: {str(error_msg)[:100]}")
            elif "message" in data:
                suggestions.insert(0, f"Server says: {data['message'][:100]}")
        except:
            pass

    return msg, suggestions


def friendly_request(
    url: str,
    method: str = "GET",
    output_file: str = None,
    lang: str = "en",
    raise_for_status: bool = True,
    **kwargs
):
    """
    Make HTTP request with friendly error handling

    Args:
        url: Request URL
        method: HTTP method
        output_file: Log errors to file
        lang: Language for messages
        raise_for_status: Raise on 4xx/5xx
        **kwargs: Passed to requests
    """
    try:
        import requests
    except ImportError:
        raise ImportError("requests not installed. Run: pip install requests")

    try:
        response = requests.request(method, url, **kwargs)

        if raise_for_status and response.status_code >= 400:
            msg, suggestions = explain_status_code(response.status_code, response.text)
            _print_error(f"HTTP {response.status_code}", url, msg, suggestions, output_file)

        return response

    except Exception as e:
        msg, suggestions = explain_http_error(e, url, lang)
        _print_error(type(e).__name__, url, msg, suggestions, output_file)
        raise


class FriendlySession:
    """Requests session with friendly error handling"""

    def __init__(self, output_file: str = None, lang: str = "en"):
        try:
            import requests
            self._session = requests.Session()
        except ImportError:
            raise ImportError("requests not installed. Run: pip install requests")

        self.output_file = output_file
        self.lang = lang

    def request(self, method: str, url: str, **kwargs):
        return friendly_request(
            url, method,
            output_file=self.output_file,
            lang=self.lang,
            **kwargs
        )

    def get(self, url: str, **kwargs):
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs):
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs):
        return self.request("PUT", url, **kwargs)

    def patch(self, url: str, **kwargs):
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs):
        return self.request("DELETE", url, **kwargs)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._session.close()


def _print_error(error_type: str, url: str, message: str, suggestions: list, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ {error_type}",
        f"🌐 {url[:60]}{'...' if len(url) > 60 else ''}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")
