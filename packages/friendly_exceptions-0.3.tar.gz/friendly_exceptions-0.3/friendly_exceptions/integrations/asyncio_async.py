"""
Asyncio error handling

Usage:
    from friendly_exceptions.integrations.asyncio_async import friendly_asyncio, explain_asyncio_error

    # Wrap async function
    @friendly_asyncio
    async def my_function():
        await some_async_operation()

    # Or use as context manager
    async with friendly_async_context():
        await some_async_operation()
"""

from typing import Tuple, List, Optional, Callable
from functools import wraps
from datetime import datetime
import sys


ASYNCIO_ERRORS = {
    # Timeout errors
    "timeout": ("Async operation timed out", [
        "Operation took too long",
        "Increase timeout: asyncio.wait_for(coro, timeout=30)",
        "Check for slow network/IO"
    ]),

    # Cancelled
    "cancelled": ("Task was cancelled", [
        "Task.cancel() was called",
        "Handle with try/except CancelledError",
        "Check cancellation source"
    ]),

    # Runtime errors
    "no_running_loop": ("No running event loop", [
        "Use asyncio.run() to start loop",
        "Or asyncio.get_event_loop().run_until_complete()",
        "Must be called from async context"
    ]),
    "loop_closed": ("Event loop is closed", [
        "Loop was already closed",
        "Create new event loop",
        "Don't reuse closed loop"
    ]),
    "loop_running": ("Event loop already running", [
        "Cannot run nested event loops",
        "Use asyncio.create_task() instead",
        "In Jupyter: use nest_asyncio"
    ]),

    # Task errors
    "task_exception": ("Task raised exception", [
        "Check task result: task.exception()",
        "Use try/except in coroutine",
        "Add error handler"
    ]),
    "invalid_state": ("Task in invalid state", [
        "Task may be pending or done",
        "Check task.done() before accessing result",
        "Task may not be started"
    ]),

    # Coroutine errors
    "coroutine_never_awaited": ("Coroutine was never awaited", [
        "Add 'await' before coroutine call",
        "async function must be awaited",
        "Use: await my_async_function()"
    ]),
    "not_a_coroutine": ("Function is not a coroutine", [
        "Use 'async def' to define coroutine",
        "Cannot await regular function",
        "Check function definition"
    ]),

    # Connection errors
    "connection_refused": ("Connection refused", [
        "Server may not be running",
        "Check host and port",
        "Verify server is accepting connections"
    ]),
    "connection_reset": ("Connection reset", [
        "Server closed connection",
        "Check server status",
        "Implement reconnection logic"
    ]),
    "connection_timeout": ("Connection timed out", [
        "Server not responding",
        "Check network connectivity",
        "Increase connection timeout"
    ]),

    # Semaphore/Lock errors
    "semaphore_release": ("Semaphore released too many times", [
        "Release called more than acquire",
        "Check acquire/release pairing",
        "Use 'async with' for safety"
    ]),
    "lock_not_acquired": ("Lock not acquired", [
        "Trying to release unacquired lock",
        "Use 'async with lock:'",
        "Check lock ownership"
    ]),

    # Queue errors
    "queue_full": ("Queue is full", [
        "Queue has reached maxsize",
        "Use put_nowait with try/except",
        "Increase maxsize or consume faster"
    ]),
    "queue_empty": ("Queue is empty", [
        "No items in queue",
        "Use get_nowait with try/except",
        "Wait for items with await get()"
    ]),

    # SSL errors
    "ssl_error": ("SSL/TLS error", [
        "Check SSL certificate",
        "Use ssl=False for testing",
        "Verify certificate chain"
    ]),

    # Resource warnings
    "unclosed_resource": ("Resource not properly closed", [
        "Use 'async with' for cleanup",
        "Call close() or aclose()",
        "Check for missing await"
    ]),
}


def explain_asyncio_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze asyncio error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Timeout
    if "timeouterror" in error_type.lower() or "asyncio.timeout" in error_type.lower() or "timed out" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["timeout"]
        return f"Asyncio: {msg}", suggestions

    # Cancelled
    if "cancellederror" in error_type.lower() or "cancelled" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["cancelled"]
        return f"Asyncio: {msg}", suggestions

    # No running loop
    if "no running event loop" in error_str or "no current event loop" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["no_running_loop"]
        return f"Asyncio: {msg}", suggestions

    # Loop closed
    if "event loop is closed" in error_str or "loop is closed" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["loop_closed"]
        return f"Asyncio: {msg}", suggestions

    # Loop running
    if "loop is already running" in error_str or "cannot be called from a running" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["loop_running"]
        return f"Asyncio: {msg}", suggestions

    # Invalid state
    if "invalidstateerror" in error_type.lower() or "invalid state" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["invalid_state"]
        return f"Asyncio: {msg}", suggestions

    # Coroutine never awaited (usually a warning)
    if "never awaited" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["coroutine_never_awaited"]
        return f"Asyncio: {msg}", suggestions

    # Not a coroutine
    if "object can't be used in 'await'" in error_str or "not a coroutine" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["not_a_coroutine"]
        return f"Asyncio: {msg}", suggestions

    # Connection errors
    if "connectionrefusederror" in error_type.lower() or "connection refused" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["connection_refused"]
        return f"Asyncio: {msg}", suggestions

    if "connectionreseterror" in error_type.lower() or "connection reset" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["connection_reset"]
        return f"Asyncio: {msg}", suggestions

    if "connection" in error_str and "timeout" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["connection_timeout"]
        return f"Asyncio: {msg}", suggestions

    # Queue errors
    if "queuefull" in error_type.lower() or "queue is full" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["queue_full"]
        return f"Asyncio: {msg}", suggestions

    if "queueempty" in error_type.lower() or "queue is empty" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["queue_empty"]
        return f"Asyncio: {msg}", suggestions

    # SSL errors
    if "sslerror" in error_type.lower() or "ssl" in error_str and "error" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["ssl_error"]
        return f"Asyncio: {msg}", suggestions

    # Lock/Semaphore errors
    if "semaphore" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["semaphore_release"]
        return f"Asyncio: {msg}", suggestions

    if "lock" in error_str and "release" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["lock_not_acquired"]
        return f"Asyncio: {msg}", suggestions

    # Resource warnings
    if "unclosed" in error_str or "not properly closed" in error_str:
        msg, suggestions = ASYNCIO_ERRORS["unclosed_resource"]
        return f"Asyncio: {msg}", suggestions

    # Generic
    msg = f"Asyncio Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check async/await usage",
        "Review asyncio documentation"
    ]

    return msg, suggestions


def _print_error(operation: str, message: str, suggestions: list, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ asyncio.{operation}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_asyncio(func=None, output_file: str = None, lang: str = "en"):
    """
    Decorator to add friendly error handling to async functions

    Usage:
        @friendly_asyncio
        async def my_function():
            ...

        # Or with parameters
        @friendly_asyncio(output_file="errors.txt")
        async def my_function():
            ...
    """
    def decorator(f):
        @wraps(f)
        async def wrapper(*args, **kwargs):
            try:
                return await f(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_asyncio_error(e, lang)
                _print_error(f.__name__, msg, suggestions, output_file)
                raise
        return wrapper

    if func is not None:
        return decorator(func)
    return decorator


class FriendlyAsyncContext:
    """Context manager for friendly async error handling"""

    def __init__(self, name: str = "block", output_file: str = None, lang: str = "en"):
        self.name = name
        self.output_file = output_file
        self.lang = lang

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_val:
            msg, suggestions = explain_asyncio_error(exc_val, self.lang)
            _print_error(self.name, msg, suggestions, self.output_file)
        return False  # Don't suppress exception


def friendly_async_context(name: str = "block", output_file: str = None, lang: str = "en"):
    """
    Create async context manager with friendly errors

    Usage:
        async with friendly_async_context("my_operation"):
            await some_async_operation()
    """
    return FriendlyAsyncContext(name, output_file, lang)


async def run_with_timeout(
    coro,
    timeout: float,
    output_file: str = None,
    lang: str = "en"
):
    """
    Run coroutine with timeout and friendly error on timeout

    Args:
        coro: Coroutine to run
        timeout: Timeout in seconds
        output_file: Log errors to file
        lang: Language for messages

    Returns:
        Coroutine result

    Raises:
        asyncio.TimeoutError: If timeout exceeded
    """
    import asyncio

    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError as e:
        msg, suggestions = explain_asyncio_error(e, lang)
        suggestions.insert(0, f"Timeout: {timeout} seconds")
        _print_error("wait_for", msg, suggestions, output_file)
        raise


async def gather_with_errors(
    *coros,
    output_file: str = None,
    lang: str = "en"
):
    """
    Run coroutines concurrently, explain any errors

    Args:
        *coros: Coroutines to run
        output_file: Log errors to file
        lang: Language for messages

    Returns:
        List of results (exceptions for failed tasks)
    """
    import asyncio

    results = await asyncio.gather(*coros, return_exceptions=True)

    for i, result in enumerate(results):
        if isinstance(result, Exception):
            msg, suggestions = explain_asyncio_error(result, lang)
            _print_error(f"gather[{i}]", msg, suggestions, output_file)

    return results


class FriendlyTaskGroup:
    """Task group with friendly error handling (Python 3.11+)"""

    def __init__(self, output_file: str = None, lang: str = "en"):
        self.output_file = output_file
        self.lang = lang
        self._tasks = []
        self._tg = None

    async def __aenter__(self):
        import asyncio
        if hasattr(asyncio, 'TaskGroup'):
            self._tg = asyncio.TaskGroup()
            await self._tg.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._tg:
            try:
                await self._tg.__aexit__(exc_type, exc_val, exc_tb)
            except* Exception as eg:
                # Handle exception group (Python 3.11+)
                for exc in eg.exceptions:
                    msg, suggestions = explain_asyncio_error(exc, self.lang)
                    _print_error("TaskGroup", msg, suggestions, self.output_file)
                raise
        return False

    def create_task(self, coro):
        """Create task in group"""
        if self._tg:
            return self._tg.create_task(coro)
        else:
            import asyncio
            task = asyncio.create_task(coro)
            self._tasks.append(task)
            return task


def install_exception_handler(output_file: str = None, lang: str = "en"):
    """
    Install global exception handler for asyncio

    Usage:
        install_exception_handler()
        asyncio.run(main())
    """
    import asyncio

    def handle_exception(loop, context):
        exception = context.get('exception')
        if exception:
            msg, suggestions = explain_asyncio_error(exception, lang)
            _print_error("loop", msg, suggestions, output_file)

        # Log the message
        message = context.get('message', 'Unknown error')
        print(f"Asyncio error: {message}")

    try:
        loop = asyncio.get_running_loop()
        loop.set_exception_handler(handle_exception)
    except RuntimeError:
        # No running loop, set on default
        loop = asyncio.new_event_loop()
        loop.set_exception_handler(handle_exception)
        asyncio.set_event_loop(loop)
