"""
python-dotenv error handling with friendly_exceptions

Usage:
    from friendly_exceptions.integrations.dotenv import load_env, get_env, require_env

    # Load .env with friendly errors
    load_env()

    # Get variable with helpful error if missing
    api_key = require_env("API_KEY")

    # Get with default
    debug = get_env("DEBUG", "false")

    # Validate .env file
    from friendly_exceptions.integrations.dotenv import validate_env
    validate_env(".env", required=["API_KEY", "DATABASE_URL"])
"""

import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime


class EnvError(Exception):
    """Friendly environment variable error"""

    def __init__(self, message: str, var_name: str = None, suggestions: List[str] = None):
        self.var_name = var_name
        self.suggestions = suggestions or []
        super().__init__(message)


def find_env_file(start_path: str = None) -> Optional[Path]:
    """Find .env file in current or parent directories"""
    current = Path(start_path or os.getcwd())

    while current != current.parent:
        env_file = current / ".env"
        if env_file.exists():
            return env_file
        current = current.parent

    return None


def parse_env_file(filepath: str) -> Dict[str, str]:
    """Parse .env file and return dict of variables"""
    result = {}
    errors = []

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()

                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue

                # Check for valid format
                if '=' not in line:
                    errors.append(f"Line {line_num}: Missing '=' in '{line[:30]}...'")
                    continue

                key, _, value = line.partition('=')
                key = key.strip()
                value = value.strip()

                # Remove quotes
                if (value.startswith('"') and value.endswith('"')) or \
                   (value.startswith("'") and value.endswith("'")):
                    value = value[1:-1]

                if not key:
                    errors.append(f"Line {line_num}: Empty variable name")
                    continue

                if not key.replace('_', '').isalnum():
                    errors.append(f"Line {line_num}: Invalid variable name '{key}'")
                    continue

                result[key] = value

    except FileNotFoundError:
        raise EnvError(
            f"❌ .env file not found: {filepath}",
            suggestions=[
                f"Create .env file: touch {filepath}",
                "Copy from example: cp .env.example .env",
                "Check file path is correct"
            ]
        )
    except PermissionError:
        raise EnvError(
            f"❌ Permission denied reading: {filepath}",
            suggestions=[
                f"Check file permissions: ls -la {filepath}",
                f"Fix permissions: chmod 644 {filepath}"
            ]
        )
    except UnicodeDecodeError:
        raise EnvError(
            f"❌ Invalid encoding in: {filepath}",
            suggestions=[
                "Save file as UTF-8",
                "Remove special characters",
                "Check for binary content"
            ]
        )

    if errors:
        print(f"⚠️ .env parsing warnings:")
        for e in errors[:5]:
            print(f"   {e}")
        if len(errors) > 5:
            print(f"   ... and {len(errors) - 5} more")

    return result


def load_env(
    filepath: str = None,
    override: bool = False,
    output_file: str = None
) -> Dict[str, str]:
    """
    Load .env file with friendly error handling

    Args:
        filepath: Path to .env file (auto-detect if None)
        override: Override existing environment variables
        output_file: Log errors to file

    Returns:
        Dict of loaded variables
    """
    # Find .env file
    if filepath is None:
        env_path = find_env_file()
        if env_path is None:
            print("ℹ️ No .env file found (searched current and parent dirs)")
            return {}
        filepath = str(env_path)

    # Parse file
    variables = parse_env_file(filepath)

    # Load into environment
    loaded = {}
    for key, value in variables.items():
        if override or key not in os.environ:
            os.environ[key] = value
            loaded[key] = value

    if loaded:
        print(f"✅ Loaded {len(loaded)} variables from {filepath}")

    return loaded


def get_env(name: str, default: str = None, cast: type = None) -> Any:
    """
    Get environment variable with optional type casting

    Args:
        name: Variable name
        default: Default value if not found
        cast: Type to cast to (int, float, bool, list)
    """
    value = os.environ.get(name, default)

    if value is None:
        return None

    if cast is None:
        return value

    try:
        if cast == bool:
            return value.lower() in ('true', '1', 'yes', 'on')
        elif cast == list:
            return [v.strip() for v in value.split(',')]
        else:
            return cast(value)
    except (ValueError, TypeError) as e:
        print(f"⚠️ Cannot cast {name}='{value}' to {cast.__name__}: {e}")
        return default


def require_env(name: str, cast: type = None) -> Any:
    """
    Get required environment variable (raises error if missing)

    Args:
        name: Variable name
        cast: Type to cast to
    """
    value = os.environ.get(name)

    if value is None:
        # Look for similar variable names
        all_vars = list(os.environ.keys())
        import difflib
        similar = difflib.get_close_matches(name, all_vars, n=3, cutoff=0.6)

        suggestions = [
            f"Add to .env: {name}=your_value",
            f"Or set: export {name}=your_value",
        ]
        if similar:
            suggestions.append(f"Similar vars found: {', '.join(similar)}")

        error_msg = f"❌ Required environment variable '{name}' is not set"
        print(error_msg)
        print("💡 Suggestions:")
        for s in suggestions:
            print(f"   • {s}")

        raise EnvError(error_msg, var_name=name, suggestions=suggestions)

    if cast:
        return get_env(name, cast=cast)

    return value


def validate_env(
    filepath: str = ".env",
    required: List[str] = None,
    optional: List[str] = None
) -> Dict[str, Any]:
    """
    Validate .env file has all required variables

    Args:
        filepath: Path to .env file
        required: List of required variable names
        optional: List of optional variable names

    Returns:
        Dict with validation results
    """
    required = required or []
    optional = optional or []

    result = {
        "valid": True,
        "missing": [],
        "found": [],
        "extra": [],
        "errors": []
    }

    # Check file exists
    if not os.path.exists(filepath):
        result["valid"] = False
        result["errors"].append(f"File not found: {filepath}")
        print(f"❌ .env file not found: {filepath}")
        print("💡 Create it with:")
        for var in required[:5]:
            print(f"   {var}=")
        return result

    # Parse file
    try:
        variables = parse_env_file(filepath)
    except EnvError as e:
        result["valid"] = False
        result["errors"].append(str(e))
        return result

    # Check required
    for var in required:
        if var in variables:
            result["found"].append(var)
        else:
            result["missing"].append(var)
            result["valid"] = False

    # Check for extra variables
    all_expected = set(required + optional)
    for var in variables:
        if var not in all_expected:
            result["extra"].append(var)

    # Print results
    print(f"\n📋 .env validation: {filepath}")
    print("=" * 40)

    if result["found"]:
        print(f"✅ Found ({len(result['found'])}):")
        for var in result["found"]:
            val = variables[var]
            masked = val[:3] + "***" if len(val) > 6 else "***"
            print(f"   {var}={masked}")

    if result["missing"]:
        print(f"❌ Missing ({len(result['missing'])}):")
        for var in result["missing"]:
            print(f"   {var}")

    if result["extra"]:
        print(f"ℹ️ Extra ({len(result['extra'])}):")
        for var in result["extra"][:5]:
            print(f"   {var}")

    print("=" * 40)
    print(f"{'✅ Valid' if result['valid'] else '❌ Invalid'}")

    return result


def create_env_template(
    filepath: str = ".env.example",
    variables: Dict[str, str] = None
):
    """Create .env template file"""
    variables = variables or {}

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("# Environment variables\n")
        f.write(f"# Generated: {datetime.now()}\n\n")

        for key, description in variables.items():
            f.write(f"# {description}\n")
            f.write(f"{key}=\n\n")

    print(f"✅ Created template: {filepath}")
