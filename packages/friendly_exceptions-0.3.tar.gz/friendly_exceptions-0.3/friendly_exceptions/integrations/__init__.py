"""
Integrations for popular frameworks and APIs

Available integrations:
    - openai: OpenAI API error handling
    - telegram: Telegram Bot API error handling
    - dotenv: Environment variable handling
    - pillow: Image processing error handling
    - requests_http: HTTP requests error handling
    - aws: AWS/boto3 error handling
    - stripe_pay: Stripe payment error handling
    - firebase: Firebase error handling
    - redis_cache: Redis error handling
    - sqlalchemy_db: SQLAlchemy database error handling
    - mongodb: MongoDB/PyMongo error handling
    - pandas_data: Pandas data processing error handling
    - numpy_arr: NumPy array error handling
    - pytest_test: Pytest test error handling
    - discord_bot: Discord.py bot error handling
    - selenium_web: Selenium WebDriver error handling
    - subprocess_cmd: Subprocess command error handling
    - asyncio_async: Asyncio error handling
    - fastapi: FastAPI error handling (see friendly_exceptions.fastapi)
"""

# Core integrations (always imported)
from .openai import friendly_openai, explain_openai_error, FriendlyOpenAIError
from .telegram import (
    friendly_telegram_bot,
    friendly_aiogram,
    explain_telegram_error,
    wrap_telegram_call
)
from .dotenv import (
    load_env,
    get_env,
    require_env,
    validate_env,
    EnvError
)
from .pillow import (
    open_image,
    save_image,
    resize_image,
    get_image_info,
    friendly_pil,
    ImageError
)

# HTTP/API integrations
from .requests_http import (
    friendly_request,
    FriendlySession,
    explain_http_error,
    explain_status_code
)
from .aws import friendly_boto3, explain_aws_error, FriendlyBoto3Client
from .stripe_pay import friendly_stripe, explain_stripe_error, FriendlyStripe
from .firebase import (
    friendly_firestore,
    friendly_auth,
    friendly_storage,
    explain_firebase_error
)

# Database integrations
from .redis_cache import friendly_redis, explain_redis_error, FriendlyRedis
from .sqlalchemy_db import (
    friendly_engine,
    friendly_session,
    explain_sqlalchemy_error,
    FriendlyEngine,
    FriendlySession as FriendlySQLSession
)
from .mongodb import friendly_mongo, explain_mongo_error, FriendlyMongoClient

# Data science integrations
from .pandas_data import (
    friendly_pandas,
    read_csv,
    read_excel,
    read_json,
    to_csv,
    to_excel,
    explain_pandas_error,
    FriendlyDataFrame
)
from .numpy_arr import (
    friendly_numpy,
    explain_numpy_error,
    safe_divide,
    safe_log,
    safe_sqrt,
    check_array
)

# Testing
from .pytest_test import friendly_pytest, explain_pytest_error, FriendlyPytestPlugin

# Bot/Automation integrations
from .discord_bot import (
    friendly_discord,
    explain_discord_error,
    create_friendly_bot,
    FriendlyDiscordClient
)
from .selenium_web import (
    friendly_selenium,
    explain_selenium_error,
    create_friendly_driver,
    FriendlyWebDriver
)

# System integrations
from .subprocess_cmd import (
    run,
    run_shell,
    run_safe,
    explain_subprocess_error,
    check_command_exists
)
from .asyncio_async import (
    friendly_asyncio,
    friendly_async_context,
    explain_asyncio_error,
    run_with_timeout,
    gather_with_errors,
    install_exception_handler,
    FriendlyTaskGroup
)

__all__ = [
    # OpenAI
    "friendly_openai",
    "explain_openai_error",
    "FriendlyOpenAIError",
    # Telegram
    "friendly_telegram_bot",
    "friendly_aiogram",
    "explain_telegram_error",
    "wrap_telegram_call",
    # Dotenv
    "load_env",
    "get_env",
    "require_env",
    "validate_env",
    "EnvError",
    # Pillow
    "open_image",
    "save_image",
    "resize_image",
    "get_image_info",
    "friendly_pil",
    "ImageError",
    # HTTP/Requests
    "friendly_request",
    "FriendlySession",
    "explain_http_error",
    "explain_status_code",
    # AWS
    "friendly_boto3",
    "explain_aws_error",
    "FriendlyBoto3Client",
    # Stripe
    "friendly_stripe",
    "explain_stripe_error",
    "FriendlyStripe",
    # Firebase
    "friendly_firestore",
    "friendly_auth",
    "friendly_storage",
    "explain_firebase_error",
    # Redis
    "friendly_redis",
    "explain_redis_error",
    "FriendlyRedis",
    # SQLAlchemy
    "friendly_engine",
    "friendly_session",
    "explain_sqlalchemy_error",
    "FriendlyEngine",
    "FriendlySQLSession",
    # MongoDB
    "friendly_mongo",
    "explain_mongo_error",
    "FriendlyMongoClient",
    # Pandas
    "friendly_pandas",
    "read_csv",
    "read_excel",
    "read_json",
    "to_csv",
    "to_excel",
    "explain_pandas_error",
    "FriendlyDataFrame",
    # NumPy
    "friendly_numpy",
    "explain_numpy_error",
    "safe_divide",
    "safe_log",
    "safe_sqrt",
    "check_array",
    # Pytest
    "friendly_pytest",
    "explain_pytest_error",
    "FriendlyPytestPlugin",
    # Discord
    "friendly_discord",
    "explain_discord_error",
    "create_friendly_bot",
    "FriendlyDiscordClient",
    # Selenium
    "friendly_selenium",
    "explain_selenium_error",
    "create_friendly_driver",
    "FriendlyWebDriver",
    # Subprocess
    "run",
    "run_shell",
    "run_safe",
    "explain_subprocess_error",
    "check_command_exists",
    # Asyncio
    "friendly_asyncio",
    "friendly_async_context",
    "explain_asyncio_error",
    "run_with_timeout",
    "gather_with_errors",
    "install_exception_handler",
    "FriendlyTaskGroup",
]
