"""
Subprocess error handling

Usage:
    from friendly_exceptions.integrations.subprocess_cmd import run, run_shell, explain_subprocess_error

    # Run command with friendly errors
    result = run(["ls", "-la"])

    # Run shell command
    result = run_shell("echo 'Hello World'")

    # Capture output
    result = run(["python", "script.py"], capture=True)
"""

from typing import Tuple, List, Optional, Union
from datetime import datetime
import subprocess
import shlex
import os


SUBPROCESS_ERRORS = {
    # File/Command not found
    "command_not_found": ("Command not found", [
        "Check command spelling",
        "Command may not be installed",
        "Check PATH environment variable",
        "Use full path to command"
    ]),
    "file_not_found": ("File not found", [
        "Check file path",
        "File may not exist",
        "Check working directory"
    ]),

    # Permission errors
    "permission_denied": ("Permission denied", [
        "Check file permissions",
        "May need sudo/admin rights",
        "Make file executable: chmod +x file"
    ]),
    "access_denied": ("Access denied", [
        "Insufficient permissions",
        "Run as administrator",
        "Check file/folder permissions"
    ]),

    # Process errors
    "process_timeout": ("Process timed out", [
        "Command took too long",
        "Increase timeout value",
        "Process may be stuck"
    ]),
    "process_killed": ("Process was killed", [
        "Process exceeded resources",
        "Killed by system (OOM)",
        "Check memory usage"
    ]),
    "broken_pipe": ("Broken pipe", [
        "Output pipe was closed",
        "Receiving process ended early",
        "Check pipe handling"
    ]),

    # Exit codes
    "exit_code_1": ("Command failed (exit code 1)", [
        "General error occurred",
        "Check command output for details",
        "Review command arguments"
    ]),
    "exit_code_2": ("Command failed (exit code 2)", [
        "Misuse of command",
        "Check command syntax",
        "Review documentation"
    ]),
    "exit_code_126": ("Permission problem", [
        "Command is not executable",
        "chmod +x to make executable",
        "Check file permissions"
    ]),
    "exit_code_127": ("Command not found", [
        "Command does not exist",
        "Check PATH",
        "Install the command"
    ]),
    "exit_code_128": ("Invalid exit code", [
        "Invalid exit argument",
        "Check script/program"
    ]),
    "exit_code_130": ("Interrupted (Ctrl+C)", [
        "Process was interrupted",
        "User pressed Ctrl+C",
        "SIGINT received"
    ]),
    "exit_code_137": ("Killed (SIGKILL)", [
        "Process was killed",
        "Out of memory (OOM killer)",
        "Killed by system or user"
    ]),
    "exit_code_139": ("Segmentation fault", [
        "Program crashed",
        "Memory access violation",
        "Bug in the program"
    ]),
    "exit_code_143": ("Terminated (SIGTERM)", [
        "Process was terminated",
        "Received shutdown signal",
        "Graceful termination"
    ]),

    # Encoding
    "encoding_error": ("Output encoding error", [
        "Non-UTF8 output",
        "Use encoding='latin-1' or errors='replace'",
        "Check output encoding"
    ]),
}


def explain_subprocess_error(error, command=None, returncode: int = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze subprocess error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # File/command not found
    if "filenotfounderror" in error_type.lower() or "no such file" in error_str:
        if command:
            if isinstance(command, list) and len(command) > 0:
                cmd_name = command[0]
            else:
                cmd_name = str(command).split()[0]

            # Check if it looks like a file or command
            if os.path.sep in str(cmd_name) or cmd_name.endswith(('.py', '.sh', '.exe')):
                msg, suggestions = SUBPROCESS_ERRORS["file_not_found"]
                suggestions.insert(0, f"File: {cmd_name}")
            else:
                msg, suggestions = SUBPROCESS_ERRORS["command_not_found"]
                suggestions.insert(0, f"Command: {cmd_name}")
        else:
            msg, suggestions = SUBPROCESS_ERRORS["command_not_found"]
        return f"Subprocess: {msg}", suggestions

    # Permission denied
    if "permission" in error_str and "denied" in error_str:
        msg, suggestions = SUBPROCESS_ERRORS["permission_denied"]
        return f"Subprocess: {msg}", suggestions

    # Timeout
    if "timeoutexpired" in error_type.lower() or "timed out" in error_str:
        msg, suggestions = SUBPROCESS_ERRORS["process_timeout"]
        timeout = getattr(error, 'timeout', None)
        if timeout:
            suggestions.insert(0, f"Timeout: {timeout} seconds")
        return f"Subprocess: {msg}", suggestions

    # Encoding error
    if "encode" in error_str or "decode" in error_str or "codec" in error_str:
        msg, suggestions = SUBPROCESS_ERRORS["encoding_error"]
        return f"Subprocess: {msg}", suggestions

    # CalledProcessError - check return code
    if "calledprocesserror" in error_type.lower() or returncode:
        code = returncode or getattr(error, 'returncode', None)

        if code:
            # Map exit codes to messages
            code_map = {
                1: "exit_code_1",
                2: "exit_code_2",
                126: "exit_code_126",
                127: "exit_code_127",
                128: "exit_code_128",
                130: "exit_code_130",
                137: "exit_code_137",
                139: "exit_code_139",
                143: "exit_code_143",
            }

            # Handle signal-based exit codes (128 + signal)
            if code > 128:
                signal_num = code - 128
                if code == 137:  # SIGKILL (9)
                    msg, suggestions = SUBPROCESS_ERRORS["exit_code_137"]
                elif code == 139:  # SIGSEGV (11)
                    msg, suggestions = SUBPROCESS_ERRORS["exit_code_139"]
                elif code == 143:  # SIGTERM (15)
                    msg, suggestions = SUBPROCESS_ERRORS["exit_code_143"]
                else:
                    msg = f"Process killed by signal {signal_num}"
                    suggestions = [
                        f"Exit code: {code}",
                        f"Signal: {signal_num}",
                        "Check what killed the process"
                    ]
            elif code in code_map:
                msg, suggestions = SUBPROCESS_ERRORS[code_map[code]]
            else:
                msg = f"Command failed (exit code {code})"
                suggestions = [
                    "Check command output for details",
                    "Verify command arguments",
                    f"Exit code: {code}"
                ]

            return f"Subprocess: {msg}", suggestions

    # Broken pipe
    if "broken pipe" in error_str:
        msg, suggestions = SUBPROCESS_ERRORS["broken_pipe"]
        return f"Subprocess: {msg}", suggestions

    # Generic
    msg = f"Subprocess Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check command and arguments",
        "Verify working directory"
    ]

    return msg, suggestions


def _print_error(command, message: str, suggestions: list, output: str = None, output_file: str = None):
    """Print formatted error"""
    cmd_str = command if isinstance(command, str) else ' '.join(str(c) for c in command)

    lines = [
        f"\n{'='*50}",
        f"❌ subprocess.run()",
        f"📝 Command: {cmd_str[:60]}{'...' if len(cmd_str) > 60 else ''}",
        f"🔍 {message}",
    ]

    if suggestions:
        lines.append("💡 Suggestions:")
        for s in suggestions[:5]:
            lines.append(f"   • {s}")

    # Show stderr/stdout if available
    if output:
        lines.append("📤 Output:")
        for line in output.strip().split('\n')[:5]:
            lines.append(f"   {line[:80]}")

    lines.append(f"{'='*50}\n")

    text = '\n'.join(lines)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


def run(
    command: Union[str, List[str]],
    capture: bool = True,
    check: bool = True,
    timeout: int = None,
    cwd: str = None,
    env: dict = None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
):
    """
    Run command with friendly error handling

    Args:
        command: Command as list or string
        capture: Capture stdout/stderr
        check: Raise on non-zero exit
        timeout: Timeout in seconds
        cwd: Working directory
        env: Environment variables
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to subprocess.run

    Returns:
        CompletedProcess result
    """
    # Convert string to list
    if isinstance(command, str):
        command = shlex.split(command)

    try:
        result = subprocess.run(
            command,
            capture_output=capture,
            check=check,
            timeout=timeout,
            cwd=cwd,
            env=env,
            text=True,
            **kwargs
        )
        return result

    except FileNotFoundError as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise

    except subprocess.CalledProcessError as e:
        msg, suggestions = explain_subprocess_error(e, command, e.returncode, lang)
        output = e.stderr or e.stdout
        _print_error(command, msg, suggestions, output, output_file)
        raise

    except subprocess.TimeoutExpired as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise

    except PermissionError as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise

    except Exception as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise


def run_shell(
    command: str,
    capture: bool = True,
    check: bool = True,
    timeout: int = None,
    cwd: str = None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
):
    """
    Run shell command with friendly error handling

    Args:
        command: Shell command string
        capture: Capture stdout/stderr
        check: Raise on non-zero exit
        timeout: Timeout in seconds
        cwd: Working directory
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to subprocess.run

    Returns:
        CompletedProcess result
    """
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=capture,
            check=check,
            timeout=timeout,
            cwd=cwd,
            text=True,
            **kwargs
        )
        return result

    except subprocess.CalledProcessError as e:
        msg, suggestions = explain_subprocess_error(e, command, e.returncode, lang)
        output = e.stderr or e.stdout
        _print_error(command, msg, suggestions, output, output_file)
        raise

    except subprocess.TimeoutExpired as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise

    except Exception as e:
        msg, suggestions = explain_subprocess_error(e, command, lang=lang)
        _print_error(command, msg, suggestions, output_file=output_file)
        raise


def check_command_exists(command: str) -> bool:
    """Check if a command exists in PATH"""
    import shutil
    return shutil.which(command) is not None


def run_safe(
    command: Union[str, List[str]],
    default=None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
):
    """
    Run command, return default on failure instead of raising

    Args:
        command: Command to run
        default: Value to return on failure
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to run()

    Returns:
        CompletedProcess on success, default on failure
    """
    try:
        return run(command, output_file=output_file, lang=lang, **kwargs)
    except Exception:
        return default
