"""
Stripe API error handling

Usage:
    from friendly_exceptions.integrations.stripe_pay import friendly_stripe, explain_stripe_error

    # Configure with friendly errors
    stripe = friendly_stripe(api_key="sk_...")

    # Now errors are explained
    stripe.PaymentIntent.create(amount=1000, currency="usd")
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


STRIPE_ERRORS = {
    # Card errors
    "card_declined": ("Card was declined", [
        "Try a different card",
        "Check card has sufficient funds",
        "Contact card issuer"
    ]),
    "expired_card": ("Card has expired", [
        "Update card expiration date",
        "Use a different card"
    ]),
    "incorrect_cvc": ("Incorrect CVC/CVV", [
        "Check the 3-4 digit security code",
        "Located on back of card"
    ]),
    "incorrect_number": ("Invalid card number", [
        "Check card number for typos",
        "Verify all digits entered"
    ]),
    "invalid_expiry_month": ("Invalid expiration month", [
        "Month must be 01-12",
        "Check card expiration"
    ]),
    "invalid_expiry_year": ("Invalid expiration year", [
        "Year cannot be in past",
        "Check card expiration"
    ]),
    "insufficient_funds": ("Insufficient funds", [
        "Card doesn't have enough balance",
        "Try a different card"
    ]),
    "processing_error": ("Processing error", [
        "Try again in a few seconds",
        "If persists, try different card"
    ]),

    # Authentication
    "authentication_required": ("3D Secure authentication required", [
        "Customer must complete authentication",
        "Use confirmCardPayment on frontend",
        "Check payment_intent.next_action"
    ]),

    # API errors
    "api_key_expired": ("API key has expired", [
        "Generate new API key in Stripe Dashboard",
        "Update STRIPE_API_KEY"
    ]),
    "invalid_api_key": ("Invalid API key", [
        "Check API key is correct",
        "Use test key (sk_test_) for testing",
        "Use live key (sk_live_) for production"
    ]),

    # Resource errors
    "resource_missing": ("Resource not found", [
        "Check ID is correct",
        "Resource may be in different mode (test/live)",
        "Resource may be deleted"
    ]),
    "customer_not_found": ("Customer not found", [
        "Check customer ID",
        "Customer may be deleted"
    ]),

    # Rate limiting
    "rate_limit": ("Too many requests", [
        "Implement exponential backoff",
        "Reduce request frequency",
        "Contact Stripe for limit increase"
    ]),

    # Idempotency
    "idempotency_key_in_use": ("Idempotency key already used", [
        "Use unique key for each request",
        "Previous request may still be processing"
    ]),

    # Amount errors
    "amount_too_small": ("Amount is below minimum", [
        "Minimum amount depends on currency",
        "USD minimum is $0.50",
        "Check Stripe docs for currency minimums"
    ]),
    "amount_too_large": ("Amount exceeds maximum", [
        "Check amount is in smallest currency unit",
        "USD: amount in cents (1000 = $10.00)"
    ]),

    # Invalid requests
    "parameter_invalid": ("Invalid parameter", [
        "Check parameter format",
        "Review API documentation"
    ]),
    "parameter_missing": ("Missing required parameter", [
        "Check required fields",
        "Review API documentation"
    ]),

    # Account
    "account_invalid": ("Account issue", [
        "Check Stripe account is active",
        "Complete account verification"
    ]),
    "platform_api_key_expired": ("Connect platform key expired", [
        "Update platform API key",
        "Check Connect settings"
    ]),
}


def explain_stripe_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Stripe error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Try to get Stripe error code
    code = None
    decline_code = None
    message = str(error)

    if hasattr(error, 'code'):
        code = error.code
    if hasattr(error, 'decline_code'):
        decline_code = error.decline_code
    if hasattr(error, 'user_message'):
        message = error.user_message

    # Check decline code first (more specific)
    if decline_code and decline_code in STRIPE_ERRORS:
        msg, suggestions = STRIPE_ERRORS[decline_code]
        return f"Stripe: {msg}", suggestions.copy()

    # Then check error code
    if code and code in STRIPE_ERRORS:
        msg, suggestions = STRIPE_ERRORS[code]
        return f"Stripe: {msg}", suggestions.copy()

    # Match by error string
    for key, (msg, suggestions) in STRIPE_ERRORS.items():
        if key.replace('_', ' ') in error_str or key in error_str:
            return f"Stripe: {msg}", suggestions.copy()

    # Categorize by error type
    suggestions = []

    if "CardError" in error_type:
        msg = "Card payment failed"
        suggestions = [
            "Check card details",
            "Try a different card",
            f"Decline reason: {decline_code or 'unknown'}"
        ]
    elif "InvalidRequestError" in error_type:
        msg = "Invalid API request"
        suggestions = [
            "Check request parameters",
            "Review Stripe API docs",
            f"Details: {message[:100]}"
        ]
    elif "AuthenticationError" in error_type:
        msg = "Authentication failed"
        suggestions = [
            "Check API key",
            "Verify key matches mode (test/live)",
            "Key may be revoked"
        ]
    elif "RateLimitError" in error_type:
        msg = "Rate limit exceeded"
        suggestions = [
            "Wait and retry",
            "Implement backoff",
            "Reduce request frequency"
        ]
    elif "APIConnectionError" in error_type:
        msg = "Cannot connect to Stripe"
        suggestions = [
            "Check internet connection",
            "Stripe may be down (status.stripe.com)",
            "Check firewall settings"
        ]
    else:
        msg = f"Stripe Error: {error_type}"
        suggestions = [
            f"Message: {message[:100]}",
            "Check Stripe Dashboard",
            "Review API logs"
        ]

    return msg, suggestions


class FriendlyStripe:
    """Wrapper for Stripe module with friendly errors"""

    def __init__(self, stripe_module, output_file: str = None, lang: str = "en"):
        self._stripe = stripe_module
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._stripe, name)

        # Wrap Stripe resource classes
        if hasattr(attr, 'create') or hasattr(attr, 'retrieve'):
            return FriendlyStripeResource(attr, name, self._output_file, self._lang)

        return attr


class FriendlyStripeResource:
    """Wrapper for Stripe resource with friendly errors"""

    def __init__(self, resource, name: str, output_file: str = None, lang: str = "en"):
        self._resource = resource
        self._name = name
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._resource, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_stripe_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ stripe.{self._name}.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_stripe(
    api_key: str = None,
    output_file: str = None,
    lang: str = "en"
) -> FriendlyStripe:
    """
    Configure Stripe with friendly error handling

    Args:
        api_key: Stripe API key (sk_test_... or sk_live_...)
        output_file: Log errors to file
        lang: Language for messages

    Returns:
        Wrapped Stripe module
    """
    try:
        import stripe
    except ImportError:
        raise ImportError("stripe not installed. Run: pip install stripe")

    if api_key:
        stripe.api_key = api_key

    return FriendlyStripe(stripe, output_file, lang)
