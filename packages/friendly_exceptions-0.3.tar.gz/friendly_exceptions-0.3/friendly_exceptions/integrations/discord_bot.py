"""
Discord.py error handling

Usage:
    from friendly_exceptions.integrations.discord_bot import friendly_discord, explain_discord_error

    # Wrap your bot with friendly errors
    import discord
    from discord.ext import commands

    bot = commands.Bot(command_prefix='!')
    friendly_discord(bot)

    # Now errors have friendly explanations
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


DISCORD_ERRORS = {
    # Authentication
    "invalid_token": ("Invalid bot token", [
        "Check token is correct",
        "Generate new token in Discord Developer Portal",
        "Token may have been reset"
    ]),
    "token_missing": ("Bot token is missing", [
        "Provide token: bot.run('token')",
        "Set DISCORD_TOKEN environment variable",
        "Check token is not empty string"
    ]),

    # Permissions
    "missing_permissions": ("Bot lacks permissions", [
        "Check bot role permissions",
        "Re-invite bot with required permissions",
        "Check channel-specific permissions"
    ]),
    "missing_access": ("Cannot access channel", [
        "Bot cannot see this channel",
        "Check channel permissions",
        "Bot may be banned from server"
    ]),
    "forbidden": ("Action forbidden", [
        "Bot lacks required permissions",
        "Cannot modify higher role users",
        "Check bot's role hierarchy"
    ]),

    # Rate limiting
    "rate_limited": ("Rate limited by Discord", [
        "Slow down requests",
        "Wait before retrying",
        "Check for loops in code"
    ]),

    # HTTP errors
    "not_found": ("Resource not found", [
        "Channel/User/Message may be deleted",
        "Check ID is correct",
        "Resource may be in different server"
    ]),
    "unknown_message": ("Message not found", [
        "Message may be deleted",
        "Message ID may be wrong",
        "Bot cannot see this message"
    ]),
    "unknown_channel": ("Channel not found", [
        "Channel may be deleted",
        "Bot may lack access",
        "Check channel ID"
    ]),
    "unknown_guild": ("Server not found", [
        "Bot may have been kicked",
        "Server may be deleted",
        "Check server ID"
    ]),

    # Message errors
    "message_too_long": ("Message too long", [
        "Max 2000 characters",
        "Split into multiple messages",
        "Use embed or file attachment"
    ]),
    "empty_message": ("Cannot send empty message", [
        "Add content or embed",
        "Check message content",
        "At least one of content/embed/file required"
    ]),
    "invalid_embed": ("Invalid embed", [
        "Check embed field limits",
        "Title max 256 chars",
        "Description max 4096 chars"
    ]),

    # Interaction errors
    "interaction_failed": ("Interaction failed", [
        "Responded too late (>3 seconds)",
        "Interaction may have expired",
        "Check for duplicate responses"
    ]),
    "already_responded": ("Already responded to interaction", [
        "Use followup for additional messages",
        "interaction.followup.send()",
        "Can only respond once"
    ]),

    # Voice errors
    "already_connected": ("Already in voice channel", [
        "Disconnect first: await voice_client.disconnect()",
        "Use existing connection",
        "Check for multiple connect attempts"
    ]),
    "not_connected": ("Not in voice channel", [
        "Connect first: await channel.connect()",
        "Check voice_client exists",
        "Connection may have timed out"
    ]),

    # Command errors
    "command_not_found": ("Command not found", [
        "Check command name spelling",
        "Command may not be registered",
        "Check command prefix"
    ]),
    "missing_required_argument": ("Missing command argument", [
        "Check command usage",
        "Provide required arguments",
        "Use help command for syntax"
    ]),
    "bad_argument": ("Invalid argument", [
        "Check argument type",
        "Provide valid value",
        "Check command documentation"
    ]),
    "cooldown": ("Command on cooldown", [
        "Wait before using again",
        "Check cooldown time",
        "Cooldown per user/channel/server"
    ]),

    # Connection
    "connection_closed": ("WebSocket closed", [
        "Connection lost",
        "Discord may have issues",
        "Bot will auto-reconnect"
    ]),
    "gateway_not_found": ("Cannot find Discord gateway", [
        "Check internet connection",
        "Discord may be down",
        "Try again later"
    ]),
}


def explain_discord_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Discord error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Get HTTP status if available
    status = getattr(error, 'status', None)
    code = getattr(error, 'code', None)

    # Token errors
    if "improper token" in error_str or "invalid token" in error_str or code == 4004:
        msg, suggestions = DISCORD_ERRORS["invalid_token"]
        return f"Discord: {msg}", suggestions

    # Permission errors
    if status == 403 or "forbidden" in error_type.lower():
        if "permission" in error_str:
            msg, suggestions = DISCORD_ERRORS["missing_permissions"]
        else:
            msg, suggestions = DISCORD_ERRORS["forbidden"]
        return f"Discord: {msg}", suggestions

    # Not found errors
    if status == 404 or "notfound" in error_type.lower():
        if "message" in error_str:
            msg, suggestions = DISCORD_ERRORS["unknown_message"]
        elif "channel" in error_str:
            msg, suggestions = DISCORD_ERRORS["unknown_channel"]
        elif "guild" in error_str or "server" in error_str:
            msg, suggestions = DISCORD_ERRORS["unknown_guild"]
        else:
            msg, suggestions = DISCORD_ERRORS["not_found"]
        return f"Discord: {msg}", suggestions

    # Rate limiting
    if status == 429 or "rate" in error_str:
        msg, suggestions = DISCORD_ERRORS["rate_limited"]
        retry_after = getattr(error, 'retry_after', None)
        if retry_after:
            suggestions.insert(0, f"Retry after: {retry_after:.1f} seconds")
        return f"Discord: {msg}", suggestions

    # Message errors
    if "2000" in error_str or "too long" in error_str:
        msg, suggestions = DISCORD_ERRORS["message_too_long"]
        return f"Discord: {msg}", suggestions

    if "empty" in error_str and "message" in error_str:
        msg, suggestions = DISCORD_ERRORS["empty_message"]
        return f"Discord: {msg}", suggestions

    # Command errors
    if "commandnotfound" in error_type.lower():
        msg, suggestions = DISCORD_ERRORS["command_not_found"]
        return f"Discord: {msg}", suggestions

    if "missingrequiredargument" in error_type.lower():
        msg, suggestions = DISCORD_ERRORS["missing_required_argument"]
        param = getattr(error, 'param', None)
        if param:
            suggestions.insert(0, f"Missing: {param.name}")
        return f"Discord: {msg}", suggestions

    if "badargument" in error_type.lower():
        msg, suggestions = DISCORD_ERRORS["bad_argument"]
        return f"Discord: {msg}", suggestions

    if "commandoncooldown" in error_type.lower():
        msg, suggestions = DISCORD_ERRORS["cooldown"]
        retry_after = getattr(error, 'retry_after', None)
        if retry_after:
            suggestions.insert(0, f"Cooldown: {retry_after:.1f} seconds")
        return f"Discord: {msg}", suggestions

    # Interaction errors
    if "interaction" in error_str:
        if "already" in error_str or "responded" in error_str:
            msg, suggestions = DISCORD_ERRORS["already_responded"]
        else:
            msg, suggestions = DISCORD_ERRORS["interaction_failed"]
        return f"Discord: {msg}", suggestions

    # Voice errors
    if "already connected" in error_str:
        msg, suggestions = DISCORD_ERRORS["already_connected"]
        return f"Discord: {msg}", suggestions

    if "not connected" in error_str:
        msg, suggestions = DISCORD_ERRORS["not_connected"]
        return f"Discord: {msg}", suggestions

    # Connection errors
    if "connection" in error_str or "websocket" in error_str:
        msg, suggestions = DISCORD_ERRORS["connection_closed"]
        return f"Discord: {msg}", suggestions

    # Generic HTTP error
    if status:
        msg = f"Discord API Error (HTTP {status})"
        suggestions = [
            f"Error code: {code or 'unknown'}",
            f"Details: {str(error)[:80]}",
            "Check Discord API docs"
        ]
        return msg, suggestions

    # Generic
    msg = f"Discord Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check Discord.py docs",
        "Verify bot permissions"
    ]

    return msg, suggestions


def _print_error(operation: str, message: str, suggestions: list, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ discord.{operation}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_discord(bot, output_file: str = None, lang: str = "en"):
    """
    Add friendly error handling to Discord bot

    Args:
        bot: discord.Client or commands.Bot instance
        output_file: Log errors to file
        lang: Language for messages
    """
    try:
        import discord
        from discord.ext import commands
    except ImportError:
        raise ImportError("discord.py not installed. Run: pip install discord.py")

    @bot.event
    async def on_error(event, *args, **kwargs):
        """Handle general errors"""
        import sys
        error = sys.exc_info()[1]
        if error:
            msg, suggestions = explain_discord_error(error, lang)
            _print_error(f"event.{event}", msg, suggestions, output_file)

    # For commands.Bot
    if hasattr(bot, 'on_command_error'):
        original_error_handler = getattr(bot, '_original_on_command_error', None)

        @bot.event
        async def on_command_error(ctx, error):
            """Handle command errors"""
            # Unwrap the error if needed
            if hasattr(error, 'original'):
                error = error.original

            msg, suggestions = explain_discord_error(error, lang)
            _print_error(f"command.{ctx.command}", msg, suggestions, output_file)

            # Re-raise if there was an original handler
            if original_error_handler:
                await original_error_handler(ctx, error)

    return bot


class FriendlyDiscordClient:
    """Wrapper for discord.Client with friendly errors"""

    def __init__(self, client, output_file: str = None, lang: str = "en"):
        self._client = client
        self._output_file = output_file
        self._lang = lang

        # Set up error handler
        friendly_discord(client, output_file, lang)

    def __getattr__(self, name):
        return getattr(self._client, name)


def create_friendly_bot(
    command_prefix: str = "!",
    output_file: str = None,
    lang: str = "en",
    **kwargs
):
    """
    Create a commands.Bot with friendly error handling

    Args:
        command_prefix: Command prefix
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to commands.Bot

    Returns:
        Configured Bot instance
    """
    try:
        import discord
        from discord.ext import commands
    except ImportError:
        raise ImportError("discord.py not installed. Run: pip install discord.py")

    # Set up intents if not provided
    if 'intents' not in kwargs:
        intents = discord.Intents.default()
        intents.message_content = True
        kwargs['intents'] = intents

    bot = commands.Bot(command_prefix=command_prefix, **kwargs)
    friendly_discord(bot, output_file, lang)

    return bot
