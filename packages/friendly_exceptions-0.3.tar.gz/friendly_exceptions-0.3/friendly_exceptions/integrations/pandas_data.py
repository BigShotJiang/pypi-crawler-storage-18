"""
Pandas error handling

Usage:
    from friendly_exceptions.integrations.pandas_data import friendly_pandas, explain_pandas_error

    # Enable friendly pandas errors
    pd = friendly_pandas()

    # Or use individual functions
    from friendly_exceptions.integrations.pandas_data import read_csv, read_excel, to_csv
"""

from typing import Tuple, List, Optional, Any
from functools import wraps
from datetime import datetime


PANDAS_ERRORS = {
    # File reading errors
    "file_not_found": ("File not found", [
        "Check file path spelling",
        "Use absolute path",
        "Verify file exists: os.path.exists(path)"
    ]),
    "empty_file": ("File is empty", [
        "Check file has data",
        "Verify file was saved correctly",
        "Check file encoding"
    ]),
    "parser_error": ("Cannot parse file", [
        "Check delimiter (comma, tab, semicolon)",
        "Try: pd.read_csv(file, sep=';')",
        "Check for malformed rows"
    ]),
    "encoding_error": ("File encoding error", [
        "Try: encoding='utf-8' or 'latin-1'",
        "Detect encoding: chardet.detect()",
        "Try: encoding='cp1252' for Windows files"
    ]),
    "excel_error": ("Cannot read Excel file", [
        "Install openpyxl: pip install openpyxl",
        "For .xls: pip install xlrd",
        "Check file is not corrupted"
    ]),

    # Column errors
    "key_error": ("Column not found", [
        "Check column name spelling",
        "List columns: df.columns.tolist()",
        "Column names are case-sensitive"
    ]),
    "index_error": ("Invalid index/row", [
        "Index out of range",
        "Use .iloc for integer position",
        "Use .loc for label-based access"
    ]),

    # Data type errors
    "dtype_error": ("Data type error", [
        "Check column data types: df.dtypes",
        "Convert: df['col'].astype(int)",
        "Handle missing values first"
    ]),
    "value_error": ("Invalid value", [
        "Check data format",
        "Handle NaN values: df.fillna()",
        "Check for mixed types in column"
    ]),

    # Merge/Join errors
    "merge_error": ("Merge failed", [
        "Check key columns exist in both DataFrames",
        "Key columns must have same dtype",
        "Try: pd.merge(df1, df2, on='key', how='left')"
    ]),

    # Memory errors
    "memory_error": ("Not enough memory", [
        "Use chunked reading: chunksize=10000",
        "Select only needed columns: usecols=['a','b']",
        "Use dtype to reduce memory: dtype={'col': 'int32'}"
    ]),

    # DateTime errors
    "datetime_error": ("Cannot parse datetime", [
        "Specify format: pd.to_datetime(df['date'], format='%Y-%m-%d')",
        "Handle errors: errors='coerce'",
        "Check date format consistency"
    ]),

    # Aggregation errors
    "agg_error": ("Aggregation error", [
        "Check column exists",
        "Numeric columns only for mean/sum",
        "Use numeric_only=True"
    ]),

    # Shape errors
    "shape_mismatch": ("Shape mismatch", [
        "DataFrames must have compatible shapes",
        "Check: df1.shape, df2.shape",
        "Align indexes: df1.align(df2)"
    ]),
}


def explain_pandas_error(error, operation: str = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Pandas error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # File not found
    if "no such file" in error_str or "file not found" in error_str or "filenotfounderror" in error_type.lower():
        msg, suggestions = PANDAS_ERRORS["file_not_found"]
        return f"Pandas: {msg}", suggestions

    # Empty data
    if "no columns" in error_str or "empty" in error_str:
        msg, suggestions = PANDAS_ERRORS["empty_file"]
        return f"Pandas: {msg}", suggestions

    # Parser error
    if "parser" in error_type.lower() or "tokenizing" in error_str or "expected" in error_str and "fields" in error_str:
        msg, suggestions = PANDAS_ERRORS["parser_error"]
        # Try to extract line number
        if "line" in error_str:
            suggestions.insert(0, f"Error near: {error_str[:80]}")
        return f"Pandas: {msg}", suggestions

    # Encoding error
    if "encoding" in error_str or "codec" in error_str or "decode" in error_str:
        msg, suggestions = PANDAS_ERRORS["encoding_error"]
        return f"Pandas: {msg}", suggestions

    # Excel errors
    if "excel" in error_str or "openpyxl" in error_str or "xlrd" in error_str:
        msg, suggestions = PANDAS_ERRORS["excel_error"]
        return f"Pandas: {msg}", suggestions

    # Key error (column not found)
    if "keyerror" in error_type.lower() or ("key" in error_str and "not in" in error_str):
        msg, suggestions = PANDAS_ERRORS["key_error"]
        # Extract the key
        key_match = str(error).replace("KeyError:", "").strip()[:50]
        suggestions.insert(0, f"Missing column: {key_match}")
        return f"Pandas: {msg}", suggestions

    # Index error
    if "indexerror" in error_type.lower() or "out of bounds" in error_str:
        msg, suggestions = PANDAS_ERRORS["index_error"]
        return f"Pandas: {msg}", suggestions

    # Type errors
    if "typeerror" in error_type.lower():
        if "numeric" in error_str or "float" in error_str or "int" in error_str:
            msg, suggestions = PANDAS_ERRORS["dtype_error"]
        else:
            msg = "Type error in operation"
            suggestions = [
                "Check data types: df.dtypes",
                "Convert types if needed",
                f"Details: {str(error)[:80]}"
            ]
        return f"Pandas: {msg}", suggestions

    # Value errors
    if "valueerror" in error_type.lower():
        if "datetime" in error_str or "time" in error_str:
            msg, suggestions = PANDAS_ERRORS["datetime_error"]
        elif "shape" in error_str or "length" in error_str:
            msg, suggestions = PANDAS_ERRORS["shape_mismatch"]
        else:
            msg, suggestions = PANDAS_ERRORS["value_error"]
        return f"Pandas: {msg}", suggestions

    # Merge errors
    if "merge" in error_str or "join" in error_str:
        msg, suggestions = PANDAS_ERRORS["merge_error"]
        return f"Pandas: {msg}", suggestions

    # Memory errors
    if "memory" in error_str or "memoryerror" in error_type.lower():
        msg, suggestions = PANDAS_ERRORS["memory_error"]
        return f"Pandas: {msg}", suggestions

    # Aggregation errors
    if operation and operation in ['mean', 'sum', 'std', 'var', 'min', 'max']:
        msg, suggestions = PANDAS_ERRORS["agg_error"]
        return f"Pandas: {msg}", suggestions

    # Generic
    msg = f"Pandas Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check DataFrame structure: df.info()",
        "Review pandas documentation"
    ]

    return msg, suggestions


def _print_error(operation: str, message: str, suggestions: list, file_path: str = None, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ pandas.{operation}()",
        f"🔍 {message}",
    ]

    if file_path:
        output.insert(2, f"📁 File: {file_path}")

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


def read_csv(filepath, output_file: str = None, lang: str = "en", **kwargs):
    """Read CSV with friendly errors"""
    try:
        import pandas as pd
        return pd.read_csv(filepath, **kwargs)
    except ImportError:
        raise ImportError("pandas not installed. Run: pip install pandas")
    except Exception as e:
        msg, suggestions = explain_pandas_error(e, "read_csv", lang)
        _print_error("read_csv", msg, suggestions, str(filepath), output_file)
        raise


def read_excel(filepath, output_file: str = None, lang: str = "en", **kwargs):
    """Read Excel with friendly errors"""
    try:
        import pandas as pd
        return pd.read_excel(filepath, **kwargs)
    except ImportError:
        raise ImportError("pandas not installed. Run: pip install pandas")
    except Exception as e:
        msg, suggestions = explain_pandas_error(e, "read_excel", lang)
        _print_error("read_excel", msg, suggestions, str(filepath), output_file)
        raise


def read_json(filepath, output_file: str = None, lang: str = "en", **kwargs):
    """Read JSON with friendly errors"""
    try:
        import pandas as pd
        return pd.read_json(filepath, **kwargs)
    except ImportError:
        raise ImportError("pandas not installed. Run: pip install pandas")
    except Exception as e:
        msg, suggestions = explain_pandas_error(e, "read_json", lang)
        _print_error("read_json", msg, suggestions, str(filepath), output_file)
        raise


def to_csv(df, filepath, output_file: str = None, lang: str = "en", **kwargs):
    """Save DataFrame to CSV with friendly errors"""
    try:
        return df.to_csv(filepath, **kwargs)
    except Exception as e:
        msg, suggestions = explain_pandas_error(e, "to_csv", lang)
        _print_error("to_csv", msg, suggestions, str(filepath), output_file)
        raise


def to_excel(df, filepath, output_file: str = None, lang: str = "en", **kwargs):
    """Save DataFrame to Excel with friendly errors"""
    try:
        return df.to_excel(filepath, **kwargs)
    except Exception as e:
        msg, suggestions = explain_pandas_error(e, "to_excel", lang)
        _print_error("to_excel", msg, suggestions, str(filepath), output_file)
        raise


class FriendlyDataFrame:
    """Wrapper for DataFrame with friendly errors"""

    def __init__(self, df, output_file: str = None, lang: str = "en"):
        self._df = df
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._df, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def __getitem__(self, key):
        try:
            result = self._df[key]
            return result
        except Exception as e:
            msg, suggestions = explain_pandas_error(e, f"df[{repr(key)[:30]}]", self._lang)
            self._print_error(f"df[{repr(key)[:30]}]", msg, suggestions)
            raise

    def __setitem__(self, key, value):
        try:
            self._df[key] = value
        except Exception as e:
            msg, suggestions = explain_pandas_error(e, f"df[{repr(key)[:30]}]=", self._lang)
            self._print_error(f"df[{repr(key)[:30]}]=", msg, suggestions)
            raise

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                result = method(*args, **kwargs)
                # Wrap returned DataFrames
                if hasattr(result, 'iloc') and hasattr(result, 'columns'):
                    return FriendlyDataFrame(result, self._output_file, self._lang)
                return result
            except Exception as e:
                msg, suggestions = explain_pandas_error(e, method_name, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ DataFrame.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    @property
    def values(self):
        return self._df.values

    @property
    def columns(self):
        return self._df.columns

    @property
    def index(self):
        return self._df.index

    @property
    def shape(self):
        return self._df.shape

    @property
    def dtypes(self):
        return self._df.dtypes


def friendly_pandas(output_file: str = None, lang: str = "en"):
    """
    Return pandas module with wrapped read functions

    Usage:
        pd = friendly_pandas()
        df = pd.read_csv("data.csv")
    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError("pandas not installed. Run: pip install pandas")

    class FriendlyPandas:
        def __getattr__(self, name):
            return getattr(pd, name)

        def read_csv(self, *args, **kwargs):
            return read_csv(*args, output_file=output_file, lang=lang, **kwargs)

        def read_excel(self, *args, **kwargs):
            return read_excel(*args, output_file=output_file, lang=lang, **kwargs)

        def read_json(self, *args, **kwargs):
            return read_json(*args, output_file=output_file, lang=lang, **kwargs)

        def DataFrame(self, *args, **kwargs):
            df = pd.DataFrame(*args, **kwargs)
            return FriendlyDataFrame(df, output_file, lang)

    return FriendlyPandas()
