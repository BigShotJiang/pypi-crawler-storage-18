"""
AWS/boto3 error handling

Usage:
    from friendly_exceptions.integrations.aws import friendly_boto3, explain_aws_error

    # Wrap boto3 client
    s3 = friendly_boto3('s3')
    s3.upload_file('file.txt', 'bucket', 'key')

    # Or wrap existing client
    import boto3
    client = boto3.client('s3')
    s3 = friendly_boto3(client=client)
"""

from typing import Optional, Tuple, List, Any
from functools import wraps
from datetime import datetime


AWS_ERRORS = {
    # Auth/Credentials
    "InvalidAccessKeyId": ("Invalid AWS Access Key", [
        "Check AWS_ACCESS_KEY_ID",
        "Key may be deactivated",
        "Generate new key in IAM console"
    ]),
    "SignatureDoesNotMatch": ("Invalid AWS Secret Key", [
        "Check AWS_SECRET_ACCESS_KEY",
        "Keys may be rotated",
        "Check for extra spaces"
    ]),
    "ExpiredToken": ("Session token expired", [
        "Refresh credentials",
        "Get new session token",
        "Check STS token duration"
    ]),
    "AccessDenied": ("Access denied", [
        "Check IAM permissions",
        "Verify resource policy",
        "Check bucket/object ACL"
    ]),
    "UnauthorizedAccess": ("Unauthorized", [
        "Check IAM user/role permissions",
        "Verify AWS region",
        "MFA may be required"
    ]),

    # S3
    "NoSuchBucket": ("Bucket does not exist", [
        "Check bucket name spelling",
        "Bucket may be in different region",
        "Bucket may be deleted"
    ]),
    "NoSuchKey": ("Object does not exist", [
        "Check object key/path",
        "Object may be deleted",
        "Check prefix is correct"
    ]),
    "BucketAlreadyExists": ("Bucket name taken globally", [
        "S3 bucket names are globally unique",
        "Choose different name",
        "Add random suffix"
    ]),
    "BucketNotEmpty": ("Cannot delete non-empty bucket", [
        "Delete all objects first",
        "Use: aws s3 rm s3://bucket --recursive",
        "Check for versioned objects"
    ]),
    "EntityTooLarge": ("File too large for single upload", [
        "Use multipart upload for >5GB",
        "Use upload_fileobj with TransferConfig",
        "Split into smaller parts"
    ]),

    # DynamoDB
    "ResourceNotFoundException": ("Table/resource not found", [
        "Check table name",
        "Table may be in different region",
        "Table may still be creating"
    ]),
    "ProvisionedThroughputExceededException": ("DynamoDB capacity exceeded", [
        "Increase read/write capacity",
        "Switch to on-demand mode",
        "Implement exponential backoff"
    ]),
    "ConditionalCheckFailedException": ("Condition not met", [
        "Item was modified by another request",
        "Check condition expression",
        "Implement retry logic"
    ]),

    # Lambda
    "FunctionNotFound": ("Lambda function not found", [
        "Check function name",
        "Check region",
        "Function may be deleted"
    ]),
    "ResourceConflictException": ("Function update in progress", [
        "Wait for update to complete",
        "Check function state",
        "Retry after delay"
    ]),
    "TooManyRequestsException": ("Lambda throttled", [
        "Reduce invocation rate",
        "Request concurrency limit increase",
        "Implement backoff"
    ]),

    # EC2
    "InvalidInstanceID.NotFound": ("EC2 instance not found", [
        "Check instance ID",
        "Instance may be terminated",
        "Check region"
    ]),
    "InsufficientInstanceCapacity": ("Not enough EC2 capacity", [
        "Try different instance type",
        "Try different AZ",
        "Use Spot Instances"
    ]),

    # SQS
    "QueueDoesNotExist": ("SQS queue not found", [
        "Check queue name/URL",
        "Queue may be in different region",
        "Queue may be deleted"
    ]),
    "QueueDeletedRecently": ("Queue was recently deleted", [
        "Wait 60 seconds",
        "Use different queue name"
    ]),

    # General
    "ThrottlingException": ("Request throttled", [
        "Too many API requests",
        "Implement exponential backoff",
        "Request limit increase"
    ]),
    "ServiceUnavailable": ("AWS service unavailable", [
        "Retry after delay",
        "Check AWS status page",
        "Try different region"
    ]),
    "InternalError": ("AWS internal error", [
        "Retry the request",
        "Check AWS status",
        "Contact AWS support if persists"
    ]),
    "ValidationError": ("Invalid request parameters", [
        "Check parameter values",
        "Review API documentation",
        "Check data types"
    ]),
    "MalformedPolicyDocument": ("Invalid IAM policy", [
        "Check JSON syntax",
        "Validate with IAM policy simulator",
        "Check resource ARNs"
    ]),
}


def explain_aws_error(error, service: str = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze AWS error and return (message, suggestions)"""
    error_str = str(error)
    error_type = type(error).__name__

    # Try to get error code from boto3 exception
    error_code = None
    if hasattr(error, 'response'):
        error_code = error.response.get('Error', {}).get('Code')
        error_message = error.response.get('Error', {}).get('Message', '')
    else:
        error_message = error_str

    # Look up error in our database
    if error_code and error_code in AWS_ERRORS:
        msg, suggestions = AWS_ERRORS[error_code]
        return f"AWS {error_code}: {msg}", suggestions.copy()

    # Try to match by error string
    for code, (msg, suggestions) in AWS_ERRORS.items():
        if code.lower() in error_str.lower():
            return f"AWS {code}: {msg}", suggestions.copy()

    # Generic suggestions based on error content
    suggestions = []
    error_lower = error_str.lower()

    if "credential" in error_lower or "access key" in error_lower:
        msg = "AWS credentials error"
        suggestions = [
            "Check AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY",
            "Run: aws configure",
            "Check ~/.aws/credentials"
        ]
    elif "region" in error_lower:
        msg = "AWS region error"
        suggestions = [
            "Set AWS_DEFAULT_REGION",
            "Specify region in client: boto3.client('s3', region_name='us-east-1')",
            "Check resource exists in this region"
        ]
    elif "timeout" in error_lower:
        msg = "AWS request timeout"
        suggestions = [
            "Check network connection",
            "Increase timeout in config",
            "Try again"
        ]
    elif "endpoint" in error_lower:
        msg = "AWS endpoint error"
        suggestions = [
            "Check service is available in region",
            "Verify endpoint URL",
            "Check VPC endpoint config"
        ]
    else:
        msg = f"AWS Error: {error_code or error_type}"
        suggestions = [
            f"Error: {error_message[:100]}",
            "Check AWS documentation",
            "Check IAM permissions",
            "Verify resource exists"
        ]

    return msg, suggestions


class FriendlyBoto3Client:
    """Wrapper for boto3 client with friendly errors"""

    def __init__(self, client, service_name: str, output_file: str = None, lang: str = "en"):
        self._client = client
        self._service = service_name
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_aws_error(e, self._service, self._lang)
                self._print_error(method_name, msg, suggestions, e)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list, error: Exception):
        output = [
            f"\n{'='*50}",
            f"❌ AWS {self._service}.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_boto3(
    service_name: str = None,
    client=None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
) -> FriendlyBoto3Client:
    """
    Create or wrap boto3 client with friendly error handling

    Args:
        service_name: AWS service ('s3', 'dynamodb', 'lambda', etc.)
        client: Existing boto3 client to wrap
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to boto3.client()

    Returns:
        Wrapped client
    """
    if client is None:
        if service_name is None:
            raise ValueError("Provide service_name or client")

        try:
            import boto3
            client = boto3.client(service_name, **kwargs)
        except ImportError:
            raise ImportError("boto3 not installed. Run: pip install boto3")

    service = service_name or getattr(client, '_service_model', {}).service_name or 'aws'

    return FriendlyBoto3Client(client, service, output_file, lang)
