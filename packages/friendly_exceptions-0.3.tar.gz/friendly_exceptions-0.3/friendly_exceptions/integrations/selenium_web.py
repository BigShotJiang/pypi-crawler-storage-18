"""
Selenium/Playwright error handling

Usage:
    from friendly_exceptions.integrations.selenium_web import friendly_selenium, explain_selenium_error

    # Wrap WebDriver
    from selenium import webdriver
    driver = webdriver.Chrome()
    driver = friendly_selenium(driver)

    # Now errors have friendly explanations
    driver.find_element(By.ID, "nonexistent")
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


SELENIUM_ERRORS = {
    # Element errors
    "element_not_found": ("Element not found", [
        "Check selector is correct",
        "Wait for element: WebDriverWait(driver, 10)",
        "Element may be in iframe",
        "Page may not be fully loaded"
    ]),
    "stale_element": ("Element is stale", [
        "Page was refreshed/changed",
        "Re-find the element",
        "DOM was modified after finding element"
    ]),
    "element_not_interactable": ("Cannot interact with element", [
        "Element may be hidden",
        "Scroll element into view",
        "Wait for element to be clickable",
        "Another element may be covering it"
    ]),
    "element_not_visible": ("Element not visible", [
        "Element is hidden (display:none)",
        "Element is outside viewport",
        "Use execute_script to interact"
    ]),
    "element_click_intercepted": ("Click was intercepted", [
        "Another element is covering it",
        "Scroll to element first",
        "Close popup/modal if present",
        "Use JavaScript click: execute_script('arguments[0].click()', element)"
    ]),

    # Driver errors
    "webdriver_exception": ("WebDriver error", [
        "Check driver is compatible with browser",
        "Update WebDriver to match browser version",
        "Check browser is installed"
    ]),
    "session_not_created": ("Cannot create session", [
        "WebDriver version may not match browser",
        "Browser may have crashed",
        "Check driver executable path"
    ]),
    "invalid_session": ("Session is invalid", [
        "Browser may have closed",
        "Session may have timed out",
        "Create new driver instance"
    ]),

    # Navigation errors
    "timeout": ("Operation timed out", [
        "Page took too long to load",
        "Increase timeout: driver.set_page_load_timeout(30)",
        "Check network connection",
        "Page may be unresponsive"
    ]),
    "invalid_url": ("Invalid URL", [
        "Check URL format",
        "Include protocol: https://",
        "URL may be malformed"
    ]),

    # Frame/Window errors
    "no_such_frame": ("Frame not found", [
        "Check frame name/id",
        "Frame may be dynamically loaded",
        "Wait for frame: WebDriverWait"
    ]),
    "no_such_window": ("Window not found", [
        "Window may be closed",
        "Check window handle is valid",
        "List windows: driver.window_handles"
    ]),

    # Alert errors
    "no_alert_present": ("No alert present", [
        "Alert may not have appeared yet",
        "Wait for alert: WebDriverWait",
        "Alert may have been dismissed"
    ]),
    "unexpected_alert": ("Unexpected alert appeared", [
        "Handle alert: driver.switch_to.alert",
        "Dismiss: alert.dismiss()",
        "Accept: alert.accept()"
    ]),

    # Cookie errors
    "invalid_cookie": ("Invalid cookie", [
        "Check cookie domain",
        "Must be on correct domain to set",
        "Check cookie format"
    ]),

    # Screenshot errors
    "screenshot_failed": ("Cannot take screenshot", [
        "Browser window may be minimized",
        "Check disk space",
        "Verify file path is valid"
    ]),

    # JavaScript errors
    "javascript_error": ("JavaScript execution failed", [
        "Check script syntax",
        "Element may not exist",
        "Script may have runtime error"
    ]),

    # Selector errors
    "invalid_selector": ("Invalid selector", [
        "Check CSS/XPath syntax",
        "Escape special characters",
        "Validate selector in browser console"
    ]),
}


def explain_selenium_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Selenium error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Element not found
    if "nosuchelementexception" in error_type.lower() or "unable to locate" in error_str:
        msg, suggestions = SELENIUM_ERRORS["element_not_found"]
        # Try to extract selector
        if "using" in error_str:
            selector_info = error_str.split("using")[0][-100:]
            suggestions.insert(0, f"Selector: {selector_info.strip()}")
        return f"Selenium: {msg}", suggestions

    # Stale element
    if "staleelementreferenceexception" in error_type.lower() or "stale element" in error_str:
        msg, suggestions = SELENIUM_ERRORS["stale_element"]
        return f"Selenium: {msg}", suggestions

    # Element not interactable
    if "elementnotinteractableexception" in error_type.lower() or "not interactable" in error_str:
        msg, suggestions = SELENIUM_ERRORS["element_not_interactable"]
        return f"Selenium: {msg}", suggestions

    # Element not visible
    if "elementnotvisibleexception" in error_type.lower() or "not visible" in error_str:
        msg, suggestions = SELENIUM_ERRORS["element_not_visible"]
        return f"Selenium: {msg}", suggestions

    # Click intercepted
    if "elementclickinterceptedexception" in error_type.lower() or "click intercepted" in error_str:
        msg, suggestions = SELENIUM_ERRORS["element_click_intercepted"]
        return f"Selenium: {msg}", suggestions

    # Timeout
    if "timeoutexception" in error_type.lower() or "timed out" in error_str:
        msg, suggestions = SELENIUM_ERRORS["timeout"]
        return f"Selenium: {msg}", suggestions

    # Session errors
    if "sessionnotcreatedexception" in error_type.lower():
        msg, suggestions = SELENIUM_ERRORS["session_not_created"]
        return f"Selenium: {msg}", suggestions

    if "invalidsessionidexception" in error_type.lower() or "invalid session" in error_str:
        msg, suggestions = SELENIUM_ERRORS["invalid_session"]
        return f"Selenium: {msg}", suggestions

    # Frame errors
    if "nosuchframeexception" in error_type.lower() or "no such frame" in error_str:
        msg, suggestions = SELENIUM_ERRORS["no_such_frame"]
        return f"Selenium: {msg}", suggestions

    # Window errors
    if "nosuchwindowexception" in error_type.lower() or "no such window" in error_str:
        msg, suggestions = SELENIUM_ERRORS["no_such_window"]
        return f"Selenium: {msg}", suggestions

    # Alert errors
    if "noalertpresentexception" in error_type.lower():
        msg, suggestions = SELENIUM_ERRORS["no_alert_present"]
        return f"Selenium: {msg}", suggestions

    if "unexpectedalertpresentexception" in error_type.lower():
        msg, suggestions = SELENIUM_ERRORS["unexpected_alert"]
        return f"Selenium: {msg}", suggestions

    # Invalid selector
    if "invalidselectorexception" in error_type.lower() or "invalid selector" in error_str:
        msg, suggestions = SELENIUM_ERRORS["invalid_selector"]
        return f"Selenium: {msg}", suggestions

    # JavaScript errors
    if "javascriptexception" in error_type.lower() or "javascript error" in error_str:
        msg, suggestions = SELENIUM_ERRORS["javascript_error"]
        return f"Selenium: {msg}", suggestions

    # WebDriver exception (generic)
    if "webdriverexception" in error_type.lower():
        msg, suggestions = SELENIUM_ERRORS["webdriver_exception"]
        suggestions.insert(0, f"Details: {str(error)[:80]}")
        return f"Selenium: {msg}", suggestions

    # Generic
    msg = f"Selenium Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check element exists on page",
        "Try adding explicit waits"
    ]

    return msg, suggestions


def _print_error(operation: str, message: str, suggestions: list, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ selenium.{operation}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


class FriendlyWebDriver:
    """Wrapper for Selenium WebDriver with friendly errors"""

    def __init__(self, driver, output_file: str = None, lang: str = "en"):
        self._driver = driver
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._driver, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                result = method(*args, **kwargs)
                # Wrap returned WebElements
                if hasattr(result, 'click') and hasattr(result, 'send_keys'):
                    return FriendlyWebElement(result, method_name, self._output_file, self._lang)
                # Wrap lists of elements
                if isinstance(result, list) and len(result) > 0 and hasattr(result[0], 'click'):
                    return [FriendlyWebElement(el, method_name, self._output_file, self._lang) for el in result]
                return result
            except Exception as e:
                msg, suggestions = explain_selenium_error(e, self._lang)
                self._print_error(method_name, msg, suggestions, args)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list, args: tuple = None):
        output = [
            f"\n{'='*50}",
            f"❌ driver.{operation}()",
            f"🔍 {message}",
        ]

        # Add selector info if available
        if args and len(args) >= 2:
            output.insert(2, f"🔍 Selector: {args[0]}={args[1]}")

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    def quit(self):
        """Quit the driver"""
        self._driver.quit()

    def close(self):
        """Close current window"""
        self._driver.close()


class FriendlyWebElement:
    """Wrapper for Selenium WebElement with friendly errors"""

    def __init__(self, element, parent_op: str, output_file: str = None, lang: str = "en"):
        self._element = element
        self._parent_op = parent_op
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._element, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_selenium_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ element.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)


def friendly_selenium(driver, output_file: str = None, lang: str = "en") -> FriendlyWebDriver:
    """
    Wrap Selenium WebDriver with friendly error handling

    Args:
        driver: WebDriver instance
        output_file: Log errors to file
        lang: Language for messages

    Returns:
        Wrapped WebDriver
    """
    return FriendlyWebDriver(driver, output_file, lang)


def create_friendly_driver(
    browser: str = "chrome",
    headless: bool = False,
    output_file: str = None,
    lang: str = "en",
    **kwargs
) -> FriendlyWebDriver:
    """
    Create a WebDriver with friendly error handling

    Args:
        browser: Browser name (chrome, firefox, edge)
        headless: Run in headless mode
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to WebDriver

    Returns:
        Wrapped WebDriver
    """
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options as ChromeOptions
        from selenium.webdriver.firefox.options import Options as FirefoxOptions
    except ImportError:
        raise ImportError("selenium not installed. Run: pip install selenium")

    browser = browser.lower()

    if browser == "chrome":
        options = ChromeOptions()
        if headless:
            options.add_argument("--headless")
        driver = webdriver.Chrome(options=options, **kwargs)
    elif browser == "firefox":
        options = FirefoxOptions()
        if headless:
            options.add_argument("--headless")
        driver = webdriver.Firefox(options=options, **kwargs)
    elif browser == "edge":
        from selenium.webdriver.edge.options import Options as EdgeOptions
        options = EdgeOptions()
        if headless:
            options.add_argument("--headless")
        driver = webdriver.Edge(options=options, **kwargs)
    else:
        raise ValueError(f"Unsupported browser: {browser}. Use: chrome, firefox, edge")

    return FriendlyWebDriver(driver, output_file, lang)
