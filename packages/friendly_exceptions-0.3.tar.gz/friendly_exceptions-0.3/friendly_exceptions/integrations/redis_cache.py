"""
Redis error handling

Usage:
    from friendly_exceptions.integrations.redis_cache import friendly_redis, explain_redis_error

    # Wrap Redis client
    r = friendly_redis(host='localhost', port=6379)
    r.get('key')

    # Or wrap existing client
    import redis
    client = redis.Redis()
    r = friendly_redis(client=client)
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


REDIS_ERRORS = {
    # Connection errors
    "connection_refused": ("Cannot connect to Redis", [
        "Check Redis is running: redis-cli ping",
        "Verify host and port",
        "Check firewall settings"
    ]),
    "connection_reset": ("Redis connection reset", [
        "Server closed connection",
        "Check Redis logs",
        "Increase timeout settings"
    ]),
    "timeout": ("Redis operation timeout", [
        "Server may be overloaded",
        "Increase socket_timeout",
        "Check network latency"
    ]),

    # Auth errors
    "noauth": ("Authentication required", [
        "Provide password: Redis(password='...')",
        "Check requirepass in redis.conf",
        "Verify password is correct"
    ]),
    "wrongpass": ("Invalid password", [
        "Check Redis password",
        "Password may have changed",
        "Check redis.conf requirepass"
    ]),
    "noperm": ("No permission", [
        "User lacks required permissions",
        "Check ACL configuration",
        "Use different user/password"
    ]),

    # Memory errors
    "oom": ("Redis out of memory", [
        "Increase maxmemory in redis.conf",
        "Enable eviction policy",
        "Delete unused keys",
        "Check memory usage: INFO memory"
    ]),

    # Data errors
    "wrongtype": ("Wrong data type for operation", [
        "Key exists with different type",
        "Use TYPE key to check type",
        "Delete key or use correct command"
    ]),
    "busykey": ("Key already exists", [
        "Use NX/XX options",
        "Delete existing key first",
        "Use different key name"
    ]),

    # Cluster errors
    "moved": ("Key moved to different node", [
        "Use cluster-aware client",
        "Enable cluster mode: Redis(cluster=True)",
        "Reconnect to correct node"
    ]),
    "ask": ("Key migrating to different node", [
        "Retry after redirect",
        "Cluster is rebalancing",
        "Wait for migration to complete"
    ]),
    "clusterdown": ("Redis cluster is down", [
        "Not enough master nodes",
        "Check cluster status: CLUSTER INFO",
        "Some slots are not covered"
    ]),

    # Lua script errors
    "noscript": ("Lua script not cached", [
        "Script was flushed",
        "Use EVAL instead of EVALSHA",
        "Re-register script with SCRIPT LOAD"
    ]),

    # Transaction errors
    "execabort": ("Transaction aborted", [
        "Error in queued command",
        "Check all commands in MULTI block",
        "Start new transaction"
    ]),

    # Replication
    "readonly": ("Cannot write to replica", [
        "Connect to master node",
        "Replica is read-only",
        "Check cluster configuration"
    ]),
    "masterdown": ("Master is down", [
        "Waiting for failover",
        "Check Sentinel status",
        "Master may be recovering"
    ]),
}


def explain_redis_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Redis error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Check for known error patterns
    for key, (msg, suggestions) in REDIS_ERRORS.items():
        if key in error_str:
            return f"Redis: {msg}", suggestions.copy()

    # Connection errors
    if "connection" in error_str or "connect" in error_type.lower():
        if "refused" in error_str:
            return REDIS_ERRORS["connection_refused"][0], REDIS_ERRORS["connection_refused"][1].copy()
        elif "reset" in error_str:
            return REDIS_ERRORS["connection_reset"][0], REDIS_ERRORS["connection_reset"][1].copy()
        else:
            msg = "Redis connection error"
            suggestions = [
                "Check Redis is running",
                "Verify connection parameters",
                "Check network connectivity"
            ]

    # Timeout
    elif "timeout" in error_str or "timed out" in error_str:
        return REDIS_ERRORS["timeout"][0], REDIS_ERRORS["timeout"][1].copy()

    # Auth
    elif "auth" in error_str or "password" in error_str:
        msg = "Redis authentication error"
        suggestions = [
            "Check password is correct",
            "Verify AUTH is configured",
            "Check redis.conf"
        ]

    # Response errors
    elif "response" in error_str:
        msg = "Invalid Redis response"
        suggestions = [
            "Server returned unexpected data",
            "Check Redis version compatibility",
            "Connection may be corrupted"
        ]

    # Data errors
    elif "encoding" in error_str or "decode" in error_str:
        msg = "Redis encoding error"
        suggestions = [
            "Set decode_responses=True for strings",
            "Or handle bytes: value.decode('utf-8')",
            "Check data encoding"
        ]

    else:
        msg = f"Redis Error: {error_type}"
        suggestions = [
            f"Details: {str(error)[:100]}",
            "Check Redis logs",
            "Verify Redis is running correctly"
        ]

    return msg, suggestions


class FriendlyRedis:
    """Wrapper for Redis client with friendly errors"""

    def __init__(self, client, output_file: str = None, lang: str = "en"):
        self._client = client
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_redis_error(e, self._lang)
                self._print_error(method_name, msg, suggestions, args)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list, args: tuple):
        # Show key if it's a key operation
        key_info = ""
        if args and isinstance(args[0], (str, bytes)):
            key = args[0] if isinstance(args[0], str) else args[0].decode('utf-8', errors='replace')
            key_info = f"\n🔑 Key: {key[:50]}"

        output = [
            f"\n{'='*50}",
            f"❌ redis.{operation}()",
            f"🔍 {message}",
        ]

        if key_info:
            output.insert(2, key_info)

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    def pipeline(self, transaction: bool = True):
        """Return wrapped pipeline"""
        pipe = self._client.pipeline(transaction=transaction)
        return FriendlyRedisPipeline(pipe, self._output_file, self._lang)


class FriendlyRedisPipeline:
    """Wrapper for Redis pipeline with friendly errors"""

    def __init__(self, pipeline, output_file: str = None, lang: str = "en"):
        self._pipeline = pipeline
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._pipeline, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_redis_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ redis.pipeline.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


def friendly_redis(
    host: str = 'localhost',
    port: int = 6379,
    db: int = 0,
    password: str = None,
    client=None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
) -> FriendlyRedis:
    """
    Create or wrap Redis client with friendly error handling

    Args:
        host: Redis host
        port: Redis port
        db: Database number
        password: Redis password
        client: Existing Redis client to wrap
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to Redis()

    Returns:
        Wrapped Redis client
    """
    if client is None:
        try:
            import redis
            client = redis.Redis(
                host=host,
                port=port,
                db=db,
                password=password,
                **kwargs
            )
        except ImportError:
            raise ImportError("redis not installed. Run: pip install redis")

    return FriendlyRedis(client, output_file, lang)
