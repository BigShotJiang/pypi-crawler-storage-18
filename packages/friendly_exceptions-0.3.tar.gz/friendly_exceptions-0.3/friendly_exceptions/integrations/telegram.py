"""
Telegram Bot API error handling with friendly_exceptions

Usage:
    # With python-telegram-bot:
    from friendly_exceptions.integrations.telegram import friendly_telegram_bot

    app = Application.builder().token("TOKEN").build()
    friendly_telegram_bot(app, output_file="bot_errors.txt")

    # With aiogram:
    from friendly_exceptions.integrations.telegram import friendly_aiogram

    dp = Dispatcher()
    friendly_aiogram(dp, output_file="bot_errors.txt")

    # Manual error handling:
    from friendly_exceptions.integrations.telegram import explain_telegram_error

    try:
        await bot.send_message(...)
    except Exception as e:
        msg, suggestions = explain_telegram_error(e)
"""

from typing import Optional, Callable
from datetime import datetime
from functools import wraps


# Error explanations
ERROR_MESSAGES = {
    "unauthorized": {
        "en": "Invalid bot token. Check your token from @BotFather",
        "ru": "Неверный токен бота. Проверьте токен от @BotFather"
    },
    "forbidden": {
        "en": "Bot was blocked by user or lacks permissions",
        "ru": "Бот заблокирован пользователем или нет прав"
    },
    "chat_not_found": {
        "en": "Chat not found. User may have deleted chat or never started bot",
        "ru": "Чат не найден. Пользователь удалил чат или не запускал бота"
    },
    "message_not_found": {
        "en": "Message not found. It may have been deleted",
        "ru": "Сообщение не найдено. Возможно, оно было удалено"
    },
    "rate_limit": {
        "en": "Too many requests. Telegram limits: 30 msg/sec to chats, 20 msg/min to groups",
        "ru": "Слишком много запросов. Лимиты: 30 сообщ/сек в чаты, 20 сообщ/мин в группы"
    },
    "flood_wait": {
        "en": "Flood control triggered. Wait before sending more messages",
        "ru": "Сработала защита от флуда. Подождите перед отправкой"
    },
    "message_too_long": {
        "en": "Message too long. Max 4096 characters",
        "ru": "Сообщение слишком длинное. Максимум 4096 символов"
    },
    "file_too_large": {
        "en": "File too large. Max 50MB for bots",
        "ru": "Файл слишком большой. Максимум 50MB для ботов"
    },
    "invalid_file": {
        "en": "Invalid file or file_id",
        "ru": "Неверный файл или file_id"
    },
    "network": {
        "en": "Network error connecting to Telegram",
        "ru": "Ошибка сети при подключении к Telegram"
    },
    "webhook": {
        "en": "Webhook error. Check URL and SSL certificate",
        "ru": "Ошибка webhook. Проверьте URL и SSL сертификат"
    },
    "parse_mode": {
        "en": "Invalid message format. Check Markdown/HTML syntax",
        "ru": "Неверный формат сообщения. Проверьте синтаксис Markdown/HTML"
    },
    "button_data": {
        "en": "Invalid callback data. Max 64 bytes",
        "ru": "Неверные данные кнопки. Максимум 64 байта"
    },
    "rights": {
        "en": "Bot lacks required permissions in this chat",
        "ru": "У бота нет нужных прав в этом чате"
    },
    "kicked": {
        "en": "Bot was kicked from the chat",
        "ru": "Бот удалён из чата"
    },
}


def get_message(key: str, lang: str = "en") -> str:
    """Get error message in specified language"""
    msgs = ERROR_MESSAGES.get(key, {})
    return msgs.get(lang, msgs.get("en", key))


def explain_telegram_error(error, lang: str = "en") -> tuple:
    """
    Analyze Telegram error and return (message, suggestions)
    """
    error_str = str(error).lower()
    error_type = type(error).__name__

    suggestions = []

    # Unauthorized (401)
    if "unauthorized" in error_str or "401" in error_str:
        msg = get_message("unauthorized", lang)
        suggestions = [
            "Get token from @BotFather",
            "Check token format: 123456789:ABC...",
            "Regenerate token if compromised"
        ]

    # Forbidden (403)
    elif "forbidden" in error_str or "403" in error_str:
        if "block" in error_str:
            msg = get_message("forbidden", lang)
            suggestions = [
                "User blocked the bot",
                "Handle blocked users gracefully",
                "Remove user from active list"
            ]
        elif "kick" in error_str:
            msg = get_message("kicked", lang)
            suggestions = [
                "Bot was removed from chat",
                "Handle kicked events",
                "User needs to add bot again"
            ]
        elif "right" in error_str or "permission" in error_str:
            msg = get_message("rights", lang)
            suggestions = [
                "Make bot admin with required rights",
                "Check chat permissions",
                "Request needed permissions"
            ]
        else:
            msg = get_message("forbidden", lang)
            suggestions = ["Check bot permissions", "User may have blocked bot"]

    # Not found (400/404)
    elif "chat not found" in error_str or "chat_not_found" in error_str:
        msg = get_message("chat_not_found", lang)
        suggestions = [
            "User must /start bot first",
            "Check chat_id is correct",
            "Chat may have been deleted"
        ]

    elif "message" in error_str and "not found" in error_str:
        msg = get_message("message_not_found", lang)
        suggestions = [
            "Message was deleted",
            "message_id is incorrect",
            "Store message IDs if needed"
        ]

    # Rate limiting
    elif "too many" in error_str or "rate" in error_str or "429" in error_str:
        msg = get_message("rate_limit", lang)
        suggestions = [
            "Add delays between messages",
            "Use message queuing",
            "Batch messages when possible"
        ]

    elif "flood" in error_str or "retry after" in error_str:
        msg = get_message("flood_wait", lang)
        # Try to extract wait time
        import re
        match = re.search(r'(\d+)', error_str)
        wait_time = match.group(1) if match else "some"
        suggestions = [
            f"Wait {wait_time} seconds",
            "Implement exponential backoff",
            "Queue messages properly"
        ]

    # Message issues
    elif "too long" in error_str or "message is too long" in error_str:
        msg = get_message("message_too_long", lang)
        suggestions = [
            "Split message into parts",
            "Max 4096 chars per message",
            "Use send_document for large text"
        ]

    elif "can't parse" in error_str or "parse" in error_str:
        msg = get_message("parse_mode", lang)
        suggestions = [
            "Escape special characters: _ * [ ] ( ) ~ ` > # + - = | { } . !",
            "Use parse_mode=None for plain text",
            "Validate Markdown/HTML before sending"
        ]

    # File issues
    elif "file" in error_str and ("large" in error_str or "big" in error_str or "size" in error_str):
        msg = get_message("file_too_large", lang)
        suggestions = [
            "Max 50MB for bots",
            "Compress file or split it",
            "Use external hosting for large files"
        ]

    elif "file" in error_str and ("invalid" in error_str or "not found" in error_str):
        msg = get_message("invalid_file", lang)
        suggestions = [
            "Check file path exists",
            "file_id may be expired",
            "Re-upload the file"
        ]

    # Callback data
    elif "callback" in error_str and "data" in error_str:
        msg = get_message("button_data", lang)
        suggestions = [
            "Max 64 bytes for callback_data",
            "Use short codes, store data elsewhere",
            "Encode data efficiently"
        ]

    # Webhook
    elif "webhook" in error_str:
        msg = get_message("webhook", lang)
        suggestions = [
            "Check URL is HTTPS",
            "Verify SSL certificate",
            "Port must be 443, 80, 88, or 8443"
        ]

    # Network
    elif "network" in error_str or "connect" in error_str or "timeout" in error_str:
        msg = get_message("network", lang)
        suggestions = [
            "Check internet connection",
            "Telegram may be blocked (use proxy)",
            "Increase timeout value"
        ]

    else:
        msg = f"Telegram Error: {error}"
        suggestions = [
            "Check Telegram Bot API docs",
            "Verify request parameters",
            "Check @BotFather settings"
        ]

    return msg, suggestions


class TelegramErrorHandler:
    """Mixin for handling Telegram errors"""

    def __init__(self, output_file: str = None, lang: str = "en"):
        self.output_file = output_file
        self.lang = lang

    def handle_error(self, error, context=None):
        msg, suggestions = explain_telegram_error(error, self.lang)

        output = [
            f"\n{'='*50}",
            f"❌ Telegram Error: {type(error).__name__}",
        ]

        if context:
            if hasattr(context, 'chat') and context.chat:
                output.append(f"📍 Chat: {context.chat.id}")
            if hasattr(context, 'user') and context.user:
                output.append(f"👤 User: {context.user.id}")

        output.extend([
            f"💬 {error}",
            f"🔍 {msg}",
        ])

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self.output_file:
            with open(self.output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_telegram_bot(app, output_file: str = None, lang: str = "en"):
    """
    Add friendly error handling to python-telegram-bot Application

    Usage:
        from telegram.ext import Application
        from friendly_exceptions.integrations.telegram import friendly_telegram_bot

        app = Application.builder().token("TOKEN").build()
        friendly_telegram_bot(app, output_file="errors.txt")
    """
    handler = TelegramErrorHandler(output_file, lang)

    async def error_handler(update, context):
        handler.handle_error(context.error, update)

    app.add_error_handler(error_handler)
    return app


def friendly_aiogram(dp, output_file: str = None, lang: str = "en"):
    """
    Add friendly error handling to aiogram Dispatcher

    Usage:
        from aiogram import Dispatcher
        from friendly_exceptions.integrations.telegram import friendly_aiogram

        dp = Dispatcher()
        friendly_aiogram(dp, output_file="errors.txt")
    """
    handler = TelegramErrorHandler(output_file, lang)

    @dp.errors()
    async def error_handler(event, exception):
        handler.handle_error(exception, event)
        return True

    return dp


def wrap_telegram_call(func: Callable, output_file: str = None, lang: str = "en"):
    """
    Decorator for wrapping individual Telegram API calls

    Usage:
        @wrap_telegram_call
        async def send_message(bot, chat_id, text):
            return await bot.send_message(chat_id, text)
    """
    handler = TelegramErrorHandler(output_file, lang)

    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            handler.handle_error(e)
            raise

    return wrapper
