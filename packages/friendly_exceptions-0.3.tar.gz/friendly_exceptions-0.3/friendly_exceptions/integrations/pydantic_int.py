"""
Pydantic Integration - Friendly validation error messages

Pydantic raises ValidationError with detailed info but hard to read.
This integration makes validation errors human-friendly.

Usage:
    import friendly_exceptions.integrations.pydantic_int

    from pydantic import BaseModel

    class User(BaseModel):
        name: str
        age: int
        email: str

    # Now validation errors are friendly!
    user = User(name=123, age="old", email="invalid")
"""

import sys
from typing import Dict, Any, List, Optional

PYDANTIC_ERRORS = {
    # Type errors
    "type_error.none.not_allowed": {
        "en": "Field '{field}' cannot be None - a value is required",
        "ru": "Поле '{field}' не может быть None - требуется значение",
    },
    "type_error.str": {
        "en": "Field '{field}' must be a string, got {input_type}",
        "ru": "Поле '{field}' должно быть строкой, получено {input_type}",
    },
    "type_error.int": {
        "en": "Field '{field}' must be an integer, got {input_type}",
        "ru": "Поле '{field}' должно быть целым числом, получено {input_type}",
    },
    "type_error.float": {
        "en": "Field '{field}' must be a number, got {input_type}",
        "ru": "Поле '{field}' должно быть числом, получено {input_type}",
    },
    "type_error.bool": {
        "en": "Field '{field}' must be true or false, got {input_type}",
        "ru": "Поле '{field}' должно быть true или false, получено {input_type}",
    },
    "type_error.list": {
        "en": "Field '{field}' must be a list, got {input_type}",
        "ru": "Поле '{field}' должно быть списком, получено {input_type}",
    },
    "type_error.dict": {
        "en": "Field '{field}' must be a dictionary, got {input_type}",
        "ru": "Поле '{field}' должно быть словарём, получено {input_type}",
    },

    # Value errors
    "value_error.missing": {
        "en": "Field '{field}' is required but was not provided",
        "ru": "Поле '{field}' обязательное, но не было передано",
    },
    "value_error.extra": {
        "en": "Extra field '{field}' is not allowed in this model",
        "ru": "Лишнее поле '{field}' не разрешено в этой модели",
    },
    "value_error.const": {
        "en": "Field '{field}' must be exactly '{expected}'",
        "ru": "Поле '{field}' должно быть равно '{expected}'",
    },
    "value_error.email": {
        "en": "Field '{field}' is not a valid email address: '{value}'",
        "ru": "Поле '{field}' не является email адресом: '{value}'",
    },
    "value_error.url": {
        "en": "Field '{field}' is not a valid URL: '{value}'",
        "ru": "Поле '{field}' не является URL адресом: '{value}'",
    },
    "value_error.uuid": {
        "en": "Field '{field}' is not a valid UUID: '{value}'",
        "ru": "Поле '{field}' не является UUID: '{value}'",
    },
    "value_error.date": {
        "en": "Field '{field}' is not a valid date: '{value}'",
        "ru": "Поле '{field}' не является датой: '{value}'",
    },
    "value_error.datetime": {
        "en": "Field '{field}' is not a valid datetime: '{value}'",
        "ru": "Поле '{field}' не является датой/временем: '{value}'",
    },
    "value_error.time": {
        "en": "Field '{field}' is not a valid time: '{value}'",
        "ru": "Поле '{field}' не является временем: '{value}'",
    },
    "value_error.json": {
        "en": "Field '{field}' contains invalid JSON",
        "ru": "Поле '{field}' содержит невалидный JSON",
    },

    # Number constraints
    "value_error.number.not_gt": {
        "en": "Field '{field}' must be greater than {limit}, got {value}",
        "ru": "Поле '{field}' должно быть больше {limit}, получено {value}",
    },
    "value_error.number.not_ge": {
        "en": "Field '{field}' must be >= {limit}, got {value}",
        "ru": "Поле '{field}' должно быть >= {limit}, получено {value}",
    },
    "value_error.number.not_lt": {
        "en": "Field '{field}' must be less than {limit}, got {value}",
        "ru": "Поле '{field}' должно быть меньше {limit}, получено {value}",
    },
    "value_error.number.not_le": {
        "en": "Field '{field}' must be <= {limit}, got {value}",
        "ru": "Поле '{field}' должно быть <= {limit}, получено {value}",
    },
    "value_error.number.not_multiple": {
        "en": "Field '{field}' must be a multiple of {multiple_of}",
        "ru": "Поле '{field}' должно быть кратно {multiple_of}",
    },

    # String constraints
    "value_error.any_str.min_length": {
        "en": "Field '{field}' must have at least {limit} characters, got {length}",
        "ru": "Поле '{field}' должно содержать минимум {limit} символов, получено {length}",
    },
    "value_error.any_str.max_length": {
        "en": "Field '{field}' must have at most {limit} characters, got {length}",
        "ru": "Поле '{field}' должно содержать максимум {limit} символов, получено {length}",
    },
    "value_error.str.regex": {
        "en": "Field '{field}' doesn't match required pattern",
        "ru": "Поле '{field}' не соответствует требуемому формату",
    },

    # List constraints
    "value_error.list.min_items": {
        "en": "Field '{field}' must have at least {limit} items, got {length}",
        "ru": "Поле '{field}' должно содержать минимум {limit} элементов, получено {length}",
    },
    "value_error.list.max_items": {
        "en": "Field '{field}' must have at most {limit} items, got {length}",
        "ru": "Поле '{field}' должно содержать максимум {limit} элементов, получено {length}",
    },
    "value_error.list.unique_items": {
        "en": "Field '{field}' contains duplicate items",
        "ru": "Поле '{field}' содержит дубликаты",
    },

    # Enum
    "type_error.enum": {
        "en": "Field '{field}' must be one of: {allowed}",
        "ru": "Поле '{field}' должно быть одним из: {allowed}",
    },

    # Generic
    "value_error": {
        "en": "Invalid value for field '{field}': {msg}",
        "ru": "Неверное значение поля '{field}': {msg}",
    },
    "type_error": {
        "en": "Wrong type for field '{field}': expected {expected}, got {input_type}",
        "ru": "Неверный тип поля '{field}': ожидалось {expected}, получено {input_type}",
    },
}


def get_lang() -> str:
    """Get current language"""
    try:
        from ..i18n import get_language
        return get_language()
    except:
        return "en"


def format_pydantic_error(error: Dict[str, Any], model_name: str = "") -> str:
    """Format single pydantic error"""
    lang = get_lang()

    error_type = error.get("type", "")
    loc = error.get("loc", ())
    msg = error.get("msg", "")
    ctx = error.get("ctx", {})

    # Build field path
    field = " -> ".join(str(x) for x in loc) if loc else "root"

    # Get input value info
    input_value = error.get("input", None)
    input_type = type(input_value).__name__ if input_value is not None else "None"

    # Find matching error template
    template_data = None

    # Try exact match first
    if error_type in PYDANTIC_ERRORS:
        template_data = PYDANTIC_ERRORS[error_type]
    else:
        # Try prefix match
        for key in PYDANTIC_ERRORS:
            if error_type.startswith(key):
                template_data = PYDANTIC_ERRORS[key]
                break

    if template_data:
        template = template_data.get(lang, template_data.get("en", ""))

        # Prepare format kwargs
        format_kwargs = {
            "field": field,
            "value": str(input_value)[:50] if input_value else "",
            "input_type": input_type,
            "msg": msg,
            **ctx
        }

        try:
            return template.format(**format_kwargs)
        except KeyError:
            pass

    # Fallback to original message
    return f"{field}: {msg}"


def format_validation_error(exc) -> str:
    """Format ValidationError with all errors"""
    lang = get_lang()

    try:
        errors = exc.errors()
    except:
        return str(exc)

    model_name = ""
    try:
        model_name = exc.model.__name__
    except:
        pass

    if not errors:
        return str(exc)

    # Format header
    if lang == "ru":
        header = f"Ошибка валидации{' в ' + model_name if model_name else ''}: {len(errors)} проблем(а)"
    else:
        header = f"Validation error{' in ' + model_name if model_name else ''}: {len(errors)} problem(s)"

    lines = [header, ""]

    for i, error in enumerate(errors, 1):
        formatted = format_pydantic_error(error, model_name)
        lines.append(f"  {i}. {formatted}")

    # Add hint
    lines.append("")
    if lang == "ru":
        lines.append("Проверьте типы данных и обязательные поля")
    else:
        lines.append("Check data types and required fields")

    return "\n".join(lines)


class PydanticExceptionHandler:
    """Exception handler for Pydantic errors"""

    def __init__(self, original_hook=None):
        self.original_hook = original_hook
        self._validation_error = None
        self._load_pydantic()

    def _load_pydantic(self):
        """Load pydantic ValidationError class"""
        try:
            # Pydantic v2
            from pydantic import ValidationError
            self._validation_error = ValidationError
        except ImportError:
            try:
                # Pydantic v1
                from pydantic.error_wrappers import ValidationError
                self._validation_error = ValidationError
            except ImportError:
                pass

    def __call__(self, exc_type, exc_value, exc_tb):
        if self._validation_error and isinstance(exc_value, self._validation_error):
            # Format friendly message
            friendly_msg = format_validation_error(exc_value)
            print(f"\n{friendly_msg}\n", file=sys.stderr)

        # Call original hook
        if self.original_hook:
            self.original_hook(exc_type, exc_value, exc_tb)
        else:
            sys.__excepthook__(exc_type, exc_value, exc_tb)


def install():
    """Install Pydantic exception handler"""
    sys.excepthook = PydanticExceptionHandler(sys.excepthook)


# Auto-install on import
install()
