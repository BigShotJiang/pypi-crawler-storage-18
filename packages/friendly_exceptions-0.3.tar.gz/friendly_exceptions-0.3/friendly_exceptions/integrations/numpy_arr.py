"""
NumPy error handling

Usage:
    from friendly_exceptions.integrations.numpy_arr import explain_numpy_error, friendly_numpy

    # Use wrapper decorator
    @friendly_numpy
    def my_function():
        import numpy as np
        return np.array([1, 2]) + np.array([1, 2, 3])  # Shape mismatch
"""

from typing import Tuple, List
from functools import wraps
from datetime import datetime


NUMPY_ERRORS = {
    # Shape errors
    "shape_mismatch": ("Array shapes do not match", [
        "Check array shapes: arr.shape",
        "Use broadcasting or reshape",
        "Reshape: arr.reshape(new_shape)"
    ]),
    "broadcast_error": ("Cannot broadcast arrays", [
        "Shapes must be compatible for broadcasting",
        "Check dimensions: arr.shape",
        "Use np.expand_dims() to add dimensions"
    ]),

    # Index errors
    "index_out_of_bounds": ("Index out of bounds", [
        "Check array size: arr.size",
        "Index must be < array length",
        "Use negative indexing for end: arr[-1]"
    ]),
    "index_error": ("Invalid index", [
        "Check index type and value",
        "Use integer or slice",
        "For multiple indices use tuple"
    ]),

    # Type errors
    "dtype_error": ("Data type error", [
        "Check array dtype: arr.dtype",
        "Convert: arr.astype(np.float64)",
        "Specify dtype: np.array(data, dtype=np.int32)"
    ]),
    "casting_error": ("Cannot cast array", [
        "Incompatible data types",
        "Use casting='unsafe' to force",
        "Check for NaN or inf values"
    ]),

    # Value errors
    "invalid_value": ("Invalid value encountered", [
        "Check for NaN: np.isnan(arr).any()",
        "Check for inf: np.isinf(arr).any()",
        "Handle with np.nan_to_num()"
    ]),
    "empty_array": ("Cannot operate on empty array", [
        "Array has no elements",
        "Check array size before operation",
        "Initialize with default value"
    ]),

    # Math errors
    "division_by_zero": ("Division by zero", [
        "Array contains zero values",
        "Use np.divide with where parameter",
        "Handle zeros: np.where(arr!=0, 1/arr, 0)"
    ]),
    "overflow": ("Numeric overflow", [
        "Value too large for dtype",
        "Use larger dtype: np.float64",
        "Scale your data"
    ]),
    "underflow": ("Numeric underflow", [
        "Value too small for dtype",
        "Use higher precision dtype",
        "Check for near-zero divisions"
    ]),

    # Linear algebra
    "singular_matrix": ("Singular matrix", [
        "Matrix is not invertible",
        "Check determinant: np.linalg.det()",
        "Use pseudo-inverse: np.linalg.pinv()"
    ]),
    "not_square": ("Matrix must be square", [
        "Operation requires square matrix",
        "Check shape: matrix.shape",
        "Reshape or pad matrix"
    ]),
    "eigenvalue_error": ("Eigenvalue computation failed", [
        "Matrix may be ill-conditioned",
        "Check for NaN values",
        "Try using scipy.linalg instead"
    ]),

    # Memory
    "memory_error": ("Not enough memory", [
        "Array too large for available RAM",
        "Use smaller dtype: np.float32",
        "Process in chunks",
        "Use memory-mapped files: np.memmap"
    ]),

    # File I/O
    "file_not_found": ("File not found", [
        "Check file path",
        "Use absolute path",
        "Verify file exists"
    ]),
    "file_format": ("Invalid file format", [
        "Check file is valid numpy format",
        "For .npy use np.load()",
        "For text use np.loadtxt()"
    ]),
}


def explain_numpy_error(error, operation: str = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze NumPy error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Shape mismatch
    if "shape" in error_str and ("mismatch" in error_str or "not aligned" in error_str):
        msg, suggestions = NUMPY_ERRORS["shape_mismatch"]
        return f"NumPy: {msg}", suggestions

    # Broadcast error
    if "broadcast" in error_str or "could not be broadcast" in error_str:
        msg, suggestions = NUMPY_ERRORS["broadcast_error"]
        return f"NumPy: {msg}", suggestions

    # Index out of bounds
    if "index" in error_str and ("out of bounds" in error_str or "out of range" in error_str):
        msg, suggestions = NUMPY_ERRORS["index_out_of_bounds"]
        return f"NumPy: {msg}", suggestions

    # Invalid index
    if "indexerror" in error_type.lower():
        msg, suggestions = NUMPY_ERRORS["index_error"]
        return f"NumPy: {msg}", suggestions

    # Division by zero
    if "divide by zero" in error_str or "division by zero" in error_str:
        msg, suggestions = NUMPY_ERRORS["division_by_zero"]
        return f"NumPy: {msg}", suggestions

    # Invalid value (nan, inf)
    if "invalid value" in error_str or ("nan" in error_str and "encountered" in error_str):
        msg, suggestions = NUMPY_ERRORS["invalid_value"]
        return f"NumPy: {msg}", suggestions

    # Overflow
    if "overflow" in error_str:
        msg, suggestions = NUMPY_ERRORS["overflow"]
        return f"NumPy: {msg}", suggestions

    # Singular matrix
    if "singular" in error_str or "not invertible" in error_str:
        msg, suggestions = NUMPY_ERRORS["singular_matrix"]
        return f"NumPy: {msg}", suggestions

    # Not square matrix
    if "square" in error_str and "matrix" in error_str:
        msg, suggestions = NUMPY_ERRORS["not_square"]
        return f"NumPy: {msg}", suggestions

    # Type/casting errors
    if "cannot cast" in error_str or "casting" in error_str:
        msg, suggestions = NUMPY_ERRORS["casting_error"]
        return f"NumPy: {msg}", suggestions

    if "typeerror" in error_type.lower() or "dtype" in error_str:
        msg, suggestions = NUMPY_ERRORS["dtype_error"]
        return f"NumPy: {msg}", suggestions

    # Empty array
    if "empty" in error_str or "zero-size" in error_str:
        msg, suggestions = NUMPY_ERRORS["empty_array"]
        return f"NumPy: {msg}", suggestions

    # Memory error
    if "memoryerror" in error_type.lower() or "memory" in error_str:
        msg, suggestions = NUMPY_ERRORS["memory_error"]
        return f"NumPy: {msg}", suggestions

    # File errors
    if "no such file" in error_str or "file not found" in error_str:
        msg, suggestions = NUMPY_ERRORS["file_not_found"]
        return f"NumPy: {msg}", suggestions

    if "unpickle" in error_str or "magic" in error_str:
        msg, suggestions = NUMPY_ERRORS["file_format"]
        return f"NumPy: {msg}", suggestions

    # Eigenvalue
    if "eigenvalue" in error_str or "eigenvector" in error_str:
        msg, suggestions = NUMPY_ERRORS["eigenvalue_error"]
        return f"NumPy: {msg}", suggestions

    # Value error (generic)
    if "valueerror" in error_type.lower():
        msg = "Invalid value or parameter"
        suggestions = [
            f"Details: {str(error)[:80]}",
            "Check input data and parameters",
            "Verify array shapes and dtypes"
        ]
        return f"NumPy: {msg}", suggestions

    # Generic
    msg = f"NumPy Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check array shapes: arr.shape",
        "Check data types: arr.dtype"
    ]

    return msg, suggestions


def _print_error(operation: str, message: str, suggestions: list, output_file: str = None):
    output = [
        f"\n{'='*50}",
        f"❌ numpy.{operation}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions[:5]:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_numpy(func=None, output_file: str = None, lang: str = "en"):
    """
    Decorator to add friendly error handling to numpy operations

    Usage:
        @friendly_numpy
        def calculate():
            return np.array([1,2]) / 0

        # Or with parameters
        @friendly_numpy(output_file="errors.txt")
        def calculate():
            ...
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except Exception as e:
                # Check if it's a numpy-related error
                error_module = getattr(type(e), '__module__', '')
                if 'numpy' in error_module or 'numpy' in str(e).lower():
                    msg, suggestions = explain_numpy_error(e, f.__name__, lang)
                    _print_error(f.__name__, msg, suggestions, output_file)
                raise
        return wrapper

    if func is not None:
        return decorator(func)
    return decorator


def safe_divide(a, b, fill_value=0, output_file: str = None):
    """
    Safe division that handles zeros

    Args:
        a: Numerator array
        b: Denominator array
        fill_value: Value to use where b is zero
    """
    try:
        import numpy as np
        return np.divide(a, b, out=np.full_like(a, fill_value, dtype=float), where=b!=0)
    except Exception as e:
        msg, suggestions = explain_numpy_error(e, "safe_divide")
        _print_error("safe_divide", msg, suggestions, output_file)
        raise


def safe_log(arr, min_value=1e-10, output_file: str = None):
    """
    Safe logarithm that handles zeros and negative values

    Args:
        arr: Input array
        min_value: Minimum value to clamp to
    """
    try:
        import numpy as np
        clipped = np.clip(arr, min_value, None)
        return np.log(clipped)
    except Exception as e:
        msg, suggestions = explain_numpy_error(e, "safe_log")
        _print_error("safe_log", msg, suggestions, output_file)
        raise


def safe_sqrt(arr, output_file: str = None):
    """
    Safe square root that handles negative values

    Args:
        arr: Input array
    """
    try:
        import numpy as np
        return np.sqrt(np.maximum(arr, 0))
    except Exception as e:
        msg, suggestions = explain_numpy_error(e, "safe_sqrt")
        _print_error("safe_sqrt", msg, suggestions, output_file)
        raise


def check_array(arr, name: str = "array", output_file: str = None) -> bool:
    """
    Check array for common issues and print warnings

    Args:
        arr: Array to check
        name: Name for error messages

    Returns:
        True if array is valid, False otherwise
    """
    try:
        import numpy as np

        issues = []

        if arr.size == 0:
            issues.append("Array is empty")

        if np.isnan(arr).any():
            nan_count = np.isnan(arr).sum()
            issues.append(f"Contains {nan_count} NaN values")

        if np.isinf(arr).any():
            inf_count = np.isinf(arr).sum()
            issues.append(f"Contains {inf_count} infinite values")

        if issues:
            output = [
                f"\n{'='*50}",
                f"⚠️  Array '{name}' has issues:",
            ]
            for issue in issues:
                output.append(f"   • {issue}")
            output.append(f"Shape: {arr.shape}, dtype: {arr.dtype}")
            output.append(f"{'='*50}\n")

            text = '\n'.join(output)
            print(text)

            if output_file:
                with open(output_file, 'a', encoding='utf-8') as f:
                    f.write(f"[{datetime.now()}]\n{text}\n")

            return False

        return True

    except Exception as e:
        msg, suggestions = explain_numpy_error(e, "check_array")
        _print_error("check_array", msg, suggestions, output_file)
        return False
