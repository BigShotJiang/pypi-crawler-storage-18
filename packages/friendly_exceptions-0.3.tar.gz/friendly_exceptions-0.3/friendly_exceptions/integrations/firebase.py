"""
Firebase error handling

Usage:
    from friendly_exceptions.integrations.firebase import explain_firebase_error

    # Wrap Firebase operations
    from friendly_exceptions.integrations.firebase import friendly_firestore, friendly_auth

    db = friendly_firestore()
    auth = friendly_auth()
"""

from typing import Tuple, List
from datetime import datetime


FIREBASE_ERRORS = {
    # Auth errors
    "auth/invalid-email": ("Invalid email format", [
        "Check email format: user@example.com",
        "Remove spaces from email"
    ]),
    "auth/user-not-found": ("User not found", [
        "Email is not registered",
        "Check email spelling",
        "User may have been deleted"
    ]),
    "auth/wrong-password": ("Incorrect password", [
        "Check password spelling",
        "Use 'Forgot Password' to reset"
    ]),
    "auth/email-already-in-use": ("Email already registered", [
        "User with this email exists",
        "Try logging in instead",
        "Use password reset"
    ]),
    "auth/weak-password": ("Password too weak", [
        "Use at least 6 characters",
        "Add numbers and symbols",
        "Avoid common passwords"
    ]),
    "auth/invalid-credential": ("Invalid credentials", [
        "Check email and password",
        "Credentials may be expired",
        "Try logging in again"
    ]),
    "auth/user-disabled": ("Account disabled", [
        "Contact administrator",
        "Account may be suspended"
    ]),
    "auth/too-many-requests": ("Too many attempts", [
        "Wait before trying again",
        "Account temporarily locked",
        "Try again in a few minutes"
    ]),
    "auth/requires-recent-login": ("Re-authentication required", [
        "Log out and log in again",
        "For sensitive operations",
        "Use reauthenticateWithCredential()"
    ]),
    "auth/invalid-api-key": ("Invalid Firebase API key", [
        "Check Firebase config",
        "API key may be restricted",
        "Generate new key in console"
    ]),
    "auth/network-request-failed": ("Network error", [
        "Check internet connection",
        "Firebase may be blocked",
        "Try again"
    ]),

    # Firestore errors
    "permission-denied": ("Permission denied", [
        "Check Firestore security rules",
        "User may not be authenticated",
        "Check document path permissions"
    ]),
    "not-found": ("Document not found", [
        "Check document path",
        "Document may be deleted",
        "Check collection name"
    ]),
    "already-exists": ("Document already exists", [
        "Use update() instead of create()",
        "Or use set() with merge option"
    ]),
    "resource-exhausted": ("Quota exceeded", [
        "Check Firebase usage limits",
        "Upgrade plan if needed",
        "Optimize queries"
    ]),
    "failed-precondition": ("Precondition failed", [
        "Index may be required",
        "Check console for index link",
        "Transaction conflict"
    ]),
    "aborted": ("Operation aborted", [
        "Transaction conflict",
        "Retry the operation",
        "Reduce concurrent writes"
    ]),
    "unavailable": ("Service unavailable", [
        "Firebase may be down",
        "Check status.firebase.google.com",
        "Retry with backoff"
    ]),
    "deadline-exceeded": ("Operation timeout", [
        "Query took too long",
        "Add indexes",
        "Reduce data size"
    ]),
    "invalid-argument": ("Invalid argument", [
        "Check query parameters",
        "Field types may be wrong",
        "Review Firestore docs"
    ]),

    # Storage errors
    "storage/unauthorized": ("Storage access denied", [
        "Check Storage security rules",
        "User not authenticated",
        "Check file path"
    ]),
    "storage/object-not-found": ("File not found", [
        "Check file path",
        "File may be deleted",
        "Check bucket name"
    ]),
    "storage/bucket-not-found": ("Bucket not found", [
        "Check bucket name",
        "Bucket may not exist",
        "Check Firebase project"
    ]),
    "storage/quota-exceeded": ("Storage quota exceeded", [
        "Delete unused files",
        "Upgrade Firebase plan",
        "Check storage usage"
    ]),
    "storage/retry-limit-exceeded": ("Upload failed", [
        "Network issues",
        "Try again",
        "Check file size"
    ]),
}


def explain_firebase_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze Firebase error and return (message, suggestions)"""
    error_str = str(error)
    error_type = type(error).__name__

    # Try to extract error code
    code = None
    if hasattr(error, 'code'):
        code = error.code

    # Search for code in error string
    if code is None:
        for key in FIREBASE_ERRORS.keys():
            if key in error_str:
                code = key
                break

    if code and code in FIREBASE_ERRORS:
        msg, suggestions = FIREBASE_ERRORS[code]
        return f"Firebase: {msg}", suggestions.copy()

    # Categorize by error content
    error_lower = error_str.lower()
    suggestions = []

    if "permission" in error_lower or "denied" in error_lower:
        msg = "Firebase permission denied"
        suggestions = [
            "Check security rules in Firebase Console",
            "Ensure user is authenticated",
            "Review rules at /firestore.rules"
        ]
    elif "network" in error_lower or "connect" in error_lower:
        msg = "Firebase connection error"
        suggestions = [
            "Check internet connection",
            "Firebase servers may be down",
            "Check firewall settings"
        ]
    elif "quota" in error_lower or "limit" in error_lower:
        msg = "Firebase quota/limit exceeded"
        suggestions = [
            "Check usage in Firebase Console",
            "Upgrade your plan",
            "Optimize data usage"
        ]
    elif "auth" in error_lower:
        msg = "Firebase authentication error"
        suggestions = [
            "Check credentials",
            "User may not exist",
            "Re-authenticate user"
        ]
    else:
        msg = f"Firebase Error: {code or error_type}"
        suggestions = [
            f"Details: {error_str[:100]}",
            "Check Firebase Console",
            "Review Firebase documentation"
        ]

    return msg, suggestions


def _create_wrapper(service_name: str, output_file: str = None, lang: str = "en"):
    """Create a wrapper class for Firebase service"""

    class FirebaseWrapper:
        def __init__(self, service):
            self._service = service
            self._output_file = output_file
            self._lang = lang
            self._name = service_name

        def __getattr__(self, name):
            attr = getattr(self._service, name)
            if callable(attr):
                return self._wrap_method(attr, name)
            return attr

        def _wrap_method(self, method, method_name):
            def wrapper(*args, **kwargs):
                try:
                    return method(*args, **kwargs)
                except Exception as e:
                    msg, suggestions = explain_firebase_error(e, self._lang)
                    self._print_error(method_name, msg, suggestions)
                    raise
            return wrapper

        def _print_error(self, operation, message, suggestions):
            output = [
                f"\n{'='*50}",
                f"❌ firebase.{self._name}.{operation}()",
                f"🔍 {message}",
            ]
            if suggestions:
                output.append("💡 Suggestions:")
                for s in suggestions[:5]:
                    output.append(f"   • {s}")
            output.append(f"{'='*50}\n")

            text = '\n'.join(output)
            print(text)

            if self._output_file:
                with open(self._output_file, 'a') as f:
                    f.write(f"[{datetime.now()}]\n{text}\n")

    return FirebaseWrapper


def friendly_firestore(db=None, output_file: str = None, lang: str = "en"):
    """Wrap Firestore client with friendly errors"""
    if db is None:
        try:
            import firebase_admin
            from firebase_admin import firestore
            db = firestore.client()
        except ImportError:
            raise ImportError("firebase-admin not installed. Run: pip install firebase-admin")

    Wrapper = _create_wrapper("firestore", output_file, lang)
    return Wrapper(db)


def friendly_auth(auth=None, output_file: str = None, lang: str = "en"):
    """Wrap Firebase Auth with friendly errors"""
    if auth is None:
        try:
            from firebase_admin import auth
        except ImportError:
            raise ImportError("firebase-admin not installed. Run: pip install firebase-admin")

    Wrapper = _create_wrapper("auth", output_file, lang)
    return Wrapper(auth)


def friendly_storage(bucket=None, output_file: str = None, lang: str = "en"):
    """Wrap Firebase Storage with friendly errors"""
    if bucket is None:
        try:
            from firebase_admin import storage
            bucket = storage.bucket()
        except ImportError:
            raise ImportError("firebase-admin not installed. Run: pip install firebase-admin")

    Wrapper = _create_wrapper("storage", output_file, lang)
    return Wrapper(bucket)
