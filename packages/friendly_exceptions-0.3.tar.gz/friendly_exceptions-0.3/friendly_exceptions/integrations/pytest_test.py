"""
Pytest error handling and improved output

Usage:
    # In conftest.py:
    from friendly_exceptions.integrations.pytest_test import friendly_pytest
    friendly_pytest()

    # Or use as plugin
    pytest -p friendly_exceptions.integrations.pytest_test
"""

from typing import Tuple, List, Optional
from datetime import datetime
import sys


PYTEST_ERRORS = {
    # Assertion errors
    "assertion": ("Assertion failed", [
        "Check expected vs actual values",
        "Verify test data",
        "Check comparison logic"
    ]),

    # Import/Module errors
    "import_error": ("Cannot import module", [
        "Check module is installed",
        "Verify import path",
        "Check PYTHONPATH"
    ]),
    "module_not_found": ("Module not found", [
        "Install missing package",
        "Check package name",
        "Verify virtual environment"
    ]),

    # Fixture errors
    "fixture_not_found": ("Fixture not found", [
        "Check fixture name spelling",
        "Ensure fixture is in conftest.py",
        "Check fixture scope"
    ]),
    "fixture_error": ("Fixture raised an error", [
        "Check fixture implementation",
        "Verify fixture dependencies",
        "Check fixture parameters"
    ]),

    # Collection errors
    "collection_error": ("Cannot collect tests", [
        "Check test file syntax",
        "Verify test function names (test_*)",
        "Check for import errors"
    ]),

    # Timeout
    "timeout": ("Test timed out", [
        "Test took too long",
        "Check for infinite loops",
        "Increase timeout limit"
    ]),

    # Markers
    "marker_error": ("Invalid marker", [
        "Register custom markers in pytest.ini",
        "Check marker spelling",
        "Use @pytest.mark.skip for skipping"
    ]),

    # Parametrize
    "parametrize_error": ("Parametrize error", [
        "Check parameter count matches",
        "Verify parameter types",
        "Check parameter names"
    ]),

    # Skip/XFail
    "skip": ("Test skipped", [
        "Intentionally skipped",
        "Check skip condition"
    ]),
    "xfail": ("Expected failure", [
        "Test is expected to fail",
        "Check xfail condition"
    ]),

    # Database/External
    "connection_error": ("External service error", [
        "Check service is running",
        "Verify connection settings",
        "Use mocking for unit tests"
    ]),
}


def explain_pytest_error(error, test_name: str = None, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze pytest error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Assertion errors
    if "assertionerror" in error_type.lower() or "assert" in error_str:
        msg = "Assertion failed"
        suggestions = []

        # Try to parse assertion message
        if "==" in str(error):
            suggestions.append("Values are not equal")
        elif "!=" in str(error):
            suggestions.append("Values should not be equal")
        elif "in" in str(error):
            suggestions.append("Value not found in collection")
        elif "is" in str(error):
            suggestions.append("Objects are not identical")
        elif ">" in str(error) or "<" in str(error):
            suggestions.append("Comparison failed")

        suggestions.extend([
            "Check expected vs actual values",
            "Print values to debug: print(actual)"
        ])

        return f"Test: {msg}", suggestions

    # Import errors
    if "importerror" in error_type.lower() or "modulenotfounderror" in error_type.lower():
        msg, suggestions = PYTEST_ERRORS["import_error"]
        return f"Test: {msg}", suggestions

    # Fixture errors
    if "fixture" in error_str:
        if "not found" in error_str:
            msg, suggestions = PYTEST_ERRORS["fixture_not_found"]
        else:
            msg, suggestions = PYTEST_ERRORS["fixture_error"]
        return f"Test: {msg}", suggestions

    # Timeout
    if "timeout" in error_str or "timedout" in error_type.lower():
        msg, suggestions = PYTEST_ERRORS["timeout"]
        return f"Test: {msg}", suggestions

    # Parametrize
    if "parametrize" in error_str or "parameter" in error_str:
        msg, suggestions = PYTEST_ERRORS["parametrize_error"]
        return f"Test: {msg}", suggestions

    # Type errors in tests
    if "typeerror" in error_type.lower():
        msg = "Type error in test"
        suggestions = [
            "Check argument types",
            "Verify mock return values",
            f"Details: {str(error)[:80]}"
        ]
        return f"Test: {msg}", suggestions

    # Attribute errors
    if "attributeerror" in error_type.lower():
        msg = "Attribute not found"
        suggestions = [
            "Object doesn't have this attribute",
            "Check mock setup",
            "Verify object type",
            f"Details: {str(error)[:80]}"
        ]
        return f"Test: {msg}", suggestions

    # Key errors
    if "keyerror" in error_type.lower():
        msg = "Key not found"
        suggestions = [
            "Dictionary key doesn't exist",
            "Check test data",
            "Verify response structure",
            f"Missing key: {str(error)[:50]}"
        ]
        return f"Test: {msg}", suggestions

    # Connection errors
    if "connection" in error_str or "socket" in error_str:
        msg, suggestions = PYTEST_ERRORS["connection_error"]
        return f"Test: {msg}", suggestions

    # Generic
    msg = f"Test Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check test implementation",
        "Run with -v for more details"
    ]

    return msg, suggestions


def format_friendly_failure(report, call) -> str:
    """Format test failure in friendly way"""
    lines = []
    lines.append(f"\n{'='*60}")
    lines.append(f"❌ FAILED: {report.nodeid}")
    lines.append(f"{'='*60}")

    # Get the exception
    if hasattr(call, 'excinfo') and call.excinfo:
        exc_type = call.excinfo.typename
        exc_value = str(call.excinfo.value)

        msg, suggestions = explain_pytest_error(call.excinfo.value, report.nodeid)

        lines.append(f"\n🔍 {msg}")
        lines.append(f"   {exc_type}: {exc_value[:200]}")

        if suggestions:
            lines.append("\n💡 Suggestions:")
            for s in suggestions[:5]:
                lines.append(f"   • {s}")

        # Show where it failed
        if hasattr(call.excinfo, 'traceback') and call.excinfo.traceback:
            tb = call.excinfo.traceback[-1]
            lines.append(f"\n📍 Location: {tb.path}:{tb.lineno}")

            # Show the failing line
            try:
                if hasattr(tb, 'statement'):
                    lines.append(f"   Code: {str(tb.statement).strip()}")
            except:
                pass

    lines.append(f"\n{'='*60}\n")

    return '\n'.join(lines)


class FriendlyPytestPlugin:
    """Pytest plugin for friendly error messages"""

    def __init__(self, output_file: str = None, lang: str = "en"):
        self.output_file = output_file
        self.lang = lang
        self.failures = []

    def pytest_runtest_makereport(self, item, call):
        """Called after each test phase (setup, call, teardown)"""
        if call.when == "call" and call.excinfo:
            # Store failure info
            self.failures.append({
                'test': item.nodeid,
                'exception': call.excinfo,
                'duration': call.duration
            })

    def pytest_runtest_logreport(self, report):
        """Called to log test report"""
        if report.when == "call" and report.failed:
            # Get the call info
            if hasattr(report, 'longrepr'):
                # Print friendly message
                try:
                    # Extract exception from report
                    if hasattr(report.longrepr, 'reprcrash'):
                        exc_msg = report.longrepr.reprcrash.message
                        msg, suggestions = explain_pytest_error(
                            Exception(exc_msg),
                            report.nodeid,
                            self.lang
                        )

                        output = [
                            f"\n{'='*50}",
                            f"❌ {report.nodeid}",
                            f"🔍 {msg}",
                        ]

                        if suggestions:
                            output.append("💡 Suggestions:")
                            for s in suggestions[:4]:
                                output.append(f"   • {s}")

                        output.append(f"{'='*50}")
                        print('\n'.join(output))

                        if self.output_file:
                            with open(self.output_file, 'a', encoding='utf-8') as f:
                                f.write(f"[{datetime.now()}]\n{chr(10).join(output)}\n")
                except:
                    pass

    def pytest_sessionfinish(self, session, exitstatus):
        """Called at end of test session"""
        if self.failures:
            print(f"\n{'='*50}")
            print(f"📊 Test Summary: {len(self.failures)} failures")
            print(f"{'='*50}")

            for fail in self.failures[:10]:
                print(f"  ❌ {fail['test']}")

            if len(self.failures) > 10:
                print(f"  ... and {len(self.failures) - 10} more")

            print("")


def friendly_pytest(output_file: str = None, lang: str = "en"):
    """
    Register friendly pytest plugin

    Usage in conftest.py:
        from friendly_exceptions.integrations.pytest_test import friendly_pytest
        friendly_pytest()
    """
    try:
        import pytest
    except ImportError:
        raise ImportError("pytest not installed. Run: pip install pytest")

    plugin = FriendlyPytestPlugin(output_file, lang)

    # Register plugin
    try:
        import _pytest.config
        if hasattr(_pytest.config, '_prepareconfig'):
            # For pytest >= 7
            pass
    except:
        pass

    return plugin


# Pytest plugin entry point
def pytest_configure(config):
    """Pytest hook to configure plugin"""
    plugin = FriendlyPytestPlugin()
    config.pluginmanager.register(plugin, "friendly_exceptions")
