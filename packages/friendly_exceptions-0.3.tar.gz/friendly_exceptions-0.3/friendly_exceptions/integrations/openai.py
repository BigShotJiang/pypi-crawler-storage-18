"""
OpenAI API error handling with friendly_exceptions

Usage:
    from friendly_exceptions.integrations.openai import friendly_openai

    client = friendly_openai(api_key="sk-...")
    # or wrap existing client:
    client = friendly_openai(client=existing_client)

    # Now all errors are friendly:
    response = client.chat.completions.create(...)
"""

from typing import Optional, Any, Callable
from datetime import datetime
from functools import wraps


# Error explanations
ERROR_MESSAGES = {
    "invalid_api_key": {
        "en": "Invalid API key. Check your OpenAI API key at platform.openai.com",
        "ru": "Неверный API ключ. Проверьте ваш ключ на platform.openai.com"
    },
    "rate_limit": {
        "en": "Rate limit exceeded. Wait a moment or upgrade your plan",
        "ru": "Превышен лимит запросов. Подождите или обновите тариф"
    },
    "quota_exceeded": {
        "en": "Quota exceeded. Check billing at platform.openai.com/account/billing",
        "ru": "Квота исчерпана. Проверьте биллинг на platform.openai.com/account/billing"
    },
    "model_not_found": {
        "en": "Model not found. Check model name or your access level",
        "ru": "Модель не найдена. Проверьте название или уровень доступа"
    },
    "context_length": {
        "en": "Context too long. Reduce message length or use a model with larger context",
        "ru": "Контекст слишком длинный. Сократите сообщение или используйте модель с большим контекстом"
    },
    "timeout": {
        "en": "Request timed out. Try again or check your connection",
        "ru": "Таймаут запроса. Попробуйте снова или проверьте соединение"
    },
    "connection": {
        "en": "Connection error. Check your internet connection",
        "ru": "Ошибка соединения. Проверьте интернет"
    },
    "server_error": {
        "en": "OpenAI server error. Try again later",
        "ru": "Ошибка сервера OpenAI. Попробуйте позже"
    },
    "content_filter": {
        "en": "Content was filtered by OpenAI's safety system",
        "ru": "Контент заблокирован системой безопасности OpenAI"
    },
}


def get_message(key: str, lang: str = "en") -> str:
    """Get error message in specified language"""
    msgs = ERROR_MESSAGES.get(key, {})
    return msgs.get(lang, msgs.get("en", key))


class FriendlyOpenAIError(Exception):
    """Friendly wrapper for OpenAI errors"""

    def __init__(self, original_error, friendly_message: str, suggestions: list = None):
        self.original_error = original_error
        self.friendly_message = friendly_message
        self.suggestions = suggestions or []
        super().__init__(friendly_message)


def explain_openai_error(error, lang: str = "en") -> tuple:
    """
    Analyze OpenAI error and return (message, suggestions)
    """
    error_str = str(error).lower()
    error_type = type(error).__name__

    suggestions = []

    # API Key errors
    if "invalid_api_key" in error_str or "invalid api key" in error_str or "incorrect api key" in error_str:
        msg = get_message("invalid_api_key", lang)
        suggestions = [
            "export OPENAI_API_KEY='sk-...'",
            "Check key starts with 'sk-'",
            "Generate new key at platform.openai.com/api-keys"
        ]

    # Rate limit
    elif "rate_limit" in error_str or "rate limit" in error_str or "too many requests" in error_str:
        msg = get_message("rate_limit", lang)
        suggestions = [
            "Wait 20-60 seconds",
            "Add retry logic with exponential backoff",
            "Upgrade plan at platform.openai.com"
        ]

    # Quota exceeded
    elif "quota" in error_str or "billing" in error_str or "insufficient" in error_str:
        msg = get_message("quota_exceeded", lang)
        suggestions = [
            "Add payment method at platform.openai.com",
            "Check usage limits",
            "Set up usage alerts"
        ]

    # Model not found
    elif "model" in error_str and ("not found" in error_str or "does not exist" in error_str):
        msg = get_message("model_not_found", lang)
        suggestions = [
            "Use 'gpt-4o' or 'gpt-4o-mini'",
            "Check model access in your account",
            "List models: client.models.list()"
        ]

    # Context length
    elif "context" in error_str or "maximum" in error_str and "token" in error_str:
        msg = get_message("context_length", lang)
        suggestions = [
            "Shorten your messages",
            "Use 'gpt-4o' (128k context)",
            "Implement chunking/summarization"
        ]

    # Timeout
    elif "timeout" in error_str or "timed out" in error_str:
        msg = get_message("timeout", lang)
        suggestions = [
            "Increase timeout: client.timeout = 60",
            "Use streaming for long responses",
            "Check network latency"
        ]

    # Connection errors
    elif "connection" in error_str or "network" in error_str or "unreachable" in error_str:
        msg = get_message("connection", lang)
        suggestions = [
            "Check internet connection",
            "Check proxy/firewall settings",
            "Try: ping api.openai.com"
        ]

    # Content filter
    elif "content" in error_str and ("filter" in error_str or "policy" in error_str or "safety" in error_str):
        msg = get_message("content_filter", lang)
        suggestions = [
            "Modify your prompt",
            "Remove potentially harmful content",
            "Use system prompt for context"
        ]

    # Server errors
    elif "500" in error_str or "502" in error_str or "503" in error_str or "server" in error_str:
        msg = get_message("server_error", lang)
        suggestions = [
            "Wait and retry",
            "Check status.openai.com",
            "Implement retry logic"
        ]

    else:
        msg = f"OpenAI Error: {error}"
        suggestions = [
            "Check OpenAI documentation",
            "Verify request parameters",
            "Check status.openai.com"
        ]

    return msg, suggestions


class OpenAIErrorHandler:
    """Wrapper that catches and explains OpenAI errors"""

    def __init__(self, client, output_file: str = None, lang: str = "en", raise_friendly: bool = False):
        self._client = client
        self._output_file = output_file
        self._lang = lang
        self._raise_friendly = raise_friendly

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        if callable(attr):
            return self._wrap_callable(attr)
        elif hasattr(attr, '__class__') and not isinstance(attr, (str, int, float, bool, type(None))):
            # Wrap nested objects (like client.chat.completions)
            return OpenAIErrorHandler(attr, self._output_file, self._lang, self._raise_friendly)
        return attr

    def _wrap_callable(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                self._handle_error(e)
                raise
        return wrapper

    def _handle_error(self, error):
        msg, suggestions = explain_openai_error(error, self._lang)

        output = [
            f"\n{'='*50}",
            f"❌ OpenAI Error: {type(error).__name__}",
            f"💬 {error}",
            f"🔍 {msg}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

        if self._raise_friendly:
            raise FriendlyOpenAIError(error, msg, suggestions)


def friendly_openai(
    client=None,
    api_key: str = None,
    output_file: str = None,
    lang: str = "en",
    raise_friendly: bool = False
):
    """
    Create or wrap OpenAI client with friendly error handling

    Args:
        client: Existing OpenAI client to wrap
        api_key: API key (if creating new client)
        output_file: File to log errors to
        lang: Language for messages (en, ru)
        raise_friendly: Raise FriendlyOpenAIError instead of original

    Returns:
        Wrapped OpenAI client
    """
    if client is None:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key) if api_key else OpenAI()
        except ImportError:
            raise ImportError("openai not installed. Run: pip install openai")

    return OpenAIErrorHandler(client, output_file, lang, raise_friendly)
