"""
Pillow (PIL) error handling with friendly_exceptions

Usage:
    from friendly_exceptions.integrations.pillow import open_image, save_image

    # Open with friendly errors
    img = open_image("photo.jpg")

    # Save with format detection and error handling
    save_image(img, "output.png")

    # Wrap existing PIL operations
    from friendly_exceptions.integrations.pillow import friendly_pil

    @friendly_pil
    def process_image(path):
        img = Image.open(path)
        return img.resize((100, 100))
"""

import os
from pathlib import Path
from typing import Optional, Tuple, Union, Callable
from functools import wraps


# Supported formats
IMAGE_FORMATS = {
    '.jpg': 'JPEG',
    '.jpeg': 'JPEG',
    '.png': 'PNG',
    '.gif': 'GIF',
    '.bmp': 'BMP',
    '.webp': 'WEBP',
    '.tiff': 'TIFF',
    '.tif': 'TIFF',
    '.ico': 'ICO',
    '.pdf': 'PDF',
}

ERROR_MESSAGES = {
    "not_found": {
        "en": "Image file not found",
        "ru": "Файл изображения не найден"
    },
    "not_image": {
        "en": "File is not a valid image",
        "ru": "Файл не является изображением"
    },
    "corrupted": {
        "en": "Image file is corrupted",
        "ru": "Файл изображения повреждён"
    },
    "permission": {
        "en": "Permission denied accessing image",
        "ru": "Нет доступа к файлу изображения"
    },
    "format": {
        "en": "Unsupported image format",
        "ru": "Неподдерживаемый формат изображения"
    },
    "memory": {
        "en": "Image too large, not enough memory",
        "ru": "Изображение слишком большое, недостаточно памяти"
    },
    "save": {
        "en": "Cannot save image",
        "ru": "Не удалось сохранить изображение"
    },
    "mode": {
        "en": "Invalid image mode for this operation",
        "ru": "Неверный режим изображения для этой операции"
    },
}


class ImageError(Exception):
    """Friendly image processing error"""

    def __init__(self, message: str, suggestions: list = None, original: Exception = None):
        self.suggestions = suggestions or []
        self.original = original
        super().__init__(message)


def get_message(key: str, lang: str = "en") -> str:
    msgs = ERROR_MESSAGES.get(key, {})
    return msgs.get(lang, msgs.get("en", key))


def explain_pil_error(error, filepath: str = None, lang: str = "en") -> Tuple[str, list]:
    """Analyze PIL error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__
    suggestions = []

    # File not found
    if "no such file" in error_str or "not found" in error_str or error_type == "FileNotFoundError":
        msg = get_message("not_found", lang)
        suggestions = [
            f"Check path: {filepath}" if filepath else "Check file path",
            "Use absolute path",
            "Verify file exists: os.path.exists(path)"
        ]

    # Not an image / can't identify
    elif "cannot identify" in error_str or "not identified" in error_str:
        msg = get_message("not_image", lang)
        ext = Path(filepath).suffix.lower() if filepath else ""
        suggestions = [
            "Check file is actually an image",
            "File may be corrupted",
            "Try opening with different library",
        ]
        if ext and ext not in IMAGE_FORMATS:
            suggestions.insert(0, f"Extension '{ext}' may not be supported")

    # Corrupted / truncated
    elif "truncated" in error_str or "corrupt" in error_str or "broken" in error_str:
        msg = get_message("corrupted", lang)
        suggestions = [
            "Re-download the image",
            "Try: from PIL import ImageFile; ImageFile.LOAD_TRUNCATED_IMAGES = True",
            "Check file transfer was complete"
        ]

    # Permission denied
    elif "permission" in error_str or error_type == "PermissionError":
        msg = get_message("permission", lang)
        suggestions = [
            "Check file permissions",
            "Close other programs using the file",
            "Run with appropriate permissions"
        ]

    # Memory error
    elif "memory" in error_str or error_type == "MemoryError":
        msg = get_message("memory", lang)
        suggestions = [
            "Resize image before processing",
            "Use img.thumbnail() for large images",
            "Process in chunks",
            "Increase available memory"
        ]

    # Unsupported format
    elif "format" in error_str or "encoder" in error_str or "decoder" in error_str:
        msg = get_message("format", lang)
        suggestions = [
            f"Supported formats: {', '.join(IMAGE_FORMATS.values())}",
            "Install additional codecs",
            "Convert to supported format first"
        ]

    # Mode errors (RGBA to JPEG, etc.)
    elif "mode" in error_str:
        msg = get_message("mode", lang)
        suggestions = [
            "Convert mode: img.convert('RGB') for JPEG",
            "Convert mode: img.convert('RGBA') for PNG",
            "Check image mode: img.mode"
        ]

    # Save errors
    elif "save" in error_str or "write" in error_str:
        msg = get_message("save", lang)
        suggestions = [
            "Check output directory exists",
            "Check write permissions",
            "Specify format explicitly: img.save('out.png', 'PNG')"
        ]

    else:
        msg = f"Image Error: {error}"
        suggestions = [
            "Check image file is valid",
            "Try: pip install --upgrade Pillow",
            "Check Pillow documentation"
        ]

    return msg, suggestions


def open_image(
    filepath: str,
    mode: str = None,
    output_file: str = None,
    lang: str = "en"
):
    """
    Open image with friendly error handling

    Args:
        filepath: Path to image file
        mode: Convert to mode (RGB, RGBA, L, etc.)
        output_file: Log errors to file
        lang: Language for messages
    """
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("Pillow not installed. Run: pip install Pillow")

    filepath = str(filepath)

    # Check file exists first
    if not os.path.exists(filepath):
        msg, suggestions = explain_pil_error(
            FileNotFoundError(f"No such file: {filepath}"),
            filepath, lang
        )
        _print_error("FileNotFoundError", filepath, msg, suggestions, output_file)
        raise ImageError(msg, suggestions)

    try:
        img = Image.open(filepath)
        img.load()  # Force load to catch truncated images

        if mode:
            img = img.convert(mode)

        return img

    except Exception as e:
        msg, suggestions = explain_pil_error(e, filepath, lang)
        _print_error(type(e).__name__, filepath, msg, suggestions, output_file)
        raise ImageError(msg, suggestions, e)


def save_image(
    image,
    filepath: str,
    format: str = None,
    quality: int = 95,
    output_file: str = None,
    lang: str = "en",
    **kwargs
):
    """
    Save image with friendly error handling

    Args:
        image: PIL Image object
        filepath: Output path
        format: Image format (auto-detect from extension if None)
        quality: JPEG quality (1-100)
        output_file: Log errors to file
        **kwargs: Additional save parameters
    """
    filepath = str(filepath)
    ext = Path(filepath).suffix.lower()

    # Auto-detect format
    if format is None:
        format = IMAGE_FORMATS.get(ext)
        if format is None:
            msg = f"Unknown format for extension '{ext}'"
            suggestions = [
                f"Supported: {', '.join(IMAGE_FORMATS.keys())}",
                "Specify format: save_image(img, path, format='PNG')"
            ]
            _print_error("FormatError", filepath, msg, suggestions, output_file)
            raise ImageError(msg, suggestions)

    # Handle RGBA to JPEG conversion
    if format == 'JPEG' and image.mode == 'RGBA':
        image = image.convert('RGB')

    try:
        # Create output directory if needed
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)

        if format == 'JPEG':
            image.save(filepath, format, quality=quality, **kwargs)
        else:
            image.save(filepath, format, **kwargs)

        return filepath

    except Exception as e:
        msg, suggestions = explain_pil_error(e, filepath, lang)
        _print_error(type(e).__name__, filepath, msg, suggestions, output_file)
        raise ImageError(msg, suggestions, e)


def resize_image(
    image_or_path,
    size: Tuple[int, int],
    keep_aspect: bool = True,
    output_file: str = None,
    lang: str = "en"
):
    """
    Resize image with friendly error handling

    Args:
        image_or_path: PIL Image or path to image
        size: Target size (width, height)
        keep_aspect: Keep aspect ratio (use thumbnail)
    """
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("Pillow not installed. Run: pip install Pillow")

    # Load if path
    if isinstance(image_or_path, (str, Path)):
        img = open_image(image_or_path, output_file=output_file, lang=lang)
    else:
        img = image_or_path

    try:
        if keep_aspect:
            img.thumbnail(size, Image.Resampling.LANCZOS)
            return img
        else:
            return img.resize(size, Image.Resampling.LANCZOS)

    except Exception as e:
        msg, suggestions = explain_pil_error(e, None, lang)
        _print_error(type(e).__name__, "resize", msg, suggestions, output_file)
        raise ImageError(msg, suggestions, e)


def get_image_info(filepath: str) -> dict:
    """Get image information without fully loading"""
    try:
        from PIL import Image

        with Image.open(filepath) as img:
            return {
                "path": filepath,
                "format": img.format,
                "mode": img.mode,
                "size": img.size,
                "width": img.width,
                "height": img.height,
                "info": dict(img.info) if img.info else {}
            }
    except Exception as e:
        return {"error": str(e)}


def friendly_pil(func: Callable = None, output_file: str = None, lang: str = "en"):
    """
    Decorator for wrapping PIL operations with friendly errors

    Usage:
        @friendly_pil
        def process(path):
            img = Image.open(path)
            return img.resize((100, 100))

        @friendly_pil(output_file="errors.txt")
        def process(path):
            ...
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except ImageError:
                raise
            except Exception as e:
                msg, suggestions = explain_pil_error(e, None, lang)
                _print_error(type(e).__name__, f.__name__, msg, suggestions, output_file)
                raise ImageError(msg, suggestions, e)
        return wrapper

    if func is not None:
        return decorator(func)
    return decorator


def _print_error(error_type: str, context: str, message: str, suggestions: list, output_file: str = None):
    """Print formatted error"""
    from datetime import datetime

    output = [
        f"\n{'='*50}",
        f"❌ {error_type}",
        f"📁 {context}",
        f"🔍 {message}",
    ]

    if suggestions:
        output.append("💡 Suggestions:")
        for s in suggestions:
            output.append(f"   • {s}")

    output.append(f"{'='*50}\n")

    text = '\n'.join(output)
    print(text)

    if output_file:
        with open(output_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now()}]\n{text}\n")
