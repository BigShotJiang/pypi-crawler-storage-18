"""
MongoDB/PyMongo error handling

Usage:
    from friendly_exceptions.integrations.mongodb import friendly_mongo, explain_mongo_error

    # Create wrapped client
    client = friendly_mongo("mongodb://localhost:27017")
    db = client.mydb
    collection = db.users

    # Or wrap existing client
    from pymongo import MongoClient
    client = MongoClient()
    wrapped = friendly_mongo(client=client)
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


MONGO_ERRORS = {
    # Connection errors
    "connection_refused": ("Cannot connect to MongoDB", [
        "Check MongoDB is running: mongod",
        "Verify host and port",
        "Check firewall settings"
    ]),
    "authentication_failed": ("MongoDB authentication failed", [
        "Check username and password",
        "Verify authSource database",
        "Check user permissions"
    ]),
    "server_selection_timeout": ("Cannot find MongoDB server", [
        "Check connection string",
        "Server may be down",
        "Check replica set name"
    ]),
    "timeout": ("MongoDB operation timeout", [
        "Server may be overloaded",
        "Increase serverSelectionTimeoutMS",
        "Check network latency"
    ]),

    # Write errors
    "duplicate_key": ("Duplicate key error", [
        "Document with this _id exists",
        "Check unique index violations",
        "Use update_one with upsert=True"
    ]),
    "write_concern": ("Write concern error", [
        "Not enough replicas acknowledged",
        "Check replica set health",
        "Reduce write concern level"
    ]),
    "document_too_large": ("Document too large", [
        "Max document size is 16MB",
        "Split into smaller documents",
        "Use GridFS for large files"
    ]),

    # Query errors
    "invalid_query": ("Invalid query", [
        "Check query syntax",
        "Verify field names",
        "Check operator usage"
    ]),
    "bad_value": ("Invalid value in query", [
        "Check data types",
        "Verify operator arguments",
        "Check for null values"
    ]),

    # Index errors
    "index_not_found": ("Index not found", [
        "Create required index first",
        "Check index name",
        "Run: db.collection.createIndex()"
    ]),
    "index_key_too_long": ("Index key too long", [
        "Key exceeds 1024 bytes",
        "Use partial index",
        "Hash the field value"
    ]),

    # Authorization
    "unauthorized": ("Not authorized", [
        "Check user permissions",
        "Verify database access",
        "User may need roles"
    ]),

    # Namespace errors
    "namespace_not_found": ("Collection not found", [
        "Check collection name",
        "Collection may not exist yet",
        "It will be created on first insert"
    ]),
    "namespace_exists": ("Collection already exists", [
        "Drop existing collection first",
        "Use different collection name"
    ]),

    # Cursor errors
    "cursor_not_found": ("Cursor expired", [
        "Cursor was idle too long",
        "Increase noCursorTimeout",
        "Re-run the query"
    ]),

    # Network
    "network_error": ("Network error", [
        "Check network connection",
        "Server may have closed connection",
        "Retry the operation"
    ]),

    # Transactions
    "transaction_aborted": ("Transaction aborted", [
        "Conflict with another operation",
        "Retry the transaction",
        "Check for write conflicts"
    ]),
}


def explain_mongo_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze MongoDB error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Get error code if available
    error_code = getattr(error, 'code', None)
    details = getattr(error, 'details', {})

    # Connection errors
    if "connection" in error_type.lower() or "connection" in error_str:
        if "refused" in error_str:
            msg, suggestions = MONGO_ERRORS["connection_refused"]
        elif "authentication" in error_str or "auth" in error_str:
            msg, suggestions = MONGO_ERRORS["authentication_failed"]
        elif "timeout" in error_str:
            msg, suggestions = MONGO_ERRORS["server_selection_timeout"]
        else:
            msg = "MongoDB connection error"
            suggestions = [
                "Check MongoDB is running",
                "Verify connection string",
                "Check network connectivity"
            ]
        return f"MongoDB: {msg}", suggestions

    # Server selection timeout
    if "serverselection" in error_type.lower() or "server selection" in error_str:
        msg, suggestions = MONGO_ERRORS["server_selection_timeout"]
        return f"MongoDB: {msg}", suggestions

    # Duplicate key (error code 11000)
    if error_code == 11000 or "duplicate key" in error_str or "e11000" in error_str:
        msg, suggestions = MONGO_ERRORS["duplicate_key"]
        # Try to extract the duplicate key info
        if "dup key" in error_str:
            key_info = error_str.split("dup key:")[1][:50] if "dup key:" in error_str else ""
            if key_info:
                suggestions.insert(0, f"Duplicate: {key_info.strip()}")
        return f"MongoDB: {msg}", suggestions

    # Document too large
    if "too large" in error_str or "bson document" in error_str:
        msg, suggestions = MONGO_ERRORS["document_too_large"]
        return f"MongoDB: {msg}", suggestions

    # Authentication
    if "authentication" in error_str or "auth" in error_type.lower():
        msg, suggestions = MONGO_ERRORS["authentication_failed"]
        return f"MongoDB: {msg}", suggestions

    # Authorization
    if "unauthorized" in error_str or "not authorized" in error_str or error_code == 13:
        msg, suggestions = MONGO_ERRORS["unauthorized"]
        return f"MongoDB: {msg}", suggestions

    # Query errors
    if "query" in error_str and ("bad" in error_str or "invalid" in error_str):
        msg, suggestions = MONGO_ERRORS["invalid_query"]
        return f"MongoDB: {msg}", suggestions

    # Bad value
    if "bad value" in error_str or "badvalue" in error_str:
        msg, suggestions = MONGO_ERRORS["bad_value"]
        return f"MongoDB: {msg}", suggestions

    # Cursor errors
    if "cursor" in error_str and ("not found" in error_str or "expired" in error_str):
        msg, suggestions = MONGO_ERRORS["cursor_not_found"]
        return f"MongoDB: {msg}", suggestions

    # Network errors
    if "network" in error_str or "socket" in error_str:
        msg, suggestions = MONGO_ERRORS["network_error"]
        return f"MongoDB: {msg}", suggestions

    # Write concern errors
    if "write concern" in error_str or "writeconcern" in error_type.lower():
        msg, suggestions = MONGO_ERRORS["write_concern"]
        return f"MongoDB: {msg}", suggestions

    # Transaction errors
    if "transaction" in error_str:
        msg, suggestions = MONGO_ERRORS["transaction_aborted"]
        return f"MongoDB: {msg}", suggestions

    # Index errors
    if "index" in error_str:
        if "not found" in error_str:
            msg, suggestions = MONGO_ERRORS["index_not_found"]
        elif "too long" in error_str or "key too large" in error_str:
            msg, suggestions = MONGO_ERRORS["index_key_too_long"]
        else:
            msg = "MongoDB index error"
            suggestions = [
                "Check index configuration",
                "Verify index exists",
                "Check field names"
            ]
        return f"MongoDB: {msg}", suggestions

    # Generic
    msg = f"MongoDB Error: {error_type}"
    if error_code:
        msg += f" (code: {error_code})"

    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check MongoDB logs",
        "Verify query and data"
    ]

    return msg, suggestions


class FriendlyMongoClient:
    """Wrapper for MongoDB client with friendly errors"""

    def __init__(self, client, output_file: str = None, lang: str = "en"):
        self._client = client
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        # Wrap databases
        if hasattr(attr, 'list_collection_names'):
            return FriendlyMongoDatabase(attr, name, self._output_file, self._lang)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def __getitem__(self, name):
        db = self._client[name]
        return FriendlyMongoDatabase(db, name, self._output_file, self._lang)

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_mongo_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ mongo.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")


class FriendlyMongoDatabase:
    """Wrapper for MongoDB database with friendly errors"""

    def __init__(self, database, name: str, output_file: str = None, lang: str = "en"):
        self._database = database
        self._name = name
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._database, name)
        # Wrap collections
        if hasattr(attr, 'find'):
            return FriendlyMongoCollection(attr, f"{self._name}.{name}", self._output_file, self._lang)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def __getitem__(self, name):
        collection = self._database[name]
        return FriendlyMongoCollection(collection, f"{self._name}.{name}", self._output_file, self._lang)

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_mongo_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ db.{self._name}.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)


class FriendlyMongoCollection:
    """Wrapper for MongoDB collection with friendly errors"""

    def __init__(self, collection, name: str, output_file: str = None, lang: str = "en"):
        self._collection = collection
        self._name = name
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._collection, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_mongo_error(e, self._lang)
                self._print_error(method_name, msg, suggestions, kwargs.get('filter') or (args[0] if args else None))
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list, query=None):
        output = [
            f"\n{'='*50}",
            f"❌ {self._name}.{operation}()",
            f"🔍 {message}",
        ]

        if query:
            query_str = str(query)[:80]
            output.insert(2, f"📝 Query: {query_str}")

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")


def friendly_mongo(
    uri: str = "mongodb://localhost:27017",
    client=None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
) -> FriendlyMongoClient:
    """
    Create or wrap MongoDB client with friendly error handling

    Args:
        uri: MongoDB connection URI
        client: Existing MongoClient to wrap
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to MongoClient()

    Returns:
        Wrapped MongoDB client
    """
    if client is None:
        try:
            from pymongo import MongoClient
            client = MongoClient(uri, **kwargs)
        except ImportError:
            raise ImportError("pymongo not installed. Run: pip install pymongo")

    return FriendlyMongoClient(client, output_file, lang)
