"""
SQLAlchemy error handling

Usage:
    from friendly_exceptions.integrations.sqlalchemy_db import friendly_engine, explain_sqlalchemy_error

    # Create wrapped engine
    engine = friendly_engine("postgresql://user:pass@localhost/db")

    # Or wrap existing engine
    from sqlalchemy import create_engine
    engine = create_engine("sqlite:///app.db")
    friendly_engine(engine=engine)
"""

from typing import Tuple, List, Optional
from functools import wraps
from datetime import datetime


SQLALCHEMY_ERRORS = {
    # Connection errors
    "connection_refused": ("Cannot connect to database", [
        "Check database is running",
        "Verify host and port",
        "Check firewall settings"
    ]),
    "authentication": ("Database authentication failed", [
        "Check username and password",
        "Verify user has access",
        "Check pg_hba.conf (PostgreSQL)"
    ]),
    "database_not_exist": ("Database does not exist", [
        "Create database first",
        "Check database name spelling",
        "Verify connection string"
    ]),
    "timeout": ("Database connection timeout", [
        "Database may be overloaded",
        "Check network connectivity",
        "Increase connection timeout"
    ]),

    # Query errors
    "syntax_error": ("SQL syntax error", [
        "Check SQL query syntax",
        "Verify table/column names",
        "Check for missing quotes/brackets"
    ]),
    "undefined_table": ("Table does not exist", [
        "Run migrations: alembic upgrade head",
        "Create table first",
        "Check table name spelling"
    ]),
    "undefined_column": ("Column does not exist", [
        "Check column name spelling",
        "Column may need migration",
        "Verify model matches database"
    ]),
    "duplicate_key": ("Duplicate key violation", [
        "Record with this key exists",
        "Use update instead of insert",
        "Check unique constraints"
    ]),
    "foreign_key": ("Foreign key constraint failed", [
        "Referenced record doesn't exist",
        "Delete child records first",
        "Check relationship integrity"
    ]),
    "not_null": ("NULL value not allowed", [
        "Provide value for required field",
        "Set default in model",
        "Check column constraints"
    ]),
    "check_constraint": ("Check constraint failed", [
        "Value doesn't meet constraint",
        "Review constraint conditions",
        "Check allowed values"
    ]),

    # Data errors
    "data_too_long": ("Data too long for column", [
        "Reduce string length",
        "Increase column size",
        "Check VARCHAR limits"
    ]),
    "numeric_overflow": ("Numeric value out of range", [
        "Value too large for column type",
        "Check numeric precision",
        "Use larger numeric type"
    ]),
    "invalid_text": ("Invalid text encoding", [
        "Check text encoding (UTF-8)",
        "Remove invalid characters",
        "Set proper encoding in connection"
    ]),

    # Transaction errors
    "deadlock": ("Database deadlock detected", [
        "Transaction was rolled back",
        "Retry the operation",
        "Reduce transaction scope"
    ]),
    "serialization": ("Serialization failure", [
        "Concurrent modification conflict",
        "Retry with fresh data",
        "Consider using SELECT FOR UPDATE"
    ]),

    # Pool errors
    "pool_timeout": ("Connection pool exhausted", [
        "All connections are in use",
        "Increase pool_size",
        "Close connections properly",
        "Check for connection leaks"
    ]),
    "pool_overflow": ("Connection pool overflow", [
        "Too many connections requested",
        "Wait for connections to free",
        "Increase max_overflow"
    ]),

    # Migration errors
    "migration": ("Migration error", [
        "Check alembic version history",
        "Run: alembic current",
        "May need to stamp or downgrade"
    ]),
}


def explain_sqlalchemy_error(error, lang: str = "en") -> Tuple[str, List[str]]:
    """Analyze SQLAlchemy error and return (message, suggestions)"""
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Get original database error if wrapped
    orig_error = getattr(error, 'orig', None)
    orig_str = str(orig_error).lower() if orig_error else ""
    full_error = f"{error_str} {orig_str}"

    # Connection errors
    if "connection" in full_error:
        if "refused" in full_error:
            msg, suggestions = SQLALCHEMY_ERRORS["connection_refused"]
        elif "timeout" in full_error or "timed out" in full_error:
            msg, suggestions = SQLALCHEMY_ERRORS["timeout"]
        elif "authentication" in full_error or "password" in full_error or "denied" in full_error:
            msg, suggestions = SQLALCHEMY_ERRORS["authentication"]
        else:
            msg = "Database connection error"
            suggestions = [
                "Check database is running",
                "Verify connection string",
                "Check network connectivity"
            ]
        return f"SQLAlchemy: {msg}", suggestions

    # Database doesn't exist
    if "database" in full_error and ("not exist" in full_error or "unknown" in full_error):
        msg, suggestions = SQLALCHEMY_ERRORS["database_not_exist"]
        return f"SQLAlchemy: {msg}", suggestions

    # Table errors
    if "no such table" in full_error or "undefined_table" in full_error or "relation" in full_error and "not exist" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["undefined_table"]
        return f"SQLAlchemy: {msg}", suggestions

    # Column errors
    if "column" in full_error and ("not exist" in full_error or "unknown" in full_error or "undefined" in full_error):
        msg, suggestions = SQLALCHEMY_ERRORS["undefined_column"]
        return f"SQLAlchemy: {msg}", suggestions

    # Constraint violations
    if "duplicate" in full_error or "unique" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["duplicate_key"]
        return f"SQLAlchemy: {msg}", suggestions

    if "foreign key" in full_error or "foreignkey" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["foreign_key"]
        return f"SQLAlchemy: {msg}", suggestions

    if "not null" in full_error or "notnull" in full_error or "null value" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["not_null"]
        return f"SQLAlchemy: {msg}", suggestions

    if "check constraint" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["check_constraint"]
        return f"SQLAlchemy: {msg}", suggestions

    # Data errors
    if "too long" in full_error or "data too large" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["data_too_long"]
        return f"SQLAlchemy: {msg}", suggestions

    if "overflow" in full_error or "out of range" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["numeric_overflow"]
        return f"SQLAlchemy: {msg}", suggestions

    # Transaction errors
    if "deadlock" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["deadlock"]
        return f"SQLAlchemy: {msg}", suggestions

    if "serialization" in full_error or "concurrent" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["serialization"]
        return f"SQLAlchemy: {msg}", suggestions

    # Pool errors
    if "pool" in full_error:
        if "timeout" in full_error:
            msg, suggestions = SQLALCHEMY_ERRORS["pool_timeout"]
        else:
            msg, suggestions = SQLALCHEMY_ERRORS["pool_overflow"]
        return f"SQLAlchemy: {msg}", suggestions

    # Syntax errors
    if "syntax" in full_error or "parse" in full_error:
        msg, suggestions = SQLALCHEMY_ERRORS["syntax_error"]
        return f"SQLAlchemy: {msg}", suggestions

    # Generic
    msg = f"Database Error: {error_type}"
    suggestions = [
        f"Details: {str(error)[:100]}",
        "Check database logs",
        "Verify query and data"
    ]

    return msg, suggestions


class FriendlyEngine:
    """Wrapper for SQLAlchemy engine with friendly errors"""

    def __init__(self, engine, output_file: str = None, lang: str = "en"):
        self._engine = engine
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._engine, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_sqlalchemy_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ engine.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    def connect(self):
        """Return wrapped connection"""
        try:
            conn = self._engine.connect()
            return FriendlyConnection(conn, self._output_file, self._lang)
        except Exception as e:
            msg, suggestions = explain_sqlalchemy_error(e, self._lang)
            self._print_error("connect", msg, suggestions)
            raise


class FriendlyConnection:
    """Wrapper for SQLAlchemy connection with friendly errors"""

    def __init__(self, connection, output_file: str = None, lang: str = "en"):
        self._connection = connection
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._connection, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_sqlalchemy_error(e, self._lang)
                self._print_error(method_name, msg, suggestions, args)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list, args: tuple = None):
        output = [
            f"\n{'='*50}",
            f"❌ connection.{operation}()",
            f"🔍 {message}",
        ]

        # Show query if available
        if args and len(args) > 0:
            query = str(args[0])[:100]
            output.insert(2, f"📝 Query: {query}...")

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._connection.close()


class FriendlySession:
    """Wrapper for SQLAlchemy session with friendly errors"""

    def __init__(self, session, output_file: str = None, lang: str = "en"):
        self._session = session
        self._output_file = output_file
        self._lang = lang

    def __getattr__(self, name):
        attr = getattr(self._session, name)
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def _wrap_method(self, method, method_name: str):
        @wraps(method)
        def wrapper(*args, **kwargs):
            try:
                return method(*args, **kwargs)
            except Exception as e:
                msg, suggestions = explain_sqlalchemy_error(e, self._lang)
                self._print_error(method_name, msg, suggestions)
                raise
        return wrapper

    def _print_error(self, operation: str, message: str, suggestions: list):
        output = [
            f"\n{'='*50}",
            f"❌ session.{operation}()",
            f"🔍 {message}",
        ]

        if suggestions:
            output.append("💡 Suggestions:")
            for s in suggestions[:5]:
                output.append(f"   • {s}")

        output.append(f"{'='*50}\n")

        text = '\n'.join(output)
        print(text)

        if self._output_file:
            with open(self._output_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}]\n{text}\n")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self._session.rollback()
        self._session.close()


def friendly_engine(
    url: str = None,
    engine=None,
    output_file: str = None,
    lang: str = "en",
    **kwargs
) -> FriendlyEngine:
    """
    Create or wrap SQLAlchemy engine with friendly error handling

    Args:
        url: Database URL
        engine: Existing engine to wrap
        output_file: Log errors to file
        lang: Language for messages
        **kwargs: Passed to create_engine()

    Returns:
        Wrapped engine
    """
    if engine is None:
        if url is None:
            raise ValueError("Provide url or engine")

        try:
            from sqlalchemy import create_engine
            engine = create_engine(url, **kwargs)
        except ImportError:
            raise ImportError("sqlalchemy not installed. Run: pip install sqlalchemy")

    return FriendlyEngine(engine, output_file, lang)


def friendly_session(
    session=None,
    sessionmaker=None,
    output_file: str = None,
    lang: str = "en"
) -> FriendlySession:
    """
    Wrap SQLAlchemy session with friendly error handling

    Args:
        session: Existing session to wrap
        sessionmaker: SessionMaker to create session from
        output_file: Log errors to file
        lang: Language for messages

    Returns:
        Wrapped session
    """
    if session is None:
        if sessionmaker is None:
            raise ValueError("Provide session or sessionmaker")
        session = sessionmaker()

    return FriendlySession(session, output_file, lang)
