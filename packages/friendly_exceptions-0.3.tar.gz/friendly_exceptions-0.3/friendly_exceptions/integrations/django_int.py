"""
Django Integration - Friendly error messages for Django

Just import once in settings.py or manage.py:
    import friendly_exceptions.integrations.django_int

All Django errors become friendly automatically.
Server mode: logs to fe.log
Console mode: prints to stderr
"""

import sys
import os
import logging
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path

# Detect if running as server
IS_SERVER = any(x in sys.argv for x in ['runserver', 'gunicorn', 'uvicorn', 'daphne', 'uwsgi'])

# Setup logging
LOG_FILE = Path("fe.log")
fe_logger = logging.getLogger("friendly_exceptions")
fe_logger.setLevel(logging.INFO)

if IS_SERVER:
    handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    fe_logger.addHandler(handler)


def log_error(message: str):
    """Log error to file (server) or console (script)"""
    if IS_SERVER:
        fe_logger.info(message)
    else:
        print(f"\n{message}\n", file=sys.stderr)


# Django error explanations
DJANGO_ERRORS = {
    # ORM Errors
    "DoesNotExist": {
        "en": "Object not found in database. Query returned no results.\n"
              "  - Check if the object exists before accessing\n"
              "  - Use .filter().first() instead of .get() to avoid exception\n"
              "  - Use get_object_or_404() in views",
        "ru": "Объект не найден в базе данных. Запрос не вернул результатов.\n"
              "  - Проверьте существует ли объект перед доступом\n"
              "  - Используйте .filter().first() вместо .get()\n"
              "  - Используйте get_object_or_404() во views",
    },
    "MultipleObjectsReturned": {
        "en": "Query returned multiple objects but expected one.\n"
              "  - Use .filter() instead of .get() for multiple results\n"
              "  - Add more filters to narrow down to one object\n"
              "  - Check for duplicate data in database",
        "ru": "Запрос вернул несколько объектов, ожидался один.\n"
              "  - Используйте .filter() вместо .get() для нескольких результатов\n"
              "  - Добавьте фильтры чтобы сузить до одного объекта\n"
              "  - Проверьте дубликаты в базе данных",
    },
    "FieldError": {
        "en": "Invalid field name in query.\n"
              "  - Check field name spelling\n"
              "  - Field might not exist on this model\n"
              "  - For related fields use double underscore: field__related",
        "ru": "Неверное имя поля в запросе.\n"
              "  - Проверьте написание имени поля\n"
              "  - Поле может не существовать в этой модели\n"
              "  - Для связанных полей используйте __: field__related",
    },
    "IntegrityError": {
        "en": "Database integrity constraint violated.\n"
              "  - UNIQUE constraint: trying to insert duplicate value\n"
              "  - NOT NULL constraint: required field is empty\n"
              "  - FOREIGN KEY constraint: referenced object doesn't exist",
        "ru": "Нарушено ограничение целостности базы данных.\n"
              "  - UNIQUE: попытка вставить дубликат\n"
              "  - NOT NULL: обязательное поле пустое\n"
              "  - FOREIGN KEY: связанный объект не существует",
    },
    "OperationalError": {
        "en": "Database operation failed.\n"
              "  - Database might be unavailable\n"
              "  - Table might not exist (run migrations)\n"
              "  - Connection timeout or limit reached",
        "ru": "Операция с базой данных не удалась.\n"
              "  - База данных может быть недоступна\n"
              "  - Таблица может не существовать (запустите миграции)\n"
              "  - Таймаут или лимит соединений",
    },
    "ProgrammingError": {
        "en": "SQL programming error.\n"
              "  - Table or column doesn't exist\n"
              "  - Run 'python manage.py migrate'\n"
              "  - Check if migrations are up to date",
        "ru": "Ошибка SQL запроса.\n"
              "  - Таблица или колонка не существует\n"
              "  - Запустите 'python manage.py migrate'\n"
              "  - Проверьте актуальность миграций",
    },

    # Template Errors
    "TemplateSyntaxError": {
        "en": "Template syntax error.\n"
              "  - Check for unclosed tags: {% if %} needs {% endif %}\n"
              "  - Check variable syntax: {{ variable }}\n"
              "  - Check filter syntax: {{ value|filter }}",
        "ru": "Синтаксическая ошибка в шаблоне.\n"
              "  - Проверьте незакрытые теги: {% if %} требует {% endif %}\n"
              "  - Проверьте синтаксис переменных: {{ variable }}\n"
              "  - Проверьте синтаксис фильтров: {{ value|filter }}",
    },
    "TemplateDoesNotExist": {
        "en": "Template file not found.\n"
              "  - Check template path and filename\n"
              "  - Check TEMPLATES['DIRS'] in settings.py\n"
              "  - Check app is in INSTALLED_APPS",
        "ru": "Файл шаблона не найден.\n"
              "  - Проверьте путь и имя файла шаблона\n"
              "  - Проверьте TEMPLATES['DIRS'] в settings.py\n"
              "  - Проверьте что приложение в INSTALLED_APPS",
    },
    "VariableDoesNotExist": {
        "en": "Template variable not found in context.\n"
              "  - Variable not passed from view\n"
              "  - Check variable name spelling\n"
              "  - Use {{ variable|default:'' }} for optional vars",
        "ru": "Переменная не найдена в контексте шаблона.\n"
              "  - Переменная не передана из view\n"
              "  - Проверьте написание имени переменной\n"
              "  - Используйте {{ variable|default:'' }} для опциональных",
    },

    # URL Errors
    "Resolver404": {
        "en": "URL not found (404).\n"
              "  - Check URL pattern in urls.py\n"
              "  - Check URL path spelling\n"
              "  - Make sure URL is included in main urls.py",
        "ru": "URL не найден (404).\n"
              "  - Проверьте паттерн URL в urls.py\n"
              "  - Проверьте написание пути URL\n"
              "  - Убедитесь что URL включен в главный urls.py",
    },
    "NoReverseMatch": {
        "en": "URL reverse lookup failed.\n"
              "  - Check URL name exists in urls.py\n"
              "  - Check all required URL arguments are provided\n"
              "  - Use: {% url 'name' arg1 arg2 %}",
        "ru": "Не удалось найти URL по имени.\n"
              "  - Проверьте что имя URL существует в urls.py\n"
              "  - Проверьте что все аргументы URL переданы\n"
              "  - Используйте: {% url 'name' arg1 arg2 %}",
    },

    # Form/Validation Errors
    "ValidationError": {
        "en": "Form/Model validation failed.\n"
              "  - Check form.errors for details\n"
              "  - Required field might be missing\n"
              "  - Value doesn't match field constraints",
        "ru": "Ошибка валидации формы/модели.\n"
              "  - Проверьте form.errors для деталей\n"
              "  - Обязательное поле может отсутствовать\n"
              "  - Значение не соответствует ограничениям поля",
    },

    # Permission Errors
    "PermissionDenied": {
        "en": "Permission denied (403).\n"
              "  - User lacks required permission\n"
              "  - Check @permission_required decorator\n"
              "  - Check user.has_perm() calls",
        "ru": "Доступ запрещён (403).\n"
              "  - У пользователя нет нужных прав\n"
              "  - Проверьте @permission_required декоратор\n"
              "  - Проверьте вызовы user.has_perm()",
    },

    # Configuration Errors
    "ImproperlyConfigured": {
        "en": "Django configuration error.\n"
              "  - Check settings.py for missing/wrong values\n"
              "  - Required setting might be missing\n"
              "  - App might not be in INSTALLED_APPS",
        "ru": "Ошибка конфигурации Django.\n"
              "  - Проверьте settings.py на пропущенные/неверные значения\n"
              "  - Обязательная настройка может отсутствовать\n"
              "  - Приложение может не быть в INSTALLED_APPS",
    },

    # Migration Errors
    "MigrationError": {
        "en": "Migration error.\n"
              "  - Try: python manage.py makemigrations\n"
              "  - Then: python manage.py migrate\n"
              "  - Check for circular dependencies",
        "ru": "Ошибка миграции.\n"
              "  - Попробуйте: python manage.py makemigrations\n"
              "  - Затем: python manage.py migrate\n"
              "  - Проверьте циклические зависимости",
    },

    # Auth Errors
    "AuthenticationFailed": {
        "en": "Authentication failed.\n"
              "  - Invalid credentials\n"
              "  - User account might be inactive\n"
              "  - Check authentication backend",
        "ru": "Ошибка аутентификации.\n"
              "  - Неверные учётные данные\n"
              "  - Аккаунт пользователя может быть неактивен\n"
              "  - Проверьте backend аутентификации",
    },

    # Serialization
    "SerializerError": {
        "en": "DRF Serializer error.\n"
              "  - Check serializer.errors for details\n"
              "  - Required field might be missing\n"
              "  - Invalid data format",
        "ru": "Ошибка DRF сериализатора.\n"
              "  - Проверьте serializer.errors для деталей\n"
              "  - Обязательное поле может отсутствовать\n"
              "  - Неверный формат данных",
    },
}


def get_lang() -> str:
    """Get current language"""
    try:
        from ..i18n import get_language
        return get_language()
    except:
        return "en"


def explain_django_error(exc_type, exc_value, exc_tb) -> Optional[str]:
    """Generate friendly explanation for Django error"""
    lang = get_lang()
    exc_name = exc_type.__name__

    # Check if it's a Django error we know
    explanation = None
    for error_name, messages in DJANGO_ERRORS.items():
        if error_name in exc_name or exc_name == error_name:
            explanation = messages.get(lang, messages.get("en", ""))
            break

    if not explanation:
        return None

    # Build full message
    lines = [
        "=" * 60,
        f"Django Error: {exc_name}",
        "=" * 60,
        "",
        f"Message: {exc_value}",
        "",
        "Explanation:",
        explanation,
        "",
    ]

    # Add location info
    if exc_tb:
        import traceback
        tb_lines = traceback.extract_tb(exc_tb)
        if tb_lines:
            last = tb_lines[-1]
            lines.append(f"Location: {last.filename}:{last.lineno} in {last.name}()")

    lines.append("=" * 60)

    return "\n".join(lines)


class DjangoExceptionHandler:
    """Global exception handler for Django"""

    def __init__(self, original_hook=None):
        self.original_hook = original_hook

    def __call__(self, exc_type, exc_value, exc_tb):
        # Try to explain Django error
        explanation = explain_django_error(exc_type, exc_value, exc_tb)
        if explanation:
            log_error(explanation)

        # Call original hook
        if self.original_hook:
            self.original_hook(exc_type, exc_value, exc_tb)
        else:
            sys.__excepthook__(exc_type, exc_value, exc_tb)


def install_excepthook():
    """Install global exception hook"""
    sys.excepthook = DjangoExceptionHandler(sys.excepthook)


def install_django_middleware():
    """Install Django middleware for request error handling"""
    try:
        from django.conf import settings
        from django.core.signals import got_request_exception

        def handle_request_exception(sender, request=None, **kwargs):
            """Handle exceptions during request processing"""
            exc_info = sys.exc_info()
            if exc_info[0]:
                explanation = explain_django_error(*exc_info)
                if explanation:
                    log_error(f"Request: {request.path if request else 'unknown'}\n{explanation}")

        got_request_exception.connect(handle_request_exception)

        if IS_SERVER:
            fe_logger.info("Django integration installed (middleware + signals)")

    except Exception as e:
        pass  # Django not available


def install_logging_handler():
    """Install handler for Django's logging system"""
    try:
        import logging

        class FriendlyDjangoHandler(logging.Handler):
            def emit(self, record):
                if record.exc_info:
                    explanation = explain_django_error(*record.exc_info)
                    if explanation:
                        log_error(explanation)

        # Add to django logger
        django_logger = logging.getLogger('django')
        django_logger.addHandler(FriendlyDjangoHandler())

        # Add to django.request logger
        request_logger = logging.getLogger('django.request')
        request_logger.addHandler(FriendlyDjangoHandler())

    except:
        pass


def install():
    """Install all Django integrations"""
    install_excepthook()
    install_django_middleware()
    install_logging_handler()

    if IS_SERVER:
        fe_logger.info(f"Friendly Exceptions Django integration active. Logging to {LOG_FILE}")


# Auto-install on import
install()
