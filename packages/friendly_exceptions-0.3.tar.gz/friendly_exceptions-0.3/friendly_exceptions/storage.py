"""
Error storage and analytics with SQLite

Usage:
    from friendly_exceptions.storage import ErrorStorage, install_storage

    # Create storage
    storage = ErrorStorage("errors.db")

    # Install globally
    install_storage(storage)

    # Query errors
    errors = storage.get_recent(limit=100)
    top_errors = storage.get_top_errors()
    stats = storage.get_stats()
"""

import sqlite3
import json
import hashlib
import traceback
import sys
import os
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
from contextlib import contextmanager
import threading


@dataclass
class StoredError:
    """Stored error record"""
    id: int
    timestamp: str
    error_type: str
    error_message: str
    error_hash: str
    filename: str
    lineno: int
    function: str
    traceback: str
    count: int = 1
    first_seen: str = ""
    last_seen: str = ""
    resolved: bool = False
    notes: str = ""
    extra_data: str = ""


class ErrorStorage:
    """SQLite-based error storage with analytics"""

    def __init__(self, db_path: str = "friendly_exceptions.db"):
        self.db_path = db_path
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        """Get thread-local connection"""
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn

    @contextmanager
    def _cursor(self):
        """Context manager for cursor"""
        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cursor.close()

    def _init_db(self):
        """Initialize database schema"""
        with self._cursor() as cur:
            # Main errors table
            cur.execute("""
                CREATE TABLE IF NOT EXISTS errors (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    error_type TEXT NOT NULL,
                    error_message TEXT NOT NULL,
                    error_hash TEXT NOT NULL,
                    filename TEXT,
                    lineno INTEGER,
                    function TEXT,
                    traceback TEXT,
                    count INTEGER DEFAULT 1,
                    first_seen TEXT,
                    last_seen TEXT,
                    resolved INTEGER DEFAULT 0,
                    notes TEXT DEFAULT '',
                    extra_data TEXT DEFAULT '{}'
                )
            """)

            # Indexes
            cur.execute("CREATE INDEX IF NOT EXISTS idx_error_hash ON errors(error_hash)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON errors(timestamp)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_error_type ON errors(error_type)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_resolved ON errors(resolved)")

            # Error occurrences (for detailed tracking)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS occurrences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    error_id INTEGER NOT NULL,
                    timestamp TEXT NOT NULL,
                    extra_data TEXT DEFAULT '{}',
                    FOREIGN KEY (error_id) REFERENCES errors(id)
                )
            """)

            cur.execute("CREATE INDEX IF NOT EXISTS idx_occ_error_id ON occurrences(error_id)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_occ_timestamp ON occurrences(timestamp)")

    def _compute_hash(self, error_type: str, filename: str, lineno: int, function: str) -> str:
        """Compute unique hash for error deduplication"""
        key = f"{error_type}:{filename}:{lineno}:{function}"
        return hashlib.md5(key.encode()).hexdigest()[:16]

    def store(
        self,
        exc_info=None,
        extra_data: dict = None
    ) -> int:
        """
        Store an error

        Args:
            exc_info: sys.exc_info() tuple
            extra_data: Additional data to store

        Returns:
            Error ID
        """
        if exc_info is None:
            exc_info = sys.exc_info()

        exc_type, exc_value, exc_tb = exc_info
        now = datetime.now().isoformat()

        # Extract frame info
        frames = traceback.extract_tb(exc_tb)
        if frames:
            last_frame = frames[-1]
            filename = last_frame.filename
            lineno = last_frame.lineno
            function = last_frame.name
        else:
            filename = ""
            lineno = 0
            function = ""

        error_type = exc_type.__name__
        error_message = str(exc_value)
        tb_text = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
        error_hash = self._compute_hash(error_type, filename, lineno, function)

        extra_json = json.dumps(extra_data or {})

        with self._cursor() as cur:
            # Check if error exists
            cur.execute(
                "SELECT id, count FROM errors WHERE error_hash = ?",
                (error_hash,)
            )
            row = cur.fetchone()

            if row:
                # Update existing
                error_id = row['id']
                new_count = row['count'] + 1

                cur.execute("""
                    UPDATE errors
                    SET count = ?, last_seen = ?, error_message = ?, traceback = ?
                    WHERE id = ?
                """, (new_count, now, error_message, tb_text, error_id))

            else:
                # Insert new
                cur.execute("""
                    INSERT INTO errors
                    (timestamp, error_type, error_message, error_hash, filename,
                     lineno, function, traceback, first_seen, last_seen, extra_data)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (now, error_type, error_message, error_hash, filename,
                      lineno, function, tb_text, now, now, extra_json))

                error_id = cur.lastrowid

            # Store occurrence
            cur.execute("""
                INSERT INTO occurrences (error_id, timestamp, extra_data)
                VALUES (?, ?, ?)
            """, (error_id, now, extra_json))

            return error_id

    def get_by_id(self, error_id: int) -> Optional[StoredError]:
        """Get error by ID"""
        with self._cursor() as cur:
            cur.execute("SELECT * FROM errors WHERE id = ?", (error_id,))
            row = cur.fetchone()
            if row:
                return StoredError(**dict(row))
        return None

    def get_recent(
        self,
        limit: int = 100,
        offset: int = 0,
        include_resolved: bool = False
    ) -> List[StoredError]:
        """Get recent errors"""
        query = "SELECT * FROM errors"
        params = []

        if not include_resolved:
            query += " WHERE resolved = 0"

        query += " ORDER BY last_seen DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        with self._cursor() as cur:
            cur.execute(query, params)
            return [StoredError(**dict(row)) for row in cur.fetchall()]

    def get_top_errors(
        self,
        limit: int = 10,
        days: int = 7
    ) -> List[Dict[str, Any]]:
        """Get most frequent errors"""
        since = (datetime.now() - timedelta(days=days)).isoformat()

        with self._cursor() as cur:
            cur.execute("""
                SELECT
                    error_type,
                    error_message,
                    filename,
                    lineno,
                    function,
                    COUNT(*) as occurrence_count,
                    MAX(o.timestamp) as last_occurrence
                FROM occurrences o
                JOIN errors e ON o.error_id = e.id
                WHERE o.timestamp > ? AND e.resolved = 0
                GROUP BY e.error_hash
                ORDER BY occurrence_count DESC
                LIMIT ?
            """, (since, limit))

            return [dict(row) for row in cur.fetchall()]

    def get_stats(self, days: int = 7) -> Dict[str, Any]:
        """Get error statistics"""
        since = (datetime.now() - timedelta(days=days)).isoformat()

        with self._cursor() as cur:
            # Total errors
            cur.execute("SELECT COUNT(*) as total FROM errors")
            total = cur.fetchone()['total']

            # Unresolved
            cur.execute("SELECT COUNT(*) as unresolved FROM errors WHERE resolved = 0")
            unresolved = cur.fetchone()['unresolved']

            # Recent occurrences
            cur.execute(
                "SELECT COUNT(*) as recent FROM occurrences WHERE timestamp > ?",
                (since,)
            )
            recent = cur.fetchone()['recent']

            # By type
            cur.execute("""
                SELECT error_type, COUNT(*) as count
                FROM errors
                GROUP BY error_type
                ORDER BY count DESC
                LIMIT 10
            """)
            by_type = [dict(row) for row in cur.fetchall()]

            # By day
            cur.execute("""
                SELECT DATE(timestamp) as date, COUNT(*) as count
                FROM occurrences
                WHERE timestamp > ?
                GROUP BY DATE(timestamp)
                ORDER BY date
            """, (since,))
            by_day = [dict(row) for row in cur.fetchall()]

            # Top files
            cur.execute("""
                SELECT filename, COUNT(*) as count
                FROM errors
                WHERE filename != ''
                GROUP BY filename
                ORDER BY count DESC
                LIMIT 10
            """)
            top_files = [dict(row) for row in cur.fetchall()]

            return {
                'total_errors': total,
                'unresolved': unresolved,
                'recent_occurrences': recent,
                'by_type': by_type,
                'by_day': by_day,
                'top_files': top_files,
                'period_days': days
            }

    def resolve(self, error_id: int, notes: str = ""):
        """Mark error as resolved"""
        with self._cursor() as cur:
            cur.execute(
                "UPDATE errors SET resolved = 1, notes = ? WHERE id = ?",
                (notes, error_id)
            )

    def unresolve(self, error_id: int):
        """Mark error as unresolved"""
        with self._cursor() as cur:
            cur.execute(
                "UPDATE errors SET resolved = 0 WHERE id = ?",
                (error_id,)
            )

    def delete(self, error_id: int):
        """Delete error and its occurrences"""
        with self._cursor() as cur:
            cur.execute("DELETE FROM occurrences WHERE error_id = ?", (error_id,))
            cur.execute("DELETE FROM errors WHERE id = ?", (error_id,))

    def clear_old(self, days: int = 30):
        """Delete errors older than N days"""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        with self._cursor() as cur:
            # Get old error IDs
            cur.execute(
                "SELECT id FROM errors WHERE last_seen < ?",
                (cutoff,)
            )
            old_ids = [row['id'] for row in cur.fetchall()]

            if old_ids:
                placeholders = ','.join('?' * len(old_ids))
                cur.execute(f"DELETE FROM occurrences WHERE error_id IN ({placeholders})", old_ids)
                cur.execute(f"DELETE FROM errors WHERE id IN ({placeholders})", old_ids)

            return len(old_ids)

    def search(
        self,
        query: str,
        limit: int = 50
    ) -> List[StoredError]:
        """Search errors by message or type"""
        pattern = f"%{query}%"

        with self._cursor() as cur:
            cur.execute("""
                SELECT * FROM errors
                WHERE error_message LIKE ? OR error_type LIKE ? OR filename LIKE ?
                ORDER BY last_seen DESC
                LIMIT ?
            """, (pattern, pattern, pattern, limit))

            return [StoredError(**dict(row)) for row in cur.fetchall()]

    def export_json(self, filepath: str, include_resolved: bool = True):
        """Export all errors to JSON"""
        with self._cursor() as cur:
            query = "SELECT * FROM errors"
            if not include_resolved:
                query += " WHERE resolved = 0"

            cur.execute(query)
            errors = [dict(row) for row in cur.fetchall()]

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(errors, f, indent=2, ensure_ascii=False)

    def export_csv(self, filepath: str, include_resolved: bool = True):
        """Export all errors to CSV"""
        import csv

        with self._cursor() as cur:
            query = "SELECT * FROM errors"
            if not include_resolved:
                query += " WHERE resolved = 0"

            cur.execute(query)
            rows = cur.fetchall()

            if not rows:
                return

            with open(filepath, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(rows[0].keys())
                for row in rows:
                    writer.writerow(row)

    def get_timeline(self, hours: int = 24) -> List[Dict[str, Any]]:
        """Get error timeline for last N hours"""
        since = (datetime.now() - timedelta(hours=hours)).isoformat()

        with self._cursor() as cur:
            cur.execute("""
                SELECT
                    strftime('%Y-%m-%d %H:00', timestamp) as hour,
                    COUNT(*) as count
                FROM occurrences
                WHERE timestamp > ?
                GROUP BY hour
                ORDER BY hour
            """, (since,))

            return [dict(row) for row in cur.fetchall()]


class StorageExceptHook:
    """Exception hook that stores errors"""

    def __init__(self, storage: ErrorStorage, original_hook=None):
        self.storage = storage
        self.original_hook = original_hook

    def __call__(self, exc_type, exc_value, exc_tb):
        # Store error
        try:
            self.storage.store(exc_info=(exc_type, exc_value, exc_tb))
        except Exception as e:
            print(f"Failed to store error: {e}", file=sys.stderr)

        # Call original hook
        if self.original_hook:
            self.original_hook(exc_type, exc_value, exc_tb)
        else:
            sys.__excepthook__(exc_type, exc_value, exc_tb)


def install_storage(storage: ErrorStorage):
    """Install storage hook globally"""
    sys.excepthook = StorageExceptHook(storage, sys.excepthook)


# Global storage instance
_global_storage: Optional[ErrorStorage] = None


def get_global_storage(db_path: str = "friendly_exceptions.db") -> ErrorStorage:
    """Get or create global storage"""
    global _global_storage
    if _global_storage is None:
        _global_storage = ErrorStorage(db_path)
    return _global_storage
