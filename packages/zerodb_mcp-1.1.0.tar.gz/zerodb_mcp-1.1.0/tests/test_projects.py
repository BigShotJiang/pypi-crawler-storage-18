"""
Tests for Project operations
"""

import pytest
from unittest.mock import MagicMock


class TestProjectOperations:
    """Test Project operations"""

    @pytest.mark.asyncio
    async def test_create(self, client, mock_httpx_client):
        """Test creating a project"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "project_id": "proj_uuid",
            "name": "Test Project"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.create(name="Test Project")
        assert result["project_id"] == "proj_uuid"

    @pytest.mark.asyncio
    async def test_get(self, client, mock_httpx_client, sample_project_id):
        """Test getting project details"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "project_id": sample_project_id,
            "name": "Test Project"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.get(project_id=sample_project_id)
        assert result["project_id"] == sample_project_id

    @pytest.mark.asyncio
    async def test_list(self, client, mock_httpx_client):
        """Test listing projects"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "projects": [{"project_id": "proj1"}],
            "total": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.list()
        assert len(result["projects"]) == 1

    @pytest.mark.asyncio
    async def test_update(self, client, mock_httpx_client, sample_project_id):
        """Test updating project"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "project_id": sample_project_id,
            "name": "Updated Project"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.update(
            project_id=sample_project_id,
            name="Updated Project"
        )
        assert result["name"] == "Updated Project"

    @pytest.mark.asyncio
    async def test_delete(self, client, mock_httpx_client, sample_project_id):
        """Test deleting project"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.delete(
            project_id=sample_project_id,
            confirm=True
        )
        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_stats(self, client, mock_httpx_client, sample_project_id):
        """Test getting project statistics"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "project_id": sample_project_id,
            "total_vectors": 10000
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.get_stats(project_id=sample_project_id)
        assert result["total_vectors"] == 10000

    @pytest.mark.asyncio
    async def test_enable_database(self, client, mock_httpx_client, sample_project_id):
        """Test enabling database features"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "database_type": "postgres"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.projects.enable_database(
            project_id=sample_project_id,
            database_type="postgres"
        )
        assert result["database_type"] == "postgres"
