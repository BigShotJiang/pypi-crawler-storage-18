"""
Tests for Event operations
"""

import pytest
from unittest.mock import MagicMock


class TestEventOperations:
    """Test Event operations"""

    @pytest.mark.asyncio
    async def test_create(self, client, mock_httpx_client, sample_project_id):
        """Test creating an event"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "event_id": "event_uuid",
            "event_type": "user.login"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.events.create(
            project_id=sample_project_id,
            event_type="user.login",
            event_data={"user_id": "user123"}
        )
        assert result["event_id"] == "event_uuid"

    @pytest.mark.asyncio
    async def test_list(self, client, mock_httpx_client, sample_project_id):
        """Test listing events"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "events": [{"event_id": "event1"}],
            "total": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.events.list(project_id=sample_project_id)
        assert len(result["events"]) == 1

    @pytest.mark.asyncio
    async def test_get(self, client, mock_httpx_client, sample_project_id):
        """Test getting event details"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"event_id": "event_uuid"}
        mock_httpx_client.post.return_value = mock_response

        result = await client.events.get(
            project_id=sample_project_id,
            event_id="event_uuid"
        )
        assert result["event_id"] == "event_uuid"

    @pytest.mark.asyncio
    async def test_subscribe(self, client, mock_httpx_client, sample_project_id):
        """Test subscribing to events"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "subscription_id": "sub_uuid",
            "websocket_url": "wss://example.com"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.events.subscribe(project_id=sample_project_id)
        assert result["subscription_id"] == "sub_uuid"

    @pytest.mark.asyncio
    async def test_stats(self, client, mock_httpx_client, sample_project_id):
        """Test getting event statistics"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_events": 10000,
            "by_type": {"user.login": 5000}
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.events.stats(project_id=sample_project_id)
        assert result["total_events"] == 10000
