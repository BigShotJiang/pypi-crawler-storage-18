"""
Tests for Embedding operations
"""

import pytest
from unittest.mock import MagicMock


class TestEmbeddingOperations:
    """Test Embedding operations"""

    @pytest.mark.asyncio
    async def test_generate(self, client, mock_httpx_client):
        """Test generating embeddings"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "embeddings": [[0.1] * 384, [0.2] * 384],
            "model": "BAAI/bge-small-en-v1.5",
            "dimensions": 384
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.generate(texts=["text1", "text2"])
        assert len(result["embeddings"]) == 2

    @pytest.mark.asyncio
    async def test_generate_empty_texts_error(self, client):
        """Test generate with empty texts raises error"""
        with pytest.raises(ValueError, match="texts list cannot be empty"):
            await client.embeddings.generate(texts=[])

    @pytest.mark.asyncio
    async def test_generate_too_many_texts_error(self, client):
        """Test generate with too many texts raises error"""
        with pytest.raises(ValueError, match="Maximum 100 texts per request"):
            await client.embeddings.generate(texts=["text"] * 101)

    @pytest.mark.asyncio
    async def test_embed_and_store(self, client, mock_httpx_client, sample_project_id):
        """Test embed and store"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "success": True,
            "vectors_stored": 2
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.embed_and_store(
            project_id=sample_project_id,
            texts=["text1", "text2"]
        )
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_embed_and_store_empty_error(self, client, sample_project_id):
        """Test embed and store with empty texts error"""
        with pytest.raises(ValueError, match="texts list cannot be empty"):
            await client.embeddings.embed_and_store(
                project_id=sample_project_id,
                texts=[]
            )

    @pytest.mark.asyncio
    async def test_semantic_search(self, client, mock_httpx_client, sample_project_id):
        """Test semantic search"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [{"vector_id": "vec1", "similarity": 0.95}],
            "total_results": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.semantic_search(
            project_id=sample_project_id,
            query="test query"
        )
        assert len(result["results"]) == 1

    @pytest.mark.asyncio
    async def test_semantic_search_empty_query_error(self, client, sample_project_id):
        """Test semantic search with empty query error"""
        with pytest.raises(ValueError, match="query cannot be empty"):
            await client.embeddings.semantic_search(
                project_id=sample_project_id,
                query=""
            )

    @pytest.mark.asyncio
    async def test_semantic_search_invalid_limit_error(self, client, sample_project_id):
        """Test semantic search with invalid limit error"""
        with pytest.raises(ValueError, match="limit must be between 1 and 100"):
            await client.embeddings.semantic_search(
                project_id=sample_project_id,
                query="test",
                limit=0
            )

    @pytest.mark.asyncio
    async def test_list_models(self, client, mock_httpx_client):
        """Test listing embedding models"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = [
            {"id": "BAAI/bge-small-en-v1.5", "dimensions": 384}
        ]
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.list_models()
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_health_check(self, client, mock_httpx_client):
        """Test health check"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "healthy"}
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.health_check()
        assert result["status"] == "healthy"

    @pytest.mark.asyncio
    async def test_get_usage(self, client, mock_httpx_client):
        """Test getting usage statistics"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "embeddings_generated_today": 1000,
            "cost_today_usd": 0.0
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.embeddings.get_usage()
        assert result["embeddings_generated_today"] == 1000
