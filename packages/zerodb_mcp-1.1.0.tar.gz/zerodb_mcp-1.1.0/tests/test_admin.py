"""
Tests for Admin operations
"""

import pytest
from unittest.mock import MagicMock


class TestAdminOperations:
    """Test Admin operations"""

    @pytest.mark.asyncio
    async def test_get_system_stats(self, client, mock_httpx_client):
        """Test getting system statistics"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_users": 1000,
            "total_projects": 5000,
            "total_vectors": 10000000
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.admin.get_system_stats()
        assert result["total_users"] == 1000

    @pytest.mark.asyncio
    async def test_list_all_projects(self, client, mock_httpx_client):
        """Test listing all projects"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "projects": [{"project_id": "proj_1", "name": "Project 1"}],
            "total": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.admin.list_all_projects()
        assert len(result["projects"]) == 1

    @pytest.mark.asyncio
    async def test_get_user_usage(self, client, mock_httpx_client):
        """Test getting user usage"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "user_id": "user_123",
            "total_projects": 10
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.admin.get_user_usage(user_id="user_123")
        assert result["user_id"] == "user_123"

    @pytest.mark.asyncio
    async def test_system_health(self, client, mock_httpx_client):
        """Test system health check"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "healthy"}
        mock_httpx_client.post.return_value = mock_response

        result = await client.admin.system_health()
        assert result["status"] == "healthy"

    @pytest.mark.asyncio
    async def test_optimize_database(self, client, mock_httpx_client):
        """Test database optimization"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "space_freed_gb": 5.5
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.admin.optimize_database()
        assert result["status"] == "success"
