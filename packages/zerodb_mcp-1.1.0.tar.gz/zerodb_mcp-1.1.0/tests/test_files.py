"""
Tests for File operations
"""

import pytest
from unittest.mock import MagicMock


class TestFileOperations:
    """Test File operations"""

    @pytest.mark.asyncio
    async def test_upload_bytes(self, client, mock_httpx_client, sample_project_id):
        """Test uploading file from bytes"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "file_id": "file_uuid",
            "file_name": "test.pdf"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.upload_bytes(
            project_id=sample_project_id,
            content=b"PDF content",
            file_name="test.pdf"
        )
        assert result["file_id"] == "file_uuid"

    @pytest.mark.asyncio
    async def test_download(self, client, mock_httpx_client, sample_project_id):
        """Test downloading a file"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        # base64 encoded "PDF content"
        mock_response.json.return_value = {
            "file_id": "file_uuid",
            "content_base64": "UERGIGNvbnRlbnQ="
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.download(
            project_id=sample_project_id,
            file_id="file_uuid"
        )
        # download returns bytes when save_path is not provided
        assert isinstance(result, bytes)
        assert result == b"PDF content"

    @pytest.mark.asyncio
    async def test_list(self, client, mock_httpx_client, sample_project_id):
        """Test listing files"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "files": [{"file_id": "file1"}],
            "total": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.list(project_id=sample_project_id)
        assert len(result["files"]) == 1

    @pytest.mark.asyncio
    async def test_delete(self, client, mock_httpx_client, sample_project_id):
        """Test deleting a file"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"success": True}
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.delete(
            project_id=sample_project_id,
            file_id="file_uuid"
        )
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_get_metadata(self, client, mock_httpx_client, sample_project_id):
        """Test getting file metadata"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "file_id": "file_uuid",
            "file_name": "test.pdf"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.get_metadata(
            project_id=sample_project_id,
            file_id="file_uuid"
        )
        assert result["file_id"] == "file_uuid"

    @pytest.mark.asyncio
    async def test_generate_presigned_url(self, client, mock_httpx_client, sample_project_id):
        """Test generating presigned URL"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "url": "https://example.com/file",
            "expires_at": "2025-01-14T13:00:00Z"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.files.generate_presigned_url(
            project_id=sample_project_id,
            file_id="file_uuid"
        )
        assert "https://" in result["url"]
