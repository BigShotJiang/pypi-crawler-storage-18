"""
Tests for Quantum operations
"""

import pytest
from unittest.mock import MagicMock


class TestQuantumOperations:
    """Test Quantum operations"""

    @pytest.mark.asyncio
    async def test_compress_vector(self, client, mock_httpx_client, sample_project_id):
        """Test quantum vector compression"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "compressed_vector_id": "comp_uuid",
            "compression_ratio": 12.0
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.compress_vector(
            project_id=sample_project_id,
            vector_id="vec_uuid",
            target_dimensions=128
        )
        assert result["compression_ratio"] == 12.0

    @pytest.mark.asyncio
    async def test_compress_vector_invalid_dimensions_error(self, client, sample_project_id):
        """Test compression with invalid dimensions raises error"""
        with pytest.raises(ValueError, match="Target dimensions must be between 2 and 512"):
            await client.quantum.compress_vector(
                project_id=sample_project_id,
                vector_id="vec_uuid",
                target_dimensions=1
            )

    @pytest.mark.asyncio
    async def test_compress_vector_invalid_backend_error(self, client, sample_project_id):
        """Test compression with invalid backend raises error"""
        with pytest.raises(ValueError, match="Backend must be simulator, ionq, or braket"):
            await client.quantum.compress_vector(
                project_id=sample_project_id,
                vector_id="vec_uuid",
                target_dimensions=128,
                backend="invalid"
            )

    @pytest.mark.asyncio
    async def test_decompress_vector(self, client, mock_httpx_client, sample_project_id):
        """Test quantum vector decompression"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "decompressed_vector": [0.1] * 1536,
            "fidelity": 0.94
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.decompress_vector(
            project_id=sample_project_id,
            compressed_state=[complex(1, 0)] * 128,
            original_dimensions=1536
        )
        assert result["fidelity"] == 0.94

    @pytest.mark.asyncio
    async def test_hybrid_similarity(self, client, mock_httpx_client, sample_project_id):
        """Test quantum-enhanced hybrid similarity"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [{"vector_id": "vec1", "hybrid_score": 0.89}],
            "total_results": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.hybrid_similarity(
            project_id=sample_project_id,
            query_vector=[0.1] * 1536
        )
        assert len(result["results"]) == 1

    @pytest.mark.asyncio
    async def test_optimize_space(self, client, mock_httpx_client, sample_project_id):
        """Test quantum space optimization"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "optimization_results": {"space_saved_mb": 150.5}
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.optimize_space(project_id=sample_project_id)
        assert result["optimization_results"]["space_saved_mb"] == 150.5

    @pytest.mark.asyncio
    async def test_feature_map(self, client, mock_httpx_client, sample_project_id):
        """Test quantum feature mapping"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "mapped_state": [0.1] * 512,
            "feature_map_type": "ZZFeatureMap"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.feature_map(
            project_id=sample_project_id,
            vector_id="vec_uuid"
        )
        assert result["feature_map_type"] == "ZZFeatureMap"

    @pytest.mark.asyncio
    async def test_kernel_similarity(self, client, mock_httpx_client, sample_project_id):
        """Test quantum kernel similarity"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "quantum_similarity": 0.93,
            "kernel_type": "fidelity"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.quantum.kernel_similarity(
            project_id=sample_project_id,
            vector_id_a="vec_a_uuid",
            vector_id_b="vec_b_uuid"
        )
        assert result["quantum_similarity"] == 0.93
