"""
Test suite for ZeroDB MCP Python Client
"""
