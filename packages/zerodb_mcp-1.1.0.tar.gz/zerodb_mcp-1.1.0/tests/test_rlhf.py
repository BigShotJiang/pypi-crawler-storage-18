"""
Tests for RLHF operations
"""

import pytest
from unittest.mock import MagicMock


class TestRLHFOperations:
    """Test RLHF operations"""

    @pytest.mark.asyncio
    async def test_collect_interaction(self, client, mock_httpx_client, sample_project_id):
        """Test collecting user-agent interaction"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "interaction_id": "int_uuid",
            "session_id": "sess_123"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.collect_interaction(
            session_id="sess_123",
            project_id=sample_project_id,
            interaction_type="query",
            user_input="What is AI?",
            agent_response="AI is..."
        )
        assert result["interaction_id"] == "int_uuid"

    @pytest.mark.asyncio
    async def test_collect_agent_feedback(self, client, mock_httpx_client, sample_project_id):
        """Test collecting agent feedback"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "feedback_id": "feedback_uuid"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.collect_agent_feedback(
            session_id="sess_123",
            project_id=sample_project_id,
            interaction_id="int_uuid",
            rating=5
        )
        assert result["feedback_id"] == "feedback_uuid"

    @pytest.mark.asyncio
    async def test_collect_workflow_feedback(self, client, mock_httpx_client, sample_project_id):
        """Test collecting workflow feedback"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "workflow_feedback_id": "workflow_uuid"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.collect_workflow_feedback(
            session_id="sess_123",
            project_id=sample_project_id,
            workflow_id="workflow_123",
            success=True,
            duration_ms=250
        )
        assert result["workflow_feedback_id"] == "workflow_uuid"

    @pytest.mark.asyncio
    async def test_collect_error_report(self, client, mock_httpx_client, sample_project_id):
        """Test collecting error report"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "error_report_id": "error_uuid"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.collect_error_report(
            session_id="sess_123",
            project_id=sample_project_id,
            error_type="ValueError",
            error_message="Invalid input"
        )
        assert result["error_report_id"] == "error_uuid"

    @pytest.mark.asyncio
    async def test_get_status(self, client, mock_httpx_client, sample_project_id):
        """Test getting RLHF collection status"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "enabled": True,
            "active_sessions": 5,
            "total_interactions": 1000
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.get_status(project_id=sample_project_id)
        assert result["enabled"] is True

    @pytest.mark.asyncio
    async def test_get_summary(self, client, mock_httpx_client, sample_project_id):
        """Test getting RLHF summary"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_interactions": 1000,
            "average_rating": 4.2
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.get_summary(project_id=sample_project_id)
        assert result["total_interactions"] == 1000

    @pytest.mark.asyncio
    async def test_start_collection(self, client, mock_httpx_client, sample_project_id):
        """Test starting RLHF collection"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "session_id": "sess_789",
            "is_collecting": True
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.start_collection(
            session_id="sess_789",
            project_id=sample_project_id
        )
        assert result["is_collecting"] is True

    @pytest.mark.asyncio
    async def test_stop_collection(self, client, mock_httpx_client, sample_project_id):
        """Test stopping RLHF collection"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "session_id": "sess_789",
            "is_collecting": False
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.stop_collection(
            session_id="sess_789",
            project_id=sample_project_id
        )
        assert result["is_collecting"] is False

    @pytest.mark.asyncio
    async def test_get_session_interactions(self, client, mock_httpx_client, sample_project_id):
        """Test getting session interactions"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "interactions": [{"interaction_id": "int1"}],
            "total": 1
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.get_session_interactions(
            session_id="sess_123",
            project_id=sample_project_id
        )
        assert len(result["interactions"]) == 1

    @pytest.mark.asyncio
    async def test_broadcast_event(self, client, mock_httpx_client, sample_project_id):
        """Test broadcasting RLHF event"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "event_id": "event_uuid",
            "recipients": 5
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.rlhf.broadcast_event(
            project_id=sample_project_id,
            event_type="feedback_collected",
            event_data={"feedback_count": 100}
        )
        assert result["recipients"] == 5
