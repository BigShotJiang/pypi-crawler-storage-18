# Copyright (C) 2021 Bosutech XXI S.L.
#
# nucliadb is offered under the AGPL v3.0 and as commercial software.
# For commercial licensing, contact us at info@nuclia.com.
#
# AGPL:
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import logging
import time

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

PROCESS_TIME_HEADER = "X-PROCESS-TIME"
ACCESS_CONTROL_EXPOSE_HEADER = "Access-Control-Expose-Headers"

logger = logging.getLogger("nucliadb.middleware")


class ProcessTimeHeaderMiddleware(BaseHTTPMiddleware):
    def capture_process_time(self, response, duration: float):
        response.headers[PROCESS_TIME_HEADER] = str(duration)

    def expose_process_time_header(self, response):
        exposed_headers = []
        if ACCESS_CONTROL_EXPOSE_HEADER in response.headers:
            exposed_headers = response.headers[ACCESS_CONTROL_EXPOSE_HEADER].split(",")
        if PROCESS_TIME_HEADER not in exposed_headers:
            exposed_headers.append(PROCESS_TIME_HEADER)
            response.headers[ACCESS_CONTROL_EXPOSE_HEADER] = ",".join(exposed_headers)

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = None
        start = time.perf_counter()
        try:
            response = await call_next(request)
            return response
        finally:
            if response is not None:
                duration = time.perf_counter() - start
                self.capture_process_time(response, duration)
                self.expose_process_time_header(response)


class ClientErrorPayloadLoggerMiddleware(BaseHTTPMiddleware):
    """
    Middleware that logs the payload of client error responses (HTTP 412 and 422).
    This helps supporting clients by providing more context about the errors they
    encounter which otherwise we don't have much visibility on.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = None
        try:
            response = await call_next(request)
            return response
        finally:
            if response is not None and response.status_code in (412, 422):
                chunks = []
                async for chunk in response.body_iterator:  # type: ignore
                    chunks.append(chunk)
                response_body = b"".join(chunks)
                logger.info(
                    f"Client error. Response payload: {response_body.decode('utf-8')}",
                    extra={
                        "request_method": request.method,
                        "request_path": request.url.path,
                        "response_status_code": response.status_code,
                    },
                )
                # Recreate the response body iterator since it has been consumed
                return Response(
                    content=response_body,
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type=response.media_type,
                    background=response.background,
                )
