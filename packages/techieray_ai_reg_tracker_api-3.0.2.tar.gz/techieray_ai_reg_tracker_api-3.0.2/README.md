# techieray_ai_reg_tracker-api
Python client library for connecting to API of techie_ray's Global AI Regulation Tracker (www.techieray.com/GlobalAIRegulationTracker)

# API key
To use this API, you need to purchase an API key on a subscription basis.
Details are set out in the 'API Access' tab on https://www.techieray.com/GlobalAIRegulationTracker

# Example Usage:
    from techieray_ai_reg_tracker_api import GlobalAIRegulationTrackerClient
    api_key = "###INSERT API KEY###"

    client = GlobalAIRegulationTrackerClient(api_key)

    try:
        response = client.call(
            market = "US", 
            target_news = "latest_news", 
            target_date = "2024-10-06"
        )    
        print("Response:", response)
        
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
    
    except ValueError as e:
        print(f"Value Error: {e}")


# Types of searches:
The API currently supports 4 types of searches:

### Search updates for a specific date across all markets 
    client.call(
        market = "global",
        target_news = "",
        target_date = "2023-10-25"
    )

This searches for news updates dated 25 October 2023 across the world. Note that the target_news argument is intentionally left as "".

### Search updates for a specific date in a specific market
    client.call(
        market = "US",
        target_news = "",
        target_date = "2023-10-25"
    )
This searches for news updates dated 25 October 2023 in the United States of America ('US'). The search will go through all latest_news, sector_news and bilateral_multilateral_news (unless target_news argument is specified)

### Search specific class of updates in a specific market
    client.call(
        market = "US",
        target_news = "latest_news",
        target_date = ""
    )
This searches for latest_news (across all dates) in the United States of America ('US'). Note that the target_date argument is intentionally left as "".

### Search specific class of updates on specific date in a specific market
    client.call(
        market = "US",
        target_news = "latest_news",
        target_date = "2023-10-25"
    )
This searches for latest_news dated 25 October 2023 in the United States of America ('US').


# Arguments for target_news:
'latest_news' - retrieve entries from the "Latest Developments" section

'sector_news' - retrieve entries from the "Sector Developments" section

'bilateral_multilateral_news' - retrieve entries from the "Bilateral & Multilateral Developments" section

'official_materials' - retrieve entries from the "Official Materials" section

'acts_bills_reform' - retrieve entries from the "Acts, Bills & Reforms" section

'orders_admin_regs' - retrieve entries from the "Executive & Regulatory Instruments", "Executive Orders" (US) or "Measures, Provisions & Regulations" (China) sections

'guidelines_standards_frameworks' - retrieve entries from the "Guidelines, Frameworks & Standards" section

# Arguments for target_date:
The target_date argument is a string, and must be in the format 'yyyy-mm-dd'
For example, '2023-10-25'

# Arguments for market
Countries, regions and groups are represented the following codes.
    
    #Groups
    Europe: 'European Union',
    COE: 'Council of Europe',
    ASEAN: 'Association of Southeast Asian Nations',
    LAC: 'Intergovernmental Council on Artificial Intelligence for Latin America and the Caribbean',
    CLAD: 'Latin American Center for Development Administration',
    AFU: 'African Union',
    EARFAI: 'Eastern Africa Sub-Regional Forum on Artificial Intelligence',
    SARFAI: 'Southern Africa Sub-Regional Forum on Artificial Intelligence',
    CIS: ' Commonwealth of Independent States'
    G7: 'Group of Seven',
    G20: 'Group of Twenty',
    OECD: 'Organisation for Economic Co-operation and Development',
    
    #Countries
    AF: 'Afghanistan',
    AX: 'Åland Islands',
    AL: 'Albania',
    DZ: 'Algeria',
    AS: 'American Samoa',
    AD: 'Andorra',
    AO: 'Angola',
    AI: 'Anguilla',
    AQ: 'Antarctica',
    AG: 'Antigua and Barbuda',
    AR: 'Argentina',
    AM: 'Armenia',
    AW: 'Aruba',
    AU: 'Australia',
    AT: 'Austria (EU)',
    AZ: 'Azerbaijan',
    BS: 'Bahamas',
    BH: 'Bahrain',
    BD: 'Bangladesh',
    BB: 'Barbados',
    BY: 'Belarus',
    BE: 'Belgium (EU)',
    BZ: 'Belize',
    BJ: 'Benin',
    BM: 'Bermuda',
    BT: 'Bhutan',
    BO: 'Bolivia',
    BA: 'Bosnia and Herzegovina',
    BW: 'Botswana',
    BR: 'Brazil',
    IO: 'British Indian Ocean Territory',
    VG: 'British Virgin Islands',
    BN: 'Brunei Darussalam',
    BG: 'Bulgaria (EU)',
    BF: 'Burkina Faso',
    BI: 'Burundi',
    KH: 'Cambodia',
    CM: 'Cameroon',
    CA: 'Canada',
    CV: 'Cape Verde',
    BQ: 'Caribbean Netherlands',
    KY: 'Cayman Islands',
    CF: 'Central African Republic',
    TD: 'Chad',
    CL: 'Chile',
    CN: 'People\'s Republic of China',
    CX: 'Christmas Island',
    CC: 'Cocos Islands',
    CO: 'Colombia',
    KM: 'Comoros',
    CG: 'Congo',
    CK: 'Cook Islands',
    CR: 'Costa Rica',
    HR: 'Croatia (EU)',
    CU: 'Cuba',
    CW: 'Curaçao',
    CY: 'Cyprus (EU)',
    CZ: 'Czech Republic (EU)',
    CD: 'Democratic Republic of the Congo',
    DK: 'Denmark (EU)',
    DJ: 'Djibouti',
    DM: 'Dominica',
    DO: 'Dominican Republic',
    EC: 'Ecuador',
    EG: 'Egypt',
    SV: 'El Salvador',
    GQ: 'Equatorial Guinea',
    ER: 'Eritrea',
    EE: 'Estonia (EU)',
    ET: 'Ethiopia',
    FK: 'Falkland Islands',
    FO: 'Faroe Islands',
    FM: 'Federated States of Micronesia',
    FJ: 'Fiji',
    FI: 'Finland (EU)',
    FR: 'France (EU)',
    GF: 'French Guiana',
    PF: 'French Polynesia',
    TF: 'French Southern Territories',
    GA: 'Gabon',
    GM: 'Gambia',
    GE: 'Georgia',
    DE: 'Germany (EU)',
    GH: 'Ghana',
    GI: 'Gibraltar',
    GR: 'Greece (EU)',
    GL: 'Greenland',
    GD: 'Grenada',
    GP: 'Guadeloupe',
    GU: 'Guam',
    GT: 'Guatemala',
    GN: 'Guinea',
    GW: 'Guinea-Bissau',
    GY: 'Guyana',
    HT: 'Haiti',
    HN: 'Honduras',
    HK: 'Hong Kong SAR',
    HU: 'Hungary (EU)',
    IS: 'Iceland',
    IN: 'India',
    ID: 'Indonesia',
    IR: 'Iran',
    IQ: 'Iraq',
    IE: 'Ireland (EU)',
    IM: 'Isle of Man',
    IL: 'Israel',
    IT: 'Italy (EU)',
    CI: 'Ivory Coast',
    JM: 'Jamaica',
    JP: 'Japan',
    JE: 'Jersey',
    JO: 'Jordan',
    KZ: 'Kazakhstan',
    KE: 'Kenya',
    KI: 'Kiribati',
    XK: 'Kosovo',
    KW: 'Kuwait',
    KG: 'Kyrgyzstan',
    LA: 'Laos',
    LV: 'Latvia (EU)',
    LB: 'Lebanon',
    LS: 'Lesotho',
    LR: 'Liberia',
    LY: 'Libya',
    LI: 'Liechtenstein',
    LT: 'Lithuania (EU)',
    LU: 'Luxembourg (EU)',
    MO: 'Macau',
    MK: 'Macedonia',
    MG: 'Madagascar',
    MW: 'Malawi',
    MY: 'Malaysia',
    MV: 'Maldives',
    ML: 'Mali',
    MT: 'Malta (EU)',
    MH: 'Marshall Islands',
    MQ: 'Martinique',
    MR: 'Mauritania',
    MU: 'Mauritius',
    YT: 'Mayotte',
    MX: 'Mexico',
    MD: 'Moldova',
    MC: 'Monaco',
    MN: 'Mongolia',
    ME: 'Montenegro',
    MS: 'Montserrat',
    MA: 'Morocco',
    MZ: 'Mozambique',
    MM: 'Myanmar',
    NA: 'Namibia',
    NR: 'Nauru',
    NP: 'Nepal',
    NL: 'Netherlands (EU)',
    NC: 'New Caledonia',
    NZ: 'New Zealand',
    NI: 'Nicaragua',
    NE: 'Niger',
    NG: 'Nigeria',
    NU: 'Niue',
    NF: 'Norfolk Island',
    KP: 'North Korea',
    MP: 'Northern Mariana Islands',
    NO: 'Norway',
    OM: 'Oman',
    PK: 'Pakistan',
    PW: 'Palau',
    PS: 'Palestine',
    PA: 'Panama',
    PG: 'Papua New Guinea',
    PY: 'Paraguay',
    PE: 'Peru',
    PH: 'Philippines',
    PN: 'Pitcairn Islands',
    PL: 'Poland (EU)',
    PT: 'Portugal (EU)',
    PR: 'Puerto Rico',
    QA: 'Qatar',
    RE: 'Réunion',
    RO: 'Romania (EU)',
    RU: 'Russia',
    RW: 'Rwanda',
    SH: 'Saint Helena',
    KN: 'Saint Kitts and Nevis',
    LC: 'Saint Lucia',
    PM: 'Saint Pierre and Miquelon',
    VC: 'Saint Vincent and the Grenadines',
    WS: 'Samoa',
    SM: 'San Marino',
    ST: 'São Tomé and Príncipe',
    SA: 'Saudi Arabia',
    SN: 'Senegal',
    RS: 'Serbia',
    SC: 'Seychelles',
    SL: 'Sierra Leone',
    SG: 'Singapore',
    SX: 'Sint Maarten',
    SK: 'Slovakia (EU)',
    SI: 'Slovenia (EU)',
    SB: 'Solomon Islands',
    SO: 'Somalia',
    ZA: 'South Africa',
    GS: 'South Georgia and the South Sandwich Islands',
    KR: 'South Korea',
    SS: 'South Sudan',
    ES: 'Spain (EU)',
    LK: 'Sri Lanka',
    SD: 'Sudan',
    SR: 'Suriname',
    SJ: 'Svalbard and Jan Mayen',
    SZ: 'Eswatini',
    SE: 'Sweden (EU)',
    CH: 'Switzerland',
    SY: 'Syria',
    TW: 'Taiwan',
    TJ: 'Tajikistan',
    TZ: 'Tanzania',
    TH: 'Thailand',
    TL: 'Timor-Leste',
    TG: 'Togo',
    TK: 'Tokelau',
    TO: 'Tonga',
    TT: 'Trinidad and Tobago',
    TN: 'Tunisia',
    TR: 'Turkey',
    TM: 'Turkmenistan',
    TC: 'Turks and Caicos Islands',
    TV: 'Tuvalu',
    UG: 'Uganda',
    UA: 'Ukraine',
    AE: 'United Arab Emirates',
    GB: 'United Kingdom',
    US: 'United States',
    UM: 'United States Minor Outlying Islands',
    VI: 'United States Virgin Islands',
    UY: 'Uruguay',
    UZ: 'Uzbekistan',
    VU: 'Vanuatu',
    VA: 'Vatican City',
    VE: 'Venezuela',
    VN: 'Vietnam',
    WF: 'Wallis and Futuna',
    EH: 'Western Sahara',
    YE: 'Yemen',
    ZM: 'Zambia',
    ZW: 'Zimbabwe'

# Other languages
Countries, regions and groups are represented the following codes.

As of version 3.0.0, Chinese (simplified) is now available. To retrieve the API data in Chinese, specify the optional parameter lang_code to 'chn'. For example.

### Search specific class of updates on specific date in a specific market
    client.call(
        market = "US",
        target_news = "latest_news",
        target_date = "2023-10-25",
        lang_code = "chn"
    )

If you do not specify lang_code (or lang_code is specified as "eng", the API will by default return data in English).

# LICENCE TERMS
The licence terms are available here: https://docs.google.com/document/d/e/2PACX-1vQnGlGUDn83BHl-fNkQJIQNndktpK-AY2FGwR3z4-PkQQgvDrix-wZnoAOne6BDZw/pub

