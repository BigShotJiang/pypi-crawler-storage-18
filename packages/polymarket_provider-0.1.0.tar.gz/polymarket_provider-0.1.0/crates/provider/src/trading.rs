use chrono::{DateTime, Utc};
use duckdb::{params_from_iter, types::Value};
use pyo3::prelude::*;
use pyo3::types::PyList;
use serde_json::Value as JsonValue;

use crate::db::{load_json_extension, open_readonly};
use crate::errors::{PyResultExt, runtime_err};
use crate::row::column;

#[pyclass(name = "HistoryPoint")]
pub struct PyHistoryPoint {
    t: i64,
    p: f64,
}

#[pymethods]
impl PyHistoryPoint {
    #[getter]
    fn t(&self) -> i64 {
        self.t
    }

    #[getter]
    fn p(&self) -> f64 {
        self.p
    }

    fn __repr__(&self) -> String {
        "HistoryPoint".to_string()
    }
}

#[pyclass(name = "Timeseries")]
pub struct PyTimeseries {
    history: Py<PyList>,
}

#[pymethods]
impl PyTimeseries {
    #[getter]
    fn history(&self, py: Python) -> Py<PyList> {
        self.history.clone_ref(py)
    }

    fn __repr__(&self) -> String {
        "Timeseries".to_string()
    }
}

/// Trading data provider (historical timeseries)
#[pyclass(name = "Trading")]
pub struct PyTrading {
    db_path: String,
    simulation_time: Option<DateTime<Utc>>,
}

impl PyTrading {
    pub fn new(db_path: &str, simulation_time: Option<DateTime<Utc>>) -> Self {
        Self {
            db_path: db_path.to_string(),
            simulation_time,
        }
    }

    pub fn set_simulation_time_value(&mut self, simulation_time: Option<DateTime<Utc>>) {
        self.simulation_time = simulation_time;
    }
}

#[pymethods]
impl PyTrading {
    fn __repr__(&self) -> String {
        "TradingDataProvider".to_string()
    }

    /// Get historical timeseries data for a token.
    ///
    /// Args:
    ///     market: The CLOB token ID for which to fetch price history
    ///     start_ts: Optional start timestamp (unix seconds)
    ///     end_ts: Optional end timestamp (unix seconds)
    ///
    /// Returns:
    ///     Timeseries object containing history (filtered by timestamps)
    #[pyo3(signature = (market, start_ts=None, end_ts=None))]
    fn get_historical_timeseries(
        &self,
        py: Python,
        market: String,
        start_ts: Option<i64>,
        end_ts: Option<i64>,
    ) -> PyResult<Py<PyTimeseries>> {
        let conn = open_readonly(&self.db_path)?;
        load_json_extension(&conn)?;

        let query = "SELECT raw_data FROM historical_timeseries_data WHERE token_id = ?";

        let mut stmt = conn
            .prepare(query)
            .py_context("prepare historical timeseries query")?;

        let mut rows = stmt
            .query(params_from_iter([Value::Text(market)]))
            .py_context("execute historical timeseries query")?;

        let Some(row) = rows.next().py_context("fetch historical timeseries row")? else {
            let list = PyList::empty(py);
            return Py::new(
                py,
                PyTimeseries {
                    history: list.unbind(),
                },
            );
        };
        let raw_data: JsonValue = column(row, 0, "raw_data")?;
        let history = filter_history(&raw_data, start_ts, end_ts, self.simulation_time)?;
        let list = PyList::empty(py);
        for entry in history {
            let point = Py::new(
                py,
                PyHistoryPoint {
                    t: entry.t,
                    p: entry.p,
                },
            )?;
            list.append(point)?;
        }
        Py::new(
            py,
            PyTimeseries {
                history: list.unbind(),
            },
        )
    }
}

fn filter_history(
    raw_data: &JsonValue,
    start_ts: Option<i64>,
    end_ts: Option<i64>,
    simulation_time: Option<DateTime<Utc>>,
) -> PyResult<Vec<HistoryPoint>> {
    let history_list = history_items(raw_data)?;

    let max_ts = match (end_ts, simulation_time) {
        (Some(end_ts), Some(sim_time)) => Some(end_ts.min(sim_time.timestamp())),
        (None, Some(sim_time)) => Some(sim_time.timestamp()),
        (Some(end_ts), None) => Some(end_ts),
        (None, None) => None,
    };

    let mut result = Vec::new();
    for item in history_list {
        let Some(obj) = item.as_object() else {
            continue;
        };
        let Some(ts) = obj.get("t").and_then(parse_i64) else {
            continue;
        };
        if let Some(start) = start_ts
            && ts < start
        {
            continue;
        }
        if let Some(end) = max_ts
            && ts > end
        {
            continue;
        }
        let Some(price) = obj.get("p").and_then(parse_f64) else {
            continue;
        };
        result.push(HistoryPoint { t: ts, p: price });
    }

    Ok(result)
}

fn history_items(payload: &JsonValue) -> PyResult<&[JsonValue]> {
    match payload {
        JsonValue::Array(items) => Ok(items),
        JsonValue::Object(obj) => {
            let history = obj
                .get("history")
                .ok_or_else(|| runtime_err("raw_data missing history field"))?;
            history
                .as_array()
                .map(|items| items.as_slice())
                .ok_or_else(|| runtime_err("history must be a list"))
        }
        _ => Err(runtime_err("raw_data must be a list or dict with history")),
    }
}

fn parse_i64(value: &JsonValue) -> Option<i64> {
    match value {
        JsonValue::Number(num) => num
            .as_i64()
            .or_else(|| num.as_u64().map(|v| v as i64))
            .or_else(|| num.as_f64().map(|v| v as i64)),
        JsonValue::String(value) => value.parse::<i64>().ok(),
        _ => None,
    }
}

fn parse_f64(value: &JsonValue) -> Option<f64> {
    match value {
        JsonValue::Number(num) => num.as_f64().or_else(|| num.as_i64().map(|v| v as f64)),
        JsonValue::String(value) => value.parse::<f64>().ok(),
        _ => None,
    }
}

struct HistoryPoint {
    t: i64,
    p: f64,
}
