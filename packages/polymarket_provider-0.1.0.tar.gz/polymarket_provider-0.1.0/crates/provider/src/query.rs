use pyo3::PyResult;

use crate::errors::runtime_err;

pub(crate) fn push_limit(query: &mut String, limit: Option<i64>) -> PyResult<()> {
    if let Some(limit) = limit {
        if limit < 0 {
            return Err(runtime_err("limit must be non-negative"));
        }
        query.push_str(" LIMIT ");
        query.push_str(&limit.to_string());
    }
    Ok(())
}

pub(crate) fn push_offset(query: &mut String, offset: Option<i64>) -> PyResult<()> {
    if let Some(offset) = offset {
        if offset < 0 {
            return Err(runtime_err("offset must be non-negative"));
        }
        query.push_str(" OFFSET ");
        query.push_str(&offset.to_string());
    }
    Ok(())
}
