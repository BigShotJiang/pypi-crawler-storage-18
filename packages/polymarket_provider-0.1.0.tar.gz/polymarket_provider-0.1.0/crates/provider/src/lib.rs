mod db;
mod errors;
mod off_chain;
mod on_chain;
mod pytime;
mod query;
mod row;
mod trading;

use chrono::{DateTime, Utc};
use pyo3::prelude::*;
use pytime::parse_simulation_time;

/// Polymarket data provider for Python
#[pymodule]
fn polymarket_provider(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyDataProvider>()?;
    m.add_class::<on_chain::PyOnChain>()?;
    m.add_class::<on_chain::PyOrderFilledEvent>()?;
    m.add_class::<on_chain::PyFpmmTransaction>()?;
    m.add_class::<off_chain::PyOffChain>()?;
    m.add_class::<trading::PyTrading>()?;
    m.add_class::<off_chain::PyMarket>()?;
    m.add_class::<off_chain::PyMarketToken>()?;
    m.add_class::<trading::PyHistoryPoint>()?;
    m.add_class::<trading::PyTimeseries>()?;
    Ok(())
}

/// Main data provider class
#[pyclass(name = "DataProvider")]
pub struct PyDataProvider {
    simulation_time: Option<DateTime<Utc>>,
    on_chain: Py<on_chain::PyOnChain>,
    off_chain: Py<off_chain::PyOffChain>,
    trading: Py<trading::PyTrading>,
}

#[pymethods]
impl PyDataProvider {
    #[new]
    #[pyo3(signature = (
        onchain_db_path = "data/onchain.duckdb",
        offchain_db_path = "data/offchain.duckdb",
        simulation_time = None
    ))]
    /// Args:
    ///     simulation_time: Unix timestamp in UTC seconds. None disables simulation-time filtering.
    fn new(
        py: Python,
        onchain_db_path: &str,
        offchain_db_path: &str,
        simulation_time: Option<i64>,
    ) -> PyResult<Self> {
        let simulation_time_value = parse_simulation_time(simulation_time)?;
        let on_chain = Py::new(py, on_chain::PyOnChain::new(onchain_db_path))?;
        let off_chain = Py::new(
            py,
            off_chain::PyOffChain::new(offchain_db_path, simulation_time_value),
        )?;
        let trading = Py::new(
            py,
            trading::PyTrading::new(offchain_db_path, simulation_time_value),
        )?;
        Ok(Self {
            simulation_time: simulation_time_value,
            on_chain,
            off_chain,
            trading,
        })
    }

    /// On-chain data (order_filled_event, fpmm_transaction)
    #[getter]
    fn on_chain(&self, py: Python) -> Py<on_chain::PyOnChain> {
        self.on_chain.clone_ref(py)
    }

    /// Off-chain data (markets, market_tokens)
    #[getter]
    fn off_chain(&self, py: Python) -> Py<off_chain::PyOffChain> {
        self.off_chain.clone_ref(py)
    }

    /// Trading data (historical_timeseries_data)
    #[getter]
    fn trading(&self, py: Python) -> Py<trading::PyTrading> {
        self.trading.clone_ref(py)
    }

    /// Set SimulationTime (Unix timestamp in UTC seconds).
    fn set_simulation_time(&mut self, py: Python, simulation_time: Option<i64>) -> PyResult<()> {
        let parsed = parse_simulation_time(simulation_time)?;
        self.simulation_time = parsed;
        self.off_chain
            .bind(py)
            .borrow_mut()
            .set_simulation_time_value(parsed);
        self.trading
            .bind(py)
            .borrow_mut()
            .set_simulation_time_value(parsed);
        Ok(())
    }

    /// Get SimulationTime (Unix timestamp in UTC seconds, or None).
    fn get_simulation_time(&self) -> PyResult<Option<i64>> {
        Ok(self.simulation_time.map(|value| value.timestamp()))
    }

    fn __repr__(&self) -> String {
        "PolymarketDataProvider".to_string()
    }
}
