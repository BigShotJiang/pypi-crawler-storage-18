use duckdb::{AccessMode, Config, Connection};
use pyo3::PyResult;

use crate::errors::PyResultExt;

pub(crate) fn open_readonly(path: &str) -> PyResult<Connection> {
    let config = Config::default()
        .access_mode(AccessMode::ReadOnly)
        .py_context("configure read-only mode")?;
    Connection::open_with_flags(path, config).py_context(format!("open database at {path}"))
}

pub(crate) fn load_json_extension(conn: &Connection) -> PyResult<()> {
    conn.execute_batch("LOAD json")
        .py_context("load DuckDB json extension")?;
    Ok(())
}
