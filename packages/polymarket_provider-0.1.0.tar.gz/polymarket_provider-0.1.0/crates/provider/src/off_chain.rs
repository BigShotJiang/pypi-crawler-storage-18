use chrono::{DateTime, SecondsFormat, Utc};
use duckdb::{params_from_iter, types::Value};
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBool, PyDict, PyList};
use serde_json::Value as JsonValue;

use crate::db::{load_json_extension, open_readonly};
use crate::errors::{PyResultExt, runtime_err};
use crate::pytime::parse_market_datetime;
use crate::query::{push_limit, push_offset};
use crate::row::column;

/// Off-chain data provider
#[pyclass(name = "OffChain")]
pub struct PyOffChain {
    db_path: String,
    simulation_time: Option<DateTime<Utc>>,
}

impl PyOffChain {
    pub fn new(db_path: &str, simulation_time: Option<DateTime<Utc>>) -> Self {
        Self {
            db_path: db_path.to_string(),
            simulation_time,
        }
    }

    pub fn set_simulation_time_value(&mut self, simulation_time: Option<DateTime<Utc>>) {
        self.simulation_time = simulation_time;
    }
}

#[pyclass(name = "Market")]
pub struct PyMarket {
    raw_data: Py<PyDict>,
}

#[pymethods]
impl PyMarket {
    #[getter]
    fn raw_data(&self, py: Python) -> Py<PyDict> {
        self.raw_data.clone_ref(py)
    }

    fn __repr__(&self) -> String {
        "Market".to_string()
    }
}

#[pyclass(name = "MarketToken")]
pub struct PyMarketToken {
    token_id: String,
    market_id: u64,
    outcome: Option<String>,
    outcome_index: i64,
    outcome_price: Option<String>,
}

#[pymethods]
impl PyMarketToken {
    #[getter]
    fn token_id(&self) -> &str {
        &self.token_id
    }

    #[getter]
    fn market_id(&self) -> u64 {
        self.market_id
    }

    #[getter]
    fn outcome(&self) -> Option<&str> {
        self.outcome.as_deref()
    }

    #[getter]
    fn outcome_index(&self) -> i64 {
        self.outcome_index
    }

    #[getter]
    fn outcome_price(&self) -> Option<&str> {
        self.outcome_price.as_deref()
    }

    fn __repr__(&self) -> String {
        "MarketToken".to_string()
    }
}

#[pymethods]
impl PyOffChain {
    fn __repr__(&self) -> String {
        "OffChainDataProvider".to_string()
    }

    /// List markets with Polymarket-style query parameters.
    ///
    /// Returns Market objects with raw_data dictionaries.
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (
        limit=None,
        offset=None,
        order=None,
        ascending=None,
        id=None,
        slug=None,
        clob_token_ids=None,
        condition_ids=None,
        market_maker_address=None,
        liquidity_num_min=None,
        liquidity_num_max=None,
        volume_num_min=None,
        volume_num_max=None,
        start_date_min=None,
        start_date_max=None,
        end_date_min=None,
        end_date_max=None,
        tag_id=None,
        related_tags=None,
        cyom=None,
        uma_resolution_status=None,
        game_id=None,
        sports_market_types=None,
        rewards_min_size=None,
        question_ids=None,
        include_tag=None,
        closed=None
    ))]
    fn list_markets(
        &self,
        py: Python,
        limit: Option<i64>,
        offset: Option<i64>,
        order: Option<String>,
        ascending: Option<bool>,
        id: Option<Vec<u64>>,
        slug: Option<Vec<String>>,
        clob_token_ids: Option<Vec<String>>,
        condition_ids: Option<Vec<String>>,
        market_maker_address: Option<Vec<String>>,
        liquidity_num_min: Option<f64>,
        liquidity_num_max: Option<f64>,
        volume_num_min: Option<f64>,
        volume_num_max: Option<f64>,
        start_date_min: Option<String>,
        start_date_max: Option<String>,
        end_date_min: Option<String>,
        end_date_max: Option<String>,
        tag_id: Option<i64>,
        related_tags: Option<bool>,
        cyom: Option<bool>,
        uma_resolution_status: Option<String>,
        game_id: Option<String>,
        sports_market_types: Option<Vec<String>>,
        rewards_min_size: Option<f64>,
        question_ids: Option<Vec<String>>,
        include_tag: Option<bool>,
        closed: Option<bool>,
    ) -> PyResult<Vec<Py<PyMarket>>> {
        let conn = open_readonly(&self.db_path)?;

        let mut query = String::from("SELECT raw_data FROM markets");
        let mut conditions: Vec<String> = Vec::new();
        let mut params: Vec<Value> = Vec::new();

        if let Some(ids) = &id {
            if ids.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(&mut conditions, "id", ids.len());
            params.extend(ids.iter().map(|value| Value::UBigInt(*value)));
        }
        if let Some(values) = &slug {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(&mut conditions, "raw_data->>'$.slug'", values.len());
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(values) = &clob_token_ids {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            let placeholders = placeholders(values.len());
            conditions.push(format!(
                "id IN (SELECT DISTINCT market_id FROM market_tokens WHERE token_id IN ({placeholders}))"
            ));
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(values) = &condition_ids {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(&mut conditions, "raw_data->>'$.conditionId'", values.len());
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(values) = &market_maker_address {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(
                &mut conditions,
                "raw_data->>'$.marketMakerAddress'",
                values.len(),
            );
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(min) = liquidity_num_min {
            conditions.push("try_cast(raw_data->>'$.liquidityNum' AS DOUBLE) >= ?".to_string());
            params.push(Value::Double(min));
        }
        if let Some(max) = liquidity_num_max {
            conditions.push("try_cast(raw_data->>'$.liquidityNum' AS DOUBLE) <= ?".to_string());
            params.push(Value::Double(max));
        }
        if let Some(min) = volume_num_min {
            conditions.push("try_cast(raw_data->>'$.volumeNum' AS DOUBLE) >= ?".to_string());
            params.push(Value::Double(min));
        }
        if let Some(max) = volume_num_max {
            conditions.push("try_cast(raw_data->>'$.volumeNum' AS DOUBLE) <= ?".to_string());
            params.push(Value::Double(max));
        }
        if let Some(min) = start_date_min {
            conditions.push("raw_data->>'$.startDate' >= ?".to_string());
            params.push(Value::Text(min));
        }
        if let Some(max) = start_date_max {
            conditions.push("raw_data->>'$.startDate' <= ?".to_string());
            params.push(Value::Text(max));
        }
        if let Some(min) = end_date_min {
            conditions.push("raw_data->>'$.endDate' >= ?".to_string());
            params.push(Value::Text(min));
        }
        if let Some(max) = end_date_max {
            conditions.push("raw_data->>'$.endDate' <= ?".to_string());
            params.push(Value::Text(max));
        }
        if let Some(tag_id) = tag_id {
            conditions.push("json_contains(raw_data->'$.tags', json(?))".to_string());
            params.push(Value::Text(format!("{{\"id\":{tag_id}}}")));
        }
        if let Some(cyom) = cyom {
            conditions.push("raw_data->>'$.cyom' = ?".to_string());
            params.push(Value::Text(if cyom { "true" } else { "false" }.to_string()));
        }
        if let Some(status) = uma_resolution_status {
            conditions.push("raw_data->>'$.umaResolutionStatus' = ?".to_string());
            params.push(Value::Text(status));
        }
        if let Some(game_id) = game_id {
            conditions.push("raw_data->>'$.gameId' = ?".to_string());
            params.push(Value::Text(game_id));
        }
        if let Some(values) = &sports_market_types {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(
                &mut conditions,
                "raw_data->>'$.sportsMarketType'",
                values.len(),
            );
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(min) = rewards_min_size {
            conditions.push("try_cast(raw_data->>'$.rewardsMinSize' AS DOUBLE) >= ?".to_string());
            params.push(Value::Double(min));
        }
        if let Some(values) = &question_ids {
            if values.is_empty() {
                return Ok(Vec::new());
            }
            push_in_clause(&mut conditions, "raw_data->>'$.questionID'", values.len());
            params.extend(values.iter().cloned().map(Value::Text));
        }
        if let Some(closed) = closed {
            if let Some(simulation_time) = self.simulation_time {
                let sim_time = simulation_time.to_rfc3339_opts(SecondsFormat::Secs, true);
                if closed {
                    conditions.push(
                        "raw_data->>'$.startDate' IS NULL OR raw_data->>'$.endDate' IS NULL \
                         OR ? < raw_data->>'$.startDate' OR ? > raw_data->>'$.endDate'"
                            .to_string(),
                    );
                } else {
                    conditions.push(
                        "raw_data->>'$.startDate' IS NOT NULL AND raw_data->>'$.endDate' IS NOT NULL \
                         AND ? >= raw_data->>'$.startDate' AND ? <= raw_data->>'$.endDate'"
                            .to_string(),
                    );
                }
                params.push(Value::Text(sim_time.clone()));
                params.push(Value::Text(sim_time));
            } else {
                conditions.push("raw_data->>'$.closed' = ?".to_string());
                params.push(Value::Text(
                    if closed { "true" } else { "false" }.to_string(),
                ));
            }
        }

        if !conditions.is_empty() {
            query.push_str(" WHERE ");
            query.push_str(&conditions.join(" AND "));
        }

        query.push_str(&order_clause(order.as_deref(), ascending)?);

        push_limit(&mut query, limit)?;
        push_offset(&mut query, offset)?;

        let _ = (related_tags, include_tag);

        load_json_extension(&conn)?;

        let mut stmt = conn.prepare(&query).py_context("prepare markets query")?;

        let mut result = Vec::new();
        let mut rows = stmt
            .query(params_from_iter(params.iter()))
            .py_context("execute markets query")?;

        while let Some(row) = rows.next().py_context("fetch markets row")? {
            let mut raw_data: JsonValue = column(row, 0, "raw_data")?;
            apply_simulation_time(&mut raw_data, self.simulation_time)?;
            let raw_dict = json_to_pydict(py, &raw_data)?;
            result.push(Py::new(py, PyMarket { raw_data: raw_dict })?);
        }

        Ok(result)
    }

    /// Get a single market by ID
    ///
    /// Args:
    ///     market_id: The market ID
    ///
    /// Returns:
    ///     Raw data dictionary or None if not found
    fn get_market(&self, py: Python, market_id: &str) -> PyResult<Option<Py<PyMarket>>> {
        let conn = open_readonly(&self.db_path)?;
        let query = "SELECT raw_data FROM markets WHERE id = ?";
        let mut stmt = conn
            .prepare(query)
            .py_context("prepare market lookup query")?;

        let mut rows = stmt
            .query(params_from_iter([Value::Text(market_id.to_string())]))
            .py_context("execute market lookup query")?;

        if let Some(row) = rows.next().py_context("fetch market row")? {
            let mut raw_data: JsonValue = column(row, 0, "raw_data")?;
            apply_simulation_time(&mut raw_data, self.simulation_time)?;

            let raw_dict = json_to_pydict(py, &raw_data)?;
            Ok(Some(Py::new(py, PyMarket { raw_data: raw_dict })?))
        } else {
            Ok(None)
        }
    }

    /// List market tokens for a market
    ///
    /// Args:
    ///     market_id: Filter by market ID (None for all tokens)
    ///
    /// Returns:
    ///     List of dictionaries containing token data
    #[pyo3(signature = (market_id=None))]
    fn list_market_tokens(
        &self,
        py: Python,
        market_id: Option<u64>,
    ) -> PyResult<Vec<Py<PyMarketToken>>> {
        let conn = open_readonly(&self.db_path)?;

        let mut query = String::from(
            "SELECT token_id, market_id, outcome, outcome_index, outcome_price FROM market_tokens",
        );
        let mut params: Vec<Value> = Vec::new();
        if let Some(mid) = &market_id {
            query.push_str(" WHERE market_id = ?");
            params.push(Value::UBigInt(*mid));
        }
        query.push_str(" ORDER BY outcome_index ASC");

        let mut stmt = conn
            .prepare(&query)
            .py_context("prepare market_tokens query")?;

        let mut result = Vec::new();
        let mut rows = stmt
            .query(params_from_iter(params.iter()))
            .py_context("execute market_tokens query")?;

        while let Some(row) = rows.next().py_context("fetch market_tokens row")? {
            let token = PyMarketToken {
                token_id: column::<String>(row, 0, "token_id")?,
                market_id: column::<u64>(row, 1, "market_id")?,
                outcome: column(row, 2, "outcome")?,
                outcome_index: column::<i64>(row, 3, "outcome_index")?,
                outcome_price: column(row, 4, "outcome_price")?,
            };

            result.push(Py::new(py, token)?);
        }

        Ok(result)
    }
}

fn apply_simulation_time(
    raw_data: &mut JsonValue,
    simulation_time: Option<DateTime<Utc>>,
) -> PyResult<()> {
    let Some(simulation_time) = simulation_time else {
        return Ok(());
    };

    let Some(raw_obj) = raw_data.as_object_mut() else {
        return Ok(());
    };
    let start = raw_obj.get("startDate").and_then(parse_market_datetime);
    let end = raw_obj.get("endDate").and_then(parse_market_datetime);

    if let (Some(start), Some(end)) = (start, end)
        && simulation_time >= start
        && simulation_time <= end
    {
        raw_obj.insert("closed".to_string(), JsonValue::Bool(false));
        raw_obj.insert("active".to_string(), JsonValue::Bool(true));
    }

    Ok(())
}

fn json_to_pydict(py: Python, value: &JsonValue) -> PyResult<Py<PyDict>> {
    let dict = json_to_py_bound(py, value)?.cast_into::<PyDict>()?;
    Ok(dict.unbind())
}

fn json_to_py_bound<'py>(py: Python<'py>, value: &JsonValue) -> PyResult<Bound<'py, PyAny>> {
    Ok(match value {
        JsonValue::Null => py.None().into_bound(py),
        JsonValue::Bool(value) => PyBool::new(py, *value).to_owned().into_any(),
        JsonValue::Number(value) => {
            if let Some(value) = value.as_i64() {
                value.into_pyobject(py)?.into_any()
            } else if let Some(value) = value.as_u64() {
                value.into_pyobject(py)?.into_any()
            } else if let Some(value) = value.as_f64() {
                value.into_pyobject(py)?.into_any()
            } else {
                py.None().into_bound(py)
            }
        }
        JsonValue::String(value) => value.into_pyobject(py)?.into_any(),
        JsonValue::Array(items) => {
            let list = PyList::empty(py);
            for item in items {
                list.append(json_to_py_bound(py, item)?)?;
            }
            list.into_any()
        }
        JsonValue::Object(map) => {
            let dict = PyDict::new(py);
            for (key, value) in map {
                dict.set_item(key, json_to_py_bound(py, value)?)?;
            }
            dict.into_any()
        }
    })
}

fn order_clause(order: Option<&str>, ascending: Option<bool>) -> PyResult<String> {
    let Some(order) = order else {
        return Ok(" ORDER BY updated_at DESC".to_string());
    };

    let mut fields: Vec<&'static str> = Vec::new();
    for field in order.split(',') {
        let field = field.trim();
        if field.is_empty() {
            continue;
        }
        match order_expression(field) {
            Some(expr) => fields.push(expr),
            None => return Err(runtime_err(format!("unsupported order field: {field}"))),
        }
    }

    if fields.is_empty() {
        return Ok(" ORDER BY updated_at DESC".to_string());
    }

    let direction = if ascending.unwrap_or(false) {
        "ASC"
    } else {
        "DESC"
    };
    let clauses: Vec<String> = fields
        .into_iter()
        .map(|expr| format!("{expr} {direction}"))
        .collect();
    Ok(format!(" ORDER BY {}", clauses.join(", ")))
}

fn order_expression(field: &str) -> Option<&'static str> {
    match field {
        "id" => Some("id"),
        "updated_at" | "updatedAt" => Some("updated_at"),
        "created_at" | "createdAt" => Some("raw_data->>'$.createdAt'"),
        "end_date" | "endDate" => Some("raw_data->>'$.endDate'"),
        "start_date" | "startDate" => Some("raw_data->>'$.startDate'"),
        "volume_num" | "volumeNum" => Some("try_cast(raw_data->>'$.volumeNum' AS DOUBLE)"),
        "liquidity_num" | "liquidityNum" => Some("try_cast(raw_data->>'$.liquidityNum' AS DOUBLE)"),
        "volume24hr" | "volume_24hr" => Some("try_cast(raw_data->>'$.volume24hr' AS DOUBLE)"),
        "volume1wk" | "volume_1wk" => Some("try_cast(raw_data->>'$.volume1wk' AS DOUBLE)"),
        "volume1mo" | "volume_1mo" => Some("try_cast(raw_data->>'$.volume1mo' AS DOUBLE)"),
        "volume1yr" | "volume_1yr" => Some("try_cast(raw_data->>'$.volume1yr' AS DOUBLE)"),
        "liquidity" => Some("try_cast(raw_data->>'$.liquidity' AS DOUBLE)"),
        "volume" => Some("try_cast(raw_data->>'$.volume' AS DOUBLE)"),
        "score" => Some("try_cast(raw_data->>'$.score' AS DOUBLE)"),
        _ => None,
    }
}

fn push_in_clause(conditions: &mut Vec<String>, expr: &str, count: usize) {
    conditions.push(format!("{expr} IN ({})", placeholders(count)));
}

fn placeholders(count: usize) -> String {
    std::iter::repeat_n("?", count)
        .collect::<Vec<_>>()
        .join(", ")
}
