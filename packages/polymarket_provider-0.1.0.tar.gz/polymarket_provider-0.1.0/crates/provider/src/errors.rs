use pyo3::exceptions::PyRuntimeError;
use pyo3::{PyErr, PyResult};
use std::fmt::Display;

pub(crate) fn runtime_err(message: impl Into<String>) -> PyErr {
    PyErr::new::<PyRuntimeError, _>(message.into())
}

pub(crate) trait PyResultExt<T> {
    fn py_context(self, context: impl Into<String>) -> PyResult<T>;
}

impl<T, E> PyResultExt<T> for Result<T, E>
where
    E: Display,
{
    fn py_context(self, context: impl Into<String>) -> PyResult<T> {
        self.map_err(|err| runtime_err(format!("{}: {}", context.into(), err)))
    }
}
