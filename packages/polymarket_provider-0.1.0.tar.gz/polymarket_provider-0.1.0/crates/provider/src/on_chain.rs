use crate::db::open_readonly;
use crate::errors::{PyResultExt, runtime_err};
use crate::query::{push_limit, push_offset};
use crate::row::column;
use duckdb::{params_from_iter, types::Value};
use pyo3::prelude::*;

#[pyclass(name = "OrderFilledEvent")]
pub struct PyOrderFilledEvent {
    id: String,
    transaction_hash: String,
    timestamp: i64,
    order_hash: String,
    maker: String,
    taker: String,
    maker_asset_id: String,
    taker_asset_id: String,
    maker_amount_filled: String,
    taker_amount_filled: String,
    fee: String,
}

#[pymethods]
impl PyOrderFilledEvent {
    #[getter]
    fn id(&self) -> &str {
        &self.id
    }

    #[getter]
    fn transaction_hash(&self) -> &str {
        &self.transaction_hash
    }

    #[getter]
    fn timestamp(&self) -> i64 {
        self.timestamp
    }

    #[getter]
    fn order_hash(&self) -> &str {
        &self.order_hash
    }

    #[getter]
    fn maker(&self) -> &str {
        &self.maker
    }

    #[getter]
    fn taker(&self) -> &str {
        &self.taker
    }

    #[getter]
    fn maker_asset_id(&self) -> &str {
        &self.maker_asset_id
    }

    #[getter]
    fn taker_asset_id(&self) -> &str {
        &self.taker_asset_id
    }

    #[getter]
    fn maker_amount_filled(&self) -> &str {
        &self.maker_amount_filled
    }

    #[getter]
    fn taker_amount_filled(&self) -> &str {
        &self.taker_amount_filled
    }

    #[getter]
    fn fee(&self) -> &str {
        &self.fee
    }

    fn __repr__(&self) -> String {
        "OrderFilledEvent".to_string()
    }
}

#[pyclass(name = "FpmmTransaction")]
pub struct PyFpmmTransaction {
    id: String,
    timestamp: i64,
    market_id: String,
    user: String,
    transaction_type: String,
    trade_amount: String,
    fee_amount: String,
    outcome_index: i64,
    outcome_tokens_amount: String,
}

#[pymethods]
impl PyFpmmTransaction {
    #[getter]
    fn id(&self) -> &str {
        &self.id
    }

    #[getter]
    fn timestamp(&self) -> i64 {
        self.timestamp
    }

    #[getter]
    fn market_id(&self) -> &str {
        &self.market_id
    }

    #[getter]
    fn user(&self) -> &str {
        &self.user
    }

    #[getter]
    fn transaction_type(&self) -> &str {
        &self.transaction_type
    }

    #[getter]
    fn trade_amount(&self) -> &str {
        &self.trade_amount
    }

    #[getter]
    fn fee_amount(&self) -> &str {
        &self.fee_amount
    }

    #[getter]
    fn outcome_index(&self) -> i64 {
        self.outcome_index
    }

    #[getter]
    fn outcome_tokens_amount(&self) -> &str {
        &self.outcome_tokens_amount
    }

    fn __repr__(&self) -> String {
        "FpmmTransaction".to_string()
    }
}

/// On-chain data provider
#[pyclass(name = "OnChain")]
pub struct PyOnChain {
    db_path: String,
}

impl PyOnChain {
    pub fn new(db_path: &str) -> Self {
        Self {
            db_path: db_path.to_string(),
        }
    }
}

#[pymethods]
impl PyOnChain {
    fn __repr__(&self) -> String {
        "OnChainDataProvider".to_string()
    }

    /// List order filled events
    ///
    /// Args:
    ///     market: Optional token ID (matches makerAssetId or takerAssetId)
    ///     start_ts: Optional start timestamp (unix seconds)
    ///     end_ts: Optional end timestamp (unix seconds)
    ///     limit: Maximum number of rows to return
    ///     offset: Rows to skip
    ///     order: Comma-separated list of fields to order by
    ///     ascending: Sort order (default: true)
    ///
    /// Returns:
    ///     List of OrderFilledEvent objects
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (
        market=None,
        start_ts=None,
        end_ts=None,
        limit=None,
        offset=None,
        order=None,
        ascending=true
    ))]
    fn list_orders(
        &self,
        py: Python,
        market: Option<String>,
        start_ts: Option<i64>,
        end_ts: Option<i64>,
        limit: Option<i64>,
        offset: Option<i64>,
        order: Option<String>,
        ascending: bool,
    ) -> PyResult<Vec<Py<PyOrderFilledEvent>>> {
        let conn = open_readonly(&self.db_path)?;

        let mut query = String::from(
            "SELECT id, transaction_hash, timestamp, order_hash, maker, taker, \
                  maker_asset_id, taker_asset_id, maker_amount_filled, taker_amount_filled, fee \
             FROM order_filled_event",
        );
        let mut conditions: Vec<String> = Vec::new();
        let mut params: Vec<Value> = Vec::new();

        if let Some(token_id) = &market {
            conditions.push("(maker_asset_id = ? OR taker_asset_id = ?)".to_string());
            params.push(Value::Text(token_id.clone()));
            params.push(Value::Text(token_id.clone()));
        }
        if let Some(ts) = start_ts {
            conditions.push("timestamp >= ?".to_string());
            params.push(Value::BigInt(ts));
        }
        if let Some(ts) = end_ts {
            conditions.push("timestamp <= ?".to_string());
            params.push(Value::BigInt(ts));
        }

        if !conditions.is_empty() {
            query.push_str(" WHERE ");
            query.push_str(&conditions.join(" AND "));
        }

        query.push_str(&orders_order_clause(order.as_deref(), ascending)?);

        push_limit(&mut query, limit)?;
        push_offset(&mut query, offset)?;

        let mut stmt = conn.prepare(&query).py_context("prepare orders query")?;
        let mut rows = stmt
            .query(params_from_iter(params.iter()))
            .py_context("execute orders query")?;

        let mut rows_out = Vec::new();
        while let Some(row) = rows.next().py_context("fetch orders row")? {
            rows_out.push(PyOrderFilledEvent {
                id: column::<String>(row, 0, "id")?,
                transaction_hash: column::<String>(row, 1, "transaction_hash")?,
                timestamp: column::<i64>(row, 2, "timestamp")?,
                order_hash: column::<String>(row, 3, "order_hash")?,
                maker: column::<String>(row, 4, "maker")?,
                taker: column::<String>(row, 5, "taker")?,
                maker_asset_id: column::<String>(row, 6, "maker_asset_id")?,
                taker_asset_id: column::<String>(row, 7, "taker_asset_id")?,
                maker_amount_filled: column::<String>(row, 8, "maker_amount_filled")?,
                taker_amount_filled: column::<String>(row, 9, "taker_amount_filled")?,
                fee: column::<String>(row, 10, "fee")?,
            });
        }

        let mut result = Vec::with_capacity(rows_out.len());
        for row in rows_out {
            result.push(Py::new(py, row)?);
        }

        Ok(result)
    }

    /// List FPMM transactions
    ///
    /// Args:
    ///     market_id: Filter by market ID
    ///     start_ts: Optional start timestamp
    ///     end_ts: Optional end timestamp
    ///     limit: Maximum number of rows to return
    ///     offset: Rows to skip
    ///     order: Comma-separated list of fields to order by
    ///     ascending: Sort order (default: true)
    ///     transaction_type: Filter by transaction type
    ///
    /// Returns:
    ///     List of FpmmTransaction objects
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (
        market_id=None,
        start_ts=None,
        end_ts=None,
        limit=None,
        offset=None,
        order=None,
        ascending=true,
        transaction_type=None
    ))]
    fn list_fpmm_transactions(
        &self,
        py: Python,
        market_id: Option<String>,
        start_ts: Option<i64>,
        end_ts: Option<i64>,
        limit: Option<i64>,
        offset: Option<i64>,
        order: Option<String>,
        ascending: bool,
        transaction_type: Option<String>,
    ) -> PyResult<Vec<Py<PyFpmmTransaction>>> {
        let conn = open_readonly(&self.db_path)?;

        let mut query = String::from(
            "SELECT id, timestamp, market_id, user, transaction_type, \
                  trade_amount, fee_amount, outcome_index, outcome_tokens_amount \
             FROM fpmm_transaction",
        );
        let mut conditions: Vec<String> = Vec::new();
        let mut params: Vec<Value> = Vec::new();

        if let Some(mid) = &market_id {
            conditions.push("market_id = ?".to_string());
            params.push(Value::Text(mid.clone()));
        }
        if let Some(ts) = start_ts {
            conditions.push("timestamp >= ?".to_string());
            params.push(Value::BigInt(ts));
        }
        if let Some(ts) = end_ts {
            conditions.push("timestamp <= ?".to_string());
            params.push(Value::BigInt(ts));
        }
        if let Some(tt) = &transaction_type {
            conditions.push("transaction_type = ?".to_string());
            params.push(Value::Text(tt.clone()));
        }

        if !conditions.is_empty() {
            query.push_str(" WHERE ");
            query.push_str(&conditions.join(" AND "));
        }

        query.push_str(&fpmm_order_clause(order.as_deref(), ascending)?);

        push_limit(&mut query, limit)?;
        push_offset(&mut query, offset)?;

        let mut stmt = conn
            .prepare(&query)
            .py_context("prepare fpmm_transactions query")?;
        let mut rows = stmt
            .query(params_from_iter(params.iter()))
            .py_context("execute fpmm_transactions query")?;

        let mut rows_out = Vec::new();
        while let Some(row) = rows.next().py_context("fetch fpmm_transactions row")? {
            rows_out.push(PyFpmmTransaction {
                id: column::<String>(row, 0, "id")?,
                timestamp: column::<i64>(row, 1, "timestamp")?,
                market_id: column::<String>(row, 2, "market_id")?,
                user: column::<String>(row, 3, "user")?,
                transaction_type: column::<String>(row, 4, "transaction_type")?,
                trade_amount: column::<String>(row, 5, "trade_amount")?,
                fee_amount: column::<String>(row, 6, "fee_amount")?,
                outcome_index: column::<i64>(row, 7, "outcome_index")?,
                outcome_tokens_amount: column::<String>(row, 8, "outcome_tokens_amount")?,
            });
        }

        let mut result = Vec::with_capacity(rows_out.len());
        for row in rows_out {
            result.push(Py::new(py, row)?);
        }

        Ok(result)
    }
}

fn orders_order_clause(order: Option<&str>, ascending: bool) -> PyResult<String> {
    let Some(order) = order else {
        return Ok(" ORDER BY timestamp ASC".to_string());
    };

    let mut fields: Vec<&'static str> = Vec::new();
    for field in order.split(',') {
        let field = field.trim();
        if field.is_empty() {
            continue;
        }
        match orders_order_expression(field) {
            Some(expr) => fields.push(expr),
            None => return Err(runtime_err(format!("Unsupported order field: {field}"))),
        }
    }

    if fields.is_empty() {
        return Ok(" ORDER BY timestamp ASC".to_string());
    }

    let direction = if ascending { "ASC" } else { "DESC" };
    let clauses: Vec<String> = fields
        .into_iter()
        .map(|expr| format!("{expr} {direction}"))
        .collect();
    Ok(format!(" ORDER BY {}", clauses.join(", ")))
}

fn orders_order_expression(field: &str) -> Option<&'static str> {
    match field {
        "timestamp" => Some("timestamp"),
        "id" => Some("id"),
        "transaction_hash" | "transactionHash" => Some("transaction_hash"),
        "order_hash" | "orderHash" => Some("order_hash"),
        "maker" => Some("maker"),
        "taker" => Some("taker"),
        "maker_asset_id" | "makerAssetId" => Some("maker_asset_id"),
        "taker_asset_id" | "takerAssetId" => Some("taker_asset_id"),
        "maker_amount_filled" | "makerAmountFilled" => Some("maker_amount_filled"),
        "taker_amount_filled" | "takerAmountFilled" => Some("taker_amount_filled"),
        "fee" => Some("fee"),
        _ => None,
    }
}

fn fpmm_order_clause(order: Option<&str>, ascending: bool) -> PyResult<String> {
    let Some(order) = order else {
        return Ok(" ORDER BY timestamp ASC".to_string());
    };

    let mut fields: Vec<&'static str> = Vec::new();
    for field in order.split(',') {
        let field = field.trim();
        if field.is_empty() {
            continue;
        }
        match fpmm_order_expression(field) {
            Some(expr) => fields.push(expr),
            None => return Err(runtime_err(format!("Unsupported order field: {field}"))),
        }
    }

    if fields.is_empty() {
        return Ok(" ORDER BY timestamp ASC".to_string());
    }

    let direction = if ascending { "ASC" } else { "DESC" };
    let clauses: Vec<String> = fields
        .into_iter()
        .map(|expr| format!("{expr} {direction}"))
        .collect();
    Ok(format!(" ORDER BY {}", clauses.join(", ")))
}

fn fpmm_order_expression(field: &str) -> Option<&'static str> {
    match field {
        "timestamp" => Some("timestamp"),
        "id" => Some("id"),
        "market_id" | "marketId" => Some("market_id"),
        "user" => Some("user"),
        "transaction_type" | "transactionType" => Some("transaction_type"),
        "trade_amount" | "tradeAmount" => Some("trade_amount"),
        "fee_amount" | "feeAmount" => Some("fee_amount"),
        "outcome_index" | "outcomeIndex" => Some("outcome_index"),
        "outcome_tokens_amount" | "outcomeTokensAmount" => Some("outcome_tokens_amount"),
        _ => None,
    }
}
