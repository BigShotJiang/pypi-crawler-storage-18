use chrono::{DateTime, TimeZone, Utc};
use pyo3::exceptions::PyRuntimeError;
use pyo3::{PyErr, PyResult};
use serde_json::Value as JsonValue;

/// Parse a Unix timestamp in UTC seconds into a chrono datetime.
///
/// We accept integer seconds to avoid float rounding issues when crossing
/// the Rust/Python boundary.
pub(crate) fn parse_simulation_time(value: Option<i64>) -> PyResult<Option<DateTime<Utc>>> {
    let Some(value) = value else {
        return Ok(None);
    };
    let datetime = timestamp_to_datetime_secs(value)
        .ok_or_else(|| PyErr::new::<PyRuntimeError, _>("simulation_time out of range"))?;
    Ok(Some(datetime))
}

pub(crate) fn parse_market_datetime(value: &JsonValue) -> Option<DateTime<Utc>> {
    match value {
        JsonValue::String(text) => {
            if let Ok(parsed) = DateTime::parse_from_rfc3339(text) {
                return Some(parsed.with_timezone(&Utc));
            }
            text.parse::<i64>()
                .ok()
                .and_then(timestamp_to_datetime_secs)
        }
        JsonValue::Number(number) => number
            .as_i64()
            .and_then(timestamp_to_datetime_secs)
            .or_else(|| {
                number
                    .as_u64()
                    .and_then(|value| i64::try_from(value).ok())
                    .and_then(timestamp_to_datetime_secs)
            }),
        _ => None,
    }
}

fn timestamp_to_datetime_secs(timestamp: i64) -> Option<DateTime<Utc>> {
    Utc.timestamp_opt(timestamp, 0).single()
}
