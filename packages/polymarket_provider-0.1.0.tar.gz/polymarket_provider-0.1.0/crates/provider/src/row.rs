use duckdb::Row;
use duckdb::types::FromSql;
use pyo3::PyResult;

use crate::errors::PyResultExt;

pub(crate) fn column<T: FromSql>(row: &Row<'_>, idx: usize, name: &str) -> PyResult<T> {
    row.get(idx).py_context(format!("column {name}"))
}
