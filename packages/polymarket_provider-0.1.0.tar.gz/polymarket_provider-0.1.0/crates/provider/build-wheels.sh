#!/bin/bash
# 构建所有平台的 Python wheels
# 使用 cargo-zigbuild 进行交叉编译

set -e

CRATE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$CRATE_DIR"

# 输出目录
DIST_DIR="$CRATE_DIR/dist"
rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR"

echo "=== Building wheels for multiple platforms ==="
echo ""

# 检测本机架构和系统
detect_native_target() {
    local os=$(uname -s)
    local arch=$(uname -m)

    case "$os" in
        Darwin)
            case "$arch" in
                arm64|aarch64) echo "aarch64-apple-darwin" ;;
                x86_64|i386) echo "x86_64-apple-darwin" ;;
                *) echo "unknown" ;;
            esac
            ;;
        Linux)
            case "$arch" in
                aarch64) echo "aarch64-unknown-linux-gnu" ;;
                x86_64) echo "x86_64-unknown-linux-gnu" ;;
                *) echo "unknown" ;;
            esac
            ;;
        *)
            echo "unknown"
            ;;
    esac
}

NATIVE_TARGET=$(detect_native_target)
echo "Detected native target: $NATIVE_TARGET"
echo ""

# 定义所有目标
# 格式: "rust_target|display_name"
ALL_TARGETS=(
    "aarch64-apple-darwin|macOS ARM64"
    "x86_64-apple-darwin|macOS x86_64"
    "x86_64-unknown-linux-gnu|Linux x86_64"
    "aarch64-unknown-linux-gnu|Linux ARM64"
)

# 检查并安装 rust targets
echo "Checking rust targets..."
for target_entry in "${ALL_TARGETS[@]}"; do
    target=$(echo "$target_entry" | cut -d'|' -f1)
    if ! rustup target list --installed | grep -q "^$target "; then
        echo "Installing target: $target"
        rustup target add "$target" 2>/dev/null || echo "Warning: Failed to install $target"
    fi
done
echo ""

# 构建每个目标
SUCCESS_COUNT=0
FAIL_COUNT=0

for target_entry in "${ALL_TARGETS[@]}"; do
    target=$(echo "$target_entry" | cut -d'|' -f1)
    name=$(echo "$target_entry" | cut -d'|' -f2)

    echo "Building for $name ($target)..."

    # 本机平台不需要 zig
    if [[ "$target" == "$NATIVE_TARGET" ]]; then
        if maturin build --release --strip --out "$DIST_DIR" 2>&1; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        else
            FAIL_COUNT=$((FAIL_COUNT + 1))
            echo "Failed to build for $name"
        fi
    # macOS x86_64 在 ARM Mac 上无法交叉编译（缺少 SDK）
    elif [[ "$target" == "x86_64-apple-darwin" && "$NATIVE_TARGET" == "aarch64-apple-darwin" ]]; then
        echo "Skipping (cannot cross-compile x86_64 macOS on ARM Mac)"
    # Linux 目标使用 zig 交叉编译
    elif [[ "$target" == *"-unknown-linux-gnu" ]]; then
        if maturin build --release --strip --zig --target "$target" --out "$DIST_DIR" 2>&1; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        else
            FAIL_COUNT=$((FAIL_COUNT + 1))
            echo "Failed to build for $name"
        fi
    # 其他目标尝试使用 zig
    else
        if maturin build --release --strip --zig --target "$target" --out "$DIST_DIR" 2>&1; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        else
            FAIL_COUNT=$((FAIL_COUNT + 1))
            echo "Failed to build for $name"
        fi
    fi

    echo ""
done

echo "=== Build Summary ==="
echo "Success: $SUCCESS_COUNT"
echo "Failed: $FAIL_COUNT"
echo "Skipped: $(( ${#ALL_TARGETS[@]} - SUCCESS_COUNT - FAIL_COUNT ))"
echo "Wheels built in: $DIST_DIR"
echo ""
ls -la "$DIST_DIR"/*.whl 2>/dev/null || echo "No wheels found"
echo ""

echo "=== Wheel Compatibility ==="
for wheel in "$DIST_DIR"/*.whl; do
    if [ -f "$wheel" ]; then
        basename "$wheel"
    fi
done
