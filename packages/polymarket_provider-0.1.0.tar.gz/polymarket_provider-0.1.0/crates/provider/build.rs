fn main() {
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        // DuckDB references Windows Restart Manager APIs on Windows builds.
        println!("cargo:rustc-link-lib=rstrtmgr");
    }
}
