# polymarket-provider

Polymarket data provider for Python, built with Rust and PyO3.

## Features

- Query Polymarket on-chain data (order filled events, FPMM transactions)
- Query Polymarket off-chain data (markets, market tokens)
- Query historical time series data for trading analysis
- Time-travel queries with `simulation_time` parameter
- Built on DuckDB for fast local queries
- Python 3.11+ support with abi3 compatibility

## Installation

```bash
pip install polymarket-provider
```

## Quick Start

```python
from polymarket_provider import DataProvider

# Create provider with default DB paths
provider = DataProvider()

# Query markets
markets = provider.off_chain.markets(limit=10)
for market in markets:
    print(f"{market.question}: {market.outcome}")

# Query on-chain events
orders = provider.on_chain.order_filled_events(limit=10)

# Query time series data
ts = provider.trading.timeseries(market_id="...", limit=100)
```

## Time Travel Queries

```python
from datetime import datetime, timezone

# Query data as of a specific time
ts = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp())
provider = DataProvider(simulation_time=ts)

# Or set it later
provider.set_simulation_time(ts)
```

## Requirements

- Python 3.11+
- Local DuckDB database files

## License

MIT
