"""Tests for Traylinx CLI."""
