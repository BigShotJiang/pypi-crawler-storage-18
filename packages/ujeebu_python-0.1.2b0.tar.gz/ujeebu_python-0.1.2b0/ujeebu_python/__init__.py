"""Top-level package for Ujeebu Python."""

__author__ = """Yacine Alhyane"""
__email__ = 'y.alhyane@gmail.com'
__version__ = '0.1.2-beta'


from .ujeebu_python import UjeebuClient

__all__ = ['UjeebuClient']
