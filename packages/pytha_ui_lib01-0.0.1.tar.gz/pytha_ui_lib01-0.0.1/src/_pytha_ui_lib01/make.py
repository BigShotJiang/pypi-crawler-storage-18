import hashlib
import logging
import os
import pathlib
import shutil
import sys
from datetime import datetime
from io import BytesIO, BufferedWriter
from re import search, Match
from typing import Iterable
from urllib.parse import urlparse
from urllib.request import urlopen


class __PATHS__:
    ROOT_DIR = pathlib.Path(__file__).parent
    SRC_DIR = ROOT_DIR / "src"

    DIST_OUT_DIR = ROOT_DIR / "dist"
    PART_OUT_DIR = ROOT_DIR / "parts"

    source = SRC_DIR / "source"

    main_js = DIST_OUT_DIR / "main.js"
    main_css = DIST_OUT_DIR / "main.css"
    main_licenses = DIST_OUT_DIR / "LICENSES.txt"

    source_lock = DIST_OUT_DIR / "source-lock.txt"

    PART_META_DIR = PART_OUT_DIR / ".meta"
    part_index_js = PART_META_DIR / "index-js"
    part_index_css = PART_META_DIR / "index-css"

    build_log = ROOT_DIR / "build.log"

    version = ROOT_DIR / "../../VERSION"


class _Logger:

    def __init__(self):
        self.formatter = logging.Formatter("%(asctime)s [%(levelname)s]  %(message)s")
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.DEBUG)

        self.file_handler = logging.FileHandler(__PATHS__.build_log)
        self.file_handler.setFormatter(self.formatter)
        self.file_handler.setLevel(logging.DEBUG)
        self.logger.addHandler(self.file_handler)

        self.console_handler = logging.StreamHandler(sys.stdout)
        self.console_handler.setFormatter(self.formatter)
        self.console_handler.setLevel(logging.DEBUG)
        self.logger.addHandler(self.console_handler)

    errors: int = 0

    def __call__(self, msg: str, lv: int = logging.INFO):
        self.logger.log(lv, msg)

    def error(self, *msg: str):
        for m in msg:
            self(m, logging.ERROR)
        self.errors += 1

    def exit(self):
        msg = f"errors: {self.errors}"
        self("=" * len(msg), logging.DEBUG)
        self(msg, logging.DEBUG)

    def set_level(self, level: int):
        self.logger.setLevel(level)
        self.file_handler.setLevel(level)
        self.console_handler.setLevel(level)


log: _Logger = _Logger()


def _flush():
    for out in (__PATHS__.DIST_OUT_DIR, __PATHS__.PART_OUT_DIR, __PATHS__.PART_META_DIR):
        log(f"[flush] {out}")
        try:
            shutil.rmtree(out)
        except FileNotFoundError:
            pass
        out.mkdir()


def _makehash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _source_lock():
    with (
        open(__PATHS__.source, "rb") as source,
        open(__PATHS__.source_lock, "wb") as lock,
        open(__PATHS__.version, "r+") as version,
    ):
        v = version.read().strip().split(".")
        v[-1] = str(int(v[-1]) + 1)
        v = '.'.join(v)

        source = source.read()
        timestamp = datetime.now().isoformat()
        _hash = _makehash(source)

        log(f"[lock source] timestamp: {timestamp}")
        log(f"[lock source] hash: {_hash}")

        log(f"[version] {v}")

        version.truncate(0)
        version.seek(0)
        version.write(v)

        lock.write(b': v')
        lock.write(v.encode())
        lock.write(b" (")
        lock.write(timestamp.encode())
        lock.write(b') #')
        lock.write(_hash.encode())
        lock.write(b"\n\n\n")
        lock.write(source)


def _parse_heredoc(match: Match[bytes], doc: Iterable[bytes], line_no: int):
    eof = match.group(1) + match.group(2)
    indent = len(match.group(1))
    heredoc = BytesIO()
    _line_no = line_no

    for line in doc:
        line_no += 1
        if line.startswith(eof):
            return heredoc.getvalue(), line_no
        heredoc.write(line[indent:])
    else:
        raise SyntaxError(f"unterminated heredoc: {match} @ line {_line_no}")


def _filename_from_url(url: str):
    return url.rsplit("/", 1)[-1]


def _fetch_url(url: str):
    log(f"[fetch] {url}")

    url = urlparse(url)
    if not url.scheme:
        url = url._replace(scheme="file", path=str(__PATHS__.SRC_DIR / url.path))
        url = url.geturl()
        log(f"[fetch] set default scheme: {url}")
    else:
        url = url.geturl()

    with urlopen(url) as f:
        return f.read()


class _MergeProcessor:
    def __init__(
            self,
            section_header: str,
            main_js: BufferedWriter,
            main_css: BufferedWriter,
            part_index_js: BufferedWriter,
            part_index_css: BufferedWriter,
    ):
        self.section_header = section_header
        self.part_dir = __PATHS__.PART_OUT_DIR / section_header
        os.makedirs(self.part_dir, exist_ok=True)

        self.main_js = main_js
        self.main_css = main_css
        self.part_index_js = part_index_js
        self.part_index_css = part_index_css

    def __call__(self, url: str):
        # set output
        if url.endswith(".js"):
            merge_out = self.main_js
            index_out = self.part_index_js
        elif url.endswith(".css"):
            merge_out = self.main_css
            index_out = self.part_index_css
        else:
            raise ValueError(f"unsupported asset type: {url}")

        # data
        data = _fetch_url(url)
        filename = _filename_from_url(url)

        # write
        with open(self.part_dir / filename, "wb") as f:
            f.write(data)
        merge_out.write(data)
        index_out.write(f"{self.section_header}/{filename}\n".encode())


class _ResourcesProcessor:
    def __init__(
            self,
            section_header: str,
            dest: str,
    ):
        dest = dest.strip("/") or section_header
        self.main_dest = __PATHS__.DIST_OUT_DIR / dest
        self.part_dest = __PATHS__.PART_OUT_DIR / dest
        os.makedirs(self.main_dest, exist_ok=True)
        os.makedirs(self.part_dest, exist_ok=True)

    def _write(self, data: bytes, filename: str):
        with open(self.main_dest / filename, "wb") as f:
            f.write(data)
        with open(self.part_dest / filename, "wb") as f:
            f.write(data)

    def __call__(self, url: str):
        # data
        data = _fetch_url(url)
        filename = _filename_from_url(url)
        self._write(data, filename)

    def add_heredoc(self, content: bytes):
        c = 0
        while True:
            filename = f"doc-{c}.txt"
            if not (
                    os.path.exists(self.part_dest / filename)
                    or os.path.exists(self.main_dest / filename)
            ):
                break
            c += 1
        self._write(content, filename)


class _LicenseProcessor:

    def __init__(
            self,
            section_header: str,
            dest: str,
            main_license: BufferedWriter,
    ):
        if not dest:  # merge
            part_dir = __PATHS__.PART_OUT_DIR / section_header
            os.makedirs(part_dir, exist_ok=True)

            def _out(buffer: BytesIO, part: str):
                main_license.write(buffer.getvalue())
                with open(part_dir / part, "ba") as f:
                    f.write(buffer.getvalue())

            def proc(url: str):
                buffer = BytesIO()

                sep = b"=" * (len(url) + len(section_header) + 3) + b"\n"
                buffer.write(sep)
                buffer.write(section_header.encode() + b" ~ " + url.encode() + b"\n")
                buffer.write(sep)
                buffer.write(b"\n  " + b"\n  ".join(_fetch_url(url).splitlines()))
                buffer.write(b"\n\n\n")

                _out(buffer, _filename_from_url(url))

            self.proc = proc

            def add_heredoc(content: bytes):
                buffer = BytesIO()
                buffer.write(b"\n  " + b"\n  ".join(content.splitlines()))
                buffer.write(b"\n\n\n")

                c = 0
                while os.path.exists(part_dir / (filename := f"doc-{c}.txt")):
                    c += 1

                _out(buffer, filename)

            self.add_heredoc = add_heredoc

        else:
            self.proc = _ResourcesProcessor(section_header, dest)
            self.add_heredoc = self.proc.add_heredoc

    def __call__(self, url: str):
        self.proc(url)


def _build():
    with (
        open(__PATHS__.source, "rb") as source,
        open(__PATHS__.main_js, "wb") as main_js,
        open(__PATHS__.main_css, "wb") as main_css,
        open(__PATHS__.main_licenses, "wb") as main_licenses,
        open(__PATHS__.part_index_js, "wb") as part_index_js,
        open(__PATHS__.part_index_css, "wb") as part_index_css,
    ):
        section_header: str
        dest: str
        processor: _MergeProcessor | _ResourcesProcessor | _LicenseProcessor
        line_no = 0

        try:
            for line in source:
                line_no += 1
                line = line.rstrip()
                if not line or search(b"^:", line):
                    continue
                if section := search(b"^\\[([^]]+)](.*)", line):
                    section_header = section.group(1).decode()
                    dest = section.group(2).strip().decode()
                    log(f"[parse] @line {line_no} [{section_header}] {dest}")
                elif key := search(b"^(\\S[^:]+):(.*)", line):
                    key = key.group(1).decode()
                    log(f"[parse] @line {line_no} directive: {key}")
                    match key:
                        case "assets":
                            if dest:
                                processor = _ResourcesProcessor(section_header, dest)
                            else:
                                processor = _MergeProcessor(section_header, main_js, main_css, part_index_js, part_index_css)
                        case "license":
                            processor = _LicenseProcessor(section_header, dest, main_licenses)
                        case _:
                            raise SyntaxError(f"unknown directive: {key} @ line {line_no}")
                elif heredoc := search(b"^(\\s*)(\"\"\"|''')", line):
                    log(f"[parse] @line {line_no} heredoc")
                    value, line_no = _parse_heredoc(heredoc, source, line_no)
                    processor.add_heredoc(value)
                else:
                    processor(line.strip().decode())
        except Exception as e:
            log.error(f"error @line {line_no}: {e}")
            raise


def main():
    try:
        _flush()
        _build()
        _source_lock()
    finally:
        log.exit()


if __name__ == "__main__":
    main()
