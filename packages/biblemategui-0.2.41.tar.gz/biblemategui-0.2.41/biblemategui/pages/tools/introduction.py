from nicegui import ui, app, run
import os, re, markdown2
from biblemategui import BIBLEMATEGUI_DATA, get_translation
from agentmake.plugins.uba.lib.BibleParser import BibleVerseParser
from agentmake import readTextFile

def get_contents(b, lang="eng"):
    parser = BibleVerseParser(False, language=lang)
    def process_content(parser, content):
        # parse content
        content = parser.parseText(content)
        # convert md to html
        content = markdown2.markdown(content, extras=["tables","fenced-code-blocks","toc","codelite"])
        content = content.replace("<h1>", "<h2>").replace("</h1>", "</h2>")
        # convert links
        content = re.sub(r'''(onclick|ondblclick)="(bcv)\((.*?)\)"''', r'''\1="emitEvent('\2', [\3]); return false;"''', content)
        return content
    contents = []
    conversation_file = os.path.join(BIBLEMATEGUI_DATA, "BibleBookStudies", lang, f"{b}.py")
    if os.path.isfile(conversation_file):
        contents = [process_content(parser, i["content"]) for i in eval(readTextFile(conversation_file)) if i.get("role", "") == "assistant" and not i.get("content", "") == "Sure! Let's dive into the analysis process."]
    return contents

def book_introduction(gui=None, b=1, c=1, v=1, area=2, **_):

    # temp
    b = 1

    # handle bcv events
    def bcv(event):
        nonlocal gui
        b, c, v, *_ = event.args
        gui.change_area_1_bible_chapter(None, b, c, v)
    ui.on('bcv', bcv)

    # Summary display
    async def load_summary(b, c):
        contents = await run.io_bound(get_contents, b, app.storage.user['ui_language'])
        sections = {
            "Overview": "info",
            "Structural Outline": "account_tree",
            "Logical Flow": "low_priority",
            "Historical Setting": "history_edu",
            "Themes": "style",
            "Keywords": "vpn_key",
            "Theology": "auto_stories",
            "Canonical Placement": "format_list_numbered",
            "Practical Living": "volunteer_activism",
            "Summary": "summarize",
        }
        # display content
        index = 0
        for section, icon in sections.items():
            with ui.expansion(get_translation(section), icon=icon) \
                    .classes('w-full bg-white border rounded-lg shadow-sm mb-2') \
                    .props('header-class="font-bold text-lg text-primary"'):
                ui.html(f'<div class="content-text">{contents[index]}</div>', sanitize=False)
            index += 1

    n = ui.notification("Loading ...", timeout=None, spinner=True)
    ui.timer(0, lambda: load_summary(b, c), once=True)
    n.dismiss()    