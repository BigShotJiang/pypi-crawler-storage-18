#!/usr/bin/env python3
#
# Copyright (c) Subfork. All rights reserved.
#
# Follows PEP-0440 version scheme guidelines
# https://www.python.org/dev/peps/pep-0440/#version-scheme
#

__prog__ = "subfork"
__version__ = "1.0.3"
