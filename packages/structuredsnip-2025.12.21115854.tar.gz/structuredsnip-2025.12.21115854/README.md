# StructuredSnip
[![PyPI version](https://badge.fury.io/py/structuredsnip.svg)](https://badge.fury.io/py/structuredsnip)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/structuredsnip)](https://pepy.tech/project/structuredsnip)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


StructuredSnip is a Python package that takes unstructured text input from users and returns structured, categorized feedback or suggestions. It uses pattern matching to ensure responses follow a consistent format, such as extracting key points, summarizing content, or organizing ideas into predefined sections.

## Features

- **Pattern Matching**: Ensures responses follow a consistent format.
- **Customizable LLM**: Uses `ChatLLM7` by default but can be customized with any `BaseChatModel` from LangChain.
- **Flexible Input**: Accepts user input text and processes it into structured output.
- **Error Handling**: Provides detailed error messages for failed LLM calls.

## Installation

```bash
pip install structuredsnip
```

## Usage

### Basic Usage

```python
from structuredsnip import structuredsnip

user_input = "Your unstructured text here."
response = structuredsnip(user_input)
print(response)
```

### Using a Custom LLM

You can use any LLM compatible with LangChain's `BaseChatModel`. Here are examples using different LLMs:

#### Using OpenAI

```python
from langchain_openai import ChatOpenAI
from structuredsnip import structuredsnip

llm = ChatOpenAI()
response = structuredsnip(user_input, llm=llm)
print(response)
```

#### Using Anthropic

```python
from langchain_anthropic import ChatAnthropic
from structuredsnip import structuredsnip

llm = ChatAnthropic()
response = structuredsnip(user_input, llm=llm)
print(response)
```

#### Using Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from structuredsnip import structuredsnip

llm = ChatGoogleGenerativeAI()
response = structuredsnip(user_input, llm=llm)
print(response)
```

### Using an API Key

You can pass an API key directly or via an environment variable.

#### Passing API Key Directly

```python
from structuredsnip import structuredsnip

user_input = "Your unstructured text here."
api_key = "your_api_key_here"
response = structuredsnip(user_input, api_key=api_key)
print(response)
```

#### Using Environment Variable

```bash
export LLM7_API_KEY="your_api_key_here"
```

```python
from structuredsnip import structuredsnip

user_input = "Your unstructured text here."
response = structuredsnip(user_input)
print(response)
```

## Parameters

- **user_input** (str): The user input text to process.
- **llm** (Optional[BaseChatModel]): The LangChain LLM instance to use. Defaults to `ChatLLM7`.
- **api_key** (Optional[str]): The API key for LLM7. If not provided, it will use the environment variable `LLM7_API_KEY`.

## Rate Limits

The default rate limits for LLM7's free tier are sufficient for most use cases of this package. If you need higher rate limits, you can pass your own API key via the `api_key` parameter or the `LLM7_API_KEY` environment variable. You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/structuredsnip/issues).

## Author

- **Eugene Evstafev**
- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)