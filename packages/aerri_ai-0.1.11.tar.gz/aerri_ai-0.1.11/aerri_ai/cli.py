import os
import subprocess
import json
from pathlib import Path
from datetime import datetime
from langchain_groq import ChatGroq
from langchain.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from typing import Annotated, TypedDict
import operator

import random
import time
import threading
import sys


# Loading animation
class LoadingAnimation:
    def __init__(self, message="Processing"):
        self.message = message
        self.running = False
        self.thread = None
        
    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._animate)
        self.thread.start()
        
    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        print(f"\r{' ' * 50}\r", end="")  # Clear line
        
    def _animate(self):
        chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while self.running:
            print(f"\r{PURPLE}{chars[i % len(chars)]} {self.message}...{RESET}", end="", flush=True)
            time.sleep(0.1)
            i += 1

# Fun messages and jokes
TOOL_MESSAGES = [
    "🔍 Looking for files like a detective...",
    "📝 Writing code faster than you can say 'bug'...",
    "🗑️ Deleting files (don't worry, I'm careful)...",
    "🏃‍♂️ Running code at lightning speed...",
    "📂 Listing files like a librarian...",
    "🧠 Accessing my memory banks...",
    "🔧 Explaining changes like a professor..."
]

JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
    "How many programmers does it take to change a light bulb? None, that's a hardware problem! 💡",
    "Why do Java developers wear glasses? Because they can't C# 👓",
    "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?' 🍺",
    "Why did the programmer quit his job? He didn't get arrays! 📊"
]

def get_tool_message(tool_name):
    messages = {
        "read_file": "🔍 Reading file contents...",
        "write_file": "📝 Writing magical code...",
        "delete_file": "🗑️ Deleting file (carefully!)...",
        "run_code": "🏃‍♂️ Executing code...",
        "list_files": "📂 Scanning directory...",
        "get_memory": "🧠 Accessing memory...",
        "explain_changes": "🔧 Analyzing changes...",
        "shell_command": "⚡ Running shell command..."
    }
    return messages.get(tool_name, f"🔧 Using {tool_name}...")

# ANSI color codes for purple styling
PURPLE = '\033[95m'
BOLD = '\033[1m'
RESET = '\033[0m'
CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'

def print_purple(text):
    print(f"{PURPLE}{BOLD}{text}{RESET}")

def print_cyan(text):
    print(f"{CYAN}{text}{RESET}")

def print_green(text):
    print(f"{GREEN}{text}{RESET}")

def print_yellow(text):
    print(f"{YELLOW}{text}{RESET}")

# Memory functions
MEMORY_FILE = ".copilot_memory.json"

def load_memory():
    """Load workspace memory from file."""
    if Path(MEMORY_FILE).exists():
        return json.loads(Path(MEMORY_FILE).read_text())
    return {"sessions": [], "files_modified": {}, "context": {"last_created": [], "last_deleted": [], "last_modified": []}}

def save_memory(memory):
    """Save workspace memory to file."""
    Path(MEMORY_FILE).write_text(json.dumps(memory, indent=2))

def add_to_memory(task, files_touched, action_type="modified"):
    """Add current session to memory with context tracking."""
    memory = load_memory()
    memory["sessions"].append({
        "timestamp": datetime.now().isoformat(),
        "task": task,
        "files": files_touched,
        "action": action_type
    })
    
    # Update context tracking
    if "context" not in memory:
        memory["context"] = {"last_created": [], "last_deleted": [], "last_modified": []}
    
    for file in files_touched:
        memory["files_modified"][file] = datetime.now().isoformat()
        # Track by action type
        if action_type == "created":
            memory["context"]["last_created"] = [file] + [f for f in memory["context"]["last_created"] if f != file][:4]
        elif action_type == "deleted":
            memory["context"]["last_deleted"] = [file] + [f for f in memory["context"]["last_deleted"] if f != file][:4]
        else:
            memory["context"]["last_modified"] = [file] + [f for f in memory["context"]["last_modified"] if f != file][:4]
    
    save_memory(memory)

def get_context_reference(text):
    """Resolve context references like 'that folder', 'the file', etc."""
    memory = load_memory()
    context = memory.get("context", {})
    
    # Extract just the folder/file name from full paths
    def extract_name(path):
        return Path(path).name if path else ""
    
    # Get recent items
    recent_created = [extract_name(item) for item in context.get("last_created", [])]
    recent_deleted = [extract_name(item) for item in context.get("last_deleted", [])]
    
    # Simple context resolution - if user says "delete it" and we just created something
    if any(word in text.lower() for word in ["delete it", "remove it", "it"]) and recent_created:
        return recent_created[0]  # Most recent created item
    
    # Restoration requests
    if any(phrase in text.lower() for phrase in ["bring it back", "restore it"]) and recent_deleted:
        return recent_deleted[0]  # Most recent deleted item
    
    return None

# Initialize LLM
llm = ChatGroq(
    api_key="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",
    model="openai/gpt-oss-120b",
    temperature=0.1
)

# Tools
@tool
def read_file(file_path: str) -> str:
    """Read content of a file."""
    try:
        return Path(file_path).read_text()
    except Exception as e:
        return f"Error reading file: {e}"

@tool
def write_file(file_path: str, content: str) -> str:
    """Create or overwrite a file with content."""
    try:
        # Check if file exists to compare changes
        old_content = ""
        if Path(file_path).exists():
            old_content = Path(file_path).read_text()
        
        Path(file_path).write_text(content)
        
        # Auto-explain line changes if file was modified
        if old_content and old_content != content:
            old_lines = old_content.splitlines()
            new_lines = content.splitlines()
            
            changes = []
            max_lines = max(len(old_lines), len(new_lines))
            
            for i in range(max_lines):
                old_line = old_lines[i] if i < len(old_lines) else ""
                new_line = new_lines[i] if i < len(new_lines) else ""
                
                if old_line != new_line:
                    if not old_line:
                        changes.append(f"+ Line {i+1}: {new_line}")
                    elif not new_line:
                        changes.append(f"- Line {i+1}: {old_line}")
                    else:
                        changes.append(f"~ Line {i+1}: {old_line} → {new_line}")
            
            change_summary = "\n".join(changes[:5])  # Show first 5 changes
            if len(changes) > 5:
                change_summary += f"\n... and {len(changes)-5} more changes"
                
            return f"✅ File '{file_path}' updated successfully\n\n📝 Changes made:\n{change_summary}"
        else:
            return f"✅ File '{file_path}' created successfully"
    except Exception as e:
        return f"Error writing file: {e}"

@tool
def explain_changes(file_path: str) -> str:
    """Explain what changes were made to a file and why."""
    memory = load_memory()
    if not memory["sessions"]:
        return "No previous changes found in memory."
    
    # Find recent sessions that modified this file
    recent_changes = []
    for session in reversed(memory["sessions"][-5:]):  # Last 5 sessions
        if file_path in session.get("files", []):
            recent_changes.append(f"• {session['timestamp'][:16]}: {session['task']}")
    
    if recent_changes:
        return f"📝 Recent changes to {file_path}:\n" + "\n".join(recent_changes) + "\n\n💡 Ask me 'why did you change X?' for specific explanations"
    else:
        return f"No recent changes found for {file_path}"

@tool
def get_memory() -> str:
    """Get workspace memory of previous sessions and file modifications."""
    memory = load_memory()
    if not memory["sessions"]:
        return "No previous sessions found."
    
    recent = memory["sessions"][-3:]  # Last 3 sessions
    result = "📝 Recent workspace activity:\n"
    for session in recent:
        result += f"• {session['timestamp'][:16]}: {session['task']}\n"
        if session['files']:
            result += f"  Files: {', '.join(session['files'])}\n"
    
    # Add context information
    context = memory.get("context", {})
    if context.get("last_created"):
        result += f"\n🆕 Recently created: {', '.join(context['last_created'][:3])}"
    if context.get("last_deleted"):
        result += f"\n🗑️ Recently deleted: {', '.join(context['last_deleted'][:3])}"
    if context.get("last_modified"):
        result += f"\n✏️ Recently modified: {', '.join(context['last_modified'][:3])}"
    
    return result

@tool
def delete_file(file_path: str) -> str:
    """Delete a file."""
    try:
        Path(file_path).unlink()
        return f"✅ File '{file_path}' deleted successfully"
    except Exception as e:
        return f"Error deleting file: {e}"

@tool
def run_code(file_path: str) -> str:
    """Execute Python file and return output or errors."""
    try:
        result = subprocess.run(['python3', file_path], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"✅ Output:\n{result.stdout}"
        else:
            return f"❌ Error detected:\n{result.stderr}\n🔧 Auto-fixing enabled - will attempt repair"
    except Exception as e:
        return f"Execution error: {e}"

@tool
def list_files(directory: str = ".") -> str:
    """List files in directory."""
    try:
        files = [f.name for f in Path(directory).iterdir() if f.is_file()]
        return f"Files: {', '.join(files)}"
    except Exception as e:
        return f"Error listing files: {e}"

@tool
def open_app(app_name: str) -> str:
    """Open an application on macOS."""
    try:
        # Store the last opened app for context
        copilot_agent.last_opened_app = app_name
        
        # Try opening as application first
        result = subprocess.run(['open', '-a', app_name], capture_output=True, text=True)
        if result.returncode == 0:
            return f"✅ {app_name} opened successfully"
        else:
            # If app not found, try common web apps
            web_apps = {
                'whatsapp': 'https://web.whatsapp.com',
                'gmail': 'https://gmail.com',
                'youtube': 'https://youtube.com',
                'github': 'https://github.com',
                'twitter': 'https://twitter.com'
            }
            
            app_lower = app_name.lower()
            if app_lower in web_apps:
                subprocess.run(['open', web_apps[app_lower]], capture_output=True)
                return f"✅ {app_name} web version opened in browser"
            else:
                return f"❌ Could not find app '{app_name}'. Try the exact app name or install it first."
    except Exception as e:
        return f"Error opening app: {e}"

@tool
def close_app(app_name: str) -> str:
    """Close an application on macOS."""
    try:
        result = subprocess.run(['pkill', '-f', app_name], capture_output=True, text=True)
        return f"✅ {app_name} closed successfully"
    except Exception as e:
        return f"Error closing app: {e}"

@tool
def shell_command(command: str, purpose: str = "") -> str:
    """Execute shell commands with user confirmation for destructive operations."""
    # List of potentially destructive commands that need confirmation
    destructive_patterns = ['rm', 'del', 'rmdir', 'mv', 'cp', 'chmod', 'chown', 'sudo']
    
    needs_confirmation = any(pattern in command.lower() for pattern in destructive_patterns)
    
    if needs_confirmation:
        print_yellow(f"\n🔧 I will run the following command: {command}")
        if purpose:
            print_cyan(f"Purpose: {purpose}")
        
        while True:
            response = input(f"\n{YELLOW}Allow this action? Use 't' to trust (always allow) this tool for the session. [y/n/t]: {RESET}").lower().strip()
            if response == 'y':
                break
            elif response == 'n':
                return "❌ Command cancelled by user"
            elif response == 't':
                # Set trust flag (you could implement session-based trust)
                break
            else:
                print_yellow("Please enter 'y' for yes, 'n' for no, or 't' to trust")
    
    try:
        start_time = time.time()
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
        end_time = time.time()
        
        execution_time = f"Completed in {end_time - start_time:.2f}s"
        
        # Track action type for memory
        action_type = "modified"
        if "mkdir" in command or "touch" in command:
            action_type = "created"
        elif "rm" in command or "del" in command:
            action_type = "deleted"
        
        if result.returncode == 0:
            output = result.stdout.strip() if result.stdout.strip() else "Command executed successfully"
            
            # Extract file/folder paths from command for memory tracking
            files_touched = []
            if "mkdir" in command:
                # Extract folder name from mkdir command
                parts = command.split()
                if len(parts) > 1:
                    files_touched.append(parts[-1])
            elif "touch" in command:
                parts = command.split()
                if len(parts) > 1:
                    files_touched.append(parts[-1])
            elif "rm" in command:
                parts = command.split()
                files_touched = [p for p in parts[1:] if not p.startswith('-')]
            
            # Add to memory with action type
            if files_touched:
                add_to_memory(f"Shell command: {command}", files_touched, action_type)
            
            return f"✅ {output}\n\n⏱️ {execution_time}"
        else:
            error = result.stderr.strip() if result.stderr.strip() else "Command failed"
            return f"❌ {error}\n\n⏱️ {execution_time}"
    except subprocess.TimeoutExpired:
        return "❌ Command timed out after 30 seconds"
    except Exception as e:
        return f"❌ Error executing command: {e}"

@tool
def create_desktop_folder(folder_name: str) -> str:
    """Create a folder on macOS Desktop."""
    desktop_path = Path("/Users/adityasuyal/Desktop")
    folder_path = desktop_path / folder_name
    
    try:
        folder_path.mkdir(exist_ok=True)
        # Update memory immediately
        add_to_memory(f"Create folder '{folder_name}' on Desktop", [str(folder_path)], "created")
        return f"✅ Folder '{folder_name}' created on Desktop"
    except Exception as e:
        return f"❌ Error creating folder: {e}"

@tool
def check_desktop_folder(folder_name: str) -> str:
    """Check if a folder exists on macOS Desktop and remove it if found."""
    desktop_path = Path("/Users/adityasuyal/Desktop")
    folder_path = desktop_path / folder_name
    
    if folder_path.exists() and folder_path.is_dir():
        try:
            folder_path.rmdir()  # Remove empty folder
            # Update memory immediately
            add_to_memory(f"Delete folder '{folder_name}' from Desktop", [str(folder_path)], "deleted")
            return f"✅ Folder '{folder_name}' removed from Desktop"
        except OSError:
            # Folder not empty, use shell command
            import shutil
            shutil.rmtree(folder_path)
            add_to_memory(f"Delete folder '{folder_name}' from Desktop", [str(folder_path)], "deleted")
            return f"✅ Folder '{folder_name}' and its contents removed from Desktop"
    else:
        # List what's actually on Desktop
        if desktop_path.exists():
            items = [f.name for f in desktop_path.iterdir() if f.is_dir()]
            if items:
                return f"❌ Folder '{folder_name}' not found on Desktop. Available folders: {', '.join(items[:5])}"
            else:
                return f"❌ Folder '{folder_name}' not found. No folders on Desktop."
        else:
            return "❌ Desktop directory not accessible"

@tool
def explain_file_recovery() -> str:
    """Explain that deleted files cannot be recovered."""
    return ("❌ I cannot recover the deleted contents of 'ALL FOLDERS'. When folders are deleted using "
            "rm/rmdir commands, their contents are permanently removed from the system and cannot be restored. "
            "The files that were inside 'ALL FOLDERS' (like adu.jpeg alias) are gone permanently. "
            "To prevent this in the future, consider using Trash instead of direct deletion commands.")

# New core capabilities
@tool
def search_files(pattern: str, directory: str = ".") -> str:
    """Search for files matching a pattern in directory."""
    try:
        import glob
        matches = glob.glob(f"{directory}/**/{pattern}", recursive=True)
        if matches:
            return f"Found {len(matches)} matches:\n" + "\n".join(matches[:10])
        return f"No files found matching '{pattern}'"
    except Exception as e:
        return f"Error searching files: {e}"

@tool
def grep_content(pattern: str, file_path: str = None) -> str:
    """Search for text pattern in files."""
    try:
        if file_path:
            content = Path(file_path).read_text()
            lines = content.splitlines()
            matches = [(i+1, line) for i, line in enumerate(lines) if pattern.lower() in line.lower()]
            if matches:
                result = f"Found {len(matches)} matches in {file_path}:\n"
                for line_num, line in matches[:5]:
                    result += f"{line_num}: {line.strip()}\n"
                return result
            return f"No matches found for '{pattern}' in {file_path}"
        else:
            # Search in current directory
            import os
            matches = []
            for root, dirs, files in os.walk("."):
                for file in files:
                    if file.endswith(('.py', '.txt', '.md', '.json')):
                        try:
                            filepath = os.path.join(root, file)
                            content = Path(filepath).read_text()
                            if pattern.lower() in content.lower():
                                matches.append(filepath)
                        except:
                            continue
            return f"Found pattern in: {matches[:5]}" if matches else f"No matches found for '{pattern}'"
    except Exception as e:
        return f"Error searching content: {e}"

@tool
def execute_bash(command: str) -> str:
    """Execute bash commands safely."""
    try:
        # Restrict dangerous commands
        dangerous = ['rm -rf', 'sudo', 'chmod 777', 'dd if=']
        if any(cmd in command.lower() for cmd in dangerous):
            return "❌ Dangerous command blocked for safety"
        
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
        output = result.stdout + result.stderr
        return f"Exit code: {result.returncode}\nOutput:\n{output}" if output else f"Command executed (exit code: {result.returncode})"
    except subprocess.TimeoutExpired:
        return "❌ Command timed out (30s limit)"
    except Exception as e:
        return f"❌ Error executing command: {e}"

@tool
def show_capabilities() -> str:
    """Show what this CLI can do."""
    return """
🌐 Web Access:
  • web_search(query) - Search web for current info

🤖 Aerri-AI Capabilities:

📁 File Operations:
  • read_file(path) - Read file contents
  • write_file(path, content) - Create/edit files
  • delete_file(path) - Remove files
  • list_files(directory) - List directory contents
  • search_files(pattern, dir) - Find files by pattern
  • grep_content(pattern, file) - Search text in files

🏃 Code Execution:
  • run_code(code, language) - Execute Python/other code
  • execute_bash(command) - Run bash commands safely

🧠 Memory & Context:
  • get_memory() - View workspace memory
  • explain_changes() - Show recent file changes

🎯 System Operations:
  • open_app(name) - Launch applications
  • close_app(name) - Close applications
  • shell_command(cmd) - Execute system commands

💡 Usage Examples:
  aerri-ai "Create a FastAPI app"
  aerri-ai "Fix bugs in main.py"
  aerri-ai "Show all Python files"
  aerri-ai "Run my tests and explain results"
"""

@tool
def web_search(query: str) -> str:
    """Search the web for current information."""
    try:
        import requests
        from urllib.parse import quote
        import re
        from datetime import datetime, timedelta
        
        # For stock prices, use Yahoo Finance API
        if any(word in query.lower() for word in ['stock', 'share', 'price', 'nvda', 'nvidia']):
            try:
                symbol = 'NVDA' if 'nvidia' in query.lower() or 'nvda' in query.lower() else None
                if symbol:
                    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
                    response = requests.get(url, timeout=10)
                    data = response.json()
                    
                    if data.get('chart', {}).get('result'):
                        price_data = data['chart']['result'][0]['meta']
                        current_price = price_data.get('regularMarketPrice', 'N/A')
                        prev_close = price_data.get('previousClose', 'N/A')
                        
                        if current_price != 'N/A':
                            change = current_price - prev_close if prev_close != 'N/A' else 0
                            change_pct = (change / prev_close * 100) if prev_close != 'N/A' else 0
                            
                            return f"📈 NVIDIA (NVDA) Stock Price:\n💰 Current: ${current_price:.2f}\n📊 Change: ${change:+.2f} ({change_pct:+.2f}%)\n🕐 Previous Close: ${prev_close:.2f}"
            except:
                pass
        
        # For news queries, provide a helpful response
        if any(word in query.lower() for word in ['news', 'yesterday', 'today', 'latest']):
            country = None
            if 'bangladesh' in query.lower():
                country = 'Bangladesh'
            elif 'india' in query.lower():
                country = 'India'
            elif 'usa' in query.lower() or 'america' in query.lower():
                country = 'USA'
            
            if country:
                return f"""🔍 News Search: {query}

📰 For latest {country} news, I recommend checking:
• BBC News - {country} section
• Reuters - {country} coverage  
• Local news websites
• Google News - {country}

💡 I cannot access real-time news feeds, but these sources will have the most current information about {country}.

🕐 For yesterday's news specifically, try searching "{country} news December 22 2025" on these platforms."""
        
        # Generic search response
        return f"""🔍 Web Search: {query}

💡 I have limited web access. For best results, try:
• Google Search: google.com
• Specific news sites: BBC, Reuters, CNN
• Official websites for accurate information

🔧 For technical queries, I can help with:
• Code generation and debugging
• File operations
• System commands
• Project analysis"""
        
    except ImportError:
        return "❌ Install requests: pip install requests"
    except Exception as e:
        return f"❌ Web search error: {e}"

@tool
def get_project_info() -> str:
    """Analyze current project structure."""
    try:
        cwd = os.getcwd()
        files = []
        for root, dirs, filenames in os.walk(cwd):
            # Skip hidden and common build directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'dist', 'build']]
            for file in filenames:
                if not file.startswith('.'):
                    rel_path = os.path.relpath(os.path.join(root, file), cwd)
                    files.append(rel_path)
        
        # Categorize files
        code_files = [f for f in files if f.endswith(('.py', '.js', '.ts', '.java', '.cpp', '.c', '.rs'))]
        config_files = [f for f in files if f.endswith(('.json', '.yaml', '.yml', '.toml', '.ini'))]
        docs = [f for f in files if f.endswith(('.md', '.txt', '.rst'))]
        
        info = f"📂 Project: {os.path.basename(cwd)}\n"
        info += f"📍 Location: {cwd}\n"
        info += f"📊 Total files: {len(files)}\n"
        if code_files:
            info += f"💻 Code files: {len(code_files)} ({', '.join(code_files[:3])}{'...' if len(code_files) > 3 else ''})\n"
        if config_files:
            info += f"⚙️ Config files: {len(config_files)}\n"
        if docs:
            info += f"📚 Documentation: {len(docs)}\n"
        
        return info
    except Exception as e:
        return f"Error analyzing project: {e}"

tools = [read_file, write_file, delete_file, run_code, list_files, get_memory, explain_changes, 
         open_app, close_app, shell_command, check_desktop_folder, create_desktop_folder, 
         explain_file_recovery, search_files, grep_content, execute_bash, show_capabilities, web_search, get_project_info]
llm_with_tools = llm.bind_tools(tools)

# State
class CopilotState(TypedDict):
    messages: Annotated[list[BaseMessage], operator.add]
    task: str
    files_touched: list

# Agent
def copilot_agent(state: CopilotState):
    try:
        # Limit message history to prevent token overflow
        messages = state.get("messages", [])
        if len(messages) > 10:  # Keep only last 10 messages
            messages = messages[-10:]
        
        memory = load_memory()
        context = ""
        if memory["sessions"]:
            recent_actions = memory["sessions"][-2:]  # Reduce to last 2 actions
            context_items = []
            for session in recent_actions:
                action = session.get('action', 'modified')  # Default to 'modified' if no action key
                context_items.append(f"- {action}: {session['task']}")
            context = f"\n\nRecent actions:\n" + "\n".join(context_items)
        
        # Resolve context references in the task
        task_with_context = state['task']
        
        # Handle "close it" context - look for recently opened apps
        if any(phrase in state['task'].lower() for phrase in ['close it', 'close that', 'shut it']):
            # Look in session actions for recently opened apps
            if hasattr(copilot_agent, 'last_opened_app'):
                task_with_context = f"close {copilot_agent.last_opened_app}"
            else:
                task_with_context = "close the most recently opened application"
        
        context_ref = get_context_reference(state['task'])
        if context_ref:
            if "delete" in state['task'].lower() or "remove" in state['task'].lower():
                task_with_context = f"Delete the folder '{context_ref}' from Desktop"
            elif "bring" in state['task'].lower() and "back" in state['task'].lower():
                task_with_context = f"Explain that the folder '{context_ref}' cannot be recovered - it was permanently deleted"
        
        system_msg = SystemMessage(content=(
            "You are Aerri-AI - an advanced AI coding assistant. "
            "Handle ONE task at a time. Don't mix multiple requests. "
            "When user says 'close it', close the most recently opened app. "
            "When user says 'open [app]', just open that app. "
            "Be direct and focused on the current request only. "
            f"Current task: {task_with_context}"
        ))
        
        # Limit conversation history to prevent token overflow
        if not state.get("messages"):
            user_msg = HumanMessage(content=task_with_context)
            msgs = [system_msg, user_msg]
        else:
            # Keep only recent messages
            recent_msgs = state["messages"][-5:] if len(state["messages"]) > 5 else state["messages"]
            msgs = [system_msg] + recent_msgs
        
        response = llm_with_tools.invoke(msgs)
        return {"messages": [response], "files_touched": state.get("files_touched", [])}
        
    except Exception as e:
        error_msg = str(e).lower()
        
        if "rate limit" in error_msg or "quota" in error_msg:
            error_response = HumanMessage(content="⚠️ I've reached my API rate limit. Please wait a moment and try again, or consider upgrading your plan for higher limits.")
        elif "token" in error_msg and ("limit" in error_msg or "exceeded" in error_msg):
            error_response = HumanMessage(content="⚠️ The conversation has become too long for me to process. Please start a new session or try a shorter request.")
        elif "connection" in error_msg or "timeout" in error_msg:
            error_response = HumanMessage(content="⚠️ I'm having trouble connecting to my AI service. Please check your internet connection and try again.")
        elif "authentication" in error_msg or "api key" in error_msg:
            error_response = HumanMessage(content="⚠️ There's an issue with my API credentials. Please check the configuration and try again.")
        else:
            error_response = HumanMessage(content=f"⚠️ I encountered an unexpected error: {str(e)[:100]}... Please try again or restart the session.")
        
        return {"messages": [error_response], "files_touched": state.get("files_touched", [])}

tool_node = ToolNode(tools)

# Graph
def should_continue(state: CopilotState):
    last_msg = state["messages"][-1]
    if hasattr(last_msg, 'tool_calls') and last_msg.tool_calls:
        return "tools"
    return END

workflow = StateGraph(CopilotState)
workflow.add_node("agent", copilot_agent)
workflow.add_node("tools", tool_node)
workflow.set_entry_point("agent")
workflow.add_conditional_edges("agent", should_continue)
workflow.add_edge("tools", "agent")

app = workflow.compile(checkpointer=None, debug=False)

def main():
    try:
        print_purple("""
 █████╗ ███████╗██████╗ ██████╗ ██╗      █████╗ ██╗
██╔══██╗██╔════╝██╔══██╗██╔══██╗██║     ██╔══██╗██║
███████║█████╗  ██████╔╝██████╔╝██║     ███████║██║
██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║     ██╔══██║██║
██║  ██║███████╗██║  ██║██║  ██║██║     ██║  ██║██║
╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝
        """)
        print_cyan("        Advanced AI Coding Assistant")
        print_cyan("    I can create, edit, delete files and fix errors!")
        print_cyan("    💡 Tip: Ask 'why' or 'how' after any action for explanations")
        print_purple("=" * 60)
        
        # Session-level memory to track actions within this CLI session
        session_actions = []
        
        while True:
            try:
                task = input(f"\n{PURPLE}{BOLD}What would you like me to do?{RESET} (or 'quit' to exit): ")
                
                if task.lower() in ['quit', 'exit', 'q']:
                    break
                
                # Filter out greetings and vague inputs
                greetings = ['hi', 'hello', 'hey', 'ok', 'okay', 'yes', 'no', 'nothing', 'sure', 'fine', 'good']
                goodbyes = ['bye', 'byee', 'goodbye', 'see you', 'later']
                
                if task.lower().strip() in greetings:
                    print_cyan("💡 Please describe a specific task you'd like me to help with.")
                    continue
                elif task.lower().strip() in goodbyes:
                    print_purple("👋 Goodbye! Have a great day!")
                    break
                
                # Handle help commands
                if task.lower() in ['help', 'h', '?', 'what can you do', 'capabilities']:
                    print(show_capabilities())
                    continue
                
                # Handle session reset
                if task.lower() in ['reset', 'clear', 'new session']:
                    session_actions = []
                    print_green("🔄 Session reset! Starting fresh.")
                    continue
                
                # Handle project info
                if task.lower() in ['info', 'project', 'status']:
                    print(get_project_info())
                    continue
                
                # Handle "what did you just do" queries
                if any(phrase in task.lower() for phrase in ['what did you', 'what have you', 'what just', 'what you just']):
                    if session_actions:
                        recent = session_actions[-3:]  # Last 3 actions
                        response = "🤖 Aerri-AI: Here's what I just did in this session:\n"
                        for i, action in enumerate(reversed(recent), 1):
                            response += f"{i}. {action}\n"
                        print_purple(response)
                        print_green("\n✅ Task completed!")
                        continue
                    else:
                        print_purple("🤖 Aerri-AI: I haven't performed any actions in this session yet. How can I help you?")
                        print_green("\n✅ Task completed!")
                        continue
                    
                initial_state = {"task": task, "messages": [], "files_touched": []}
                
                print_yellow("\n--- Working ---\n")
                
                files_touched = []
                last_action = ""
                
                # Start thinking animation
                thinking = LoadingAnimation("🧠 Thinking")
                thinking.start()
                
                try:
                    for output in app.stream(initial_state, {"recursion_limit": 8}):
                        thinking.stop()  # Stop thinking when we get output
                        
                        try:
                            for key, value in output.items():
                                if key == "agent" and "messages" in value:
                                    msg = value["messages"][-1]
                                    if hasattr(msg, 'content') and msg.content:
                                        print_purple(f"🤖 Aerri-AI: {msg.content}")
                                        last_action = msg.content
                                    # Show tool calls with fun messages and loading
                                    if hasattr(msg, 'tool_calls') and msg.tool_calls:
                                        for call in msg.tool_calls:
                                            tool_name = call.get('name', 'unknown')
                                            print_yellow(f"🔧 {get_tool_message(tool_name)}")
                                            
                                            # Start tool loading animation
                                            tool_loading = LoadingAnimation(f"Executing {tool_name}")
                                            tool_loading.start()
                                            time.sleep(0.5)  # Brief pause for effect
                                            tool_loading.stop()
                                            
                                            if random.random() < 0.3:  # 30% chance for joke
                                                print_cyan(f"😄 {random.choice(JOKES)}")
                                    if "files_touched" in value:
                                        files_touched = value["files_touched"]
                                elif key == "tools" and "messages" in value:
                                    msg = value["messages"][-1]
                                    print_green(f"✅ {msg.content}")
                                    if random.random() < 0.2:  # 20% chance for celebration
                                        print_cyan("🎉 Another task conquered!")
                                    
                                    # Start thinking again for next iteration
                                    thinking = LoadingAnimation("🧠 Processing results")
                                    thinking.start()
                        except KeyboardInterrupt:
                            thinking.stop()
                            print_purple("\n\n👋 Goodbye from Aerri-AI!")
                            exit(0)
                    
                    thinking.stop()  # Make sure to stop final animation
                except KeyboardInterrupt:
                    thinking.stop()
                    print_purple("\n\n👋 Goodbye from Aerri-AI!")
                    exit(0)
                
                # Add to session memory
                if last_action:
                    session_actions.append(f"{task} → {last_action}")
                
                # Save to memory
                if files_touched:
                    # Determine action type based on task
                    action_type = "modified"
                    if "create" in task.lower() or "make" in task.lower():
                        action_type = "created"
                    elif "delete" in task.lower() or "remove" in task.lower():
                        action_type = "deleted"
                    
                    add_to_memory(task, files_touched, action_type)
                
                print_green("\n✅ Task completed!")
                
                # Interactive follow-up
                while True:
                    try:
                        follow_up = input(f"\n{CYAN}❓ Ask 'why', 'how', or continue with new task (press Enter): {RESET}").strip()
                        
                        if not follow_up:
                            break
                        
                        # Handle "open again" context
                        if follow_up.lower() in ['open again', 'reopen', 'open it again']:
                            if hasattr(copilot_agent, 'last_opened_app'):
                                context_task = f"open {copilot_agent.last_opened_app}"
                            else:
                                print_cyan("💡 Please specify which app you'd like to open.")
                                continue
                        # Handle goodbye messages
                        elif follow_up.lower() in ['bye', 'byee', 'goodbye', 'see you', 'later']:
                            print_purple("👋 Goodbye! Have a great day!")
                            continue
                        # Handle confirmations if last response was a question
                        elif follow_up.lower() in ['yes', 'y', 'sure', 'ok', 'okay'] and last_action and '?' in last_action:
                            # Extract the action from the question and execute it
                            if 'whatsapp' in last_action.lower():
                                context_task = "open whatsapp"
                            elif 'folder' in last_action.lower():
                                context_task = "create folder"
                            else:
                                context_task = follow_up
                            
                            new_state = {"task": context_task, "messages": [], "files_touched": []}
                            print_yellow("\n--- Working ---\n")
                            
                            working = LoadingAnimation("🧠 Processing confirmation")
                            working.start()
                            
                            new_last_action = ""
                            
                            try:
                                for output in app.stream(new_state, {"recursion_limit": 5}):
                                    working.stop()
                                    for key, value in output.items():
                                        if key == "agent" and "messages" in value:
                                            msg = value["messages"][-1]
                                            if hasattr(msg, 'content') and msg.content:
                                                print_purple(f"🤖 Aerri-AI: {msg.content}")
                                                new_last_action = msg.content
                                        elif key == "tools" and "messages" in value:
                                            msg = value["messages"][-1]
                                            print_green(f"✅ {msg.content}")
                                        working = LoadingAnimation("🧠 Continuing")
                                        working.start()
                                working.stop()
                                print_green("\n✅ Task completed!")
                            except KeyboardInterrupt:
                                working.stop()
                                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                                exit(0)
                            
                            if new_last_action:
                                session_actions.append(f"{context_task} → {new_last_action}")
                            continue
                        
                        # Filter out other vague responses
                        vague_responses = ['no', 'nothing', 'nope', 'fine', 'good', 'thanks', 'thank you']
                        if follow_up.lower() in vague_responses:
                            print_cyan("💡 Please provide a specific task or press Enter to continue.")
                            continue
                        elif follow_up.lower() in ['why', 'how', 'explain']:
                            explanation_state = {
                                "task": f"Explain {follow_up} you performed the previous action: {last_action}",
                                "messages": [],
                                "files_touched": []
                            }
                            
                            print_yellow("\n--- Explaining ---\n")
                            
                            explaining = LoadingAnimation("🤔 Analyzing")
                            explaining.start()
                            
                            try:
                                for output in app.stream(explanation_state, {"recursion_limit": 10}):
                                    explaining.stop()
                                    try:
                                        for key, value in output.items():
                                            if key == "agent" and "messages" in value:
                                                msg = value["messages"][-1]
                                                if hasattr(msg, 'content') and msg.content:
                                                    print_purple(f"🤖 Explanation: {msg.content}")
                                            elif key == "tools" and "messages" in value:
                                                msg = value["messages"][-1]
                                                print_green(f"✅ {msg.content}")
                                            explaining = LoadingAnimation("🤔 Continuing analysis")
                                            explaining.start()
                                    except KeyboardInterrupt:
                                        explaining.stop()
                                        raise
                                explaining.stop()
                            except KeyboardInterrupt:
                                explaining.stop()
                                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                                exit(0)
                        else:
                            # Handle "what did you just do" in follow-up
                            if any(phrase in follow_up.lower() for phrase in ['what did you', 'what have you', 'what just', 'what you just']):
                                if session_actions:
                                    recent = session_actions[-3:]  # Last 3 actions
                                    response = "🤖 Aerri-AI: Here's what I just did in this session:\n"
                                    for i, action in enumerate(reversed(recent), 1):
                                        response += f"{i}. {action}\n"
                                    print_purple(response)
                                    print_green("\n✅ Task completed!")
                                    continue
                                else:
                                    print_purple("🤖 Aerri-AI: I haven't performed any actions in this session yet.")
                                    print_green("\n✅ Task completed!")
                                    continue
                            
                            # Treat as new task with context from previous interaction
                            context_task = follow_up
                            if last_action and any(word in last_action.lower() for word in ['which', 'what', 'specify']):
                                context_task = f"{task}: {follow_up}"
                            
                            new_state = {"task": context_task, "messages": [], "files_touched": []}
                            print_yellow("\n--- Working ---\n")
                            
                            working = LoadingAnimation("🧠 Processing new task")
                            working.start()
                            
                            new_last_action = ""
                            
                            try:
                                for output in app.stream(new_state, {"recursion_limit": 10}):
                                    working.stop()
                                    try:
                                        for key, value in output.items():
                                            if key == "agent" and "messages" in value:
                                                msg = value["messages"][-1]
                                                if hasattr(msg, 'content') and msg.content:
                                                    print_purple(f"🤖 Aerri-AI: {msg.content}")
                                                    new_last_action = msg.content
                                                if hasattr(msg, 'tool_calls') and msg.tool_calls:
                                                    for call in msg.tool_calls:
                                                        tool_name = call.get('name', 'unknown')
                                                        print_yellow(f"🔧 {get_tool_message(tool_name)}")
                                                        
                                                        tool_loading = LoadingAnimation(f"Executing {tool_name}")
                                                        tool_loading.start()
                                                        time.sleep(0.3)
                                                        tool_loading.stop()
                                                        
                                                        if random.random() < 0.3:
                                                            print_cyan(f"😄 {random.choice(JOKES)}")
                                                if "files_touched" in value:
                                                    files_touched.extend(value["files_touched"])
                                            elif key == "tools" and "messages" in value:
                                                msg = value["messages"][-1]
                                                print_green(f"✅ {msg.content}")
                                            working = LoadingAnimation("🧠 Continuing work")
                                            working.start()
                                    except KeyboardInterrupt:
                                        working.stop()
                                        raise
                                working.stop()
                                print_green("\n✅ Task completed!")
                            except KeyboardInterrupt:
                                working.stop()
                                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                                exit(0)
                            
                            # Add to session memory
                            if new_last_action:
                                session_actions.append(f"{follow_up} → {new_last_action}")
                            
                            # Save new task to memory
                            if files_touched:
                                action_type = "modified"
                                if "create" in follow_up.lower() or "make" in follow_up.lower():
                                    action_type = "created"
                                elif "delete" in follow_up.lower() or "remove" in follow_up.lower():
                                    action_type = "deleted"
                                add_to_memory(follow_up, files_touched, action_type)
                    except KeyboardInterrupt:
                        print_purple("\n\n👋 Goodbye from Aerri-AI!")
                        exit(0)
                        
            except KeyboardInterrupt:
                print_purple("\n\n👋 Goodbye from Aerri-AI!")
                exit(0)
            except Exception as e:
                print_yellow(f"\n❌ Error: {e}")
                continue
        
        print_purple("\n👋 Goodbye from Aerri-AI!")
        
    except KeyboardInterrupt:
        print_purple("\n\n👋 Goodbye from Aerri-AI!")
    except Exception as e:
        print_yellow(f"\n❌ Unexpected error: {e}")
        print_purple("👋 Goodbye from Aerri-AI!")

if __name__ == "__main__":
    main()
