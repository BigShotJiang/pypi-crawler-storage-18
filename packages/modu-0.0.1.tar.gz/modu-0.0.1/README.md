**Modu** is a module for doing modular arithmetic in Python. It is in essence a "domain-specific language" (DSL) dedicated to modular arithmetic. Modu is best used as an interactive calculator in Python terminal sessions (REPL) or in Jupyter Notebooks. Modu can be used as well in your Python scripts to ease calculations involving modular arithmetic. The prime target domain is research and education in number theory.

Modu allows you defining and manipulating sets of residue classes for given moduli. These sets are displayed with usual notations of modular arithmetic, using character strings, like `n ≡ {0, ±2, +3} (mod 6)` or rendered as LaTeX formula like
$$ n \equiv \left\{\begin{array}{l} 0\\±2\\+3 \end{array}\right. \pmod{6} $$
New sets can be computed from existing ones using set operations (union, intersection, complement), as well as  arithmetic operations (addition, negation, multiplication, division, exponentiation).

Modu is an open-source module distributed under the **MIT license**.

Here are few examples.
* integers having residue 0 modulo 2 (the even numbers):
```
>>> from modu import O
>>> O % 2
0 (mod 2)
```
* integers multiples of 2 or 3, defined by set union:  
```
>>> O%2 | O%3
{0, ±2, +3} (mod 6)
```
* integers not multiples of 2 or 3, defined by complement of the previous set:
```
>>> ~(O%2 | O%3)
±1 (mod 6)
```
* testing whether 15 and 23 belongs to the previous set (note: any prime numbers greater or equal to 5 belongs to this set):
```
>>> 15 in ~(O%2 | O%3)
False
>>> 23 in ~(O%2 | O%3)
True
```
* integers multiples of 2 and 3 altogether, defined by set intersection--see Chinese remainder theorem:
```
>>> O%2 & O%3
0 (mod 6)
```
* checking whether two sets are equivalent or not:
```
>>> O%2 | O%3 == (0, 2, 3, 4) + O%6
True
>>> O%2 & O%3 == O%6
True
>>> O%2 | O%3 != O%6
True
```
Modu provides more functions for normalizing the representation, tuning the display format or providing samples using table layout. Modu is much suited in REPL mode or in Jupyter Notebook, the latter performing instantaneous LaTex formula rendering.
