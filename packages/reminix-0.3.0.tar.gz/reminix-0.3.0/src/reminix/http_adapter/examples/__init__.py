"""
HTTP adapter examples
"""
