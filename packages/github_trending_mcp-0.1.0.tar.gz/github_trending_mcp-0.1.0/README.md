# GitHub Trending MCP Server

[![PyPI version](https://badge.fury.io/py/github-trending-mcp.svg)](https://badge.fury.io/py/github-trending-mcp)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

A Model Context Protocol (MCP) server that provides GitHub trending repositories information. This server allows LLMs to fetch and analyze trending repositories on GitHub.

## Features

- 🔥 Get real-time GitHub trending repositories
- 🌐 Filter by programming language (Python, JavaScript, Rust, Go, etc.)
- 📅 Filter by time range (daily, weekly, monthly)
- 🗣️ Filter by spoken language (Chinese, English, Japanese, etc.)
- 📊 Returns detailed repository information including stars, forks, description, and contributors

## Installation

### Using pip

```bash
pip install github-trending-mcp
```

### Using uv (recommended)

```bash
uv pip install github-trending-mcp
```

## Usage

### As a CLI tool

```bash
github-trending-mcp
```

### Configure with Claude Desktop

Add the following to your Claude Desktop configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "github-trending": {
      "command": "github-trending-mcp"
    }
  }
}
```

Or if using uv:

```json
{
  "mcpServers": {
    "github-trending": {
      "command": "uv",
      "args": ["run", "github-trending-mcp"]
    }
  }
}
```

Or using uvx directly:

```json
{
  "mcpServers": {
    "github-trending": {
      "command": "uvx",
      "args": ["github-trending-mcp"]
    }
  }
}
```

### Configure with Cursor

Add to your Cursor MCP settings:

```json
{
  "mcpServers": {
    "github-trending": {
      "command": "github-trending-mcp"
    }
  }
}
```

## Available Tools

### `get_github_trending`

Fetches GitHub trending repositories with optional filters.

**Parameters:**

| Parameter | Type | Description | Default |
|-----------|------|-------------|---------|
| `language` | string | Programming language filter (e.g., 'python', 'javascript', 'rust') | `""` (all) |
| `since` | string | Time range: 'daily', 'weekly', or 'monthly' | `"daily"` |
| `spoken_language` | string | Spoken language code (e.g., 'zh', 'en', 'ja') | `""` (all) |

**Example Usage in Claude:**

```
Get the trending Python repositories this week
```

```
Show me trending Rust projects with Chinese descriptions
```

```
What are the monthly trending JavaScript repositories?
```

## Response Format

The tool returns formatted markdown with repository information:

```markdown
# GitHub Trending Repositories

**Filters:** Language: python, Period: daily, Spoken Language: All

**Total:** 25 repositories

---

## 1. [owner/repo-name](https://github.com/owner/repo-name)

📝 Repository description here

- ⭐ Stars: 1,234
- 🍴 Forks: 567
- 💻 Language: Python
- 📈 234 stars today
- 👥 Built by: user1, user2, user3
```

## Development

### Clone the repository

```bash
git clone https://github.com/wwango/github-trending-mcp.git
cd github-trending-mcp
```

### Install dependencies

```bash
uv venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
uv pip install -e ".[dev]"
```

### Run tests

```bash
pytest
```

### Build the package

```bash
uv build
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Acknowledgments

- Built with [MCP (Model Context Protocol)](https://modelcontextprotocol.io/)
- Data sourced from [GitHub Trending](https://github.com/trending)

