"""MCP Server for GitHub Trending repositories."""

import asyncio
from typing import Any
from mcp.server.models import InitializationOptions
import mcp.types as types
from mcp.server import NotificationOptions, Server
import mcp.server.stdio
import httpx
from bs4 import BeautifulSoup

# Create server instance
server = Server("github-trending-mcp")

# GitHub Trending URL
GITHUB_TRENDING_URL = "https://github.com/trending"


async def fetch_trending_repos(
    language: str = "",
    since: str = "daily",
    spoken_language: str = ""
) -> list[dict[str, Any]]:
    """
    Fetch trending repositories from GitHub.
    
    Args:
        language: Programming language filter (e.g., 'python', 'javascript', 'rust')
        since: Time range - 'daily', 'weekly', or 'monthly'
        spoken_language: Spoken language filter (e.g., 'zh' for Chinese, 'en' for English)
    
    Returns:
        List of trending repository information
    """
    # Build URL with parameters
    url = GITHUB_TRENDING_URL
    if language:
        url = f"{url}/{language}"
    
    params = {}
    if since and since in ["daily", "weekly", "monthly"]:
        params["since"] = since
    if spoken_language:
        params["spoken_language_code"] = spoken_language
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url,
            params=params,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            },
            follow_redirects=True,
            timeout=30.0
        )
        response.raise_for_status()
        html = response.text
    
    soup = BeautifulSoup(html, "html.parser")
    repos = []
    
    # Find all repository articles
    articles = soup.find_all("article", class_="Box-row")
    
    for article in articles:
        repo = {}
        
        # Get repository name and owner
        h2 = article.find("h2")
        if h2:
            link = h2.find("a")
            if link:
                href = link.get("href", "").strip("/")
                parts = href.split("/")
                if len(parts) >= 2:
                    repo["owner"] = parts[0]
                    repo["name"] = parts[1]
                    repo["full_name"] = f"{parts[0]}/{parts[1]}"
                    repo["url"] = f"https://github.com/{href}"
        
        # Get description
        p = article.find("p", class_="col-9")
        if p:
            repo["description"] = p.get_text(strip=True)
        else:
            repo["description"] = ""
        
        # Get programming language
        lang_span = article.find("span", itemprop="programmingLanguage")
        if lang_span:
            repo["language"] = lang_span.get_text(strip=True)
        else:
            repo["language"] = ""
        
        # Get stars count
        star_link = article.find("a", href=lambda x: x and "/stargazers" in x)
        if star_link:
            repo["stars"] = star_link.get_text(strip=True).replace(",", "")
        else:
            repo["stars"] = "0"
        
        # Get forks count
        fork_link = article.find("a", href=lambda x: x and "/forks" in x)
        if fork_link:
            repo["forks"] = fork_link.get_text(strip=True).replace(",", "")
        else:
            repo["forks"] = "0"
        
        # Get stars today/this week/this month
        stars_today_span = article.find("span", class_="d-inline-block float-sm-right")
        if stars_today_span:
            repo["stars_period"] = stars_today_span.get_text(strip=True)
        else:
            repo["stars_period"] = ""
        
        # Get built by (contributors)
        built_by = article.find("span", class_="d-inline-block mr-3")
        if built_by:
            contributors = []
            for img in built_by.find_all("img"):
                alt = img.get("alt", "")
                if alt.startswith("@"):
                    contributors.append(alt[1:])
            repo["built_by"] = contributors
        else:
            repo["built_by"] = []
        
        if "full_name" in repo:
            repos.append(repo)
    
    return repos


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """List available tools."""
    return [
        types.Tool(
            name="get_github_trending",
            description="Get GitHub trending repositories. Returns a list of currently trending repositories on GitHub with details like stars, forks, description, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "language": {
                        "type": "string",
                        "description": "Programming language to filter (e.g., 'python', 'javascript', 'rust', 'go', 'typescript'). Leave empty for all languages.",
                        "default": ""
                    },
                    "since": {
                        "type": "string",
                        "description": "Time range for trending: 'daily', 'weekly', or 'monthly'",
                        "enum": ["daily", "weekly", "monthly"],
                        "default": "daily"
                    },
                    "spoken_language": {
                        "type": "string", 
                        "description": "Spoken language code (e.g., 'zh' for Chinese, 'en' for English, 'ja' for Japanese). Leave empty for all.",
                        "default": ""
                    }
                },
                "required": []
            }
        )
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """Handle tool calls."""
    if name != "get_github_trending":
        raise ValueError(f"Unknown tool: {name}")
    
    arguments = arguments or {}
    language = arguments.get("language", "")
    since = arguments.get("since", "daily")
    spoken_language = arguments.get("spoken_language", "")
    
    try:
        repos = await fetch_trending_repos(
            language=language,
            since=since,
            spoken_language=spoken_language
        )
        
        if not repos:
            return [types.TextContent(
                type="text",
                text="No trending repositories found for the specified criteria."
            )]
        
        # Format the response
        result_lines = [f"# GitHub Trending Repositories\n"]
        result_lines.append(f"**Filters:** Language: {language or 'All'}, Period: {since}, Spoken Language: {spoken_language or 'All'}\n")
        result_lines.append(f"**Total:** {len(repos)} repositories\n")
        result_lines.append("---\n")
        
        for i, repo in enumerate(repos, 1):
            result_lines.append(f"## {i}. [{repo['full_name']}]({repo['url']})\n")
            if repo.get("description"):
                result_lines.append(f"📝 {repo['description']}\n")
            result_lines.append(f"- ⭐ Stars: {repo.get('stars', 'N/A')}")
            result_lines.append(f"- 🍴 Forks: {repo.get('forks', 'N/A')}")
            if repo.get("language"):
                result_lines.append(f"- 💻 Language: {repo['language']}")
            if repo.get("stars_period"):
                result_lines.append(f"- 📈 {repo['stars_period']}")
            if repo.get("built_by"):
                result_lines.append(f"- 👥 Built by: {', '.join(repo['built_by'][:5])}")
            result_lines.append("\n")
        
        return [types.TextContent(
            type="text",
            text="\n".join(result_lines)
        )]
        
    except httpx.HTTPError as e:
        return [types.TextContent(
            type="text",
            text=f"Error fetching GitHub trending: HTTP error - {str(e)}"
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Error fetching GitHub trending: {str(e)}"
        )]


async def run():
    """Run the MCP server."""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="github-trending-mcp",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


def main():
    """Main entry point."""
    asyncio.run(run())


if __name__ == "__main__":
    main()

