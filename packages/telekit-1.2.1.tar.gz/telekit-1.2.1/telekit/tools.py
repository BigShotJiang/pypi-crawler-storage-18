from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent  # telekit/
