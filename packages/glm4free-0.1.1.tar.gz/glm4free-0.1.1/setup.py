from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="glm4free",
    version="0.1.1",
    description="A Python API Wrapper for Z.AI (GLM).",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SertraFurr",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    entry_points={
        'console_scripts': [
            'glm4free=GLM4Free.client:main',
        ],
    },
    python_requires='>=3.6',
)
