# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInstance:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'instancename': 'str',
        'region': 'str',
        'zone': 'str',
        'arch': 'str',
        'cpu_flavor': 'str',
        'vpc_id': 'str',
        'subnet_id': 'str',
        'service_ip': 'str',
        'security_group_ids': 'list[str]',
        'status': 'int',
        'run_status': 'int',
        'access_status': 'int',
        'upgradable': 'int',
        'cloud_service_type': 'str',
        'resource_type': 'str',
        'resource_spec_code': 'str',
        'specification': 'str',
        'hosts': 'list[IdHostnameEntry]',
        'server_id': 'str',
        'create_time': 'int',
        'instance_name': 'str'
    }

    attribute_map = {
        'id': 'id',
        'instancename': 'instancename',
        'region': 'region',
        'zone': 'zone',
        'arch': 'arch',
        'cpu_flavor': 'cpu_flavor',
        'vpc_id': 'vpc_id',
        'subnet_id': 'subnet_id',
        'service_ip': 'service_ip',
        'security_group_ids': 'security_group_ids',
        'status': 'status',
        'run_status': 'run_status',
        'access_status': 'access_status',
        'upgradable': 'upgradable',
        'cloud_service_type': 'cloudServiceType',
        'resource_type': 'resourceType',
        'resource_spec_code': 'resourceSpecCode',
        'specification': 'specification',
        'hosts': 'hosts',
        'server_id': 'serverId',
        'create_time': 'create_time',
        'instance_name': 'instance_name'
    }

    def __init__(self, id=None, instancename=None, region=None, zone=None, arch=None, cpu_flavor=None, vpc_id=None, subnet_id=None, service_ip=None, security_group_ids=None, status=None, run_status=None, access_status=None, upgradable=None, cloud_service_type=None, resource_type=None, resource_spec_code=None, specification=None, hosts=None, server_id=None, create_time=None, instance_name=None):
        r"""ListInstance

        The model defined in huaweicloud sdk

        :param id: 独享引擎实例ID
        :type id: str
        :param instancename: 独享引擎实例名称
        :type instancename: str
        :param region: 独享引擎实例Region ID
        :type region: str
        :param zone: 可用区ID
        :type zone: str
        :param arch: CPU架构
        :type arch: str
        :param cpu_flavor: ECS规格
        :type cpu_flavor: str
        :param vpc_id: 独享引擎实例所在VPC ID
        :type vpc_id: str
        :param subnet_id: 独享引擎实例所在VPC的子网ID
        :type subnet_id: str
        :param service_ip: 独享引擎实例的业务面IP
        :type service_ip: str
        :param security_group_ids: 独享引擎绑定的安全组
        :type security_group_ids: list[str]
        :param status: **参数解释：** 独享引擎计费状态标识，用于指示独享引擎当前的计费使用状态 **约束限制：** 不涉及 **取值范围：**  - 0：正常计费  - 1：冻结，资源和数据会保留，但租户无法再正常使用云服务  - 2：终止，资源和数据将清除 **默认取值：** 不涉及
        :type status: int
        :param run_status: **参数解释：** 独享引擎运行状态标识，用于反映独享引擎当前的运行生命周期状态 **约束限制：** 不涉及 **取值范围：**  - 0：创建中  - 1：运行中  - 2：删除中  - 3：已删除  - 4：创建失败  - 5：已冻结  - 6：异常  - 7：更新中  - 8：更新失败 **默认取值：** 不涉及
        :type run_status: int
        :param access_status: **参数解释：** 独享引擎接入状态 **约束限制：** 不涉及 **取值范围：**  - 0: 未接入  - 1: 已接入  **默认取值：** 不涉及
        :type access_status: int
        :param upgradable: 独享引擎是否可升级（0：不可升级，1：可升级）
        :type upgradable: int
        :param cloud_service_type: 云服务代码。 仅作为标记，用户可忽略。
        :type cloud_service_type: str
        :param resource_type: 云服务资源类型，仅作为标记，用户可忽略。
        :type resource_type: str
        :param resource_spec_code: 云服务资源代码。仅作为标记，用户可忽略。
        :type resource_spec_code: str
        :param specification: 独享引擎ECS规格，如\&quot;8vCPUs | 16GB\&quot;
        :type specification: str
        :param hosts: 独享引擎防护的域名
        :type hosts: list[:class:`huaweicloudsdkwaf.v1.IdHostnameEntry`]
        :param server_id: 独享引擎ECS ID
        :type server_id: str
        :param create_time: 引擎实例创建时间
        :type create_time: int
        :param instance_name: 独享引擎实例名称
        :type instance_name: str
        """
        
        

        self._id = None
        self._instancename = None
        self._region = None
        self._zone = None
        self._arch = None
        self._cpu_flavor = None
        self._vpc_id = None
        self._subnet_id = None
        self._service_ip = None
        self._security_group_ids = None
        self._status = None
        self._run_status = None
        self._access_status = None
        self._upgradable = None
        self._cloud_service_type = None
        self._resource_type = None
        self._resource_spec_code = None
        self._specification = None
        self._hosts = None
        self._server_id = None
        self._create_time = None
        self._instance_name = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if instancename is not None:
            self.instancename = instancename
        if region is not None:
            self.region = region
        if zone is not None:
            self.zone = zone
        if arch is not None:
            self.arch = arch
        if cpu_flavor is not None:
            self.cpu_flavor = cpu_flavor
        if vpc_id is not None:
            self.vpc_id = vpc_id
        if subnet_id is not None:
            self.subnet_id = subnet_id
        if service_ip is not None:
            self.service_ip = service_ip
        if security_group_ids is not None:
            self.security_group_ids = security_group_ids
        if status is not None:
            self.status = status
        if run_status is not None:
            self.run_status = run_status
        if access_status is not None:
            self.access_status = access_status
        if upgradable is not None:
            self.upgradable = upgradable
        if cloud_service_type is not None:
            self.cloud_service_type = cloud_service_type
        if resource_type is not None:
            self.resource_type = resource_type
        if resource_spec_code is not None:
            self.resource_spec_code = resource_spec_code
        if specification is not None:
            self.specification = specification
        if hosts is not None:
            self.hosts = hosts
        if server_id is not None:
            self.server_id = server_id
        if create_time is not None:
            self.create_time = create_time
        if instance_name is not None:
            self.instance_name = instance_name

    @property
    def id(self):
        r"""Gets the id of this ListInstance.

        独享引擎实例ID

        :return: The id of this ListInstance.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this ListInstance.

        独享引擎实例ID

        :param id: The id of this ListInstance.
        :type id: str
        """
        self._id = id

    @property
    def instancename(self):
        r"""Gets the instancename of this ListInstance.

        独享引擎实例名称

        :return: The instancename of this ListInstance.
        :rtype: str
        """
        return self._instancename

    @instancename.setter
    def instancename(self, instancename):
        r"""Sets the instancename of this ListInstance.

        独享引擎实例名称

        :param instancename: The instancename of this ListInstance.
        :type instancename: str
        """
        self._instancename = instancename

    @property
    def region(self):
        r"""Gets the region of this ListInstance.

        独享引擎实例Region ID

        :return: The region of this ListInstance.
        :rtype: str
        """
        return self._region

    @region.setter
    def region(self, region):
        r"""Sets the region of this ListInstance.

        独享引擎实例Region ID

        :param region: The region of this ListInstance.
        :type region: str
        """
        self._region = region

    @property
    def zone(self):
        r"""Gets the zone of this ListInstance.

        可用区ID

        :return: The zone of this ListInstance.
        :rtype: str
        """
        return self._zone

    @zone.setter
    def zone(self, zone):
        r"""Sets the zone of this ListInstance.

        可用区ID

        :param zone: The zone of this ListInstance.
        :type zone: str
        """
        self._zone = zone

    @property
    def arch(self):
        r"""Gets the arch of this ListInstance.

        CPU架构

        :return: The arch of this ListInstance.
        :rtype: str
        """
        return self._arch

    @arch.setter
    def arch(self, arch):
        r"""Sets the arch of this ListInstance.

        CPU架构

        :param arch: The arch of this ListInstance.
        :type arch: str
        """
        self._arch = arch

    @property
    def cpu_flavor(self):
        r"""Gets the cpu_flavor of this ListInstance.

        ECS规格

        :return: The cpu_flavor of this ListInstance.
        :rtype: str
        """
        return self._cpu_flavor

    @cpu_flavor.setter
    def cpu_flavor(self, cpu_flavor):
        r"""Sets the cpu_flavor of this ListInstance.

        ECS规格

        :param cpu_flavor: The cpu_flavor of this ListInstance.
        :type cpu_flavor: str
        """
        self._cpu_flavor = cpu_flavor

    @property
    def vpc_id(self):
        r"""Gets the vpc_id of this ListInstance.

        独享引擎实例所在VPC ID

        :return: The vpc_id of this ListInstance.
        :rtype: str
        """
        return self._vpc_id

    @vpc_id.setter
    def vpc_id(self, vpc_id):
        r"""Sets the vpc_id of this ListInstance.

        独享引擎实例所在VPC ID

        :param vpc_id: The vpc_id of this ListInstance.
        :type vpc_id: str
        """
        self._vpc_id = vpc_id

    @property
    def subnet_id(self):
        r"""Gets the subnet_id of this ListInstance.

        独享引擎实例所在VPC的子网ID

        :return: The subnet_id of this ListInstance.
        :rtype: str
        """
        return self._subnet_id

    @subnet_id.setter
    def subnet_id(self, subnet_id):
        r"""Sets the subnet_id of this ListInstance.

        独享引擎实例所在VPC的子网ID

        :param subnet_id: The subnet_id of this ListInstance.
        :type subnet_id: str
        """
        self._subnet_id = subnet_id

    @property
    def service_ip(self):
        r"""Gets the service_ip of this ListInstance.

        独享引擎实例的业务面IP

        :return: The service_ip of this ListInstance.
        :rtype: str
        """
        return self._service_ip

    @service_ip.setter
    def service_ip(self, service_ip):
        r"""Sets the service_ip of this ListInstance.

        独享引擎实例的业务面IP

        :param service_ip: The service_ip of this ListInstance.
        :type service_ip: str
        """
        self._service_ip = service_ip

    @property
    def security_group_ids(self):
        r"""Gets the security_group_ids of this ListInstance.

        独享引擎绑定的安全组

        :return: The security_group_ids of this ListInstance.
        :rtype: list[str]
        """
        return self._security_group_ids

    @security_group_ids.setter
    def security_group_ids(self, security_group_ids):
        r"""Sets the security_group_ids of this ListInstance.

        独享引擎绑定的安全组

        :param security_group_ids: The security_group_ids of this ListInstance.
        :type security_group_ids: list[str]
        """
        self._security_group_ids = security_group_ids

    @property
    def status(self):
        r"""Gets the status of this ListInstance.

        **参数解释：** 独享引擎计费状态标识，用于指示独享引擎当前的计费使用状态 **约束限制：** 不涉及 **取值范围：**  - 0：正常计费  - 1：冻结，资源和数据会保留，但租户无法再正常使用云服务  - 2：终止，资源和数据将清除 **默认取值：** 不涉及

        :return: The status of this ListInstance.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ListInstance.

        **参数解释：** 独享引擎计费状态标识，用于指示独享引擎当前的计费使用状态 **约束限制：** 不涉及 **取值范围：**  - 0：正常计费  - 1：冻结，资源和数据会保留，但租户无法再正常使用云服务  - 2：终止，资源和数据将清除 **默认取值：** 不涉及

        :param status: The status of this ListInstance.
        :type status: int
        """
        self._status = status

    @property
    def run_status(self):
        r"""Gets the run_status of this ListInstance.

        **参数解释：** 独享引擎运行状态标识，用于反映独享引擎当前的运行生命周期状态 **约束限制：** 不涉及 **取值范围：**  - 0：创建中  - 1：运行中  - 2：删除中  - 3：已删除  - 4：创建失败  - 5：已冻结  - 6：异常  - 7：更新中  - 8：更新失败 **默认取值：** 不涉及

        :return: The run_status of this ListInstance.
        :rtype: int
        """
        return self._run_status

    @run_status.setter
    def run_status(self, run_status):
        r"""Sets the run_status of this ListInstance.

        **参数解释：** 独享引擎运行状态标识，用于反映独享引擎当前的运行生命周期状态 **约束限制：** 不涉及 **取值范围：**  - 0：创建中  - 1：运行中  - 2：删除中  - 3：已删除  - 4：创建失败  - 5：已冻结  - 6：异常  - 7：更新中  - 8：更新失败 **默认取值：** 不涉及

        :param run_status: The run_status of this ListInstance.
        :type run_status: int
        """
        self._run_status = run_status

    @property
    def access_status(self):
        r"""Gets the access_status of this ListInstance.

        **参数解释：** 独享引擎接入状态 **约束限制：** 不涉及 **取值范围：**  - 0: 未接入  - 1: 已接入  **默认取值：** 不涉及

        :return: The access_status of this ListInstance.
        :rtype: int
        """
        return self._access_status

    @access_status.setter
    def access_status(self, access_status):
        r"""Sets the access_status of this ListInstance.

        **参数解释：** 独享引擎接入状态 **约束限制：** 不涉及 **取值范围：**  - 0: 未接入  - 1: 已接入  **默认取值：** 不涉及

        :param access_status: The access_status of this ListInstance.
        :type access_status: int
        """
        self._access_status = access_status

    @property
    def upgradable(self):
        r"""Gets the upgradable of this ListInstance.

        独享引擎是否可升级（0：不可升级，1：可升级）

        :return: The upgradable of this ListInstance.
        :rtype: int
        """
        return self._upgradable

    @upgradable.setter
    def upgradable(self, upgradable):
        r"""Sets the upgradable of this ListInstance.

        独享引擎是否可升级（0：不可升级，1：可升级）

        :param upgradable: The upgradable of this ListInstance.
        :type upgradable: int
        """
        self._upgradable = upgradable

    @property
    def cloud_service_type(self):
        r"""Gets the cloud_service_type of this ListInstance.

        云服务代码。 仅作为标记，用户可忽略。

        :return: The cloud_service_type of this ListInstance.
        :rtype: str
        """
        return self._cloud_service_type

    @cloud_service_type.setter
    def cloud_service_type(self, cloud_service_type):
        r"""Sets the cloud_service_type of this ListInstance.

        云服务代码。 仅作为标记，用户可忽略。

        :param cloud_service_type: The cloud_service_type of this ListInstance.
        :type cloud_service_type: str
        """
        self._cloud_service_type = cloud_service_type

    @property
    def resource_type(self):
        r"""Gets the resource_type of this ListInstance.

        云服务资源类型，仅作为标记，用户可忽略。

        :return: The resource_type of this ListInstance.
        :rtype: str
        """
        return self._resource_type

    @resource_type.setter
    def resource_type(self, resource_type):
        r"""Sets the resource_type of this ListInstance.

        云服务资源类型，仅作为标记，用户可忽略。

        :param resource_type: The resource_type of this ListInstance.
        :type resource_type: str
        """
        self._resource_type = resource_type

    @property
    def resource_spec_code(self):
        r"""Gets the resource_spec_code of this ListInstance.

        云服务资源代码。仅作为标记，用户可忽略。

        :return: The resource_spec_code of this ListInstance.
        :rtype: str
        """
        return self._resource_spec_code

    @resource_spec_code.setter
    def resource_spec_code(self, resource_spec_code):
        r"""Sets the resource_spec_code of this ListInstance.

        云服务资源代码。仅作为标记，用户可忽略。

        :param resource_spec_code: The resource_spec_code of this ListInstance.
        :type resource_spec_code: str
        """
        self._resource_spec_code = resource_spec_code

    @property
    def specification(self):
        r"""Gets the specification of this ListInstance.

        独享引擎ECS规格，如\"8vCPUs | 16GB\"

        :return: The specification of this ListInstance.
        :rtype: str
        """
        return self._specification

    @specification.setter
    def specification(self, specification):
        r"""Sets the specification of this ListInstance.

        独享引擎ECS规格，如\"8vCPUs | 16GB\"

        :param specification: The specification of this ListInstance.
        :type specification: str
        """
        self._specification = specification

    @property
    def hosts(self):
        r"""Gets the hosts of this ListInstance.

        独享引擎防护的域名

        :return: The hosts of this ListInstance.
        :rtype: list[:class:`huaweicloudsdkwaf.v1.IdHostnameEntry`]
        """
        return self._hosts

    @hosts.setter
    def hosts(self, hosts):
        r"""Sets the hosts of this ListInstance.

        独享引擎防护的域名

        :param hosts: The hosts of this ListInstance.
        :type hosts: list[:class:`huaweicloudsdkwaf.v1.IdHostnameEntry`]
        """
        self._hosts = hosts

    @property
    def server_id(self):
        r"""Gets the server_id of this ListInstance.

        独享引擎ECS ID

        :return: The server_id of this ListInstance.
        :rtype: str
        """
        return self._server_id

    @server_id.setter
    def server_id(self, server_id):
        r"""Sets the server_id of this ListInstance.

        独享引擎ECS ID

        :param server_id: The server_id of this ListInstance.
        :type server_id: str
        """
        self._server_id = server_id

    @property
    def create_time(self):
        r"""Gets the create_time of this ListInstance.

        引擎实例创建时间

        :return: The create_time of this ListInstance.
        :rtype: int
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this ListInstance.

        引擎实例创建时间

        :param create_time: The create_time of this ListInstance.
        :type create_time: int
        """
        self._create_time = create_time

    @property
    def instance_name(self):
        r"""Gets the instance_name of this ListInstance.

        独享引擎实例名称

        :return: The instance_name of this ListInstance.
        :rtype: str
        """
        return self._instance_name

    @instance_name.setter
    def instance_name(self, instance_name):
        r"""Sets the instance_name of this ListInstance.

        独享引擎实例名称

        :param instance_name: The instance_name of this ListInstance.
        :type instance_name: str
        """
        self._instance_name = instance_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInstance):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
