import os
import ast
import re
import hashlib
from radon.complexity import cc_visit
from radon.metrics import mi_visit
from git import Repo

class CodeDetoxEngine:
    def __init__(self, target_path):
        self.target_path = os.path.abspath(target_path)
        self.results = []

    def get_git_metrics(self, file_path):
        try:
            repo = Repo(self.target_path, search_parent_directories=True)
            rel_path = os.path.relpath(file_path, repo.working_tree_dir)
            commits = list(repo.iter_commits(paths=rel_path))
            return len(commits)
        except:
            return 0

    def detect_duplication(self, lines):
        seen = {}
        dupes = 0
        for i in range(len(lines) - 3):
            chunk = "".join(lines[i:i+3]).strip()
            if len(chunk) > 20:
                h = hashlib.md5(chunk.encode()).hexdigest()
                if h in seen: dupes += 1
                seen[h] = True
        return dupes

    def analyze_file(self, file_path):
        ext = os.path.splitext(file_path)[1].lower()
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            if not code.strip(): return None

            lines = code.splitlines()
            loc = len(lines)
            churn = self.get_git_metrics(file_path)
            
            complexity, mi, fan_in = 0, 100, 0
            sec_pat = r'(api[_-]?key|password|secret|token|pwd|auth)\s*[:=]\s*["\'][^"\']+["\']'
            secrets = [i+1 for i, l in enumerate(lines) if re.search(sec_pat, l, re.I)]

            if ext == '.py':
                try:
                    tree = ast.parse(code)
                    cc_blocks = cc_visit(code)
                    complexity = sum(c.complexity for c in cc_blocks) / len(cc_blocks) if cc_blocks else 0
                    mi = mi_visit(code, multi=True)
                    fan_in = len([n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))])
                except: pass 
            
            elif ext in ['.js', '.html', '.css']:
                complexity = (code.count('if ') + code.count('for ') + code.count('{') ) / 10

            risk_score = (complexity * 3) + (churn * 0.5) + (len(secrets) * 25)
            risk_factor = "CRITICAL" if risk_score > 50 else "HIGH" if risk_score > 30 else "LOW"

            return {
                "file": os.path.relpath(file_path, self.target_path),
                "type": ext.replace('.', '').upper(),
                "loc": loc,
                "size": f"{os.path.getsize(file_path)/1024:.1f} KB",
                "complexity": round(complexity, 2),
                "mi": round(mi, 2),
                "churn": churn,
                "fan_in": fan_in,
                "dupes": self.detect_duplication(lines),
                "comment_ratio": f"{(len([l for l in lines if l.strip().startswith(('#','//','/*'))]) / loc * 100):.1f}%" if loc > 0 else "0%",
                "secrets": secrets,
                "risk_score": round(risk_score, 2),
                "risk_factor": risk_factor
            }
        except: return None

    def run(self):
        valid = ['.py', '.js', '.html', '.css']
        for root, dirs, files in os.walk(self.target_path):
            dirs[:] = [d for d in dirs if d not in ['.git', 'venv', 'node_modules', '__pycache__']]
            for f in files:
                if any(f.endswith(ext) for ext in valid):
                    res = self.analyze_file(os.path.join(root, f))
                    if res: self.results.append(res)
        return self.results