def generate_report(data):
    if not data: 
        print("No valid files found (PY, JS, HTML, CSS).")
        return
    
    with open("codedetox_report.txt", "w") as f:
        f.write("="*80 + "\n")
        f.write("CodeDetox: FULL-STACK TECHNICAL DEBT AUDIT\n")
        f.write("="*80 + "\n\n")

        for item in data:
            f.write(f"[{item['type']}] {item['file']}\n")
            f.write(f"  > Metrics:   {item['loc']} LOC | {item['size']} | Churn: {item['churn']} revs\n")
            f.write(f"  > Quality:   Complexity: {item['complexity']} | MI: {item['mi']} | Fan-in: {item['fan_in']}\n")
            f.write(f"  > Health:    Comment Ratio: {item['comment_ratio']} | Duplicates: {item['dupes']}\n")
            f.write(f"  > RISK:      SCORE: {item['risk_score']} | FACTOR: {item['risk_factor']}\n")
            if item['secrets']:
                f.write(f"  !! ALERT !!  Hardcoded keys on lines: {item['secrets']}\n")
            f.write("-" * 80 + "\n")
            
    print(f"✅ CodeDetox complete. {len(data)} files analyzed.")
    print("📄 Report created: codedetox_report.txt")