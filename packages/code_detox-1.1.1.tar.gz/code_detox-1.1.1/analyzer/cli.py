import argparse
from .core import CodeDetoxEngine
from .report import generate_report

def main():
    parser = argparse.ArgumentParser(description="CodeDetox: Full-Stack Tech Debt Analyzer")
    parser.add_argument("path", nargs="?", default=".", help="Directory to audit")
    args = parser.parse_args()
    
    engine = ScalpelEngine(args.path)
    generate_report(engine.run())

if __name__ == "__main__":
    main()