# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListPortsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ports': 'list[Port]'
    }

    attribute_map = {
        'ports': 'ports'
    }

    def __init__(self, ports=None):
        r"""ListPortsResponse

        The model defined in huaweicloud sdk

        :param ports: port列表对象
        :type ports: list[:class:`huaweicloudsdkvpc.v2.Port`]
        """
        
        super().__init__()

        self._ports = None
        self.discriminator = None

        if ports is not None:
            self.ports = ports

    @property
    def ports(self):
        r"""Gets the ports of this ListPortsResponse.

        port列表对象

        :return: The ports of this ListPortsResponse.
        :rtype: list[:class:`huaweicloudsdkvpc.v2.Port`]
        """
        return self._ports

    @ports.setter
    def ports(self, ports):
        r"""Sets the ports of this ListPortsResponse.

        port列表对象

        :param ports: The ports of this ListPortsResponse.
        :type ports: list[:class:`huaweicloudsdkvpc.v2.Port`]
        """
        self._ports = ports

    def to_dict(self):
        import warnings
        warnings.warn("ListPortsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListPortsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
