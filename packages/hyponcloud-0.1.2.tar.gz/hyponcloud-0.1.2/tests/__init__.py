"""Tests for hyponcloud library."""
