"""CLI interface for TermiBase."""

