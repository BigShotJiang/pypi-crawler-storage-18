"""Interactive SQL learning module."""

