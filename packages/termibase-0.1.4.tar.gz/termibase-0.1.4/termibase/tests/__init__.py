"""Tests for TermiBase."""

