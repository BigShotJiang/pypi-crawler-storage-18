
{
    "version": "2025.12.25",
    "target": "default",
    "variant": "cpu"
}
