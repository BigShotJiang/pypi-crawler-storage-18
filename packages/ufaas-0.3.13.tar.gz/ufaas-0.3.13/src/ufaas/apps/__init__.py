"""UFaaS applications module."""
