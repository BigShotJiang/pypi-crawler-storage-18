"""FastAPI integration for UFaaS."""
