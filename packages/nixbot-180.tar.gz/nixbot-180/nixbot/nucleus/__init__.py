# This file is placed in the Public Domain.


"core"
