# lexigram-core
