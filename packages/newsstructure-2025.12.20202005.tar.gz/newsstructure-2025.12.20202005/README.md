# newsstructure

[![PyPI version](https://img.shields.io/pypi/v/newsstructure.svg)](https://pypi.org/project/newsstructure/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/newsstructure)](https://pepy.tech/project/newsstructure)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue)](https://www.linkedin.com/in/eugene-evstafev/)

A Python package that takes a news headline or short text snippet as input and returns a structured summary of the key event, actors, and context. It uses an LLM to generate the content and pattern matching to ensure the output follows a consistent format. Ideal for news aggregation, automated reporting, and content tagging.

## Installation

```bash
pip install newsstructure
```

## Usage

### Basic Example

```python
from newsstructure import newsstructure

user_input = "Apple announces new iPhone with advanced AI features"
result = newsstructure(user_input)
print(result)
```

### Using a Custom LLM

You can pass your own LangChain-compatible LLM instance. For example, to use OpenAI:

```python
from langchain_openai import ChatOpenAI
from newsstructure import newsstructure

llm = ChatOpenAI()
user_input = "Tesla stock surges after earnings report"
response = newsstructure(user_input, llm=llm)
```

To use Anthropic:

```python
from langchain_anthropic import ChatAnthropic
from newsstructure import newsstructure

llm = ChatAnthropic()
response = newsstructure(user_input, llm=llm)
```

To use Google Generative AI:

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from newsstructure import newsstructure

llm = ChatGoogleGenerativeAI()
response = newsstructure(user_input, llm=llm)
```

### Using a Custom API Key

By default, the package uses the free tier of LLM7 (via [langchain_llm7](https://pypi.org/project/langchain-llm7/)). You can provide your own API key either via environment variable or directly:

```python
import os
os.environ["LLM7_API_KEY"] = "your_api_key_here"

# or

response = newsstructure(user_input, api_key="your_api_key_here")
```

Get a free API key by registering at [https://token.llm7.io/](https://token.llm7.io/).

## Parameters

- `user_input` (str): The text input (e.g., news headline or snippet) to process.
- `llm` (Optional[BaseChatModel]): A LangChain LLM instance. If not provided, defaults to `ChatLLM7`.
- `api_key` (Optional[str]): API key for LLM7. If not provided, the package will try to read from the `LLM7_API_KEY` environment variable.

## License

This project is licensed under the MIT License.

## Issues

Report issues or feature requests on [GitHub](https://github.com/chigwell/newsstructure/issues).

## Author

Eugene Evstafev  
Email: hi@euegne.plus  
GitHub: [chigwell](https://github.com/chigwell)