import requests
from ._common.retry import retry_on_network_error


class Sender:
    def __init__(self, robot_endpoint: str, robot_ak: str, retry: int = 3):
        self.robot_endpoint = robot_endpoint
        self.robot_ak = robot_ak
        self.retry = retry

    @retry_on_network_error()
    def send_robot_with_at(self, group_id: list[int], message: str, at_user_ids: list[str] = None,
                             at_all: bool = False):
        """
        发送消息并@指定用户或@全体成员
        :param group_id: 群聊id列表
        :param message: 要发送的消息内容
        :param at_user_ids: 要at的用户id字符串列表
        :param at_all: 是否@全体成员,True时会忽略at_user_ids
        :return:
        """
        params = {
            "access_token": self.robot_ak
        }
        message = {
            "message": {
                "header": {"toid": group_id},
                "body": [
                    {"content": message, "type": "TEXT"},
                    {"atuserids": at_user_ids, "type": "AT", "atall": at_all}
                ]
            }
        }
        response = requests.post(self.robot_endpoint, params=params, json=message)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def call_ali(phone_number: str, message: str):
        from ._call.Ali import CallUtil
        return CallUtil.call(phone_number, message)
    @staticmethod
    def get_call_status_ali(call_id: str, timestamp: int):
        from ._call.Ali import CallUtil
        return CallUtil.get_call_status(call_id, timestamp)


