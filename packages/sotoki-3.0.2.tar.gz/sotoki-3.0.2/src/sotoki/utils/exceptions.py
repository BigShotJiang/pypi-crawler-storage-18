class DatabaseError(Exception):
    pass
