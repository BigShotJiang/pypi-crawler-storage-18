# lev-antipov-bivt-2216 - MNIST Digit Recognition Project

<a target="_blank" href="https://cookiecutter-data-science.drivendata.org/">
    <img src="https://img.shields.io/badge/CCDS-Project%20template-328F97?logo=cookiecutter" />
</a>

## Project Organization

```
├── LICENSE            <- Open-source license if one is chosen
├── Makefile           <- Makefile with convenience commands like `make data` or `make train`
├── README.md          <- The top-level README for developers using this project.
├── data
│   ├── external       <- Data from third party sources.
│   ├── interim        <- Intermediate data that has been transformed.
│   ├── processed      <- The final, canonical data sets for modeling.
│   └── raw            <- The original, immutable data dump.
│
├── docs               <- A default mkdocs project; see www.mkdocs.org for details
│
├── models             <- Trained and serialized models, model predictions, or model summaries
│
├── notebooks          <- Jupyter notebooks. Naming convention is a number (for ordering),
│                         the creator's initials, and a short `-` delimited description, e.g.
│                         `1.0-jqp-initial-data-exploration`.
│
├── pyproject.toml     <- Project configuration file with package metadata for 
│                         ds_core and configuration for tools like black
│
├── references         <- Data dictionaries, manuals, and all other explanatory materials.
│
├── reports            <- Generated analysis as HTML, PDF, LaTeX, etc.
│   └── figures        <- Generated graphics and figures to be used in reporting
│
├── requirements.txt   <- The requirements file for reproducing the analysis environment, e.g.
│                         generated with `pip freeze > requirements.txt`
│
├── setup.cfg          <- Configuration file for flake8
│
└── src   <- Source code for use in this project.
    │
    ├── __init__.py             <- Makes ds_core a Python module
    │
    ├── config.py               <- Store useful variables and configuration
    │
    ├── dataset.py              <- Scripts to download MNIST dataset
    │
    ├── features.py             <- Code to preprocess MNIST images
    │
    ├── modeling                
    │   ├── __init__.py 
    │   ├── predict.py          <- Code to run model inference with trained models          
    │   └── train.py            <- Code to train Logistic Regression model
    │
    └── plots.py                <- Code to create visualizations
```

--------

## Quick Start

### 1. Download MNIST Dataset
```bash
python -m ds_core.dataset
```

### 2. Preprocess Data
```bash
python -m ds_core.features
```

### 3. Train Model
```bash
python -m ds_core.modeling.train
```

### 4. Make Predictions
```bash
python -m ds_core.modeling.predict
```

### 5. Generate Visualizations
```bash
python -m ds_core.plots
```

## Running Tests

```bash
pytest tests/
```

## Project Features

- **Dataset Loading**: Automatic download and loading of MNIST dataset from Yann LeCun's website
- **Preprocessing**: Image normalization (0-1 range) and flattening (28x28 → 784)
- **Model**: Logistic Regression classifier with multinomial solver
- **Evaluation**: Accuracy metrics and confusion matrix
- **Visualization**: Sample images and confusion matrix plots

## Expected Results

The Logistic Regression model typically achieves ~92% accuracy on the MNIST test set.

