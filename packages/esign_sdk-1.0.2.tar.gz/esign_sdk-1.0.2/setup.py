"""
Setup configuration for esign-sdk package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="esign-sdk",
    version="1.0.2",
    author="Axonate Tech",
    author_email="support@axonate.com",
    description="Professional SDK for Indian eSign (eKYC-based digital signatures) integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/axonatetech/esign-sdk",
    project_urls={
        "Bug Tracker": "https://github.com/axonatetech/esign-sdk/issues",
        "Documentation": "https://github.com/axonatetech/esign-sdk/blob/main/README.md",
        "Source Code": "https://github.com/axonatetech/esign-sdk",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: Microsoft :: Windows",
        "Natural Language :: English",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Flask>=2.0.0",
        "pythonnet>=3.0.0",
        "managex-xml-sdk>=1.0.0",
        "requests>=2.25.0",
        "cryptography>=3.4.0",
        "lxml>=4.6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
        ],
    },
    package_data={
        "esign_sdk": [
            "lib/native/*.dll",
            "lib/native/.gitignore",
        ],
        "": [
            "certs/*.pem",
            "config/*.pfx",
            "config/*.ini",
            "config/root_certificates/*/*.pem",
        ],
    },
    include_package_data=True,
    keywords=[
        "esign",
        "digital-signature",
        "pdf-signing",
        "ekyc",
        "indian-esign",
        "document-signing",
        "cryptography",
        "pdf",
        "signature",
    ],
    license="MIT",
    zip_safe=False,  # Important for DLL files
)
