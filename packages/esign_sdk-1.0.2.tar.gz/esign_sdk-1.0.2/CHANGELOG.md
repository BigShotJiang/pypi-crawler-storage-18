# Changelog

All notable changes to the Python eSign SDK will be documented in this file.

## [1.0.0] - 2025-12-23

### Added
- Complete eSign 2.1 protocol implementation
- RESTful API server with HTTPS support
- JSON and XML request/response support
- Memory-based multi-page PDF signing (no temp files on disk)
- Automatic transaction ID-based field naming
- Auto-generated PDF metadata
- Self-signed SSL certificate management
- Windows certificate store auto-installation
- Portable SDK structure with relative paths
- Comprehensive API documentation
- Sample request/response examples
- Configuration file support (config.ini)
- Default PFX certificate management
- Native library abstraction (hidden DLLs)

### Features
- **PDF Operations**
  - Deferred signature placeholder creation
  - Multi-page signing with single certificate
  - Custom signature appearance
  - Green tick enable/disable
  - PDF certification and locking
  - Flexible page selection (individual pages, ranges, all pages)

- **eSign Integration**
  - XML request generation with digital signature
  - SHA-256 hash calculation
  - PKCS7 signature embedding
  - Webhook callback handling
  - Transaction ID management

- **API Server**
  - Health check endpoint
  - eSign processing endpoint
  - Signed PDF download endpoint
  - Redirect page generation
  - Request validation
  - Error handling

- **Security**
  - HTTPS-only endpoints
  - SSL certificate auto-setup
  - PFX certificate management
  - Secure password handling
  - Memory-based processing

### Technical Details
- Python 3.8+ support
- Windows .NET Framework 4.0+ required
- Flask web framework
- pythonnet for .NET interop
- managex-xml-sdk for XML signing
- Native PDF libraries (hidden in lib/native)

### Directory Structure
- Organized SDK with clear separation of concerns
- Hidden native libraries in lib/native
- SSL certificates in certs/
- Configuration in config/
- Examples and documentation
- Runtime data directory

### Documentation
- Complete README with quick start guide
- API reference documentation
- Sample JSON request files
- Configuration examples
- Troubleshooting guide

---

## Versioning

This project follows [Semantic Versioning](https://semver.org/).

Given a version number MAJOR.MINOR.PATCH:
- MAJOR version for incompatible API changes
- MINOR version for new functionality (backwards compatible)
- PATCH version for bug fixes (backwards compatible)

---

**Current Version**: 1.0.0
**Last Updated**: December 23, 2025
