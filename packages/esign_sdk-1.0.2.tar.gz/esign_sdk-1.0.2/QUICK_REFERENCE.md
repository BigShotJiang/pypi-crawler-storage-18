# Python eSign SDK - Quick Reference Card

## Start Server

```bash
cd python-esign-sdk
python api_server.py
```

Server runs at: `https://localhost:8080`

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Health check |
| `/api/v1/esign/process` | POST | Process eSign request |
| `/api/v1/esign/signed/<ref>` | GET | Download signed PDF |
| `/api/v1/esign/redirect/<ref>` | GET | Redirect to eSign portal |

## Minimal Request

```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "<base64_pdf>",
      "title": "Document",
      "txn": "UKC:public:TXN001",
      "callbackurl": "https://your-server/callback",
      "signatories": {
        "signatory": [{
          "name": "Signer Name",
          "option": {"pagenum": 1}
        }]
      }
    }
  }
}
```

## File Locations

| Item | Location | Purpose |
|------|----------|---------|
| DLLs | `lib/native/` | Native PDF libraries (hidden) |
| SSL Certs | `certs/` | HTTPS certificates |
| PFX Cert | `config/default.pfx` | Signing certificate |
| Config | `config/config.ini` | Server configuration |
| Samples | `examples/` | Sample files and requests |
| Docs | `docs/` | API documentation |

## Configuration

Edit `config/config.ini`:

```ini
[Server]
port = 8080

[Signing]
default_pfx = config/default.pfx
default_pfx_password = 123
```

## Testing

```bash
# Health check
curl -k https://localhost:8080/health

# Process request
curl -k -X POST https://localhost:8080/api/v1/esign/process \
  -H "Content-Type: application/json" \
  -d @examples/sample_request.json
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Port in use | Change port in config.ini |
| DLL not found | Check `lib/native/` folder |
| SSL error | Verify `certs/` folder |
| PFX error | Check `config/default.pfx` |

## Documentation

- **README.md** - Quick start
- **docs/API_REFERENCE.md** - Complete API docs
- **DEPLOYMENT.md** - Deployment guide
- **SDK_COMPLETE.md** - Full feature list

## Support Files

- `requirements.txt` - Python packages
- `examples/sample_request.json` - Sample request
- `CHANGELOG.md` - Version history

---

**Version**: 1.0.0 | **Updated**: Dec 2025
