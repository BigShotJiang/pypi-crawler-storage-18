# Python eSign SDK - Start Here! 🚀

Complete step-by-step guide to setup and run the eSign SDK.

## ⚡ Quick Start (3 Steps)

### Step 1: Install Python Dependencies

```bash
cd python-esign-sdk
pip install -r requirements.txt
```

Required packages will be installed:
- Flask (API server)
- pythonnet (.NET interop)
- managex-xml-sdk (XML signing)
- requests (HTTP client)
- cryptography (SSL)

### Step 2: Configure Environment Variables (Optional)

```bash
# Windows PowerShell
$env:ESIGN_PFX_PATH = "C:\path\to\your\certificate.pfx"
$env:ESIGN_PFX_PASSWORD = "your_password"
$env:ESIGN_HOST = "0.0.0.0"
$env:ESIGN_PORT = "8080"

# Windows CMD
set ESIGN_PFX_PATH=C:\path\to\your\certificate.pfx
set ESIGN_PFX_PASSWORD=your_password
set ESIGN_HOST=0.0.0.0
set ESIGN_PORT=8080

# Linux/Mac
export ESIGN_PFX_PATH=/path/to/your/certificate.pfx
export ESIGN_PFX_PASSWORD=your_password
export ESIGN_HOST=0.0.0.0
export ESIGN_PORT=8080
```

**Default Values (if not set):**
- PFX Path: `config/default.pfx` (included test certificate)
- PFX Password: `123`
- Host: `0.0.0.0`
- Port: `8080`

### Step 3: Start the Server

```bash
python api_server.py
```

**Expected Output:**
```
================================================================================
eSign API Server Starting...
================================================================================
Host: 0.0.0.0
Port: 8080
Data Directory: D:\path\to\python-esign-sdk\data
SSL Cert: D:\path\to\python-esign-sdk\certs\webhook_cert.pem
SSL Key: D:\path\to\python-esign-sdk\certs\webhook_key.pem
================================================================================
SSL certificates found - Starting HTTPS server
 * Running on https://127.0.0.1:8080
 * Running on https://192.168.1.10:8080
```

✅ **Server is ready!**

---

## 🧪 Testing the API

### Test 1: Health Check

```bash
curl -k https://localhost:8080/health
```

Expected response:
```json
{
  "service": "eSign API Server",
  "status": "OK",
  "version": "1.0.0",
  "timestamp": "2025-12-23T..."
}
```

### Test 2: Process eSign Request (JSON)

```bash
curl -k -X POST https://localhost:8080/api/v1/esign/process \
  -H "Content-Type: application/json" \
  -d @examples/sample_request.json
```

### Test 3: Process eSign Request (XML)

```bash
curl -k -X POST https://localhost:8080/api/v1/esign/process \
  -H "Content-Type: application/xml" \
  -d @examples/sample_request.xml
```

### Test 4: Using Python Test Script

```bash
python ../test_api.py
```

---

## 📁 SDK Structure

```
python-esign-sdk/
├── api_server.py              ← START THIS FILE
├── requirements.txt           ← Install these packages
├── README.md                  ← Full documentation
├── START_HERE.md              ← This file
│
├── esign_sdk/                 ← Core SDK modules
│   ├── models/                ← Request/Response models
│   ├── pdf_factory_itextsharp.py ← PDF signing
│   ├── esign_request_factory.py  ← XML generation
│   └── constants.py           ← Configuration
│
├── lib/native/                ← Native libraries (hidden)
│   ├── pdf_core.dll
│   ├── pdf_core_lic.dll
│   └── pdf_signer.dll
│
├── certs/                     ← SSL certificates
│   ├── webhook_cert.pem
│   └── webhook_key.pem
│
├── config/                    ← Configuration
│   ├── config.ini
│   ├── default.pfx           ← Test signing certificate
│   └── root_certificates/    ← Trusted root CAs
│
├── examples/                  ← Sample files
│   ├── sample_request.json
│   ├── sample_request.xml
│   └── sample_files/
│       └── sample_input.pdf
│
├── data/                      ← Runtime data (auto-created)
│   ├── uploads/
│   ├── temp/
│   ├── signed/
│   └── api_server.log
│
└── docs/                      ← Documentation
    └── API_REFERENCE.md
```

---

## 🔧 Configuration

### Option 1: Environment Variables (Recommended)

Set before starting server:

```bash
# Your certificate
set ESIGN_PFX_PATH=C:\MyCertificates\production.pfx
set ESIGN_PFX_PASSWORD=MySecurePassword123

# Server settings
set ESIGN_HOST=0.0.0.0
set ESIGN_PORT=8443
```

### Option 2: Edit config.ini

Edit `config/config.ini`:

```ini
[Server]
host = 0.0.0.0
port = 8080

[Signing]
default_pfx = config/default.pfx
default_pfx_password = 123
```

**Note:** Environment variables take priority over config.ini

---

## 📝 API Usage Examples

### Minimal JSON Request

```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "<base64_encoded_pdf>",
      "title": "Document",
      "txn": "UKC:public:TXN001",
      "callbackurl": "https://your-server/callback",
      "signatories": {
        "signatory": [{
          "name": "Signer Name",
          "option": {"pagenum": 1}
        }]
      }
    }
  }
}
```

### Complete JSON Request

See: `examples/sample_request.json`

### XML Request

See: `examples/sample_request.xml`

---

## 🔍 Troubleshooting

### Problem: "Native PDF library not available"

**Solution:**
```bash
# Check if DLL files exist
dir lib\native
# Should show: pdf_core.dll, pdf_core_lic.dll, pdf_signer.dll

# Reinstall pythonnet
pip install --upgrade pythonnet
```

### Problem: "Port 8080 already in use"

**Solution:**
```bash
# Option 1: Change port
set ESIGN_PORT=8090
python api_server.py

# Option 2: Kill existing process
netstat -ano | findstr :8080
taskkill /PID <process_id> /F
```

### Problem: "SSL certificate not found"

**Solution:**
```bash
# Check certificates exist
dir certs
# Should show: webhook_cert.pem, webhook_key.pem
```

### Problem: "PFX file not found"

**Solution:**
```bash
# Option 1: Use default (already included)
# No action needed - uses config/default.pfx

# Option 2: Set your certificate
set ESIGN_PFX_PATH=C:\path\to\your\cert.pfx
set ESIGN_PFX_PASSWORD=your_password
```

### Problem: "managex_xml_sdk not found"

**Solution:**
```bash
pip install managex-xml-sdk
```

---

## 🌐 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Check server status |
| `/api/v1/esign/process` | POST | Process eSign request |
| `/api/v1/esign/signed/<ref>` | GET | Download signed PDF |
| `/api/v1/esign/redirect/<ref>` | GET | Redirect to eSign portal |

---

## 📚 Documentation

- **START_HERE.md** (this file) - Quick start guide
- **README.md** - Complete SDK documentation
- **docs/API_REFERENCE.md** - Full API documentation
- **DEPLOYMENT.md** - Production deployment guide
- **QUICK_REFERENCE.md** - Quick reference card

---

## 🎯 Next Steps

After server is running:

1. **Test with sample request:**
   ```bash
   python ../test_api.py
   ```

2. **Read API documentation:**
   ```bash
   # Open in browser
   docs/API_REFERENCE.md
   ```

3. **Customize configuration:**
   - Add your PFX certificate to `config/`
   - Update environment variables
   - Modify `config/config.ini`

4. **Deploy to production:**
   - Read `DEPLOYMENT.md`
   - Set up Windows Service
   - Configure firewall
   - Use production certificates

---

## ❓ Need Help?

- Check `README.md` for detailed information
- See `docs/API_REFERENCE.md` for API details
- Read `DEPLOYMENT.md` for production setup
- Review log file: `data/api_server.log`

---

## 🎉 Success Checklist

After completing setup:

- [x] Python dependencies installed (`pip install -r requirements.txt`)
- [x] Environment variables set (optional)
- [x] Server started (`python api_server.py`)
- [x] Health check passed (`curl -k https://localhost:8080/health`)
- [x] Test request successful

**You're ready to use the eSign SDK!**

---

**Version:** 1.0.0
**Last Updated:** December 2025
**Protocol:** eSign 2.1
