# Python eSign SDK

Professional SDK for Indian eSign (eKYC-based digital signatures) integration with RESTful API server.

## Features

- **Complete eSign 2.1 Protocol** - Full implementation of Indian eSign specifications
- **Deferred PDF Signing** - Two-step signing process for eSign integration
- **Multi-Page Signing** - Sign multiple pages in a single transaction
- **Memory-Based Processing** - No temporary files visible to users
- **RESTful API Server** - Production-ready HTTPS API with JSON/XML support
- **Portable** - Self-contained SDK with all dependencies included
- **Secure** - Built-in SSL certificate management and PFX handling

## Quick Start

### Installation

```bash
# Install required Python packages
pip install -r requirements.txt
```

### Start API Server

```bash
# Navigate to SDK directory
cd python-esign-sdk

# Start the server
python api_server.py
```

Server will be available at:
- `https://localhost:8080`
- `https://192.168.1.10:8080`

### Test the API

```bash
# Health check
curl -k https://localhost:8080/health

# Process eSign request
curl -k -X POST https://localhost:8080/api/v1/esign/process \
  -H "Content-Type: application/json" \
  -d @examples/sample_request.json
```

## Directory Structure

```
python-esign-sdk/
├── esign_sdk/              # Core SDK modules
│   ├── models/             # Data models (Request/Response)
│   ├── pdf_factory_*.py    # PDF signing implementations
│   ├── esign_request_*.py  # XML request generators
│   └── constants.py        # Configuration constants
├── lib/                    # Internal libraries (hidden from users)
│   └── native/             # Native PDF signing libraries
├── certs/                  # SSL certificates
│   ├── webhook_cert.pem
│   └── webhook_key.pem
├── config/                 # Configuration files
│   ├── config.ini          # Server configuration
│   └── default.pfx         # Default signing certificate
├── data/                   # Runtime data (auto-created)
│   ├── uploads/            # Uploaded PDFs
│   ├── temp/               # Temporary processing files
│   └── signed/             # Signed PDFs
├── examples/               # Usage examples
│   ├── sample_files/       # Sample PDFs
│   └── *.py                # Example scripts
├── docs/                   # Documentation
├── api_server.py           # RESTful API server
├── requirements.txt        # Python dependencies
└── README.md               # This file
```

## API Documentation

### POST /api/v1/esign/process

Process eSign request with PDF document.

**Request Body (JSON)**:
```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "<base64_encoded_pdf>",
      "title": "Document_Title",
      "txn": "UKC:public:UNIQUE_TXN_ID",
      "callbackurl": "https://your-server/callback",
      "signatories": {
        "signatory": [{
          "name": "Signer Name",
          "email": "signer@example.com",
          "mobile": "9876543210",
          "option": {
            "cood": "100,250,200,500",
            "pagenum": 1,
            "reason": "Document Approval",
            "location": "New Delhi",
            "customtext": "Digitally Signed",
            "disablegreentick": "no",
            "lockpdf": "no"
          },
          "dsc": {
            "authmethod": "pfx",
            "pfxpath": "config/default.pfx",
            "pfxpassword": "123",
            "responsesigtype": "pkcs7"
          }
        }]
      }
    }
  }
}
```

**Response (JSON)**:
```json
{
  "success": true,
  "txn": "UKC:public:GENERATED_TXN",
  "reference": "UNIQUE_REFERENCE_ID",
  "redirectUrl": "https://server/api/v1/esign/redirect/REFERENCE",
  "signedPdfUrl": "https://server/api/v1/esign/signed/REFERENCE",
  "message": "Document prepared for signing",
  "timestamp": "2025-12-23T16:44:18.495983"
}
```

### GET /health

Health check endpoint.

**Response**:
```json
{
  "service": "eSign API Server",
  "status": "OK",
  "version": "1.0.0",
  "timestamp": "2025-12-23T16:40:03.834351"
}
```

### GET /api/v1/esign/signed/<reference>

Download signed PDF.

**Response**: PDF file (application/pdf)

## Requirements

### Python Packages
- Flask >= 2.0.0
- pythonnet >= 3.0.0
- managex-xml-sdk >= 1.0.0
- requests >= 2.25.0
- cryptography >= 3.4.0

### System Requirements
- Windows (for .NET native libraries)
- Python 3.8 or higher
- .NET Framework 4.0 or higher

## Version

**Version**: 1.0.0
**Last Updated**: December 2025
**eSign Protocol**: 2.1
