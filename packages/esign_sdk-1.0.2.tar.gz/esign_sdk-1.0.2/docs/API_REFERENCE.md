# eSign SDK API Reference

Complete API documentation for the Python eSign SDK.

## Table of Contents

1. [RESTful API Endpoints](#restful-api-endpoints)
2. [Python SDK API](#python-sdk-api)
3. [Request/Response Models](#requestresponse-models)
4. [Error Codes](#error-codes)
5. [Examples](#examples)

## RESTful API Endpoints

### Base URL

```
https://localhost:8080/api/v1/esign
```

### Authentication

Currently no authentication required. Add API key/token authentication as needed.

### Endpoints

#### 1. Health Check

**Endpoint**: `GET /health`

**Description**: Check if API server is running

**Response**:
```json
{
  "service": "eSign API Server",
  "status": "OK",
  "version": "1.0.0",
  "timestamp": "2025-12-23T16:40:03.834351"
}
```

---

#### 2. Process eSign Request

**Endpoint**: `POST /api/v1/esign/process`

**Description**: Process PDF document for eSign

**Content-Type**: `application/json` or `application/xml`

**Request Body**:
```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "base64_encoded_pdf_content",
      "pdfurl": "https://example.com/document.pdf",
      "title": "Document_Title",
      "txn": "UKC:public:UNIQUE_TRANSACTION_ID",
      "callbackurl": "https://your-server.com/callback",
      "signatories": {
        "signatory": [
          {
            "name": "Signer Name (Required)",
            "email": "signer@example.com",
            "mobile": "9876543210",
            "option": {
              "cood": "100,250,200,500",
              "pagenum": 1,
              "reason": "Document Approval",
              "location": "New Delhi",
              "customtext": "Digitally Signed by XYZ",
              "disablegreentick": "no",
              "lockpdf": "no"
            },
            "dsc": {
              "authmethod": "pfx",
              "pfxpath": "config/default.pfx",
              "pfxpassword": "certificate_password",
              "responsesigtype": "pkcs7"
            }
          }
        ]
      }
    }
  }
}
```

**Field Descriptions**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `pdf64` | string | Yes* | Base64 encoded PDF content |
| `pdfurl` | string | Yes* | URL to download PDF (alternative to pdf64) |
| `title` | string | Yes | Document title (used in XML and PDF metadata) |
| `txn` | string | Yes | Unique transaction ID (format: UKC:public:XXXXX) |
| `callbackurl` | string | Yes | Webhook URL for eSign response |
| `name` | string | Yes | Signer name (mandatory) |
| `email` | string | No | Signer email |
| `mobile` | string | No | Signer mobile number |
| `cood` | string | No | Signature coordinates (x1,y1,x2,y2) |
| `pagenum` | number | No | Page number to sign (default: 1) |
| `reason` | string | No | Reason for signing |
| `location` | string | No | Location of signing |
| `customtext` | string | No | Custom text to display in signature |
| `disablegreentick` | string | No | "yes" or "no" (default: "no") |
| `lockpdf` | string | No | Lock PDF after signing: "yes" or "no" |
| `pfxpath` | string | No | Path to PFX certificate (defaults to config/default.pfx) |
| `pfxpassword` | string | No | PFX certificate password |

*Note: Either `pdf64` OR `pdfurl` must be provided, not both.

**Success Response (200 OK)**:
```json
{
  "success": true,
  "txn": "UKC:public:GENERATED_INTERNAL_TXN",
  "reference": "A74540261D86887EB885779726D2CB9A",
  "redirectUrl": "https://server/api/v1/esign/redirect/A74540261D86887EB885779726D2CB9A",
  "signedPdfUrl": "https://server/api/v1/esign/signed/A74540261D86887EB885779726D2CB9A",
  "message": "Document prepared for signing. Use redirectUrl to complete eSign authentication.",
  "timestamp": "2025-12-23T16:44:18.495983"
}
```

**Error Response (400/500)**:
```json
{
  "success": false,
  "error_code": "VALIDATION_ERROR",
  "error_message": "Signer name is required",
  "message": "Request validation failed",
  "timestamp": "2025-12-23T16:44:18.495983"
}
```

---

#### 3. Get Redirect Page

**Endpoint**: `GET /api/v1/esign/redirect/<reference>`

**Description**: Get HTML redirect page to eSign portal

**Response**: HTML page that auto-submits to eSign server

---

#### 4. Download Signed PDF

**Endpoint**: `GET /api/v1/esign/signed/<reference>`

**Description**: Download signed PDF after eSign completion

**Response**: PDF file (Content-Type: application/pdf)

---

#### 5. Callback Webhook

**Endpoint**: `POST <your_callback_url>` (configured in request)

**Description**: Receives eSign response with PKCS7 signature

**Request Body (from eSign server)**:
```xml
<Esign>
  <DocSignature>
    <SignedDoc>
      <DocSignStatus>1</DocSignStatus>
      <DocSignature>
        BASE64_PKCS7_SIGNATURE_HERE
      </DocSignature>
    </SignedDoc>
  </DocSignature>
</Esign>
```

---

## Python SDK API

### PDF Factory

```python
from esign_sdk import SDK

# Get PDF factory instance
pdf_factory = SDK.get_pdf_factory_instance(use_itextsharp=True)
```

#### create_empty_signature()

Create PDF with signature placeholder.

```python
hash_value = pdf_factory.empty_signature(
    src: str,                      # Source PDF path
    dest: str,                     # Destination PDF path
    field_name: str,               # Signature field name
    page_nums: list = None,        # List of page numbers [1, 2, 3]
    page_num: int = 1,             # Single page number (if page_nums not used)
    signer_name: str = "",         # Signer name
    reason: str = "",              # Reason for signing
    location: str = "",            # Location
    custom_text: str = "",         # Custom text
    disable_green_tick: bool = False,  # Disable verification tick
    lock_pdf: bool = False,        # Certify and lock PDF
    rect: tuple = (10,10,200,100), # (x, y, width, height)
    estimated_size: int = 15000    # PKCS7 signature size estimate
) -> str  # Returns SHA-256 hash (hex)
```

#### embed_signature()

Embed PKCS7 signature into placeholder.

```python
pdf_factory.embed_signature(
    src: str,                      # PDF with placeholder
    dest: str,                     # Destination signed PDF
    field_name: str,               # Signature field name
    pkcs7_signature: str           # Base64 PKCS7 from eSign
) -> None
```

### XML Request Factory

```python
xml_factory = SDK.get_esign_request_factory_instance()
```

#### Configuration

```python
# Set transaction ID
xml_factory.set_txn("UKC:public:TXN123")

# Set ASP ID
xml_factory.set_asp_id("your_asp_id")

# Set auth mode
xml_factory.set_auth_mode(1)  # 1 = Yes, 0 = No

# Set response signature type
from esign_sdk.constants import ResponseSigType
xml_factory.set_response_sig_type(ResponseSigType.PKCS7_PDF)

# Set callback URL
xml_factory.set_response_url("https://your-server/callback")
```

#### Add Documents

```python
xml_factory.add_document(
    doc_id: str,           # Document ID (1, 2, 3, ...)
    doc_info: str,         # Document description/title
    hash_value: str        # SHA-256 hash from empty_signature()
)
```

#### Generate XML

```python
unsigned_xml = xml_factory.to_xml()  # Returns XML string
```

### Constants

```python
from esign_sdk.constants import AuthMethods, ResponseSigType

# Auth Methods
AuthMethods.PFX           # Certificate-based
AuthMethods.USBTOKEN      # USB token
AuthMethods.AADHAAR       # Aadhaar OTP

# Response Signature Types
ResponseSigType.PKCS7     # PKCS7 detached
ResponseSigType.PKCS7_PDF # PKCS7 for PDF (recommended)
```

## Request/Response Models

### ESignApiRequest

Python dataclass for request parsing.

```python
from esign_sdk.models.api_request import ESignApiRequest

# Parse from dict
request = ESignApiRequest.from_dict(json_data)

# Validate
is_valid, error_msg = request.validate()

# Access fields
upload = request.parameter.uploadpdf
txn = upload.txn
title = upload.title
signatory = upload.signatories.signatory[0]
```

### ESignApiResponse

Python dataclass for response generation.

```python
from esign_sdk.models.api_response import ESignApiResponse

# Create success response
response = ESignApiResponse.create_success(
    txn="UKC:public:TXN123",
    reference="ABC123",
    redirect_url="https://...",
    signed_pdf_url="https://...",
    message="Success"
)

# Create error response
response = ESignApiResponse.create_error(
    error_code="VALIDATION_ERROR",
    error_message="Invalid request"
)

# Convert to JSON
json_response = response.to_dict()

# Convert to XML
xml_response = response.to_xml()
```

## Error Codes

| Code | Description |
|------|-------------|
| `VALIDATION_ERROR` | Request validation failed |
| `PDF_ERROR` | PDF processing error |
| `XML_ERROR` | XML generation error |
| `SIGNING_ERROR` | Certificate signing error |
| `PROCESSING_ERROR` | General processing error |
| `NOT_FOUND` | Resource not found |
| `SERVER_ERROR` | Internal server error |

## Examples

### Example 1: Basic Request

```bash
curl -k -X POST https://localhost:8080/api/v1/esign/process \
  -H "Content-Type: application/json" \
  -d '{
    "parameter": {
      "uploadpdf": {
        "pdf64": "JVBERi0xLjQKJeLj...",
        "title": "Test_Doc",
        "txn": "UKC:public:TEST001",
        "callbackurl": "https://example.com/callback",
        "signatories": {
          "signatory": [{
            "name": "John Doe",
            "option": {
              "pagenum": 1
            }
          }]
        }
      }
    }
  }'
```

### Example 2: Multi-Page Signing

```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "...",
      "title": "Multi_Page_Doc",
      "txn": "UKC:public:MULTI001",
      "callbackurl": "https://example.com/callback",
      "signatories": {
        "signatory": [{
          "name": "John Doe",
          "option": {
            "pagenum": 1,
            "cood": "100,250,200,350"
          }
        }]
      }
    }
  }
}
```

### Example 3: Custom Signature Appearance

```json
{
  "parameter": {
    "uploadpdf": {
      "pdf64": "...",
      "title": "Custom_Appearance",
      "txn": "UKC:public:CUSTOM001",
      "callbackurl": "https://example.com/callback",
      "signatories": {
        "signatory": [{
          "name": "Jane Smith",
          "email": "jane@example.com",
          "mobile": "9876543210",
          "option": {
            "pagenum": 1,
            "cood": "50,700,250,800",
            "reason": "Approved by Manager",
            "location": "Mumbai",
            "customtext": "Verified and Approved",
            "disablegreentick": "no",
            "lockpdf": "yes"
          }
        }]
      }
    }
  }
}
```

### Example 4: Using PDF URL

```json
{
  "parameter": {
    "uploadpdf": {
      "pdfurl": "https://example.com/documents/contract.pdf",
      "title": "Contract_2025",
      "txn": "UKC:public:CONTRACT001",
      "callbackurl": "https://example.com/callback",
      "signatories": {
        "signatory": [{
          "name": "Legal Department"
        }]
      }
    }
  }
}
```

---

**Last Updated**: December 2025
**SDK Version**: 1.0.0
