"""
eSign SDK - Python
A Python library for Indian eSign 2.1 guideline compliance.

This SDK implements the eSign 2.1 API specification as per:
Controller of Certifying Authorities (CCA), Government of India
https://cca.gov.in/sites/files/pdf/ACT/eSign-APIv2.1.pdf
"""

from esign_sdk.sdk import SDK
from esign_sdk.pdf_factory_native import PdfFactoryNative
from esign_sdk.xml_request_factory import XMLRequestFactory
from esign_sdk.constants import AuthMethods, ResponseSigType, HashAlgorithm

__version__ = "1.0.2"
__author__ = "Axonate Tech"
__email__ = "support@axonate.com"

__all__ = [
    "SDK",
    "PdfFactoryNative",
    "XMLRequestFactory",
    "AuthMethods",
    "ResponseSigType",
    "HashAlgorithm",
]
