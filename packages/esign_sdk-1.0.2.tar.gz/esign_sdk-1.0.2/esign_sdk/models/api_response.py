"""
API Response Models for eSign SDK
Handles JSON/XML response format to users
"""

from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime


@dataclass
class ESignApiResponse:
    """
    Complete eSign API response structure.
    Returns both JSON and XML formats.
    """
    success: bool = True
    txn: str = ""                    # Internal transaction ID (UKC:public:XXX)
    reference: str = ""              # Document reference ID
    redirectUrl: str = ""            # URL to redirect user for eSign authentication
    signedPdfUrl: str = ""          # URL to download signed PDF (after completion)
    message: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    # Error info (if failed)
    error_code: Optional[str] = None
    error_message: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON response"""
        response = {
            'success': self.success,
            'txn': self.txn,
            'reference': self.reference,
            'redirectUrl': self.redirectUrl,
            'signedPdfUrl': self.signedPdfUrl,
            'message': self.message,
            'timestamp': self.timestamp
        }

        if not self.success and self.error_code:
            response['error'] = {
                'code': self.error_code,
                'message': self.error_message or ''
            }

        return response

    def to_xml(self) -> str:
        """Convert to XML response"""
        status = "success" if self.success else "error"

        if self.success:
            return f"""<?xml version="1.0" encoding="UTF-8"?>
<response>
    <status>{status}</status>
    <txn>{self.txn}</txn>
    <reference>{self.reference}</reference>
    <redirectUrl><![CDATA[{self.redirectUrl}]]></redirectUrl>
    <signedPdfUrl><![CDATA[{self.signedPdfUrl}]]></signedPdfUrl>
    <message>{self.message}</message>
    <timestamp>{self.timestamp}</timestamp>
</response>"""
        else:
            return f"""<?xml version="1.0" encoding="UTF-8"?>
<response>
    <status>{status}</status>
    <error>
        <code>{self.error_code or ''}</code>
        <message>{self.error_message or ''}</message>
    </error>
    <timestamp>{self.timestamp}</timestamp>
</response>"""

    @classmethod
    def create_success(cls, txn: str, reference: str, redirect_url: str, signed_pdf_url: str, message: str = "Request processed successfully"):
        """Create success response"""
        return cls(
            success=True,
            txn=txn,
            reference=reference,
            redirectUrl=redirect_url,
            signedPdfUrl=signed_pdf_url,
            message=message
        )

    @classmethod
    def create_error(cls, error_code: str, error_message: str):
        """Create error response"""
        return cls(
            success=False,
            error_code=error_code,
            error_message=error_message,
            message="Request failed"
        )
