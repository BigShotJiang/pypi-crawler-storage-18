"""Models package for eSign SDK"""

# Existing models
try:
    from .api_request import (
        ESignApiRequest, Parameter, UploadPdfInfo,
        Signatories, Signatory, SigningOption, DscInfo
    )
    from .api_response import ESignApiResponse

    __all__ = [
        'ESignApiRequest', 'Parameter', 'UploadPdfInfo',
        'Signatories', 'Signatory', 'SigningOption', 'DscInfo',
        'ESignApiResponse'
    ]
except ImportError:
    # Models not yet created
    __all__ = []
