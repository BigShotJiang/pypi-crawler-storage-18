"""
API Request Models for eSign SDK
Handles JSON/XML request format from users
"""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class DscInfo:
    """DSC (Digital Signature Certificate) information"""
    email: str = ""
    serial: str = ""
    organization: str = ""
    orgunit: str = ""


@dataclass
class SigningOption:
    """Signing options for visual appearance"""
    cood: str = "100,250,200,500"  # Coordinates: x1,y1,x2,y2
    pagenum: int = 1               # Page number to sign
    reason: str = "Document Signing"
    location: str = "India"
    customtext: str = ""
    disablegreentick: str = "no"   # "yes" or "no"
    lockpdf: str = "no"            # "yes" or "no"


@dataclass
class Signatory:
    """Individual signatory information"""
    id: str = "signatory1"
    sn: str = "1"                  # Serial number
    name: str = ""                 # Signer name (MANDATORY)
    email: str = ""
    mail: str = "y"                # Send email: "y" or "n"
    mobile: str = ""
    sms: str = "y"                 # Send SMS: "y" or "n"
    mode: str = ""                 # Authentication mode
    ekycid: str = ""               # eKYC ID
    dsc: DscInfo = field(default_factory=DscInfo)
    option: SigningOption = field(default_factory=SigningOption)


@dataclass
class Signatories:
    """Container for signatories"""
    signatory: List[Signatory] = field(default_factory=list)


@dataclass
class UploadPdfInfo:
    """PDF upload information and signing configuration"""
    pdf64: str = ""                         # Base64 encoded PDF (if provided)
    pdfurl: str = ""                        # URL to PDF (if provided)
    title: str = "Document"                 # Document title (used for filename)
    txn: str = ""                           # Transaction ID (goes in signature field & XML)
    callbackurl: str = ""                   # Webhook URL for response
    signatories: Signatories = field(default_factory=Signatories)

    def get_pdf_source(self) -> tuple[str, str]:
        """
        Get PDF source type and value.
        Returns: (source_type, source_value)
        - ("base64", pdf_data) if pdf64 provided
        - ("url", url) if pdfurl provided
        - ("none", "") if neither provided
        """
        if self.pdf64:
            return ("base64", self.pdf64)
        elif self.pdfurl:
            return ("url", self.pdfurl)
        else:
            return ("none", "")


@dataclass
class Parameter:
    """Request parameter container"""
    uploadpdf: UploadPdfInfo = field(default_factory=UploadPdfInfo)


@dataclass
class ESignApiRequest:
    """
    Complete eSign API request structure.
    Accepts both JSON and XML formats.
    """
    parameter: Parameter = field(default_factory=Parameter)

    @classmethod
    def from_dict(cls, data: dict):
        """
        Create from dictionary (parsed JSON).

        Args:
            data: Dictionary containing request data

        Returns:
            ESignApiRequest instance
        """
        param_data = data.get('parameter', {})
        upload_data = param_data.get('uploadpdf', {})

        # Parse signatories
        signatories_data = upload_data.get('signatories', {})
        signatory_list_data = signatories_data.get('signatory', [])

        signatories = []
        for sig_data in signatory_list_data:
            # Parse DSC info
            dsc_data = sig_data.get('dsc', {})
            dsc = DscInfo(
                email=dsc_data.get('email', ''),
                serial=dsc_data.get('serial', ''),
                organization=dsc_data.get('organization', ''),
                orgunit=dsc_data.get('orgunit', '')
            )

            # Parse signing options
            option_data = sig_data.get('option', {})
            option = SigningOption(
                cood=option_data.get('cood', '100,250,200,500'),
                pagenum=int(option_data.get('pagenum', 1)),
                reason=option_data.get('reason', 'Document Signing'),
                location=option_data.get('location', 'India'),
                customtext=option_data.get('customtext', ''),
                disablegreentick=option_data.get('disablegreentick', 'no'),
                lockpdf=option_data.get('lockpdf', 'no')
            )

            # Create signatory
            signatory = Signatory(
                id=sig_data.get('id', 'signatory1'),
                sn=sig_data.get('sn', '1'),
                name=sig_data.get('name', ''),
                email=sig_data.get('email', ''),
                mail=sig_data.get('mail', 'y'),
                mobile=sig_data.get('mobile', ''),
                sms=sig_data.get('sms', 'y'),
                mode=sig_data.get('mode', ''),
                ekycid=sig_data.get('ekycid', ''),
                dsc=dsc,
                option=option
            )
            signatories.append(signatory)

        # Create upload info
        upload_pdf = UploadPdfInfo(
            pdf64=upload_data.get('pdf64', ''),
            pdfurl=upload_data.get('pdfurl', ''),
            title=upload_data.get('title', 'Document'),
            txn=upload_data.get('txn', ''),
            callbackurl=upload_data.get('callbackurl', ''),
            signatories=Signatories(signatory=signatories)
        )

        # Create parameter
        parameter = Parameter(uploadpdf=upload_pdf)

        return cls(parameter=parameter)

    def to_dict(self) -> dict:
        """
        Convert to dictionary for JSON serialization.

        Returns:
            Dictionary representation
        """
        return {
            'parameter': {
                'uploadpdf': {
                    'pdf64': self.parameter.uploadpdf.pdf64,
                    'pdfurl': self.parameter.uploadpdf.pdfurl,
                    'title': self.parameter.uploadpdf.title,
                    'txn': self.parameter.uploadpdf.txn,
                    'callbackurl': self.parameter.uploadpdf.callbackurl,
                    'signatories': {
                        'signatory': [
                            {
                                'id': sig.id,
                                'sn': sig.sn,
                                'name': sig.name,
                                'email': sig.email,
                                'mail': sig.mail,
                                'mobile': sig.mobile,
                                'sms': sig.sms,
                                'mode': sig.mode,
                                'ekycid': sig.ekycid,
                                'dsc': {
                                    'email': sig.dsc.email,
                                    'serial': sig.dsc.serial,
                                    'organization': sig.dsc.organization,
                                    'orgunit': sig.dsc.orgunit
                                },
                                'option': {
                                    'cood': sig.option.cood,
                                    'pagenum': sig.option.pagenum,
                                    'reason': sig.option.reason,
                                    'location': sig.option.location,
                                    'customtext': sig.option.customtext,
                                    'disablegreentick': sig.option.disablegreentick,
                                    'lockpdf': sig.option.lockpdf
                                }
                            }
                            for sig in self.parameter.uploadpdf.signatories.signatory
                        ]
                    }
                }
            }
        }

    def validate(self) -> tuple[bool, str]:
        """
        Validate request data.

        Returns:
            (is_valid, error_message)
        """
        upload = self.parameter.uploadpdf

        # Check PDF source
        source_type, _ = upload.get_pdf_source()
        if source_type == "none":
            return (False, "Either pdf64 or pdfurl must be provided")

        # Check transaction ID
        if not upload.txn:
            return (False, "Transaction ID (txn) is required")

        # Check signatories
        if not upload.signatories.signatory:
            return (False, "At least one signatory is required")

        # Validate each signatory
        for sig in upload.signatories.signatory:
            if not sig.name:
                return (False, f"Signer name is required for signatory {sig.id}")

        return (True, "")
