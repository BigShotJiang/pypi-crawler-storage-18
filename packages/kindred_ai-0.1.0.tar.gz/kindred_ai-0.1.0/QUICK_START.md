# Quick Start Guide

## What Users Need to Do (3 Simple Steps)

### Step 1: Install the SDK

```bash
pip install -e ".[all]"
```

### Step 2: Set Environment Variables

```bash
# Set your Kindred URL (used for fetching restricted URLs and as the sidecar endpoint)
export KINDRED_URL="http://your-server.com:8080"

# Set your agent token (also serves as agent ID, provided by Kindred)
export KINDRED_AGENT_TOKEN="your-token-here"
```

### Step 3: Add 2 Lines to Your Code

Add these lines at the **very beginning** of your Python script (before any HTTP requests):

```python
from kindred_ai import Interceptor
Interceptor.init(verbose=True)
```

## Complete Example

**Before (Your Original Code):**
```python
import requests

# Your existing code
response = requests.get("https://api.stripe.com/v1/charges")
print(response.json())
```

**After (With SDK - Only 2 Lines Added):**
```python
from kindred_ai import Interceptor
Interceptor.init(verbose=True)  # <-- ADD THIS

import requests

# Your existing code - NO CHANGES NEEDED!
response = requests.get("https://api.stripe.com/v1/charges")
# Automatically rerouted if URL is in restricted list
print(response.json())
```

## What Gets Rerouted?

Once initialized, HTTP requests matching your restricted URLs are automatically intercepted:
- ✅ `requests.get()`, `requests.post()`, etc.
- ✅ `httpx.get()`, `httpx.post()`, etc. (sync and async)
- ✅ OpenAI SDK, Anthropic SDK, and any library using `requests`/`httpx`

**Note:** Only URLs in your restricted list (fetched from the server) will be intercepted. If there are no restricted URLs, nothing will be intercepted.

## Example: OpenAI SDK

```python
from kindred_ai import Interceptor
Interceptor.init(verbose=True)  # <-- Just add this

from openai import OpenAI

# Your existing OpenAI code - NO CHANGES!
client = OpenAI(api_key="sk-...")
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
# Automatically rerouted to your server!
```

## That's It!

No other code changes needed. The SDK intercepts requests transparently and routes them to your server while preserving:
- ✅ All headers (including Authorization)
- ✅ Request bodies
- ✅ Query parameters
- ✅ Paths (appended to your endpoint)

## URL Transformation

**Original:** `https://api.stripe.com/v1/charges?limit=10`  
**Your Kindred URL:** `http://your-server.com:8080`  
**Result:** `http://your-server.com:8080/v1/charges?limit=10`

The SDK fetches your restricted URLs from `KINDRED_URL/restricted-urls?agent_id=<KINDRED_AGENT_TOKEN>` and only intercepts requests matching those URLs.

