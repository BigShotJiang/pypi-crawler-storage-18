"""
Kindred AI SDK - Patchers for HTTP libraries.
"""

from .requests_patch import RequestsPatcher
from .httpx_patch import HTTPXPatcher

__all__ = ["RequestsPatcher", "HTTPXPatcher"]

