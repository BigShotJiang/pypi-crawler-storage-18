"""
Patcher for the requests library.
"""

import json
import logging
import base64
from typing import Any, Dict, Optional
import wrapt

from ..rules import _rewrite_url

logger = logging.getLogger(__name__)


class RequestsPatcher:
    """Patcher for requests.Session.request method."""
    
    _original_request = None
    _is_patched = False
    _rules: Dict[str, str] = {}
    _verbose: bool = False
    _agent_token: Optional[str] = None
    
    @classmethod
    def patch(cls, rules: Dict[str, str], agent_token: Optional[str] = None, verbose: bool = False) -> None:
        """
        Apply the patch to requests library.
        
        Args:
            rules: Dictionary mapping hostnames to destinations
            verbose: Whether to log intercepted requests
        """
        if cls._is_patched:
            logger.warning("Requests patcher is already active")
            return
        
        try:
            import requests.sessions
            cls._original_request = requests.sessions.Session.request
            cls._rules = rules
            cls._verbose = verbose
            cls._agent_token = agent_token
            
            def wrapper(wrapped, instance, args, kwargs):
                return cls._intercept_request(wrapped, instance, args, kwargs)
            
            wrapt.wrap_function_wrapper('requests.sessions', 'Session.request', wrapper)
            
            cls._is_patched = True
            
            if verbose:
                logger.info("Requests library patched successfully")
                
        except ImportError:
            logger.warning("requests library not available, skipping patch")
        except Exception as e:
            logger.error(f"Failed to patch requests library: {e}")
            raise
    
    @classmethod
    def unpatch(cls) -> None:
        """Remove the patch from requests library."""
        if not cls._is_patched:
            return
        
        try:
            import requests.sessions
            if cls._original_request:
                requests.sessions.Session.request = cls._original_request
                cls._is_patched = False
                cls._original_request = None
                cls._rules = {}
                cls._agent_token = None
                
                if cls._verbose:
                    logger.info("Requests library unpatched")
        except Exception as e:
            logger.error(f"Failed to unpatch requests library: {e}")
    
    @classmethod
    def _intercept_request(
        cls,
        wrapped,
        instance,
        args,
        kwargs
    ) -> Any:
        """
        Intercept and rewrite the request URL.
        
        Args:
            wrapped: The original request method
            instance: The Session instance
            args: Positional arguments
            kwargs: Keyword arguments
            
        Returns:
            Response from the original request method
        """
        # Extract URL from args or kwargs
        # requests.Session.request(method, url, ...) - method is args[0], url is args[1] or kwargs['url']
        url = None
        if 'url' in kwargs:
            url = kwargs['url']
        elif len(args) > 1:
            url = args[1]  # args[0] is method, args[1] is URL
        
        if url:
            original_url = str(url)
            rewritten_url = _rewrite_url(original_url, cls._rules)
            
            if rewritten_url != original_url:
                if cls._verbose:
                    logger.info(
                        f"[Kindred AI] Rewriting request: {original_url} -> {rewritten_url}"
                    )
                
                # Capture original payload/body
                original_payload = None
                if 'data' in kwargs:
                    original_payload = kwargs['data']
                elif 'json' in kwargs:
                    original_payload = kwargs['json']
                elif 'files' in kwargs:
                    # For file uploads, we can't easily serialize, so skip
                    original_payload = None
                
                # Initialize headers if not present
                if 'headers' not in kwargs or kwargs['headers'] is None:
                    kwargs['headers'] = {}
                # Ensure headers is a dict
                if not isinstance(kwargs['headers'], dict):
                    # Convert list of tuples to dict if needed
                    if isinstance(kwargs['headers'], (list, tuple)):
                        kwargs['headers'] = dict(kwargs['headers'])
                    else:
                        # For other types, create new dict and copy existing
                        kwargs['headers'] = {}
                
                # Add original destination URL header
                kwargs['headers']['X-Kindred-Original-URL'] = original_url
                
                # Add original payload header if available
                if original_payload is not None:
                    try:
                        # Try to serialize as JSON if it's a dict/list
                        if isinstance(original_payload, (dict, list)):
                            payload_str = json.dumps(original_payload)
                            kwargs['headers']['X-Kindred-Original-Payload'] = payload_str
                            kwargs['headers']['X-Kindred-Original-Payload-Type'] = 'json'
                        elif isinstance(original_payload, str):
                            kwargs['headers']['X-Kindred-Original-Payload'] = original_payload
                            kwargs['headers']['X-Kindred-Original-Payload-Type'] = 'string'
                        elif isinstance(original_payload, bytes):
                            # Encode binary data as base64
                            payload_str = base64.b64encode(original_payload).decode('utf-8')
                            kwargs['headers']['X-Kindred-Original-Payload'] = payload_str
                            kwargs['headers']['X-Kindred-Original-Payload-Type'] = 'base64'
                        else:
                            # For other types, convert to string
                            kwargs['headers']['X-Kindred-Original-Payload'] = str(original_payload)
                            kwargs['headers']['X-Kindred-Original-Payload-Type'] = 'string'
                    except Exception as e:
                        if cls._verbose:
                            logger.warning(f"Failed to serialize original payload: {e}")
                
                # Add agent token header if available
                if cls._agent_token:
                    kwargs['headers']['X-Kindred-Agent-Token'] = cls._agent_token
                    if cls._verbose:
                        logger.debug(f"Added X-Kindred-Agent-Token header to intercepted request")
                
                # Update the URL in args or kwargs
                if 'url' in kwargs:
                    kwargs['url'] = rewritten_url
                elif len(args) > 1:
                    # Preserve method (args[0]) and update URL (args[1])
                    args = (args[0], rewritten_url) + args[2:]
        
        # Call the original method
        return wrapped(*args, **kwargs)

