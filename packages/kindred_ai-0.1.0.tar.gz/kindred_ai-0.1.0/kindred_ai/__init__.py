"""
Kindred AI SDK

A Python SDK that intercepts HTTP requests and reroutes them based on configuration rules.
"""

from .core import Interceptor

__all__ = ["Interceptor"]
__version__ = "0.1.0"

