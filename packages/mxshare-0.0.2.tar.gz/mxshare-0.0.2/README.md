# mxshare
A demo Python package for test.

## 安装
```bash
pip install mxshare