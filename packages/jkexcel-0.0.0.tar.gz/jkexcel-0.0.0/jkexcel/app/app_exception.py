class ExecutionFaultedException(Exception):
    pass
