export { default } from "./Image";
