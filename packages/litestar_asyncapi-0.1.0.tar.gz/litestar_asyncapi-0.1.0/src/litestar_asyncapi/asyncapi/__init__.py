"""AsyncAPI schema generation internals."""
