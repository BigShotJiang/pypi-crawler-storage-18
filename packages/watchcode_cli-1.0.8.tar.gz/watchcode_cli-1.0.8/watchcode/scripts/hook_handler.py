#!/usr/bin/env python3
"""
Centralized hook handler for WatchCode Claude Code hooks.

Security hardened:
- Safe JSON parsing
- Path validation with realpath
- No shell=True in subprocess
- Input size limits
- Sanitized environment

Usage:
    export HOOK_INPUT='{"session_id": "...", ...}'
    python3 hook_handler.py <hook_type>

Hook types: stop, notification, session_start, session_end, subagent_stop, permission_request
"""

import json
import os
import sys
import subprocess
import logging
import time
import uuid
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# Security constants
MAX_INPUT_SIZE = 1024 * 1024  # 1MB
ALLOWED_HOOKS = {'stop', 'notification', 'notification_debug', 'session_start', 'session_end', 'subagent_stop', 'permission_request', 'pre_tool_use'}
APNS_SENDER = Path.home() / ".watchcode" / "apns_sender.py"
RESPONSE_LISTENER = Path.home() / ".watchcode" / "response_listener.py"
CLOUDKIT_POLLER = Path.home() / ".watchcode" / "cloudkit_poller.py"
DEBUG_LOG = Path.home() / ".watchcode" / "hook_debug.log"
ICLOUD_DRIVE_PATH = Path.home() / "Library" / "Mobile Documents" / "iCloud~com~watchcode~app" / "Documents"

# Wake push configuration
WAKE_PUSH_INTERVAL = 8  # seconds between wake pushes
DEFAULT_PERMISSION_TIMEOUT = 55  # seconds to wait for Watch response

# Relay server configuration
RELAY_URL = "https://relay.vgbndg.net"
AUTH_TOKEN_FILE = Path.home() / ".watchcode" / "auth_token.txt"
CLAUDE_SETTINGS_FILE = Path.home() / ".claude" / "settings.json"


def load_allowed_patterns() -> list:
    """Load auto-allowed tool patterns from Claude settings."""
    try:
        if not CLAUDE_SETTINGS_FILE.exists():
            return []
        with open(CLAUDE_SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
        return settings.get('permissions', {}).get('allow', [])
    except Exception as e:
        log_debug(f"Failed to load allowed patterns: {e}")
        return []


def is_auto_allowed(tool_name: str, tool_input: dict) -> bool:
    """Check if a tool call is auto-allowed (no permission needed).

    Parses patterns like:
    - Bash(curl -s:*) - Bash commands starting with "curl -s"
    - Write(path:/tmp/*) - Write to files under /tmp
    - Edit(path:*.py) - Edit Python files

    Returns True if auto-allowed (skip notification), False if permission needed.
    """
    import fnmatch

    patterns = load_allowed_patterns()
    if not patterns:
        return False  # No patterns = nothing auto-allowed

    for pattern in patterns:
        # Parse pattern format: Tool(arg:value)
        if not pattern.startswith(tool_name + '('):
            continue

        # Extract the inner part: e.g., "curl -s:*" from "Bash(curl -s:*)"
        inner = pattern[len(tool_name)+1:-1] if pattern.endswith(')') else ''
        if not inner:
            continue

        if tool_name == 'Bash':
            command = tool_input.get('command', '')
            # Pattern format: "command_prefix:*" or just the command
            if ':' in inner:
                prefix = inner.split(':')[0]
                # Check if command starts with prefix
                if command.startswith(prefix):
                    log_debug(f"Auto-allowed: Bash command matches '{prefix}:*'")
                    return True
            else:
                # Exact match or fnmatch
                if fnmatch.fnmatch(command, inner):
                    log_debug(f"Auto-allowed: Bash command matches '{inner}'")
                    return True

        elif tool_name in ('Write', 'Edit'):
            file_path = tool_input.get('file_path', '')
            if file_path and fnmatch.fnmatch(file_path, inner):
                log_debug(f"Auto-allowed: {tool_name} path matches '{inner}'")
                return True

    return False


def log_debug(msg: str) -> None:
    """Append debug message to log file."""
    try:
        with open(DEBUG_LOG, 'a') as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def validate_path(path: str, allowed_base: Path | None = None) -> Path | None:
    """Validate and resolve a path, preventing traversal attacks."""
    if not path:
        return None

    try:
        resolved = Path(path).expanduser().resolve()

        # If allowed_base specified, ensure path is under it
        if allowed_base:
            allowed_resolved = allowed_base.resolve()
            if not str(resolved).startswith(str(allowed_resolved)):
                logger.warning(f"Path traversal blocked: {path}")
                return None

        return resolved
    except Exception as e:
        logger.warning(f"Path validation failed: {e}")
        return None


def parse_input() -> dict:
    """Parse JSON input from stdin (Claude Code) or HOOK_INPUT env (manual testing)."""
    input_data = None
    source = "unknown"

    # First try stdin (Claude Code sends data via stdin for hooks)
    if not sys.stdin.isatty():
        try:
            stdin_content = sys.stdin.read()
            if stdin_content.strip():
                input_data = stdin_content
                source = "stdin"
        except Exception as e:
            log_debug(f"Failed to read stdin: {e}")

    # Fallback to HOOK_INPUT env var (for manual testing)
    if not input_data:
        input_data = os.environ.get('HOOK_INPUT', '{}')
        source = "HOOK_INPUT" if input_data != '{}' else "default"

    # ALWAYS log raw input for debugging
    log_debug(f"=== RAW INPUT (source: {source}) ===")
    log_debug(f"Length: {len(input_data)}")
    log_debug(f"Content: {input_data[:1000]}")

    # Size limit
    if len(input_data) > MAX_INPUT_SIZE:
        raise ValueError(f"Input too large: {len(input_data)} bytes (max {MAX_INPUT_SIZE})")

    try:
        return json.loads(input_data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON input: {e}")


def extract_transcript_data(transcript_path: str) -> tuple[str, str]:
    """Extract the task request and assistant response from transcript.

    Finds the most likely "task request" - a substantial user message that
    triggered the work, not just follow-ups like "yes do it".

    Returns: (user_prompt, full_response)
    """
    user_prompt = ''
    full_response = ''

    validated_path = validate_path(transcript_path)
    if not validated_path or not validated_path.exists():
        log_debug(f"Transcript not found: {transcript_path}")
        return user_prompt, full_response

    try:
        with open(validated_path, 'r') as f:
            lines = f.readlines()

        # Collect all user messages and assistant responses
        user_messages = []
        last_assistant_msg = ''

        for line in lines:
            try:
                entry = json.loads(line.strip())
                entry_type = entry.get('type', '')

                if entry_type == 'user':
                    msg = entry.get('message', {})
                    if isinstance(msg, dict):
                        content = msg.get('content', [])
                        for block in content:
                            if isinstance(block, dict) and block.get('type') == 'text':
                                text = block.get('text', '').strip()
                                if text and not text.startswith('[Request interrupted'):
                                    user_messages.append(text)

                elif entry_type == 'assistant':
                    msg = entry.get('message', {})
                    if isinstance(msg, dict):
                        content = msg.get('content', [])
                        texts = []
                        for block in content:
                            if isinstance(block, dict) and block.get('type') == 'text':
                                text = block.get('text', '').strip()
                                if text:
                                    texts.append(text)
                        if texts:
                            last_assistant_msg = '\n'.join(texts)
            except json.JSONDecodeError:
                continue

        # Find the most likely "task request" - look for substantial user messages
        # Short messages like "yes", "do it", "sounds good" are follow-ups, not requests
        SHORT_FOLLOWUP_PATTERNS = [
            'yes', 'no', 'ok', 'okay', 'do it', 'go ahead', 'sounds good',
            'perfect', 'great', 'thanks', 'thank you', 'sure', 'yep', 'nope',
            'continue', 'proceed', 'looks good', 'lgtm', 'approved'
        ]

        task_request = ''
        # Search from most recent to oldest for a substantial message
        for msg in reversed(user_messages):
            msg_lower = msg.lower().strip()
            # Skip very short messages
            if len(msg) < 20:
                # Check if it's just a short confirmation
                if any(msg_lower.startswith(p) or msg_lower == p for p in SHORT_FOLLOWUP_PATTERNS):
                    continue
            # Skip messages that are complaints/feedback about the current work
            if 'don\'t see' in msg_lower or 'didn\'t work' in msg_lower or 'still' in msg_lower:
                continue
            # Found a substantial message - this is likely the task request
            task_request = msg
            break

        # If no substantial message found, use the last one
        if not task_request and user_messages:
            task_request = user_messages[-1]

        user_prompt = task_request
        full_response = last_assistant_msg

    except Exception as e:
        log_debug(f"Transcript parsing error: {e}")

    return user_prompt, full_response


def send_notification(
    event: str,
    message: str,
    session_id: str,
    project_name: str = '',
    full_response: str = '',
    user_prompt: str = '',
    requires_action: bool = False,
    notification_id: str = ''
) -> int:
    """Send notification via watchcode CLI (uses relay server)."""

    # Build command using watchcode CLI
    cmd = ['watchcode', 'notify', '--event', event]

    if message:
        cmd.extend(['--message', message[:500]])

    if requires_action:
        cmd.append('--requires-action')

    if notification_id:
        cmd.extend(['--notification-id', notification_id])

    try:
        # Build safe environment
        safe_env = os.environ.copy()
        for var in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES',
                    'BASH_ENV', 'CDPATH', 'ENV']:
            safe_env.pop(var, None)
        # Include common paths where watchcode might be installed
        safe_env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:' + \
                          str(Path.home() / '.local' / 'bin') + ':' + \
                          '/Library/Frameworks/Python.framework/Versions/3.12/bin'

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            env=safe_env
        )

        log_debug(f"watchcode notify exit code: {result.returncode}")
        if result.stdout:
            log_debug(f"stdout: {result.stdout}")
        if result.stderr:
            log_debug(f"stderr: {result.stderr}")

        return result.returncode

    except subprocess.TimeoutExpired:
        logger.error("watchcode notify timed out after 30s")
        return 1
    except FileNotFoundError:
        logger.error("watchcode CLI not found in PATH")
        return 1
    except Exception as e:
        logger.error(f"Failed to run watchcode notify: {e}")
        return 1


def handle_stop(data: dict) -> int:
    """Handle 'stop' hook - task completion."""
    session_id = data.get('session_id', 'claude')
    transcript_path = data.get('transcript_path', '')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else ''

    log_debug(f"Stop hook: session={session_id}, project={project_name}")

    # Extract transcript data
    user_prompt, full_response = extract_transcript_data(transcript_path)

    # Create summary
    if full_response:
        summary = full_response[:200]
        if len(full_response) > 200:
            summary += '...'
    else:
        summary = 'Task completed'

    log_debug(f"user_prompt: {user_prompt[:100] if user_prompt else 'EMPTY'}")
    log_debug(f"full_response: {full_response[:100] if full_response else 'EMPTY'}")

    return send_notification(
        event='stop',
        message=summary,
        session_id=session_id,
        project_name=project_name,
        full_response=full_response,
        user_prompt=user_prompt
    )


def handle_notification(data: dict) -> int:
    """Handle 'notification' hook - fires when Claude awaits user input.

    This includes permission dialogs. We send notification and wait for response.
    """
    message = data.get('message', 'Notification')
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else ''

    # Generate unique notification ID
    notification_id = str(uuid.uuid4())
    sequence_id = generate_sequence_id()

    log_debug(f"[seq={sequence_id}] Notification hook: {message[:50]}...")

    # Send notification with requires_action since we're awaiting input
    send_result = send_notification(
        event='permission_request',
        message=message[:200] if message else 'Claude needs your input',
        session_id=session_id,
        project_name=project_name,
        requires_action=True,
        notification_id=notification_id
    )

    if send_result != 0:
        log_debug(f"[seq={sequence_id}] Failed to send notification")
        return 0  # Don't block, let terminal handle it

    # Wait for Watch response
    log_debug(f"[seq={sequence_id}] Waiting for Watch response...")
    response = wait_for_response_with_wake(
        session_id=session_id,
        sequence_id=sequence_id,
        timeout=DEFAULT_PERMISSION_TIMEOUT,
        wake_interval=WAKE_PUSH_INTERVAL,
        notification_id=notification_id
    )

    # Output decision
    if response:
        action = response.get('action', '').lower()
        if action == 'approve':
            output_decision('allow')
            log_debug(f"[seq={sequence_id}] User APPROVED via Watch")
        elif action == 'deny':
            output_decision('deny', 'Denied via Apple Watch')
            log_debug(f"[seq={sequence_id}] User DENIED via Watch")
    else:
        log_debug(f"[seq={sequence_id}] No response, falling back to terminal")

    return 0


def handle_session_start(data: dict) -> int:
    """Handle 'session_start' hook."""
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else 'Unknown Project'

    return send_notification(
        event='session_start',
        message=f'Session started: {project_name}',
        session_id=session_id,
        project_name=project_name
    )


def handle_session_end(data: dict) -> int:
    """Handle 'session_end' hook."""
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else ''

    return send_notification(
        event='session_end',
        message='Session ended',
        session_id=session_id,
        project_name=project_name
    )


def handle_subagent_stop(data: dict) -> int:
    """Handle 'subagent_stop' hook - subagent (Task tool) completion."""
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else 'Unknown'

    log_debug(f"SubagentStop hook: session={session_id}, project={project_name}")

    return send_notification(
        event='notification',
        message=f'Subagent completed in {project_name}',
        session_id=session_id,
        project_name=project_name
    )


def wait_for_response(session_id: str, timeout: int = 55) -> dict | None:
    """Run response_listener.py and return parsed response.

    Returns None if timeout or error, dict with 'action' key if successful.
    """
    if not RESPONSE_LISTENER.exists():
        log_debug(f"response_listener.py not found at {RESPONSE_LISTENER}")
        return None

    cmd = [
        sys.executable,
        str(RESPONSE_LISTENER),
        '--session-id', session_id,
        '--timeout', str(timeout)
    ]

    try:
        # Build safe environment
        safe_env = os.environ.copy()
        for var in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES',
                    'BASH_ENV', 'CDPATH', 'ENV']:
            safe_env.pop(var, None)
        safe_env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 5,  # Extra buffer for subprocess overhead
            env=safe_env
        )

        log_debug(f"response_listener exit code: {result.returncode}")
        if result.stderr:
            log_debug(f"response_listener stderr: {result.stderr[:200]}")

        if result.returncode == 0 and result.stdout.strip():
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError as e:
                log_debug(f"Failed to parse response JSON: {e}")
                return None
        else:
            log_debug(f"No valid response (exit code {result.returncode})")
            return None

    except subprocess.TimeoutExpired:
        log_debug(f"response_listener timed out after {timeout}s")
        return None
    except Exception as e:
        log_debug(f"wait_for_response error: {e}")
        return None


def generate_sequence_id() -> int:
    """Generate a unique sequence ID for correlation tracking."""
    return int(time.time() * 1000) % 1000000  # 6-digit millisecond-based ID


def check_icloud_response(session_id: str) -> dict | None:
    """Direct file check for iCloud Drive response (faster than subprocess).

    Checks: ~/Library/Mobile Documents/iCloud~com~watchcode~app/Documents/response_{session_id}.json

    Returns response dict if found and valid, None otherwise.
    """
    response_file = ICLOUD_DRIVE_PATH / f"response_{session_id}.json"

    if not response_file.exists():
        return None

    try:
        with open(response_file, 'r') as f:
            response = json.load(f)

        # Validate response has required field
        if 'action' not in response:
            log_debug(f"Response file missing 'action' field")
            return None

        # Delete file after reading (consume once)
        response_file.unlink()
        log_debug(f"✓ Read and deleted response file for session {session_id}")

        return response
    except json.JSONDecodeError as e:
        log_debug(f"Invalid JSON in response file: {e}")
        return None
    except Exception as e:
        log_debug(f"Error reading response file: {e}")
        return None


def get_auth_token() -> str | None:
    """Read auth token from Keychain or file."""
    # Try Keychain first - use same service name as CLI (com.watchcode.cli)
    try:
        result = subprocess.run(
            ['security', 'find-generic-password', '-s', 'com.watchcode.cli', '-a', 'auth_token', '-w'],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass

    # Fallback to file
    try:
        if AUTH_TOKEN_FILE.exists():
            return AUTH_TOKEN_FILE.read_text().strip()
    except Exception:
        pass

    return None


def check_relay_response(notification_id: str) -> dict | None:
    """Check relay server for Watch response.

    The Watch sends responses to POST /respond on the relay.
    The Mac polls GET /response/:auth_token/:notification_id to get them.

    Returns response dict if found, None otherwise.
    """
    auth_token = get_auth_token()
    if not auth_token:
        log_debug("No auth token found for relay polling")
        return None

    if not notification_id:
        log_debug("No notification_id for relay polling")
        return None

    url = f"{RELAY_URL}/response/{auth_token}/{notification_id}"

    try:
        import urllib.request
        import urllib.error

        req = urllib.request.Request(url, method='GET')
        req.add_header('Accept', 'application/json')

        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                data = json.loads(resp.read().decode())
                # Response structure: { found: true, response: { action, timestamp, selected_options, ... } }
                if data.get('found'):
                    response_data = data.get('response', {})
                    action = response_data.get('action')
                    if action:
                        selected_opts = response_data.get('selected_options', [])
                        log_debug(f"✓ Relay response found: action={action}, selected={selected_opts}")
                        # Return full response data including selected_options
                        return response_data
    except urllib.error.HTTPError as e:
        if e.code != 404:  # 404 just means no response yet
            log_debug(f"Relay HTTP error: {e.code}")
    except Exception as e:
        log_debug(f"Relay poll error: {e}")

    return None


def delete_stale_cloudkit_record(session_id: str) -> None:
    """Delete a stale CloudKit record to prevent future false positives."""
    if not CLOUDKIT_POLLER.exists():
        return

    # Use cloudkit_poller with --delete flag (we'll add this)
    # For now, just run the poller once more which will trigger its cleanup
    cmd = [
        sys.executable,
        str(CLOUDKIT_POLLER),
        '--session-id', session_id,
        '--delete-only'  # Delete without returning data
    ]

    try:
        safe_env = os.environ.copy()
        for var in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES',
                    'BASH_ENV', 'CDPATH', 'ENV']:
            safe_env.pop(var, None)
        safe_env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

        subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
            env=safe_env
        )
        log_debug(f"Deleted stale CloudKit record for session {session_id}")
    except Exception as e:
        log_debug(f"Failed to delete stale record: {e}")


def check_cloudkit_response(session_id: str, notification_id: str = '') -> dict | None:
    """Check CloudKit for response from Watch (single check, no polling).

    Watch writes directly to CloudKit, bypassing iPhone entirely.
    This is more reliable than iCloud Drive for Watch responses.

    If notification_id is provided, looks up by notification_id (unique per request).
    Otherwise falls back to session_id (legacy behavior).

    Returns response dict if found and valid, None otherwise.
    """
    if not CLOUDKIT_POLLER.exists():
        # CloudKit poller not set up - skip silently
        return None

    # Prefer notification_id (unique per request) over session_id (shared across requests)
    lookup_id = notification_id if notification_id else session_id

    cmd = [
        sys.executable,
        str(CLOUDKIT_POLLER),
        '--session-id', lookup_id,
        '--once'  # Single check, no polling
    ]

    try:
        safe_env = os.environ.copy()
        for var in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES',
                    'BASH_ENV', 'CDPATH', 'ENV']:
            safe_env.pop(var, None)
        safe_env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
            env=safe_env
        )

        if result.returncode == 0 and result.stdout.strip():
            try:
                response = json.loads(result.stdout)

                # Validate timestamp - reject records older than 2 minutes
                # This prevents stale records from being reused
                record_timestamp = response.get('timestamp', 0)
                if record_timestamp:
                    # CloudKit timestamps are in milliseconds
                    record_age_seconds = (time.time() * 1000 - record_timestamp) / 1000
                    if record_age_seconds > 30:  # 30 seconds - permission requests are frequent
                        log_debug(f"⚠️ CloudKit response too old ({record_age_seconds:.0f}s), deleting stale record")
                        # Delete the stale record to prevent future false positives
                        delete_stale_cloudkit_record(lookup_id)
                        return None
                    log_debug(f"✓ CloudKit response found for {lookup_id} (age: {record_age_seconds:.1f}s)")
                else:
                    log_debug(f"✓ CloudKit response found for {lookup_id} (no timestamp)")

                return response
            except json.JSONDecodeError as e:
                log_debug(f"Invalid CloudKit response JSON: {e}")
                return None

    except subprocess.TimeoutExpired:
        log_debug("CloudKit check timed out")
    except Exception as e:
        log_debug(f"CloudKit check error: {e}")

    return None


def send_wake_push(session_id: str, sequence_id: int, attempt: int) -> bool:
    """Send silent wake push to wake iOS app.

    This sends a background APNs notification that wakes the iPhone app
    to process any queued WatchConnectivity messages.
    """
    if not APNS_SENDER.exists():
        log_debug("apns_sender.py not found for wake push")
        return False

    cmd = [
        sys.executable,
        str(APNS_SENDER),
        '--event', 'wake',
        '--message', '',  # Empty for wake push
        '--session-id', session_id,
        '--push-type', 'background',
        '--sequence-id', str(sequence_id),
    ]

    try:
        safe_env = os.environ.copy()
        for var in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES',
                    'BASH_ENV', 'CDPATH', 'ENV']:
            safe_env.pop(var, None)
        safe_env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
            env=safe_env
        )

        if result.returncode == 0:
            log_debug(f"[seq={sequence_id}] Wake push #{attempt} sent successfully")
            return True
        else:
            log_debug(f"[seq={sequence_id}] Wake push #{attempt} failed: {result.stderr[:100] if result.stderr else 'no error'}")
            return False

    except subprocess.TimeoutExpired:
        log_debug(f"[seq={sequence_id}] Wake push #{attempt} timed out")
        return False
    except Exception as e:
        log_debug(f"[seq={sequence_id}] Wake push #{attempt} error: {e}")
        return False


def wait_for_response_with_wake(
    session_id: str,
    sequence_id: int,
    timeout: int = DEFAULT_PERMISSION_TIMEOUT,
    wake_interval: int = WAKE_PUSH_INTERVAL,
    notification_id: str = ''
) -> dict | None:
    """Poll for response while sending periodic wake pushes.

    This improves reliability when the iPhone app is suspended - wake pushes
    will wake the app to process queued WatchConnectivity messages from Watch.

    Args:
        session_id: Claude Code session ID
        sequence_id: Unique sequence for this request (for correlation)
        timeout: Total timeout in seconds
        wake_interval: Seconds between wake pushes
        notification_id: Unique notification ID for CloudKit lookup (if provided)

    Returns:
        Response dict if received, None on timeout
    """
    start_time = time.time()
    wake_count = 0
    poll_count = 0
    last_wake = 0.0

    log_debug(f"[seq={sequence_id}] Starting response wait (timeout={timeout}s, wake_interval={wake_interval}s, notification_id={notification_id[:8] if notification_id else 'none'}...)")

    while time.time() - start_time < timeout:
        poll_count += 1
        elapsed = time.time() - start_time

        # Check CloudKit first (Watch writes directly, bypasses iPhone)
        # Use notification_id if provided (unique per request), otherwise fall back to session_id
        response = check_cloudkit_response(session_id, notification_id)
        if response:
            log_debug(f"[seq={sequence_id}] ✓ CloudKit response after {elapsed:.1f}s, {poll_count} polls")
            return response

        # Also check iCloud Drive (iPhone relay path)
        response = check_icloud_response(session_id)
        if response:
            log_debug(f"[seq={sequence_id}] ✓ iCloud Drive response after {elapsed:.1f}s, {poll_count} polls, {wake_count} wakes")
            return response

        # Check relay server (Watch sends responses here via POST /respond)
        response = check_relay_response(notification_id)
        if response:
            log_debug(f"[seq={sequence_id}] ✓ Relay response after {elapsed:.1f}s, {poll_count} polls")
            return response

        # Send wake push every wake_interval seconds (for iPhone relay path)
        if elapsed - last_wake >= wake_interval:
            wake_count += 1
            log_debug(f"[seq={sequence_id}] Sending wake push #{wake_count} at {elapsed:.1f}s")
            send_wake_push(session_id, sequence_id, wake_count)
            last_wake = elapsed

        # Short sleep between polls (1 second)
        time.sleep(1)

    log_debug(f"[seq={sequence_id}] ⏱️ Timeout after {timeout}s, {poll_count} polls, {wake_count} wakes")
    return None


def output_decision(decision: str, reason: str = '') -> None:
    """Output hook decision to stdout for Claude Code.

    Uses the hookSpecificOutput format required by PermissionRequest hooks.
    """
    behavior = "allow" if decision == "allow" else "deny"

    output = {
        "hookSpecificOutput": {
            "hookEventName": "PermissionRequest",
            "decision": {
                "behavior": behavior
            }
        }
    }

    if reason and behavior == "deny":
        output["hookSpecificOutput"]["decision"]["message"] = reason

    print(json.dumps(output), flush=True)


def handle_permission_request(data: dict) -> int:
    """Handle 'permission_request' hook - forward to Watch for approval.

    Sends tool permission prompt to Apple Watch and waits for user response.
    Uses periodic wake pushes to ensure iPhone processes Watch responses.
    If user approves/denies within timeout, returns that decision.
    If timeout, returns nothing (falls back to terminal prompt).
    """
    tool_name = data.get('tool_name', 'Unknown')
    tool_input = data.get('tool_input', {})
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else 'Unknown'

    # Handle AskUserQuestion specially - send question with options to Watch
    # PreToolUse doesn't fire for AskUserQuestion, so we handle it here
    if tool_name == 'AskUserQuestion':
        log_debug(f"AskUserQuestion detected in PermissionRequest - sending question to Watch")
        return handle_ask_user_question(tool_input, session_id, project_name)

    log_debug(f"PermissionRequest: tool={tool_name}, session={session_id}")

    # Note: PermissionRequest hook only fires when permission is actually needed
    # No filtering required - Claude Code already filtered for us

    # Generate unique sequence ID for this request (for correlation)
    sequence_id = generate_sequence_id()

    # Build human-readable prompt based on tool type
    if tool_name == 'Write':
        file_path = tool_input.get('file_path', 'file')
        prompt = f"Allow Write to {Path(file_path).name}?"
    elif tool_name == 'Edit':
        file_path = tool_input.get('file_path', 'file')
        prompt = f"Allow Edit to {Path(file_path).name}?"
    elif tool_name == 'Bash':
        command = tool_input.get('command', '')[:40]
        prompt = f"Allow Bash: {command}?"
    elif tool_name == 'NotebookEdit':
        notebook_path = tool_input.get('notebook_path', 'notebook')
        prompt = f"Allow NotebookEdit to {Path(notebook_path).name}?"
    else:
        prompt = f"Allow {tool_name}?"

    # Generate unique notification ID for this request
    # This prevents stale approvals from being reused for different requests
    notification_id = str(uuid.uuid4())

    log_debug(f"[seq={sequence_id}] PermissionRequest: {prompt} (session={session_id}, notification={notification_id[:8]}...)")

    # 1. Send notification to Watch with action buttons
    send_result = send_notification(
        event='permission_request',
        message=prompt,
        session_id=session_id,
        project_name=project_name,
        requires_action=True,
        notification_id=notification_id
    )

    if send_result != 0:
        log_debug(f"[seq={sequence_id}] Failed to send notification, falling back to terminal")
        return 0  # No output = use terminal prompt

    # 2. Wait for Watch response with periodic wake pushes
    # Wake pushes help when iPhone is suspended and can't receive Watch messages immediately
    log_debug(f"[seq={sequence_id}] Waiting for Watch response with wake pushes...")
    response = wait_for_response_with_wake(
        session_id=session_id,
        sequence_id=sequence_id,
        timeout=DEFAULT_PERMISSION_TIMEOUT,
        wake_interval=WAKE_PUSH_INTERVAL,
        notification_id=notification_id
    )

    # 3. Output decision or nothing
    if response:
        action = response.get('action', '').lower()
        if action == 'approve':
            output_decision('allow')
            log_debug(f"[seq={sequence_id}] ✓ User APPROVED via Watch")
        elif action == 'deny':
            output_decision('deny', 'Denied via Apple Watch')
            log_debug(f"[seq={sequence_id}] ✗ User DENIED via Watch")
        else:
            log_debug(f"[seq={sequence_id}] Unknown action '{action}', no decision output")
            # No output = terminal prompt stays active
    else:
        log_debug(f"[seq={sequence_id}] No response received, falling back to terminal prompt")
        # No output = terminal prompt stays active

    return 0


def handle_ask_user_question(tool_input: dict, session_id: str, project_name: str) -> int:
    """Handle AskUserQuestion tool - send question with options to Watch.

    Extracts question and options from tool_input, sends to relay,
    waits for Watch response, and outputs the answer.
    """
    questions = tool_input.get('questions', [])
    if not questions:
        log_debug("No questions found in AskUserQuestion input")
        return 0

    # For now, handle first question (most common case)
    first_q = questions[0]
    question_text = first_q.get('question', 'Question')
    options = first_q.get('options', [])
    multi_select = first_q.get('multiSelect', False)

    # Convert options to relay format
    question_options = []
    for opt in options:
        question_options.append({
            'id': opt.get('label', '').lower().replace(' ', '_'),
            'label': opt.get('label', '?'),
            'description': opt.get('description', '')
        })

    log_debug(f"Sending AskUserQuestion with {len(question_options)} options: {question_text[:50]}...")

    # Generate unique IDs for this request
    notification_id = str(uuid.uuid4())
    sequence_id = generate_sequence_id()

    # Send directly to relay with options
    success = send_question_to_relay(
        message=question_text,
        session_id=session_id,
        question_options=question_options,
        multi_select=multi_select,
        notification_id=notification_id
    )

    if not success:
        log_debug(f"⚠️ Failed to send AskUserQuestion to Watch, falling back to terminal")
        return 0

    log_debug(f"✓ AskUserQuestion sent, waiting for Watch response...")

    # Wait for Watch response (same as permission_request)
    response = wait_for_response_with_wake(
        session_id=session_id,
        sequence_id=sequence_id,
        timeout=DEFAULT_PERMISSION_TIMEOUT,
        wake_interval=WAKE_PUSH_INTERVAL,
        notification_id=notification_id
    )

    if response:
        action = response.get('action', '')
        selected_options = response.get('selected_options', [])
        log_debug(f"✓ Received Watch answer: action={action}, selected={selected_options}")

        # For selectOption action, use the selected_options array
        if action == 'selectOption' and selected_options:
            answer = ', '.join(selected_options)
            output_question_answer(answer)
        else:
            # Fallback to action as answer
            output_question_answer(action)
    else:
        log_debug(f"No Watch response, falling back to terminal prompt")

    return 0


def output_question_answer(answer: str) -> None:
    """Output question answer to stdout for Claude Code.

    Uses hookSpecificOutput format to provide the user's answer.
    """
    output = {
        "hookSpecificOutput": {
            "hookEventName": "PermissionRequest",
            "decision": {
                "behavior": "allow"
            },
            "userAnswer": answer  # Include the answer for Claude to see
        }
    }

    # Also output the answer directly so Claude sees it
    print(f"User selected via Watch: {answer}", flush=True)
    # print(json.dumps(output), flush=True)


def send_question_to_relay(
    message: str,
    session_id: str,
    question_options: list,
    multi_select: bool = False,
    notification_id: str = ''
) -> bool:
    """Send question notification directly to relay with options.

    This bypasses the CLI to include question_options in the payload.
    """
    auth_token = get_auth_token()
    if not auth_token:
        log_debug("No auth token found for question notification")
        return False

    if not notification_id:
        notification_id = str(uuid.uuid4())

    payload = {
        'auth_token': auth_token,
        'event': 'question',
        'message': message[:500],
        'session_id': session_id,
        'requires_action': True,
        'notification_id': notification_id,
        'question_options': question_options,
        'allows_multi_select': multi_select  # Relay expects allows_multi_select
    }

    try:
        import urllib.request
        import urllib.error

        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            f"{RELAY_URL}/notify",
            data=data,
            method='POST'
        )
        req.add_header('Content-Type', 'application/json')

        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status == 200:
                log_debug(f"✓ Question notification sent to relay")
                return True
            else:
                log_debug(f"Relay returned status {resp.status}")
                return False

    except urllib.error.HTTPError as e:
        log_debug(f"Relay HTTP error: {e.code} - {e.read().decode()[:100]}")
        return False
    except Exception as e:
        log_debug(f"Failed to send question to relay: {e}")
        return False


def handle_pre_tool_use(data: dict) -> int:
    """Handle 'pre_tool_use' hook - detect AskUserQuestion and send to Watch.

    When Claude asks a multi-choice question, this sends a notification
    showing the question and options. User can select on Watch.
    """
    tool_name = data.get('tool_name', '')
    tool_input = data.get('tool_input', {})
    session_id = data.get('session_id', 'unknown')
    cwd = data.get('cwd', '')
    project_name = Path(cwd).name if cwd else 'Unknown'

    # Only process AskUserQuestion tool
    if tool_name != 'AskUserQuestion':
        return 0

    log_debug(f"PreToolUse: AskUserQuestion detected")

    # Extract questions from tool_input
    questions = tool_input.get('questions', [])
    if not questions:
        log_debug("No questions found in AskUserQuestion input")
        return 0

    # For now, handle first question (most common case)
    # TODO: Support multiple questions if needed
    first_q = questions[0]
    question_text = first_q.get('question', 'Question')
    options = first_q.get('options', [])
    multi_select = first_q.get('multiSelect', False)

    # Convert options to relay format
    question_options = []
    for opt in options:
        question_options.append({
            'id': opt.get('label', '').lower().replace(' ', '_'),
            'label': opt.get('label', '?'),
            'description': opt.get('description', '')
        })

    log_debug(f"Sending question with {len(question_options)} options: {question_text[:50]}...")

    # Send directly to relay with options (bypasses CLI)
    send_question_to_relay(
        message=question_text,
        session_id=session_id,
        question_options=question_options,
        multi_select=multi_select
    )

    return 0


def handle_notification_debug(data: dict) -> int:
    """DEBUG: Log Notification hook data to understand what it provides."""
    log_debug(f"=== NOTIFICATION DEBUG ===")
    log_debug(f"Full data: {json.dumps(data, indent=2)[:1000]}")
    log_debug(f"Keys: {list(data.keys())}")
    log_debug(f"message: {data.get('message', 'N/A')[:200]}")
    log_debug(f"tool_name: {data.get('tool_name', 'N/A')}")
    log_debug(f"tool_input: {str(data.get('tool_input', 'N/A'))[:200]}")
    return 0


HANDLERS = {
    'stop': handle_stop,
    'notification': handle_notification,
    'notification_debug': handle_notification_debug,
    'session_start': handle_session_start,
    'session_end': handle_session_end,
    'subagent_stop': handle_subagent_stop,
    'permission_request': handle_permission_request,
    'pre_tool_use': handle_pre_tool_use,
}


def main() -> int:
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <hook_type>", file=sys.stderr)
        print(f"Hook types: {', '.join(ALLOWED_HOOKS)}", file=sys.stderr)
        return 1

    hook_type = sys.argv[1].lower().replace('-', '_')

    if hook_type not in ALLOWED_HOOKS:
        logger.error(f"Unknown hook type: {hook_type}")
        logger.error(f"Allowed: {', '.join(ALLOWED_HOOKS)}")
        return 1

    log_debug(f"=== Hook triggered: {hook_type} ===")

    try:
        data = parse_input()
        handler = HANDLERS.get(hook_type)

        if handler:
            return handler(data)
        else:
            logger.error(f"No handler for hook type: {hook_type}")
            return 1

    except ValueError as e:
        logger.error(f"Input error: {e}")
        return 1
    except Exception as e:
        logger.error(f"Hook failed: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())
