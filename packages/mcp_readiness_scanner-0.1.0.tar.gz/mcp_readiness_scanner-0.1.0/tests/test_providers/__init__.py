"""Tests for inspection providers."""
