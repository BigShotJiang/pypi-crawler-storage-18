# OpenAPI 代码生成器使用指南

> **版本**: v3.38.0 | **更新**: 2025-12-24

本指南介绍如何使用 df-test-framework 的 OpenAPI 代码生成器，从 Swagger/OpenAPI 规范自动生成测试代码。

## 概述

OpenAPI 代码生成器可以从 Swagger 2.0 或 OpenAPI 3.0 规范文件自动生成：

- **Pydantic 模型** - 请求和响应数据模型
- **API 客户端** - 强类型的 API 调用类
- **测试用例** - 基于 pytest 的测试模板

## 快速开始

### 前置条件

```bash
# 确保安装了 pyyaml（OpenAPI 解析依赖）
pip install pyyaml
```

### 基本用法

```bash
# 从本地文件生成
uv run df-test generate openapi swagger.json

# 从 URL 生成
uv run df-test generate openapi https://api.example.com/swagger.json

# 指定输出目录
uv run df-test generate openapi swagger.json --output ./my_project
```

## 命令行选项

```bash
uv run df-test generate openapi <spec_path> [OPTIONS]

参数:
  spec_path           OpenAPI 规范文件路径或 URL

选项:
  --output, -o        输出目录（默认: 当前目录）
  --tags, -t          过滤的 API 标签（逗号分隔）
  --models-only       只生成模型
  --clients-only      只生成客户端
  --tests-only        只生成测试
  --force, -f         强制覆盖已存在的文件
```

### 示例

```bash
# 只生成用户和订单相关的 API
uv run df-test generate openapi swagger.json --tags user,order

# 只生成模型文件
uv run df-test generate openapi swagger.json --models-only

# 强制覆盖已存在的文件
uv run df-test generate openapi swagger.json --force
```

## 代码方式调用

```python
from df_test_framework.cli.generators import generate_from_openapi

# 基本调用
generate_from_openapi("swagger.json")

# 完整参数
generate_from_openapi(
    "https://api.example.com/swagger.json",
    output_dir=Path("./my_project"),
    generate_tests=True,
    generate_clients=True,
    generate_models=True,
    tags=["user", "order"],
    force=False,
)
```

## 生成的文件结构

```
src/{project_name}/
├── models/
│   ├── __init__.py          # 导出通用模型
│   ├── base.py              # Result[T]、PageInfo[T] 通用包装
│   ├── requests/
│   │   ├── __init__.py
│   │   ├── user.py          # 用户相关请求模型
│   │   └── order.py         # 订单相关请求模型
│   └── responses/
│       ├── __init__.py
│       ├── user.py          # 用户相关响应模型
│       └── order.py         # 订单相关响应模型
├── apis/
│   ├── user_api.py          # 用户 API 客户端
│   └── order_api.py         # 订单 API 客户端
tests/
└── api/
    ├── test_user_api.py     # 用户 API 测试
    └── test_order_api.py    # 订单 API 测试
```

## 生成的代码详解

### 1. 通用响应包装类

`models/base.py` 提供常用的响应包装：

```python
from typing import Generic, TypeVar
from pydantic import BaseModel, Field

T = TypeVar("T")

class Result(BaseModel, Generic[T]):
    """通用响应包装

    适用于格式:
        {"code": 200, "message": "success", "data": {...}}
    """
    code: int = Field(..., description="业务状态码")
    message: str = Field(..., description="响应消息")
    data: T | None = Field(None, description="响应数据")


class PageInfo(BaseModel, Generic[T]):
    """分页响应

    适用于格式:
        {"total": 100, "current": 1, "size": 20, "records": [...]}
    """
    total: int = Field(..., description="总记录数")
    current: int = Field(default=1, description="当前页码")
    size: int = Field(default=20, description="每页大小")
    records: list[T] = Field(default_factory=list, description="记录列表")
```

### 2. 请求/响应模型

生成的模型自动处理 Java/Python 命名转换：

```python
# models/requests/user.py
from pydantic import BaseModel, ConfigDict, Field

class CreateUserRequest(BaseModel):
    """创建用户请求"""

    model_config = ConfigDict(populate_by_name=True)

    # Java camelCase 自动转换为 Python snake_case
    # alias 保留原始名称用于 JSON 序列化
    user_name: str = Field(..., description="用户名", alias="userName")
    email: str = Field(..., description="邮箱", alias="email")
    phone_number: str | None = Field(None, description="手机号", alias="phoneNumber")
```

**命名转换规则**：
- `userName` → `user_name`（alias="userName"）
- `phoneNumber` → `phone_number`（alias="phoneNumber"）
- `email` → `email`（名称相同，无 alias）

### 3. 强类型 API 客户端

```python
# apis/user_api.py
from df_test_framework import BaseAPI, HttpClient
from df_test_framework.testing.decorators import api_class
from ..models.requests.user import CreateUserRequest
from ..models.responses.user import CreateUserResponse

@api_class("user_api", scope="function")
class UserAPI(BaseAPI):
    """用户 API 客户端

    Fixture 名称: user_api
    """

    def __init__(self, http_client: HttpClient):
        super().__init__(http_client)
        self.base_path = "/api/v1/users"

    def create_user(self, request: CreateUserRequest) -> CreateUserResponse:
        """创建用户

        Args:
            request: CreateUserRequest 请求模型

        Returns:
            CreateUserResponse: 响应数据
        """
        return self.post(self.base_path, json=request, model=CreateUserResponse)

    def get_user(self, user_id: int) -> UserDetailResponse:
        """获取用户详情"""
        return self.get(f"{self.base_path}/{user_id}", model=UserDetailResponse)
```

### 4. 测试用例模板（v3.38.0+）

**生成的测试包含最新特性**：

```python
# tests/api/test_user_api.py
import pytest
import allure
from assertpy import assert_that
from df_test_framework import step, DataGenerator

@allure.feature("User")
class TestUserAPI:
    """用户 API 测试类

    Fixture 依赖 (v3.38.0+):
        - user_api: API 客户端（由 @api_class 自动注册）
        - cleanup: 数据清理管理器（框架自动注册）
        - allure_observer: Allure 观察者（框架自动注册，自动记录请求/响应）
    """

    @allure.title("创建用户")
    @pytest.mark.smoke
    def test_create_user(self, user_api, cleanup, allure_observer):
        """测试创建用户

        Args:
            user_api: API 客户端（自动注册）
            cleanup: 数据清理管理器（自动注册）
            allure_observer: Allure 观察者（自动记录请求/响应到报告）
        """
        from my_project.models.requests.user import CreateUserRequest

        with step("构造请求数据"):
            # 使用 DataGenerator 生成唯一标识符
            user_id = DataGenerator.test_id("TEST_USER")
            request = CreateUserRequest(
                id=user_id,
                user_name="Alice",
                email="alice@example.com"
            )

        with step("调用接口"):
            response = user_api.create_user(request)
            # ✅ allure_observer 已自动记录请求/响应详情

        with step("注册数据清理"):
            # 测试结束后自动清理创建的用户
            cleanup.add("users", user_id)

        with step("验证响应"):
            assert_that(response.code).is_equal_to(200)
            assert_that(response.data.user_name).is_equal_to("Alice")

    @allure.title("查询用户（跳过认证）")
    def test_get_user_public(self, user_api, allure_observer):
        """测试公开接口 - 演示 skip_auth 参数"""
        with step("调用公开接口（跳过认证）"):
            # 使用 skip_auth=True 跳过全局认证中间件
            response = user_api.get_user(user_id=1, skip_auth=True)

        with step("验证响应"):
            assert_that(response.code).is_equal_to(200)
```

**新特性说明**：

1. **allure_observer** - 自动记录所有 HTTP 请求/响应到 Allure 报告，无需手动调用 `attach_json()`
2. **cleanup** - 配置驱动的数据清理，测试结束后自动清理创建的数据
3. **DataGenerator.test_id()** - 生成唯一测试标识符，避免数据冲突
4. **skip_auth/token** - 请求级别的认证控制，灵活处理不同接口的认证需求

## 集成到项目

### 1. 配置 conftest.py

```python
# conftest.py
from df_test_framework.testing.decorators import load_api_fixtures

# 导入 API 类（触发 @api_class 装饰器注册）
from my_project.apis.user_api import UserAPI  # noqa: F401
from my_project.apis.order_api import OrderAPI  # noqa: F401

# 加载所有已注册的 API fixtures
load_api_fixtures(globals())
```

### 2. 编写测试

```python
# tests/api/test_user_api.py
from my_project.models.requests.user import CreateUserRequest

def test_create_user(user_api):
    """user_api fixture 由 @api_class 自动注册"""
    request = CreateUserRequest(
        user_name="Alice",
        email="alice@example.com"
    )
    response = user_api.create_user(request)

    assert response.code == 200
    assert response.data.user_name == "Alice"
```

### 3. 运行测试

```bash
# 运行所有 API 测试
uv run pytest tests/api/ -v

# 运行冒烟测试
uv run pytest tests/api/ -m smoke -v
```

## 高级用法

### 自定义模型

生成的模型可以根据需要进行扩展：

```python
# 扩展生成的模型
from my_project.models.requests.user import CreateUserRequest

class CreateUserRequestWithValidation(CreateUserRequest):
    """添加自定义验证"""

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        if not v.endswith("@company.com"):
            raise ValueError("必须使用公司邮箱")
        return v
```

### 使用 Result[T] 包装

```python
from my_project.models.base import Result
from my_project.models.responses.user import UserData

# 定义带包装的响应类型
class CreateUserResponse(Result[UserData]):
    """创建用户响应 = Result[UserData]"""
    pass

# 使用时自动解析
response = user_api.create_user(request)
print(response.code)        # 200
print(response.message)     # "success"
print(response.data.id)     # 1
print(response.data.name)   # "Alice"
```

### 处理分页响应

```python
from my_project.models.base import PageInfo

class UserListResponse(PageInfo[UserData]):
    """用户列表响应"""
    pass

# 使用
response = user_api.list_users(page=1, size=20)
print(response.total)       # 100
print(response.current)     # 1
print(response.size)        # 20
for user in response.records:
    print(user.name)
```

## 支持的规范格式

### Swagger 2.0

```json
{
  "swagger": "2.0",
  "info": {"title": "API", "version": "1.0"},
  "host": "api.example.com",
  "basePath": "/api/v1",
  "paths": {
    "/users": {
      "post": {
        "operationId": "createUser",
        "parameters": [
          {
            "in": "body",
            "name": "body",
            "schema": {"$ref": "#/definitions/CreateUserRequest"}
          }
        ],
        "responses": {
          "200": {
            "schema": {"$ref": "#/definitions/CreateUserResponse"}
          }
        }
      }
    }
  }
}
```

### OpenAPI 3.0

```yaml
openapi: 3.0.0
info:
  title: API
  version: 1.0.0
paths:
  /users:
    post:
      operationId: createUser
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateUserRequest'
      responses:
        '200':
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CreateUserResponse'
```

## 常见问题

### Q: 生成的模型字段为空？

检查 Swagger 文档中的 `$ref` 引用是否正确。生成器会自动解析引用，但如果引用路径错误，可能导致字段为空。

### Q: 如何处理不规范的 Swagger 文档？

生成器使用宽松模式解析，会跳过严格的 OpenAPI 规范验证。如果仍有问题，可以尝试手动修复 Swagger 文档。

### Q: 如何更新已生成的代码？

使用 `--force` 选项强制覆盖：

```bash
uv run df-test generate openapi swagger.json --force
```

建议先备份自定义修改，或使用继承扩展生成的类。

## 相关文档

- [v3.38.0 发布说明](../releases/v3.38.0.md)
- [脚手架 CLI 工具指南](scaffold_cli_guide.md)
- [HTTP 客户端使用指南](async_http_client.md)
- [测试数据生成指南](test_data.md)
