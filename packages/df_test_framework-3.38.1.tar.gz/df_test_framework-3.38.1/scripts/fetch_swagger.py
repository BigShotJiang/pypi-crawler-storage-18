"""从 Swagger UI 获取 OpenAPI 文档

用法：
    python scripts/fetch_swagger.py [URL] [OUTPUT]

示例：
    python scripts/fetch_swagger.py http://8.129.8.225:11001/swagger-ui/index.html
    python scripts/fetch_swagger.py http://8.129.8.225:11001 swagger.json
"""

import json
import sys
from pathlib import Path
from urllib.parse import urljoin, urlparse

import httpx


# 常见的 OpenAPI 文档端点
COMMON_API_DOC_PATHS = [
    "/v3/api-docs",
    "/v2/api-docs",
    "/swagger.json",
    "/api-docs",
    "/openapi.json",
    "/swagger/v1/swagger.json",
    "/swagger-resources",
]


def get_base_url(url: str) -> str:
    """从 URL 中提取基础地址"""
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}"


def try_fetch_swagger_doc(base_url: str, client: httpx.Client) -> dict | None:
    """尝试从常见端点获取 Swagger 文档"""
    for path in COMMON_API_DOC_PATHS:
        url = urljoin(base_url, path)
        print(f"  尝试: {url}")
        try:
            response = client.get(url, timeout=10)
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")
                if "json" in content_type or path.endswith(".json"):
                    data = response.json()
                    # 检查是否是有效的 OpenAPI 文档
                    if "swagger" in data or "openapi" in data or "paths" in data:
                        print(f"  ✅ 找到 OpenAPI 文档: {url}")
                        return data
                    # 可能是 swagger-resources 响应
                    if isinstance(data, list) and len(data) > 0:
                        # swagger-resources 返回的是资源列表
                        for resource in data:
                            if "url" in resource or "location" in resource:
                                resource_url = resource.get("url") or resource.get("location")
                                full_url = urljoin(base_url, resource_url)
                                print(f"  发现资源: {full_url}")
                                res = client.get(full_url, timeout=10)
                                if res.status_code == 200:
                                    return res.json()
        except Exception as e:
            print(f"  ❌ 失败: {e}")
            continue
    return None


def fetch_swagger(url: str, output: str | None = None) -> None:
    """获取 Swagger 文档并保存"""
    base_url = get_base_url(url)
    print(f"基础地址: {base_url}")
    print("正在探测 OpenAPI 文档端点...")

    with httpx.Client(follow_redirects=True) as client:
        # 尝试获取文档
        doc = try_fetch_swagger_doc(base_url, client)

        if not doc:
            print("\n❌ 未找到 OpenAPI 文档，请手动指定文档 URL")
            print("常见端点:")
            for path in COMMON_API_DOC_PATHS:
                print(f"  {urljoin(base_url, path)}")
            sys.exit(1)

        # 确定输出文件名
        if not output:
            # 从文档中获取标题作为文件名
            title = doc.get("info", {}).get("title", "swagger")
            # 清理文件名
            safe_title = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)
            output = f"{safe_title}.json"

        # 保存文档
        output_path = Path(output)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)

        print(f"\n✅ 已保存到: {output_path.absolute()}")
        print(f"   版本: {doc.get('openapi') or doc.get('swagger', 'unknown')}")
        print(f"   标题: {doc.get('info', {}).get('title', 'N/A')}")
        print(f"   接口数: {len(doc.get('paths', {}))}")

        # 提示使用方法
        print(f"\n🚀 使用方法:")
        print(f"   uv run df-test gen from-swagger {output_path.name} --output generated/")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        url = "http://8.129.8.225:11001/swagger-ui/index.html"
    else:
        url = sys.argv[1]

    output = sys.argv[2] if len(sys.argv) > 2 else None

    fetch_swagger(url, output)
