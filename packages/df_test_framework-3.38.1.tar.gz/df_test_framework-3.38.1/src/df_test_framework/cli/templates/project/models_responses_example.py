"""示例响应模型模板"""

MODELS_RESPONSES_EXAMPLE_TEMPLATE = """\"\"\"用户相关响应模型

演示如何定义响应模型，提供：
- IDE 智能提示
- 类型检查
- 自动反序列化
- 别名支持（如 createdAt -> created_at）

使用方式：
    >>> from {project_name}.models.responses.user import UserResponse
    >>> user = UserResponse.model_validate(api_response["data"])
    >>> print(user.name)
\"\"\"

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class UserResponse(BaseModel):
    \"\"\"用户响应模型\"\"\"

    model_config = ConfigDict(populate_by_name=True)

    id: int = Field(..., description="用户ID")
    name: str = Field(..., description="用户名")
    email: str = Field(..., description="邮箱地址")
    phone: str | None = Field(None, description="手机号")
    created_at: str | None = Field(None, alias="createdAt", description="创建时间")


class PagedUsersResponse(BaseModel):
    \"\"\"分页用户列表响应模型\"\"\"

    model_config = ConfigDict(populate_by_name=True)

    total: int = Field(..., description="总记录数")
    page: int = Field(..., description="当前页码")
    size: int = Field(..., description="每页数量")
    items: list[UserResponse] = Field(default_factory=list, description="用户列表")


class ApiResponse(BaseModel):
    \"\"\"通用 API 响应包装

    常见格式:
        {"code": 200, "message": "success", "data": {...}}
    \"\"\"

    model_config = ConfigDict(populate_by_name=True)

    code: int = Field(..., description="业务状态码")
    message: str = Field(..., description="响应消息")
    data: dict[str, Any] | list[Any] | None = Field(None, description="响应数据")


__all__ = [
    "UserResponse",
    "PagedUsersResponse",
    "ApiResponse",
]
"""

__all__ = ["MODELS_RESPONSES_EXAMPLE_TEMPLATE"]
