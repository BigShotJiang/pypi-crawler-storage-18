"""示例 API 客户端模板"""

USER_API_EXAMPLE_TEMPLATE = """\"\"\"示例用户 API 客户端

演示如何使用 BaseAPI 封装 API 调用，提供：
- 强类型方法签名
- IDE 智能提示
- 请求级认证控制（skip_auth/token）
- 自动 Pydantic 模型序列化

使用方式：
    # 方式 1: 直接实例化
    >>> from {project_name}.apis.user_api import UserAPI
    >>> api = UserAPI(http_client)
    >>> response = api.get_user(user_id=1)

    # 方式 2: 使用 fixture（推荐）
    >>> def test_example(user_api):
    ...     response = user_api.list_users()
\"\"\"

from typing import Any

from df_test_framework import BaseAPI, HttpClient
from df_test_framework.testing.decorators import api_class

from ..models.requests.user import (
    CreateUserRequest,
    QueryUsersRequest,
    UpdateUserRequest,
)


@api_class("user_api", scope="function")
class UserAPI(BaseAPI):
    \"\"\"用户 API 客户端

    使用 @api_class 装饰器自动注册为 pytest fixture。

    Fixture 使用:
        1. 在 conftest.py 中导入此类（触发装饰器注册）
        2. 调用 load_api_fixtures(globals())
        3. 在测试中直接使用 user_api fixture

    Attributes:
        base_path: API 路径前缀
    \"\"\"

    def __init__(self, http_client: HttpClient):
        super().__init__(http_client)
        self.base_path = "/api/v1"

    # ========== 查询接口 ==========

    def get_user(
        self,
        user_id: int,
        *,
        skip_auth: bool = False,
        token: str | None = None,
    ) -> dict[str, Any]:
        \"\"\"获取用户详情

        Args:
            user_id: 用户 ID
            skip_auth: 跳过认证（测试公开接口）
            token: 自定义 Token（覆盖全局配置）

        Returns:
            API 响应数据

        Example:
            >>> response = user_api.get_user(user_id=123)
            >>> print(response["data"]["name"])
        \"\"\"
        return self.get(
            f"/users/{{user_id}}",
            skip_auth=skip_auth,
            token=token,
        )

    def list_users(
        self,
        request: QueryUsersRequest | None = None,
        *,
        page: int = 1,
        size: int = 20,
    ) -> dict[str, Any]:
        \"\"\"获取用户列表

        Args:
            request: 查询请求模型（可选）
            page: 页码（当 request 为 None 时使用）
            size: 每页数量（当 request 为 None 时使用）

        Returns:
            分页用户列表
        \"\"\"
        if request:
            params = request.model_dump(exclude_none=True)
        else:
            params = {{"page": page, "size": size}}

        return self.get("/users", params=params)

    # ========== 写入接口 ==========

    def create_user(self, request: CreateUserRequest) -> dict[str, Any]:
        \"\"\"创建用户

        Args:
            request: 创建用户请求模型

        Returns:
            创建成功的用户数据

        Example:
            >>> request = CreateUserRequest(name="Alice", email="alice@example.com")
            >>> response = user_api.create_user(request)
            >>> user_id = response["data"]["id"]
        \"\"\"
        # BaseAPI.post() 自动将 Pydantic 模型序列化为 JSON
        return self.post("/users", json=request)

    def update_user(
        self,
        user_id: int,
        request: UpdateUserRequest,
    ) -> dict[str, Any]:
        \"\"\"更新用户信息

        Args:
            user_id: 用户 ID
            request: 更新请求模型（只包含要更新的字段）

        Returns:
            更新后的用户数据
        \"\"\"
        # 排除 None 值，只发送有值的字段
        return self.put(
            f"/users/{{user_id}}",
            json=request.model_dump(exclude_none=True),
        )

    def delete_user(self, user_id: int) -> dict[str, Any]:
        \"\"\"删除用户

        Args:
            user_id: 用户 ID

        Returns:
            删除结果
        \"\"\"
        return self.delete(f"/users/{{user_id}}")

    # ========== 业务接口示例 ==========

    def check_email_exists(self, email: str) -> bool:
        \"\"\"检查邮箱是否已存在

        演示返回非 dict 类型的方法。

        Args:
            email: 邮箱地址

        Returns:
            True 表示已存在，False 表示不存在
        \"\"\"
        response = self.get("/users/check-email", params={{"email": email}})
        return response.get("data", {{}}).get("exists", False)


__all__ = ["UserAPI"]
"""

__all__ = ["USER_API_EXAMPLE_TEMPLATE"]
