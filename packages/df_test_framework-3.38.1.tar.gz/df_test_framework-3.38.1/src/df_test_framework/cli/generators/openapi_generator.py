"""从 OpenAPI/Swagger 规范生成测试代码

基于 OpenAPI 规范自动生成测试用例、API 客户端和 Pydantic 模型。

v3.38.0 重大改进:
- Model 分类生成（requests/responses/common）
- API 方法类型化（强类型参数和返回值）
- 通用响应包装处理（Result[T]）
- 符合框架最佳实践和脚手架结构
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ..utils import (
    create_file,
    detect_project_name,
    to_ascii_identifier,
    to_pascal_case,
    to_snake_case,
)
from .openapi_parser import OPENAPI_AVAILABLE, APIEndpoint, OpenAPIParser


def generate_from_openapi(
    spec_path: str | Path,
    *,
    output_dir: Path | None = None,
    generate_tests: bool = True,
    generate_clients: bool = True,
    generate_models: bool = True,
    tags: list[str] | None = None,
    force: bool = False,
) -> None:
    """从 OpenAPI 规范生成测试代码

    Args:
        spec_path: OpenAPI 规范文件路径或 URL
        output_dir: 输出目录（默认: 当前目录）
        generate_tests: 是否生成测试用例
        generate_clients: 是否生成 API 客户端
        generate_models: 是否生成 Pydantic 模型
        tags: 过滤的标签列表（None 表示生成所有）
        force: 是否强制覆盖

    Example:
        >>> generate_from_openapi(
        ...     "https://api.example.com/swagger.json",
        ...     generate_tests=True,
        ...     generate_clients=True,
        ...     generate_models=True
        ... )
    """
    if not OPENAPI_AVAILABLE:
        print("❌ 错误: OpenAPI 功能需要安装 pyyaml 库")
        print("   请运行: pip install pyyaml")
        return

    # 检测项目名称
    project_name = detect_project_name()
    if not project_name:
        print("⚠️  错误: 无法检测项目名称，请在项目根目录下运行")
        return

    if output_dir is None:
        output_dir = Path.cwd()

    # 解析 OpenAPI 规范
    print(f"\n📝 解析 OpenAPI 规范: {spec_path}")
    try:
        parser = OpenAPIParser(spec_path)
    except Exception as e:
        print(f"❌ 解析失败: {e}")
        return

    # 获取 API 信息
    info = parser.get_info()
    print(f"📋 API: {info.get('title', 'Unknown')} v{info.get('version', '1.0.0')}")

    # 获取端点列表
    endpoints = parser.get_endpoints(tags=tags)
    print(f"📊 找到 {len(endpoints)} 个 API 端点")

    if not endpoints:
        print("⚠️  没有找到符合条件的 API 端点")
        return

    # 生成统计
    generated_files = []

    # Phase 1: 生成模型（分类到 requests/responses/common）
    if generate_models:
        print("\n📝 生成 Pydantic 模型...")
        model_files = _generate_models_v2(parser, endpoints, project_name, output_dir, force)
        generated_files.extend(model_files)

    # Phase 2: 生成 API 客户端（类型化方法）
    if generate_clients:
        print("\n📝 生成 API 客户端...")
        client_files = _generate_api_clients_v2(endpoints, parser, project_name, output_dir, force)
        generated_files.extend(client_files)

    # Phase 3: 生成测试用例
    if generate_tests:
        print("\n📝 生成测试用例...")
        test_files = _generate_tests_v2(endpoints, project_name, output_dir, force)
        generated_files.extend(test_files)

    # 输出结果
    print("\n✅ 生成完成！")
    print(f"\n📁 共生成 {len(generated_files)} 个文件:")
    for file_type, file_path in generated_files:
        print(f"  ✓ {file_type:<20} {file_path}")

    print("\n💡 下一步:")
    print("  1. 在 conftest.py 中导入生成的 API 类")
    print("  2. 调用 load_api_fixtures(globals())")
    print("  3. 根据需要完善请求/响应模型")
    print("  4. 运行测试: pytest tests/ -v")


# ========== Phase 1: Model 分类生成 ==========


def _generate_models_v2(
    parser: OpenAPIParser,
    endpoints: list[APIEndpoint],
    project_name: str,
    output_dir: Path,
    force: bool,
) -> list[tuple[str, Path]]:
    """生成分类的 Pydantic 模型

    v3.38.0 改进:
    - 区分 requests/responses/common
    - 按 tag 组织文件
    - 生成通用响应包装类
    """
    generated: list[tuple[str, Path]] = []

    # 创建目录
    models_dir = output_dir / "src" / project_name / "models"
    requests_dir = models_dir / "requests"
    responses_dir = models_dir / "responses"
    requests_dir.mkdir(parents=True, exist_ok=True)
    responses_dir.mkdir(parents=True, exist_ok=True)

    # Phase 1.1: 生成 models/base.py（通用响应包装）
    base_model_files = _generate_base_models(models_dir, force)
    generated.extend(base_model_files)

    # Phase 1.2: 按 tag 分组 endpoints
    endpoints_by_tag: dict[str, list[APIEndpoint]] = defaultdict(list)
    for endpoint in endpoints:
        tag = endpoint.tags[0] if endpoint.tags else "default"
        endpoints_by_tag[tag].append(endpoint)

    # Phase 1.3: 为每个 tag 生成 request/response 模型
    parser.get_schemas()

    for tag, tag_endpoints in endpoints_by_tag.items():
        # 生成 requests/{tag}.py
        request_files = _generate_request_models(tag, tag_endpoints, parser, requests_dir, force)
        generated.extend(request_files)

        # 生成 responses/{tag}.py
        response_files = _generate_response_models(tag, tag_endpoints, parser, responses_dir, force)
        generated.extend(response_files)

    # Phase 1.4: 生成 __init__.py
    init_files = _generate_model_init_files(models_dir, requests_dir, responses_dir, force)
    generated.extend(init_files)

    return generated


def _generate_base_models(models_dir: Path, force: bool) -> list[tuple[str, Path]]:
    """生成 models/base.py（通用响应包装类）"""
    generated = []

    base_model_code = '''"""通用响应模型

提供常见的响应包装类，如 Result[T]、PageInfo 等。
"""

from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class Result(BaseModel, Generic[T]):
    """通用响应包装

    常见格式:
        {
          "code": 200,
          "message": "success",
          "data": { ... }
        }

    使用示例:
        >>> class UserResponse(BaseModel):
        ...     id: int
        ...     name: str
        >>>
        >>> response_data = {"code": 200, "message": "success", "data": {"id": 1, "name": "Alice"}}
        >>> result = Result[UserResponse](**response_data)
        >>> print(result.data.name)  # Alice
    """

    code: int = Field(..., description="业务状态码")
    message: str = Field(..., description="响应消息")
    data: T | None = Field(None, description="响应数据")


class PageInfo(BaseModel, Generic[T]):
    """分页响应

    常见格式:
        {
          "total": 100,
          "current": 1,
          "size": 20,
          "records": [...]
        }
    """

    total: int = Field(..., description="总记录数")
    current: int = Field(default=1, description="当前页码")
    size: int = Field(default=20, description="每页大小")
    records: list[T] = Field(default_factory=list, description="记录列表")


__all__ = ["Result", "PageInfo"]
'''

    file_path = models_dir / "base.py"
    try:
        create_file(file_path, base_model_code, force=force)
        generated.append(
            ("Model (Base)", Path("src") / file_path.relative_to(models_dir.parent.parent))
        )
    except FileExistsError:
        pass

    return generated


def _generate_request_models(
    tag: str,
    endpoints: list[APIEndpoint],
    parser: OpenAPIParser,
    requests_dir: Path,
    force: bool,
) -> list[tuple[str, Path]]:
    """生成请求模型文件"""
    generated = []

    # 收集该 tag 下所有的 request models
    request_models = []
    for endpoint in endpoints:
        if endpoint.request_body:
            model_info = _extract_request_model_info(endpoint, parser)
            if model_info:
                request_models.append(model_info)

    if not request_models:
        return generated

    # 生成文件内容（使用 ASCII 标识符处理中文 tag）
    tag_id = to_ascii_identifier(tag)
    file_name = f"{tag_id}.py"
    file_path = requests_dir / file_name

    code = _build_request_models_file(tag, tag_id, request_models)

    try:
        create_file(file_path, code, force=force)
        generated.append(
            (
                "Model (Request)",
                Path("src") / file_path.relative_to(requests_dir.parent.parent.parent),
            )
        )
    except FileExistsError:
        pass

    return generated


def _generate_response_models(
    tag: str,
    endpoints: list[APIEndpoint],
    parser: OpenAPIParser,
    responses_dir: Path,
    force: bool,
) -> list[tuple[str, Path]]:
    """生成响应模型文件"""
    generated = []

    # 收集该 tag 下所有的 response models
    response_models = []
    for endpoint in endpoints:
        model_info = _extract_response_model_info(endpoint, parser)
        if model_info:
            response_models.append(model_info)

    if not response_models:
        return generated

    # 生成文件内容（使用 ASCII 标识符处理中文 tag）
    tag_id = to_ascii_identifier(tag)
    file_name = f"{tag_id}.py"
    file_path = responses_dir / file_name

    code = _build_response_models_file(tag, tag_id, response_models)

    try:
        create_file(file_path, code, force=force)
        generated.append(
            (
                "Model (Response)",
                Path("src") / file_path.relative_to(responses_dir.parent.parent.parent),
            )
        )
    except FileExistsError:
        pass

    return generated


def _extract_request_model_info(endpoint: APIEndpoint, parser: OpenAPIParser) -> dict | None:
    """从 endpoint 提取请求模型信息"""
    if not endpoint.request_body:
        return None

    # 生成模型名称（基于 operationId）
    method_name = to_snake_case(endpoint.operation_id) if endpoint.operation_id else "request"
    model_name = to_pascal_case(method_name) + "Request"

    # 获取 schema 并解析 $ref 引用
    schema = endpoint.request_body.get("schema", {})
    if "$ref" in schema:
        schema = parser._resolve_ref(schema["$ref"])

    return {
        "name": model_name,
        "schema": schema,
        "description": endpoint.summary or f"{model_name} 请求模型",
    }


def _extract_response_model_info(endpoint: APIEndpoint, parser: OpenAPIParser) -> dict | None:
    """从 endpoint 提取响应模型信息

    即使 Swagger 文档中没有详细的响应 schema，也会生成基于 Result[dict] 的占位符模型。
    """
    # 尝试获取 200/201 响应
    success_response = endpoint.get_success_response()
    if not success_response:
        return None

    # 生成模型名称
    method_name = to_snake_case(endpoint.operation_id) if endpoint.operation_id else "response"
    model_name = to_pascal_case(method_name) + "Response"

    # 获取 schema 并解析 $ref 引用
    schema = success_response.get("schema", {})
    if "$ref" in schema:
        schema = parser._resolve_ref(schema["$ref"])

    # 标记是否有详细的 schema（用于决定生成完整模型还是占位符）
    has_detailed_schema = bool(schema and schema.get("properties"))

    return {
        "name": model_name,
        "schema": schema,
        "description": success_response.get("description", f"{model_name} 响应模型"),
        "has_detailed_schema": has_detailed_schema,
    }


def _build_request_models_file(tag: str, tag_id: str, models: list[dict]) -> str:
    """构建请求模型文件内容

    Args:
        tag: 原始 tag 名称（用于注释）
        tag_id: ASCII 标识符（用于导入路径）
        models: 模型信息列表
    """
    # 去重
    unique_models = {m["name"]: m for m in models}

    model_classes = []
    for model_info in unique_models.values():
        model_code = _build_model_class(
            model_info["name"], model_info["schema"], model_info["description"]
        )
        model_classes.append(model_code)

    all_names = list(unique_models.keys())

    code = f'''"""自动生成的请求模型 - {tag}

从 OpenAPI 规范生成。
模块标识: {tag_id}

注意：字段名使用 Python 惯例的 snake_case，但序列化时使用原始的 camelCase。
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


{chr(10).join(model_classes)}


__all__ = {all_names}
'''

    return code


def _build_response_models_file(tag: str, tag_id: str, models: list[dict]) -> str:
    """构建响应模型文件内容

    Args:
        tag: 原始 tag 名称（用于注释）
        tag_id: ASCII 标识符（用于导入路径）
        models: 模型信息列表

    v3.38.1 改进：
    - 为没有详细 schema 的响应生成基于 Result[dict] 的占位符模型
    - 添加 TODO 注释提示用户完善模型
    """
    # 去重
    unique_models = {m["name"]: m for m in models}

    model_classes = []
    for model_info in unique_models.values():
        has_detailed_schema = model_info.get("has_detailed_schema", False)
        if has_detailed_schema:
            # 有详细 schema，生成完整模型
            model_code = _build_model_class(
                model_info["name"], model_info["schema"], model_info["description"]
            )
        else:
            # 没有详细 schema，生成占位符模型
            model_code = _build_placeholder_response_model(
                model_info["name"], model_info["description"]
            )
        model_classes.append(model_code)

    all_names = list(unique_models.keys())

    code = f'''"""自动生成的响应模型 - {tag}

从 OpenAPI 规范生成。
模块标识: {tag_id}

注意：
- 字段名使用 Python 惯例的 snake_case，但序列化时使用原始的 camelCase
- 如果 Swagger 文档未定义响应结构，会生成基于 Result[dict] 的占位符模型
- 请根据实际 API 响应结构完善这些模型
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field
from ..base import Result


{chr(10).join(model_classes)}


__all__ = {all_names}
'''

    return code


def _build_placeholder_response_model(model_name: str, description: str) -> str:
    """构建占位符响应模型（当 Swagger 未定义响应 schema 时使用）

    生成基于 Result[dict] 的简单模型，用户可以后续根据实际响应结构完善。
    """
    return f'''class {model_name}(Result[dict[str, Any]]):
    """{description}

    注意：Swagger 文档未定义此响应的详细结构。
    此模型基于通用 Result[dict] 生成，请根据实际 API 响应完善。

    常见响应格式:
        {{"code": 200, "message": "success", "data": {{...}}}}

    使用示例:
        >>> response = api.some_method(request)
        >>> if response.code == 200:
        ...     print(response.data)  # dict[str, Any]

    TODO: 根据实际响应结构定义具体字段
    """
    pass
'''


def _build_model_class(model_name: str, schema: dict, description: str) -> str:
    """构建 Pydantic 模型类代码

    自动处理 Java/Python 命名转换：
    - Java camelCase -> Python snake_case
    - 保留原始名称作为 alias
    """
    properties = schema.get("properties", {})
    required = schema.get("required", [])

    if not properties:
        # 空模型
        return f'''class {model_name}(BaseModel):
    """{description}"""

    model_config = ConfigDict(populate_by_name=True)
    pass
'''

    # 生成字段
    fields = []
    for original_name, field_schema in properties.items():
        # 转换字段名：camelCase -> snake_case
        python_name = to_snake_case(original_name)
        field_type = _get_python_type(field_schema)
        is_required = original_name in required
        field_desc = field_schema.get("description", f"{original_name} 字段")

        # 如果转换后名称不同，添加 alias
        if python_name != original_name:
            alias_param = f', alias="{original_name}"'
        else:
            alias_param = ""

        if is_required:
            fields.append(
                f'    {python_name}: {field_type} = Field(..., description="{field_desc}"{alias_param})'
            )
        else:
            fields.append(
                f'    {python_name}: {field_type} | None = Field(None, description="{field_desc}"{alias_param})'
            )

    fields_code = "\n".join(fields)

    return f'''class {model_name}(BaseModel):
    """{description}"""

    model_config = ConfigDict(populate_by_name=True)

{fields_code}
'''


def _get_python_type(schema: dict) -> str:
    """将 OpenAPI 类型转换为 Python 类型"""
    schema_type = schema.get("type", "string")

    type_mapping = {
        "string": "str",
        "integer": "int",
        "number": "float",
        "boolean": "bool",
        "object": "dict[str, Any]",
    }

    # 处理数组类型
    if schema_type == "array" and "items" in schema:
        item_type = _get_python_type(schema["items"])
        return f"list[{item_type}]"

    return type_mapping.get(schema_type, "Any")


def _generate_model_init_files(
    models_dir: Path, requests_dir: Path, responses_dir: Path, force: bool
) -> list[tuple[str, Path]]:
    """生成 models/__init__.py 和子目录的 __init__.py"""
    generated = []

    # models/__init__.py
    models_init_code = '''"""数据模型模块

组织结构:
- base.py: 通用响应包装类（Result[T]、PageInfo等）
- requests/: 请求模型
- responses/: 响应模型
"""

from .base import PageInfo, Result

__all__ = ["Result", "PageInfo"]
'''

    try:
        create_file(models_dir / "__init__.py", models_init_code, force=force)
        generated.append(
            (
                "Model (Init)",
                Path("src") / (models_dir / "__init__.py").relative_to(models_dir.parent.parent),
            )
        )
    except FileExistsError:
        pass

    # requests/__init__.py
    request_init_code = '"""请求模型模块"""\n'
    try:
        create_file(requests_dir / "__init__.py", request_init_code, force=force)
    except FileExistsError:
        pass

    # responses/__init__.py
    response_init_code = '"""响应模型模块"""\n'
    try:
        create_file(responses_dir / "__init__.py", response_init_code, force=force)
    except FileExistsError:
        pass

    return generated


# ========== Phase 2: API 客户端类型化 ==========


def _generate_api_clients_v2(
    endpoints: list[APIEndpoint],
    parser: OpenAPIParser,
    project_name: str,
    output_dir: Path,
    force: bool,
) -> list[tuple[str, Path]]:
    """生成类型化的 API 客户端

    v3.38.0 改进:
    - 方法参数和返回值使用 Pydantic 模型
    - 自动导入对应的 request/response 模型
    - 利用 BaseAPI 的自动序列化能力
    """
    generated: list[tuple[str, Path]] = []

    # 按标签分组
    endpoints_by_tag: dict[str, list[APIEndpoint]] = defaultdict(list)
    for endpoint in endpoints:
        tag = endpoint.tags[0] if endpoint.tags else "default"
        endpoints_by_tag[tag].append(endpoint)

    apis_dir = output_dir / "src" / project_name / "apis"
    apis_dir.mkdir(parents=True, exist_ok=True)

    # 为每个标签生成一个客户端（使用 ASCII 标识符处理中文 tag）
    for tag, tag_endpoints in endpoints_by_tag.items():
        tag_id = to_ascii_identifier(tag)
        file_name = f"{tag_id}_api.py"
        file_path = apis_dir / file_name

        # 生成客户端代码
        content = _build_typed_client_code(tag, tag_id, tag_endpoints, project_name)

        try:
            create_file(file_path, content, force=force)
            generated.append(("API Client", file_path.relative_to(output_dir)))
        except FileExistsError:
            print(f"⚠️  客户端文件已存在（跳过）: {file_path.name}")

    return generated


def _build_typed_client_code(
    tag: str, tag_id: str, endpoints: list[APIEndpoint], project_name: str
) -> str:
    """构建类型化的 API 客户端代码

    Args:
        tag: 原始 tag 名称（用于注释）
        tag_id: ASCII 标识符（用于类名、fixture名、导入路径）
        endpoints: API 端点列表
        project_name: 项目名称

    v3.38.0 改进:
    - 导入 request/response 模型
    - 方法签名使用强类型
    - 利用 BaseAPI 自动序列化/解析
    """
    class_name = to_pascal_case(tag_id) + "API"
    fixture_name = tag_id + "_api"
    tag_snake = tag_id

    # 获取公共路径前缀
    paths = [e.path for e in endpoints]
    base_path = _get_common_path_prefix(paths)

    # 收集需要导入的模型
    request_models = set()
    response_models = set()

    for endpoint in endpoints:
        if endpoint.request_body:
            method_name = (
                to_snake_case(endpoint.operation_id) if endpoint.operation_id else "request"
            )
            request_models.add(to_pascal_case(method_name) + "Request")

        if endpoint.get_success_response():
            method_name = (
                to_snake_case(endpoint.operation_id) if endpoint.operation_id else "response"
            )
            response_models.add(to_pascal_case(method_name) + "Response")

    # 生成导入语句
    imports = []
    if request_models:
        imports.append(
            f"from ..models.requests.{tag_snake} import (\n    "
            + ",\n    ".join(sorted(request_models))
            + ",\n)"
        )
    if response_models:
        imports.append(
            f"from ..models.responses.{tag_snake} import (\n    "
            + ",\n    ".join(sorted(response_models))
            + ",\n)"
        )

    imports_code = "\n".join(imports) if imports else ""

    # 生成方法
    methods = []
    for endpoint in endpoints:
        method_code = _build_typed_method_code(endpoint, base_path)
        methods.append(method_code)

    code = f'''"""自动生成的 API 客户端 - {tag}

从 OpenAPI 规范生成，基于 df-test-framework v3.38.0 最佳实践。
类名: {class_name}
模块标识: {tag_id}

v3.38.0 特性:
- ✅ 强类型方法签名（Pydantic 请求/响应模型）
- ✅ BaseAPI 自动序列化请求模型
- ✅ BaseAPI 自动解析响应模型
- ✅ @api_class 装饰器自动注册 fixture
- ✅ IDE 智能提示和类型检查

使用示例:
    # 方式1: 直接实例化
    from {project_name}.models.requests.{tag_snake} import XxxRequest
    from {project_name}.models.responses.{tag_snake} import XxxResponse

    api = {class_name}(http_client)
    request = XxxRequest(field="value")
    response: XxxResponse = api.xxx_method(request)

    # 方式2: 使用 fixture（推荐）
    def test_example({fixture_name}):
        request = XxxRequest(field="value")
        response = {fixture_name}.xxx_method(request)
        assert response.code == 200
"""

from typing import Any

from df_test_framework import BaseAPI, HttpClient
from df_test_framework.testing.decorators import api_class

{imports_code}


@api_class("{fixture_name}", scope="function")
class {class_name}(BaseAPI):
    """{tag} API 客户端

    自动从 OpenAPI 规范生成。

    接口前缀: {base_path or "/"}
    Fixture 名称: {fixture_name}
    """

    def __init__(self, http_client: HttpClient):
        super().__init__(http_client)
        self.base_path = "{base_path}"

{chr(10).join(methods)}


__all__ = ["{class_name}"]
'''

    return code


def _build_typed_method_code(endpoint: APIEndpoint, base_path: str = "") -> str:
    """构建类型化的方法代码

    v3.38.0 改进:
    - request: XXXRequest 参数
    - -> XXXResponse 返回值
    - 使用 BaseAPI 的 model 参数
    """
    # 生成方法名
    if endpoint.operation_id:
        method_name = to_snake_case(endpoint.operation_id)
        # 移除 _using_get/post 等后缀
        for suffix in ["_using_get", "_using_post", "_using_put", "_using_delete", "_using_patch"]:
            if method_name.endswith(suffix):
                method_name = method_name[: -len(suffix)]
                break
    else:
        method_name = "unknown_method"

    # 路径参数
    path_params = endpoint.get_path_params()
    query_params = endpoint.get_query_params()

    # 请求模型
    request_model_name = None
    if endpoint.request_body:
        req_method_name = (
            to_snake_case(endpoint.operation_id) if endpoint.operation_id else "request"
        )
        request_model_name = to_pascal_case(req_method_name) + "Request"

    # 响应模型
    response_model_name = None
    if endpoint.get_success_response():
        resp_method_name = (
            to_snake_case(endpoint.operation_id) if endpoint.operation_id else "response"
        )
        response_model_name = to_pascal_case(resp_method_name) + "Response"

    # 构建方法参数
    params = []
    if path_params:
        params.extend([f"{p.name}: {_get_python_type(p.schema)}" for p in path_params])
    if request_model_name:
        params.append(f"request: {request_model_name}")
    elif endpoint.method.upper() in ["POST", "PUT", "PATCH"]:
        params.append("data: dict[str, Any] | None = None")
    if query_params:
        params.append("**kwargs: Any")

    params_str = ", ".join(params)

    # 返回类型
    return_type = response_model_name if response_model_name else "dict[str, Any]"

    # 构建相对路径
    path = endpoint.path
    if base_path and path.startswith(base_path):
        path = path[len(base_path) :]
    if not path:
        path = "/"

    # HTTP 方法
    http_method = endpoint.method.lower()

    # 生成文档字符串
    summary = endpoint.summary or method_name.replace("_", " ").title()
    doc_lines = [f'"""{summary}']

    if endpoint.description:
        doc_lines.append("")
        doc_lines.append(f"        {endpoint.description}")

    if params:
        doc_lines.append("")
        doc_lines.append("        Args:")
        for p in path_params:
            doc_lines.append(f"            {p.name}: {p.description or p.name}")
        if request_model_name:
            doc_lines.append(f"            request: {request_model_name} 请求模型")
        elif endpoint.method.upper() in ["POST", "PUT", "PATCH"]:
            doc_lines.append("            data: 请求数据")
        if query_params:
            doc_lines.append("            **kwargs: 查询参数")

    doc_lines.append("")
    doc_lines.append("        Returns:")
    doc_lines.append(f"            {return_type}: 响应数据")
    doc_lines.append('        """')

    doc = "\n".join(doc_lines)

    # 构建路径表达式
    if path_params:
        path_expr = f'f"{{self.base_path}}{path}"'
    else:
        path_expr = f'self.base_path + "{path}"'

    # 构建方法调用
    call_args = [path_expr]
    if request_model_name:
        call_args.append("json=request")
    elif endpoint.method.upper() in ["POST", "PUT", "PATCH"] and "data" in params_str:
        call_args.append("json=data")

    # 添加 model 参数（如果有响应模型）
    if response_model_name:
        call_args.append(f"model={response_model_name}")

    call_str = ", ".join(call_args)

    # 生成方法体
    if response_model_name:
        return_stmt = f"return self.{http_method}({call_str})"
    else:
        return_stmt = (
            f"response = self.http_client.{http_method}({call_str})\n        return response.json()"
        )

    code = f"""    def {method_name}(self{", " + params_str if params_str else ""}) -> {return_type}:
        {doc}
        {return_stmt}
"""

    return code


def _get_common_path_prefix(paths: list[str]) -> str:
    """获取路径列表的公共前缀"""
    if not paths:
        return ""

    # 将路径分割为部分
    split_paths = [p.split("/") for p in paths]
    if not split_paths:
        return ""

    # 找到公共前缀
    common = []
    for parts in zip(*split_paths):
        # 跳过路径参数 {id}
        if all(p == parts[0] and not p.startswith("{") for p in parts):
            common.append(parts[0])
        else:
            break

    return "/".join(common) if common else ""


# ========== Phase 3: 测试代码生成 ==========


def _generate_tests_v2(
    endpoints: list[APIEndpoint], project_name: str, output_dir: Path, force: bool
) -> list[tuple[str, Path]]:
    """生成测试用例

    v3.38.0 改进:
    - 使用类型化的 API 客户端
    - 更清晰的测试结构
    """
    generated: list[tuple[str, Path]] = []

    # 按标签分组
    endpoints_by_tag: dict[str, list[APIEndpoint]] = defaultdict(list)
    for endpoint in endpoints:
        tag = endpoint.tags[0] if endpoint.tags else "default"
        endpoints_by_tag[tag].append(endpoint)

    tests_dir = output_dir / "tests" / "api"
    tests_dir.mkdir(parents=True, exist_ok=True)

    # 为每个标签生成一个测试文件（使用 ASCII 标识符处理中文 tag）
    for tag, tag_endpoints in endpoints_by_tag.items():
        tag_id = to_ascii_identifier(tag)
        file_name = f"test_{tag_id}_api.py"
        file_path = tests_dir / file_name

        # 生成测试代码
        content = _build_typed_test_code(tag, tag_id, tag_endpoints, project_name)

        try:
            create_file(file_path, content, force=force)
            generated.append(("Test", file_path.relative_to(output_dir)))
        except FileExistsError:
            print(f"⚠️  测试文件已存在（跳过）: {file_path.name}")

    return generated


def _build_typed_test_code(
    tag: str, tag_id: str, endpoints: list[APIEndpoint], project_name: str
) -> str:
    """构建类型化的测试代码

    Args:
        tag: 原始 tag 名称（用于注释和 allure feature）
        tag_id: ASCII 标识符（用于类名、fixture名、导入路径）
        endpoints: API 端点列表
        project_name: 项目名称
    """
    class_name = "Test" + to_pascal_case(tag_id) + "API"
    api_client_name = to_pascal_case(tag_id) + "API"
    api_fixture_name = tag_id + "_api"
    tag_snake = tag_id

    # 生成测试方法
    test_methods = []
    for endpoint in endpoints:
        if endpoint.operation_id:
            api_method = to_snake_case(endpoint.operation_id)
            for suffix in ["_using_get", "_using_post", "_using_put", "_using_delete"]:
                if api_method.endswith(suffix):
                    api_method = api_method[: -len(suffix)]
                    break
        else:
            api_method = "unknown_method"

        method_code = _build_typed_test_method_code(endpoint, api_fixture_name, api_method)
        test_methods.append(method_code)

    code = f'''"""自动生成的测试文件 - {tag}

从 OpenAPI 规范生成，基于 df-test-framework v3.38.0 最佳实践。
测试类: {class_name}
模块标识: {tag_id}

v3.38.0 特性:
- ✅ 使用类型化的 API 客户端
- ✅ 强类型的请求/响应模型
- ✅ allure_observer 自动记录请求/响应
- ✅ cleanup 配置驱动数据清理
- ✅ DataGenerator 测试数据生成
- ✅ IDE 智能提示

使用方法:
    pytest tests/api/test_{tag_snake}_api.py -v

前置条件:
    在 conftest.py 中添加:
        from df_test_framework.testing.decorators import load_api_fixtures
        from {project_name}.apis.{tag_snake}_api import {api_client_name}  # noqa: F401
        load_api_fixtures(globals())
"""

import pytest
import allure
from assertpy import assert_that

from df_test_framework import attach_json, step, DataGenerator


@allure.feature("{tag}")
class {class_name}:
    """{tag} API 测试类

    自动从 OpenAPI 规范生成。

    Fixture 依赖 (v3.38.0+):
        - {api_fixture_name}: API 客户端（由 @api_class 自动注册）
        - cleanup: 数据清理管理器（框架自动注册）
        - allure_observer: Allure 观察者（框架自动注册，自动记录请求/响应）
    """

{chr(10).join(test_methods)}
'''

    return code


def _build_typed_test_method_code(endpoint: APIEndpoint, api_fixture: str, api_method: str) -> str:
    """构建类型化的测试方法代码（v3.38.0+）

    包含 v3.38.0 最佳实践：
    - allure_observer: 自动记录请求/响应
    - cleanup: 配置驱动数据清理（POST/PUT/DELETE 方法）
    - DataGenerator: 测试数据生成（创建操作）
    - skip_auth/token: 请求级别认证控制
    """
    test_name = f"test_{api_method}"
    summary = endpoint.summary or api_method.replace("_", " ").title()
    http_method = endpoint.method.upper()

    # 检查是否有请求体
    has_request_model = endpoint.request_body is not None

    # 判断是否需要数据清理（创建/修改/删除操作）
    needs_cleanup = http_method in ["POST", "PUT", "DELETE"]

    # 构建调用示例
    if has_request_model:
        req_method_name = (
            to_snake_case(endpoint.operation_id) if endpoint.operation_id else "request"
        )
        request_model = to_pascal_case(req_method_name) + "Request"

        # POST 请求添加数据生成示例
        if http_method == "POST":
            call_code = f"""# TODO: 根据实际需求构造请求数据
            # from {api_fixture.replace("_api", "")}.models.requests.{to_snake_case(endpoint.tags[0])} import {request_model}
            # test_id = DataGenerator.test_id("TEST")  # 生成唯一标识符
            # request = {request_model}(id=test_id, ...)
            # response = {api_fixture}.{api_method}(request)
            response = {api_fixture}.{api_method}(data={{}})"""
        else:
            call_code = f"""# TODO: 根据实际需求构造请求数据
            # from {api_fixture.replace("_api", "")}.models.requests.{to_snake_case(endpoint.tags[0])} import {request_model}
            # request = {request_model}(...)
            # response = {api_fixture}.{api_method}(request)
            response = {api_fixture}.{api_method}(data={{}})"""
    else:
        # GET 请求可能需要 skip_auth
        if http_method == "GET":
            call_code = f"""response = {api_fixture}.{api_method}()
            # 提示: 如需跳过认证，可使用 skip_auth=True
            # response = {api_fixture}.{api_method}(skip_auth=True)
            # 或使用自定义 token:
            # response = {api_fixture}.{api_method}(token="custom_token")"""
        else:
            call_code = f"response = {api_fixture}.{api_method}()"

    # 构建清理代码
    cleanup_code = ""
    if needs_cleanup and http_method == "POST":
        cleanup_code = """
        # TODO: 注册数据清理（创建操作需要清理）
        # cleanup.add("resource_type", test_id)  # 测试结束后自动清理"""

    # 构建完整的测试方法
    code = f'''    @allure.title("{summary}")
    @allure.severity(allure.severity_level.NORMAL)
    @pytest.mark.smoke
    def {test_name}(self, {api_fixture}, cleanup, allure_observer):
        """{summary}

        Args:
            {api_fixture}: API 客户端（自动注册）
            cleanup: 数据清理管理器（自动注册）
            allure_observer: Allure 观察者（自动记录请求/响应到报告）
        """
        with step("调用接口"):
            {call_code}
            # ✅ allure_observer 已自动记录请求/响应详情{cleanup_code}

        with step("验证响应"):
            # TODO: 根据实际响应结构添加断言
            # assert_that(response.code).is_equal_to(200)
            pass
'''

    return code


__all__ = ["generate_from_openapi"]
