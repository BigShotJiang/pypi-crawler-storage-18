from __future__ import annotations

import inspect
from abc import ABC, abstractmethod

from fastapi import FastAPI

from arp_standard_model import (
    Health,
    ToolDefinition,
    ToolInvocationResult,
    ToolRegistryGetToolRequest,
    ToolRegistryHealthRequest,
    ToolRegistryInvokeToolRequest,
    ToolRegistryListToolsRequest,
    ToolRegistryVersionRequest,
    VersionInfo,
)

from arp_standard_server.app import build_app
from .router import create_router


class BaseToolRegistryServer(ABC):
    @abstractmethod
    async def get_tool(self, request: ToolRegistryGetToolRequest) -> ToolDefinition:
        raise NotImplementedError

    @abstractmethod
    async def health(self, request: ToolRegistryHealthRequest) -> Health:
        raise NotImplementedError

    @abstractmethod
    async def invoke_tool(self, request: ToolRegistryInvokeToolRequest) -> ToolInvocationResult:
        raise NotImplementedError

    @abstractmethod
    async def list_tools(self, request: ToolRegistryListToolsRequest) -> list[ToolDefinition]:
        raise NotImplementedError

    @abstractmethod
    async def version(self, request: ToolRegistryVersionRequest) -> VersionInfo:
        raise NotImplementedError

    def create_app(
        self,
        *,
        title: str | None = None,
        api_key: str | None = None,
        api_key_header: str = "X-API-Key",
    ) -> FastAPI:
        if inspect.isabstract(self.__class__):
            raise TypeError(
                "BaseToolRegistryServer has unimplemented abstract methods. "
                "Implement all required endpoints before creating the app."
            )
        return build_app(
            router=create_router(self),
            title=title or "ARP Tool Registry Server",
            api_key=api_key,
            api_key_header=api_key_header,
        )
