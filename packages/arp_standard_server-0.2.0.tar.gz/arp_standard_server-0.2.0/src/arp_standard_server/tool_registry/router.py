from __future__ import annotations

from inspect import isawaitable
from typing import TYPE_CHECKING

from fastapi import APIRouter, Body, Path

from arp_standard_model import (
    Health,
    ToolDefinition,
    ToolInvocationRequestBody,
    ToolInvocationResult,
    ToolRegistryGetToolParams,
    ToolRegistryGetToolRequest,
    ToolRegistryHealthRequest,
    ToolRegistryInvokeToolRequest,
    ToolRegistryListToolsRequest,
    ToolRegistryVersionRequest,
    VersionInfo,
)


if TYPE_CHECKING:
    from .server import BaseToolRegistryServer

def create_router(server: BaseToolRegistryServer) -> APIRouter:
    router = APIRouter()

    @router.get("/v1/tools/{tool_id}", response_model=ToolDefinition, status_code=200)
    async def get_tool(
        tool_id: str = Path(..., alias="tool_id"),
    ) -> ToolDefinition:
        params = ToolRegistryGetToolParams(
            tool_id=tool_id,
        )
        request = ToolRegistryGetToolRequest(params=params)
        result = server.get_tool(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/health", response_model=Health, status_code=200)
    async def health(
    ) -> Health:
        request = ToolRegistryHealthRequest()
        result = server.health(request)
        if isawaitable(result):
            result = await result
        return result

    @router.post("/v1/tool-invocations", response_model=ToolInvocationResult, status_code=200)
    async def invoke_tool(
        body: ToolInvocationRequestBody = Body(...),
    ) -> ToolInvocationResult:
        request = ToolRegistryInvokeToolRequest(body=body)
        result = server.invoke_tool(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/tools", response_model=list[ToolDefinition], status_code=200)
    async def list_tools(
    ) -> list[ToolDefinition]:
        request = ToolRegistryListToolsRequest()
        result = server.list_tools(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/version", response_model=VersionInfo, status_code=200)
    async def version(
    ) -> VersionInfo:
        request = ToolRegistryVersionRequest()
        result = server.version(request)
        if isawaitable(result):
            result = await result
        return result

    return router
