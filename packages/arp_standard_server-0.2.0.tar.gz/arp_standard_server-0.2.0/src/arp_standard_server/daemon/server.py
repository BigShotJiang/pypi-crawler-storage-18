from __future__ import annotations

import inspect
from abc import ABC, abstractmethod

from fastapi import FastAPI

from arp_standard_model import (
    DaemonCreateInstancesRequest,
    DaemonDeleteInstanceRequest,
    DaemonDeleteRuntimeProfileRequest,
    DaemonGetRunResultRequest,
    DaemonGetRunStatusRequest,
    DaemonGetRunTraceRequest,
    DaemonHealthRequest,
    DaemonListInstancesRequest,
    DaemonListRunsRequest,
    DaemonListRuntimeProfilesRequest,
    DaemonRegisterInstanceRequest,
    DaemonSubmitRunRequest,
    DaemonUpsertRuntimeProfileRequest,
    DaemonVersionRequest,
    Health,
    InstanceCreateResponse,
    InstanceListResponse,
    InstanceRegisterResponse,
    RunListResponse,
    RunResult,
    RunStatus,
    RuntimeProfile,
    RuntimeProfileListResponse,
    TraceResponse,
    VersionInfo,
)

from arp_standard_server.app import build_app
from .router import create_router


class BaseDaemonServer(ABC):
    @abstractmethod
    async def create_instances(self, request: DaemonCreateInstancesRequest) -> InstanceCreateResponse:
        raise NotImplementedError

    @abstractmethod
    async def delete_instance(self, request: DaemonDeleteInstanceRequest) -> None:
        raise NotImplementedError

    @abstractmethod
    async def delete_runtime_profile(self, request: DaemonDeleteRuntimeProfileRequest) -> None:
        raise NotImplementedError

    @abstractmethod
    async def get_run_result(self, request: DaemonGetRunResultRequest) -> RunResult:
        raise NotImplementedError

    @abstractmethod
    async def get_run_status(self, request: DaemonGetRunStatusRequest) -> RunStatus:
        raise NotImplementedError

    @abstractmethod
    async def get_run_trace(self, request: DaemonGetRunTraceRequest) -> TraceResponse:
        raise NotImplementedError

    @abstractmethod
    async def health(self, request: DaemonHealthRequest) -> Health:
        raise NotImplementedError

    @abstractmethod
    async def list_instances(self, request: DaemonListInstancesRequest) -> InstanceListResponse:
        raise NotImplementedError

    @abstractmethod
    async def list_runs(self, request: DaemonListRunsRequest) -> RunListResponse:
        raise NotImplementedError

    @abstractmethod
    async def list_runtime_profiles(self, request: DaemonListRuntimeProfilesRequest) -> RuntimeProfileListResponse:
        raise NotImplementedError

    @abstractmethod
    async def register_instance(self, request: DaemonRegisterInstanceRequest) -> InstanceRegisterResponse:
        raise NotImplementedError

    @abstractmethod
    async def submit_run(self, request: DaemonSubmitRunRequest) -> RunStatus:
        raise NotImplementedError

    @abstractmethod
    async def upsert_runtime_profile(self, request: DaemonUpsertRuntimeProfileRequest) -> RuntimeProfile:
        raise NotImplementedError

    @abstractmethod
    async def version(self, request: DaemonVersionRequest) -> VersionInfo:
        raise NotImplementedError

    def create_app(
        self,
        *,
        title: str | None = None,
        api_key: str | None = None,
        api_key_header: str = "X-API-Key",
    ) -> FastAPI:
        if inspect.isabstract(self.__class__):
            raise TypeError(
                "BaseDaemonServer has unimplemented abstract methods. "
                "Implement all required endpoints before creating the app."
            )
        return build_app(
            router=create_router(self),
            title=title or "ARP Daemon Server",
            api_key=api_key,
            api_key_header=api_key_header,
        )
