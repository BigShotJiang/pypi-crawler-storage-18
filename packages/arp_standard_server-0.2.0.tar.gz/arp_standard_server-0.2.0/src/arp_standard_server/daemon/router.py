from __future__ import annotations

from inspect import isawaitable
from typing import TYPE_CHECKING

from fastapi import APIRouter, Body, Query, Path

from arp_standard_model import (
    DaemonCreateInstancesRequest,
    DaemonDeleteInstanceParams,
    DaemonDeleteInstanceRequest,
    DaemonDeleteRuntimeProfileParams,
    DaemonDeleteRuntimeProfileRequest,
    DaemonGetRunResultParams,
    DaemonGetRunResultRequest,
    DaemonGetRunStatusParams,
    DaemonGetRunStatusRequest,
    DaemonGetRunTraceParams,
    DaemonGetRunTraceRequest,
    DaemonHealthRequest,
    DaemonListInstancesRequest,
    DaemonListRunsParams,
    DaemonListRunsRequest,
    DaemonListRuntimeProfilesRequest,
    DaemonRegisterInstanceRequest,
    DaemonSubmitRunRequest,
    DaemonUpsertRuntimeProfileParams,
    DaemonUpsertRuntimeProfileRequest,
    DaemonVersionRequest,
    Health,
    InstanceCreateRequestBody,
    InstanceCreateResponse,
    InstanceListResponse,
    InstanceRegisterRequestBody,
    InstanceRegisterResponse,
    RunListResponse,
    RunRequestBody,
    RunResult,
    RunStatus,
    RuntimeProfile,
    RuntimeProfileListResponse,
    RuntimeProfileUpsertRequestBody,
    TraceResponse,
    VersionInfo,
)


if TYPE_CHECKING:
    from .server import BaseDaemonServer

def create_router(server: BaseDaemonServer) -> APIRouter:
    router = APIRouter()

    @router.post("/v1/instances", response_model=InstanceCreateResponse, status_code=200)
    async def create_instances(
        body: InstanceCreateRequestBody = Body(...),
    ) -> InstanceCreateResponse:
        request = DaemonCreateInstancesRequest(body=body)
        result = server.create_instances(request)
        if isawaitable(result):
            result = await result
        return result

    @router.delete("/v1/instances/{instance_id}", status_code=204)
    async def delete_instance(
        instance_id: str = Path(..., alias="instance_id"),
    ) -> None:
        params = DaemonDeleteInstanceParams(
            instance_id=instance_id,
        )
        request = DaemonDeleteInstanceRequest(params=params)
        result = server.delete_instance(request)
        if isawaitable(result):
            result = await result
        return None

    @router.delete("/v1/admin/runtime-profiles/{runtime_profile}", status_code=204)
    async def delete_runtime_profile(
        runtime_profile: str = Path(..., alias="runtime_profile"),
    ) -> None:
        params = DaemonDeleteRuntimeProfileParams(
            runtime_profile=runtime_profile,
        )
        request = DaemonDeleteRuntimeProfileRequest(params=params)
        result = server.delete_runtime_profile(request)
        if isawaitable(result):
            result = await result
        return None

    @router.get("/v1/runs/{run_id}/result", response_model=RunResult, status_code=200)
    async def get_run_result(
        run_id: str = Path(..., alias="run_id"),
    ) -> RunResult:
        params = DaemonGetRunResultParams(
            run_id=run_id,
        )
        request = DaemonGetRunResultRequest(params=params)
        result = server.get_run_result(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs/{run_id}", response_model=RunStatus, status_code=200)
    async def get_run_status(
        run_id: str = Path(..., alias="run_id"),
    ) -> RunStatus:
        params = DaemonGetRunStatusParams(
            run_id=run_id,
        )
        request = DaemonGetRunStatusRequest(params=params)
        result = server.get_run_status(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs/{run_id}/trace", response_model=TraceResponse, status_code=200)
    async def get_run_trace(
        run_id: str = Path(..., alias="run_id"),
    ) -> TraceResponse:
        params = DaemonGetRunTraceParams(
            run_id=run_id,
        )
        request = DaemonGetRunTraceRequest(params=params)
        result = server.get_run_trace(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/health", response_model=Health, status_code=200)
    async def health(
    ) -> Health:
        request = DaemonHealthRequest()
        result = server.health(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/instances", response_model=InstanceListResponse, status_code=200)
    async def list_instances(
    ) -> InstanceListResponse:
        request = DaemonListInstancesRequest()
        result = server.list_instances(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs", response_model=RunListResponse, status_code=200)
    async def list_runs(
        page_size: int | None = Query(None, alias="page_size"),
        page_token: str | None = Query(None, alias="page_token"),
    ) -> RunListResponse:
        params = DaemonListRunsParams(
            page_size=page_size,
            page_token=page_token,
        )
        request = DaemonListRunsRequest(params=params)
        result = server.list_runs(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/admin/runtime-profiles", response_model=RuntimeProfileListResponse, status_code=200)
    async def list_runtime_profiles(
    ) -> RuntimeProfileListResponse:
        request = DaemonListRuntimeProfilesRequest()
        result = server.list_runtime_profiles(request)
        if isawaitable(result):
            result = await result
        return result

    @router.post("/v1/instances:register", response_model=InstanceRegisterResponse, status_code=200)
    async def register_instance(
        body: InstanceRegisterRequestBody = Body(...),
    ) -> InstanceRegisterResponse:
        request = DaemonRegisterInstanceRequest(body=body)
        result = server.register_instance(request)
        if isawaitable(result):
            result = await result
        return result

    @router.post("/v1/runs", response_model=RunStatus, status_code=202)
    async def submit_run(
        body: RunRequestBody = Body(...),
    ) -> RunStatus:
        request = DaemonSubmitRunRequest(body=body)
        result = server.submit_run(request)
        if isawaitable(result):
            result = await result
        return result

    @router.put("/v1/admin/runtime-profiles/{runtime_profile}", response_model=RuntimeProfile, status_code=200)
    async def upsert_runtime_profile(
        runtime_profile: str = Path(..., alias="runtime_profile"),
        body: RuntimeProfileUpsertRequestBody = Body(...),
    ) -> RuntimeProfile:
        params = DaemonUpsertRuntimeProfileParams(
            runtime_profile=runtime_profile,
        )
        request = DaemonUpsertRuntimeProfileRequest(params=params, body=body)
        result = server.upsert_runtime_profile(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/version", response_model=VersionInfo, status_code=200)
    async def version(
    ) -> VersionInfo:
        request = DaemonVersionRequest()
        result = server.version(request)
        if isawaitable(result):
            result = await result
        return result

    return router
