from __future__ import annotations

from inspect import isawaitable
from typing import TYPE_CHECKING

from fastapi import APIRouter, Body, Path

from arp_standard_model import (
    Health,
    RunRequestBody,
    RunResult,
    RunStatus,
    RuntimeCancelRunParams,
    RuntimeCancelRunRequest,
    RuntimeCreateRunRequest,
    RuntimeGetRunResultParams,
    RuntimeGetRunResultRequest,
    RuntimeGetRunStatusParams,
    RuntimeGetRunStatusRequest,
    RuntimeHealthRequest,
    RuntimeStreamRunEventsParams,
    RuntimeStreamRunEventsRequest,
    RuntimeVersionRequest,
    VersionInfo,
)


if TYPE_CHECKING:
    from .server import BaseRuntimeServer

def create_router(server: BaseRuntimeServer) -> APIRouter:
    router = APIRouter()

    @router.post("/v1/runs/{run_id}:cancel", response_model=RunStatus, status_code=200)
    async def cancel_run(
        run_id: str = Path(..., alias="run_id"),
    ) -> RunStatus:
        params = RuntimeCancelRunParams(
            run_id=run_id,
        )
        request = RuntimeCancelRunRequest(params=params)
        result = server.cancel_run(request)
        if isawaitable(result):
            result = await result
        return result

    @router.post("/v1/runs", response_model=RunStatus, status_code=200)
    async def create_run(
        body: RunRequestBody = Body(...),
    ) -> RunStatus:
        request = RuntimeCreateRunRequest(body=body)
        result = server.create_run(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs/{run_id}/result", response_model=RunResult, status_code=200)
    async def get_run_result(
        run_id: str = Path(..., alias="run_id"),
    ) -> RunResult:
        params = RuntimeGetRunResultParams(
            run_id=run_id,
        )
        request = RuntimeGetRunResultRequest(params=params)
        result = server.get_run_result(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs/{run_id}", response_model=RunStatus, status_code=200)
    async def get_run_status(
        run_id: str = Path(..., alias="run_id"),
    ) -> RunStatus:
        params = RuntimeGetRunStatusParams(
            run_id=run_id,
        )
        request = RuntimeGetRunStatusRequest(params=params)
        result = server.get_run_status(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/health", response_model=Health, status_code=200)
    async def health(
    ) -> Health:
        request = RuntimeHealthRequest()
        result = server.health(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/runs/{run_id}/events", response_model=str, status_code=200)
    async def stream_run_events(
        run_id: str = Path(..., alias="run_id"),
    ) -> str:
        params = RuntimeStreamRunEventsParams(
            run_id=run_id,
        )
        request = RuntimeStreamRunEventsRequest(params=params)
        result = server.stream_run_events(request)
        if isawaitable(result):
            result = await result
        return result

    @router.get("/v1/version", response_model=VersionInfo, status_code=200)
    async def version(
    ) -> VersionInfo:
        request = RuntimeVersionRequest()
        result = server.version(request)
        if isawaitable(result):
            result = await result
        return result

    return router
