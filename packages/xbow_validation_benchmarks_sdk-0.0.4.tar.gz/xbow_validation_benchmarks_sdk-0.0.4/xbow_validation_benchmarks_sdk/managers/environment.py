import shutil
import subprocess
import uuid
from pathlib import Path

import portpicker
import yaml

from xbow_validation_benchmarks_sdk.models.benchmark import Benchmark
from xbow_validation_benchmarks_sdk.models.benchmark import WinCondition
from xbow_validation_benchmarks_sdk.models.environment import Environment
from xbow_validation_benchmarks_sdk.models.environment import Target


class EnvironmentManager:
    def __init__(self, xbow_benchmark_folder: Path, public_accessible_host: str) -> None:
        self.xbow_benchmark_folder = xbow_benchmark_folder
        self.public_accessible_host = public_accessible_host

    def create_environment(self, benchmark: Benchmark, flag: str) -> Environment:
        if benchmark.win_condition != WinCondition.FLAG:
            raise ValueError('Benchmark win condition must be FLAG')

        environment_id = str(uuid.uuid4())
        benchmark_path = self.xbow_benchmark_folder / 'benchmarks' / benchmark.id
        environment_path = Path('environments') / benchmark.id / environment_id
        environment_path.mkdir(parents=True, exist_ok=True)

        shutil.copytree(benchmark_path, environment_path)

        environment_docker_compose_path = environment_path / 'docker-compose.yml'
        with open(environment_docker_compose_path) as f:
            environment_docker_compose_object = yaml.safe_load(f)

        unused_host_ports = []
        for service in environment_docker_compose_object.get('services', {}).values():
            new_ports = []
            for ports in service.get('ports', []):
                if isinstance(ports, str) and ':' in ports:
                    unused_host_port = portpicker.pick_unused_port()
                    unused_host_ports.append(unused_host_port)
                    parts = ports.split(':')
                    new_ports.append(f"{unused_host_port}:{parts[-1]}")
                else:
                    new_ports.append(ports)
            service['ports'] = new_ports

        with open(environment_docker_compose_path, 'w') as f:
            yaml.dump(environment_docker_compose_object, f)

        return Environment(
            id=environment_id,
            path=environment_path,
            benchmark=benchmark,
            flag=flag,
            targets=[
                Target(
                    host=self.public_accessible_host, port=unused_port,
                ) for unused_port in unused_host_ports
            ],
        )

    def destroy_environment(self, environment: Environment):
        shutil.rmtree(
            Path('environments') /
            environment.benchmark.id / environment.id,
        )

    def start_environment(self, environment: Environment):
        subprocess.run(
            [
                'docker-compose', '-f', environment.path /
                'docker-compose.yml', 'up', '-d',
            ], check=True,
        )

    def stop_environment(self, environment: Environment):
        subprocess.run(
            [
                'docker-compose', '-f', environment.path /
                'docker-compose.yml', 'down',
            ], check=True,
        )
