"""Email-to-EML Secure Archiver"""
__version__ = "0.2.0"
