<!--
Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com

This work is licensed under the Creative Commons Attribution-ShareAlike 4.0
International License. To view a copy of this license, visit
http://creativecommons.org/licenses/by-sa/4.0/ or send a letter to Creative
Commons, PO Box 1866, Mountain View, CA 94042, USA.
-->

<!--
Changelog titles are:
- Added: for new features.
- Changed: for changes in existing functionality.
- Deprecated: for soon-to-be removed features.
- Removed: for now removed features.
- Fixed: for any bug fixes.
- Security: in case of vulnerabilities.
-->

# Changelog

All notable changes of this project will be documented here.

The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.0.0)
and this project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Version 3.0.0 (December 2025)

### Added

- Support for GEMSEO v6.3.
- Support for Python 3.13.

### Changed

- BREAKING CHANGE:
    - Return 404 error instead of 204 when a discipline is not found.
- Improved error messages for the client.

### Removed

- Support for Python 3.9.

## Version 2.0.0 (August 2025)

### Added

- Support GEMSEO v6.

## Version 1.0.0 (June 2025)

### Added

- Initial release.
