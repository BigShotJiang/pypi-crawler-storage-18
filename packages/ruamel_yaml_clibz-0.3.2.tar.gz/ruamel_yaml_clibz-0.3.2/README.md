
# ruamel.yaml.clibz

`ruamel.yaml.clibz` is a C based reader/scanner and emitter for ruamel.yaml
based on the same sources as `ruamel.yaml.clib`, but compiled using Zig (with the
packages `setuptools-zig` and `ziglang`).

The intention is to only distribute this package as .tar.gz, allowing
for optimised compilation according to your machine's specific architecture and 
capabilities, instead of some (low performance) common denominator. 

**Please do not create binary distributions of this package (`.whl` nor 
packages for specific Linux installers).**

<table class="docutils">
  <tr>
    <td>version</td>
    <td>0.3.2</td>
  </tr>
  <tr>
    <td>updated</td>
    <td>2025-12-23</td>
  </tr>
  <tr>
    <td>documentation</td>
    <td><a href="https://yaml.dev/doc/ruamel.yaml.clibz">https://yaml.dev/doc/ruamel.yaml.clibz</a></td>
  </tr>
  <tr>
    <td>repository</td>
    <td><a href="https://sourceforge.net/projects/ruamel-yaml-clibz/">https://sourceforge.net/projects/ruamel-yaml-clibz/</a></td>
  </tr>
  <tr>
    <td>pypi</td>
    <td><a href="https://pypi.org/project/ruamel.yaml.clibz/">https://pypi.org/project/ruamel.yaml.clibz/</a></td>
  </tr>
</table>


This package was split of from ruamel.yaml, so that ruamel.yaml can be
build as a universal wheel. Apart from the C code seldom changing, and
taking a long time to compile for all platforms, this allows
installation of the .so on Linux systems under /usr/lib64/pythonX.Y
(without a .pth file or a ruamel directory) and the Python code for
ruamel.yaml under /usr/lib/pythonX.Y.
Using Zig as the toolchain, 
installed using the `ziglang` package, 
no (other) development environment installations
should be necessary.


[![image](https://sourceforge.net/p/ruamel-yaml-clibz/code/ci/default/tree/_doc/_static/license.svg?format=raw)](https://opensource.org/licenses/MIT)
[![image](https://sourceforge.net/p/ruamel-yaml-clibz/code/ci/default/tree/_doc/_static/pypi.svg?format=raw)](https://pypi.org/project/ruamel.yaml.clibz/)

This release in loving memory of 
Johanna Clasina van der Neut-Bandel \[1922-10-19 – 2015-11-21\] and 
Jan van der Neut \[1919-12-01 – 1998-11-19\]. 

Klaus E. \[1938-04-25 – 2025-11-01\],
thanx for your help and trust, I do miss "Und was macht Coco?".
