import click
import subprocess
import shutil
import platform
import os
import sys
from pathlib import Path
from .config_parser import CppProjectConfig

@click.group()
def cli():
    pass

def _setup_global_command():
    system = platform.system()

    if system == "Windows":
        bin_dir = Path(os.environ.get('LOCALAPPDATA', os.path.expanduser('~\\AppData\\Local'))) / 'IncludeCPP' / 'bin'
        bin_dir.mkdir(parents=True, exist_ok=True)

        script_path = bin_dir / 'includecpp.bat'
        with open(script_path, 'w') as f:
            f.write('@echo off\n')
            f.write(f'"{sys.executable}" -m includecpp %*\n')

        current_path = os.environ.get('PATH', '')
        bin_dir_str = str(bin_dir)

        if bin_dir_str not in current_path:
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Environment', 0, winreg.KEY_ALL_ACCESS)
                try:
                    user_path, _ = winreg.QueryValueEx(key, 'PATH')
                except FileNotFoundError:
                    user_path = ''

                if bin_dir_str not in user_path:
                    new_path = f"{user_path};{bin_dir_str}" if user_path else bin_dir_str
                    winreg.SetValueEx(key, 'PATH', 0, winreg.REG_EXPAND_SZ, new_path)
                    click.secho(f"Added {bin_dir} to user PATH", fg='green')
                    click.echo("Restart your terminal for the change to take effect")
                    winreg.CloseKey(key)
                    return True
            except Exception as e:
                click.secho(f"Warning: Could not update PATH automatically: {e}", fg='yellow')
                click.echo(f"Please manually add {bin_dir} to your PATH")
                return False

        click.secho(f"Global command 'includecpp' is ready at {script_path}", fg='green')
        return True

    elif system in ["Linux", "Darwin"]:
        bin_dir = Path.home() / '.local' / 'bin'
        bin_dir.mkdir(parents=True, exist_ok=True)

        script_path = bin_dir / 'includecpp'
        with open(script_path, 'w') as f:
            f.write('#!/usr/bin/env bash\n')
            f.write(f'exec "{sys.executable}" -m includecpp "$@"\n')

        script_path.chmod(0o755)

        current_path = os.environ.get('PATH', '')
        bin_dir_str = str(bin_dir)

        if bin_dir_str in current_path:
            click.secho(f"Global command 'includecpp' is ready at {script_path}", fg='green')
        else:
            click.secho(f"Created wrapper script at {script_path}", fg='green')
            click.echo(f"Add {bin_dir} to your PATH by adding this to ~/.bashrc or ~/.zshrc:")
            click.echo(f'  export PATH="$PATH:{bin_dir}"')

        return True

    return False

@cli.command()
def init():
    config_file = Path.cwd() / "cpp.proj"
    if config_file.exists():
        click.echo("cpp.proj already exists")
        return

    CppProjectConfig.create_default('cpp.proj')
    click.echo("Created cpp.proj configuration")
    click.echo("Created include/ directory")
    click.echo("Created plugins/ directory")

    marker_file = Path.home() / '.includecpp_global_setup'
    if not marker_file.exists():
        click.echo()
        if _setup_global_command():
            marker_file.touch()
            click.echo()
            click.echo("You can now use 'includecpp <command>' instead of 'python -m includecpp <command>'")

def _show_build_info_report(build_dir: Path, compiler: str):
    """Show detailed analysis report of the last build."""
    import json
    from datetime import datetime

    registry_path = build_dir / "module_registry.json"

    # Check if build exists
    if not build_dir.exists() or not registry_path.exists():
        click.echo("")
        click.secho("╔══════════════════════════════════════════════════════════════╗", fg='yellow')
        click.secho("║ NO BUILD FOUND                                               ║", fg='yellow')
        click.secho("╚══════════════════════════════════════════════════════════════╝", fg='yellow')
        click.echo("")
        click.echo("No previous build found. Run 'includecpp rebuild' first.")
        click.echo("")
        return

    # Load registry
    try:
        with open(registry_path, 'r') as f:
            registry = json.load(f)
    except Exception as e:
        click.secho(f"Error reading registry: {e}", fg='red', err=True)
        return

    modules = registry.get('modules', {})
    if not modules:
        click.echo("No modules found in registry.")
        return

    # Collect statistics
    total_modules = len(modules)
    total_functions = 0
    total_classes = 0
    total_structs = 0
    total_methods = 0
    total_bindings = 0

    for mod_info in modules.values():
        funcs = mod_info.get('functions', [])
        classes = mod_info.get('classes', [])
        structs = mod_info.get('structs', [])

        total_functions += len(funcs)
        total_classes += len(classes)
        total_structs += len(structs)

        for cls in classes:
            if isinstance(cls, dict):
                total_methods += len(cls.get('methods', []))

        # Count bindings (functions + methods + class constructors)
        total_bindings += len(funcs)
        for cls in classes:
            if isinstance(cls, dict):
                total_bindings += len(cls.get('methods', [])) + 1  # +1 for constructor

    # Check for .pyd/.so files
    pyd_files = list(build_dir.glob("*.pyd")) + list(build_dir.glob("*.so"))

    # Check for .pyi stub files
    pyi_files = list(build_dir.glob("*.pyi"))

    # Get last build time from registry file modification time
    last_build_time = datetime.fromtimestamp(registry_path.stat().st_mtime)
    time_ago = datetime.now() - last_build_time
    if time_ago.days > 0:
        time_str = f"{time_ago.days} day(s) ago"
    elif time_ago.seconds >= 3600:
        time_str = f"{time_ago.seconds // 3600} hour(s) ago"
    elif time_ago.seconds >= 60:
        time_str = f"{time_ago.seconds // 60} minute(s) ago"
    else:
        time_str = f"{time_ago.seconds} second(s) ago"

    # Print report header
    click.echo("")
    click.secho("╔══════════════════════════════════════════════════════════════╗", fg='cyan')
    click.secho("║ IncludeCPP Build Analysis Report                             ║", fg='cyan')
    click.secho("╚══════════════════════════════════════════════════════════════╝", fg='cyan')
    click.echo("")

    # Build Info Section
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='blue')
    click.secho("│ Build Information                                           │", fg='blue')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='blue')
    click.echo(f"  Build Directory: {build_dir}")
    click.echo(f"  Compiler:        {compiler}")
    click.echo(f"  Last Build:      {last_build_time.strftime('%Y-%m-%d %H:%M:%S')} ({time_str})")
    click.echo("")

    # Statistics Section
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='green')
    click.secho("│ Build Statistics                                            │", fg='green')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='green')
    click.echo(f"  Modules:         {total_modules}")
    click.echo(f"  Functions:       {total_functions}")
    click.echo(f"  Classes:         {total_classes}")
    click.echo(f"  Structs:         {total_structs}")
    click.echo(f"  Methods:         {total_methods}")
    click.echo(f"  Total Bindings:  {total_bindings}")
    click.echo("")

    # Compiled Modules Section
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='magenta')
    click.secho("│ Compiled Modules                                            │", fg='magenta')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='magenta')

    for mod_name, mod_info in modules.items():
        funcs = mod_info.get('functions', [])
        classes = mod_info.get('classes', [])
        structs = mod_info.get('structs', [])

        # Check if .pyd exists
        pyd_path = build_dir / f"{mod_name}.pyd"
        so_path = build_dir / f"{mod_name}.so"
        has_binary = pyd_path.exists() or so_path.exists()

        status_icon = click.style("✓", fg='green') if has_binary else click.style("✗", fg='red')
        click.echo(f"  {status_icon} {mod_name}")

        # Show source files
        sources = mod_info.get('sources', [])
        if sources:
            click.echo(f"      Sources: {', '.join(sources)}")

        # Show dependencies
        deps = mod_info.get('depends', [])
        if deps:
            click.echo(f"      Depends: {', '.join(deps)}")

        # Summary line
        summary_parts = []
        if funcs:
            summary_parts.append(f"{len(funcs)} function(s)")
        if classes:
            summary_parts.append(f"{len(classes)} class(es)")
        if structs:
            summary_parts.append(f"{len(structs)} struct(s)")

        if summary_parts:
            click.echo(f"      Exports: {', '.join(summary_parts)}")
        click.echo("")

    # Bindings Details Section
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='yellow')
    click.secho("│ Bindings Details                                            │", fg='yellow')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='yellow')

    for mod_name, mod_info in modules.items():
        click.secho(f"  {mod_name}:", fg='cyan')

        # Functions
        funcs = mod_info.get('functions', [])
        if funcs:
            click.echo("    Functions:")
            for func in funcs:
                if isinstance(func, dict):
                    name = func.get('name', 'unknown')
                    return_type = func.get('return_type', 'void')
                    params = func.get('params', [])
                    param_str = ', '.join(params) if params else ''
                    click.echo(f"      → {return_type} {name}({param_str})")
                else:
                    click.echo(f"      → {func}")

        # Classes
        classes = mod_info.get('classes', [])
        if classes:
            click.echo("    Classes:")
            for cls in classes:
                if isinstance(cls, dict):
                    cls_name = cls.get('name', 'unknown')
                    methods = cls.get('methods', [])
                    click.secho(f"      ▶ {cls_name}", fg='green')
                    for method in methods:
                        if isinstance(method, dict):
                            m_name = method.get('name', 'unknown')
                            m_return = method.get('return_type', 'void')
                            m_params = method.get('params', [])
                            param_str = ', '.join(m_params) if m_params else ''
                            click.echo(f"          .{m_name}({param_str}) → {m_return}")
                        else:
                            click.echo(f"          .{method}()")
                else:
                    click.echo(f"      ▶ {cls}")

        # Structs
        structs = mod_info.get('structs', [])
        if structs:
            click.echo("    Structs:")
            for struct in structs:
                if isinstance(struct, dict):
                    s_name = struct.get('name', 'unknown')
                    fields = struct.get('fields', [])
                    click.secho(f"      ◆ {s_name}", fg='yellow')
                    for field in fields:
                        if isinstance(field, dict):
                            f_name = field.get('name', 'unknown')
                            f_type = field.get('type', 'unknown')
                            click.echo(f"          .{f_name}: {f_type}")
                        else:
                            click.echo(f"          .{field}")
                else:
                    click.echo(f"      ◆ {struct}")

        click.echo("")

    # Output Files Section
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='white')
    click.secho("│ Output Files                                                │", fg='white')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='white')

    click.echo("  Binary Modules (.pyd/.so):")
    if pyd_files:
        for pyd in pyd_files:
            size_kb = pyd.stat().st_size / 1024
            click.secho(f"    ✓ {pyd.name}", fg='green', nl=False)
            click.echo(f" ({size_kb:.1f} KB)")
    else:
        click.secho("    (none found)", fg='yellow')

    click.echo("")
    click.echo("  Type Stubs (.pyi):")
    if pyi_files:
        for pyi in pyi_files:
            click.secho(f"    ✓ {pyi.name}", fg='green')
    else:
        click.secho("    (none found)", fg='yellow')

    click.echo("")

    # Usage Example
    click.secho("┌─────────────────────────────────────────────────────────────┐", fg='cyan')
    click.secho("│ Usage Example                                               │", fg='cyan')
    click.secho("└─────────────────────────────────────────────────────────────┘", fg='cyan')

    if modules:
        first_mod = list(modules.keys())[0]
        first_info = modules[first_mod]
        first_func = None
        if first_info.get('functions'):
            f = first_info['functions'][0]
            first_func = f.get('name', f) if isinstance(f, dict) else f

        click.echo(f"  from {first_mod} import {first_func or 'your_function'}")
        click.echo(f"  result = {first_func or 'your_function'}(...)")

    click.echo("")
    click.secho("═" * 64, fg='cyan')
    click.echo("")


@cli.command()
@click.option('--clean', is_flag=True, help='Force clean rebuild (ignore incremental)')
@click.option('--full', is_flag=True, help='Complete rebuild including plugin_gen.exe and all caches')
@click.option('--verbose', is_flag=True, help='Verbose output')
@click.option('--no-incremental', is_flag=True, help='Disable incremental builds')
@click.option('--incremental', is_flag=True, help='Explicitly enable incremental builds (default: auto)')
@click.option('--parallel/--no-parallel', default=True, help='Enable/disable parallel compilation (default: enabled)')
@click.option('--jobs', '-j', type=int, default=4, help='Max parallel jobs (default: 4)')
@click.option('--modules', '-m', multiple=True, help='Specific modules to rebuild')
@click.option('--this', 'build_paths', multiple=True, type=click.Path(exists=True),
              help='Build only from specific paths (can specify multiple)')
@click.option('--fast', 'fast_plugin', type=str, default=None,
              help='Fast incremental rebuild of single plugin (e.g., algorithms.cp)')
@click.option('--all', 'fast_all', is_flag=True, help='With --fast: rebuild all plugins incrementally')
@click.option('--info', is_flag=True, help='Show detailed analysis report of the last build')
def rebuild(clean, full, verbose, no_incremental, incremental, parallel, jobs, modules,
            build_paths, fast_plugin, fast_all, info):
    """v2.0: Rebuild C++ modules with incremental and parallel support."""
    from ..core.build_manager import BuildManager
    from ..core.error_formatter import BuildErrorFormatter, BuildSuccessFormatter
    import time
    import json
    from datetime import datetime

    project_root = Path.cwd()
    config = CppProjectConfig()

    compiler = detect_compiler()
    build_dir = config.get_build_dir(compiler)

    # Handle --info flag: Show detailed build analysis report
    if info:
        _show_build_info_report(build_dir, compiler)
        return

    # Full rebuild: delete everything including generator
    if full and build_dir.exists():
        click.echo("Full rebuild: Deleting entire build directory including plugin_gen.exe...")
        shutil.rmtree(build_dir)
        clean = True  # Force clean mode

    # Clean if requested
    elif clean and build_dir.exists():
        click.echo("Cleaning build directory...")
        shutil.rmtree(build_dir)

    build_dir.mkdir(parents=True, exist_ok=True)
    config.update_base_dir(build_dir)

    click.echo(f"Build directory: {build_dir}")

    if incremental and no_incremental:
        click.secho("Error: Cannot use both --incremental and --no-incremental", fg='red', err=True)
        raise click.Abort()

    if clean and incremental:
        click.secho("Warning: --clean overrides --incremental", fg='yellow')
        incremental = False

    if fast_plugin and build_paths:
        click.secho("Error: Cannot use both --fast and --this", fg='red', err=True)
        raise click.Abort()

    if fast_all and not fast_plugin:
        click.secho("Error: --all requires --fast <plugin>", fg='red', err=True)
        raise click.Abort()

    final_incremental = True
    if incremental:
        final_incremental = True
    elif no_incremental or clean:
        final_incremental = False

    discovered_modules = []
    if build_paths:
        if verbose:
            click.echo(f"Discovering modules in {len(build_paths)} path(s)...")

        from ..core.path_discovery import PathDiscovery
        discoverer = PathDiscovery(project_root, config)

        for path in build_paths:
            path_obj = Path(path)
            found = discoverer.discover_modules_in_path(path_obj)
            discovered_modules.extend(found)
            if verbose:
                click.echo(f"  {path}: found {len(found)} module(s)")

        if discovered_modules:
            modules = tuple(discovered_modules)
            if verbose:
                click.echo(f"Building {len(modules)} discovered module(s): {', '.join(modules)}")
        else:
            click.secho("No modules found in specified paths", fg='yellow')
            raise click.Abort()

    if fast_plugin and not fast_all:
        if verbose:
            click.echo(f"Fast rebuild mode: {fast_plugin}")

        # Extract module name (strip .cp extension and path prefix)
        fast_module_name = fast_plugin
        if fast_module_name.endswith('.cp'):
            fast_module_name = fast_module_name[:-3]
        # Strip any path prefix (plugins/math_utils -> math_utils)
        if '/' in fast_module_name:
            fast_module_name = fast_module_name.split('/')[-1]
        if '\\' in fast_module_name:
            fast_module_name = fast_module_name.split('\\')[-1]

        # Use the already-imported BuildManager (from line 115)
        temp_builder = BuildManager(project_root, build_dir, config)
        registry = temp_builder._load_registry()
        available_modules = registry.get('modules', {})

        if fast_module_name not in available_modules:
            click.secho(f"Module '{fast_module_name}' not found", fg='red', err=True)
            click.echo(f"Available modules: {', '.join(available_modules.keys())}")
            raise click.Abort()

        dep_graph = temp_builder._build_dependency_graph(available_modules)
        affected_modules = temp_builder._get_affected_modules(fast_module_name, dep_graph, available_modules)

        modules = tuple(affected_modules)
        final_incremental = True
        clean = False

        if verbose:
            click.echo(f"Affected modules ({len(modules)}): {', '.join(modules)}")

    if fast_all:
        if verbose:
            click.echo("Fast rebuild mode: ALL plugins")

        final_incremental = True
        clean = False
        modules = None

        if verbose:
            click.echo("Will rebuild all changed plugins incrementally")

    # v2.0: Show build configuration
    if verbose:
        click.echo(f"Incremental: {final_incremental}")
        click.echo(f"Parallel: {parallel}")
        if parallel:
            click.echo(f"Max jobs: {jobs}")
        if modules:
            click.echo(f"Target modules: {', '.join(modules)}")

    # Build start message
    build_type = "Incremental" if final_incremental else "Full"
    target_modules = list(modules) if modules else []

    click.echo("")
    click.secho("╔══════════════════════════════════════════════════════════════╗", fg='cyan')
    click.secho(f"║ IncludeCPP {build_type} Build", fg='cyan')
    click.secho("╚══════════════════════════════════════════════════════════════╝", fg='cyan')
    click.echo(f"Modules: {len(target_modules) if target_modules else 'all'}")
    click.echo("")

    start_time = time.time()

    try:
        builder = BuildManager(project_root, build_dir, config)

        success = builder.rebuild(
            modules=list(modules) if modules else None,
            incremental=final_incremental,
            parallel=parallel,
            clean=clean,
            verbose=verbose
        )

        build_time = time.time() - start_time

        if success:
            # Get built modules from registry for success message
            registry = builder._load_registry()
            built_modules = list(registry.get('modules', {}).keys()) if not target_modules else target_modules

            # Collect stats
            stats = {}
            total_funcs = 0
            total_classes = 0
            total_structs = 0
            for mod_name, mod_info in registry.get('modules', {}).items():
                if not target_modules or mod_name in target_modules:
                    total_funcs += len(mod_info.get('functions', []))
                    total_classes += len(mod_info.get('classes', []))
                    total_structs += len(mod_info.get('structs', []))

            if total_funcs > 0:
                stats['total_functions'] = total_funcs
            if total_classes > 0:
                stats['total_classes'] = total_classes
            if total_structs > 0:
                stats['total_structs'] = total_structs

            # Print success message
            click.echo("")
            click.secho("╔══════════════════════════════════════════════════════════════╗", fg='green')
            click.secho("║ ✓ BUILD SUCCESSFUL                                           ║", fg='green')
            click.secho("╚══════════════════════════════════════════════════════════════╝", fg='green')
            click.echo("")
            click.echo(f"Modules built ({len(built_modules)}):")
            for mod in built_modules:
                click.secho(f"  ✓ {mod}", fg='green')
            click.echo("")
            click.echo(f"Build time: {build_time:.2f}s")
            if stats:
                if 'total_functions' in stats:
                    click.echo(f"  Functions exported: {stats['total_functions']}")
                if 'total_classes' in stats:
                    click.echo(f"  Classes exported:   {stats['total_classes']}")
                if 'total_structs' in stats:
                    click.echo(f"  Structs exported:   {stats['total_structs']}")
            click.echo("")
            click.echo("Your modules are ready to use:")
            click.secho("  from module_name import function_name", fg='cyan')
            click.echo("")
        else:
            click.echo("")
            click.secho("╔══════════════════════════════════════════════════════════════╗", fg='red')
            click.secho("║ ✗ BUILD FAILED                                               ║", fg='red')
            click.secho("╚══════════════════════════════════════════════════════════════╝", fg='red')
            click.echo("")
            click.echo("To fix:")
            click.echo("  • Check the error messages above")
            click.echo("  • Run with --verbose for more details")
            click.echo("  • Fix errors and run: python -m includecpp rebuild")
            click.echo("")
            raise click.Abort()

    except click.Abort:
        raise
    except Exception as e:
        build_time = time.time() - start_time
        error_msg = str(e)

        # v2.4.1: Use analyze_error for intelligent error formatting
        formatted_error = BuildErrorFormatter.analyze_error(error_msg, target_modules[0] if target_modules else "")

        click.echo("")
        click.secho(formatted_error, fg='red', err=True)

        if verbose:
            click.echo("")
            click.secho("═" * 60, fg='yellow')
            click.secho("Full Stack Trace (--verbose):", fg='yellow')
            click.secho("═" * 60, fg='yellow')
            import traceback
            traceback.print_exc()

        raise click.Abort()

@cli.command()
@click.argument('module_name')
def add(module_name):
    """Create a new module template."""
    plugins_dir = Path("plugins")
    if not plugins_dir.exists():
        click.echo("Error: plugins/ directory not found")
        return

    cp_file = plugins_dir / f"{module_name}.cp"
    if cp_file.exists():
        click.echo(f"Module {module_name} already exists")
        return

    template = f"""SOURCE(include/{module_name}.cpp) {module_name}

PUBLIC(
    {module_name} FUNC(example_function)
)
"""

    with open(cp_file, 'w') as f:
        f.write(template)

    click.echo(f"Created {cp_file}")
    click.echo(f"Now create include/{module_name}.cpp with your C++ code")

@cli.command()
def list():
    """List all available C++ modules."""
    from ..core.build_manager import BuildManager

    project_root = Path.cwd()
    config = CppProjectConfig()
    compiler = detect_compiler()
    build_dir = config.get_build_dir(compiler)

    if not build_dir.exists():
        click.echo("No build directory found. Run 'python -m includecpp rebuild' first.")
        return

    try:
        builder = BuildManager(project_root, build_dir, config)
        registry = builder._load_registry()

        modules = registry.get('modules', {})
        if not modules:
            click.echo("No modules found. Run 'python -m includecpp rebuild' to build modules.")
            return

        click.echo(f"\nAvailable modules ({len(modules)}):")
        click.echo("=" * 60)

        for module_name, module_info in sorted(modules.items()):
            # Get source count
            sources = module_info.get('sources', [])
            source_count = len(sources)

            # Get dependency count
            deps = module_info.get('dependencies', [])
            dep_count = len(deps)

            # Get struct/class/function counts
            structs = module_info.get('structs', [])
            classes = module_info.get('classes', [])
            functions = module_info.get('functions', [])

            click.echo(f"\n  {module_name}")
            click.echo(f"    Sources: {source_count} file(s)")

            if dep_count > 0:
                dep_names = [d.get('target', '?') for d in deps]
                click.echo(f"    Dependencies: {', '.join(dep_names)}")

            if structs:
                click.echo(f"    Structs: {len(structs)}")
            if classes:
                click.echo(f"    Classes: {len(classes)}")
            if functions:
                click.echo(f"    Functions: {len(functions)}")

        click.echo("\n" + "=" * 60)
        click.echo(f"Total: {len(modules)} module(s)\n")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)

@cli.command()
@click.argument('module_name')
def info(module_name):
    """Show detailed information about a module."""
    from ..core.build_manager import BuildManager

    project_root = Path.cwd()
    config = CppProjectConfig()
    compiler = detect_compiler()
    build_dir = config.get_build_dir(compiler)

    if not build_dir.exists():
        click.echo("No build directory found. Run 'python -m includecpp rebuild' first.")
        return

    try:
        builder = BuildManager(project_root, build_dir, config)
        registry = builder._load_registry()

        modules = registry.get('modules', {})
        if module_name not in modules:
            click.echo(f"Module '{module_name}' not found.")
            click.echo(f"Available modules: {', '.join(sorted(modules.keys()))}")
            return

        module_info = modules[module_name]

        click.echo(f"\nModule: {module_name}")
        click.echo("=" * 60)

        # Sources
        sources = module_info.get('sources', [])
        click.echo(f"\nSources ({len(sources)}):")
        for src in sources:
            click.echo(f"  • {src}")

        # Dependencies
        deps = module_info.get('dependencies', [])
        if deps:
            click.echo(f"\nDependencies ({len(deps)}):")
            for dep in deps:
                target = dep.get('target', '?')
                types = dep.get('types', [])
                if types:
                    click.echo(f"  • {target} (types: {', '.join(types)})")
                else:
                    click.echo(f"  • {target}")

        # Structs
        structs = module_info.get('structs', [])
        if structs:
            click.echo(f"\nStructs ({len(structs)}):")
            for struct in structs:
                name = struct.get('name', '?')
                is_template = struct.get('is_template', False)
                if is_template:
                    template_types = struct.get('template_types', [])
                    click.echo(f"  • {name}<{', '.join(template_types)}>")
                else:
                    click.echo(f"  • {name}")

                fields = struct.get('fields', [])
                if fields:
                    for field in fields:
                        field_type = field.get('type', '?')
                        field_name = field.get('name', '?')
                        click.echo(f"      - {field_type} {field_name}")

        # Classes
        classes = module_info.get('classes', [])
        if classes:
            click.echo(f"\nClasses ({len(classes)}):")
            for cls in classes:
                name = cls.get('name', '?')
                methods = cls.get('methods', [])
                click.echo(f"  • {name}")
                if methods:
                    click.echo(f"      Methods: {', '.join(methods)}")

        # Functions
        functions = module_info.get('functions', [])
        if functions:
            click.echo(f"\nFunctions ({len(functions)}):")
            for func in functions:
                name = func.get('name', '?')
                click.echo(f"  • {name}()")

        # Build info
        last_built = module_info.get('last_built', 'Never')
        build_time = module_info.get('build_time_ms', 0)
        click.echo(f"\nLast Built: {last_built}")
        if build_time > 0:
            click.echo(f"Build Time: {build_time}ms")

        click.echo("=" * 60 + "\n")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)

@cli.command()
@click.argument('module_name')
def get(module_name):
    """Display detailed module API information with full signatures.

    Shows all classes, methods, functions, structs with complete
    type information, parameters, and documentation.
    """
    from ..core.build_manager import BuildManager

    project_root = Path.cwd()
    config = CppProjectConfig()
    compiler = detect_compiler()
    build_dir = config.get_build_dir(compiler)

    if not build_dir.exists():
        click.secho("\n╔══════════════════════════════════════════════════════════════╗", fg='red')
        click.secho("║  BUILD NOT FOUND                                             ║", fg='red')
        click.secho("╚══════════════════════════════════════════════════════════════╝", fg='red')
        click.echo("\nNo build directory found.")
        click.echo("\nTo fix this, run:")
        click.secho("  python -m includecpp rebuild", fg='cyan')
        return

    try:
        builder = BuildManager(project_root, build_dir, config)
        registry = builder._load_registry()

        modules = registry.get('modules', {})
        if module_name not in modules:
            click.secho(f"\n╔══════════════════════════════════════════════════════════════╗", fg='red')
            click.secho(f"║  MODULE NOT FOUND                                            ║", fg='red')
            click.secho(f"╚══════════════════════════════════════════════════════════════╝", fg='red')
            click.echo(f"\nModule '{module_name}' not found in registry.")
            click.echo(f"\nAvailable modules:")
            for mod in sorted(modules.keys()):
                click.echo(f"  • {mod}")
            click.echo(f"\nTo rebuild all modules:")
            click.secho("  python -m includecpp rebuild", fg='cyan')
            return

        module_info = modules[module_name]

        # Header
        click.echo()
        click.secho("╔" + "═" * 70 + "╗", fg='cyan', bold=True)
        title = f"  Module: {module_name}"
        padding = 70 - len(title) - 1
        click.secho(f"║{title}" + " " * padding + "║", fg='cyan', bold=True)
        click.secho("╚" + "═" * 70 + "╝", fg='cyan', bold=True)

        # Sources section
        sources = module_info.get('sources', [])
        click.echo()
        click.secho("┌─ Sources ─────────────────────────────────────────────────────────┐", fg='blue')
        for src in sources:
            click.echo(f"│  📄 {src}")
        click.secho("└───────────────────────────────────────────────────────────────────┘", fg='blue')

        # Dependencies section
        deps = module_info.get('dependencies', [])
        if deps:
            click.echo()
            click.secho("┌─ Dependencies ────────────────────────────────────────────────────┐", fg='yellow')
            for dep in deps:
                target = dep.get('target', '?')
                types = dep.get('types', [])
                optional = dep.get('optional', False)
                opt_str = " (optional)" if optional else ""
                if types:
                    click.echo(f"│  📦 {target}{opt_str} → types: {', '.join(types)}")
                else:
                    click.echo(f"│  📦 {target}{opt_str}")
            click.secho("└───────────────────────────────────────────────────────────────────┘", fg='yellow')

        # Classes section
        classes = module_info.get('classes', [])
        if classes:
            click.echo()
            click.secho("┌─ Classes ─────────────────────────────────────────────────────────┐", fg='green')
            for cls in classes:
                cls_name = cls.get('name', '?')
                cls_doc = cls.get('doc', '')
                methods = cls.get('methods', [])

                click.secho(f"│", fg='green')
                click.secho(f"│  🔷 class ", fg='green', nl=False)
                click.secho(f"{cls_name}", fg='white', bold=True)

                if cls_doc:
                    # Wrap documentation
                    click.secho(f"│     └─ {cls_doc[:60]}{'...' if len(cls_doc) > 60 else ''}", fg='bright_black')

                if methods:
                    click.secho(f"│", fg='green')
                    click.secho(f"│     Methods:", fg='green')

                    for method_info in methods:
                        if isinstance(method_info, dict):
                            method_name = method_info.get('name', '?')
                            method_doc = method_info.get('doc', '')
                            return_type = method_info.get('return_type', 'void')
                            params = method_info.get('parameters', [])
                            is_const = method_info.get('const', False)
                            is_static = method_info.get('static', False)

                            # Build parameter string
                            param_strs = []
                            for p in params:
                                p_type = p.get('type', '?')
                                p_name = p.get('name', '?')
                                p_default = p.get('default', '')
                                if p.get('const'):
                                    p_type = f"const {p_type}"
                                if p.get('reference'):
                                    p_type += "&"
                                if p.get('pointer'):
                                    p_type += "*"
                                if p_default:
                                    param_strs.append(f"{p_type} {p_name} = {p_default}")
                                else:
                                    param_strs.append(f"{p_type} {p_name}")

                            params_str = ", ".join(param_strs) if param_strs else ""
                            const_str = " const" if is_const else ""
                            static_str = "static " if is_static else ""

                            click.echo(f"│       ├─ ", nl=False)
                            click.secho(f"{static_str}{return_type} ", fg='magenta', nl=False)
                            click.secho(f"{method_name}", fg='white', bold=True, nl=False)
                            click.echo(f"({params_str}){const_str}")

                            if method_doc:
                                click.secho(f"│       │     └─ {method_doc[:55]}{'...' if len(method_doc) > 55 else ''}", fg='bright_black')
                        else:
                            # Simple string method name (legacy format)
                            click.echo(f"│       ├─ {method_info}()")

            click.secho("│", fg='green')
            click.secho("└───────────────────────────────────────────────────────────────────┘", fg='green')

        # Structs section
        structs = module_info.get('structs', [])
        if structs:
            click.echo()
            click.secho("┌─ Structs ─────────────────────────────────────────────────────────┐", fg='magenta')
            for struct in structs:
                struct_name = struct.get('name', '?')
                struct_doc = struct.get('doc', '')
                is_template = struct.get('is_template', False)
                template_types = struct.get('template_types', [])
                fields = struct.get('fields', [])

                click.secho(f"│", fg='magenta')
                if is_template:
                    click.secho(f"│  🔶 struct ", fg='magenta', nl=False)
                    click.secho(f"{struct_name}<{', '.join(template_types)}>", fg='white', bold=True)
                else:
                    click.secho(f"│  🔶 struct ", fg='magenta', nl=False)
                    click.secho(f"{struct_name}", fg='white', bold=True)

                if struct_doc:
                    click.secho(f"│     └─ {struct_doc[:60]}{'...' if len(struct_doc) > 60 else ''}", fg='bright_black')

                if fields:
                    click.secho(f"│", fg='magenta')
                    click.secho(f"│     Fields:", fg='magenta')
                    for field in fields:
                        field_type = field.get('type', '?')
                        field_name = field.get('name', '?')
                        click.echo(f"│       ├─ ", nl=False)
                        click.secho(f"{field_type} ", fg='cyan', nl=False)
                        click.echo(f"{field_name}")

            click.secho("│", fg='magenta')
            click.secho("└───────────────────────────────────────────────────────────────────┘", fg='magenta')

        # Functions section
        functions = module_info.get('functions', [])
        if functions:
            click.echo()
            click.secho("┌─ Functions ───────────────────────────────────────────────────────┐", fg='cyan')
            for func in functions:
                func_name = func.get('name', '?')
                func_doc = func.get('doc', '')
                return_type = func.get('return_type', 'void')
                params = func.get('parameters', [])
                is_static = func.get('static', False)
                is_const = func.get('const', False)
                is_inline = func.get('inline', False)

                # Build parameter string with types
                param_strs = []
                for p in params:
                    p_type = p.get('type', '?')
                    p_name = p.get('name', '?')
                    p_default = p.get('default', '')
                    if p.get('const'):
                        p_type = f"const {p_type}"
                    if p.get('reference'):
                        p_type += "&"
                    if p.get('pointer'):
                        p_type += "*"
                    if p_default:
                        param_strs.append(f"{p_type} {p_name} = {p_default}")
                    else:
                        param_strs.append(f"{p_type} {p_name}")

                params_str = ", ".join(param_strs) if param_strs else ""
                qualifiers = []
                if is_static:
                    qualifiers.append("static")
                if is_inline:
                    qualifiers.append("inline")
                if is_const:
                    qualifiers.append("const")
                qualifier_str = " ".join(qualifiers) + " " if qualifiers else ""

                click.secho(f"│", fg='cyan')
                click.echo(f"│  ⚡ ", nl=False)
                click.secho(f"{qualifier_str}{return_type} ", fg='yellow', nl=False)
                click.secho(f"{func_name}", fg='white', bold=True, nl=False)
                click.echo(f"({params_str})")

                if func_doc:
                    click.secho(f"│     └─ {func_doc[:60]}{'...' if len(func_doc) > 60 else ''}", fg='bright_black')

                # Show parameters in detail if any
                if params:
                    click.secho(f"│     Parameters:", fg='cyan')
                    for p in params:
                        p_type = p.get('type', '?')
                        p_name = p.get('name', '?')
                        p_default = p.get('default', '')
                        type_info = []
                        if p.get('const'):
                            type_info.append("const")
                        if p.get('reference'):
                            type_info.append("ref")
                        if p.get('pointer'):
                            type_info.append("ptr")
                        type_suffix = f" [{', '.join(type_info)}]" if type_info else ""
                        default_str = f" = {p_default}" if p_default else ""
                        click.echo(f"│       ├─ {p_name}: ", nl=False)
                        click.secho(f"{p_type}", fg='cyan', nl=False)
                        click.echo(f"{type_suffix}{default_str}")

            click.secho("│", fg='cyan')
            click.secho("└───────────────────────────────────────────────────────────────────┘", fg='cyan')

        # Usage section
        click.echo()
        click.secho("┌─ Usage Example ───────────────────────────────────────────────────┐", fg='white')
        click.echo(f"│")
        click.echo(f"│  from includecpp import CppApi")
        click.echo(f"│")
        click.echo(f"│  cpp = CppApi()")
        click.echo(f"│  {module_name} = cpp.{module_name}")
        click.echo(f"│")
        if functions:
            first_func = functions[0].get('name', 'function')
            click.echo(f"│  # Call a function")
            click.echo(f"│  result = {module_name}.{first_func}(...)")
        if classes:
            first_cls = classes[0].get('name', 'Class')
            click.echo(f"│")
            click.echo(f"│  # Use a class")
            click.echo(f"│  obj = {module_name}.{first_cls}()")
        click.echo(f"│")
        click.secho("└───────────────────────────────────────────────────────────────────┘", fg='white')
        click.echo()

    except Exception as e:
        click.secho(f"\n╔══════════════════════════════════════════════════════════════╗", fg='red')
        click.secho(f"║  ERROR                                                       ║", fg='red')
        click.secho(f"╚══════════════════════════════════════════════════════════════╝", fg='red')
        click.echo(f"\n{e}")

@cli.command()
@click.argument('module_name', required=False)
@click.option('--list-all', is_flag=True, help='List all available modules')
def install(module_name, list_all):
    """Install a module from GitHub: https://github.com/liliassg/IncludeCPP/minstall/{module}"""
    import tempfile
    import urllib.request
    import urllib.error
    import json

    # Handle --list-all option
    if list_all:
        click.echo("=" * 60)
        click.secho("Available IncludeCPP Modules", fg='cyan', bold=True)
        click.echo("=" * 60)
        click.echo(f"Source: https://github.com/liliassg/IncludeCPP/tree/main/minstall")
        click.echo()

        try:
            # Fetch directory listing from GitHub API
            api_url = "https://api.github.com/repos/liliassg/IncludeCPP/contents/minstall"
            click.echo("  Fetching module list...", nl=False)

            with urllib.request.urlopen(api_url) as response:
                data = json.loads(response.read())
                click.secho(" OK", fg='green')
                click.echo()

            # Extract module names (directories)
            modules = [item['name'] for item in data if item['type'] == 'dir']

            if not modules:
                click.secho("  No modules found.", fg='yellow')
            else:
                click.secho(f"Found {len(modules)} module(s):", fg='green', bold=True)
                click.echo()
                for module in sorted(modules):
                    click.echo(f"  • {module}")

                click.echo()
                click.echo("Install a module with:")
                click.echo("  includecpp install <module_name>")

        except urllib.error.HTTPError as e:
            click.secho(f"  FAILED (HTTP {e.code})", fg='red', err=True)
            click.echo()
            click.echo("Could not fetch module list from GitHub.")
        except Exception as e:
            click.secho(f"  FAILED ({e})", fg='red', err=True)

        click.echo("=" * 60)
        return

    # Require module_name if not using --list-all
    if not module_name:
        click.secho("Error: Missing argument 'MODULE_NAME'.", fg='red', err=True)
        click.echo("Use 'includecpp install --list-all' to see available modules.")
        return

    # Check if include and plugins directories exist
    include_dir = Path.cwd() / "include"
    plugins_dir = Path.cwd() / "plugins"

    if not include_dir.exists() or not plugins_dir.exists():
        click.secho("Error: Not in a valid IncludeCPP project directory.", fg='red', err=True)
        click.echo("Run 'python -m includecpp init' first.")
        return

    click.echo("=" * 60)
    click.secho(f"Collecting {module_name}", fg='cyan', bold=True)
    click.echo("=" * 60)
    click.echo(f"Source: https://github.com/liliassg/IncludeCPP/tree/main/minstall/{module_name}")
    click.echo()

    # GitHub raw content base URL
    base_url = f"https://raw.githubusercontent.com/liliassg/IncludeCPP/main/minstall/{module_name}/"

    # Try to download .cp, .cpp, and .h files
    files_to_download = [
        (f"{module_name}.cp", plugins_dir, "Plugin definition"),
        (f"{module_name}.cpp", include_dir, "C++ implementation"),
        (f"{module_name}.h", include_dir, "C++ header")
    ]

    downloaded = []

    for filename, target_dir, description in files_to_download:
        url = base_url + filename
        target_path = target_dir / filename

        try:
            click.echo(f"  Collecting {filename:20} ({description})...", nl=False)
            with urllib.request.urlopen(url) as response:
                content = response.read()

                # Write to target directory
                with open(target_path, 'wb') as f:
                    f.write(content)

                downloaded.append(filename)
                file_size_kb = len(content) / 1024
                click.secho(f" OK ({file_size_kb:.1f} KB)", fg='green')

        except urllib.error.HTTPError as e:
            if e.code == 404:
                # File doesn't exist, skip (optional file like .h)
                click.secho(" SKIP (optional)", fg='yellow')
            else:
                click.secho(f" FAILED ({e})", fg='red', err=True)
        except Exception as e:
            click.secho(f" FAILED ({e})", fg='red', err=True)

    click.echo()

    if not downloaded:
        click.secho(f"Error: Module '{module_name}' not found or no files available.", fg='red', err=True)
        click.echo(f"Check https://github.com/liliassg/IncludeCPP/tree/main/minstall for available modules.")
        return

    click.secho(f"Successfully installed {len(downloaded)} file(s):", fg='green', bold=True)
    for f in downloaded:
        click.echo(f"  - {f}")

    click.echo()
    click.secho(f"Module '{module_name}' installed successfully!", fg='green', bold=True)
    click.echo("Run 'python -m includecpp rebuild' to build the module.")
    click.echo("=" * 60)

@cli.command()
@click.argument('module_name', required=False)
@click.option('--list-all', is_flag=True, help='List all available modules')
def minstall(module_name, list_all):
    """Alias for 'install' - Install modules from GitHub minstall repository."""
    # Call the install command with the same arguments
    ctx = click.get_current_context()
    ctx.invoke(install, module_name=module_name, list_all=list_all)

@cli.command()
def update():
    """Update IncludeCPP package to latest version from PyPI."""
    import subprocess
    import urllib.request
    import json

    click.echo("=" * 60)
    click.secho("Checking for IncludeCPP updates", fg='cyan', bold=True)
    click.echo("=" * 60)
    click.echo()

    try:
        click.echo("  Fetching latest version from PyPI...", nl=False)
        with urllib.request.urlopen("https://pypi.org/pypi/IncludeCPP/json") as response:
            data = json.loads(response.read())
            latest_version = data['info']['version']
            click.secho(f" OK", fg='green')

        from .. import __version__ as current_version
        click.echo()
        click.echo(f"  Current version: {current_version}")
        click.echo(f"  Latest version:  {latest_version}")
        click.echo()

        if current_version == latest_version:
            click.secho("IncludeCPP is already up to date!", fg='green', bold=True)
            click.echo("=" * 60)
            return

        click.secho(f"Upgrading to version {latest_version}...", fg='cyan', bold=True)
        click.echo()

        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "IncludeCPP"],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            click.echo()
            click.secho(f"Successfully upgraded to IncludeCPP {latest_version}!", fg='green', bold=True)
            click.echo("Restart your terminal to use the new version.")
        else:
            click.secho("Upgrade failed!", fg='red', err=True, bold=True)
            click.echo(result.stderr)

    except Exception as e:
        click.secho(f"Failed to check for updates: {e}", fg='red', err=True)

    click.echo("=" * 60)

@cli.command()
@click.argument('plugin_name')
@click.argument('files', nargs=-1, required=True)
@click.option('--private', '-p', multiple=True, help='Private functions to exclude from public API')
def plugin(plugin_name, files, private):
    import re
    from pathlib import Path

    project_root = Path.cwd()
    plugins_dir = project_root / "plugins"

    if not plugins_dir.exists():
        click.secho("Error: plugins/ directory not found", fg='red', err=True)
        click.echo("Run 'python -m includecpp init' first")
        return

    cpp_files = []
    h_files = []

    for file_path in files:
        p = Path(file_path)
        if not p.is_absolute():
            p = project_root / p

        if not p.exists():
            click.secho(f"Error: File not found: {file_path}", fg='red', err=True)
            return

        if p.suffix == '.cpp':
            cpp_files.append(p)
        elif p.suffix == '.h':
            h_files.append(p)

    if not cpp_files:
        click.secho("Error: No .cpp files provided", fg='red', err=True)
        return

    classes = {}
    functions = set()
    namespaces = set()

    def find_matching_brace(text, start_pos):
        """Find the position of the matching closing brace using bracket counting."""
        brace_count = 0
        for i, char in enumerate(text[start_pos:]):
            if char == '{':
                brace_count += 1
            elif char == '}':
                brace_count -= 1
                if brace_count == 0:
                    return start_pos + i
        return len(text) - 1

    def extract_public_section(class_body, is_struct=False):
        """Extract the public section from a class body."""
        # For struct, everything before first access specifier is public
        if is_struct:
            first_access = re.search(r'\b(private|protected)\s*:', class_body)
            if first_access:
                return class_body[:first_access.start()]
            return class_body

        # For class, find public: section
        public_match = re.search(r'\bpublic\s*:', class_body)
        if not public_match:
            return ""

        public_start = public_match.end()
        # Find end of public section (next access specifier or end)
        next_access = re.search(r'\b(private|protected)\s*:', class_body[public_start:])
        if next_access:
            return class_body[public_start:public_start + next_access.start()]
        return class_body[public_start:]

    def extract_methods(public_section, class_name):
        """Extract method names from public section, handling inline bodies."""
        methods = set()
        constructors = 0

        # Method pattern that handles return types, const, and inline bodies
        # Match: [modifiers] return_type method_name(params) [const] [{ body } | ;]
        method_regex = re.compile(
            r'(?:(?:virtual|static|inline|explicit|constexpr)\s+)*'  # Optional modifiers
            r'(?:const\s+)?'  # Optional const before return type
            r'([\w:]+(?:<[^>]+>)?(?:\s*[&*])?)\s+'  # Return type (with templates, refs, pointers)
            r'(\w+)\s*'  # Method name
            r'\([^)]*\)\s*'  # Parameters
            r'(?:const|override|final|noexcept|\s)*'  # Optional qualifiers after params
            r'(?::\s*[^{;]+)?'  # Optional initializer list
            r'(?:\{|;)',  # Body start or declaration end
            re.MULTILINE
        )

        for match in method_regex.finditer(public_section):
            return_type = match.group(1).strip()
            method_name = match.group(2).strip()

            # Skip if method name is the class name (it's a constructor)
            if method_name == class_name:
                constructors += 1
                continue

            # Skip destructors
            if method_name.startswith('~'):
                continue

            # Skip operators (operator+, operator==, etc.)
            if method_name == 'operator':
                continue

            methods.add(method_name)

        # Also look for explicit constructors
        constructor_pattern = rf'\b{re.escape(class_name)}\s*\([^)]*\)'
        constructor_matches = re.findall(constructor_pattern, public_section)
        constructors = max(constructors, len(constructor_matches))

        return methods, constructors

    all_files = cpp_files + h_files

    for file in all_files:
        with open(file, 'r', encoding='utf-8') as f:
            content = f.read()

        # Extract namespaces
        namespace_matches = re.findall(r'\bnamespace\s+(\w+)', content)
        namespaces.update(namespace_matches)

        # Find class/struct declarations with proper bracket matching
        class_pattern = re.compile(
            r'\b(class|struct)\s+(\w+)\s*'  # class/struct keyword and name
            r'(?::\s*(?:public|private|protected)?\s*\w+(?:\s*,\s*(?:public|private|protected)?\s*\w+)*)?\s*'  # Optional inheritance
            r'\{',  # Opening brace
            re.MULTILINE
        )

        for match in class_pattern.finditer(content):
            keyword = match.group(1)
            class_name = match.group(2)
            is_struct = keyword == 'struct'
            brace_start = match.end() - 1

            # Find matching closing brace
            brace_end = find_matching_brace(content, brace_start)
            class_body = content[brace_start + 1:brace_end]

            # Extract public section
            public_section = extract_public_section(class_body, is_struct)

            if class_name not in classes:
                classes[class_name] = {'methods': set(), 'constructors': 0}

            # Extract methods from public section
            methods, constructors = extract_methods(public_section, class_name)
            classes[class_name]['methods'].update(methods)
            classes[class_name]['constructors'] = max(classes[class_name]['constructors'], constructors)

        # Find free functions (not inside class bodies)
        # First, remove all class bodies from content to avoid matching class methods
        content_no_classes = content
        for match in class_pattern.finditer(content):
            brace_start = match.end() - 1
            brace_end = find_matching_brace(content, brace_start)
            # Replace class body with spaces to preserve positions
            class_body = content[match.start():brace_end + 1]
            content_no_classes = content_no_classes.replace(class_body, ' ' * len(class_body), 1)

        # Now find functions in the cleaned content
        func_pattern = re.compile(
            r'(?:(?:inline|static|extern|constexpr)\s+)*'  # Optional modifiers
            r'(?:const\s+)?'  # Optional const
            r'[\w:]+(?:<[^>]+>)?(?:\s*[&*])?\s+'  # Return type
            r'(\w+)\s*'  # Function name
            r'\([^)]*\)\s*'  # Parameters
            r'(?:const|noexcept|\s)*'  # Optional qualifiers
            r'\{',  # Body start (not just declaration)
            re.MULTILINE
        )
        for match in func_pattern.finditer(content_no_classes):
            func_name = match.group(1)
            if func_name not in ['if', 'while', 'for', 'switch', 'catch']:
                functions.add(func_name)

    private_set = set(private) if private else set()
    public_functions = functions - private_set - set(classes.keys())

    cp_file = plugins_dir / f"{plugin_name}.cp"

    cpp_sources = ' '.join(str(f.relative_to(project_root) if f.is_relative_to(project_root) else f).replace('\\', '/') for f in cpp_files)
    h_headers = ' '.join(str(f.relative_to(project_root) if f.is_relative_to(project_root) else f).replace('\\', '/') for f in h_files) if h_files else None

    with open(cp_file, 'w') as f:
        if h_headers:
            f.write(f'SOURCE({cpp_sources}) && HEADER({h_headers}) {plugin_name}\n\n')
        else:
            f.write(f'SOURCE({cpp_sources}) {plugin_name}\n\n')

        if classes or public_functions:
            f.write('PUBLIC(\n')

            for cls_name in sorted(classes.keys()):
                cls_info = classes[cls_name]
                f.write(f'    {plugin_name} CLASS({cls_name}) {{\n')

                if cls_info['constructors'] > 0:
                    f.write(f'        CONSTRUCTOR()\n')

                for method in sorted(cls_info['methods']):
                    f.write(f'        METHOD({method})\n')

                f.write(f'    }}\n')

            if classes and public_functions:
                f.write('\n')

            for func in sorted(public_functions):
                if not any(c.lower() in func.lower() or func.lower() in c.lower() for c in classes.keys()):
                    f.write(f'    {plugin_name} FUNCTION({func})\n')

            f.write(')\n')

    click.secho(f"Generated plugin: {cp_file}", fg='green', bold=True)
    click.echo(f"Classes found: {len(classes)}")
    click.echo(f"Public functions: {len(public_functions)}")
    if private_set:
        click.echo(f"Private functions excluded: {len(private_set)}")
    click.echo()
    click.echo("Run 'python -m includecpp rebuild' to build the plugin")

def detect_compiler():
    for compiler in ['g++', 'clang++', 'cl']:
        if shutil.which(compiler):
            return compiler.replace('++', '').replace('cl', 'msvc')
    return 'gcc'

if __name__ == '__main__':
    cli()
