"""Date and datetime parsing functions with locale awareness.

- parse_date() returns tuple[date | None, tuple[FluentParseError, ...]]
- parse_datetime() returns tuple[datetime | None, tuple[FluentParseError, ...]]
- Removed `strict` parameter - functions NEVER raise, errors returned in tuple
- Consistent with format_*() "never raise" philosophy
- Fixed: Date pattern tokenizer replaces regex word boundary approach

Thread-safe. Uses Python 3.13 stdlib + Babel CLDR patterns.

Python 3.13+.
"""

from datetime import date, datetime, timezone

from babel import Locale, UnknownLocaleError

from ftllexbuffer.diagnostics import FluentParseError
from ftllexbuffer.diagnostics.templates import ErrorTemplate
from ftllexbuffer.locale_utils import normalize_locale

# CLDR date format styles used for parsing.
# "long" is included for dates but excluded for datetimes (rarely used in input).
_DATE_PARSE_STYLES: tuple[str, ...] = ("short", "medium", "long")
_DATETIME_PARSE_STYLES: tuple[str, ...] = ("short", "medium")

# Default separator between date and time components (fallback only).
# Used when locale-specific dateTimeFormat pattern extraction fails.
_DATETIME_SEPARATOR_FALLBACK: str = " "


def parse_date(
    value: str,
    locale_code: str,
) -> tuple[date | None, tuple[FluentParseError, ...]]:
    """Parse locale-aware date string to date object.

    No longer raises exceptions. Errors are returned in tuple.
    The `strict` parameter has been removed.

    Only ISO 8601 and locale-specific CLDR patterns are supported.
    Ambiguous formats like "1/2/25" will ONLY match if locale CLDR pattern matches.

    Args:
        value: Date string (e.g., "28.01.25" for lv_LV, "2025-01-28" for ISO 8601)
        locale_code: BCP 47 locale identifier (e.g., "en_US", "lv_LV", "de_DE")

    Returns:
        Tuple of (result, errors):
        - result: Parsed date object, or None if parsing failed
        - errors: Tuple of FluentParseError (empty tuple on success)

    Examples:
        >>> result, errors = parse_date("2025-01-28", "en_US")  # ISO 8601
        >>> result
        datetime.date(2025, 1, 28)
        >>> errors
        ()

        >>> result, errors = parse_date("1/28/25", "en_US")  # US locale format
        >>> result
        datetime.date(2025, 1, 28)

        >>> result, errors = parse_date("invalid", "en_US")
        >>> result is None
        True
        >>> len(errors)
        1

    Thread Safety:
        Thread-safe. Uses Babel + stdlib (no global state).
    """
    errors: list[FluentParseError] = []

    # Type check: value must be string (runtime defense for untyped callers)
    if not isinstance(value, str):
        diagnostic = ErrorTemplate.parse_date_failed(  # type: ignore[unreachable]
            str(value), locale_code, f"Expected string, got {type(value).__name__}"
        )
        errors.append(
            FluentParseError(
                diagnostic,
                input_value=str(value),
                locale_code=locale_code,
                parse_type="date",
            )
        )
        return (None, tuple(errors))

    # Try ISO 8601 first (fastest path)
    try:
        return (datetime.fromisoformat(value).date(), tuple(errors))
    except ValueError:
        pass

    # Try locale-specific CLDR patterns
    patterns = _get_date_patterns(locale_code)
    if not patterns:
        # Unknown locale
        diagnostic = ErrorTemplate.parse_locale_unknown(locale_code)
        errors.append(
            FluentParseError(
                diagnostic,
                input_value=value,
                locale_code=locale_code,
                parse_type="date",
            )
        )
        return (None, tuple(errors))

    for pattern in patterns:
        try:
            return (datetime.strptime(value, pattern).date(), tuple(errors))
        except ValueError:
            continue

    # All patterns failed
    diagnostic = ErrorTemplate.parse_date_failed(
        value, locale_code, "No matching date pattern found"
    )
    errors.append(
        FluentParseError(
            diagnostic,
            input_value=value,
            locale_code=locale_code,
            parse_type="date",
        )
    )
    return (None, tuple(errors))


def parse_datetime(
    value: str,
    locale_code: str,
    *,
    tzinfo: timezone | None = None,
) -> tuple[datetime | None, tuple[FluentParseError, ...]]:
    """Parse locale-aware datetime string to datetime object.

    No longer raises exceptions. Errors are returned in tuple.
    The `strict` parameter has been removed.

    Only ISO 8601 and locale-specific CLDR patterns are supported.

    Args:
        value: DateTime string (e.g., "2025-01-28 14:30" for ISO 8601)
        locale_code: BCP 47 locale identifier (e.g., "en_US", "lv_LV", "de_DE")
        tzinfo: Timezone to assign if not in string (default: None - naive datetime)

    Returns:
        Tuple of (result, errors):
        - result: Parsed datetime object, or None if parsing failed
        - errors: Tuple of FluentParseError (empty tuple on success)

    Examples:
        >>> result, errors = parse_datetime("2025-01-28 14:30", "en_US")  # ISO 8601
        >>> result
        datetime.datetime(2025, 1, 28, 14, 30)
        >>> errors
        ()

        >>> result, errors = parse_datetime("1/28/25 2:30 PM", "en_US")  # US locale
        >>> result
        datetime.datetime(2025, 1, 28, 14, 30)

        >>> result, errors = parse_datetime("invalid", "en_US")
        >>> result is None
        True
        >>> len(errors)
        1

    Thread Safety:
        Thread-safe. Uses Babel + stdlib (no global state).
    """
    errors: list[FluentParseError] = []

    # Type check: value must be string (runtime defense for untyped callers)
    if not isinstance(value, str):
        diagnostic = ErrorTemplate.parse_datetime_failed(  # type: ignore[unreachable]
            str(value), locale_code, f"Expected string, got {type(value).__name__}"
        )
        errors.append(
            FluentParseError(
                diagnostic,
                input_value=str(value),
                locale_code=locale_code,
                parse_type="datetime",
            )
        )
        return (None, tuple(errors))

    # Try ISO 8601 first (fastest path)
    try:
        parsed = datetime.fromisoformat(value)
        if tzinfo is not None and parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=tzinfo)
        return (parsed, tuple(errors))
    except (ValueError, TypeError):
        pass

    # Try locale-specific CLDR patterns
    patterns = _get_datetime_patterns(locale_code)
    if not patterns:
        # Unknown locale
        diagnostic = ErrorTemplate.parse_locale_unknown(locale_code)
        errors.append(
            FluentParseError(
                diagnostic,
                input_value=value,
                locale_code=locale_code,
                parse_type="datetime",
            )
        )
        return (None, tuple(errors))

    for pattern in patterns:
        try:
            parsed = datetime.strptime(value, pattern)
            if tzinfo is not None and parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=tzinfo)
            return (parsed, tuple(errors))
        except ValueError:
            continue

    # All patterns failed
    diagnostic = ErrorTemplate.parse_datetime_failed(
        value, locale_code, "No matching datetime pattern found"
    )
    errors.append(
        FluentParseError(
            diagnostic,
            input_value=value,
            locale_code=locale_code,
            parse_type="datetime",
        )
    )
    return (None, tuple(errors))


def _get_date_patterns(locale_code: str) -> list[str]:
    """Get strptime date patterns for locale.

    Uses ONLY Babel CLDR date format patterns specific to the locale.
    No fallback patterns to avoid ambiguous date interpretation.

    Args:
        locale_code: BCP 47 locale identifier

    Returns:
        List of strptime patterns to try, in order of preference
        Empty list if locale parsing fails
    """
    try:
        locale = Locale.parse(normalize_locale(locale_code))

        # Get CLDR date patterns
        patterns = []

        # Try CLDR format styles
        for style in _DATE_PARSE_STYLES:
            try:
                babel_pattern = locale.date_formats[style].pattern
                strptime_pattern = _babel_to_strptime(babel_pattern)
                patterns.append(strptime_pattern)
            except (AttributeError, KeyError):
                pass

        return patterns

    except (UnknownLocaleError, ValueError, RuntimeError):
        return []


def _extract_datetime_separator(locale: Locale, style: str = "medium") -> str:
    """Extract the date-time separator from locale's CLDR dateTimeFormat.

    CLDR dateTimeFormat patterns use {0} for time and {1} for date, e.g.:
    - en_US: "{1}, {0}" -> separator is ", "
    - ja_JP: "{1} {0}" -> separator is " "
    - fr_FR medium: "{1}, {0}" -> separator is ", "

    Args:
        locale: Babel Locale object
        style: Format style to extract from ("short" or "medium")

    Returns:
        The separator string between date and time components.
        Falls back to space if extraction fails.
    """
    try:
        datetime_format = locale.datetime_formats.get(style)
        if datetime_format is None:
            return _DATETIME_SEPARATOR_FALLBACK

        # Get the pattern string - may be str or DateTimePattern object
        pattern = str(datetime_format)

        # Pattern format: "{1}<separator>{0}" where {1}=date, {0}=time
        # Find the text between {1} and {0}
        date_placeholder = "{1}"
        time_placeholder = "{0}"

        date_idx = pattern.find(date_placeholder)
        time_idx = pattern.find(time_placeholder)

        if date_idx == -1 or time_idx == -1:
            return _DATETIME_SEPARATOR_FALLBACK

        # Handle both "{1}<sep>{0}" and "{0}<sep>{1}" orderings
        if date_idx < time_idx:
            # Normal order: date first, then time
            sep_start = date_idx + len(date_placeholder)
            sep_end = time_idx
        else:
            # Reversed order: time first, then date
            sep_start = time_idx + len(time_placeholder)
            sep_end = date_idx

        if sep_start < sep_end:
            return pattern[sep_start:sep_end]

        return _DATETIME_SEPARATOR_FALLBACK

    except (AttributeError, TypeError, ValueError):
        return _DATETIME_SEPARATOR_FALLBACK


def _get_datetime_patterns(locale_code: str) -> list[str]:
    """Get strptime datetime patterns for locale.

    Uses ONLY Babel CLDR datetime format patterns specific to the locale.
    No fallback patterns to avoid ambiguous datetime interpretation.

    Args:
        locale_code: BCP 47 locale identifier

    Returns:
        List of strptime patterns to try, in order of preference
        Empty list if locale parsing fails
    """
    try:
        locale = Locale.parse(normalize_locale(locale_code))

        # Get CLDR datetime patterns
        patterns = []

        # Try CLDR format styles for datetime
        for style in _DATETIME_PARSE_STYLES:
            try:
                babel_pattern = locale.datetime_formats[style].pattern
                strptime_pattern = _babel_to_strptime(babel_pattern)
                patterns.append(strptime_pattern)
            except (AttributeError, KeyError):
                pass

        # Get date patterns and add time components for locale
        date_patterns = _get_date_patterns(locale_code)

        # Get locale-specific separator from CLDR dateTimeFormat
        sep = _extract_datetime_separator(locale)
        for date_pat in date_patterns:
            patterns.extend(
                [
                    f"{date_pat}{sep}%H:%M:%S",  # 24-hour with seconds
                    f"{date_pat}{sep}%H:%M",  # 24-hour without seconds
                    f"{date_pat}{sep}%I:%M:%S %p",  # 12-hour with seconds + AM/PM
                    f"{date_pat}{sep}%I:%M %p",  # 12-hour without seconds + AM/PM
                ]
            )

        return patterns

    except (UnknownLocaleError, ValueError, RuntimeError):
        return []


# ==============================================================================
# TOKEN-BASED BABEL-TO-STRPTIME CONVERTER
# ==============================================================================

# Token mapping: Babel CLDR pattern -> Python strptime directive
_BABEL_TOKEN_MAP: dict[str, str] = {
    # Year
    "yyyy": "%Y",  # 4-digit year
    "yy": "%y",  # 2-digit year
    "y": "%Y",  # Year (default to 4-digit)
    # Month
    "MMMM": "%B",  # Full month name
    "MMM": "%b",  # Short month name
    "MM": "%m",  # 2-digit month
    "M": "%m",  # Month
    # Day
    "dd": "%d",  # 2-digit day
    "d": "%d",  # Day
    # Weekday
    "EEEE": "%A",  # Full weekday name
    "EEE": "%a",  # Short weekday name
    "E": "%a",  # Weekday
    # Hour
    "HH": "%H",  # 2-digit hour (0-23)
    "H": "%H",  # Hour (0-23)
    "hh": "%I",  # 2-digit hour (1-12)
    "h": "%I",  # Hour (1-12)
    # Minute
    "mm": "%M",  # 2-digit minute
    "m": "%M",  # Minute
    # Second
    "ss": "%S",  # 2-digit second
    "s": "%S",  # Second
    # AM/PM
    "a": "%p",  # AM/PM marker
}


def _tokenize_babel_pattern(pattern: str) -> list[str]:
    """Tokenize Babel CLDR pattern into individual tokens.

    This correctly handles patterns like "d.MM.yyyy" where "d" is adjacent
    to punctuation without word boundaries.

    CLDR quote escaping rules:
    - Single quotes delimit literal text: 'at' produces "at"
    - Two consecutive single quotes '' produce a literal single quote
    - '' inside quoted text also produces a literal single quote

    Examples:
        "h 'o''clock' a" -> ["h", " ", "o'clock", " ", "a"]
        "yyyy-MM-dd" -> ["yyyy", "-", "MM", "-", "dd"]
        "d.MM.yyyy" -> ["d", ".", "MM", ".", "yyyy"]

    Args:
        pattern: Babel CLDR date pattern (e.g., "d.MM.yyyy")

    Returns:
        List of tokens (e.g., ["d", ".", "MM", ".", "yyyy"])
    """
    tokens: list[str] = []
    i = 0
    n = len(pattern)

    while i < n:
        char = pattern[i]

        # Check for quoted literal (single quotes in CLDR patterns)
        if char == "'":
            # Check for escaped quote '' (produces literal single quote)
            if i + 1 < n and pattern[i + 1] == "'":
                # '' outside quoted section -> literal single quote
                tokens.append("'")
                i += 2
                continue

            # Start of quoted literal section
            i += 1  # Skip opening quote
            literal_chars: list[str] = []

            while i < n:
                if pattern[i] == "'":
                    # Check for escaped quote '' inside quoted section
                    if i + 1 < n and pattern[i + 1] == "'":
                        # '' inside quoted section -> literal single quote
                        literal_chars.append("'")
                        i += 2
                    else:
                        # Closing quote found
                        i += 1
                        break
                else:
                    literal_chars.append(pattern[i])
                    i += 1

            # Add collected literal as single token
            if literal_chars:
                tokens.append("".join(literal_chars))
            continue

        # Check for pattern letter sequences (a-zA-Z)
        if char.isalpha():
            # Collect consecutive same letters (e.g., "yyyy", "MM", "dd")
            j = i + 1
            while j < n and pattern[j] == char:
                j += 1
            tokens.append(pattern[i:j])
            i = j
            continue

        # Everything else is a literal (punctuation, spaces, etc.)
        tokens.append(char)
        i += 1

    return tokens


def _babel_to_strptime(babel_pattern: str) -> str:
    """Convert Babel CLDR pattern to Python strptime format.

    Fixes edge cases with word boundaries in patterns like "d.MM.yyyy".

    Babel uses Unicode CLDR date pattern syntax, Python uses strptime directives.

    Babel Patterns:
        y, yy      = 2-digit year
        yyyy       = 4-digit year
        M, MM      = month (1-12)
        MMM        = short month name (Jan, Feb)
        MMMM       = full month name (January, February)
        d, dd      = day of month
        E, EEE     = short weekday (Mon)
        EEEE       = full weekday (Monday)
        H, HH      = hour 0-23
        h, hh      = hour 1-12
        m, mm      = minute
        s, ss      = second
        a          = AM/PM

    Python strptime:
        %y  = 2-digit year
        %Y  = 4-digit year
        %m  = month (01-12)
        %b  = short month name
        %B  = full month name
        %d  = day of month
        %a  = short weekday
        %A  = full weekday
        %H  = hour 0-23
        %I  = hour 1-12
        %M  = minute
        %S  = second
        %p  = AM/PM

    Args:
        babel_pattern: Babel CLDR date pattern

    Returns:
        Python strptime pattern
    """
    tokens = _tokenize_babel_pattern(babel_pattern)
    result_parts: list[str] = []

    for token in tokens:
        # Check if token is a Babel pattern token
        if token in _BABEL_TOKEN_MAP:
            result_parts.append(_BABEL_TOKEN_MAP[token])
        else:
            # Literal: pass through (punctuation, spaces, etc.)
            result_parts.append(token)

    return "".join(result_parts)
