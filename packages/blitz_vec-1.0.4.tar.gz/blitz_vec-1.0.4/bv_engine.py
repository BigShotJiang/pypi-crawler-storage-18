import os, datetime, decimal, time, threading
import numpy as np

from blitz_vec import BlitzVec

class VectorExp:
    SEP = "|"
    MAX_CHAR = "\xff"
    
    def __init__(
        self,
        storage_base_path="vectordb_data",
        shards=2,
        max_size_gb=50
    ):
        GB = 1024 * 1024 * 1024
        os.makedirs(storage_base_path, exist_ok=True)
        
        self.storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "index_data"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.8) // shards
        )
        self.meta_storage = BlitzVec(
            base_path=os.path.join(storage_base_path, "meta_blobs"),
            num_shards=shards,
            map_size=int(max_size_gb * GB * 0.2) // shards
        )
        
        # Fine-grained locks: separate write lock per operation type
        self._write_lock = threading.Lock()  # Only for writes that modify structure
        self._id_lock = threading.Lock()
        
        self._last_timestamp = 0
        self._counter = 0
        self.actual_dim = 0
        
    def store_embeddings_batch(self, vectors, metadata_dicts=None, text_field=None):
        count = len(vectors)
        if count == 0: 
            return []
        
        dim = len(vectors[0])
        if self.actual_dim == 0: 
            self.actual_dim = dim
        
        ids = self._generate_ids(count)
        if metadata_dicts is None: 
            metadata_dicts = [{} for _ in range(count)]
        
        # Normalize vectors (no lock needed - pure computation)
        vec_np = np.array(vectors, dtype=np.float32)
        norms = np.linalg.norm(vec_np, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vec_np /= norms
        
        # Build index entries (no lock needed - pure computation)
        index_entries = []
        for uid, meta in zip(ids, metadata_dicts):
            for key, value in meta.items():
                if text_field and key == text_field: 
                    continue
                val_str = self._format_for_indexing(value)
                prefix = f"idx_{key}:{val_str}"
                index_entries.append((prefix, uid))
        
        # Single write lock for all insertions
        with self._write_lock:
            # LMDB handles concurrent writes internally via transactions
            self.storage.store_flat_vectors(vec_np, ids)
            self.meta_storage.store_data(metadata_dicts, ids)
            
            if index_entries:
                self.storage.batch_index_insert(index_entries)
                
        return ids
    
    def search(self, query_embedding, metadata_filter=None, k=5):
        if self.actual_dim == 0: 
            self.actual_dim = len(query_embedding)
        
        # Normalize query (no lock - pure computation)
        query_np = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_np)
        if query_norm > 0:
            query_np /= query_norm
        
        # Filter resolution (no lock - LMDB read transaction)
        filter_tree = self._compile_filter(metadata_filter)
        allowed_iter = None
        if filter_tree:
            allowed_iter = self.storage.get_ids_from_filter(filter_tree)
            if allowed_iter is not None and len(allowed_iter) == 0:
                return []
        
        # Search (no lock - LMDB uses MVCC for concurrent reads)
        results = self.storage.search_flat(query_np, allowed_iter, k)
        
        if not results: 
            return []
            
        final_ids = [res[1] for res in results]
        scores = [res[0] for res in results]
        final_metas = self.meta_storage.get_data(final_ids)
        
        return list(zip(final_ids, scores, final_metas))
    
    def delete(self, metadata_query):
        filter_tree = self._compile_filter(metadata_query)
        if filter_tree is None: 
            return 0
        
        # Filter resolution (no lock - read-only)
        blitz_iter = self.storage.get_ids_from_filter(filter_tree)
        if not blitz_iter: 
            return 0
        
        ids = blitz_iter.to_list()
        if not ids: 
            return 0
        
        # Get metadata for index cleanup (no lock - read-only)
        metadatas = self.meta_storage.get_data(ids)
        
        # Build delete list (no lock - pure computation)
        indices_to_delete = []
        for uid, meta in zip(ids, metadatas):
            if meta:
                for key, value in meta.items():
                    val_str = self._format_for_indexing(value)
                    indices_to_delete.append((f"idx_{key}:{val_str}", uid))
        
        # Single write lock for all deletions
        with self._write_lock:
            self.storage.delete_flat_vectors(ids)
            
            if indices_to_delete:
                self.storage.batch_index_delete(indices_to_delete)
            
            self.meta_storage.delete_data(ids)
            
        return len(ids)
    
    def count(self):
        return self.meta_storage.get_data_count()
    
    def compact(self):
        """Reclaim space from deleted vectors"""
        if self.actual_dim == 0:
            return 0
        with self._write_lock:
            return self.storage.compact_vectors(self.actual_dim)
    
    def _format_for_indexing(self, value):
        if isinstance(value, (datetime.date, datetime.datetime)): 
            return value.isoformat()
        if isinstance(value, bool): 
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            offset = decimal.Decimal(2**63)
            return f"{decimal.Decimal(value) + offset:064.8f}"
        return str(value)
    
    def _generate_ids(self, count):
        ids = []
        with self._id_lock:
            now = int(time.time() * 1000)
            if now <= self._last_timestamp: 
                now = self._last_timestamp
            start_idx = self._counter
            self._counter += count
            self._last_timestamp = now
            base_id = (now << 16)
            for i in range(count):
                ids.append(base_id | ((start_idx + i) & 0xFFFF))
        return ids
    
    def _compile_filter(self, query):
        if not query: 
            return None
        
        nodes = []
        for key, value in query.items():
            if key == "$and":
                sub_nodes = [self._compile_filter(q) for q in value]
                nodes.extend([n for n in sub_nodes if n])
                continue
            
            if key == "$or":
                sub_nodes = [self._compile_filter(q) for q in value]
                valid_subs = [n for n in sub_nodes if n]
                if valid_subs: 
                    nodes.append((3, valid_subs))
                continue
            
            if key == "$not":
                sub = self._compile_filter(value)
                if sub: 
                    nodes.append((4, sub))
                continue
            
            prefix_base = f"idx_{key}:"
            
            if isinstance(value, dict):
                field_nodes = []
                
                if "$in" in value:
                    or_nodes = []
                    for v in value["$in"]:
                        val_str = self._format_for_indexing(v)
                        or_nodes.append((0, f"{prefix_base}{val_str}"))
                    if or_nodes: 
                        field_nodes.append((3, or_nodes))
                
                if "$ne" in value:
                    val_str = self._format_for_indexing(value["$ne"])
                    r1_start = f"{prefix_base}"
                    r1_end = f"{prefix_base}{val_str}"
                    r2_start = f"{prefix_base}{val_str}{self.MAX_CHAR}"
                    r2_end = f"{prefix_base}{self.MAX_CHAR}"
                    ne_node = (3, [(1, r1_start, r1_end), (1, r2_start, r2_end)])
                    field_nodes.append(ne_node)
                
                gt = value.get("$gt")
                gte = value.get("$gte")
                lt = value.get("$lt")
                lte = value.get("$lte")
                
                if any(x is not None for x in [gt, gte, lt, lte]):
                    if gte is not None: 
                        s = f"{prefix_base}{self._format_for_indexing(gte)}"
                    elif gt is not None: 
                        s = f"{prefix_base}{self._format_for_indexing(gt)}{self.MAX_CHAR}"
                    else: 
                        s = f"{prefix_base}"
                    
                    if lte is not None: 
                        e = f"{prefix_base}{self._format_for_indexing(lte)}{self.MAX_CHAR}"
                    elif lt is not None: 
                        e = f"{prefix_base}{self._format_for_indexing(lt)}"
                    else: 
                        e = f"{prefix_base}{self.MAX_CHAR}"
                    
                    field_nodes.append((1, s, e))
                
                if field_nodes:
                    if len(field_nodes) == 1: 
                        nodes.append(field_nodes[0])
                    else: 
                        nodes.append((2, field_nodes))
            else:
                val_str = self._format_for_indexing(value)
                nodes.append((0, f"{prefix_base}{val_str}"))
        
        if not nodes: 
            return None
        if len(nodes) == 1: 
            return nodes[0]
        return (2, nodes)
