"""Configuration module for codesense."""
