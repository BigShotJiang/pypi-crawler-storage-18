# Images
## Metadata
By default, ComfyUI and ComfyScript will save the workflow into the generated image's metadata (in both virtual and real mode). The workflow can then be loaded from the image into ComfyUI's web UI and ComfyScript's [MetadataViewer](../UI/Solara.md#metadataviewer).

You can disable this behavior by passing `--disable-metadata` when launching ComfyUI. If you start ComfyUI in ComfyScript, use the following code:
```python
from comfy_script.runtime import *
load(args=ComfyUIArgs('--disable-metadata'))
from comfy_script.runtime.nodes import *
```

Note that only PNG images are fully supported, [WebP may cannot be loaded properly](https://github.com/Chaoses-Ib/ComfyScript/issues/19) due to bugs/limitations in custom nodes and ComfyUI.

## Loading
### [From path](https://github.com/Chaoses-Ib/ComfyUI_Ib_CustomNodes#load-image-from-path)
```python
def LoadImageFromPath(
    image: str = r'ComfyUI_00001_-assets\ComfyUI_00001_.png [output]'
) -> tuple[Image, Mask]
```
One use of this node is to work with Photoshop's [Quick Export](https://helpx.adobe.com/photoshop/using/export-artboards-layers.html#:~:text=in%20Photoshop.-,Quick%20Export%20As,-Use%20the%20Quick) to quickly perform img2img/inpaint on the edited image. Update: For working with Photoshop, [comfyui-photoshop](https://github.com/NimaNzrii/comfyui-photoshop) is more convenient and supports waiting for changes. See [tutorial at r/comfyui](https://www.reddit.com/r/comfyui/comments/18jygtn/new_ai_news_photoshop_to_comfyui_v1_is_finally/).

### [From Base64](https://github.com/Acly/comfyui-tooling-nodes)
```python
def ETNLoadImageBase64(
    image: str
) -> tuple[Image, Mask]

def ETNLoadMaskBase64(
    mask: str
) -> Mask
```

### From empty
```python
def EmptyImage(
    width: int = 512,
    height: int = 512,
    batch_size: int = 1,
    color: int = 0
) -> Image
```

### [From Photoshop](https://github.com/NimaNzrii/comfyui-photoshop) (not built-in)
```python
def PhotoshopToComfyUI(
    password: str = '12341234',
    wait_for_photoshop_changes: bool = False
) -> tuple[Image, Int, Int]
```
See [tutorial at r/comfyui](https://www.reddit.com/r/comfyui/comments/18jygtn/new_ai_news_photoshop_to_comfyui_v1_is_finally/).

### [From `PIL.Image.Image`](https://github.com/Chaoses-Ib/ComfyUI_Ib_CustomNodes) (real mode)
```python
def PILToImage(
    images: PilImage
) -> Image

def PILToMask(
    images: PilImage
) -> Image
```

### From `input` directory
```python
def LoadImage(
    image: LoadImage.image = 'ComfyUI_00001_.png'
) -> tuple[Image, Mask]

def LoadImageMask(
    image: LoadImageMask.image = 'ComfyUI_00001_.png',
    channel: LoadImageMask.channel = 'alpha'
) -> Mask
```

## Saving
### To `output` directory
```python
def SaveImage(
    images: Image,
    filename_prefix: str = 'ComfyUI'
)
```

Retrieving the saved images:
```python
from PIL import Image

image = EmptyImage(512, 512, 1)
image = SaveImage(image, 'ComfyUI')

image_batch = image.wait()

# Get the first image
image: Image.Image = image_batch[0]

# Get all images in the batch
images: list[Image.Image] = image_batch.wait()
```
Or with `await`:
```python
from PIL import Image

image = EmptyImage(512, 512, 1)
image = SaveImage(image, 'ComfyUI')

image_batch = await image

# Get the first image
image: Image.Image = await image_batch.get(0)

# Get all images in the batch
images: list[Image.Image] = await image_batch
```

### To `temp` directory
```python
def PreviewImage(
    images: Image
)
```

Retrieving the preview images:
```python
from PIL import Image

image = EmptyImage(512, 512, 1)
image = PreviewImage(image)

image_batch = image.wait()

# Get the first image
image: Image.Image = image_batch[0]

# Get all images in the batch
images: list[Image.Image] = image_batch.wait()
```
Or with `await`:
```python
from PIL import Image

image = EmptyImage(512, 512, 1)
image = PreviewImage(image)

image_batch = await image

# Get the first image
image: Image.Image = await image_batch.get(0)

# Get all images in the batch
images: list[Image.Image] = await image_batch
```

### [To client](https://github.com/Acly/comfyui-tooling-nodes)
```python
def ETNSendImageWebSocket(
    images: Image
)
```
Sends an output image over the client WebSocket connection as PNG binary data.

### [To `PIL.Image.Image`](https://github.com/Chaoses-Ib/ComfyUI_Ib_CustomNodes) (real mode)
```python
def ImageToPIL(
    images: Image
) -> PilImage
```

### To animation
```python
def SaveAnimatedWEBP(
    images: Image,
    filename_prefix: str = 'ComfyUI',
    fps: float = 6.0,
    lossless: bool = True,
    quality: int = 80,
    method: SaveAnimatedWEBP.method = 'default'
)

def SaveAnimatedPNG(
    images: Image,
    filename_prefix: str = 'ComfyUI',
    fps: float = 6.0,
    compress_level: int = 4
)
```

## Masking
Creating:
```python
def SolidMask(
    value: float = 1.0,
    width: int = 512,
    height: int = 512
) -> Mask

def ImageToMask(
    image: Image,
    channel: ImageToMask.channel = 'red'
) -> Mask

def ImageColorToMask(
    image: Image,
    color: int = 0
) -> Mask

def MaskToImage(
    mask: Mask
) -> Image
```

[Applying](https://github.com/Acly/comfyui-tooling-nodes):
```python
def ETNApplyMaskToImage(
    image: Image,
    mask: Mask
) -> Image
```

## Batching
```python
def ImageBatch(
    image1: Image,
    image2: Image
) -> Image

def RebatchImages(
    images: Image,
    batch_size: int = 1
) -> Image

def RepeatImageBatch(
    image: Image,
    amount: int = 1
) -> Image
```