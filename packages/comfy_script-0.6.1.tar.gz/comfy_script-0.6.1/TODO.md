
batch index
webp


# Turns out retrying doesn't help at most times but annoying
print(f'ComfyScript: Failed to watch, you can retry it via `queue.start_watch()`')
