import os
import shutil

def create_project(name):
    if os.path.exists(name):
        print(f"Folder '{name}' already exists!")
        return

    os.makedirs(f"{name}/pages", exist_ok=True)
    os.makedirs(f"{name}/assets", exist_ok=True)

    # Create starter pages
    with open(f"{name}/pages/index.py", "w") as f:
        f.write('def get():\n    return "<h1>Home Page</h1>"\n')

    with open(f"{name}/pages/about.py", "w") as f:
        f.write('def get():\n    return "<h1>About Page</h1>"\n')

    # Create main.py
    with open(f"{name}/main.py", "w") as f:
        f.write("from flowweb import FlowWeb\napp = FlowWeb()\napp.run(port=3000)\n")

    print(f"FlowWeb project '{name}' created successfully!")

def main():
    import sys
    if len(sys.argv) < 2:
        print("Usage: flowweb create <project_name>")
        return

    if sys.argv[1] == "create":
        create_project(sys.argv[2])
    else:
        print("Unknown command")
