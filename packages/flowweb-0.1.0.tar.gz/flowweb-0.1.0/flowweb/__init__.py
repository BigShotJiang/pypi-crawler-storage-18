import socketserver
from flowweb.server import MiniHandler  # absolute import

class FlowWeb:
    def run(self, port=3000):
        with socketserver.TCPServer(("", port), MiniHandler) as httpd:
            print(f"FlowWeb running at http://localhost:{port}")
            httpd.serve_forever()
