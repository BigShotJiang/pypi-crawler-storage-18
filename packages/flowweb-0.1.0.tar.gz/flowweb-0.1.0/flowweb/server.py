from http.server import BaseHTTPRequestHandler
from flowweb.router import load_pages

class MiniHandler(BaseHTTPRequestHandler):
    routes = load_pages()
    
    def do_GET(self):
        handler = self.routes.get(self.path)
        if handler:
            result = handler()
            self.send_response(200)
        else:
            result = "<h1>404 Not Found</h1>"
            self.send_response(404)

        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(result.encode())
