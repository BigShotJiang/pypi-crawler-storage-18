import os
import importlib.util

def load_pages(base="pages"):
    routes = {}

    for root, _, files in os.walk(base):
        for file in files:
            if not file.endswith(".py"):
                continue

            name = file[:-3]
            path = os.path.join(root, file)

            route = "/" + os.path.relpath(path, base).replace("\\", "/").replace(".py","")
            if route.endswith("/index"):
                route = route[:-6]
            if route == "index":
                route = "/"

            route = "/" + route.lstrip("/")

            spec = importlib.util.spec_from_file_location(route, path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            if hasattr(mod, "get"):
                # register route with and without trailing slash
                routes[route] = mod.get
                if not route.endswith("/"):
                    routes[route+"/"] = mod.get
                # map /index if it's the root page
                if route == "/":
                    routes["/index"] = mod.get


    return routes
