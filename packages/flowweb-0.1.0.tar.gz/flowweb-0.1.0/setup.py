from setuptools import setup, find_packages

setup(
    name="flowweb",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "flowweb=flowweb.cli:main",
        ],
    },
    author="Your Name",
    description="A mini Flask-like Python framework with file-based routing",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/flowweb",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
