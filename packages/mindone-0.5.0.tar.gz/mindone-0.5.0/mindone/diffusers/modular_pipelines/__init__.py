from typing import TYPE_CHECKING

from ..utils import _LazyModule, logging

logger = logging.get_logger(__name__)
logger.warning(
    "Modular Diffusers is currently an experimental feature under active development. The API is subject to breaking changes in future releases."
)

# These modules contain pipelines from multiple libraries/frameworks
_dummy_objects = {}
_import_structure = {}

_import_structure["modular_pipeline"] = [
    "ModularPipelineBlocks",
    "ModularPipeline",
    "AutoPipelineBlocks",
    "SequentialPipelineBlocks",
    "LoopSequentialPipelineBlocks",
    "PipelineState",
    "BlockState",
]
_import_structure["modular_pipeline_utils"] = [
    "ComponentSpec",
    "ConfigSpec",
    "InputParam",
    "OutputParam",
    "InsertableDict",
]
_import_structure["stable_diffusion_xl"] = ["StableDiffusionXLAutoBlocks", "StableDiffusionXLModularPipeline"]
_import_structure["wan"] = ["WanAutoBlocks", "WanModularPipeline"]
_import_structure["flux"] = ["FluxAutoBlocks", "FluxModularPipeline"]
_import_structure["qwenimage"] = [
    "QwenImageAutoBlocks",
    "QwenImageModularPipeline",
    "QwenImageEditModularPipeline",
    "QwenImageEditAutoBlocks",
    "QwenImageEditPlusModularPipeline",
    "QwenImageEditPlusAutoBlocks",
]
_import_structure["components_manager"] = ["ComponentsManager"]

if TYPE_CHECKING:
    from .components_manager import ComponentsManager
    from .flux import FluxAutoBlocks, FluxModularPipeline
    from .modular_pipeline import (
        AutoPipelineBlocks,
        BlockState,
        LoopSequentialPipelineBlocks,
        ModularPipeline,
        ModularPipelineBlocks,
        PipelineState,
        SequentialPipelineBlocks,
    )
    from .modular_pipeline_utils import ComponentSpec, ConfigSpec, InputParam, InsertableDict, OutputParam
    from .qwenimage import (
        QwenImageAutoBlocks,
        QwenImageEditAutoBlocks,
        QwenImageEditModularPipeline,
        QwenImageEditPlusAutoBlocks,
        QwenImageEditPlusModularPipeline,
        QwenImageModularPipeline,
    )
    from .stable_diffusion_xl import StableDiffusionXLAutoBlocks, StableDiffusionXLModularPipeline
    from .wan import WanAutoBlocks, WanModularPipeline
else:
    import sys

    sys.modules[__name__] = _LazyModule(
        __name__,
        globals()["__file__"],
        _import_structure,
        module_spec=__spec__,
    )
    for name, value in _dummy_objects.items():
        setattr(sys.modules[__name__], name, value)
