StreamHandle = str
