"""Page domain implementation."""
