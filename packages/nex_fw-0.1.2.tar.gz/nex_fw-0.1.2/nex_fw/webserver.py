"""
NexFramework WebServer - 集成 API 和前端的 Web 服务器
"""
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional
import json
import os
from .framework import NexFramework

app = FastAPI(title="NexFramework WebServer", version="0.1.0")

# 使用当前工作目录
nex = NexFramework(os.getcwd())

# 静态文件目录
STATIC_DIR = os.path.join(os.path.dirname(__file__), 'static')


class ChatRequest(BaseModel):
    user: str = "guest"
    message: str
    stream: bool = False


class DeleteRequest(BaseModel):
    id: Optional[int] = None


class SwitchModelRequest(BaseModel):
    model_key: str


# ========== API 接口 ==========
@app.post("/nex/chat")
async def chat(req: ChatRequest):
    """对话接口"""
    try:
        if req.stream:
            def generate():
                tool_events = []
                def collect_tool(event, data):
                    tool_events.append((event, data))
                for chunk in nex.chat_stream(req.user, req.message, on_tool_call=collect_tool):
                    while tool_events:
                        e, d = tool_events.pop(0)
                        yield f"data: {json.dumps({'type': e, 'data': d}, ensure_ascii=False)}\n\n"
                    yield f"data: {json.dumps({'type': 'content', 'data': chunk}, ensure_ascii=False)}\n\n"
                yield f"data: {json.dumps({'type': 'done'})}\n\n"
            return StreamingResponse(generate(), media_type="text/event-stream")
        else:
            reply = nex.chat(req.user, req.message)
            return {"code": 0, "data": {"reply": reply}}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/nex/history")
async def get_history(limit: Optional[int] = None):
    return {"code": 0, "data": nex.get_history(limit)}


@app.delete("/nex/history")
async def delete_history(req: DeleteRequest = None):
    if nex.delete_history(req.id if req else None):
        return {"code": 0, "message": "删除成功"}
    raise HTTPException(status_code=404, detail="记录不存在")


@app.get("/nex/models")
async def get_models():
    return {"code": 0, "data": {"models": nex.get_models(), "current": nex.get_current_model()}}


@app.post("/nex/models/switch")
async def switch_model(req: SwitchModelRequest):
    if nex.switch_model(req.model_key):
        return {"code": 0, "data": nex.get_current_model(), "message": "切换成功"}
    raise HTTPException(status_code=404, detail="模型不存在")


@app.get("/nex/tools")
async def get_tools():
    """获取所有可用工具列表"""
    tools_list = []
    for tool in nex.tools:
        func = tool.get("function", {})
        tools_list.append({
            "name": func.get("name"),
            "description": func.get("description"),
            "parameters": func.get("parameters"),
            "has_handler": func.get("name") in nex._custom_tools or func.get("name") in ["execute_shell", "http_request"]
        })
    return {"code": 0, "data": tools_list}


# ========== 前端页面 ==========
@app.get("/", response_class=HTMLResponse)
async def index():
    html_path = os.path.join(STATIC_DIR, 'index.html')
    with open(html_path, 'r', encoding='utf-8') as f:
        return f.read()
