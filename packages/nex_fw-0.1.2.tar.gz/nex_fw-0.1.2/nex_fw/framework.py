"""
NexFramework 核心模块
"""
from openai import OpenAI
import os
import json
from datetime import datetime
import filelock
import subprocess
import requests
from typing import Optional, Callable, Generator, Dict, List


class NexFramework:
    """AI 对话框架，支持多模型切换、工具调用、流式输出"""
    
    def __init__(
        self,
        work_dir: str,
        default_model: str = "default",
    ):
        """
        初始化 NexFramework
        
        Args:
            work_dir: 工作目录，包含配置文件
            default_model: 默认使用的模型 key
        """
        self.work_dir = os.path.abspath(work_dir)
        
        # 文件路径
        self.models_file = os.path.join(self.work_dir, 'model_config.json')
        self.prompt_file = os.path.join(self.work_dir, 'prompt_config.txt')
        self.history_file = os.path.join(self.work_dir, 'chat_history.json')
        self.tools_dir = os.path.join(self.work_dir, 'tools')
        self.lock_file = self.history_file + ".lock"
        
        # 初始化
        self.models = self._load_models()
        # 如果指定的模型不存在，使用第一个可用模型
        if default_model not in self.models:
            default_model = next(iter(self.models.keys()))
        self.current_model_key = default_model
        self._init_client()
        self.lock = filelock.FileLock(self.lock_file, timeout=10)
        self._init_tools()
        self._custom_tools: Dict[str, Callable] = {}
        self._load_custom_tools()
    
    def _load_models(self) -> Dict:
        """加载模型配置"""
        if os.path.exists(self.models_file):
            try:
                with open(self.models_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                raise RuntimeError(f"加载模型配置失败: {e}")
        raise FileNotFoundError(f"模型配置文件不存在: {self.models_file}\n请运行 nex init 初始化")
    
    def _init_client(self):
        """初始化模型客户端"""
        if self.current_model_key not in self.models:
            available = list(self.models.keys())
            raise ValueError(f"模型 '{self.current_model_key}' 不存在，可用: {available}")
        config = self.models[self.current_model_key]
        self.client = OpenAI(api_key=config['api_key'], base_url=config['base_url'])
        self.model = config['model']

    def _init_tools(self):
        """初始化内置工具"""
        self.tools = [
            {
                "type": "function",
                "function": {
                    "name": "execute_shell",
                    "description": "执行shell命令并返回结果",
                    "parameters": {
                        "type": "object",
                        "properties": {"command": {"type": "string", "description": "要执行的shell命令"}},
                        "required": ["command"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "http_request",
                    "description": "发送HTTP请求获取网页内容或API数据",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "url": {"type": "string", "description": "请求的URL"},
                            "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE"]},
                            "headers": {"type": "object", "description": "请求头"},
                            "body": {"type": "string", "description": "请求体"}
                        },
                        "required": ["url"]
                    }
                }
            }
        ]
    
    def _load_custom_tools(self):
        """从 tools/ 目录加载自定义工具
        
        支持两种方式：
        1. JSON + Python: tool.json 定义 + tool.py 执行脚本
        2. 纯 Python: tool.py 中包含 TOOL_DEF 定义和 execute(args) 函数
        """
        if not os.path.exists(self.tools_dir):
            return
        
        loaded_tools = set()
        
        # 方式1: 加载 JSON 定义的工具
        for filename in os.listdir(self.tools_dir):
            if filename.endswith('.json'):
                tool_name = filename[:-5]  # 去掉 .json
                json_path = os.path.join(self.tools_dir, filename)
                py_path = os.path.join(self.tools_dir, f"{tool_name}.py")
                
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        tool_def = json.load(f)
                    
                    self.tools.append({"type": "function", "function": tool_def})
                    actual_name = tool_def.get("name", tool_name)
                    
                    # 如果有对应的 .py 文件，加载执行函数
                    if os.path.exists(py_path):
                        handler = self._load_py_handler(py_path, actual_name)
                        if handler:
                            self._custom_tools[actual_name] = handler
                    
                    loaded_tools.add(tool_name)
                except Exception as e:
                    print(f"[警告] 加载工具 {filename} 失败: {e}")
        
        # 方式2: 加载纯 Python 定义的工具
        for filename in os.listdir(self.tools_dir):
            if filename.endswith('.py'):
                tool_name = filename[:-3]
                if tool_name in loaded_tools:
                    continue  # 已经作为 JSON 工具的执行脚本加载过了
                
                py_path = os.path.join(self.tools_dir, filename)
                try:
                    tool_def, handler = self._load_py_tool(py_path)
                    if tool_def and handler:
                        self.tools.append({"type": "function", "function": tool_def})
                        self._custom_tools[tool_def["name"]] = handler
                except Exception as e:
                    print(f"[警告] 加载工具 {filename} 失败: {e}")
    
    def _load_py_handler(self, py_path: str, tool_name: str) -> Optional[Callable]:
        """从 Python 文件加载执行函数"""
        import importlib.util
        try:
            spec = importlib.util.spec_from_file_location(tool_name, py_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # 查找 execute 函数
            if hasattr(module, 'execute'):
                return module.execute
            # 或者查找与工具同名的函数
            if hasattr(module, tool_name):
                return getattr(module, tool_name)
        except Exception as e:
            print(f"[警告] 加载 {py_path} 失败: {e}")
        return None
    
    def _load_py_tool(self, py_path: str) -> tuple:
        """从纯 Python 文件加载工具定义和执行函数"""
        import importlib.util
        tool_name = os.path.basename(py_path)[:-3]
        try:
            spec = importlib.util.spec_from_file_location(tool_name, py_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # 需要有 TOOL_DEF 和 execute
            if hasattr(module, 'TOOL_DEF') and hasattr(module, 'execute'):
                return module.TOOL_DEF, module.execute
        except Exception as e:
            print(f"[警告] 加载 {py_path} 失败: {e}")
        return None, None

    # ========== 工具注册 ==========
    def register_tool(self, name: str, description: str, parameters: Dict, handler: Callable) -> None:
        """注册自定义工具"""
        self.tools.append({
            "type": "function",
            "function": {"name": name, "description": description, "parameters": parameters}
        })
        self._custom_tools[name] = handler
    
    # ========== 模型管理 ==========
    def switch_model(self, model_key: str) -> bool:
        if model_key in self.models:
            self.current_model_key = model_key
            self._init_client()
            return True
        return False
    
    def get_models(self) -> List[Dict]:
        return [{"key": k, "name": v.get("name", k), "model": v.get("model")} for k, v in self.models.items()]
    
    def get_current_model(self) -> Dict:
        return {"key": self.current_model_key, "name": self.models[self.current_model_key].get("name"), "model": self.model}
    
    def add_model(self, key: str, name: str, api_key: str, base_url: str, model: str, save: bool = False) -> None:
        self.models[key] = {"name": name, "api_key": api_key, "base_url": base_url, "model": model}
        if save:
            self._save_models()
    
    def _save_models(self) -> None:
        with open(self.models_file, 'w', encoding='utf-8') as f:
            json.dump(self.models, f, ensure_ascii=False, indent=2)
    
    # ========== 工具执行 ==========
    def execute_shell(self, command: str) -> str:
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30, encoding='utf-8', errors='replace')
            return (result.stdout or result.stderr or "(无输出)")[:2000]
        except subprocess.TimeoutExpired:
            return "命令执行超时(30秒)"
        except Exception as e:
            return f"执行失败: {e}"
    
    def http_request(self, url: str, method: str = "GET", headers: Dict = None, body: str = None) -> str:
        try:
            resp = requests.request(method.upper(), url, headers=headers, data=body, timeout=15)
            return f"状态码: {resp.status_code}\n内容:\n{resp.text[:3000]}"
        except requests.Timeout:
            return "请求超时(15秒)"
        except requests.RequestException as e:
            return f"请求失败: {e}"
    
    def handle_tool_call(self, tool_call) -> str:
        if isinstance(tool_call, dict):
            name, args = tool_call["function"]["name"], json.loads(tool_call["function"]["arguments"])
        else:
            name, args = tool_call.function.name, json.loads(tool_call.function.arguments)
        
        if name == "execute_shell":
            return self.execute_shell(args["command"])
        elif name == "http_request":
            return self.http_request(args["url"], args.get("method", "GET"), args.get("headers"), args.get("body"))
        elif name in self._custom_tools:
            try:
                return str(self._custom_tools[name](args))
            except Exception as e:
                return f"工具执行失败: {e}"
        return "未知工具"

    # ========== 历史管理 ==========
    def load_history(self) -> List[Dict]:
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def save_history(self, history: List[Dict]) -> None:
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    
    def get_history(self, limit: int = None) -> List[Dict]:
        history = self.load_history()
        return history[-limit:] if limit else history
    
    def delete_history(self, history_id: int = None) -> bool:
        with self.lock:
            history = self.load_history()
            if history_id is None:
                self.save_history([])
                return True
            for i, entry in enumerate(history):
                if entry.get('id') == history_id:
                    history.pop(i)
                    self.save_history(history)
                    return True
        return False
    
    def _read_prompt(self) -> str:
        try:
            with open(self.prompt_file, 'r', encoding='utf-8') as f:
                return f.read()
        except:
            return "You are a helpful assistant."
    
    def set_prompt(self, prompt: str) -> None:
        self._runtime_prompt = prompt
    
    def _get_prompt(self) -> str:
        return getattr(self, '_runtime_prompt', None) or self._read_prompt()

    # ========== 对话功能 ==========
    def chat(self, user: str, message: str, save_history: bool = True) -> str:
        now = datetime.now().strftime("%Y年%m月%d日 %H:%M")
        prompt = f"【系统信息】\n当前时间: {now}\n【以下为输入内容】\n===[{user}] {message}"
        
        history = self.load_history()
        messages = [{"role": "system", "content": self._get_prompt()}]
        for entry in history[-50:]:
            messages.append({"role": "user", "content": f"[{entry['user']}] {entry['message']}"})
            messages.append({"role": "assistant", "content": entry['response']})
        messages.append({"role": "user", "content": prompt})
        
        response = self.client.chat.completions.create(
            model=self.model, messages=messages, tools=self.tools, tool_choice="auto", max_tokens=1000, temperature=0.7
        )
        assistant_message = response.choices[0].message
        
        while assistant_message.tool_calls:
            messages.append(assistant_message)
            for tc in assistant_message.tool_calls:
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": self.handle_tool_call(tc)})
            response = self.client.chat.completions.create(
                model=self.model, messages=messages, tools=self.tools, tool_choice="auto", max_tokens=1000, temperature=0.7
            )
            assistant_message = response.choices[0].message
        
        reply = assistant_message.content
        if save_history:
            with self.lock:
                history = self.load_history()
                new_id = max([e.get('id', 0) for e in history], default=0) + 1
                history.append({"id": new_id, "user": user, "message": message, "response": reply, "time": now})
                self.save_history(history)
        return reply

    def chat_stream(self, user: str, message: str, on_tool_call: Callable = None, save_history: bool = True) -> Generator[str, None, None]:
        now = datetime.now().strftime("%Y年%m月%d日 %H:%M")
        prompt = f"【系统信息】\n当前时间: {now}\n【以下为输入内容】\n===[{user}] {message}"
        
        history = self.load_history()
        messages = [{"role": "system", "content": self._get_prompt()}]
        for entry in history[-50:]:
            messages.append({"role": "user", "content": f"[{entry['user']}] {entry['message']}"})
            messages.append({"role": "assistant", "content": entry['response']})
        messages.append({"role": "user", "content": prompt})
        
        full_reply = ""
        while True:
            stream = self.client.chat.completions.create(
                model=self.model, messages=messages, tools=self.tools, tool_choice="auto",
                max_tokens=1000, temperature=0.7, stream=True
            )
            
            content_buffer = ""
            tool_calls_buffer = {}
            
            for chunk in stream:
                delta = chunk.choices[0].delta
                if delta.content:
                    content_buffer += delta.content
                    yield delta.content
                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        idx = tc.index
                        if idx not in tool_calls_buffer:
                            tool_calls_buffer[idx] = {"id": "", "name": "", "arguments": ""}
                        if tc.id:
                            tool_calls_buffer[idx]["id"] = tc.id
                        if tc.function:
                            if tc.function.name:
                                tool_calls_buffer[idx]["name"] = tc.function.name
                            if tc.function.arguments:
                                tool_calls_buffer[idx]["arguments"] += tc.function.arguments
            
            if tool_calls_buffer:
                tool_calls_list = [{"id": tc["id"], "type": "function", "function": {"name": tc["name"], "arguments": tc["arguments"]}}
                                   for tc in [tool_calls_buffer[i] for i in sorted(tool_calls_buffer.keys())]]
                messages.append({"role": "assistant", "content": content_buffer or None, "tool_calls": tool_calls_list})
                
                for tc in tool_calls_list:
                    name, args = tc["function"]["name"], json.loads(tc["function"]["arguments"])
                    if on_tool_call:
                        on_tool_call("tool_start", {"name": name, "args": args})
                    result = self.handle_tool_call(tc)
                    if on_tool_call:
                        on_tool_call("tool_end", {"name": name, "result": result})
                    messages.append({"role": "tool", "tool_call_id": tc["id"], "content": result})
                continue
            else:
                full_reply = content_buffer
                break
        
        if save_history:
            with self.lock:
                history = self.load_history()
                new_id = max([e.get('id', 0) for e in history], default=0) + 1
                history.append({"id": new_id, "user": user, "message": message, "response": full_reply, "time": now})
                self.save_history(history)
