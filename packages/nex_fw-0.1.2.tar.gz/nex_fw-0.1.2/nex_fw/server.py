"""
NexFramework Console Server - 控制台管理服务器
"""
import subprocess
import sys
import os
import getpass
from .framework import NexFramework


class NexServer:
    def __init__(self, work_dir: str = "."):
        self.work_dir = os.path.abspath(work_dir)
        self.nex = NexFramework(self.work_dir)
        # 使用系统用户名作为默认用户
        self.current_user = getpass.getuser()
        self.api_process = None
        self.api_running = False
        # 启动时恢复上次使用的模型
        self._restore_last_model()

    def start_api(self, host="0.0.0.0", port=8000):
        if self.api_running:
            print("[Server] WebServer 已在运行中")
            return
        try:
            self.api_process = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "nex_fw.webserver:app", "--host", host, "--port", str(port)],
                cwd=self.work_dir,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            self.api_running = True
            print(f"[Server] WebServer 已启动 http://{host}:{port}")
        except Exception as e:
            print(f"[Server] 启动失败: {e}")

    def stop_api(self):
        if not self.api_running or not self.api_process:
            print("[Server] WebServer 未运行")
            return
        try:
            self.api_process.terminate()
            self.api_process.wait(timeout=5)
            self.api_running = False
            print("[Server] WebServer 已停止")
        except Exception as e:
            print(f"[Server] 停止失败: {e}")

    def _restore_last_model(self):
        """从历史记录恢复上次使用的模型"""
        history = self.nex.load_history()
        if history and 'last_model' in history[0]:
            last_model = history[0]['last_model']
            if last_model in [m['key'] for m in self.nex.get_models()]:
                self.nex.switch_model(last_model)

    def _save_last_model(self):
        """保存当前模型到历史记录"""
        history = self.nex.load_history()
        if not history:
            history = [{}]
        if not isinstance(history[0], dict) or 'id' in history[0]:
            # 第一条是聊天记录，插入元数据
            history.insert(0, {'last_model': self.nex.current_model_key})
        else:
            history[0]['last_model'] = self.nex.current_model_key
        self.nex.save_history(history)

    def show_status(self):
        print("\n" + "=" * 50)
        print("  NexFramework 状态")
        print("=" * 50)
        print(f"  工作目录: {self.work_dir}")
        print(f"  WebServer: {'🟢 运行中' if self.api_running else '🔴 已停止'}")
        model = self.nex.get_current_model()
        print(f"  当前模型: {model['name']} ({model['model']})")
        print(f"  当前用户: {self.current_user}")
        print(f"  历史记录: {len(self.nex.get_history())} 条")
        print("=" * 50 + "\n")

    def show_models(self):
        current = self.nex.get_current_model()
        print("\n[Models] 可用模型:")
        for m in self.nex.get_models():
            marker = " *" if m['key'] == current['key'] else ""
            print(f"  {m['key']}: {m['name']} ({m['model']}){marker}")
        print()

    def on_tool_call(self, event, data):
        if event == "tool_start":
            print(f"\n[Tool] 调用 {data['name']}")
            if data['name'] == 'execute_shell':
                print(f"       命令: {data['args'].get('command', '')}")
            elif data['name'] == 'http_request':
                print(f"       URL: {data['args'].get('url', '')}")
        elif event == "tool_end":
            result = data['result'][:150] + "..." if len(data['result']) > 150 else data['result']
            print(f"       结果: {result}\n")

    def chat(self, message):
        print("[Nex] ", end="", flush=True)
        for chunk in self.nex.chat_stream(self.current_user, message, on_tool_call=self.on_tool_call):
            print(chunk, end="", flush=True)
        print()

    def show_help(self):
        print("""
╔══════════════════════════════════════════════════════╗
║            NexFramework Console 命令                 ║
╠══════════════════════════════════════════════════════╣
║  /start [port]     启动 WebServer (默认 8000)        ║
║  /stop             停止 WebServer                    ║
║  /status           查看服务状态                      ║
║  /models           查看可用模型                      ║
║  /use <key>        切换模型                          ║
║  /user <name>      切换用户                          ║
║  /whoami           显示当前用户                      ║
║  /history [n]      查看最近n条历史                   ║
║  /clear            清空历史记录                      ║
║  /help             显示此帮助                        ║
║  /quit             退出程序                          ║
║  直接输入文字即可与 AI 对话                          ║
╚══════════════════════════════════════════════════════╝
""")


def main(work_dir: str = "."):
    work_dir = os.path.abspath(work_dir)
    server = NexServer(work_dir)
    print("\n" + "=" * 50)
    print("     🚀 NexFramework Console")
    print("=" * 50)
    print(f"  📁 工作目录: {work_dir}")
    print("  输入 /help 查看命令, /start 启动WebServer")
    print("=" * 50 + "\n")

    while True:
        try:
            user_input = input(f"[{server.current_user}] > ").strip()
            if not user_input:
                continue

            parts = user_input.split(maxsplit=1)
            cmd, arg = parts[0].lower(), parts[1] if len(parts) > 1 else None

            if cmd == "/start":
                server.start_api(port=int(arg) if arg else 8000)
            elif cmd == "/stop":
                server.stop_api()
            elif cmd == "/status":
                server.show_status()
            elif cmd == "/models":
                server.show_models()
            elif cmd == "/use" and arg:
                if server.nex.switch_model(arg):
                    server._save_last_model()
                    print(f"[Server] 已切换到: {server.nex.get_current_model()['name']}")
                else:
                    print(f"[Server] 模型 '{arg}' 不存在")
            elif cmd == "/user" and arg:
                server.current_user = arg
                print(f"[Server] 已切换用户: {arg}")
            elif cmd == "/whoami":
                print(f"[Server] 当前用户: {server.current_user}")
            elif cmd == "/history":
                history = server.nex.get_history(int(arg) if arg else 5)
                if not history:
                    print("[Server] 暂无历史")
                else:
                    print(f"\n[History] 最近 {len(history)} 条:")
                    for e in history:
                        msg = e['message'][:40] + "..." if len(e['message']) > 40 else e['message']
                        print(f"  #{e.get('id', '?')} [{e['user']}] {msg}")
                    print()
            elif cmd == "/clear":
                server.nex.delete_history()
                print("[Server] 历史已清空")
            elif cmd == "/help":
                server.show_help()
            elif cmd == "/quit":
                server.stop_api()
                print("[Server] 再见! 👋")
                break
            elif cmd.startswith("/"):
                print("[Server] 未知命令，输入 /help 查看帮助")
            else:
                server.chat(user_input)
        except KeyboardInterrupt:
            print("\n[Server] 正在退出...")
            server.stop_api()
            print("[Server] 再见! 👋")
            break
        except Exception as e:
            print(f"[Server] 错误: {e}")


if __name__ == "__main__":
    main()
