from __future__ import absolute_import
from .health import Health, HealthBuilder, Status, CompositeHealthIndicator, Indicator, MetricIndicator, MetricEndPoint
from .actuator import create_actuator_route

from .health import get_health_manager


class DefaultIndicator(Indicator):
    @property
    def name(self) -> str:
        return 'application'

    def health(self) -> Health:
        return Health.up().build()


get_health_manager().add_indicator(DefaultIndicator())

__all__ = [
    "Health",
    "HealthBuilder",
    "Status",
    "get_health_manager",
    "CompositeHealthIndicator",
    "Indicator",
    "MetricIndicator",
    "MetricEndPoint",
    "create_actuator_route"
]
