#!/bin/bash
# ContextDigger - Install all Claude Code skills
# This script downloads all 37+ ContextDigger skills to ~/.claude/commands

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# GitHub repository
REPO="ialameh/contextdigger"
BRANCH="main"
BASE_URL="https://raw.githubusercontent.com/${REPO}/${BRANCH}/claude-skills"

# Skills to install
SKILLS=(
    "delete-context"
    "dig-analytics"
    "dig-auto"
    "dig-back"
    "dig-backup"
    "dig-benchmark"
    "dig-dashboard"
    "dig-deps"
    "dig-export"
    "dig-forward"
    "dig-gaps"
    "dig-health"
    "dig-history"
    "dig-hotspots"
    "dig-impact"
    "dig-map"
    "dig-note"
    "dig-notes"
    "dig-perf"
    "dig-query"
    "dig-report"
    "dig-rules"
    "dig-search"
    "dig-stats"
    "dig-status"
    "dig-suggest"
    "dig-team"
    "dig-tests"
    "dig-wiki"
    "dig"
    "goto-spot"
    "init-dig"
    "list-contexts"
    "load-context"
    "mark-spot"
    "redig"
    "save-context"
)

# Target directory
COMMANDS_DIR="${HOME}/.claude/commands"

echo -e "${BLUE}⛏️  ContextDigger Skill Installer${NC}"
echo -e "${BLUE}================================${NC}"
echo ""
echo -e "Installing ${GREEN}${#SKILLS[@]}${NC} skills to: ${YELLOW}${COMMANDS_DIR}${NC}"
echo ""

# Create directory if it doesn't exist
if [ ! -d "${COMMANDS_DIR}" ]; then
    echo -e "${YELLOW}Creating directory: ${COMMANDS_DIR}${NC}"
    mkdir -p "${COMMANDS_DIR}"
fi

# Change to commands directory
cd "${COMMANDS_DIR}"

# Download counter
SUCCESS=0
FAILED=0
SKIPPED=0

# Download each skill
for skill in "${SKILLS[@]}"; do
    FILENAME="${skill}.md"
    URL="${BASE_URL}/${FILENAME}"

    # Check if file already exists
    if [ -f "${FILENAME}" ]; then
        echo -e "${YELLOW}⊙${NC} ${skill} (already exists, updating...)"
        if curl -fsSL "${URL}" -o "${FILENAME}"; then
            ((SUCCESS++))
        else
            echo -e "${RED}  ✗ Failed to update${NC}"
            ((FAILED++))
        fi
    else
        echo -e "${BLUE}↓${NC} ${skill}"
        if curl -fsSL "${URL}" -o "${FILENAME}"; then
            ((SUCCESS++))
        else
            echo -e "${RED}  ✗ Failed to download${NC}"
            ((FAILED++))
        fi
    fi
done

echo ""
echo -e "${BLUE}================================${NC}"
echo -e "${GREEN}✓ Installation Complete!${NC}"
echo ""
echo -e "Summary:"
echo -e "  ${GREEN}Success:${NC} ${SUCCESS}"
if [ ${FAILED} -gt 0 ]; then
    echo -e "  ${RED}Failed:${NC}  ${FAILED}"
fi
echo ""
echo -e "Skills installed in: ${YELLOW}${COMMANDS_DIR}${NC}"
echo ""
echo -e "${BLUE}Quick Start:${NC}"
echo -e "  1. Open Claude Code in your project"
echo -e "  2. Run: ${GREEN}/init-dig${NC} to discover code areas"
echo -e "  3. Run: ${GREEN}/dig <area>${NC} to start exploring"
echo ""
echo -e "${BLUE}Available Commands:${NC}"
echo -e "  Discovery:    /init-dig, /dig, /redig, /dig-status"
echo -e "  Navigation:   /dig-back, /dig-forward, /dig-history"
echo -e "  Bookmarks:    /mark-spot, /goto-spot"
echo -e "  Team:         /dig-team, /dig-note, /dig-wiki"
echo -e "  Intelligence: /dig-deps, /dig-hotspots, /dig-gaps"
echo -e "  Analytics:    /dig-analytics, /dig-dashboard, /dig-stats"
echo -e "  Export:       /dig-export, /dig-backup, /dig-report"
echo ""
echo -e "Documentation: ${BLUE}https://github.com/${REPO}${NC}"
echo ""

# Exit with appropriate code
if [ ${FAILED} -gt 0 ]; then
    exit 1
else
    exit 0
fi
