# Changelog

All notable changes to ContextDigger will be documented in this file.

## [1.1.0] - 2025-12-22

### Added - Phase 1: Core Governance Features 🎯

This release transforms ContextDigger from a navigation tool into an **AI context governance system**.

#### 🎯 Context Budget System
- **Budget Tracking**: Automatically calculates and displays file/line counts for every area
- **Budget Display**: Shows `Budget: X/Y files, A/B lines` after dig commands
- **Warning Thresholds**: Alerts at 80% budget usage with ⚠️ symbol
- **Line Count Caching**: Optimized performance with intelligent file caching
- **Configuration**: Default limits of 15 files / 3,000 lines (configurable in `.cdg/config.json`)

#### 🚫 Refusal Mode (Governance Discipline)
- **Budget Enforcement**: Refuses to load areas exceeding budget limits
- **Clear Error Messages**: Shows exactly why refusal occurred with actual vs. budget numbers
- **Sub-Area Suggestions**: Automatically suggests smaller, focused areas when budget exceeded
- **Exit Codes**: Returns exit code 1 when refusing to enforce governance
- **Intentional Friction**: Forces thoughtful decisions about scope

#### 📄 Context File Export for AI Tools
- **Automatic Export**: Generates `.cdg/context/<area>.txt` on every successful dig
- **AI-Readable Format**: Clear instructions, file lists, budget status, usage guidelines
- **Universal Compatibility**: Works with Claude Code, Cursor, ChatGPT, Copilot, and any AI tool
- **Bookmark Integration**: Includes area-specific bookmarks in context files
- **Metadata Headers**: Shows area description, budget, and generation timestamp

### Changed
- **Updated Mission**: From "navigation tool" to "AI context governance system"
- **Enhanced Output**: dig command now shows budget and context file path
- **Better Errors**: Refusal messages provide actionable options and suggestions

### Technical Details
- **New Modules**: `budget.py` (208 lines), `refusal.py` (234 lines), `export.py` (183 lines)
- **Modified**: `cli.py`, `manager.py`, `.cdg/config.json` schema
- **Code Added**: 625+ lines of production code
- **Tests**: 6/6 integration tests passed, AI workflow validated

### Documentation
- `IMPLEMENTATION_PLAN_PHASE1.md` - Technical specifications
- `IMPLEMENTATION_GAP_ANALYSIS.md` - Feature gap analysis
- `PHASE1_TASK_TRACKER.md` - Development progress (100% complete)
- `TEST_REPORT_DAY1.md` - Integration test results

### Migration Guide

**Fully backward compatible** - no breaking changes.

**New automatic features:**
```bash
contextdigger dig tests
# Now shows: Budget: 3/15 files, 557/3,000 lines.
#            📄 Context file: .cdg/context/tests.txt

# If area too large:
contextdigger dig large-area
# May refuse with suggestions for sub-areas

# Use with AI tools:
> "Read .cdg/context/tests.txt and help me add test coverage"
```

**Customize budgets** (optional) in `.cdg/config.json`:
```json
{
  "budgets": {
    "max_files": 15,
    "max_lines": 3000,
    "warn_threshold": 0.8
  }
}
```

### Upgrade
```bash
pip install --upgrade contextdigger
```

---

## [1.0.0] - 2024-12-20

### Initial Release - Complete Feature Set

ContextDigger v1.0.0 includes all planned features across 9 major phases:

#### Phase 1: Foundation
- **Auto-discovery Algorithm** - Automatically excavates code areas from any codebase
- **Area Definitions** - JSON-based area metadata with patterns and descriptions
- **Session Tracking** - Records exploration sessions with file access history
- **Bookmark System** - Mark and navigate to important code locations
- **Claude Skills** - 40+ markdown-based skills for Claude Code integration

#### Phase 2: Navigation & Context
- **Dig History** (4 commands)
  - `/dig-history` - Complete exploration timeline
  - `/dig-back` - Navigate backward through areas
  - `/dig-forward` - Navigate forward like a browser
  - `/dig-trail` - Breadcrumb trail of recent areas

- **Context Snapshots** (4 commands)
  - `/dig-snapshot` - Save complete mental state
  - `/dig-snapshots` - List all saved snapshots
  - `/dig-compare` - Compare current state with snapshot
  - `/dig-restore` - Restore saved context

- **Smart Suggestions** (2 commands)
  - `/dig-suggest` - AI-powered area recommendations
  - `/dig-suggest-pattern` - Pattern-based suggestions

#### Phase 3: Team Collaboration
- **Team Awareness** (1 command)
  - `/dig-team` - See who's working where in real-time
  - File-based collaboration without server requirements

- **Knowledge Capture** (3 commands)
  - `/dig-note` - Create notes in current area
  - `/dig-notes` - View area notes
  - `/dig-wiki` - Generate comprehensive markdown wiki

#### Phase 4: Code Intelligence
- **Dependency Analysis** (3 commands)
  - `/dig-deps` - Show area dependencies
  - `/dig-impact` - Analyze change impact
  - `/dig-map` - ASCII dependency graph visualization
  - Import parsing for Python, JavaScript, TypeScript

- **Hot Spots Detection** (1 command)
  - `/dig-hotspots` - Find frequently changed code
  - Temperature scoring algorithm
  - Git history analysis

#### Phase 5: Testing & Performance
- **Test Coverage Analysis** (2 commands)
  - `/dig-tests` - Show test coverage
  - `/dig-gaps` - Find untested areas
  - Convention-based detection (no test execution needed)

- **Performance Profiling** (2 commands)
  - `/dig-perf` - Performance metrics
  - `/dig-benchmark` - Record benchmarks
  - Complexity analysis and slow code detection

#### Phase 6: Automation & Search
- **Context-Aware Automation** (2 commands)
  - `/dig-auto` - Create automation rules
  - `/dig-rules` - List and manage rules
  - Trigger-based workflows

- **Advanced Search** (2 commands)
  - `/dig-search` - Query across all data
  - `/dig-query` - Advanced pattern matching
  - Relevance-scored results

#### Phase 7: Analytics & Insights
- **Work Analytics** (1 command)
  - `/dig-analytics` - Time tracking and productivity metrics
  - Session-based time distribution
  - Multi-factor productivity scoring

- **Reporting** (1 command)
  - `/dig-report` - Generate comprehensive markdown reports
  - Customizable sections and formatting

#### Phase 8: Export & Integration
- **Export System** (1 command)
  - `/dig-export` - Export to JSON, CSV, or HTML
  - Multiple format support
  - Excel/Google Sheets compatible CSV

- **Backup & Restore** (1 command)
  - `/dig-backup` - Complete data backup to tar.gz
  - Safe restore with pre-restore backup
  - Timestamped archives

#### Phase 9: Dashboard & Utilities
- **Dashboard** (1 command)
  - `/dig-dashboard` - Real-time overview with alerts
  - Key metrics, recent activity, suggestions
  - Smart alerting for hotspots and coverage gaps

- **Health Checks** (1 command)
  - `/dig-health` - Data integrity validation
  - Status levels: healthy/warning/error
  - Actionable fix recommendations

- **Statistics** (1 command)
  - `/dig-stats` - Detailed usage analytics
  - Totals, averages, distributions
  - Tag frequency analysis

### Technical Highlights

**Architecture:**
- Python 3.11+ with dataclasses
- JSON file-based storage (no external dependencies)
- Cross-platform compatible (macOS, Linux, Windows)
- Browser-like history with index-based navigation

**Code Metrics:**
- 4,330+ lines of implementation
- 37 Claude Code skills
- 60+ public methods in FocusManager
- Zero external dependencies (stdlib only)

**Data Models:**
- 20+ dataclasses for type safety
- Comprehensive metadata tracking
- Backwards-compatible JSON format

**Performance:**
- Fast discovery (1-5 seconds for most codebases)
- Lightweight .cdg/ directory
- Efficient file-based queries
- Git log caching for performance

### Installation

```bash
# Install Python package
pip3 install --user git+https://github.com/ialameh/contextdigger.git

# Install all 40+ Claude skills
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash
```

### Breaking Changes

None - this is the initial release.

### Known Issues

None at release.

### Credits

**Created by:** Sam Alameh ([@ialameh](https://github.com/ialameh))
**Website:** [FlowMason.com](https://www.flowmason.com)
**Repository:** [github.com/ialameh/contextdigger](https://github.com/ialameh/contextdigger)

---

## Future Roadmap

Potential features for future releases:

- **PR Integration** - Analyze pull request impact on areas
- **Migration Assistant** - Track refactoring progress across codebase
- **Web UI** - Browser-based dashboard for teams
- **IDE Plugins** - VSCode, JetBrains integration
- **Git Hooks** - Pre-commit/pre-push automation
- **Remote Sync** - Cloud-based team synchronization
- **Custom Analyzers** - Plugin system for language-specific analysis
- **Visual Graphs** - Interactive dependency visualizations
- **CI/CD Integration** - Automated analysis in build pipelines
- **AI Summaries** - Claude-powered code explanations

---

For detailed feature documentation, see [README.md](README.md)
