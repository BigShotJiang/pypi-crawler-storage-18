# Publishing Guide for Focus Manager

## Overview

This guide explains how to publish Focus Manager so others can install and use it globally.

---

## Package Structure

```
focusmanager/
├── focusmanager/               # Python package
│   ├── __init__.py            # Package initialization
│   ├── manager.py             # Core FocusManager class
│   ├── discover.py            # Discovery algorithm
│   └── cli.py                 # Command-line interface
├── claude-skills/              # Claude Code skills
│   ├── init-focus.md
│   ├── focus.md
│   ├── refocus.md
│   ├── focus-status.md
│   ├── bookmark.md
│   └── goto.md
├── pyproject.toml             # Python package config
├── install.sh                 # Installation script
├── README.md                  # User documentation
├── LICENSE                    # MIT License
├── .gitignore                 # Git ignore rules
└── PUBLISHING.md              # This file
```

---

## Publishing to GitHub

### 1. Create Repository

```bash
# Create new repository on GitHub
# Name: focusmanager
# Description: Language-agnostic focus area management for codebases
# License: MIT

# Initialize and push
cd /tmp/focusmanager-package
git init
git add .
git commit -m "Initial release: Focus Manager v1.0.0

Features:
- Multi-language focus area discovery
- Session tracking
- Bookmark management
- Claude Code skills integration
- Support for Python, JavaScript, Salesforce, and more"

git remote add origin https://github.com/yourusername/focusmanager.git
git branch -M main
git push -u origin main
```

### 2. Create Release

On GitHub:
1. Go to Releases → Create a new release
2. Tag: `v1.0.0`
3. Title: `Focus Manager v1.0.0`
4. Description:

```markdown
# Focus Manager v1.0.0

First stable release of Focus Manager - a language-agnostic focus area management and testing intelligence system.

## Features

✅ Multi-language support (Python, JavaScript, TypeScript, Salesforce Apex)
✅ Automatic focus area discovery
✅ Session tracking and activity monitoring
✅ Bookmark management for quick navigation
✅ Claude Code skills integration
✅ Monorepo support

## Installation

```bash
git clone https://github.com/yourusername/focusmanager.git
cd focusmanager
./install.sh
```

## Quick Start

```bash
# Navigate to any project
cd /path/to/your/project

# Initialize focus management
/init-focus

# Switch focus
/focus <area-name>

# Check status
/focus-status
```

## Documentation

See [README.md](README.md) for full documentation.

## Requirements

- Python 3.11+
- Claude Code CLI

## License

MIT
```

3. Publish release

---

## Publishing to PyPI (Optional)

To make installation easier, publish to PyPI:

### 1. Setup

```bash
# Install build tools
pip install build twine

# Create accounts
# - Test PyPI: https://test.pypi.org/account/register/
# - PyPI: https://pypi.org/account/register/
```

### 2. Build Package

```bash
cd /tmp/focusmanager-package

# Build distribution
python -m build

# This creates:
# - dist/focusmanager-1.0.0.tar.gz
# - dist/focusmanager-1.0.0-py3-none-any.whl
```

### 3. Test on Test PyPI

```bash
# Upload to Test PyPI
python -m twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ focusmanager
```

### 4. Publish to PyPI

```bash
# Upload to PyPI
python -m twine upload dist/*

# Now anyone can install with:
pip install focusmanager
```

### 5. Update Installation Instructions

Update README.md:

```markdown
## Installation

### From PyPI (Recommended)

```bash
pip install focusmanager
```

### From Source

```bash
git clone https://github.com/yourusername/focusmanager.git
cd focusmanager
./install.sh
```
```

---

## Distribution Options

### Option 1: GitHub Only (Current)

**Pros:**
- Simple to maintain
- Full control
- Easy for contributors

**Cons:**
- Users must clone repo
- Manual installation

**Best for:**
- Initial release
- Testing with early adopters

**Installation:**
```bash
git clone https://github.com/yourusername/focusmanager.git
cd focusmanager
./install.sh
```

---

### Option 2: GitHub + PyPI

**Pros:**
- Easy installation (`pip install focusmanager`)
- Wide discoverability
- Professional distribution

**Cons:**
- More maintenance
- PyPI registration required

**Best for:**
- Public release
- Wide adoption

**Installation:**
```bash
pip install focusmanager
```

---

### Option 3: GitHub + Homebrew (macOS)

Create a Homebrew formula:

**Pros:**
- Native macOS distribution
- Easy updates

**Cons:**
- macOS only
- Requires formula maintenance

**Best for:**
- macOS users
- Developer tools

**Installation:**
```bash
brew tap yourusername/focusmanager
brew install focusmanager
```

---

## Marketing & Promotion

### README Badges

Add to README.md:

```markdown
[![PyPI version](https://badge.fury.io/py/focusmanager.svg)](https://badge.fury.io/py/focusmanager)
[![Downloads](https://pepy.tech/badge/focusmanager)](https://pepy.tech/project/focusmanager)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
```

### Share On

- **Twitter/X**: "Introducing Focus Manager - language-agnostic code focus management for any codebase"
- **Reddit**: r/programming, r/python, r/javascript
- **Hacker News**: Show HN: Focus Manager
- **Dev.to**: Write a tutorial article
- **GitHub Topics**: Add topics to repository (focus-management, productivity, claude-code, testing)

### Demo

Create a demo GIF or video showing:
1. `/init-focus` discovering areas
2. `/focus` switching to an area
3. `/bookmark` and `/goto` for navigation
4. `/focus-status` showing activity

Use tools:
- **asciinema** - Terminal recordings
- **peek** - GIF screen recording
- **OBS** - Video recording

---

## Maintenance

### Version Updates

1. Update version in `focusmanager/__init__.py`
2. Update version in `pyproject.toml`
3. Create git tag: `git tag v1.1.0`
4. Create GitHub release
5. If on PyPI: `python -m build && twine upload dist/*`

### Changelog

Maintain CHANGELOG.md:

```markdown
# Changelog

## [1.1.0] - 2025-01-15

### Added
- Test coverage analysis
- Gap identification
- Template generation

### Fixed
- Discovery edge cases for nested monorepos

### Changed
- Improved fuzzy matching algorithm
```

---

## Support Channels

Setup support infrastructure:

1. **GitHub Issues** - Bug reports and feature requests
2. **GitHub Discussions** - General questions and community
3. **Documentation** - Keep README.md updated
4. **Examples** - Add `/examples` directory with sample projects

---

## Analytics (Optional)

Track adoption:

- **PyPI Downloads**: Automatic via PyPI
- **GitHub Stars**: Monitor repository stars
- **User Feedback**: Collect via issues and discussions

---

## Legal

### License

MIT License is included. Ensure all files have license header if needed.

### Trademarks

If creating a logo or brand:
- Trademark the name if desired
- Create brand guidelines

### Contributions

Add CONTRIBUTING.md with:
- How to contribute
- Code style guide
- Pull request process
- Code of conduct

---

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Push initial release
3. ✅ Create v1.0.0 release
4. 📝 Test installation on fresh machine
5. 📝 Create demo video/GIF
6. 📝 Share on social media
7. 📝 Monitor feedback and iterate

**Optional:**
- Publish to PyPI
- Create Homebrew formula
- Build VSCode extension
- Create landing page

---

## Quick Checklist

Before publishing:

- [ ] All tests pass
- [ ] README.md is complete and accurate
- [ ] LICENSE file is included
- [ ] Version numbers are correct
- [ ] Installation script works on fresh machine
- [ ] Claude skills install correctly
- [ ] Examples work as documented
- [ ] No sensitive data in repository
- [ ] .gitignore is comprehensive

---

*Ready to publish? Follow the steps above and share Focus Manager with the world!*
