# Team Onboarding Example

How to use ContextDigger to onboard new team members effectively.

## For the Onboarding Lead

### 1. Generate Comprehensive Documentation

```
# Generate wiki with all knowledge
/dig-wiki ONBOARDING_GUIDE.md
```

This creates a markdown file with:
- All discovered code areas
- Team notes and documentation
- Architecture overview
- Getting started guides

### 2. Export Codebase Map

```
# Create visual dependency map
/dig-map > ARCHITECTURE.txt
```

### 3. Create Guided Tour Snapshots

```
# Create snapshots for key areas
/dig authentication
/dig-snapshot tour-1-authentication

/dig backend-api
/dig-snapshot tour-2-backend-api

/dig frontend-components
/dig-snapshot tour-3-frontend

/dig database-layer
/dig-snapshot tour-4-database

/dig deployment
/dig-snapshot tour-5-deployment
```

### 4. Mark Important Locations

```
# Entry points
/mark-spot app-entry-point
/mark-spot api-entry-point
/mark-spot main-config

# Critical systems
/mark-spot authentication-system
/mark-spot payment-processing
/mark-spot user-management

# Common pain points
/mark-spot database-migrations
/mark-spot deployment-scripts
/mark-spot environment-setup
```

### 5. Document Common Workflows

```
/dig-note "Development Workflow

1. Create feature branch from main
2. Run: make setup
3. Start dev server: make dev
4. Run tests: make test
5. Submit PR when ready

#workflow #getting-started"

/dig-note "Deployment Process

1. Merge to main triggers CI/CD
2. Tests run automatically
3. Staging deployment first
4. Manual approval for production
5. Rollback: git revert + redeploy

#deployment #process"
```

### 6. Generate Report

```
/dig-report CODEBASE_OVERVIEW.md
```

---

## For the New Team Member

### Day 1: Setup & Orientation

#### Morning: Installation

```bash
# 1. Clone repository
git clone https://github.com/company/project.git
cd project

# 2. Install ContextDigger
pip3 install --user git+https://github.com/ialameh/contextdigger.git
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash

# 3. Initialize (pulls shared areas from git)
/init-dig
```

#### Afternoon: Guided Tour

```
# Follow the guided tour
/dig-snapshots

# Restore each tour snapshot
/dig-restore tour-1-authentication
/dig-restore tour-2-backend-api
/dig-restore tour-3-frontend
/dig-restore tour-4-database
/dig-restore tour-5-deployment
```

### Day 2: Exploration

```
# Start with dashboard
/dig-dashboard

# Navigate through areas
/redig    # Interactive selector

# Check team activity
/dig-team

# Read knowledge base
/dig-notes authentication
/dig-notes backend-api
```

### Day 3: First Task

```
# 1. Get assigned task: "Add email validation"

# 2. Find relevant code
/dig-search "email"
/dig-search "validation"

# 3. Navigate to areas
/dig user-management

# 4. Mark important spots
/mark-spot user-model
/mark-spot validation-logic

# 5. Check dependencies
/dig-deps user-management

# 6. Check test coverage
/dig-coverage user-management

# 7. Snapshot before changes
/dig-snapshot before-email-validation

# 8. Make changes...

# 9. Document what you learned
/dig-note "Email Validation

Added validation to user registration:
- Uses email-validator library
- Checks MX records
- Validates format and deliverability

Files changed:
- src/users/validators.py
- tests/test_validators.py

#validation #users"
```

### Week 1: Building Confidence

```
# Daily routine
/dig-dashboard          # Start of day
/dig-team              # See what others are doing
/goto-spot <location>  # Jump to work location
/dig-history           # Review what you explored

# End of day
/dig-snapshot end-of-week-1
/dig-analytics         # See your progress
```

### Week 2: Contributing

```
# You're now comfortable enough to help others!

# Add notes for future new members
/dig-note "Common Gotcha: Database Connections

The DB connection pool size is set in config.py.
If you see 'connection pool exhausted', increase
POOL_SIZE in config.py.

#database #troubleshooting #onboarding"

# Share your learnings
/dig-wiki    # Keep wiki updated
```

---

## Onboarding Checklist

### For Onboarding Lead

- [ ] Generate `/dig-wiki ONBOARDING_GUIDE.md`
- [ ] Create guided tour snapshots
- [ ] Mark all important code locations
- [ ] Document common workflows
- [ ] Set up automation rules for new devs
- [ ] Generate architecture map
- [ ] Export codebase overview

### For New Team Member

**Day 1:**
- [ ] Install ContextDigger
- [ ] Run `/init-dig` in project
- [ ] Complete guided tour (snapshots)
- [ ] Read generated wiki
- [ ] Introduce yourself in `/dig-team`

**Week 1:**
- [ ] Explore all major areas
- [ ] Complete first task
- [ ] Add first note
- [ ] Create useful bookmarks
- [ ] Join team daily check-ins

**Month 1:**
- [ ] Comfortable navigating codebase
- [ ] Contributing to knowledge base
- [ ] Using all core features
- [ ] Helping newer team members

---

## Knowledge Transfer Session (30 minutes)

### Senior Dev → Junior Dev

```bash
# 1. Senior: Share your context
/dig-snapshot handoff-feature-x

# 2. Junior: Restore context
/dig-restore handoff-feature-x

# 3. Senior: Show key locations
/goto-spot api-endpoint
/goto-spot database-schema
/goto-spot test-suite

# 4. Junior: Mark locations
/mark-spot feature-x-api
/mark-spot feature-x-db
/mark-spot feature-x-tests

# 5. Senior: Share notes
/dig-note "Feature X Implementation

Architecture decisions:
- Used async for performance
- Cached at Redis layer
- Fallback to database on cache miss

Watch out for:
- Rate limiting (500 req/min)
- Cache invalidation on updates

#feature-x #handoff"
```

---

## Team Knowledge Base

### Organizing Notes

Use tags consistently:

```
#onboarding        - Info for new members
#troubleshooting   - Common issues and fixes
#architecture      - Design decisions
#deployment        - Deploy/ops info
#testing           - Test strategies
#security          - Security considerations
#performance       - Performance tips
```

### Example Notes

```
/dig-note "Running Tests Locally

Full suite: make test
Single file: pytest tests/test_auth.py
With coverage: pytest --cov

CI runs all tests on PR.

#testing #onboarding"

/dig-note "Database Migrations

Creating:
  python manage.py makemigrations

Applying:
  python manage.py migrate

Rolling back:
  python manage.py migrate app_name previous

#database #migrations #onboarding"
```

---

## Metrics

Track onboarding success with analytics:

```
# After 1 month, new member runs:
/dig-analytics

# Should see:
# - Regular activity across areas
# - Notes contributed
# - Bookmarks created
# - Healthy productivity score
```

---

## Common Questions

**Q: How do I know what to explore first?**
```
/dig-dashboard      # See overview
/redig             # Browse areas
/dig-suggest       # Get AI suggestions
```

**Q: How do I find where feature X is implemented?**
```
/dig-search "feature X"
/dig-deps <area>
```

**Q: How do I remember important locations?**
```
/mark-spot location-name
/goto-spot location-name
```

**Q: How do I learn from the team?**
```
/dig-team          # See team activity
/dig-notes <area>  # Read team notes
/dig-wiki          # Full knowledge base
```

---

## Success Story

> "Before ContextDigger, onboarding took 4-6 weeks before new devs were productive. Now they're contributing in week 1. The knowledge base captures tribal knowledge that would otherwise be lost." - Engineering Manager

**Time to First PR:**
- Before: 2-3 weeks
- After: 3-5 days

**Knowledge Retention:**
- Before: In people's heads
- After: In searchable notes

**Context Switching:**
- Before: 15-20 min lost
- After: Instant with bookmarks

---

Happy onboarding! 👋⛏️
