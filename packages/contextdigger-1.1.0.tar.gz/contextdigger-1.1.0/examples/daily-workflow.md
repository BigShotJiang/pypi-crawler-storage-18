# Daily Workflow Example

A typical day using ContextDigger for productive code exploration.

## Morning Routine (5 minutes)

### 1. Check Dashboard

```
/dig-dashboard
```

**What you see:**
```
📊 ContextDigger Dashboard
============================================================

## Overview
------------------------------------------------------------
  Areas: 12
  Notes: 45
  Bookmarks: 78
  Snapshots: 8

  Currently in: Backend API
  Path: src/api


## ⚠️  Alerts
------------------------------------------------------------
  🔴 2 critical hotspot(s) detected
     Action: /dig-hotspots

  🟡 3 area(s) with <40% test coverage
     Action: /dig-gaps
```

### 2. Address Alerts

```
/dig-hotspots
```

**Output:**
```
🔥 Code Hot Spots (Last 30 days)
============================================================

  Area: payments-service
  Temperature: 🔴 CRITICAL
  Files: 8
  Commits: 24
  Contributors: 4
  Complexity: HIGH

  Top files:
    src/payments/stripe.py (12 commits)
    src/payments/webhook.py (8 commits)
```

### 3. Check Health

```
/dig-health
```

All green? Good to go!

---

## Feature Development (2 hours)

### Starting a New Feature

```
# 1. Create snapshot before starting
/dig-snapshot before-oauth-integration

# 2. Dig into relevant area
/dig authentication

# 3. Mark key locations
/mark-spot current-auth-flow
/mark-spot user-model
/mark-spot login-endpoint
```

### During Development

```
# Check dependencies frequently
/dig-deps authentication

# Track what you're changing
/dig-trail
```

**Output:**
```
🥖 Breadcrumb Trail
============================================================
  authentication > user-model > database-layer > authentication
```

### Before Committing

```
# 1. Compare with snapshot
/dig-compare before-oauth-integration

# 2. Check test coverage
/dig-coverage authentication

# 3. Add notes for the team
/dig-note "OAuth 2.0 Integration

Added Google and GitHub OAuth providers
- New endpoints: /auth/google, /auth/github
- User model extended with provider field
- See docs/oauth.md for configuration"
```

---

## Bug Investigation (1 hour)

### Bug Report: "Payment webhook failing intermittently"

```
# 1. Dig into payments area
/dig payments-service

# 2. Check recent activity (hotspot)
/dig-hotspots

# 3. View change history
/dig-history
```

### Find the Issue

```
# 4. Search for webhook-related code
/dig-search webhook

# 5. Check dependencies
/dig-deps payments-service

# 6. Found it! Mark the location
/mark-spot webhook-bug-signature-validation
```

### Verify the Fix

```
# 7. Check test coverage
/dig-coverage payments-service

# 8. Note the fix
/dig-note "Webhook Bug Fix

Issue: Signature validation failing on retry
Root cause: Timestamp validation too strict
Fix: Increased tolerance window to 5 minutes
Tests: Added webhook_retry_test.py"
```

---

## Code Review (30 minutes)

### Reviewing a PR

```
# 1. Snapshot current state
/dig-snapshot before-pr-review

# 2. See what areas are affected
/dig-search "feature-user-dashboard"

# 3. Check impact
/dig-impact frontend-dashboard

# 4. Review test coverage
/dig-gaps

# 5. Check for hotspots
/dig-hotspots
```

### Leaving Comments

```
# Navigate through marked spots
/goto-spot auth-middleware
# Review code, add PR comments

/goto-spot api-endpoint
# Review code, add PR comments
```

---

## End of Day (10 minutes)

### Document Your Work

```
# 1. Generate report for standup
/dig-report daily-progress.md
```

**Generates:**
```markdown
# ContextDigger Report
Generated: 2024-12-20 17:30

## Summary
- Areas explored: 5
- Notes added: 3
- Time spent: 4.5 hours
- Bookmarks created: 6

## Areas Worked On
1. authentication (2.1 hours)
2. payments-service (1.2 hours)
3. frontend-dashboard (0.8 hours)
...
```

### Create Backup

```
/dig-backup
```

### Check Analytics

```
/dig-analytics
```

**Output:**
```
📊 Work Analytics (Last 30 days)
============================================================

## Time Distribution
  Total time: 87.5 hours
  Avg per day: 4.4 hours
  Most productive: Tuesday (12.3 hours)

## Top Areas
  1. authentication (18.2 hours)
  2. backend-api (15.7 hours)
  3. frontend-components (12.4 hours)

## Productivity Score: 87/100
```

### Save Context for Tomorrow

```
/dig-snapshot end-of-day-2024-12-20
```

---

## Weekly Tasks

### Monday Morning

```
# Review last week
/dig-analytics

# Check project health
/dig-health

# Generate weekly report
/dig-report weekly-report.md
```

### Friday Afternoon

```
# Backup before weekend
/dig-backup

# Generate wiki for team
/dig-wiki CODEBASE_GUIDE.md

# Export data for analysis
/dig-export json
```

---

## Team Collaboration

### See What Teammates Are Doing

```
/dig-team
```

**Output:**
```
👥 Team Activity (Last 24 hours)
============================================================

  Alice Johnson
  • Currently: frontend-components
  • Last seen: 12 minutes ago
  • Recent areas: frontend, tests, docs

  Bob Smith
  • Currently: database-layer
  • Last seen: 2 hours ago
  • Recent areas: database, migrations, backend-api
```

### Share Knowledge

```
# Add note with tag for discoverability
/dig-note "Database Migration Guide

When adding new tables:
1. Create migration in db/migrations/
2. Update models in src/models/
3. Run: python manage.py migrate
4. Update tests

#database #migration #onboarding"
```

### Browse Team Knowledge

```
/dig-wiki
```

---

## Keyboard Shortcuts

Create aliases in your shell config (`~/.bashrc` or `~/.zshrc`):

```bash
# Quick access
alias dd='/dig-dashboard'
alias ds='/dig-status'
alias dh='/dig-hotspots'
alias dc='/dig-coverage'
alias dt='/dig-team'
alias dn='/dig-note'
```

Now you can just type:

```bash
dd    # Dashboard
ds    # Status
dh    # Hotspots
```

---

## Pro Tips

### 1. Snapshot Everything

Before any significant work:
```
/dig-snapshot before-feature-x
/dig-snapshot before-refactor
/dig-snapshot before-experiment
```

### 2. Mark Strategically

Create a "map" of important locations:
```
/mark-spot entry-point
/mark-spot config
/mark-spot error-handler
/mark-spot cache-layer
/mark-spot auth-middleware
```

### 3. Use Search Extensively

```
/dig-search "TODO"       # Find all todos
/dig-search "FIXME"      # Find fixmes
/dig-search "api_key"    # Find API key usage
/dig-search tag:security # Find security notes
```

### 4. Automate Common Tasks

```
/dig-auto "run tests before digging out"
/dig-auto "backup weekly on friday"
/dig-auto "generate report daily at 5pm"
```

### 5. Export for Presentations

```
/dig-export html    # Share with stakeholders
/dig-wiki          # Team documentation
/dig-report        # Status updates
```

---

## Time Saved

**Without ContextDigger:**
- Finding code: 15-20 min/day
- Context switching: 30 min/day
- Remembering locations: 10 min/day
- **Total: ~1 hour/day**

**With ContextDigger:**
- Finding code: instant (`/goto-spot`)
- Context switching: minimal (`/dig-back`)
- Remembering locations: not needed (bookmarks)
- **Time saved: ~45 min/day** = **3.75 hours/week** = **15 hours/month**

---

Happy digging! ⛏️
