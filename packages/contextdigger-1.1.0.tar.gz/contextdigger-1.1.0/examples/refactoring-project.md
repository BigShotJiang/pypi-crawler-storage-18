# Refactoring Project Example

How to use ContextDigger for large-scale refactoring projects.

## Scenario: Migrate from REST to GraphQL

A real-world example of using ContextDigger to manage a major architectural change.

---

## Phase 1: Planning (Week 1)

### 1. Snapshot Current State

```
/dig-snapshot before-graphql-migration
/dig-backup
```

Safety first! Always have a way back.

### 2. Analyze Current Architecture

```
# Map all dependencies
/dig-map > architecture-before.txt

# Find all REST endpoints
/dig-search "app.route"
/dig-search "@api.route"
/dig-search "def get_|def post_|def put_|def delete_"

# Check affected areas
/dig-deps backend-api
/dig-deps frontend-api-client
```

### 3. Identify Hotspots

```
/dig-hotspots
```

**Output:**
```
🔥 Code Hot Spots
============================================================

  1. api-endpoints (🔴 CRITICAL)
     - 45 commits in 30 days
     - 6 contributors
     - High complexity

  2. api-client (🟡 MEDIUM)
     - 12 commits in 30 days
     - 3 contributors
```

**Decision:** Start with less active areas first to minimize merge conflicts.

### 4. Check Test Coverage

```
/dig-coverage backend-api
/dig-coverage frontend-api-client
```

**Output:**
```
Backend API: 78% (Good)
Frontend Client: 45% (Need more tests first!)
```

**Action:** Add tests to frontend client before refactoring.

### 5. Create Migration Plan

```
/dig-note "GraphQL Migration Plan

Phase 1: Infrastructure (Week 1-2)
- Set up GraphQL server
- Add schema definitions
- Configure Apollo/GraphQL clients

Phase 2: User Endpoints (Week 3-4)
- Migrate user CRUD
- Update frontend user components
- Parallel running (REST + GraphQL)

Phase 3: Content Endpoints (Week 5-6)
- Migrate content APIs
- Update frontend content components

Phase 4: Integration Endpoints (Week 7-8)
- Migrate integrations
- Update external API consumers

Phase 5: Cleanup (Week 9-10)
- Remove REST endpoints
- Clean up old code
- Update documentation

#migration #graphql #architecture"
```

---

## Phase 2: Infrastructure Setup (Week 1-2)

### Create Feature Branch

```bash
git checkout -b feature/graphql-migration
```

### Set Up Tracking

```
# Create new area for GraphQL code
/dig graphql-server
/mark-spot graphql-schema
/mark-spot graphql-resolvers
/mark-spot graphql-types

# Track both old and new
/mark-spot rest-endpoints-old
```

### Document as You Go

```
/dig-note "GraphQL Setup

Installed: graphene-django
Schema location: src/graphql/schema.py
Endpoint: /graphql

Example query:
  query {
    users {
      id
      name
      email
    }
  }

#graphql #setup"
```

---

## Phase 3: Parallel Implementation (Week 3-8)

### Week 3: User Endpoints

#### Before Starting

```
/dig-snapshot week3-before-user-migration

# Analyze current implementation
/dig backend-api
/dig-search "class UserView"
/dig-deps backend-api
```

#### During Migration

```
# Track both implementations
/mark-spot rest-user-endpoints
/mark-spot graphql-user-resolvers

# Compare complexity
/dig-perf backend-api
/dig-perf graphql-server
```

#### Testing

```
# Check coverage before and after
/dig-coverage backend-api
/dig-coverage graphql-server

# Find gaps
/dig-gaps
```

#### End of Week

```
/dig-snapshot week3-user-migration-complete

# Compare with snapshot
/dig-compare week3-before-user-migration

# Document
/dig-note "Week 3: User Endpoints Migrated

Completed:
- ✅ User queries (get, list, search)
- ✅ User mutations (create, update, delete)
- ✅ Tests (95% coverage)
- ✅ Frontend integration

Performance:
- GraphQL: 45ms avg
- REST: 78ms avg
- Improvement: 42% faster!

#graphql #week3 #users"
```

### Week 4-7: Repeat Pattern

Same workflow for each endpoint group:

1. Snapshot before
2. Analyze dependencies
3. Implement GraphQL equivalent
4. Test thoroughly
5. Snapshot after
6. Compare and document

---

## Phase 4: Data Migration & Testing (Week 8)

### Track Progress

```
/dig-analytics
```

**Output:**
```
📊 Work Analytics (Last 30 days)
============================================================

## Areas Worked On
1. graphql-server (32 hours)
2. backend-api (18 hours)
3. frontend-api-client (15 hours)

## Productivity
- Notes added: 24
- Snapshots: 8
- Test coverage: 78% → 92%
```

### Verify Nothing Broken

```
# Check all affected areas
/dig-hotspots

# Find any new issues
/dig-search "TODO"
/dig-search "FIXME"
/dig-search "HACK"
```

### Integration Testing

```
/dig-note "Integration Test Results

REST → GraphQL Comparison:

User endpoints: ✅ Identical results
Content endpoints: ✅ Identical results
Search: ✅ Better performance
Pagination: ✅ Improved UX
Error handling: ✅ More consistent

#testing #integration #week8"
```

---

## Phase 5: Cleanup (Week 9-10)

### Identify Dead Code

```
# Find old REST endpoints
/dig-search "@api.route"
/dig-search "class.*View"

# Check if still used
/dig-deps backend-api
/dig-impact backend-api
```

### Remove Safely

Before each deletion:

```
# 1. Snapshot
/dig-snapshot before-removing-user-rest-endpoints

# 2. Remove code

# 3. Run tests

# 4. If tests fail:
/dig-restore before-removing-user-rest-endpoints

# 5. If tests pass:
git commit -m "Remove deprecated REST user endpoints"
```

### Update Documentation

```
/dig-wiki GRAPHQL_GUIDE.md

/dig-note "Migration Complete!

Old REST endpoints removed.
All functionality now in GraphQL.

New endpoint: /graphql
Schema: src/graphql/schema.py
Playground: /graphql/playground

Migration duration: 10 weeks
Code quality: improved
Performance: 40% faster avg
Test coverage: 92% (from 78%)

#migration #complete #graphql"
```

---

## Tracking Impact

### Before Migration

```bash
/dig-export json > before-migration.json
/dig-stats > stats-before.txt
/dig-map > architecture-before.txt
```

### After Migration

```bash
/dig-export json > after-migration.json
/dig-stats > stats-after.txt
/dig-map > architecture-after.txt

# Compare
diff stats-before.txt stats-after.txt
diff architecture-before.txt architecture-after.txt
```

### Metrics to Track

```
/dig-analytics
```

**Key Metrics:**

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| API Files | 45 | 18 | -60% |
| Lines of Code | 8,500 | 5,200 | -39% |
| Test Coverage | 78% | 92% | +14% |
| Avg Response Time | 78ms | 45ms | -42% |
| Hotspots | 8 | 2 | -75% |
| Dependencies | Complex | Clear | Better |

---

## Team Coordination

### Daily Standups

```
# Show your progress
/dig-trail
/dig-analytics
```

### Share Context

```
# For team members picking up work:
/dig-snapshot handoff-content-endpoints

# They restore:
/dig-restore handoff-content-endpoints
```

### Avoid Conflicts

```
# See who's working where
/dig-team
```

**Output:**
```
👥 Team Activity
============================================================

Alice (you): graphql-server
Bob: frontend-api-client
Carol: backend-api (legacy cleanup)
```

---

## Crisis Management

### Rollback Needed

```
# Week 6: Performance issue discovered

# 1. Check what changed
/dig-compare week5-complete

# 2. Identify problem area
/dig-hotspots
/dig-perf graphql-server

# 3. Isolate issue
/dig-search "N+1 query"

# 4. Fix found! Database query optimization needed

# 5. Document
/dig-note "Performance Issue - Week 6

N+1 query problem in user resolver.
Added dataloader for batch fetching.

Before: 2.3s for 100 users
After: 45ms for 100 users

#performance #graphql #fix"
```

### Emergency Rollback

```
# Worst case: need to rollback everything
git checkout main
git reset --hard origin/main

/dig-restore before-graphql-migration

# All state restored!
```

---

## Lessons Learned

### What Worked Well

1. **Snapshots** - Could always rollback safely
2. **Dependency mapping** - Knew exactly what to change
3. **Notes** - Team knowledge preserved
4. **Analytics** - Progress visible and measurable
5. **Bookmarks** - Easy to navigate between old/new

### What We'd Do Differently

```
/dig-note "Refactoring Lessons

1. Snapshot MORE frequently (daily, not weekly)
2. Write migration notes DURING, not after
3. Use /dig-compare more to catch regressions
4. Set up automation rules earlier
5. Export metrics weekly for stakeholders

#lessons #refactoring #retrospective"
```

---

## Automation for Future Refactorings

### Set Up Rules

```
/dig-auto "snapshot before major changes"
/dig-auto "check test coverage before committing"
/dig-auto "generate weekly progress report"
/dig-auto "backup on fridays"
```

### Templates

Create snapshot templates:

```bash
# Pre-change
/dig-snapshot before-${FEATURE_NAME}
/dig-export json > before-${FEATURE_NAME}.json

# Post-change
/dig-snapshot after-${FEATURE_NAME}
/dig-compare before-${FEATURE_NAME}
/dig-export json > after-${FEATURE_NAME}.json
```

---

## Final Report

```
/dig-report GRAPHQL_MIGRATION_FINAL_REPORT.md
```

**Generated Report Includes:**
- Complete timeline
- All areas affected
- Performance improvements
- Test coverage changes
- Team contributions
- Knowledge captured (24 notes)
- Lessons learned

---

## Time Saved with ContextDigger

**Estimated time without ContextDigger:**
- Finding code: 2 hours/week × 10 weeks = 20 hours
- Understanding context: 3 hours/week × 10 weeks = 30 hours
- Coordination: 2 hours/week × 10 weeks = 20 hours
- Documentation: 5 hours
- **Total: 75 hours**

**With ContextDigger:**
- Finding code: Instant bookmarks
- Understanding context: Snapshots + notes
- Coordination: /dig-team visibility
- Documentation: Auto-generated
- **Time saved: ~60 hours** (~1.5 weeks of work)

---

## Success!

✅ Migration complete in 10 weeks
✅ 40% performance improvement
✅ 14% test coverage increase
✅ 60% code reduction
✅ Complete knowledge capture
✅ Team fully aligned

All thanks to systematic tracking and context management! ⛏️🎉
