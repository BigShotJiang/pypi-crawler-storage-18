# Mark Spot - Save Bookmark

Save current file location as a bookmark for quick access later.

## Your Task:

Run the ContextDigger command to save current file location as a bookmark for quick access later.

## Implementation:

```bash
contextdigger mark-spot <name> <file-path> [line-number]
```

## Usage:

Usage: contextdigger mark-spot <name> <file-path> [line-number]

## Notes:

- Bookmarks persist across sessions
- Can include line numbers
- Use /goto-spot to jump to bookmarks

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
