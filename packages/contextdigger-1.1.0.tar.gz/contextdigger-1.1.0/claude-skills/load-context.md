# Load Context Snapshot

Restore a previously saved work context.

## Your Task:

Run the ContextDigger command to restore a previously saved work context.

## Implementation:

```bash
contextdigger load-context <name>
```

## Usage:

Usage: contextdigger load-context <name>

## Notes:

- Restores area, bookmarks, and history
- Useful for task switching
- Run /list-contexts to see all snapshots

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
