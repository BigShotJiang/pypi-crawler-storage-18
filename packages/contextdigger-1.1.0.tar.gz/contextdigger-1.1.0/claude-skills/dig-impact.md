# Impact Analysis

Show which areas would be affected by changes to a given area.

## Your Task:

Run the ContextDigger command to show which areas would be affected by changes to a given area.

## Implementation:

```bash
contextdigger impact <area-id>
```

## Usage:

Usage: contextdigger impact <area-id>

## Notes:

- Shows dependent areas (reverse dependencies)
- Helps estimate change impact
- Critical for refactoring

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
