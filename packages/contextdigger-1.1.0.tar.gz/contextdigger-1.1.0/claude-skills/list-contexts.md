# List Context Snapshots

Show all saved context snapshots.

## Your Task:

Run the ContextDigger command to show all saved context snapshots.

## Implementation:

```bash
contextdigger list-contexts 
```

## Usage:

No arguments required.

## Notes:

- Shows all saved contexts with descriptions
- Includes save timestamps

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
