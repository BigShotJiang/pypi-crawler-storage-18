# Run Benchmarks

Run benchmarks and show overall statistics.

## Your Task:

Run the ContextDigger command to run benchmarks and show overall statistics.

## Implementation:

```bash
contextdigger benchmark 
```

## Usage:

No arguments required.

## Notes:

- Shows counts of areas, sessions, bookmarks
- Quick health check

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
