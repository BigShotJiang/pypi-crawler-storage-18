# Delete Context Snapshot

Delete a saved context snapshot.

## Your Task:

Run the ContextDigger command to delete a saved context snapshot.

## Implementation:

```bash
contextdigger delete-context <name>
```

## Usage:

Usage: contextdigger delete-context <name>

## Notes:

- Permanently removes the snapshot
- Cannot be undone

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
