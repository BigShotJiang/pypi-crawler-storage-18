# Navigate Forward in History

Go forward to the next area in your navigation history.

## Your Task:

Run the ContextDigger command to go forward to the next area in your navigation history.

## Implementation:

```bash
contextdigger forward 
```

## Usage:

No arguments required.

## Notes:

- Works like browser forward button
- Only works if you've navigated back
- Use /dig-back to go back

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
