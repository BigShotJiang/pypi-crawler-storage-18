# Team Activity

View recent team activity.

## Your Task:

Run the ContextDigger command to view recent team activity.

## Implementation:

```bash
contextdigger team 
```

## Usage:

No arguments required.

## Notes:

- Last 24 hours of team activity
- Shows who worked on what
- Based on git commits

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
