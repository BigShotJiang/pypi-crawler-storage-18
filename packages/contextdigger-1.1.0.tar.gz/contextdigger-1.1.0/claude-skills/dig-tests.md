# Test Coverage

View test coverage for current or specified area.

## Your Task:

Run the ContextDigger command to view test coverage for current or specified area.

## Implementation:

```bash
contextdigger tests [area-id]
```

## Usage:

Usage: contextdigger tests [area-id]

## Notes:

- Line and branch coverage
- File counts
- Defaults to current area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
