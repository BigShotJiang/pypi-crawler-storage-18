# Custom Query

Run custom queries against ContextDigger data.

## Your Task:

Run the ContextDigger command to run custom queries against contextdigger data.

## Implementation:

```bash
contextdigger query <query>
```

## Usage:

Usage: contextdigger query <query>

## Notes:

- Advanced querying (coming soon)

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
