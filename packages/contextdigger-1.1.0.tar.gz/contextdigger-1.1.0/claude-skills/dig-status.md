# Dig Status - Show Current Session

Show current dig status and session information.

## Your Task:

Run the ContextDigger command to show current dig status and session information.

## Implementation:

```bash
contextdigger status 
```

## Usage:

No arguments required.

## Notes:

- Shows current focus area
- Session duration
- Files modified in session

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
