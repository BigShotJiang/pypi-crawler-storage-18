# Re-dig - Interactive Area Selector

Show all discovered areas and select one interactively.

## Your Task:

Run the ContextDigger command to show all discovered areas and select one interactively.

## Implementation:

```bash
contextdigger redig 
```

## Usage:

No arguments required.

## Notes:

- Shows all areas with current focus highlighted
- Lists areas with descriptions
- Use /dig <area-id> to switch to an area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
