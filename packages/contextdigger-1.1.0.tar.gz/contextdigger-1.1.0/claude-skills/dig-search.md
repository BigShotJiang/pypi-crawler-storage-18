# Search All Data

Search across areas, bookmarks, and notes.

## Your Task:

Run the ContextDigger command to search across areas, bookmarks, and notes.

## Implementation:

```bash
contextdigger search <query>
```

## Usage:

Usage: contextdigger search <query>

## Notes:

- Searches area names and descriptions
- Searches bookmark names and paths
- Shows top 5 results

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
