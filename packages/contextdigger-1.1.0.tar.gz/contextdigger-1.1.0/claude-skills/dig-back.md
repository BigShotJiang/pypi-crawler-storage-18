# Navigate Back in History

Go back to the previous area in your navigation history.

## Your Task:

Run the ContextDigger command to go back to the previous area in your navigation history.

## Implementation:

```bash
contextdigger back 
```

## Usage:

No arguments required.

## Notes:

- Works like browser back button
- Maintains navigation history
- Use /dig-forward to go forward

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
