# Create Backup

Create a backup of all ContextDigger data.

## Your Task:

Run the ContextDigger command to create a backup of all contextdigger data.

## Implementation:

```bash
contextdigger backup 
```

## Usage:

No arguments required.

## Notes:

- Creates .tar.gz archive
- Includes all .cdg directory contents
- Timestamped filename

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
