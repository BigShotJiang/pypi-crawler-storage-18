# Performance Analysis

Analyze performance characteristics of an area.

## Your Task:

Run the ContextDigger command to analyze performance characteristics of an area.

## Implementation:

```bash
contextdigger perf [area-id]
```

## Usage:

Usage: contextdigger perf [area-id]

## Notes:

- Shows complexity metrics
- Defaults to current area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
