# Show Dependencies

Show dependencies for current or specified area.

## Your Task:

Run the ContextDigger command to show dependencies for current or specified area.

## Implementation:

```bash
contextdigger deps [area-id]
```

## Usage:

Usage: contextdigger deps [area-id]

## Notes:

- Shows which areas this area depends on
- Includes relationship types
- Defaults to current area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
