# Health Check

Run health check on ContextDigger data.

## Your Task:

Run the ContextDigger command to run health check on contextdigger data.

## Implementation:

```bash
contextdigger health 
```

## Usage:

No arguments required.

## Notes:

- Checks for issues
- Validates data integrity
- Reports status

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
