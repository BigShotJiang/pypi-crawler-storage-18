# Find Code Hotspots

Identify files with high change frequency and complexity.

## Your Task:

Run the ContextDigger command to identify files with high change frequency and complexity.

## Implementation:

```bash
contextdigger hotspots [days]
```

## Usage:

Usage: contextdigger hotspots [days]

## Notes:

- Defaults to last 30 days
- Shows commit count and complexity
- Identifies problem areas

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
