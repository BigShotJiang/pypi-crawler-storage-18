# Automation Suggestions

Get suggestions for automating common tasks.

## Your Task:

Run the ContextDigger command to get suggestions for automating common tasks.

## Implementation:

```bash
contextdigger auto 
```

## Usage:

No arguments required.

## Notes:

- Suggests automation opportunities
- Based on usage patterns

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
