# Find Coverage Gaps

Identify areas with low test coverage.

## Your Task:

Run the ContextDigger command to identify areas with low test coverage.

## Implementation:

```bash
contextdigger gaps 
```

## Usage:

No arguments required.

## Notes:

- Shows areas below coverage threshold
- Defaults to 70% threshold

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
