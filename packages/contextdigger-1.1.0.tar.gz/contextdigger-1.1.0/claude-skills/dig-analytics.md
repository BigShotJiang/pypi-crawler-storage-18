# Work Analytics

View work analytics and time tracking.

## Your Task:

Run the ContextDigger command to view work analytics and time tracking.

## Implementation:

```bash
contextdigger analytics [days]
```

## Usage:

Usage: contextdigger analytics [days]

## Notes:

- Defaults to last 30 days
- Shows session counts and time spent
- Top areas worked

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
