# Add Note to Current Area

Add a note or comment to the current code area.

## Your Task:

Run the ContextDigger command to add a note or comment to the current code area.

## Implementation:

```bash
contextdigger note <note-text>
```

## Usage:

Usage: contextdigger note <note-text>

## Notes:

- Notes are attached to the current area
- Include timestamps
- Use /dig-notes to view all notes for an area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
