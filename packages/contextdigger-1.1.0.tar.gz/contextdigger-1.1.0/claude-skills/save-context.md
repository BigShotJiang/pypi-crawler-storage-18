# Save Context Snapshot

Save current work context (area, bookmarks, history) for later.

## Your Task:

Run the ContextDigger command to save current work context (area, bookmarks, history) for later.

## Implementation:

```bash
contextdigger save-context <name> [description]
```

## Usage:

Usage: contextdigger save-context <name> [description]

## Notes:

- Saves current area, bookmarks, and history
- Great for switching between tasks
- Use /load-context to restore

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
