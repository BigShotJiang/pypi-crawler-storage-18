# Dig History

Show the user's dig navigation history - their exploration path through the codebase.

## Your Task:

Display the dig history showing where the user has been digging, with timestamps and duration spent in each area.

## Implementation:

Execute the following Python code:

```python
import sys
from pathlib import Path
from datetime import datetime

# Add the project root to path
project_root = Path.cwd()
sys.path.insert(0, str(project_root))

# Import from contextdigger package
from contextdigger.manager import FocusManager

# Initialize manager
manager = FocusManager(project_root)

if not manager.is_initialized():
    print("❌ ContextDigger not initialized")
    print("Run: /init-dig")
    exit(1)

# Get dig history
history = manager.get_dig_history(limit=20)  # Last 20 entries

if not history:
    print("📭 No dig history yet")
    print("\nStart digging into areas with /dig <area>")
    print("Your navigation will be tracked automatically")
    exit(0)

# Display history
print("⛏️  Dig History")
print("="*60)
print()

for i, entry in enumerate(history):
    # Format entry
    entered = datetime.fromisoformat(entry.enteredAt.replace('Z', '+00:00'))
    time_str = entered.strftime("%Y-%m-%d %H:%M")

    # Duration
    if entry.duration:
        minutes = entry.duration // 60
        if minutes < 60:
            duration_str = f"{minutes}m"
        else:
            hours = minutes // 60
            mins = minutes % 60
            duration_str = f"{hours}h {mins}m"
    else:
        duration_str = "active"

    # Current indicator
    config = manager.load_config()
    current_index = config.get("history", {}).get("currentIndex", -1)
    is_current = (len(history) - 1 - i) == current_index
    indicator = "⛏️ " if is_current else "   "

    print(f"{indicator}{i+1}. {entry.areaName} ({entry.areaId})")
    print(f"     {time_str} • {duration_str}")

    if entry.actions:
        print(f"     {', '.join(entry.actions)}")

    print()

# Show breadcrumb trail
breadcrumb = manager.get_breadcrumb_trail()
if breadcrumb:
    print("="*60)
    print(f"Trail: {breadcrumb}")
    print()

# Navigation hints
print("Navigation:")
print("  /dig-back      - Go to previous area")
print("  /dig-forward   - Go to next area")
print("  /dig <area>    - Dig into new area")
```

## Display Format:

```
⛏️  Dig History
============================================================

⛏️  1. Backend API (backend-api)
     2025-01-15 14:30 • 25m
     marked 2 spots, viewed 8 files

   2. Frontend Components (frontend-components)
     2025-01-15 14:05 • 18m

   3. Database Layer (database-layer)
     2025-01-15 13:45 • 15m
     marked 1 spot

============================================================
Trail: database-layer → frontend-components → backend-api

Navigation:
  /dig-back      - Go to previous area
  /dig-forward   - Go to next area
  /dig <area>    - Dig into new area
```

## Notes:

- ⛏️ indicator shows current position in history
- Duration shows time spent in each area
- "active" means still in that area
- Actions list shows what user did (future enhancement)
- Breadcrumb trail shows path to current area
