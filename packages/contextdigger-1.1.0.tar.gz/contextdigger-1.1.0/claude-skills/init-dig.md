# Initialize ContextDigger

Initialize ContextDigger in your project to start discovering code areas.

## Your Task:

Run the ContextDigger command to initialize the project and discover code areas.

## Implementation:

```bash
contextdigger init
```

## Usage:

- `contextdigger init` - Initialize (or show status if already initialized)
- `contextdigger init -f` - Force re-initialization

## Notes:

- Creates `.cdg/` directory structure
- Discovers code areas automatically
- If already initialized, shows status and helpful commands
- Use `-f` or `--force` flag to re-initialize (rediscovers all areas)

## What It Creates:

- `.cdg/` - Main data directory
  - `areas/` - Discovered code areas
  - `sessions/` - Session tracking
  - `bookmarks/` - Saved locations
  - `config.json` - Configuration

## Related Commands:

After initialization:
- `/dig-dashboard` - View overall status and suggestions
- `/dig <area>` - Start exploring a code area
- `/redig` - See all discovered areas
