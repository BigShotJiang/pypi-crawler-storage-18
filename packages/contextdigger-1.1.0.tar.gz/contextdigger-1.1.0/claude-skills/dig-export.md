# Export Data

Export ContextDigger data in various formats.

## Your Task:

Run the ContextDigger command to export contextdigger data in various formats.

## Implementation:

```bash
contextdigger export <format>
```

## Usage:

Usage: contextdigger export <format>

## Notes:

- Supports: json, markdown
- Includes areas, bookmarks, contexts

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
