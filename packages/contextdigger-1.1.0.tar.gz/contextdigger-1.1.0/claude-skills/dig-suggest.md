# Area Suggestions

Get intelligent suggestions for which areas to explore next.

## Your Task:

Run the ContextDigger command to get intelligent suggestions for which areas to explore next.

## Implementation:

```bash
contextdigger suggest 
```

## Usage:

No arguments required.

## Notes:

- Based on dependencies and work patterns
- Context-aware suggestions
- Helps discover related code

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
