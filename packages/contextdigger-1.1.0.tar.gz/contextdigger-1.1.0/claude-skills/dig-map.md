# Codebase Map

Show a high-level map of all code areas and their relationships.

## Your Task:

Run the ContextDigger command to show a high-level map of all code areas and their relationships.

## Implementation:

```bash
contextdigger map 
```

## Usage:

No arguments required.

## Notes:

- Visual overview of codebase structure
- Shows dependencies between areas

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
