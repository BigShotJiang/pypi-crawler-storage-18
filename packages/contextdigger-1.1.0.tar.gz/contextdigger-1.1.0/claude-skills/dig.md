# Dig Into Code Area

Switch focus to a specific code area.

## Your Task:

Run the ContextDigger command to switch focus to a specific code area.

## Implementation:

```bash
contextdigger dig <area-id>
```

## Usage:

Usage: contextdigger dig <area-id>

## Notes:

- Use fuzzy matching if exact area ID not found
- Starts a new session for the area
- Tracks time spent in area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
