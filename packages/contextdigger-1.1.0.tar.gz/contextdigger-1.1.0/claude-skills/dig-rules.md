# Automation Rules

List configured automation rules.

## Your Task:

Run the ContextDigger command to list configured automation rules.

## Implementation:

```bash
contextdigger rules 
```

## Usage:

No arguments required.

## Notes:

- Shows active automation rules
- Includes triggers and actions

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
