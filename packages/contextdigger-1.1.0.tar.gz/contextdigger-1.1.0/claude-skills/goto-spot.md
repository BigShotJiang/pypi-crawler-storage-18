# Go To Spot - Jump to Bookmark

Jump to a previously saved bookmark.

## Your Task:

Run the ContextDigger command to jump to a previously saved bookmark.

## Implementation:

```bash
contextdigger goto-spot [bookmark-name]
```

## Usage:

Usage: contextdigger goto-spot [bookmark-name]

## Notes:

- Shows file context around bookmark
- Tracks access count
- Run without args to list all bookmarks

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
