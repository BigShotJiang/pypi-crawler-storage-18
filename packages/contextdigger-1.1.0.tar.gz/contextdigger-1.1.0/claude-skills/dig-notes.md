# View Notes for Area

View all notes for current or specified area.

## Your Task:

Run the ContextDigger command to view all notes for current or specified area.

## Implementation:

```bash
contextdigger notes [area-id]
```

## Usage:

Usage: contextdigger notes [area-id]

## Notes:

- Shows all notes with timestamps
- Defaults to current area

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
