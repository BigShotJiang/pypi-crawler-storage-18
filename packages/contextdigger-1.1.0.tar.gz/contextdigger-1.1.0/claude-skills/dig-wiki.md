# Generate Wiki Documentation

Generate wiki-style documentation from all areas and notes.

## Your Task:

Run the ContextDigger command to generate wiki-style documentation from all areas and notes.

## Implementation:

```bash
contextdigger wiki 
```

## Usage:

No arguments required.

## Notes:

- Combines area descriptions and notes
- Formatted as markdown
- Great for onboarding documentation

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
