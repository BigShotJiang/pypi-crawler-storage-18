# Statistics

View detailed statistics.

## Your Task:

Run the ContextDigger command to view detailed statistics.

## Implementation:

```bash
contextdigger stats 
```

## Usage:

No arguments required.

## Notes:

- Total counts
- Most focused areas
- Usage statistics

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
