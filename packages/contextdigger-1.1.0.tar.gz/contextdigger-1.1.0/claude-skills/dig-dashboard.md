# Dashboard

View comprehensive dashboard with key metrics.

## Your Task:

Run the ContextDigger command to view comprehensive dashboard with key metrics.

## Implementation:

```bash
contextdigger dashboard 
```

## Usage:

No arguments required.

## Notes:

- Overview statistics
- Alerts and warnings
- Recent activity
- Smart suggestions

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
