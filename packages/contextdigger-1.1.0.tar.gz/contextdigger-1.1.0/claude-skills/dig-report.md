# Generate Report

Generate a comprehensive report.

## Your Task:

Run the ContextDigger command to generate a comprehensive report.

## Implementation:

```bash
contextdigger report [output-file]
```

## Usage:

Usage: contextdigger report [output-file]

## Notes:

- Markdown format
- Includes all areas and statistics
- Outputs to file or stdout

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
