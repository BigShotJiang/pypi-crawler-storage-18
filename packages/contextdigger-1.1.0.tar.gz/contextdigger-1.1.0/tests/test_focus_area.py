"""
Unit tests for FocusArea class and path property.
"""

import pytest
from contextdigger.manager import FocusArea


class TestFocusAreaPath:
    """Test the path property extraction from patterns."""

    def test_path_from_simple_pattern(self):
        """Test: path extracted from simple include pattern."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": ["flowmason-studio/**/*.py"],
                "exclude": []
            }
        )

        assert area.path == "flowmason-studio"

    def test_path_from_nested_pattern(self):
        """Test: path extracted from nested directory pattern."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": ["src/components/**/*.tsx"],
                "exclude": []
            }
        )

        assert area.path == "src/components"

    def test_path_from_multiple_patterns(self):
        """Test: path extracted from first pattern when multiple exist."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": [
                    "flowmason/core/**/*.py",
                    "flowmason/utils/**/*.py"
                ],
                "exclude": []
            }
        )

        assert area.path == "flowmason/core"

    def test_path_with_glob_only(self):
        """Test: path when pattern is just glob."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": ["**/*.py"],
                "exclude": []
            }
        )

        assert area.path == "."

    def test_path_no_patterns(self):
        """Test: path returns empty string when no patterns."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="manual",
            patterns={}
        )

        assert area.path == ""

    def test_path_empty_include(self):
        """Test: path returns empty string when include is empty."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="manual",
            patterns={"include": [], "exclude": []}
        )

        assert area.path == ""

    def test_path_with_trailing_slash(self):
        """Test: path handles patterns with trailing slashes."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": ["docs/"],
                "exclude": []
            }
        )

        assert area.path == "docs"

    def test_path_with_file_extension(self):
        """Test: path handles patterns with file extensions."""
        area = FocusArea(
            id="test-area",
            name="Test Area",
            description="Test",
            type="auto-detected",
            patterns={
                "include": ["README.md"],
                "exclude": []
            }
        )

        assert area.path == "README.md"


class TestFocusAreaCreation:
    """Test FocusArea creation and attributes."""

    def test_create_minimal_area(self):
        """Test: Create FocusArea with minimal required fields."""
        area = FocusArea(
            id="test",
            name="Test",
            description="Test area",
            type="manual",
            patterns={"include": ["test/**"], "exclude": []}
        )

        assert area.id == "test"
        assert area.name == "Test"
        assert area.focusCount == 0
        assert area.lastFocused is None

    def test_create_with_metadata(self):
        """Test: Create FocusArea with metadata."""
        area = FocusArea(
            id="python-pkg",
            name="Python Package",
            description="Main package",
            type="auto-detected",
            patterns={"include": ["pkg/**/*.py"], "exclude": []},
            metadata={
                "language": "python",
                "framework": "pytest"
            }
        )

        assert area.metadata["language"] == "python"
        assert area.metadata["framework"] == "pytest"

    def test_create_with_dependencies(self):
        """Test: Create FocusArea with dependencies."""
        area = FocusArea(
            id="frontend",
            name="Frontend",
            description="UI components",
            type="auto-detected",
            patterns={"include": ["src/**/*.tsx"], "exclude": []},
            dependencies=["api", "utils"]
        )

        assert "api" in area.dependencies
        assert "utils" in area.dependencies
        assert len(area.dependencies) == 2

    def test_create_with_quick_access(self):
        """Test: Create FocusArea with quickAccess."""
        area = FocusArea(
            id="tests",
            name="Tests",
            description="Test suite",
            type="auto-detected",
            patterns={"include": ["tests/**/*.py"], "exclude": []},
            quickAccess={
                "commonTasks": ["pytest", "pytest --cov"]
            }
        )

        assert "commonTasks" in area.quickAccess
        assert "pytest" in area.quickAccess["commonTasks"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
