"""
Tests for auto-discovery functionality.
"""

import pytest
from pathlib import Path
from contextdigger.discover import FocusAreaDiscovery, DiscoveryConfig


class TestDiscovery:
    """Test area discovery on flow project."""

    PROJECT_PATH = Path("/Users/sam/Documents/CCAT/flow")

    def test_discover_flow_project(self):
        """Test: Discover areas in flow project."""
        discovery = FocusAreaDiscovery(self.PROJECT_PATH)
        areas = discovery.discover()

        assert len(areas) > 0, "No areas discovered in flow project"
        print(f"✓ Discovered {len(areas)} areas")

        # Verify all areas have required fields
        for area in areas:
            assert area.id, f"Area missing ID: {area}"
            assert area.name, f"Area missing name: {area}"
            assert area.description, f"Area missing description: {area}"
            assert area.patterns, f"Area missing patterns: {area}"
            assert "include" in area.patterns, f"Area missing include patterns: {area}"

    def test_discover_python_packages(self):
        """Test: Python packages are discovered."""
        config = DiscoveryConfig()
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, config)
        areas = discovery.discover()

        python_areas = [a for a in areas if a.metadata.get("language") == "python"]
        assert len(python_areas) > 0, "No Python packages discovered"
        print(f"✓ Discovered {len(python_areas)} Python areas")

    def test_discover_typescript_areas(self):
        """Test: TypeScript/JavaScript areas are discovered."""
        config = DiscoveryConfig()
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, config)
        areas = discovery.discover()

        ts_areas = [a for a in areas if a.metadata.get("language") in ["typescript", "javascript"]]
        # May or may not have TS areas depending on project structure
        print(f"✓ Discovered {len(ts_areas)} TypeScript/JavaScript areas")

    def test_area_patterns_valid(self):
        """Test: All discovered areas have valid glob patterns."""
        config = DiscoveryConfig()
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, config)
        areas = discovery.discover()

        for area in areas:
            assert len(area.patterns["include"]) > 0, f"Area {area.id} has no include patterns"

            # Verify patterns are valid globs (contain wildcards or specific paths)
            for pattern in area.patterns["include"]:
                assert pattern, f"Empty pattern in area {area.id}"
                assert "/" in pattern or "*" in pattern or "." in pattern, \
                    f"Invalid pattern '{pattern}' in area {area.id}"

        print("✓ All area patterns are valid")

    def test_area_ids_unique(self):
        """Test: All area IDs are unique."""
        config = DiscoveryConfig()
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, config)
        areas = discovery.discover()

        area_ids = [a.id for a in areas]
        unique_ids = set(area_ids)

        assert len(area_ids) == len(unique_ids), f"Duplicate area IDs found: {len(area_ids)} vs {len(unique_ids)}"
        print(f"✓ All {len(area_ids)} area IDs are unique")

    def test_area_types(self):
        """Test: All areas have valid types."""
        config = DiscoveryConfig()
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, config)
        areas = discovery.discover()

        valid_types = ["auto-detected", "manual"]

        for area in areas:
            assert area.type in valid_types, f"Area {area.id} has invalid type: {area.type}"

        auto_detected = [a for a in areas if a.type == "auto-detected"]
        print(f"✓ All areas have valid types ({len(auto_detected)} auto-detected)")

    def test_exclude_patterns(self):
        """Test: Exclude patterns work."""
        exclude_patterns = ["**/tests/**", "**/test/**"]
        discovery = FocusAreaDiscovery(self.PROJECT_PATH, exclude_patterns=exclude_patterns)
        areas = discovery.discover()

        # Verify discovery respects exclude patterns
        test_areas = [a for a in areas if 'test' in a.id.lower()]
        print(f"✓ Discovered {len(areas)} areas ({len(test_areas)} test-related areas)")

    def test_default_exclude_patterns(self):
        """Test: Default exclude patterns work."""
        discovery = FocusAreaDiscovery(self.PROJECT_PATH)
        areas = discovery.discover()

        # Verify no areas point to excluded directories
        excluded = ["node_modules", "__pycache__", ".git", "dist", "build"]
        for area in areas:
            for pattern in area.patterns.get("include", []):
                for excl in excluded:
                    assert f"/{excl}/" not in pattern, f"Area {area.id} includes excluded dir: {excl}"

        print(f"✓ Default exclude patterns applied")


class TestDiscoveryConfig:
    """Test DiscoveryConfig class."""

    def test_config_class_exists(self):
        """Test: DiscoveryConfig class exists and has language indicators."""
        config = DiscoveryConfig()

        # Verify it has the expected class attributes
        assert hasattr(config, 'LANGUAGE_INDICATORS')
        assert 'python' in config.LANGUAGE_INDICATORS
        assert 'javascript' in config.LANGUAGE_INDICATORS

        print("✓ DiscoveryConfig class has expected structure")

    def test_language_indicators(self):
        """Test: Language indicators are properly defined."""
        config = DiscoveryConfig()

        # Check Python indicators
        python = config.LANGUAGE_INDICATORS['python']
        assert 'indicators' in python
        assert 'test_patterns' in python
        assert 'entry_points' in python

        # Check JavaScript indicators
        js = config.LANGUAGE_INDICATORS['javascript']
        assert 'indicators' in js
        assert 'package.json' in js['indicators']

        print("✓ Language indicators are properly defined")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
