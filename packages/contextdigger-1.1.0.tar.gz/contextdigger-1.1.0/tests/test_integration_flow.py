"""
Integration tests for ContextDigger using /Users/sam/Documents/CCAT/flow project.
Tests the complete workflow from init to exploration.
"""

import subprocess
import json
import shutil
from pathlib import Path
import pytest


class TestContextDiggerIntegration:
    """Integration tests against real flow project."""

    PROJECT_PATH = Path("/Users/sam/Documents/CCAT/flow")
    CDG_DIR = PROJECT_PATH / ".cdg"

    @classmethod
    def setup_class(cls):
        """Setup: Clean any existing CDG data."""
        if cls.CDG_DIR.exists():
            shutil.rmtree(cls.CDG_DIR)

    @classmethod
    def teardown_class(cls):
        """Cleanup: Remove CDG directory after tests."""
        if cls.CDG_DIR.exists():
            shutil.rmtree(cls.CDG_DIR)

    def run_cmd(self, cmd: str) -> tuple[int, str, str]:
        """Run a contextdigger command and return (returncode, stdout, stderr)."""
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=self.PROJECT_PATH,
            capture_output=True,
            text=True
        )
        return result.returncode, result.stdout, result.stderr

    def test_01_init(self):
        """Test: contextdigger init creates .cdg directory and discovers areas."""
        returncode, stdout, stderr = self.run_cmd("contextdigger init")

        assert returncode == 0, f"Init failed: {stderr}"
        assert self.CDG_DIR.exists(), ".cdg directory not created"
        assert (self.CDG_DIR / "config.json").exists(), "config.json not created"
        assert (self.CDG_DIR / "areas" / "index.json").exists(), "areas index not created"

        # Check areas were discovered
        with open(self.CDG_DIR / "areas" / "index.json") as f:
            index = json.load(f)
            areas_count = len(index.get("areas", []))
            assert areas_count > 0, "No areas discovered"
            print(f"✓ Discovered {areas_count} areas")

    def test_02_list_areas(self):
        """Test: contextdigger list shows all discovered areas."""
        returncode, stdout, stderr = self.run_cmd("contextdigger list")

        assert returncode == 0, f"List failed: {stderr}"
        assert "Discovered Code Areas" in stdout, "List output format incorrect"

        # Count areas in output
        lines = [l for l in stdout.split('\n') if l.strip() and not l.startswith('=')]
        area_count = len([l for l in lines if not l.startswith('Discovered')])
        assert area_count > 0, "No areas listed"
        print(f"✓ Listed {area_count} areas")

    def test_03_status_no_focus(self):
        """Test: contextdigger status shows no focus initially."""
        returncode, stdout, stderr = self.run_cmd("contextdigger status")

        assert returncode == 0, f"Status failed: {stderr}"
        assert "Not currently digging" in stdout or "No active focus" in stdout
        print("✓ Status correctly shows no active focus")

    def test_04_dig_into_area(self):
        """Test: contextdigger dig <area> sets focus."""
        # Get first area from list
        _, stdout, _ = self.run_cmd("contextdigger list")
        lines = [l.strip() for l in stdout.split('\n') if l.strip()]
        # Find first area name (skip header)
        area_id = None
        for line in lines:
            if line and not line.startswith('=') and not line.startswith('Discovered'):
                area_id = line.strip()
                break

        assert area_id, "No area found to dig into"

        # Dig into the area
        returncode, stdout, stderr = self.run_cmd(f'contextdigger dig "{area_id}"')

        assert returncode == 0, f"Dig failed: {stderr}"
        assert "Digging into" in stdout or "⛏️" in stdout
        print(f"✓ Successfully dug into: {area_id}")

        # Verify status now shows focus
        returncode, stdout, stderr = self.run_cmd("contextdigger status")
        assert area_id in stdout or "Currently digging" in stdout
        print("✓ Status now shows active focus")

    def test_05_dashboard(self):
        """Test: contextdigger dashboard shows overview."""
        returncode, stdout, stderr = self.run_cmd("contextdigger dashboard")

        assert returncode == 0, f"Dashboard failed: {stderr}"
        assert "Dashboard" in stdout or "Overview" in stdout
        assert "Areas:" in stdout
        assert "Bookmarks:" in stdout
        assert "Notes:" in stdout
        print("✓ Dashboard displays correctly")

    def test_06_history(self):
        """Test: contextdigger history shows navigation history."""
        returncode, stdout, stderr = self.run_cmd("contextdigger history")

        assert returncode == 0, f"History failed: {stderr}"
        # History should have at least one entry from test_04
        assert stdout.strip() != "", "History is empty"
        print("✓ History tracks navigation")

    def test_07_area_patterns(self):
        """Test: Verify discovered areas have valid patterns."""
        with open(self.CDG_DIR / "areas" / "index.json") as f:
            index = json.load(f)
            areas = index.get("areas", [])

        assert len(areas) > 0, "No areas in index"

        # Extract area ID from first entry (could be dict or string)
        first_area = areas[0]
        if isinstance(first_area, dict):
            first_area_id = first_area['id']
        else:
            first_area_id = first_area

        area_file = self.CDG_DIR / "areas" / f"{first_area_id}.json"

        assert area_file.exists(), f"Area file not found: {area_file}"

        with open(area_file) as f:
            area_data = json.load(f)
            assert "patterns" in area_data, "Area missing patterns"
            assert "include" in area_data["patterns"], "Area missing include patterns"
            assert len(area_data["patterns"]["include"]) > 0, "Area has no include patterns"

        print(f"✓ Area patterns are valid")

    def test_08_config_validity(self):
        """Test: Verify config.json has required fields."""
        config_file = self.CDG_DIR / "config.json"
        assert config_file.exists(), "config.json not found"

        with open(config_file) as f:
            config = json.load(f)
            assert "version" in config, "Config missing version"
            assert "initialized" in config, "Config missing initialized timestamp"
            # Config structure may vary - just verify it's valid JSON with some expected fields

        print(f"✓ Config is valid")

    def test_09_multiple_dig_navigation(self):
        """Test: Navigate between multiple areas."""
        # Get area IDs from index file
        with open(self.CDG_DIR / "areas" / "index.json") as f:
            index = json.load(f)
            all_areas = index.get("areas", [])

        # Extract IDs (handle both dict and string formats)
        area_ids = []
        for area in all_areas[:3]:
            if isinstance(area, dict):
                area_ids.append(area['id'])
            else:
                area_ids.append(area)

        assert len(area_ids) >= 2, "Need at least 2 areas for navigation test"

        # Dig into first area
        returncode, stdout, stderr = self.run_cmd(f'contextdigger dig {area_ids[0]}')
        assert returncode == 0, f"First dig failed for {area_ids[0]}: {stderr}"

        # Dig into second area
        returncode, stdout, stderr = self.run_cmd(f'contextdigger dig {area_ids[1]}')
        assert returncode == 0, f"Second dig failed for {area_ids[1]}: {stderr}"

        # Check history has entries
        returncode, stdout, stderr = self.run_cmd("contextdigger history")
        assert returncode == 0, f"History failed: {stderr}"
        assert len(stdout.strip()) > 0, "History is empty after navigation"

        print("✓ Multiple area navigation works")

    def test_10_version(self):
        """Test: contextdigger --version shows version."""
        returncode, stdout, stderr = self.run_cmd("contextdigger --version")

        assert returncode == 0, f"Version failed: {stderr}"
        assert "contextdigger" in stdout.lower() or "1.0." in stdout
        print(f"✓ Version: {stdout.strip()}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
