# Contributing to ContextDigger

Thank you for your interest in contributing to ContextDigger! This document provides guidelines and information for contributors.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Project Structure](#project-structure)
- [Coding Guidelines](#coding-guidelines)
- [Submitting Changes](#submitting-changes)
- [Adding New Features](#adding-new-features)

---

## Code of Conduct

Be respectful, inclusive, and constructive. We're all here to make better tools for developers.

---

## How Can I Contribute?

### Reporting Bugs

Found a bug? Please [open an issue](https://github.com/ialameh/contextdigger/issues) with:

- **Clear title** - Describe the issue concisely
- **Steps to reproduce** - How to trigger the bug
- **Expected behavior** - What should happen
- **Actual behavior** - What actually happens
- **Environment** - OS, Python version, ContextDigger version
- **Error messages** - Include full stack traces if applicable

### Suggesting Features

Have an idea? [Open an issue](https://github.com/ialameh/contextdigger/issues) with:

- **Use case** - Why is this feature needed?
- **Proposed solution** - How would it work?
- **Alternatives** - What other approaches did you consider?
- **Examples** - Show how it would be used

### Contributing Code

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Test thoroughly
5. Commit with clear messages
6. Push to your fork
7. Open a Pull Request

---

## Development Setup

### Prerequisites

- Python 3.11+
- Git
- Claude Code (for testing skills)

### Installation

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/contextdigger.git
cd contextdigger

# Install in development mode
pip3 install -e .

# Link skills for testing
ln -s $(pwd)/claude-skills ~/.claude/commands-dev
```

### Testing Changes

```bash
# Test Python package
contextdigger --version

# Test in a sample project
cd /path/to/test/project
/init-dig
/dig-status
```

---

## Project Structure

```
contextdigger/
├── contextdigger/           # Python package
│   ├── __init__.py
│   ├── __main__.py         # CLI entry point
│   ├── manager.py          # Core FocusManager (4330+ lines)
│   ├── discover.py         # Auto-discovery algorithm
│   └── models.py           # Dataclass models
│
├── claude-skills/          # Claude Code skills (37 files)
│   ├── init-dig.md
│   ├── dig.md
│   ├── dig-*.md            # Feature skills
│   └── ...
│
├── README.md               # Main documentation
├── CHANGELOG.md            # Version history
├── QUICKSTART.md           # Getting started guide
├── CONTRIBUTING.md         # This file
├── setup.py                # Package configuration
├── install.sh              # Installation script
└── install-skills.sh       # Skills installer
```

### Key Files

**`contextdigger/manager.py`** (4330 lines)
- Core `FocusManager` class
- 60+ public methods
- All business logic

**`contextdigger/discover.py`**
- Auto-discovery algorithm
- Language/framework detection
- Area generation

**`contextdigger/models.py`**
- 20+ dataclasses
- Type-safe data structures

**`claude-skills/*.md`**
- Claude Code integration
- User-facing commands
- Python code blocks

---

## Coding Guidelines

### Python Style

- **PEP 8** compliant
- **Type hints** required for all public methods
- **Docstrings** for all public methods (Google style)
- **Dataclasses** for data structures
- **No external dependencies** - Use only Python stdlib

Example:

```python
def get_area_coverage(self, area_id: str) -> TestCoverage:
    """
    Get test coverage analysis for a specific area.

    Args:
        area_id: Unique identifier for the code area

    Returns:
        TestCoverage object with metrics

    Raises:
        ValueError: If area_id doesn't exist
    """
    area = self.get_area(area_id)
    if not area:
        raise ValueError(f"Area not found: {area_id}")

    # Implementation...
```

### File Structure

- **JSON storage** - All data in `.cdg/` directory
- **Atomic writes** - Use temp files + rename for safety
- **Path handling** - Use `pathlib.Path` everywhere
- **Error handling** - Catch and handle gracefully

### Claude Skills

Skills should:
- **Be self-contained** - All logic in the markdown
- **Show clear output** - User-friendly formatting
- **Handle errors** - Helpful error messages
- **Include examples** - Show usage patterns

Example skill structure:

```markdown
# Skill Name - Brief Description

Detailed explanation of what this skill does.

## Your Task:

Clear instruction for Claude.

## Implementation:

```python
import sys
from pathlib import Path

project_root = Path.cwd()
sys.path.insert(0, str(project_root))

from contextdigger.manager import FocusManager

manager = FocusManager(project_root)

if not manager.is_initialized():
    print("❌ ContextDigger not initialized")
    print("Run: /init-dig")
    exit(1)

# Skill logic here...
```

## Usage Examples:

Show common use cases.

## Notes:

Additional information.
```

---

## Submitting Changes

### Commit Messages

Use clear, descriptive commit messages:

```bash
# Good
git commit -m "Add test coverage gaps detection

- Implement find_coverage_gaps() method
- Add /dig-gaps skill
- Include threshold filtering
- Add documentation"

# Bad
git commit -m "fix stuff"
git commit -m "wip"
```

### Pull Request Process

1. **Update documentation** - README, CHANGELOG, etc.
2. **Test thoroughly** - Verify all features work
3. **Clear description** - Explain what and why
4. **Link issues** - Reference related issues
5. **Be responsive** - Address review feedback

### PR Template

```markdown
## Description

Brief description of changes.

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing

How did you test this?

## Checklist

- [ ] Code follows style guidelines
- [ ] Added docstrings
- [ ] Updated documentation
- [ ] Tested in real projects
- [ ] No external dependencies added
```

---

## Adding New Features

### Feature Development Workflow

1. **Discuss first** - Open an issue to discuss the approach
2. **Design the API** - Plan method signatures
3. **Implement core** - Add methods to `FocusManager`
4. **Add dataclasses** - Create models if needed
5. **Create skills** - Add Claude Code commands
6. **Update docs** - README, examples, etc.
7. **Test extensively** - Verify in real projects

### Example: Adding a New Analysis Feature

Let's say you want to add "code smell detection":

#### 1. Add Dataclass (`models.py`)

```python
@dataclass
class CodeSmell:
    """Represents a detected code smell."""
    id: str
    smell_type: str  # e.g., "long_method", "god_class"
    severity: str  # low, medium, high
    file_path: str
    line_number: int
    description: str
    suggestion: str
    detected_at: str = field(default_factory=lambda: datetime.now().isoformat())
```

#### 2. Add Method (`manager.py`)

```python
def detect_code_smells(
    self,
    area_id: Optional[str] = None,
    min_severity: str = "medium"
) -> List[CodeSmell]:
    """
    Detect code smells in an area.

    Args:
        area_id: Area to analyze (None = current focus)
        min_severity: Minimum severity to include

    Returns:
        List of detected code smells
    """
    # Implementation here...
    pass
```

#### 3. Create Skill (`claude-skills/dig-smells.md`)

```markdown
# Dig Smells - Code Smell Detection

Find potential code quality issues in your codebase.

## Your Task:

Detect code smells and suggest improvements.

## Implementation:

```python
from contextdigger.manager import FocusManager
from pathlib import Path

manager = FocusManager(Path.cwd())
# ... implementation
```
```

#### 4. Update Documentation

- Add to README.md command reference
- Add to CHANGELOG.md
- Add example workflow
- Update install-skills.sh

---

## Architecture Decisions

### Why No External Dependencies?

- **Simplicity** - Easy installation, no dependency hell
- **Reliability** - No breaking changes from third parties
- **Portability** - Works everywhere Python runs
- **Security** - Smaller attack surface

### Why JSON Storage?

- **Human-readable** - Easy to inspect and debug
- **Git-friendly** - Diffs work well
- **No server** - Works offline, no infrastructure
- **Universal** - Every language can read JSON

### Why File-Based?

- **Simplicity** - No database setup
- **Portability** - Copy `.cdg/` to migrate
- **Git integration** - Commit shared data
- **Zero config** - Just works

---

## Questions?

- **Issues**: [GitHub Issues](https://github.com/ialameh/contextdigger/issues)
- **Discussions**: [GitHub Discussions](https://github.com/ialameh/contextdigger/discussions)
- **Email**: Check GitHub profile

---

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to ContextDigger! 🎉⛏️
