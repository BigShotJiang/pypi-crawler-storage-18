# ContextDigger Quick Start Guide

Get started with ContextDigger in 5 minutes.

## Installation (2 minutes)

### Step 1: Install Python Package

```bash
pip3 install --user git+https://github.com/ialameh/contextdigger.git
```

### Step 2: Install Claude Skills

```bash
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash
```

### Step 3: Verify Installation

```bash
contextdigger --version
# Should show: ContextDigger v1.0.0

ls ~/.claude/commands/*dig*.md | wc -l
# Should show: 37+ skills
```

---

## Your First Session (3 minutes)

### 1. Initialize Your Project

Open Claude Code in your project directory:

```bash
cd /path/to/your/project
```

Then run:

```
/init-dig
```

**What happens:**
- Scans your codebase
- Detects languages and frameworks
- Discovers code areas automatically
- Creates `.cdg/` directory

**Output example:**
```
⛏️  Digging through codebase...
✓ Discovered 5 code areas

1. backend-api (Python)
2. frontend-components (TypeScript)
3. database-layer (Python)
4. test-suite (Python)
5. config-files (YAML)
```

### 2. Dig Into an Area

```
/dig backend-api
```

**What you see:**
- Area information and files
- Recent history in this area
- Suggested next steps

### 3. Mark Important Locations

While viewing code:

```
/mark-spot authentication-logic
```

**What it saves:**
- Current file and line number
- Code context around the line
- Your bookmark name

### 4. Navigate Back Later

From anywhere in your project:

```
/goto-spot authentication-logic
```

**What happens:**
- Jumps to exact file:line
- Restores full context
- Ready to continue work

---

## Common Workflows

### Daily Check-in

```
/dig-dashboard
```

See metrics, alerts, recent activity, and suggestions.

### Bug Investigation

```
# 1. Dig into the buggy area
/dig backend-api

# 2. Mark the bug location
/mark-spot bug-payment-processing

# 3. Check dependencies
/dig-deps backend-api

# 4. See recent changes (hotspots)
/dig-hotspots

# 5. Jump back to fix
/goto-spot bug-payment-processing
```

### Code Review

```
# 1. Check test coverage
/dig-coverage backend-api

# 2. Find gaps
/dig-gaps

# 3. See impact of changes
/dig-impact backend-api

# 4. Review hotspots
/dig-hotspots
```

### Knowledge Sharing

```
# 1. Add notes while exploring
/dig-note "Authentication uses JWT with RS256"

# 2. View team activity
/dig-team

# 3. Generate wiki for onboarding
/dig-wiki TEAM_GUIDE.md
```

### Weekly Reporting

```
# 1. View analytics
/dig-analytics

# 2. Generate report
/dig-report weekly-report.md

# 3. Export data
/dig-export json  # For data analysis
/dig-export html  # For browser viewing
```

### Backup & Maintenance

```
# 1. Run health check
/dig-health

# 2. Create backup
/dig-backup

# 3. View statistics
/dig-stats
```

---

## Essential Commands

### Must-Know (Top 10)

```
/init-dig          # Initialize in project (run once)
/dig <area>        # Dig into code area
/redig             # Interactive area selector
/dig-status        # Where am I?

/mark-spot <name>  # Bookmark location
/goto-spot <name>  # Jump to bookmark

/dig-dashboard     # Daily overview
/dig-hotspots      # Find problem areas
/dig-search <term> # Search everything
/dig-backup        # Backup all data
```

### Navigation

```
/dig-back          # Go back
/dig-forward       # Go forward
/dig-history       # View full history
/dig-trail         # Breadcrumb trail
```

### Snapshots & Context

```
/dig-snapshot <name>     # Save mental state
/dig-snapshots           # List snapshots
/dig-restore <snapshot>  # Restore state
/dig-compare <snapshot>  # Compare states
```

### Team & Knowledge

```
/dig-team          # Who's working where
/dig-note <title>  # Add note
/dig-notes         # View notes
/dig-wiki          # Generate wiki
```

### Analysis

```
/dig-deps          # Dependencies
/dig-impact        # Change impact
/dig-map           # Dependency graph
/dig-coverage      # Test coverage
/dig-gaps          # Coverage gaps
/dig-perf          # Performance data
```

---

## Tips & Tricks

### 1. Use History Like a Browser

Navigate naturally:
```
/dig frontend     # Dig into frontend
/dig backend      # Switch to backend
/dig-back         # Return to frontend
/dig-forward      # Back to backend
```

### 2. Snapshot Before Big Changes

```
/dig-snapshot before-refactor
# ... make changes ...
/dig-compare before-refactor  # See what changed
/dig-restore before-refactor  # Undo if needed
```

### 3. Mark Strategic Locations

```
/mark-spot api-entry-point
/mark-spot database-connection
/mark-spot auth-middleware
/mark-spot payment-processor

# Later: jump to any of them instantly
/goto-spot auth-middleware
```

### 4. Daily Dashboard Routine

Start each day:
```
/dig-dashboard    # Check alerts and recent activity
/dig-health       # Verify system health
```

### 5. Search Everything

```
/dig-search authentication     # Find in all data
/dig-search "API endpoint"     # Quoted for phrases
/dig-search tag:security       # By tag
```

### 6. Export for Sharing

```
/dig-export html  # Share with non-Claude users
/dig-wiki         # Generate team documentation
/dig-report       # Comprehensive markdown
```

---

## What to Commit to Git

**DO commit:**
```
.cdg/areas/        ✅  Share discovered areas with team
.cdg/config.json   ✅  Project configuration
```

**DON'T commit:**
```
.cdg/sessions/     ❌  Personal exploration history
.cdg/bookmarks/    ❌  Personal bookmarks
.cdg/snapshots/    ❌  Personal snapshots
.cdg/team/         ❌  Team activity (each user generates)
```

The `.cdg/.gitignore` is already configured correctly!

---

## Getting Help

### In Claude Code

```
# Most skills show help without arguments
/dig-backup         # Shows usage
/dig-export         # Shows formats
/dig-search         # Shows syntax
```

### Documentation

- **Full README:** [github.com/ialameh/contextdigger](https://github.com/ialameh/contextdigger)
- **Changelog:** [CHANGELOG.md](CHANGELOG.md)
- **Issues:** [GitHub Issues](https://github.com/ialameh/contextdigger/issues)

### Common Issues

**"ContextDigger not initialized"**
```
/init-dig
```

**"No current dig"**
```
/dig <area-name>
# or
/redig  # Interactive selector
```

**Skills not found**
```bash
# Reinstall skills
curl -o - "https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh" | bash
```

---

## Next Steps

1. **Explore Areas** - Use `/redig` to browse all discovered areas
2. **Add Notes** - Document as you explore with `/dig-note`
3. **Check Coverage** - Find gaps with `/dig-gaps`
4. **Set Up Automation** - Create rules with `/dig-auto`
5. **Generate Reports** - Share insights with `/dig-report`

---

**Ready to dig deeper?** Check out the full [README.md](README.md) for advanced features and workflows.

**Questions or feedback?** Open an issue at [github.com/ialameh/contextdigger/issues](https://github.com/ialameh/contextdigger/issues)

Happy digging! ⛏️
