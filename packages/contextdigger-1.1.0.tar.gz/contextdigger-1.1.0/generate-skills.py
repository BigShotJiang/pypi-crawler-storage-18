#!/usr/bin/env python3
"""
Generate all Claude Code skill files that call CLI commands.
This eliminates approval prompts by using simple bash commands instead of inline Python.
"""

from pathlib import Path

# Define all skills with their metadata
SKILLS = [
    # Core Navigation
    {
        "file": "init-dig.md",
        "title": "Initialize ContextDigger",
        "description": "Initialize ContextDigger in your project to start discovering code areas",
        "command": "contextdigger init",
        "usage": "No arguments required",
        "notes": [
            "Creates `.cdg/` directory structure",
            "Discovers code areas automatically",
            "Safe to run multiple times (will ask for confirmation)",
        ],
    },
    {
        "file": "dig.md",
        "title": "Dig Into Code Area",
        "description": "Switch focus to a specific code area",
        "command": "contextdigger dig",
        "usage": "<area-id>",
        "notes": [
            "Use fuzzy matching if exact area ID not found",
            "Starts a new session for the area",
            "Tracks time spent in area",
        ],
    },
    {
        "file": "redig.md",
        "title": "Re-dig - Interactive Area Selector",
        "description": "Show all discovered areas and select one interactively",
        "command": "contextdigger redig",
        "usage": "No arguments required",
        "notes": [
            "Shows all areas with current focus highlighted",
            "Lists areas with descriptions",
            "Use /dig <area-id> to switch to an area",
        ],
    },
    {
        "file": "dig-status.md",
        "title": "Dig Status - Show Current Session",
        "description": "Show current dig status and session information",
        "command": "contextdigger status",
        "usage": "No arguments required",
        "notes": [
            "Shows current focus area",
            "Session duration",
            "Files modified in session",
        ],
    },
    {
        "file": "dig-back.md",
        "title": "Navigate Back in History",
        "description": "Go back to the previous area in your navigation history",
        "command": "contextdigger back",
        "usage": "No arguments required",
        "notes": [
            "Works like browser back button",
            "Maintains navigation history",
            "Use /dig-forward to go forward",
        ],
    },
    {
        "file": "dig-forward.md",
        "title": "Navigate Forward in History",
        "description": "Go forward to the next area in your navigation history",
        "command": "contextdigger forward",
        "usage": "No arguments required",
        "notes": [
            "Works like browser forward button",
            "Only works if you've navigated back",
            "Use /dig-back to go back",
        ],
    },

    # Bookmarks
    {
        "file": "mark-spot.md",
        "title": "Mark Spot - Save Bookmark",
        "description": "Save current file location as a bookmark for quick access later",
        "command": "contextdigger mark-spot",
        "usage": "<name> <file-path> [line-number]",
        "notes": [
            "Bookmarks persist across sessions",
            "Can include line numbers",
            "Use /goto-spot to jump to bookmarks",
        ],
    },
    {
        "file": "goto-spot.md",
        "title": "Go To Spot - Jump to Bookmark",
        "description": "Jump to a previously saved bookmark",
        "command": "contextdigger goto-spot",
        "usage": "[bookmark-name]",
        "notes": [
            "Shows file context around bookmark",
            "Tracks access count",
            "Run without args to list all bookmarks",
        ],
    },

    # Context Snapshots
    {
        "file": "save-context.md",
        "title": "Save Context Snapshot",
        "description": "Save current work context (area, bookmarks, history) for later",
        "command": "contextdigger save-context",
        "usage": "<name> [description]",
        "notes": [
            "Saves current area, bookmarks, and history",
            "Great for switching between tasks",
            "Use /load-context to restore",
        ],
    },
    {
        "file": "load-context.md",
        "title": "Load Context Snapshot",
        "description": "Restore a previously saved work context",
        "command": "contextdigger load-context",
        "usage": "<name>",
        "notes": [
            "Restores area, bookmarks, and history",
            "Useful for task switching",
            "Run /list-contexts to see all snapshots",
        ],
    },
    {
        "file": "list-contexts.md",
        "title": "List Context Snapshots",
        "description": "Show all saved context snapshots",
        "command": "contextdigger list-contexts",
        "usage": "No arguments required",
        "notes": [
            "Shows all saved contexts with descriptions",
            "Includes save timestamps",
        ],
    },
    {
        "file": "delete-context.md",
        "title": "Delete Context Snapshot",
        "description": "Delete a saved context snapshot",
        "command": "contextdigger delete-context",
        "usage": "<name>",
        "notes": [
            "Permanently removes the snapshot",
            "Cannot be undone",
        ],
    },

    # Notes & Documentation
    {
        "file": "dig-note.md",
        "title": "Add Note to Current Area",
        "description": "Add a note or comment to the current code area",
        "command": "contextdigger note",
        "usage": "<note-text>",
        "notes": [
            "Notes are attached to the current area",
            "Include timestamps",
            "Use /dig-notes to view all notes for an area",
        ],
    },
    {
        "file": "dig-notes.md",
        "title": "View Notes for Area",
        "description": "View all notes for current or specified area",
        "command": "contextdigger notes",
        "usage": "[area-id]",
        "notes": [
            "Shows all notes with timestamps",
            "Defaults to current area",
        ],
    },
    {
        "file": "dig-wiki.md",
        "title": "Generate Wiki Documentation",
        "description": "Generate wiki-style documentation from all areas and notes",
        "command": "contextdigger wiki",
        "usage": "No arguments required",
        "notes": [
            "Combines area descriptions and notes",
            "Formatted as markdown",
            "Great for onboarding documentation",
        ],
    },

    # Analysis & Intelligence
    {
        "file": "dig-suggest.md",
        "title": "Area Suggestions",
        "description": "Get intelligent suggestions for which areas to explore next",
        "command": "contextdigger suggest",
        "usage": "No arguments required",
        "notes": [
            "Based on dependencies and work patterns",
            "Context-aware suggestions",
            "Helps discover related code",
        ],
    },
    {
        "file": "dig-deps.md",
        "title": "Show Dependencies",
        "description": "Show dependencies for current or specified area",
        "command": "contextdigger deps",
        "usage": "[area-id]",
        "notes": [
            "Shows which areas this area depends on",
            "Includes relationship types",
            "Defaults to current area",
        ],
    },
    {
        "file": "dig-impact.md",
        "title": "Impact Analysis",
        "description": "Show which areas would be affected by changes to a given area",
        "command": "contextdigger impact",
        "usage": "<area-id>",
        "notes": [
            "Shows dependent areas (reverse dependencies)",
            "Helps estimate change impact",
            "Critical for refactoring",
        ],
    },
    {
        "file": "dig-map.md",
        "title": "Codebase Map",
        "description": "Show a high-level map of all code areas and their relationships",
        "command": "contextdigger map",
        "usage": "No arguments required",
        "notes": [
            "Visual overview of codebase structure",
            "Shows dependencies between areas",
        ],
    },
    {
        "file": "dig-hotspots.md",
        "title": "Find Code Hotspots",
        "description": "Identify files with high change frequency and complexity",
        "command": "contextdigger hotspots",
        "usage": "[days]",
        "notes": [
            "Defaults to last 30 days",
            "Shows commit count and complexity",
            "Identifies problem areas",
        ],
    },
    {
        "file": "dig-gaps.md",
        "title": "Find Coverage Gaps",
        "description": "Identify areas with low test coverage",
        "command": "contextdigger gaps",
        "usage": "No arguments required",
        "notes": [
            "Shows areas below coverage threshold",
            "Defaults to 70% threshold",
        ],
    },
    {
        "file": "dig-perf.md",
        "title": "Performance Analysis",
        "description": "Analyze performance characteristics of an area",
        "command": "contextdigger perf",
        "usage": "[area-id]",
        "notes": [
            "Shows complexity metrics",
            "Defaults to current area",
        ],
    },
    {
        "file": "dig-benchmark.md",
        "title": "Run Benchmarks",
        "description": "Run benchmarks and show overall statistics",
        "command": "contextdigger benchmark",
        "usage": "No arguments required",
        "notes": [
            "Shows counts of areas, sessions, bookmarks",
            "Quick health check",
        ],
    },

    # Search & Query
    {
        "file": "dig-search.md",
        "title": "Search All Data",
        "description": "Search across areas, bookmarks, and notes",
        "command": "contextdigger search",
        "usage": "<query>",
        "notes": [
            "Searches area names and descriptions",
            "Searches bookmark names and paths",
            "Shows top 5 results",
        ],
    },
    {
        "file": "dig-query.md",
        "title": "Custom Query",
        "description": "Run custom queries against ContextDigger data",
        "command": "contextdigger query",
        "usage": "<query>",
        "notes": [
            "Advanced querying (coming soon)",
        ],
    },

    # Automation
    {
        "file": "dig-auto.md",
        "title": "Automation Suggestions",
        "description": "Get suggestions for automating common tasks",
        "command": "contextdigger auto",
        "usage": "No arguments required",
        "notes": [
            "Suggests automation opportunities",
            "Based on usage patterns",
        ],
    },
    {
        "file": "dig-rules.md",
        "title": "Automation Rules",
        "description": "List configured automation rules",
        "command": "contextdigger rules",
        "usage": "No arguments required",
        "notes": [
            "Shows active automation rules",
            "Includes triggers and actions",
        ],
    },

    # Reports & Export
    {
        "file": "dig-analytics.md",
        "title": "Work Analytics",
        "description": "View work analytics and time tracking",
        "command": "contextdigger analytics",
        "usage": "[days]",
        "notes": [
            "Defaults to last 30 days",
            "Shows session counts and time spent",
            "Top areas worked",
        ],
    },
    {
        "file": "dig-report.md",
        "title": "Generate Report",
        "description": "Generate a comprehensive report",
        "command": "contextdigger report",
        "usage": "[output-file]",
        "notes": [
            "Markdown format",
            "Includes all areas and statistics",
            "Outputs to file or stdout",
        ],
    },
    {
        "file": "dig-export.md",
        "title": "Export Data",
        "description": "Export ContextDigger data in various formats",
        "command": "contextdigger export",
        "usage": "<format>",
        "notes": [
            "Supports: json, markdown",
            "Includes areas, bookmarks, contexts",
        ],
    },
    {
        "file": "dig-backup.md",
        "title": "Create Backup",
        "description": "Create a backup of all ContextDigger data",
        "command": "contextdigger backup",
        "usage": "No arguments required",
        "notes": [
            "Creates .tar.gz archive",
            "Includes all .cdg directory contents",
            "Timestamped filename",
        ],
    },

    # Dashboard & Monitoring
    {
        "file": "dig-dashboard.md",
        "title": "Dashboard",
        "description": "View comprehensive dashboard with key metrics",
        "command": "contextdigger dashboard",
        "usage": "No arguments required",
        "notes": [
            "Overview statistics",
            "Alerts and warnings",
            "Recent activity",
            "Smart suggestions",
        ],
    },
    {
        "file": "dig-health.md",
        "title": "Health Check",
        "description": "Run health check on ContextDigger data",
        "command": "contextdigger health",
        "usage": "No arguments required",
        "notes": [
            "Checks for issues",
            "Validates data integrity",
            "Reports status",
        ],
    },
    {
        "file": "dig-stats.md",
        "title": "Statistics",
        "description": "View detailed statistics",
        "command": "contextdigger stats",
        "usage": "No arguments required",
        "notes": [
            "Total counts",
            "Most focused areas",
            "Usage statistics",
        ],
    },

    # Team
    {
        "file": "dig-team.md",
        "title": "Team Activity",
        "description": "View recent team activity",
        "command": "contextdigger team",
        "usage": "No arguments required",
        "notes": [
            "Last 24 hours of team activity",
            "Shows who worked on what",
            "Based on git commits",
        ],
    },
    {
        "file": "dig-tests.md",
        "title": "Test Coverage",
        "description": "View test coverage for current or specified area",
        "command": "contextdigger tests",
        "usage": "[area-id]",
        "notes": [
            "Line and branch coverage",
            "File counts",
            "Defaults to current area",
        ],
    },
]


def generate_skill(skill_data: dict) -> str:
    """Generate a skill file content."""
    usage_line = f"Usage: {skill_data['command']} {skill_data['usage']}" if skill_data['usage'] != "No arguments required" else "No arguments required."

    notes_section = "\n".join(f"- {note}" for note in skill_data['notes'])

    return f"""# {skill_data['title']}

{skill_data['description']}.

## Your Task:

Run the ContextDigger command to {skill_data['description'].lower()}.

## Implementation:

```bash
{skill_data['command']} {skill_data['usage'] if skill_data['usage'] != "No arguments required" else ""}
```

## Usage:

{usage_line}

## Notes:

{notes_section}

## Related Commands:

Run `/dig-dashboard` to see overall status and suggestions.
"""


def main():
    """Generate all skill files."""
    output_dir = Path("claude-skills")
    output_dir.mkdir(exist_ok=True)

    print(f"Generating {len(SKILLS)} skill files...")

    for skill in SKILLS:
        file_path = output_dir / skill["file"]
        content = generate_skill(skill)
        file_path.write_text(content)
        print(f"✓ Generated {skill['file']}")

    print(f"\n✓ All {len(SKILLS)} skill files generated successfully!")
    print("\nNext steps:")
    print("1. Run: ./install-skills.sh")
    print("2. Test with: /dig-dashboard")


if __name__ == "__main__":
    main()
