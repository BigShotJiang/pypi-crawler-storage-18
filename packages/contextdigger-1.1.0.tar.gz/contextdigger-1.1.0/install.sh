#!/usr/bin/env bash
#
# ContextDigger Installer & Updater
# This script installs or updates ContextDigger with a single command:
#
#   curl -sSL https://contextdigger.com/install.sh | bash
#
# What it does:
# 1. Installs/updates the Python package from GitHub
# 2. Installs/updates the Claude Code skills
#
# Requirements:
# - Python 3.11+
# - pip3
# - Claude Code
#

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Detect OS
OS="$(uname -s)"
case "${OS}" in
    Linux*)     MACHINE=Linux;;
    Darwin*)    MACHINE=Mac;;
    CYGWIN*)    MACHINE=Cygwin;;
    MINGW*)     MACHINE=MinGw;;
    *)          MACHINE="UNKNOWN:${OS}"
esac

echo -e "${BLUE}"
echo "⛏️  ContextDigger Installer"
echo "============================"
echo -e "${NC}"
echo "System: $MACHINE"
echo ""

# Check Python version
echo -e "${BLUE}Checking requirements...${NC}"

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 not found${NC}"
    echo "Please install Python 3.11 or higher"
    echo "Visit: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)

echo "Python version: $PYTHON_VERSION"

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    echo -e "${RED}❌ Python 3.11+ required (found $PYTHON_VERSION)${NC}"
    echo "Please upgrade Python: https://www.python.org/downloads/"
    exit 1
fi

if ! command -v pip3 &> /dev/null; then
    echo -e "${RED}❌ pip3 not found${NC}"
    echo "Please install pip3"
    exit 1
fi

echo -e "${GREEN}✓ Requirements met${NC}"
echo ""

# Step 1: Install/Update Python package
echo -e "${BLUE}Step 1: Installing ContextDigger package...${NC}"
echo "This may take a minute..."
echo ""

if pip3 show contextdigger &> /dev/null; then
    echo -e "${YELLOW}ContextDigger already installed, updating...${NC}"
    pip3 install --user --upgrade git+https://github.com/ialameh/contextdigger.git
else
    echo -e "${YELLOW}Installing ContextDigger for the first time...${NC}"
    pip3 install --user git+https://github.com/ialameh/contextdigger.git
fi

echo ""
echo -e "${GREEN}✓ Package installed${NC}"
echo ""

# Verify installation
if ! command -v contextdigger &> /dev/null; then
    echo -e "${YELLOW}⚠️  Warning: 'contextdigger' command not found in PATH${NC}"
    echo ""
    echo "You may need to add the pip user bin directory to your PATH:"

    if [ "$MACHINE" = "Mac" ] || [ "$MACHINE" = "Linux" ]; then
        echo ""
        echo "Add this to your ~/.bashrc or ~/.zshrc:"
        echo ""
        echo '  export PATH="$HOME/.local/bin:$PATH"'
        echo ""
        echo "Then run: source ~/.bashrc  (or ~/.zshrc)"
    fi
    echo ""
fi

# Step 2: Install Claude Code skills
echo -e "${BLUE}Step 2: Installing Claude Code skills...${NC}"
echo ""

SKILLS_URL="https://raw.githubusercontent.com/ialameh/contextdigger/main/install-skills.sh"

if command -v curl &> /dev/null; then
    curl -sSL "$SKILLS_URL" | bash
elif command -v wget &> /dev/null; then
    wget -qO- "$SKILLS_URL" | bash
else
    echo -e "${RED}❌ Neither curl nor wget found${NC}"
    echo "Please install curl or wget and run:"
    echo "  curl -sSL $SKILLS_URL | bash"
    exit 1
fi

echo ""

# Final success message
echo -e "${GREEN}"
echo "================================"
echo "✓ Installation Complete!"
echo "================================"
echo -e "${NC}"
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo ""
echo "1. Open Claude Code in your project directory"
echo "2. Run: ${GREEN}/init-dig${NC}"
echo "3. Start exploring with: ${GREEN}/dig <area>${NC}"
echo ""
echo -e "${BLUE}Useful Commands:${NC}"
echo "  ${GREEN}/init-dig${NC}          - Initialize in your project"
echo "  ${GREEN}/dig <area>${NC}        - Dig into a code area"
echo "  ${GREEN}/dig-dashboard${NC}     - View overview dashboard"
echo "  ${GREEN}/mark-spot <name>${NC}  - Bookmark current location"
echo "  ${GREEN}/goto-spot <name>${NC}  - Jump to bookmark"
echo ""
echo -e "${BLUE}Documentation:${NC}"
echo "  https://contextdigger.com/documentation"
echo ""
echo -e "${BLUE}Get Help:${NC}"
echo "  https://github.com/ialameh/contextdigger/issues"
echo ""
echo "Happy digging! ⛏️"
echo ""
