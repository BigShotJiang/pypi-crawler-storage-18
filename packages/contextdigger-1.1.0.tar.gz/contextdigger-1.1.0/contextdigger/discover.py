"""
Focus Area Discovery Algorithm

Automatically discovers logical focus areas in a codebase by analyzing
project structure, file patterns, and language indicators. Works across
Python, JavaScript, Salesforce, and other languages.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
from collections import defaultdict
import re

from .manager import FocusArea


class DiscoveryConfig:
    """Configuration for discovery patterns and heuristics."""

    # Language detection indicators
    LANGUAGE_INDICATORS = {
        "python": {
            "indicators": ["pyproject.toml", "setup.py", "requirements.txt", "*.py"],
            "test_patterns": ["tests/", "test_*.py", "*_test.py"],
            "entry_points": ["main.py", "__init__.py", "cli.py", "__main__.py"],
            "structure": ["src/", "tests/", "docs/"],
        },
        "javascript": {
            "indicators": ["package.json", "*.js", "*.ts", "*.jsx", "*.tsx"],
            "test_patterns": ["__tests__/", "*.test.js", "*.spec.js", "*.test.ts", "*.spec.ts"],
            "entry_points": ["index.js", "main.js", "index.ts", "app.js"],
            "structure": ["src/", "lib/", "dist/", "test/"],
        },
        "salesforce": {
            "indicators": ["sfdx-project.json", "*.cls", "*.trigger"],
            "test_patterns": ["*_Test.cls", "*Test.cls"],
            "entry_points": ["force-app/main/default/classes/"],
            "structure": ["force-app/", "manifest/", "config/"],
        },
        "nextjs": {
            "indicators": ["next.config.js", "next.config.mjs", "app/", "pages/"],
            "test_patterns": ["*.test.tsx", "*.test.ts", "*.spec.tsx"],
            "entry_points": ["app/page.tsx", "pages/index.tsx", "pages/index.js"],
            "structure": ["app/", "pages/", "public/", "components/"],
        },
        "astro": {
            "indicators": ["astro.config.mjs", "*.astro"],
            "test_patterns": ["*.test.js", "*.spec.js"],
            "entry_points": ["src/pages/index.astro"],
            "structure": ["src/pages/", "src/components/", "src/layouts/"],
        },
    }

    # Structural patterns for grouping
    STRUCTURAL_PATTERNS = {
        "frontend": {
            "patterns": ["**/components/**", "**/pages/**", "**/public/**", "**/static/**", "**/assets/**"],
            "weight": 0.8,
        },
        "backend": {
            "patterns": ["**/api/**", "**/server/**", "**/backend/**", "**/force-app/**", "**/core/**"],
            "weight": 0.9,
        },
        "tests": {
            "patterns": ["**/tests/**", "**/__tests__/**", "**/test/**"],
            "weight": 1.0,
        },
        "docs": {
            "patterns": ["**/docs/**", "**/*.md", "**/documentation/**"],
            "weight": 0.6,
        },
        "scripts": {
            "patterns": ["**/scripts/**", "**/bin/**", "**/*.sh"],
            "weight": 0.5,
        },
        "config": {
            "patterns": ["**/config/**", "**/.config/**", "**/settings/**"],
            "weight": 0.4,
        },
    }


class FocusAreaDiscovery:
    """Discovers focus areas in a codebase."""

    def __init__(self, project_root: Path, exclude_patterns: Optional[List[str]] = None):
        """
        Initialize discovery.

        Args:
            project_root: Root directory of the project
            exclude_patterns: Patterns to exclude from discovery
        """
        self.project_root = Path(project_root).resolve()
        self.exclude_patterns = exclude_patterns or [
            "**/__pycache__/**",
            "**/*.pyc",
            "**/node_modules/**",
            "**/.git/**",
            "**/dist/**",
            "**/build/**",
            "**/.venv/**",
            "**/.cdg/**",
            "**/coverage/**",
            "**/.pytest_cache/**",
        ]

    def discover(self) -> List[FocusArea]:
        """
        Run full discovery process.

        Returns:
            List of discovered focus areas
        """
        print("🔍 Discovering focus areas...")

        # Pass 1: Detect languages and frameworks
        languages = self._detect_languages()
        print(f"   Found languages: {', '.join(languages.keys())}")

        # Pass 2: Detect project structure (monorepo vs single)
        is_monorepo, sub_projects = self._detect_monorepo()
        if is_monorepo:
            print(f"   Detected monorepo with {len(sub_projects)} sub-projects")

        # Pass 3: Group by logical areas
        areas = []

        if is_monorepo:
            # Create areas per sub-project
            for project_path, project_info in sub_projects.items():
                project_areas = self._create_areas_for_project(project_path, project_info)
                areas.extend(project_areas)
        else:
            # Create areas for single project
            areas = self._create_areas_for_project(self.project_root, {"languages": languages})

        # Deduplicate areas by ID (keep the one with simplest/shortest path)
        areas = self._deduplicate_areas(areas)

        print(f"✓ Discovered {len(areas)} focus areas")
        return areas

    def _deduplicate_areas(self, areas: List[FocusArea]) -> List[FocusArea]:
        """
        Remove duplicate area IDs, keeping the one with the simplest path.

        When multiple areas have the same ID (e.g., discovered from different locations),
        keep the one with the shortest/simplest include pattern path.
        """
        from collections import defaultdict

        # Group areas by ID
        areas_by_id = defaultdict(list)
        for area in areas:
            areas_by_id[area.id].append(area)

        # For each ID, keep only the best one
        unique_areas = []
        for area_id, duplicate_areas in areas_by_id.items():
            if len(duplicate_areas) == 1:
                # No duplicates, keep as is
                unique_areas.append(duplicate_areas[0])
            else:
                # Multiple areas with same ID - pick the best one
                # Prefer: 1) fewer path segments, 2) not in tests/, 3) first discovered
                def area_score(area):
                    if not area.patterns or "include" not in area.patterns:
                        return (999, True, 0)  # worst score

                    first_pattern = area.patterns["include"][0]
                    path_depth = first_pattern.count("/")
                    in_tests = "/tests/" in first_pattern or first_pattern.startswith("tests/")

                    return (path_depth, in_tests, 0)

                best_area = min(duplicate_areas, key=area_score)
                unique_areas.append(best_area)

        return unique_areas

    def _detect_languages(self) -> Dict[str, Dict]:
        """
        Detect languages used in the project.

        Returns:
            Dict mapping language name to detection info
        """
        languages = {}

        for lang_name, lang_info in DiscoveryConfig.LANGUAGE_INDICATORS.items():
            score = 0
            found_indicators = []

            # Check for indicator files
            for indicator in lang_info["indicators"]:
                if "*" in indicator:
                    # Glob pattern
                    matches = list(self.project_root.glob(f"**/{indicator}"))
                    if matches:
                        score += 10
                        found_indicators.append(indicator)
                else:
                    # Exact file
                    if (self.project_root / indicator).exists():
                        score += 20
                        found_indicators.append(indicator)

            # Check for structural directories
            for structure in lang_info.get("structure", []):
                if (self.project_root / structure).exists():
                    score += 5

            if score > 0:
                languages[lang_name] = {
                    "score": score,
                    "indicators": found_indicators,
                    "config": lang_info,
                }

        return languages

    def _detect_monorepo(self) -> Tuple[bool, Dict[Path, Dict]]:
        """
        Detect if this is a monorepo and find sub-projects.

        Returns:
            Tuple of (is_monorepo, sub_projects_dict)
        """
        sub_projects = {}

        # Check for common monorepo indicators
        monorepo_indicators = [
            "lerna.json",
            "nx.json",
            "pnpm-workspace.yaml",
            "packages/",
            "apps/",
        ]

        is_monorepo = any((self.project_root / indicator).exists() for indicator in monorepo_indicators)

        if not is_monorepo:
            # Check for multiple project config files at depth 1-2
            project_configs = []
            for pattern in ["*/pyproject.toml", "*/package.json", "*/sfdx-project.json",
                            "*/*/pyproject.toml", "*/*/package.json"]:
                project_configs.extend(self.project_root.glob(pattern))

            if len(project_configs) > 1:
                is_monorepo = True

        if is_monorepo:
            # Find sub-projects (look at depth 1, 2, and 3)
            for config_file in ["pyproject.toml", "package.json", "sfdx-project.json", "astro.config.mjs"]:
                # Check depth 1, 2, and 3
                for pattern in [f"*/{config_file}", f"*/*/{config_file}", f"*/*/*/{config_file}"]:
                    for path in self.project_root.glob(pattern):
                        project_dir = path.parent

                        # Skip if already found or is project root
                        if project_dir in sub_projects or project_dir == self.project_root:
                            continue

                        # Skip excluded directories
                        try:
                            rel_str = str(project_dir.relative_to(self.project_root))
                            excluded_dirs = [
                                "__pycache__", "node_modules", ".git", "dist", "build",
                                ".venv", ".cdg", "coverage", ".pytest_cache", ".mypy_cache"
                            ]
                            if any(excl in rel_str for excl in excluded_dirs):
                                continue
                        except ValueError:
                            continue

                        # Detect languages in this sub-project
                        sub_languages = {}
                        for lang_name, lang_info in DiscoveryConfig.LANGUAGE_INDICATORS.items():
                            for indicator in lang_info["indicators"]:
                                if "*" not in indicator:
                                    if (project_dir / indicator).exists():
                                        sub_languages[lang_name] = lang_info
                                        break

                        if sub_languages:
                            sub_projects[project_dir] = {
                                "name": project_dir.name,
                                "languages": sub_languages,
                                "config_file": config_file,
                            }

        return is_monorepo, sub_projects

    def _create_areas_for_project(self, project_path: Path, project_info: Dict) -> List[FocusArea]:
        """
        Create focus areas for a single project.

        Args:
            project_path: Path to project root
            project_info: Project metadata (languages, etc.)

        Returns:
            List of focus areas for this project
        """
        areas = []
        languages = project_info.get("languages", {})

        # Get relative path for pattern prefixes
        try:
            rel_path = project_path.relative_to(self.project_root)
            path_prefix = str(rel_path) + "/" if rel_path != Path(".") else ""
        except ValueError:
            path_prefix = ""

        # Determine project type and create appropriate areas
        if "python" in languages:
            areas.extend(self._create_python_areas(project_path, path_prefix))

        if "javascript" in languages or "nextjs" in languages:
            areas.extend(self._create_javascript_areas(project_path, path_prefix))

        if "salesforce" in languages:
            areas.extend(self._create_salesforce_areas(project_path, path_prefix))

        if "astro" in languages:
            areas.extend(self._create_astro_areas(project_path, path_prefix))

        # Create common areas (docs, scripts, tests)
        areas.extend(self._create_common_areas(project_path, path_prefix))

        return areas

    def _create_python_areas(self, project_path: Path, path_prefix: str) -> List[FocusArea]:
        """Create focus areas for Python projects."""
        areas = []

        # Find Python package directories (any directory with __init__.py at appropriate depth)
        package_dirs = []

        # Look for packages in common locations: top-level, src/, and nested packages
        for init_file in project_path.glob("**/__init__.py"):
            package_dir = init_file.parent

            # Skip excluded directories
            should_skip = False
            rel_str = str(package_dir.relative_to(project_path))

            # Check against common exclusions
            excluded_dirs = [
                "__pycache__", "node_modules", ".git", "dist", "build",
                ".venv", ".cdg", "coverage", ".pytest_cache", ".mypy_cache"
            ]
            if any(excl in rel_str for excl in excluded_dirs):
                should_skip = True

            if should_skip:
                continue

            # Skip if it's a nested package (we want top-level packages)
            # A top-level package is one that's either directly in project root,
            # in a src/ dir, or in a subdirectory at depth 1-2
            try:
                rel_path = package_dir.relative_to(project_path)
                depth = len(rel_path.parts)

                # Include packages at depth 1-3 (e.g., flowmason/core/flowmason_core, flowmason/studio/flowmason_studio)
                if depth <= 3 and package_dir not in package_dirs:
                    package_dirs.append(package_dir)
            except ValueError:
                continue

        # Create area for each major package
        for package_dir in package_dirs:
            rel_package = package_dir.relative_to(project_path)
            package_name = package_dir.name

            # Get subdirectories as potential sub-areas
            subdirs = [d for d in package_dir.iterdir() if d.is_dir() and not d.name.startswith("_")]

            if len(subdirs) > 3:
                # Create areas for major subdirectories
                for subdir in subdirs:
                    if subdir.name in ["__pycache__", ".pytest_cache"]:
                        continue

                    area_id = self._slugify(f"{path_prefix}{package_name}-{subdir.name}")
                    area_name = f"{package_name.title()} - {subdir.name.replace('_', ' ').title()}"

                    areas.append(FocusArea(
                        id=area_id,
                        name=area_name,
                        description=f"{subdir.name.replace('_', ' ').title()} module",
                        type="auto-detected",
                        patterns={
                            "include": [f"{path_prefix}{rel_package}/{subdir.name}/**/*.py"],
                            "exclude": ["**/__pycache__/**", "**/*.pyc"],
                        },
                        metadata={
                            "language": "python",
                            "framework": "pytest",
                            "packageName": package_name,
                            "submodule": subdir.name,
                        },
                        quickAccess={
                            "commonTasks": [
                                f"pytest {path_prefix}tests/{subdir.name}/",
                                f"pytest --cov={path_prefix}{rel_package}/{subdir.name}",
                            ]
                        },
                    ))
            else:
                # Single area for whole package
                area_id = self._slugify(f"{path_prefix}{package_name}")
                area_name = f"{package_name.replace('_', ' ').title()}"

                areas.append(FocusArea(
                    id=area_id,
                    name=area_name,
                    description=f"{package_name} Python package",
                    type="auto-detected",
                    patterns={
                        "include": [f"{path_prefix}{rel_package}/**/*.py"],
                        "exclude": ["**/__pycache__/**", "**/*.pyc"],
                    },
                    metadata={
                        "language": "python",
                        "framework": "pytest",
                        "packageName": package_name,
                    },
                    quickAccess={
                        "commonTasks": [
                            f"pytest {path_prefix}tests/",
                            f"pytest --cov={path_prefix}{rel_package}",
                        ]
                    },
                ))

        # Create test area
        test_dir = project_path / "tests"
        if test_dir.exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}tests"),
                name=f"{'Tests' if not path_prefix else path_prefix.rstrip('/') + ' Tests'}",
                description="Test suite",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}tests/**/*.py"],
                    "exclude": ["**/__pycache__/**", "**/*.pyc"],
                },
                metadata={
                    "language": "python",
                    "framework": "pytest",
                    "type": "tests",
                },
                quickAccess={
                    "commonTasks": [
                        f"pytest {path_prefix}tests/",
                        f"pytest {path_prefix}tests/ -v",
                        f"pytest {path_prefix}tests/ --cov",
                    ]
                },
            ))

        return areas

    def _create_javascript_areas(self, project_path: Path, path_prefix: str) -> List[FocusArea]:
        """Create focus areas for JavaScript/TypeScript projects."""
        areas = []

        # Check for Next.js structure
        if (project_path / "app").exists() or (project_path / "pages").exists():
            # Next.js project
            if (project_path / "app").exists():
                areas.append(FocusArea(
                    id=self._slugify(f"{path_prefix}nextjs-app"),
                    name=f"{path_prefix.rstrip('/')} App" if path_prefix else "Next.js App",
                    description="Next.js app directory",
                    type="auto-detected",
                    patterns={
                        "include": [f"{path_prefix}app/**/*.tsx", f"{path_prefix}app/**/*.ts"],
                        "exclude": ["**/node_modules/**"],
                    },
                    metadata={
                        "language": "typescript",
                        "framework": "nextjs",
                        "type": "frontend",
                    },
                ))

            if (project_path / "components").exists():
                areas.append(FocusArea(
                    id=self._slugify(f"{path_prefix}components"),
                    name=f"{path_prefix.rstrip('/')} Components" if path_prefix else "Components",
                    description="React components",
                    type="auto-detected",
                    patterns={
                        "include": [f"{path_prefix}components/**/*.tsx", f"{path_prefix}components/**/*.ts"],
                        "exclude": ["**/node_modules/**"],
                    },
                    metadata={
                        "language": "typescript",
                        "framework": "react",
                        "type": "frontend",
                    },
                ))

        # Check for general src structure
        elif (project_path / "src").exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}src"),
                name=f"{path_prefix.rstrip('/')} Source" if path_prefix else "Source",
                description="Source code",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}src/**/*.ts", f"{path_prefix}src/**/*.js"],
                    "exclude": ["**/node_modules/**", "**/*.test.ts", "**/*.spec.ts"],
                },
                metadata={
                    "language": "typescript",
                },
            ))

        return areas

    def _create_salesforce_areas(self, project_path: Path, path_prefix: str) -> List[FocusArea]:
        """Create focus areas for Salesforce projects."""
        areas = []

        force_app = project_path / "force-app" / "main" / "default"
        if not force_app.exists():
            return areas

        # Apex classes
        classes_dir = force_app / "classes"
        if classes_dir.exists():
            # Separate test and non-test classes
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}salesforce-apex"),
                name=f"{path_prefix.rstrip('/')} Salesforce Apex" if path_prefix else "Salesforce Apex",
                description="Apex classes and logic",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}force-app/main/default/classes/**/*.cls"],
                    "exclude": [f"{path_prefix}force-app/main/default/classes/**/*Test.cls",
                                f"{path_prefix}force-app/main/default/classes/**/*_Test.cls"],
                },
                metadata={
                    "language": "apex",
                    "framework": "salesforce",
                    "type": "backend",
                },
                quickAccess={
                    "commonTasks": [
                        "sf project deploy start",
                        "sf apex run test --test-level RunLocalTests",
                    ]
                },
            ))

            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}salesforce-apex-tests"),
                name=f"{path_prefix.rstrip('/')} Salesforce Apex Tests" if path_prefix else "Salesforce Apex Tests",
                description="Apex test classes",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}force-app/main/default/classes/**/*Test.cls",
                                f"{path_prefix}force-app/main/default/classes/**/*_Test.cls"],
                    "exclude": [],
                },
                metadata={
                    "language": "apex",
                    "framework": "salesforce",
                    "type": "tests",
                },
                quickAccess={
                    "commonTasks": [
                        "sf apex run test --test-level RunLocalTests",
                        "sf apex get test --code-coverage",
                    ]
                },
            ))

        # Lightning Web Components
        lwc_dir = force_app / "lwc"
        if lwc_dir.exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}salesforce-lwc"),
                name=f"{path_prefix.rstrip('/')} Lightning Web Components" if path_prefix else "Lightning Web Components",
                description="Lightning Web Components",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}force-app/main/default/lwc/**/*.js",
                                f"{path_prefix}force-app/main/default/lwc/**/*.html"],
                    "exclude": [f"{path_prefix}force-app/main/default/lwc/**/__tests__/**"],
                },
                metadata={
                    "language": "javascript",
                    "framework": "lwc",
                    "type": "frontend",
                },
            ))

        return areas

    def _create_astro_areas(self, project_path: Path, path_prefix: str) -> List[FocusArea]:
        """Create focus areas for Astro projects."""
        areas = []

        src_dir = project_path / "src"
        if not src_dir.exists():
            return areas

        # Pages
        if (src_dir / "pages").exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}astro-pages"),
                name=f"{path_prefix.rstrip('/')} Pages" if path_prefix else "Astro Pages",
                description="Astro pages",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}src/pages/**/*.astro"],
                    "exclude": [],
                },
                metadata={
                    "language": "astro",
                    "framework": "astro",
                    "type": "frontend",
                },
            ))

        # Components
        if (src_dir / "components").exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}astro-components"),
                name=f"{path_prefix.rstrip('/')} Components" if path_prefix else "Astro Components",
                description="Astro components",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}src/components/**/*.astro", f"{path_prefix}src/components/**/*.tsx"],
                    "exclude": [],
                },
                metadata={
                    "language": "astro",
                    "framework": "astro",
                    "type": "frontend",
                },
            ))

        return areas

    def _create_common_areas(self, project_path: Path, path_prefix: str) -> List[FocusArea]:
        """Create common areas (docs, scripts) if they exist."""
        areas = []

        # Documentation
        docs_dir = project_path / "docs"
        if docs_dir.exists() and list(docs_dir.glob("**/*.md")):
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}docs"),
                name=f"{path_prefix.rstrip('/')} Documentation" if path_prefix else "Documentation",
                description="Project documentation",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}docs/**/*.md", f"{path_prefix}docs/**/*.mdx"],
                    "exclude": [],
                },
                metadata={
                    "type": "documentation",
                },
            ))

        # Scripts
        scripts_dir = project_path / "scripts"
        if scripts_dir.exists():
            areas.append(FocusArea(
                id=self._slugify(f"{path_prefix}scripts"),
                name=f"{path_prefix.rstrip('/')} Scripts" if path_prefix else "Scripts",
                description="Utility scripts",
                type="auto-detected",
                patterns={
                    "include": [f"{path_prefix}scripts/**/*.py", f"{path_prefix}scripts/**/*.sh",
                                f"{path_prefix}scripts/**/*.js"],
                    "exclude": [],
                },
                metadata={
                    "type": "scripts",
                },
            ))

        return areas

    def _slugify(self, text: str) -> str:
        """Convert text to slug (lowercase, hyphens)."""
        # Remove leading/trailing slashes and dots
        text = text.strip("/.")
        # Replace slashes and underscores with hyphens
        text = text.replace("/", "-").replace("_", "-")
        # Remove special characters
        text = re.sub(r'[^a-z0-9-]', '', text.lower())
        # Remove consecutive hyphens
        text = re.sub(r'-+', '-', text)
        return text.strip("-")
