"""
ContextDigger Refusal Mode

Implements refusal to load oversized areas, enforcing budget discipline.
When an area exceeds budget limits, ContextDigger refuses to load it and
guides the user toward better scoping decisions.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Optional
from collections import defaultdict


@dataclass
class SubArea:
    """Represents a suggested sub-area when an area is too large."""

    name: str
    path: str
    file_count: int
    line_count: int
    description: str
    files: List[Path]


class RefusalHandler:
    """
    Handles refusal scenarios when areas exceed budget.

    Core governance mechanism: ContextDigger refuses to load oversized areas,
    forcing intentional decisions about scope.
    """

    def __init__(self, max_files: int = 15, max_lines: int = 3000):
        """
        Initialize refusal handler.

        Args:
            max_files: Maximum files allowed
            max_lines: Maximum lines allowed
        """
        self.max_files = max_files
        self.max_lines = max_lines

    def format_refusal_message(
        self,
        area_name: str,
        files_used: int,
        lines_used: int,
        reason: str = "file budget"
    ) -> str:
        """
        Format refusal message explaining why area was rejected.

        Args:
            area_name: Name of the area
            files_used: Number of files in area
            lines_used: Number of lines in area
            reason: Why it was refused (default: "file budget")

        Returns:
            Formatted refusal message
        """
        limit_type = "files" if files_used > self.max_files else "lines"
        limit_value = self.max_files if files_used > self.max_files else self.max_lines
        actual_value = files_used if files_used > self.max_files else lines_used

        message = f"\n❌ ERROR: Area too large ({actual_value} {limit_type} > {limit_value} {limit_type} budget)\n"
        message += f"\nThe '{area_name}' area exceeds budget limits.\n"
        message += f"  Files: {files_used} (limit: {self.max_files})\n"
        message += f"  Lines: {lines_used:,} (limit: {self.max_lines:,})\n"

        return message

    def suggest_sub_areas(
        self,
        files: List[Path],
        area_name: str,
        project_root: Path
    ) -> List[SubArea]:
        """
        Break large area into smaller sub-areas by directory.

        Strategy:
        1. Group files by parent directory
        2. Calculate file/line counts per directory
        3. Suggest directories that fit within budget
        4. Return top 4 suggestions

        Args:
            files: List of files in the oversized area
            area_name: Name of the parent area
            project_root: Project root path for relative path calculation

        Returns:
            List of SubArea suggestions
        """
        # Group files by parent directory
        files_by_dir: Dict[Path, List[Path]] = defaultdict(list)

        for file_path in files:
            # Get parent directory relative to project root
            try:
                rel_path = file_path.relative_to(project_root)
                parent = rel_path.parent
            except ValueError:
                parent = file_path.parent

            files_by_dir[parent].append(file_path)

        # Create sub-area suggestions
        sub_areas = []

        for dir_path, dir_files in files_by_dir.items():
            file_count = len(dir_files)

            # Only suggest directories that fit within budget
            if file_count <= self.max_files:
                # Calculate line count
                line_count = sum(self._count_lines(f) for f in dir_files)

                # Create sub-area
                sub_area = SubArea(
                    name=f"{area_name}-{dir_path.name}",
                    path=str(dir_path),
                    file_count=file_count,
                    line_count=line_count,
                    description=f"{dir_path.name} module",
                    files=dir_files
                )
                sub_areas.append(sub_area)

        # Sort by file count (prefer smaller, more focused areas)
        sub_areas.sort(key=lambda x: x.file_count)

        return sub_areas[:4]  # Return top 4 suggestions

    def format_sub_area_suggestions(self, sub_areas: List[SubArea]) -> str:
        """
        Format sub-area suggestions for display.

        Args:
            sub_areas: List of suggested sub-areas

        Returns:
            Formatted suggestion text
        """
        if not sub_areas:
            return "\nNo suitable sub-areas found. Consider creating a custom area."

        message = "\nSuggested sub-areas:\n"

        for i, sub in enumerate(sub_areas, 1):
            within_budget = "✓" if sub.line_count <= self.max_lines else "⚠️"
            message += f"\n{i}. {sub.name}\n"
            message += f"   Path: {sub.path}\n"
            message += f"   Size: {sub.file_count} files, {sub.line_count:,} lines {within_budget}\n"
            message += f"   {sub.description}\n"

        return message

    def format_options(self, files_used: int, lines_used: int) -> str:
        """
        Format available options when refusal occurs.

        Args:
            files_used: Number of files in oversized area
            lines_used: Number of lines in oversized area

        Returns:
            Formatted options text
        """
        message = "\nOptions:\n"
        message += "1. Focus on a sub-area (recommended)\n"
        message += f"2. Increase budget to {files_used} files / {lines_used:,} lines (requires explicit confirmation)\n"
        message += "3. Exit and refine your area definition\n"
        message += f"\n⚠️  ContextDigger will not load all {files_used} files without a decision.\n"

        return message

    def display_refusal(
        self,
        area_name: str,
        files: List[Path],
        files_used: int,
        lines_used: int,
        project_root: Path
    ) -> None:
        """
        Display complete refusal message with suggestions and options.

        Args:
            area_name: Name of the area
            files: Files in the area
            files_used: Number of files
            lines_used: Number of lines
            project_root: Project root path
        """
        # Display refusal message
        print(self.format_refusal_message(area_name, files_used, lines_used))

        # Suggest sub-areas
        sub_areas = self.suggest_sub_areas(files, area_name, project_root)
        print(self.format_sub_area_suggestions(sub_areas))

        # Display options
        print(self.format_options(files_used, lines_used))

    def _count_lines(self, file_path: Path) -> int:
        """
        Count lines in a file.

        Args:
            file_path: Path to file

        Returns:
            Number of lines in file
        """
        try:
            if not file_path.exists():
                return 0

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for _ in f)
        except Exception:
            return 0


def should_refuse(files_used: int, lines_used: int, max_files: int, max_lines: int) -> bool:
    """
    Check if area should be refused based on budget.

    Args:
        files_used: Number of files in area
        lines_used: Number of lines in area
        max_files: Maximum files allowed
        max_lines: Maximum lines allowed

    Returns:
        True if area exceeds budget and should be refused
    """
    return files_used > max_files or lines_used > max_lines
