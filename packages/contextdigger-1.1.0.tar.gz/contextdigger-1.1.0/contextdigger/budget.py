"""
ContextDigger Budget System

Tracks and enforces context budgets (max files, max lines).
Implements governance discipline through hard limits.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class BudgetStatus:
    """Represents the budget status for a set of files."""

    files_used: int
    files_max: int
    lines_used: int
    lines_max: int

    @property
    def percentage_files(self) -> float:
        """Percentage of file budget used."""
        if self.files_max == 0:
            return 0.0
        return self.files_used / self.files_max

    @property
    def percentage_lines(self) -> float:
        """Percentage of line budget used."""
        if self.lines_max == 0:
            return 0.0
        return self.lines_used / self.lines_max

    @property
    def exceeds(self) -> bool:
        """True if budget is exceeded."""
        return self.files_used > self.files_max or self.lines_used > self.lines_max

    @property
    def within_budget(self) -> bool:
        """True if within budget."""
        return not self.exceeds

    @property
    def at_warning_threshold(self) -> bool:
        """True if at or above 80% budget usage."""
        return self.percentage_files >= 0.8 or self.percentage_lines >= 0.8


class BudgetTracker:
    """
    Tracks context budget usage.

    Implements the core governance mechanism: context budgets are ENFORCED,
    not suggested. This is the foundation of disciplined AI attention.
    """

    def __init__(self, max_files: int = 15, max_lines: int = 3000):
        """
        Initialize budget tracker.

        Args:
            max_files: Maximum number of files allowed (default: 15)
            max_lines: Maximum total lines allowed (default: 3000)
        """
        self.max_files = max_files
        self.max_lines = max_lines
        self._line_count_cache = {}  # Cache for file line counts

    def calculate_budget(self, files: List[Path]) -> BudgetStatus:
        """
        Calculate budget usage for a set of files.

        Args:
            files: List of file paths

        Returns:
            BudgetStatus with usage information
        """
        file_count = len(files)
        line_count = sum(self._count_lines(f) for f in files)

        return BudgetStatus(
            files_used=file_count,
            files_max=self.max_files,
            lines_used=line_count,
            lines_max=self.max_lines
        )

    def is_within_budget(self, files: List[Path]) -> bool:
        """
        Check if files fit within budget.

        Args:
            files: List of file paths

        Returns:
            True if within budget, False otherwise
        """
        budget = self.calculate_budget(files)
        return budget.within_budget

    def format_budget_display(self, budget: BudgetStatus) -> str:
        """
        Format budget for display.

        Args:
            budget: BudgetStatus to format

        Returns:
            Formatted string like "Budget: 12/15 files, 2,340/3,000 lines."
        """
        return (
            f"Budget: {budget.files_used}/{budget.files_max} files, "
            f"{budget.lines_used:,}/{budget.lines_max:,} lines."
        )

    def _count_lines(self, file_path: Path) -> int:
        """
        Count lines in a file.

        Uses cache to avoid re-counting unchanged files.

        Args:
            file_path: Path to file

        Returns:
            Number of lines in file
        """
        file_path = Path(file_path)

        # Check cache
        cache_key = str(file_path.absolute())
        if cache_key in self._line_count_cache:
            cached_mtime, cached_count = self._line_count_cache[cache_key]
            if file_path.exists() and file_path.stat().st_mtime == cached_mtime:
                return cached_count

        # Count lines
        try:
            if not file_path.exists():
                return 0

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                count = sum(1 for _ in f)

            # Update cache
            self._line_count_cache[cache_key] = (file_path.stat().st_mtime, count)
            return count

        except Exception:
            # If we can't read the file, assume 0 lines
            return 0

    def get_budget_breakdown(self, files: List[Path]) -> dict:
        """
        Get detailed budget breakdown by file.

        Args:
            files: List of file paths

        Returns:
            Dict with per-file line counts and totals
        """
        file_details = []
        total_lines = 0

        for file_path in files:
            lines = self._count_lines(file_path)
            total_lines += lines
            file_details.append({
                'file': str(file_path),
                'lines': lines,
                'percentage': 0.0  # Will calculate after we have total
            })

        # Calculate percentages
        for detail in file_details:
            if total_lines > 0:
                detail['percentage'] = detail['lines'] / total_lines

        return {
            'files': file_details,
            'total_files': len(files),
            'total_lines': total_lines,
            'max_files': self.max_files,
            'max_lines': self.max_lines
        }


def create_budget_tracker_from_config(config: dict) -> BudgetTracker:
    """
    Create BudgetTracker from configuration.

    Args:
        config: Configuration dict with 'budgets' section

    Returns:
        BudgetTracker instance
    """
    budgets = config.get('budgets', {})
    max_files = budgets.get('max_files', 15)
    max_lines = budgets.get('max_lines', 3000)

    return BudgetTracker(max_files=max_files, max_lines=max_lines)
